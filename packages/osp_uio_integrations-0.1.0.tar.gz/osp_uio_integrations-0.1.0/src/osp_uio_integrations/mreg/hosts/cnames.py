"""Host CNAME operations.

This module owns the alias-oriented workflows around the MREG CNAME endpoints.
Those workflows are more than plain CRUD: they need host-vs-alias conflict
checks, forward-zone validation, and a stable distinction between "missing
alias", "alias is already a host", and "alias belongs to another host".

Keeping that logic here prevents the rest of the host surface from needing to
understand the operational rules around alias management.
"""

from __future__ import annotations

from typing import Any, cast

from ..enums import CompatibilityFallback, RequestMethod, ValidationSource
from ..exceptions import (
    ConflictError,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from ._shared import extract_results
from .models import CnameRecord
from .queries import HostQueries


class HostCnameAPI:
    """Host-facing API for CNAME alias workflows.

    The class exposes alias operations in host terms rather than record-id
    terms. It owns the endpoint-aware checks needed to keep alias behavior
    predictable for callers importing the library rather than using the CLI.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the CNAME API."""
        self._client = client
        self._queries = queries

    def many(
        self,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> list[CnameRecord]:
        """Return CNAME records associated with one host."""
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        host_id = _require_host_id(host=host, endpoint=f"/api/v1/hosts/{hostname}")
        data = self._client.get_json(
            "/api/v1/cnames/",
            params={"host": str(host_id)},
            correlation_id=correlation_id,
        )
        return [
            self._parse_cname_payload(item, endpoint="/api/v1/cnames/", method=RequestMethod.GET)
            for item in extract_results(data, endpoint="/api/v1/cnames/")
        ]

    def get(self, alias: str, *, correlation_id: str | None = None) -> CnameRecord | None:
        """Return one CNAME by alias, or `None` if it does not exist."""
        data = self._client.get_json(
            f"/api/v1/cnames/{alias}",
            soft_404=True,
            correlation_id=correlation_id,
        )
        if not data:
            return None
        return self._parse_cname_payload(
            data,
            endpoint=f"/api/v1/cnames/{alias}",
            method=RequestMethod.GET,
        )

    def get_required(self, alias: str, *, correlation_id: str | None = None) -> CnameRecord:
        """Return one CNAME by alias or raise if it does not exist."""
        cname = self.get(alias, correlation_id=correlation_id)
        if cname is None:
            raise NotFoundError(
                f"CNAME {alias!r} was not found",
                method=RequestMethod.GET,
                endpoint=f"/api/v1/cnames/{alias}",
            )
        return cname

    def add(
        self,
        hostname: str,
        alias: str,
        *,
        correlation_id: str | None = None,
    ) -> CnameRecord:
        """Add one alias and point it at the supplied host.

        The method enforces the operational distinctions that matter for
        callers: an alias cannot shadow an existing host name, and an existing
        CNAME owned by another host is a conflict rather than a silent move.

        Args:
            hostname: Canonical host that should own the alias.
            alias: Alias name to create.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            The created or already-existing ``CnameRecord`` when the alias
            already points at the requested host.
        """
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        host_id = _require_host_id(host=host, endpoint=f"/api/v1/hosts/{hostname}")

        alias_host = self._queries.get(alias, correlation_id=correlation_id)
        if alias_host is not None:
            raise ConflictError(
                f"The alias {alias!r} is already a host",
                method=RequestMethod.GET,
                endpoint=f"/api/v1/hosts/{alias}",
            )

        existing = self.get(alias, correlation_id=correlation_id)
        if existing is not None:
            if existing.host_id == host_id:
                return existing
            raise ConflictError(
                f"The alias {alias!r} is already in use by another host",
                method=RequestMethod.GET,
                endpoint=f"/api/v1/cnames/{alias}",
            )

        self._require_forward_zone(alias, correlation_id=correlation_id)

        created_payload = self._client.post_json(
            "/api/v1/cnames/",
            json={"host": str(host_id), "name": alias},
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if isinstance(created_payload, dict):
            created = self._parse_cname_payload(
                created_payload,
                endpoint="/api/v1/cnames/",
                method=RequestMethod.POST,
            )
            if created.name != alias or created.host_id != host_id:
                raise ResponseDecodeError(
                    "MREG create response did not match the requested CNAME",
                    method=RequestMethod.POST,
                    endpoint="/api/v1/cnames/",
                )
            return created
        if created_payload is not None:
            raise ResponseDecodeError(
                "MREG CNAME create response did not match a supported JSON shape",
                method=RequestMethod.POST,
                endpoint="/api/v1/cnames/",
            )
        try:
            created = self.get_required(alias, correlation_id=correlation_id)
        except NotFoundError as exc:
            raise RequestFailedError(
                "CNAME create returned an empty success response, and verification "
                "did not find the alias. Inspect MREG if needed, but this is "
                "treated as a failed create rather than an uncertain partial "
                "mutation.",
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/cnames/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "Created CNAME upstream, but verification failed. Upstream "
                "state may be partially updated. Inspect the alias in MREG "
                "before deciding whether to retry.",
                operation="create_cname",
                completed_steps=(MutationStep("create_request"),),
                remaining_steps=(MutationStep("verify_created_object"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/cnames/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        return created

    def remove(
        self,
        hostname: str,
        alias: str,
        *,
        correlation_id: str | None = None,
    ) -> None:
        """Remove one alias from the supplied host.

        The removal path keeps host-vs-alias confusion explicit. If the name
        resolves as a real host instead of a CNAME, the caller gets a local
        validation failure instead of accidentally treating host identity as an
        alias record.
        """
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        host_id = _require_host_id(host=host, endpoint=f"/api/v1/hosts/{hostname}")

        alias_host = self._queries.get(alias, correlation_id=correlation_id)
        if alias_host is not None and alias_host.name == alias:
            raise ValidationError(
                f"The alias {alias!r} is a host, not a CNAME",
                source=ValidationSource.LOCAL,
                method=RequestMethod.GET,
                endpoint=f"/api/v1/hosts/{alias}",
            )

        cname = self.get_required(alias, correlation_id=correlation_id)
        if cname.host_id != host_id:
            raise ConflictError(
                f"The alias {alias!r} is associated with another host",
                method=RequestMethod.GET,
                endpoint=f"/api/v1/cnames/{alias}",
            )

        self._client.delete_json(
            f"/api/v1/cnames/{alias}",
            correlation_id=correlation_id,
        )

    def replace(
        self,
        alias: str,
        hostname: str,
        *,
        correlation_id: str | None = None,
    ) -> CnameRecord:
        """Repoint an existing alias at another host.

        Args:
            alias: Existing alias to move.
            hostname: Destination host that should own the alias.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Updated alias record after the move has been persisted upstream.
        """
        host = self._queries.get_required(hostname, correlation_id=correlation_id)
        host_id = _require_host_id(host=host, endpoint=f"/api/v1/hosts/{hostname}")
        self.get_required(alias, correlation_id=correlation_id)

        self._client.patch_json(
            f"/api/v1/cnames/{alias}",
            json={"host": host_id},
            allow_empty=True,
            correlation_id=correlation_id,
        )
        try:
            updated = self.get_required(alias, correlation_id=correlation_id)
        except NotFoundError as exc:
            raise RequestFailedError(
                "CNAME replace returned an empty success response, and verification "
                "did not find the alias. Inspect MREG if needed, but this is "
                "treated as a failed replace rather than an uncertain partial "
                "mutation.",
                method=RequestMethod.PATCH,
                status_code=exc.status_code,
                endpoint=f"/api/v1/cnames/{alias}",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "Replaced CNAME upstream, but verification failed. Upstream "
                "state may be partially updated. Inspect the alias in MREG "
                "before deciding whether to retry.",
                operation="replace_cname",
                completed_steps=(MutationStep("replace_request"),),
                remaining_steps=(MutationStep("verify_replaced_object"),),
                method=RequestMethod.PATCH,
                status_code=exc.status_code,
                endpoint=f"/api/v1/cnames/{alias}",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc
        return updated

    def _parse_cname_payload(
        self,
        payload: object,
        *,
        endpoint: str,
        method: RequestMethod,
    ) -> CnameRecord:
        """Interpret one MREG CNAME payload into the stable library shape.

        Args:
            payload: Raw decoded JSON payload returned by a CNAME endpoint.
            endpoint: Endpoint path used to annotate decode failures.
            method: HTTP method associated with the payload.

        Returns:
            Stable ``CnameRecord`` instance.

        Raises:
            ResponseDecodeError: Payload was not a JSON object or did not carry
                the alias name required by the library contract.
        """
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG CNAME payload was not a JSON object",
                method=method,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)
        name = payload_dict.get("name")
        if not isinstance(name, str) or not name.strip():
            raise ResponseDecodeError(
                "MREG CNAME payload did not include an alias name",
                method=method,
                endpoint=endpoint,
            )
        return CnameRecord(
            id=_optional_int(payload_dict.get("id")),
            name=name.strip(),
            host_id=_optional_int(payload_dict.get("host")),
            raw=dict(payload_dict),
        )

    def _require_forward_zone(self, alias: str, *, correlation_id: str | None) -> None:
        """Require that MREG manages a forward zone for the alias name.

        This check stays local to the alias boundary because it is an
        endpoint-specific DNS rule, not a generic host lookup concern.
        """
        zone = self._client.get_json(
            f"/api/v1/zones/forward/hostname/{alias}",
            soft_404=True,
            correlation_id=correlation_id,
        )
        if zone:
            return
        raise NotFoundError(
            f"No forward zone was found for alias {alias!r}",
            method=RequestMethod.GET,
            endpoint=f"/api/v1/zones/forward/hostname/{alias}",
        )


def _optional_int(value: object) -> int | None:
    """Normalize optional integer fields from MREG payloads."""
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def _require_host_id(*, endpoint: str, host: Any) -> int:
    """Require a parsed host ID for host-linked mutations."""
    host_id = getattr(host, "id", None)
    if isinstance(host_id, int):
        return host_id
    raise ResponseDecodeError(
        "MREG host payload did not include a host ID",
        method=RequestMethod.GET,
        endpoint=endpoint,
    )
