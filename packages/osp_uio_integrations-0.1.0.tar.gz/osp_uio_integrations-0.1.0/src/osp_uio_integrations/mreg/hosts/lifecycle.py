"""Basic host lifecycle operations.

This module owns the smallest host lifecycle surface needed by the library:
create and delete. It keeps the create-payload shaping and the legacy
JSON-to-form compatibility fallback close to the host-create path instead of
spreading those details across callers. It also owns the narrow "write
accepted, verification failed" behavior for host creation so callers do not
mistake uncertain upstream state for an ordinary decode problem.

It does not try to model every host provisioning concern. The goal is to give
other code one boring, explicit way to create and delete MREG host entries.
"""

from __future__ import annotations

import ipaddress
from typing import Any

from ..enums import CompatibilityFallback, RequestMethod, ValidationSource
from ..exceptions import (
    MregError,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ValidationError,
)
from .contacts import _normalize_contacts
from .models import HostRecord
from .queries import HostQueries


class HostLifecycleAPI:
    """Host-facing API for host create and delete.

    More complex provisioning workflows belong to higher-level callers; this
    module only owns the MREG host create and delete contract plus the local
    validation needed to call it safely.
    """

    def __init__(self, client: Any, queries: HostQueries) -> None:
        """Initialize the lifecycle API."""
        self._client = client
        self._queries = queries

    def create(
        self,
        name: str,
        *,
        contacts: list[str] | None = None,
        comment: str | None = None,
        ipaddress: str | None = None,
        network: str | None = None,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Create one host through the narrow lifecycle surface.

        Exposes the host create contract that exists in MREG: host identity
        plus a few creation-time convenience fields. Larger provisioning
        workflows belong outside this library.

        Args:
            name: Canonical host name to create in MREG.
            contacts: Optional siteadmin identifiers that should be installed
                on the new host at creation time.
            comment: Optional free-text comment forwarded to MREG.
            ipaddress: Optional fixed IP address to bind during creation.
            network: Optional network identifier used to ask MREG for address
                allocation.
            force: Whether to bypass local guard checks that would otherwise
                reject wildcard host names.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Newly created host in normalized ``HostRecord`` form.

        Raises:
            MutationStateUncertainError: MREG accepted the create request, but
                the follow-up verification request failed before the client
                could confirm the resulting host state.
            ValidationError: The supplied name looks like a wildcard label and
                ``force`` was not set.
        """
        _validate_create_name(name, force=force)
        payload = _build_create_payload(
            name=name,
            contacts=contacts,
            comment=comment,
            ipaddress=ipaddress,
            network=network,
        )
        data = self._client.post_json(
            "/api/v1/hosts/",
            json=payload,
            allow_empty=True,
            compatibility_fallback=CompatibilityFallback.FORM,
            correlation_id=correlation_id,
        )
        if data is None:
            try:
                created = self._queries.get_required(name, correlation_id=correlation_id)
            except NotFoundError as exc:
                raise RequestFailedError(
                    "Host create returned an empty success response, and verification "
                    "did not find the new host. Inspect MREG if needed, but this is "
                    "treated as a failed create rather than an uncertain partial "
                    "mutation.",
                    method=RequestMethod.POST,
                    status_code=exc.status_code,
                    endpoint="/api/v1/hosts/",
                    request_id=exc.request_id,
                    correlation_id=exc.correlation_id or correlation_id,
                ) from exc
            except RequestFailedError as exc:
                raise MutationStateUncertainError(
                    "Host create request succeeded, but follow-up verification "
                    "failed. Upstream state may be partially updated. Inspect "
                    "the host in MREG before deciding whether to retry.",
                    operation="create_host",
                    completed_steps=(MutationStep("create_request"),),
                    remaining_steps=(MutationStep("verify_created_host"),),
                    method=RequestMethod.POST,
                    status_code=exc.status_code,
                    endpoint="/api/v1/hosts/",
                    request_id=exc.request_id,
                    correlation_id=exc.correlation_id or correlation_id,
                ) from exc
            return created
        return self._queries.parse_host_payload(
            data,
            endpoint="/api/v1/hosts/",
            method=RequestMethod.POST,
        )

    def create_with_addresses(
        self,
        name: str,
        *,
        ipv4: str | None = None,
        ipv6: str | None = None,
        contacts: list[str] | None = None,
        comment: str | None = None,
        force: bool = False,
        correlation_id: str | None = None,
    ) -> HostRecord:
        """Create a host and attach a secondary address when needed.

        MREG requires one address at host creation time, so dual-stack host
        creation is inherently a multi-step workflow. This helper exposes that
        common contract once for provider and service callers instead of making
        each caller rediscover the primary-plus-secondary sequence.

        On clean success it returns the final normalized host state. If the
        initial host create succeeds but the later secondary-address step
        fails, the method raises `MutationStateUncertainError` because the host
        now exists upstream in a partially completed state.
        """
        primary_ip, secondary_ip = _split_primary_and_secondary(ipv4=ipv4, ipv6=ipv6)
        created = self.create(
            name,
            contacts=contacts,
            comment=comment,
            ipaddress=primary_ip,
            force=force,
            correlation_id=correlation_id,
        )
        if secondary_ip is None:
            return created

        secondary_step = MutationStep("attach_secondary_address", detail=secondary_ip)
        host_id = created.id
        if host_id is None:
            try:
                resolved_host = self._queries.get_required(name, correlation_id=correlation_id)
            except RequestFailedError as exc:
                raise MutationStateUncertainError(
                    "Host create succeeded, but resolving the new host id for "
                    "secondary address attachment failed. Inspect MREG before "
                    "deciding whether to retry.",
                    operation="create_host_with_addresses",
                    completed_steps=(MutationStep("create_host"),),
                    remaining_steps=(secondary_step,),
                    method=RequestMethod.POST,
                    status_code=exc.status_code,
                    endpoint=exc.endpoint or "/api/v1/hosts/",
                    request_id=exc.request_id,
                    correlation_id=exc.correlation_id or correlation_id,
                ) from exc
            host_id = resolved_host.id
        if host_id is None:
            raise MutationStateUncertainError(
                "Host create succeeded, but the library could not resolve the "
                "new host id for secondary address attachment. Inspect MREG "
                "before deciding whether to retry.",
                operation="create_host_with_addresses",
                completed_steps=(MutationStep("create_host"),),
                remaining_steps=(secondary_step,),
                method=RequestMethod.POST,
                endpoint="/api/v1/hosts/",
                correlation_id=correlation_id,
            )
        try:
            self._client.post_json(
                "/api/v1/ipaddresses/",
                json={"host": str(host_id), "ipaddress": secondary_ip},
                allow_empty=True,
                compatibility_fallback=CompatibilityFallback.FORM,
                correlation_id=correlation_id,
            )
        except MregError as exc:
            raise MutationStateUncertainError(
                "Host create succeeded, but attaching the secondary address "
                "failed. The host now exists upstream in a partially completed "
                "state. Inspect MREG before deciding whether to retry.",
                operation="create_host_with_addresses",
                completed_steps=(MutationStep("create_host"),),
                remaining_steps=(secondary_step,),
                method=RequestMethod.POST,
                status_code=getattr(exc, "status_code", None),
                endpoint=getattr(exc, "endpoint", None) or "/api/v1/hosts/",
                request_id=getattr(exc, "request_id", None),
                correlation_id=getattr(exc, "correlation_id", None) or correlation_id,
            ) from exc

        try:
            return self._queries.get_required(name, correlation_id=correlation_id)
        except RequestFailedError as exc:
            raise MutationStateUncertainError(
                "Host create and secondary address attach request both "
                "succeeded, but the final host verification failed. Inspect "
                "MREG before deciding whether to retry.",
                operation="create_host_with_addresses",
                completed_steps=(
                    MutationStep("create_host"),
                    MutationStep("attach_secondary_address_request", detail=secondary_ip),
                ),
                remaining_steps=(MutationStep("verify_host_after_secondary_attach"),),
                method=RequestMethod.POST,
                status_code=exc.status_code,
                endpoint="/api/v1/ipaddresses/",
                request_id=exc.request_id,
                correlation_id=exc.correlation_id or correlation_id,
            ) from exc

    def delete(self, name: str, *, correlation_id: str | None = None) -> None:
        """Delete one host after confirming it currently exists upstream.

        The pre-read keeps missing-host behavior explicit and consistent with
        the rest of the library instead of depending on whatever delete
        semantics a particular MREG deployment exposes. Delete intentionally
        stays a single-step operation here; there is no follow-up verification
        or rollback layer.
        """
        self._queries.get_required(name, correlation_id=correlation_id)
        self._client.delete_json(
            f"/api/v1/hosts/{name}",
            correlation_id=correlation_id,
        )

    def delete_if_exists(self, name: str, *, correlation_id: str | None = None) -> bool:
        """Delete one host when present and treat absence as an idempotent no-op."""
        if not self._queries.exists(name, correlation_id=correlation_id):
            return False
        try:
            self._client.delete_json(
                f"/api/v1/hosts/{name}",
                correlation_id=correlation_id,
            )
        except NotFoundError:
            return False
        return True


def _validate_create_name(name: str, *, force: bool) -> None:
    """Reject wildcard host names unless the caller explicitly opts in.

    MREG accepts wildcard labels such as ``*.example.com`` or ``host.*`` because
    they are valid DNS owner names, but creating one by accident usually masks
    a real host name typo. The CLI requires ``force`` for that case and the
    library carries the same guard so it is not a foot-gun for downstream code.
    """
    if force:
        return
    stripped = name.strip()
    if stripped.startswith("*.") or stripped.endswith(".*") or "*" in stripped:
        raise ValidationError(
            f"Host name {name!r} contains a wildcard label; force is required",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/hosts/",
        )


def _build_create_payload(
    *,
    name: str,
    contacts: list[str] | None,
    comment: str | None,
    ipaddress: str | None,
    network: str | None,
) -> dict[str, object]:
    """Build the constrained payload used by the host create endpoint.

    The helper keeps create-time validation close to payload shaping so the
    lifecycle method itself stays readable. In particular, callers must choose
    either a concrete IP address or a network-driven allocation target, never
    both.

    Args:
        name: Canonical host name for the create request.
        contacts: Optional contact identifiers to normalize for the payload.
        comment: Optional free-text comment sent upstream.
        ipaddress: Optional fixed IP address for creation.
        network: Optional network identifier for first-free allocation.

    Returns:
        Minimal payload expected by the upstream create endpoint.

    Raises:
        ValidationError: Both ``ipaddress`` and ``network`` were supplied even
            though the upstream create contract only accepts one addressing
            strategy at a time.
    """
    if ipaddress and network:
        raise ValidationError(
            "Only one of ipaddress or network may be set",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/hosts/",
        )

    payload: dict[str, object] = {"name": name}
    if contacts is not None:
        payload["contacts"] = list(_normalize_contacts(contacts))
    if comment:
        payload["comment"] = comment
    if ipaddress:
        payload["ipaddress"] = ipaddress
    if network:
        payload["network"] = network
    return payload


def _split_primary_and_secondary(
    *,
    ipv4: str | None,
    ipv6: str | None,
) -> tuple[str, str | None]:
    """Choose the create-time primary address and validate any secondary one."""
    if not ipv4 and not ipv6:
        raise ValidationError(
            "At least one of ipv4 or ipv6 must be set",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/hosts/",
        )

    if ipv4:
        _validate_ip_literal(ipv4, family=4)
    if ipv6:
        _validate_ip_literal(ipv6, family=6)

    primary = ipv4 or ipv6
    secondary = ipv6 if ipv4 and ipv6 else None
    return primary or "", secondary


def _validate_ip_literal(value: str, *, family: int) -> None:
    """Reject malformed or wrong-family literal IP addresses up front."""
    try:
        parsed = ipaddress.ip_address(value)
    except ValueError as exc:
        raise ValidationError(
            f"Invalid IP address {value!r}",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/hosts/",
        ) from exc
    if parsed.version != family:
        raise ValidationError(
            f"Expected an IPv{family} address, got {value!r}",
            source=ValidationSource.LOCAL,
            method=RequestMethod.POST,
            endpoint="/api/v1/hosts/",
        )
