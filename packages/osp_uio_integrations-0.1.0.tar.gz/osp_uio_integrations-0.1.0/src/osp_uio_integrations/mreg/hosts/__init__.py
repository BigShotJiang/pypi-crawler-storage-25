"""Host-oriented MREG API surface.

Public exports:

- `HostsAPI` as the composed host entrypoint hanging off `MregClient`
- stable host/result models for callers that want typed return values without
  importing implementation modules directly

Other modules under `osp_uio_integrations.mreg.hosts` are internal
implementation details. Callers should prefer `client.hosts` plus the
re-exported models here over reaching into individual mutation modules.
"""

from .api import HostsAPI
from .models import AddressMoveResult, AddressRecord, CnameRecord, HostHistoryRecord, HostRecord

__all__ = [
    "AddressMoveResult",
    "AddressRecord",
    "CnameRecord",
    "HostHistoryRecord",
    "HostRecord",
    "HostsAPI",
]
