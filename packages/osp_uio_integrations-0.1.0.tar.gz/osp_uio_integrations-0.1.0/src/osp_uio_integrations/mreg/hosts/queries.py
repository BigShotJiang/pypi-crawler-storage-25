"""Read-only host queries and host payload interpretation.

This module is the host-domain boundary for fetching and normalizing host data.
It owns the translation from the upstream MREG host payload shapes into the
stable ``HostRecord`` exposed by this library.

That ownership boundary matters: models stay dumb, while endpoint-aware payload
interpretation stays next to the endpoint code that actually fetched the data.
Mutation modules are free to rely on this normalized host shape without having
to understand every odd MREG response variant themselves.
"""

from __future__ import annotations

import ipaddress
from typing import Any, cast

from ..enums import RequestMethod
from ..exceptions import NotFoundError, ResponseDecodeError
from ._shared import extract_results
from .models import HostRecord


class HostQueries:
    """Read-only host query surface plus host payload parser.

    The class combines two closely related responsibilities:

    - fetching host data from the upstream host endpoints
    - interpreting those endpoint payloads into the stable ``HostRecord`` shape

    Keeping those together avoids reintroducing API knowledge into the model
    layer while still giving every other host sub-API one shared, explicit
    lookup dependency.
    """

    def __init__(self, client: Any) -> None:
        """Initialize the host query API."""
        self._client = client

    def get(self, hostname: str, *, correlation_id: str | None = None) -> HostRecord | None:
        """Return one normalized host record by hostname.

        Missing hosts are modeled as ``None`` here so higher-level host
        modules can decide whether absence is expected, idempotent, or an
        actual error for the operation they are implementing.

        Args:
            hostname: Host identity to resolve through the canonical host
                endpoint.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Normalized ``HostRecord`` when the host exists, otherwise ``None``.
        """
        endpoint = f"/api/v1/hosts/{hostname}"
        data = self._client.get_json(
            endpoint,
            soft_404=True,
            correlation_id=correlation_id,
        )
        if not data:
            return None
        return self.parse_host_payload(data, endpoint=endpoint, method=RequestMethod.GET)

    def get_required(self, hostname: str, *, correlation_id: str | None = None) -> HostRecord:
        """Return one host record and promote absence into ``NotFoundError``.

        Mutation-oriented modules use this helper when the operation contract
        cannot proceed without a concrete upstream host.
        """
        host = self.get(hostname, correlation_id=correlation_id)
        if host is None:
            raise NotFoundError(
                f"Host {hostname!r} was not found",
                method=RequestMethod.GET,
                endpoint=f"/api/v1/hosts/{hostname}",
            )
        return host

    def exists(self, hostname: str, *, correlation_id: str | None = None) -> bool:
        """Return whether MREG currently knows about the supplied hostname."""
        return self.get(hostname, correlation_id=correlation_id) is not None

    def many(
        self,
        *,
        params: dict[str, object] | None = None,
        correlation_id: str | None = None,
    ) -> list[HostRecord]:
        """Return normalized host records from the host listing endpoint.

        The upstream API uses a couple of list response shapes; this method
        keeps that inconsistency local and always returns a plain Python list
        of stable ``HostRecord`` instances.

        Args:
            params: Optional upstream query parameters used to narrow the host
                listing.
            correlation_id: Optional logical operation id for tracing.

        Returns:
            Stable host records parsed from the supported MREG list shapes.
        """
        endpoint = "/api/v1/hosts/"
        return [
            self.parse_host_payload(item, endpoint=endpoint, method=RequestMethod.GET)
            for item in extract_results(
                self._client.get_json_collection(
                    endpoint,
                    params=params,
                    correlation_id=correlation_id,
                ),
                endpoint=endpoint,
            )
        ]

    def parse_host_payload(
        self,
        payload: object,
        *,
        endpoint: str,
        method: RequestMethod,
    ) -> HostRecord:
        """Interpret one upstream host payload into the stable library shape.

        This parser is intentionally colocated with the host endpoints instead
        of living on ``HostRecord`` itself. Endpoint-aware translation belongs
        with the code that fetched the payload; the model only owns local shape
        normalization once the important fields have already been identified.

        Args:
            payload: Raw decoded JSON payload returned by one host endpoint.
            endpoint: Endpoint path used to annotate decode failures.
            method: HTTP method used to fetch or mutate the payload.

        Returns:
            Stable ``HostRecord`` for the rest of the host domain modules.

        Raises:
            ResponseDecodeError: The payload did not contain the minimum host
                information the library relies on.
        """
        if not isinstance(payload, dict):
            raise ResponseDecodeError(
                "MREG host payload was not a JSON object",
                method=method,
                endpoint=endpoint,
            )
        payload_dict = cast(dict[str, Any], payload)

        name = _first_string(payload_dict, "name", "hostname", "host")
        if not name:
            raise ResponseDecodeError(
                "MREG host payload did not include a host name",
                method=method,
                endpoint=endpoint,
            )

        siteadmins = _extract_siteadmins(payload_dict)
        contact = _first_string(payload_dict, "contact", "siteadmin")
        if contact is None and siteadmins:
            contact = ",".join(siteadmins)
        return HostRecord(
            id=_optional_int(payload_dict.get("id")),
            name=name,
            contact=contact,
            siteadmins=siteadmins,
            ipaddresses=_extract_ipaddresses(payload_dict),
            ttl=_optional_int(payload_dict.get("ttl")),
            zone_id=_optional_int(payload_dict.get("zone")),
            raw=dict(payload_dict),
        )


def _first_string(data: dict[str, Any], *keys: str) -> str | None:
    """Return the first usable string under the supplied candidate keys."""
    for key in keys:
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _split_siteadmins(value: str | None) -> tuple[str, ...]:
    """Split the upstream comma-joined contact field into stable identifiers."""
    if not value:
        return ()
    return tuple(part.strip() for part in value.split(",") if part.strip())


def _extract_siteadmins(data: dict[str, Any]) -> tuple[str, ...]:
    """Extract stable contact identifiers from canonical or legacy host fields."""
    contacts = data.get("contacts")
    if isinstance(contacts, list):
        normalized = tuple(dict.fromkeys(_iter_contact_identifiers(contacts)))
        if normalized:
            return normalized
    return _split_siteadmins(_first_string(data, "contact", "siteadmin"))


def _iter_contact_identifiers(contacts: list[object]) -> list[str]:
    """Return normalized contact identifiers from a contacts payload list."""
    normalized: list[str] = []
    for contact in contacts:
        if isinstance(contact, str) and contact.strip():
            normalized.append(contact.strip())
            continue
        if isinstance(contact, dict):
            email = cast(dict[str, Any], contact).get("email")
            if isinstance(email, str) and email.strip():
                normalized.append(email.strip())
    return normalized


def _extract_ipaddresses(data: dict[str, Any]) -> tuple[str, ...]:
    """Extract canonical host IP strings from several upstream payload shapes.

    MREG host payloads may expose addresses as top-level strings, lists, or
    nested objects. This helper accepts that inconsistency once and returns a
    deduplicated tuple of canonical address strings for the rest of the
    library.

    Args:
        data: Host payload dictionary that may carry address information in
            several legacy shapes.

    Returns:
        Deduplicated canonical IP strings in discovery order.
    """
    candidates: list[Any] = []
    for key in ("ipaddress", "ipv4", "ipv6", "ip", "address"):
        value = data.get(key)
        if value:
            candidates.append(value)
    for key in ("ipaddresses", "ipaddrs", "addresses", "ips"):
        value = data.get(key)
        if isinstance(value, list):
            candidates.extend(value)

    normalized: list[str] = []
    seen: set[str] = set()

    def add_candidate(value: object) -> None:
        if value is None:
            return
        try:
            rendered = str(ipaddress.ip_address(str(value)))
        except ValueError:
            return
        if rendered in seen:
            return
        seen.add(rendered)
        normalized.append(rendered)

    def visit(item: object) -> None:
        if item is None:
            return
        if isinstance(item, dict):
            item_payload = cast(dict[str, Any], item)
            for key in ("ipaddress", "ipv4", "ipv6", "ip", "address"):
                add_candidate(item_payload.get(key))
            nested = item_payload.get("ipaddresses")
            if isinstance(nested, list):
                for child in nested:
                    visit(child)
            return
        if isinstance(item, list | tuple | set):
            for child in item:
                visit(child)
            return
        add_candidate(item)

    for candidate in candidates:
        visit(candidate)
    return tuple(normalized)


def _optional_int(value: object) -> int | None:
    """Normalize optional integer-like fields from upstream payloads."""
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None
