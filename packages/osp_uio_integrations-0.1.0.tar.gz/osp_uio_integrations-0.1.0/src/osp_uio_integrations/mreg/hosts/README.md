# hosts (Host-Domain API)

The `hosts` package is the host-shaped surface of the MREG client. It is
the single place where MREG host endpoints, the host payload variants, and
the operational guard rules around host writes are actually understood.

`hosts.api.HostsAPI` composes a small bag of focused sub-APIs (queries,
lifecycle, addressing, contacts, cnames, history, and host-owned records)
behind `client.hosts`. The composition root deliberately stays thin so each
sub-API keeps its own endpoint knowledge close to the operation it implements
instead of leaking back into a god object.

The package owns:

- normalization of every supported MREG host payload shape into one stable
  `HostRecord`
- write workflows that include local guards, write-then-verify state checks,
  and explicit uncertain-state reporting where MREG cannot be trusted to be
  transactional
- the host-domain `force` convention: each sub-API decides which destructive
  operations require an explicit opt-in, rather than carrying one global flag

The package does not own:

- transport details such as base URL, retries, or token refresh — that is
  `mreg/client.py`
- raw `httpx` errors — those are mapped into the exception taxonomy in
  `mreg/exceptions.py`
- record-shape resolution back through MREG — models in `models.py` and
  `records/models.py` are dumb data and never perform I/O
- CLI rendering or human-friendly formatting

## What lives here

- **`api.py`** — `HostsAPI`: composition root exposed as `client.hosts`. Wires
  sub-APIs together; has no behavior of its own.
- **`queries.py`** — `HostQueries`: read-only host lookups plus the
  `parse_host_payload` translator that every other sub-API depends on.
- **`lifecycle.py`** — `HostLifecycleAPI`: minimal `create()` / `delete()`
  with the wildcard-name guard and the empty-success verification path.
- **`addressing.py`** — `HostAddressingAPI`: A/AAAA add/change/move/remove,
  plus the network and PTR-override guards that go with them.
- **`contacts.py`** — `HostContactsAPI`: `set` / `add` / `remove` / `unset`
  for the host contact list, including the multi-contact `unset` guard.
- **`cnames.py`** — `HostCnameAPI`: alias workflows with host-vs-alias
  conflict checks, forward-zone validation, and stable existence semantics.
- **`history.py`** — `HostHistoryAPI`: read-only host history lookups,
  including the multi-pass model_id fan-out that MREG requires.
- **`models.py`** — stable host-domain return shapes (`HostRecord`,
  `CnameRecord`, `AddressRecord`, `AddressMoveResult`, `HostHistoryRecord`).
- **`records/`** — host-owned RR sub-APIs exposed at `client.hosts.records`.
  Each RR module is independent; see `records/README.md` for layout.
- **`_shared.py`** — `extract_results` (list-shape normalizer used by every
  list endpoint) and `normalize_hostname_for_compare` (DNS-style equality).
- **`_network.py`** — `parse_network_payload` and `NetworkRecord`: a tiny
  shared shape for the network checks used by addressing and PTR.

---

## Layer guides

### `api.py` — HostsAPI composition root

`HostsAPI.__init__` wires every host sub-API to the same transport client and
to the shared `HostQueries` instance. The latter sharing matters: every
mutation module needs `parse_host_payload` and `get_required`, and routing
those through one queries instance keeps payload interpretation in lockstep.

```python
class HostsAPI:
    def __init__(self, client):
        self.queries     = HostQueries(client)
        self.addressing  = HostAddressingAPI(client, self.queries)
        self.contacts    = HostContactsAPI(client, self.queries)
        self.cnames      = HostCnameAPI(client, self.queries)
        self.history     = HostHistoryAPI(client)
        self.lifecycle   = HostLifecycleAPI(client, self.queries)
        self.records     = HostRecordsAPI(client, self.queries)
```

There are no per-method shortcuts on `HostsAPI`. Reach for the sub-API that
owns the operation: `client.hosts.queries.get(...)`,
`client.hosts.lifecycle.create(...)`, `client.hosts.records.ptr.add(...)`.

### `queries.py` — HostQueries

`HostQueries` is the host-domain boundary for reads and the only place that
turns upstream payloads into `HostRecord`. It exposes:

```python
get(hostname)            -> HostRecord | None     # soft-404 read
get_required(hostname)   -> HostRecord            # promotes None to NotFoundError
exists(hostname)         -> bool
many(*, params=None)     -> list[HostRecord]      # both list shapes accepted
parse_host_payload(...)  -> HostRecord            # shared by every mutation module
```

`parse_host_payload` is colocated with the host endpoint code on purpose:
endpoint-aware translation belongs next to the request that produced the
payload, while `models.py` stays a dumb dataclass.

### `lifecycle.py` — HostLifecycleAPI

```python
create(name, *, contacts=None, comment=None, ipaddress=None, network=None,
       force=False) -> HostRecord
delete(name) -> None
```

Behavior worth pinning:

- `_validate_create_name` rejects any wildcard label (`*.foo`, `foo.*`, or
  any literal `*`) unless the caller passes `force=True`.
- `_build_create_payload` rejects passing both `ipaddress` and `network`.
- `delete()` does a `get_required()` pre-read so missing-host failure is
  consistent with the rest of the library.
- Empty-success on POST is handled with the standard write-then-verify
  pattern (see "Design recipes").

### `addressing.py` — HostAddressingAPI

Owns A/AAAA add, change, move, and remove. Notable invariants:

- IP/network parsing accepts trailing slashes and treats `/32` and `/128`
  as direct addresses.
- Network frozen, network-address, broadcast-address, and reserved-address
  guards come from `_network.parse_network_payload`.
- PTR-override moves are tracked separately from A/AAAA moves and reported
  in `AddressMoveResult.moved_ptr_override`.
- `force` allows reserved-address use and (where applicable) bypassing the
  managed-zone check; it never bypasses the frozen-network guard.

### `contacts.py` — HostContactsAPI

```python
set(hostname, contacts)            # patch full contact list
add(hostname, contacts)            # idempotent merge
remove(hostname, contacts)         # idempotent remove
unset(hostname, *, force=False)    # clear all; force needed for >1 contact
```

`_normalize_contacts` enforces "at least one non-empty contact" and is the
reason `unset()` has its own explicit empty-tuple path.

### `cnames.py` — HostCnameAPI

```python
many(hostname)              -> list[CnameRecord]
get(alias)                  -> CnameRecord | None
get_required(alias)         -> CnameRecord
add(hostname, alias)        -> CnameRecord
remove(hostname, alias)     -> None
replace(alias, hostname)    -> CnameRecord
```

`add()` performs three checks before issuing the create: alias is not an
existing host, alias is not an existing CNAME owned by another host, and a
forward zone exists for the alias (`_require_forward_zone`). When the alias
already points at the requested host, `add()` is idempotent and returns the
existing record without issuing a write.

### `history.py` — HostHistoryAPI

`many(hostname)` runs three queries against `/api/v1/history/`:

1. direct host history rows by `(resource=host, name=hostname)`
2. fan-out by `model_id__in=<ids from pass 1>`
3. fan-out by `data__relation=hosts, data__id__in=<ids from pass 1>`

The result is deduplicated by upstream history id and sorted by
`(timestamp, id)`. Pass #1 is load-bearing — without it there are no model
ids to drive the fan-out — but an empty pass #1 returns `[]` rather than
raising `NotFoundError`. History retention is independent from host
existence.

### `_shared.py` and `_network.py`

Both modules are deliberately tiny. `_shared.extract_results` normalizes
the two MREG list response shapes (raw list vs `{results: [...]}`) used by
many endpoints. `_shared.normalize_hostname_for_compare` strips trailing
dots and lowercases — DNS-style equality, not Python string equality.
`_network.parse_network_payload` returns a `NetworkRecord` carrying just
the four fields addressing and PTR actually need.

---

## Design recipes

### Write-then-verify with explicit uncertainty

Several MREG write endpoints return an empty success body. The library
handles that uniformly:

```python
data = self._client.post_json(endpoint, json=payload, allow_empty=True, ...)
if data is None:
    try:
        verified = self._queries.get_required(name, ...)
    except NotFoundError as exc:
        # Empty success + verification 404 = ordinary failed write.
        raise RequestFailedError(...) from exc
    except RequestFailedError as exc:
        # Empty success + verification transport failure = uncertain partial state.
        raise MutationStateUncertainError(
            ..., completed_steps=(MutationStep("create_request"),),
                 remaining_steps=(MutationStep("verify_created_object"),),
        ) from exc
    return verified
return self._queries.parse_host_payload(data, ...)
```

The split matters: `RequestFailedError` says "we believe nothing changed",
while `MutationStateUncertainError` says "the write probably reached MREG
but we cannot prove the resulting state". Callers can log uncertain
mutations differently and choose not to auto-retry them.

### The host-domain `force` convention

There is no global `force` flag and no shared `force` policy. Each sub-API
decides what it means:

| Sub-API | What `force` does |
|---|---|
| `lifecycle.create` | Allow wildcard host names |
| `contacts.unset` | Allow clearing more than one contact |
| `addressing.*` | Allow reserved addresses; allow bypassing managed-zone check; **never** bypasses frozen-network guard |
| `records.ptr.*` | Allow operating on PTR overrides outside managed boundaries; does **not** override cross-host PTR conflicts |
| `records.naptr.*` | Allow destructive multi-match deletes |

Treating `force` as domain-specific keeps each guard's audit story local. A
caller that needs `force` for one sub-API does not implicitly buy escapes
for another.

### Why payload interpretation lives next to the endpoint

Models are I/O-free dataclasses. `parse_host_payload`,
`_parse_cname_payload`, `_parse_address_payload` etc. live next to the
endpoint code that issued the request. That keeps endpoint-aware quirks
(legacy field names, multiple list shapes, JSON-string-as-payload) bundled
with the modules already aware of those quirks, and lets the models keep
their narrow contract: stable shape, no behavior.

### Why reading is decoupled from mutating

Every mutation module receives the same `HostQueries` instance. That
instance owns soft-404 semantics, `get_required()` promotion, and payload
parsing. Mutation modules never reimplement those rules — they call the
queries surface and inherit one consistent contract.

---

## Design rules

- **No facade shortcuts.** `HostsAPI` does not forward methods; the call
  site names the sub-API. This is enforced by the architecture test that
  pins `hosts.__all__` and `mreg.__all__`.
- **Models never call MREG.** Anything that needs an HTTP request belongs
  on a sub-API, not on a model.
- **Empty success is never silently trusted.** Every write that can return
  `204 No Content` or `200 {}` follows the verify-then-classify pattern
  above.
- **`MutationStateUncertainError` is reserved for write-then-verify
  uncertainty.** It is not a generic "I do not know what happened" wrapper.
  If the library never issued the upstream write, it is `RequestFailedError`,
  not uncertainty.
- **Wildcard, multi-contact, frozen, reserved, and managed-zone checks are
  client-side guards** — they protect callers from common foot-guns, not
  duplicate MREG's authoritative validation. Upstream remains the source of
  truth.
- **Hostnames compare DNS-style.** Use `normalize_hostname_for_compare`
  before comparing user input against an upstream-normalized name.

---

## Common issues

- **`MutationStateUncertainError` after a write.** The write probably
  reached MREG but the verifying GET failed. Inspect the affected object in
  MREG before retrying. The exception carries `completed_steps` /
  `remaining_steps` describing what is known.
- **`ValidationError: ... wildcard label; force is required`.** The host
  name contains `*`. Pass `force=True` to `lifecycle.create` if intentional.
- **`ValidationError: ... contacts; force is required`.** `unset()` was
  called on a host with more than one contact. Pass `force=True` to confirm.
- **`ConflictError: alias is already in use by another host`.** `cnames.add`
  refuses to silently move an alias. Use `cnames.replace(alias, new_host)`.
- **`NotFoundError: No forward zone was found for alias`.** `cnames.add`
  requires a managed forward zone for the alias label.
- **`HostHistoryAPI.many` returned `[]` for an existing host.** Expected.
  Empty history is reported as an empty list, not `NotFoundError`.

---

## Mini cheat sheet

| I want to … | Use |
|---|---|
| Look up a host | `client.hosts.queries.get(name)` |
| Create a host | `client.hosts.lifecycle.create(name, ...)` |
| Delete a host | `client.hosts.lifecycle.delete(name)` |
| Add an A/AAAA | `client.hosts.addressing.add(...)` |
| Move an IP between hosts | `client.hosts.addressing.move_ipv4(...)` / `move_ipv6(...)` |
| Replace the contact list | `client.hosts.contacts.set(name, [...])` |
| Add an alias | `client.hosts.cnames.add(host, alias)` |
| Repoint an alias | `client.hosts.cnames.replace(alias, new_host)` |
| List host history | `client.hosts.history.many(name)` |
| Add a TXT / MX / SRV / etc. | `client.hosts.records.<rr>.add(...)` |

See [records/README.md](records/README.md) for the per-RR layout and
[../README.md](../README.md) for the package-level surface and exception
taxonomy.
