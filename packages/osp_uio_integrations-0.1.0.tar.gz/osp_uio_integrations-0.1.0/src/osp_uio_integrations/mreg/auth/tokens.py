"""Token storage abstractions for the MREG client.

The transport client never hardcodes how API tokens are persisted. Instead
it depends on the small :class:`TokenStore` ``Protocol`` defined here, so
callers can plug in keyring-backed storage, file-backed storage, secret
managers, or test fakes without changing the client. The
:class:`MemoryTokenStore` shipped here is the safe default for tests and
short-lived processes.

This module owns the persistence boundary contract and one in-memory
implementation. It does not own credential collection (see
``interactive.py``) or the token-auth wire flow (see ``login.py``).
"""

from __future__ import annotations

from collections.abc import MutableMapping
from typing import Protocol


class TokenStore(Protocol):
    """Persistence interface used by the MREG client to cache API tokens.

    All operations are keyed on ``(base_url, username)`` so a single store
    can hold tokens for multiple MREG instances and multiple identities at
    the same time. ``username`` may be ``None`` when the calling code does
    not pin a specific user identity to the cached token.
    """

    def load_token(self, *, base_url: str, username: str | None) -> str | None:
        """Return a previously persisted token, or ``None`` if none is cached."""

    def save_token(self, *, base_url: str, username: str | None, token: str) -> None:
        """Persist ``token`` for the supplied ``base_url`` / ``username`` key."""

    def clear_token(self, *, base_url: str, username: str | None) -> None:
        """Drop any persisted token for the supplied key.

        Called by the client when a cached token is rejected by MREG (for
        example after a 401) so that the next request triggers a fresh
        login instead of reusing the known-bad token.
        """


class MemoryTokenStore:
    """Process-local in-memory implementation of :class:`TokenStore`.

    Suitable for tests and short-lived CLI invocations. Long-running tools
    should pass a custom store backed by their preferred secret manager so
    tokens survive across processes and are not held in plain Python
    memory longer than needed.
    """

    def __init__(self, initial: MutableMapping[tuple[str, str | None], str] | None = None) -> None:
        """Create a store, optionally seeded with already-known tokens.

        Args:
            initial: Optional mapping of ``(base_url, username)`` to token
                used to preload the store. Useful in tests that need to
                exercise the cached-token path without going through a
                real login.
        """
        self._tokens: dict[tuple[str, str | None], str] = dict(initial or {})

    def load_token(self, *, base_url: str, username: str | None) -> str | None:
        """Return the cached token for the key, or ``None`` if absent."""
        return self._tokens.get((base_url, username))

    def save_token(self, *, base_url: str, username: str | None, token: str) -> None:
        """Replace any existing cached token for the supplied key."""
        self._tokens[(base_url, username)] = token

    def clear_token(self, *, base_url: str, username: str | None) -> None:
        """Drop the cached token for the supplied key if one exists."""
        self._tokens.pop((base_url, username), None)
