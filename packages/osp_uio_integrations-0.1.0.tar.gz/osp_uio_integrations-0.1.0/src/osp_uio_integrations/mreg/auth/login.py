"""Token login helpers for the MREG client."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from ..enums import RequestMethod
from ..exceptions import AuthenticationFailedError, RequestFailedError, ResponseDecodeError


@dataclass(frozen=True, slots=True)
class Credentials:
    """Credentials used to authenticate against MREG."""

    username: str
    password: str


def login_for_token(
    client: httpx.Client,
    *,
    credentials: Credentials,
    correlation_id: str | None = None,
) -> str:
    """Exchange username/password credentials for one MREG API token.

    The transport client owns token lifecycle, but the actual token-auth
    protocol is isolated here so the request shape and its error mapping stay
    easy to audit. The function accepts a plain ``httpx.Client`` because it is
    used by the MREG transport boundary itself, not by domain modules.

    Args:
        client: Configured ``httpx.Client`` used to reach the token-auth
            endpoint.
        credentials: Username/password pair to exchange for a token.
        correlation_id: Optional correlation id propagated to the auth request
            for traceability.

    Returns:
        Newly issued MREG API token.

    Raises:
        AuthenticationFailedError: MREG rejected the supplied credentials.
        RequestFailedError: Network failure or unexpected upstream HTTP status
            prevented successful login.
        ResponseDecodeError: Login succeeded but the response body did not
            contain a usable token.
    """
    endpoint = "/api/token-auth/"
    try:
        response = client.post(
            endpoint,
            data={
                "username": credentials.username,
                "password": credentials.password,
            },
            headers=_auth_headers(correlation_id),
        )
    except httpx.HTTPError as exc:
        raise RequestFailedError(
            "MREG login request failed",
            method=RequestMethod.POST,
            endpoint=endpoint,
            correlation_id=correlation_id,
        ) from exc

    if response.status_code in (401, 403):
        raise AuthenticationFailedError(
            "MREG rejected the supplied credentials",
            method=RequestMethod.POST,
            status_code=response.status_code,
            endpoint=endpoint,
            request_id=response.headers.get("X-Request-Id"),
            correlation_id=response.headers.get("X-Correlation-ID") or correlation_id,
        )
    if response.status_code >= 400:
        raise RequestFailedError(
            f"MREG login failed with status {response.status_code}",
            method=RequestMethod.POST,
            status_code=response.status_code,
            endpoint=endpoint,
            request_id=response.headers.get("X-Request-Id"),
            correlation_id=response.headers.get("X-Correlation-ID") or correlation_id,
        )

    try:
        payload: Any = response.json()
    except ValueError as exc:
        raise ResponseDecodeError(
            "MREG login response was not valid JSON",
            method=RequestMethod.POST,
            status_code=response.status_code,
            endpoint=endpoint,
            request_id=response.headers.get("X-Request-Id"),
            correlation_id=response.headers.get("X-Correlation-ID") or correlation_id,
        ) from exc

    token = payload.get("token") if isinstance(payload, dict) else None
    if not isinstance(token, str) or not token:
        raise ResponseDecodeError(
            "MREG login response did not include a token",
            method=RequestMethod.POST,
            status_code=response.status_code,
            endpoint=endpoint,
            request_id=response.headers.get("X-Request-Id"),
            correlation_id=response.headers.get("X-Correlation-ID") or correlation_id,
        )
    return token


def _auth_headers(correlation_id: str | None) -> dict[str, str]:
    """Build token-auth headers, forwarding a correlation id when available."""
    if not correlation_id:
        return {}
    return {"X-Correlation-ID": correlation_id}
