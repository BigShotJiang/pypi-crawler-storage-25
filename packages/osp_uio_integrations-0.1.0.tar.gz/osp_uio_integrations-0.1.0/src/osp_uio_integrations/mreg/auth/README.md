# auth (MREG Authentication Helpers)

The `auth` package owns the token-auth flow: a credentials value object,
the token-auth POST exchange, an optional interactive prompt, and a token
storage protocol with an in-memory default.

The package exists so the transport client (`mreg/client.py`) can stay
focused on HTTP behavior while the actual auth contract — request shape,
status-to-exception mapping, prompt hook, persistence boundary — stays in
one auditable place.

The package owns:

- the token-auth wire contract (`POST /api/token-auth/`, form body, JSON
  token response)
- mapping HTTP status to `AuthenticationFailedError`,
  `RequestFailedError`, or `ResponseDecodeError`
- the optional interactive prompt used when no token is cached
- a tiny `TokenStore` protocol so callers can plug in their own
  persistence (keyring, file, secret manager) without changing the client

The package does not own:

- session, cookie, or SSO flows — token-auth only
- token refresh on the wire — `MregClient` performs the one-shot 401
  retry by re-issuing login and replaying the request once
- credential discovery — env-var, config-file, or vault lookups belong in
  the calling application

## What lives here

- **`__init__.py`** — re-exports the small public surface.
- **`login.py`** — `Credentials` value object and `login_for_token()`,
  the only place that constructs the token-auth request and classifies
  its responses.
- **`tokens.py`** — `TokenStore` `Protocol` and `MemoryTokenStore`
  default implementation.
- **`interactive.py`** — `CredentialPrompt` `Protocol` and
  `prompt_for_credentials`, the default stdin/getpass prompt used when
  the client needs credentials and the caller has not supplied a hook.

---

## Layer guides

### `login.py` — login_for_token

```python
def login_for_token(
    client: httpx.Client,
    *,
    credentials: Credentials,
    correlation_id: str | None = None,
) -> str
```

`login_for_token` accepts a plain `httpx.Client` rather than a
`MregClient` because the MREG transport boundary itself uses it during
construction. It:

- POSTs `username` / `password` as a form body to `/api/token-auth/`
- forwards `X-Correlation-ID` when provided
- maps `401`/`403` to `AuthenticationFailedError`
- maps any other `>=400` to `RequestFailedError`
- maps non-JSON or token-less success bodies to `ResponseDecodeError`
- returns the issued token string on success

`Credentials` is a frozen, slotted dataclass holding `username` and
`password`. Treat it as a short-lived value object; do not log it.

### `tokens.py` — TokenStore protocol

```python
class TokenStore(Protocol):
    def load_token(self, *, base_url, username) -> str | None: ...
    def save_token(self, *, base_url, username, token) -> None: ...
    def clear_token(self, *, base_url, username) -> None: ...
```

The protocol is keyed on `(base_url, username)` so a single store can
hold tokens for multiple MREG instances or multiple users. `username`
may be `None` when the caller does not pin one.

`MemoryTokenStore` is the default. It is suitable for tests and
short-lived processes; long-lived tools should pass a custom
implementation backed by their preferred secret store.

### `interactive.py` — CredentialPrompt protocol

```python
class CredentialPrompt(Protocol):
    def __call__(self, *, base_url, username: str | None) -> Credentials: ...
```

`prompt_for_credentials` is the default implementation. It uses `input()`
for the username (when not supplied) and `getpass()` for the password.
The protocol is what the client expects, so callers can plug in
non-interactive credential providers (config-file lookups, secret
manager fetches, test fakes) without touching `MregClient`.

---

## How `MregClient` uses these helpers

`MregClient.__init__` accepts both a `credential_prompt` and a
`token_store`. Each defaults to the helpers above:

```python
self._credential_prompt = credential_prompt or prompt_for_credentials
self._token_store       = token_store or MemoryTokenStore()
```

The auth flow at request time is:

1. If a token is already cached for `(base_url, username)`, reuse it.
2. On `401` from a real request, drop the cached token and prompt the
   `CredentialPrompt` for credentials.
3. Call `login_for_token(...)`; persist the returned token through
   `TokenStore.save_token(...)`.
4. Replay the original request once with the new token. Any further
   `401` is surfaced to the caller.

The package never retries beyond that one-shot refresh. Repeated 401s
are treated as configuration or credential problems and propagate as
`AuthenticationFailedError`.

---

## Design recipes

### Why a `Protocol` for `TokenStore` and `CredentialPrompt`

Using `Protocol` (instead of an abstract base class) lets callers plug in
keyring-backed storage, environment-driven credential providers, or test
fakes without inheriting from anything in this package. `MregClient`
depends on the shape, not the type.

### Why credentials are a frozen dataclass, not raw strings

`Credentials` keeps the username and password together at the call site,
makes accidental mutation noisy, and gives type-checkers a stable type
to reason about. It does not implement `__repr__` redaction; do not log
instances.

### Why login error mapping lives here

Status-to-exception mapping for `/api/token-auth/` belongs next to the
endpoint that defines it, not in transport. Keeping it here means
`mreg/client.py` does not need to know the difference between a 401
during login and a 401 during a normal data request.

---

## Design rules

- **No retry policy in this package.** `login_for_token` issues exactly
  one POST. Retries and the one-shot refresh dance live in the client.
- **`TokenStore` keys are `(base_url, username)`.** Callers pin
  `username` when they want per-user isolation; otherwise stores hold
  one token per base URL.
- **`prompt_for_credentials` is best-effort interactive.** It assumes a
  TTY. Headless callers must inject their own `CredentialPrompt`
  implementation.
- **No HTTP session is shared between login and request.** The client
  drives both, so this package does not assume anything about cookies
  or persistent auth headers.

---

## Common issues

- **`AuthenticationFailedError` on every request.** Either the cached
  token is wrong (clear it via `TokenStore.clear_token(...)`) or the
  account/password is invalid for the supplied `base_url`.
- **Repeated prompts in a loop.** The one-shot refresh ran but the new
  token was also rejected. Verify `Credentials.username` is the correct
  identity for that `base_url`.
- **`ResponseDecodeError: MREG login response did not include a token`.**
  MREG returned 2xx but the body was empty or did not carry a `token`
  field. Treat as a transient infrastructure problem; do not auto-retry.
- **`RequestFailedError` during login.** Network or non-401/403 HTTP
  failure. Inspect `status_code` and any `X-Request-Id` on the exception.

---

## Mini cheat sheet

| I want to … | Use |
|---|---|
| Plug in custom credential lookup | Pass `credential_prompt=` to `MregClient` |
| Plug in custom token persistence | Pass `token_store=` to `MregClient` |
| Authenticate manually | `login_for_token(httpx_client, credentials=Credentials(...))` |
| Drop a cached token | `token_store.clear_token(base_url=..., username=...)` |
| Use a non-interactive flow | Implement `CredentialPrompt`; never call `prompt_for_credentials` |

See [../README.md](../README.md) for the package-level surface,
[../client.py](../client.py) for how the prompt and token store are wired
into the transport, and [../exceptions.py](../exceptions.py) for the full
exception taxonomy.
