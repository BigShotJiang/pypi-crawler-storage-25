"""Interactive helpers for obtaining MREG credentials.

The MREG client takes a :class:`CredentialPrompt` hook that it invokes
when no usable token is cached and a fresh login is required. The default
hook is the simple stdin/getpass prompt defined here, but the protocol is
public so callers can plug in headless credential providers (config-file
lookup, secret-manager fetch, test fakes) without touching the transport
layer.

This module owns only the interactive default and the protocol shape. It
does not own token storage (see ``tokens.py``) or the token-auth wire
exchange (see ``login.py``).
"""

from __future__ import annotations

from getpass import getpass
from typing import Protocol

from .login import Credentials


class CredentialPrompt(Protocol):
    """Callable hook used by the MREG client to obtain login credentials.

    Implementations may prompt the user, read from a config file, fetch
    from a secret manager, or return canned credentials in tests. The
    protocol intentionally mirrors a single call rather than a stateful
    object so non-interactive providers stay trivial to implement.
    """

    def __call__(self, *, base_url: str, username: str | None) -> Credentials:
        """Return :class:`Credentials` for the supplied MREG instance.

        Args:
            base_url: MREG base URL the credentials should authenticate
                against. Useful for prompts that surface the target host
                or for providers that pick a per-environment secret.
            username: Username already known to the client, or ``None``
                when the caller has not pinned one. Implementations may
                reuse the value or prompt for a fresh username.
        """


def prompt_for_credentials(*, base_url: str, username: str | None) -> Credentials:
    """Prompt the operator for an MREG username and password on stdin.

    This is the default :class:`CredentialPrompt` used by ``MregClient``
    when none is supplied. It assumes a real TTY: the username is read
    from ``input()`` (when not already known) and the password is read
    from ``getpass()`` so it does not echo. Headless callers should
    replace this hook entirely rather than depending on terminal
    behavior.

    Args:
        base_url: MREG base URL surfaced in the username prompt so the
            operator can tell which instance is asking.
        username: Username already known to the client, or ``None`` to
            prompt for one.

    Returns:
        A :class:`Credentials` value object to feed into ``login_for_token``.
    """
    prompt_username = username or input(f"Username for {base_url}: ").strip()
    password = getpass(f"Password for {prompt_username}: ")
    return Credentials(username=prompt_username, password=password)
