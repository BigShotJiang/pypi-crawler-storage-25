"""Synchronous Nivlheim transport boundary.

This package extracts the small reusable part of Nivlheim integration that
multiple OSP callers care about: token-backed request dispatch, stable error
mapping, host and file lookup helpers, and a normalized host record for the
common "tell me what this host is" flow.

It does not own CLI reporting, LDAP/netgroup expansion, uptime monkey-patching,
or other OSP-local policy layered on top of Nivlheim data. Those concerns stay
with the callers so this library remains a boring service client rather than a
second command suite.
"""
