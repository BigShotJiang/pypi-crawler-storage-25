"""Stable public models for Nivlheim reads.

The shared library only normalizes the host record shape that several OSP
callers already depend on. Lower-level list and search endpoints continue to
return dictionaries because their useful fields vary heavily by call site.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class HostRecord:
    """Normalized host facts returned by ``NivlheimClient.get_host_record_by_name``.

    Attributes:
        hostname: Canonical hostname returned by Nivlheim when present.
        provider: Stable provider hint derived from Nivlheim's product field.
        siteadmins: Normalized siteadmin identifiers from the host record.
        importance: Raw Nivlheim importance value when provided.
        raw: Original upstream payload for callers that need extra fields.
    """

    hostname: str
    provider: str
    siteadmins: tuple[str, ...]
    importance: int | None
    raw: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Return the dict shape already used by existing OSP callers.

        The dataclass remains the richer shared-library contract. This adapter
        exists so consumers can migrate without all of them carrying their own
        one-off model-to-dict conversion.
        """
        return {
            "hostname": self.hostname,
            "provider": self.provider,
            "siteadmins": list(self.siteadmins),
            "importance": self.importance,
        }


@dataclass(frozen=True, slots=True)
class GrepMatch:
    """One parsed line from Nivlheim's ``grep`` endpoint.

    The model is intentionally tiny because the upstream format is tiny:
    hostname, filename, and the matching line payload.
    """

    hostname: str
    filename: str
    line: str
