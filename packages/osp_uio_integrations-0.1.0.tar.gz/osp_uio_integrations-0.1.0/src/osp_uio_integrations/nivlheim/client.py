"""Synchronous Nivlheim transport boundary.

This module owns token-backed request dispatch, low-level error mapping, and
the small set of host and file operations that are useful across OSP callers.
It deliberately keeps higher-level reporting, uptime patching, and local policy
out of the client so the transport contract stays predictable.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any, SupportsIndex, SupportsInt, cast
from urllib.parse import quote, urlencode

import httpx

from ..version import __version__
from .exceptions import (
    AuthenticationFailedError,
    AuthenticationRequiredError,
    ForbiddenError,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from .models import GrepMatch, HostRecord

_MSEARCH_PARAM_RE = re.compile(r"(?P<parameter>q|f|op)(?P<digit>\d+)$")


class NivlheimClient:
    """Token-aware synchronous client for the Nivlheim API.

    The client owns the HTTP contract with Nivlheim: APIKEY auth headers,
    request dispatch, upstream status mapping, JSON decode checks, and light
    normalization for the common host lookup flow.

    It does not own CLI-only report composition, uptime enrichment, or any
    caller policy about what Nivlheim data should mean.
    """

    def __init__(
        self,
        *,
        base_url: str,
        token: str | None = None,
        api_version: int = 2,
        timeout: float = 20.0,
        user_agent: str | None = None,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        """Configure one synchronous Nivlheim client instance.

        The constructor is intentionally small because Nivlheim auth is small:
        callers provide a base URL plus the long-lived API token they want this
        client to use. There is no login flow, token refresh, or ambient global
        state hiding behind the client instance.

        The optional custom transport exists mainly for tests. Real callers are
        expected to depend on the public read/delete methods rather than on
        ``httpx`` details.
        """
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._api_version = api_version
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            transport=transport,
            headers={"User-Agent": user_agent or self._default_user_agent()},
        )

    @property
    def base_url(self) -> str:
        """Return the configured Nivlheim base URL."""
        return self._base_url

    @property
    def api_version(self) -> int:
        """Return the configured Nivlheim API version."""
        return self._api_version

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> NivlheimClient:
        """Return the client as a context manager."""
        return self

    def __exit__(self, *_: object) -> None:
        """Close the HTTP client when exiting a context manager."""
        self.close()

    def get_host(
        self,
        hostname: str,
        *,
        fields: str | Iterable[str] | None = None,
    ) -> dict[str, Any] | None:
        """Return one raw host payload by hostname.

        This method keeps the low-level host endpoint available for callers
        that still need Nivlheim's original field names. Higher-level callers
        should usually prefer ``get_host_by_name`` or
        ``get_host_record_by_name`` so normalization stays at the integration
        boundary.
        """
        endpoint = self._endpoint_path("host", hostname)
        response = self._request(
            "GET",
            endpoint,
            params=self._normalize_params({"fields": fields}),
            soft_404=True,
        )
        if response.status_code == 404:
            return None
        return self._decode_json_object(response, endpoint)

    def get_host_by_name(self, hostname: str) -> dict[str, Any]:
        """Return normalized host facts as a plain mapping.

        This mirrors the read contract already used by orchestrator. Callers
        that want a typed dataclass can use ``get_host_record_by_name``.
        """
        record = self.get_host_record_by_name(hostname)
        if record is None:
            return {}
        return record.to_dict()

    def get_host_record_by_name(self, hostname: str) -> HostRecord | None:
        """Return normalized host facts as a stable dataclass.

        This is the typed boundary for callers that want one explicit host
        model owned by the shared library rather than an ad-hoc dictionary.
        It normalizes the small host shape that multiple OSP callers already
        depend on and leaves the full upstream payload available under
        ``HostRecord.raw``.
        """
        data = self.get_host(
            hostname,
            fields=("hostname", "product", "siteadmin", "importance"),
        )
        if data is None:
            return None

        resolved_name = str(data.get("hostname") or hostname).strip() or hostname
        siteadmins = _split_siteadmins(data.get("siteadmin"))
        importance = _coerce_int(data.get("importance"))
        if importance is None:
            importance = 5
        return HostRecord(
            hostname=resolved_name,
            provider=_map_provider(data.get("product")),
            siteadmins=siteadmins,
            importance=importance,
            raw=dict(data),
        )

    def host_exists(self, hostname: str) -> bool:
        """Return whether Nivlheim currently knows about ``hostname``.

        Existence checks intentionally reuse the normal host lookup path so the
        library has one definition of what "host missing" means at the HTTP
        boundary.
        """
        return self.get_host(hostname, fields="hostname") is not None

    def delete_host(self, hostname: str) -> bool:
        """Delete one host document when present.

        The boolean return value keeps cleanup flows idempotent without forcing
        callers to special-case upstream ``404`` handling themselves.

        Returns ``True`` when Nivlheim deleted a host and ``False`` when the
        host was already absent.
        """
        endpoint = self._endpoint_path("host", hostname)
        response = self._request("DELETE", endpoint, soft_404=True)
        return response.status_code != 404

    def get_file_by_name(
        self,
        *,
        filename: str,
        hostname: str | None = None,
        certfp: str | None = None,
        fields: str | Iterable[str] | None = None,
        format: str | None = "raw",
    ) -> str:
        """Return one file payload using the method name existing callers use.

        ``format="raw"`` returns the file body as text. Other formats are
        intentionally not normalized here yet because the current OSP callers
        only use the raw-text flow. This keeps the shared client honest about
        the behavior it actually owns today instead of pretending to be a full
        generic file API.
        """
        if format not in {None, "raw"}:
            raise ValidationError("only format='raw' is supported by the shared client")
        return self.get_file_text(
            filename=filename,
            hostname=hostname,
            certfp=certfp,
            fields=fields,
        )

    def get_file_text(
        self,
        *,
        filename: str,
        hostname: str | None = None,
        certfp: str | None = None,
        fields: str | Iterable[str] | None = None,
    ) -> str:
        """Return file contents from one host as plain text.

        The empty-string-on-404 contract is deliberate. Existing callers use
        this endpoint for optional files such as siteadmin hints and should not
        have to treat "file absent" as an exceptional transport failure.
        """
        self._validate_file_lookup(filename=filename, hostname=hostname, certfp=certfp)

        endpoint = self._endpoint_path("file")
        response = self._request(
            "GET",
            endpoint,
            params=self._normalize_params(
                {
                    "filename": filename,
                    "hostname": hostname,
                    "certfp": certfp,
                    "fields": fields,
                    "format": "raw",
                }
            ),
            soft_404=True,
        )
        if response.status_code == 404:
            return ""
        return response.text or ""

    def list_files(
        self,
        *,
        filename: str,
        fields: str | Iterable[str] | None = None,
        lastseen: str | None = None,
        hostname: str | None = None,
        certfp: str | None = None,
    ) -> list[dict[str, Any]]:
        """Return file rows from Nivlheim's shared file index.

        The shared client deliberately returns dictionaries here instead of a
        typed model because different callers care about different file fields.
        The normalization responsibility is limited to flattening the supported
        collection wrappers and keeping 404s idempotent.
        """
        if not filename:
            raise ValidationError("filename is required")
        if hostname is not None and certfp is not None:
            raise ValidationError("expected exactly one of hostname or certfp, not both")

        endpoint = self._endpoint_path("file")
        response = self._request(
            "GET",
            endpoint,
            params=self._normalize_params(
                {
                    "filename": filename,
                    "fields": fields,
                    "lastseen": lastseen,
                    "hostname": hostname,
                    "certfp": certfp,
                }
            ),
            soft_404=True,
        )
        if response.status_code == 404:
            return []
        return self._decode_json_collection(response, endpoint)

    def get_siteadmins_from_file(self, hostname: str) -> list[str]:
        """Return siteadmin identifiers from the conventional Nivlheim file.

        This helper exists because several OSP callers care about this one file
        specifically and should not all duplicate the same text-splitting and
        empty-file handling.
        """
        content = self.get_file_by_name(
            hostname=hostname,
            filename="/etc/uio/conf/site-admin",
        )
        if not content.strip():
            return []
        return [line.strip() for line in content.splitlines() if line.strip()]

    def hostlist(
        self,
        *,
        fields: str | Iterable[str] | None = None,
        filters: str | Iterable[str] | None = None,
        sort: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
        count: bool = False,
    ) -> list[dict[str, Any]]:
        """Return rows from Nivlheim's hostlist endpoint.

        ``filters`` preserves Nivlheim's odd hostlist filter grammar by
        appending raw expressions after the normal query string. This keeps the
        transport detail local instead of leaking hand-built URLs to callers.
        The method otherwise stays intentionally thin: it normalizes response
        shape, not the meaning of every hostlist field.
        """
        endpoint = self._endpoint_path("hostlist")
        request_target = self._request_target(
            endpoint,
            params=self._normalize_params(
                {
                    "fields": fields,
                    "sort": sort,
                    "limit": limit,
                    "offset": offset,
                    "count": 1 if count else None,
                }
            ),
            filters=filters,
        )
        response = self._request("GET", request_target, soft_404=True)
        if response.status_code == 404:
            return []
        return self._decode_json_collection(response, endpoint)

    def search(
        self,
        *,
        q: str | Iterable[str],
        fields: str | Iterable[str],
        filename: str | Iterable[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Return structured rows from Nivlheim's ``search`` endpoint.

        This is a direct wrapper around product behavior rather than an
        opinionated report helper. The shared client validates the minimum
        required parameters, sends the request, and flattens the supported JSON
        collection shapes.
        """
        if not q:
            raise ValidationError("q is required")
        if not fields:
            raise ValidationError("fields is required")

        endpoint = self._endpoint_path("search")
        response = self._request(
            "GET",
            endpoint,
            params=self._normalize_params(
                {
                    "q": q,
                    "fields": fields,
                    "filename": filename,
                }
            ),
        )
        return self._decode_json_collection(response, endpoint)

    def msearch(
        self,
        *,
        fields: str | Iterable[str],
        **searches: str,
    ) -> list[dict[str, Any]]:
        """Return structured rows from Nivlheim's ``msearch`` endpoint.

        The local validation here exists to fail fast on obviously malformed
        ``qN``/``fN``/``opN`` keys before a caller ships nonsense upstream.
        """
        if not fields:
            raise ValidationError("fields is required")

        params = self._normalize_params({"fields": fields})
        for key, value in searches.items():
            match = _MSEARCH_PARAM_RE.fullmatch(key)
            if not match:
                raise ValidationError(
                    "msearch keys must look like q1, f1, or op2"
                )
            parameter = match.group("parameter")
            digit = int(match.group("digit"))
            if parameter in {"q", "f"} and digit < 1:
                raise ValidationError(f"{key!r} must use an index of 1 or greater")
            if parameter == "op" and digit < 2:
                raise ValidationError(f"{key!r} must use an index of 2 or greater")
            params[key] = value

        if "q1" not in params:
            raise ValidationError("q1 is required")

        endpoint = self._endpoint_path("msearch")
        response = self._request("GET", endpoint, params=params)
        return self._decode_json_collection(response, endpoint)

    def grep(
        self,
        *,
        q: str | Iterable[str],
        filename: str | Iterable[str] | None = None,
        limit: int | None = None,
    ) -> tuple[GrepMatch, ...]:
        """Return parsed grep matches from Nivlheim's ``grep`` endpoint.

        The raw endpoint returns colon-delimited text lines. This helper keeps
        that parsing logic inside the integration boundary for callers that
        want structured match records instead of string processing.
        """
        text = self.grep_text(q=q, filename=filename, limit=limit)
        matches: list[GrepMatch] = []
        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line:
                continue
            hostname, matched_file, content = line.split(":", maxsplit=2)
            matches.append(
                GrepMatch(
                    hostname=hostname,
                    filename=matched_file,
                    line=content,
                )
            )
        return tuple(matches)

    def grep_text(
        self,
        *,
        q: str | Iterable[str],
        filename: str | Iterable[str] | None = None,
        limit: int | None = None,
    ) -> str:
        """Return the raw text body from Nivlheim's ``grep`` endpoint.

        This exists alongside ``grep()`` because some CLI-style callers still
        want the product's original text rendering rather than parsed records.
        """
        if not q:
            raise ValidationError("q is required")

        endpoint = self._endpoint_path("grep")
        response = self._request(
            "GET",
            endpoint,
            params=self._normalize_params(
                {
                    "q": q,
                    "filename": filename,
                    "limit": limit,
                }
            ),
        )
        return response.text.rstrip()

    def status(self) -> dict[str, Any] | list[Any]:
        """Return the decoded payload from Nivlheim's ``status`` endpoint.

        The library does not impose a stronger model here because the endpoint
        is mainly useful for diagnostics and monitoring, not as a stable
        workflow contract.
        """
        endpoint = self._endpoint_path("status")
        response = self._request("GET", endpoint)
        return self._decode_json_any(response, endpoint)

    def _request(
        self,
        method: str,
        endpoint: str,
        *,
        params: dict[str, str] | None = None,
        soft_404: bool = False,
    ) -> httpx.Response:
        """Issue one HTTP request and map failures into local exceptions.

        This is the narrow transport boundary for the package. Public methods
        own endpoint-specific semantics; `_request` owns only APIKEY auth,
        timeout/network handling, and translation from upstream status codes
        into the shared exception taxonomy.
        """
        if not self._token:
            raise AuthenticationRequiredError(
                "Nivlheim API token is required",
                method=method,
                endpoint=endpoint,
            )

        headers = {"Authorization": f"APIKEY {self._token}"}
        try:
            response = self._client.request(
                method,
                endpoint,
                params=params,
                headers=headers,
            )
        except httpx.TimeoutException as exc:
            raise RequestFailedError(
                "Nivlheim request timed out",
                method=method,
                endpoint=endpoint,
            ) from exc
        except httpx.RequestError as exc:
            raise RequestFailedError(
                f"Nivlheim request failed: {exc}",
                method=method,
                endpoint=endpoint,
            ) from exc

        if soft_404 and response.status_code == 404:
            return response

        if response.is_success:
            return response

        request_id = response.headers.get("X-Request-ID")
        correlation_id = response.headers.get("X-Correlation-ID")
        message = response.text.strip() or "Nivlheim request failed"
        error_kwargs = {
            "method": method,
            "status_code": response.status_code,
            "endpoint": endpoint,
            "request_id": request_id,
            "correlation_id": correlation_id,
        }
        if response.status_code == 400 or response.status_code == 422:
            raise ValidationError(message, **error_kwargs)
        if response.status_code == 401:
            raise AuthenticationFailedError(message, **error_kwargs)
        if response.status_code == 403:
            raise ForbiddenError(message, **error_kwargs)
        if response.status_code == 404:
            raise NotFoundError(message, **error_kwargs)
        raise RequestFailedError(message, **error_kwargs)

    def _decode_json_any(
        self,
        response: httpx.Response,
        endpoint: str,
    ) -> dict[str, Any] | list[Any]:
        """Decode any JSON payload type."""
        try:
            decoded = response.json()
        except ValueError as exc:
            raise ResponseDecodeError(
                "Nivlheim returned invalid JSON",
                method=response.request.method,
                status_code=response.status_code,
                endpoint=endpoint,
                request_id=response.headers.get("X-Request-ID"),
                correlation_id=response.headers.get("X-Correlation-ID"),
            ) from exc
        if not isinstance(decoded, (dict, list)):
            raise ResponseDecodeError(
                "Nivlheim returned a JSON scalar where an object or list was expected",
                method=response.request.method,
                status_code=response.status_code,
                endpoint=endpoint,
                request_id=response.headers.get("X-Request-ID"),
                correlation_id=response.headers.get("X-Correlation-ID"),
            )
        return decoded

    def _decode_json_object(self, response: httpx.Response, endpoint: str) -> dict[str, Any]:
        """Decode one JSON object payload."""
        decoded = self._decode_json_any(response, endpoint)
        if not isinstance(decoded, dict):
            raise ResponseDecodeError(
                "Nivlheim returned a JSON list where an object was expected",
                method=response.request.method,
                status_code=response.status_code,
                endpoint=endpoint,
                request_id=response.headers.get("X-Request-ID"),
                correlation_id=response.headers.get("X-Correlation-ID"),
            )
        return decoded

    def _decode_json_collection(
        self,
        response: httpx.Response,
        endpoint: str,
    ) -> list[dict[str, Any]]:
        """Decode one collection response into a flat list of objects."""
        decoded = self._decode_json_any(response, endpoint)
        if isinstance(decoded, list):
            return [item for item in decoded if isinstance(item, dict)]
        for key in ("results", "data", "items"):
            value = decoded.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        return [decoded]

    def _request_target(
        self,
        endpoint: str,
        *,
        params: dict[str, str] | None = None,
        filters: str | Iterable[str] | None = None,
    ) -> str:
        """Build one request target, including hostlist's raw filter grammar."""
        query = urlencode(params or {}, safe="")
        filter_tokens = _normalize_filters(filters)
        if filter_tokens:
            encoded_filters = ",".join(quote(token, safe="=!<>") for token in filter_tokens)
            if query:
                return f"{endpoint}?{query}&{encoded_filters}"
            return f"{endpoint}?{encoded_filters}"
        if query:
            return f"{endpoint}?{query}"
        return endpoint

    def _endpoint_path(self, *parts: str) -> str:
        """Return a relative API endpoint path below the configured version."""
        return "/".join(("", "api", f"v{self._api_version}", *parts))

    def _default_user_agent(self) -> str:
        """Return the default Nivlheim client user agent."""
        return f"osp-uio-integrations/{__version__} nivlheim-client"

    @staticmethod
    def _normalize_params(params: dict[str, object | None]) -> dict[str, str]:
        """Return one encoded-parameter dictionary without ``None`` values."""
        normalized: dict[str, str] = {}
        for key, value in params.items():
            if value is None:
                continue
            if isinstance(value, str):
                normalized[key] = value
                continue
            if isinstance(value, Iterable):
                normalized[key] = ",".join(str(item) for item in value)
                continue
            normalized[key] = str(value)
        return normalized

    @staticmethod
    def _validate_file_lookup(
        *,
        filename: str,
        hostname: str | None,
        certfp: str | None,
    ) -> None:
        """Validate one file lookup request before sending it upstream."""
        if not filename:
            raise ValidationError("filename is required")
        if hostname is None and certfp is None:
            raise ValidationError("expected one of hostname or certfp")
        if hostname is not None and certfp is not None:
            raise ValidationError("expected exactly one of hostname or certfp, not both")


def _split_siteadmins(raw: object) -> tuple[str, ...]:
    """Return normalized siteadmin identifiers from one raw field value."""
    text = str(raw or "").strip()
    if not text:
        return ()
    return tuple(part.strip() for part in text.split(",") if part.strip())


def _map_provider(product: object) -> str:
    """Map one raw Nivlheim product string into a stable provider hint."""
    text = str(product or "").strip()
    if text.startswith("Vmware"):
        return "vmware"
    if text.startswith("Openstack Compute"):
        return "nrec"
    return "unknown"


def _coerce_int(value: object) -> int | None:
    """Return one integer value when the upstream field can be parsed."""
    if value is None:
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            return int(text)
        except ValueError:
            return None
    if isinstance(value, (bytes, bytearray)):
        try:
            return int(value)
        except ValueError:
            return None
    try:
        return int(cast(SupportsInt | SupportsIndex, value))
    except (TypeError, ValueError):
        return None


def _normalize_filters(filters: str | Iterable[str] | None) -> tuple[str, ...]:
    """Normalize hostlist filters into Nivlheim's raw expression format."""
    if filters is None:
        return ()
    if isinstance(filters, str):
        candidates = [part.strip() for part in filters.split(",")]
    else:
        candidates = [str(part).strip() for part in filters]

    normalized: list[str] = []
    for candidate in candidates:
        if not candidate:
            continue
        if any(operator in candidate for operator in ("!=", "<=", ">=", "=", "<", ">")):
            normalized.append(candidate)
            continue
        normalized.append(f"hostname={candidate}")
    return tuple(normalized)
