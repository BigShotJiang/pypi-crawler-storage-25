"""Nivlheim client package.

This package provides a small synchronous client for the UiO Nivlheim API. It
owns HTTP transport, APIKEY auth, stable error mapping, and light response
normalization for the host and file reads that OSP callers share.

It does not own CLI report logic, caller policy, or broader workflow decisions.
Modules under ``osp_uio_integrations.nivlheim`` remain implementation details
unless re-exported here or documented as public elsewhere.
"""

from .client import NivlheimClient
from .exceptions import (
    AuthenticationFailedError,
    AuthenticationRequiredError,
    ForbiddenError,
    NivlheimError,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from .models import GrepMatch, HostRecord

__all__ = [
    "AuthenticationFailedError",
    "AuthenticationRequiredError",
    "ForbiddenError",
    "GrepMatch",
    "HostRecord",
    "NivlheimClient",
    "NivlheimError",
    "NotFoundError",
    "RequestFailedError",
    "ResponseDecodeError",
    "ValidationError",
]
