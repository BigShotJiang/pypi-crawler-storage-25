"""Stable exception taxonomy for the Nivlheim client.

The library keeps a deliberately small exception surface so callers can handle
authentication failures, missing resources, decode problems, and ordinary HTTP
or network errors without importing ``httpx`` directly.
"""

from __future__ import annotations


class NivlheimError(Exception):
    """Base exception for Nivlheim client failures."""


class RequestFailedError(NivlheimError):
    """Raised when Nivlheim or the network fails a request."""

    def __init__(
        self,
        message: str,
        *,
        method: str | None = None,
        status_code: int | None = None,
        endpoint: str | None = None,
        request_id: str | None = None,
        correlation_id: str | None = None,
    ) -> None:
        """Store stable request metadata alongside the error."""
        super().__init__(message)
        self.method = method
        self.status_code = status_code
        self.endpoint = endpoint
        self.request_id = request_id
        self.correlation_id = correlation_id


class AuthenticationRequiredError(RequestFailedError):
    """Raised when a request needs an API token and none is configured."""


class AuthenticationFailedError(RequestFailedError):
    """Raised when Nivlheim rejects the configured API token."""


class ForbiddenError(RequestFailedError):
    """Raised when Nivlheim denies access to an authenticated caller."""


class NotFoundError(RequestFailedError):
    """Raised when a requested Nivlheim object does not exist."""


class ValidationError(RequestFailedError):
    """Raised when local or remote validation rejects a request."""


class ResponseDecodeError(RequestFailedError):
    """Raised when Nivlheim returns a body the client cannot decode."""
