from __future__ import annotations

import ast
from pathlib import Path

import osp_uio_integrations.mreg as mreg
import osp_uio_integrations.mreg.hosts as hosts
import osp_uio_integrations.mreg.hosts.records as records
import osp_uio_integrations.mreg.networks as networks
import osp_uio_integrations.nivlheim as nivlheim

REPO_ROOT = Path(__file__).resolve().parents[2]
SRC_ROOT = REPO_ROOT / "src"
MREG_ROOT = SRC_ROOT / "osp_uio_integrations" / "mreg"
HOSTS_ROOT = MREG_ROOT / "hosts"


def test_host_model_modules_stay_transport_free() -> None:
    _assert_imports_within_allowlist(
        HOSTS_ROOT / "models.py",
        allowed_prefixes={
            "__future__",
            "dataclasses",
            "datetime",
            "ipaddress",
            "osp_uio_integrations.mreg.enums",
            "typing",
        },
    )
    _assert_imports_within_allowlist(
        HOSTS_ROOT / "records" / "models.py",
        allowed_prefixes={
            "__future__",
            "dataclasses",
            "typing",
        },
    )


def test_host_modules_do_not_import_httpx_directly() -> None:
    offenders: list[str] = []

    for path in HOSTS_ROOT.rglob("*.py"):
        imports = _resolved_imports(path)
        if any(
            import_name == "httpx" or import_name.startswith("httpx.")
            for import_name in imports
        ):
            offenders.append(path.relative_to(REPO_ROOT).as_posix())

    assert not offenders, "host modules should depend on the shared client, not on httpx directly"


def test_client_depends_on_host_facade_only() -> None:
    imports = _resolved_imports(MREG_ROOT / "client.py")
    disallowed = sorted(
        import_name
        for import_name in imports
        if import_name.startswith("osp_uio_integrations.mreg.hosts.")
    )

    assert not disallowed, (
        "client.py should compose through osp_uio_integrations.mreg.hosts only, "
        f"not concrete host modules: {disallowed}"
    )


def test_public_facades_stay_curated() -> None:
    assert set(mreg.__all__) == {
        "AddressFamily",
        "AuthenticationFailedError",
        "AuthenticationRequiredError",
        "CompatibilityFallback",
        "ConflictError",
        "ForbiddenError",
        "MregClient",
        "MregError",
        "MutationStateUncertainError",
        "MutationStep",
        "NotFoundError",
        "RequestFailedError",
        "RequestMethod",
        "ResponseDecodeError",
        "SshfpAlgorithm",
        "SshfpHashType",
        "ValidationError",
        "ValidationSource",
    }
    assert set(hosts.__all__) == {
        "AddressMoveResult",
        "AddressRecord",
        "CnameRecord",
        "HostHistoryRecord",
        "HostRecord",
        "HostsAPI",
    }
    assert set(records.__all__) == {
        "HinfoRecord",
        "HostRecordsAPI",
        "LocRecord",
        "MxRecord",
        "NaptrIdentity",
        "NaptrRecord",
        "PtrRecord",
        "SrvRecord",
        "SshfpRecord",
        "TxtRecord",
    }
    assert set(networks.__all__) == {
        "NetworkRecord",
        "NetworkUsageRecord",
        "NetworksAPI",
        "VlanUsageRecord",
    }
    assert set(nivlheim.__all__) == {
        "AuthenticationFailedError",
        "AuthenticationRequiredError",
        "ForbiddenError",
        "GrepMatch",
        "HostRecord",
        "NivlheimClient",
        "NivlheimError",
        "NotFoundError",
        "RequestFailedError",
        "ResponseDecodeError",
        "ValidationError",
    }


def _assert_imports_within_allowlist(path: Path, *, allowed_prefixes: set[str]) -> None:
    imports = _resolved_imports(path)
    disallowed = sorted(
        import_name
        for import_name in imports
        if not any(
            import_name == allowed_prefix or import_name.startswith(f"{allowed_prefix}.")
            for allowed_prefix in allowed_prefixes
        )
    )
    assert not disallowed, (
        f"{path.relative_to(REPO_ROOT).as_posix()} imports disallowed modules: {disallowed}"
    )


def _resolved_imports(path: Path) -> set[str]:
    tree = ast.parse(path.read_text())
    imports: set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            resolved = _resolve_import_from(path, node)
            if resolved:
                imports.add(resolved)

    return imports


def _resolve_import_from(path: Path, node: ast.ImportFrom) -> str:
    if node.level == 0:
        return node.module or ""

    package_parts = _package_parts(path)
    if node.level > 1:
        package_parts = package_parts[: -(node.level - 1)]

    if node.module:
        package_parts.extend(node.module.split("."))

    return ".".join(package_parts)


def _package_parts(path: Path) -> list[str]:
    module_name = _module_name(path)
    parts = module_name.split(".")
    if path.name == "__init__.py":
        return parts
    return parts[:-1]


def _module_name(path: Path) -> str:
    relative = path.relative_to(SRC_ROOT).with_suffix("")
    parts = list(relative.parts)
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)
