import osp_uio_integrations as integrations
from osp_uio_integrations.mreg import (
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    SshfpAlgorithm,
    SshfpHashType,
)
from osp_uio_integrations.mreg.hosts import HostHistoryRecord, HostRecord
from osp_uio_integrations.mreg.hosts.records import HostRecordsAPI, PtrRecord, SrvRecord
from osp_uio_integrations.nivlheim import (
    GrepMatch,
    NivlheimClient,
)
from osp_uio_integrations.nivlheim import (
    HostRecord as NivlheimHostRecord,
)


def test_version_export_is_present() -> None:
    assert integrations.__version__ == "0.1.0"


def test_mreg_client_export_is_present() -> None:
    assert MregClient.__name__ == "MregClient"


def test_nivlheim_client_export_is_present() -> None:
    assert integrations.NivlheimClient.__name__ == "NivlheimClient"
    assert NivlheimClient.__name__ == "NivlheimClient"


def test_mreg_mutation_exports_are_present() -> None:
    assert MutationStateUncertainError.__name__ == "MutationStateUncertainError"
    assert MutationStep.__name__ == "MutationStep"


def test_host_exports_are_present() -> None:
    assert HostRecord.__name__ == "HostRecord"
    assert HostHistoryRecord.__name__ == "HostHistoryRecord"
    assert HostRecordsAPI.__name__ == "HostRecordsAPI"
    assert PtrRecord.__name__ == "PtrRecord"
    assert SrvRecord.__name__ == "SrvRecord"


def test_sshfp_enums_are_present() -> None:
    assert int(SshfpAlgorithm.ED25519) == 4
    assert int(SshfpHashType.SHA256) == 2


def test_nivlheim_model_exports_are_present() -> None:
    assert NivlheimHostRecord.__name__ == "HostRecord"
    assert GrepMatch.__name__ == "GrepMatch"
