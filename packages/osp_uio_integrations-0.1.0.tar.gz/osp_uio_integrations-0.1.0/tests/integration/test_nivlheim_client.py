import httpx
import pytest

from osp_uio_integrations.nivlheim import (
    AuthenticationRequiredError,
    NivlheimClient,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)


def test_public_export_is_available() -> None:
    client = NivlheimClient(base_url="https://nivlheim.example.test", token="token")
    assert client.base_url == "https://nivlheim.example.test"
    assert client.api_version == 2
    client.close()


def test_get_host_by_name_normalizes_provider_and_siteadmins() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["User-Agent"] == "osp-uio-integrations/0.1.0 nivlheim-client"
        assert request.headers["Authorization"] == "APIKEY token"
        assert request.url.path == "/api/v2/host/example.uio.no"
        assert request.url.query == b"fields=hostname%2Cproduct%2Csiteadmin%2Cimportance"
        return httpx.Response(
            200,
            json={
                "hostname": "example.uio.no",
                "product": "Vmware ESXi 8.0",
                "siteadmin": "alice, bob",
                "importance": "4",
            },
        )

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.get_host_by_name("example.uio.no")

    assert host == {
        "hostname": "example.uio.no",
        "provider": "vmware",
        "siteadmins": ["alice", "bob"],
        "importance": 4,
    }
    client.close()


def test_get_host_by_name_returns_none_on_404() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "missing"})

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    assert client.get_host_by_name("missing.uio.no") == {}
    assert client.host_exists("missing.uio.no") is False
    client.close()


def test_get_host_record_by_name_returns_typed_model() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "hostname": "example.uio.no",
                "product": "Openstack Compute",
                "siteadmin": "alice,bob",
                "importance": 3,
            },
        )

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.get_host_record_by_name("example.uio.no")

    assert host is not None
    assert host.hostname == "example.uio.no"
    assert host.provider == "nrec"
    assert host.siteadmins == ("alice", "bob")
    assert host.to_dict() == {
        "hostname": "example.uio.no",
        "provider": "nrec",
        "siteadmins": ["alice", "bob"],
        "importance": 3,
    }
    client.close()


def test_get_host_by_name_defaults_importance_to_existing_contract() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "hostname": "example.uio.no",
                "product": "Vmware ESXi 8.0",
                "siteadmin": "alice",
            },
        )

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.get_host_by_name("example.uio.no")

    assert host == {
        "hostname": "example.uio.no",
        "provider": "vmware",
        "siteadmins": ["alice"],
        "importance": 5,
    }
    client.close()


def test_missing_token_raises_before_request() -> None:
    client = NivlheimClient(base_url="https://nivlheim.example.test")

    with pytest.raises(AuthenticationRequiredError):
        client.get_host("example.uio.no")

    client.close()


def test_list_files_flattens_collection_wrappers() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v2/file"
        assert request.url.query == (
            b"filename=%2Fetc%2Fuio%2Fconf%2Fsite-admin&"
            b"fields=hostname%2Ccontent&lastseen=30d"
        )
        return httpx.Response(
            200,
            json={
                "results": [
                    {"hostname": "a.uio.no", "content": "ops-a\n"},
                    {"hostname": "b.uio.no", "content": "ops-b\n"},
                ]
            },
        )

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    rows = client.list_files(
        filename="/etc/uio/conf/site-admin",
        fields=("hostname", "content"),
        lastseen="30d",
    )

    assert rows == [
        {"hostname": "a.uio.no", "content": "ops-a\n"},
        {"hostname": "b.uio.no", "content": "ops-b\n"},
    ]
    client.close()


def test_get_file_by_name_returns_empty_string_on_404() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v2/file"
        assert request.url.query == (
            b"filename=%2Fetc%2Fuio%2Fconf%2Fsite-admin&hostname=example.uio.no&format=raw"
        )
        return httpx.Response(404, text="missing")

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    content = client.get_file_by_name(
        hostname="example.uio.no",
        filename="/etc/uio/conf/site-admin",
    )

    assert content == ""
    client.close()


def test_get_siteadmins_from_file_returns_list() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="ops-a\nops-b\n")

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    assert client.get_siteadmins_from_file("example.uio.no") == ["ops-a", "ops-b"]
    client.close()


def test_grep_parses_raw_lines_into_matches() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v2/grep"
        assert request.url.query == b"q=alice&filename=%2Fetc%2Fpasswd&limit=2"
        return httpx.Response(
            200,
            text=(
                "host-1:/etc/passwd:alice:x:1000:1000::/home/alice:/bin/bash\n"
                "host-2:/etc/passwd:alice:x:1001:1001::/home/alice:/bin/bash\n"
            ),
        )

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    matches = client.grep(q="alice", filename="/etc/passwd", limit=2)

    assert [(match.hostname, match.filename) for match in matches] == [
        ("host-1", "/etc/passwd"),
        ("host-2", "/etc/passwd"),
    ]
    client.close()


def test_hostlist_preserves_raw_filter_grammar() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v2/hostlist"
        assert request.url.query == (
            b"fields=hostname%2Csiteadmin&sort=hostname&limit=10&"
            b"siteadmin=ops%20drift,hostname=web-01.uio.no"
        )
        return httpx.Response(200, json=[{"hostname": "web-01.uio.no", "siteadmin": "ops drift"}])

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    rows = client.hostlist(
        fields=("hostname", "siteadmin"),
        filters=("siteadmin=ops drift", "web-01.uio.no"),
        sort="hostname",
        limit=10,
    )

    assert rows == [{"hostname": "web-01.uio.no", "siteadmin": "ops drift"}]
    client.close()


def test_delete_host_is_idempotent_on_404() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "DELETE"
        if request.url.path.endswith("/present.uio.no"):
            return httpx.Response(204)
        return httpx.Response(404, text="missing")

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    assert client.delete_host("present.uio.no") is True
    assert client.delete_host("missing.uio.no") is False
    client.close()


def test_invalid_json_raises_decode_error() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="not json")

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ResponseDecodeError):
        client.get_host("example.uio.no")

    client.close()


def test_network_failure_is_mapped_to_request_failed_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom", request=request)

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError):
        client.status()

    client.close()


def test_search_msearch_and_status_decode_successfully() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v2/search":
            assert request.url.query == (
                b"q=alice&fields=hostname%2Cfilename&filename=%2Fetc%2Fpasswd"
            )
            return httpx.Response(200, json=[{"hostname": "host-1", "filename": "/etc/passwd"}])
        if request.url.path == "/api/v2/msearch":
            assert request.url.query == (
                b"fields=hostname&q1=alice&f1=%2Fetc%2Fpasswd&op2=and&q2=bob"
            )
            return httpx.Response(200, json={"items": [{"hostname": "host-2"}]})
        if request.url.path == "/api/v2/status":
            return httpx.Response(200, json={"ok": True})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = NivlheimClient(
        base_url="https://nivlheim.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    search_rows = client.search(
        q="alice",
        fields=("hostname", "filename"),
        filename="/etc/passwd",
    )
    msearch_rows = client.msearch(
        fields="hostname",
        q1="alice",
        f1="/etc/passwd",
        op2="and",
        q2="bob",
    )
    status = client.status()

    assert search_rows == [{"hostname": "host-1", "filename": "/etc/passwd"}]
    assert msearch_rows == [{"hostname": "host-2"}]
    assert status == {"ok": True}
    client.close()


def test_search_and_msearch_validate_required_parameters() -> None:
    client = NivlheimClient(base_url="https://nivlheim.example.test", token="token")

    with pytest.raises(ValidationError):
        client.search(q="", fields="hostname")
    with pytest.raises(ValidationError):
        client.msearch(fields="hostname")
    with pytest.raises(ValidationError):
        client.get_file_by_name(filename="/etc/hosts", hostname="example.uio.no", format="json")

    client.close()
