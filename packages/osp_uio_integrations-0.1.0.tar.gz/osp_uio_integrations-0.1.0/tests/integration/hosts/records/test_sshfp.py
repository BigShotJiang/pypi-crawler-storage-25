import httpx
import pytest

from osp_uio_integrations.mreg import (
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    RequestFailedError,
    SshfpAlgorithm,
    SshfpHashType,
)


def test_sshfp_add_accepts_enum_inputs_and_refetches_after_empty_create() -> None:
    requests_seen: list[tuple[str, str, bytes, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, request.content, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "GET":
            if len([item for item in requests_seen if item[:2] == ("GET", "/api/v1/sshfps/")]) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 9,
                            "host": 10,
                            "algorithm": 4,
                            "hash_type": 2,
                            "fingerprint": "abcdef",
                        }
                    ]
                },
            )
        if request.url.path == "/api/v1/sshfps/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.sshfp.add(
        "example.uio.no",
        algorithm=SshfpAlgorithm.ED25519,
        hash_type=SshfpHashType.SHA256,
        fingerprint="abcdef",
    )

    assert record.algorithm == 4
    assert record.hash_type == 2
    assert (
        "POST",
        "/api/v1/sshfps/",
        b'{"host":10,"algorithm":4,"hash_type":2,"fingerprint":"abcdef"}',
        "",
    ) in requests_seen
    client.close()


def test_sshfp_add_raises_request_failed_when_verify_does_not_find_created_record() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        if request.url.path == "/api/v1/sshfps/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.sshfp.add(
            "example.uio.no",
            algorithm=SshfpAlgorithm.ED25519,
            hash_type=SshfpHashType.SHA256,
            fingerprint="abcdef",
        )

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/sshfps/"
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", ""),
        ("GET", "/api/v1/sshfps/", "10"),
        ("POST", "/api/v1/sshfps/", ""),
        ("GET", "/api/v1/sshfps/", "10"),
    ]
    client.close()


def test_sshfp_add_raises_request_failed_when_verify_returns_404_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/sshfps/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.sshfp.add(
            "example.uio.no",
            algorithm=SshfpAlgorithm.ED25519,
            hash_type=SshfpHashType.SHA256,
            fingerprint="abcdef",
        )

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/sshfps/"
    client.close()


def test_sshfp_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/sshfps/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.sshfp.add(
            "example.uio.no",
            algorithm=SshfpAlgorithm.ED25519,
            hash_type=SshfpHashType.SHA256,
            fingerprint="abcdef",
        )

    assert exc_info.value.operation == "create_sshfp_record"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_sshfp_remove_without_fingerprint_deletes_all_host_records() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 9,
                            "host": 10,
                            "algorithm": 4,
                            "hash_type": 2,
                            "fingerprint": "abcdef",
                        },
                        {
                            "id": 11,
                            "host": 10,
                            "algorithm": 1,
                            "hash_type": 1,
                            "fingerprint": "123456",
                        },
                    ]
                },
            )
        if request.method == "DELETE" and request.url.path in {
            "/api/v1/sshfps/9",
            "/api/v1/sshfps/11",
        }:
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    client.hosts.records.sshfp.remove("example.uio.no")

    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", ""),
        ("GET", "/api/v1/sshfps/", "10"),
        ("DELETE", "/api/v1/sshfps/9", ""),
        ("DELETE", "/api/v1/sshfps/11", ""),
    ]
    client.close()


def test_sshfp_remove_raises_uncertain_state_after_partial_delete() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 9,
                            "host": 10,
                            "algorithm": 4,
                            "hash_type": 2,
                            "fingerprint": "abcdef",
                        },
                        {
                            "id": 11,
                            "host": 10,
                            "algorithm": 1,
                            "hash_type": 1,
                            "fingerprint": "123456",
                        },
                    ]
                },
            )
        if request.method == "DELETE" and request.url.path == "/api/v1/sshfps/9":
            return httpx.Response(204, content=b"")
        if request.method == "DELETE" and request.url.path == "/api/v1/sshfps/11":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.sshfp.remove("example.uio.no")

    assert exc_info.value.operation == "delete_sshfp_records"
    assert exc_info.value.completed_steps == (MutationStep("delete_record", detail="9"),)
    client.close()


def test_sshfp_remove_reraises_request_failure_when_first_delete_fails() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/sshfps/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 9,
                            "host": 10,
                            "algorithm": 4,
                            "hash_type": 2,
                            "fingerprint": "abcdef",
                        },
                        {
                            "id": 11,
                            "host": 10,
                            "algorithm": 1,
                            "hash_type": 1,
                            "fingerprint": "123456",
                        },
                    ]
                },
            )
        if request.method == "DELETE" and request.url.path == "/api/v1/sshfps/9":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.sshfp.remove("example.uio.no")

    assert exc_info.value.endpoint == "/api/v1/sshfps/9"
    client.close()
