import httpx
import pytest

from osp_uio_integrations.mreg import (
    ConflictError,
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    RequestFailedError,
    ValidationError,
    ValidationSource,
)


def test_txt_add_can_refetch_after_empty_create_response() -> None:
    requests_seen: list[tuple[str, str, bytes, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, request.content, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/txts/" and request.method == "GET":
            if len([item for item in requests_seen if item[:2] == ("GET", "/api/v1/txts/")]) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(
                200,
                json={"results": [{"id": 7, "host": 10, "txt": "v=spf1 include:uio.no"}]},
            )
        if request.url.path == "/api/v1/txts/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.txt.add("example.uio.no", "v=spf1 include:uio.no")

    assert record.text == "v=spf1 include:uio.no"
    assert (
        "POST",
        "/api/v1/txts/",
        b'{"host":10,"txt":"v=spf1 include:uio.no"}',
        "",
    ) in requests_seen
    client.close()


def test_txt_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, bytes, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, request.content, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/txts/" and request.method == "GET":
            if len([item for item in requests_seen if item[:2] == ("GET", "/api/v1/txts/")]) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/txts/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.txt.add("example.uio.no", "v=spf1 include:uio.no")

    assert exc_info.value.operation == "create_txt_record"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_mx_add_is_idempotent_when_exact_record_exists() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/mxs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={"results": [{"id": 5, "host": 10, "mx": "mx1.uio.no", "priority": 10}]},
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.mx.add(
        "example.uio.no",
        exchange="mx1.uio.no",
        priority=10,
    )

    assert record.exchange == "mx1.uio.no"
    assert record.priority == 10
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", ""),
        ("GET", "/api/v1/mxs/", "10"),
    ]
    client.close()


def test_mx_add_rejects_out_of_range_priority_locally() -> None:
    client = MregClient(base_url="https://mreg.example.test", token="token")

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.records.mx.add(
            "example.uio.no",
            exchange="mx1.uio.no",
            priority=70000,
        )

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "POST"
    client.close()


def test_mx_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/mxs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/mxs/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/mxs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.mx.add(
            "example.uio.no",
            exchange="mx1.uio.no",
            priority=10,
        )

    assert exc_info.value.operation == "create_mx_record"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_mx_add_raises_request_failed_when_verify_returns_404_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/mxs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/mxs/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/mxs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.mx.add(
            "example.uio.no",
            exchange="mx1.uio.no",
            priority=10,
        )

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/mxs/"
    client.close()


def test_hinfo_add_rejects_conflicting_existing_record() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/hinfos/" and request.method == "GET":
            return httpx.Response(
                200,
                json={"results": [{"id": 4, "host": 10, "cpu": "x86_64", "os": "Linux"}]},
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ConflictError):
        client.hosts.records.hinfo.add("example.uio.no", cpu="arm64", os="Linux")

    client.close()


def test_hinfo_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/hinfos/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/hinfos/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/hinfos/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.hinfo.add("example.uio.no", cpu="x86_64", os="Linux")

    assert exc_info.value.operation == "create_hinfo_record"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_hinfo_add_raises_request_failed_when_verify_returns_404_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/hinfos/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/hinfos/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/hinfos/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.hinfo.add("example.uio.no", cpu="x86_64", os="Linux")

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/hinfos/"
    client.close()
