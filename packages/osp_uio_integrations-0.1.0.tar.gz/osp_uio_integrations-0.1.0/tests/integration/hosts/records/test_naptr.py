import httpx
import pytest

from osp_uio_integrations.mreg import (
    ConflictError,
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
    ValidationSource,
)
from osp_uio_integrations.mreg.hosts.records import NaptrIdentity


def test_naptr_remove_requires_force_for_multiple_matches() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 4,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                        {
                            "id": 5,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                    ]
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.records.naptr.remove(
            "example.uio.no",
            NaptrIdentity(
                preference=10,
                order=20,
                flag="s",
                service="SIP+D2U",
                regex="",
                replacement="_sip._udp.example.uio.no",
            ),
        )

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "DELETE"
    client.close()


def test_naptr_remove_raises_uncertain_state_after_partial_delete() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 4,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                        {
                            "id": 5,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                    ]
                },
            )
        if request.url.path == "/api/v1/naptrs/4" and request.method == "DELETE":
            return httpx.Response(204, content=b"")
        if request.url.path == "/api/v1/naptrs/5" and request.method == "DELETE":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.naptr.remove(
            "example.uio.no",
            NaptrIdentity(
                preference=10,
                order=20,
                flag="s",
                service="SIP+D2U",
                regex="",
                replacement="_sip._udp.example.uio.no",
            ),
            force=True,
        )

    assert exc_info.value.operation == "delete_naptr_records"
    assert exc_info.value.completed_steps == (MutationStep("delete_record", detail="4"),)
    client.close()


def test_naptr_remove_reraises_request_failure_when_first_delete_fails() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 4,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                        {
                            "id": 5,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                    ]
                },
            )
        if request.url.path == "/api/v1/naptrs/4" and request.method == "DELETE":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.naptr.remove(
            "example.uio.no",
            NaptrIdentity(
                preference=10,
                order=20,
                flag="s",
                service="SIP+D2U",
                regex="",
                replacement="_sip._udp.example.uio.no",
            ),
            force=True,
        )

    assert exc_info.value.endpoint == "/api/v1/naptrs/4"
    client.close()


def test_naptr_add_normalizes_identity_whitespace_and_uses_post_body() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        if request.url.path == "/api/v1/naptrs/" and request.method == "POST":
            return httpx.Response(
                201,
                json={
                    "id": 4,
                    "host": 10,
                    "preference": 10,
                    "order": 20,
                    "flag": " s ",
                    "service": " SIP+D2U ",
                    "regex": "  ",
                    "replacement": " _sip._udp.example.uio.no ",
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.naptr.add(
        "example.uio.no",
        NaptrIdentity(
            preference=10,
            order=20,
            flag=" s ",
            service=" SIP+D2U ",
            regex="  ",
            replacement=" _sip._udp.example.uio.no ",
        ),
    )

    assert record.flag == "s"
    assert record.service == "SIP+D2U"
    assert record.regex == ""
    assert record.replacement == "_sip._udp.example.uio.no"
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", ""),
        ("GET", "/api/v1/naptrs/", "10"),
        ("POST", "/api/v1/naptrs/", ""),
    ]
    client.close()


def test_naptr_add_raises_request_failed_when_verify_does_not_find_created_record() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        if request.url.path == "/api/v1/naptrs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.naptr.add(
            "example.uio.no",
            NaptrIdentity(
                preference=10,
                order=20,
                flag="s",
                service="SIP+D2U",
                regex="",
                replacement="_sip._udp.example.uio.no",
            ),
        )

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/naptrs/"
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", ""),
        ("GET", "/api/v1/naptrs/", "10"),
        ("POST", "/api/v1/naptrs/", ""),
        ("GET", "/api/v1/naptrs/", "10"),
    ]
    client.close()


def test_naptr_add_raises_request_failed_when_verify_returns_404_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/naptrs/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.naptr.add(
            "example.uio.no",
            NaptrIdentity(
                preference=10,
                order=20,
                flag="s",
                service="SIP+D2U",
                regex="",
                replacement="_sip._udp.example.uio.no",
            ),
        )

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/naptrs/"
    client.close()


def test_naptr_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        requests_seen.append((request.method, request.url.path, host_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/naptrs/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.naptr.add(
            "example.uio.no",
            NaptrIdentity(
                preference=10,
                order=20,
                flag="s",
                service="SIP+D2U",
                regex="",
                replacement="_sip._udp.example.uio.no",
            ),
        )

    assert exc_info.value.operation == "create_naptr_record"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_naptr_add_rejects_multiple_existing_matches() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 4,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                        {
                            "id": 5,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                    ]
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ConflictError) as exc_info:
        client.hosts.records.naptr.add(
            "example.uio.no",
            NaptrIdentity(
                preference=10,
                order=20,
                flag="s",
                service="SIP+D2U",
                regex="",
                replacement="_sip._udp.example.uio.no",
            ),
        )

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/naptrs/"
    client.close()


def test_naptr_remove_with_force_deletes_all_matching_records() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 4,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                        {
                            "id": 5,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                    ]
                },
            )
        if request.method == "DELETE" and request.url.path in {
            "/api/v1/naptrs/4",
            "/api/v1/naptrs/5",
        }:
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    client.hosts.records.naptr.remove(
        "example.uio.no",
        NaptrIdentity(
            preference=10,
            order=20,
            flag="s",
            service="SIP+D2U",
            regex="",
            replacement="_sip._udp.example.uio.no",
        ),
        force=True,
    )

    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", ""),
        ("GET", "/api/v1/naptrs/", "10"),
        ("DELETE", "/api/v1/naptrs/4", ""),
        ("DELETE", "/api/v1/naptrs/5", ""),
    ]
    client.close()


def test_naptr_remove_validates_all_ids_before_delete() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/naptrs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 4,
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                        {
                            "host": 10,
                            "preference": 10,
                            "order": 20,
                            "flag": "s",
                            "service": "SIP+D2U",
                            "regex": "",
                            "replacement": "_sip._udp.example.uio.no",
                        },
                    ]
                },
            )
        if request.method == "DELETE":
            raise AssertionError("delete should not start before all record ids are validated")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ResponseDecodeError) as exc_info:
        client.hosts.records.naptr.remove(
            "example.uio.no",
            NaptrIdentity(
                preference=10,
                order=20,
                flag="s",
                service="SIP+D2U",
                regex="",
                replacement="_sip._udp.example.uio.no",
            ),
            force=True,
        )

    assert exc_info.value.method == "GET"
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", ""),
        ("GET", "/api/v1/naptrs/", "10"),
    ]
    client.close()
