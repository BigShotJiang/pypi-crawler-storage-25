import httpx
import pytest

from osp_uio_integrations.mreg import (
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ValidationError,
    ValidationSource,
)


def test_srv_add_checks_forward_zones_and_refetches_after_empty_create() -> None:
    requests_seen: list[tuple[str, str, bytes, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        name_param = request.url.params.get("name", "")
        requests_seen.append((request.method, request.url.path, request.content, name_param))
        if request.url.path == "/api/v1/zones/forward/hostname/_sip._tcp.example.uio.no":
            return httpx.Response(200, json={"zone": {"name": "example.uio.no"}})
        if request.url.path == "/api/v1/hosts/target.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "target.uio.no"})
        if request.url.path == "/api/v1/zones/forward/hostname/target.uio.no":
            return httpx.Response(200, json={"zone": {"name": "uio.no"}})
        if request.url.path == "/api/v1/srvs/" and request.method == "GET":
            if len([item for item in requests_seen if item[:2] == ("GET", "/api/v1/srvs/")]) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 13,
                            "name": "_sip._tcp.example.uio.no",
                            "host": 10,
                            "priority": 10,
                            "weight": 5,
                            "port": 5060,
                            "ttl": 3600,
                        }
                    ]
                },
            )
        if request.url.path == "/api/v1/srvs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.srv.add(
        "_sip._tcp.example.uio.no",
        target_host="target.uio.no",
        priority=10,
        weight=5,
        port=5060,
        ttl=3600,
    )

    assert record.name == "_sip._tcp.example.uio.no"
    assert record.ttl == 3600
    assert (
        "POST",
        "/api/v1/srvs/",
        b'{"name":"_sip._tcp.example.uio.no","host":10,"priority":10,"weight":5,"port":5060,"ttl":3600}',
        "",
    ) in requests_seen
    client.close()


def test_srv_add_requires_forward_zone_for_service_name() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/zones/forward/hostname/_sip._tcp.example.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(NotFoundError) as exc_info:
        client.hosts.records.srv.add(
            "_sip._tcp.example.uio.no",
            target_host="target.uio.no",
            priority=10,
            weight=5,
            port=5060,
        )

    assert exc_info.value.method == "GET"
    assert exc_info.value.endpoint == "/api/v1/zones/forward/hostname/_sip._tcp.example.uio.no"
    client.close()


def test_srv_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("name", "")))
        if request.url.path == "/api/v1/zones/forward/hostname/_sip._tcp.example.uio.no":
            return httpx.Response(200, json={"zone": {"name": "example.uio.no"}})
        if request.url.path == "/api/v1/hosts/target.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "target.uio.no"})
        if request.url.path == "/api/v1/zones/forward/hostname/target.uio.no":
            return httpx.Response(200, json={"zone": {"name": "uio.no"}})
        if request.url.path == "/api/v1/srvs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/srvs/", "_sip._tcp.example.uio.no")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/srvs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.srv.add(
            "_sip._tcp.example.uio.no",
            target_host="target.uio.no",
            priority=10,
            weight=5,
            port=5060,
            ttl=3600,
        )

    assert exc_info.value.operation == "create_srv_record"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_srv_add_raises_request_failed_when_verify_returns_404_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("name", "")))
        if request.url.path == "/api/v1/zones/forward/hostname/_sip._tcp.example.uio.no":
            return httpx.Response(200, json={"zone": {"name": "example.uio.no"}})
        if request.url.path == "/api/v1/hosts/target.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "target.uio.no"})
        if request.url.path == "/api/v1/zones/forward/hostname/target.uio.no":
            return httpx.Response(200, json={"zone": {"name": "uio.no"}})
        if request.url.path == "/api/v1/srvs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/srvs/", "_sip._tcp.example.uio.no")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/srvs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.srv.add(
            "_sip._tcp.example.uio.no",
            target_host="target.uio.no",
            priority=10,
            weight=5,
            port=5060,
            ttl=3600,
        )

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/srvs/"
    client.close()


def test_srv_remove_raises_when_target_service_match_is_missing() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/target.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "target.uio.no"})
        if request.url.path == "/api/v1/srvs/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(NotFoundError):
        client.hosts.records.srv.remove(
            "_sip._tcp.example.uio.no",
            target_host="target.uio.no",
            priority=10,
            weight=5,
            port=5060,
        )

    client.close()


def test_ptr_add_requires_force_when_host_is_not_in_managed_zone() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no", "zone": None})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.records.ptr.add("example.uio.no", "192.0.2.10")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "POST"
    client.close()


def test_ptr_add_invalid_ip_exposes_local_operation_metadata() -> None:
    client = MregClient(base_url="https://mreg.example.test", token="token")

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.records.ptr.add("example.uio.no", "not-an-ip")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/ptroverrides/"
    client.close()


def test_ptr_add_checks_reserved_ip_before_create() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no", "zone": 7})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        if request.url.path == "/api/v1/networks/ip/192.0.2.10":
            return httpx.Response(200, json={"network": "192.0.2.0/24"})
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F24/reserved_list",
            "/api/v1/networks/192.0.2.0/24/reserved_list",
        }:
            return httpx.Response(200, json=["192.0.2.10"])
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.records.ptr.add("example.uio.no", "192.0.2.10")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert (
        "POST",
        "/api/v1/ptroverrides/",
        b'{"host":10,"ipaddress":"192.0.2.10"}',
    ) not in requests_seen
    client.close()


def test_ptr_add_returns_matching_existing_record_for_same_host() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no", "zone": 7})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {"id": 14, "host": 20, "ipaddress": "192.0.2.10"},
                        {"id": 15, "host": 10, "ipaddress": "192.0.2.10"},
                    ]
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.ptr.add("example.uio.no", "192.0.2.10")

    assert record.id == 15
    assert record.host_id == 10
    client.close()


def test_ptr_add_uses_post_response_body_when_available() -> None:
    requests_seen: list[tuple[str, str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        host_param = request.url.params.get("host", "")
        ip_param = request.url.params.get("ipaddress", "")
        requests_seen.append((request.method, request.url.path, host_param, ip_param))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no", "zone": 7})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            if ip_param == "192.0.2.10":
                return httpx.Response(200, json={"results": []})
            raise AssertionError("PTR add should not refetch by host when POST returned a body")
        if request.url.path == "/api/v1/networks/ip/192.0.2.10":
            return httpx.Response(200, json={"network": "192.0.2.0/24"})
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F24/reserved_list",
            "/api/v1/networks/192.0.2.0/24/reserved_list",
        }:
            return httpx.Response(200, json=[])
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "POST":
            return httpx.Response(201, json={"id": 14, "host": 10, "ipaddress": "192.0.2.10"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.ptr.add("example.uio.no", "192.0.2.10")

    assert record.id == 14
    assert record.host_id == 10
    assert requests_seen.count(("GET", "/api/v1/ptroverrides/", "", "192.0.2.10")) == 1
    assert ("GET", "/api/v1/ptroverrides/", "10", "") not in requests_seen
    client.close()


def test_ptr_add_can_refetch_after_empty_create_response() -> None:
    requests_seen: list[tuple[str, str, bytes, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        ip_param = request.url.params.get("ipaddress", "")
        host_param = request.url.params.get("host", "")
        marker = f"{host_param}|{ip_param}"
        requests_seen.append((request.method, request.url.path, request.content, marker))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no", "zone": 7})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            if ip_param == "192.0.2.10":
                return httpx.Response(200, json={"results": []})
            if host_param == "10":
                return httpx.Response(
                    200,
                    json={"results": [{"id": 14, "host": 10, "ipaddress": "192.0.2.10"}]},
                )
        if request.url.path == "/api/v1/networks/ip/192.0.2.10":
            return httpx.Response(200, json={"network": "192.0.2.0/24"})
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F24/reserved_list",
            "/api/v1/networks/192.0.2.0/24/reserved_list",
        }:
            return httpx.Response(200, json=[])
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.ptr.add("example.uio.no", "192.0.2.10")

    assert record.ipaddress == "192.0.2.10"
    assert (
        "POST",
        "/api/v1/ptroverrides/",
        b'{"host":10,"ipaddress":"192.0.2.10"}',
        "|",
    ) in requests_seen
    client.close()


def test_ptr_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no", "zone": 7})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            if request.url.params.get("ipaddress") == "192.0.2.10":
                return httpx.Response(200, json={"results": []})
            if request.url.params.get("host") == "10":
                return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/networks/ip/192.0.2.10":
            return httpx.Response(200, json={"network": "192.0.2.0/24"})
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F24/reserved_list",
            "/api/v1/networks/192.0.2.0/24/reserved_list",
        }:
            return httpx.Response(200, json=[])
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.ptr.add("example.uio.no", "192.0.2.10")

    assert exc_info.value.operation == "create_ptr_override"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_ptr_add_raises_request_failed_when_verify_returns_404_after_empty_success() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no", "zone": 7})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            if request.url.params.get("ipaddress") == "192.0.2.10":
                return httpx.Response(200, json={"results": []})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/networks/ip/192.0.2.10":
            return httpx.Response(200, json={"network": "192.0.2.0/24"})
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F24/reserved_list",
            "/api/v1/networks/192.0.2.0/24/reserved_list",
        }:
            return httpx.Response(200, json=[])
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.ptr.add("example.uio.no", "192.0.2.10")

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/ptroverrides/"
    client.close()


def test_ttl_set_host_patches_host_and_returns_updated_record() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "PATCH":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no", "ttl": 3600})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.records.ttl.set_host("example.uio.no", 3600)

    assert host.ttl == 3600
    assert requests_seen == [("PATCH", "/api/v1/hosts/example.uio.no", b'{"ttl":3600}')]
    client.close()


def test_ttl_set_host_raises_uncertain_state_on_verify_failure() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.ttl.set_host("example.uio.no", 3600)

    assert exc_info.value.operation == "set_host_ttl"
    assert exc_info.value.completed_steps == (MutationStep("ttl_patch_request"),)
    client.close()


def test_ttl_remove_service_patches_unique_srv_record_to_null() -> None:
    requests_seen: list[tuple[str, str, bytes, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        name_param = request.url.params.get("name", "")
        requests_seen.append((request.method, request.url.path, request.content, name_param))
        if request.url.path == "/api/v1/srvs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 13,
                            "name": "_sip._tcp.example.uio.no",
                            "host": 10,
                            "priority": 10,
                            "weight": 5,
                            "port": 5060,
                            "ttl": None,
                        }
                    ]
                },
            )
        if request.url.path == "/api/v1/srvs/13" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    record = client.hosts.records.ttl.remove_service("_sip._tcp.example.uio.no")

    assert record.ttl is None
    assert ("PATCH", "/api/v1/srvs/13", b'{"ttl":null}', "") in requests_seen
    client.close()


def test_ttl_remove_service_raises_uncertain_state_on_verify_failure() -> None:
    requests_seen: list[tuple[str, str, bytes, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        name_param = request.url.params.get("name", "")
        requests_seen.append((request.method, request.url.path, request.content, name_param))
        if request.url.path == "/api/v1/srvs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/srvs/", b"", "_sip._tcp.example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={
                        "results": [
                            {
                                "id": 13,
                                "name": "_sip._tcp.example.uio.no",
                                "host": 10,
                                "priority": 10,
                                "weight": 5,
                                "port": 5060,
                                "ttl": 3600,
                            }
                        ]
                    },
                )
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/srvs/13" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.ttl.remove_service("_sip._tcp.example.uio.no")

    assert exc_info.value.operation == "remove_srv_ttl"
    assert exc_info.value.completed_steps == (MutationStep("ttl_patch_request"),)
    client.close()


def test_ttl_service_rejects_ambiguous_srv_name() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/srvs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 13,
                            "name": "_sip._tcp.example.uio.no",
                            "host": 10,
                            "priority": 10,
                            "weight": 5,
                            "port": 5060,
                            "ttl": 3600,
                        },
                        {
                            "id": 14,
                            "name": "_sip._tcp.example.uio.no",
                            "host": 11,
                            "priority": 20,
                            "weight": 5,
                            "port": 5060,
                            "ttl": 3600,
                        },
                    ]
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.records.ttl.get_service("_sip._tcp.example.uio.no")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "GET"
    client.close()
