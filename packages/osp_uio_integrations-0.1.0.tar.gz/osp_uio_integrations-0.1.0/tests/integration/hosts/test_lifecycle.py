import httpx
import pytest

from osp_uio_integrations.mreg import (
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    RequestFailedError,
    ValidationError,
    ValidationSource,
)


def test_host_create_can_refetch_after_empty_create_response() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        if request.url.path == "/api/v1/hosts/new.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 22,
                    "name": "new.uio.no",
                    "contact": "alice",
                    "comment": "created",
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.lifecycle.create(
        "new.uio.no",
        contacts=["alice"],
        comment="created",
        network="10.0.0.0/24",
    )

    assert host.id == 22
    assert host.name == "new.uio.no"
    assert requests_seen == [
        (
            "POST",
            "/api/v1/hosts/",
            b'{"name":"new.uio.no","contacts":["alice"],"comment":"created","network":"10.0.0.0/24"}',
        ),
        ("GET", "/api/v1/hosts/new.uio.no", b""),
    ]
    client.close()


def test_host_create_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        if request.url.path == "/api/v1/hosts/new.uio.no" and request.method == "GET":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.lifecycle.create("new.uio.no")

    assert exc_info.value.operation == "create_host"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_host_create_treats_missing_verified_host_as_request_failure() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        if request.url.path == "/api/v1/hosts/new.uio.no" and request.method == "GET":
            return httpx.Response(404, json={"detail": "missing"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.lifecycle.create("new.uio.no")

    assert "failed create" in str(exc_info.value)
    client.close()


def test_host_delete_accepts_empty_success_response() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/old.uio.no" and request.method == "GET":
            return httpx.Response(200, json={"id": 9, "name": "old.uio.no"})
        if request.url.path == "/api/v1/hosts/old.uio.no" and request.method == "DELETE":
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    client.hosts.lifecycle.delete("old.uio.no")

    assert requests_seen == [
        ("GET", "/api/v1/hosts/old.uio.no"),
        ("DELETE", "/api/v1/hosts/old.uio.no"),
    ]
    client.close()


def test_host_create_rejects_ipaddress_and_network_together() -> None:
    client = MregClient(base_url="https://mreg.example.test", token="token")

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.lifecycle.create(
            "new.uio.no",
            ipaddress="192.0.2.10",
            network="192.0.2.0/24",
        )

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "POST"
    client.close()


def test_host_create_rejects_wildcard_label_without_force() -> None:
    client = MregClient(base_url="https://mreg.example.test", token="token")

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.lifecycle.create("*.uio.no")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "POST"
    client.close()


def test_host_create_allows_wildcard_label_with_force() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "POST" and request.url.path == "/api/v1/hosts/":
            return httpx.Response(
                201,
                json={"id": 42, "name": "*.uio.no"},
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.lifecycle.create("*.uio.no", force=True)

    assert host.name == "*.uio.no"
    assert requests_seen == [("POST", "/api/v1/hosts/")]
    client.close()


def test_host_create_with_addresses_attaches_secondary_ip() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.method == "POST" and request.url.path == "/api/v1/hosts/":
            return httpx.Response(201, json={"id": 42, "name": "dual.uio.no"})
        if request.method == "GET" and request.url.path == "/api/v1/hosts/dual.uio.no":
            return httpx.Response(
                200,
                json={
                    "id": 42,
                    "name": "dual.uio.no",
                    "ipaddresses": ["192.0.2.10", "2001:db8::10"],
                },
            )
        if request.method == "POST" and request.url.path == "/api/v1/ipaddresses/":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.lifecycle.create_with_addresses(
        "dual.uio.no",
        ipv4="192.0.2.10",
        ipv6="2001:db8::10",
    )

    assert host.name == "dual.uio.no"
    assert host.ipaddresses == ("192.0.2.10", "2001:db8::10")
    assert requests_seen[0] == (
        "POST",
        "/api/v1/hosts/",
        b'{"name":"dual.uio.no","ipaddress":"192.0.2.10"}',
    )
    assert requests_seen[1][0:2] == ("POST", "/api/v1/ipaddresses/")
    client.close()


def test_host_create_with_addresses_raises_uncertain_on_secondary_failure() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST" and request.url.path == "/api/v1/hosts/":
            return httpx.Response(201, json={"id": 42, "name": "dual.uio.no"})
        if request.method == "POST" and request.url.path == "/api/v1/ipaddresses/":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.lifecycle.create_with_addresses(
            "dual.uio.no",
            ipv4="192.0.2.10",
            ipv6="2001:db8::10",
        )

    assert exc_info.value.operation == "create_host_with_addresses"
    assert exc_info.value.completed_steps == (MutationStep("create_host"),)
    assert exc_info.value.remaining_steps == (
        MutationStep("attach_secondary_address", detail="2001:db8::10"),
    )
    client.close()


def test_host_delete_if_exists_is_idempotent() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/gone.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    deleted = client.hosts.lifecycle.delete_if_exists("gone.uio.no")

    assert deleted is False
    assert requests_seen == [("GET", "/api/v1/hosts/gone.uio.no")]
    client.close()


def test_host_delete_if_exists_tolerates_racy_404_on_delete() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/racy.uio.no":
            return httpx.Response(200, json={"name": "racy.uio.no"})
        if request.method == "DELETE" and request.url.path == "/api/v1/hosts/racy.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    deleted = client.hosts.lifecycle.delete_if_exists("racy.uio.no")

    assert deleted is False
    assert requests_seen == [
        ("GET", "/api/v1/hosts/racy.uio.no"),
        ("DELETE", "/api/v1/hosts/racy.uio.no"),
    ]
    client.close()


def test_host_create_with_addresses_raises_uncertain_when_host_id_lookup_fails() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST" and request.url.path == "/api/v1/hosts/":
            return httpx.Response(201, json={"name": "dual.uio.no"})
        if request.method == "GET" and request.url.path == "/api/v1/hosts/dual.uio.no":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.lifecycle.create_with_addresses(
            "dual.uio.no",
            ipv4="192.0.2.10",
            ipv6="2001:db8::10",
        )

    assert exc_info.value.operation == "create_host_with_addresses"
    assert exc_info.value.completed_steps == (MutationStep("create_host"),)
    assert exc_info.value.remaining_steps == (
        MutationStep("attach_secondary_address", detail="2001:db8::10"),
    )
    assert exc_info.value.status_code == 503
    client.close()
