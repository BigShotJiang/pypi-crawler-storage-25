import httpx
import pytest

from osp_uio_integrations.mreg import (
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ValidationError,
    ValidationSource,
)


def test_cname_add_can_refetch_after_empty_create_response() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/hosts/alias.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/cnames/alias.uio.no")) == 1:
                return httpx.Response(404, json={"detail": "missing"})
            return httpx.Response(200, json={"id": 7, "name": "alias.uio.no", "host": 10})
        if request.url.path == "/api/v1/zones/forward/hostname/alias.uio.no":
            return httpx.Response(200, json={"zone": {"name": "uio.no"}})
        if request.url.path == "/api/v1/cnames/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    cname = client.hosts.cnames.add("example.uio.no", "alias.uio.no")

    assert cname.name == "alias.uio.no"
    assert cname.host_id == 10
    client.close()


def test_cname_add_treats_missing_verify_as_request_failure() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/hosts/alias.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "GET":
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/zones/forward/hostname/alias.uio.no":
            return httpx.Response(200, json={"zone": {"name": "uio.no"}})
        if request.url.path == "/api/v1/cnames/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.cnames.add("example.uio.no", "alias.uio.no")

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/cnames/"
    client.close()


def test_cname_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/hosts/alias.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/cnames/alias.uio.no")) == 1:
                return httpx.Response(404, json={"detail": "missing"})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/zones/forward/hostname/alias.uio.no":
            return httpx.Response(200, json={"zone": {"name": "uio.no"}})
        if request.url.path == "/api/v1/cnames/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.cnames.add("example.uio.no", "alias.uio.no")

    assert exc_info.value.operation == "create_cname"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_cname_replace_can_refetch_after_empty_patch_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "GET":
            return httpx.Response(200, json={"id": 7, "name": "alias.uio.no", "host": 10})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    cname = client.hosts.cnames.replace("alias.uio.no", "example.uio.no")

    assert cname.name == "alias.uio.no"
    client.close()


def test_cname_remove_rejects_alias_when_it_is_a_real_host() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/hosts/alias.uio.no":
            return httpx.Response(200, json={"id": 11, "name": "alias.uio.no"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.cnames.remove("example.uio.no", "alias.uio.no")

    assert exc_info.value.source == ValidationSource.LOCAL
    client.close()


def test_cname_add_requires_forward_zone_for_alias() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/hosts/alias.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/cnames/alias.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/zones/forward/hostname/alias.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(NotFoundError) as exc_info:
        client.hosts.cnames.add("example.uio.no", "alias.uio.no")

    assert exc_info.value.method == "GET"
    assert exc_info.value.endpoint == "/api/v1/zones/forward/hostname/alias.uio.no"
    client.close()


def test_cname_replace_treats_missing_verify_as_request_failure() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/cnames/alias.uio.no")) == 1:
                return httpx.Response(200, json={"id": 7, "name": "alias.uio.no", "host": 10})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.cnames.replace("alias.uio.no", "example.uio.no")

    assert "failed replace" in str(exc_info.value)
    client.close()


def test_cname_replace_raises_uncertain_state_when_verify_fails_after_empty_patch() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/cnames/alias.uio.no")) == 1:
                return httpx.Response(200, json={"id": 7, "name": "alias.uio.no", "host": 10})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/cnames/alias.uio.no" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.cnames.replace("alias.uio.no", "example.uio.no")

    assert exc_info.value.operation == "replace_cname"
    assert exc_info.value.completed_steps == (MutationStep("replace_request"),)
    client.close()
