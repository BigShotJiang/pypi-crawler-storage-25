import httpx
import pytest

from osp_uio_integrations.mreg import (
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    RequestFailedError,
    ValidationError,
    ValidationSource,
)


def test_contact_set_uses_canonical_contacts_payload_and_normalizes_response() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.method == "PATCH":
            return httpx.Response(
                200,
                json={
                    "name": "example.uio.no",
                    "contacts": [{"email": "alice"}, {"email": "bob"}],
                    "ipaddresses": [{"ipaddress": "192.0.2.10"}],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.contacts.set("example.uio.no", ["alice", "bob", "alice"])

    assert host.siteadmins == ("alice", "bob")
    assert host.ipaddresses == ("192.0.2.10",)
    assert requests_seen == [
        ("PATCH", "/api/v1/hosts/example.uio.no", b'{"contacts":["alice","bob"]}'),
    ]
    client.close()


def test_contact_set_treats_missing_verify_as_request_failure() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PATCH" and request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, content=b"")
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(404, json={"detail": "missing"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.contacts.set("example.uio.no", ["alice"])

    assert exc_info.value.method == "PATCH"
    assert exc_info.value.endpoint == "/api/v1/hosts/example.uio.no"
    client.close()


def test_contact_set_raises_uncertain_state_when_refetch_fails_after_empty_patch() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PATCH" and request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, content=b"")
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.contacts.set("example.uio.no", ["alice"])

    assert exc_info.value.operation == "set_host_contacts"
    assert exc_info.value.completed_steps == (MutationStep("contact_request"),)
    client.close()


def test_contact_add_is_idempotent_when_contact_already_present() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET":
            return httpx.Response(
                200,
                json={"name": "example.uio.no", "contact": "alice"},
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.contacts.add("example.uio.no", ["alice"])

    assert host.siteadmins == ("alice",)
    assert requests_seen == [("GET", "/api/v1/hosts/example.uio.no")]
    client.close()


def test_contact_add_uses_atomic_contacts_endpoint_and_refetches_host() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no", b"")) == 1:
                return httpx.Response(
                    200,
                    json={"name": "example.uio.no", "contacts": [{"email": "alice"}]},
                )
            return httpx.Response(
                200,
                json={
                    "name": "example.uio.no",
                    "contacts": [{"email": "alice"}, {"email": "bob"}],
                },
            )
        if (
            request.method == "POST"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(200, json={"added": ["bob"]})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.contacts.add("example.uio.no", ["bob", "bob"])

    assert host.siteadmins == ("alice", "bob")
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", b""),
        ("POST", "/api/v1/hosts/example.uio.no/contacts/", b'{"emails":["bob"]}'),
        ("GET", "/api/v1/hosts/example.uio.no", b""),
    ]
    client.close()


def test_contact_add_treats_missing_verify_as_request_failure() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={"name": "example.uio.no", "contacts": [{"email": "alice"}]},
                )
            return httpx.Response(404, json={"detail": "missing"})
        if (
            request.method == "POST"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(200, json={"added": ["bob"]})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.contacts.add("example.uio.no", ["bob"])

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/hosts/example.uio.no/contacts/"
    client.close()


def test_contact_add_raises_uncertain_state_when_refetch_fails_after_write() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={"name": "example.uio.no", "contacts": [{"email": "alice"}]},
                )
            return httpx.Response(503, json={"detail": "boom"})
        if (
            request.method == "POST"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(200, json={"added": ["bob"]})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.contacts.add("example.uio.no", ["bob"])

    assert exc_info.value.operation == "add_host_contacts"
    assert exc_info.value.completed_steps == (MutationStep("contact_request"),)
    client.close()


def test_contact_remove_uses_atomic_contacts_endpoint_with_delete_body() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no", b"")) == 1:
                return httpx.Response(
                    200,
                    json={
                        "name": "example.uio.no",
                        "contacts": [{"email": "alice"}, {"email": "bob"}],
                    },
                )
            return httpx.Response(
                200,
                json={"name": "example.uio.no", "contacts": [{"email": "alice"}]},
            )
        if (
            request.method == "DELETE"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(200, json={"removed": ["bob"]})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.contacts.remove("example.uio.no", ["bob"])

    assert host.siteadmins == ("alice",)
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", b""),
        ("DELETE", "/api/v1/hosts/example.uio.no/contacts/", b'{"emails":["bob"]}'),
        ("GET", "/api/v1/hosts/example.uio.no", b""),
    ]
    client.close()


def test_contact_remove_treats_missing_verify_as_request_failure() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={
                        "name": "example.uio.no",
                        "contacts": [{"email": "alice"}, {"email": "bob"}],
                    },
                )
            return httpx.Response(404, json={"detail": "missing"})
        if (
            request.method == "DELETE"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(200, json={"removed": ["bob"]})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.contacts.remove("example.uio.no", ["bob"])

    assert exc_info.value.method == "DELETE"
    assert exc_info.value.endpoint == "/api/v1/hosts/example.uio.no/contacts/"
    client.close()


def test_contact_remove_raises_uncertain_state_when_refetch_fails_after_write() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={
                        "name": "example.uio.no",
                        "contacts": [{"email": "alice"}, {"email": "bob"}],
                    },
                )
            return httpx.Response(503, json={"detail": "boom"})
        if (
            request.method == "DELETE"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(200, json={"removed": ["bob"]})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.contacts.remove("example.uio.no", ["bob"])

    assert exc_info.value.operation == "remove_host_contacts"
    assert exc_info.value.completed_steps == (MutationStep("contact_request"),)
    client.close()


def test_contact_remove_rejects_empty_local_input() -> None:
    client = MregClient(base_url="https://mreg.example.test", token="token")

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.contacts.remove("example.uio.no", ["", " "])

    assert exc_info.value.source == "local"
    assert exc_info.value.method == "PATCH"
    client.close()


def test_contact_unset_clears_single_contact_without_force() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={"name": "example.uio.no", "contacts": [{"email": "alice"}]},
                )
            return httpx.Response(200, json={"name": "example.uio.no", "contacts": []})
        if (
            request.method == "DELETE"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.contacts.unset("example.uio.no")

    assert host.siteadmins == ()
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no"),
        ("DELETE", "/api/v1/hosts/example.uio.no/contacts/"),
        ("GET", "/api/v1/hosts/example.uio.no"),
    ]
    client.close()


def test_contact_unset_treats_missing_verify_as_request_failure() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={"name": "example.uio.no", "contacts": [{"email": "alice"}]},
                )
            return httpx.Response(404, json={"detail": "missing"})
        if (
            request.method == "DELETE"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.contacts.unset("example.uio.no")

    assert exc_info.value.method == "DELETE"
    assert exc_info.value.endpoint == "/api/v1/hosts/example.uio.no/contacts/"
    client.close()


def test_contact_unset_raises_uncertain_state_when_refetch_fails_after_write() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={"name": "example.uio.no", "contacts": [{"email": "alice"}]},
                )
            return httpx.Response(503, json={"detail": "boom"})
        if (
            request.method == "DELETE"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.contacts.unset("example.uio.no")

    assert exc_info.value.operation == "unset_host_contacts"
    assert exc_info.value.completed_steps == (MutationStep("contact_request"),)
    client.close()


def test_contact_unset_requires_force_when_multiple_contacts_present() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(
                200,
                json={
                    "name": "example.uio.no",
                    "contacts": [{"email": "alice"}, {"email": "bob"}],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.contacts.unset("example.uio.no")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "DELETE"
    client.close()


def test_contact_unset_clears_multiple_contacts_with_force() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.method == "GET" and request.url.path == "/api/v1/hosts/example.uio.no":
            if requests_seen.count(("GET", "/api/v1/hosts/example.uio.no")) == 1:
                return httpx.Response(
                    200,
                    json={
                        "name": "example.uio.no",
                        "contacts": [{"email": "alice"}, {"email": "bob"}],
                    },
                )
            return httpx.Response(200, json={"name": "example.uio.no", "contacts": []})
        if (
            request.method == "DELETE"
            and request.url.path == "/api/v1/hosts/example.uio.no/contacts/"
        ):
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.contacts.unset("example.uio.no", force=True)

    assert host.siteadmins == ()
    client.close()
