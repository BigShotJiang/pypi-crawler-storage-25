import httpx
import pytest

from osp_uio_integrations.mreg import (
    ConflictError,
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    RequestFailedError,
)


def test_loc_add_rejects_conflicting_existing_record() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/locs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={"results": [{"id": 8, "host": 10, "loc": "59 54 30 N 10 44 30 E"}]},
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ConflictError):
        client.hosts.records.loc.add("example.uio.no", "60 00 00 N 10 00 00 E")

    client.close()


def test_loc_add_raises_request_failed_when_verify_returns_404_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/locs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/locs/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/locs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.loc.add("example.uio.no", "59 54 30 N 10 44 30 E")

    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/locs/"
    client.close()


def test_loc_add_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/locs/" and request.method == "GET":
            if requests_seen.count(("GET", "/api/v1/locs/", "10")) == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/locs/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.loc.add("example.uio.no", "59 54 30 N 10 44 30 E")

    assert exc_info.value.operation == "create_loc_record"
    assert exc_info.value.completed_steps == (MutationStep("create_request"),)
    client.close()


def test_loc_remove_deletes_singleton_record() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.params.get("host", "")))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/locs/" and request.method == "GET":
            return httpx.Response(
                200,
                json={"results": [{"id": 8, "host": 10, "loc": "59 54 30 N 10 44 30 E"}]},
            )
        if request.url.path == "/api/v1/locs/8" and request.method == "DELETE":
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    client.hosts.records.loc.remove("example.uio.no")

    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no", ""),
        ("GET", "/api/v1/locs/", "10"),
        ("DELETE", "/api/v1/locs/8", ""),
    ]
    client.close()
