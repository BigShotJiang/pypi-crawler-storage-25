import httpx
import pytest

from osp_uio_integrations.mreg import (
    AddressFamily,
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
    ValidationSource,
)


def test_show_ipv4_and_ipv6_filter_host_addresses() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "id": 10,
                "name": "example.uio.no",
                "ipaddresses": [
                    {"id": 1, "ipaddress": "192.0.2.10", "macaddress": "aa:bb:cc:dd:ee:ff"},
                    {"id": 2, "ipaddress": "2001:db8::10"},
                ],
            },
        )

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    ipv4 = client.hosts.addressing.show_ipv4("example.uio.no")
    ipv6 = client.hosts.addressing.show_ipv6("example.uio.no")

    assert [record.ipaddress for record in ipv4] == ["192.0.2.10"]
    assert ipv4[0].family == AddressFamily.IPV4
    assert [record.ipaddress for record in ipv6] == ["2001:db8::10"]
    assert ipv6[0].family == AddressFamily.IPV6
    client.close()


def test_add_ipv4_can_resolve_first_unused_from_network() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no":
            if request.method == "GET":
                return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path in (
            "/api/v1/networks/192.0.2.0%2F24",
            "/api/v1/networks/192.0.2.0/24",
        ):
            return httpx.Response(200, json={"network": "192.0.2.0/24", "frozen": False})
        if request.url.path in (
            "/api/v1/networks/192.0.2.0%2F24/first_unused",
            "/api/v1/networks/192.0.2.0/24/first_unused",
        ):
            return httpx.Response(200, json="192.0.2.10")
        if request.url.path == "/api/v1/hosts/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        if request.url.path == "/api/v1/ipaddresses/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.addressing.add_ipv4("example.uio.no", "192.0.2.0/24")

    assert host.name == "example.uio.no"
    assert (
        "POST",
        "/api/v1/ipaddresses/",
        b'{"ipaddress":"192.0.2.10","host":"10"}',
    ) in requests_seen
    client.close()


def test_add_ipv6_requires_force_when_host_already_has_ipaddress() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "example.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/networks/ip/2001:db8::10":
            return httpx.Response(200, json={"network": "2001:db8::/64", "frozen": False})
        if request.url.path == "/api/v1/hosts/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.addressing.add_ipv6("example.uio.no", "2001:db8::10")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "POST"
    assert all(path != "/api/v1/ipaddresses/" for _, path, _ in requests_seen)
    client.close()


def test_add_ipv6_allows_dual_stack_host_with_force() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []
    host_reads = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal host_reads
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            host_reads += 1
            if host_reads == 1:
                return httpx.Response(
                    200,
                    json={
                        "id": 10,
                        "name": "example.uio.no",
                        "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                    },
                )
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "example.uio.no",
                    "ipaddresses": [
                        {"id": 4, "ipaddress": "192.0.2.10"},
                        {"id": 5, "ipaddress": "2001:db8::10"},
                    ],
                },
            )
        if request.url.path == "/api/v1/networks/ip/2001:db8::10":
            return httpx.Response(200, json={"network": "2001:db8::/64", "frozen": False})
        if request.url.path == "/api/v1/hosts/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        if request.url.path == "/api/v1/ipaddresses/" and request.method == "POST":
            return httpx.Response(201, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.addressing.add_ipv6("example.uio.no", "2001:db8::10", force=True)

    assert host.ipaddresses == ("192.0.2.10", "2001:db8::10")
    assert (
        "POST",
        "/api/v1/ipaddresses/",
        b'{"ipaddress":"2001:db8::10","host":"10"}',
    ) in requests_seen
    client.close()


def test_add_ipv4_rejects_frozen_network_without_force() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/networks/ip/192.0.2.10":
            return httpx.Response(200, json={"network": "192.0.2.0/24", "frozen": True})
        if request.url.path == "/api/v1/hosts/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.addressing.add_ipv4("example.uio.no", "192.0.2.10")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "POST"
    assert exc_info.value.endpoint == "/api/v1/ipaddresses/"
    assert (
        "POST",
        "/api/v1/ipaddresses/",
        b'{"ipaddress":"192.0.2.10","host":"10"}',
    ) not in requests_seen
    client.close()


def test_add_ipv4_rejects_broadcast_address_without_force() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path == "/api/v1/networks/ip/192.0.2.255":
            return httpx.Response(200, json={"network": "192.0.2.0/24", "frozen": False})
        if request.url.path == "/api/v1/hosts/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.addressing.add_ipv4("example.uio.no", "192.0.2.255")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "POST"
    assert (
        "POST",
        "/api/v1/ipaddresses/",
        b'{"ipaddress":"192.0.2.255","host":"10"}',
    ) not in requests_seen
    client.close()


def test_change_ipv4_patches_ipaddress_record() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "example.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/networks/ip/192.0.2.20":
            return httpx.Response(200, json={"network": "192.0.2.0/24", "frozen": False})
        if request.url.path == "/api/v1/hosts/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        if request.url.path == "/api/v1/ipaddresses/4" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.addressing.change_ipv4(
        "example.uio.no",
        old_ip="192.0.2.10",
        new_ip_or_network="192.0.2.20",
    )

    assert host.name == "example.uio.no"
    assert ("PATCH", "/api/v1/ipaddresses/4", b'{"ipaddress":"192.0.2.20"}') in requests_seen
    client.close()


def test_remove_ipv4_deletes_ipaddress_record() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "example.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/ipaddresses/4" and request.method == "DELETE":
            return httpx.Response(204, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.addressing.remove_ipv4("example.uio.no", "192.0.2.10", force=True)

    assert host.name == "example.uio.no"
    assert requests_seen == [
        ("GET", "/api/v1/hosts/example.uio.no"),
        ("DELETE", "/api/v1/ipaddresses/4"),
        ("GET", "/api/v1/hosts/example.uio.no"),
    ]
    client.close()


def test_remove_ipv4_requires_force_when_hostname_resolves_via_cname() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/alias.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "example.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.addressing.remove_ipv4("alias.uio.no", "192.0.2.10")

    assert exc_info.value.source == ValidationSource.LOCAL
    assert exc_info.value.method == "DELETE"
    assert exc_info.value.endpoint == "/api/v1/ipaddresses/192.0.2.10"
    client.close()


def test_remove_ipv4_allows_normalized_hostname_without_force() -> None:
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/Example.uio.no." and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "example.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/ipaddresses/4" and request.method == "DELETE":
            return httpx.Response(204, content=b"")
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "example.uio.no",
                    "ipaddresses": [],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.addressing.remove_ipv4("Example.uio.no.", "192.0.2.10")

    assert host.ipaddresses == ()
    assert requests_seen == [
        ("GET", "/api/v1/hosts/Example.uio.no."),
        ("DELETE", "/api/v1/ipaddresses/4"),
        ("GET", "/api/v1/hosts/example.uio.no"),
    ]
    client.close()


def test_remove_ipv4_raises_on_malformed_host_address_payload() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "example.uio.no",
                    "ipaddresses": [{"id": 4}],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ResponseDecodeError) as exc_info:
        client.hosts.addressing.remove_ipv4("example.uio.no", "192.0.2.10", force=True)

    assert exc_info.value.method == "GET"
    assert exc_info.value.endpoint == "/api/v1/hosts/example.uio.no"
    client.close()


def test_move_ipv4_moves_ip_and_ptr_override() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "source.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                    "ptr_overrides": [{"id": 8, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ipaddresses/4" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        if request.url.path == "/api/v1/ptroverrides/8" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    result = client.hosts.addressing.move_ipv4(
        "192.0.2.10",
        from_host="source.uio.no",
        to_host="dest.uio.no",
    )

    assert result.moved_ip is True
    assert result.moved_ptr_override is True
    assert ("PATCH", "/api/v1/ipaddresses/4", b'{"host":20}') in requests_seen
    assert ("PATCH", "/api/v1/ptroverrides/8", b'{"host":20}') in requests_seen
    client.close()


def test_move_ipv4_raises_uncertain_state_when_ptr_move_fails_after_ip_move() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "source.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                    "ptr_overrides": [{"id": 8, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ipaddresses/4" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        if request.url.path == "/api/v1/ptroverrides/8" and request.method == "PATCH":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.addressing.move_ipv4(
            "192.0.2.10",
            from_host="source.uio.no",
            to_host="dest.uio.no",
        )

    assert exc_info.value.operation == "move_address_and_ptr"
    assert exc_info.value.completed_steps == (MutationStep("move_ip"),)
    assert exc_info.value.remaining_steps == (MutationStep("move_ptr_override"),)
    client.close()


def test_move_ipv4_reraises_request_failure_when_ip_move_fails_first() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "source.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                    "ptr_overrides": [{"id": 8, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ipaddresses/4" and request.method == "PATCH":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.addressing.move_ipv4(
            "192.0.2.10",
            from_host="source.uio.no",
            to_host="dest.uio.no",
        )

    assert exc_info.value.endpoint == "/api/v1/ipaddresses/4"
    client.close()


def test_move_ipv4_moves_ptr_override_without_ipaddress_record() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "source.uio.no",
                    "ptr_overrides": [{"id": 8, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ptroverrides/8" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    result = client.hosts.addressing.move_ipv4(
        "192.0.2.10",
        from_host="source.uio.no",
        to_host="dest.uio.no",
    )

    assert result.moved_ip is False
    assert result.moved_ptr_override is True
    assert ("PATCH", "/api/v1/ptroverrides/8", b'{"host":20}') in requests_seen
    assert not any(path.startswith("/api/v1/ipaddresses/") for _, path, _ in requests_seen)
    client.close()


def test_move_ipv4_reraises_request_failure_when_ptr_only_move_fails_first() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "source.uio.no",
                    "ptr_overrides": [{"id": 8, "ipaddress": "192.0.2.10"}],
                },
            )
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ptroverrides/8" and request.method == "PATCH":
            return httpx.Response(503, json={"detail": "boom"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.addressing.move_ipv4(
            "192.0.2.10",
            from_host="source.uio.no",
            to_host="dest.uio.no",
        )

    assert exc_info.value.endpoint == "/api/v1/ptroverrides/8"
    client.close()


def test_move_ipv4_same_host_is_a_no_op() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(
                200,
                json={
                    "id": 10,
                    "name": "source.uio.no",
                    "ipaddresses": [{"id": 4, "ipaddress": "192.0.2.10"}],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    result = client.hosts.addressing.move_ipv4(
        "192.0.2.10",
        from_host="source.uio.no",
        to_host="source.uio.no",
    )

    assert result.moved_ip is False
    assert result.moved_ptr_override is False
    assert requests_seen == [
        ("GET", "/api/v1/hosts/source.uio.no", b""),
        ("GET", "/api/v1/hosts/source.uio.no", b""),
    ]
    client.close()


def test_add_ipv4_network_lookup_preserves_upstream_not_found_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(200, json={"id": 10, "name": "example.uio.no"})
        if request.url.path in (
            "/api/v1/networks/192.0.2.0%2F24",
            "/api/v1/networks/192.0.2.0/24",
        ):
            return httpx.Response(
                404,
                json={"detail": "missing"},
                headers={"X-Correlation-ID": "upstream-correlation"},
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(NotFoundError) as exc_info:
        client.hosts.addressing.add_ipv4("example.uio.no", "192.0.2.0/24")

    assert exc_info.value.endpoint in {
        "/api/v1/networks/192.0.2.0%2F24",
        "/api/v1/networks/192.0.2.0/24",
    }
    assert exc_info.value.correlation_id == "upstream-correlation"
    client.close()


def test_add_ipv4_treats_host_prefix_as_direct_address() -> None:
    """``/32`` and trailing ``/`` resolve to a fixed IP, not a network lookup."""
    requests_seen: list[tuple[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path))
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={"id": 7, "name": "example.uio.no"},
            )
        if request.url.path == "/api/v1/hosts/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        if request.url.path == "/api/v1/networks/ip/192.0.2.10":
            return httpx.Response(
                200,
                json={
                    "network": "192.0.2.0/24",
                    "frozen": False,
                    "broadcast_address": "192.0.2.255",
                    "network_address": "192.0.2.0",
                },
            )
        if request.url.path == "/api/v1/ipaddresses/" and request.method == "POST":
            return httpx.Response(
                201,
                json={"id": 99, "ipaddress": "192.0.2.10", "host": 7},
            )
        if request.url.path == "/api/v1/hosts/example.uio.no" and request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": 7,
                    "name": "example.uio.no",
                    "ipaddresses": [{"id": 99, "ipaddress": "192.0.2.10"}],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    client.hosts.addressing.add_ipv4("example.uio.no", "192.0.2.10/32")

    assert ("GET", "/api/v1/networks/ip/192.0.2.10") in requests_seen
    assert not any(
        path.startswith("/api/v1/networks/192.0.2.10/first_unused")
        for _, path in requests_seen
    )
    client.close()
