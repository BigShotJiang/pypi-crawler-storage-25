import httpx
import pytest

from osp_uio_integrations.mreg import (
    ConflictError,
    MregClient,
    MutationStateUncertainError,
    MutationStep,
    NotFoundError,
    RequestFailedError,
)


def test_ptr_move_rejects_destination_with_same_ip_ptr_record() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "source.uio.no"})
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            if request.url.params.get("host") == "10":
                return httpx.Response(
                    200,
                    json={"results": [{"id": 14, "host": 10, "ipaddress": "192.0.2.10"}]},
                )
            if request.url.params.get("host") == "20":
                return httpx.Response(
                    200,
                    json={"results": [{"id": 21, "host": 20, "ipaddress": "192.0.2.10"}]},
                )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ConflictError) as exc_info:
        client.hosts.records.ptr.move(
            "192.0.2.10",
            from_host="source.uio.no",
            to_host="dest.uio.no",
        )

    assert exc_info.value.method == "PATCH"
    client.close()


def test_ptr_move_rejects_destination_with_different_ptr_ip() -> None:
    requests_seen: list[tuple[str, str, bytes]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.content))
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "source.uio.no"})
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            if request.url.params.get("host") == "10":
                return httpx.Response(
                    200,
                    json={"results": [{"id": 14, "host": 10, "ipaddress": "192.0.2.10"}]},
                )
            if request.url.params.get("host") == "20":
                return httpx.Response(
                    200,
                    json={"results": [{"id": 21, "host": 20, "ipaddress": "192.0.2.20"}]},
                )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ConflictError) as exc_info:
        client.hosts.records.ptr.move(
            "192.0.2.10",
            from_host="source.uio.no",
            to_host="dest.uio.no",
        )

    assert exc_info.value.method == "PATCH"
    assert all(path != "/api/v1/ptroverrides/14" for _, path, _ in requests_seen)
    client.close()


def test_ptr_move_raises_when_source_ptr_override_is_missing() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "source.uio.no"})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            return httpx.Response(200, json={"results": []})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(NotFoundError) as exc_info:
        client.hosts.records.ptr.move(
            "192.0.2.10",
            from_host="source.uio.no",
            to_host="dest.uio.no",
        )

    assert exc_info.value.method == "PATCH"
    assert exc_info.value.endpoint == "/api/v1/ptroverrides/"
    client.close()


def test_ptr_move_raises_request_failed_when_verify_returns_404_after_empty_success() -> None:
    destination_reads = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal destination_reads
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "source.uio.no"})
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            if request.url.params.get("host") == "10":
                return httpx.Response(
                    200,
                    json={"results": [{"id": 14, "host": 10, "ipaddress": "192.0.2.10"}]},
                )
            destination_reads += 1
            if destination_reads == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(404, json={"detail": "missing"})
        if request.url.path == "/api/v1/ptroverrides/14" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.hosts.records.ptr.move(
            "192.0.2.10",
            from_host="source.uio.no",
            to_host="dest.uio.no",
        )

    assert exc_info.value.method == "PATCH"
    assert exc_info.value.endpoint == "/api/v1/ptroverrides/14"
    client.close()


def test_ptr_move_raises_uncertain_state_when_verify_request_fails_after_empty_success() -> None:
    destination_reads = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal destination_reads
        if request.url.path == "/api/v1/hosts/source.uio.no":
            return httpx.Response(200, json={"id": 10, "name": "source.uio.no"})
        if request.url.path == "/api/v1/hosts/dest.uio.no":
            return httpx.Response(200, json={"id": 20, "name": "dest.uio.no"})
        if request.url.path == "/api/v1/ptroverrides/" and request.method == "GET":
            if request.url.params.get("host") == "10":
                return httpx.Response(
                    200,
                    json={"results": [{"id": 14, "host": 10, "ipaddress": "192.0.2.10"}]},
                )
            destination_reads += 1
            if destination_reads == 1:
                return httpx.Response(200, json={"results": []})
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path == "/api/v1/ptroverrides/14" and request.method == "PATCH":
            return httpx.Response(200, content=b"")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(MutationStateUncertainError) as exc_info:
        client.hosts.records.ptr.move(
            "192.0.2.10",
            from_host="source.uio.no",
            to_host="dest.uio.no",
        )

    assert exc_info.value.operation == "move_ptr_override"
    assert exc_info.value.completed_steps == (MutationStep("move_request"),)
    client.close()
