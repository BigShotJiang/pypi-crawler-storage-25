from datetime import UTC, datetime

import httpx
import pytest

from osp_uio_integrations.mreg import MregClient, ResponseDecodeError


def test_host_history_fetches_related_entries_and_dedupes_by_id() -> None:
    requests_seen: list[dict[str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        params = dict(request.url.params)
        requests_seen.append(params)
        if params == {"resource": "host", "name": "example.uio.no"}:
            return httpx.Response(
                200,
                json=[
                    {
                        "id": 1,
                        "timestamp": "2026-04-20T10:00:00Z",
                        "user": "alice",
                        "resource": "host",
                        "name": "example.uio.no",
                        "model_id": 10,
                        "model": "Host",
                        "action": "create",
                        "data": '{"contact": "alice"}',
                    }
                ],
            )
        if params == {"resource": "host", "model_id__in": "10"}:
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 1,
                            "timestamp": "2026-04-20T10:00:00Z",
                            "user": "alice",
                            "resource": "host",
                            "name": "example.uio.no",
                            "model_id": 10,
                            "model": "Host",
                            "action": "create",
                            "data": {"contact": "alice"},
                        },
                        {
                            "id": 2,
                            "timestamp": "2026-04-20T11:00:00Z",
                            "user": "bob",
                            "resource": "host",
                            "name": "example.uio.no",
                            "model_id": 10,
                            "model": "Host",
                            "action": "update",
                            "data": {"update": {"contact": "alice,bob"}},
                        },
                    ]
                },
            )
        if params == {"data__relation": "hosts", "data__id__in": "10"}:
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 3,
                            "timestamp": "2026-04-20T12:00:00+00:00",
                            "user": "carol",
                            "resource": "host",
                            "name": "example.uio.no",
                            "model_id": 10,
                            "model": "CNAME",
                            "action": "add",
                            "data": {"relation": "hosts", "id": 10, "name": "alias.uio.no"},
                        }
                    ]
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    history = client.hosts.history.many("example.uio.no")

    assert [entry.id for entry in history] == [1, 2, 3]
    assert history[0].timestamp == datetime(2026, 4, 20, 10, 0, tzinfo=UTC)
    assert history[0].data == {"contact": "alice"}
    assert history[2].action == "add"
    assert requests_seen == [
        {"resource": "host", "name": "example.uio.no"},
        {"resource": "host", "model_id__in": "10"},
        {"data__relation": "hosts", "data__id__in": "10"},
    ]
    client.close()


def test_host_history_returns_empty_list_when_history_is_missing() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert dict(request.url.params) == {"resource": "host", "name": "missing.uio.no"}
        return httpx.Response(200, json={"results": []})

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    assert client.hosts.history.many("missing.uio.no") == []

    client.close()


def test_host_history_rejects_invalid_json_data_shape() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json=[
                {
                    "id": 1,
                    "timestamp": "2026-04-20T10:00:00Z",
                    "user": "alice",
                    "resource": "host",
                    "name": "example.uio.no",
                    "model_id": 10,
                    "model": "Host",
                    "action": "create",
                    "data": '["not", "a", "dict"]',
                }
            ],
        )

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ResponseDecodeError):
        client.hosts.history.many("example.uio.no")

    client.close()


def test_host_history_sorts_timestamp_ties_by_entry_id() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        params = dict(request.url.params)
        if params == {"resource": "host", "name": "example.uio.no"}:
            return httpx.Response(
                200,
                json=[
                    {
                        "id": 3,
                        "timestamp": "2026-04-20T10:00:00Z",
                        "user": "alice",
                        "resource": "host",
                        "name": "example.uio.no",
                        "model_id": 10,
                        "model": "Host",
                        "action": "create",
                        "data": {"contact": "alice"},
                    }
                ],
            )
        if params == {"resource": "host", "model_id__in": "10"}:
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 2,
                            "timestamp": "2026-04-20T10:00:00Z",
                            "user": "bob",
                            "resource": "host",
                            "name": "example.uio.no",
                            "model_id": 10,
                            "model": "Host",
                            "action": "update",
                            "data": {"contact": "alice,bob"},
                        }
                    ]
                },
            )
        if params == {"data__relation": "hosts", "data__id__in": "10"}:
            return httpx.Response(
                200,
                json={
                    "results": [
                        {
                            "id": 1,
                            "timestamp": "2026-04-20T10:00:00Z",
                            "user": "carol",
                            "resource": "host",
                            "name": "example.uio.no",
                            "model_id": 10,
                            "model": "CNAME",
                            "action": "add",
                            "data": {"relation": "hosts", "id": 10, "name": "alias.uio.no"},
                        }
                    ]
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    history = client.hosts.history.many("example.uio.no")

    assert [entry.id for entry in history] == [1, 2, 3]
    client.close()
