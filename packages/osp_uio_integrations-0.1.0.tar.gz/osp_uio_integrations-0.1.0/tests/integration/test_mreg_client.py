import httpx
import pytest

from osp_uio_integrations.mreg import (
    AuthenticationRequiredError,
    CompatibilityFallback,
    MregClient,
    RequestFailedError,
    ResponseDecodeError,
    ValidationError,
)
from osp_uio_integrations.mreg.auth import Credentials, MemoryTokenStore


def test_public_export_is_available() -> None:
    client = MregClient(base_url="https://mreg.example.test", token="token")
    assert client.base_url == "https://mreg.example.test"
    client.close()


def test_host_lookup_logs_in_and_normalizes_shape() -> None:
    correlation_ids: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["User-Agent"] == "osp-uio-integrations/0.1.0 mreg-client"
        correlation_ids.append(request.headers["X-Correlation-ID"])
        if request.url.path == "/api/token-auth/":
            assert request.method == "POST"
            assert request.content == b"username=alice&password=secret"
            return httpx.Response(200, json={"token": "fresh-token"})
        if request.url.path == "/api/v1/hosts/example.uio.no":
            assert request.headers["Authorization"] == "Token fresh-token"
            return httpx.Response(
                200,
                json={
                    "name": "example.uio.no",
                    "contact": "alice,bob",
                    "ipaddresses": [
                        {"ipaddress": "192.0.2.10"},
                        {"ipaddress": "192.0.2.10"},
                    ],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        username="alice",
        password="secret",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.queries.get("example.uio.no")

    assert host is not None
    assert host.name == "example.uio.no"
    assert host.siteadmins == ("alice", "bob")
    assert host.ipaddresses == ("192.0.2.10",)
    assert len(correlation_ids) == 2
    assert correlation_ids[0] == correlation_ids[1]
    client.close()


def test_get_host_by_name_returns_orchestrator_style_mapping() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/hosts/example.uio.no"
        return httpx.Response(
            200,
            json={
                "name": "example.uio.no",
                "contact": "alice,bob",
                "ipaddresses": [
                    {"ipaddress": "192.0.2.10"},
                    {"ipaddress": "2001:db8::10"},
                ],
            },
        )

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.get_host_by_name("example.uio.no")

    assert host == {
        "hostname": "example.uio.no",
        "siteadmins": ["alice", "bob"],
        "ipaddresses": ["192.0.2.10", "2001:db8::10"],
    }
    client.close()


def test_get_host_record_by_name_keeps_typed_path() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"name": "example.uio.no", "contact": "alice"})

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.get_host_record_by_name("example.uio.no")

    assert host is not None
    assert host.name == "example.uio.no"
    assert host.to_dict() == {
        "hostname": "example.uio.no",
        "siteadmins": ["alice"],
        "ipaddresses": [],
    }
    client.close()


def test_list_hosts_returns_normalized_host_mappings() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/hosts/"
        assert request.url.query == b"contact=alice"
        return httpx.Response(
            200,
            json={
                "count": 2,
                "next": None,
                "results": [
                    {
                        "name": "a.uio.no",
                        "contact": "alice",
                        "ipaddresses": [{"ipaddress": "192.0.2.10"}],
                    },
                    {
                        "hostname": "b.uio.no",
                        "contact": "alice,bob",
                        "ipaddresses": [{"ipaddress": "192.0.2.11"}],
                    },
                ],
            },
        )

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    hosts = client.list_hosts(params={"contact": "alice"})

    assert hosts == [
        {
            "hostname": "a.uio.no",
            "siteadmins": ["alice"],
            "ipaddresses": ["192.0.2.10"],
        },
        {
            "hostname": "b.uio.no",
            "siteadmins": ["alice", "bob"],
            "ipaddresses": ["192.0.2.11"],
        },
    ]
    client.close()


def test_host_exists_uses_host_lookup_boundary() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/present.uio.no"):
            return httpx.Response(200, json={"name": "present.uio.no"})
        return httpx.Response(404, json={"detail": "missing"})

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    assert client.host_exists("present.uio.no") is True
    assert client.host_exists("missing.uio.no") is False
    client.close()


def test_missing_credentials_raise_without_interactive_prompt() -> None:
    client = MregClient(base_url="https://mreg.example.test")

    with pytest.raises(AuthenticationRequiredError) as exc_info:
        client.hosts.queries.get("example.uio.no")

    assert exc_info.value.correlation_id is not None
    client.close()


def test_interactive_prompt_can_supply_credentials() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/token-auth/":
            return httpx.Response(200, json={"token": "prompted-token"})
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(200, json={"hostname": "example.uio.no", "contact": "alice"})
        raise AssertionError(f"Unexpected request to {request.url}")

    def prompt(*, base_url: str, username: str | None) -> Credentials:
        assert base_url == "https://mreg.example.test"
        assert username is None
        return Credentials(username="alice", password="secret")

    client = MregClient(
        base_url="https://mreg.example.test",
        interactive=True,
        credential_prompt=prompt,
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.queries.get("example.uio.no")

    assert host is not None
    assert host.siteadmins == ("alice",)
    client.close()


def test_stale_token_triggers_one_login_retry() -> None:
    requests_seen: list[tuple[str, str, str | None, str | None]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        auth_header = request.headers.get("Authorization")
        correlation_id = request.headers.get("X-Correlation-ID")
        requests_seen.append((request.method, request.url.path, auth_header, correlation_id))
        if (
            request.url.path == "/api/v1/hosts/example.uio.no"
            and auth_header == "Token stale-token"
        ):
            return httpx.Response(401, json={"detail": "expired"})
        if request.url.path == "/api/token-auth/":
            return httpx.Response(200, json={"token": "fresh-token"})
        if (
            request.url.path == "/api/v1/hosts/example.uio.no"
            and auth_header == "Token fresh-token"
        ):
            return httpx.Response(200, json={"name": "example.uio.no"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        username="alice",
        password="secret",
        token_store=MemoryTokenStore({("https://mreg.example.test", "alice"): "stale-token"}),
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.queries.get("example.uio.no")

    assert host is not None
    assert requests_seen == [
        (
            "GET",
            "/api/v1/hosts/example.uio.no",
            "Token stale-token",
            requests_seen[0][3],
        ),
        (
            "POST",
            "/api/token-auth/",
            None,
            requests_seen[0][3],
        ),
        (
            "GET",
            "/api/v1/hosts/example.uio.no",
            "Token fresh-token",
            requests_seen[0][3],
        ),
    ]
    client.close()


def test_fresh_login_401_does_not_retry_login_again() -> None:
    requests_seen: list[tuple[str, str, str | None]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        auth_header = request.headers.get("Authorization")
        requests_seen.append((request.method, request.url.path, auth_header))
        if request.url.path == "/api/token-auth/":
            return httpx.Response(200, json={"token": "fresh-token"})
        if request.url.path == "/api/v1/hosts/example.uio.no":
            return httpx.Response(401, json={"detail": "still unauthorized"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        username="alice",
        password="secret",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(AuthenticationRequiredError) as exc_info:
        client.hosts.queries.get("example.uio.no")

    assert exc_info.value.method == "GET"
    assert requests_seen == [
        ("POST", "/api/token-auth/", None),
        ("GET", "/api/v1/hosts/example.uio.no", "Token fresh-token"),
    ]
    client.close()


def test_explicit_correlation_id_is_forwarded() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["X-Correlation-ID"] == "corr-123"
        return httpx.Response(200, json={"name": "example.uio.no"})

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.queries.get("example.uio.no", correlation_id="corr-123")

    assert host is not None
    client.close()


def test_remote_validation_error_exposes_metadata() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            422,
            json={"detail": "bad request"},
            headers={
                "X-Request-Id": "req-1",
                "X-Correlation-ID": "corr-1",
            },
        )

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ValidationError) as exc_info:
        client.hosts.queries.get("example.uio.no")

    assert exc_info.value.source == "remote"
    assert exc_info.value.method == "GET"
    assert exc_info.value.endpoint == "/api/v1/hosts/example.uio.no"
    assert exc_info.value.request_id == "req-1"
    assert exc_info.value.correlation_id == "corr-1"
    client.close()


def test_decode_error_for_missing_host_name_in_payload() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"contact": "alice"})

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ResponseDecodeError) as exc_info:
        client.hosts.queries.get("example.uio.no")

    assert exc_info.value.method == "GET"
    assert exc_info.value.endpoint == "/api/v1/hosts/example.uio.no"
    client.close()


def test_patch_json_can_retry_as_form_when_explicitly_enabled() -> None:
    contents: list[bytes] = []

    def handler(request: httpx.Request) -> httpx.Response:
        contents.append(request.content)
        if request.content == b'{"contact":"alice"}':
            return httpx.Response(500, json={"detail": "legacy server"})
        if request.content == b"contact=alice":
            return httpx.Response(200, json={"name": "example.uio.no", "contact": "alice"})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    payload = client.patch_json(
        "/api/v1/hosts/example.uio.no",
        json={"contact": "alice"},
        compatibility_fallback=CompatibilityFallback.FORM,
    )

    assert payload == {"name": "example.uio.no", "contact": "alice"}
    assert contents == [b'{"contact":"alice"}', b"contact=alice"]
    client.close()


def test_patch_json_does_not_retry_as_form_for_non_500_server_failures() -> None:
    contents: list[bytes] = []

    def handler(request: httpx.Request) -> httpx.Response:
        contents.append(request.content)
        return httpx.Response(503, json={"detail": "service unavailable"})

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.patch_json(
            "/api/v1/hosts/example.uio.no",
            json={"contact": "alice"},
            compatibility_fallback=CompatibilityFallback.FORM,
        )

    assert exc_info.value.status_code == 503
    assert contents == [b'{"contact":"alice"}']
    client.close()


def test_patch_json_wraps_network_errors_during_form_retry() -> None:
    contents: list[bytes] = []

    def handler(request: httpx.Request) -> httpx.Response:
        contents.append(request.content)
        if request.content == b'{"contact":"alice"}':
            return httpx.Response(500, json={"detail": "legacy server"})
        if request.content == b"contact=alice":
            raise httpx.ConnectError("retry failed", request=request)
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(RequestFailedError) as exc_info:
        client.patch_json(
            "/api/v1/hosts/example.uio.no",
            json={"contact": "alice"},
            compatibility_fallback=CompatibilityFallback.FORM,
        )

    assert exc_info.value.method == "PATCH"
    assert exc_info.value.endpoint == "/api/v1/hosts/example.uio.no"
    assert exc_info.value.correlation_id is not None
    assert contents == [b'{"contact":"alice"}', b"contact=alice"]
    client.close()


def test_get_json_soft_404_returns_none() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, json={"detail": "missing"})

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    payload = client.get_json("/api/v1/missing", soft_404=True)

    assert payload is None
    client.close()


def test_get_json_204_without_allow_empty_raises_explicit_empty_response_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(204, content=b"")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ResponseDecodeError) as exc_info:
        client.get_json("/api/v1/hosts/example.uio.no")

    assert "204 No Content" in str(exc_info.value)
    client.close()


def test_get_json_str_rejects_non_string_json_values() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=123)

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    with pytest.raises(ResponseDecodeError) as exc_info:
        client.get_json_str("/api/v1/networks/example/first_unused")

    assert exc_info.value.method == "GET"
    assert exc_info.value.endpoint == "/api/v1/networks/example/first_unused"
    client.close()


def test_host_lookup_reads_canonical_contacts_field() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "name": "example.uio.no",
                "contacts": [{"email": "alice"}, {"email": "bob"}, {"email": "alice"}],
            },
        )

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    host = client.hosts.queries.get("example.uio.no")

    assert host is not None
    assert host.contact == "alice,bob"
    assert host.siteadmins == ("alice", "bob")
    client.close()
