import httpx

from osp_uio_integrations.mreg import AddressFamily, MregClient


def test_paginated_host_listing_follows_next_links() -> None:
    requests_seen: list[tuple[str, str, str]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests_seen.append((request.method, request.url.path, request.url.query.decode()))
        if request.url.path == "/api/v1/hosts/" and request.url.query == b"contact=alice":
            return httpx.Response(
                200,
                json={
                    "results": [{"name": "a.uio.no"}],
                    "next": "https://mreg.example.test/api/v1/hosts/?page=2&contact=alice",
                },
            )
        if request.url.path == "/api/v1/hosts/" and request.url.query == b"page=2&contact=alice":
            return httpx.Response(
                200,
                json={
                    "results": [{"name": "b.uio.no"}],
                    "next": None,
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    hosts = client.hosts.queries.many(params={"contact": "alice"})

    assert [host.name for host in hosts] == ["a.uio.no", "b.uio.no"]
    assert requests_seen == [
        ("GET", "/api/v1/hosts/", "contact=alice"),
        ("GET", "/api/v1/hosts/", "page=2&contact=alice"),
    ]
    client.close()


def test_network_listing_is_paginated_and_normalized() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/networks/" and request.url.query == b"vlan=120":
            return httpx.Response(
                200,
                json={
                    "results": [{"network": "192.0.2.0/24", "gateway": "192.0.2.1"}],
                    "next": "/api/v1/networks/?vlan=120&page=2",
                },
            )
        if request.url.path == "/api/v1/networks/" and request.url.query == b"vlan=120&page=2":
            return httpx.Response(
                200,
                json={"results": [{"network": "2001:db8::/64", "vlan": 120}], "next": None},
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    networks = client.networks.many(params={"vlan": 120})

    assert [network.network for network in networks] == ["192.0.2.0/24", "2001:db8::/64"]
    assert networks[0].gateway == "192.0.2.1"
    assert networks[1].family == AddressFamily.IPV6
    client.close()


def test_network_pick_unused_in_vlan_prefers_largest_matching_network() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/networks/" and request.url.query == b"vlan=120":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {"network": "192.0.2.0/25", "vlan": 120},
                        {"network": "192.0.2.128/25", "vlan": 120},
                        {"network": "198.51.100.0/24", "vlan": 120},
                    ],
                    "next": None,
                },
            )
        if request.url.path in {
            "/api/v1/networks/198.51.100.0%2F24/random_unused",
            "/api/v1/networks/198.51.100.0/24/random_unused",
        }:
            return httpx.Response(200, json="198.51.100.99")
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    candidate = client.networks.pick_unused_in_vlan(120, family=4)

    assert candidate is not None
    network, ipaddress_value = candidate
    assert network.network == "198.51.100.0/24"
    assert ipaddress_value == "198.51.100.99"
    client.close()


def test_network_last_unused_can_resolve_hostnames_from_used_host_list() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path in {"/api/v1/networks/192.0.2.0%2F29", "/api/v1/networks/192.0.2.0/29"}:
            return httpx.Response(200, json={"network": "192.0.2.0/29"})
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F29/used_host_list",
            "/api/v1/networks/192.0.2.0/29/used_host_list",
        }:
            return httpx.Response(200, json=["a.uio.no", "b.uio.no", "192.0.2.5"])
        if request.url.path == "/api/v1/hosts/a.uio.no":
            return httpx.Response(200, json={"name": "a.uio.no", "ipaddresses": ["192.0.2.1"]})
        if request.url.path == "/api/v1/hosts/b.uio.no":
            return httpx.Response(200, json={"name": "b.uio.no", "ipaddresses": ["192.0.2.2"]})
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    assert (
        client.networks.pick_unused_in_network("192.0.2.0/29", address_pick="last")
        == "192.0.2.6"
    )
    client.close()


def test_network_last_unused_resolves_hostnames_even_when_some_ips_are_literal() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path in {"/api/v1/networks/192.0.2.0%2F29", "/api/v1/networks/192.0.2.0/29"}:
            return httpx.Response(200, json={"network": "192.0.2.0/29"})
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F29/used_host_list",
            "/api/v1/networks/192.0.2.0/29/used_host_list",
        }:
            return httpx.Response(200, json=["192.0.2.1", "last-host.uio.no"])
        if request.url.path == "/api/v1/hosts/last-host.uio.no":
            return httpx.Response(
                200,
                json={"name": "last-host.uio.no", "ipaddresses": ["192.0.2.6"]},
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    assert (
        client.networks.pick_unused_in_network("192.0.2.0/29", address_pick="last")
        == "192.0.2.5"
    )
    client.close()


def test_used_host_list_supports_mapping_payloads() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F29/used_host_list",
            "/api/v1/networks/192.0.2.0/29/used_host_list",
        }:
            return httpx.Response(
                200,
                json={
                    "192.0.2.1": ["a.uio.no"],
                    "192.0.2.6": ["last-host.uio.no"],
                },
            )
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    assert client.networks.used_host_list("192.0.2.0/29") == ("192.0.2.1", "192.0.2.6")
    client.close()


def test_vlan_fullness_ipv4_uses_used_host_list_before_unused_list() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v1/networks/" and request.url.query == b"vlan=120":
            return httpx.Response(
                200,
                json={
                    "results": [
                        {"network": "192.0.2.0/30", "vlan": 120},
                        {"network": "192.0.2.4/30", "vlan": 120},
                    ],
                    "next": None,
                },
            )
        if request.url.path in {
            "/api/v1/networks/192.0.2.0%2F30/used_host_list",
            "/api/v1/networks/192.0.2.0/30/used_host_list",
        }:
            return httpx.Response(200, json=["192.0.2.1"])
        if request.url.path in {
            "/api/v1/networks/192.0.2.4%2F30/used_host_list",
            "/api/v1/networks/192.0.2.4/30/used_host_list",
        }:
            return httpx.Response(503, json={"detail": "boom"})
        if request.url.path in {
            "/api/v1/networks/192.0.2.4%2F30/unused_list",
            "/api/v1/networks/192.0.2.4/30/unused_list",
        }:
            return httpx.Response(200, json=["192.0.2.5", "192.0.2.6"])
        raise AssertionError(f"Unexpected request to {request.url}")

    client = MregClient(
        base_url="https://mreg.example.test",
        token="token",
        transport=httpx.MockTransport(handler),
    )

    usage = client.networks.vlan_fullness_ipv4(120)

    assert usage.vlan == 120
    assert usage.capacity == 4
    assert usage.used == 1
    assert usage.unused == 3
    assert [network.cidr for network in usage.networks] == ["192.0.2.0/30", "192.0.2.4/30"]
    client.close()
