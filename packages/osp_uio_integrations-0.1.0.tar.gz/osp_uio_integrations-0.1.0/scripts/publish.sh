#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

export PYTHON_KEYRING_BACKEND=keyring.backends.null.Keyring

PUSH_TAG=0
TWINE_ARGS=()

while [[ $# -gt 0 ]]; do
  case "$1" in
    --tag)
      PUSH_TAG=1
      shift
      ;;
    *)
      TWINE_ARGS+=("$1")
      shift
      ;;
  esac
done

VERSION="$(
python - <<'PY'
from pathlib import Path
import tomllib

data = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
print(data["project"]["version"])
PY
)"

DIST_DIR="${ROOT_DIR}/dist"
WHL_FILE="${DIST_DIR}/osp_uio_integrations-${VERSION}-py3-none-any.whl"
SDIST_FILE="${DIST_DIR}/osp_uio_integrations-${VERSION}.tar.gz"
TAG_NAME="v${VERSION}"
RELEASE_NOTES_FILE="${ROOT_DIR}/docs/release-notes-${VERSION}.md"

echo "Publishing osp-uio-integrations version ${VERSION}"
if [[ "${PUSH_TAG}" -eq 1 ]]; then
  if [[ -n "$(git status --porcelain)" ]]; then
    echo "Refusing --tag with a dirty worktree." >&2
    exit 1
  fi
  if git rev-parse -q --verify "refs/tags/${TAG_NAME}" >/dev/null; then
    echo "Tag ${TAG_NAME} already exists." >&2
    exit 1
  fi
  if [[ ! -f "${RELEASE_NOTES_FILE}" ]]; then
    echo "Missing release notes file: ${RELEASE_NOTES_FILE}" >&2
    exit 1
  fi
fi

rm -rf "${DIST_DIR}"
python -m build

ARTIFACTS=(
  "${WHL_FILE}"
  "${SDIST_FILE}"
)

for artifact in "${ARTIFACTS[@]}"; do
  if [[ ! -f "${artifact}" ]]; then
    echo "Missing expected artifact: ${artifact}" >&2
    exit 1
  fi
done

UNEXPECTED_COUNT="$(find "${DIST_DIR}" -maxdepth 1 -type f | wc -l | tr -d ' ')"
if [[ "${UNEXPECTED_COUNT}" -ne 2 ]]; then
  echo "Unexpected files in ${DIST_DIR}. Refusing to publish." >&2
  find "${DIST_DIR}" -maxdepth 1 -type f -print >&2
  exit 1
fi

twine check "${ARTIFACTS[@]}"
twine upload "${TWINE_ARGS[@]}" "${ARTIFACTS[@]}"

if [[ "${PUSH_TAG}" -eq 1 ]]; then
  bash "${ROOT_DIR}/scripts/tag-release.sh" --push
fi

rm -rf "${DIST_DIR}"
echo "Publish complete. Removed ${DIST_DIR}."
