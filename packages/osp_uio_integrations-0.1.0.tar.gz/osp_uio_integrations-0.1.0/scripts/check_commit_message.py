#!/usr/bin/env python3
r"""Reject commit messages that contain literal ``\n`` escapes."""

from __future__ import annotations

import sys
from pathlib import Path


def main() -> int:
    r"""Validate one commit message file and fail on literal ``\n`` escapes."""
    if len(sys.argv) != 2:
        print("usage: check_commit_message.py <commit-msg-file>", file=sys.stderr)
        return 2

    message = Path(sys.argv[1]).read_text(encoding="utf-8", errors="replace")
    if "\\n" not in message:
        return 0

    print("commit message contains literal '\\n' escape sequences.", file=sys.stderr)
    print("use real newlines instead. for shell commits, prefer:", file=sys.stderr)
    print("", file=sys.stderr)
    print("  git commit -F - <<'EOF'", file=sys.stderr)
    print("  <subject>", file=sys.stderr)
    print("", file=sys.stderr)
    print("  <body>", file=sys.stderr)
    print("  EOF", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
