#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

PUSH_TAG=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --push)
      PUSH_TAG=1
      shift
      ;;
    *)
      echo "Unknown argument: $1" >&2
      exit 1
      ;;
  esac
done

VERSION="$(
python - <<'PY'
from pathlib import Path
import tomllib

data = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
print(data["project"]["version"])
PY
)"

TAG_NAME="v${VERSION}"
RELEASE_NOTES_FILE="${ROOT_DIR}/docs/release-notes-${VERSION}.md"

if [[ -n "$(git status --porcelain)" ]]; then
  echo "Refusing to tag with a dirty worktree." >&2
  exit 1
fi

if [[ ! -f "${RELEASE_NOTES_FILE}" ]]; then
  echo "Missing release notes file: ${RELEASE_NOTES_FILE}" >&2
  exit 1
fi

if git rev-parse -q --verify "refs/tags/${TAG_NAME}" >/dev/null; then
  echo "Tag ${TAG_NAME} already exists." >&2
  exit 1
fi

git tag -a "${TAG_NAME}" -F "${RELEASE_NOTES_FILE}"

if [[ "${PUSH_TAG}" -eq 1 ]]; then
  git push origin "${TAG_NAME}"
fi

echo "Created ${TAG_NAME} from ${RELEASE_NOTES_FILE}"
