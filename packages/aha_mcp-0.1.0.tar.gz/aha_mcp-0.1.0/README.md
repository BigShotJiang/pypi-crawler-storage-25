# AHA! MCP Server

[![GitHub](https://img.shields.io/badge/GitHub-Repository-blue)](https://github.com/DLTKFrancescoCarbone/aha_mcp)

A Model Context Protocol (MCP) server for interacting with the AHA! product management platform. This server provides tools for searching, retrieving, creating, and editing ideas, features, epics, releases, and initiatives in AHA!.

## Repository

**GitHub**: https://github.com/DLTKFrancescoCarbone/aha_mcp

## Features

- **Search Ideas**: Search and filter ideas by name, product, release, epic, initiative, status, and more (with automatic name resolution)
- **Get Idea**: Retrieve detailed information about a specific idea
- **Create Idea**: Create new ideas in AHA!
- **Update Idea**: Modify existing ideas
- **Search Features**: Search and filter features by name, product, release, epic, status, and more
- **Get Feature**: Retrieve detailed information about a specific feature
- **Create Feature**: Create new features in AHA! (requires a release)
- **Update Feature**: Modify existing features

## Installation

**If you only want to run the server** (not develop in this repo), use **[RUNNING.md](RUNNING.md)** — it covers `pipx`, `pip install`, and the npm CLI in one place.

### Developers / clone of this repo

1. Install Python dependencies (editable install includes the `aha-mcp` CLI):

```bash
pip install -e .
```

Or without the CLI entry point:

```bash
pip install -r requirements.txt
```

2. Set up your AHA! API credentials. You can either:

   **Option A: Use a .env file (Recommended)**
   ```bash
   cp env.example .env
   # Then edit .env and fill in your values
   ```

   **Option B: Set environment variables directly**
   ```bash
   export AHA_ACCOUNT_DOMAIN="your-account-domain"  # e.g., "company" for company.aha.io
   export AHA_API_KEY="your-api-key"
   ```

### Option C: NPM package (Node.js)

If you use Node.js 18+, you can install the published package and run the MCP entrypoint without a local git clone:

```bash
npm install -g aha-mcp
python -m pip install "$(npm root -g)/aha-mcp"
```

On Windows PowerShell use ``python -m pip install (Join-Path (npm root -g) aha-mcp)``. That installs the **Python** dependencies and the `aha_mcp` package from the folder npm placed on disk.

The CLI runs `python -m aha_mcp` with stdio inherited. Set `AHA_ACCOUNT_DOMAIN` and `AHA_API_KEY` in your MCP client `env` (recommended); a `.env` file can live next to the `aha_mcp` package inside `node_modules/aha-mcp/` but using `env` in the client is simpler.

**Cursor / Claude example:**

```json
{
  "mcpServers": {
    "aha": {
      "command": "aha-mcp",
      "args": [],
      "env": {
        "AHA_ACCOUNT_DOMAIN": "your-account-domain",
        "AHA_API_KEY": "your-api-key"
      }
    }
  }
}
```

Use `npx aha-mcp` as the command if you prefer not to install globally (still install Python deps once with `pip install -r` against the package path, or run `pip install mcp httpx python-dotenv`). Override the Python executable with `PYTHON` if needed (for example `C:\\Python312\\python.exe` on Windows).

## Configuration

The server uses environment variables for configuration. You can set them either via a `.env` file or as system environment variables:

- `AHA_ACCOUNT_DOMAIN`: Your AHA! account domain (without .aha.io)
- `AHA_API_KEY`: Your AHA! API key (required)

### Using .env file

1. Copy `env.example` to `.env`:
   ```bash
   cp env.example .env
   ```

2. Edit `.env` and fill in your values:
   ```env
   AHA_ACCOUNT_DOMAIN=your-account-domain
   AHA_API_KEY=your-api-key-here
   ```

The server will automatically load variables from the `.env` file if it exists.

### Getting Your API Key

1. Log in to your AHA! account
2. Go to Settings → Account → API
3. Generate a new API key or use an existing one

## Usage

### Running the Server

The server uses stdio for communication, which is the standard for MCP servers. You typically don't run it directly - your MCP client will start it automatically.

For testing purposes, you can run:
```bash
aha-mcp
```
or from the repo: `python server.py` (shim) or `python -m aha_mcp`.

### MCP Client Configuration

To use this server with an MCP client, you need to configure it in your client's settings. See **[CLIENT_SETUP.md](CLIENT_SETUP.md)** for detailed instructions for:

- **Cursor IDE** - Step-by-step configuration
- **Claude Desktop** - Configuration guide
- **VS Code** - MCP extension setup
- **Generic MCP clients** - General configuration pattern

**Quick Example (Cursor)** — after `pipx install aha-mcp` or `pip install -e .` so `aha-mcp` is on PATH:

```json
{
  "mcpServers": {
    "aha": {
      "command": "aha-mcp",
      "args": [],
      "env": {
        "AHA_ACCOUNT_DOMAIN": "your-account-domain",
        "AHA_API_KEY": "your-api-key"
      }
    }
  }
}
```

**Note:** Restart your client after configuration. To run from a clone without installing the CLI, you can still use `"command": "python"` and `"args": ["C:/absolute/path/to/server.py"]`.

## API Reference

### Ideas

#### Search Ideas
- **Tool**: `search_ideas`
- **Parameters**:
  - `product_id` (required): Product ID - all operations are scoped to a product
  - `query` (optional): Search query string (e.g., "mobile app") - searches idea names and descriptions using the `q` parameter
  - `release_id` (optional): Filter by release ID. Takes precedence over `release_name` if both are provided.
  - `release_name` (optional): Filter by release name (e.g., "Q4 Release", "Q4 2024") - **Automatically resolved to release_id using fuzzy matching**. Use this for natural language queries.
  - `epic_id` (optional): Filter by epic ID. Takes precedence over `epic_name` if both are provided.
  - `epic_name` (optional): Filter by epic name - **Automatically resolved to epic_id using fuzzy matching**. Use this for natural language queries.
  - `initiative_id` (optional): Filter by initiative ID. Takes precedence over `initiative_name` if both are provided.
  - `initiative_name` (optional): Filter by initiative name - **Automatically resolved to initiative_id using fuzzy matching**. Use this for natural language queries.
  - `workflow_status_id` (optional): Filter by workflow status ID
  - `limit` (optional): Maximum results (default: 25)
  - `page` (optional): Page number (default: 1)
  
**Note**: 
- Names are automatically resolved to IDs using a cached context discovery service with fuzzy matching (60% similarity threshold).
- The context cache is refreshed every 30 minutes or can be manually cleared.
- Uses query parameters to filter ideas by release/epic/initiative when provided.

#### Get Idea
- **Tool**: `get_idea`
- **Parameters**:
  - `id` (required): Idea ID or reference number
  - `fields` (optional): Comma-separated fields to include

#### Create Idea
- **Tool**: `create_idea`
- **Parameters**:
  - `name` (required): Name of the idea
  - `product_id` (required): Product ID
  - `description` (optional): Description (HTML or plain text)
  - `workflow_status_id` (optional): Initial workflow status ID
  - `submitted_idea_portal_id` (optional): Idea portal ID
  - `skip_portal` (optional): Skip portal submission (default: false)

#### Update Idea
- **Tool**: `update_idea`
- **Parameters**:
  - `id` (required): Idea ID or reference number
  - `name` (optional): New name
  - `description` (optional): New description
  - `workflow_status_id` (optional): New workflow status ID
  - `product_id` (optional): Product ID to move to

### Features

#### Search Features
- **Tool**: `search_features`
- **Parameters**:
  - `product_id` (required): Product ID - all operations are scoped to a product
  - `query` (optional): Search query string (e.g., "data lake") - searches feature names and descriptions using the `q` parameter
  - `release_id` (optional): Filter by release ID - **When provided, searches only within this release**. Takes precedence over `release_name` if both are provided.
  - `release_name` (optional): Filter by release name (e.g., "Q4 Release", "Q4 2024") - **Automatically resolved to release_id using fuzzy matching**. Use this for natural language queries.
  - `epic_id` (optional): Filter by epic ID - **When provided, searches only within this epic**. Takes precedence over `epic_name` if both are provided.
  - `epic_name` (optional): Filter by epic name - **Automatically resolved to epic_id using fuzzy matching**. Use this for natural language queries.
  - `initiative_id` (optional): Filter by initiative ID - **When provided, searches only within this initiative**. Takes precedence over `initiative_name` if both are provided.
  - `initiative_name` (optional): Filter by initiative name - **Automatically resolved to initiative_id using fuzzy matching**. Use this for natural language queries.
  - `workflow_status_id` (optional): Filter by workflow status ID
  - `limit` (optional): Maximum results (default: 25)
  - `page` (optional): Page number (default: 1)
  
**Note**: 
- When `release_id`/`release_name`, `epic_id`/`epic_name`, or `initiative_id`/`initiative_name` is provided, the search uses the specific nested endpoint for that resource (e.g., `/releases/{release_id}/features`).
- Names are automatically resolved to IDs using a cached context discovery service with fuzzy matching (60% similarity threshold).
- The context cache is refreshed every 30 minutes or can be manually cleared.
- Otherwise, uses the product-scoped endpoint `/products/{product_id}/features` to search within the product.

#### Get Feature
- **Tool**: `get_feature`
- **Parameters**:
  - `id` (required): Feature ID or reference number
  - `fields` (optional): Comma-separated fields to include

#### Create Feature
- **Tool**: `create_feature`
- **Parameters**:
  - `name` (required): Name of the feature
  - `release_id` (required): Release ID
  - `description` (optional): Description (HTML or plain text)
  - `epic_id` (optional): Epic ID to associate with
  - `workflow_status_id` (optional): Initial workflow status ID
  - `start_date` (optional): Start date (YYYY-MM-DD)
  - `due_date` (optional): Due date (YYYY-MM-DD)

#### Update Feature
- **Tool**: `update_feature`
- **Parameters**:
  - `id` (required): Feature ID or reference number
  - `name` (optional): New name
  - `description` (optional): New description
  - `workflow_status_id` (optional): New workflow status ID
  - `release_id` (optional): Release ID to move to
  - `epic_id` (optional): Epic ID to associate with
  - `start_date` (optional): Start date (YYYY-MM-DD)
  - `due_date` (optional): Due date (YYYY-MM-DD)

### Epics

#### Search Epics
- **Tool**: `search_epics`
- **Parameters**:
  - `product_id` (required): Product ID - all operations are scoped to a product
  - `query` (optional): Search query string
  - `release_id` (optional): Filter by release ID (searches within this release if provided)
  - `workflow_status_id` (optional): Filter by workflow status ID
  - `limit` (optional): Maximum results (default: 25)
  - `page` (optional): Page number (default: 1)

#### Get Epic
- **Tool**: `get_epic`
- **Parameters**:
  - `id` (required): Epic ID or reference number
  - `fields` (optional): Comma-separated fields to include

#### Create Epic
- **Tool**: `create_epic`
- **Parameters**:
  - `name` (required): Name of the epic
  - `release_id` (optional): Release ID (required if product_id not provided)
  - `product_id` (optional): Product ID (creates in default release if release_id not provided)
  - `description` (optional): Description (HTML or plain text)
  - `initiative_id` (optional): Initiative ID to associate with
  - `workflow_status_id` (optional): Initial workflow status ID
  - `start_date` (optional): Start date (YYYY-MM-DD)
  - `due_date` (optional): Due date (YYYY-MM-DD)

#### Update Epic
- **Tool**: `update_epic`
- **Parameters**:
  - `id` (required): Epic ID or reference number
  - `name` (optional): New name
  - `description` (optional): New description
  - `workflow_status_id` (optional): New workflow status ID
  - `release_id` (optional): Release ID to move to
  - `initiative_id` (optional): Initiative ID to associate with
  - `start_date` (optional): Start date (YYYY-MM-DD)
  - `due_date` (optional): Due date (YYYY-MM-DD)

### Releases

#### Search Releases
- **Tool**: `search_releases`
- **Parameters**:
  - `product_id` (required): Product ID to list releases for
  - `query` (optional): Search query string
  - `workflow_status_id` (optional): Filter by workflow status ID
  - `limit` (optional): Maximum results (default: 25)
  - `page` (optional): Page number (default: 1)

#### Get Release
- **Tool**: `get_release`
- **Parameters**:
  - `id` (required): Release ID or reference number
  - `fields` (optional): Comma-separated fields to include

#### Create Release
- **Tool**: `create_release`
- **Parameters**:
  - `name` (required): Name of the release
  - `product_id` (required): Product ID
  - `description` (optional): Description/theme (HTML or plain text)
  - `release_date` (optional): Release date (YYYY-MM-DD)
  - `start_date` (optional): Start date (YYYY-MM-DD)
  - `end_date` (optional): End date (YYYY-MM-DD)
  - `workflow_status_id` (optional): Initial workflow status ID
  - `owner_email` (optional): Owner email address

#### Update Release
- **Tool**: `update_release`
- **Parameters**:
  - `id` (required): Release ID or reference number
  - `product_id` (required): Product ID
  - `name` (optional): New name
  - `description` (optional): New description/theme
  - `release_date` (optional): Release date (YYYY-MM-DD)
  - `start_date` (optional): Start date (YYYY-MM-DD)
  - `end_date` (optional): End date (YYYY-MM-DD)
  - `workflow_status_id` (optional): New workflow status ID
  - `owner_email` (optional): Owner email address

### Initiatives

#### List Initiatives
- **Tool**: `list_initiatives`
- **Parameters**:
  - `product_id` (required): Product ID - all operations are scoped to a product
  - `query` (optional): Search query string
  - `limit` (optional): Maximum results (default: 25)
  - `page` (optional): Page number (default: 1)

#### Get Initiative
- **Tool**: `get_initiative`
- **Parameters**:
  - `id` (required): Initiative ID or reference number
  - `fields` (optional): Comma-separated fields to include

## Examples

### Search for ideas
```python
# Search for ideas containing "mobile" in product PRJ1 (product_id is required)
search_ideas(product_id="131414752", query="mobile")

# Search for ideas in a specific release (using name - automatically resolved!)
search_ideas(product_id="131414752", query="mobile app", release_name="Q4 Release")

# Search for ideas within a specific epic (using name)
search_ideas(product_id="131414752", query="authentication", epic_name="User Authentication Epic")

# Search for ideas within a specific initiative (using name)
search_ideas(product_id="131414752", query="mobile", initiative_name="Mobile App Initiative")

# You can still use IDs if you prefer
search_ideas(product_id="131414752", query="mobile", release_id="278327321")
```

### Create a new idea
```python
# Create a new idea
create_idea(
    name="Mobile App Redesign",
    product_id="131414752",
    description="Redesign the mobile app for better UX",
    workflow_status_id="3259216"
)
```

### Search for features
```python
# Search for features in a product (product_id is required)
search_features(product_id="131414752", limit=50)

# Search for features in a specific release (using ID)
search_features(product_id="131414752", release_id="278327321", limit=50)

# Search for "data lake" features in Q4 Release (using name - automatically resolved!)
search_features(product_id="131414752", query="data lake", release_name="Q4 Release")

# Search for features within a specific epic (using name)
search_features(product_id="131414752", query="authentication", epic_name="User Authentication Epic")

# Search for features within a specific initiative (using name)
search_features(product_id="131414752", query="mobile", initiative_name="Mobile App Initiative")

# You can still use IDs if you prefer
search_features(product_id="131414752", query="data lake", release_id="278327321")
```

### Create a new feature
```python
# Create a new feature
create_feature(
    name="User Authentication",
    release_id="278327321",
    description="Implement OAuth2 authentication",
    epic_id="999605892"
)
```

### Search for epics
```python
# Search for epics in a product
search_epics(product_id="131414752", limit=50)

# Search for epics in a specific release
search_epics(product_id="131414752", release_id="278327321", limit=50)
```

### Create a new epic
```python
# Create a new epic
create_epic(
    name="Authentication Epic",
    release_id="278327321",
    description="Epic for all authentication-related features"
)
```

### Search for releases
```python
# Search for releases in a product
search_releases(product_id="131414752", limit=50)
```

### Create a new release
```python
# Create a new release
create_release(
    name="Q1 2024 Release",
    product_id="131414752",
    release_date="2024-03-31",
    description="Major features for Q1"
)
```

### List initiatives
```python
# List all initiatives for a product (product_id is required)
list_initiatives(product_id="131414752")

# Search for initiatives by name
list_initiatives(product_id="131414752", query="mobile")
```

### Workflow: Finding features in a release
```python
# Step 1: List releases for a product to find the release ID
releases = search_releases(product_id="131414752", query="Q4")
# Find the release ID from the results (e.g., "278327321")

# Step 2: Search for features within that release
features = search_features(query="data lake", release_id="278327321")
```

### Workflow: Finding features in an epic
```python
# Step 1: List epics for a product or release
epics = search_epics(product_id="131414752", query="authentication")
# Find the epic ID from the results (e.g., "999605892")

# Step 2: Search for features within that epic
features = search_features(product_id="131414752", query="OAuth", epic_id="999605892")
```

## Error Handling

The server handles errors gracefully and returns error messages in JSON format. Common errors include:

- Missing API key: Set `AHA_API_KEY` environment variable
- Invalid credentials: Check your API key
- Resource not found: Verify the ID or reference number
- Validation errors: Check required fields and data formats

## License

This project is provided as-is for use with the AHA! API.

## Support

For issues related to:
- **This MCP Server**: Open an issue in the repository
- **AHA! API**: Contact AHA! support at https://www.aha.io/support

