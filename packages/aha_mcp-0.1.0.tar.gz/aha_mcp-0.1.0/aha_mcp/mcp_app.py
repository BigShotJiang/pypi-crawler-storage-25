#!/usr/bin/env python3
"""
MCP Server for AHA! API
Supports searching, retrieving, creating, and editing ideas, features, epics, and releases.
"""

import asyncio
import json
import os
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .aha_client import AhaClient
from .context_cache import ContextCache

# Load .env from the package directory, then current working directory
_pkg_dir = Path(__file__).resolve().parent
_env_candidates = (_pkg_dir / ".env", Path.cwd() / ".env")
for _env_path in _env_candidates:
    if _env_path.exists():
        load_dotenv(_env_path, override=True)
        break
else:
    load_dotenv(override=True)


# Initialize the MCP server
server = Server("aha-mcp-server")

# Initialize AHA client and context cache
aha_client: Optional[AhaClient] = None
context_cache: Optional[ContextCache] = None


def get_client() -> AhaClient:
    """Get or create the AHA client instance with context cache."""
    global aha_client, context_cache
    if aha_client is None:
        account_domain = os.getenv("AHA_ACCOUNT_DOMAIN")
        api_key = os.getenv("AHA_API_KEY")
        
        if not account_domain:
            raise ValueError("AHA_ACCOUNT_DOMAIN environment variable is required. Please set it in your .env file or as an environment variable.")
        if not api_key:
            raise ValueError("AHA_API_KEY environment variable is required. Please set it in your .env file or as an environment variable.")
        
        # Create client first
        aha_client = AhaClient(account_domain, api_key)
        # Initialize context cache with the client
        context_cache = ContextCache(aha_client, ttl_minutes=30)
        # Set the cache in the client
        aha_client.context_cache = context_cache
    return aha_client


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List all available tools."""
    return [
        Tool(
            name="search_ideas",
            description="Search for ideas in a product. All operations are scoped to a specific product. You can filter by release, epic, or initiative using either IDs or names. When a name is provided, it will be automatically resolved to an ID. When release/epic/initiative is specified, filters ideas using query parameters. If product_id is not provided, will use AHA_PRODUCT_ID from environment if available. This tool uses a discovery-first approach: it will first populate the context cache with releases, epics, and initiatives before searching.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter ideas by name or description (e.g., 'mobile app'). Uses the 'q' parameter to search idea names and descriptions."
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Filter by release ID. Takes precedence over release_name if both are provided."
                    },
                    "release_name": {
                        "type": "string",
                        "description": "Filter by release name (e.g., 'Q4 Release', 'Q4 2024'). Will be automatically resolved to release_id using fuzzy matching. Use this for natural language queries like 'ideas in Q4 Release'."
                    },
                    "epic_id": {
                        "type": "string",
                        "description": "Filter by epic ID. Takes precedence over epic_name if both are provided."
                    },
                    "epic_name": {
                        "type": "string",
                        "description": "Filter by epic name. Will be automatically resolved to epic_id using fuzzy matching. Use this for natural language queries."
                    },
                    "initiative_id": {
                        "type": "string",
                        "description": "Filter by initiative ID. Takes precedence over initiative_name if both are provided."
                    },
                    "initiative_name": {
                        "type": "string",
                        "description": "Filter by initiative name. Will be automatically resolved to initiative_id using fuzzy matching. Use this for natural language queries."
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Filter by workflow status ID"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_idea",
            description="Retrieve a specific idea by ID or reference number.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Idea ID or reference number (e.g., 'PRJ1-I-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": "Comma-separated list of fields to include (optional)"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="create_idea",
            description="Create a new idea in AHA!. Products belong to workspaces, so specifying product_id ensures creation in the correct workspace.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the idea"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID where the idea should be created (products belong to workspaces)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description of the idea (HTML or plain text)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Initial workflow status ID (optional)"
                    },
                    "submitted_idea_portal_id": {
                        "type": "string",
                        "description": "Idea portal ID if submitting from a portal (optional)"
                    },
                    "skip_portal": {
                        "type": "boolean",
                        "description": "Skip portal submission (default: false)",
                        "default": False
                    }
                },
                "required": ["name", "product_id"]
            }
        ),
        Tool(
            name="update_idea",
            description="Update an existing idea in AHA!.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Idea ID or reference number"
                    },
                    "name": {
                        "type": "string",
                        "description": "New name for the idea"
                    },
                    "description": {
                        "type": "string",
                        "description": "New description for the idea"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "New workflow status ID"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID to move the idea to"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="search_features",
            description="Search for features. All operations are scoped to a specific product. You can filter by release, epic, or initiative using either IDs or names. When a name is provided, it will be automatically resolved to an ID. When release/epic/initiative is specified, searches within that specific resource using nested endpoints. Otherwise, searches within the product. If product_id is not provided, will use AHA_PRODUCT_ID from environment if available. This tool uses a discovery-first approach: it will first populate the context cache with releases, epics, and initiatives before searching.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter features by name or description (e.g., 'data lake'). Uses the 'q' parameter to search feature names and descriptions."
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Filter by release ID. When provided, searches only within this release. Takes precedence over release_name if both are provided."
                    },
                    "release_name": {
                        "type": "string",
                        "description": "Filter by release name (e.g., 'Q4 Release', 'Q4 2024'). Will be automatically resolved to release_id using fuzzy matching. Use this for natural language queries like 'features in Q4 Release'."
                    },
                    "epic_id": {
                        "type": "string",
                        "description": "Filter by epic ID. When provided, searches only within this epic. Takes precedence over epic_name if both are provided."
                    },
                    "epic_name": {
                        "type": "string",
                        "description": "Filter by epic name. Will be automatically resolved to epic_id using fuzzy matching. Use this for natural language queries."
                    },
                    "initiative_id": {
                        "type": "string",
                        "description": "Filter by initiative ID. When provided, searches only within this initiative. Takes precedence over initiative_name if both are provided."
                    },
                    "initiative_name": {
                        "type": "string",
                        "description": "Filter by initiative name. Will be automatically resolved to initiative_id using fuzzy matching. Use this for natural language queries."
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Filter by workflow status ID"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                }
            }
        ),
        Tool(
            name="get_feature",
            description="Retrieve a specific feature by ID or reference number.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Feature ID or reference number (e.g., 'PRJ1-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": "Comma-separated list of fields to include (optional)"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="create_feature",
            description="Create a new feature in AHA!. Features must belong to a release. Releases belong to products, which belong to workspaces, so specifying release_id ensures creation in the correct workspace.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the feature"
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release ID where the feature should be created (releases belong to products, which belong to workspaces)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description of the feature (HTML or plain text)"
                    },
                    "epic_id": {
                        "type": "string",
                        "description": "Epic ID to associate the feature with (optional)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Initial workflow status ID (optional)"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format (optional)"
                    },
                    "due_date": {
                        "type": "string",
                        "description": "Due date in YYYY-MM-DD format (optional)"
                    }
                },
                "required": ["name", "release_id"]
            }
        ),
        Tool(
            name="update_feature",
            description="Update an existing feature in AHA!.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Feature ID or reference number"
                    },
                    "name": {
                        "type": "string",
                        "description": "New name for the feature"
                    },
                    "description": {
                        "type": "string",
                        "description": "New description for the feature"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "New workflow status ID"
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release ID to move the feature to"
                    },
                    "epic_id": {
                        "type": "string",
                        "description": "Epic ID to associate the feature with"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format"
                    },
                    "due_date": {
                        "type": "string",
                        "description": "Due date in YYYY-MM-DD format"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="search_epics",
            description="Search for epics in a product. All operations are scoped to a specific product. If release_id is provided, searches within that release. If product_id is not provided, will use AHA_PRODUCT_ID from environment if available.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter epics by name or description"
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Filter by release ID (searches within this release if provided)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Filter by workflow status ID"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_epic",
            description="Retrieve a specific epic by ID or reference number.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Epic ID or reference number (e.g., 'PRJ1-E-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": "Comma-separated list of fields to include (optional)"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="create_epic",
            description="Create a new epic in AHA!. Epics belong to releases. You must provide either release_id or product_id (which will create the epic in the product's default release).",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the epic"
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release ID where the epic should be created (required if product_id not provided)"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (creates in default release if release_id not provided)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description of the epic (HTML or plain text)"
                    },
                    "initiative_id": {
                        "type": "string",
                        "description": "Initiative ID to associate the epic with (optional)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Initial workflow status ID (optional)"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format (optional)"
                    },
                    "due_date": {
                        "type": "string",
                        "description": "Due date in YYYY-MM-DD format (optional)"
                    }
                },
                "required": ["name"]
            }
        ),
        Tool(
            name="update_epic",
            description="Update an existing epic in AHA!.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Epic ID or reference number"
                    },
                    "name": {
                        "type": "string",
                        "description": "New name for the epic"
                    },
                    "description": {
                        "type": "string",
                        "description": "New description for the epic"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "New workflow status ID"
                    },
                    "release_id": {
                        "type": "string",
                        "description": "Release ID to move the epic to"
                    },
                    "initiative_id": {
                        "type": "string",
                        "description": "Initiative ID to associate the epic with"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format"
                    },
                    "due_date": {
                        "type": "string",
                        "description": "Due date in YYYY-MM-DD format"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="search_releases",
            description="Search for releases in AHA!. Requires product_id to list releases for a specific product. If product_id is not provided, will use AHA_PRODUCT_ID from environment if available.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID to list releases for (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter releases by name or description"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Filter by workflow status ID"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_release",
            description="Retrieve a specific release by ID or reference number.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Release ID or reference number (e.g., 'PRJ1-R-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": "Comma-separated list of fields to include (optional)"
                    }
                },
                "required": ["id"]
            }
        ),
        Tool(
            name="create_release",
            description="Create a new release in AHA!. Releases belong to products, which belong to workspaces.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Name of the release"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID where the release should be created (required)"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description/theme of the release (HTML or plain text)"
                    },
                    "release_date": {
                        "type": "string",
                        "description": "Release date in YYYY-MM-DD format (optional)"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format (optional)"
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date in YYYY-MM-DD format (optional)"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "Initial workflow status ID (optional)"
                    },
                    "owner_email": {
                        "type": "string",
                        "description": "Owner email address (optional)"
                    }
                },
                "required": ["name", "product_id"]
            }
        ),
        Tool(
            name="update_release",
            description="Update an existing release in AHA!.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Release ID or reference number"
                    },
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (required)"
                    },
                    "name": {
                        "type": "string",
                        "description": "New name for the release"
                    },
                    "description": {
                        "type": "string",
                        "description": "New description/theme for the release"
                    },
                    "release_date": {
                        "type": "string",
                        "description": "Release date in YYYY-MM-DD format"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Start date in YYYY-MM-DD format"
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date in YYYY-MM-DD format"
                    },
                    "workflow_status_id": {
                        "type": "string",
                        "description": "New workflow status ID"
                    },
                    "owner_email": {
                        "type": "string",
                        "description": "Owner email address"
                    }
                },
                "required": ["id", "product_id"]
            }
        ),
        Tool(
            name="list_initiatives",
            description="List initiatives for a product. All operations are scoped to a specific product. If product_id is not provided, will use AHA_PRODUCT_ID from environment if available.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {
                        "type": "string",
                        "description": "Product ID (optional if AHA_PRODUCT_ID is set in environment)"
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query string to filter initiatives by name or description"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of results to return (default: 25)",
                        "default": 25
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number for pagination (default: 1)",
                        "default": 1
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_initiative",
            description="Retrieve a specific initiative by ID or reference number.",
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Initiative ID or reference number (e.g., 'PRJ1-S-1')"
                    },
                    "fields": {
                        "type": "string",
                        "description": "Comma-separated list of fields to include (optional)"
                    }
                },
                "required": ["id"]
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""
    client = get_client()
    
    # Get default product ID from environment if available
    default_product_id = os.getenv("AHA_PRODUCT_ID")
    
    try:
        if name == "search_ideas":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            
            if "product_id" not in arguments or not arguments.get("product_id"):
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": "product_id is required. Either provide it as a parameter or set AHA_PRODUCT_ID in your environment."}, indent=2)
                )]
            
            # Discovery-first approach: populate context cache before searching
            # This ensures releases, epics, and initiatives are available for name resolution
            if client.context_cache:
                product_id = arguments["product_id"]
                # Pre-populate cache with product structure
                await asyncio.gather(
                    client.context_cache.get_releases(product_id),
                    client.context_cache.get_epics(product_id),
                    client.context_cache.get_initiatives(product_id),
                    return_exceptions=True
                )
            
            # Extract name-based parameters and pass them to search_ideas
            result = await client.search_ideas(
                product_id=arguments["product_id"],
                query=arguments.get("query"),
                release_id=arguments.get("release_id"),
                release_name=arguments.get("release_name"),
                epic_id=arguments.get("epic_id"),
                epic_name=arguments.get("epic_name"),
                initiative_id=arguments.get("initiative_id"),
                initiative_name=arguments.get("initiative_name"),
                workflow_status_id=arguments.get("workflow_status_id"),
                limit=arguments.get("limit", 25),
                page=arguments.get("page", 1)
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_idea":
            result = await client.get_idea(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "create_idea":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            result = await client.create_idea(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "update_idea":
            result = await client.update_idea(arguments["id"], **{k: v for k, v in arguments.items() if k != "id"})
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "search_features":
            # Use default product_id if not provided
            if ("product_id" not in arguments or not arguments.get("product_id")) and default_product_id:
                arguments["product_id"] = default_product_id
            
            if "product_id" not in arguments or not arguments.get("product_id"):
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": "product_id is required. Either provide it as a parameter or set AHA_PRODUCT_ID in your environment."}, indent=2)
                )]
            
            # Discovery-first approach: populate context cache before searching
            # This ensures releases, epics, and initiatives are available for name resolution
            if client.context_cache:
                product_id = arguments["product_id"]
                # Pre-populate cache with product structure
                await asyncio.gather(
                    client.context_cache.get_releases(product_id),
                    client.context_cache.get_epics(product_id),
                    client.context_cache.get_initiatives(product_id),
                    return_exceptions=True
                )
            
            # Extract name-based parameters and pass them to search_features
            result = await client.search_features(
                product_id=arguments["product_id"],
                query=arguments.get("query"),
                release_id=arguments.get("release_id"),
                release_name=arguments.get("release_name"),
                epic_id=arguments.get("epic_id"),
                epic_name=arguments.get("epic_name"),
                initiative_id=arguments.get("initiative_id"),
                initiative_name=arguments.get("initiative_name"),
                workflow_status_id=arguments.get("workflow_status_id"),
                limit=arguments.get("limit", 25),
                page=arguments.get("page", 1)
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_feature":
            result = await client.get_feature(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "create_feature":
            result = await client.create_feature(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "update_feature":
            result = await client.update_feature(arguments["id"], **{k: v for k, v in arguments.items() if k != "id"})
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "search_epics":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            result = await client.search_epics(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_epic":
            result = await client.get_epic(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "create_epic":
            result = await client.create_epic(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "update_epic":
            result = await client.update_epic(arguments["id"], **{k: v for k, v in arguments.items() if k != "id"})
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "search_releases":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            result = await client.search_releases(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_release":
            result = await client.get_release(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "create_release":
            result = await client.create_release(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "update_release":
            result = await client.update_release(arguments["id"], arguments["product_id"], **{k: v for k, v in arguments.items() if k not in ["id", "product_id"]})
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "list_initiatives":
            # Use default product_id if not provided
            if "product_id" not in arguments and default_product_id:
                arguments["product_id"] = default_product_id
            result = await client.list_initiatives(**arguments)
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        elif name == "get_initiative":
            result = await client.get_initiative(arguments["id"], arguments.get("fields"))
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        
        else:
            raise ValueError(f"Unknown tool: {name}")
    
    except Exception as e:
        error_msg = f"Error executing {name}: {str(e)}"
        return [TextContent(
            type="text",
            text=json.dumps({"error": error_msg}, indent=2)
        )]


async def main():
    """Main entry point for the MCP server."""
    async with stdio_server() as streams:
        await server.run(
            streams[0],
            streams[1],
            server.create_initialization_options()
        )


def run_mcp() -> None:
    """Run the MCP server over stdio (used by CLI and ``python -m aha_mcp``)."""
    asyncio.run(main())

