"""
Context Discovery and Caching Service for AHA! MCP Server.

Provides caching and fuzzy name matching for releases, epics, and initiatives
to enable natural language queries like "features in Q4 Release" instead of
requiring explicit IDs.
"""

from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from difflib import SequenceMatcher
import asyncio

from .aha_client import AhaClient


class ContextCache:
    """Cache for product structure (releases, epics, initiatives) with fuzzy matching."""
    
    def __init__(self, client: AhaClient, ttl_minutes: int = 30):
        """
        Initialize the context cache.
        
        Args:
            client: AHA client instance
            ttl_minutes: Time-to-live for cache entries in minutes (default: 30)
        """
        self.client = client
        self.ttl = timedelta(minutes=ttl_minutes)
        
        # Cache structure: {product_id: {type: {data: [...], timestamp: datetime}}}
        self._cache: Dict[str, Dict[str, Dict]] = {}
        self._lock = asyncio.Lock()
    
    async def get_releases(self, product_id: str, force_refresh: bool = False) -> List[Dict]:
        """
        Get releases for a product, using cache if available.
        
        Args:
            product_id: Product ID
            force_refresh: If True, bypass cache and fetch fresh data
        
        Returns:
            List of release dictionaries
        """
        async with self._lock:
            if not force_refresh and self._is_cached(product_id, "releases"):
                return self._cache[product_id]["releases"]["data"]
            
            releases_result = await self.client.search_releases(product_id=product_id, limit=1000)
            releases = releases_result.get("releases", [])
            
            self._update_cache(product_id, "releases", releases)
            return releases
    
    async def get_epics(self, product_id: str, release_id: Optional[str] = None, force_refresh: bool = False) -> List[Dict]:
        """
        Get epics for a product or release, using cache if available.
        
        Args:
            product_id: Product ID
            release_id: Optional release ID to filter epics
            force_refresh: If True, bypass cache and fetch fresh data
        
        Returns:
            List of epic dictionaries
        """
        async with self._lock:
            cache_key = f"epics_{release_id}" if release_id else "epics"
            
            if not force_refresh and self._is_cached(product_id, cache_key):
                return self._cache[product_id][cache_key]["data"]
            
            if release_id:
                epics_result = await self.client.search_epics(product_id=product_id, release_id=release_id, limit=1000)
            else:
                epics_result = await self.client.search_epics(product_id=product_id, limit=1000)
            
            epics = epics_result.get("epics", [])
            self._update_cache(product_id, cache_key, epics)
            return epics
    
    async def get_initiatives(self, product_id: str, force_refresh: bool = False) -> List[Dict]:
        """
        Get initiatives for a product, using cache if available.
        
        Args:
            product_id: Product ID
            force_refresh: If True, bypass cache and fetch fresh data
        
        Returns:
            List of initiative dictionaries
        """
        async with self._lock:
            if not force_refresh and self._is_cached(product_id, "initiatives"):
                return self._cache[product_id]["initiatives"]["data"]
            
            initiatives_result = await self.client.list_initiatives(product_id=product_id, limit=1000)
            initiatives = initiatives_result.get("initiatives", [])
            
            self._update_cache(product_id, "initiatives", initiatives)
            return initiatives
    
    def _is_cached(self, product_id: str, cache_key: str) -> bool:
        """Check if data is cached and still valid."""
        if product_id not in self._cache:
            return False
        if cache_key not in self._cache[product_id]:
            return False
        
        entry = self._cache[product_id][cache_key]
        if "timestamp" not in entry:
            return False
        
        age = datetime.now() - entry["timestamp"]
        return age < self.ttl
    
    def _update_cache(self, product_id: str, cache_key: str, data: List[Dict]):
        """Update cache with new data."""
        if product_id not in self._cache:
            self._cache[product_id] = {}
        
        self._cache[product_id][cache_key] = {
            "data": data,
            "timestamp": datetime.now()
        }
    
    def clear_cache(self, product_id: Optional[str] = None):
        """
        Clear cache for a specific product or all products.
        
        Args:
            product_id: If provided, clear only this product's cache. Otherwise clear all.
        """
        if product_id:
            if product_id in self._cache:
                del self._cache[product_id]
        else:
            self._cache.clear()
    
    async def find_release_by_name(
        self,
        product_id: str,
        name: str,
        threshold: float = 0.6
    ) -> Optional[Tuple[str, Dict]]:
        """
        Find a release by name using fuzzy matching.
        
        Args:
            product_id: Product ID
            name: Release name to search for
            threshold: Similarity threshold (0.0 to 1.0, default: 0.6)
        
        Returns:
            Tuple of (release_id, release_dict) if found, None otherwise
        """
        releases = await self.get_releases(product_id)
        return self._fuzzy_match(name, releases, threshold)
    
    async def find_epic_by_name(
        self,
        product_id: str,
        name: str,
        release_id: Optional[str] = None,
        threshold: float = 0.6
    ) -> Optional[Tuple[str, Dict]]:
        """
        Find an epic by name using fuzzy matching.
        
        Args:
            product_id: Product ID
            name: Epic name to search for
            release_id: Optional release ID to limit search
            threshold: Similarity threshold (0.0 to 1.0, default: 0.6)
        
        Returns:
            Tuple of (epic_id, epic_dict) if found, None otherwise
        """
        epics = await self.get_epics(product_id, release_id)
        return self._fuzzy_match(name, epics, threshold)
    
    async def find_initiative_by_name(
        self,
        product_id: str,
        name: str,
        threshold: float = 0.6
    ) -> Optional[Tuple[str, Dict]]:
        """
        Find an initiative by name using fuzzy matching.
        
        Args:
            product_id: Product ID
            name: Initiative name to search for
            threshold: Similarity threshold (0.0 to 1.0, default: 0.6)
        
        Returns:
            Tuple of (initiative_id, initiative_dict) if found, None otherwise
        """
        initiatives = await self.get_initiatives(product_id)
        return self._fuzzy_match(name, initiatives, threshold)
    
    def _fuzzy_match(
        self,
        search_name: str,
        items: List[Dict],
        threshold: float = 0.6
    ) -> Optional[Tuple[str, Dict]]:
        """
        Find the best matching item by name using fuzzy string matching.
        
        Args:
            search_name: Name to search for
            items: List of item dictionaries with 'name' and 'id' fields
            threshold: Minimum similarity score (0.0 to 1.0)
        
        Returns:
            Tuple of (item_id, item_dict) for best match, or None if no match above threshold
        """
        if not items:
            return None
        
        search_name_lower = search_name.lower().strip()
        best_match = None
        best_score = 0.0
        
        for item in items:
            item_name = item.get("name", "")
            if not item_name:
                continue
            
            item_name_lower = item_name.lower().strip()
            
            # Check for exact match (case-insensitive)
            if item_name_lower == search_name_lower:
                return (item.get("id"), item)
            
            # Check for substring match
            if search_name_lower in item_name_lower or item_name_lower in search_name_lower:
                score = min(len(search_name_lower), len(item_name_lower)) / max(len(search_name_lower), len(item_name_lower))
                if score > best_score:
                    best_score = score
                    best_match = (item.get("id"), item)
            
            # Calculate similarity ratio
            similarity = SequenceMatcher(None, search_name_lower, item_name_lower).ratio()
            if similarity > best_score:
                best_score = similarity
                best_match = (item.get("id"), item)
        
        # Return best match if it meets threshold
        if best_match and best_score >= threshold:
            return best_match
        
        return None





