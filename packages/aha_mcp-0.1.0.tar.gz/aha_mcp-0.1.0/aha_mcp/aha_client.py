"""
AHA! API Client
Handles all API interactions with the AHA! service.
"""

from typing import Any, Optional, Dict
import httpx


class AhaClient:
    """Client for interacting with the AHA! API."""
    
    def __init__(self, account_domain: str, api_key: str, context_cache=None):
        """
        Initialize the AHA client.
        
        Args:
            account_domain: Your AHA! account domain (e.g., 'company' for company.aha.io)
            api_key: Your AHA! API key
            context_cache: Optional ContextCache instance for name-based resolution
        """
        self.account_domain = account_domain
        self.api_key = api_key
        self.base_url = f"https://{account_domain}.aha.io/api/v1"
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        self.context_cache = context_cache
    
    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the AHA! API.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint (e.g., '/ideas')
            params: Query parameters
            data: Request body data
        
        Returns:
            JSON response as a dictionary
        """
        url = f"{self.base_url}{endpoint}"
        
        async with httpx.AsyncClient() as client:
            response = await client.request(
                method=method,
                url=url,
                headers=self.headers,
                params=params,
                json=data,
                timeout=30.0
            )
            response.raise_for_status()
            return response.json()
    
    # Ideas methods
    
    async def search_ideas(
        self,
        product_id: str,
        query: Optional[str] = None,
        release_id: Optional[str] = None,
        release_name: Optional[str] = None,
        epic_id: Optional[str] = None,
        epic_name: Optional[str] = None,
        initiative_id: Optional[str] = None,
        initiative_name: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        Search for ideas in a product. All operations are scoped to a specific product.
        
        If release_id/epic_id/initiative_id or their names are provided, filters ideas
        using query parameters. Names are resolved to IDs using the context cache if available.
        If both ID and name are provided for the same resource type, ID takes precedence.
        
        Args:
            product_id: Product ID (required - all operations are scoped to a product)
            query: Search query string
            release_id: Filter by release ID
            release_name: Filter by release name (resolved to ID if context_cache available)
            epic_id: Filter by epic ID
            epic_name: Filter by epic name (resolved to ID if context_cache available)
            initiative_id: Filter by initiative ID
            initiative_name: Filter by initiative name (resolved to ID if context_cache available)
            workflow_status_id: Filter by workflow status ID
            limit: Maximum number of results
            page: Page number
        
        Returns:
            Search results with ideas and pagination
        """
        # Resolve names to IDs if context cache is available
        if self.context_cache:
            if release_name and not release_id:
                match = await self.context_cache.find_release_by_name(product_id, release_name)
                if match:
                    release_id = match[0]
            
            if epic_name and not epic_id:
                match = await self.context_cache.find_epic_by_name(product_id, epic_name, release_id)
                if match:
                    epic_id = match[0]
            
            if initiative_name and not initiative_id:
                match = await self.context_cache.find_initiative_by_name(product_id, initiative_name)
                if match:
                    initiative_id = match[0]
        
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        if workflow_status_id:
            params["workflow_status_id"] = workflow_status_id
        if release_id:
            params["release_id"] = release_id
        if epic_id:
            params["epic_id"] = epic_id
        if initiative_id:
            params["initiative_id"] = initiative_id
        
        return await self._request("GET", f"/products/{product_id}/ideas", params=params)
    
    async def get_idea(self, idea_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific idea by ID.
        
        Args:
            idea_id: Idea ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Idea details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/ideas/{idea_id}", params=params)
    
    async def create_idea(
        self,
        name: str,
        product_id: str,
        description: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        submitted_idea_portal_id: Optional[str] = None,
        skip_portal: bool = False
    ) -> Dict[str, Any]:
        """
        Create a new idea.
        
        Args:
            name: Name of the idea
            product_id: Product ID (products belong to workspaces, so this ensures creation in the correct workspace)
            description: Description (HTML or plain text)
            workflow_status_id: Initial workflow status ID
            submitted_idea_portal_id: Idea portal ID if submitting from a portal
            skip_portal: Skip portal submission
        
        Returns:
            Created idea details
        """
        idea_data = {
            "name": name,
            "product_id": product_id
        }
        
        if description:
            idea_data["description"] = {"body": description}
        if workflow_status_id:
            idea_data["workflow_status_id"] = workflow_status_id
        if submitted_idea_portal_id:
            idea_data["submitted_idea_portal_id"] = submitted_idea_portal_id
        if skip_portal:
            idea_data["skip_portal"] = True
        
        return await self._request("POST", "/ideas", data={"idea": idea_data})
    
    async def update_idea(
        self,
        idea_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        product_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update an existing idea.
        
        Args:
            idea_id: Idea ID or reference number
            name: New name
            description: New description
            workflow_status_id: New workflow status ID
            product_id: Product ID to move the idea to
        
        Returns:
            Updated idea details
        """
        idea_data = {}
        
        if name:
            idea_data["name"] = name
        if description:
            idea_data["description"] = {"body": description}
        if workflow_status_id:
            idea_data["workflow_status_id"] = workflow_status_id
        if product_id:
            idea_data["product_id"] = product_id
        
        return await self._request("PUT", f"/ideas/{idea_id}", data={"idea": idea_data})
    
    # Features methods
    
    async def search_features(
        self,
        product_id: str,
        query: Optional[str] = None,
        release_id: Optional[str] = None,
        release_name: Optional[str] = None,
        epic_id: Optional[str] = None,
        epic_name: Optional[str] = None,
        initiative_id: Optional[str] = None,
        initiative_name: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        Search for features. All operations are scoped to a specific product.
        
        If release_id/epic_id/initiative_id or their names are provided, uses the specific endpoint
        for that resource. Otherwise, uses the product-scoped features endpoint.
        
        Names are resolved to IDs using the context cache if available. If both ID and name
        are provided for the same resource type, ID takes precedence.
        
        Args:
            product_id: Product ID (required - all operations are scoped to a product)
            query: Search query string (searches feature names and descriptions)
            release_id: Filter by release ID (uses /releases/{release_id}/features endpoint)
            release_name: Filter by release name (resolved to ID if context_cache available)
            epic_id: Filter by epic ID (uses /epics/{epic_id}/features endpoint)
            epic_name: Filter by epic name (resolved to ID if context_cache available)
            initiative_id: Filter by initiative ID (uses /initiatives/{initiative_id}/features endpoint)
            initiative_name: Filter by initiative name (resolved to ID if context_cache available)
            workflow_status_id: Filter by workflow status ID
            limit: Maximum number of results
            page: Page number
        
        Returns:
            Search results with features and pagination
        """
        # Resolve names to IDs if context cache is available
        if self.context_cache:
            if release_name and not release_id:
                match = await self.context_cache.find_release_by_name(product_id, release_name)
                if match:
                    release_id = match[0]
            
            if epic_name and not epic_id:
                match = await self.context_cache.find_epic_by_name(product_id, epic_name, release_id)
                if match:
                    epic_id = match[0]
            
            if initiative_name and not initiative_id:
                match = await self.context_cache.find_initiative_by_name(product_id, initiative_name)
                if match:
                    initiative_id = match[0]
        
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        if workflow_status_id:
            params["workflow_status_id"] = workflow_status_id
        
        # Use specific endpoint if release_id, epic_id, or initiative_id is provided
        if release_id:
            return await self._request("GET", f"/releases/{release_id}/features", params=params)
        elif epic_id:
            return await self._request("GET", f"/epics/{epic_id}/features", params=params)
        elif initiative_id:
            return await self._request("GET", f"/initiatives/{initiative_id}/features", params=params)
        else:
            # Use product-scoped features endpoint
            return await self._request("GET", f"/products/{product_id}/features", params=params)
    
    async def get_feature(self, feature_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific feature by ID.
        
        Args:
            feature_id: Feature ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Feature details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/features/{feature_id}", params=params)
    
    async def create_feature(
        self,
        name: str,
        release_id: str,
        description: Optional[str] = None,
        epic_id: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        start_date: Optional[str] = None,
        due_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new feature.
        
        Args:
            name: Name of the feature
            release_id: Release ID (required - releases belong to products, which belong to workspaces)
            description: Description (HTML or plain text)
            epic_id: Epic ID to associate with
            workflow_status_id: Initial workflow status ID
            start_date: Start date in YYYY-MM-DD format
            due_date: Due date in YYYY-MM-DD format
        
        Returns:
            Created feature details
        """
        feature_data = {
            "name": name,
            "release_id": release_id
        }
        
        if description:
            feature_data["description"] = {"body": description}
        if epic_id:
            feature_data["epic_id"] = epic_id
        if workflow_status_id:
            feature_data["workflow_status_id"] = workflow_status_id
        if start_date:
            feature_data["start_date"] = start_date
        if due_date:
            feature_data["due_date"] = due_date
        
        return await self._request("POST", "/features", data={"feature": feature_data})
    
    async def update_feature(
        self,
        feature_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        release_id: Optional[str] = None,
        epic_id: Optional[str] = None,
        start_date: Optional[str] = None,
        due_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update an existing feature.
        
        Args:
            feature_id: Feature ID or reference number
            name: New name
            description: New description
            workflow_status_id: New workflow status ID
            release_id: Release ID to move the feature to
            epic_id: Epic ID to associate with
            start_date: Start date in YYYY-MM-DD format
            due_date: Due date in YYYY-MM-DD format
        
        Returns:
            Updated feature details
        """
        feature_data = {}
        
        if name:
            feature_data["name"] = name
        if description:
            feature_data["description"] = {"body": description}
        if workflow_status_id:
            feature_data["workflow_status_id"] = workflow_status_id
        if release_id:
            feature_data["release_id"] = release_id
        if epic_id:
            feature_data["epic_id"] = epic_id
        if start_date:
            feature_data["start_date"] = start_date
        if due_date:
            feature_data["due_date"] = due_date
        
        return await self._request("PUT", f"/features/{feature_id}", data={"feature": feature_data})
    
    # Epics methods
    
    async def search_epics(
        self,
        product_id: str,
        query: Optional[str] = None,
        release_id: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        Search for epics in a product.
        
        Args:
            product_id: Product ID (required)
            query: Search query string
            release_id: Filter by release ID (uses /releases/{release_id}/epics endpoint)
            workflow_status_id: Filter by workflow status ID
            limit: Maximum number of results
            page: Page number
        
        Returns:
            Search results with epics and pagination
        """
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        if workflow_status_id:
            params["workflow_status_id"] = workflow_status_id
        
        # Use release-specific endpoint if release_id is provided
        if release_id:
            return await self._request("GET", f"/releases/{release_id}/epics", params=params)
        else:
            # Use product-specific endpoint
            return await self._request("GET", f"/products/{product_id}/epics", params=params)
    
    async def get_epic(self, epic_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific epic by ID.
        
        Args:
            epic_id: Epic ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Epic details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/epics/{epic_id}", params=params)
    
    async def create_epic(
        self,
        name: str,
        release_id: Optional[str] = None,
        product_id: Optional[str] = None,
        description: Optional[str] = None,
        initiative_id: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        start_date: Optional[str] = None,
        due_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new epic.
        
        Args:
            name: Name of the epic
            release_id: Release ID (required if product_id not provided)
            product_id: Product ID (creates in default release if release_id not provided)
            description: Description (HTML or plain text)
            initiative_id: Initiative ID to associate with
            workflow_status_id: Initial workflow status ID
            start_date: Start date in YYYY-MM-DD format
            due_date: Due date in YYYY-MM-DD format
        
        Returns:
            Created epic details
        """
        if not release_id and not product_id:
            raise ValueError("Either release_id or product_id must be provided")
        
        epic_data = {
            "name": name
        }
        
        if description:
            epic_data["description"] = {"body": description} if isinstance(description, str) else description
        if initiative_id:
            epic_data["initiative_id"] = initiative_id
        if workflow_status_id:
            epic_data["workflow_status_id"] = workflow_status_id
        if start_date:
            epic_data["start_date"] = start_date
        if due_date:
            epic_data["due_date"] = due_date
        
        if release_id:
            return await self._request("POST", f"/releases/{release_id}/epics", data={"epic": epic_data})
        else:
            return await self._request("POST", f"/products/{product_id}/epics", data={"epic": epic_data})
    
    async def update_epic(
        self,
        epic_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        release_id: Optional[str] = None,
        initiative_id: Optional[str] = None,
        start_date: Optional[str] = None,
        due_date: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update an existing epic.
        
        Args:
            epic_id: Epic ID or reference number
            name: New name
            description: New description
            workflow_status_id: New workflow status ID
            release_id: Release ID to move the epic to
            initiative_id: Initiative ID to associate with
            start_date: Start date in YYYY-MM-DD format
            due_date: Due date in YYYY-MM-DD format
        
        Returns:
            Updated epic details
        """
        epic_data = {}
        
        if name:
            epic_data["name"] = name
        if description:
            epic_data["description"] = {"body": description} if isinstance(description, str) else description
        if workflow_status_id:
            epic_data["workflow_status_id"] = workflow_status_id
        if release_id:
            epic_data["release_id"] = release_id
        if initiative_id:
            epic_data["initiative_id"] = initiative_id
        if start_date:
            epic_data["start_date"] = start_date
        if due_date:
            epic_data["due_date"] = due_date
        
        return await self._request("PUT", f"/epics/{epic_id}", data={"epic": epic_data})
    
    # Releases methods
    
    async def search_releases(
        self,
        query: Optional[str] = None,
        product_id: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        Search for releases.
        
        Args:
            query: Search query string
            product_id: Filter by product ID (required for listing)
            workflow_status_id: Filter by workflow status ID
            limit: Maximum number of results
            page: Page number
        
        Returns:
            Search results with releases and pagination
        """
        if not product_id:
            raise ValueError("product_id is required for searching releases")
        
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        if workflow_status_id:
            params["workflow_status_id"] = workflow_status_id
        
        return await self._request("GET", f"/products/{product_id}/releases", params=params)
    
    async def get_release(self, release_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific release by ID.
        
        Args:
            release_id: Release ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Release details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/releases/{release_id}", params=params)
    
    async def create_release(
        self,
        name: str,
        product_id: str,
        description: Optional[str] = None,
        release_date: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        owner_email: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new release.
        
        Args:
            name: Name of the release
            product_id: Product ID (required)
            description: Description/theme (HTML or plain text)
            release_date: Release date in YYYY-MM-DD format
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            workflow_status_id: Initial workflow status ID
            owner_email: Owner email address
        
        Returns:
            Created release details
        """
        release_data = {
            "name": name
        }
        
        if description:
            release_data["theme"] = description
        if release_date:
            release_data["release_date"] = release_date
        if start_date:
            release_data["start_date"] = start_date
        if end_date:
            release_data["end_date"] = end_date
        if workflow_status_id:
            release_data["status"] = workflow_status_id
        if owner_email:
            release_data["owner"] = owner_email
        
        return await self._request("POST", f"/products/{product_id}/releases", data={"release": release_data})
    
    async def update_release(
        self,
        release_id: str,
        product_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        release_date: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        workflow_status_id: Optional[str] = None,
        owner_email: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Update an existing release.
        
        Args:
            release_id: Release ID or reference number
            product_id: Product ID (required)
            name: New name
            description: New description/theme
            release_date: Release date in YYYY-MM-DD format
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            workflow_status_id: New workflow status ID
            owner_email: Owner email address
        
        Returns:
            Updated release details
        """
        release_data = {}
        
        if name:
            release_data["name"] = name
        if description:
            release_data["theme"] = description
        if release_date:
            release_data["release_date"] = release_date
        if start_date:
            release_data["start_date"] = start_date
        if end_date:
            release_data["end_date"] = end_date
        if workflow_status_id:
            release_data["status"] = workflow_status_id
        if owner_email:
            release_data["owner"] = owner_email
        
        return await self._request("PUT", f"/products/{product_id}/releases/{release_id}", data={"release": release_data})
    
    # Initiatives methods
    
    async def list_initiatives(
        self,
        product_id: str,
        query: Optional[str] = None,
        limit: int = 25,
        page: int = 1
    ) -> Dict[str, Any]:
        """
        List initiatives for a product.
        
        Args:
            product_id: Product ID (required)
            query: Search query string
            limit: Maximum number of results
            page: Page number
        
        Returns:
            List of initiatives with pagination
        """
        params = {
            "per_page": limit,
            "page": page
        }
        
        if query:
            params["q"] = query
        
        return await self._request("GET", f"/products/{product_id}/initiatives", params=params)
    
    async def get_initiative(self, initiative_id: str, fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Get a specific initiative by ID.
        
        Args:
            initiative_id: Initiative ID or reference number
            fields: Comma-separated list of fields to include
        
        Returns:
            Initiative details
        """
        params = {}
        if fields:
            params["fields"] = fields
        
        return await self._request("GET", f"/initiatives/{initiative_id}", params=params)



