"""Aha! Model Context Protocol server package."""

__version__ = "0.1.0"
