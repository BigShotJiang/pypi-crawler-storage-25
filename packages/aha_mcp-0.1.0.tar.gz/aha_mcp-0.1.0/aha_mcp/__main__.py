"""Entry for ``python -m aha_mcp`` and the ``aha-mcp`` console script."""


def main() -> None:
    from .mcp_app import run_mcp

    run_mcp()


if __name__ == "__main__":
    main()
