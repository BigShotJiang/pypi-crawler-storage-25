# beequa-memory

Sovereign, self-improving memory for AI agents.

Your AI agent forgets everything between sessions. Provider memory (Anthropic, OpenAI, Google) creates vendor lock-in — switch models and your agent is a newborn again. **beequa-memory** is an external, model-agnostic memory layer that makes any AI agent improve with every interaction, while keeping full ownership of what it knows.

## Why

- **Your data, your server.** Memory lives in PostgreSQL on your machine (or your VPS). No cloud, no third-party data stores.
- **Model-agnostic.** Works with Claude, GPT, Gemini, Ollama, or any LLM. Switch models, keep your memory.
- **Gets smarter over time.** Frequently accessed knowledge rises in ranking (`fact_boost = log(1 + access_count)`). Unused connections decay. Like synapses.
- **Session recovery.** Pick up exactly where you left off — even after a crash — with `memory_wake`.
- **Vault sync.** Every stored memory is also a Markdown file in a directory you control.

## Quick start

```bash
pip install beequa-memory
beequa-memory up
```

That's it. PostgreSQL + the MCP server start via Docker or Podman. The server is ready at `http://localhost:8765`.

## Add to Claude Code

```json
{
  "mcpServers": {
    "beequa-memory": {
      "type": "http",
      "url": "http://localhost:8765/mcp/"
    }
  }
}
```

Or edit `~/.claude/claude_desktop_config.json` for Claude Desktop.

## Core MCP tools

| Tool | What it does |
|------|-------------|
| `memory_write` | Store a fact or note |
| `memory_search` | Hybrid search (semantic + BM25 + graph + temporal) |
| `memory_read` | Fetch a specific memory by ID (increments `access_count`) |
| `memory_wake` | Recover session state after restart/crash |
| `memory_checkpoint` | Save current work state (what you're doing, what's blocked) |
| `memory_sleep` | Clean session end — stores handoff note |
| `memory_capture` | Store an entire conversation as memories |
| `memory_reinforce` | Manually boost a memory's ranking |
| `memory_consolidate` | Trigger background graph consolidation |
| `memory_export` | Export memories to JSON or Markdown zip |
| `memory_status` | Bank stats |

## Retrieval profiles

Pass `profile` to `memory_search` to tune retrieval for your query intent:

| Profile | Use when |
|---------|----------|
| `default` | General knowledge lookup |
| `planning` | "What was I working on?" — boosts recent 72h memories |
| `temporal` | "When did X happen?" — boosts temporal retrieval |
| `entity` | "What do I know about X?" — boosts graph traversal |
| `auto` | LLM classifies the query and selects the best profile |

## CLI

```bash
# Container services (Docker or Podman)
beequa-memory up
beequa-memory down
beequa-memory logs [-f]

# Import / export
beequa-memory import --format chatgpt conversations.json --bank default
beequa-memory export --format json --bank default --output memory.json
beequa-memory export --format markdown --bank default --output vault.zip

# Inspect
beequa-memory inspect banks
beequa-memory inspect units --bank default --limit 20
beequa-memory inspect checkpoint --bank default
```

## Configuration

Copy `.env.example` and set your values:

```bash
cp .env.example .env
```

Key variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `BM_DATABASE_URL` | `postgresql://cm:cognitive@localhost/beequa_memory` | PostgreSQL connection |
| `BM_LLM_PROVIDER` | `anthropic` | LLM provider for extraction |
| `BM_LLM_MODEL` | `claude-haiku-4-5-20251001` | Model for fact extraction |
| `BM_BANK_ID` | `default` | Default memory bank |
| `BM_VAULT_DIR` | `./vault` | Markdown vault directory |
| `BM_DECAY_LAMBDA` | `0.01` | Link decay rate (per day) |
| `BM_REINFORCEMENT_ENABLED` | `true` | Enable access_count tracking |

## How memory improves over time

1. **Reinforcement:** Every search increments `access_count` on returned memories. RRF fusion applies `fact_boost = max(1.0, log(1 + access_count))` — frequently retrieved facts rank higher.

2. **Decay:** Consolidation runs `weight *= exp(-λ * days_since_access) * log(1 + access_count + 1)` on all graph links. Unused connections weaken and are pruned below threshold.

3. **Session continuity:** `memory_wake` returns your last checkpoint + memories from the past 48h + a `context_death` flag (True if the last session ended abnormally).

## Requirements

- Docker or Podman (for `beequa-memory up`)
- Python 3.11+
- An LLM API key (Anthropic, OpenAI, or Google — for fact extraction and embeddings)

## Development

```bash
git clone https://github.com/yourusername/beequa-memory
cd beequa-memory
uv pip install -e ".[local-ml]"
beequa-memory up
```

With local ML (no API key needed for embeddings):
```bash
uv pip install -e ".[local-ml]"
BM_EMBEDDINGS_PROVIDER=local beequa-memory up
```
