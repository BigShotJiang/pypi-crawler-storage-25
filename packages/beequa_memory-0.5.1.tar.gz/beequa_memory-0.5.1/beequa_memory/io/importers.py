"""Import utilities for beequa-memory."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Callable, Awaitable

logger = logging.getLogger(__name__)

_BATCH_TURNS = 10  # messages per retain call


async def import_chatgpt_json(
    path: str | Path,
    retain_fn: Callable[[dict], Awaitable[dict]],
    bank_id: str | None = None,
    progress_callback: Callable[[int, int], None] | None = None,
) -> dict:
    """
    Import a ChatGPT conversations.json export into beequa-memory.

    Args:
        path: Path to the exported conversations.json file.
        retain_fn: Async callable matching retain pipeline signature.
                   Called as: await retain_fn({"content": ..., "context": ..., "bank_id": ...})
        bank_id: Target bank; uses server default if None.
        progress_callback: Optional (current, total) progress reporter.

    Returns:
        {"conversations": int, "batches": int, "units_stored": int}
    """
    path = Path(path)
    raw = path.read_text(encoding="utf-8")
    data = json.loads(raw)

    # ChatGPT export is a list of conversation objects
    if not isinstance(data, list):
        raise ValueError(f"Expected a JSON array in {path}, got {type(data).__name__}")

    conversations = data
    total = len(conversations)
    batches_sent = 0
    units_stored = 0

    for conv_idx, conv in enumerate(conversations):
        if progress_callback:
            progress_callback(conv_idx, total)

        title = conv.get("title", f"conversation_{conv_idx}")
        mapping = conv.get("mapping", {})

        # Extract ordered messages from the mapping tree
        messages = _extract_messages(mapping)
        if not messages:
            continue

        # Batch into chunks of _BATCH_TURNS turns
        for batch_start in range(0, len(messages), _BATCH_TURNS):
            batch = messages[batch_start : batch_start + _BATCH_TURNS]
            transcript = "\n".join(
                f"{msg['role']}: {msg['content']}" for msg in batch
            )
            payload: dict = {
                "content": transcript,
                "context": f"chatgpt_import/{title}",
            }
            if bank_id:
                payload["bank_id"] = bank_id

            try:
                result = await retain_fn(payload)
                # retain returns {"units": [...]} or similar
                stored = result.get("units", [])
                units_stored += len(stored) if isinstance(stored, list) else 1
                batches_sent += 1
            except Exception as exc:
                logger.warning(
                    "Failed to retain batch %d from conversation %r: %s",
                    batches_sent,
                    title,
                    exc,
                )

    if progress_callback:
        progress_callback(total, total)

    return {
        "conversations": total,
        "batches": batches_sent,
        "units_stored": units_stored,
    }


def _extract_messages(mapping: dict) -> list[dict]:
    """
    Walk the ChatGPT conversation mapping tree and return messages in order.

    The mapping is a dict of {node_id: node} where each node has:
      - "parent": parent node_id or None
      - "message": {"author": {"role": ...}, "content": {"parts": [...]}}
    """
    if not mapping:
        return []

    # Find root (node with no parent or parent not in mapping)
    root_id = None
    for node_id, node in mapping.items():
        parent = node.get("parent")
        if parent is None or parent not in mapping:
            root_id = node_id
            break

    if root_id is None:
        return []

    # Build children map
    children: dict[str, list[str]] = {}
    for node_id, node in mapping.items():
        parent = node.get("parent")
        if parent:
            children.setdefault(parent, []).append(node_id)

    # DFS to collect messages in order (follow first child for linear conversations)
    messages = []
    stack = [root_id]
    while stack:
        node_id = stack.pop(0)
        node = mapping.get(node_id, {})
        msg = node.get("message")
        if msg:
            role = (msg.get("author") or {}).get("role", "")
            content_obj = msg.get("content") or {}
            parts = content_obj.get("parts", [])
            text = " ".join(str(p) for p in parts if p).strip()
            if role in ("user", "assistant") and text:
                messages.append({"role": role, "content": text})

        # Queue children (take first child to follow main thread)
        kids = children.get(node_id, [])
        if kids:
            stack = [kids[0]] + stack

    return messages
