"""Export utilities for beequa-memory."""

from __future__ import annotations

import io
import json
import logging
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


async def export_json(
    pool,
    bank_id: str,
    output_path: str | Path,
) -> dict:
    """
    Export all memory data for a bank to a JSON file.

    Exports: memory_units, memory_links, entities, entity_cooccurrences

    Args:
        pool: asyncpg connection pool.
        bank_id: Bank to export.
        output_path: Destination .json file path.

    Returns:
        {"units": int, "links": int, "entities": int, "path": str}
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    async with pool.acquire() as conn:
        units = await conn.fetch(
            """
            SELECT id::text, bank_id, context, fact_type, text, metadata,
                   embedding_model, access_count, last_accessed, created_at, updated_at
            FROM memory_units
            WHERE bank_id = $1
            ORDER BY created_at
            """,
            bank_id,
        )

        links = await conn.fetch(
            """
            SELECT ml.id::text, ml.from_unit_id::text, ml.to_unit_id::text,
                   ml.relation_type, ml.weight, ml.bank_id,
                   ml.access_count, ml.last_accessed, ml.created_at
            FROM memory_links ml
            JOIN memory_units mu ON ml.from_unit_id = mu.id
            WHERE mu.bank_id = $1
            ORDER BY ml.created_at
            """,
            bank_id,
        )

        # Entities (may not exist in all deployments)
        try:
            entities = await conn.fetch(
                """
                SELECT id::text, bank_id, name, entity_type, aliases, metadata, created_at
                FROM entities
                WHERE bank_id = $1
                ORDER BY name
                """,
                bank_id,
            )
        except Exception:
            entities = []

        # Entity co-occurrences
        try:
            cooccurrences = await conn.fetch(
                """
                SELECT ec.entity_id::text, ec.unit_id::text, ec.count
                FROM entity_cooccurrences ec
                JOIN memory_units mu ON ec.unit_id = mu.id
                WHERE mu.bank_id = $1
                """,
                bank_id,
            )
        except Exception:
            cooccurrences = []

    def _row(r) -> dict[str, Any]:
        d = dict(r)
        # Serialize non-JSON-native types
        for k, v in d.items():
            if isinstance(v, datetime):
                d[k] = v.isoformat()
        return d

    payload = {
        "version": "1.0",
        "exported_at": datetime.utcnow().isoformat() + "Z",
        "bank_id": bank_id,
        "memory_units": [_row(r) for r in units],
        "memory_links": [_row(r) for r in links],
        "entities": [_row(r) for r in entities],
        "entity_cooccurrences": [_row(r) for r in cooccurrences],
    }

    output_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")

    return {
        "units": len(units),
        "links": len(links),
        "entities": len(entities),
        "path": str(output_path),
    }


async def export_markdown(
    pool,
    bank_id: str,
    vault_dir: str | Path | None,
    output_path: str | Path,
) -> dict:
    """
    Export vault Markdown files (or generate them) as a zip archive.

    If vault_dir exists and contains files, zips those directly.
    Otherwise, generates Markdown from memory_units.

    Args:
        pool: asyncpg connection pool.
        bank_id: Bank to export.
        vault_dir: Optional vault directory to zip. If None, generates from DB.
        output_path: Destination .zip file path.

    Returns:
        {"files": int, "path": str}
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    vault = Path(vault_dir) if vault_dir else None
    file_count = 0

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        if vault and vault.is_dir():
            # Zip existing vault files
            for md_file in sorted(vault.rglob("*.md")):
                arcname = md_file.relative_to(vault)
                zf.write(md_file, arcname)
                file_count += 1
        else:
            # Generate Markdown from memory_units
            async with pool.acquire() as conn:
                units = await conn.fetch(
                    """
                    SELECT id::text, context, fact_type, text, metadata,
                           access_count, created_at
                    FROM memory_units
                    WHERE bank_id = $1
                    ORDER BY context, created_at
                    """,
                    bank_id,
                )

            for row in units:
                md = _unit_to_markdown(dict(row))
                ctx = (row["context"] or "general").replace("/", "_")
                filename = f"{ctx}/{row['id']}.md"
                zf.writestr(filename, md)
                file_count += 1

    output_path.write_bytes(buf.getvalue())

    return {"files": file_count, "path": str(output_path)}


def _unit_to_markdown(unit: dict[str, Any]) -> str:
    """Render a memory unit dict as a Markdown file with YAML frontmatter."""
    created = unit.get("created_at")
    if isinstance(created, datetime):
        created = created.isoformat()

    metadata = unit.get("metadata") or {}
    meta_lines = "\n".join(f"  {k}: {v}" for k, v in metadata.items())

    frontmatter = f"""\
---
id: {unit['id']}
context: {unit.get('context', '')}
fact_type: {unit.get('fact_type', '')}
access_count: {unit.get('access_count', 0)}
created_at: {created}
metadata:
{meta_lines}
---
"""
    return frontmatter + "\n" + (unit.get("text") or "") + "\n"
