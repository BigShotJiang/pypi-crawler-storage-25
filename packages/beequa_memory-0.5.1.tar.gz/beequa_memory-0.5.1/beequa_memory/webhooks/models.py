"""Webhook models stub."""
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class WebhookEventType(str, Enum):
    RETAIN = "retain"
    CONSOLIDATION = "consolidation"


@dataclass
class WebhookEvent:
    event_type: WebhookEventType
    data: Any = None


@dataclass
class RetainEventData:
    bank_id: str = ""
    unit_ids: list = field(default_factory=list)


@dataclass
class ConsolidationEventData:
    bank_id: str = ""


@dataclass
class WebhookConfig:
    pass


@dataclass
class WebhookHttpConfig:
    pass
