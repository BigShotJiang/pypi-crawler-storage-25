"""Webhooks stub — webhook system stripped from beequa-memory."""


class WebhookManager:
    """Stub webhook manager."""
    pass
