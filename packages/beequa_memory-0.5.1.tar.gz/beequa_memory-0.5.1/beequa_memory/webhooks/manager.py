"""Webhook manager stub."""
MAX_ATTEMPTS = 3
RETRY_DELAYS = [60, 300, 3600]
