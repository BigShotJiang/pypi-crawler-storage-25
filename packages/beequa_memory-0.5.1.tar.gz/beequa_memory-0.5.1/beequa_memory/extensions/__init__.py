"""Extensions stub — multi-tenant extension system stripped from beequa-memory."""


class OperationValidatorExtension:
    """Stub for operation validator extension."""
    pass


class TenantExtension:
    """Stub for tenant extension."""
    pass


class MCPExtension:
    """Stub for MCP extension."""
    pass


def load_extension(name: str, extension_class):
    """Stub extension loader — always returns None (extensions stripped)."""
    return None


class AuthenticationError(Exception):
    """Raised when authentication fails."""
    pass


class HttpExtension:
    """Stub for HTTP extension."""
    pass


class OperationValidationError(Exception):
    """Raised when an operation fails validation."""
    pass


class ExtensionContext:
    """Stub extension context."""
    pass


class DefaultExtensionContext(ExtensionContext):
    """Stub default extension context."""
    def __init__(self, **kwargs):
        pass
