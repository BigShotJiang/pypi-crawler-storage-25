"""Tenant extension stub — multi-tenancy stripped from beequa-memory."""


class AuthenticationError(Exception):
    """Raised when MCP authentication fails."""
    pass
