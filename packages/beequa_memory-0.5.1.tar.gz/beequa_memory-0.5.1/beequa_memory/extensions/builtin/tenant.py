"""Default tenant extension stub."""


class DefaultTenantExtension:
    """Stub default tenant extension."""
    pass
