"""
beequa-memory connect — interactive wizard to link beequa-memory to an agent system.

Supported agent systems: Tomclaw, OpenClaw.

Usage:
    beequa-memory connect
    beequa-memory connect --agent tomclaw
    beequa-memory connect --agent openclaw --no-patch-config --no-restart
"""

from __future__ import annotations

import json
import os
import sys
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Driver base class
# ---------------------------------------------------------------------------


class ConnectDriver(ABC):
    """Abstract base class for agent-system integration drivers."""

    name: str = ""
    description: str = ""
    default_network: str = ""

    @abstractmethod
    def detect(self) -> bool:
        """Return True if this agent system appears to be installed on this host."""
        ...

    @abstractmethod
    def get_config_path(self) -> Optional[Path]:
        """Return the resolved config file path, or None if not applicable."""
        ...

    @abstractmethod
    def patch_config(self, config_path: Path, mcp_url: str) -> bool:
        """Write the MCP URL into the agent system's config file.

        Returns True if a change was made, False if already correct.
        """
        ...

    @abstractmethod
    def next_steps(self, mcp_url: str) -> str:
        """Return a human-readable message with instructions for the user."""
        ...

    def verify(self, mcp_url: str) -> bool:
        """Check that the MCP server is reachable from this host."""
        try:
            import httpx
            r = httpx.get(mcp_url.rstrip("/").rstrip("mcp").rstrip("/") + "/health", timeout=5)
            return r.status_code == 200
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Tomclaw driver
# ---------------------------------------------------------------------------


class TomclawDriver(ConnectDriver):
    name = "Tomclaw"
    description = "Multi-agent container orchestration system"
    default_network = "tomclaw_default"

    def detect(self) -> bool:
        tomclaw_dir = Path.home() / "tomclaw"
        return (tomclaw_dir / "docker-compose.yml").exists() or (tomclaw_dir / ".env").exists()

    def get_config_path(self) -> Optional[Path]:
        return Path.home() / "tomclaw" / ".env"

    def patch_config(self, config_path: Path, mcp_url: str) -> bool:
        """Add/update BM_MCP_URL and COGNITIVE_MEMORY_ENABLED in Tomclaw's .env file."""
        lines: list[str] = []
        if config_path.exists():
            lines = config_path.read_text().splitlines()

        changes: dict[str, str] = {
            "BM_MCP_URL": mcp_url,
            "COGNITIVE_MEMORY_ENABLED": "true",
        }

        updated_keys: set[str] = set()
        new_lines: list[str] = []
        changed = False

        for line in lines:
            stripped = line.strip()
            if "=" in stripped and not stripped.startswith("#"):
                key = stripped.split("=", 1)[0].strip()
                if key in changes:
                    new_val = f"{key}={changes[key]}"
                    if line.strip() != new_val:
                        new_lines.append(new_val)
                        changed = True
                    else:
                        new_lines.append(line)
                    updated_keys.add(key)
                    continue
            new_lines.append(line)

        # Append any keys that weren't found
        for key, val in changes.items():
            if key not in updated_keys:
                new_lines.append(f"{key}={val}")
                changed = True

        if changed:
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text("\n".join(new_lines) + "\n")

        return changed

    def next_steps(self, mcp_url: str) -> str:
        return (
            f"\nNext steps for Tomclaw:\n"
            f"  1. Restart Tomclaw:  cd ~/tomclaw && docker compose up -d\n"
            f"  2. Verify from a Tomclaw container:\n"
            f"     docker exec <container> curl -sf http://beequa-memory:8765/health\n"
            f"  3. MCP URL to use inside Tomclaw: http://beequa-memory:8765/mcp/\n"
        )


# ---------------------------------------------------------------------------
# OpenClaw driver
# ---------------------------------------------------------------------------


class OpenClawDriver(ConnectDriver):
    name = "OpenClaw"
    description = "ClawhHub-based agent platform"
    default_network = "openclaw_default"

    def detect(self) -> bool:
        openclaw_dir = Path.home() / ".openclaw"
        return openclaw_dir.exists() or (Path.home() / ".openclaw" / "config.json").exists()

    def get_config_path(self) -> Optional[Path]:
        return Path.home() / ".openclaw" / "config.json"

    def patch_config(self, config_path: Path, mcp_url: str) -> bool:
        """Merge MCP server entry into OpenClaw's config.json."""
        cfg: dict = {}
        if config_path.exists():
            try:
                cfg = json.loads(config_path.read_text())
            except json.JSONDecodeError:
                print(f"  Warning: could not parse {config_path} — will create new entry.")

        mcp_servers = cfg.setdefault("mcpServers", {})
        existing = mcp_servers.get("beequa-memory", {})
        desired = {"type": "http", "url": mcp_url}

        if existing == desired:
            return False

        mcp_servers["beequa-memory"] = desired
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(json.dumps(cfg, indent=2) + "\n")
        return True

    def next_steps(self, mcp_url: str) -> str:
        return (
            f"\nNext steps for OpenClaw:\n"
            f"  1. Restart OpenClaw agents so they pick up the new MCP config.\n"
            f"  2. MCP URL inside the OpenClaw network: http://beequa-memory:8765/mcp/\n"
            f"  3. MCP config written to: {self.get_config_path()}\n"
        )


# ---------------------------------------------------------------------------
# Docker Compose patcher
# ---------------------------------------------------------------------------


def _locate_compose_file() -> Optional[Path]:
    for candidate in [
        Path(__file__).parent.parent / "docker-compose.yml",
        Path.cwd() / "docker-compose.yml",
    ]:
        if candidate.exists():
            return candidate
    return None


def _patch_compose(compose_file: Path, network_name: str) -> bool:
    """Add network_name to docker-compose.yml.

    Returns True if the file was modified, False if the network was already present.
    """
    import yaml  # pyyaml is in dependencies

    content = compose_file.read_text()
    cfg = yaml.safe_load(content)

    # Check if already patched
    svc_networks = cfg.get("services", {}).get("beequa-memory", {}).get("networks", [])
    if isinstance(svc_networks, list) and network_name in svc_networks:
        return False
    if isinstance(svc_networks, dict) and network_name in svc_networks:
        return False

    # Write backup first
    backup = compose_file.with_suffix(".yml.bak")
    backup.write_text(content)

    # Patch services.beequa-memory.networks
    services = cfg.setdefault("services", {})
    bm_service = services.setdefault("beequa-memory", {})
    existing = bm_service.get("networks", [])
    if isinstance(existing, dict):
        existing[network_name] = None
        bm_service["networks"] = existing
    else:
        if not isinstance(existing, list):
            existing = []
        if network_name not in existing:
            existing.append(network_name)
        bm_service["networks"] = existing

    # Patch top-level networks
    top_networks = cfg.setdefault("networks", {})
    if network_name not in top_networks:
        top_networks[network_name] = {"external": True}

    compose_file.write_text(yaml.dump(cfg, default_flow_style=False, sort_keys=False))
    return True


# ---------------------------------------------------------------------------
# Wizard
# ---------------------------------------------------------------------------


def _prompt(msg: str, default: str = "") -> str:
    """Read a line from stdin, returning default on empty input."""
    try:
        val = input(msg).strip()
        return val if val else default
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(0)


def _confirm(msg: str, default: bool = True) -> bool:
    hint = "[Y/n]" if default else "[y/N]"
    raw = _prompt(f"{msg} {hint}: ").lower()
    if not raw:
        return default
    return raw.startswith("y")


def _cmd_connect(args: list[str] | None = None) -> None:
    """Interactive wizard: connect beequa-memory to an agent system."""
    import argparse as _ap

    p = _ap.ArgumentParser(prog="beequa-memory connect")
    p.add_argument("--agent", choices=["tomclaw", "openclaw"], help="Agent system to connect (skip prompt)")
    p.add_argument("--no-patch-config", action="store_true", help="Skip patching the agent system's config file")
    p.add_argument("--no-restart", action="store_true", help="Skip restarting beequa-memory after patching compose")
    p.add_argument("--mcp-url", default="http://localhost:8765/mcp/", help="MCP URL (default: http://localhost:8765/mcp/)")
    opts = p.parse_args(args or [])

    mcp_url = opts.mcp_url
    runtime = _get_container_runtime()

    print("\nbeequa-memory connect\n" + "=" * 40)

    # Step 1 — verify server is running
    print("\nChecking beequa-memory server...", end=" ", flush=True)
    try:
        import httpx
        r = httpx.get("http://localhost:8765/health", timeout=5)
        if r.status_code != 200:
            raise ValueError(f"HTTP {r.status_code}")
        print("running")
    except Exception:
        print("not reachable")
        print("\nError: beequa-memory is not running.")
        print("Start it first with:  beequa-memory up")
        sys.exit(1)

    # Step 2 — select driver
    drivers: list[ConnectDriver] = [TomclawDriver(), OpenClawDriver()]

    if opts.agent:
        driver = next((d for d in drivers if d.name.lower() == opts.agent), None)
        if driver is None:
            print(f"Error: unknown agent '{opts.agent}'")
            sys.exit(1)
    else:
        print("\nWhich agent system do you want to connect?\n")
        for i, d in enumerate(drivers, 1):
            status = "(detected)" if d.detect() else "(not detected)"
            print(f"  [{i}] {d.name} — {d.description} {status}")
        print()
        choice = _prompt(f"Select [1-{len(drivers)}]: ", default="1")
        try:
            idx = int(choice) - 1
            driver = drivers[idx]
        except (ValueError, IndexError):
            print("Invalid selection.")
            sys.exit(1)

    print(f"\nConnecting to {driver.name}...")

    # Step 3 — determine network name
    network_name = _prompt(
        f"\nDocker network name [{driver.default_network}]: ",
        default=driver.default_network,
    )

    # Step 4 — locate and patch docker-compose.yml
    compose_file = _locate_compose_file()
    if compose_file is None:
        print("Error: docker-compose.yml not found. Run from the beequa-memory project directory.")
        sys.exit(1)

    print(f"\nPatching {compose_file}...", end=" ", flush=True)
    try:
        patched = _patch_compose(compose_file, network_name)
        if patched:
            print(f"done  (backup: {compose_file.with_suffix('.yml.bak')})")
        else:
            print(f"skipped (network '{network_name}' already present)")
    except Exception as exc:
        print(f"failed: {exc}")
        sys.exit(1)

    # Step 5 — patch agent config
    if not opts.no_patch_config:
        config_path = driver.get_config_path()
        if config_path is None:
            print(f"\nNote: {driver.name} does not have a patchable config file.")
        else:
            if _confirm(f"\nPatch {config_path} to add MCP URL?"):
                print(f"Patching {config_path}...", end=" ", flush=True)
                try:
                    changed = driver.patch_config(config_path, mcp_url)
                    print("updated" if changed else "already correct")
                except Exception as exc:
                    print(f"failed: {exc}")

    # Step 6 — restart containers
    if not opts.no_restart and patched:
        if runtime is None:
            print("\nWarning: no container runtime found. Restart manually.")
        elif _confirm("\nRestart beequa-memory to apply network change?"):
            import subprocess
            print("Restarting...", end=" ", flush=True)
            result = subprocess.run(
                [runtime, "compose", "-f", str(compose_file), "up", "-d", "--no-build"],
                capture_output=True,
            )
            if result.returncode == 0:
                print("done")
                # Wait for health
                print("Waiting for beequa-memory to be ready", end="", flush=True)
                for _ in range(15):
                    try:
                        r = httpx.get("http://localhost:8765/health", timeout=2)
                        if r.status_code == 200:
                            print(" ready")
                            break
                    except Exception:
                        pass
                    print(".", end="", flush=True)
                    time.sleep(2)
                else:
                    print("\nTimeout: check logs with: beequa-memory logs")
            else:
                print("failed")
                print(result.stderr.decode())

    # Step 7 — verify connectivity
    print("\nVerifying connectivity...", end=" ", flush=True)
    ok = driver.verify(mcp_url)
    print("OK" if ok else "FAILED (server may still be starting)")

    # Step 8 — next steps
    print(driver.next_steps(mcp_url))

    # Summary
    print("=" * 40)
    print(f"beequa-memory <-> {driver.name} connection configured.")
    print(f"MCP URL: {mcp_url}")
    print(f"Network: {network_name}")
    if not ok:
        print("\nNote: connectivity check failed. Ensure the agent network exists and try restarting.")
    print()


def _get_container_runtime() -> Optional[str]:
    import shutil
    override = (os.environ.get("BM_CONTAINER_RUNTIME") or "").strip().lower()
    if override in ("docker", "podman") and shutil.which(override):
        return override
    return "podman" if shutil.which("podman") else "docker" if shutil.which("docker") else None
