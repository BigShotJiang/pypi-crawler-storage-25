"""
Session lifecycle for beequa-memory.

Provides wake / checkpoint / sleep primitives so agents can recover from
context resets (crashed sessions, context window exhaustion, restarts).

Usage pattern:
    # At session start
    ctx = await SessionLifecycle.wake(pool, bank_id)
    # → returns last checkpoint, recent memories, context_death flag

    # During work (before risky operations, on topic changes)
    await SessionLifecycle.checkpoint(pool, bank_id, working_on="...", focus="...")

    # At clean session end
    await SessionLifecycle.sleep(pool, bank_id, retain_fn, summary="...")
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import asyncpg

logger = logging.getLogger(__name__)


class SessionLifecycle:
    """Static methods for session lifecycle management."""

    @staticmethod
    async def wake(pool: asyncpg.Pool, bank_id: str) -> dict[str, Any]:
        """
        Recover session context after a restart or crash.

        Returns:
            {
                "last_checkpoint": dict | None,   # last saved checkpoint
                "recent_units": list[dict],        # memory units from last 48h
                "context_death": bool,             # True if previous session ended abnormally
            }
        """
        async with pool.acquire() as conn:
            # Last checkpoint for this bank
            row = await conn.fetchrow(
                """
                SELECT id, working_on, focus, blocked, session_key, created_at
                FROM checkpoints
                WHERE bank_id = $1
                ORDER BY created_at DESC
                LIMIT 1
                """,
                bank_id,
            )

            last_checkpoint = None
            context_death = False
            if row:
                last_checkpoint = dict(row)
                last_checkpoint["id"] = str(last_checkpoint["id"])
                last_checkpoint["created_at"] = last_checkpoint["created_at"].isoformat()
                # context_death if the last session didn't end cleanly
                context_death = row["session_key"] != "sleep"

            # Recent memory units from last 48h (recency-weighted)
            recent_rows = await conn.fetch(
                """
                SELECT id, text, context, fact_type, confidence_score,
                       mentioned_at, created_at, access_count
                FROM memory_units
                WHERE bank_id = $1
                  AND mentioned_at > NOW() - INTERVAL '48 hours'
                ORDER BY mentioned_at DESC
                LIMIT 20
                """,
                bank_id,
            )

            recent_units = []
            for r in recent_rows:
                unit = dict(r)
                unit["id"] = str(unit["id"])
                if unit.get("mentioned_at"):
                    unit["mentioned_at"] = unit["mentioned_at"].isoformat()
                if unit.get("created_at"):
                    unit["created_at"] = unit["created_at"].isoformat()
                recent_units.append(unit)

        return {
            "last_checkpoint": last_checkpoint,
            "recent_units": recent_units,
            "context_death": context_death,
        }

    @staticmethod
    async def checkpoint(
        pool: asyncpg.Pool,
        bank_id: str,
        working_on: str | None = None,
        focus: str | None = None,
        blocked: str | None = None,
        session_key: str | None = None,
    ) -> str:
        """
        Save current working state.

        Returns:
            str: UUID of the created checkpoint record.
        """
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO checkpoints (bank_id, working_on, focus, blocked, session_key)
                VALUES ($1, $2, $3, $4, $5)
                RETURNING id
                """,
                bank_id,
                working_on,
                focus,
                blocked,
                session_key,
            )
            checkpoint_id = str(row["id"])

        logger.debug("Checkpoint saved for bank %s: %s", bank_id, checkpoint_id)
        return checkpoint_id

    @staticmethod
    async def sleep(
        pool: asyncpg.Pool,
        bank_id: str,
        retain_fn,
        summary: str,
        next_steps: str | None = None,
        blockers: str | None = None,
    ) -> str:
        """
        Clean session end — store handoff memory + mark session as cleanly closed.

        Args:
            pool: asyncpg connection pool
            bank_id: memory bank scope
            retain_fn: async callable(content_dict, bank_id) → retains a memory unit
            summary: what was accomplished this session
            next_steps: optional next actions
            blockers: optional current blockers

        Returns:
            str: UUID of the sleep checkpoint record.
        """
        # Build handoff note content
        parts = [f"Session summary: {summary}"]
        if next_steps:
            parts.append(f"Next steps: {next_steps}")
        if blockers:
            parts.append(f"Blockers: {blockers}")
        handoff_text = "\n".join(parts)

        # Store as an experience memory unit via the retain pipeline
        try:
            await retain_fn(
                {
                    "content": handoff_text,
                    "context": "session_handoff",
                    "metadata": {
                        "type": "session_handoff",
                        "next_steps": next_steps,
                        "blockers": blockers,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    },
                },
                bank_id=bank_id,
            )
        except Exception as exc:
            logger.warning("Failed to retain handoff note during sleep: %s", exc)

        # Mark session as cleanly closed
        checkpoint_id = await SessionLifecycle.checkpoint(
            pool=pool,
            bank_id=bank_id,
            working_on=summary[:200] if summary else None,
            session_key="sleep",
        )
        logger.info("Clean sleep checkpoint saved for bank %s: %s", bank_id, checkpoint_id)
        return checkpoint_id
