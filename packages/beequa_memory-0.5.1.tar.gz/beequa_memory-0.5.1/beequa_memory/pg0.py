"""pg0 embedded PostgreSQL stub — not supported in beequa-memory.
Use `beequa-memory up` (Docker Compose) or pass BM_DATABASE_URL directly.
"""


class EmbeddedPostgres:
    """Stub — pg0 embedded PostgreSQL is not supported."""
    pass


def parse_pg0_url(db_url: str) -> tuple:
    """Parse pg0:// URLs. Always returns (False, None, None) since pg0 is not supported."""
    if db_url and db_url.startswith("pg0"):
        raise RuntimeError(
            "pg0 embedded PostgreSQL is not supported in beequa-memory. "
            "Use `beequa-memory up` (Docker Compose) or set BM_DATABASE_URL "
            "to a PostgreSQL connection string."
        )
    return False, None, None
