"""Reflect pipeline stub — deprioritized for v1 of beequa-memory."""


async def run_reflect_agent(*args, **kwargs):
    """Stub — reflect pipeline is not enabled in v1."""
    raise NotImplementedError("Reflect pipeline is not enabled in beequa-memory v1.")
