"""Reflect tools stub."""


async def tool_expand(*args, **kwargs):
    raise NotImplementedError("Reflect pipeline not enabled.")


async def tool_recall(*args, **kwargs):
    raise NotImplementedError("Reflect pipeline not enabled.")


async def tool_search_mental_models(*args, **kwargs):
    raise NotImplementedError("Reflect pipeline not enabled.")


async def tool_search_observations(*args, **kwargs):
    raise NotImplementedError("Reflect pipeline not enabled.")
