"""Reflect observations stub."""
from dataclasses import dataclass


@dataclass
class ObservationEvidence:
    pass


@dataclass
class Observation:
    pass
