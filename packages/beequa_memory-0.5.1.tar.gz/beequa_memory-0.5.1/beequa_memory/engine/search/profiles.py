"""
Retrieval profiles for beequa-memory.

A profile bundles retrieval weights and recency preferences so that
memory_search can adapt to the query intent without requiring the caller
to tune individual parameters.

Profiles:
    default  — balanced weights, good for general queries
    planning — boosts recent memories (last 72 h); useful for task continuity
    temporal — boosts temporal retrieval; useful for timeline queries
    entity   — boosts graph/entity traversal; useful for "what do I know about X?"
    auto     — LLM classifies query intent and selects the best profile

Usage in recall():
    from .profiles import get_profile, PROFILES
    profile = get_profile(profile_name, query=query_text, llm=llm)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class RetrievalProfile:
    """Weights and settings for a single retrieval profile."""

    name: str

    # RRF source weights (multiplied into the per-source rank score before fusion)
    semantic_weight: float = 1.0
    bm25_weight: float = 1.0
    graph_weight: float = 1.0
    temporal_weight: float = 1.0

    # Recency bias: fraction of score to come from recency (0 = off, 1 = full recency)
    recency_alpha: float = 0.2

    # If set, retrieval prefers memories from within this many hours
    prefer_recent_hours: int | None = None

    def __str__(self) -> str:
        return (
            f"RetrievalProfile(name={self.name!r}, "
            f"sem={self.semantic_weight}, bm25={self.bm25_weight}, "
            f"graph={self.graph_weight}, temporal={self.temporal_weight})"
        )


PROFILES: dict[str, RetrievalProfile | None] = {
    # Balanced — default for most queries
    "default": RetrievalProfile("default"),

    # Recency-weighted — good for "what was I working on?", "continue from where I left off"
    "planning": RetrievalProfile(
        name="planning",
        recency_alpha=0.5,
        prefer_recent_hours=72,
    ),

    # Temporal-heavy — good for "when did X happen?", "what changed between A and B?"
    "temporal": RetrievalProfile(
        name="temporal",
        temporal_weight=2.0,
        recency_alpha=0.3,
    ),

    # Entity/graph-heavy — good for "what do I know about <person/project/concept>?"
    "entity": RetrievalProfile(
        name="entity",
        graph_weight=2.0,
        semantic_weight=0.8,
    ),

    # Auto: LLM classifies query intent → select profile at runtime
    # get_profile() handles this case specially
    "auto": None,
}

_INTENT_PROMPT = """\
Classify this memory query into one of four retrieval profiles.
Reply with exactly one word: default, planning, temporal, or entity.

- default: general knowledge lookup
- planning: recent task state, what was I working on, continue session
- temporal: when did X happen, timeline, before/after, recent changes
- entity: who is X, what do I know about Y, relationship between Z and W

Query: {query}
Profile:"""


async def _classify_intent(query: str, llm) -> str:
    """Use LLM to classify query intent into a profile name."""
    try:
        prompt = _INTENT_PROMPT.format(query=query)
        response = await llm.complete(prompt, max_tokens=5)
        word = response.strip().lower().split()[0]
        if word in PROFILES and word != "auto":
            return word
    except Exception as exc:
        logger.debug("Profile intent classification failed: %s", exc)
    return "default"


def get_profile(
    name: str | None,
    query: str = "",
    llm=None,
) -> RetrievalProfile:
    """
    Resolve a profile name to a RetrievalProfile.

    For 'auto', attempts LLM classification (sync wrapper returns default;
    use get_profile_async for async contexts).

    Returns default profile for unknown names.
    """
    name = (name or "default").lower()
    profile = PROFILES.get(name)
    if profile is not None:
        return profile
    # auto or unknown → default
    return PROFILES["default"]  # type: ignore[return-value]


async def get_profile_async(
    name: str | None,
    query: str = "",
    llm=None,
) -> RetrievalProfile:
    """
    Resolve a profile name to a RetrievalProfile (async version for 'auto').

    For 'auto', calls the LLM to classify the query intent.
    """
    name = (name or "default").lower()
    if name == "auto":
        if llm is not None and query:
            resolved = await _classify_intent(query, llm)
            profile = PROFILES.get(resolved)
            if profile is not None:
                return profile
        return PROFILES["default"]  # type: ignore[return-value]

    profile = PROFILES.get(name)
    if profile is not None:
        return profile
    return PROFILES["default"]  # type: ignore[return-value]
