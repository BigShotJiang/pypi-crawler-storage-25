"""
Markdown vault sync for beequa-memory.

VaultSync keeps a directory of Markdown files in sync with the PostgreSQL
memory_units table. Every stored memory unit gets a corresponding .md file
with YAML frontmatter. Human edits to the vault (e.g., in Obsidian) are
detected on startup via SHA-256 content hash comparison and re-ingested.

File layout:
    vault/
    ├── world/          # fact_type = 'world'
    ├── experience/     # fact_type = 'experience'
    ├── observation/    # fact_type = 'observation'
    └── session_handoff/

File format:
    ---
    id: <uuid>
    bank_id: <bank_id>
    fact_type: world
    context: <context>
    confidence: 0.9
    created_at: 2026-03-26T12:00:00+00:00
    tags: []
    ---

    <memory text>

    <!-- wikilinks: [[EntityA]] [[EntityB]] -->
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
from pathlib import Path
from typing import Any

import asyncpg

logger = logging.getLogger(__name__)

try:
    import frontmatter as fm
    HAS_FRONTMATTER = True
except ImportError:
    HAS_FRONTMATTER = False
    logger.warning(
        "python-frontmatter not installed — vault sync will use basic YAML parsing. "
        "Install with: pip install python-frontmatter"
    )


def _compute_hash(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _slug(text: str, max_len: int = 60) -> str:
    """Create a filesystem-safe slug from text."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", "-", text)
    text = text.strip("-")
    return text[:max_len] or "memory"


def _unit_to_markdown(
    unit_id: str,
    text: str,
    context: str | None,
    fact_type: str,
    bank_id: str,
    metadata: dict,
) -> str:
    """Render a memory unit as a Markdown file with YAML frontmatter."""
    import yaml

    front = {
        "id": unit_id,
        "bank_id": bank_id,
        "fact_type": fact_type,
        "context": context or "",
        "confidence": metadata.get("confidence_score"),
        "created_at": metadata.get("created_at", ""),
        "tags": metadata.get("tags", []),
    }
    # Remove None values for cleaner output
    front = {k: v for k, v in front.items() if v is not None}

    yaml_block = yaml.dump(front, allow_unicode=True, default_flow_style=False).strip()

    # Extract entity mentions for wikilinks
    entities = metadata.get("entities", [])
    wikilinks = " ".join(f"[[{e}]]" for e in entities) if entities else ""
    wikilinks_line = f"\n<!-- wikilinks: {wikilinks} -->" if wikilinks else ""

    return f"---\n{yaml_block}\n---\n\n{text}{wikilinks_line}\n"


def _parse_markdown(path: Path) -> dict | None:
    """Parse a vault Markdown file and return unit fields."""
    if not path.exists():
        return None
    content = path.read_text(encoding="utf-8")

    if HAS_FRONTMATTER:
        try:
            post = fm.loads(content)
            meta = post.metadata
            body = post.content.strip()
            return {
                "id": meta.get("id"),
                "bank_id": meta.get("bank_id"),
                "fact_type": meta.get("fact_type", "world"),
                "context": meta.get("context"),
                "confidence_score": meta.get("confidence"),
                "text": body,
                "tags": meta.get("tags", []),
            }
        except Exception as exc:
            logger.warning("Failed to parse frontmatter in %s: %s", path, exc)
            return None
    else:
        # Fallback: basic regex parse
        match = re.match(r"^---\n(.*?)\n---\n(.*)", content, re.DOTALL)
        if not match:
            return None
        import yaml
        try:
            meta = yaml.safe_load(match.group(1))
            body = match.group(2).strip()
            return {
                "id": meta.get("id"),
                "bank_id": meta.get("bank_id"),
                "fact_type": meta.get("fact_type", "world"),
                "context": meta.get("context"),
                "confidence_score": meta.get("confidence"),
                "text": body,
                "tags": meta.get("tags", []),
            }
        except Exception as exc:
            logger.warning("Failed to parse YAML in %s: %s", path, exc)
            return None


class VaultSync:
    """
    Bidirectional sync between PostgreSQL memory_units and Markdown vault files.

    Write path (PostgreSQL → Markdown):
        vault_sync.write_unit(unit_id, text, context, fact_type, bank_id, metadata)

    Startup sync (Markdown → PostgreSQL, best-effort):
        await vault_sync.sync_from_disk(retain_fn)
    """

    def __init__(self, vault_dir: str | Path, pool: asyncpg.Pool, bank_id: str):
        self.vault_dir = Path(vault_dir)
        self.pool = pool
        self.bank_id = bank_id
        self.vault_dir.mkdir(parents=True, exist_ok=True)

    def write_unit(
        self,
        unit_id: str,
        text: str,
        context: str | None,
        fact_type: str,
        metadata: dict | None = None,
    ) -> Path:
        """
        Write a memory unit to the Markdown vault.

        Creates the file and schedules a vault_files upsert (sync via
        sync_record_written for the async path).

        Returns the path of the written file.
        """
        metadata = metadata or {}
        subdir = self.vault_dir / (context or fact_type or "world")
        subdir.mkdir(parents=True, exist_ok=True)

        # Use first 60 chars of text as slug
        filename = f"{_slug(text[:80])}.md"
        path = subdir / filename

        content = _unit_to_markdown(
            unit_id=unit_id,
            text=text,
            context=context,
            fact_type=fact_type,
            bank_id=self.bank_id,
            metadata=metadata,
        )
        path.write_text(content, encoding="utf-8")
        return path

    async def record_written(self, unit_id: str, path: Path) -> None:
        """Insert/update the vault_files tracking row after writing a file."""
        content = path.read_text(encoding="utf-8")
        content_hash = _compute_hash(content)
        mtime = path.stat().st_mtime
        str_path = str(path)

        async with self.pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO vault_files (path, content_hash, unit_id, bank_id, mtime)
                VALUES ($1, $2, $3, $4, $5)
                ON CONFLICT (path) DO UPDATE
                    SET content_hash = EXCLUDED.content_hash,
                        unit_id = EXCLUDED.unit_id,
                        mtime = EXCLUDED.mtime
                """,
                str_path,
                content_hash,
                unit_id,
                self.bank_id,
                mtime,
            )

    async def sync_from_disk(self, retain_fn) -> dict[str, int]:
        """
        Scan vault directory and re-ingest Markdown files changed since last sync.

        Compares SHA-256 hash of each file against vault_files.content_hash.
        Changed files are passed through the retain pipeline so facts/entities
        are extracted and stored.

        Args:
            retain_fn: async callable(content_dict, bank_id) from the retain pipeline

        Returns:
            {"scanned": N, "ingested": N, "errors": N}
        """
        stats = {"scanned": 0, "ingested": 0, "errors": 0}

        # Load all known hashes for this bank from DB
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT path, content_hash FROM vault_files WHERE bank_id = $1",
                self.bank_id,
            )
        known_hashes: dict[str, str] = {r["path"]: r["content_hash"] for r in rows}

        for root, _dirs, files in os.walk(self.vault_dir):
            for filename in files:
                if not filename.endswith(".md"):
                    continue
                path = Path(root) / filename
                stats["scanned"] += 1

                try:
                    content = path.read_text(encoding="utf-8")
                    current_hash = _compute_hash(content)
                    str_path = str(path)

                    if known_hashes.get(str_path) == current_hash:
                        continue  # unchanged, skip

                    # Parse frontmatter to get text and metadata
                    parsed = _parse_markdown(path)
                    if not parsed or not parsed.get("text"):
                        continue

                    # Skip if unit_id already exists in DB (only re-ingest external edits)
                    if parsed.get("id"):
                        async with self.pool.acquire() as conn:
                            exists = await conn.fetchval(
                                "SELECT 1 FROM memory_units WHERE id = $1::uuid AND bank_id = $2",
                                parsed["id"],
                                self.bank_id,
                            )
                        if not exists:
                            # Unit was deleted from DB; skip (human-deleted)
                            continue

                    # Re-ingest changed file via retain pipeline
                    await retain_fn(
                        {
                            "content": parsed["text"],
                            "context": parsed.get("context"),
                            "metadata": {"source": "vault_sync", "vault_path": str_path},
                        },
                        bank_id=self.bank_id,
                    )

                    # Update hash record
                    mtime = path.stat().st_mtime
                    async with self.pool.acquire() as conn:
                        await conn.execute(
                            """
                            INSERT INTO vault_files (path, content_hash, unit_id, bank_id, mtime)
                            VALUES ($1, $2, $3, $4, $5)
                            ON CONFLICT (path) DO UPDATE
                                SET content_hash = EXCLUDED.content_hash,
                                    mtime = EXCLUDED.mtime
                            """,
                            str_path,
                            current_hash,
                            None,
                            self.bank_id,
                            mtime,
                        )
                    stats["ingested"] += 1

                except Exception as exc:
                    logger.warning("Vault sync error for %s: %s", path, exc)
                    stats["errors"] += 1

        if stats["ingested"] or stats["errors"]:
            logger.info(
                "Vault sync complete for bank %s: scanned=%d ingested=%d errors=%d",
                self.bank_id,
                stats["scanned"],
                stats["ingested"],
                stats["errors"],
            )
        return stats
