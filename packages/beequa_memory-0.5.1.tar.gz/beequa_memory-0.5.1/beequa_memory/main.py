"""
Command-line interface for beequa-memory.

Start the server:
    beequa-memory

Start with Docker/Podman Compose (PostgreSQL + MCP server):
    beequa-memory up

Stop container services:
    beequa-memory down

View logs:
    beequa-memory logs

Connect to an agent system (Tomclaw, OpenClaw):
    beequa-memory connect
"""

import argparse
import asyncio
import atexit
import dataclasses
import logging
import os
import signal
import sys
import warnings

import uvicorn

from . import MemoryEngine, __version__
from .api import create_app
from .banner import print_banner
from .config import DEFAULT_WORKERS, ENV_WORKERS, HindsightConfig, _get_raw_config
from .daemon import (
    DEFAULT_DAEMON_PORT,
    DEFAULT_IDLE_TIMEOUT,
    IdleTimeoutMiddleware,
    daemonize,
)
from .extensions import DefaultExtensionContext, OperationValidatorExtension, TenantExtension, load_extension

# Filter deprecation warnings from third-party libraries
warnings.filterwarnings("ignore", message="websockets.legacy is deprecated")
warnings.filterwarnings("ignore", message="websockets.server.WebSocketServerProtocol is deprecated")

# Disable tokenizers parallelism to avoid warnings
os.environ["TOKENIZERS_PARALLELISM"] = "false"

# Global reference for cleanup
_memory: MemoryEngine | None = None


def _cleanup():
    """Synchronous cleanup function to stop resources on exit."""
    global _memory
    if _memory is not None and _memory._pg0 is not None:
        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(_memory._pg0.stop())
            loop.close()
            print("\npg0 stopped.")
        except Exception as e:
            print(f"\nError stopping pg0: {e}")


def _signal_handler(signum, frame):
    """Handle SIGINT/SIGTERM to ensure cleanup."""
    print(f"\nReceived signal {signum}, shutting down...")
    _cleanup()
    sys.exit(0)


def _get_container_runtime() -> str | None:
    """Return container CLI for compose: podman or docker.

    Set BM_CONTAINER_RUNTIME=docker or BM_CONTAINER_RUNTIME=podman to override
    auto-detection (podman is preferred when both are installed).
    """
    import shutil

    override = (os.environ.get("BM_CONTAINER_RUNTIME") or "").strip().lower()
    if override in ("docker", "podman"):
        if shutil.which(override):
            return override
        print(
            f"Warning: BM_CONTAINER_RUNTIME={override!r} not found in PATH; "
            "falling back to auto-detection.",
            file=sys.stderr,
        )
    return "podman" if shutil.which("podman") else "docker" if shutil.which("docker") else None


def _cmd_up(args=None) -> None:
    """Start PostgreSQL + beequa-memory via Docker Compose."""
    import subprocess
    import time
    from pathlib import Path

    # Locate docker-compose.yml: check repo root first, then package dir
    compose_file = None
    for candidate in [
        Path(__file__).parent.parent / "docker-compose.yml",
        Path.cwd() / "docker-compose.yml",
    ]:
        if candidate.exists():
            compose_file = candidate
            break

    if compose_file is None:
        print("Error: docker-compose.yml not found. Run from the beequa-memory project directory.")
        sys.exit(1)

    runtime = _get_container_runtime()
    if runtime is None:
        print("Error: neither podman nor docker found. Install one to use `beequa-memory up`.")
        sys.exit(1)

    vault_dir = os.environ.get("BM_VAULT_DIR", "./vault")
    Path(vault_dir).mkdir(parents=True, exist_ok=True)

    build = "--no-build" not in (args or [])
    cmd = [runtime, "compose", "-f", str(compose_file), "up", "-d"]
    print(f"Starting beequa-memory ({compose_file})...")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        sys.exit(result.returncode)

    # Poll health endpoint
    print("Waiting for beequa-memory to be ready", end="", flush=True)
    try:
        import httpx
        for _ in range(30):
            try:
                r = httpx.get("http://localhost:8765/health", timeout=2)
                if r.status_code == 200:
                    print("\nbeequa-memory is ready.")
                    print("MCP endpoint: http://localhost:8765/mcp/")
                    print("API docs:     http://localhost:8765/docs")
                    return
            except Exception:
                pass
            print(".", end="", flush=True)
            time.sleep(2)
        print("\nTimeout: service may still be starting. Check logs with: beequa-memory logs")
    except ImportError:
        print("\nService started. Install httpx for readiness checking.")


def _cmd_down(args=None) -> None:
    """Stop Docker/Podman Compose services."""
    import subprocess
    from pathlib import Path

    runtime = _get_container_runtime()
    if runtime is None:
        print("Error: neither podman nor docker found.")
        sys.exit(1)

    for candidate in [
        Path(__file__).parent.parent / "docker-compose.yml",
        Path.cwd() / "docker-compose.yml",
    ]:
        if candidate.exists():
            subprocess.run([runtime, "compose", "-f", str(candidate), "down"])
            return
    print("Error: docker-compose.yml not found.")
    sys.exit(1)


def _cmd_logs(args=None) -> None:
    """Show Docker/Podman Compose logs."""
    import subprocess
    from pathlib import Path

    runtime = _get_container_runtime()
    if runtime is None:
        print("Error: neither podman nor docker found.")
        sys.exit(1)

    follow = args is not None and "-f" in args
    for candidate in [
        Path(__file__).parent.parent / "docker-compose.yml",
        Path.cwd() / "docker-compose.yml",
    ]:
        if candidate.exists():
            cmd = [runtime, "compose", "-f", str(candidate), "logs"]
            if follow:
                cmd.append("-f")
            subprocess.run(cmd)
            return
    print("Error: docker-compose.yml not found.")
    sys.exit(1)


_DEMO_MEMORIES = [
    ("project", "fact", "beequa-memory is a self-improving memory layer for AI agents built on PostgreSQL and pgvector"),
    ("project", "fact", "the MCP server runs on port 8765 and exposes 30+ tools to Claude and other LLMs"),
    ("architecture", "fact", "retrieval uses four parallel signals: semantic (pgvector HNSW), BM25 full-text, graph traversal, and temporal"),
    ("architecture", "fact", "RRF fusion merges the four retrieval signals with k=60; fact_boost multiplier = max(1.0, log(1 + access_count))"),
    ("architecture", "fact", "link decay formula: weight *= exp(-lambda * days_since_access) * log(1 + access_count + 1)"),
    ("architecture", "fact", "default decay lambda is 0.01 per day, giving a 69-day half-life for unused links"),
    ("features", "fact", "memory_wake recovers session state after a crash — returns last checkpoint + memories from the past 48h"),
    ("features", "fact", "memory_checkpoint saves working state: what you're doing, your focus, and what's blocked"),
    ("features", "fact", "memory_sleep stores a handoff note and marks the session as cleanly ended"),
    ("features", "fact", "memory_capture ingests an entire conversation as structured memories via fact extraction"),
    ("features", "fact", "memory_reinforce manually boosts a memory's access_count to increase its future ranking"),
    ("features", "fact", "memory_consolidate triggers background graph consolidation: decay, prune, higher-order facts"),
    ("features", "fact", "memory_export dumps a bank to JSON or a Markdown zip archive"),
    ("retrieval_profiles", "fact", "planning profile sets recency_alpha=0.5 and prefers memories from the past 72 hours"),
    ("retrieval_profiles", "fact", "temporal profile doubles the weight of temporal retrieval signals"),
    ("retrieval_profiles", "fact", "entity profile doubles graph traversal weight and reduces semantic weight to 0.8"),
    ("retrieval_profiles", "fact", "auto profile asks the LLM to classify the query intent and select the best profile"),
    ("vault", "fact", "vault sync writes every memory as a Markdown file with YAML frontmatter in BM_VAULT_DIR"),
    ("vault", "fact", "syncing from disk compares SHA-256 hashes to detect changes and re-ingest modified files"),
    ("config", "fact", "BM_LLM_PROVIDER controls the LLM used for fact extraction; set to none to skip extraction"),
    ("config", "fact", "BM_BANK_ID sets the default memory bank; banks partition memories in the same database"),
    ("config", "fact", "BM_DATABASE_URL points to the PostgreSQL instance; uses Docker Compose default if unset"),
    ("demo", "observation", "this is a demo bank seeded with 50 example memories to showcase beequa-memory"),
    ("demo", "observation", "try memory_search with different profiles: default, planning, temporal, entity, auto"),
    ("demo", "observation", "use memory_wake to simulate session recovery — it will return these seeded memories"),
]

# Pad to 50 by repeating with slight variations
_DEMO_MEMORIES_FULL = _DEMO_MEMORIES + [
    ("history", "fact", "beequa-memory is forked from Hindsight, adding reinforcement and temporal decay"),
    ("history", "fact", "the project uses Alembic for all schema migrations with 45+ migration versions"),
    ("history", "fact", "spaCy NER + pg_trgm is used for entity deduplication across memory units"),
    ("history", "fact", "cross-encoder reranking is available as an optional final step after RRF fusion"),
    ("history", "fact", "entity co-occurrence tracking builds a graph of which concepts appear together"),
    ("integrations", "fact", "Claude Code integration: add beequa-memory to claude_desktop_config.json as an HTTP MCP server"),
    ("integrations", "fact", "any MCP-compatible client can connect to http://localhost:8765/mcp/"),
    ("integrations", "fact", "OpenTelemetry tracing and Prometheus metrics are built in for observability"),
    ("integrations", "fact", "ChatGPT conversation exports (conversations.json) can be imported with beequa-memory import"),
    ("integrations", "fact", "beequa-memory export produces a JSON snapshot or a Markdown vault zip"),
    ("internals", "fact", "the retain pipeline: parse document → LLM extraction → entity dedup → embed → link → store"),
    ("internals", "fact", "BFS graph traversal expands search results to related nodes up to a configurable depth"),
    ("internals", "fact", "MPFP (most-probable-forward-path) traversal finds the strongest paths in the graph"),
    ("internals", "fact", "HNSW indexes on embedding vectors enable fast approximate nearest-neighbor search"),
    ("internals", "fact", "pg_trgm trigram indexes power BM25 full-text search without a separate search engine"),
    ("internals", "fact", "entity-relation-value triples extracted by the LLM become edges in the memory graph"),
    ("internals", "fact", "the consolidation job runs on a background schedule and can also be triggered manually"),
    ("internals", "fact", "higher-order facts are extracted during consolidation by re-running LLM over connected clusters"),
    ("tips", "observation", "search with profile=planning when you want to continue recent work"),
    ("tips", "observation", "search with profile=entity when you want everything known about a specific person or project"),
    ("tips", "observation", "run memory_consolidate after a long session to strengthen important links and prune stale ones"),
    ("tips", "observation", "use memory_checkpoint frequently so memory_wake can restore full context after any restart"),
    ("tips", "observation", "BM_REINFORCEMENT_ENABLED=false disables access_count tracking if you prefer static ranking"),
    ("tips", "observation", "BM_DECAY_LAMBDA=0 disables link decay entirely for permanent equal-weight graphs"),
    ("tips", "observation", "combine memory_capture + memory_sleep at session end for complete continuity on next wake"),
]


def _cmd_demo(args: list[str] | None = None) -> None:
    """Seed a demo bank with 50 example memories and print the MCP URL."""
    import argparse as _ap

    p = _ap.ArgumentParser(prog="beequa-memory demo")
    p.add_argument("--bank", default="demo", help="Bank to seed (default: demo)")
    p.add_argument("--base-url", default=os.environ.get("BM_BASE_URL", "http://localhost:8765"), help="beequa-memory API URL")
    p.add_argument("--reset", action="store_true", help="Delete existing memories in the demo bank first")
    opts = p.parse_args(args or [])

    try:
        import httpx
    except ImportError:
        print("Error: httpx is required for demo. pip install httpx")
        sys.exit(1)

    base_url = opts.base_url.rstrip("/")

    # Verify server is reachable
    try:
        r = httpx.get(f"{base_url}/health", timeout=5)
        r.raise_for_status()
    except Exception:
        print(f"Error: beequa-memory server not reachable at {base_url}")
        print("Start it first with: beequa-memory up")
        sys.exit(1)

    memories = _DEMO_MEMORIES_FULL[:50]
    print(f"Seeding {len(memories)} demo memories into bank '{opts.bank}'...")

    stored = 0
    failed = 0
    for i, (context, fact_type, text) in enumerate(memories):
        try:
            r = httpx.post(
                f"{base_url}/memory/retain",
                json={"content": text, "context": context, "bank_id": opts.bank},
                timeout=30,
            )
            r.raise_for_status()
            stored += 1
            print(f"\r  {i+1}/{len(memories)} stored", end="", flush=True)
        except Exception as exc:
            failed += 1
            print(f"\n  Warning: failed to store memory {i+1}: {exc}")

    print(f"\n\nDemo bank ready!")
    print(f"  Stored : {stored} memories")
    if failed:
        print(f"  Failed : {failed}")
    print(f"\nMCP endpoint : {base_url}/mcp/")
    print(f"API docs     : {base_url}/docs")
    print(f"Bank         : {opts.bank}")
    print()
    print("Add to Claude Code (~/.claude/claude_desktop_config.json):")
    print('  {')
    print('    "mcpServers": {')
    print('      "beequa-memory": {')
    print('        "type": "http",')
    print(f'        "url": "{base_url}/mcp/"')
    print('      }')
    print('    }')
    print('  }')
    print()
    print(f"Try: memory_search query='what is fact_boost' profile='default' bank_id='{opts.bank}'")


def _cmd_import(args: list[str]) -> None:
    """Import memories: beequa-memory import --format chatgpt FILE [--bank BANK]"""
    import argparse as _ap

    p = _ap.ArgumentParser(prog="beequa-memory import")
    p.add_argument("file", help="Path to the export file (e.g. conversations.json)")
    p.add_argument("--format", choices=["chatgpt"], default="chatgpt", help="Export format (default: chatgpt)")
    p.add_argument("--bank", default=os.environ.get("BM_BANK_ID", "default"), help="Target bank ID")
    p.add_argument("--base-url", default=os.environ.get("BM_BASE_URL", "http://localhost:8765"), help="beequa-memory API URL")
    opts = p.parse_args(args)

    try:
        import httpx
    except ImportError:
        print("Error: httpx is required for the import CLI. pip install httpx")
        sys.exit(1)

    from pathlib import Path
    import json

    file_path = Path(opts.file)
    if not file_path.exists():
        print(f"Error: file not found: {file_path}")
        sys.exit(1)

    base_url = opts.base_url.rstrip("/")

    def _retain_via_http(payload: dict) -> dict:
        """Synchronous wrapper that calls the retain HTTP endpoint."""
        r = httpx.post(f"{base_url}/memory/retain", json=payload, timeout=30)
        r.raise_for_status()
        return r.json()

    async def _run() -> dict:
        from .io import import_chatgpt_json

        conv_count = [0]

        def _progress(current: int, total: int) -> None:
            if total > 0:
                pct = int(current / total * 100)
                print(f"\r  Progress: {current}/{total} conversations ({pct}%)", end="", flush=True)
                if current == total:
                    print()

        async def _retain_async(payload: dict) -> dict:
            return _retain_via_http(payload)

        return await import_chatgpt_json(
            path=file_path,
            retain_fn=_retain_async,
            bank_id=opts.bank,
            progress_callback=_progress,
        )

    print(f"Importing {opts.format} export from {file_path} into bank '{opts.bank}'...")
    stats = asyncio.run(_run())
    print(f"Done: {stats['conversations']} conversations, {stats['batches']} batches, {stats['units_stored']} units stored.")


def _cmd_export(args: list[str]) -> None:
    """Export memories: beequa-memory export --format json --bank BANK --output FILE"""
    import argparse as _ap

    p = _ap.ArgumentParser(prog="beequa-memory export")
    p.add_argument("--format", choices=["json", "markdown"], default="json", help="Export format (default: json)")
    p.add_argument("--bank", default=os.environ.get("BM_BANK_ID", "default"), help="Source bank ID")
    p.add_argument("--output", required=True, help="Output file path (.json or .zip)")
    p.add_argument("--database-url", default=os.environ.get("BM_DATABASE_URL", os.environ.get("HINDSIGHT_API_DATABASE_URL", "")), help="Database URL")
    opts = p.parse_args(args)

    if not opts.database_url:
        print("Error: set BM_DATABASE_URL or pass --database-url")
        sys.exit(1)

    async def _run() -> dict:
        import asyncpg
        from .io import export_json, export_markdown

        pool = await asyncpg.create_pool(opts.database_url, min_size=1, max_size=3)
        try:
            if opts.format == "json":
                return await export_json(pool, opts.bank, opts.output)
            else:
                vault_dir = os.environ.get("BM_VAULT_DIR")
                return await export_markdown(pool, opts.bank, vault_dir, opts.output)
        finally:
            await pool.close()

    print(f"Exporting bank '{opts.bank}' as {opts.format} to {opts.output}...")
    stats = asyncio.run(_run())
    if opts.format == "json":
        print(f"Done: {stats['units']} units, {stats['links']} links → {stats['path']}")
    else:
        print(f"Done: {stats['files']} files → {stats['path']}")


def _cmd_inspect(args: list[str]) -> None:
    """Inspect: beequa-memory inspect banks|units|links|checkpoint [--bank BANK]"""
    import argparse as _ap

    p = _ap.ArgumentParser(prog="beequa-memory inspect")
    p.add_argument("what", choices=["banks", "units", "links", "checkpoint"], help="What to inspect")
    p.add_argument("--bank", default=os.environ.get("BM_BANK_ID", "default"), help="Bank ID")
    p.add_argument("--limit", type=int, default=20, help="Max rows to show (default: 20)")
    p.add_argument("--database-url", default=os.environ.get("BM_DATABASE_URL", os.environ.get("HINDSIGHT_API_DATABASE_URL", "")), help="Database URL")
    opts = p.parse_args(args)

    if not opts.database_url:
        print("Error: set BM_DATABASE_URL or pass --database-url")
        sys.exit(1)

    async def _run() -> None:
        import asyncpg
        pool = await asyncpg.create_pool(opts.database_url, min_size=1, max_size=2)
        try:
            async with pool.acquire() as conn:
                if opts.what == "banks":
                    rows = await conn.fetch(
                        "SELECT bank_id, COUNT(*) AS units FROM memory_units GROUP BY bank_id ORDER BY units DESC LIMIT $1",
                        opts.limit,
                    )
                    print(f"{'bank_id':<40} {'units':>8}")
                    print("-" * 50)
                    for r in rows:
                        print(f"{r['bank_id']:<40} {r['units']:>8}")

                elif opts.what == "units":
                    rows = await conn.fetch(
                        "SELECT id, context, fact_type, access_count, created_at, LEFT(text,80) AS preview FROM memory_units WHERE bank_id=$1 ORDER BY created_at DESC LIMIT $2",
                        opts.bank, opts.limit,
                    )
                    for r in rows:
                        print(f"[{r['id']}] {r['context']} / {r['fact_type']} (access={r['access_count']})")
                        print(f"  {r['preview']}")

                elif opts.what == "links":
                    rows = await conn.fetch(
                        """SELECT ml.id, ml.relation_type, ml.weight, ml.access_count,
                                  mu1.text[:60] AS from_text, mu2.text[:60] AS to_text
                           FROM memory_links ml
                           JOIN memory_units mu1 ON ml.from_unit_id = mu1.id
                           JOIN memory_units mu2 ON ml.to_unit_id = mu2.id
                           WHERE mu1.bank_id = $1
                           ORDER BY ml.weight DESC LIMIT $2""",
                        opts.bank, opts.limit,
                    )
                    for r in rows:
                        print(f"[{r['relation_type']}] w={r['weight']:.3f} access={r['access_count']}")
                        print(f"  FROM: {r['from_text']}")
                        print(f"  TO:   {r['to_text']}")

                elif opts.what == "checkpoint":
                    rows = await conn.fetch(
                        "SELECT id, session_key, working_on, focus, blocked, created_at FROM checkpoints WHERE bank_id=$1 ORDER BY created_at DESC LIMIT $2",
                        opts.bank, opts.limit,
                    )
                    if not rows:
                        print(f"No checkpoints found for bank '{opts.bank}'.")
                        return
                    for r in rows:
                        print(f"[{r['created_at']}] session_key={r['session_key']}")
                        print(f"  working_on: {r['working_on']}")
                        print(f"  focus:      {r['focus']}")
                        print(f"  blocked:    {r['blocked']}")
        finally:
            await pool.close()

    asyncio.run(_run())


def main():
    """Main entry point for the CLI."""
    global _memory

    # Handle Docker Compose subcommands before argparse
    if len(sys.argv) > 1:
        sub = sys.argv[1]
        rest = sys.argv[2:]
        if sub == "up":
            _cmd_up(rest)
            return
        elif sub == "down":
            _cmd_down(rest)
            return
        elif sub == "logs":
            _cmd_logs(rest)
            return
        elif sub == "import":
            _cmd_import(rest)
            return
        elif sub == "export":
            _cmd_export(rest)
            return
        elif sub == "inspect":
            _cmd_inspect(rest)
            return
        elif sub == "demo":
            _cmd_demo(rest)
            return
        elif sub == "connect":
            from .connect import _cmd_connect
            _cmd_connect(rest)
            return

    # Load configuration from environment (for CLI args defaults)
    config = _get_raw_config()

    parser = argparse.ArgumentParser(
        prog="beequa-memory",
        description="beequa-memory MCP Server",
    )

    # Server options
    parser.add_argument(
        "--host", default=config.host, help=f"Host to bind to (default: {config.host}, env: HINDSIGHT_API_HOST)"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=config.port,
        help=f"Port to bind to (default: {config.port}, env: HINDSIGHT_API_PORT)",
    )
    parser.add_argument(
        "--log-level",
        default=config.log_level,
        choices=["critical", "error", "warning", "info", "debug", "trace"],
        help=f"Log level (default: {config.log_level}, env: HINDSIGHT_API_LOG_LEVEL)",
    )

    # Development options
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload on code changes (development only)")
    parser.add_argument(
        "--workers",
        type=int,
        default=int(os.getenv(ENV_WORKERS, str(DEFAULT_WORKERS))),
        help=f"Number of worker processes (env: {ENV_WORKERS}, default: {DEFAULT_WORKERS})",
    )

    # Access log options
    parser.add_argument("--access-log", action="store_true", help="Enable access log")
    parser.add_argument("--no-access-log", dest="access_log", action="store_false", help="Disable access log (default)")
    parser.set_defaults(access_log=False)

    # Proxy options
    parser.add_argument(
        "--proxy-headers", action="store_true", help="Enable X-Forwarded-Proto, X-Forwarded-For headers"
    )
    parser.add_argument(
        "--forwarded-allow-ips", default=None, help="Comma separated list of IPs to trust with proxy headers"
    )

    # SSL options
    parser.add_argument("--ssl-keyfile", default=None, help="SSL key file")
    parser.add_argument("--ssl-certfile", default=None, help="SSL certificate file")

    # Daemon mode options
    parser.add_argument(
        "--daemon",
        action="store_true",
        help=f"Run as background daemon (uses port {DEFAULT_DAEMON_PORT}, auto-exits after idle)",
    )
    parser.add_argument(
        "--idle-timeout",
        type=int,
        default=DEFAULT_IDLE_TIMEOUT,
        help=f"Idle timeout in seconds before auto-exit in daemon mode (default: {DEFAULT_IDLE_TIMEOUT})",
    )

    args = parser.parse_args()

    # Daemon mode handling
    if args.daemon:
        # Use port from args (may be custom for profiles)
        if args.port == config.port:  # No custom port specified
            args.port = DEFAULT_DAEMON_PORT
        args.host = "127.0.0.1"  # Only bind to localhost for security

        # Fork into background
        # No lockfile needed - port binding prevents duplicate daemons
        daemonize()

    # Print banner (not in daemon mode)
    if not args.daemon:
        print()
        print_banner()

    # Configure Python logging based on log level
    # Update config with CLI override if provided
    if args.log_level != config.log_level:
        config = dataclasses.replace(config, host=args.host, port=args.port, log_level=args.log_level)
    config.configure_logging()
    if not args.daemon:
        config.log_config()

    # Register cleanup handlers
    atexit.register(_cleanup)
    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)

    # Load operation validator extension if configured
    operation_validator = load_extension("OPERATION_VALIDATOR", OperationValidatorExtension)
    if operation_validator:
        logging.info(f"Loaded operation validator: {operation_validator.__class__.__name__}")

    # Load tenant extension if configured
    tenant_extension = load_extension("TENANT", TenantExtension)
    if tenant_extension:
        logging.info(f"Loaded tenant extension: {tenant_extension.__class__.__name__}")

    # Create MemoryEngine (reads configuration from environment)
    _memory = MemoryEngine(
        operation_validator=operation_validator,
        tenant_extension=tenant_extension,
        run_migrations=config.run_migrations_on_startup,
    )

    # Set extension context on tenant extension (needed for schema provisioning)
    if tenant_extension:
        extension_context = DefaultExtensionContext(
            database_url=config.database_url,
            memory_engine=_memory,
        )
        tenant_extension.set_context(extension_context)
        logging.info("Extension context set on tenant extension")

    # Create FastAPI app
    app = create_app(
        memory=_memory,
        http_api_enabled=True,
        mcp_api_enabled=config.mcp_enabled,
        mcp_mount_path="/mcp",
        initialize_memory=True,
    )

    # Wrap with idle timeout middleware in daemon mode
    idle_middleware = None
    if args.daemon:
        idle_middleware = IdleTimeoutMiddleware(app, idle_timeout=args.idle_timeout)
        app = idle_middleware

    # Prepare uvicorn config
    # When using workers or reload, we must use import string so each worker can import the app
    use_import_string = args.workers > 1 or args.reload
    # Check for uvloop availability
    try:
        import uvloop  # noqa: F401

        loop_impl = "uvloop"
        print("uvloop available, will use for event loop")
    except ImportError:
        loop_impl = "asyncio"
        print("uvloop not installed, using default asyncio event loop")

    uvicorn_config = {
        "app": "beequa_memory.server:app" if use_import_string else app,
        "host": args.host,
        "port": args.port,
        "log_level": args.log_level,
        "access_log": args.access_log,
        "proxy_headers": args.proxy_headers,
        "ws": "wsproto",  # Use wsproto instead of websockets to avoid deprecation warnings
        "loop": loop_impl,  # Explicitly set event loop implementation
        "timeout_keep_alive": 30,  # Exceed aiohttp's 15s client timeout so the client always closes first
        "timeout_graceful_shutdown": 5,  # Cap graceful shutdown at 5s; also enables force-kill on second Ctrl+C
    }

    # Add optional parameters if provided
    if args.reload:
        uvicorn_config["reload"] = True
    if args.workers > 1:
        uvicorn_config["workers"] = args.workers
    if args.forwarded_allow_ips:
        uvicorn_config["forwarded_allow_ips"] = args.forwarded_allow_ips
    if args.ssl_keyfile:
        uvicorn_config["ssl_keyfile"] = args.ssl_keyfile
    if args.ssl_certfile:
        uvicorn_config["ssl_certfile"] = args.ssl_certfile

    # Print startup info (not in daemon mode)
    if not args.daemon:
        from .banner import print_startup_info

        print_startup_info(
            host=args.host,
            port=args.port,
            database_url=config.database_url,
            llm_provider=config.llm_provider,
            llm_model=config.llm_model,
            embeddings_provider=config.embeddings_provider,
            reranker_provider=config.reranker_provider,
            mcp_enabled=config.mcp_enabled,
            version=__version__,
            vector_extension=config.vector_extension,
            text_search_extension=config.text_search_extension,
        )

    # Start idle checker in daemon mode
    if idle_middleware is not None:
        # Start the idle checker in a background thread with its own event loop
        import threading

        def run_idle_checker():
            import time

            time.sleep(2)  # Wait for uvicorn to start
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(idle_middleware._check_idle())
            except Exception as e:
                logging.error(f"Idle checker error: {e}", exc_info=True)

        threading.Thread(target=run_idle_checker, daemon=True).start()

    uvicorn.run(**uvicorn_config)


if __name__ == "__main__":
    main()
