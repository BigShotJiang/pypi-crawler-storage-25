"""Worker exceptions stub."""


class RetryTaskAt(Exception):
    """Raised to signal that a task should be retried at a specific time."""
    def __init__(self, retry_at=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.retry_at = retry_at
