"""Worker module stub — background workers stripped from beequa-memory."""
