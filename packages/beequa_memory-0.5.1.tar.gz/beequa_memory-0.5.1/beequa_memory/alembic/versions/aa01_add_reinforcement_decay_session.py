"""Add reinforcement, decay, session lifecycle, and vault sync tables.

beequa-memory additions on top of Hindsight schema:
- access_count + last_accessed on memory_units (reinforcement tracking)
- access_count + last_accessed on memory_links (decay/reinforcement)
- checkpoints table (session lifecycle: wake/checkpoint/sleep)
- vault_files table (Markdown vault sync tracking)

Revision ID: aa01cm_reinforcement
Revises: z1u2v3w4x5y6
Create Date: 2026-03-26
"""

from alembic import op

# revision identifiers
revision = "aa01cm_reinforcement"
down_revision = "z1u2v3w4x5y6"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── Reinforcement columns on memory_units ────────────────────────────────
    op.execute(
        "ALTER TABLE memory_units ADD COLUMN IF NOT EXISTS access_count INTEGER NOT NULL DEFAULT 0"
    )
    op.execute(
        "ALTER TABLE memory_units ADD COLUMN IF NOT EXISTS last_accessed TIMESTAMPTZ"
    )

    # ── Reinforcement / decay columns on memory_links ───────────────────────
    op.execute(
        "ALTER TABLE memory_links ADD COLUMN IF NOT EXISTS access_count INTEGER NOT NULL DEFAULT 0"
    )
    op.execute(
        "ALTER TABLE memory_links ADD COLUMN IF NOT EXISTS last_accessed TIMESTAMPTZ"
    )

    # ── Session lifecycle table ──────────────────────────────────────────────
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS checkpoints (
            id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            bank_id     TEXT NOT NULL REFERENCES banks(bank_id) ON DELETE CASCADE,
            working_on  TEXT,
            focus       TEXT,
            blocked     TEXT,
            session_key TEXT,
            created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_checkpoints_bank_id_created "
        "ON checkpoints(bank_id, created_at DESC)"
    )

    # ── Vault sync tracking table ────────────────────────────────────────────
    op.execute(
        """
        CREATE TABLE IF NOT EXISTS vault_files (
            path         TEXT PRIMARY KEY,
            content_hash TEXT NOT NULL,
            unit_id      UUID REFERENCES memory_units(id) ON DELETE SET NULL,
            bank_id      TEXT NOT NULL REFERENCES banks(bank_id) ON DELETE CASCADE,
            mtime        DOUBLE PRECISION NOT NULL
        )
        """
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_vault_files_bank_id ON vault_files(bank_id)"
    )
    op.execute(
        "CREATE INDEX IF NOT EXISTS idx_vault_files_unit_id ON vault_files(unit_id)"
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS idx_vault_files_unit_id")
    op.execute("DROP INDEX IF EXISTS idx_vault_files_bank_id")
    op.execute("DROP TABLE IF EXISTS vault_files")

    op.execute("DROP INDEX IF EXISTS idx_checkpoints_bank_id_created")
    op.execute("DROP TABLE IF EXISTS checkpoints")

    op.execute("ALTER TABLE memory_links DROP COLUMN IF EXISTS last_accessed")
    op.execute("ALTER TABLE memory_links DROP COLUMN IF EXISTS access_count")

    op.execute("ALTER TABLE memory_units DROP COLUMN IF EXISTS last_accessed")
    op.execute("ALTER TABLE memory_units DROP COLUMN IF EXISTS access_count")
