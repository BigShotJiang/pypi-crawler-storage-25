# Query Pane Empty States Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add four contextual empty states to the QueryPane body: no project open, pre-query idle with collections, pre-query idle without collections, and an improved no-results state.

**Architecture:** All changes are inside `QueryPane.tsx`'s scrollable body — three new conditional blocks added before the loading/results content, plus the existing no-results block replaced. No store, API, or component changes. Four tests updated/added in `QueryPane.test.tsx`.

**Tech Stack:** React 19, TypeScript, lucide-react, Vitest + Testing Library.

---

### Files

| File | Action |
|------|--------|
| `studio/src/components/query/QueryPane.tsx` | Modify — add 3 icons, add 3 empty state blocks, replace no-results block |
| `studio/src/components/query/QueryPane.test.tsx` | Modify — update 1 existing test, add 3 new tests |

---

### Task 1: Update and add tests (all should fail before implementation)

**Files:**
- Modify: `studio/src/components/query/QueryPane.test.tsx`

- [ ] **Step 1: Update the existing "No results found" test and add 3 new tests**

In `studio/src/components/query/QueryPane.test.tsx`, make two changes:

**Change 1** — Update the existing test at line 99. Replace:

```typescript
  it("shows 'No results found' when results are empty after query", async () => {
    vi.mocked(useMultiQueryResults).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);
    renderWithProviders(<QueryPane />);
    const input = screen.getByRole("textbox", { name: /query input/i });
    fireEvent.change(input, { target: { value: "nothing" } });
    fireEvent.submit(input.closest("form")!);
    await waitFor(() => {
      expect(screen.getByText(/no results found/i)).toBeInTheDocument();
    });
  });
```

With:

```typescript
  it("shows 'No results' when results are empty after query", async () => {
    vi.mocked(useMultiQueryResults).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);
    renderWithProviders(<QueryPane />);
    const input = screen.getByRole("textbox", { name: /query input/i });
    fireEvent.change(input, { target: { value: "nothing" } });
    fireEvent.submit(input.closest("form")!);
    await waitFor(() => {
      expect(screen.getByText("No results")).toBeInTheDocument();
    });
  });
```

**Change 2** — Add 3 new tests at the end of the `describe("QueryPane", () => {` block, after the last existing test ("Clear all removes all history chips"):

```typescript
  it("shows 'No project open' when currentDb is null", () => {
    useAppStore.setState({ currentDb: null } as any);
    renderWithProviders(<QueryPane />);
    expect(screen.getByText("No project open")).toBeInTheDocument();
  });

  it("shows idle state before any query when collections exist", () => {
    renderWithProviders(<QueryPane />);
    expect(screen.getByText("Ask anything about your documents")).toBeInTheDocument();
  });

  it("shows 'No collections yet' when collections list is empty", () => {
    vi.mocked(useCollections).mockReturnValue({
      data: [],
      isLoading: false,
      error: null,
    } as any);
    renderWithProviders(<QueryPane />);
    expect(screen.getByText("No collections yet")).toBeInTheDocument();
  });
```

- [ ] **Step 2: Run the tests to confirm exactly 4 fail**

```bash
cd studio && npm test -- --run --reporter=verbose QueryPane
```

Expected: 4 FAIL, 14 PASS.

The 4 failures:
- "shows 'No results' when results are empty after query" — text changed from "No results found." to "No results"
- "shows 'No project open' when currentDb is null" — state doesn't exist yet
- "shows idle state before any query when collections exist" — state doesn't exist yet
- "shows 'No collections yet' when collections list is empty" — state doesn't exist yet

---

### Task 2: Implement the empty states in QueryPane.tsx

**Files:**
- Modify: `studio/src/components/query/QueryPane.tsx`

- [ ] **Step 3: Replace the full file content**

Replace `studio/src/components/query/QueryPane.tsx` with:

```tsx
import { useState } from "react";
import type { FormEvent } from "react";
import { Search, Sparkles, Info, Loader2, X, FolderOpen, PackageOpen, SearchX } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useMultiQueryResults, useChat, useCollections } from "@/hooks/useApi";
import { useAppStore } from "@/store/app";
import { ResultCard } from "./ResultCard";

export function QueryPane() {
  const { apiUrl, currentDb, currentCollection, aiProvider, aiModel, aiApiKey,
          queryHistory, addQueryHistory, removeQueryHistory, clearQueryHistory } =
    useAppStore();

  const [text, setText] = useState("");
  const [submitted, setSubmitted] = useState("");
  const [useAi, setUseAi] = useState(false);
  const [nResults, setNResults] = useState(5);
  const [minScore, setMinScore] = useState(0);
  const [selectedCollections, setSelectedCollections] = useState<string[]>(
    currentCollection ? [currentCollection] : []
  );

  const { data: collections = [] } = useCollections(apiUrl, currentDb ?? "");
  // For AI mode (single-collection): use first selected or fall back to currentCollection
  const activeCollection = selectedCollections[0] ?? currentCollection ?? "";

  const multiResult = useMultiQueryResults(
    apiUrl, currentDb ?? "", selectedCollections, submitted,
    { enabled: !!submitted && !useAi, n_results: nResults,
      min_score: minScore > 0 ? minScore : undefined }
  );
  const chatResult = useChat(
    apiUrl, currentDb ?? "", activeCollection, submitted,
    { enabled: !!submitted && useAi, n_results: nResults,
      min_score: minScore > 0 ? minScore : undefined,
      provider: aiProvider || undefined, model: aiModel || undefined,
      api_key: aiApiKey || undefined }
  );

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (text.trim()) {
      setSubmitted(text.trim());
      addQueryHistory(text.trim());
    }
  }

  function handleCollectionToggle(col: string) {
    if (useAi) {
      setSelectedCollections([col]);
    } else {
      setSelectedCollections((prev) => {
        if (prev.includes(col)) {
          if (prev.length === 1) return prev; // never deselect last
          return prev.filter((c) => c !== col);
        }
        return [...prev, col];
      });
    }
  }

  const results = useAi ? (chatResult.data?.sources ?? []) : (multiResult.data ?? []);
  const isLoading = useAi ? chatResult.isLoading : multiResult.isLoading;
  const error = useAi ? chatResult.error : multiResult.error;
  const canRun = !isLoading && selectedCollections.length > 0;

  return (
    <div className="flex flex-col h-full">

      {/* ── Search area ─────────────────────────────────────────────────── */}
      <div className="px-6 pt-5 pb-4 border-b shrink-0 space-y-3">

        {/* Search input — dominant, full width */}
        <form onSubmit={handleSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <Input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Ask a question or search your documents…"
              className="pl-9 pr-9 h-10"
              aria-label="Query input"
            />
            {text && (
              <button
                type="button"
                onClick={() => { setText(""); setSubmitted(""); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <Button
            type="submit"
            disabled={!canRun}
            className="h-10 px-5 shrink-0"
          >
            {isLoading ? "Searching…" : "Search"}
          </Button>
        </form>

        {/* Query history chips */}
        {queryHistory.length > 0 && (
          <div className="flex flex-wrap gap-1.5 items-center">
            {queryHistory.map((q) => (
              <span
                key={q}
                className="group flex items-center gap-0.5 text-xs pl-2 pr-1 py-0.5 rounded-full border bg-muted/50 hover:bg-muted transition-colors"
              >
                <button
                  type="button"
                  onClick={() => { setText(q); setSubmitted(q); addQueryHistory(q); }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  {q}
                </button>
                <button
                  type="button"
                  onClick={() => removeQueryHistory(q)}
                  aria-label={`Remove ${q}`}
                  className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
            {queryHistory.length > 1 && (
              <button
                type="button"
                onClick={clearQueryHistory}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                Clear all
              </button>
            )}
          </div>
        )}

        {/* Collection pills */}
        <div className="flex flex-wrap gap-1.5">
          {collections.map((col) => {
            const isSelected = selectedCollections.includes(col);
            return (
              <button
                key={col}
                type="button"
                onClick={() => handleCollectionToggle(col)}
                className={cn(
                  "text-xs px-2.5 py-1 rounded-full border transition-colors",
                  isSelected
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-muted/50 text-muted-foreground border-border hover:bg-muted hover:text-foreground"
                )}
              >
                {col}
              </button>
            );
          })}
        </div>

        {/* Options strip — compact, secondary */}
        <div className="flex items-center gap-3">

          {/* Results count */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-muted-foreground whitespace-nowrap">Results</span>
            <Input
              type="number" min={1} max={50}
              value={nResults}
              onChange={(e) => setNResults(Math.max(1, Number(e.target.value)))}
              className="h-7 w-14 text-xs text-center px-1"
              aria-label="Max results"
            />
          </div>

          {/* Min score */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-muted-foreground whitespace-nowrap">Min score</span>
            <Input
              id="min-score"
              type="number" min={0} max={1} step={0.05}
              value={minScore}
              onChange={(e) => setMinScore(Number(e.target.value))}
              className="h-7 w-16 text-xs text-center px-1"
            />
          </div>

          <div className="flex-1" />

          {/* AI toggle */}
          <div className="flex items-center gap-2">
            <Switch
              id="ai-toggle"
              checked={useAi}
              onCheckedChange={(val) => {
                setUseAi(val);
                if (val && selectedCollections.length > 1) {
                  setSelectedCollections([selectedCollections[0]]);
                }
              }}
              aria-label="AI answer toggle"
            />
            <Label
              htmlFor="ai-toggle"
              className="text-xs flex items-center gap-1.5 cursor-pointer select-none"
            >
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              AI Answer
            </Label>
          </div>
        </div>

        {/* AI Agent notice — shown below the strip when toggle is on but not configured */}
        {useAi && !aiProvider && !aiModel && (
          <div className="flex items-center gap-1.5 text-[11px] text-amber-500 dark:text-amber-400">
            <Info className="w-3.5 h-3.5 shrink-0" />
            AI Answer requires a provider and model — configure them in{" "}
            <strong className="font-medium">Settings → AI Agent</strong>.
          </div>
        )}
      </div>

      {/* ── Error ────────────────────────────────────────────────────────── */}
      {error && (
        <div
          className="mx-6 mt-4 shrink-0 text-destructive text-sm p-3 border border-destructive/30 rounded-md bg-destructive/5"
          role="alert"
        >
          {error.message}
        </div>
      )}

      {/* ── Scrollable body ──────────────────────────────────────────────── */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        <div className="px-6 py-4 space-y-4">

          {/* Empty state: no project open */}
          {!currentDb && (
            <div className="flex flex-col items-center justify-center py-16 text-center px-6">
              <FolderOpen className="w-8 h-8 text-muted-foreground/40 mb-3" />
              <p className="text-sm font-medium text-muted-foreground">No project open</p>
              <p className="text-xs text-muted-foreground/60 mt-1">
                Open a project from the sidebar to start searching.
              </p>
            </div>
          )}

          {/* Empty state: pre-query idle (has collections) */}
          {!!currentDb && !submitted && collections.length > 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-center px-6">
              <Search className="w-8 h-8 text-muted-foreground/40 mb-3" />
              <p className="text-sm font-medium text-muted-foreground">
                Ask anything about your documents
              </p>
              <p className="text-xs text-muted-foreground/60 mt-1">
                Type a question above and press Search.
              </p>
            </div>
          )}

          {/* Empty state: pre-query idle (no collections) */}
          {!!currentDb && !submitted && collections.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-center px-6">
              <PackageOpen className="w-8 h-8 text-muted-foreground/40 mb-3" />
              <p className="text-sm font-medium text-muted-foreground">No collections yet</p>
              <p className="text-xs text-muted-foreground/60 mt-1">
                Go to the Ingest tab to add some documents first.
              </p>
            </div>
          )}

          {/* AI answer — loading */}
          {useAi && chatResult.isLoading && (
            <div className="rounded-lg border border-primary/25 bg-primary/8 p-4 flex items-center gap-3">
              <Loader2 className="w-4 h-4 text-primary shrink-0 animate-spin" />
              <span className="text-sm text-muted-foreground">Generating answer…</span>
            </div>
          )}

          {/* AI answer — result */}
          {useAi && chatResult.data && (
            <div className="rounded-lg border border-primary/25 bg-primary/8 p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary shrink-0" />
                <span className="text-sm font-semibold">AI Answer</span>
                <Badge variant="secondary" className="text-xs ml-auto font-mono">
                  {chatResult.data.provider} · {chatResult.data.model}
                </Badge>
              </div>
              <div className="prose prose-sm dark:prose-invert max-w-none text-sm leading-relaxed
                [&>p]:mb-2 [&>ul]:mb-2 [&>ol]:mb-2 [&>ul]:pl-4 [&>ol]:pl-4
                [&>h1]:text-base [&>h2]:text-sm [&>h3]:text-sm
                [&>pre]:bg-muted [&>pre]:p-2 [&>pre]:rounded [&>pre]:overflow-x-auto
                [&>code]:bg-muted [&>code]:px-1 [&>code]:rounded [&>code]:text-xs">
                <ReactMarkdown>{chatResult.data.answer}</ReactMarkdown>
              </div>
            </div>
          )}

          {/* Vector search loading skeleton */}
          {!useAi && isLoading && !!submitted && (
            <div className="flex flex-col gap-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="rounded-lg border bg-card p-4 space-y-2.5 animate-pulse">
                  <div className="flex items-center gap-2">
                    <div className="h-5 w-10 rounded bg-muted" />
                    <div className="h-4 w-32 rounded bg-muted" />
                    <div className="h-4 w-48 rounded bg-muted flex-1" />
                  </div>
                  <div className="space-y-1.5">
                    <div className="h-3 w-full rounded bg-muted" />
                    <div className="h-3 w-4/5 rounded bg-muted" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Results header */}
          {!isLoading && submitted && results.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                {useAi ? "Sources" : "Results"}
              </span>
              <span className="text-xs text-muted-foreground">
                {results.length}
              </span>
            </div>
          )}

          {/* Empty state: no results */}
          {!isLoading && !!submitted && results.length === 0 && !error && (
            <div className="flex flex-col items-center justify-center py-16 text-center px-6">
              <SearchX className="w-8 h-8 text-muted-foreground/40 mb-3" />
              <p className="text-sm font-medium text-muted-foreground">No results</p>
              <p className="text-xs text-muted-foreground/60 mt-1">
                Try broader terms, a lower min-score, or check that the collection has been ingested.
              </p>
            </div>
          )}

          {/* Result cards */}
          {!!submitted && (
            <div className="flex flex-col gap-2">
              {results.map((r) => (
                <ResultCard key={`${r.source}-${r.chunk}`} result={r} />
              ))}
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
```

- [ ] **Step 4: Run the QueryPane tests to confirm all 18 pass**

```bash
cd studio && npm test -- --run --reporter=verbose QueryPane
```

Expected: 18 PASS, 0 FAIL.

- [ ] **Step 5: Run the full test suite to confirm no regressions**

```bash
cd studio && npm test -- --run
```

Expected:
```
Test Files  15 passed (15)
     Tests  106 passed (106)
```

(103 existing + 3 net new = 106 total)

- [ ] **Step 6: Commit**

```bash
git add studio/src/components/query/QueryPane.tsx studio/src/components/query/QueryPane.test.tsx
git commit -m "feat(query): add contextual empty states to query pane"
```
