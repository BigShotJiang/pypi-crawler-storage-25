# Changelog

All notable changes to `remex` are documented here.

---

## [Unreleased]

### Added
- Keyboard shortcuts cheat sheet modal (`?` key)
- CI: Rust/Clippy/test job + GitHub Releases workflow via `tauri-action`

---

## [0.4.0] — 2026-04-18

### Added — Studio v1.0

**Query pane**
- Multi-collection AI Answer via `POST /collections/multi-chat` — queries all selected collections, merges results by score, generates a single AI-synthesised answer
- Filter results by source document — collapsible chip strip, passes `where` filter to ChromaDB
- Export results to JSON, CSV, or Markdown via native save dialog
- Collection pills show chunk count + embedding model in tooltip
- Empty states for no-project / no-collections / no-results scenarios

**Ingest pane**
- Stop button cancels in-progress ingest stream (FilesTab + SQLiteTab)
- Incremental mode toggle in Advanced settings (skip unchanged files by SHA-256 hash)
- Skipped-file reasons persisted in last-ingest result and shown in post-ingest toast

**Collections pane**
- Collection rename — `PATCH /collections/{name}/rename` + inline rename dialog with pencil button

**Settings pane**
- App version display (reads from Tauri `getVersion()`)

**Shell / UX**
- First-run onboarding modal (persisted `onboardingDone` flag, never shown again)
- Per-theme background tints + dot-grid pattern follows active theme
- Animated dot-grid homepage replaces aurora mesh

### Fixed
- API key removed from React Query cache keys (security)
- CSP hardened: `unsafe-inline` removed, `connect-src` narrowed to sidecar port only
- SQLite path validation: rejects relative paths and non-existent files before opening
- `write_text_file` Tauri command validates path extension
- Abort race condition in SSE `done` event (FilesTab + SQLiteTab)
- Keyboard shortcut `e.key` case-insensitive matching across platforms
- Duplicate collection name prevention in CollectionSwitcher
- Rename endpoint uses `.upsert()` for idempotency
- Generic `except Exception` catches narrowed to specific types in pipeline

### Performance
- Embedding batch size raised from 64 → 256

---

## [0.3.0] — 2026-04-12

### Added
- **Remex Studio** — native desktop app (Tauri v2 + React 19 + TypeScript)
  - Visual ingest with live progress, streaming SSE, and embedding model picker
  - Query panel with semantic search, min-score filter, and AI Answer (markdown rendered)
  - Collections panel — stats, sources list, delete source, purge, reset
  - Settings panel — API server URL, dark mode, accent colour, AI provider/model/key
  - Automatic sidecar management — spawns `remex serve` on startup, restarts on URL change
- **API additions for Studio** — `api_key` field on `/chat` endpoint forwarded to AI providers; catch-all exception handler ensures CORS headers on all error responses; `detect_provider()` runs off the async event loop to avoid blocking
- **`remex serve --host / --port`** — explicit bind address flags, used by the Studio sidecar

---

## [0.2.0] — 2026-04-09

### Changed
- **Package renamed** from `synapse-core` to `remex`. Import path: `from remex import ingest, query` (was `from synapse_core import ...`)
- Unified CLI entry point: `remex` command replaces `synapse` (all subcommands unchanged)
- `remex.toml` / `[remex]` section replaces `synapse.toml` / `[synapse]` for project config
- Default ChromaDB path changed from `./synapse_db` to `./remex_db`
- Default collection name changed from `synapse` to `remex`
- Base exception renamed from `SynapseError` to `RemexError` (`SynapseError` kept as a backward-compat alias)
- `remex.api` FastAPI sidecar added — start with `remex serve` (requires `remex[api]`)
- Top-level `remex` package now re-exports the full public API (previously only `remex.core`)

---

## [1.1.1] — 2026-03-24

### Added
- `save_config(settings, root)` — writes a `[synapse]` section to `synapse.toml`; preserves other sections; exported from top-level namespace
- `load_config()` exported from top-level namespace (previously only used internally by the CLI)
- `detect_provider()`, `generate_answer()`, `PROVIDERS`, `DEFAULT_MODELS` exported from top-level namespace (previously only accessible via `synapse_core.ai`)
- `SUPPORTED_EXTENSIONS` frozenset and `is_supported()` exported from top-level namespace (previously only accessible via `synapse_core.extractors`)

---

## [1.1.0] — 2026-03-24

### Added
- `list_collections(db_path)` — returns all collection names in a ChromaDB directory; exposed in CLI as `synapse list-collections`
- `collection_stats(db_path, collection_name)` — returns a `CollectionStats` dataclass with `total_chunks`, `total_sources`, and `embedding_model`; CLI: `synapse stats`
- `delete_source(source, db_path, collection_name)` — explicitly removes all chunks for a given source (file path or SQLite source string); CLI: `synapse delete-source SOURCE [--yes]`
- `query(…, min_score=…)` / `query_async(…, min_score=…)` — optional float 0–1 to filter out low-relevance results; CLI: `synapse query --min-score 0.5`
- `CollectionStats` dataclass exported from the top-level `synapse_core` namespace
- `py.typed` marker — downstream type checkers (Pylance, mypy) now pick up remex's type hints automatically

---

## [1.0.0] — 2026-03-24

### Added
- `ingest_async()` — async wrapper around `ingest()`, runs in a thread pool via `asyncio.to_thread()`; full parameter parity with `ingest()`
- `query_async()` — async wrapper around `query()`, runs in a thread pool via `asyncio.to_thread()`; full parameter parity with `query()`
- Both functions exported from the top-level `synapse_core` namespace

### Fixed
- `ingest_many()` was not returning its `IngestResult` (returned `None`)

---

## [0.7.0] — 2026-03-18

### Added
- `--embedding-model` CLI flag on `ingest`, `ingest-sqlite`, and `query` — override the SentenceTransformer model without touching Python code
- `ingest_many()` gains `incremental=True` (SHA-256 hash-skip) and `streaming_threshold` — now consistent with `ingest()`
- `synapse init` CLI command — scaffolds `docs/`, writes `synapse.toml`, adds `synapse_db/` to `.gitignore`
- `synapse.toml` project config — `[synapse]` section sets per-project defaults for all CLI commands; CLI flags always override
- EPUB metadata extraction — `extract_metadata()` reads title, author, date from OPF/Dublin Core
- ODT metadata extraction — `extract_metadata()` reads `dc:title`, `dc:creator`, `dc:date`
- End-to-end integration test hitting a real ChromaDB `PersistentClient`

---

## [0.6.3] — 2026-03-18

### Added
- `ingest_many(paths)` — ingest an explicit list of files instead of scanning a directory; accepts `str` or `pathlib.Path`; skipped files recorded in `result.skipped_reasons`
- `ingest_sqlite()` `on_progress` callback — same `Callable[[IngestProgress], None]` pattern as `ingest()`
- `query --format json` CLI flag — emits raw JSON for scripting and piping; conflicts with `--ai` (caught early)
- `ingest-sqlite` CLI gains `--columns`, `--id-column`, `--row-template` flags matching the Python API
- `--min-chunk-size` CLI flag on `ingest` and `ingest-sqlite` commands
- `query()` validates `n_results >= 1` at the API level (was only guarded by the CLI)

### Changed
- Test suite consolidated from 10 files → 6 component-based files (166 tests total)
- `examples/` folder removed — usage covered by README and inline docstrings
- README simplified from ~440 lines to ~185 lines

---

## [0.6.1] — 2025

### Added
- `IngestResult.skipped_reasons` — human-readable list of why each file was skipped
- `PurgeResult` — typed return from `purge()` with `chunks_deleted` and `chunks_checked`
- `reset(confirm=True)` guard — API raises `ValueError` unless `confirm=True` is passed explicitly
- Embedding model mismatch detection — warns when the model passed to `ingest()` differs from the one stored in collection metadata

---

## [0.6.0] — 2025

### Added
- Streaming ingest — large files (`.txt` `.md` `.csv` `.jsonl`) are paged through the chunker without loading the full file into memory (`streaming_threshold` param, default 50 MB)
- `on_progress` callback on `ingest()` — `Callable[[IngestProgress], None]` for tqdm / custom UIs
- `IngestProgress` model — `filename`, `files_done`, `files_total`, `status`, `chunks_stored`
- Multi-collection query — `query(collection_names=[...])` merges results from multiple collections ranked by score
- Metadata filtering — `query(where={...})` passes a ChromaDB `where` filter

---

## [0.5.5] — 2025

### Added
- Typed public API — `IngestResult`, `QueryResult` (TypedDict), `SynapseError` exception hierarchy
- `CollectionNotFoundError`, `SourceNotFoundError`, `TableNotFoundError` — all also inherit from matching Python built-ins

---

## [0.5.1] — 2025

### Added
- `--ai` CLI flag — AI-synthesized answer using Anthropic, OpenAI, or Ollama (auto-detected from env vars)
- `--provider` and `--model` overrides for `synapse query`

---

## [0.5.0] — 2025

### Added
- CLI — `synapse ingest`, `query`, `sources`, `purge`, `reset`
- 12 file formats: `txt` `md` `csv` `pdf` `docx` `json` `jsonl` `html` `pptx` `xlsx` `epub` `odt`
- Document metadata extraction — title, author, created date (PDF / DOCX / HTML / PPTX)

---

## [0.4.0] — 2025

### Added
- Incremental ingest — SHA-256 hash check, skip unchanged files on re-runs
- Sentence-aware chunking (NLTK) via `chunking="sentence"`

---

## [0.3.0] — 2025

### Changed
- Replaced all `print()` calls with structured logging via `synapse_core.logger`
- Added `setup_logging()` public helper

---

## [0.2.0] — 2025

### Added
- `query()` added to public API with ranked results and score normalization

---

## [0.1.0] — 2025

### Added
- Initial release — `ingest()` scans a directory, chunks text, stores embeddings in ChromaDB
- `ingest_sqlite()` — embed SQLite table rows alongside files in the same collection
- `purge()` — remove chunks whose source no longer exists on disk
- `reset()` — wipe an entire collection
- `sources()` — list all indexed source paths
