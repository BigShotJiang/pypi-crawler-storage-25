import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface RecentProject {
  path: string;
  lastOpened: string;
}

export type Theme = "default" | "violet" | "green" | "lime" | "yellow" | "rose" | "coral" | "slate";

export interface ProgressItem {
  filename: string;
  status: "ingested" | "skipped" | "error";
  chunks_stored: number;
}

export interface LastIngestResult {
  collection: string;
  sourcePath: string;
  startedAt: string;   // ISO string
  completedAt: string; // ISO string
  sourcesFound: number;
  sourcesIngested: number;
  sourcesSkipped: number;
  chunksStored: number;
  skippedReasons: string[];
}

export interface AppState {
  currentDb: string | null;
  currentCollection: string | null;
  recentProjects: RecentProject[];
  queryHistory: string[];
  apiUrl: string;
  sidecarStatus: "starting" | "connected" | "error";
  darkMode: boolean;
  theme: Theme;
  aiProvider: string;
  aiModel: string;
  aiApiKey: string;
  // Sidecar reconnect (not persisted)
  sidecarReconnectSeq: number;
  triggerSidecarReconnect: () => void;
  // Files ingest session state (not persisted)
  ingestRunning: boolean;
  ingestProgress: ProgressItem[];
  ingestFilesDone: number;
  ingestFilesTotal: number;
  ingestStreamError: string | null;
  ingestDoneUnread: boolean;
  // SQLite ingest session state (not persisted)
  sqliteIngestRunning: boolean;
  sqliteIngestRowsDone: number;
  sqliteIngestRowsTotal: number;
  sqliteIngestStreamError: string | null;
  // Ingest result (persisted)
  lastIngestResult: LastIngestResult | null;
  // Collection metadata (persisted)
  collectionTypes: Record<string, "files" | "sqlite">;
  incompleteCollections: Record<string, true>;
  // Actions
  setCurrentDb: (db: string | null) => void;
  setCurrentCollection: (col: string | null) => void;
  addRecentProject: (path: string) => void;
  removeRecentProject: (path: string) => void;
  addQueryHistory: (text: string) => void;
  removeQueryHistory: (text: string) => void;
  clearQueryHistory: () => void;
  setApiUrl: (url: string) => void;
  setSidecarStatus: (status: AppState["sidecarStatus"]) => void;
  setDarkMode: (dark: boolean) => void;
  setTheme: (theme: Theme) => void;
  setAiProvider: (provider: string) => void;
  setAiModel: (model: string) => void;
  setAiApiKey: (key: string) => void;
  resetIngestSession: () => void;
  appendIngestProgress: (item: ProgressItem) => void;
  setIngestFilesDone: (n: number) => void;
  setIngestFilesTotal: (n: number) => void;
  setIngestRunning: (v: boolean) => void;
  setIngestStreamError: (err: string | null) => void;
  setLastIngestResult: (r: LastIngestResult | null) => void;
  setIngestDoneUnread: (v: boolean) => void;
  resetSqliteIngestSession: () => void;
  setSqliteIngestRunning: (v: boolean) => void;
  setSqliteIngestRowsDone: (n: number) => void;
  setSqliteIngestRowsTotal: (n: number) => void;
  setSqliteIngestStreamError: (err: string | null) => void;
  setCollectionType: (dbPath: string, collection: string, type: "files" | "sqlite") => void;
  removeCollectionType: (dbPath: string, collection: string) => void;
  setIncompleteCollection: (dbPath: string, collection: string) => void;
  clearIncompleteCollection: (dbPath: string, collection: string) => void;
  // Onboarding
  onboardingDone: boolean;
  setOnboardingDone: (v: boolean) => void;
  // Keyboard shortcuts modal (not persisted)
  shortcutsOpen: boolean;
  setShortcutsOpen: (v: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentDb: null,
      currentCollection: null,
      recentProjects: [],
      queryHistory: [],
      apiUrl: "http://localhost:8000",
      sidecarStatus: "starting",
      sidecarReconnectSeq: 0,
      darkMode: false,
      theme: "default",
      aiProvider: "",
      aiModel: "",
      aiApiKey: "",
      ingestRunning: false,
      ingestProgress: [],
      ingestFilesDone: 0,
      ingestFilesTotal: 0,
      ingestStreamError: null,
      ingestDoneUnread: false,
      sqliteIngestRunning: false,
      sqliteIngestRowsDone: 0,
      sqliteIngestRowsTotal: 0,
      sqliteIngestStreamError: null,
      lastIngestResult: null,
      collectionTypes: {},
      incompleteCollections: {},
      onboardingDone: false,
      shortcutsOpen: false,

      setCurrentDb: (db) => set({ currentDb: db }),
      setCurrentCollection: (col) => set({ currentCollection: col }),

      addRecentProject: (path) => {
        const filtered = get().recentProjects.filter((p) => p.path !== path);
        set({
          recentProjects: [
            { path, lastOpened: new Date().toISOString() },
            ...filtered,
          ].slice(0, 10),
        });
      },

      removeRecentProject: (path) => {
        set({
          recentProjects: get().recentProjects.filter((p) => p.path !== path),
        });
      },

      addQueryHistory: (text) => {
        const filtered = get().queryHistory.filter((q) => q !== text);
        set({ queryHistory: [text, ...filtered].slice(0, 20) });
      },

      removeQueryHistory: (text) => {
        set({ queryHistory: get().queryHistory.filter((q) => q !== text) });
      },

      clearQueryHistory: () => {
        set({ queryHistory: [] });
      },

      setApiUrl:         (url)      => set({ apiUrl: url }),
      setSidecarStatus:        (status) => set({ sidecarStatus: status }),
      triggerSidecarReconnect: ()       => set((s) => ({ sidecarReconnectSeq: s.sidecarReconnectSeq + 1 })),
      setDarkMode:       (dark)     => set({ darkMode: dark }),
      setTheme:          (theme)    => set({ theme }),
      setAiProvider:     (provider) => set({ aiProvider: provider }),
      setAiModel:        (model)    => set({ aiModel: model }),
      setAiApiKey:       (key)      => set({ aiApiKey: key }),

      resetIngestSession: () => set({
        ingestRunning:     false,
        ingestProgress:    [],
        ingestFilesDone:   0,
        ingestFilesTotal:  0,
        ingestStreamError: null,
      }),

      appendIngestProgress: (item) =>
        set({ ingestProgress: [...get().ingestProgress, item] }),

      setIngestFilesDone:   (n)   => set({ ingestFilesDone: n }),
      setIngestFilesTotal:  (n)   => set({ ingestFilesTotal: n }),
      setIngestRunning:     (v)   => set({ ingestRunning: v }),
      setIngestStreamError: (err) => set({ ingestStreamError: err }),
      setLastIngestResult:  (r)   => set({ lastIngestResult: r }),
      setIngestDoneUnread:  (v)   => set({ ingestDoneUnread: v }),
      resetSqliteIngestSession: () => set({
        sqliteIngestRunning:     false,
        sqliteIngestRowsDone:    0,
        sqliteIngestRowsTotal:   0,
        sqliteIngestStreamError: null,
      }),
      setSqliteIngestRunning:     (v)   => set({ sqliteIngestRunning: v }),
      setSqliteIngestRowsDone:    (n)   => set({ sqliteIngestRowsDone: n }),
      setSqliteIngestRowsTotal:   (n)   => set({ sqliteIngestRowsTotal: n }),
      setSqliteIngestStreamError: (err) => set({ sqliteIngestStreamError: err }),

      setCollectionType: (dbPath, collection, type) =>
        set((s) => ({
          collectionTypes: {
            ...s.collectionTypes,
            [`${dbPath}::${collection}`]: type,
          },
        })),
      removeCollectionType: (dbPath, collection) =>
        set((s) => {
          const next = { ...s.collectionTypes };
          delete next[`${dbPath}::${collection}`];
          return { collectionTypes: next };
        }),
      setIncompleteCollection: (dbPath, collection) =>
        set((s) => ({
          incompleteCollections: {
            ...s.incompleteCollections,
            [`${dbPath}::${collection}`]: true,
          },
        })),
      clearIncompleteCollection: (dbPath, collection) =>
        set((s) => {
          const next = { ...s.incompleteCollections };
          delete next[`${dbPath}::${collection}`];
          return { incompleteCollections: next };
        }),
      setOnboardingDone: (v) => set({ onboardingDone: v }),
      setShortcutsOpen:  (v) => set({ shortcutsOpen: v }),
    }),
    {
      name: "remex-studio",
      partialize: (state) => ({
        recentProjects:   state.recentProjects,
        queryHistory:     state.queryHistory,
        apiUrl:           state.apiUrl,
        darkMode:         state.darkMode,
        theme:            state.theme,
        aiProvider:       state.aiProvider,
        aiModel:          state.aiModel,
        // aiApiKey intentionally NOT persisted — API keys should not survive
        // in localStorage across sessions for security.
        lastIngestResult: state.lastIngestResult,
        collectionTypes:       state.collectionTypes,
        incompleteCollections: state.incompleteCollections,
        onboardingDone:        state.onboardingDone,
      }),
    }
  )
);
