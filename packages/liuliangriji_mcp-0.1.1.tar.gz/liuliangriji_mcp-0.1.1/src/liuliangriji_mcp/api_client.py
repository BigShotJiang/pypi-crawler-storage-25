"""HTTP 客户端，连接流量日记 App 的本地 API"""

import httpx
from typing import Any, Optional

BASE_URL = "http://127.0.0.1:19820/api/v1"
TIMEOUT = 10.0


async def _request(method: str, path: str, **kwargs: Any) -> dict[str, Any]:
    """发送请求到流量日记 App API"""
    async with httpx.AsyncClient(base_url=BASE_URL, timeout=TIMEOUT) as client:
        response = await client.request(method, path, **kwargs)
        response.raise_for_status()
        data = response.json()
        if not data.get("success"):
            error = data.get("error", {})
            raise RuntimeError(
                f"API 错误 [{error.get('code', 'UNKNOWN')}]: {error.get('message', '未知错误')}"
            )
        return data


async def get(path: str, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """发送 GET 请求"""
    return await _request("GET", path, params=params)


async def health_check() -> bool:
    """检查流量日记 App 是否在运行且 API 可用"""
    try:
        await get("/health")
        return True
    except Exception:
        return False


async def get_csv(params: Optional[dict[str, Any]] = None) -> str:
    """获取 CSV 导出内容（返回原始文本）"""
    async with httpx.AsyncClient(base_url=BASE_URL, timeout=TIMEOUT) as client:
        response = await client.get("/export/csv", params=params)
        response.raise_for_status()
        return response.text
