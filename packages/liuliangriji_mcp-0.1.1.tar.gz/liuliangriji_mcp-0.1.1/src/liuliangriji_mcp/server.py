"""流量日记 MCP Server — 让 AI 查询自媒体数据"""

from mcp.server.fastmcp import FastMCP
from liuliangriji_mcp.models import (
    BaseQueryInput,
    AccountListInput,
    TopArticlesInput,
    ExportCSVInput,
)
from liuliangriji_mcp import api_client
from liuliangriji_mcp.formatters import (
    format_accounts,
    format_articles,
    auto_format_markdown,
)

mcp = FastMCP(
    "liuliangriji_mcp",
    instructions=(
        "流量日记 MCP Server — 查询用户的自媒体数据（微信公众号、小红书）。\n"
        "使用前请确保「流量日记」macOS App 正在运行。"
    ),
)


def _build_query_params(params: BaseQueryInput) -> dict:
    """从输入模型构建 HTTP 查询参数"""
    query: dict = {}
    if params.start_date:
        query["start_date"] = params.start_date
    if params.end_date:
        query["end_date"] = params.end_date
    if params.account_id:
        query["account_id"] = params.account_id
    query["limit"] = params.limit
    query["offset"] = params.offset
    return query


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  通用
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@mcp.tool(name="liuliangriji_check_connection")
async def check_connection() -> str:
    """检查流量日记 App 是否在运行且 API 可用"""
    is_ok = await api_client.health_check()
    if is_ok:
        return "✅ 流量日记已连接，API 正常。"
    return "❌ 无法连接。请确保「流量日记」App 正在运行且 MCP 服务已开启。"


@mcp.tool(name="liuliangriji_list_accounts")
async def list_accounts(params: AccountListInput) -> str:
    """列出自媒体账号（微信公众号 + 小红书）。可用 platform 筛选。"""
    query: dict = {}
    if params.platform:
        query["platform"] = params.platform.value
    query["limit"] = params.limit
    query["offset"] = params.offset
    result = await api_client.get("/accounts", params=query)
    return format_accounts(result["data"])


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  微信公众号
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@mcp.tool(name="liuliangriji_wechat_account_daily")
async def wechat_account_daily(params: BaseQueryInput) -> str:
    """查询微信公众号每日统计：阅读量、分享、收藏、新增关注等。"""
    query = _build_query_params(params)
    result = await api_client.get("/wechat/account-daily", params=query)
    return auto_format_markdown(result)


@mcp.tool(name="liuliangriji_wechat_article_stats")
async def wechat_article_stats(params: BaseQueryInput) -> str:
    """查询微信公众号文章统计：标题、阅读、分享、关注转化、送达数等。"""
    query = _build_query_params(params)
    result = await api_client.get("/wechat/article-stats", params=query)
    return auto_format_markdown(result)


@mcp.tool(name="liuliangriji_wechat_top_articles")
async def wechat_top_articles(params: TopArticlesInput) -> str:
    """微信公众号阅读量最高的文章排行，默认 Top 10。"""
    query = _build_query_params(params)
    result = await api_client.get("/wechat/articles/top", params=query)
    return format_articles(result)


@mcp.tool(name="liuliangriji_wechat_followers")
async def wechat_followers(params: BaseQueryInput) -> str:
    """查询微信公众号粉丝增长：每日新增、取关、净增长、累计粉丝。"""
    query = _build_query_params(params)
    result = await api_client.get("/wechat/followers", params=query)
    return auto_format_markdown(result)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  小红书
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@mcp.tool(name="liuliangriji_xhs_account_traffic")
async def xhs_account_traffic(params: BaseQueryInput) -> str:
    """查询小红书账号每日流量：曝光、观看、封面点击率、完播率等。"""
    query = _build_query_params(params)
    result = await api_client.get("/xhs/account-traffic", params=query)
    return auto_format_markdown(result)


@mcp.tool(name="liuliangriji_xhs_notes")
async def xhs_notes(params: BaseQueryInput) -> str:
    """查询小红书笔记列表：曝光、观看、点赞、评论、收藏、分享等。"""
    query = _build_query_params(params)
    result = await api_client.get("/xhs/notes", params=query)
    return auto_format_markdown(result)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  导入历史 & 数据导出
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


@mcp.tool(name="liuliangriji_import_history")
async def import_history(params: BaseQueryInput) -> str:
    """查询数据导入历史：导入时间、文件名、记录数等。"""
    query = _build_query_params(params)
    result = await api_client.get("/import-history", params=query)
    return auto_format_markdown(result)


@mcp.tool(name="liuliangriji_export_csv")
async def export_csv(params: ExportCSVInput) -> str:
    """将指定类型的数据导出为 CSV 格式文本，可直接保存为 .csv 文件。"""
    query: dict = {"type": params.data_type.value}
    if params.start_date:
        query["start_date"] = params.start_date
    if params.end_date:
        query["end_date"] = params.end_date

    csv_text = await api_client.get_csv(params=query)
    if not csv_text.strip():
        return "⚠️ 没有可导出的数据。请检查数据类型和日期范围是否正确。"
    line_count = csv_text.count("\n")
    return f"📊 已导出 {line_count} 行数据（类型: {params.data_type.value}）\n\n```csv\n{csv_text}\n```"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  入口
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
