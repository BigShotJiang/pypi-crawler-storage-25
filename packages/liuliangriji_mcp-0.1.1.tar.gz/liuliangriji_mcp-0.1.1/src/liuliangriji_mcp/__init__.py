"""流量日记 MCP Server — 让 AI 查询和分析自媒体数据"""

__version__ = "0.1.0"
