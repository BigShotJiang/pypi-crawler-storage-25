"""MCP Tool 的 Pydantic 输入模型"""

from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import Optional
from enum import Enum
from datetime import datetime


class PlatformType(str, Enum):
    WECHAT = "wechat"
    XIAOHONGSHU = "xiaohongshu"


# ── 通用查询参数 ──


class BaseQueryInput(BaseModel):
    """平台特定工具的通用查询参数（不含 platform，由工具名区分平台）"""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    start_date: Optional[str] = Field(default=None, description="开始日期，YYYYMMDD 格式")
    end_date: Optional[str] = Field(default=None, description="结束日期，YYYYMMDD 格式")
    account_id: Optional[str] = Field(default=None, description="账号 ID，通过 list_accounts 获取")
    limit: int = Field(default=20, ge=1, le=100, description="返回数量 1-100")
    offset: int = Field(default=0, ge=0, description="分页偏移")

    @field_validator("start_date", "end_date")
    @classmethod
    def validate_date_format(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            try:
                datetime.strptime(v, "%Y%m%d")
            except ValueError:
                raise ValueError(f"日期格式应为 YYYYMMDD，收到: '{v}'")
        return v


# ── 具体工具输入 ──


class AccountListInput(BaseModel):
    """账号列表查询参数"""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    platform: Optional[PlatformType] = Field(default=None, description="'wechat' | 'xiaohongshu'")
    limit: int = Field(default=20, ge=1, le=100, description="返回数量 1-100")
    offset: int = Field(default=0, ge=0, description="分页偏移")


class TopArticlesInput(BaseQueryInput):
    limit: int = Field(default=10, ge=1, le=50, description="Top N，默认 10")


class CSVExportType(str, Enum):
    ACCOUNT_DAILY = "account-daily"
    ARTICLE_7DAY = "article-7day"
    FOLLOWERS = "followers"
    XHS_TRAFFIC = "xhs-traffic"
    XHS_NOTES = "xhs-notes"


class ExportCSVInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    data_type: CSVExportType = Field(
        ...,
        description="'account-daily' | 'article-7day' | 'followers' | 'xhs-traffic' | 'xhs-notes'",
    )
    start_date: Optional[str] = Field(default=None, description="开始日期，YYYYMMDD 格式")
    end_date: Optional[str] = Field(default=None, description="结束日期，YYYYMMDD 格式")

    @field_validator("start_date", "end_date")
    @classmethod
    def validate_date_format(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            try:
                datetime.strptime(v, "%Y%m%d")
            except ValueError:
                raise ValueError(f"日期格式应为 YYYYMMDD，收到: '{v}'")
        return v
