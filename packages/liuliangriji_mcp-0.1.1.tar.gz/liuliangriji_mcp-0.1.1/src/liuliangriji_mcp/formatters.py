"""将 API 响应格式化为 Markdown"""


def format_accounts(data: list[dict]) -> str:
    """格式化账号列表（仅基本信息，不含统计数据）"""
    if not data:
        return "暂无自媒体账号数据。"

    lines = ["## 📊 自媒体账号列表\n"]
    lines.append(f"共 {len(data)} 个账号\n")
    lines.append("| 账号名 | 平台 | 账号 ID | 状态 |")
    lines.append("|--------|------|---------|------|")
    for a in data:
        status = "✅ 活跃" if a.get("is_active") else "⏸ 停用"
        platform = "微信公众号" if a.get("platform") == "wechat" else "小红书"
        lines.append(
            f"| {a.get('name', '-')} | {platform} | "
            f"{a.get('id', '-')} | {status} |"
        )
    return "\n".join(lines)


def format_articles(result: dict) -> str:
    """格式化文章列表"""
    articles = result.get("data", [])
    if not articles:
        return "暂无文章数据。"

    pagination = result.get("pagination", {})
    total = pagination.get("total", len(articles))

    lines = [f"## 📝 文章数据 (共 {total} 篇)\n"]
    lines.append("| # | 标题 | 发布日期 | 阅读量 | 分享 | 点赞 | 评论 |")
    lines.append("|---|------|----------|--------|------|------|------|")
    for i, a in enumerate(articles, 1):
        title = a.get("title", "无标题")
        if len(title) > 20:
            title = title[:18] + "…"
        lines.append(
            f"| {i} | {title} | {a.get('publish_date', '-')} | "
            f"{a.get('total_reads', 0):,} | {a.get('total_shares', 0):,} | "
            f"{a.get('total_likes', 0):,} | {a.get('total_comments', 0):,} |"
        )

    if pagination.get("has_more"):
        lines.append(
            f"\n> 显示 {len(articles)}/{total} 条，使用 offset 参数查看更多。"
        )

    return "\n".join(lines)


def auto_format_markdown(result: dict) -> str:
    """通用 Markdown 格式化，处理各种数据结构"""
    data = result.get("data", {})
    pagination = result.get("pagination")

    if isinstance(data, list):
        if not data:
            return "暂无数据。"
        # 自动从第一项的 key 生成表头
        keys = list(data[0].keys())
        # 限制列数防止表格过宽
        display_keys = keys[:8]
        header = "| " + " | ".join(display_keys) + " |"
        separator = "| " + " | ".join(["---"] * len(display_keys)) + " |"
        rows = []
        for item in data:
            vals = []
            for k in display_keys:
                v = item.get(k, "")
                s = str(v)
                if len(s) > 25:
                    s = s[:23] + "…"
                vals.append(s)
            rows.append("| " + " | ".join(vals) + " |")
        lines = [header, separator] + rows
        if pagination and pagination.get("has_more"):
            lines.append(
                f"\n> 共 {pagination['total']} 条，当前显示 {pagination['count']} 条。"
            )
        return "\n".join(lines)

    if isinstance(data, dict):
        lines = []
        for k, v in data.items():
            lines.append(f"- **{k}**: {v}")
        return "\n".join(lines)

    return str(data)
