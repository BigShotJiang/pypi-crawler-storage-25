#  liuliangriji-mcp/src/liuliangriji_mcp/__main__.py
#  允许通过 `python3 -m liuliangriji_mcp` 启动 MCP Server
#  本文件仅作入口转发，不包含业务逻辑

from liuliangriji_mcp.server import main

main()
