# liuliangriji-mcp

> 流量日记 MCP Server — 让 AI 查询和分析你的自媒体数据

## 简介

`liuliangriji-mcp` 是「流量日记」macOS App 的 MCP (Model Context Protocol) 服务器，让 Claude、Cursor、VS Code Copilot 等 AI 客户端能直接查询你导入的微信公众号和小红书数据。

## 前置条件

- 「流量日记」macOS App 正在运行
- App 设置中 MCP API 服务已开启（默认端口 19820）

## 安装

推荐使用 `uvx`（无需手动安装）：

```bash
uvx liuliangriji-mcp
```

或通过 pip 安装：

```bash
pip install liuliangriji-mcp
```

## 配置

### Claude Desktop

编辑 `~/Library/Application Support/Claude/claude_desktop_config.json`：

```json
{
    "mcpServers": {
        "liuliangriji": {
            "command": "uvx",
            "args": ["liuliangriji-mcp"]
        }
    }
}
```

### Claude Code

编辑 `~/.claude/settings.json` 或项目 `.mcp.json`：

```json
{
    "mcpServers": {
        "liuliangriji": {
            "command": "uvx",
            "args": ["liuliangriji-mcp"]
        }
    }
}
```

### VS Code Copilot

创建 `.vscode/mcp.json`：

```json
{
    "servers": {
        "liuliangriji": {
            "command": "uvx",
            "args": ["liuliangriji-mcp"]
        }
    }
}
```

### Cursor

编辑 `~/.cursor/mcp.json`：

```json
{
    "mcpServers": {
        "liuliangriji": {
            "command": "uvx",
            "args": ["liuliangriji-mcp"]
        }
    }
}
```

### Trae

编辑 `~/.trae/mcp.json`：

```json
{
    "mcpServers": {
        "liuliangriji": {
            "command": "uvx",
            "args": ["liuliangriji-mcp"]
        }
    }
}
```

## 可用工具

| 工具名 | 说明 |
|--------|------|
| `liuliangriji_check_connection` | 检查流量日记连接状态 |
| `liuliangriji_list_accounts` | 列出所有自媒体账号 |
| `liuliangriji_wechat_account_daily` | 公众号每日统计 |
| `liuliangriji_wechat_article_stats` | 文章 7 日数据 |
| `liuliangriji_wechat_top_articles` | 热门文章排行 |
| `liuliangriji_wechat_followers` | 粉丝增长数据 |
| `liuliangriji_xhs_account_traffic` | 小红书账号流量 |
| `liuliangriji_xhs_notes` | 小红书笔记数据 |
| `liuliangriji_import_history` | 查询导入历史 |
| `liuliangriji_export_csv` | 导出 CSV 数据 |

## 使用示例

配置完成后，在 AI 对话中即可使用：

```
用户：我公众号上周的阅读量趋势怎么样？
用户：帮我对比一下小红书和公众号最近一个月的粉丝增长
用户：哪篇文章的阅读量最高？
```

## 许可证

MIT
