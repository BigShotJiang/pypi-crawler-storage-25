# web session header

```
0.0.1 未经严谨测试
0.0.2 修复部分问题
```
