"""Extractor テストパッケージ."""
