# aifx/constants/DInstrument.py
#
#    AI FX
#    Author: Nadim-Daniel Ghaznavi
#    Copyright: (c) 2026 Nadim-Daniel Ghaznavi
#    GitHub: https://github.com/NadimGhaznavi/aifx
#    Website: https://aifx.osoyalce.com
#    License: GPL 3.0from typing import Final

from typing import Final


class DInstrument:

    DISPLAY_NAME: Final[str] = "displayName"
    NAME: Final[str] = "name"
    INSTRUMENT: Final[str] = "Instrument"
    MARGIN_RATE: Final[str] = "marginRate"
    TYPE: Final[str] = "type"
    PIP_LOC: Final[str] = "pipLocation"
    STARTED: Final[str] = "started"


class DInstrumentF:
    INSTRUMENT: Final[str] = "instrument"
    INSTRUMENTS: Final[str] = "instruments"
    TOPIC: Final[str] = "topic"
