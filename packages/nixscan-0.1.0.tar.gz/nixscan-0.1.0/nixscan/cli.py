import argparse
import logging
import sys

from dotenv import load_dotenv
from .scanner import Scanner

def main():
    load_dotenv()
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    parser = argparse.ArgumentParser(description="AI-Powered Security Code Scanner")
    parser.add_argument("target", nargs='?', help="Local directory path or Git URL to scan. Falls back to '.' if not provided.")
    parser.add_argument("--reports-dir", default="reports", help="Directory to save vulnerability reports")
    parser.add_argument("--tracker", default=".scanned_files_tracker.json", help="Tracker JSON file path")
    args = parser.parse_args()

    target = args.target

    if not target:
        target = "."

    scanner = Scanner(target=target, reports_dir=args.reports_dir, tracker_file=args.tracker)
    
    try:
        scanner.run()
    except Exception as e:
        logging.error(f"Scan failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
