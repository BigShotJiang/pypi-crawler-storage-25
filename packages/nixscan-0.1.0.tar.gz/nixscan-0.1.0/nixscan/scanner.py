import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from dotenv import load_dotenv

logger = logging.getLogger(__name__)

try:
    from nixagent import Agent
except ImportError:
    Agent = None

SYSTEM_PROMPT = """You are an elite application security engineer. Your objective is to perform a rigorous static code analysis on the provided source code.

Analyze the code heavily for the following threats:
1. Malicious intents (e.g., quietly sending sensitive data or telemetry to remote servers).
2. Known security vulnerabilities (e.g., SQL Injection, XSS, CSRF, remote code execution).
3. Hardcoded credentials, exposed API keys, or unsecured local states.

OUTPUT FORMAT REQUIREMENTS:
You must reply STRICTLY with a valid JSON object. Do not include markdown code blocks or conversational text. Your response must be purely parseable JSON.

If you analyze the code and guarantee there are no security risks or suspicious activity, return exactly:
{
  "isFileCleaned": true
}

If you find ANY potential vulnerability, suspicious external network call, or insecure practice, return:
{
  "isFileCleaned": false,
  "report": "Provide a comprehensive explanation here. Include the severity of the issue, the exact snippet or line of code that is vulnerable, and a recommended fix."
}"""

class Scanner:
    def __init__(self, target: str, reports_dir="reports", tracker_file=".scanned_files_tracker.json"):
        load_dotenv()
        
        if Agent is None:
            raise ImportError("nixagent is not installed. Please run `pip install nixagent` first.")
            
        self.target = target
        self.reports_dir = reports_dir
        self.tracker_file = tracker_file
        
        self.ignored_dirs = {'.git', '__pycache__', 'node_modules', 'venv', '.venv', 'env', '.env'}
        self.ignored_extensions = {
            '.jpg', '.jpeg', '.png', '.gif', '.ico', '.pdf', '.zip', '.tar', '.gz',
            '.mp3', '.mp4', '.bin', '.exe', '.dll', '.so', '.pyc', '.class', '.whl'
        }

    def is_git_url(self, url: str) -> bool:
        return url.startswith("http://") or url.startswith("https://") or url.startswith("git@")

    def clone_repo(self, url: str, dest: str):
        logger.info(f"Cloning repository {url} into local folder...")
        try:
            subprocess.run(["git", "clone", url, dest], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to clone repository: {url}")
            raise RuntimeError(f"Failed to clone: {e}")

    def load_tracker(self) -> list:
        if os.path.exists(self.tracker_file):
            try:
                with open(self.tracker_file, 'r') as f:
                    data = json.load(f)
                    return data.get("scanned_files", [])
            except Exception as e:
                logger.error(f"Failed to read tracker file: {e}")
                return []
        return []

    def save_tracker_append(self, filepath: str):
        scanned = self.load_tracker()
        if filepath not in scanned:
            scanned.append(filepath)
            with open(self.tracker_file, 'w') as f:
                json.dump({"scanned_files": scanned}, f, indent=4)

    def is_source_file(self, filepath: Path) -> bool:
        if filepath.is_dir():
            return False
        for part in filepath.parts:
            if part in self.ignored_dirs:
                return False
        if filepath.suffix.lower() in self.ignored_extensions:
            return False
        return True

    def clean_json_string(self, s: str) -> str:
        s = s.strip()
        if s.startswith("```json"):
            s = s[7:]
        elif s.startswith("```"):
            s = s[3:]
        if s.endswith("```"):
            s = s[:-3]
        return s.strip()

    def process_file(self, filepath_obj: Path):
        abs_path = str(filepath_obj.resolve())
        scanned_files = self.load_tracker()

        if abs_path in scanned_files:
            logger.info(f"Skipping already scanned file: {abs_path}")
            return

        if filepath_obj.stat().st_size > 1_000_000:
            logger.info(f"Skipping large file: {abs_path}")
            return

        try:
            with open(filepath_obj, 'r', encoding='utf-8') as f:
                content = f.read()
        except UnicodeDecodeError:
            logger.info(f"Skipping non-UTF8 file: {abs_path}")
            return
        except Exception as e:
            logger.error(f"Failed to read file {abs_path}: {e}")
            return

        if not content.strip():
            return

        logger.info(f"Scanning file: {abs_path}")

        agent = Agent(
            name="SecurityScanner",
            system_prompt=SYSTEM_PROMPT,
            use_builtin_tools=False
        )

        try:
            reply = agent.run(user_prompt=content)
        except Exception as e:
            logger.error(f"Agent failed to scan {abs_path}: {e}")
            return

        clean_reply = self.clean_json_string(reply)

        try:
            result = json.loads(clean_reply)
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON returned for {abs_path}: {e}\nRaw: {reply}")
            return

        is_cleaned = result.get("isFileCleaned", True)

        if not is_cleaned:
            report = result.get("report", "No details provided.")
            safe_name = filepath_obj.name.replace('.', '_') + "_report.md"
            report_path = os.path.join(self.reports_dir, safe_name)
            
            os.makedirs(self.reports_dir, exist_ok=True)

            with open(report_path, 'w', encoding='utf-8') as rf:
                rf.write(f"# Vulnerability Report for {filepath_obj.name}\n\n")
                rf.write(f"**Original Path:** `{abs_path}`\n\n")
                rf.write(report)
            
            logger.warning(f"Issues found in {filepath_obj.name}! Saved report to {report_path}")
        else:
             logger.info(f"File {filepath_obj.name} is clean.")

        self.save_tracker_append(abs_path)

    def start_scan(self, target_dir: str):
        base_dir = Path(target_dir).resolve()
        
        for root, dirs, files in os.walk(base_dir):
            dirs[:] = [d for d in dirs if d not in self.ignored_dirs]

            for file in files:
                file_path = Path(root) / file
                if self.is_source_file(file_path):
                     self.process_file(file_path)

    def run(self):
        os.makedirs(self.reports_dir, exist_ok=True)

        if self.is_git_url(self.target):
            repo_name = self.target.rstrip('/').split('/')[-1]
            if repo_name.endswith('.git'):
                repo_name = repo_name[:-4]
            if not repo_name:
                repo_name = "cloned_repo"
                
            repo_dir = os.path.join(os.getcwd(), repo_name)
            
            if not os.path.exists(repo_dir):
                self.clone_repo(self.target, repo_dir)
            else:
                logger.info(f"Repository {repo_name} already exists. Scanning existing folder.")
                
            self.start_scan(repo_dir)
        else:
            if not os.path.exists(self.target):
                logger.error(f"Target path does not exist: {self.target}")
                raise FileNotFoundError(f"Path not found: {self.target}")
            self.start_scan(self.target)
