# nixscan

nixscan is an AI-powered static code analysis and security scanning tool, built on top of the `nixagent` framework. It deeply inspects local files or cloned Git repositories for malicious intents, security vulnerabilities, and securely manages the evaluation history to be fully resilient against interruptions.

## Installation

```bash
pip install nixscan
```

## Setup

Create a `.env` file where your python script executes (or your current working directory):

```bash
PROVIDER=openai
OPENAI_API_KEY=your_api_key_here
```

## CLI Usage

```bash
nixscan https://github.com/technicalheist/nixclaw
nixscan ./my-local-folder
```

## Python Integration

```python
from nixscan import Scanner

scanner = Scanner(target="https://github.com/some/repo")
scanner.run()
```
