from setuptools import setup, find_packages
import os

long_description = ""
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()

setup(
    name="nixscan",
    version="0.1.0",
    author="nix",
    description="An AI-powered automated security code scanner powered by nixagent",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
    install_requires=[
        "nixagent",
        "python-dotenv"
    ],
    entry_points={
        "console_scripts": [
            "nixscan=nixscan.cli:main",
        ],
    },
)
