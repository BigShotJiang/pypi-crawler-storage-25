# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import TypeAlias

from .channel import Channel

__all__ = ["MessageChannels"]

MessageChannels: TypeAlias = Dict[str, Channel]
