# Userbot Guide (MTProto user account)

## What this is

A userbot in `telecraft` is your regular Telegram user account connected through MTProto.
It is event-driven and pulls updates from Telegram using the `Dispatcher`.

## Prerequisites

1. Create and activate a virtualenv.
2. Install dependencies.
3. Set your Telegram API credentials in `apps/env.sh`.

```bash
python3 -m venv .venv
./.venv/bin/python -m pip install -U pip
./.venv/bin/python -m pip install -e ".[dev]"
cp apps/env.example.sh apps/env.sh
source apps/env.sh
```

Required env vars:
- `TELEGRAM_API_ID`
- `TELEGRAM_API_HASH`

Optional:
- `TELEGRAM_PASSWORD` (if 2FA is enabled)

## Runtime safety

Production is blocked unless both are set:
- `--allow-prod`
- `TELECRAFT_ALLOW_PROD=1`

## Login (user session)

Login writes a user session file and updates the user pointer.

```bash
TELECRAFT_ALLOW_PROD=1 ./.venv/bin/python apps/run.py login --runtime prod --allow-prod --dc 2
```

Important defaults:
- session kind is `user`
- pointer file is `.sessions/<runtime>/current`

## Quick checks

```bash
TELECRAFT_ALLOW_PROD=1 ./.venv/bin/python apps/run.py me --runtime prod --allow-prod
TELECRAFT_ALLOW_PROD=1 ./.venv/bin/python apps/run.py send-self "hello from userbot" --runtime prod --allow-prod
TELECRAFT_ALLOW_PROD=1 ./.venv/bin/python apps/run.py updates --runtime prod --allow-prod
```

## Running a userbot app

Examples:
- `apps/echo_bot.py`
- `apps/command_bot.py`

```bash
TELECRAFT_ALLOW_PROD=1 ./.venv/bin/python apps/command_bot.py --runtime prod --allow-prod
```

## Minimal pattern

```python
from telecraft.bot import Dispatcher, Router, outgoing, command
from telecraft.client import Client

router = Router()

@router.on_message(outgoing() and command("ping"))
async def on_ping(e):
    await e.reply("pong")

app = Client(...)
await app.connect()
await Dispatcher(client=app.raw, router=router, ignore_outgoing=False).run()
```

## Common pitfalls

- User accounts cannot behave exactly like Bot API bots in every Telegram client UX flow.
- Sending to channels/DMs may need entity priming (`access_hash` cache). `Dispatcher` does best-effort priming on startup.
- If you accidentally load a non-prod session, runtime isolation blocks startup.

## Session files (user kind)

Typical files:
- `.sessions/prod/prod_dcX.session.json`
- `.sessions/prod/current`

You can override selection with:
- `--session /path/to/file`
- `--session-kind user`
