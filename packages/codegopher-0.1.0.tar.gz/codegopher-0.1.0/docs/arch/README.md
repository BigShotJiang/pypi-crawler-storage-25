# Architecture Docs

These docs describe implemented CodeGopher runtime architecture.

- [SESSION](SESSION.md): reusable `AgentSession`, provider-ready history, TUI resume, and session safety.
- [CONTEXT](CONTEXT.md): context builder, token budget accounting, thresholds, compaction, skills, memory, and TODO context.
- [MEMORY](MEMORY.md): local memory storage, `save_memory`, TUI memory commands, redaction, and context injection.
- [SKILLS](SKILLS.md): Markdown skill discovery, built-in skill packs, project materialization, and static-only security boundaries.
- [PROVIDERS_MCP](PROVIDERS_MCP.md): Chat Completions/Responses provider selection and MCP stdio/SSE tool lifecycle.
