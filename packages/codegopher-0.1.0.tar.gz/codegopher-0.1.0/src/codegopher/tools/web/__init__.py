"""Web tools (fetch, search)."""
