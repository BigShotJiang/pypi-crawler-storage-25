"""Git integration tools."""
