"""Shell execution tool."""
