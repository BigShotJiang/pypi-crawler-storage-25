"""Bootstrap a Frisky cluster inside an existing Dask cluster.

Usage:

    from dask.distributed import LocalCluster, Client as DaskClient
    import frisky

    with LocalCluster() as dc:
        with DaskClient(dc) as dask_client:
            frisky_client = frisky.hijack(dask_client)
            assert frisky_client.submit(lambda: 10).result() == 10

The Frisky scheduler runs inside the Dask scheduler process; one Frisky
worker runs inside each Dask worker process. The Frisky scheduler address
is stored on the Dask scheduler as `frisky_address` so workers (and the
returned client) can connect.

The Frisky dashboard is also mounted on the Dask scheduler's HTTP server,
replacing the Dask dashboard at `/`. This means the existing Dask dashboard
URL (e.g. `http://host:8787/`) now serves the Frisky dashboard. The
underlying Dask dashboard pages (`/status`, `/workers`, ...) and operational
endpoints (`/metrics`, `/health`, `/json/identity.json`, ...) remain reachable
at their original paths — see `install_dashboard_proxy` for the exact claimed
route list.
"""
import os
import tempfile
from urllib.parse import urlparse

import tornado.httpclient
import tornado.ioloop
import tornado.web
import tornado.websocket
from distributed.diagnostics.plugin import SchedulerPlugin, WorkerPlugin

from frisky.frisky import Client, Scheduler, Worker, generate_tls_material


def _write_pem(content, suffix):
    """Write a PEM string to a tmp file and return the path.

    Used by the plugins to shuttle cert material from the laptop's
    `hijack()` call to the actual scheduler/worker processes — `Scheduler`
    and `Worker` accept paths, not in-memory PEMs.
    """
    f = tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False)
    f.write(content)
    f.close()
    return f.name


class FriskySchedulerPlugin(SchedulerPlugin):
    name = "frisky-scheduler"
    idempotent = True

    def __init__(self, tls_port=None, tls_cert_pem=None, tls_key_pem=None, tls_ca_pem=None):
        # When tls_port is set, scheduler binds tls://0.0.0.0:tls_port with
        # the supplied cert/key. The cert is generated on the laptop side
        # (caller of hijack()), then shipped over the wire as PEM strings —
        # one fewer filesystem dependency on the scheduler VM.
        #
        # tls_ca_pem turns on mTLS: the scheduler will require + verify a
        # client cert during the handshake. For the single-self-signed-cert
        # dev pattern this is the same content as tls_cert_pem.
        self.tls_port = tls_port
        self.tls_cert_pem = tls_cert_pem
        self.tls_key_pem = tls_key_pem
        self.tls_ca_pem = tls_ca_pem
        self._tmp_paths = []

    def start(self, scheduler):
        self._dask_scheduler = scheduler
        if self.tls_port is not None:
            if not self.tls_cert_pem or not self.tls_key_pem:
                raise ValueError("tls_port requires tls_cert_pem and tls_key_pem")
            cert_path = _write_pem(self.tls_cert_pem, ".pem")
            key_path = _write_pem(self.tls_key_pem, ".pem")
            self._tmp_paths = [cert_path, key_path]
            tls_kwargs = dict(tls_cert=cert_path, tls_key=key_path)
            if self.tls_ca_pem is not None:
                ca_path = _write_pem(self.tls_ca_pem, ".pem")
                self._tmp_paths.append(ca_path)
                tls_kwargs["tls_ca_file"] = ca_path
            bind = f"tls://0.0.0.0:{self.tls_port}"
            self.scheduler = Scheduler(
                bind,
                dashboard=True,
                dashboard_address="127.0.0.1:0",
                **tls_kwargs,
            )
        else:
            # Plaintext path is locked down to localhost. Anything that
            # needs to talk across machines (real cluster, Coiled, anywhere
            # that workers live on a different host) must use tls_port —
            # exposing plain TCP across the network is a credential leak
            # waiting to happen. LocalCluster works because every party is
            # on 127.0.0.1.
            self.scheduler = Scheduler(
                "127.0.0.1:0",
                dashboard=True,
                dashboard_address="127.0.0.1:0",
            )
        bound_port = self.scheduler.address.rsplit(":", 1)[1]
        dask_host = urlparse(scheduler.address).hostname or "127.0.0.1"
        scheme = "tls://" if self.tls_port is not None else ""
        scheduler.frisky_address = f"{scheme}{dask_host}:{bound_port}"
        if self.scheduler.dashboard_address:
            scheduler.frisky_dashboard = self.scheduler.dashboard_address
            install_dashboard_proxy(scheduler, self.scheduler.dashboard_address)

    async def close(self):
        # Point the proxy at no upstream BEFORE shutting Frisky down, so any
        # in-flight requests get a clean 503 instead of a confusing ConnectionRefused.
        s = getattr(self, "_dask_scheduler", None)
        if s is not None:
            getattr(s, "_frisky_proxy_state", {}).pop("upstream", None)
        self.scheduler.close()
        for p in self._tmp_paths:
            try:
                os.unlink(p)
            except OSError:
                pass


class FriskyWorkerPlugin(WorkerPlugin):
    name = "frisky-worker"
    idempotent = True

    def __init__(
        self,
        scheduler_address,
        tls_cert_pem=None,
        tls_key_pem=None,
        tls_ca_pem=None,
    ):
        # Workers act as both client (dialing the scheduler) and server
        # (other workers fetch data from them). With TLS that means they
        # need their own identity (cert/key) and the CA to verify the
        # scheduler. For the single-self-signed-cert dev pattern (what
        # hijack uses) all three PEMs are the same content.
        self.scheduler_address = scheduler_address
        self.tls_cert_pem = tls_cert_pem
        self.tls_key_pem = tls_key_pem
        self.tls_ca_pem = tls_ca_pem
        self._tmp_paths = []

    def setup(self, worker):
        tls_kwargs = {}
        if self.scheduler_address.startswith("tls://"):
            if not (self.tls_cert_pem and self.tls_key_pem and self.tls_ca_pem):
                raise ValueError(
                    "tls:// scheduler_address requires tls_cert_pem, tls_key_pem, tls_ca_pem"
                )
            cert_path = _write_pem(self.tls_cert_pem, ".pem")
            key_path = _write_pem(self.tls_key_pem, ".pem")
            ca_path = _write_pem(self.tls_ca_pem, ".pem")
            self._tmp_paths = [cert_path, key_path, ca_path]
            # Listen address scheme must match the scheduler scheme — the
            # Worker constructor enforces that, so we mirror tls:// here.
            tls_kwargs = dict(
                listen_address="tls://0.0.0.0:0",
                tls_cert=cert_path,
                tls_key=key_path,
                tls_ca_file=ca_path,
            )
        self.worker = Worker(
            self.scheduler_address,
            nthreads=worker.state.nthreads,
            memory_limit=worker.memory_manager.memory_limit,
            **tls_kwargs,
        )

    def teardown(self, worker):
        self.worker.close()
        for p in self._tmp_paths:
            try:
                os.unlink(p)
            except OSError:
                pass


def hijack(dask_client, connect_client=True, tls_port=None):
    """Bootstrap a Frisky cluster on a running Dask cluster and return a Frisky Client.

    Parameters
    ----------
    dask_client:
        A connected ``distributed.Client``.
    connect_client:
        If ``True`` (default), construct and return a ``frisky.Client``
        bound to the Frisky scheduler. The Client constructor fails fast
        (~5 s default) with a :class:`ConnectionError` if the address
        isn't reachable, so leaving this on is usually fine; pass
        ``False`` to skip the Client step entirely and submit via
        ``dask_client.run_on_scheduler`` instead.
    tls_port:
        If set (e.g. ``17786``), bring up Frisky over TLS with mutual
        authentication. The Frisky scheduler binds
        ``tls://0.0.0.0:tls_port`` and requires a client cert during the
        TLS handshake (mTLS). Each worker dials it via
        ``tls://<vpc-internal-ip>:tls_port``; the returned Client dials
        ``tls://<public-host>:tls_port``. All three parties share one
        self-signed cert that hijack() generates and ships over Dask —
        the same cert serves as identity AND trust root, and any party
        without it gets rejected at handshake time.

        On Coiled the cluster's public scheduler port (443) is reserved
        for Dask comms, so you need to add ``tls_port`` to the cluster's
        ingress list:

            cluster = coiled.Cluster(
                ...,
                backend_options={"ingress": [
                    {"ports": [443, 8786, 17786], "cidr": "0.0.0.0/0"},
                ]},
            )
            client = frisky.hijack(dask_client, tls_port=17786)

        For LocalCluster, no ingress fuss — both public and internal
        host are ``127.0.0.1``.

        When ``tls_port`` is None (the default), Frisky runs in plaintext
        mode but binds only to ``127.0.0.1`` — fine for LocalCluster,
        broken-by-design for any deployment where workers live on a
        different host. That's intentional: plaintext-over-WAN would be
        a credential leak. Use ``tls_port`` whenever workers and the
        scheduler aren't on the same machine.
    """
    if tls_port is None:
        # Plaintext path (back-compat).
        dask_client.register_plugin(FriskySchedulerPlugin())
        frisky_address = dask_client.run_on_scheduler(
            lambda dask_scheduler: dask_scheduler.frisky_address
        )
        dask_client.register_plugin(FriskyWorkerPlugin(frisky_address))
        if connect_client:
            return Client(frisky_address)
        return None

    # TLS path. Generate one self-signed cert covering both the public
    # host (how the laptop dials) and the internal host (how workers dial).
    # rcgen treats each SAN string as an IP if it parses as one, else as
    # DNS — so passing the IP literals directly Just Works.
    public_host = urlparse(dask_client.scheduler.address).hostname or "127.0.0.1"
    internal_host = dask_client.run_on_scheduler(
        lambda dask_scheduler: urlparse(dask_scheduler.address).hostname or "127.0.0.1"
    )
    sans = list(dict.fromkeys([public_host, internal_host, "localhost", "127.0.0.1"]))
    cert_pem, key_pem = generate_tls_material(sans)

    # Plugin idempotency would otherwise keep stale TLS material from a
    # previous hijack() — explicit unregister so each call rebuilds fresh.
    for fn, name in (
        (dask_client.unregister_worker_plugin, "frisky-worker"),
        (dask_client.unregister_scheduler_plugin, "frisky-scheduler"),
    ):
        try:
            fn(name)
        except Exception:  # noqa: BLE001 — best-effort cleanup
            pass

    # mTLS everywhere: scheduler gets the same self-signed cert as its CA
    # for client verification; workers and the laptop client present the
    # same cert as their identity. Net effect: the only parties that can
    # open a frisky channel are those holding this cert.
    dask_client.register_plugin(FriskySchedulerPlugin(
        tls_port=tls_port,
        tls_cert_pem=cert_pem,
        tls_key_pem=key_pem,
        tls_ca_pem=cert_pem,
    ))
    frisky_address = dask_client.run_on_scheduler(
        lambda dask_scheduler: dask_scheduler.frisky_address
    )
    dask_client.register_plugin(FriskyWorkerPlugin(
        frisky_address,
        tls_cert_pem=cert_pem,
        tls_key_pem=key_pem,
        tls_ca_pem=cert_pem,
    ))

    if not connect_client:
        return None

    # The Client dials via the *public* host (what the laptop can reach),
    # not the internal address stored on the scheduler. Same cert serves
    # as the trust root AND as the client's identity for mTLS.
    cert_path = _write_pem(cert_pem, ".pem")
    key_path = _write_pem(key_pem, ".pem")
    ca_path = _write_pem(cert_pem, ".pem")
    public_address = f"tls://{public_host}:{tls_port}"
    return Client(
        public_address,
        tls_ca_file=ca_path,
        tls_cert=cert_path,
        tls_key=key_path,
    )


# ---------------------------------------------------------------------------
# Dashboard proxy
# ---------------------------------------------------------------------------
#
# Frisky's scheduler runs its own dashboard HTTP server on a random local port.
# We install Tornado handlers on the Dask scheduler's http_application so that
# requests to the Dask dashboard port are reverse-proxied to Frisky.
#
# Top-level routes added via `add_handlers` take priority over the BokehApplication
# routes that Dask's dashboard installs (see distributed.http.routing.RoutingApplication).
# That lets us claim `/` for Frisky while leaving Dask's `/status`, `/workers`, etc.
# reachable at their original paths.


# Hop-by-hop headers (RFC 7230 6.1) plus content-encoding/length.
# We strip content-encoding because tornado's AsyncHTTPClient decompresses
# the body by default — forwarding the original encoding would cause double
# decompression in the browser.
_DROP_HEADERS = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host",
    "content-length", "content-encoding",
}


class _HTTPProxy(tornado.web.RequestHandler):
    """Forward HTTP requests to an upstream URL, preserving method/body/headers."""

    SUPPORTED_METHODS = ("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS")

    def initialize(self, state):
        # `state` is a dict shared with install_dashboard_proxy; "upstream" is
        # either the upstream base URL (e.g. "http://127.0.0.1:54321") or None
        # when the Frisky scheduler is shutting down.
        self._state = state

    async def _forward(self):
        upstream = self._state.get("upstream")
        if upstream is None:
            self.set_status(503)
            self.write("Frisky dashboard not available")
            return
        url = upstream + self.request.uri
        headers = {k: v for k, v in self.request.headers.items()
                   if k.lower() not in _DROP_HEADERS}
        body = self.request.body if self.request.method in ("POST", "PUT", "PATCH") else None
        client = tornado.httpclient.AsyncHTTPClient()
        try:
            resp = await client.fetch(
                url,
                method=self.request.method,
                headers=headers,
                body=body,
                allow_nonstandard_methods=True,
                follow_redirects=False,
                raise_error=False,
                request_timeout=30,
            )
        except Exception as e:
            self.set_status(502)
            self.write(f"Bad gateway: {e}")
            return
        self.set_status(resp.code)
        for header, value in resp.headers.get_all():
            if header.lower() in _DROP_HEADERS:
                continue
            self.set_header(header, value)
        if resp.body:
            self.write(resp.body)

    async def get(self, *args, **kwargs):    await self._forward()
    async def post(self, *args, **kwargs):   await self._forward()
    async def put(self, *args, **kwargs):    await self._forward()
    async def delete(self, *args, **kwargs): await self._forward()
    async def patch(self, *args, **kwargs):  await self._forward()
    async def head(self, *args, **kwargs):   await self._forward()
    async def options(self, *args, **kwargs): await self._forward()


class _WebSocketProxy(tornado.websocket.WebSocketHandler):
    """Bidirectional WebSocket reverse proxy."""

    def initialize(self, state):
        self._state = state
        self._upstream = None

    def check_origin(self, origin):
        # Browser already connected to the Dask dashboard; trust that origin.
        return True

    async def open(self):
        upstream_ws = self._state.get("ws_upstream")
        if upstream_ws is None:
            self.close(code=1011, reason="frisky dashboard not available")
            return
        try:
            self._upstream = await tornado.websocket.websocket_connect(upstream_ws)
        except Exception:
            self.close(code=1011, reason="upstream connect failed")
            return
        tornado.ioloop.IOLoop.current().spawn_callback(self._pump_from_upstream)

    async def _pump_from_upstream(self):
        try:
            while True:
                msg = await self._upstream.read_message()
                if msg is None:
                    break
                await self.write_message(msg, binary=isinstance(msg, (bytes, bytearray)))
        except Exception:
            pass
        finally:
            self.close()

    async def on_message(self, message):
        # NB: must be async — write_message returns a coroutine on
        # WebSocketClientConnection; a sync handler would silently drop frames.
        if self._upstream is not None:
            await self._upstream.write_message(
                message, binary=isinstance(message, (bytes, bytearray))
            )

    def on_close(self):
        if self._upstream is not None:
            self._upstream.close()
            self._upstream = None


def install_dashboard_proxy(dask_scheduler, frisky_dashboard_url):
    """Mount a reverse proxy to the Frisky dashboard on the Dask HTTP application.

    Routes claimed on the Dask dashboard port: `/`, `/ws`, `/api/*`, `/assets/*`,
    `/vite.svg`. Dask's own pages (`/status`, `/workers`, `/json/identity.json`,
    `/metrics`, `/health`, ...) remain reachable at their original paths.

    Idempotent: a second call updates the upstream URL in place. After the
    Frisky scheduler closes, requests get a clean 503 until a new hijack runs.
    """
    parsed = urlparse(frisky_dashboard_url)
    state = getattr(dask_scheduler, "_frisky_proxy_state", None)
    if state is None:
        state = {}
        dask_scheduler._frisky_proxy_state = state
        # Note: `/health` deliberately falls through to Dask's
        # `distributed.http.health` handler — Frisky doesn't need to own it,
        # and load-balancer probes that expect Dask-shaped JSON keep working.
        # `/metrics` (Prometheus, scraped by Coiled) also falls through.
        routes = [
            (r"/ws", _WebSocketProxy, dict(state=state)),
            (r"/api/.*", _HTTPProxy, dict(state=state)),
            (r"/assets/.*", _HTTPProxy, dict(state=state)),
            (r"/vite\.svg", _HTTPProxy, dict(state=state)),
            (r"/", _HTTPProxy, dict(state=state)),
        ]
        dask_scheduler.http_application.add_handlers(r".*", routes)
    state["upstream"] = f"http://{parsed.netloc}"
    state["ws_upstream"] = f"ws://{parsed.netloc}/ws"
