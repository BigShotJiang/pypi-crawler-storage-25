"""
A2A v0.3 Backward Compatibility Layer.

Internal models are now native v1.0.
This module translates v0.3 wire format INPUT to v1.0 internal types,
so old clients (tasks/send, {type:"text"}, COMPLETED) still work.
"""

from typing import Any, Dict, List, Optional, Union
from .a2a_protocol import (
    TaskState, Message, TextPart, FilePart, DataPart, Part,
    Task, Artifact, TaskStatusUpdateEvent, TaskMessageEvent, TaskArtifactUpdateEvent,
)

# ─── State Translation ──────────────────────────────────────────────────────

# Accept both v1.0 and v0.3 state strings → internal TaskState (now v1.0 native)
STATE_STRING_TO_INTERNAL: Dict[str, TaskState] = {
    # v1.0 values (native)
    "TASK_STATE_SUBMITTED": TaskState.SUBMITTED,
    "TASK_STATE_WORKING": TaskState.WORKING,
    "TASK_STATE_INPUT_REQUIRED": TaskState.INPUT_REQUIRED,
    "TASK_STATE_COMPLETED": TaskState.COMPLETED,
    "TASK_STATE_FAILED": TaskState.FAILED,
    "TASK_STATE_CANCELED": TaskState.CANCELED,
    "TASK_STATE_REJECTED": TaskState.REJECTED,
    "TASK_STATE_AUTH_REQUIRED": TaskState.AUTH_REQUIRED,
    # v0.3 values (backward compat)
    "SUBMITTED": TaskState.SUBMITTED,
    "WORKING": TaskState.WORKING,
    "INPUT_REQUIRED": TaskState.INPUT_REQUIRED,
    "COMPLETED": TaskState.COMPLETED,
    "FAILED": TaskState.FAILED,
    "CANCELED": TaskState.CANCELED,
    "REJECTED": TaskState.REJECTED,
    "AUTH_REQUIRED": TaskState.AUTH_REQUIRED,
}


def state_from_v1(v1_state: str) -> TaskState:
    """Convert any state string (v0.3 or v1.0) to internal TaskState."""
    return STATE_STRING_TO_INTERNAL.get(v1_state, TaskState.WORKING)


def state_to_v1(state: TaskState) -> str:
    """Return the v1.0 wire value (TaskState is already v1.0 native)."""
    return state.value


# ─── Role Translation ───────────────────────────────────────────────────────

# Accept all role variants → internal v1.0 role (user/agent)
ROLE_TO_INTERNAL = {"user": "user", "agent": "agent", "assistant": "agent", "ROLE_USER": "user", "ROLE_AGENT": "agent", "system": "user", "tool": "user"}
INTERNAL_ROLE_TO_WIRE = {"user": "user", "agent": "agent", "assistant": "agent"}


def role_from_v1(v1_role: str) -> str:
    """Convert any role string (v0.3 or v1.0) to internal v1.0 role."""
    return ROLE_TO_INTERNAL.get(v1_role, "user")


def role_to_v1(role: str) -> str:
    """Return v1.0 wire role."""
    return INTERNAL_ROLE_TO_WIRE.get(role, "user")


# ─── Part Translation ────────────────────────────────────────────────────────

def part_from_v1(v1_part: Dict[str, Any]) -> Part:
    """Convert v1.0 unified Part to internal typed Part.

    v1.0: {"text": "hello"} or {"url": "...", "media_type": "..."} or {"data": {...}}
    v0.3: TextPart(type="text", content="hello") etc.
    """
    # v1.0 format: field name IS the discriminator
    if "text" in v1_part:
        return TextPart(content=v1_part["text"])
    elif "url" in v1_part:
        return FilePart(
            url=v1_part["url"],
            media_type=v1_part.get("media_type") or v1_part.get("mediaType"),
            filename=v1_part.get("filename"),
        )
    elif "data" in v1_part:
        data = v1_part["data"]
        if not isinstance(data, dict):
            data = {"value": data}
        return DataPart(
            content=data,
            media_type=v1_part.get("media_type") or v1_part.get("mediaType") or "application/json",
        )
    elif "raw" in v1_part:
        # v1.0 raw bytes → store as DataPart with base64
        return DataPart(
            content={"raw_base64": v1_part["raw"], "media_type": v1_part.get("media_type")},
            media_type=v1_part.get("media_type") or "application/octet-stream",
        )
    # Fallback: check v0.3 format (type field)
    elif "type" in v1_part:
        ptype = v1_part["type"]
        if ptype == "text":
            return TextPart(content=v1_part.get("content", ""))
        elif ptype == "file":
            return FilePart(
                url=v1_part.get("url", ""),
                media_type=v1_part.get("mediaType") or v1_part.get("media_type"),
                filename=v1_part.get("filename"),
            )
        elif ptype == "data":
            return DataPart(
                content=v1_part.get("content", {}),
                media_type=v1_part.get("mediaType") or v1_part.get("media_type") or "application/json",
            )
    return TextPart(content="")


def part_to_v1(part: Part) -> Dict[str, Any]:
    """Convert internal typed Part to v1.0 unified Part."""
    if isinstance(part, TextPart):
        return {"text": part.content}
    elif isinstance(part, FilePart):
        r: Dict[str, Any] = {"url": str(part.url)}
        if part.media_type:
            r["media_type"] = part.media_type
        if part.filename:
            r["filename"] = part.filename
        return r
    elif isinstance(part, DataPart):
        r = {"data": part.content}
        if part.media_type and part.media_type != "application/json":
            r["media_type"] = part.media_type
        return r
    return {"text": ""}


# ─── Message Translation ────────────────────────────────────────────────────

def message_from_v1(v1_msg: Dict[str, Any]) -> Message:
    """Convert v1.0 message to internal Message."""
    role = role_from_v1(v1_msg.get("role", "user"))
    parts_raw = v1_msg.get("parts", [])
    parts = [part_from_v1(p) for p in parts_raw] if parts_raw else [TextPart(content="")]
    return Message(role=role, parts=parts, metadata=v1_msg.get("metadata"))


def message_to_v1(msg: Message) -> Dict[str, Any]:
    """Convert internal Message to v1.0 wire format."""
    return {
        "role": role_to_v1(msg.role),
        "parts": [part_to_v1(p) for p in msg.parts],
        "metadata": msg.metadata,
    }


# ─── Task Translation ───────────────────────────────────────────────────────

def task_to_v1(task: Task) -> Dict[str, Any]:
    """Convert internal Task to v1.0 wire format."""
    return {
        "id": task.id,
        "status": {
            "state": state_to_v1(task.state),
            "timestamp": task.updated_at.isoformat() if task.updated_at else None,
        },
        "history": [message_to_v1(m) for m in task.messages],
        "artifacts": [
            {
                "artifact_id": a.id,
                "name": a.type,
                "parts": [part_to_v1(TextPart(content=str(a.content)))] if a.content else
                         [{"url": str(a.url)}] if a.url else [],
                "metadata": a.metadata,
            }
            for a in task.artifacts
        ],
        "metadata": task.metadata,
    }


# ─── SSE Event Translation ──────────────────────────────────────────────────

def sse_event_to_v1(event: Any) -> Optional[Dict[str, Any]]:
    """Convert internal SSE event to v1.0 StreamResponse format."""
    if isinstance(event, TaskStatusUpdateEvent):
        return {
            "statusUpdate": {
                "taskId": event.task_id,
                "status": {
                    "state": state_to_v1(event.state),
                    "timestamp": event.timestamp.isoformat(),
                    "message": event.message,
                },
            }
        }
    elif isinstance(event, TaskMessageEvent):
        return {
            "message": message_to_v1(event.message),
        }
    elif isinstance(event, TaskArtifactUpdateEvent):
        return {
            "artifactUpdate": {
                "taskId": event.task_id,
                "artifact": {
                    "artifact_id": event.artifact.id,
                    "name": event.artifact.type,
                    "parts": [part_to_v1(TextPart(content=str(event.artifact.content)))] if event.artifact.content else [],
                },
                "lastChunk": True,
            }
        }
    return None


# ─── Method Name Translation ─────────────────────────────────────────────────

# v1.0 method → v0.3 method
V1_METHOD_TO_INTERNAL = {
    "message/send": "tasks/send",
    "message/stream": "tasks/sendSubscribe",
    "tasks/get": "tasks/get",
    "tasks/cancel": "tasks/cancel",
    # v0.3 names pass through
    "tasks/send": "tasks/send",
    "tasks/sendSubscribe": "tasks/sendSubscribe",
}


def method_from_v1(method: str) -> str:
    """Convert v1.0 method name to internal v0.3 method name."""
    return V1_METHOD_TO_INTERNAL.get(method, method)
