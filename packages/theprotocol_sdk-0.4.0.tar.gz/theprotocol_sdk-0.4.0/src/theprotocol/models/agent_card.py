"""
Pydantic models for A2A Agent Cards.
Supports A2A v1.0 wire format with v0.3 internal fields.
Full v1.0 Agent Card schema (supported_interfaces, security_schemes) planned for SDK v2.0.
"""

from typing import List, Optional, Dict, Any, Literal
from pydantic import BaseModel, Field, HttpUrl, AnyUrl, ConfigDict, model_validator


class AgentProvider(BaseModel):
    name: str
    url: Optional[HttpUrl] = None
    support_contact: Optional[str] = None


class AgentSkill(BaseModel):
    id: str
    name: str
    description: str
    input_schema: Optional[Dict[str, Any]] = None
    output_schema: Optional[Dict[str, Any]] = None


class AgentAuthentication(BaseModel):
    scheme: Literal['apiKey', 'bearer', 'oauth2', 'none']
    description: Optional[str] = None
    token_url: Optional[HttpUrl] = Field(None, alias="tokenUrl")
    scopes: Optional[List[str]] = None
    service_identifier: Optional[str] = None

    @model_validator(mode='after')
    def check_oauth2_fields(self) -> 'AgentAuthentication':
        if self.scheme == 'oauth2' and self.token_url is None:
            raise ValueError("'tokenUrl' is required when scheme is 'oauth2'")
        return self


class TeeDetails(BaseModel):
    type: str
    attestation_endpoint: Optional[HttpUrl] = Field(None, alias="attestationEndpoint")
    public_key: Optional[str] = Field(None, alias="publicKey")
    description: Optional[str] = None


class AgentCapabilities(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    streaming: bool = Field(..., description="Whether agent supports SSE streaming.")

    @model_validator(mode='before')
    @classmethod
    def backcompat_streaming_default(cls, data: Any) -> Any:
        if isinstance(data, dict) and 'streaming' not in data:
            data['streaming'] = False
        return data

    a2a_version: Optional[str] = Field(None, alias="a2aVersion")
    mcp_version: Optional[str] = Field(None, alias="mcpVersion")
    supported_message_parts: Optional[List[str]] = Field(None, alias="supportedMessageParts")
    tee_details: Optional[TeeDetails] = Field(None, alias="teeDetails")
    supports_push_notifications: Optional[bool] = Field(None, alias="supportsPushNotifications")
    state_transition_history: Optional[bool] = Field(None, alias="stateTransitionHistory")


class AgentCard(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    protocol_version: str = Field(..., alias="protocolVersion")

    @model_validator(mode='before')
    @classmethod
    def backcompat_schema_version(cls, data: Any) -> Any:
        if isinstance(data, dict) and 'schemaVersion' in data and 'protocolVersion' not in data:
            data['protocolVersion'] = data.pop('schemaVersion')
        return data

    human_readable_id: str = Field(..., alias="humanReadableId")
    agent_version: str = Field(..., alias="agentVersion")
    name: str
    description: str
    url: AnyUrl
    provider: AgentProvider
    capabilities: AgentCapabilities
    auth_schemes: List[AgentAuthentication] = Field(..., alias="authSchemes", min_length=1)
    skills: Optional[List[AgentSkill]] = None
    tags: Optional[List[str]] = None
    privacy_policy_url: Optional[HttpUrl] = Field(None, alias="privacyPolicyUrl")
    terms_of_service_url: Optional[HttpUrl] = Field(None, alias="termsOfServiceUrl")
    icon_url: Optional[HttpUrl] = Field(None, alias="iconUrl")
    last_updated: Optional[str] = Field(None, alias="lastUpdated")
