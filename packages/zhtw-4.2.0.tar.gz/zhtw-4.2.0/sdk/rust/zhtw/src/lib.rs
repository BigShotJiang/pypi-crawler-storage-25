//! Traditional Chinese converter for Taiwan — Rust SDK.
//!
//! Part of the [rajatim/zhtw](https://github.com/rajatim/zhtw) monorepo.

mod builder;
mod config;
mod converter;
mod error;
mod generated;
mod header;
mod matcher;
mod source;

pub use builder::Builder;
pub use config::{AmbiguityMode, Config};
pub use converter::{ConversionDetail, Converter, Layer, LookupResult, Match};
pub use error::{Error, Result};
pub use source::Source;

/// Convert simplified Chinese text to Traditional Chinese (Taiwan) using the
/// default instance (Cn+Hk sources, char layer enabled).
pub fn convert(text: &str) -> String {
    Converter::default_instance().convert(text)
}

/// Check text for simplified Chinese terms/characters using the default instance.
pub fn check(text: &str) -> Vec<Match> {
    Converter::default_instance().check(text)
}

/// Look up a word/phrase using the default instance.
pub fn lookup(word: &str) -> LookupResult {
    Converter::default_instance().lookup(word)
}
