"""HAP type definitions for Haive graphs and nodes.

This module defines HAP protocol types for exposing Haive graph structures,
nodes, edges, and graph execution capabilities.
"""

from typing import Any, Optional, Literal, Union
from pydantic import BaseModel, Field
from datetime import datetime

from haive.hap.types import BaseInfo


class NodeInfo(BaseInfo):
    """Information about a node in a graph."""
    
    node_id: str = Field(description="Unique node identifier")
    node_type: str = Field(description="Type of node (agent, tool, validation, etc.)")
    node_class: str = Field(description="Full class name of the node")
    input_mapping: Optional[dict[str, str]] = Field(
        default=None,
        description="Input field mappings"
    )
    output_mapping: Optional[dict[str, str]] = Field(
        default=None,
        description="Output field mappings"
    )
    command_goto: Optional[Union[str, list[str]]] = Field(
        default=None,
        description="Command-based routing targets"
    )
    retry_policy: Optional[dict[str, Any]] = Field(
        default=None,
        description="Retry policy configuration"
    )
    created_at: Optional[str] = Field(default=None, description="Creation timestamp")


class EdgeInfo(BaseModel):
    """Information about an edge in a graph."""
    
    source: str = Field(description="Source node name")
    target: str = Field(description="Target node name")
    edge_type: Literal["direct", "conditional", "dynamic"] = Field(
        default="direct",
        description="Type of edge"
    )
    condition: Optional[str] = Field(default=None, description="Condition for conditional edges")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Edge metadata")


class BranchInfo(BaseModel):
    """Information about a conditional branch."""
    
    name: str = Field(description="Branch name")
    source_node: str = Field(description="Node that branches")
    branch_type: Literal["function", "key_value", "send", "command"] = Field(
        description="Type of branch logic"
    )
    conditions: dict[str, str] = Field(
        default_factory=dict,
        description="Condition -> target mappings"
    )
    default_target: Optional[str] = Field(default=None, description="Default branch target")


class GraphInfo(BaseInfo):
    """Information about a Haive graph exposed through HAP."""
    
    graph_id: str = Field(description="Unique graph identifier")
    graph_class: str = Field(default="BaseGraph", description="Graph class name")
    nodes: list[NodeInfo] = Field(default_factory=list, description="Nodes in the graph")
    edges: list[EdgeInfo] = Field(default_factory=list, description="Edges in the graph")
    branches: list[BranchInfo] = Field(default_factory=list, description="Conditional branches")
    entry_points: list[str] = Field(default_factory=list, description="Entry point nodes")
    finish_points: list[str] = Field(default_factory=list, description="Finish point nodes")
    state_schema: Optional[str] = Field(default=None, description="State schema class")
    subgraphs: list[str] = Field(default_factory=list, description="Nested subgraph names")
    is_compiled: bool = Field(default=False, description="Whether graph is compiled")
    needs_recompile: bool = Field(default=False, description="Whether graph needs recompilation")
    allow_cycles: bool = Field(default=False, description="Whether cycles are allowed")
    require_end_path: bool = Field(default=True, description="Whether all nodes need path to END")


class GraphExecutionRequest(BaseModel):
    """Request to execute a graph."""
    
    graph_name: str = Field(description="Name of graph to execute")
    input_data: dict[str, Any] = Field(description="Input data for the graph")
    config: Optional[dict[str, Any]] = Field(default=None, description="Runtime configuration")
    checkpoint_id: Optional[str] = Field(default=None, description="Checkpoint to resume from")
    stream: bool = Field(default=False, description="Whether to stream results")
    interrupt_before: Optional[list[str]] = Field(
        default=None,
        description="Nodes to interrupt before"
    )
    interrupt_after: Optional[list[str]] = Field(
        default=None,
        description="Nodes to interrupt after"
    )


class GraphExecutionResult(BaseModel):
    """Result from graph execution."""
    
    status: Literal["success", "error", "interrupted"] = Field(description="Execution status")
    result: Optional[dict[str, Any]] = Field(default=None, description="Final state")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    executed_nodes: list[str] = Field(default_factory=list, description="Nodes that executed")
    execution_path: list[str] = Field(default_factory=list, description="Execution path taken")
    checkpoint_id: Optional[str] = Field(default=None, description="Checkpoint ID if interrupted")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Execution metadata")
    duration_ms: Optional[float] = Field(default=None, description="Total execution time")


class NodeExecutionInfo(BaseModel):
    """Information about a single node execution."""
    
    node_name: str = Field(description="Name of the node")
    start_time: str = Field(description="Execution start time")
    end_time: Optional[str] = Field(default=None, description="Execution end time")
    duration_ms: Optional[float] = Field(default=None, description="Execution duration")
    status: Literal["success", "error", "skipped"] = Field(description="Execution status")
    input_state: dict[str, Any] = Field(description="Input state to node")
    output_state: Optional[dict[str, Any]] = Field(default=None, description="Output from node")
    error: Optional[str] = Field(default=None, description="Error if failed")


class GraphModificationRequest(BaseModel):
    """Request to modify a graph structure."""
    
    graph_name: str = Field(description="Graph to modify")
    operation: Literal["add_node", "remove_node", "add_edge", "remove_edge", "update_node"] = Field(
        description="Operation to perform"
    )
    node_name: Optional[str] = Field(default=None, description="Node name for node operations")
    node_config: Optional[dict[str, Any]] = Field(default=None, description="Node configuration")
    source: Optional[str] = Field(default=None, description="Source for edge operations")
    target: Optional[str] = Field(default=None, description="Target for edge operations")
    updates: Optional[dict[str, Any]] = Field(default=None, description="Updates for update operations")


class GraphValidationResult(BaseModel):
    """Result of graph validation."""
    
    valid: bool = Field(description="Whether graph is valid")
    errors: list[str] = Field(default_factory=list, description="Validation errors")
    warnings: list[str] = Field(default_factory=list, description="Validation warnings")
    unreachable_nodes: list[str] = Field(default_factory=list, description="Unreachable nodes")
    cycles_detected: list[list[str]] = Field(default_factory=list, description="Cycles found")
    missing_handlers: list[str] = Field(default_factory=list, description="Nodes missing handlers")


class GraphVisualizationRequest(BaseModel):
    """Request for graph visualization."""
    
    graph_name: str = Field(description="Graph to visualize")
    format: Literal["mermaid", "graphviz", "json", "ascii"] = Field(
        default="mermaid",
        description="Visualization format"
    )
    include_subgraphs: bool = Field(default=True, description="Include subgraphs")
    highlight_path: Optional[list[str]] = Field(
        default=None,
        description="Path to highlight"
    )


class GraphCheckpointInfo(BaseModel):
    """Information about a graph checkpoint."""
    
    checkpoint_id: str = Field(description="Unique checkpoint identifier")
    graph_name: str = Field(description="Graph this checkpoint belongs to")
    created_at: str = Field(description="When checkpoint was created")
    current_node: str = Field(description="Node where execution paused")
    state: dict[str, Any] = Field(description="State at checkpoint")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Checkpoint metadata")