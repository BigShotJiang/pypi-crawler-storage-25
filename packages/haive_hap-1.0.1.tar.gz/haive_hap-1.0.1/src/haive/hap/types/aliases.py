from typing import Any, Dict, NewType
JSONMap = Dict[str, Any]
AgentId = NewType("AgentId", str)
Entrypoint = NewType("Entrypoint", str)
