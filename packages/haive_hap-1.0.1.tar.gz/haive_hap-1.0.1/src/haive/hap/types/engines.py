"""HAP type definitions for Haive engines.

This module defines HAP protocol types for exposing Haive engine configurations
and capabilities through the protocol.
"""

from typing import Any, Optional, Literal
from pydantic import BaseModel, Field

from haive.hap.types import BaseInfo


class EngineInfo(BaseInfo):
    """Information about a Haive engine exposed through HAP.
    
    Engines are configuration/factory classes that create runtime objects.
    This captures their metadata and capabilities.
    """
    
    engine_type: str = Field(description="Type of engine (LLM, RETRIEVER, etc.)")
    engine_class: str = Field(description="Full class name of the engine")
    version: str = Field(default="1.0.0", description="Engine version")
    input_fields: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Input field definitions as name -> {type, default, description}"
    )
    output_fields: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Output field definitions as name -> {type, default, description}"
    )
    capabilities: list[str] = Field(
        default_factory=list,
        description="List of engine capabilities"
    )
    config_schema: Optional[dict[str, Any]] = Field(
        default=None,
        description="JSON schema for engine configuration"
    )


class AugLLMConfigInfo(EngineInfo):
    """Information about AugLLMConfig engine."""
    
    engine_type: Literal["LLM"] = "LLM"
    llm_provider: Optional[str] = Field(default=None, description="LLM provider (Azure, OpenAI, etc.)")
    model: Optional[str] = Field(default=None, description="Model name")
    temperature: Optional[float] = Field(default=None, description="Temperature setting")
    max_tokens: Optional[int] = Field(default=None, description="Max tokens setting")
    has_tools: bool = Field(default=False, description="Whether tools are configured")
    tool_count: int = Field(default=0, description="Number of tools configured")
    has_structured_output: bool = Field(default=False, description="Whether structured output is configured")
    structured_output_model: Optional[str] = Field(default=None, description="Structured output model class")
    has_prompt_template: bool = Field(default=False, description="Whether prompt template is configured")
    system_message: Optional[str] = Field(default=None, description="System message if configured")


class RetrieverEngineInfo(EngineInfo):
    """Information about retriever engines."""
    
    engine_type: Literal["RETRIEVER"] = "RETRIEVER"
    retriever_type: str = Field(description="Type of retriever (vector, keyword, hybrid)")
    embedding_model: Optional[str] = Field(default=None, description="Embedding model used")
    vector_store_type: Optional[str] = Field(default=None, description="Vector store type")
    search_kwargs: dict[str, Any] = Field(default_factory=dict, description="Search parameters")


class ToolEngineInfo(EngineInfo):
    """Information about tool engines."""
    
    engine_type: Literal["TOOL"] = "TOOL"
    tool_names: list[str] = Field(default_factory=list, description="Names of tools managed")
    tool_schemas: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Tool schemas as name -> schema"
    )


class VectorStoreEngineInfo(EngineInfo):
    """Information about vector store engines."""
    
    engine_type: Literal["VECTORSTORE"] = "VECTORSTORE"
    store_type: str = Field(description="Type of vector store")
    embedding_dimensions: Optional[int] = Field(default=None, description="Embedding dimensions")
    collection_name: Optional[str] = Field(default=None, description="Collection/index name")
    document_count: Optional[int] = Field(default=None, description="Number of documents stored")


class DocumentEngineInfo(EngineInfo):
    """Information about document processing engines."""
    
    engine_type: Literal["DOCUMENT"] = "DOCUMENT"
    loader_types: list[str] = Field(default_factory=list, description="Supported loader types")
    splitter_types: list[str] = Field(default_factory=list, description="Supported splitter types")
    transformer_types: list[str] = Field(default_factory=list, description="Supported transformer types")


class EngineCapability(BaseModel):
    """Describes a specific capability of an engine."""
    
    name: str = Field(description="Capability name")
    description: str = Field(description="What this capability does")
    required_fields: list[str] = Field(default_factory=list, description="Required input fields")
    output_fields: list[str] = Field(default_factory=list, description="Fields produced")
    parameters: dict[str, Any] = Field(default_factory=dict, description="Configuration parameters")


class EngineExecutionRequest(BaseModel):
    """Request to execute an engine."""
    
    engine_name: str = Field(description="Name of the engine to execute")
    input_data: dict[str, Any] = Field(description="Input data for the engine")
    config: Optional[dict[str, Any]] = Field(default=None, description="Runtime configuration")
    capability: Optional[str] = Field(default=None, description="Specific capability to use")


class EngineExecutionResult(BaseModel):
    """Result from engine execution."""
    
    status: Literal["success", "error"] = Field(description="Execution status")
    result: Optional[Any] = Field(default=None, description="Execution result")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Execution metadata")
    duration_ms: Optional[float] = Field(default=None, description="Execution duration in milliseconds")