"""HAP type definitions for Haive agents.

This module defines HAP protocol types for exposing Haive agents,
which are the primary building blocks of AI systems.
"""

from typing import Any, Optional, Literal, Union
from pydantic import BaseModel, Field

from haive.hap.types import BaseInfo


class AgentInfo(BaseInfo):
    """Information about a Haive agent exposed through HAP.
    
    Agents are workflow + engine combinations that provide
    intelligent behavior through LLMs or other AI models.
    """
    
    agent_class: str = Field(description="Full class name of the agent")
    agent_type: str = Field(description="Type of agent (Simple, React, RAG, etc.)")
    engine_type: Optional[str] = Field(default=None, description="Type of main engine")
    engine_class: Optional[str] = Field(default=None, description="Engine class if configured")
    has_tools: bool = Field(default=False, description="Whether agent has tools")
    tool_count: int = Field(default=0, description="Number of tools")
    tool_names: list[str] = Field(default_factory=list, description="Names of tools")
    has_structured_output: bool = Field(default=False, description="Has structured output model")
    structured_output_model: Optional[str] = Field(
        default=None,
        description="Structured output model class"
    )
    state_schema: Optional[str] = Field(default=None, description="State schema class")
    input_schema: Optional[str] = Field(default=None, description="Input schema class")
    output_schema: Optional[str] = Field(default=None, description="Output schema class")
    graph_info: Optional[dict[str, Any]] = Field(default=None, description="Graph structure info")
    capabilities: list[str] = Field(default_factory=list, description="Agent capabilities")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class SimpleAgentInfo(AgentInfo):
    """Information specific to SimpleAgent."""
    
    agent_type: Literal["SimpleAgent"] = "SimpleAgent"
    prompt_template: Optional[str] = Field(default=None, description="Prompt template if set")
    system_message: Optional[str] = Field(default=None, description="System message if set")


class ReactAgentInfo(AgentInfo):
    """Information specific to ReactAgent."""
    
    agent_type: Literal["ReactAgent"] = "ReactAgent"
    max_iterations: int = Field(default=10, description="Maximum reasoning iterations")
    supports_reasoning: bool = Field(default=True, description="Supports reasoning loops")
    reasoning_style: Literal["react", "cot", "tot"] = Field(
        default="react",
        description="Reasoning style"
    )


class RAGAgentInfo(AgentInfo):
    """Information specific to RAG agents."""
    
    agent_type: Literal["RAGAgent"] = "RAGAgent"
    retriever_type: Optional[str] = Field(default=None, description="Type of retriever")
    vector_store: Optional[str] = Field(default=None, description="Vector store type")
    embedding_model: Optional[str] = Field(default=None, description="Embedding model")
    chunk_size: Optional[int] = Field(default=None, description="Document chunk size")
    top_k: Optional[int] = Field(default=None, description="Number of documents to retrieve")


class MultiAgentInfo(AgentInfo):
    """Information about multi-agent systems."""
    
    agent_type: Literal["MultiAgent"] = "MultiAgent"
    sub_agents: list[str] = Field(default_factory=list, description="Names of sub-agents")
    coordination_mode: Literal["sequential", "parallel", "hierarchical", "collaborative"] = Field(
        default="sequential",
        description="How agents coordinate"
    )
    routing_strategy: Optional[str] = Field(default=None, description="Agent routing strategy")


class AgentExecutionRequest(BaseModel):
    """Request to execute an agent.
    
    This is the primary tool for agent execution through HAP.
    """
    
    input_data: Union[str, dict[str, Any], list[dict[str, Any]]] = Field(
        description="Input for the agent (string, dict, or messages)"
    )
    config: Optional[dict[str, Any]] = Field(
        default=None,
        description="Runtime configuration"
    )
    stream: bool = Field(default=False, description="Whether to stream results")
    include_state: bool = Field(default=False, description="Include final state in result")
    checkpoint_id: Optional[str] = Field(
        default=None,
        description="Checkpoint to resume from"
    )
    save_checkpoint: bool = Field(default=True, description="Whether to save checkpoints")


class AgentExecutionResult(BaseModel):
    """Result from agent execution."""
    
    status: Literal["success", "error", "interrupted"] = Field(description="Execution status")
    result: Optional[Any] = Field(default=None, description="Agent output")
    state: Optional[dict[str, Any]] = Field(default=None, description="Final state if requested")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    checkpoint_id: Optional[str] = Field(default=None, description="Checkpoint ID if saved")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Execution metadata")
    duration_ms: Optional[float] = Field(default=None, description="Execution duration")
    token_usage: Optional[dict[str, int]] = Field(
        default=None,
        description="Token usage statistics"
    )


class AgentStateSnapshot(BaseModel):
    """Snapshot of agent state at a point in time."""
    
    agent_name: str = Field(description="Agent name")
    timestamp: str = Field(description="When snapshot was taken")
    state: dict[str, Any] = Field(description="State data")
    messages: Optional[list[dict[str, Any]]] = Field(
        default=None,
        description="Conversation messages if any"
    )
    context: Optional[dict[str, Any]] = Field(default=None, description="Agent context")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class AgentConfigUpdate(BaseModel):
    """Request to update agent configuration."""
    
    temperature: Optional[float] = Field(default=None, description="Update temperature")
    max_tokens: Optional[int] = Field(default=None, description="Update max tokens")
    system_message: Optional[str] = Field(default=None, description="Update system message")
    tools_enabled: Optional[bool] = Field(default=None, description="Enable/disable tools")
    tool_names: Optional[list[str]] = Field(
        default=None,
        description="Specific tools to enable"
    )
    structured_output_enabled: Optional[bool] = Field(
        default=None,
        description="Enable/disable structured output"
    )


class AgentStatistics(BaseModel):
    """Statistics about agent usage."""
    
    total_executions: int = Field(default=0, description="Total number of executions")
    successful_executions: int = Field(default=0, description="Successful executions")
    failed_executions: int = Field(default=0, description="Failed executions")
    total_tokens: int = Field(default=0, description="Total tokens used")
    total_duration_ms: float = Field(default=0.0, description="Total execution time")
    average_duration_ms: float = Field(default=0.0, description="Average execution time")
    last_execution: Optional[str] = Field(default=None, description="Last execution timestamp")
    error_types: dict[str, int] = Field(
        default_factory=dict,
        description="Count of different error types"
    )


class AgentToolCall(BaseModel):
    """Information about a tool call made by an agent."""
    
    tool_name: str = Field(description="Name of tool called")
    arguments: dict[str, Any] = Field(description="Arguments passed to tool")
    result: Optional[Any] = Field(default=None, description="Tool result")
    error: Optional[str] = Field(default=None, description="Error if tool failed")
    duration_ms: Optional[float] = Field(default=None, description="Tool execution time")


class AgentReasoningStep(BaseModel):
    """A step in agent reasoning (for agents that support it)."""
    
    step_number: int = Field(description="Step number in reasoning sequence")
    thought: str = Field(description="Agent's thought/reasoning")
    action: Optional[str] = Field(default=None, description="Action taken")
    action_input: Optional[Any] = Field(default=None, description="Input to action")
    observation: Optional[str] = Field(default=None, description="Result observation")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Step metadata")