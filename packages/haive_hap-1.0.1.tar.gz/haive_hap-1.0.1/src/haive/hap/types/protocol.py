"""
Core types for the Haive Agent Protocol (HAP).

This module defines the fundamental types used throughout HAP,
mirroring the structure of MCP but adapted for agents and graphs.

Enhanced with comprehensive Pydantic validation for:
- Field-level validation with constraints
- Cross-field validation
- JSON-RPC 2.0 compliance
- HAP protocol standards
"""

from typing import Any, Optional, List, Dict, Protocol, Callable, Union
from pydantic import BaseModel, Field, ConfigDict, field_validator, model_validator
from datetime import datetime
from enum import Enum
import re


# Base Types

class BaseInfo(BaseModel):
    """Base class for all HAP info types."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
        json_schema_extra={
            "description": "Base information structure for HAP protocol objects"
        }
    )
    
    name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        pattern=r'^[a-zA-Z][a-zA-Z0-9_-]*$',
        description="Object identifier (alphanumeric, underscore, hyphen)"
    )
    description: str = Field(
        ...,
        min_length=1,
        max_length=1000,
        description="Human-readable description"
    )
    
    @field_validator("name")
    @classmethod
    def validate_name_format(cls, v: str) -> str:
        """Ensure name follows HAP naming conventions."""
        if not v[0].isalpha():
            raise ValueError("Name must start with a letter")
        return v


# Protocol Types (JSON-RPC 2.0 based)

class HAPRequest(BaseModel):
    """Base request structure for HAP protocol with JSON-RPC 2.0 compliance."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "jsonrpc": "2.0",
                    "id": "req-123",
                    "method": "agents/execute",
                    "params": {"agent_name": "test", "input": {}}
                }
            ]
        }
    )
    
    jsonrpc: str = Field(
        default="2.0",
        pattern=r"^2\.0$",
        description="JSON-RPC version (must be '2.0')"
    )
    id: Union[str, int] = Field(
        ...,
        description="Request identifier for correlation"
    )
    method: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="HAP method name (e.g., 'agents/execute')"
    )
    params: Dict[str, Any] = Field(
        default_factory=dict,
        description="Method parameters"
    )
    
    @field_validator("method")
    @classmethod
    def validate_method(cls, v: str) -> str:
        """Validate method follows HAP conventions."""
        valid_prefixes = [
            "agents/", "graphs/", "tools/", "resources/", 
            "prompts/", "schemas/", "engines/"
        ]
        if not any(v.startswith(prefix) for prefix in valid_prefixes):
            raise ValueError(
                f"Method must start with one of: {', '.join(valid_prefixes)}"
            )
        return v


class HAPResponse(BaseModel):
    """Base response structure for HAP protocol with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "jsonrpc": "2.0",
                    "id": "req-123",
                    "result": {"status": "success", "output": "Hello World"}
                },
                {
                    "jsonrpc": "2.0", 
                    "id": "req-124",
                    "error": {"code": -32001, "message": "Agent not found"}
                }
            ]
        }
    )
    
    jsonrpc: str = Field(
        default="2.0",
        pattern=r"^2\.0$", 
        description="JSON-RPC version (must be '2.0')"
    )
    id: Union[str, int] = Field(
        ...,
        description="Request identifier matching the original request"
    )
    result: Optional[Any] = Field(
        default=None,
        description="Success result (mutually exclusive with error)"
    )
    error: Optional["HAPError"] = Field(
        default=None,
        description="Error details (mutually exclusive with result)"
    )
    
    @model_validator(mode="after")
    def validate_result_or_error(self) -> "HAPResponse":
        """Ensure response has either result or error, not both."""
        has_result = self.result is not None
        has_error = self.error is not None
        
        if has_result and has_error:
            raise ValueError("Response cannot have both result and error")
        if not has_result and not has_error:
            raise ValueError("Response must have either result or error")
        
        return self


class HAPError(BaseModel):
    """Error structure for HAP protocol with enhanced validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid"
    )
    
    code: int = Field(
        ...,
        description="Error code (JSON-RPC or HAP-specific)"
    )
    message: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description="Human-readable error message"
    )
    data: Optional[Any] = Field(
        default=None,
        description="Additional error information"
    )
    
    @field_validator("code")
    @classmethod
    def validate_error_code(cls, v: int) -> int:
        """Validate error code is in expected ranges."""
        # JSON-RPC reserved range: -32768 to -32000
        # HAP-specific range: -32999 to -32001
        if -32768 <= v <= -32000:
            return v  # Standard JSON-RPC errors
        if -32999 <= v <= -32001:
            return v  # HAP-specific errors
        if v > 0:
            return v  # Application-specific errors (positive)
        
        raise ValueError(
            "Error code must be standard JSON-RPC (-32768 to -32000), "
            "HAP-specific (-32999 to -32001), or application-specific (positive)"
        )


class ErrorCode(int, Enum):
    """Standard error codes."""
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603
    
    # HAP-specific errors
    AGENT_NOT_FOUND = -32001
    GRAPH_NOT_FOUND = -32002
    TOOL_NOT_FOUND = -32003
    RESOURCE_NOT_FOUND = -32004
    EXECUTION_ERROR = -32005
    VALIDATION_ERROR = -32006
    AUTHENTICATION_ERROR = -32007


# Method Request Types

class ToolCall(BaseModel):
    """Request to call a tool."""
    name: str
    arguments: dict = Field(default_factory=dict)


class ResourceRead(BaseModel):
    """Request to read a resource."""
    uri: str


class PromptGet(BaseModel):
    """Request to get a prompt."""
    name: str
    arguments: dict = Field(default_factory=dict)


# Info Types

class ToolInfo(BaseInfo):
    """Tool metadata with enhanced validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "name": "calculator",
                    "description": "Perform mathematical calculations",
                    "input_schema": {
                        "type": "object",
                        "properties": {
                            "expression": {"type": "string"}
                        },
                        "required": ["expression"]
                    },
                    "output_schema": {
                        "type": "object",
                        "properties": {
                            "result": {"type": "number"}
                        }
                    }
                }
            ]
        }
    )
    
    input_schema: Dict[str, Any] = Field(
        ...,
        description="JSON Schema for tool input validation"
    )
    output_schema: Optional[Dict[str, Any]] = Field(
        default=None,
        description="JSON Schema for tool output validation"
    )
    
    @field_validator("input_schema", "output_schema")
    @classmethod
    def validate_json_schema(cls, v: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """Validate that schema is a valid JSON Schema structure."""
        if v is None:
            return v
        
        # Basic JSON Schema validation
        if not isinstance(v, dict):
            raise ValueError("Schema must be a dictionary")
        
        if "type" not in v:
            raise ValueError("Schema must have a 'type' field")
        
        valid_types = {"object", "array", "string", "number", "integer", "boolean", "null"}
        if v["type"] not in valid_types:
            raise ValueError(f"Schema type must be one of: {', '.join(valid_types)}")
        
        return v


class ResourceInfo(BaseModel):
    """Resource metadata with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "uri": "hap://server/status",
                    "name": "server_status",
                    "description": "Current server status information",
                    "mime_type": "application/json"
                },
                {
                    "uri": "file:///data/config.yaml",
                    "name": "configuration",
                    "description": "Application configuration file",
                    "mime_type": "application/yaml"
                }
            ]
        }
    )
    
    uri: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description="Resource URI (e.g., hap://server/info, file:///path/to/file)"
    )
    name: str = Field(
        ...,
        min_length=1,
        max_length=100,
        pattern=r'^[a-zA-Z][a-zA-Z0-9_-]*$',
        description="Resource name identifier"
    )
    description: str = Field(
        ...,
        min_length=1,
        max_length=500,
        description="Human-readable resource description"
    )
    mime_type: str = Field(
        default="application/json",
        pattern=r'^[a-zA-Z][a-zA-Z0-9][a-zA-Z0-9!#$&\-\^_]*\/[a-zA-Z0-9][a-zA-Z0-9!#$&\-\^_.]*$',
        description="MIME type of the resource"
    )
    
    @field_validator("uri")
    @classmethod
    def validate_uri_format(cls, v: str) -> str:
        """Validate URI has proper format."""
        # Check for basic URI structure
        if not re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', v):
            raise ValueError("URI must start with a valid scheme (e.g., http:, file:, hap:)")
        
        # Common schemes validation
        valid_schemes = ["http", "https", "file", "hap", "ftp", "data"]
        scheme = v.split(":", 1)[0].lower()
        if scheme not in valid_schemes:
            raise ValueError(f"URI scheme '{scheme}' not in common schemes: {', '.join(valid_schemes)}")
        
        return v


class PromptArgument(BaseModel):
    """Prompt argument definition with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid"
    )
    
    name: str = Field(
        ...,
        min_length=1,
        max_length=50,
        pattern=r'^[a-zA-Z][a-zA-Z0-9_]*$',
        description="Argument name (valid Python identifier)"
    )
    description: str = Field(
        ...,
        min_length=1,
        max_length=200,
        description="Argument description"
    )
    required: bool = Field(
        default=True,
        description="Whether argument is required"
    )


class PromptInfo(BaseInfo):
    """Prompt metadata with enhanced validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid"
    )
    
    arguments: List[PromptArgument] = Field(
        default_factory=list,
        description="Prompt argument definitions"
    )
    
    @field_validator("arguments")
    @classmethod
    def validate_unique_arguments(cls, v: List[PromptArgument]) -> List[PromptArgument]:
        """Ensure argument names are unique."""
        names = [arg.name for arg in v]
        if len(names) != len(set(names)):
            raise ValueError("Argument names must be unique")
        return v


# Agent-specific Types

class AgentInfo(BaseInfo):
    """Agent metadata for HAP with enhanced validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "name": "research_assistant",
                    "description": "AI agent specialized in research tasks",
                    "type": "ReactAgent",
                    "capabilities": ["tools", "structured_output", "memory"],
                    "tools": ["web_search", "calculator", "document_reader"],
                    "state_schema": {
                        "type": "object",
                        "properties": {
                            "messages": {"type": "array"},
                            "context": {"type": "object"}
                        }
                    }
                }
            ]
        }
    )
    
    type: str = Field(
        ...,
        min_length=1,
        max_length=50,
        description="Agent class type (e.g., SimpleAgent, ReactAgent)"
    )
    capabilities: List[str] = Field(
        default_factory=list,
        description="Agent capabilities (tools, structured_output, memory, etc.)"
    )
    tools: List[str] = Field(
        default_factory=list,
        description="Available tool names"
    )
    state_schema: Optional[Dict[str, Any]] = Field(
        default=None,
        description="JSON Schema for agent state"
    )
    
    @field_validator("capabilities")
    @classmethod
    def validate_capabilities(cls, v: List[str]) -> List[str]:
        """Validate capability names."""
        valid_capabilities = {
            "tools", "structured_output", "memory", "streaming",
            "async", "parallel", "routing", "validation"
        }
        
        for cap in v:
            if cap not in valid_capabilities:
                raise ValueError(f"Unknown capability '{cap}'. Valid: {', '.join(valid_capabilities)}")
        
        # Remove duplicates while preserving order
        return list(dict.fromkeys(v))
    
    @field_validator("tools")
    @classmethod
    def validate_tool_names(cls, v: List[str]) -> List[str]:
        """Validate tool names format."""
        for tool in v:
            if not tool or not re.match(r'^[a-zA-Z][a-zA-Z0-9_-]*$', tool):
                raise ValueError(f"Invalid tool name format: '{tool}'")
        
        # Remove duplicates while preserving order
        return list(dict.fromkeys(v))
    

class AgentExecutionRequest(BaseModel):
    """Request to execute an agent with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "input_data": {"query": "Hello world"},
                    "config_overrides": {"temperature": 0.7},
                    "stream": False,
                    "timeout": 30.0
                }
            ]
        }
    )
    
    input_data: Dict[str, Any] = Field(
        ...,
        description="Input data for agent execution"
    )
    config_overrides: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Optional configuration overrides"
    )
    stream: bool = Field(
        default=False,
        description="Enable streaming response"
    )
    timeout: Optional[float] = Field(
        default=None,
        gt=0,
        le=300,
        description="Execution timeout in seconds (max 300s)"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional request metadata"
    )
    

class ExecutionStatus(str, Enum):
    """Agent execution status values."""
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


class AgentExecutionResult(BaseModel):
    """Result from agent execution with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid"
    )
    
    status: ExecutionStatus = Field(
        ...,
        description="Execution status"
    )
    result: Optional[Any] = Field(
        default=None,
        description="Execution result (present for success)"
    )
    error: Optional[str] = Field(
        default=None,
        max_length=1000,
        description="Error message (present for error/timeout)"
    )
    execution_time: float = Field(
        ...,
        ge=0,
        description="Execution time in seconds"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Execution metadata (tokens used, etc.)"
    )
    
    @model_validator(mode="after")
    def validate_result_consistency(self) -> "AgentExecutionResult":
        """Ensure result/error fields are consistent with status."""
        if self.status == ExecutionStatus.SUCCESS:
            if self.error is not None:
                raise ValueError("Success status cannot have error message")
        else:  # ERROR, TIMEOUT, or CANCELLED
            if self.error is None:
                raise ValueError(f"{self.status} status must have error message")
        return self


# Graph-specific Types

class NodeType(str, Enum):
    """Graph node types."""
    AGENT = "agent"
    TOOL = "tool"
    DECISION = "decision"
    START = "start"
    END = "end"
    PARALLEL = "parallel"
    MERGE = "merge"


class NodeInfo(BaseModel):
    """Graph node metadata with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid"
    )
    
    id: str = Field(
        ...,
        min_length=1,
        max_length=100,
        pattern=r'^[a-zA-Z][a-zA-Z0-9_-]*$',
        description="Node identifier"
    )
    type: NodeType = Field(
        ...,
        description="Node type"
    )
    agent_name: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=100,
        description="Agent name (required for agent nodes)"
    )
    description: Optional[str] = Field(
        default=None,
        max_length=500,
        description="Node description"
    )
    
    @model_validator(mode="after")
    def validate_node_requirements(self) -> "NodeInfo":
        """Validate node-type specific requirements."""
        if self.type == NodeType.AGENT and not self.agent_name:
            raise ValueError("Agent nodes must have agent_name specified")
        
        if self.type != NodeType.AGENT and self.agent_name:
            raise ValueError(f"{self.type} nodes should not have agent_name")
        
        return self
    

class EdgeInfo(BaseModel):
    """Graph edge metadata with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid"
    )
    
    source: str = Field(
        ...,
        min_length=1,
        max_length=100,
        pattern=r'^[a-zA-Z][a-zA-Z0-9_-]*$',
        description="Source node ID"
    )
    target: str = Field(
        ...,
        min_length=1,
        max_length=100,
        pattern=r'^[a-zA-Z][a-zA-Z0-9_-]*$',
        description="Target node ID"
    )
    condition: Optional[str] = Field(
        default=None,
        max_length=200,
        description="Conditional logic for edge traversal"
    )
    
    @model_validator(mode="after")
    def validate_edge(self) -> "EdgeInfo":
        """Validate edge constraints."""
        if self.source == self.target:
            raise ValueError("Edge cannot connect node to itself")
        return self
    

class GraphInfo(BaseInfo):
    """Graph metadata for HAP with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid"
    )
    
    nodes: List[NodeInfo] = Field(
        ...,
        min_length=1,
        description="Graph nodes"
    )
    edges: List[EdgeInfo] = Field(
        default_factory=list,
        description="Graph edges"
    )
    entry_point: str = Field(
        ...,
        min_length=1,
        max_length=100,
        pattern=r'^[a-zA-Z][a-zA-Z0-9_-]*$',
        description="Entry node ID"
    )
    
    @field_validator("nodes")
    @classmethod
    def validate_unique_node_ids(cls, v: List[NodeInfo]) -> List[NodeInfo]:
        """Ensure node IDs are unique."""
        node_ids = [node.id for node in v]
        if len(node_ids) != len(set(node_ids)):
            raise ValueError("Node IDs must be unique")
        return v
    
    @model_validator(mode="after")
    def validate_graph_structure(self) -> "GraphInfo":
        """Validate overall graph structure."""
        node_ids = {node.id for node in self.nodes}
        
        # Validate entry point exists
        if self.entry_point not in node_ids:
            raise ValueError(f"Entry point '{self.entry_point}' not found in nodes")
        
        # Validate edge references
        for edge in self.edges:
            if edge.source not in node_ids:
                raise ValueError(f"Edge source '{edge.source}' not found in nodes")
            if edge.target not in node_ids:
                raise ValueError(f"Edge target '{edge.target}' not found in nodes")
        
        return self
    

class GraphExecutionRequest(BaseModel):
    """Request to execute a graph with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid",
        json_schema_extra={
            "examples": [
                {
                    "input_data": {"query": "Process this workflow"},
                    "start_node": "entry_point",
                    "end_node": "final_output",
                    "stream_nodes": True,
                    "timeout": 60.0
                }
            ]
        }
    )
    
    input_data: Dict[str, Any] = Field(
        ...,
        description="Input data for graph execution"
    )
    start_node: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=100,
        pattern=r'^[a-zA-Z0-9_-]+$',
        description="Starting node ID (alphanumeric, underscore, hyphen)"
    )
    end_node: Optional[str] = Field(
        default=None,
        min_length=1,
        max_length=100,
        pattern=r'^[a-zA-Z0-9_-]+$',
        description="Target end node ID (alphanumeric, underscore, hyphen)"
    )
    stream_nodes: bool = Field(
        default=False,
        description="Whether to stream intermediate node results"
    )
    timeout: Optional[float] = Field(
        default=None,
        gt=0,
        le=3600,
        description="Execution timeout in seconds (max 3600s)"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional execution metadata"
    )
    
    @field_validator("input_data")
    @classmethod
    def validate_input_not_empty(cls, v: Dict[str, Any]) -> Dict[str, Any]:
        """Ensure input data is not empty."""
        if not v:
            raise ValueError("Input data cannot be empty")
        return v
    

class GraphExecutionStatus(str, Enum):
    """Graph execution status values."""
    SUCCESS = "success"
    ERROR = "error"
    PARTIAL = "partial"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


class GraphExecutionResult(BaseModel):
    """Result from graph execution with validation."""
    model_config = ConfigDict(
        str_strip_whitespace=True,
        validate_assignment=True,
        extra="forbid"
    )
    
    status: GraphExecutionStatus = Field(
        ...,
        description="Execution status"
    )
    path: List[str] = Field(
        default_factory=list,
        description="Nodes executed in order"
    )
    results: Dict[str, Any] = Field(
        default_factory=dict,
        description="Results from each executed node"
    )
    final_output: Optional[Any] = Field(
        default=None,
        description="Final graph output (present for success)"
    )
    error: Optional[str] = Field(
        default=None,
        max_length=1000,
        description="Error message (present for error/timeout)"
    )
    execution_time: float = Field(
        ...,
        ge=0,
        description="Total execution time in seconds"
    )
    node_metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Metadata from individual node executions"
    )
    
    @field_validator("path")
    @classmethod
    def validate_path_items(cls, v: List[str]) -> List[str]:
        """Validate all path items are valid node IDs."""
        for node_id in v:
            if not node_id or not re.match(r'^[a-zA-Z0-9_-]+$', node_id):
                raise ValueError(f"Invalid node ID in path: {node_id}")
        return v
    
    @model_validator(mode="after")
    def validate_result_consistency(self) -> "GraphExecutionResult":
        """Ensure result fields are consistent with status."""
        if self.status == GraphExecutionStatus.SUCCESS:
            if self.error is not None:
                raise ValueError("Success status cannot have error message")
        else:  # ERROR, TIMEOUT, PARTIAL, or CANCELLED
            if self.status in [GraphExecutionStatus.ERROR, GraphExecutionStatus.TIMEOUT] and self.error is None:
                raise ValueError(f"{self.status} status must have error message")
        return self


# State Schema Types

class FieldInfo(BaseModel):
    """Field metadata."""
    name: str
    type: str
    required: bool = True
    description: str = ""
    default: Optional[Any] = None
    

class StateSchemaInfo(BaseModel):
    """State schema metadata."""
    name: str
    description: str
    schema: dict  # JSON Schema
    fields: List[FieldInfo] = Field(default_factory=list)
    

class StateValidationRequest(BaseModel):
    """Request to validate state."""
    data: dict
    strict: bool = True
    

class StateValidationResult(BaseModel):
    """Result of state validation."""
    valid: bool
    errors: List[str] = Field(default_factory=list)
    validated_data: Optional[dict] = None


# Server Registration Types

class ServerCapability(str, Enum):
    """Server capabilities."""
    TOOLS = "tools"
    RESOURCES = "resources"
    PROMPTS = "prompts"
    STREAMING = "streaming"
    AUTHENTICATION = "authentication"
    STATE_PERSISTENCE = "state_persistence"


class ServerRegistration(BaseModel):
    """Registration info for a HAP server."""
    name: str
    type: str  # "agent", "graph", "schema", "coordinator"
    endpoint: str
    capabilities: List[ServerCapability] = Field(default_factory=list)
    registered_at: datetime = Field(default_factory=datetime.now)
    health_check_url: Optional[str] = None
    metadata: dict = Field(default_factory=dict)


# Transport Types

class TransportType(str, Enum):
    """Available transport types."""
    STDIO = "stdio"
    SSE = "sse"
    HTTP = "http"
    WEBSOCKET = "websocket"


class TransportConfig(BaseModel):
    """Transport configuration."""
    type: TransportType
    host: Optional[str] = None
    port: Optional[int] = None
    path: Optional[str] = None
    options: dict = Field(default_factory=dict)


# Protocol Interfaces

class IHAPServer(Protocol):
    """Interface for HAP servers."""
    
    async def handle_request(self, request: HAPRequest) -> HAPResponse:
        """Handle incoming HAP request."""
        ...
    
    def list_tools(self) -> List[ToolInfo]:
        """List available tools."""
        ...
    
    def list_resources(self) -> List[ResourceInfo]:
        """List available resources."""
        ...
    
    def list_prompts(self) -> List[PromptInfo]:
        """List available prompts."""
        ...


class ITransport(Protocol):
    """Transport layer interface."""
    
    async def start(self, server: IHAPServer):
        """Start transport."""
        ...
    
    async def stop(self):
        """Stop transport."""
        ...
    
    async def send_response(self, response: HAPResponse):
        """Send response to client."""
        ...


# Update forward references
HAPResponse.model_rebuild()