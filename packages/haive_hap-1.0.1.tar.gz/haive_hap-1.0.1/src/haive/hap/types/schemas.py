"""HAP type definitions for Haive state schemas.

This module defines HAP protocol types for exposing Haive state schemas,
which are the foundation of agent state management.
"""

from typing import Any, Optional, Literal
from pydantic import BaseModel, Field

from haive.hap.types import BaseInfo


class FieldInfo(BaseModel):
    """Information about a field in a state schema."""
    
    name: str = Field(description="Field name")
    type: str = Field(description="Field type as string")
    default: Optional[Any] = Field(default=None, description="Default value")
    required: bool = Field(default=True, description="Whether field is required")
    description: Optional[str] = Field(default=None, description="Field description")
    is_shared: bool = Field(default=False, description="Whether field is shared with parent graphs")
    has_reducer: bool = Field(default=False, description="Whether field has a reducer function")
    reducer_name: Optional[str] = Field(default=None, description="Name of reducer function")
    validation_rules: list[str] = Field(default_factory=list, description="Validation rules")


class StateSchemaInfo(BaseInfo):
    """Information about a StateSchema exposed through HAP."""
    
    schema_class: str = Field(description="Full class name of the schema")
    base_class: str = Field(description="Base class name")
    fields: list[FieldInfo] = Field(default_factory=list, description="Schema fields")
    shared_fields: list[str] = Field(default_factory=list, description="Fields shared with parent")
    reducer_fields: dict[str, str] = Field(
        default_factory=dict,
        description="Fields with reducers as field -> reducer_name"
    )
    engine_io_mappings: dict[str, dict[str, list[str]]] = Field(
        default_factory=dict,
        description="Engine I/O mappings as engine -> {inputs: [...], outputs: [...]}"
    )
    structured_models: dict[str, str] = Field(
        default_factory=dict,
        description="Structured output models as field -> model_class"
    )
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class MessagesStateInfo(StateSchemaInfo):
    """Information about the common MessagesState schema."""
    
    schema_class: Literal["MessagesState"] = "MessagesState"
    supports_message_operations: bool = Field(
        default=True,
        description="Whether schema supports message operations"
    )
    message_field_name: str = Field(default="messages", description="Name of messages field")
    has_memory_integration: bool = Field(
        default=False,
        description="Whether schema integrates with memory systems"
    )


class DocumentStateInfo(StateSchemaInfo):
    """Information about document-oriented state schemas."""
    
    document_fields: list[str] = Field(
        default_factory=list,
        description="Fields that hold document data"
    )
    supports_chunking: bool = Field(
        default=False,
        description="Whether schema supports document chunking"
    )
    supports_embeddings: bool = Field(
        default=False,
        description="Whether schema supports embeddings"
    )


class MetaStateSchemaInfo(StateSchemaInfo):
    """Information about meta-capable state schemas."""
    
    schema_class: Literal["MetaStateSchema"] = "MetaStateSchema"
    supports_agent_embedding: bool = Field(
        default=True,
        description="Whether schema can embed agents"
    )
    supports_recompilation: bool = Field(
        default=True,
        description="Whether schema supports recompilation tracking"
    )
    embedded_agent_type: Optional[str] = Field(
        default=None,
        description="Type of embedded agent if any"
    )
    execution_tracking: bool = Field(
        default=True,
        description="Whether schema tracks execution history"
    )


class SchemaField(BaseModel):
    """Detailed field definition for schema operations."""
    
    name: str = Field(description="Field name")
    type: str = Field(description="Python type")
    default_factory: Optional[str] = Field(default=None, description="Default factory function")
    validator: Optional[str] = Field(default=None, description="Validator function")
    serializer: Optional[str] = Field(default=None, description="Serializer function")
    json_schema_extra: Optional[dict[str, Any]] = Field(default=None, description="Extra JSON schema")


class SchemaCreationRequest(BaseModel):
    """Request to create a new state schema dynamically."""
    
    name: str = Field(description="Name for the new schema")
    base_class: str = Field(default="StateSchema", description="Base class to extend")
    fields: list[SchemaField] = Field(description="Fields to add")
    shared_fields: Optional[list[str]] = Field(default=None, description="Fields to share")
    reducer_fields: Optional[dict[str, str]] = Field(default=None, description="Reducer mappings")
    engine_io_mappings: Optional[dict[str, dict[str, list[str]]]] = Field(
        default=None,
        description="Engine I/O mappings"
    )


class SchemaValidationRequest(BaseModel):
    """Request to validate data against a schema."""
    
    schema_name: str = Field(description="Name of schema to validate against")
    data: dict[str, Any] = Field(description="Data to validate")
    strict: bool = Field(default=True, description="Whether to use strict validation")


class SchemaValidationResult(BaseModel):
    """Result of schema validation."""
    
    valid: bool = Field(description="Whether data is valid")
    errors: list[dict[str, Any]] = Field(default_factory=list, description="Validation errors")
    warnings: list[str] = Field(default_factory=list, description="Validation warnings")
    coerced_data: Optional[dict[str, Any]] = Field(
        default=None,
        description="Data after type coercion"
    )


class SchemaCompositionRequest(BaseModel):
    """Request to compose multiple schemas."""
    
    schemas: list[str] = Field(description="Schema names to compose")
    composition_type: Literal["merge", "union", "intersection"] = Field(
        default="merge",
        description="How to compose schemas"
    )
    conflict_resolution: Literal["first", "last", "error"] = Field(
        default="last",
        description="How to handle field conflicts"
    )
    name: Optional[str] = Field(default=None, description="Name for composed schema")


class SchemaDiffResult(BaseModel):
    """Result of comparing two schemas."""
    
    added_fields: list[str] = Field(default_factory=list, description="Fields added")
    removed_fields: list[str] = Field(default_factory=list, description="Fields removed")
    modified_fields: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Fields modified with changes"
    )
    compatible: bool = Field(description="Whether schemas are compatible")
    breaking_changes: list[str] = Field(
        default_factory=list,
        description="List of breaking changes"
    )