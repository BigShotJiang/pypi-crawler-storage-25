"""HAP type definitions for Haive graph nodes.

This module defines HAP protocol types for exposing various node types
used in Haive graphs.
"""

from typing import Any, Optional, Literal, Union
from pydantic import BaseModel, Field

from haive.hap.types import BaseInfo


class NodeConfigInfo(BaseInfo):
    """Base information about a node configuration."""
    
    node_class: str = Field(description="Full class name of the node")
    node_type: str = Field(description="Type of node")
    requires_state_schema: bool = Field(default=True, description="Whether node needs state schema")
    supports_streaming: bool = Field(default=False, description="Whether node supports streaming")
    input_fields: list[str] = Field(default_factory=list, description="Expected input fields")
    output_fields: list[str] = Field(default_factory=list, description="Fields produced")
    configuration: dict[str, Any] = Field(default_factory=dict, description="Node configuration")


class AgentNodeInfo(NodeConfigInfo):
    """Information about agent nodes."""
    
    node_type: Literal["agent"] = "agent"
    agent_name: str = Field(description="Name of the agent")
    agent_class: str = Field(description="Agent class")
    has_pre_agent: bool = Field(default=False, description="Has pre-processing agent")
    has_post_agent: bool = Field(default=False, description="Has post-processing agent")
    supports_async: bool = Field(default=True, description="Supports async execution")


class ToolNodeInfo(NodeConfigInfo):
    """Information about tool nodes."""
    
    node_type: Literal["tool"] = "tool"
    tool_names: list[str] = Field(default_factory=list, description="Names of tools")
    tool_schemas: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Tool schemas"
    )
    parallel_execution: bool = Field(default=False, description="Execute tools in parallel")


class ValidationNodeInfo(NodeConfigInfo):
    """Information about validation nodes."""
    
    node_type: Literal["validation"] = "validation"
    validation_model: Optional[str] = Field(default=None, description="Validation model class")
    tool_routes: dict[str, str] = Field(default_factory=dict, description="Tool routing config")
    supports_retry: bool = Field(default=True, description="Supports validation retry")
    max_retries: int = Field(default=3, description="Maximum retry attempts")


class ParserNodeInfo(NodeConfigInfo):
    """Information about parser nodes."""
    
    node_type: Literal["parser"] = "parser"
    parser_type: str = Field(description="Type of parser")
    output_model: Optional[str] = Field(default=None, description="Output model class")
    supports_streaming: bool = Field(default=False, description="Supports streaming parsing")


class MultiAgentNodeInfo(NodeConfigInfo):
    """Information about multi-agent nodes."""
    
    node_type: Literal["multi_agent"] = "multi_agent"
    agents: list[str] = Field(default_factory=list, description="Agent names")
    execution_mode: Literal["sequential", "parallel", "conditional"] = Field(
        default="sequential",
        description="How agents execute"
    )
    routing_config: Optional[dict[str, Any]] = Field(
        default=None,
        description="Routing configuration"
    )


class CallableNodeInfo(NodeConfigInfo):
    """Information about callable/function nodes."""
    
    node_type: Literal["callable"] = "callable"
    function_name: str = Field(description="Function name")
    function_signature: str = Field(description="Function signature")
    is_async: bool = Field(default=False, description="Whether function is async")


class NodeExecutionRequest(BaseModel):
    """Request to execute a specific node."""
    
    node_name: str = Field(description="Name of node to execute")
    state: dict[str, Any] = Field(description="Input state")
    config: Optional[dict[str, Any]] = Field(default=None, description="Runtime config")


class NodeExecutionResult(BaseModel):
    """Result from node execution."""
    
    status: Literal["success", "error", "skipped"] = Field(description="Execution status")
    output: Optional[dict[str, Any]] = Field(default=None, description="Node output")
    error: Optional[str] = Field(default=None, description="Error if failed")
    duration_ms: Optional[float] = Field(default=None, description="Execution time")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Execution metadata")


class ValidationNodeResult(NodeExecutionResult):
    """Result from validation node execution."""
    
    validation_passed: bool = Field(default=False, description="Whether validation passed")
    validation_errors: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Validation errors"
    )
    retry_count: int = Field(default=0, description="Number of retries attempted")
    final_output: Optional[Any] = Field(default=None, description="Final validated output")


class ToolNodeResult(NodeExecutionResult):
    """Result from tool node execution."""
    
    tool_calls: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Tool calls made"
    )
    tool_results: dict[str, Any] = Field(
        default_factory=dict,
        description="Results from each tool"
    )
    parallel_execution: bool = Field(default=False, description="Whether executed in parallel")


class NodeCreationRequest(BaseModel):
    """Request to create a new node."""
    
    node_type: str = Field(description="Type of node to create")
    name: str = Field(description="Node name")
    config: dict[str, Any] = Field(description="Node configuration")
    input_mapping: Optional[dict[str, str]] = Field(default=None, description="Input mappings")
    output_mapping: Optional[dict[str, str]] = Field(default=None, description="Output mappings")


class NodeUpdateRequest(BaseModel):
    """Request to update a node configuration."""
    
    node_name: str = Field(description="Node to update")
    updates: dict[str, Any] = Field(description="Configuration updates")
    update_mappings: bool = Field(default=False, description="Update I/O mappings")


class NodeIntrospectionResult(BaseModel):
    """Result of node introspection."""
    
    node_name: str = Field(description="Node name")
    node_info: NodeConfigInfo = Field(description="Node information")
    dependencies: list[str] = Field(default_factory=list, description="Node dependencies")
    can_execute: bool = Field(description="Whether node can execute")
    missing_requirements: list[str] = Field(
        default_factory=list,
        description="Missing requirements"
    )
    performance_stats: Optional[dict[str, Any]] = Field(
        default=None,
        description="Performance statistics"
    )