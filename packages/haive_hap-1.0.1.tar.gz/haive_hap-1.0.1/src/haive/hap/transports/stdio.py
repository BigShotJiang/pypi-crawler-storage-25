"""
Standard I/O transport for HAP protocol.

This transport reads JSON-RPC requests from stdin and writes responses to stdout,
similar to how Language Server Protocol and MCP work.
"""

import sys
import json
import asyncio
from typing import Optional
import logging

from ..types import HAPRequest, HAPResponse, HAPError, ErrorCode, IHAPServer

logger = logging.getLogger(__name__)


class StdioTransport:
    """
    Standard I/O transport implementation.
    
    Reads JSON-RPC requests from stdin and writes responses to stdout.
    Each message is a single line of JSON.
    """
    
    def __init__(self):
        self.server: Optional[IHAPServer] = None
        self._running = False
        self._reader_task: Optional[asyncio.Task] = None
    
    async def start(self, server: IHAPServer):
        """
        Start the stdio transport.
        
        Args:
            server: The HAP server to handle requests
        """
        self.server = server
        self._running = True
        
        logger.info("Starting stdio transport")
        
        # Start reading from stdin
        self._reader_task = asyncio.create_task(self._read_loop())
        
        try:
            # Wait until stopped
            await self._reader_task
        except asyncio.CancelledError:
            logger.info("Stdio transport cancelled")
        except Exception as e:
            logger.error(f"Stdio transport error: {e}")
            raise
        finally:
            await self.stop()
    
    async def stop(self):
        """Stop the stdio transport."""
        logger.info("Stopping stdio transport")
        self._running = False
        
        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
    
    async def send_response(self, response: HAPResponse):
        """
        Send a response to stdout.
        
        Args:
            response: The HAP response to send
        """
        try:
            # Convert to JSON and write to stdout
            json_str = response.model_dump_json(exclude_none=True)
            print(json_str, flush=True)
            logger.debug(f"Sent response: {json_str}")
        except Exception as e:
            logger.error(f"Error sending response: {e}")
    
    async def _read_loop(self):
        """Main loop reading from stdin."""
        logger.info("Started reading from stdin")
        
        # Create stream reader for stdin
        loop = asyncio.get_event_loop()
        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        
        await loop.connect_read_pipe(lambda: protocol, sys.stdin)
        
        while self._running:
            try:
                # Read a line from stdin
                line_bytes = await reader.readline()
                
                if not line_bytes:
                    logger.info("EOF reached on stdin")
                    break
                
                line = line_bytes.decode('utf-8').strip()
                
                if not line:
                    continue
                
                logger.debug(f"Received line: {line}")
                
                # Parse and handle the request
                await self._handle_line(line)
                
            except asyncio.CancelledError:
                logger.info("Read loop cancelled")
                break
            except Exception as e:
                logger.error(f"Error in read loop: {e}")
                # Send error response
                error_response = HAPResponse(
                    jsonrpc="2.0",
                    id="unknown",
                    error=HAPError(
                        code=ErrorCode.INTERNAL_ERROR,
                        message=f"Read error: {str(e)}"
                    )
                )
                await self.send_response(error_response)
    
    async def _handle_line(self, line: str):
        """
        Handle a single line of input.
        
        Args:
            line: JSON-RPC request as string
        """
        request_id = "unknown"
        
        try:
            # Parse JSON
            data = json.loads(line)
            request_id = data.get("id", "unknown")
            
            # Validate and create request
            request = HAPRequest.model_validate(data)
            
            logger.info(f"Processing request: {request.method} (id: {request.id})")
            
            # Handle with server
            response = await self.server.handle_request(request)
            
            # Send response
            await self.send_response(response)
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}")
            error_response = HAPResponse(
                jsonrpc="2.0",
                id=request_id,
                error=HAPError(
                    code=ErrorCode.PARSE_ERROR,
                    message=f"Parse error: {str(e)}"
                )
            )
            await self.send_response(error_response)
            
        except Exception as e:
            logger.error(f"Request handling error: {e}")
            error_response = HAPResponse(
                jsonrpc="2.0",
                id=request_id,
                error=HAPError(
                    code=ErrorCode.INTERNAL_ERROR,
                    message=f"Internal error: {str(e)}"
                )
            )
            await self.send_response(error_response)


class ContentLengthStdioTransport(StdioTransport):
    """
    Content-Length based stdio transport (LSP-style).
    
    This transport uses Content-Length headers like the Language Server Protocol,
    allowing for multi-line JSON messages.
    """
    
    async def send_response(self, response: HAPResponse):
        """Send a response with Content-Length header."""
        try:
            # Convert to JSON
            json_str = response.model_dump_json(exclude_none=True, indent=2)
            json_bytes = json_str.encode('utf-8')
            
            # Write header and content
            header = f"Content-Length: {len(json_bytes)}\r\n\r\n"
            sys.stdout.buffer.write(header.encode('utf-8'))
            sys.stdout.buffer.write(json_bytes)
            sys.stdout.buffer.flush()
            
            logger.debug(f"Sent response with Content-Length: {len(json_bytes)}")
            
        except Exception as e:
            logger.error(f"Error sending response: {e}")
    
    async def _read_loop(self):
        """Read loop for Content-Length based messages."""
        logger.info("Started reading from stdin (Content-Length mode)")
        
        loop = asyncio.get_event_loop()
        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        
        await loop.connect_read_pipe(lambda: protocol, sys.stdin)
        
        while self._running:
            try:
                # Read headers
                headers = {}
                while True:
                    line_bytes = await reader.readline()
                    if not line_bytes:
                        logger.info("EOF reached on stdin")
                        return
                    
                    line = line_bytes.decode('utf-8').strip()
                    
                    if not line:
                        # Empty line marks end of headers
                        break
                    
                    # Parse header
                    if ':' in line:
                        key, value = line.split(':', 1)
                        headers[key.strip()] = value.strip()
                
                # Get content length
                content_length = headers.get('Content-Length')
                if not content_length:
                    logger.error("Missing Content-Length header")
                    continue
                
                try:
                    content_length = int(content_length)
                except ValueError:
                    logger.error(f"Invalid Content-Length: {content_length}")
                    continue
                
                # Read content
                content_bytes = await reader.readexactly(content_length)
                content = content_bytes.decode('utf-8')
                
                logger.debug(f"Received message ({content_length} bytes)")
                
                # Handle the request
                await self._handle_line(content)
                
            except asyncio.CancelledError:
                logger.info("Read loop cancelled")
                break
            except asyncio.IncompleteReadError:
                logger.error("Incomplete read - connection closed")
                break
            except Exception as e:
                logger.error(f"Error in read loop: {e}")
                # Continue reading