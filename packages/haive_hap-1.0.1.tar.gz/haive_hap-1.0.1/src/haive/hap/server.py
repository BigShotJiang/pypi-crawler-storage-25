"""
Base HAPServer implementation with tool, resource, and prompt management.

This is the core server class that all HAP servers inherit from.
It provides the registration system and request handling logic.
"""

import asyncio
import inspect
from typing import Any, Callable, Dict, List, Optional, Union, get_type_hints
from functools import wraps
from datetime import datetime
import json

from pydantic import BaseModel, create_model
from pydantic.json_schema import GenerateJsonSchema

from .types import (
    HAPRequest,
    HAPResponse,
    HAPError,
    ErrorCode,
    ToolInfo,
    ResourceInfo,
    PromptInfo,
    PromptArgument,
    ToolCall,
    ResourceRead,
    PromptGet,
    ServerCapability,
)
from .context import HAPContext, SimpleResourceProvider


class ToolWrapper:
    """Wrapper for registered tools."""
    
    def __init__(
        self,
        name: str,
        func: Callable,
        description: str = "",
        input_model: Optional[type[BaseModel]] = None,
        output_model: Optional[type[BaseModel]] = None,
    ):
        self.name = name
        self.func = func
        self.description = description or func.__doc__ or ""
        self.input_model = input_model
        self.output_model = output_model
        
        # Extract schema if not provided
        if not self.input_model:
            self._extract_input_schema()
    
    def _extract_input_schema(self):
        """Extract input schema from function signature."""
        sig = inspect.signature(self.func)
        
        # Skip 'self' and 'ctx' parameters
        fields = {}
        for param_name, param in sig.parameters.items():
            if param_name in ("self", "ctx"):
                continue
            
            # Get type annotation
            param_type = param.annotation if param.annotation != inspect.Parameter.empty else Any
            
            # Check if required
            required = param.default == inspect.Parameter.empty
            
            # Create field
            if required:
                fields[param_name] = (param_type, ...)
            else:
                fields[param_name] = (param_type, param.default)
        
        # Create dynamic model
        if fields:
            self.input_model = create_model(
                f"{self.name}_Input",
                **fields
            )
    
    def get_info(self) -> ToolInfo:
        """Get tool info."""
        input_schema = {}
        if self.input_model:
            input_schema = self.input_model.model_json_schema()
        
        output_schema = None
        if self.output_model:
            output_schema = self.output_model.model_json_schema()
        
        return ToolInfo(
            name=self.name,
            description=self.description,
            input_schema=input_schema,
            output_schema=output_schema,
        )
    
    async def execute(self, arguments: dict, ctx: HAPContext) -> Any:
        """Execute the tool."""
        # Validate input if model exists
        if self.input_model:
            try:
                validated = self.input_model.model_validate(arguments)
                arguments = validated.model_dump()
            except Exception as e:
                raise ValueError(f"Invalid arguments: {str(e)}")
        
        # Check if context is needed
        sig = inspect.signature(self.func)
        if "ctx" in sig.parameters:
            if asyncio.iscoroutinefunction(self.func):
                result = await self.func(**arguments, ctx=ctx)
            else:
                result = self.func(**arguments, ctx=ctx)
        else:
            if asyncio.iscoroutinefunction(self.func):
                result = await self.func(**arguments)
            else:
                result = self.func(**arguments)
        
        # Validate output if model exists
        if self.output_model:
            if isinstance(result, BaseModel):
                return result.model_dump()
            else:
                validated = self.output_model.model_validate(result)
                return validated.model_dump()
        
        return result


class ResourceWrapper:
    """Wrapper for registered resources."""
    
    def __init__(
        self,
        uri: str,
        func: Callable,
        name: str = "",
        description: str = "",
        mime_type: str = "application/json",
    ):
        self.uri = uri
        self.func = func
        self.name = name or uri
        self.description = description or func.__doc__ or ""
        self.mime_type = mime_type
    
    def get_info(self) -> ResourceInfo:
        """Get resource info."""
        return ResourceInfo(
            uri=self.uri,
            name=self.name,
            description=self.description,
            mime_type=self.mime_type,
        )
    
    async def read(self, ctx: HAPContext) -> Any:
        """Read the resource."""
        if asyncio.iscoroutinefunction(self.func):
            return await self.func()
        else:
            return self.func()


class PromptWrapper:
    """Wrapper for registered prompts."""
    
    def __init__(
        self,
        name: str,
        func: Callable,
        description: str = "",
    ):
        self.name = name
        self.func = func
        self.description = description or func.__doc__ or ""
        self._extract_arguments()
    
    def _extract_arguments(self):
        """Extract prompt arguments from function signature."""
        sig = inspect.signature(self.func)
        self.arguments = []
        
        for param_name, param in sig.parameters.items():
            if param_name == "self":
                continue
            
            required = param.default == inspect.Parameter.empty
            
            self.arguments.append(
                PromptArgument(
                    name=param_name,
                    description=f"Argument: {param_name}",
                    required=required,
                )
            )
    
    def get_info(self) -> PromptInfo:
        """Get prompt info."""
        return PromptInfo(
            name=self.name,
            description=self.description,
            arguments=self.arguments,
        )
    
    async def get(self, arguments: dict, ctx: HAPContext) -> str:
        """Get the prompt."""
        if asyncio.iscoroutinefunction(self.func):
            return await self.func(**arguments)
        else:
            return self.func(**arguments)


class HAPServer:
    """
    Base HAP server with tool, resource, and prompt management.
    
    This class provides the core functionality for creating HAP servers
    that expose tools, resources, and prompts via the HAP protocol.
    """
    
    def __init__(
        self,
        name: str,
        description: str = "",
        version: str = "1.0.0",
    ):
        self.name = name
        self.description = description
        self.version = version
        
        # Registries
        self._tools: Dict[str, ToolWrapper] = {}
        self._resources: Dict[str, ResourceWrapper] = {}
        self._prompts: Dict[str, PromptWrapper] = {}
        
        # Middleware stack
        self._middleware: List[Callable] = []
        
        # Resource provider for internal resources
        self._resource_provider = SimpleResourceProvider()
        
        # Server metadata
        self.created_at = datetime.now()
        
        # Register built-in resources
        self._register_builtin_resources()
    
    def _register_builtin_resources(self):
        """Register built-in server resources."""
        
        @self.resource("hap://server/info")
        def server_info() -> dict:
            """Get server information."""
            return {
                "name": self.name,
                "description": self.description,
                "version": self.version,
                "type": self.__class__.__name__,
                "created_at": self.created_at.isoformat(),
                "capabilities": self.get_capabilities(),
                "stats": {
                    "tools": len(self._tools),
                    "resources": len(self._resources),
                    "prompts": len(self._prompts),
                }
            }
    
    # Registration Decorators
    
    def tool(
        self,
        name: Optional[str] = None,
        description: Optional[str] = None,
        input_model: Optional[type[BaseModel]] = None,
        output_model: Optional[type[BaseModel]] = None,
    ):
        """
        Decorator to register a tool.
        
        Args:
            name: Tool name (defaults to function name)
            description: Tool description (defaults to docstring)
            input_model: Pydantic model for input validation
            output_model: Pydantic model for output validation
        """
        def decorator(func: Callable) -> Callable:
            tool_name = name or func.__name__
            tool_desc = description or func.__doc__ or ""
            
            # Create wrapper
            wrapper = ToolWrapper(
                name=tool_name,
                func=func,
                description=tool_desc,
                input_model=input_model,
                output_model=output_model,
            )
            
            # Register
            self._tools[tool_name] = wrapper
            
            return func
        
        return decorator
    
    def resource(
        self,
        uri: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        mime_type: str = "application/json",
    ):
        """
        Decorator to register a resource.
        
        Args:
            uri: Resource URI
            name: Resource name (defaults to URI)
            description: Resource description (defaults to docstring)
            mime_type: MIME type of the resource
        """
        def decorator(func: Callable) -> Callable:
            resource_name = name or uri
            resource_desc = description or func.__doc__ or ""
            
            # Create wrapper
            wrapper = ResourceWrapper(
                uri=uri,
                func=func,
                name=resource_name,
                description=resource_desc,
                mime_type=mime_type,
            )
            
            # Register
            self._resources[uri] = wrapper
            
            return func
        
        return decorator
    
    def prompt(
        self,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ):
        """
        Decorator to register a prompt.
        
        Args:
            name: Prompt name (defaults to function name)
            description: Prompt description (defaults to docstring)
        """
        def decorator(func: Callable) -> Callable:
            prompt_name = name or func.__name__
            prompt_desc = description or func.__doc__ or ""
            
            # Create wrapper
            wrapper = PromptWrapper(
                name=prompt_name,
                func=func,
                description=prompt_desc,
            )
            
            # Register
            self._prompts[prompt_name] = wrapper
            
            return func
        
        return decorator
    
    # Capability Methods
    
    def get_capabilities(self) -> List[ServerCapability]:
        """Get server capabilities."""
        caps = []
        
        # Don't count built-in resources
        non_builtin_resources = [r for r in self._resources if not r.startswith("hap://")]
        
        if self._tools:
            caps.append(ServerCapability.TOOLS)
        if non_builtin_resources:
            caps.append(ServerCapability.RESOURCES)
        if self._prompts:
            caps.append(ServerCapability.PROMPTS)
        
        return caps
    
    # List Methods
    
    def list_tools(self) -> List[ToolInfo]:
        """List all available tools."""
        return [tool.get_info() for tool in self._tools.values()]
    
    def list_resources(self) -> List[ResourceInfo]:
        """List all available resources."""
        return [resource.get_info() for resource in self._resources.values()]
    
    def list_prompts(self) -> List[PromptInfo]:
        """List all available prompts."""
        return [prompt.get_info() for prompt in self._prompts.values()]
    
    # Request Handling
    
    async def handle_request(self, request: HAPRequest) -> HAPResponse:
        """
        Handle incoming HAP request.
        
        This is the main entry point for processing requests.
        """
        # Create context for this request
        ctx = HAPContext(
            request_id=request.id,
            resource_provider=self._resource_provider,
        )
        
        try:
            # Apply middleware
            for middleware in self._middleware:
                request = await middleware(request, ctx)
            
            # Route to appropriate handler
            if request.method == "tools/list":
                result = self.list_tools()
            elif request.method == "tools/call":
                result = await self._handle_tool_call(request.params, ctx)
            elif request.method == "resources/list":
                result = self.list_resources()
            elif request.method == "resources/read":
                result = await self._handle_resource_read(request.params, ctx)
            elif request.method == "prompts/list":
                result = self.list_prompts()
            elif request.method == "prompts/get":
                result = await self._handle_prompt_get(request.params, ctx)
            else:
                return HAPResponse(
                    jsonrpc="2.0",
                    id=request.id,
                    error=HAPError(
                        code=ErrorCode.METHOD_NOT_FOUND,
                        message=f"Unknown method: {request.method}",
                    )
                )
            
            # Return success response
            return HAPResponse(
                jsonrpc="2.0",
                id=request.id,
                result=result,
            )
            
        except Exception as e:
            # Return error response
            return HAPResponse(
                jsonrpc="2.0",
                id=request.id,
                error=HAPError(
                    code=ErrorCode.INTERNAL_ERROR,
                    message=str(e),
                    data={"type": type(e).__name__}
                )
            )
    
    async def _handle_tool_call(self, params: dict, ctx: HAPContext) -> Any:
        """Handle tool call request."""
        tool_call = ToolCall.model_validate(params)
        
        if tool_call.name not in self._tools:
            raise ValueError(f"Tool not found: {tool_call.name}")
        
        tool = self._tools[tool_call.name]
        return await tool.execute(tool_call.arguments, ctx)
    
    async def _handle_resource_read(self, params: dict, ctx: HAPContext) -> Any:
        """Handle resource read request."""
        resource_read = ResourceRead.model_validate(params)
        
        if resource_read.uri not in self._resources:
            raise ValueError(f"Resource not found: {resource_read.uri}")
        
        resource = self._resources[resource_read.uri]
        return await resource.read(ctx)
    
    async def _handle_prompt_get(self, params: dict, ctx: HAPContext) -> str:
        """Handle prompt get request."""
        prompt_get = PromptGet.model_validate(params)
        
        if prompt_get.name not in self._prompts:
            raise ValueError(f"Prompt not found: {prompt_get.name}")
        
        prompt = self._prompts[prompt_get.name]
        return await prompt.get(prompt_get.arguments, ctx)
    
    # Middleware
    
    def add_middleware(self, middleware: Callable):
        """Add middleware to the server."""
        self._middleware.append(middleware)
    
    # Transport Methods (to be implemented by transports)
    
    async def run_stdio(self):
        """Run server with stdio transport."""
        from .transports.stdio import StdioTransport
        transport = StdioTransport()
        await transport.start(self)
    
    async def run_http(
        self,
        host: str = "localhost",
        port: int = 8000,
        path_prefix: str = "/api/v1",
    ):
        """Run server with HTTP transport."""
        from .transports.http import HTTPTransport
        transport = HTTPTransport(host=host, port=port, path_prefix=path_prefix)
        await transport.start(self)
    
    async def run_sse(
        self,
        host: str = "localhost",
        port: int = 8001,
        endpoint: str = "/sse",
    ):
        """Run server with SSE transport."""
        from .transports.sse import SSETransport
        transport = SSETransport(host=host, port=port, endpoint=endpoint)
        await transport.start(self)