"""
AgentServer implementation for exposing Haive agents via HAP protocol.

This module provides a HAP server that wraps any Haive agent and exposes
its functionality through tools, resources, and prompts.
"""

from typing import Any, Optional, Dict, List
import asyncio
import inspect
from datetime import datetime

from ..server import HAPServer
from ..context import HAPContext
from ..types import (
    AgentInfo,
    AgentExecutionRequest,
    AgentExecutionResult,
    ServerCapability,
)


class AgentServer(HAPServer):
    """
    HAP server that exposes a Haive agent via MCP-like protocol.
    
    This server wraps any Haive agent and provides:
    - Tool for executing the agent
    - Resources for agent state and configuration
    - Tools for individual agent tools (if applicable)
    - Structured output schema access
    """
    
    def __init__(
        self,
        agent: Any,
        name: Optional[str] = None,
        description: Optional[str] = None,
        expose_tools: bool = True,
        expose_state: bool = True,
    ):
        """
        Initialize AgentServer.
        
        Args:
            agent: The Haive agent to expose
            name: Server name (defaults to agent-{agent.name})
            description: Server description
            expose_tools: Whether to expose agent's individual tools
            expose_state: Whether to expose agent state as resource
        """
        # Extract agent name
        agent_name = getattr(agent, "name", agent.__class__.__name__)
        
        super().__init__(
            name=name or f"agent-{agent_name}",
            description=description or f"HAP server for {agent_name} agent",
        )
        
        self.agent = agent
        self.agent_name = agent_name
        self.expose_tools = expose_tools
        self.expose_state = expose_state
        
        # Track execution stats
        self.execution_count = 0
        self.total_execution_time = 0.0
        self.last_execution = None
        
        # Register agent interface
        self._register_agent_interface()
    
    def _register_agent_interface(self):
        """Register agent-specific tools, resources, and prompts."""
        
        # Main execution tool
        @self.tool(
            description=f"Execute the {self.agent_name} agent",
            input_model=AgentExecutionRequest,
            output_model=AgentExecutionResult,
        )
        async def execute(
            input_data: dict,
            ctx: HAPContext,
            config_overrides: Optional[dict] = None,
            stream: bool = False
        ) -> AgentExecutionResult:
            """Execute the agent with given input."""
            start_time = datetime.now()
            
            try:
                await ctx.info(f"Starting execution of {self.agent_name}")
                await ctx.report_progress(0, 100, "Initializing agent")
                
                # Apply config overrides if provided
                if config_overrides and hasattr(self.agent, "update_config"):
                    await ctx.debug("Applying configuration overrides")
                    self.agent.update_config(config_overrides)
                
                # Execute agent
                await ctx.report_progress(25, 100, "Executing agent")
                
                # Check if agent has async run method
                if hasattr(self.agent, "arun"):
                    result = await self.agent.arun(input_data)
                elif hasattr(self.agent, "run"):
                    # Run sync method in thread pool
                    result = await asyncio.to_thread(self.agent.run, input_data)
                else:
                    # Try calling directly
                    if asyncio.iscoroutinefunction(self.agent):
                        result = await self.agent(input_data)
                    else:
                        result = await asyncio.to_thread(self.agent, input_data)
                
                # Process result
                await ctx.report_progress(75, 100, "Processing results")
                
                execution_time = (datetime.now() - start_time).total_seconds()
                self.execution_count += 1
                self.total_execution_time += execution_time
                self.last_execution = datetime.now()
                
                await ctx.report_progress(100, 100, "Execution complete")
                await ctx.info(f"Agent {self.agent_name} completed in {execution_time:.2f}s")
                
                return AgentExecutionResult(
                    status="success",
                    result=result,
                    execution_time=execution_time,
                    metadata={
                        "agent_name": self.agent_name,
                        "execution_count": self.execution_count,
                    }
                )
                
            except Exception as e:
                await ctx.error(f"Agent execution failed: {str(e)}")
                execution_time = (datetime.now() - start_time).total_seconds()
                
                return AgentExecutionResult(
                    status="error",
                    error=str(e),
                    execution_time=execution_time,
                    metadata={
                        "agent_name": self.agent_name,
                        "error_type": type(e).__name__,
                    }
                )
        
        # Agent info resource
        @self.resource(f"agent://{self.agent_name}/info")
        def get_agent_info() -> AgentInfo:
            """Get agent information and capabilities."""
            capabilities = []
            
            # Check capabilities
            if hasattr(self.agent, "tools") and self.agent.tools:
                capabilities.append("tools")
            
            if hasattr(self.agent, "engine"):
                engine = self.agent.engine
                if hasattr(engine, "structured_output_model"):
                    capabilities.append("structured_output")
                if hasattr(engine, "system_message"):
                    capabilities.append("system_message")
            
            if hasattr(self.agent, "memory"):
                capabilities.append("memory")
            
            if hasattr(self.agent, "get_state"):
                capabilities.append("state_persistence")
            
            # Get tool names
            tool_names = []
            if hasattr(self.agent, "tools"):
                tool_names = [
                    tool.name if hasattr(tool, "name") else str(tool)
                    for tool in self.agent.tools
                ]
            
            return AgentInfo(
                name=self.agent_name,
                type=self.agent.__class__.__name__,
                description=getattr(self.agent, "description", ""),
                capabilities=capabilities,
                tools=tool_names,
                state_schema=self._get_state_schema(),
            )
        
        # Agent state resource (if enabled)
        if self.expose_state:
            @self.resource(f"agent://{self.agent_name}/state")
            def get_state() -> dict:
                """Get current agent state."""
                if hasattr(self.agent, "get_state"):
                    return self.agent.get_state()
                elif hasattr(self.agent, "model_dump"):
                    return self.agent.model_dump()
                else:
                    return {
                        "message": "Agent does not expose state",
                        "type": self.agent.__class__.__name__,
                    }
        
        # Agent configuration resource
        @self.resource(f"agent://{self.agent_name}/config")
        def get_config() -> dict:
            """Get agent configuration."""
            config = {
                "name": self.agent_name,
                "type": self.agent.__class__.__name__,
            }
            
            # Add engine config if available
            if hasattr(self.agent, "engine"):
                engine = self.agent.engine
                config["engine"] = {
                    "type": engine.__class__.__name__,
                }
                
                # Add relevant engine fields
                if hasattr(engine, "model"):
                    config["engine"]["model"] = engine.model
                if hasattr(engine, "temperature"):
                    config["engine"]["temperature"] = engine.temperature
                if hasattr(engine, "max_tokens"):
                    config["engine"]["max_tokens"] = engine.max_tokens
            
            # Add model dump if available
            if hasattr(self.agent, "model_dump"):
                config["full_config"] = self.agent.model_dump()
            
            return config
        
        # Execution statistics resource
        @self.resource(f"agent://{self.agent_name}/stats")
        def get_stats() -> dict:
            """Get agent execution statistics."""
            avg_time = (
                self.total_execution_time / self.execution_count
                if self.execution_count > 0
                else 0.0
            )
            
            return {
                "execution_count": self.execution_count,
                "total_execution_time": self.total_execution_time,
                "average_execution_time": avg_time,
                "last_execution": (
                    self.last_execution.isoformat()
                    if self.last_execution
                    else None
                ),
            }
        
        # Expose individual agent tools (if enabled)
        if self.expose_tools and hasattr(self.agent, "tools"):
            self._register_agent_tools()
        
        # Expose structured output schema if available
        if hasattr(self.agent, "engine") and hasattr(self.agent.engine, "structured_output_model"):
            self._register_structured_output()
        
        # Expose prompts if available
        if hasattr(self.agent, "prompt_template"):
            self._register_agent_prompt()
    
    def _register_agent_tools(self):
        """Register individual agent tools as HAP tools."""
        for tool in self.agent.tools:
            tool_name = getattr(tool, "name", str(tool))
            
            # Create wrapper function
            async def execute_tool(
                tool_input: dict,
                ctx: HAPContext,
                _tool=tool  # Capture tool in closure
            ) -> dict:
                """Execute specific agent tool."""
                await ctx.info(f"Executing tool: {_tool.name if hasattr(_tool, 'name') else str(_tool)}")
                
                try:
                    # Check if tool has async run
                    if hasattr(_tool, "arun"):
                        result = await _tool.arun(tool_input)
                    elif hasattr(_tool, "run"):
                        result = await asyncio.to_thread(_tool.run, tool_input)
                    else:
                        # Try calling directly
                        if asyncio.iscoroutinefunction(_tool):
                            result = await _tool(tool_input)
                        else:
                            result = await asyncio.to_thread(_tool, tool_input)
                    
                    return {
                        "status": "success",
                        "result": result,
                        "tool": tool_name,
                    }
                    
                except Exception as e:
                    await ctx.error(f"Tool execution failed: {str(e)}")
                    return {
                        "status": "error",
                        "error": str(e),
                        "tool": tool_name,
                    }
            
            # Register the tool
            self.tool(
                name=f"tool_{tool_name}",
                description=f"Execute {tool_name} tool from {self.agent_name}",
            )(execute_tool)
    
    def _register_structured_output(self):
        """Register structured output schema resource."""
        model = self.agent.engine.structured_output_model
        
        @self.resource(f"agent://{self.agent_name}/output_schema")
        def get_output_schema() -> dict:
            """Get the structured output schema."""
            return {
                "model_name": model.__name__,
                "schema": model.model_json_schema(),
                "fields": list(model.model_fields.keys()),
            }
        
        @self.tool()
        def validate_output(data: dict) -> dict:
            """Validate data against structured output schema."""
            try:
                validated = model.model_validate(data)
                return {
                    "valid": True,
                    "data": validated.model_dump(),
                }
            except Exception as e:
                return {
                    "valid": False,
                    "errors": str(e),
                }
    
    def _register_agent_prompt(self):
        """Register agent prompt as HAP prompt."""
        @self.prompt(
            name=f"{self.agent_name}_prompt",
            description=f"Get the prompt template for {self.agent_name}",
        )
        def get_agent_prompt(**kwargs) -> str:
            """Get agent prompt with variables filled."""
            prompt_template = self.agent.prompt_template
            
            # If it's a string template
            if isinstance(prompt_template, str):
                return prompt_template.format(**kwargs)
            
            # If it's a ChatPromptTemplate or similar
            if hasattr(prompt_template, "format"):
                return prompt_template.format(**kwargs)
            
            # If it has a messages attribute
            if hasattr(prompt_template, "messages"):
                messages = prompt_template.messages
                formatted = []
                for msg in messages:
                    if hasattr(msg, "format"):
                        formatted.append(msg.format(**kwargs))
                    else:
                        formatted.append(str(msg))
                return "\n".join(formatted)
            
            # Default: return string representation
            return str(prompt_template)
    
    def _get_state_schema(self) -> Optional[dict]:
        """Get agent state schema if available."""
        # Check if agent has explicit state schema
        if hasattr(self.agent, "state_schema"):
            schema_class = self.agent.state_schema
            if hasattr(schema_class, "model_json_schema"):
                return schema_class.model_json_schema()
        
        # Check if agent itself is a Pydantic model
        if hasattr(self.agent, "model_json_schema"):
            return self.agent.model_json_schema()
        
        # Try to infer from get_state
        if hasattr(self.agent, "get_state"):
            try:
                state = self.agent.get_state()
                if isinstance(state, dict):
                    # Create basic schema from state keys
                    properties = {}
                    for key, value in state.items():
                        properties[key] = {
                            "type": type(value).__name__.lower()
                        }
                    return {
                        "type": "object",
                        "properties": properties,
                    }
            except:
                pass
        
        return None
    
    def get_capabilities(self) -> List[ServerCapability]:
        """Get server capabilities including agent-specific ones."""
        caps = super().get_capabilities()
        
        # Add agent-specific capabilities
        if hasattr(self.agent, "engine") and hasattr(self.agent.engine, "stream"):
            if ServerCapability.STREAMING not in caps:
                caps.append(ServerCapability.STREAMING)
        
        if hasattr(self.agent, "get_state") or hasattr(self.agent, "save_state"):
            if ServerCapability.STATE_PERSISTENCE not in caps:
                caps.append(ServerCapability.STATE_PERSISTENCE)
        
        return caps