# AGP Server Module

This module contains the runtime and server components for executing AGP workflows.

## Overview

The server module provides:
- **HAPRuntime**: Core execution engine for agent graphs
- Future: HAP server integration for protocol-based agent exposure

## Components

### HAPRuntime

The main execution engine that:
- Loads agents from entrypoints or instances
- Executes graphs with proper context flow
- Handles async and sync execution patterns
- Manages error propagation

```python
from haive.hap.server.runtime import HAPRuntime
from haive.hap.models.graph import HAPGraph

# Create and execute workflow
graph = HAPGraph()
# ... build graph ...

runtime = HAPRuntime(graph)
result = await runtime.run(initial_context)
```

## Key Features

### Agent Loading

The runtime supports multiple agent loading patterns:

```python
# From entrypoint string
runtime._load_agent("haive.agents.simple:SimpleAgent")

# With automatic configuration
# Tries: no args → name only → name + engine
```

### Execution Flow

1. **Initialize**: Create runtime with graph
2. **Load**: Load agents as needed
3. **Execute**: Run through topological order
4. **Context Flow**: Pass context between nodes
5. **Complete**: Return final context with all metadata

### Error Handling

- Invalid entrypoint formats
- Missing modules or classes
- Agent instantiation failures
- Execution errors with proper propagation

## Usage Patterns

### Basic Execution

```python
runtime = HAPRuntime(graph)
result = await runtime.run({"input": "data"})
```

### Synchronous Execution

```python
result = runtime.run_sync({"input": "data"})
```

### Custom Context

```python
initial_context = {
    "user": "alice",
    "session": "12345",
    "config": {...}
}
result = await runtime.run(initial_context)
```

## Future Development

### HAP Server Integration

The server module will integrate with HAP (Haive Agent Protocol) to:
- Expose agents via JSON-RPC
- Handle agent discovery
- Manage agent lifecycles
- Support distributed execution

### Plugin System

Following the plugin generalization pattern from haive-dataflow:
- Auto-discovery of agents
- Dynamic registration
- Server factory creation