from typing import Protocol
from haive.hap.models.context import HAPContext

class BaseAgentProtocol(Protocol):
    def __call__(self, context: HAPContext) -> HAPContext: ...
