"""
Haive Agent Protocol (HAP) - MCP-like server for agents and graphs.

This module provides a standardized protocol for exposing Haive agents,
graphs, and state schemas as servers with tools, resources, and prompts.
"""

# Core models
from haive.hap.models.graph import HAPGraph, HAPNode
from haive.hap.models.context import HAPContext

# Protocol types from types package
from haive.hap.types import (
    HAPRequest,
    HAPResponse, 
    HAPError,
    ErrorCode,
    ToolInfo,
    ResourceInfo,
    PromptInfo,
    PromptArgument,
    AgentInfo,
    GraphInfo,
    NodeInfo,
    EdgeInfo,
    ServerRegistration,
    ServerCapability,
    AgentExecutionRequest,
    AgentExecutionResult,
    GraphExecutionRequest,
    GraphExecutionResult,
    BaseInfo,
    # Aliases
    AgentId,
    Entrypoint, 
    JSONMap
)

__version__ = "0.1.0"

__all__ = [
    # Core models
    "HAPGraph",
    "HAPNode", 
    "HAPContext",
    # Protocol types
    "HAPRequest",
    "HAPResponse",
    "HAPError", 
    "ErrorCode",
    "ToolInfo",
    "ResourceInfo",
    "PromptInfo",
    "PromptArgument",
    "AgentInfo",
    "GraphInfo",
    "NodeInfo",
    "EdgeInfo", 
    "ServerRegistration",
    "ServerCapability",
    "AgentExecutionRequest",
    "AgentExecutionResult",
    "GraphExecutionRequest", 
    "GraphExecutionResult",
    "BaseInfo"
]