from typing import Any, Dict, List
from pydantic import Field
from haive.core.schema.state_schema import StateSchema

class HAPContext(StateSchema):
    """HAP execution context inheriting from real Haive StateSchema."""
    
    # HAP-specific fields that extend StateSchema
    execution_path: List[str] = Field(
        default_factory=list,
        description="Path of agents/nodes executed"
    )
    
    agent_metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Metadata about agents in execution"
    )
    
    graph_context: Dict[str, Any] = Field(
        default_factory=dict,
        description="Graph-level execution context"
    )
    
    # Backward compatibility fields - stored as regular fields
    legacy_inputs: Dict[str, Any] = Field(default_factory=dict)
    legacy_outputs: Dict[str, Any] = Field(default_factory=dict)
    legacy_state: Dict[str, Any] = Field(default_factory=dict)
    legacy_meta: Dict[str, Any] = Field(default_factory=dict)
    
    # Backward compatibility properties
    @property
    def inputs(self) -> Dict[str, Any]:
        """Backward compatibility for inputs."""
        return self.legacy_inputs
    
    @inputs.setter
    def inputs(self, value: Dict[str, Any]):
        """Backward compatibility setter."""
        self.legacy_inputs = value
    
    @property
    def outputs(self) -> Dict[str, Any]:
        """Backward compatibility for outputs."""
        return self.legacy_outputs
    
    @outputs.setter  
    def outputs(self, value: Dict[str, Any]):
        """Backward compatibility setter."""
        self.legacy_outputs = value
    
    @property
    def state(self) -> Dict[str, Any]:
        """Backward compatibility for state."""
        return self.legacy_state
    
    @state.setter
    def state(self, value: Dict[str, Any]):
        """Backward compatibility setter."""
        self.legacy_state = value
    
    @property
    def meta(self) -> Dict[str, Any]:
        """Backward compatibility for meta."""
        return self.legacy_meta
    
    @meta.setter
    def meta(self, value: Dict[str, Any]):
        """Backward compatibility setter."""
        self.legacy_meta = value
