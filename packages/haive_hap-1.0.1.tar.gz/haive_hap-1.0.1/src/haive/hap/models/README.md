# AGP Models Module

This module contains the core data models for the Haive Agent Protocol (AGP).

## Overview

The models module provides the fundamental building blocks for AGP:
- **HAPContext**: State management with execution tracking
- **HAPGraph**: Graph structure for agent workflows
- **HAPNode**: Individual nodes in the graph

## Components

### HAPContext

The `HAPContext` class extends Haive's `StateSchema` to provide:
- Execution path tracking
- Agent metadata storage
- Graph context management
- Backward compatibility with AGP v1 properties

```python
from haive.hap.models.context import HAPContext

context = HAPContext()
context.execution_path.append("node1")
context.agent_metadata["node1"] = {"status": "complete"}
```

### HAPGraph

The `HAPGraph` class manages the workflow structure:
- Node management (add, remove, connect)
- Topological ordering for execution
- Entry point configuration

```python
from haive.hap.models.graph import HAPGraph

graph = HAPGraph()
graph.add_agent_node("step1", agent1, next_nodes=["step2"])
graph.add_agent_node("step2", agent2)
graph.entry_node = "step1"
```

### HAPNode

Individual nodes in the graph that can contain:
- Agent instances
- Agent entrypoints (module:class format)
- Connections to other nodes

## Backward Compatibility

The module maintains backward compatibility with AGP v1:
- `HAPContext` supports `inputs`, `outputs`, `state`, `meta` properties
- `AgentGraph` and `AgentNode` are aliases for the AGP classes

## Usage Example

```python
from haive.hap.models import HAPGraph, HAPContext
from haive.agents.simple.agent import SimpleAgent

# Create context
context = HAPContext()

# Build graph
graph = HAPGraph()
agent = SimpleAgent(name="worker", engine=config)
graph.add_agent_node("worker_node", agent)

# Track execution
context.execution_path.append("worker_node")
context.agent_metadata["worker_node"] = {
    "start_time": time.time(),
    "status": "running"
}
```

## Design Principles

1. **StateSchema Integration**: HAPContext inherits from StateSchema for proper Haive integration
2. **Simplicity**: Uses BaseModel instead of complex inheritance chains
3. **Flexibility**: Supports both agent instances and entrypoint strings
4. **Compatibility**: Maintains all AGP v1 interfaces