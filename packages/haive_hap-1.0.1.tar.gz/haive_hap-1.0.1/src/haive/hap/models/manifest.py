from typing import Dict, List, Optional
from pydantic import BaseModel, Field

class AgentManifest(BaseModel):
    name: str
    version: str = "0.1.0"
    entrypoint: str
    description: Optional[str] = None
    dependencies: List[str] = Field(default_factory=list)
    inputs: Dict[str, str] = Field(default_factory=dict)
    outputs: Dict[str, str] = Field(default_factory=dict)
