"""
Context system for HAP, providing execution context for tools and resources.

Similar to MCP's context, this allows tools to:
- Log messages at different levels
- Report progress
- Access resources
- Get authentication info
"""

from typing import Optional, Any, Dict, List, Callable, Protocol
from datetime import datetime
import asyncio
from enum import Enum


class LogLevel(str, Enum):
    """Log levels for context messages."""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class ProgressState(Enum):
    """Progress reporting state."""
    STARTED = "started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class IResourceProvider(Protocol):
    """Interface for resource providers."""
    
    async def read_resource(self, uri: str) -> Any:
        """Read a resource by URI."""
        ...


class IAuthProvider(Protocol):
    """Interface for authentication providers."""
    
    def get_current_user(self) -> Optional[str]:
        """Get the current authenticated user."""
        ...
    
    def get_user_scopes(self) -> List[str]:
        """Get the current user's scopes."""
        ...


class HAPContext:
    """
    Execution context for HAP tools and resources.
    
    Provides utilities for logging, progress reporting, resource access,
    and authentication info during execution.
    """
    
    def __init__(
        self,
        request_id: str | int,
        resource_provider: Optional[IResourceProvider] = None,
        auth_provider: Optional[IAuthProvider] = None,
        log_handler: Optional[Callable[[str, LogLevel, dict], None]] = None,
        progress_handler: Optional[Callable[[int, int, str, ProgressState], None]] = None,
    ):
        self.request_id = request_id
        self._resource_provider = resource_provider
        self._auth_provider = auth_provider
        self._log_handler = log_handler
        self._progress_handler = progress_handler
        
        # Track progress for nested operations
        self._progress_stack: List[tuple[int, str]] = []
        
        # Store context data
        self._data: Dict[str, Any] = {}
    
    # Logging Methods
    
    async def debug(self, message: str, **kwargs):
        """Log debug message."""
        await self._log(LogLevel.DEBUG, message, kwargs)
    
    async def info(self, message: str, **kwargs):
        """Log info message."""
        await self._log(LogLevel.INFO, message, kwargs)
    
    async def warning(self, message: str, **kwargs):
        """Log warning message."""
        await self._log(LogLevel.WARNING, message, kwargs)
    
    async def error(self, message: str, **kwargs):
        """Log error message."""
        await self._log(LogLevel.ERROR, message, kwargs)
    
    async def _log(self, level: LogLevel, message: str, data: dict):
        """Internal logging method."""
        if self._log_handler:
            log_entry = {
                "timestamp": datetime.now().isoformat(),
                "level": level.value,
                "message": message,
                "request_id": self.request_id,
                **data
            }
            # Run in background to not block
            asyncio.create_task(
                asyncio.to_thread(self._log_handler, message, level, log_entry)
            )
    
    # Progress Reporting
    
    async def report_progress(
        self,
        current: int,
        total: int,
        message: str = "",
        state: Optional[ProgressState] = None
    ):
        """
        Report progress for the current operation.
        
        Args:
            current: Current progress value
            total: Total expected value
            message: Optional progress message
            state: Optional progress state
        """
        if not state:
            if current == 0:
                state = ProgressState.STARTED
            elif current >= total:
                state = ProgressState.COMPLETED
            else:
                state = ProgressState.IN_PROGRESS
        
        if self._progress_handler:
            asyncio.create_task(
                asyncio.to_thread(
                    self._progress_handler,
                    current,
                    total,
                    message,
                    state
                )
            )
    
    def start_nested_progress(self, total: int, description: str = ""):
        """Start a nested progress operation."""
        self._progress_stack.append((total, description))
    
    async def update_nested_progress(self, current: int, message: str = ""):
        """Update the current nested progress."""
        if self._progress_stack:
            total, description = self._progress_stack[-1]
            full_message = f"{description}: {message}" if description else message
            await self.report_progress(current, total, full_message)
    
    def end_nested_progress(self):
        """End the current nested progress operation."""
        if self._progress_stack:
            total, description = self._progress_stack.pop()
            asyncio.create_task(
                self.report_progress(total, total, f"{description} completed")
            )
    
    # Resource Access
    
    async def read_resource(self, uri: str) -> Any:
        """
        Read a resource by URI.
        
        Args:
            uri: Resource URI (e.g., "agent://my-agent/state")
            
        Returns:
            Resource content
            
        Raises:
            ResourceNotFoundError: If resource doesn't exist
            PermissionError: If access is denied
        """
        if not self._resource_provider:
            raise RuntimeError("No resource provider configured")
        
        await self.debug(f"Reading resource: {uri}")
        try:
            result = await self._resource_provider.read_resource(uri)
            await self.debug(f"Successfully read resource: {uri}")
            return result
        except Exception as e:
            await self.error(f"Failed to read resource {uri}: {str(e)}")
            raise
    
    # Authentication
    
    def get_auth_user(self) -> Optional[str]:
        """Get the current authenticated user."""
        if not self._auth_provider:
            return None
        return self._auth_provider.get_current_user()
    
    def get_auth_scopes(self) -> List[str]:
        """Get the current user's scopes."""
        if not self._auth_provider:
            return []
        return self._auth_provider.get_user_scopes()
    
    def has_scope(self, scope: str) -> bool:
        """Check if the current user has a specific scope."""
        return scope in self.get_auth_scopes()
    
    # Context Data
    
    def set_data(self, key: str, value: Any):
        """Store data in the context."""
        self._data[key] = value
    
    def get_data(self, key: str, default: Any = None) -> Any:
        """Retrieve data from the context."""
        return self._data.get(key, default)
    
    def update_data(self, data: dict):
        """Update context data with a dictionary."""
        self._data.update(data)
    
    # Utilities
    
    async def with_progress(
        self,
        operation: Callable,
        total: int,
        description: str = "Processing"
    ):
        """
        Execute an operation with automatic progress tracking.
        
        Args:
            operation: Async callable that accepts (current, context) args
            total: Total number of items
            description: Progress description
        """
        self.start_nested_progress(total, description)
        try:
            for i in range(total):
                await self.update_nested_progress(i, f"Item {i+1}/{total}")
                await operation(i, self)
        finally:
            self.end_nested_progress()
    
    def create_child_context(self, **overrides) -> "HAPContext":
        """Create a child context with optional overrides."""
        return HAPContext(
            request_id=overrides.get("request_id", f"{self.request_id}.child"),
            resource_provider=overrides.get("resource_provider", self._resource_provider),
            auth_provider=overrides.get("auth_provider", self._auth_provider),
            log_handler=overrides.get("log_handler", self._log_handler),
            progress_handler=overrides.get("progress_handler", self._progress_handler),
        )


class SimpleResourceProvider:
    """Simple in-memory resource provider for testing."""
    
    def __init__(self):
        self.resources: Dict[str, Any] = {}
    
    def add_resource(self, uri: str, content: Any):
        """Add a resource."""
        self.resources[uri] = content
    
    async def read_resource(self, uri: str) -> Any:
        """Read a resource."""
        if uri not in self.resources:
            raise KeyError(f"Resource not found: {uri}")
        return self.resources[uri]


class SimpleAuthProvider:
    """Simple auth provider for testing."""
    
    def __init__(self, user: Optional[str] = None, scopes: Optional[List[str]] = None):
        self.user = user
        self.scopes = scopes or []
    
    def get_current_user(self) -> Optional[str]:
        """Get current user."""
        return self.user
    
    def get_user_scopes(self) -> List[str]:
        """Get user scopes."""
        return self.scopes