# HAP (Haive Agent Protocol) Module

This module implements the Haive Agent Protocol - a JSON-RPC 2.0 based protocol for agent communication and orchestration.

## Overview

HAP is the protocol layer that enables:
- Agent discovery and registration
- Resource management
- Progress tracking
- Authentication and authorization
- Tool and prompt exposure

## Components

### Core Classes

- **HAPContext**: Execution context with logging, progress, and resource access
- **HAPServer**: JSON-RPC server for agent exposure
- **HAPClient**: Client for interacting with HAP servers
- **Resource Providers**: Pluggable resource access
- **Auth Providers**: Authentication and authorization

### Protocol Structure

HAP follows JSON-RPC 2.0 with extensions for:
- Progress notifications
- Streaming responses
- Resource URIs
- Authentication tokens

```python
# Example HAP request
{
    "jsonrpc": "2.0",
    "method": "agent/execute",
    "params": {
        "agent": "analyzer",
        "input": {"text": "..."}
    },
    "id": "req-123"
}
```

## Key Features

### Context Management

```python
from haive.hap.hap import HAPContext

context = HAPContext(request_id="req-123")
await context.info("Starting agent execution")
await context.report_progress(0, 100, "Initializing")
```

### Resource Access

```python
# Read resources through context
data = await context.read_resource("file://data.json")
config = await context.read_resource("config://agent/settings")
```

### Authentication

```python
from haive.hap.hap import SimpleAuthProvider

auth = SimpleAuthProvider(user="alice", scopes=["execute", "read"])
context = HAPContext(auth_provider=auth)

if context.has_scope("execute"):
    # Allowed to execute agents
    pass
```

## Integration with AGP

HAP provides the protocol layer for AGP:

```python
# Future implementation
server = HAPServer()

# Register HAP runtime
server.register_runtime(agp_runtime)

# Expose agents
server.expose_agent("analyzer", analyzer_agent)
server.expose_agent("writer", writer_agent)

# Start server
await server.start(port=8080)
```

## Protocol Methods

### Standard Methods

- `agent/list` - List available agents
- `agent/execute` - Execute an agent
- `agent/describe` - Get agent metadata
- `resource/read` - Read a resource
- `resource/list` - List available resources

### Notifications

- `progress` - Progress updates
- `log` - Log messages
- `state` - State changes

## Future Development

1. **Full Protocol Implementation**: Complete JSON-RPC server/client
2. **MCP Compatibility**: Bridge between HAP and MCP
3. **Discovery Service**: Agent discovery and registration
4. **Distributed Execution**: Multi-server agent orchestration