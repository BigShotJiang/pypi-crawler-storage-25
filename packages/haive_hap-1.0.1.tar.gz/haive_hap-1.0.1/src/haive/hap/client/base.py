from __future__ import annotations
from typing import Protocol, Mapping, Any
from ..models.context import HAPContext
from ..models.graph import AgentGraph

class HAPClientProtocol(Protocol):
    def run_agent(self, entrypoint: str, *, inputs: Mapping[str, Any] | None = None) -> HAPContext: ...
    def run_graph(self, graph: AgentGraph, *, inputs: Mapping[str, Any] | None = None) -> HAPContext: ...
