from __future__ import annotations
from typing import Mapping, Any
import json
import urllib.request
from ..models.context import HAPContext
from ..models.graph import AgentGraph

class HTTPClient:
    """Very small HTTP client for a future HAP server.

    Expects a server that exposes /run-agent and /run-graph endpoints.

    This is a placeholder you can wire to your FastAPI app later.
    """
    def __init__(self, base_url: str, *, timeout: float = 30.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _post_json(self, path: str, payload: dict) -> dict:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(self.base_url + path, data=data, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def run_agent(self, entrypoint: str, *, inputs: Mapping[str, Any] | None = None) -> HAPContext:
        res = self._post_json("/run-agent", {"entrypoint": entrypoint, "inputs": dict(inputs or {})})
        return HAPContext.model_validate(res)

    def run_graph(self, graph: AgentGraph, *, inputs: Mapping[str, Any] | None = None) -> HAPContext:
        res = self._post_json("/run-graph", {"graph": graph.model_dump(), "inputs": dict(inputs or {})})
        return HAPContext.model_validate(res)
