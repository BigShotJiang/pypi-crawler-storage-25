from __future__ import annotations
from typing import Mapping, Any
from ..models.context import HAPContext
from ..models.graph import AgentGraph
from ..server.runtime import HAPRuntime
import importlib
from haive.agents.base.agent import Agent

class LocalClient:
    """Runs agents/graphs in-process using the local runtime."""

    def run_agent(self, entrypoint: str, *, inputs: Mapping[str, Any] | None = None) -> HAPContext:
        ctx = HAPContext(inputs=dict(inputs or {}))
        # Build a trivial one-node graph for the single agent
        from ..models.graph import AgentGraph, AgentNode
        g = AgentGraph(nodes={"__single__": AgentNode(id="__single__", agent=entrypoint)}, entry="__single__")
        return HAPRuntime(g).run(ctx)

    def run_graph(self, graph: AgentGraph, *, inputs: Mapping[str, Any] | None = None) -> HAPContext:
        ctx = HAPContext(inputs=dict(inputs or {}))
        return HAPRuntime(graph).run(ctx)
