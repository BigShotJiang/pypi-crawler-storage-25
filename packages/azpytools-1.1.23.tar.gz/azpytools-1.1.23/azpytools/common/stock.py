import tushare as ts
import pandas as pd
import akshare as ak
import re
from .spider import clsSpider
from datetime import datetime
import dataclasses
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__ + '.stock')
# logger.setLevel(logging.INFO)



@dataclasses.dataclass(frozen=True)
class ETFQT:
    sz50: str =  '510050'     #上证50ETF华夏
    hs300sh: str =  '510300'     #沪深300ETF华泰柏瑞
    hs300sz: str =  '159919'     #沪深300ETF嘉实
    zz500sh: str =  '510500'     #中证500ETF
    zz500sz: str =  '159922'     #中证500ETF嘉实
    cyb: str =  '159915'     #创业板ETF易方达
    kcb50: str =  '588080'     #科创50ETF易方达F
    sz100: str =  '159901'     #深证100ETF易方达   
    kc50: str =  '588000'     #科创50ETF华夏

@dataclasses.dataclass(frozen=True)
class ETFQT_TS:
    sz50: str =  '510050.SH'     #上证50ETF华夏
    hs300sh: str =  '510300.SH'     #沪深300ETF华泰柏瑞
    hs300sz: str =  '159919.SZ'     #沪深300ETF嘉实
    zz500sh: str =  '510500.SH'     #中证500ETF
    zz500sz: str =  '159922.SZ'     #中证500ETF嘉实
    cyb: str =  '159915.SZ'     #创业板ETF易方达
    kcb50: str =  '588080.SH'     #科创50ETF易方达F
    sz100: str =  '159901.SZ'     #深证100ETF易方达   
    kc50: str =  'SH588000'     #科创50ETF华夏

@dataclasses.dataclass(frozen=True)
class ETFQT_EM:
    sz50: str =  'SH510050'     #上证50ETF华夏
    hs300sh: str =  'SH510300'     #沪深300ETF华泰柏瑞
    hs300sz: str =  'SZ159919'     #沪深300ETF嘉实
    zz500sh: str =  'SH510500'     #中证500ETF
    zz500sz: str =  'SZ159922'     #中证500ETF嘉实
    cyb: str =  'SZ159915'     #创业板ETF易方达
    kcb50: str =  'SH588080'     #科创50ETF易方达F
    sz100: str =  'SZ159901'     #深证100ETF易方达   
    kc50: str =  'SH588000'     #科创50ETF华夏


class stockAPI:
    def __init__(self):
        pass
    @staticmethod
    def get_hot_by_type(hot_type = 'top',date =''):
        """
        下载热门数据
        hot_type: top 个股涨幅榜
                  bot 个股跌幅榜
                  strong 强势股涨榜
                  hotem 东方财富热门榜
                  hotxq 雪球热门榜
                  hotbd 百度热门榜
                  bktop 板块-涨幅榜
                  bkbot 板块-跌幅榜
                  intop 行业-涨幅榜
                  inbot 行业-跌幅榜
        板块代码是财联社的，如果获取板块股票列表，需要先获取板块代码，再调用get_bk_stock_list方法
        """
        if hot_type == 'top':
            data = stockAPI.get_up_limit_list(date)
        elif hot_type == 'bot':
            data = stockAPI.get_down_limit_list(date)
        elif hot_type == 'strong':
            data = stockAPI.get_strong_list(date)
        elif hot_type == 'hotem':
            api_ak = stockAPIAkShare()
            data = api_ak.get_hot_rank_em()
        elif hot_type == 'hotxq':
            api_ak = stockAPIAkShare()
            data = api_ak.get_hot_xueqiu_rank_tweet()
        elif hot_type == 'hotbd':
            api_ak = stockAPIAkShare()
            data = api_ak.get_hot_search_baidu(date)
        elif hot_type == 'bktop':
            data = stockAPI.get_bk_top(type = 'concept',up = True)
        elif hot_type == 'bkbot':
            data = stockAPI.get_bk_top(type = 'concept',up = False)
        elif hot_type == 'intop':
            data = stockAPI.get_bk_top(type = 'industry',up = True)
        elif hot_type == 'inbot':
            data = stockAPI.get_bk_top(type = 'industry',up = False)
        else:
            data = pd.DataFrame()
        if len(data) > 0 and not ('date' in data.columns):
                data['date'] = datetime.now().strftime('%Y%m%d')
        return data 
    
    @staticmethod
    def get_bk_top(type = 'concept',up:bool = True):
        """_获取板块涨跌幅榜列表
        up: 是否获取涨幅榜块（默认True），False表示获取跌幅榜
         type - "industry": 行业板块（默认）
                - "concept": 概念板块
        """
        cls = clsSpider()
        df = cls.get_bk_list(type,up)   
        return df
    
    @staticmethod
    def get_bk_stock_list(clsbk_code:str):
        """_获取板块股票列表
        clsbk_code - 板块代码，例如："cls81377"
        """
        cls = clsSpider()
        df = cls.get_bk_stock_list(clsbk_code)
        return df

    @staticmethod
    def get_up_limit_list(date=''):
        """_获取涨停股票列表
        date - 日期，格式为YYYYMMDD，默认当前日期
        """
        if date == '':
            tdate = datetime.now().strftime('%Y%m%d')
        else:
            tdate = date
        try:
            df = ak.stock_zt_pool_em(date=tdate)
            # 代码    名称        涨跌幅     首次封板时间  最 后封板时间  炸板次数  涨停统计 连板数  所属行业
            df = df[['代码','名称','涨跌幅','首次封板时间','最后封板时间','炸板次数','涨停统计','连板数','所属行业']]
            df.rename(columns={'代码':'ts_code',
                          '名称':'name',
                          '涨跌幅':'change_pct',
                          '首次封板时间':'first_limit_time',
                        #   '最后封板时间':'last_limit_time',
                          '炸板次数':'limit_count',
                          '涨停统计':'change_amt',
                          '连板数':'continue_count',
                          '所属行业':'industry'},
                          inplace=True)
            df['code'] = df['ts_code'].apply(lambda x: x + '.SZ' if str(x).startswith(('3', '0')) else (x + '.SH' if str(x).startswith('6') else x))
        except Exception as e:
            logger.error(str(e))
            df = None
        if df is None:
            cls = clsSpider()
            df = cls.get_up_pool()['stocks']
            df.rename(columns={'secu_code':'ts_code',
                          'secu_name':'name',
                          'change':'change_pct',
                          'last_px':'last_price',
                          'time':'first_limit_time',
                          'up_reason':'up_reason',
                          'num_stocks':'num_stocks'},
                          inplace=True)
        df = df[['code','ts_code','name','change_pct']]
        df['date'] = tdate
        return df

    @staticmethod    
    def get_down_limit_list(date=''):
        """_获取跌停股票列表
        """
        if date == '':
            tdate = datetime.now().strftime('%Y%m%d')
        else:
            tdate = date
        try:
            df = ak.stock_zt_pool_dtgc_em(date=tdate)
            #  代码     名称         涨跌幅
            df = df[['代码','名称','涨跌幅']]
            df.rename(columns={'代码':'ts_code',
                          '名称':'name',
                          '涨跌幅':'change_pct'},
                          inplace=True)
            df['code'] = df['ts_code'].apply(lambda x: x + '.SZ' if str(x).startswith(('3', '0')) else (x + '.SH' if str(x).startswith('6') else x))
        except Exception as e:
            logger.error(str(e))
            df = None
        if df is None:
            cls = clsSpider()
            df = cls.get_down_pool()['stocks']
            df.rename(columns={'secu_code':'ts_code',
                          'secu_name':'name',
                          'change':'change_pct',
                          'last_px':'last_price',
                          'time':'first_limit_time',
                          'up_reason':'up_reason',
                          'num_stocks':'num_stocks'},
                          inplace=True)    
        if df.empty:
            return df
        df['date'] = tdate
        return df
        
    @staticmethod    
    def get_up_limit_continue_list(date=''):
        """_获取涨停连板股票列表
        """
        if date == '':
            tdate = datetime.now().strftime('%Y%m%d')
        else:
            tdate = date
        cls = clsSpider()
        df = cls.get_continuous_up_pool()['stocks']
        df.rename(columns={'secu_code':'ts_code',
                          'secu_name':'name',
                          'change':'change_pct',
                          'last_px':'last_price',
                          'time':'first_limit_time',
                          'up_reason':'up_reason',
                          'num_stocks':'num_stocks'},
                          inplace=True)    
        if df.empty:
            return df
        df['date'] = tdate
        return df

    @staticmethod    
    def get_up_limit_open(date=''):
        """_获取涨停开板股票列表
        """
        if date == '':
            tdate = datetime.now().strftime('%Y%m%d')
        else:
            tdate = date
        try:
            df = ak.stock_zt_pool_zbgc_em(date=tdate)
            df = df[['代码','名称','涨跌幅']]
            df.rename(columns={'代码':'ts_code',
                          '名称':'name',
                          '涨跌幅':'change_pct'},
                          inplace=True)
            df['code'] = stockAPI.transform_stock_code_suffix(df['ts_code'])
            # df['ts_code'].apply(lambda x: x + '.SZ' if str(x).startswith(('3', '0')) else (x + '.SH' if str(x).startswith('6') else x))
        except Exception as e:
            logger.error(str(e))
            df = None
        if df is None:    
            cls = clsSpider()
            df = cls.get_up_open_pool()['stocks']
            df.rename(columns={'secu_code':'ts_code',
                          'secu_name':'name',
                          'change':'change_pct',
                          'last_px':'last_price',
                          'time':'first_limit_time',
                          'up_reason':'up_reason',
                          'num_stocks':'num_stocks'},
                          inplace=True)    
        if df.empty:
            return df
        df['date'] = tdate
        return df
    
    @staticmethod    
    def get_strong_list(date=''):
        """_获取强势股列表
        """
        if date == '':
            tdate = datetime.now().strftime('%Y%m%d')
        else:
            tdate = date
        try:
            df = ak.stock_zt_pool_strong_em(date=tdate)
            # 代码    名称        涨跌幅      涨停统计    入选理由  所属行业
            df = df[['代码','名称','涨跌幅','涨停统计','入选理由','所属行业']]
            df.rename(columns={'代码':'ts_code',
                          '名称':'name',
                          '涨跌幅':'change_pct',
                          '涨停统计':'change_amt',
                          '入选理由':'reason_reason',
                          '所属行业':'industry'},
                          inplace=True)
            df['code']  = stockAPI.transform_stock_code_suffix(df['ts_code'])
            # df['ts_code'].apply(lambda x: x + '.SZ' if str(x).startswith(('3', '0')) else (x + '.SH' if str(x).startswith('6') else x))
        except Exception as e:
            logger.error(str(e))
            df = pd.DataFrame()
        if df.empty:
            return df
        df['date'] = tdate
        return df

    @staticmethod
    def transform_stock_code(series: pd.Series) -> pd.Series:
        """
        批量转换股票代码格式：
        sz000001 -> 000001.SZ
        sh600000 -> 600000.SH
        其他格式保持不变
        """
        s = series.astype(str)
        
        # 1. 判断是否以 sz 或 sh 开头（忽略大小写）
        # 使用切片比对，速度极快
        prefix = s.str[:2].str.lower()
        mask = prefix.isin(['sz', 'sh','bj','hk'])
        
        # 2. 构建结果容器（先复制原数据，处理不匹配的情况）
        result = s.copy()
        
        # 3. 仅对符合条件的数据进行拼接
        # 代码部分 = [2:]，后缀部分 = [:2] 转 大写
        result[mask] = s[mask].str[2:] + '.' + prefix[mask].str.upper()
        
        return result
    
    @staticmethod
    def transform_stock_code_suffix(series: pd.Series) -> pd.Series:
        """
        为股票代码添加交易所后缀：
        - 以 '3' 或 '0' 开头 → 加 '.SZ' (深市)
        - 以 '6' 开头       → 加 '.SH' (沪市)
        - 其他情况保持不变
        - 缺失值 (NaN) 保持不变

        参数:
            series: 包含股票代码的 pandas Series

        返回:
            处理后的 pandas Series
        """
        s = series.astype(str)
        
        # 复制以避免修改原始数据
        result = series.copy()
        
        # 筛选非空值进行处理
        notna_mask = series.notna()
        if not notna_mask.any():
            return result  # 全为空值时直接返回
        
        # 对非空值应用转换（向量化）
        codes = series[notna_mask].astype(str)
        
        cond_sz = codes.str.startswith(('3', '0'))
        cond_sh = codes.str.startswith('6')
        cond_bj = codes.str.startswith('9')
        
        # 使用布尔索引赋值，比 np.select 更直观且保留原索引
        modified_codes = codes.copy()
        modified_codes[cond_sz] = codes[cond_sz] + '.SZ'
        modified_codes[cond_sh] = codes[cond_sh] + '.SH'
        modified_codes[cond_bj] = codes[cond_bj] + '.BJ'
        
        # 将处理结果写回
        result[notna_mask] = modified_codes
        
        return result
 
class stockAPIAkShare:
    COLUMN_MAP= {'日期':'date', 
                 '股票代码':'code', 
                 '名称':'name', 
                 '板块名称':'name', 
                 '板块代码':'code', 
                #  '最新价':'close', 
                 '代码':'code', 
                  '开盘':'open', 
                  '收盘':'close',
                  '最新价':'close',
                  '市盈率-动态':'pe', 
                  '市净率':'pb', 
                  '最高':'high', 
                  '最低':'low', 
                  '成交量':'volume', 
                  '成交额':'amount', 
                  '振幅':'amplitude', 
                  '涨跌幅':'change_pct', 
                  '涨跌额':'change_amt', 
                  '换手率':'turnover_rate',
                  '总市值':'total_share',
                  '流通市值':'float_share',}
    
    def __init__(self):
        pass
    
    def get_hot_search_baidu(self,date):
        """百度热搜
        返回：名称/代码     涨跌幅    综合热度
        名称/代码      涨跌幅    综合热度
        海航控股   +4.86%  428391
        """
        try:
            return ak.stock_hot_search_baidu(date = date)
        except Exception as e:
            logger.error(str(e))
            return pd.DataFrame()
    
    def get_hot_xueqiu_rank_tweet(self):
        """雪球讨论排行帮 
        股票代码	股票简称	关注	最新价       
        """
        try:
            data = ak.stock_hot_tweet_xq()
        except Exception as e:
            logger.error(str(e))
            return pd.DataFrame()
        data.rename(columns = {'股票代码':'ts_code','股票简称':'name','关注':'hot','最新价':'close'}, inplace=True)
        data['code'] =  stockAPI.transform_stock_code(data['ts_code'])
        return data
    
    def get_hot_xueqiu_follow(self):
        """雪球关注排行

        Returns:
            _type_: _description_
        """
        try:
            return ak.stock_hot_follow_xq()
        except Exception as e:
            logger.error(str(e))
            return pd.DataFrame()
    
    def get_hot_rank_up(self):
        """东方财富飙升榜-A股
        """
        try:
            return ak.stock_hot_up_em()
        except Exception as e:
            logger.error(str(e))
            return pd.DataFrame()
    
    def get_hot_rank_em(self):
        """股票热度-东财
        当前排名	代码	股票名称	最新价	涨跌额	涨跌幅
        """
        columnsmap = {'当前排名':'rank',
                      '代码':'ts_code',
                      '股票名称':'name',
                      '最新价':'close',
                      '涨跌额':'change_amt',
                      '涨跌幅':'change_pct'}
                      
        try:
            data = ak.stock_hot_rank_em()
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()
        data.rename(columns = columnsmap, inplace=True)
        data['code'] =  stockAPI.transform_stock_code_suffix(data['ts_code'])
        data['ts_code'] =  stockAPI.transform_stock_code(data['ts_code'])   
        return data     
    
    def get_hot_rank_em_last_code(self,symbol):
        """东方财富个股人气榜-最新排名
        """
        try:
            return ak.stock_hot_rank_latest_em(symbol)
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()
    
    def get_hot_rank_em_hist_code(self,symbol):
        """东方财富

        Args:
            symbol (_type_): _description_
        """
        try:
            return ak.stock_hot_rank_detail_em(symbol)
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()
    
    def get_limit_up_em(self,date: str = "20241231"):
        """涨停股池"""
        try:
            return ak.stock_zt_pool_em(date=date)
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()
    
    def get_limit_down_em(self,date: str = "20241231"):
        """跌停股池"""
        try:
            return ak.stock_zt_pool_dtgc_em(date=date)
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()
    
    def get_limint_up_open_em(self,date: str = "20241231"):
        """炸板股池"""
        try:
            return ak.stock_zt_pool_zbgc_em(date=date)
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()
    
    def get_strong_pool_em(self,date: str = "20241231"):
        """强势股池 """
        try:
            return ak.stock_zt_pool_strong_em(date=date)
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()
    
    
    def get_etf_list(self):
        try:
            fund_etf_list = ak.fund_etf_category_sina(symbol="ETF基金")
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()   
        fund_etf_list = fund_etf_list[['代码','名称','成交额','成交量']]
        fund_etf_list.rename(columns={'代码':'code','名称':'name','成交额':'amount','成交量':'volume'}, inplace=True)
        # 转换代码格式：sz59998 -> 159998.SZ
        fund_etf_list['code'] = fund_etf_list['code'].apply(lambda x: x[2:] + '.' + x[:2].upper() if x.startswith(('sh', 'sz')) else x)
        return fund_etf_list
    
    # 板块
    def get_board_list(self):
        """_获取板块概念列表
        排名	int64	-
        板块名称	object	-
        板块代码	object	-
        最新价	float64	-
        涨跌额	float64	-
        涨跌幅	float64	注意单位：%
        总市值	int64	-
        换手率	float64	注意单位：%
        上涨家数	int64	-
        下跌家数	int64	-
        领涨股票	object	-
        领涨股票-涨跌幅	float64	注意单位：%
        """
        try:
            stock_board_concept = ak.stock_board_concept_name_em()
            stock_board_industry = ak.stock_board_industry_name_em()
        except Exception as e:
            logger.error(str(e))    
            return pd.DataFrame()       
        retdata = pd.concat([stock_board_concept, stock_board_industry], axis=0)
        retdata.rename(columns=self.COLUMN_MAP, inplace=True)
        return retdata  
    
    def get_board_pe_ratio(self,board_name,date ):
        """_行业市盈率
        变动日期          行业分类  行业层级  ... 静态市盈率-加权平均 静态市盈率-中位数  静态市盈率-算术平均
        """
        try:
            return  ak.stock_industry_pe_ratio_cninfo(symbol= board_name, date=date)
        except Exception as e:
            logger.error(str(e))        
            return pd.DataFrame()
    
    def get_board_contain_stock(self,board_name):
        """_获取板块成分股列表
        名称	类型	描述
        序号	int64	-
        代码	object	-
        名称	object	-
        最新价	float64	-
        涨跌幅	float64	注意单位: %
        涨跌额	float64	-
        成交量	float64	注意单位: 手
        成交额	float64	-
        振幅	float64	注意单位: %
        最高	float64	-
        最低	float64	-
        今开	float64	-
        昨收	float64	-
        换手率	float64	注意单位: %
        市盈率-动态	float64	-
        市净率	float64	-
      """
    # 板块成分
        try:
            stock_board_concept  = ak.stock_board_concept_cons_em(symbol=board_name)
        except Exception as e:
            logger.error(str(e))        
            return pd.DataFrame()
        if stock_board_concept is None:
            # return stock_board_concept
            try:
                stock_board_concept  = ak.stock_board_industry_cons_em(symbol=board_name)
            except Exception as e:
                logger.error(str(e))        
                return pd.DataFrame()
        stock_board_concept.rename(columns=self.COLUMN_MAP, inplace=True)
        return stock_board_concept
        # return stock_board_industry
    
    def get_ticket(self,ts_code):
    # 盘口
        try:
            stock_bid = ak.stock_bid_ask_em(symbol=ts_code)
        except Exception as e:
            logger.error(str(e))        
            return pd.DataFrame()
        return stock_bid
    
    def get_minute_history(self,ts_code,start_date,end_date,period='1'):
        # 分时数据
        # period='1'; 获取 1, 5, 15, 30, 60 分钟的数据频率
        # "2024-03-20 09:30:00"
        try:
            stock_zh_a_hist_min = ak.stock_zh_a_hist_min_em(symbol=ts_code, start_date=start_date, end_date=end_date, period="1", adjust="qfq")
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
        return stock_zh_a_hist_min

    # 分时数据-新浪
    # period='1'; 获取 1, 5, 15, 30, 60 分钟的数据频率
    # stock_zh_a_minute_df = ak.stock_zh_a_minute(symbol='sh600751', period='1', adjust="qfq")
    # 分时数据-东财
    # 注意：该接口返回的数据只有最近一个交易日的有开盘价，其他日期开盘价为 0
    def get_minute(self,ts_code,period='1'):
    # 日内分时数据-东财
        try:
            stock_intraday = ak.stock_intraday_em(symbol=ts_code)
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
        return stock_intraday
    
    def get_today_list(self):
        try:
            stock_zh_a_spot_em_df = ak.stock_zh_a_spot_em()
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
        stock_zh_a_spot_em_df.rename(columns=self.COLUMN_MAP, inplace=True)
        return stock_zh_a_spot_em_df
    
    def get_daily_by_code_list(self,ts_codes,start_date='', end_date=''):
        """根据股票代码清单，获取日线数据

        Args:
            ts_codes (_type_): 多个股票代码，逗号分开，如：'600004,600005'
            start_date (str, optional): 开始日期，如：'20200101'
            end_date (str, optional): 结束日期，如：'20200102' .

        Returns:
            _type_: _description_
        """
        retdata =None
        #根据回车或换行符切割
        codelist = re.split(',|;',ts_codes)
        for code in codelist:
            if code.strip():
                data = self.get_daily_by_code(code.strip(),start_date, end_date)
                if data is not None:
                    if retdata is None:
                        retdata = data
                    else:
                        retdata =pd.concat([retdata,data],axis=0)
        return retdata
 
        
    def get_daily_by_code(self,ts_code,start_date='', end_date=''):
        """根据单个股票代码，获取日线数据

        Args:
            ts_codes (_type_): 股票代码 ，如：'600004'
            start_date (str, optional): 开始日期，如：'20200101'
            end_date (str, optional): 结束日期，如：'20200102' .
"""
        columns = { '日期':'date',
                    '股票代码':'code',
                    '开盘':'open',
                    '收盘':'close',
                    '最高':'high',
                    '最低':'low',
                    '成交量':'volume',
                    '成交额':'amount',
                    # '振幅':'pct_chg',
                    # '涨跌幅',
                    # '涨跌额',
                    # '换手率'
                    }
        # period='daily'; choice of {'daily', 'weekly', 'monthly'}\
        try:
            stock_zh_a_hist_df = ak.stock_zh_a_hist(symbol=ts_code, period="daily", start_date=start_date, end_date=end_date, adjust="qfq")
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
        stock_zh_a_hist_df.rename(columns=self.COLUMN_MAP, inplace=True)
        return stock_zh_a_hist_df

    def get_code_list(self):
        """_获取股票列表

        Returns:
            code	object	-
         name	object
        """
        try:
            stock_info = ak.stock_info_a_code_name()
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
        return stock_info
    
    def get_basic_data(self,tscode):
        """_获取股票基本信息
        Returns:
            code	object	-
         name	object
        """
        try:
            stock_a_indicator = ak.stock_a_indicator_lg(symbol=tscode)
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
        # stock_a_indicator = ak.stock_value_em(symbol=tscode)
        return stock_a_indicator
    
    
    def get_basic_gdhs_by_date(self,date):
        """股东户数，按日期"""
        try:
            stock_zh_a_gdhs_df = ak.stock_zh_a_gdhs(symbol=date) #每个季度末最后一天
            return stock_zh_a_gdhs_df
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
        
        
        
    def get_basic_gdhs_by_code(self,tscode):
        """股东户数，按股票代码,包含历史数据"""
        try:
            stock_zh_a_gdhs_detail_em_df = ak.stock_zh_a_gdhs_detail_em(symbol=tscode)
        except Exception as e:
            logger.error(str(e))                
            return pd.DataFrame()
        return stock_zh_a_gdhs_detail_em_df
    
    def get_basic_holders_top10_free_by_date(self,date):

        #     名称	类型	描述
        # 序号	int64	-
        # 股东名称	object	-
        # 股东类型	object	-
        # 股票代码	object	-
        # 股票简称	object	-
        # 报告期	object	-
        # 期末持股-数量	float64	注意单位: 股
        # 期末持股-数量变化	float64	注意单位: 股
        # 期末持股-数量变化比例	float64	注意单位: %
        # 期末持股-持股变动	float64	-
        # 期末持股-流通市值	float64	注意单位: 元
        # 公告日	object	-   
        """股东持股分析-十大股东"""
        try:
                    # 股东持股明细-十大流通股东
        #  stock_gdfx_free_holding_detail_em 
        #     股东持股分析-十大流通股东
        # 接口: stock_gdfx_free_holding_analyse_em
            stock_gdfx_holding_analyse_em_df = ak.stock_gdfx_free_holding_analyse_em(date=date)
            return stock_gdfx_holding_analyse_em_df
        except Exception as e:
            logger.error(str(e))                
            return pd.DataFrame()

    def get_basic_holders_top10_by_date(self,date):
        """股东持股分析-十大股东"""
        try:
            # 接口: stock_gdfx_holding_detail_em
            stock_gdfx_holding_analyse_em_df = ak.stock_gdfx_holding_analyse_em(date=date)
            return stock_gdfx_holding_analyse_em_df
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
    
    def get_basic_holders_top10_by_code(self,tscodde,date):
        """十大股东(个股)"""
        try:
            stock_gdfx_top_10_em_df = ak.stock_gdfx_top_10_em(symbol=tscodde, date=date)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        return stock_gdfx_top_10_em_df
    
      
    # 财务指标
#     stock_financial_analysis_indicator_df = ak.stock_financial_analysis_indicator(symbol="600004", start_year="2020")
    def get_basic_institute_hold_list(self,quarter):
        """_获取机构持股列表
        Args:
            quarter (str): 季度如：20201 年+季度
        Returns:
        证券代码  证券简称 机构数  机构数变化   持股比例  持股比例增幅  占流通股比例  占流通股比例增幅
            _type_: _description_dataframe
        """
        try:
            stock_institute_hold_df = ak.stock_institute_hold(symbol=quarter)
        except Exception as e:
            logger.error(str(e))            
            return pd.DataFrame()
        return stock_institute_hold_df
    def get_basic_institute_hold_detail_by_stock(self,stock,quarter):
        """_获取机构持股详情
        Args:
            stock (str): 股票代码如：300033
            quarter (str): 季度如：20201 年+季度
        Returns:
        持股机构类型  持股机构代码      持股机构简称  ... 最新占流通股比例  持股比例增幅  占流通股比例增幅
            _type_: _description_dataframe
        """
        try:
            stock_institute_hold_detail_df = ak.stock_institute_hold_detail(stock=stock, quarter=quarter)
        except Exception as e:
            logger.error(str(e))                
            return pd.DataFrame()
        return stock_institute_hold_detail_df
    

    def get_daily_list(self,start_date='', end_date=''):
        """_获取日期列表
        Args:
        """
        retdata =None
        #根据回车或换行符切割
        codelist=self.get_code_list()
        for code in codelist:
            if code.get('code'):
                data = self.get_daily_by_code(code.get('code'),start_date, end_date)
                if data is not None:
                    if retdata is None:
                        retdata = data
                    else:
                        retdata =pd.concat([retdata,data],axis=0)
        return retdata
    
    def get_index_daily_by_code(self,tscode,start_date='', end_date='' ,period='daily'):
        '''
            历史行情数据-通用
            输入参数
        名称	类型	描述
        symbol	str	symbol="399282"; 指数代码，此处不用市场标识
        period	str	period="daily"; choice of {'daily', 'weekly', 'monthly'}
        start_date	str	start_date="19700101"; 开始日期
        end_date	str	end_date="22220101"; 结束时间
        '''
        try:
            index_zh_a_hist_df = ak.index_zh_a_hist(symbol=tscode, period=period, start_date=start_date, end_date=end_date)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        return index_zh_a_hist_df.rename(columns=self.COLUMN_MAP, inplace=True)
        # return index_zh_a_hist_df 
    
    def get_index_list(self,symbol='沪深重要指数'):  
        '''
        symbol="上证系列指数"；choice of {"沪深重要指数", "上证系列指数", "深证系列指数", "指数成份", "中证系列指数"}
        '''
        try:
            stock_zh_index_spot_em_df = ak.stock_zh_index_spot_em(symbol=symbol)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        return stock_zh_index_spot_em_df

    def get_index_minute_by_code(self,tscode,start_date='', end_date='' ,period='1'):
        '''
        历史分钟数据-通用
        # 名称	类型	描述
        # symbol	str	symbol="399006"; 指数代码，此处不用市场标识
        # period	str	period="1"; choice of {'1', '5', '15', '30', '60'}, 其中 1 分钟数据只能返回当前的, 其余只能返回近期的数据
        # start_date	str	start_date="1979-09-01 09:32:00"; 开始日期时间
        # end_date	str	end_date="2222-01-01 09:32:00"; 结束时间时间
        '''
        try:
            index_zh_a_hist_min_em_df = ak.index_zh_a_hist_min_em(symbol=tscode, period=period, start_date=start_date, end_date=end_date)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        return index_zh_a_hist_min_em_df 
                
        
class stockAPITuShare:
    COLUMN_MAP= {'trade_date':'date', 
                 'ts_code':'code', 
                 'con_code':'code', 
                 '名称':'name', 
                 '板块名称':'name', 
                 '板块代码':'code', 
                #  '最新价':'close', 
                 '代码':'code', 
                  '开盘':'open', 
                  '收盘':'close',
                  '最新价':'close',
                  '市盈率-动态':'pe', 
                  '市净率':'pb', 
                  '最高':'high', 
                  '最低':'low', 
                  'vol':'volume', 
                  '成交额':'amount', 
                  '振幅':'amplitude', 
                  'pct_chg':'change_pct', 
                  'change':'change_amt', 
                  '换手率':'turnover_rate',
                  'open_qfq':'open',
                  'high_qfq':'high',
                  'low_qfq':'low',
                  'close_qfq':'close',
                    }
    
    
    def __init__(self,apitoken):
        self.API = ts.pro_api(apitoken)
        
    def get_trade_date(self,exchange = 'SSE', start_date='', end_date=''):
        """_summary_

        Args:
            exchange	str	Y	交易所 SSE上交所 SZSE深交所
            cal_date	str	Y	日历日期
            is_open	str	Y	是否交易 0休市 1交易
            pretrade_date	str	Y	上一个交易日
        """
        df = self.API.trade_cal(exchange='SSE', start_date=start_date, end_date=end_date)
        return df
        
        
    def get_kdata(self,ts_code,start_date='', end_date='',freq = 'D'):
        """获取股票K线数据
        Args:
            ts_code (_type_): 股票代码如：300033.SZ '688362.SH,600203.SH,300223.SZ,300346.SZ'
            start_date (str, optional): 开始日期：'20200102'.
            end_date (str, optional):  开始日期：'20200202'.
            freq：频率：D=日线 W=周 M=月
        Returns:
            _type_  : _description_dataframe:
            code ：代码
            date  ：交易日期 
            open   ：开盘价
            high   ：最高价 
            low    ：最低价 
            close  ：收盘价 
            pre_close ：昨收价【除权价，前复权】
            previous_close ：前收价
            change  ：涨跌额 
            pct_chg ：涨跌幅 
            volume: 成交量 
            amount ：成交额 
        """
        if freq == 'D':
            # df =  self.API.daily(ts_code=ts_code , start_date=start_date, end_date=end_date)
            try:
                df =  self.API.query('daily', ts_code=ts_code,start_date=start_date, end_date=end_date)
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        elif freq == 'W':
            # df = self.API.weekly(ts_code=ts_code, start_date=start_date, end_date=end_date)
            try:
                df =  self.API.query('weekly', ts_code=ts_code,start_date=start_date, end_date=end_date)
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        elif freq == 'M':
            # 获取月线行情
            # df=pro.stk_week_month_adj(ts_code='000001.SZ',freq='week')
            try:
                df = self.API.monthly(ts_code=ts_code, start_date=start_date, end_date=end_date) #, fields='ts_code,trade_date,open,high,low,close,vol,amount')
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()   
        else:
            return pd.DataFrame()
          
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        df['amount'] = df['amount'] * 1000
        return df
    
    def get_kdata_index(self,ts_code,start_date='', end_date='',freq = 'D'):
        """获取指数K线数据
        Args:
            ts_code (_type_): 股票代码如：300033.SZ '688362.SH,600203.SH,300223.SZ,300346.SZ'
            start_date (str, optional): 开始日期：'20200102'.
            end_date (str, optional):  开始日期：'20200202'.
            freq：频率：D=日线 W=周 M=月
        Returns:
            _type_  : _description_dataframe:
            code ：代码
            date  ：交易日期 
            open   ：开盘价
            high   ：最高价 
            low    ：最低价 
            close  ：收盘价 
            pre_close ：昨收价【除权价，前复权】
            previous_close ：前收价
            change  ：涨跌额 
            pct_chg ：涨跌幅 
            volume: 成交量 
            amount ：成交额 
        """
        if freq == 'D':
            try:
                df =  self.API.index_daily(ts_code=ts_code , start_date=start_date, end_date=end_date)
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        elif freq == 'W':
            try:
                df = self.API.index_weekly(ts_code=ts_code, start_date=start_date, end_date=end_date)
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        elif freq == 'M':
            # 获取月线行情
            try:
                df = self.API.index_monthly(ts_code=ts_code, start_date=start_date, end_date=end_date) #, fields='ts_code,trade_date,open,high,low,close,vol,amount')
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()   
        else:
            return pd.DataFrame()  
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        df['amount'] = df['amount'] * 1000
        return df
   
    def get_kdata_etf(self,ts_code,start_date='', end_date='',freq = 'D'):
        '''
        获取ETFK线数据
        Args:
            ts_code (_type_): 股票代码如：300033.SZ '688362.SH,600203.SH,300223.SZ,300346.SZ'
            start_date (str, optional): 开始日期：'20200102'.
            end_date (str, optional):  开始日期：'20200202'.
            freq：频率：D=日线 W=周 M=月
        Returns:
            _type_  : _description_dataframe:
            code ：代码
            date  ：交易日期 
            open   ：开盘价
            high   ：最高价 
            low    ：最低价 
            close  ：收盘价 
            pre_close ：昨收价【除权价，前复权】
            previous_close ：前收价
            change  ：涨跌额 
            pct_chg ：涨跌幅 
            volume: 成交量 
            amount ：成交额 
        '''
            # # adj
        # df = pro.fund_adj(ts_code='513100.SH', start_date='20190101', end_date='20190926')
    
        if freq == 'D':
            try:
                df =  self.API.fund_daily(ts_code=ts_code , start_date=start_date, end_date=end_date)
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        # elif freq == 'W':
        #     df = self.API.fund_weekly(ts_code=ts_code, start_date=start_date, end_date=end_date)
        # elif freq == 'M':
        #     # 获取月线行情
        #     df = self.API.fund_monthly(ts_code=ts_code, start_date=start_date, end_date=end_date) #, fields='ts_code,trade_date,open,high,low,close,vol,amount')
        else:
            return pd.DataFrame()  
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        df['amount'] = df['amount'] * 1000
        return df
    
   
    def get_basic(self):
        """_获取股票列表
        Returns:
            _type_: _description_dataframe
        """
        try:
            df = self.API.query('stock_basic', exchange='', list_status='L', fields='ts_code,symbol,name,area,industry,list_date')
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        return df
    
    def get_basic_etf(self):            
        # #获取当前所有上市的ETF列表
        try:
            df = self.API.etf_basic(list_status='L', fields='ts_code,extname,index_code,index_name,exchange,mgr_name')
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        return df
    
    def get_basic_index(self,market='SSE'):
        """获取指定市场指数列表 
            MSCI	MSCI指数
            CSI	中证指数
            SSE	上交所指数
            SZSE	深交所指数
            CICC	中金指数
            SW	申万指数
            OTH	其他指数
        """    
        try:
            df = self.API.index_basic(market=market)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        return df
    
    def get_basic_concept(self):
        """获取概念列表 
        """    
        # df = pro.concept_detail(id='TS2', fields='ts_code,name')
        # #或者查询某个股票的概念
        # df = pro.concept_detail(ts_code = '600848.SH')
        try:
            df = self.API.concept()
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        return df
    
    def get_basic_index_content(self,index_code, start_date='', end_date=''):
        """获取指数成份股
        Args:
            index_code (str): 指数代码如：399300.SZ
            start_date和end_date分别输入当月第一天和最后一天的日期
            Returns:
            _type_: _description_dataframe
        """
        #提取沪深300指数2018年9月成分和权重 index_code='399300.SZ'
        try:
            df = self.API.index_weight(index_code=index_code, start_date=start_date, end_date=end_date)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        return df

    def get_weekly_montly(self,ts_code,start_date='', end_date='',freq = 'W'):
        """获取周线月线行情
        Args:
            ts_code (str): 股票代码如：300033.SZ
            start_date和end_date分别输入当月第一天和最后一天的日期
            freq：频率：D=日线 W=周 M=月
        Returns:
            _type_: _description_dataframe
        """
        if freq == 'W':
            try:
                df = self.API.stk_week_month_adj(ts_code=ts_code, start_date=start_date, end_date=end_date,freq='week')
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        elif freq == 'M':
            try:
                df = self.API.stk_week_month_adj(ts_code=ts_code, start_date=start_date, end_date=end_date,freq='month')
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        df['amount'] = df['amount'] * 1000
        return df
    
    # df=pro.stk_week_month_adj(ts_code='000001.SZ',freq='week')
    def get_daily_list(self,trade_date=''):
        '''根据指定日期获取当日股票行情列表 
        '''
        # data = pd.DataFrame()
        try:
            df = self.API.daily(trade_date=trade_date)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        df['amount'] = df['amount'] * 1000
        return df
    
    def get_daliy_basic_by_code(self,ts_code,start_date='', end_date=''):
        '''获取每日指标
        '''
        try:
            df = self.API.daily_basic(ts_code=ts_code, start_date=start_date, end_date=end_date) #, fields='ts_code,trade_date,turnover_rate,volume_ratio,pe,pb')
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        return df
    
    def get_daliy_basic(self,trade_date):
        '''获取每日指标
        '''
        try:
            df = self.API.daily_basic(ts_code='', trade_date=trade_date) #, fields='ts_code,trade_date,turnover_rate,volume_ratio,pe,pb')
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        return df
    
    def get_daliy_adj(self,ts_code='',trade_date=''):
        '''
        获取股票复权因子
        '''
        # 类型	算法	参数标识
        # 不复权	无	空或None
        # 前复权	当日收盘价 × 当日复权因子 / 最新复权因子	qfq
        # 后复权	当日收盘价 × 当日复权因子	hfq
        
        if ts_code == '':
            #提取开始日期所有股票复权因子
            try:
                df = self.API.adj_factor(ts_code='', trade_date=trade_date)
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        else:
            #提取股票所有复权因子
            try:
                df = self.API.adj_factor(ts_code=ts_code, trade_date='')
            except Exception as e:
                logger.error(str(e))                    
                return pd.DataFrame()
        df.rename(columns=self.COLUMN_MAP, inplace=True)
        return df

    def get_stock_top10_holders(self,ts_code,start_date='', end_date=''):
        '''
        获取股票前十大股东
        '''
        try:
            df = self.API.top10_holders(ts_code=ts_code, start_date=start_date, end_date=end_date)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        return df
        
        
    def get_stock_top10_floatholders(self,ts_code,start_date='', end_date=''):
        '''
        获取股票前十大流通股东
        '''
        try:
            df = self.API.top10_floatholders(ts_code=ts_code, start_date=start_date, end_date=end_date)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        return df
    
    def get_stock_holdernumber(self,ts_code,start_date='', end_date=''):
        '''
        获取股票股东人数
        '''
        try:
            df = self.API.stk_holdernumber(ts_code=ts_code, start_date=start_date, end_date=end_date)
        except Exception as e:
            logger.error(str(e))                    
            return pd.DataFrame()
        return df

