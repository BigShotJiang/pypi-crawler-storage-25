# Changelog

All notable changes to this project will be documented in this file.
## [1.2.0] - 2026-04-18


### CI/CD

- bump astral-sh/setup-uv from 7.6.0 to 8.0.0 (#342)
- bump github/codeql-action from 4.33.0 to 4.35.1 (#338)
- bump actions/deploy-pages from 4.0.5 to 5.0.0 (#339)
- bump actions/configure-pages from 5.0.0 to 6.0.0 (#341)
- bump codecov/codecov-action from 5.5.3 to 6.0.0 (#340)
- bump CodSpeedHQ/action from 4.12.1 to 4.13.0 (#346)
- bump actions/upload-artifact from 7.0.0 to 7.0.1 (#350)
- bump actions/upload-pages-artifact from 4.0.0 to 5.0.0 (#351)
- bump CodSpeedHQ/action from 4.13.0 to 4.13.1 (#353)
- bump PyO3/maturin-action from 1.50.1 to 1.51.0 (#352)
- bump pypa/gh-action-pypi-publish from 1.13.0 to 1.14.0 (#349)


### Documentation

- update changelog for v1.1.1 (#333)


### Features

- adding json attribute (#355)


### Refactoring

- remove code duplication (#344)


### Deps

- bump uuid from 1.22.0 to 1.23.0 in the rust-dependencies group across 1 directory (#343)
- bump the rust-dependencies group with 3 updates (#347)
- bump the rust-dependencies group with 3 updates (#354)
## [1.1.1] - 2026-03-28


### Bug Fixes

- bump deps (#305)
- add consistent_read parameter to batch operations (#324)
- Specify correct return types for Get/Query/Scan/BatchGet depending on the value of as_dict (#323)
- correct fields marked as dirty (#329)
- resolve naming collision when performing conditional updates (#330)


### CI/CD

- bump CodSpeedHQ/action from 4.11.0 to 4.11.1 (#306)
- bump github/codeql-action from 4.32.5 to 4.32.6 (#307)
- bump astral-sh/setup-uv from 7.3.1 to 7.6.0 (#314)
- bump github/codeql-action from 4.32.6 to 4.33.0 (#315)
- bump actions/cache from 5.0.3 to 5.0.4 (#319)
- bump actions/download-artifact from 8.0.0 to 8.0.1 (#313)
- bump CodSpeedHQ/action from 4.11.1 to 4.12.1 (#318)
- bump codecov/codecov-action from 5.5.2 to 5.5.3 (#317)
- resolve security issues (#326)
- bump release-drafter/release-drafter from 6 to 7 (#312)


### Documentation

- update changelog for v1.1.0 (#304)


### Refactoring

- split client.rs file (#332)


### Build

- bump requests from 2.32.5 to 2.33.0 (#327)
- bump memray from 1.19.1 to 1.19.2 (#328)


### Deps

- bump uuid from 1.21.0 to 1.22.0 in the rust-dependencies group (#308)
- bump lz4_flex from 0.12.0 to 0.12.1 (#321)
- bump the rust-dependencies group across 1 directory with 6 updates (#320)
## [1.1.0] - 2026-03-04


### Bug Fixes

- add tracer in scan/query methods (#303)


### CI/CD

- bump PyO3/maturin-action from 1.50.0 to 1.50.1 (#300)
- bump actions/download-artifact from 7.0.0 to 8.0.0 (#299)
- bump github/codeql-action from 4.32.4 to 4.32.5 (#301)
- bump actions/upload-artifact from 6.0.0 to 7.0.0 (#302)
- bump astral-sh/setup-uv from 7.3.0 to 7.3.1 (#298)


### Documentation

- update changelog for v1.0.0 (#293)


### Features

- add support for return values (#297)


### Deps

- bump aws-sdk-dynamodb in the rust-dependencies group (#296)
## [1.0.0] - 2026-02-24


### Bug Fixes

- resolve boolean check (#291)


### CI/CD

- bump CodSpeedHQ/action from 4.10.6 to 4.11.0 (#289)
- bump github/codeql-action from 4.32.3 to 4.32.4 (#287)
- bump orhun/git-cliff-action from 4.7.0 to 4.7.1 (#288)


### Documentation

- update changelog for v0.27.0 (#286)


### Features

- v1 (#292)


### Deps

- bump the rust-dependencies group with 4 updates (#290)
## [0.27.0] - 2026-02-20


### Bug Fixes

- release GIL on sync ops (#284)
- allow dynamodb big numbers (#285)


### CI/CD

- bump github/codeql-action from 4.32.2 to 4.32.3 (#274)


### Documentation

- update changelog for v0.26.0 (#268)


### Refactoring

- collection query and sync_query (#276)
- adding additional client consistency in model validation (#277)


### Deps

- bump time from 0.3.45 to 0.3.47 (#270)
- bump bytes from 1.11.0 to 1.11.1 (#269)
- bump the rust-dependencies group with 7 updates (#275)
## [0.26.0] - 2026-02-10


### CI/CD

- bump PyO3/maturin-action from 1.49.4 to 1.50.0 (#266)
- bump github/codeql-action from 4.32.1 to 4.32.2 (#265)
- bump astral-sh/setup-uv from 7.2.1 to 7.3.0 (#264)
- bump CodSpeedHQ/action from 4.10.4 to 4.10.6 (#263)


### Documentation

- update changelog for v0.25.0 (#248)


### Features

- adding field alias support (#267)


### Refactoring

- improve error message mechanism (#254)
- improve thread mechanism (#255)
- remove 2step serialization (#256)
- unify query API (#260)


### Deps

- bump the rust-dependencies group with 7 updates (#261)
## [0.25.0] - 2026-02-05


### CI/CD

- bump actions/cache from 5.0.2 to 5.0.3 (#241)
- bump CodSpeedHQ/action from 4.8.2 to 4.10.4 (#240)
- bump github/codeql-action from 4.32.0 to 4.32.1 (#239)
- bump astral-sh/setup-uv from 7.2.0 to 7.2.1 (#238)


### Documentation

- update changelog for v0.24.0 (#235)
- add security docs
- add security docs
- launch


### Features

- add Collection for multi-entity queries (#237)
- add tstring support (#243)
- adding debug logs (#247)


### Refactoring

- clean up rust code (#245)


### Deps

- bump aws-sdk-s3 in the rust-dependencies group (#242)
## [0.24.0] - 2026-01-31


### Documentation

- update changelog for v0.23.0 (#229)


### Features

- smart save - only send changed fields to DynamoDB (#232)
- adding model inheritance (#234)


### Refactoring

- rename hash e range key names
## [0.23.0] - 2026-01-30


### Documentation

- update changelog for v0.22.0 (#225)


### Features

- adding single table design (#226)


### Refactoring

- breaking change - rename hash e range key names (#228)
## [0.22.0] - 2026-01-29


### CI/CD

- bump actions/setup-python from 6.1.0 to 6.2.0 (#217)
- bump CodSpeedHQ/action from 4.7.0 to 4.8.2 (#219)
- bump github/codeql-action from 4.31.10 to 4.32.0 (#216)
- bump actions/checkout from 6.0.1 to 6.0.2 (#218)


### Documentation

- update changelog for v0.21.0 (#186)
- refactoring table operations async first (#197)
- refactoring s3 operations async first (#201)
- refactoring kms operations async first (#205)
- refactoring transaction operations async first (#209)
- refactoring batch operations async first (#213)
- refactoring all operations async first (#222)
- refactoring all operations async first


### Features

- add batch get support (#190)


### Refactoring

- start adding async as first design (#193)
- refactoring table operations async first (#196)
- refactoring s3 operations async first (#200)
- refactoring km operations async first (#204)
- refactoring transaction operations async first (#208)
- refactoring batch operations async first (#212)
- refactoring model/client operations async first (#221)


### Deps

- bump the rust-dependencies group with 2 updates (#220)
## [0.21.0] - 2026-01-22


### CI/CD

- bump actions/cache from 5.0.1 to 5.0.2 (#180)


### Documentation

- update changelog for v0.20.0 (#179)


### Features

- adding return values on failure (#181)
- adding transaction (#184)


### Refactoring

- Add `last_evaluated_key` parameter to GSI and LSI query (#185)


### Deps

- bump thiserror in the rust-dependencies group (#182)
## [0.20.0] - 2026-01-17


### Bug Fixes

- query pagination bug + add page_size parameter (#178)


### Documentation

- update changelog for v0.19.0 (#176)
## [0.19.0] - 2026-01-16


### Documentation

- update changelog for v0.18.0 (#174)


### Features

- add support for LSI (#175)
## [0.18.0] - 2026-01-16


### CI/CD

- bump CodSpeedHQ/action from 4.5.2 to 4.7.0 (#169)


### Docs

- add boto3 migration (#165)
- add annoucement (#167)


### Documentation

- update changelog for v0.17.0 (#163)


### Feat

- add async gsi query (#168)


### Refactoring

- fix type check issues (#171)
- unify all aws config clients (#173)


### Deps

- bump the rust-dependencies group across 1 directory with 8 updates (#170)
## [0.17.0] - 2026-01-15


### CI/CD

- bump actions/checkout from 4.2.2 to 6.0.1 (#149)
- bump astral-sh/setup-uv from 6.0.1 to 7.2.0 (#150)
- bump github/codeql-action from 3.28.19 to 4.31.10 (#151)
- bump softprops/action-gh-release from 2.2.1 to 2.5.0 (#148)


### Documentation

- update changelog for v0.16.0 (#146)


### Features

- adding testing feature (#147)
- add projection fields (#153)
- add KMS metrics (#159)
- add S3 metrics to Model observability (#162)


### Refactor

- clean the tests (#161)


### Refactoring

- add class methods instead of instance attributes (#154)
## [0.16.0] - 2026-01-10


### CI/CD

- bump actions/download-artifact from 4.3.0 to 7.0.0 (#139)
- bump actions/setup-python from 5.6.0 to 6.1.0 (#137)
- bump actions/upload-artifact from 4.6.2 to 6.0.0 (#135)


### Documentation

- update changelog for v0.15.0 (#141)


### Features

- adding OTEL (#143)
- add `as_dict` parameter to skip Model instantiation (#144)
- adding table operations to model (#145)
## [0.15.0] - 2026-01-09


### CI/CD

- replace mypy with ty (#128)
- create examples test workflow (#132)
- bump actions/cache from 4.2.3 to 5.0.1 (#138)
- bump CodSpeedHQ/action from 3.5.0 to 4.5.2 (#136)


### Features

- add parallel scan (#130)


### Miscellaneous

- refactor python code (#134)
## [0.14.0] - 2026-01-07


### CI/CD

- add prebuilt wheels dists (#24)
- add memray tests + fix codspeed (#80)
- add scorecard (#96)
- add scorecard
- bump actions/cache from 4.3.0 to 5.0.1 (#105)
- bump astral-sh/setup-uv from 4.2.0 to 7.1.6 (#103)
- bump actions/checkout from 4.3.1 to 6.0.1 (#104)
- bump actions/setup-python from 5.6.0 to 6.1.0 (#106)
- bump codecov/codecov-action from 4.6.0 to 5.5.2 (#107)
- bump codecov/codecov-action from 5.4.3 to 5.5.2 (#118)
- bump PyO3/maturin-action from 1.48.1 to 1.49.4 (#119)
- bump ossf/scorecard-action from 2.4.1 to 2.4.3 (#117)
- bump actions/upload-pages-artifact from 3.0.1 to 4.0.0 (#116)
- bump pypa/gh-action-pypi-publish from 1.12.4 to 1.13.0 (#115)


### Documentation

- adding genai guidance (#46)
- add agentic examples (#109)
- adding api reference (#121)


### Features

- improving error messages (#19)
- add support for ORM Model (#22)
- add support for Pydantic integration (#23)
- add table management methods to DynamoDBClient (#25)
- adding TTL attribute (#29)
- adding Rate Limit feature (#31)
- adding lifecycle rules (#34)
- adding lifecycle rules (#35)
- add CompressedAttribute for automatic text compression (#37)
- adding encryption field (#39)
- adding item size calculator (#41)
- add ORM-style conditions (#50)
- add atomic operations support (#52)
- add JSONAttribute, EnumAttribute, DatetimeAttribute, and Set types (#54)
- add observability (#56)
- add support for GSI index (#58)
- add async support (#60)
- add consistent read (#62)
- add generators (#67)
- add dataclass integration (#69)
- add query class (#72)
- add PartiQL support (#76)
- add optimistic lock (#77)
- add full auth chain (#82)
- add scan (#83)
- add s3file attribute (#84)
- add multi-attribute GSI keys support (Nov 2025 DynamoDB feature) (#89)
- add benchmark infra with CloudWatch dashboard (#93)
- add update_by_key and delete_by_key static methods (#108)
- adding hot partition support (#124)


### Miscellaneous

- rename dynamoclient (#21)
- add analytics (#71)
- improve CI (#111)


### Refactoring

- organize imports with namespaces (#27)
- replace class Meta with ModelConfig (#44)
- modernize python code (#48)
- use data key instead of encrypt operation (#110)


### Deps

- bump the rust-dependencies group with 3 updates (#102)

