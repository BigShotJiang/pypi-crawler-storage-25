"""LineageScope tests."""
