"""
AfriLink SDK — Finetune LLMs on HPC from Google Colab

Quick Start:
    from afrilink import AfriLinkClient

    client = AfriLinkClient()
    client.authenticate()

    ft = client.finetune(model="qwen2.5-0.5b", training_mode="low", data=my_dataset, gpus=1)
    result = ft.run(wait=True)

    client.download_model(result["job_id"], "./my_model")

User Guide:
    A built-in manual is available via forward-slash commands in any
    notebook or Python session.  After installing the package run:

        import afrilink
        afrilink/help            # topic index
        afrilink/quickstart      # 5-step end-to-end example
        afrilink/finetune        # full finetune() API reference
        afrilink/specs           # CINECA A100 hardware spec sheet
        afrilink/recover         # session recovery when cert expires
        afrilink/inference       # HuggingFace inference endpoint routing
        afrilink/billing         # credits, invoices & vouchers

    See  afrilink/help  for the complete topic list.
"""

__version__ = "0.5.9"

# Credentials provisioning (auto-runs in Colab)
from .credentials import (
    provision_credentials,
    get_cineca_credentials,
    CredentialProvider,
    OrgCredentials,
)

# Core authentication
from .auth import AfriLinkAuth, authenticate, AuthResult
from .cineca_auth import CinecaDirectAuth, authenticate_cineca, CinecaAuthResult

# Telemetry
from .telemetry import TelemetryClient, JobUsageTracker, track_cineca_jobs

# Finetuning API
from .finetune import finetune, FinetuneJob, FinetuneJobSpec, TrainingMode, TrainingConfig, SUPPORTED_BACKENDS, DEFAULT_BACKEND

# SLURM job management
from .slurm import SlurmJobManager, SlurmConfig

# Distributed training
from .distributed import DistributedConfig, DistributedStrategy, get_optimal_strategy

# Model/dataset registry
from .registry import (
    ModelRegistry,
    ModelInfo,
    DatasetInfo,
    ModelSize,
    ModelType,
    get_registry,
    list_models,
    list_datasets,
)

# Vouchers
from .vouchers import generate_voucher, validate_voucher, generate_batch

# Data transfer
from .transfer import DataTransferManager, create_transfer_manager

# Session watchdog & recovery
from .watchdog import SessionWatchdog, EmailNotifier, JobRecoveryInfo

# HuggingFace inference
from .inference import HFInferenceClient, InferenceResult

# Main client (recommended entry point)
from .client import AfriLinkClient, ClientConfig, create_client

# Help / manual system — enables: import afrilink; afrilink/help
from .help import help_system as _help_system

import sys as _sys
import types as _types


class _AfriLinkModule(_types.ModuleType):
    """Module subclass that implements afrilink/<topic> slash syntax."""

    def __truediv__(self, topic):
        _help_system._show(str(topic))
        return self

    def __repr__(self):
        return (
            f"<module 'afrilink' v{__version__}> — "
            "run  import afrilink; afrilink/help  for the user guide."
        )


# Replace this module with the instrumented subclass so that
# `afrilink / 'specs'` works at the module level in notebooks.
_current = _sys.modules[__name__]
_upgraded = _AfriLinkModule(__name__, __doc__)
_upgraded.__dict__.update({k: v for k, v in _current.__dict__.items()
                            if not k.startswith("_upgraded")})
_sys.modules[__name__] = _upgraded


__all__ = [
    "__version__",
    # Main client
    "AfriLinkClient",
    "ClientConfig",
    "create_client",
    # Credentials
    "provision_credentials",
    "get_cineca_credentials",
    "CredentialProvider",
    "OrgCredentials",
    # Authentication
    "AfriLinkAuth",
    "authenticate",
    "AuthResult",
    "CinecaDirectAuth",
    "authenticate_cineca",
    "CinecaAuthResult",
    # Finetuning
    "finetune",
    "FinetuneJob",
    "FinetuneJobSpec",
    "TrainingMode",
    "TrainingConfig",
    "SUPPORTED_BACKENDS",
    "DEFAULT_BACKEND",
    # SLURM
    "SlurmJobManager",
    "SlurmConfig",
    # Distributed
    "DistributedConfig",
    "DistributedStrategy",
    "get_optimal_strategy",
    # Registry
    "ModelRegistry",
    "ModelInfo",
    "DatasetInfo",
    "ModelSize",
    "ModelType",
    "get_registry",
    "list_models",
    "list_datasets",
    # Vouchers
    "generate_voucher",
    "validate_voucher",
    "generate_batch",
    # Transfer
    "DataTransferManager",
    "create_transfer_manager",
    # Telemetry
    "TelemetryClient",
    "JobUsageTracker",
    "track_cineca_jobs",
    # Watchdog & recovery
    "SessionWatchdog",
    "EmailNotifier",
    "JobRecoveryInfo",
    # HuggingFace inference
    "HFInferenceClient",
    "InferenceResult",
    # Help system
    "help_system",
]
