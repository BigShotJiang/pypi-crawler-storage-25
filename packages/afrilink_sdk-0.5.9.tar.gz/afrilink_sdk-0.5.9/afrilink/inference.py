"""
AfriLink SDK — HuggingFace Inference Client
============================================

Passes inference requests through to HuggingFace Inference Endpoints
(both the free Inference API and privately-deployed endpoints).

Usage:

    result = client.inference(
        prompt="Explain gradient descent in one sentence.",
        model_id="meta-llama/Llama-2-7b-chat-hf",  # any HF model ID
    )
    print(result.text)

    # Or with an explicit private endpoint URL:
    result = client.inference(
        payload={"inputs": "Hello!", "parameters": {"max_new_tokens": 64}},
        endpoint_url="https://your-endpoint.endpoints.huggingface.cloud",
        hf_token="hf_...",
    )

The SDK does not run inference on CINECA — it simply forwards the
request to the HuggingFace endpoint specified by the caller and returns
a structured result.  No authentication with CINECA is required.
"""

from __future__ import annotations

import json as _json
import urllib.request as _urllib_req
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

# Public HuggingFace Inference API base URL
_HF_INFERENCE_BASE = "https://api-inference.huggingface.co/models"


@dataclass
class InferenceResult:
    """
    Result returned by client.inference().

    Attributes
    ----------
    text : str
        Generated text (first result for text-generation / text2text tasks;
        empty string for other task types — use `raw` instead).
    raw : Any
        The full decoded JSON response from the endpoint.
    status_code : int
        HTTP status code returned by the endpoint.
    model_id : str
        The model / endpoint that was called.
    error : str | None
        Error message if the request failed, otherwise None.
    success : bool
        True if status_code < 400.
    """
    text: str = ""
    raw: Any = None
    status_code: int = 0
    model_id: str = ""
    error: Optional[str] = None

    @property
    def success(self) -> bool:
        return self.status_code < 400 and self.error is None

    def __repr__(self) -> str:
        if self.success:
            preview = (self.text[:120] + "…") if len(self.text) > 120 else self.text
            return f"InferenceResult(status={self.status_code}, text={preview!r})"
        return f"InferenceResult(status={self.status_code}, error={self.error!r})"


class HFInferenceClient:
    """
    Lightweight client for HuggingFace Inference API / Inference Endpoints.

    Does not require CINECA authentication.  Instantiated automatically
    by AfriLinkClient after DataSpires authentication succeeds.

    Parameters
    ----------
    default_hf_token : str | None
        HuggingFace API token used for all requests unless overridden
        per-call.  Required for gated models (e.g. Llama-2, Gemma).
        Free public models work without a token (rate-limited).
    """

    def __init__(self, default_hf_token: Optional[str] = None):
        self._default_token = default_hf_token

    # ── Public method ─────────────────────────────────────────────────────────

    def run(
        self,
        *,
        prompt: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
        model_id: Optional[str] = None,
        endpoint_url: Optional[str] = None,
        hf_token: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        timeout: int = 120,
    ) -> InferenceResult:
        """
        Send an inference request to a HuggingFace endpoint.

        Exactly one of ``model_id`` or ``endpoint_url`` must be provided.

        Parameters
        ----------
        prompt : str, optional
            Text prompt for text-generation / text2text tasks.
            If provided, it is wrapped in the standard HF payload:
            ``{"inputs": prompt, "parameters": parameters}``.
        payload : dict, optional
            Fully custom request body.  Takes precedence over ``prompt``
            when both are given.  Must be JSON-serialisable.
        model_id : str, optional
            HuggingFace model ID, e.g. ``"meta-llama/Llama-2-7b-chat-hf"``.
            Routes to ``https://api-inference.huggingface.co/models/<id>``.
        endpoint_url : str, optional
            Full URL of a private HuggingFace Inference Endpoint, e.g.
            ``"https://xyz.endpoints.huggingface.cloud"``.
            Takes precedence over ``model_id`` when both are given.
        hf_token : str, optional
            HuggingFace API token for this call.  Falls back to the token
            passed at construction time.  Omit for public open-access models.
        parameters : dict, optional
            Generation parameters merged into the ``parameters`` key of the
            request body.  Common keys: ``max_new_tokens``, ``temperature``,
            ``top_p``, ``repetition_penalty``, ``return_full_text``.
            Ignored when ``payload`` is given directly.
        timeout : int
            Request timeout in seconds (default 120).

        Returns
        -------
        InferenceResult
        """
        # ── Resolve URL ───────────────────────────────────────────────────────
        if endpoint_url:
            url = endpoint_url.rstrip("/")
            resolved_id = endpoint_url
        elif model_id:
            url = f"{_HF_INFERENCE_BASE}/{model_id}"
            resolved_id = model_id
        else:
            return InferenceResult(
                error="Provide either model_id= or endpoint_url=.",
                status_code=0,
                model_id="",
            )

        # ── Build request body ────────────────────────────────────────────────
        if payload is not None:
            body = payload
        elif prompt is not None:
            body: Dict[str, Any] = {"inputs": prompt}
            if parameters:
                body["parameters"] = parameters
        else:
            return InferenceResult(
                error="Provide either prompt= or payload=.",
                status_code=0,
                model_id=resolved_id,
            )

        # ── Resolve token ─────────────────────────────────────────────────────
        token = hf_token or self._default_token

        # ── Execute request ───────────────────────────────────────────────────
        return self._execute(url, body, token, resolved_id, timeout)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _execute(
        self,
        url: str,
        body: Dict[str, Any],
        token: Optional[str],
        model_id: str,
        timeout: int,
    ) -> InferenceResult:
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        raw_body = _json.dumps(body).encode("utf-8")

        try:
            # Try requests first (better error messages); fall back to urllib
            try:
                import requests as _requests  # type: ignore
                resp = _requests.post(url, data=raw_body, headers=headers, timeout=timeout)
                status = resp.status_code
                raw_bytes = resp.content
            except ImportError:
                req = _urllib_req.Request(url, data=raw_body, headers=headers, method="POST")
                try:
                    with _urllib_req.urlopen(req, timeout=timeout) as r:
                        status = r.getcode()
                        raw_bytes = r.read()
                except _urllib_req.HTTPError as http_err:
                    status = http_err.code
                    raw_bytes = http_err.read()

        except Exception as exc:
            return InferenceResult(
                error=f"Request failed: {exc}",
                status_code=0,
                model_id=model_id,
            )

        # ── Decode response ───────────────────────────────────────────────────
        try:
            decoded = _json.loads(raw_bytes)
        except Exception:
            decoded = raw_bytes.decode("utf-8", errors="replace")

        error_msg: Optional[str] = None
        if status >= 400:
            if isinstance(decoded, dict):
                error_msg = decoded.get("error") or decoded.get("message") or str(decoded)
            else:
                error_msg = str(decoded)[:300]

        text = _extract_text(decoded)

        return InferenceResult(
            text=text,
            raw=decoded,
            status_code=status,
            model_id=model_id,
            error=error_msg,
        )


# ── Utility: extract generated text from common HF response shapes ─────────

def _extract_text(decoded: Any) -> str:
    """
    Best-effort extraction of generated text from a HuggingFace response.

    Handles the three most common shapes:
      1. List of dicts with 'generated_text' key  → text-generation pipeline
      2. List of dicts with 'translation_text' or 'summary_text'
      3. Dict with 'generated_text'
      4. Plain string
    """
    if isinstance(decoded, list) and decoded:
        first = decoded[0]
        if isinstance(first, dict):
            for key in ("generated_text", "translation_text", "summary_text",
                        "sequence", "label"):
                if key in first:
                    return str(first[key])
        if isinstance(first, str):
            return first
    if isinstance(decoded, dict):
        for key in ("generated_text", "translation_text", "summary_text"):
            if key in decoded:
                return str(decoded[key])
    if isinstance(decoded, str):
        return decoded
    return ""
