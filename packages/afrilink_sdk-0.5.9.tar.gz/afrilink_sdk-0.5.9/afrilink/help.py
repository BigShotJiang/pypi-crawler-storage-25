"""
AfriLink SDK — Slash-command help system
========================================

Usage (in any notebook or Python session):

    import afrilink
    afrilink/help         # full user guide index
    afrilink/authenticate # authentication reference
    afrilink/finetune     # finetune API reference
    afrilink/models       # available models
    afrilink/datasets     # available datasets
    afrilink/jobs         # job management
    afrilink/download     # model download
    afrilink/recover      # session recovery & watchdog
    afrilink/specs        # CINECA hardware specs
    afrilink/billing      # credits, billing & vouchers
    afrilink/quickstart   # 5-step quick-start example
    afrilink/backends     # supported HPC backends
    afrilink/training     # training modes (low/medium/high)
    afrilink/config       # ClientConfig & environment variables
    afrilink/transfer     # data transfer (upload / download)
    afrilink/ssh          # running raw SSH commands
    afrilink/geofence     # geofencing & access policy
    afrilink/watchdog     # session watchdog internals
    afrilink/inference    # HuggingFace inference endpoint routing
    afrilink/vouchers     # voucher code format & redemption
    afrilink/version      # current SDK version

The forward-slash syntax works because the afrilink module object implements
__truediv__ — no extra imports needed.
"""

from __future__ import annotations

# ─── ANSI colours (graceful fallback if not a real TTY) ─────────────────────
_C = {
    "reset":  "\033[0m",
    "bold":   "\033[1m",
    "dim":    "\033[2m",
    "cyan":   "\033[36m",
    "green":  "\033[32m",
    "yellow": "\033[33m",
    "blue":   "\033[34m",
    "magenta":"\033[35m",
    "red":    "\033[31m",
}

def _c(color: str, text: str) -> str:
    """Wrap text in ANSI colour codes."""
    return _C.get(color, "") + text + _C["reset"]


# ─── Individual page content ─────────────────────────────────────────────────

PAGES: dict[str, str] = {}

# ── /help ────────────────────────────────────────────────────────────────────
PAGES["help"] = f"""
{_c("bold", "AfriLink SDK — User Guide")}
{_c("dim", "─" * 60)}

  Run {_c("cyan", "afrilink/<topic>")} in any cell for detailed docs.

  {_c("bold", "Getting started")}
    afrilink/quickstart   5-step end-to-end example
    afrilink/config       ClientConfig & environment variables
    afrilink/authenticate authenticate() reference

  {_c("bold", "Core workflow")}
    afrilink/finetune     client.finetune() API
    afrilink/training     training modes (low / medium / high)
    afrilink/models       available base models
    afrilink/datasets     available datasets
    afrilink/jobs         job management (list / cancel / status)
    afrilink/download     downloading trained weights
    afrilink/transfer     uploading datasets to CINECA

  {_c("bold", "Session management")}
    afrilink/recover      session recovery when SSH cert expires
    afrilink/watchdog     background cert-expiry watchdog
    afrilink/ssh          raw SSH commands via client.run_command()

  {_c("bold", "Inference")}
    afrilink/inference    route inference to HuggingFace endpoints

  {_c("bold", "Platform")}
    afrilink/backends     supported HPC backends
    afrilink/specs        CINECA A100 hardware spec sheet
    afrilink/billing      credits, invoices & vouchers
    afrilink/vouchers     voucher code format & redemption
    afrilink/geofence     geographic access policy

  {_c("bold", "Meta")}
    afrilink/version      SDK version info
"""

# ── /quickstart ──────────────────────────────────────────────────────────────
PAGES["quickstart"] = f"""
{_c("bold", "AfriLink — Quick Start (5 steps)")}
{_c("dim", "─" * 60)}

  Step 1  Install
  {_c("cyan", "!pip install afrilink-sdk")}

  Step 2  Authenticate
  {_c("cyan", "from afrilink import AfriLinkClient")}
  {_c("cyan", "client = AfriLinkClient()")}
  {_c("cyan", "client.authenticate()   # prompts for DataSpires + CINECA creds")}

  Step 3  Prepare a dataset (Alpaca/ShareGPT format)
  {_c("cyan", "import pandas as pd")}
  {_c("cyan", "data = pd.DataFrame({{")}
  {_c("cyan", '      "instruction": ["Translate to French", ...],')}
  {_c("cyan", '      "input":       ["Hello world",         ...],')}
  {_c("cyan", '      "output":      ["Bonjour le monde",    ...],')}
  {_c("cyan", "  }})")}

  Step 4  Submit a finetune job
  {_c("cyan", 'ft = client.finetune(')}
  {_c("cyan", '    model          = "qwen2.5-0.5b",')}
  {_c("cyan", '    training_mode  = "low",')}
  {_c("cyan", '    data           = data,')}
  {_c("cyan", '    gpus           = 1,')}
  {_c("cyan", ')')}
  {_c("cyan", "result = ft.run(wait=True)          # blocks until training finishes")}

  Step 5  Download trained weights
  {_c("cyan", 'client.download_model(result["job_id"], "./my_model")')}

  Run {_c("yellow", "afrilink/finetune")} for full parameter reference.
  Run {_c("yellow", "afrilink/models")} to see all available base models.
"""

# ── /authenticate ─────────────────────────────────────────────────────────────
PAGES["authenticate"] = f"""
{_c("bold", "authenticate() — Two-phase authentication")}
{_c("dim", "─" * 60)}

  Authentication happens in two required phases:

    Phase 1  {_c("green", "DataSpires")} (billing & account gating)
             Validates your dataspires.com account.
             Sets up credit tracking and invoice generation.

    Phase 2  {_c("green", "CINECA")} (HPC SSH certificate)
             Headless OIDC + TOTP login to Leonardo/Booster.
             Issues a 12-hour Smallstep SSH certificate.
             The background watchdog starts immediately after.

  {_c("bold", "Signatures")}

    {_c("cyan", "client.authenticate(")}
    {_c("cyan", "    dataspires_email    = None,   # prompted if omitted")}
    {_c("cyan", "    dataspires_password = None,")}
    {_c("cyan", "    cineca_email        = None,   # or CINECA_EMAIL env var")}
    {_c("cyan", "    cineca_password     = None,   # or CINECA_PASSWORD env var")}
    {_c("cyan", "    cineca_totp_seed    = None,   # or CINECA_TOTP_SEED env var")}
    {_c("cyan", "    cineca_username     = None,")}
    {_c("cyan", "    interactive         = True,")}
    {_c("cyan", ")")}

    {_c("cyan", "client.authenticate_dataspires(email, password)")}
    Authenticate DataSpires only (no CINECA). Use when you need
    to check billing/balance without starting an HPC session.

  {_c("bold", "Environment variables (alternative to passing creds)")}

    CINECA_EMAIL          CINECA SSO email
    CINECA_PASSWORD       CINECA SSO password
    CINECA_TOTP_SEED      Base-32 TOTP seed for 2FA
    CINECA_USERNAME       CINECA Unix username
    DATASPIRES_EMAIL      DataSpires account email
    DATASPIRES_PASSWORD   DataSpires account password

  {_c("bold", "Properties after authenticate()")}

    client.is_authenticated           True if both phases succeeded
    client.is_dataspires_authenticated True if DataSpires succeeded
    client.cert_minutes_remaining     Minutes until SSH cert expires
    client.dataspires_user_id         UUID of your DataSpires account

  Run {_c("yellow", "afrilink/recover")} for what to do when the cert expires.
  Run {_c("yellow", "afrilink/config")} for ClientConfig environment variables.
"""

# ── /finetune ─────────────────────────────────────────────────────────────────
PAGES["finetune"] = f"""
{_c("bold", "finetune() — Submit a training job")}
{_c("dim", "─" * 60)}

  {_c("cyan", "ft = client.finetune(")}
  {_c("cyan", "    model          = 'qwen2.5-0.5b',  # model identifier")}
  {_c("cyan", "    training_mode  = 'low',           # 'low' | 'medium' | 'high'")}
  {_c("cyan", "    data           = df,              # DataFrame or path string")}
  {_c("cyan", "    dataset_path   = None,            # explicit remote path")}
  {_c("cyan", "    gpus           = 1,               # number of A100 GPUs")}
  {_c("cyan", "    time_limit     = '04:00:00',      # SLURM wall-clock limit")}
  {_c("cyan", "    backend        = 'cineca',        # HPC backend")}
  {_c("cyan", "    output_dir     = None,            # remote output path")}
  {_c("cyan", ")")}

  Returns a {_c("green", "FinetuneJob")} object. Call {_c("cyan", "ft.run()")} to submit and optionally block.

  {_c("bold", "FinetuneJob methods")}

    {_c("cyan", "ft.run(wait=False, poll_interval=30, timeout=14400)")}
      Submit to SLURM. Pass wait=True to block until completion.

    {_c("cyan", "ft.status")}
      Current SLURM state string (PENDING / RUNNING / COMPLETED / FAILED).

    {_c("cyan", "ft.job_id")}
      AfriLink internal job UUID.

    {_c("cyan", "ft.slurm_job_id")}
      Numeric SLURM job ID (set after ft.run()).

    {_c("cyan", "ft.cancel()")}
      Send scancel to SLURM for this job.

  {_c("bold", "Dataset format")}

    Alpaca / instruction-following:
      columns: instruction | input (optional) | output

    ShareGPT / conversation:
      columns: conversations (list of {{from, value}} dicts)

    Pass as a pandas DataFrame or a local file path (.json / .csv / .parquet).

  Run {_c("yellow", "afrilink/training")}  for training mode details.
  Run {_c("yellow", "afrilink/models")}    for the full model list.
  Run {_c("yellow", "afrilink/backends")}  for available HPC clusters.
"""

# ── /training ─────────────────────────────────────────────────────────────────
PAGES["training"] = f"""
{_c("bold", "Training modes")}
{_c("dim", "─" * 60)}

  Pass as training_mode= in client.finetune().

  {_c("bold", "low   (default, fastest)")}
    Quantization:  4-bit QLoRA  (bitsandbytes NF4)
    LoRA rank:     8
    Gradient ckpt: disabled
    Use when:      rapid iteration, ≤ 1 GPU, small datasets
    Typical time:  10–40 min on 1× A100 for 0.5B–3B model

  {_c("bold", "medium")}
    Quantization:  8-bit
    LoRA rank:     16
    Gradient ckpt: enabled
    Use when:      balanced quality / speed, 1–4 GPUs, 7B models

  {_c("bold", "high  (best quality)")}
    Quantization:  none (bf16 full fine-tune or 16-bit LoRA)
    LoRA rank:     64
    Gradient ckpt: enabled
    Use when:      production-quality adapters, ≥ 4 GPUs, 7B–70B models

  {_c("bold", "GPU recommendations")}

    Model size    low    medium    high
    ─────────────────────────────────────
    0.5B – 1B     1      1         1
    3B – 7B       1      1–2       2–4
    13B           2      2–4       4
    30B+          4      4         4×+

  Run {_c("yellow", "afrilink/specs")} for A100 hardware specs.
  Run {_c("yellow", "afrilink/finetune")} for the full finetune() API.
"""

# ── /models ───────────────────────────────────────────────────────────────────
PAGES["models"] = f"""
{_c("bold", "Available base models")}
{_c("dim", "─" * 60)}

  Use with:  {_c("cyan", "ft = client.finetune(model=<id>, ...)")}
  List live: {_c("cyan", "client.list_available_models()")}
  Filter:    {_c("cyan", "client.list_available_models(size='small')")}
             size = 'small' | 'medium' | 'large'

  {_c("bold", "Text models")}

    ID                    Size    Parameters   Notes
    ─────────────────────────────────────────────────────
    qwen2.5-0.5b          small   0.5B         Qwen 2.5 base (recommended starter)
    qwen2.5-1.5b          small   1.5B
    qwen2.5-3b            small   3B
    qwen2.5-7b            medium  7B
    qwen2.5-14b           medium  14B
    llama-3b              small   3B           Meta Llama 3.2
    llama-7b              medium  7B           Meta Llama 2
    llama-13b             large   13B
    mistral-7b            medium  7B           Mistral v0.3
    phi-3.5               small   3.8B         Microsoft Phi-3.5-mini
    gemma-2b              small   2B           Google Gemma 2

  {_c("bold", "Vision-Language models")}

    ID                    Size    Notes
    ─────────────────────────────────────────────────
    llava-1.5-7b          medium  LLaVA 1.5 (image+text)
    qwen2-vl-2b           small   Qwen2 VL (video/image)
    qwen2-vl-7b           medium  Qwen2 VL

  {_c("bold", "Resource requirements")}

    {_c("cyan", "client.get_model_requirements('qwen2.5-7b', training_mode='low')")}
    Returns recommended gpus, RAM, time_limit for a given model × mode.

  Run {_c("yellow", "afrilink/finetune")} to use a model in a job.
"""

# ── /datasets ─────────────────────────────────────────────────────────────────
PAGES["datasets"] = f"""
{_c("bold", "Available datasets")}
{_c("dim", "─" * 60)}

  List available: {_c("cyan", "client.list_available_datasets()")}

  {_c("bold", "Hosted datasets (pass as dataset_path= in finetune())")}

    ID                     Format       Description
    ───────────────────────────────────────────────────────────────
    alpaca-cleaned         Alpaca        52K cleaned instruction pairs
    dolly-15k              Alpaca        15K Databricks instruction pairs
    openassistant-top1     ShareGPT      9K high-quality conversations
    ultrachat-200k         ShareGPT      200K multi-turn chat
    code-alpaca-20k        Alpaca        20K coding instructions
    medical-meadow         Alpaca        Medical Q&A (research use)

  {_c("bold", "Bring your own data")}

    Pass a pandas DataFrame directly to data=
    OR upload a file then pass the remote path to dataset_path=

    {_c("cyan", "client.upload_dataset('./my_data.json', 'my_dataset')")}

  {_c("bold", "Required column names")}

    Alpaca:   instruction, input (optional), output
    ShareGPT: conversations   [{{'from': 'human', 'value': '...'}}]

  Run {_c("yellow", "afrilink/transfer")} for upload details.
"""

# ── /jobs ─────────────────────────────────────────────────────────────────────
PAGES["jobs"] = f"""
{_c("bold", "Job management")}
{_c("dim", "─" * 60)}

  {_c("bold", "List jobs")}
    {_c("cyan", "client.list_jobs()")}
    Returns a list of dicts from SLURM with job ID, state, time used.

    {_c("cyan", "client.list_jobs(include_completed=True)")}
    Include COMPLETED / FAILED jobs (from sacct).

  {_c("bold", "Get a specific job object")}
    {_c("cyan", 'job = client.get_job(job_id)')}
    Retrieves the FinetuneJob object tracked in this session.
    Returns None if the job_id was not submitted in this session.

  {_c("bold", "Cancel a job")}
    {_c("cyan", "client.cancel_job(job_id)")}  # AfriLink UUID
    {_c("cyan", "client.cancel_job(slurm_job_id)")}  # numeric SLURM ID
    Calls scancel on the cluster. Returns True on success.

  {_c("bold", "Queue status")}
    {_c("cyan", "client.get_queue_status()")}
    Returns cluster-wide queue info (running, pending counts).

  {_c("bold", "Job status values")}

    PENDING    Queued — waiting for resources
    RUNNING    Training in progress
    COMPLETED  Training finished successfully → download weights
    FAILED     Training crashed → inspect logs
    CANCELLED  Manually stopped with cancel_job()
    TIMEOUT    Hit the time_limit wall-clock

  {_c("bold", "FinetuneJob properties (returned by client.finetune())")}
    {_c("cyan", "ft.status")}         Current state string
    {_c("cyan", "ft.job_id")}         AfriLink UUID
    {_c("cyan", "ft.slurm_job_id")}   SLURM integer ID (after ft.run())

  Run {_c("yellow", "afrilink/recover")} to check jobs after reconnecting.
"""

# ── /download ─────────────────────────────────────────────────────────────────
PAGES["download"] = f"""
{_c("bold", "download_model() — Download trained adapter weights")}
{_c("dim", "─" * 60)}

  {_c("cyan", "client.download_model(job_id, local_dir)")}

  Downloads the LoRA adapter checkpoint from CINECA $WORK
  to a local directory after job completion.

  {_c("bold", "Parameters")}
    job_id      AfriLink job UUID (from result['job_id'] after ft.run())
    local_dir   Local path where files will be written
                (created if it does not exist)

  {_c("bold", "What gets downloaded")}
    adapter_config.json     LoRA adapter configuration
    adapter_model.bin       Trained adapter weights
    tokenizer_config.json
    tokenizer.model
    training_args.bin       Hyperparameters used
    trainer_state.json      Loss curves / training metrics

  {_c("bold", "After downloading — inference with transformers")}
    {_c("cyan", "from transformers import AutoModelForCausalLM, AutoTokenizer")}
    {_c("cyan", "from peft import PeftModel")}
    {_c("cyan", "")}
    {_c("cyan", 'base = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-0.5B")')}
    {_c("cyan", 'tok  = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-0.5B")')}
    {_c("cyan", 'model = PeftModel.from_pretrained(base, "./my_model")')}
    {_c("cyan", "")}
    {_c("cyan", 'inputs = tok("Hello!", return_tensors="pt")')}
    {_c("cyan", "print(tok.decode(model.generate(**inputs)[0]))")}

  Run {_c("yellow", "afrilink/transfer")} for upload/download details.
  Run {_c("yellow", "afrilink/recover")} to download after a reconnect.
"""

# ── /transfer ─────────────────────────────────────────────────────────────────
PAGES["transfer"] = f"""
{_c("bold", "Data transfer — upload & download")}
{_c("dim", "─" * 60)}

  All transfers go over SCP via the SSH certificate obtained at
  authenticate() time. No external S3/storage account needed.

  {_c("bold", "Upload a dataset")}
    {_c("cyan", "client.upload_dataset(local_path, dataset_name=None)")}
    Uploads a local file (JSON / CSV / Parquet) to your CINECA $WORK
    directory. Returns a TransferResult with the remote path.

    Then pass the remote path to finetune():
    {_c("cyan", 'ft = client.finetune(..., dataset_path=result.remote_path)')}

  {_c("bold", "Download model weights")}
    {_c("cyan", "client.download_model(job_id, local_dir)")}
    Downloads trained adapter weights from CINECA to local_dir.

  {_c("bold", "Low-level transfer manager")}
    {_c("cyan", "client.transfer")}   DataTransferManager instance
    {_c("cyan", "client.transfer.upload_dataset(local_path, name)")}
    {_c("cyan", "client.transfer.download_model_weights(job_id, local_dir)")}

  {_c("bold", "TransferResult fields")}
    .success         True / False
    .remote_path     Path on CINECA (use as dataset_path=)
    .local_path      Local destination path
    .error           Error message if success=False

  Run {_c("yellow", "afrilink/download")} for post-training download details.
"""

# ── /recover ──────────────────────────────────────────────────────────────────
PAGES["recover"] = f"""
{_c("bold", "recover_session() — Re-auth and recover after cert expiry")}
{_c("dim", "─" * 60)}

  CINECA SSH certificates are valid for {_c("yellow", "12 hours")}. The SDK
  background watchdog warns you at 60 / 30 / 15 / 5 minutes
  before expiry and prints:
    {_c("yellow", "⚠ Certificate expires in 15 minutes. Run client.recover_session()")}

  When you see that message (or after reconnecting to a notebook):

    {_c("cyan", "recovery = client.recover_session(download_dir='./models')")}
    {_c("cyan", "print(recovery)")}

  {_c("bold", "What recover_session() does")}
    1  Re-authenticates with CINECA (fresh 12-hour certificate)
    2  Rebuilds SLURM and transfer managers
    3  Restarts the watchdog
    4  Queries SLURM state for every tracked job
    5  Downloads weights for COMPLETED jobs (if download_dir given)
    6  Registers email notification for RUNNING / PENDING jobs

  {_c("bold", "Parameters")}
    download_dir   Local directory to download completed models to.
                   Pass None to just report status without downloading.

  {_c("bold", "Returns: JobRecoveryInfo")}
    recovery.re_authenticated    True if CINECA re-auth succeeded
    recovery.jobs                {{job_id: {{status, slurm_job_id, model, ...}}}}
    recovery.files_retrieved     List of local paths downloaded
    recovery.email_requested     True if email notification was queued

  {_c("bold", "Check cert time remaining without recovering")}
    {_c("cyan", "client.cert_minutes_remaining")}

  Run {_c("yellow", "afrilink/watchdog")} for watchdog internals.
"""

# ── /watchdog ─────────────────────────────────────────────────────────────────
PAGES["watchdog"] = f"""
{_c("bold", "SessionWatchdog — Background cert-expiry monitor")}
{_c("dim", "─" * 60)}

  Starts automatically after authenticate() succeeds.
  Runs as a daemon thread — no action needed from you.

  {_c("bold", "Warning thresholds")}
    60 min  — first reminder
    30 min  — second reminder
    15 min  — urgent reminder
     5 min  — final warning

  {_c("bold", "Properties (read-only, available on client)")}
    {_c("cyan", "client.cert_minutes_remaining")}   float, inf if no cert
    {_c("cyan", "client._watchdog.is_expired")}      True after cert has expired
    {_c("cyan", "client._watchdog.is_running")}      True while daemon is alive

  {_c("bold", "Email notification on job completion")}
    If your notebook disconnects with a job still RUNNING, call
    recover_session() later. It will also register an email
    so you receive a notification when the job finishes.

    The email is sent via a Supabase Edge Function that polls
    the email_notifications table every 2 minutes and uses Resend
    to deliver the message to your DataSpires email address.

  Run {_c("yellow", "afrilink/recover")} for the full recovery workflow.
"""

# ── /ssh ──────────────────────────────────────────────────────────────────────
PAGES["ssh"] = f"""
{_c("bold", "run_command() — Execute raw SSH commands on CINECA")}
{_c("dim", "─" * 60)}

  {_c("cyan", "code, stdout, stderr = client.run_command(command, timeout=60)")}

  Runs an arbitrary shell command on the CINECA Leonardo login node
  via the SSH certificate obtained at authenticate() time.

  {_c("bold", "Parameters")}
    command   Shell command string
    timeout   Seconds before the connection is aborted (default 60)

  {_c("bold", "Returns")}
    code    Return code (0 = success)
    stdout  Command output as a string
    stderr  Error output as a string

  {_c("bold", "Examples")}
    {_c("cyan", 'code, out, _ = client.run_command("squeue -u $USER")')}
    {_c("cyan", 'print(out)')}

    {_c("cyan", 'code, out, _ = client.run_command("ls $WORK/outputs/")')}
    {_c("cyan", 'print(out)')}

    {_c("cyan", 'code, out, _ = client.run_command("sacct -j 12345 --format=State,Elapsed")')}

  {_c("bold", "Low-level access")}
    {_c("cyan", "client.cineca")}            CinecaDirectAuth instance
    {_c("cyan", "client.cineca.run_ssh_command(cmd)")}   same as run_command
    {_c("cyan", "client.slurm")}             SlurmJobManager instance
    {_c("cyan", "client.transfer")}          DataTransferManager instance
"""

# ── /backends ─────────────────────────────────────────────────────────────────
PAGES["backends"] = f"""
{_c("bold", "Supported HPC backends")}
{_c("dim", "─" * 60)}

  Pass as backend= in client.finetune().

  {_c("bold", "cineca")} (default)
    Cluster:   Leonardo / Booster (CINECA, Italy)
    GPUs:      4× NVIDIA A100 64 GB per node
    Network:   200 Gb/s HDR InfiniBand
    Auth:      OIDC + TOTP Smallstep SSH certificate
    Status:    ✓ Production

  {_c("bold", "eversetech")}
    Status:    Coming soon

  {_c("bold", "agh")}
    Cluster:   AGH Cyfronet (Krakow, Poland)
    Status:    Coming soon

  {_c("bold", "acf")}
    Cluster:   ACF (University of Tennessee)
    Status:    Coming soon

  Run {_c("yellow", "afrilink/specs")} for detailed CINECA hardware specs.
"""

# ── /specs ─────────────────────────────────────────────────────────────────────
PAGES["specs"] = f"""
{_c("bold", "CINECA Leonardo — Hardware Spec Sheet")}
{_c("dim", "─" * 60)}

  {_c("bold", "GPU NODE (Booster partition)")}  ← AfriLink runs here

  ┌─────────────────────────┬──────────────────────────────────────┐
  │ Component               │ Specification                        │
  ├─────────────────────────┼──────────────────────────────────────┤
  │ GPU per node            │ 4× NVIDIA A100 (customised)          │
  │ GPU memory              │ 64 GB HBM2e per GPU (256 GB / node)  │
  │ FP64 performance        │ 11.2 TFLOPS per GPU                  │
  │ FP32 performance        │ 22.4 TFLOPS per GPU                  │
  │ CPU cores per node      │ 32                                   │
  │ System RAM per node     │ 512 GB DDR4                          │
  │ RAM per GPU (effective) │ ~128 GB (shared, not partitioned)    │
  │ Node interconnect       │ 200 Gb/s HDR InfiniBand              │
  │ SLURM partition         │ boost_usr_prod                       │
  │ SLURM account           │ aih4a_dataspire                      │
  └─────────────────────────┴──────────────────────────────────────┘

  {_c("bold", "CPU NODE (DCGP partition)")} ← not used by AfriLink jobs

  ┌─────────────────────────┬──────────────────────────────────────┐
  │ GPU                     │ None                                 │
  │ CPU cores per node      │ 112                                  │
  │ System RAM per node     │ 512 GB DDR5                          │
  │ Node interconnect       │ 100 Gb/s                             │
  └─────────────────────────┴──────────────────────────────────────┘

  {_c("bold", "Per-GPU memory guide for model loading")}

  ┌──────────────────┬──────────────────┬──────────────────────────┐
  │ Model            │ Training mode    │ Min GPUs recommended     │
  ├──────────────────┼──────────────────┼──────────────────────────┤
  │ 0.5B – 1B        │ low (QLoRA 4-bit)│ 1                        │
  │ 3B – 7B          │ low              │ 1                        │
  │ 3B – 7B          │ high (bf16)      │ 2–4                      │
  │ 13B              │ low              │ 2                        │
  │ 13B              │ high             │ 4                        │
  │ 30B+             │ low              │ 4                        │
  └──────────────────┴──────────────────┴──────────────────────────┘

  {_c("bold", "Billing rate")}
    $2.00 / GPU-hour   (charged per completed GPU-minute, minimum 1 min)
    Credits are deducted automatically from your DataSpires balance.

  Run {_c("yellow", "afrilink/billing")} for credit management.
  Run {_c("yellow", "afrilink/training")} for mode recommendations.
"""

# ── /billing ──────────────────────────────────────────────────────────────────
PAGES["billing"] = f"""
{_c("bold", "Billing — credits, invoices & vouchers")}
{_c("dim", "─" * 60)}

  {_c("bold", "Rate")}
    $2.00 / GPU-hour
    Billed per completed job (wall-clock elapsed, minimum 1 min).
    A 1-hour job on 4 GPUs costs $8.00.

  {_c("bold", "Credit balance")}
    View in the DataSpires dashboard → Billing page, or via:
    {_c("cyan", "client._dataspires_auth.balance_usd")}

  {_c("bold", "Adding credits")}
    Use a payment card or voucher code on the DataSpires Billing page.
    Vouchers add AfriLink-specific credits, not general USD credits.

  {_c("bold", "Invoices")}
    Auto-generated per job. Visible in the Billing → Invoices section.
    Exportable as CSV or PDF from the dashboard.

  {_c("bold", "Insufficient balance")}
    If your balance drops below the estimated job cost you will see
    a warning before submission. Top up credits on the billing page.

  Run {_c("yellow", "afrilink/vouchers")} for voucher code details.
  Run {_c("yellow", "afrilink/specs")} for the rate breakdown.
"""

# ── /vouchers ─────────────────────────────────────────────────────────────────
PAGES["vouchers"] = f"""
{_c("bold", "Vouchers — AfriLink credit codes")}
{_c("dim", "─" * 60)}

  Voucher codes add {_c("yellow", "AfriLink credits")} to your account.
  These are separate from USD card-payment credits and are
  deducted first when you run AfriLink jobs.

  {_c("bold", "Code format")}
    XXXX-XXXX-XXXX-XXXX   (16 hex chars, dash-separated)
    Example: 0064-2A1F-C3D4-89AB

    First 4 chars of raw code  →  credit amount in hex (USD cents)
    Chars 5–12                 →  random entropy
    Last 4 chars               →  HMAC-SHA256 verification tag

  {_c("bold", "Redeeming a voucher")}
    Option A — Dashboard:
      DataSpires → Billing → Vouchers → enter code → Apply

    Option B — SDK:
      Vouchers are redeemed through the dashboard UI only.
      The SDK reads your balance automatically after redemption.

  {_c("bold", "One-time use")}
    Each code can only be redeemed once. Attempting to reuse a
    code returns "Voucher already redeemed".

  {_c("bold", "Voucher credits vs USD credits")}
    AfriLink credits (from vouchers):  deducted for CINECA GPU jobs
    USD credits (from card payments):  deducted for API / other usage
    The billing page shows both balances separately.
"""

# ── /inference ────────────────────────────────────────────────────────────────
PAGES["inference"] = f"""
{_c("bold", "inference() — Route inference to HuggingFace endpoints")}
{_c("dim", "─" * 60)}

  {_c("cyan", "result = client.inference(")}
  {_c("cyan", "    prompt       = 'Your prompt here',")}
  {_c("cyan", "    model_id     = 'HuggingFaceH4/zephyr-7b-beta',")}
  {_c("cyan", "    hf_token     = 'hf_...',   # optional for public models")}
  {_c("cyan", "    parameters   = {{'max_new_tokens': 256, 'temperature': 0.7}},")}
  {_c("cyan", ")")}
  {_c("cyan", "print(result.text)")}

  The SDK forwards the request to HuggingFace — CINECA is {_c("yellow", "not")} involved.
  Any model on the HuggingFace Hub with inference enabled can be used.
  DataSpires authentication is still required so usage is tracked.

  {_c("bold", "Parameters")}

    prompt        Text prompt for generation (wrapped into standard HF payload).
    model_id      HuggingFace model ID — e.g. "meta-llama/Llama-2-7b-chat-hf".
                  Routes to api-inference.huggingface.co/models/<id>.
    payload       Fully custom request body (dict). Overrides prompt= when given.
    endpoint_url  Private HF Inference Endpoint URL. Takes precedence over model_id.
    hf_token      HuggingFace token. Required for gated models (Llama-2, Gemma etc.).
                  Free public models work without a token (rate-limited).
    parameters    Generation parameter dict, e.g.:
                    {_c("cyan", "{{'max_new_tokens': 256, 'temperature': 0.7, 'top_p': 0.9}}")}
                  Ignored when payload= is given directly.
    timeout       Request timeout in seconds (default 120).

  {_c("bold", "Returns: InferenceResult")}

    result.text         Generated text string (first result)
    result.raw          Full decoded JSON response from HuggingFace
    result.status_code  HTTP status code
    result.success      True if status_code < 400
    result.error        Error message string, or None

  {_c("bold", "Examples")}

  Public model (no token):
    {_c("cyan", "result = client.inference(")}
    {_c("cyan", "    'What is a transformer?',")}
    {_c("cyan", "    model_id='HuggingFaceH4/zephyr-7b-beta',")}
    {_c("cyan", ")")}
    {_c("cyan", "print(result.text)")}

  Gated model with HF token:
    {_c("cyan", "result = client.inference(")}
    {_c("cyan", "    'Summarise the history of machine learning.',")}
    {_c("cyan", "    model_id='meta-llama/Llama-2-7b-chat-hf',")}
    {_c("cyan", "    hf_token='hf_...',")}
    {_c("cyan", "    parameters={{'max_new_tokens': 300, 'temperature': 0.8}},")}
    {_c("cyan", ")")}

  Private endpoint:
    {_c("cyan", "result = client.inference(")}
    {_c("cyan", "    payload={{'inputs': 'Hello world!'}},")}
    {_c("cyan", "    endpoint_url='https://xyz.endpoints.huggingface.cloud',")}
    {_c("cyan", "    hf_token='hf_...',")}
    {_c("cyan", ")")}

  Your own finetuned model (uploaded to HF Hub):
    {_c("cyan", "result = client.inference(")}
    {_c("cyan", "    'Explain gradient descent.',")}
    {_c("cyan", "    model_id='your-org/your-finetuned-model',")}
    {_c("cyan", "    hf_token='hf_...', # needed if model is private")}
    {_c("cyan", ")")}

  {_c("bold", "HuggingFace token")}
    Get a free token at https://huggingface.co/settings/tokens
    For gated models (Llama-2, Gemma, Mistral-v0.2) you also need to
    accept the model's terms of use on the model card page on HF Hub.

  {_c("bold", "Rate limits")}
    Without a token:  ~10 requests/minute (Inference API free tier).
    With a free token: ~100 requests/minute.
    With a PRO/paid token or private endpoint: no shared rate limit.

  Run {_c("yellow", "afrilink/models")}    to see finetunable models.
  Run {_c("yellow", "afrilink/download")}  for loading weights locally with transformers.
"""

# ── /geofence ─────────────────────────────────────────────────────────────────
PAGES["geofence"] = f"""
{_c("bold", "Geofence — Geographic access policy")}
{_c("dim", "─" * 60)}

  AfriLink SDK includes IP-based geofencing.
  Access is restricted to users physically located in {_c("green", "Africa")}.

  {_c("bold", "How it works")}
    At authenticate() time, the SDK queries your public IP against
    three free geolocation APIs (ip-api.com, ipapi.co, ipinfo.io).
    If all three agree you are outside Africa the request is blocked.
    If the APIs are unreachable the check fails open (access is allowed)
    to avoid blocking legitimate users during network issues.

  {_c("bold", "Covered countries")}
    All 57 African ISO 3166-1 alpha-2 countries, including:
    NG, ZA, KE, EG, ET, GH, TZ, RW, CM, CI, SN, UG, MZ, AO, MA …

  {_c("bold", "Bypass (dev / CI only)")}
    Set the environment variable before importing afrilink:
    {_c("cyan", "import os; os.environ['AFRILINK_SKIP_GEOFENCE'] = '1'")}
    Do not use in production user-facing environments.

  {_c("bold", "Error message")}
    GeofenceError: Access restricted to users in Africa.
    (Your detected location: US / North America)
    Contact support@dataspires.com if you believe this is incorrect.
"""

# ── /config ───────────────────────────────────────────────────────────────────
PAGES["config"] = f"""
{_c("bold", "ClientConfig — configuration reference")}
{_c("dim", "─" * 60)}

  {_c("bold", "Create the config")}
    {_c("cyan", "from afrilink import ClientConfig")}
    {_c("cyan", "config = ClientConfig.from_env()          # reads env vars")}
    {_c("cyan", "config = ClientConfig.from_colab_secrets() # reads Colab secrets")}
    {_c("cyan", "client = AfriLinkClient(config)")}

  {_c("bold", "Fields and their environment variables")}

    Field                    Env variable               Default
    ──────────────────────────────────────────────────────────────────
    cineca_username          CINECA_USERNAME             iomunga0
    cineca_email             CINECA_EMAIL
    cineca_password          CINECA_PASSWORD
    cineca_totp_seed         CINECA_TOTP_SEED
    dataspires_email         DATASPIRES_EMAIL
    dataspires_password      DATASPIRES_PASSWORD
    supabase_url             SUPABASE_URL
    supabase_key             SUPABASE_SERVICE_KEY
    slurm_account            SLURM_ACCOUNT               aih4a_dataspire
    slurm_partition          SLURM_PARTITION             boost_usr_prod
    work_dir                                             $WORK

  {_c("bold", "Setting env vars in a notebook")}
    {_c("cyan", "import os")}
    {_c("cyan", "os.environ['CINECA_EMAIL']    = 'you@university.it'")}
    {_c("cyan", "os.environ['CINECA_PASSWORD'] = 'secret'")}
    {_c("cyan", "os.environ['CINECA_TOTP_SEED']= 'BASE32SEED...'")}
    {_c("cyan", "os.environ['DATASPIRES_EMAIL']= 'you@example.com'")}
    {_c("cyan", "os.environ['DATASPIRES_PASSWORD'] = 'secret'")}

  {_c("bold", "Colab secrets (recommended for Colab users)")}
    In Colab: Tools → Secrets → add key/value pairs with the names
    above. ClientConfig.from_colab_secrets() reads them automatically.
"""

# ── /version ──────────────────────────────────────────────────────────────────
def _version_page() -> str:
    try:
        from afrilink import __version__
        ver = __version__
    except Exception:
        ver = "unknown"
    return f"""
{_c("bold", "AfriLink SDK version")}
{_c("dim", "─" * 60)}

  Installed:   {_c("green", ver)}
  PyPI:        https://pypi.org/project/afrilink-sdk/
  Changelog:   see afrilinkSOP.md (section 12)

  {_c("bold", "Check for updates")}
    {_c("cyan", "!pip install afrilink-sdk --upgrade")}

  {_c("bold", "Report issues")}
    Email:   support@dataspires.com
    Docs:    https://dataspires.com
"""

PAGES["version"] = ""  # filled dynamically below


# ─── Slash-command dispatcher ─────────────────────────────────────────────────

class _HelpDispatcher:
    """
    Implements the afrilink/<topic> slash syntax by overriding __truediv__.

    When Python evaluates  afrilink / "specs"  it calls
    afrilink.__truediv__("specs"), which is wired to this class.
    """

    _ALIASES: dict[str, str] = {
        "auth":       "authenticate",
        "login":      "authenticate",
        "ft":         "finetune",
        "train":      "finetune",
        "training":   "training",
        "mode":       "training",
        "modes":      "training",
        "model":      "models",
        "dataset":    "datasets",
        "data":       "datasets",
        "job":        "jobs",
        "cancel":     "jobs",
        "dl":         "download",
        "weights":    "download",
        "scp":        "transfer",
        "upload":     "transfer",
        "session":    "recover",
        "recovery":   "recover",
        "reauth":     "recover",
        "ssh":        "ssh",
        "cmd":        "ssh",
        "gpu":        "specs",
        "hardware":   "specs",
        "a100":       "specs",
        "cineca":     "specs",
        "credits":    "billing",
        "invoice":    "billing",
        "invoices":   "billing",
        "voucher":    "vouchers",
        "code":       "vouchers",
        "geo":        "geofence",
        "africa":     "geofence",
        "cfg":        "config",
        "env":        "config",
        "watchdog":   "watchdog",
        "daemon":     "watchdog",
        "expiry":     "watchdog",
        "backend":    "backends",
        "cluster":    "backends",
        "infer":      "inference",
        "hf":         "inference",
        "predict":    "inference",
        "generate":   "inference",
        "endpoint":   "inference",
        "v":          "version",
        "ver":        "version",
    }

    def __call__(self, topic: str = "help"):
        """Direct call: afrilink.help('topic')"""
        self._show(topic)

    def __truediv__(self, topic: str):
        """Division syntax: afrilink / 'topic'"""
        self._show(str(topic))
        return self

    def _show(self, topic: str):
        topic = topic.strip().lower().lstrip("/")
        topic = self._ALIASES.get(topic, topic)
        if topic == "version":
            print(_version_page())
            return
        if topic not in PAGES:
            self._unknown(topic)
            return
        print(PAGES[topic])

    def _unknown(self, topic: str):
        keys = sorted(set(PAGES.keys()) | set(self._ALIASES.keys()))
        suggestions = [k for k in keys if k.startswith(topic[:3])][:5]
        msg = f"\n{_c('red', 'Unknown topic:')} {topic}\n"
        if suggestions:
            msg += f"  Did you mean: {', '.join(suggestions)}\n"
        msg += f"\n  Run {_c('cyan', 'afrilink/help')} for the full topic list.\n"
        print(msg)

    def __repr__(self) -> str:
        return (
            f"AfriLink help system — run {_c('cyan', 'afrilink/help')} for the topic index, "
            f"or {_c('cyan', 'afrilink/<topic>')} for a specific page."
        )


# Singleton exposed at package level
help_system = _HelpDispatcher()
