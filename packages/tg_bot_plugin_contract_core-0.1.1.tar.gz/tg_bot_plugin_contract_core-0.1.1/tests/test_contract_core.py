from __future__ import annotations

import json
from pathlib import Path

import pytest

from tg_bot_plugin_contract_core import (
    ContractCoreError,
    SignerIdentity,
    compute_artifact_digest,
    compute_package_sha256,
    inspect_bundle,
    match_signer_identity,
    validate_bundle_target_profile,
    verify_bundle,
    write_reproducible_bundle,
)
from tg_bot_plugin_contract_core import core as core_module


def _manifest_payload(*, artifact_digest: str = "", runtime_profile_id: str = "cpython-3.13-linux-x86_64-gnu") -> dict[str, object]:
    return {
        "plugin_id": "demo",
        "plugin_version": "1.2.3",
        "name": "demo",
        "description": "demo plugin",
        "category": "utility",
        "runtime_profile_id": runtime_profile_id,
        "artifact_digest": artifact_digest,
        "entrypoint": {"module_path": "__init__", "symbol": "DemoPlugin"},
        "config_schema": {},
        "interaction_schema": {},
        "declared_scopes": [],
        "declared_capabilities": [],
    }


def _write_manifest(plugin_dir: Path, payload: dict[str, object]) -> None:
    (plugin_dir / "manifest.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _stage_plugin_tree(
    root: Path,
    *,
    include_signature_bundle: bool,
    runtime_profile_id: str = "cpython-3.13-linux-x86_64-gnu",
) -> Path:
    plugin_dir = root / "demo"
    plugin_dir.mkdir(parents=True, exist_ok=True)
    (plugin_dir / "__init__.py").write_text(
        "class DemoPlugin:\n"
        "    pass\n",
        encoding="utf-8",
    )
    (plugin_dir / "data.json").write_text('{"hello":"world"}\n', encoding="utf-8")
    (plugin_dir / "native.so").write_bytes(b"binary-plugin")
    meta_inf_dir = plugin_dir / "META-INF"
    meta_inf_dir.mkdir(parents=True, exist_ok=True)
    if include_signature_bundle:
        (meta_inf_dir / "sigstore.bundle.json").write_text("{}", encoding="utf-8")
    (meta_inf_dir / "sbom.json").write_text('{"bom":"ignored"}', encoding="utf-8")
    manifest_payload = _manifest_payload(runtime_profile_id=runtime_profile_id)
    _write_manifest(plugin_dir, manifest_payload)
    artifact_digest = compute_artifact_digest(plugin_dir, manifest_payload)
    manifest_payload["artifact_digest"] = artifact_digest
    _write_manifest(plugin_dir, manifest_payload)
    return plugin_dir


def test_compute_artifact_digest_ignores_signature_material(tmp_path: Path):
    plugin_dir = _stage_plugin_tree(tmp_path, include_signature_bundle=True)
    manifest_payload = json.loads((plugin_dir / "manifest.json").read_text(encoding="utf-8"))

    digest_before = compute_artifact_digest(plugin_dir, manifest_payload)
    (plugin_dir / "META-INF" / "sigstore.bundle.json").write_text('{"changed":true}', encoding="utf-8")
    (plugin_dir / "META-INF" / "sbom.json").write_text('{"changed":true}', encoding="utf-8")
    digest_after = compute_artifact_digest(plugin_dir, manifest_payload)

    assert digest_before == digest_after


def test_write_reproducible_bundle_is_byte_stable(tmp_path: Path):
    plugin_dir = _stage_plugin_tree(tmp_path, include_signature_bundle=True)
    bundle_a = tmp_path / "dist" / "demo-a.tgpkg"
    bundle_b = tmp_path / "dist" / "demo-b.tgpkg"

    write_reproducible_bundle(plugin_dir, bundle_a)
    write_reproducible_bundle(plugin_dir, bundle_b)

    assert bundle_a.read_bytes() == bundle_b.read_bytes()
    assert compute_package_sha256(bundle_a) == compute_package_sha256(bundle_b)


def test_inspect_bundle_reads_manifest_and_digest(tmp_path: Path):
    plugin_dir = _stage_plugin_tree(tmp_path, include_signature_bundle=True)
    bundle_path = tmp_path / "dist" / "demo.tgpkg"
    write_reproducible_bundle(plugin_dir, bundle_path)

    inspection = inspect_bundle(bundle_path)

    assert inspection.plugin_id == "demo"
    assert inspection.plugin_version == "1.2.3"
    assert inspection.signature_bundle_present is True
    assert inspection.signature_bundle_path == "META-INF/sigstore.bundle.json"
    assert inspection.entrypoint_relpath == "__init__.py"
    assert inspection.package_sha256 == compute_package_sha256(bundle_path)
    assert "manifest.json" in inspection.archive_entries


def test_match_signer_identity_matches_active_rule():
    identity = SignerIdentity(
        issuer="https://token.actions.githubusercontent.com",
        repository_owner="Fire-Dragons",
        repository_name="demo",
        workflow_ref="Fire-Dragons/demo/.github/workflows/release.yml@refs/heads/main",
        reusable_workflow_ref="Fire-Dragons/tg-bot-plugin-buildkit/.github/workflows/release-plugin.yml@refs/tags/v1",
        ref="refs/tags/v1.2.3",
    )

    result = match_signer_identity(
        identity,
        trusted_signer_rules=[
            {
                "rule_id": "disabled-rule",
                "issuer": "https://token.actions.githubusercontent.com",
                "repository_owner": "Fire-Dragons",
                "repository_name": "demo",
                "workflow_ref": "Fire-Dragons/demo/.github/workflows/release.yml@refs/heads/main",
                "reusable_workflow_ref": "Fire-Dragons/tg-bot-plugin-buildkit/.github/workflows/release-plugin.yml@refs/tags/v1",
                "ref_pattern": "refs/tags/v*",
                "status": "disabled",
            },
            {
                "rule_id": "github-release-main",
                "issuer": "https://token.actions.githubusercontent.com",
                "repository_owner": "Fire-Dragons",
                "repository_name": "demo",
                "workflow_ref": "Fire-Dragons/demo/.github/workflows/release.yml@refs/heads/main",
                "reusable_workflow_ref": "Fire-Dragons/tg-bot-plugin-buildkit/.github/workflows/release-plugin.yml@refs/tags/v1",
                "ref_pattern": "refs/tags/v*",
                "status": "active",
            },
        ],
    )

    assert result.matched is True
    assert result.matched_rule_id == "github-release-main"
    assert result.reason == "matched"
    assert result.signer_identity_text.startswith("issuer=https://token.actions.githubusercontent.com")


def test_match_signer_identity_rejects_invalid_rule_schema():
    identity = SignerIdentity(
        issuer="https://token.actions.githubusercontent.com",
        repository_owner="Fire-Dragons",
        repository_name="demo",
        workflow_ref="Fire-Dragons/demo/.github/workflows/release.yml@refs/heads/main",
        reusable_workflow_ref="Fire-Dragons/tg-bot-plugin-buildkit/.github/workflows/release-plugin.yml@refs/tags/v1",
        ref="refs/tags/v1.2.3",
    )

    with pytest.raises(ContractCoreError) as exc_info:
        match_signer_identity(
            identity,
            trusted_signer_rules=[
                {
                    "rule_id": "invalid-rule",
                    "issuer": "https://token.actions.githubusercontent.com",
                    "repository_owner": "Fire-Dragons",
                    "repository_name": "demo",
                    "workflow_ref": "Fire-Dragons/demo/.github/workflows/release.yml@refs/heads/main",
                    "reusable_workflow_ref": "Fire-Dragons/tg-bot-plugin-buildkit/.github/workflows/release-plugin.yml@refs/tags/v1",
                    "ref_pattern": "main",
                    "status": "active",
                }
            ],
        )

    assert exc_info.value.code == "trusted_signer_rule_invalid"


def test_verify_bundle_allows_dev_unsigned(tmp_path: Path):
    plugin_dir = _stage_plugin_tree(tmp_path, include_signature_bundle=False)
    bundle_path = tmp_path / "dist" / "demo.tgpkg"
    write_reproducible_bundle(plugin_dir, bundle_path)

    result = verify_bundle(bundle_path, allow_unsigned_dev=True)

    assert result.signature_verification_status == "unsigned_dev"
    assert result.signer_identity is None


def test_verify_bundle_uses_sigstore_verifier(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    plugin_dir = _stage_plugin_tree(tmp_path, include_signature_bundle=True)
    bundle_path = tmp_path / "dist" / "demo.tgpkg"
    write_reproducible_bundle(plugin_dir, bundle_path)
    expected_identity = SignerIdentity(
        issuer="https://token.actions.githubusercontent.com",
        repository_owner="Fire-Dragons",
        repository_name="demo",
        workflow_ref="Fire-Dragons/demo/.github/workflows/release.yml@refs/heads/main",
        reusable_workflow_ref="Fire-Dragons/tg-bot-plugin-buildkit/.github/workflows/release-plugin.yml@refs/tags/v1",
        ref="refs/tags/v1.2.3",
    )
    monkeypatch.setattr(core_module, "_verify_sigstore_bundle", lambda *args, **kwargs: expected_identity)

    result = verify_bundle(bundle_path)

    assert result.signature_verification_status == "verified"
    assert result.signer_identity == expected_identity


def test_validate_bundle_target_profile_rejects_runtime_mismatch(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
):
    plugin_dir = _stage_plugin_tree(tmp_path, include_signature_bundle=True)
    bundle_path = tmp_path / "dist" / "demo.tgpkg"
    write_reproducible_bundle(plugin_dir, bundle_path)
    monkeypatch.setattr(
        core_module,
        "_verify_sigstore_bundle",
        lambda *args, **kwargs: SignerIdentity(
            issuer="https://token.actions.githubusercontent.com",
            repository_owner="Fire-Dragons",
            repository_name="demo",
            workflow_ref="Fire-Dragons/demo/.github/workflows/release.yml@refs/heads/main",
            reusable_workflow_ref="Fire-Dragons/tg-bot-plugin-buildkit/.github/workflows/release-plugin.yml@refs/tags/v1",
            ref="refs/tags/v1.2.3",
        ),
    )

    with pytest.raises(ContractCoreError) as exc_info:
        validate_bundle_target_profile(
            bundle_path,
            target_runtime_profile_id="cpython-3.13-linux-arm64-gnu",
        )

    assert exc_info.value.code == "runtime_profile_mismatch"
