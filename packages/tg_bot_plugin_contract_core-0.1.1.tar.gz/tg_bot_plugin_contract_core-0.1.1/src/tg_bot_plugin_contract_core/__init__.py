"""TG-BOT 插件 bundle 的共享正式合同辅助接口。"""

from .core import (
    compute_artifact_digest,
    compute_package_sha256,
    inspect_bundle,
    match_signer_identity,
    validate_bundle_same_profile,
    validate_bundle_target_profile,
    verify_bundle,
    write_reproducible_bundle,
)
from .errors import ContractCoreError
from .models import (
    ArtifactDescriptor,
    BundleInspectionResult,
    BundleVerificationResult,
    PluginManifest,
    SignerIdentity,
    SignerIdentityMatchResult,
)

__all__ = [
    "ArtifactDescriptor",
    "BundleInspectionResult",
    "BundleVerificationResult",
    "ContractCoreError",
    "PluginManifest",
    "SignerIdentity",
    "SignerIdentityMatchResult",
    "compute_artifact_digest",
    "compute_package_sha256",
    "inspect_bundle",
    "match_signer_identity",
    "validate_bundle_same_profile",
    "validate_bundle_target_profile",
    "verify_bundle",
    "write_reproducible_bundle",
]
