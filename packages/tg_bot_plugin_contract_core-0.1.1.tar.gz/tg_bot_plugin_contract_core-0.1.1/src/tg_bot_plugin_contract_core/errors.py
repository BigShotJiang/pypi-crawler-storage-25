"""TG-BOT 插件合同校验使用的错误类型。"""

from __future__ import annotations


class ContractCoreError(ValueError):
    """带稳定机器可读错误码的结构化校验异常。"""

    def __init__(self, code: str, message: str) -> None:
        self.code = str(code or "").strip() or "contract_core_error"
        super().__init__(message)
