"""TG-BOT 插件合同辅助层对外暴露的数据模型。"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True, slots=True)
class PluginManifest:
    plugin_id: str
    plugin_version: str
    name: str
    description: str
    category: str
    runtime_profile_id: str
    artifact_digest: str
    entrypoint: dict[str, str]
    config_schema: dict[str, Any]
    interaction_schema: dict[str, Any]
    declared_scopes: list[Any]
    declared_capabilities: list[Any]
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class ArtifactDescriptor:
    manifest_normalized: dict[str, Any]
    files: tuple[dict[str, Any], ...]


@dataclass(frozen=True, slots=True)
class SignerIdentity:
    issuer: str
    repository_owner: str
    repository_name: str
    workflow_ref: str
    reusable_workflow_ref: str
    ref: str

    def persistent_value(self) -> str:
        return (
            f"issuer={self.issuer},"
            f"repo={self.repository_owner}/{self.repository_name},"
            f"workflow_ref={self.workflow_ref},"
            f"reusable_workflow_ref={self.reusable_workflow_ref},"
            f"ref={self.ref}"
        )


@dataclass(frozen=True, slots=True)
class BundleInspectionResult:
    bundle_path: Path
    bundle_name: str
    plugin_id: str
    plugin_version: str
    runtime_profile_id: str
    artifact_digest: str
    package_sha256: str
    manifest: PluginManifest
    artifact_descriptor: ArtifactDescriptor
    archive_entries: tuple[str, ...]
    entrypoint_relpath: str
    signature_bundle_path: str
    signature_bundle_present: bool


@dataclass(frozen=True, slots=True)
class BundleVerificationResult:
    inspection: BundleInspectionResult
    signer_identity: SignerIdentity | None
    signature_verification_status: str

    @property
    def plugin_id(self) -> str:
        return self.inspection.plugin_id

    @property
    def plugin_version(self) -> str:
        return self.inspection.plugin_version

    @property
    def runtime_profile_id(self) -> str:
        return self.inspection.runtime_profile_id

    @property
    def artifact_digest(self) -> str:
        return self.inspection.artifact_digest

    @property
    def package_sha256(self) -> str:
        return self.inspection.package_sha256


@dataclass(frozen=True, slots=True)
class SignerIdentityMatchResult:
    signer_identity: SignerIdentity | None
    matched: bool
    matched_rule_id: str
    signer_identity_text: str
    reason: str
