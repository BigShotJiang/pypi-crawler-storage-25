#!/usr/bin/env python3
"""校验 Git tag 与 pyproject 中的项目版本一致。"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import tomllib


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="校验 release tag 与项目版本是否一致。")
    parser.add_argument("--tag", required=True, help="例如 v0.1.0")
    parser.add_argument(
        "--project-root",
        default=".",
        help="包含 pyproject.toml 的项目根目录。",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    project_root = Path(args.project_root).expanduser().resolve()
    pyproject_path = project_root / "pyproject.toml"
    tag = str(args.tag or "").strip()
    expected_prefix = "v"

    if not pyproject_path.is_file():
        print(f"missing pyproject.toml: {pyproject_path}", file=sys.stderr)
        return 1
    if not tag.startswith(expected_prefix):
        print(f"release tag must start with '{expected_prefix}': {tag}", file=sys.stderr)
        return 1

    payload = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    project_version = str(payload.get("project", {}).get("version", "")).strip()
    tag_version = tag[len(expected_prefix):]
    if project_version == "":
        print("project.version is missing in pyproject.toml", file=sys.stderr)
        return 1
    if project_version != tag_version:
        print(
            f"release tag mismatch: tag={tag_version}, project.version={project_version}",
            file=sys.stderr,
        )
        return 1

    print(f"release tag matches project version: {project_version}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
