"""Dataset generation components."""
