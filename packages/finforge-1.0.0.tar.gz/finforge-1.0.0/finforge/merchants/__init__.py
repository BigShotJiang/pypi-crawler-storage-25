"""Merchant catalog components."""
