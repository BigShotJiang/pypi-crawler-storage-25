from __future__ import annotations

import json
import subprocess
from pathlib import Path

from rich.console import Console
from typer.testing import CliRunner

from rpr.cli import app
from rpr.dependencies import (
    ROOT_STORYBOOK_DEV_DEPENDENCIES,
    STORYBOOK_DEV_DEPENDENCIES,
    storybook_package_dependencies,
)


runner = CliRunner()


def _completed(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")


def _write_ui_package(path: Path, *, with_project_json: bool = True) -> None:
    path.mkdir(parents=True, exist_ok=True)
    if with_project_json:
        (path / "project.json").write_text('{"name": "' + path.name + '"}\n')
    else:
        (path / "package.json").write_text('{"name": "@repo/' + path.name + '"}\n')


def test_generate_storybook_requires_ui_library(monkeypatch):
    monkeypatch.setattr(
        "rpr.commands.generate.storybook.console",
        Console(highlight=False, no_color=True),
    )

    with runner.isolated_filesystem():
        result = runner.invoke(app, ["generate", "storybook"])

        assert result.exit_code == 1
        assert (
            "[rpr] Error: No UI library found at packages/node/*-ui/. "
            "Run `rpr generate ui <name>` first."
        ) in result.stdout


def test_generate_storybook_scaffolds_host_package_and_starter_story(monkeypatch):
    recorded_calls: list[dict[str, object]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append(
            {
                "cmd": cmd,
                "cwd": cwd,
                "supports_dry_run": supports_dry_run,
            }
        )
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)

    with runner.isolated_filesystem():
        _write_ui_package(Path("packages/node/my-app-ui"))

        result = runner.invoke(app, ["generate", "storybook"])
        assert result.exit_code == 0, result.stdout

        root_package = json.loads(Path("package.json").read_text())
        sb_package = json.loads(Path("packages/node/sb/package.json").read_text())
        sb_project = json.loads(Path("packages/node/sb/project.json").read_text())
        sb_main = Path("packages/node/sb/.storybook/main.ts").read_text()
        sb_preview = Path("packages/node/sb/.storybook/preview.ts").read_text()
        starter_story = Path(
            "packages/node/my-app-ui/src/stories/Example.stories.tsx"
        ).read_text()

        assert root_package["workspaces"] == ["apps/*", "packages/node/*"]
        assert (
            root_package["devDependencies"]["@nx/storybook"]
            == ROOT_STORYBOOK_DEV_DEPENDENCIES["@nx/storybook"]
        )
        assert sb_package["dependencies"]["@repo/my-app-ui"] == "workspace:*"
        assert (
            sb_package["dependencies"]["@mui/material"]
            == storybook_package_dependencies("my-app-ui")["@mui/material"]
        )
        assert sb_project["targets"]["storybook"]["options"]["command"] == (
            "storybook dev -p 6006 -c packages/node/sb/.storybook"
        )
        assert sb_project["targets"]["build-storybook"]["options"]["command"] == (
            "storybook build -c packages/node/sb/.storybook -o dist/storybook"
        )
        assert "../../my-app-ui/src/**/*.stories.@(ts|tsx)" in sb_main
        assert "@storybook/addon-essentials" in sb_main
        assert "ThemeProvider" in sb_preview
        assert 'import { appTheme } from "@repo/my-app-ui";' in sb_preview
        assert "createTheme" not in sb_preview
        assert 'title: "my-app-ui/Example"' in starter_story
        assert 'import { uiPackageName } from "../index";' in starter_story
        assert not Path("packages/node/sb/stories/Example.stories.tsx").exists()
        assert "Run with: npx nx storybook sb" in result.stdout

        assert recorded_calls == [
            {"cmd": ["npm", "install"], "cwd": Path.cwd(), "supports_dry_run": False},
            {
                "cmd": [
                    "npx",
                    "nx",
                    "g",
                    "@nx/storybook:configuration",
                    "--project=sb",
                    "--uiFramework=@storybook/react-vite",
                    "--interactionTests=true",
                ],
                "cwd": Path.cwd(),
                "supports_dry_run": True,
            },
        ]

        assert Path("packages/node/sb/src/App.tsx").exists()
        assert Path("packages/node/sb/src/App.test.ts").exists()
        assert Path("packages/node/sb/vite.config.ts").exists()


def test_generate_storybook_prompts_for_target_ui_library(monkeypatch):
    recorded_calls: list[list[str]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append(cmd)
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr("typer.prompt", lambda *args, **kwargs: "2")

    with runner.isolated_filesystem():
        _write_ui_package(Path("packages/node/admin-ui"))
        _write_ui_package(Path("packages/node/storefront-ui"), with_project_json=False)

        result = runner.invoke(app, ["generate", "storybook"])
        assert result.exit_code == 0, result.stdout

        assert [
            "npx",
            "nx",
            "g",
            "@nx/storybook:configuration",
            "--project=sb",
            "--uiFramework=@storybook/react-vite",
            "--interactionTests=true",
        ] in recorded_calls
        assert Path(
            "packages/node/storefront-ui/src/stories/Example.stories.tsx"
        ).exists()
        assert not Path(
            "packages/node/admin-ui/src/stories/Example.stories.tsx"
        ).exists()


def test_generate_storybook_dry_run_previews_files_and_forwards_nx_dry_run(
    monkeypatch, capsys
):
    recorded_calls: list[dict[str, object]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append(
            {
                "cmd": cmd,
                "supports_dry_run": supports_dry_run,
            }
        )
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr("rpr.context.console", Console(highlight=False, no_color=True))
    monkeypatch.setattr(
        "rpr.commands.generate.storybook.console",
        Console(highlight=False, no_color=True),
    )

    with runner.isolated_filesystem():
        _write_ui_package(Path("packages/node/my-app-ui"))

        result = runner.invoke(app, ["generate", "storybook", "--dry-run"])
        assert result.exit_code == 0, result.stdout

        output = result.stdout + capsys.readouterr().out

        assert "DRY RUN" in output
        assert "packages/node/sb/package.json" in output
        assert "packages/node/sb/project.json" in output
        assert "packages/node/sb/.storybook/main.ts" in output
        assert "packages/node/my-app-ui/src/stories/Example.stories.tsx" in output
        assert "Would install npm dependencies for workspace root" in output
        assert "dev=[@nx/storybook]" in output
        assert "Would install npm dependencies for packages/node/sb" in output
        assert "runtime=[@repo/my-app-ui, @emotion/react, @emotion/styled, @mui/material, react, react-dom]" in output
        assert not Path("package.json").exists()
        assert not Path("packages/node/sb").exists()
        assert not Path(
            "packages/node/my-app-ui/src/stories/Example.stories.tsx"
        ).exists()
        assert STORYBOOK_DEV_DEPENDENCIES["vite"] == "^8"
        assert recorded_calls == [
            {
                "cmd": [
                    "npx",
                    "nx",
                    "g",
                    "@nx/storybook:configuration",
                    "--project=sb",
                    "--uiFramework=@storybook/react-vite",
                    "--interactionTests=true",
                ],
                "supports_dry_run": True,
            }
        ]
