from __future__ import annotations

import json
import subprocess
from pathlib import Path

from rich.console import Console
from typer.testing import CliRunner

from rpr.cli import app
from rpr.dependencies import MATURIN_SPEC, PYO3_VERSION


runner = CliRunner()


def _completed(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")


def _write_root_pyproject() -> None:
    Path("pyproject.toml").write_text(
        """[project]
name = "workspace"
version = "0.0.0"
requires-python = ">=3.12"
dependencies = []

[tool.uv.workspace]
members = []
"""
    )


def test_generate_engine_scaffolds_rust_python_and_nx_metadata():
    recorded_calls: list[tuple[list[str], Path | str | None]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append((cmd, cwd))
        return _completed(cmd)

    monkeypatch = __import__("pytest").MonkeyPatch()
    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)

    with runner.isolated_filesystem():
        _write_root_pyproject()

        result = runner.invoke(app, ["generate", "engine", "my-app"])
        assert result.exit_code == 0, result.stdout

        engine_root = Path("packages/python/my-app-engine")
        cargo_toml = (engine_root / "Cargo.toml").read_text()
        lib_rs = (engine_root / "src/lib.rs").read_text()
        engine_pyproject = (engine_root / "pyproject.toml").read_text()
        stub_file = (engine_root / "my_app_engine.pyi").read_text()
        project_json = json.loads((engine_root / "project.json").read_text())
        root_pyproject = Path("pyproject.toml").read_text()

        assert engine_root.exists()
        assert 'name = "my-app-engine"' in cargo_toml
        assert 'name = "my_app_engine"' in cargo_toml
        assert (
            f'pyo3 = {{ version = "{PYO3_VERSION}", features = ["extension-module"] }}'
            in cargo_toml
        )
        assert "#[pymodule]" in lib_rs
        assert "fn my_app_engine" in lib_rs
        assert 'Ok("hello from my_app_engine".to_string())' in lib_rs
        assert "[build-system]" in engine_pyproject
        assert f'requires = ["{MATURIN_SPEC}"]' in engine_pyproject
        assert 'build-backend = "maturin"' in engine_pyproject
        assert 'name = "my-app-engine"' in engine_pyproject
        assert 'module-name = "my_app_engine"' in engine_pyproject
        assert stub_file == "def hello() -> str: ...\n"
        assert project_json["name"] == "my-app-engine"
        assert (
            project_json["targets"]["engine:build"]["options"]["command"]
            == "uv run maturin develop"
        )
        assert (
            project_json["targets"]["engine:lint"]["options"]["command"]
            == "cargo clippy --all-targets --all-features -- -D warnings"
        )
        assert (
            project_json["targets"]["engine:format"]["options"]["command"]
            == "cargo fmt --check"
        )
        assert 'members = ["packages/python/my-app-engine"]' in root_pyproject
        assert "Build with: npx nx engine:build my-app-engine" in result.stdout
        assert recorded_calls == [(["uv", "sync"], Path.cwd())]

    monkeypatch.undo()


def test_generate_engine_dry_run_previews_files_and_workspace_update(
    monkeypatch, capsys
):
    monkeypatch.setattr("rpr.context.console", Console(highlight=False, no_color=True))
    monkeypatch.setattr(
        "rpr.commands.generate.engine.console", Console(highlight=False, no_color=True)
    )
    monkeypatch.setattr(
        "rpr.workspace.console", Console(highlight=False, no_color=True)
    )

    with runner.isolated_filesystem():
        _write_root_pyproject()

        result = runner.invoke(app, ["generate", "engine", "my-app", "--dry-run"])
        assert result.exit_code == 0, result.stdout

        output = result.stdout + capsys.readouterr().out

        assert "DRY RUN" in output
        assert "Would create directory" in output
        assert "packages/python/my-app-engine/src" in output
        assert "Would create:" in output
        assert "packages/python/my-app-engine/Cargo.toml" in output
        assert "packages/python/my-app-engine/src/lib.rs" in output
        assert "packages/python/my-app-engine/pyproject.toml" in output
        assert "packages/python/my-app-engine/my_app_engine.pyi" in output
        assert "packages/python/my-app-engine/project.json" in output
        assert (
            "Would add 'packages/python/my-app-engine' to workspace members" in output
        )
        assert "Would install uv dependencies for packages/python/my-app-engine" in output
        assert not Path("packages").exists()
        assert "members = []" in Path("pyproject.toml").read_text()
