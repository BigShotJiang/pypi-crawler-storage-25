import pytest
from typer.testing import CliRunner

from rpr.cli import app
from rpr.dependencies import tech_stack_instruction_variables
from rpr.generators.base import SyncConfig

runner = CliRunner()


@pytest.fixture
def project_dir(tmp_path):
    """Create a temporary project directory with .rpr.yaml."""
    d = tmp_path / "my-project"
    d.mkdir()
    (d / ".rpr.yaml").write_text("variables:\n  name: my-project\n")
    return d


@pytest.fixture
def source_dir(tmp_path):
    """Create a temporary source directory with instructions."""
    d = tmp_path / "source"
    d.mkdir()
    instructions = d / "instructions"
    instructions.mkdir()

    (instructions / "global.instructions.md").write_text("""---
applyTo: "**"
description: "Global rule"
---

# Global

Global content for {name}.
""")

    (instructions / "scoped.instructions.md").write_text("""---
applyTo: "src/**"
description: "Scoped rule"
---

# Scoped

Scoped content for {name}.
""")
    return d


def test_sync_rules_dry_run(project_dir, source_dir, monkeypatch):
    """Test sync rules command with --dry-run."""
    monkeypatch.chdir(project_dir)

    # Configure .rpr.yaml to point to source
    config = SyncConfig(source=str(source_dir), variables={"name": "test-project"})
    config.save(project_dir / ".rpr.yaml")

    result = runner.invoke(app, ["sync", "rules", "--dry-run"])

    assert result.exit_code == 0
    assert "[DRY RUN] Would create directory:" in result.stdout
    assert "Copilot Instructions Preview" in result.stdout
    assert "Claude Instructions Preview" in result.stdout
    assert "Global content for test-project" in result.stdout
    assert "Scoped content for test-project" in result.stdout
    assert "1 │" not in result.stdout

    # Verify NO files were created
    assert not (project_dir / ".cursor").exists()
    assert not (project_dir / ".github" / "copilot-instructions.md").exists()
    assert not (project_dir / "CLAUDE.md").exists()


def test_sync_rules(project_dir, source_dir, monkeypatch):
    """Test sync rules command implementation."""
    monkeypatch.chdir(project_dir)

    # Configure .rpr.yaml to point to source
    config = SyncConfig(source=str(source_dir), variables={"name": "test-project"})
    config.save(project_dir / ".rpr.yaml")

    result = runner.invoke(app, ["sync", "rules"])

    assert result.exit_code == 0
    assert "Done! Rules synced for: cursor, copilot, claude" in result.stdout

    assert "Copilot Instructions Preview" in result.stdout
    assert "Claude Instructions Preview" in result.stdout
    assert "Global content for test-project" in result.stdout
    assert "Scoped content for test-project" in result.stdout

    # Verify Cursor rules
    cursor_rules = project_dir / ".cursor" / "rules"
    assert cursor_rules.exists()
    assert (cursor_rules / "global.mdc").exists()
    assert (cursor_rules / "scoped.mdc").exists()

    global_mdc = (cursor_rules / "global.mdc").read_text()
    assert "globs: **" in global_mdc
    assert "alwaysApply: true" in global_mdc
    assert "Global content for test-project" in global_mdc

    scoped_mdc = (cursor_rules / "scoped.mdc").read_text()
    assert "globs: src/**" in scoped_mdc
    assert "alwaysApply: false" in scoped_mdc
    assert "Scoped content for test-project" in scoped_mdc

    # Verify Copilot rules
    copilot_file = project_dir / ".github" / "copilot-instructions.md"
    assert copilot_file.exists()
    content = copilot_file.read_text()
    assert "Global content for test-project" in content
    assert "Scoped content" not in content  # Scoped rules should be excluded

    # Verify Claude rules
    claude_file = project_dir / "CLAUDE.md"
    assert claude_file.exists()
    content = claude_file.read_text()
    assert "Global content for test-project" in content
    assert "Scoped content for test-project" in content


def test_sync_rules_gemini_target_shows_markdown_preview(
    project_dir, source_dir, monkeypatch
):
    monkeypatch.chdir(project_dir)

    config = SyncConfig(
        source=str(source_dir),
        targets=["gemini"],
        variables={"name": "test-project"},
    )
    config.save(project_dir / ".rpr.yaml")

    result = runner.invoke(app, ["sync", "rules", "--target", "gemini", "--dry-run"])

    assert result.exit_code == 0
    assert "Gemini Instructions Preview" in result.stdout
    assert "Global content for test-project" in result.stdout
    assert "Scoped content for test-project" in result.stdout
    assert not (project_dir / "GEMINI.md").exists()


def test_sync_rules_injects_manifest_backed_tech_stack_variables(
    project_dir, monkeypatch, tmp_path
):
    monkeypatch.chdir(project_dir)

    source_dir = tmp_path / "source"
    instructions = source_dir / "instructions"
    instructions.mkdir(parents=True)
    (instructions / "global.instructions.md").write_text("""---
applyTo: "**"
description: "Global rule"
---

# Global

Frontend stack: {tech_stack_frontend}
""")

    config = SyncConfig(source=str(source_dir), variables={"name": "test-project"})
    config.save(project_dir / ".rpr.yaml")

    result = runner.invoke(app, ["sync", "rules", "--target", "claude"])

    assert result.exit_code == 0
    assert tech_stack_instruction_variables()["tech_stack_frontend"] in (
        project_dir / "CLAUDE.md"
    ).read_text()
