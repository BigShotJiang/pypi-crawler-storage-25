from __future__ import annotations

import json
import shutil
from pathlib import Path

from typer.testing import CliRunner

from rpr.cli import app
from rpr.dependencies import (
    STORYBOOK_DEV_DEPENDENCIES,
    STORYBOOK_DEPENDENCIES,
    UI_LIBRARY_DEPENDENCIES,
    UI_LIBRARY_DEV_DEPENDENCIES,
    WEB_APP_DEV_DEPENDENCIES,
    api_runtime_dependencies,
    domain_dependencies,
    web_app_dependencies,
)

runner = CliRunner()

RPR_YAML = """\
source: .github/instructions
targets:
  - cursor
  - copilot
  - claude
variables:
  name: my-app
  name_underscore: my_app
"""

PYPROJECT_TOML = """\
[project]
name = "my-app"
version = "0.1.0"
requires-python = ">=3.12"
dependencies = []

[tool.uv]
require-version = ">=0.8.0"

[tool.uv.workspace]
members = ["packages/python/domain", "apps/my-app-api"]

[dependency-groups]
dev = [
    "pytest",
    "pytest-asyncio",
    "pytest-cov",
    "ipykernel",
    "pre-commit",
    "pyright",
    "ruff",
    "maturin",
]

[tool.pytest.ini_options]
pythonpath = []
testpaths = []
"""

PACKAGE_JSON = """\
{
    "name": "my-app",
    "private": true,
    "workspaces": ["apps/*", "packages/node/*"],
    "devDependencies": {
        "@nx/storybook": "latest"
    }
}
"""

PRE_COMMIT = """\
repos:
    - repo: https://github.com/pre-commit/pre-commit-hooks
        rev: v6.0.0
        hooks:
            - id: check-merge-conflict
    - repo: https://github.com/kynan/nbstripout
        rev: v0.8.2
        hooks:
            - id: nbstripout
    - repo: local
        hooks:
            - id: ruff-format
                entry: uv run ruff format
            - id: ruff-lint
                entry: uv run ruff check --fix
            - id: eslint
                entry: npx nx run-many --target=lint --all --fix --exclude=engine
"""


def _create_workspace(base: Path, *, rpr_yaml: bool = True) -> None:
    """Create a minimal passing workspace."""
    (base / "nx.json").write_text('{"version": 2, "neverConnectToCloud": true}')
    (base / "pyproject.toml").write_text(PYPROJECT_TOML)
    (base / "package.json").write_text(PACKAGE_JSON)
    (base / ".pre-commit-config.yaml").write_text(PRE_COMMIT)
    if rpr_yaml:
        (base / ".rpr.yaml").write_text(RPR_YAML)


def _create_instructions(base: Path) -> None:
    """Create all required AI instruction files."""
    cursor_rules = base / ".cursor" / "rules"
    cursor_rules.mkdir(parents=True)
    (cursor_rules / "all.mdc").write_text("# rules")
    (base / ".github").mkdir(parents=True, exist_ok=True)
    (base / ".github" / "copilot-instructions.md").write_text("# copilot")
    (base / "CLAUDE.md").write_text("# claude")


def _create_domain_templates(base: Path) -> None:
    """Create Python domain package + all template files."""
    domain = base / "packages" / "python" / "domain"
    utils = domain / "src" / "my_app_domain" / "utils"
    config = domain / "src" / "my_app_domain" / "config"
    utils.mkdir(parents=True)
    config.mkdir(parents=True)
    (utils / "mapper_util.py").write_text("")
    (utils / "dto_util.py").write_text("")
    (utils / "partial_update.py").write_text("")
    (utils / "encrypted_column.py").write_text("")
    (config / "settings.py").write_text("")
    (config / "container.py").write_text("")


def _create_ui_templates(base: Path) -> None:
    """Create UI library + all template files."""
    ui = base / "packages" / "node" / "my-app-ui"
    services = ui / "src" / "services" / "base"
    hooks = ui / "src" / "hooks"
    services.mkdir(parents=True)
    hooks.mkdir(parents=True)
    (services / "api.service.ts").write_text("")
    (hooks / "useStateNavigation.ts").write_text("")


def _create_packages(base: Path) -> None:
    """Create all generated packages & apps."""
    domain = base / "packages" / "python" / "domain"
    (domain / "src" / "my_app_domain").mkdir(parents=True, exist_ok=True)
    (domain / "tests").mkdir(parents=True, exist_ok=True)
    (domain / "pyproject.toml").write_text(
        "[project]\n"
        'name = "my-app-domain"\n'
        "dependencies = [\n"
        + "\n".join(f'    "{dependency}",' for dependency in domain_dependencies(include_migrations=False))
        + "\n]\n"
    )
    (domain / "project.json").write_text(
        '{"name": "domain", "targets": {"build": {}, "test": {}, "lint": {}}}'
    )

    api = base / "apps" / "my-app-api"
    (api / "src" / "my_app_api").mkdir(parents=True)
    (api / "tests").mkdir(parents=True)
    (api / "pyproject.toml").write_text(
        "[project]\n"
        'name = "my-app-api"\n'
        "dependencies = [\n"
        + "\n".join(f'    "{dependency}",' for dependency in api_runtime_dependencies("my-app"))
        + "\n]\n\n"
        "[tool.uv.sources]\n"
        "my-app-domain = { workspace = true }\n"
    )
    (api / "project.json").write_text(
        '{"targets": {"serve": {}, "build": {}, "test": {}, "lint": {}}}'
    )

    ui = base / "packages" / "node" / "my-app-ui"
    ui.mkdir(parents=True, exist_ok=True)
    (ui / "package.json").write_text(
        json.dumps(
            {
                "dependencies": UI_LIBRARY_DEPENDENCIES,
                "devDependencies": UI_LIBRARY_DEV_DEPENDENCIES,
            }
        )
    )
    (ui / "project.json").write_text(
        '{"targets": {"build": {}, "lint": {}, "test": {}, "typecheck": {}}}'
    )

    web = base / "apps" / "my-app-web"
    web.mkdir(parents=True, exist_ok=True)
    (web / "package.json").write_text(
        json.dumps(
            {
                "dependencies": web_app_dependencies("my-app-ui"),
                "devDependencies": WEB_APP_DEV_DEPENDENCIES,
            }
        )
    )
    (web / "project.json").write_text(
        '{"targets": {"serve": {}, "build": {}, "lint": {}, "test": {}, "typecheck": {}}}'
    )

    sb = base / "packages" / "node" / "sb"
    sb.mkdir(parents=True)
    (sb / "package.json").write_text(
        json.dumps(
            {
                "dependencies": {
                    "@repo/my-app-ui": web_app_dependencies("my-app-ui")["@repo/my-app-ui"],
                    **STORYBOOK_DEPENDENCIES,
                },
                "devDependencies": STORYBOOK_DEV_DEPENDENCIES,
            }
        )
    )
    (sb / "project.json").write_text(
        '{"targets": {"serve": {}, "build": {}, "lint": {}, "test": {}, "typecheck": {}, "storybook": {}, "build-storybook": {}}}'
    )


def _create_domain_migration_scaffold(base: Path) -> None:
    domain = base / "packages" / "python" / "domain"
    (domain / "alembic.ini").write_text("[alembic]\nscript_location = %(here)s/migrations\n")
    migrations = domain / "migrations"
    (migrations / "versions").mkdir(parents=True, exist_ok=True)
    (migrations / "env.py").write_text(
        "from my_app_domain.config.settings import Settings\n"
        "import my_app_domain.entities  # noqa: F401\n"
    )
    (domain / "pyproject.toml").write_text(
        """[project]
name = "my-app-domain"
dependencies = [
    "sqlmodel",
    "httpx",
    "dependency-injector",
    "pydantic",
    "pydantic-settings",
    "asyncpg",
    "alembic",
]
"""
    )
    (domain / "project.json").write_text(
        json.dumps(
            {
                "name": "domain",
                "targets": {
                    "build": {},
                    "test": {},
                    "lint": {},
                    "migrate": {
                        "options": {
                            "command": "uv run alembic -c packages/python/domain/alembic.ini",
                            "cwd": ".",
                        }
                    },
                },
            }
        )
    )


def test_check_all_pass():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        _create_domain_templates(base)
        _create_ui_templates(base)
        _create_packages(base)

        result = runner.invoke(app, ["check"])
        assert result.exit_code == 0, result.output
        assert "✓" in result.output
        assert "✗" not in result.output
        assert "my-app" in result.output


def test_check_missing_items_exit_nonzero():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        # No instructions, no packages

        result = runner.invoke(app, ["check"])
        assert result.exit_code == 1
        assert "✗" in result.output
        assert "rpr sync rules --target cursor" in result.output
        assert "rpr sync rules --target copilot" in result.output
        assert "rpr sync rules --target claude" in result.output


def test_check_missing_rpr_yaml_shows_unknown():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base, rpr_yaml=False)

        result = runner.invoke(app, ["check"])
        assert result.exit_code == 1
        assert "unknown" in result.output


def test_check_json_output_valid():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)

        result = runner.invoke(app, ["check", "--json"])
        assert result.exit_code == 1  # some items missing

        # Extract JSON from output (strip Rich formatting)
        output = result.output.strip()
        data = json.loads(output)
        assert isinstance(data, list)
        assert len(data) > 0

        first = data[0]
        assert "group" in first
        assert "area" in first
        assert "status" in first
        assert "path" in first
        assert "suggestion" in first


def test_check_json_all_pass_exit_zero():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        _create_domain_templates(base)
        _create_ui_templates(base)
        _create_packages(base)

        result = runner.invoke(app, ["check", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output.strip())
        assert all(item["status"] for item in data)


def test_check_group_workspace_only():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)

        result = runner.invoke(app, ["check", "--group", "workspace"])
        assert result.exit_code == 0, result.output
        assert "Workspace" in result.output
        assert "AI Instructions" not in result.output
        assert "Generated Packages" not in result.output


def test_check_group_instructions_only():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        _create_domain_templates(base)
        _create_ui_templates(base)

        result = runner.invoke(app, ["check", "--group", "instructions"])
        assert result.exit_code == 0, result.output
        assert "AI Instructions" in result.output
        assert "Workspace" not in result.output
        assert "Generated Packages" not in result.output


def test_check_group_packages_only():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_packages(base)

        result = runner.invoke(app, ["check", "--group", "packages"])
        assert result.exit_code == 0, result.output
        assert "Generated Packages" in result.output
        assert "Workspace" not in result.output
        assert "AI Instructions" not in result.output


def test_check_python_templates_skipped_without_domain():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        # No domain package, no UI library

        result = runner.invoke(app, ["check"])
        assert "mapper_util" not in result.output
        assert "dto_util" not in result.output
        assert "fetch_service" not in result.output
        assert "sticky_navigation" not in result.output


def test_check_python_templates_checked_when_domain_exists():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        # Create domain dir but NOT the template files
        domain = base / "packages" / "python" / "domain"
        (domain / "src" / "my_app_domain").mkdir(parents=True)
        (domain / "tests").mkdir(parents=True)
        (domain / "project.json").write_text(
            '{"targets": {"build": {}, "test": {}, "lint": {}}}'
        )

        result = runner.invoke(app, ["check"])
        assert "domain_settings" in result.output
        assert "domain_container" in result.output
        assert "mapper_util" in result.output
        assert "dto_util" in result.output
        assert result.exit_code == 1


def test_check_js_templates_checked_when_ui_exists():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        # Create UI dir but NOT the template files
        ui = base / "packages" / "node" / "my-app-ui"
        ui.mkdir(parents=True)
        (ui / "project.json").write_text(
            '{"targets": {"build": {}, "lint": {}, "test": {}, "typecheck": {}}}'
        )

        result = runner.invoke(app, ["check"])
        assert "fetch_service" in result.output
        assert "sticky_navigation" in result.output
        assert result.exit_code == 1


def test_check_detects_missing_web_app_and_target_drift():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        _create_domain_templates(base)
        _create_ui_templates(base)
        _create_packages(base)

        shutil.rmtree(base / "apps" / "my-app-web")
        (base / "packages" / "node" / "sb" / "project.json").write_text(
            '{"targets": {"storybook": {}, "build-storybook": {}}}'
        )

        result = runner.invoke(app, ["check", "--json"])

        assert result.exit_code == 1
        data = json.loads(result.output)

        web_result = next(item for item in data if item["area"] == "Web app")
        storybook_result = next(
            item for item in data if item["area"] == "Storybook targets"
        )

        assert web_result["status"] is False
        assert web_result["suggestion"] == "rpr generate ui my-app --no-library"
        assert "apps/my-app-web" in web_result["path"]
        assert storybook_result["status"] is False
        assert "missing targets" in storybook_result["path"]


def test_check_domain_migration_scaffold_is_optional_when_absent():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        _create_domain_templates(base)
        _create_ui_templates(base)
        _create_packages(base)

        result = runner.invoke(app, ["check", "--json"])

        assert result.exit_code == 0, result.output
        data = json.loads(result.output)
        migration_result = next(
            item
            for item in data
            if item["area"] == "Domain migration scaffold (optional)"
        )
        assert migration_result["status"] is True
        assert migration_result["path"] == "not scaffolded"


def test_check_detects_incomplete_domain_migration_scaffold():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        _create_domain_templates(base)
        _create_ui_templates(base)
        _create_packages(base)

        domain = base / "packages" / "python" / "domain"
        (domain / "migrations" / "versions").mkdir(parents=True)
        (domain / "project.json").write_text(
            json.dumps(
                {
                    "name": "domain",
                    "targets": {
                        "build": {},
                        "test": {},
                        "lint": {},
                        "migrate": {"options": {"command": "uv run alembic"}},
                    },
                }
            )
        )

        result = runner.invoke(app, ["check", "--json"])

        assert result.exit_code == 1, result.output
        data = json.loads(result.output)
        migration_result = next(
            item
            for item in data
            if item["area"] == "Domain migration scaffold (optional)"
        )
        assert migration_result["status"] is False
        assert "incomplete migration scaffold" in migration_result["path"]


def test_check_detects_install_metadata_drift():
    with runner.isolated_filesystem():
        base = Path(".")
        _create_workspace(base)
        _create_instructions(base)
        _create_domain_templates(base)
        _create_ui_templates(base)
        _create_packages(base)
        _create_domain_migration_scaffold(base)

        (base / "apps" / "my-app-api" / "pyproject.toml").write_text(
            "[project]\n"
            'name = "my-app-api"\n'
            "dependencies = [\n"
            f'    "{api_runtime_dependencies("my-app")[0]}",\n'
            f'    "{api_runtime_dependencies("my-app")[2]}",\n'
            "]\n\n"
            "[tool.uv.sources]\n"
            "my-app-domain = { workspace = true }\n"
        )
        (base / "package.json").write_text(
            json.dumps(
                {
                    "name": "my-app",
                    "private": True,
                    "workspaces": ["apps/*", "packages/node/*"],
                }
            )
        )

        result = runner.invoke(app, ["check", "--json"])

        assert result.exit_code == 1, result.output
        data = json.loads(result.output)
        api_result = next(
            item for item in data if item["area"] == "API install metadata"
        )
        storybook_root_result = next(
            item
            for item in data
            if item["area"] == "Storybook root install metadata"
        )
        migration_result = next(
            item
            for item in data
            if item["area"] == "Domain migration scaffold (optional)"
        )

        assert api_result["status"] is False
        assert api_runtime_dependencies("my-app")[1] in api_result["path"]
        assert storybook_root_result["status"] is False
        assert "@nx/storybook" in storybook_root_result["path"]
        assert migration_result["status"] is True
