from __future__ import annotations

import json
import subprocess
from pathlib import Path

from typer.testing import CliRunner

from rpr.cli import app


runner = CliRunner()


def _completed(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")


def test_init_new_workspace_disables_nx_cloud(monkeypatch):
    recorded_calls: list[dict[str, object]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append({"cmd": cmd, "cwd": cwd, "env": env})
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr(
        "rpr.commands.init._scaffold_ai_instructions", lambda *args, **kwargs: None
    )
    monkeypatch.setattr(
        "rpr.commands.init._write_rpr_yaml", lambda *args, **kwargs: None
    )

    with runner.isolated_filesystem():
        result = runner.invoke(app, ["init", "my-app"])
        assert result.exit_code == 0, result.stdout

        project_dir = Path("my-app")
        assert project_dir.exists()

        create_call = next(
            call
            for call in recorded_calls
            if "create-nx-workspace@latest" in call["cmd"]
        )
        assert "--nxCloud=never" in create_call["cmd"]
        assert "--integrated" not in create_call["cmd"]
        assert create_call["env"] == {"NX_NO_CLOUD": "true"}
        nx_json = (project_dir / "nx.json").read_text()
        pyproject = (project_dir / "pyproject.toml").read_text()
        pre_commit = (project_dir / ".pre-commit-config.yaml").read_text()
        assert '"neverConnectToCloud": true' in nx_json
        assert '"plugin": "@nx/eslint/plugin"' in nx_json
        assert 'name = "my-app"' in pyproject
        assert 'readme = "README.md"' in pyproject
        assert '[tool.uv]' in pyproject
        assert 'require-version = ">=' in pyproject
        assert '"pytest-asyncio"' in pyproject
        assert '"pytest-cov"' in pyproject
        assert '"ipykernel"' in pyproject
        assert '"pyright"' in pyproject
        assert '"maturin"' in pyproject
        assert 'line-length = 88' in pyproject
        assert 'select = ["E", "F", "W", "I001"]' in pyproject
        assert '[tool.pytest.ini_options]' in pyproject
        assert 'repo: https://github.com/pre-commit/pre-commit-hooks' in pre_commit
        assert 'repo: https://github.com/kynan/nbstripout' in pre_commit
        assert 'entry: uv run ruff format' in pre_commit
        assert 'entry: uv run ruff check --fix' in pre_commit
        assert 'entry: npx nx run-many --target=lint --all --fix --exclude=engine' in pre_commit

        package_json = json.loads((project_dir / "package.json").read_text())
        assert package_json["scripts"]["lint"] == "npx nx run-many --target=lint --all"
        assert package_json["workspaces"] == ["apps/*", "packages/node/*"]
        assert "eslint" in package_json["devDependencies"]
        assert "prettier" in package_json["devDependencies"]

        assert (project_dir / "eslint.config.mjs").exists()
        assert (project_dir / ".prettierrc").exists()
        assert (project_dir / ".prettierignore").exists()
        assert (project_dir / ".pre-commit-config.yaml").exists()


def test_init_existing_workspace_disables_nx_cloud(monkeypatch):
    recorded_calls: list[dict[str, object]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append({"cmd": cmd, "cwd": cwd, "env": env})
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr(
        "rpr.commands.init._scaffold_ai_instructions", lambda *args, **kwargs: None
    )
    monkeypatch.setattr(
        "rpr.commands.init._write_rpr_yaml", lambda *args, **kwargs: None
    )
    monkeypatch.setattr("typer.confirm", lambda *args, **kwargs: True)

    with runner.isolated_filesystem():
        project_dir = Path("my-app")
        project_dir.mkdir()
        (project_dir / "README.md").write_text("existing")

        result = runner.invoke(app, ["init", "my-app"])
        assert result.exit_code == 0, result.stdout

        init_call = next(
            call
            for call in recorded_calls
            if call["cmd"][:4] == ["npx", "--yes", "nx", "init"]
        )
        assert "--nxCloud=false" in init_call["cmd"]
        assert "--integrated" not in init_call["cmd"]
        assert init_call["env"] == {"NX_NO_CLOUD": "true"}
        nx_json = (project_dir / "nx.json").read_text()
        pyproject = (project_dir / "pyproject.toml").read_text()
        pre_commit = (project_dir / ".pre-commit-config.yaml").read_text()
        assert '"neverConnectToCloud": true' in nx_json
        assert '"plugin": "@nx/eslint/plugin"' in nx_json
        assert 'name = "my-app"' in pyproject
        assert 'require-version = ">=' in pyproject
        assert 'testpaths = []' in pyproject
        assert 'repo: https://github.com/pre-commit/pre-commit-hooks' in pre_commit
        assert 'repo: https://github.com/kynan/nbstripout' in pre_commit
        assert 'entry: npx nx run-many --target=lint --all --fix --exclude=engine' in pre_commit

        package_json = json.loads((project_dir / "package.json").read_text())
        assert package_json["workspaces"] == ["apps/*", "packages/node/*"]

        assert (project_dir / "eslint.config.mjs").exists()
        assert (project_dir / ".prettierrc").exists()
        assert (project_dir / ".prettierignore").exists()
        assert (project_dir / ".pre-commit-config.yaml").exists()


def test_init_scaffold_selection_runs_requested_generators_in_dependency_order(
    monkeypatch,
):
    recorded_calls: list[dict[str, object]] = []
    scaffold_calls: list[str] = []
    instructions_calls: list[dict[str, object]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append({"cmd": cmd, "cwd": cwd, "env": env})
        return _completed(cmd)

    def fake_domain(*, name, dry_run, migrations=False):
        scaffold_calls.append(f"domain:{name}:{dry_run}:{migrations}")

    def fake_api(*, name, dry_run):
        scaffold_calls.append(f"api:{name}:{dry_run}")

    def fake_ui(*, name, dry_run, include_library=True, include_web=True):
        scaffold_calls.append(
            f"ui:{name}:{dry_run}:{include_library}:{include_web}"
        )

    def fake_storybook(*, ui_package=None, dry_run):
        scaffold_calls.append(f"storybook:{ui_package}:{dry_run}")

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr(
        "rpr.commands.init._scaffold_ai_instructions",
        lambda *args, **kwargs: instructions_calls.append({"args": args, "kwargs": kwargs}),
    )
    monkeypatch.setattr(
        "rpr.commands.generate.domain.domain",
        fake_domain,
    )
    monkeypatch.setattr(
        "rpr.commands.generate.api.api",
        fake_api,
    )
    monkeypatch.setattr(
        "rpr.commands.generate.ui.ui",
        fake_ui,
    )
    monkeypatch.setattr(
        "rpr.commands.generate.storybook.storybook",
        fake_storybook,
    )

    with runner.isolated_filesystem():
        result = runner.invoke(
            app,
            [
                "init",
                "my-app",
                "--scaffold",
                "api",
                "--scaffold",
                "storybook",
            ],
        )
        assert result.exit_code == 0, result.stdout

        assert instructions_calls == []
        assert scaffold_calls == [
            "domain:my-app:False:False",
            "api:my-app:False",
            "ui:my-app:False:True:False",
            "storybook:my-app-ui:False",
        ]


def test_init_forwards_domain_migrations(monkeypatch):
    recorded_calls: list[dict[str, object]] = []
    scaffold_calls: list[str] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        recorded_calls.append({"cmd": cmd, "cwd": cwd, "env": env})
        return _completed(cmd)

    def fake_domain(*, name, dry_run, migrations=False):
        scaffold_calls.append(f"domain:{name}:{dry_run}:{migrations}")

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr(
        "rpr.commands.init._scaffold_ai_instructions", lambda *args, **kwargs: None
    )
    monkeypatch.setattr(
        "rpr.commands.generate.domain.domain",
        fake_domain,
    )

    with runner.isolated_filesystem():
        result = runner.invoke(
            app,
            ["init", "my-app", "--scaffold", "domain", "--domain-migrations"],
        )
        assert result.exit_code == 0, result.stdout

        assert scaffold_calls == ["domain:my-app:False:True"]


def test_init_rejects_domain_migrations_without_domain_scaffold(monkeypatch):
    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)

    with runner.isolated_filesystem():
        result = runner.invoke(app, ["init", "my-app", "--domain-migrations"])

        assert result.exit_code == 2
        assert "--domain-migrations requires a scaffold" in result.output


def test_init_forwards_domain_migrations_through_api_dependency(monkeypatch):
    scaffold_calls: list[str] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        return _completed(cmd)

    def fake_domain(*, name, dry_run, migrations=False):
        scaffold_calls.append(f"domain:{name}:{dry_run}:{migrations}")

    def fake_api(*, name, dry_run):
        scaffold_calls.append(f"api:{name}:{dry_run}")

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr(
        "rpr.commands.init._scaffold_ai_instructions", lambda *args, **kwargs: None
    )
    monkeypatch.setattr("rpr.commands.generate.domain.domain", fake_domain)
    monkeypatch.setattr("rpr.commands.generate.api.api", fake_api)

    with runner.isolated_filesystem():
        result = runner.invoke(
            app,
            ["init", "my-app", "--scaffold", "api", "--domain-migrations"],
        )

        assert result.exit_code == 0, result.stdout
        assert scaffold_calls == ["domain:my-app:False:True", "api:my-app:False"]


def test_init_defaults_to_instruction_scaffolding_only(monkeypatch):
    generator_calls: list[str] = []
    instructions_calls: list[dict[str, object]] = []

    def fake_run_command(
        self, cmd, *, cwd=None, env=None, capture=False, supports_dry_run=False
    ):
        return _completed(cmd)

    monkeypatch.setattr("rpr.context.RunContext.run_command", fake_run_command)
    monkeypatch.setattr(
        "rpr.commands.init._scaffold_ai_instructions",
        lambda *args, **kwargs: instructions_calls.append({"args": args, "kwargs": kwargs}),
    )
    monkeypatch.setattr(
        "rpr.commands.generate.domain.domain",
        lambda **kwargs: generator_calls.append("domain"),
    )
    monkeypatch.setattr(
        "rpr.commands.generate.api.api",
        lambda **kwargs: generator_calls.append("api"),
    )
    monkeypatch.setattr(
        "rpr.commands.generate.ui.ui",
        lambda **kwargs: generator_calls.append("ui"),
    )
    monkeypatch.setattr(
        "rpr.commands.generate.storybook.storybook",
        lambda **kwargs: generator_calls.append("storybook"),
    )
    monkeypatch.setattr(
        "rpr.commands.generate.engine.engine",
        lambda **kwargs: generator_calls.append("engine"),
    )
    monkeypatch.setattr(
        "rpr.commands.init._write_rpr_yaml", lambda *args, **kwargs: None
    )

    with runner.isolated_filesystem():
        result = runner.invoke(app, ["init", "my-app"])
        assert result.exit_code == 0, result.stdout

        assert len(instructions_calls) == 1
        assert generator_calls == []


def test_init_dry_run_with_domain_scaffold_previews_full_plan_without_writes():
    with runner.isolated_filesystem():
        result = runner.invoke(
            app,
            [
                "init",
                "todo-list",
                "--scaffold",
                "domain",
                "--domain-migrations",
                "--dry-run",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert "DRY RUN" in result.stdout
        assert "create-nx-workspace@latest" in result.stdout
        assert "todo-list/package.json" in result.stdout
        assert "packages/python/domain/pyproject.toml" in result.stdout
        assert "Would add 'packages/python/domain' to workspace members" in result.stdout
        assert "Would install uv dependencies for packages/python/domain" in result.stdout
        assert (
            "runtime=[sqlmodel, httpx, dependency-injector, pydantic, "
            "pydantic-settings, asyncpg, alembic]"
        ) in result.stdout
        assert not Path("todo-list").exists()


def test_init_dry_run_with_storybook_uses_previewed_ui_dependency():
    with runner.isolated_filesystem():
        result = runner.invoke(
            app,
            [
                "init",
                "todo-list",
                "--scaffold",
                "storybook",
                "--dry-run",
            ],
        )

        assert result.exit_code == 0, result.stdout
        assert "Scaffolding requested project components (ui, storybook)" in result.stdout
        assert "Generating frontend projects: todo-list-ui" in result.stdout
        assert "Generating Storybook package:" in result.stdout
        assert "importing from todo-list-ui" in result.stdout
        assert not Path("todo-list").exists()
