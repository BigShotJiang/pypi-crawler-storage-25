from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from rpr.cli import app
from rpr.dependencies import get_dependency_manifest, render_dependency_manifest_module

runner = CliRunner()


def test_refresh_manifest_updates_manifest_data_file(monkeypatch, tmp_path: Path) -> None:
    manifest_path = tmp_path / "dependency_manifest_data.py"
    manifest_path.write_text(render_dependency_manifest_module(get_dependency_manifest()))

    def fake_fetch_latest_version(registry: str, package: str, *, timeout: float = 10.0) -> str:
        return "9.9.9"

    monkeypatch.setattr("rpr.commands.refresh.MANIFEST_DATA_PATH", manifest_path)
    monkeypatch.setattr(
        "rpr.manifest_refresh.fetch_latest_version", fake_fetch_latest_version
    )

    result = runner.invoke(app, ["refresh", "manifest"])

    assert result.exit_code == 0, result.stdout
    assert "uvicorn[standard]: uvicorn[standard]>=0.34 -> uvicorn[standard]>=9.9.9" in result.stdout
    updated = manifest_path.read_text()
    assert "'specifier': '^9.9.9'" in updated
    assert "'specifier': 'fastapi>=9.9.9'" in updated
    assert "'specifier': 'uvicorn[standard]>=9.9.9'" in updated
    assert "'specifier': '9.9.9'" in updated
    assert "'specifier': 'maturin>=9.9.9,<10.0'" in updated


def test_refresh_manifest_dry_run_does_not_write_file(monkeypatch, tmp_path: Path) -> None:
    manifest_path = tmp_path / "dependency_manifest_data.py"
    original = render_dependency_manifest_module(get_dependency_manifest())
    manifest_path.write_text(original)

    def fake_fetch_latest_version(registry: str, package: str, *, timeout: float = 10.0) -> str:
        return "9.9.9"

    monkeypatch.setattr("rpr.commands.refresh.MANIFEST_DATA_PATH", manifest_path)
    monkeypatch.setattr(
        "rpr.manifest_refresh.fetch_latest_version", fake_fetch_latest_version
    )

    result = runner.invoke(app, ["refresh", "manifest", "--dry-run"])

    assert result.exit_code == 0, result.stdout
    assert manifest_path.read_text() == original