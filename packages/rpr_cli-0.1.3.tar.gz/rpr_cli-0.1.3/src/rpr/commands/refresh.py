from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpr.cli import refresh_app
from rpr.context import RunContext
from rpr.dependencies import (
    MANIFEST_DATA_PATH,
    get_dependency_manifest,
    render_dependency_manifest_module,
)
from rpr.manifest_refresh import ManifestRefreshError, refresh_dependency_manifest

console = Console()


@refresh_app.command("manifest")
def manifest(
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview manifest updates without writing.")
    ] = False,
    timeout: Annotated[
        float,
        typer.Option(
            "--timeout",
            min=1.0,
            help="Per-request timeout in seconds when talking to registries.",
        ),
    ] = 10.0,
) -> None:
    """Refresh the scaffold dependency manifest from npm, PyPI, and crates.io."""
    ctx = RunContext(dry_run=dry_run, project_dir=Path.cwd())

    try:
        refreshed_manifest, changes = refresh_dependency_manifest(
            get_dependency_manifest(),
            timeout=timeout,
        )
    except ManifestRefreshError as exc:
        console.print(f"[bold red]Error:[/] {exc}")
        raise typer.Exit(1) from exc

    if not changes:
        console.print("[bold green]Done![/] Dependency manifest is already up to date.")
        return

    console.print(f"\n[bold]Refreshing dependency manifest[/] ({len(changes)} updates)\n")
    for change in changes:
        console.print(
            f"  {change.dependency}: {change.old_specifier} -> {change.new_specifier}",
            markup=False,
        )

    rendered = render_dependency_manifest_module(refreshed_manifest)
    ctx.update_file(MANIFEST_DATA_PATH, rendered)

    if dry_run:
        console.print("\n[bold yellow]Dry run complete.[/] Review the preview above.")
        return

    console.print(f"\n[bold green]Done![/] Updated dependency manifest at {MANIFEST_DATA_PATH}")