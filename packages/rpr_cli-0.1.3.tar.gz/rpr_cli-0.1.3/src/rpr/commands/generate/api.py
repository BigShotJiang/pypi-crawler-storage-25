from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpr.cli import generate_app
from rpr.context import RunContext
from rpr.dependencies import api_runtime_dependencies
from rpr.workspace import add_workspace_member

console = Console()


@generate_app.command()
def api(
    name: Annotated[
        str | None, typer.Argument(help="App name (used as package prefix).")
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview changes without writing.")
    ] = False,
) -> None:
    """Scaffold a FastAPI application."""
    if not name:
        name = typer.prompt("App name")

    ctx = RunContext(dry_run=dry_run, project_dir=Path.cwd())
    app_name = f"{name}-api"
    app_name_underscore = app_name.replace("-", "_")
    domain_underscore = f"{name}_domain".replace("-", "_")
    api_root = ctx.project_dir / "apps" / app_name
    src_root = api_root / "src" / app_name_underscore
    tests_root = api_root / "tests"

    console.print(f"\n[bold]Generating FastAPI app:[/] {app_name}\n")

    ctx.ensure_dir(src_root / "routes")
    ctx.ensure_dir(tests_root)

    _write_api_pyproject(ctx, api_root, name, app_name, app_name_underscore)
    _write_api_project_json(ctx, api_root, app_name, app_name_underscore)
    _write_main(ctx, src_root / "main.py", name, domain_underscore)
    _write_init_file(ctx, src_root / "__init__.py")
    _write_init_file(ctx, src_root / "routes" / "__init__.py")
    _write_health_route(ctx, src_root / "routes" / "health.py")
    _write_health_test(ctx, tests_root / "test_health.py", app_name_underscore)

    add_workspace_member(ctx, f"apps/{app_name}")
    ctx.preview_dependencies(
        manager="uv",
        target=f"apps/{app_name}",
        runtime=api_runtime_dependencies(name),
    )

    if not dry_run:
        ctx.run_command(["uv", "sync"], cwd=ctx.project_dir)

    console.print(f"\n[bold green]Done![/] FastAPI app created at {api_root}")
    console.print(f"  Run with: npx nx serve {app_name}")


def _write_init_file(ctx: RunContext, path: Path) -> None:
    ctx.write_file(path, "")


def _write_api_pyproject(
    ctx: RunContext, api_root: Path, name: str, app_name: str, app_name_underscore: str
) -> None:
    content = f"""[project]
name = "{app_name}"
version = "0.1.0"
description = "{name} API"
readme = "README.md"
requires-python = ">=3.12"
dependencies = [
    "{api_runtime_dependencies(name)[0]}",
    "{api_runtime_dependencies(name)[1]}",
    "{api_runtime_dependencies(name)[2]}",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/{app_name_underscore}"]

[tool.uv.sources]
{name}-domain = {{ workspace = true }}

[tool.pytest.ini_options]
testpaths = ["tests"]
"""
    ctx.write_file(api_root / "pyproject.toml", content)


def _write_api_project_json(
    ctx: RunContext, api_root: Path, app_name: str, app_name_underscore: str
) -> None:
    project = {
        "name": app_name,
        "root": f"apps/{app_name}",
        "targets": {
            "serve": {
                "executor": "nx:run-commands",
                "options": {
                    "command": f"uv run uvicorn {app_name_underscore}.main:app --reload --host 0.0.0.0 --port 8000",
                    "cwd": f"apps/{app_name}",
                },
            },
            "build": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "uv build",
                    "cwd": f"apps/{app_name}",
                },
            },
            "test": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "uv run pytest",
                    "cwd": f"apps/{app_name}",
                },
            },
            "lint": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "uv run ruff check .",
                    "cwd": f"apps/{app_name}",
                },
            },
        },
    }
    ctx.write_file(api_root / "project.json", json.dumps(project, indent=2) + "\n")


def _write_main(ctx: RunContext, path: Path, name: str, domain_underscore: str) -> None:
    content = f'''from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from starlette.requests import Request
from starlette.responses import JSONResponse

from {domain_underscore}.config.container import Container

_container = Container()


@asynccontextmanager
async def lifespan(app: FastAPI):
    container = _container
    container.wire(modules=[__name__])
    app.state.container = container
    try:
        yield
    finally:
        pass


async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    return JSONResponse(status_code=500, content={{"message": "Internal server error"}})


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(status_code=422, content={{"message": "Validation error", "details": exc.errors()}})


def create_app() -> FastAPI:
    app = FastAPI(
        title="{name.replace("-", " ").title()}",
        description="{name} API",
        version="1.0.0",
        lifespan=lifespan,
    )

    app.add_exception_handler(Exception, generic_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    from .routes.health import router as health_router

    app.include_router(health_router, prefix="/api/health", tags=["Health"])

    return app


app = create_app()
'''
    ctx.write_file(path, content)


def _write_health_route(ctx: RunContext, path: Path) -> None:
    content = """from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()


class HealthResponse(BaseModel):
    status: str


@router.get("", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    return HealthResponse(status="ok")
"""
    ctx.write_file(path, content)


def _write_health_test(ctx: RunContext, path: Path, app_name_underscore: str) -> None:
    content = f"""import pytest

from {app_name_underscore}.routes.health import health_check


@pytest.mark.asyncio
async def test_health_check() -> None:
    response = await health_check()

    assert response.status == "ok"
"""
    ctx.write_file(path, content)
