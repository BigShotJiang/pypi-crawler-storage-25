from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpr.cli import generate_app
from rpr.context import RunContext
from rpr.dependencies import domain_dependencies
from rpr.workspace import add_workspace_member

console = Console()

_SCAFFOLD_DIR = Path(__file__).parent.parent.parent / "scaffolds" / "domain"

_UTILITY_TEMPLATES = ["mapper_util", "dto_util", "partial_update"]


@generate_app.command()
def domain(
    name: Annotated[
        str | None, typer.Argument(help="App name (used as package prefix).")
    ] = None,
    migrations: Annotated[
        bool,
        typer.Option("--migrations", help="Scaffold Alembic migrations for the domain package."),
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview changes without writing.")
    ] = False,
) -> None:
    """Scaffold a DDD Python domain package."""
    if not name:
        name = typer.prompt("App name")

    ctx = RunContext(dry_run=dry_run, project_dir=Path.cwd())

    name_underscore = name.replace("-", "_")
    pkg_name = f"{name}-domain"
    pkg_name_underscore = f"{name_underscore}_domain"

    domain_root = ctx.project_dir / "packages" / "python" / "domain"
    src_root = domain_root / "src" / pkg_name_underscore
    tests_root = domain_root / "tests"
    migrations_root = domain_root / "migrations"

    console.print(f"\n[bold]Generating domain package:[/] {pkg_name}\n")

    # --- directories -------------------------------------------------------
    dirs = ["entities", "dtos", "repos", "services", "workflows", "config", "utils"]
    for d in dirs:
        ctx.ensure_dir(src_root / d)
    ctx.ensure_dir(tests_root)
    if migrations:
        ctx.ensure_dir(migrations_root / "versions")

    # --- project metadata --------------------------------------------------
    _write_domain_pyproject(ctx, domain_root, name, pkg_name_underscore)
    _write_project_json(ctx, domain_root, include_migrations=migrations)

    # --- __init__.py files -------------------------------------------------
    for d in ["", *dirs]:
        ctx.write_file(src_root / d / "__init__.py", "")

    # --- config stubs ------------------------------------------------------
    _write_settings(ctx, src_root / "config" / "settings.py")
    _write_container(ctx, src_root / "config" / "container.py", pkg_name_underscore)

    # --- scaffold files ----------------------------------------------------
    _write_base_entity(ctx, src_root / "entities" / "base.py")
    _write_base_repo(ctx, src_root / "repos" / "base.py", pkg_name_underscore)
    _write_domain_test(ctx, tests_root / "test_package.py", pkg_name_underscore)
    if migrations:
        _write_alembic_ini(ctx, domain_root / "alembic.ini")
        _write_migration_env(ctx, migrations_root / "env.py", pkg_name_underscore)

    # --- workspace + deps --------------------------------------------------
    add_workspace_member(ctx, "packages/python/domain")
    ctx.preview_dependencies(
        manager="uv",
        target="packages/python/domain",
        runtime=domain_dependencies(include_migrations=migrations),
    )

    if not dry_run:
        ctx.run_command(["uv", "sync"], cwd=ctx.project_dir)
        _install_domain_deps(ctx, domain_root, include_migrations=migrations)
        ctx.run_command(["uv", "sync"], cwd=ctx.project_dir)

    console.print(f"\n[bold green]Done![/] Domain package created at {domain_root}")

    # --- post-scaffold utility prompt --------------------------------------
    if not dry_run:
        _offer_utility_templates(ctx, name)


# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


def _install_domain_deps(
    ctx: RunContext, domain_root: Path, *, include_migrations: bool
) -> None:
    ctx.run_command(
        ["uv", "add", *domain_dependencies(include_migrations=include_migrations)],
        cwd=domain_root,
    )


# ---------------------------------------------------------------------------
# Project metadata
# ---------------------------------------------------------------------------


def _write_domain_pyproject(
    ctx: RunContext, domain_root: Path, name: str, pkg_name_underscore: str
) -> None:
    content = f"""\
[project]
name = "{name}-domain"
version = "0.1.0"
description = "{name} domain layer"
readme = "README.md"
requires-python = ">=3.12"
dependencies = []

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/{pkg_name_underscore}"]

[tool.pytest.ini_options]
testpaths = ["tests"]
"""
    ctx.write_file(domain_root / "pyproject.toml", content)


def _write_project_json(
    ctx: RunContext, domain_root: Path, *, include_migrations: bool
) -> None:
    project = {
        "name": "domain",
        "root": "packages/python/domain",
        "targets": {
            "build": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "uv build",
                    "cwd": "packages/python/domain",
                },
            },
            "test": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "uv run pytest packages/python/domain",
                },
            },
            "lint": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "uv run ruff check packages/python/domain/src",
                },
            },
        },
    }
    if include_migrations:
        project["targets"]["migrate"] = {
            "executor": "nx:run-commands",
            "options": {
                "command": "uv run alembic -c packages/python/domain/alembic.ini",
                "cwd": ".",
            },
        }
    ctx.write_file(domain_root / "project.json", json.dumps(project, indent=2) + "\n")


# ---------------------------------------------------------------------------
# Config stubs
# ---------------------------------------------------------------------------


def _write_settings(ctx: RunContext, path: Path) -> None:
    code = _extract_first_code_block(_SCAFFOLD_DIR / "settings.md")
    ctx.write_file(path, code)


def _write_container(ctx: RunContext, path: Path, pkg_name_underscore: str) -> None:
    code = _extract_first_code_block(_SCAFFOLD_DIR / "container.md")
    code = code.replace("your_app_domain", pkg_name_underscore)
    ctx.write_file(path, code)


# ---------------------------------------------------------------------------
# Scaffold helpers
# ---------------------------------------------------------------------------


def _extract_first_code_block(md_path: Path) -> str:
    """Return the content of the first fenced code block in a markdown file."""
    text = md_path.read_text()
    match = re.search(r"```(?:\w*)\n(.*?)```", text, re.DOTALL)
    if not match:
        raise ValueError(f"No fenced code block found in {md_path}")
    return match.group(1)


def _write_base_entity(ctx: RunContext, path: Path) -> None:
    code = _extract_first_code_block(_SCAFFOLD_DIR / "base_entity.md")
    ctx.write_file(path, code)


def _write_base_repo(ctx: RunContext, path: Path, pkg_name_underscore: str) -> None:
    code = _extract_first_code_block(_SCAFFOLD_DIR / "base_repo.md")
    code = code.replace("your_app_domain", pkg_name_underscore)
    ctx.write_file(path, code)


def _write_domain_test(ctx: RunContext, path: Path, pkg_name_underscore: str) -> None:
    content = f"""from {pkg_name_underscore}.config.settings import Settings


def test_settings_database_url_uses_defaults() -> None:
    settings = Settings()

    assert settings.database_url.startswith("postgresql+")
"""
    ctx.write_file(path, content)


def _write_alembic_ini(ctx: RunContext, path: Path) -> None:
    content = """[alembic]
script_location = %(here)s/migrations

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level = WARN
handlers = console

[logger_sqlalchemy]
level = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level = INFO
handlers =
qualname = alembic

[handler_console]
class = StreamHandler
args = (sys.stderr,)
level = NOTSET
formatter = generic

[formatter_generic]
format = %(levelname)-5.5s [%(name)s] %(message)s
"""
    ctx.write_file(path, content)


def _write_migration_env(
    ctx: RunContext, path: Path, pkg_name_underscore: str
) -> None:
    content = f"""from __future__ import annotations

import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel import SQLModel

from {pkg_name_underscore}.config.settings import Settings
import {pkg_name_underscore}.entities  # noqa: F401


settings = Settings()
config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = SQLModel.metadata


def include_object(object, name, type_, reflected, compare_to):
    if type_ == "table":
        entity_table_names = set(target_metadata.tables.keys())
        return name in entity_table_names

    if type_ in ("index", "unique_constraint", "foreign_key_constraint", "check_constraint"):
        if hasattr(object, "table"):
            entity_table_names = set(target_metadata.tables.keys())
            return object.table.name in entity_table_names

    return True


def do_run_migrations(connection) -> None:
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=True,
        include_object=include_object,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_offline() -> None:
    context.configure(
        url=settings.database_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={{"paramstyle": "named"}},
        include_object=include_object,
    )

    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online() -> None:
    connectable = create_async_engine(settings.database_url, pool_pre_ping=True)

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
"""
    ctx.write_file(path, content)


# ---------------------------------------------------------------------------
# Post-scaffold utility prompt
# ---------------------------------------------------------------------------


def _offer_utility_templates(ctx: RunContext, name: str) -> None:
    console.print("\n[bold]Tip:[/] Add common utilities with:")
    for t in _UTILITY_TEMPLATES:
        console.print(f"  [dim]rpr add template {t} --name {name}[/]")

    if typer.confirm("\nWould you like to add these utilities now?", default=False):
        for t in _UTILITY_TEMPLATES:
            ctx.run_command(["rpr", "add", "template", t, "--name", name])
