from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rpr.cli import generate_app
from rpr.context import RunContext
from rpr.dependencies import (
    ROOT_STORYBOOK_DEV_DEPENDENCIES,
    STORYBOOK_DEV_DEPENDENCIES,
    storybook_package_dependencies,
)
from rpr.workspace import ensure_npm_workspaces, write_package_json

console = Console()
_NO_UI_LIBRARY_ERROR = (
    "[rpr] Error: No UI library found at packages/node/*-ui/. "
    "Run `rpr generate ui <name>` first."
)


def _find_ui_packages(project_dir: Path) -> list[str]:
    """Return UI packages that look like real Nx/UI libraries."""
    node_packages = project_dir / "packages" / "node"
    if not node_packages.exists():
        return []

    matches: list[str] = []
    for child in sorted(node_packages.iterdir(), key=lambda path: path.name):
        if not child.is_dir() or not child.name.endswith("-ui"):
            continue
        if (child / "project.json").exists() or (child / "package.json").exists():
            matches.append(child.name)
    return matches


def _choose_ui_package(ui_packages: list[str]) -> str:
    if len(ui_packages) == 1:
        return ui_packages[0]

    console.print(
        "\n[bold]Multiple UI libraries found.[/] Choose a Storybook target:\n"
    )
    for index, ui_package in enumerate(ui_packages, start=1):
        console.print(f"  {index}. {ui_package}")

    allowed_choices = ", ".join(ui_packages)
    while True:
        raw_selection = typer.prompt("Choose UI library", default="1")
        selection = str(raw_selection).strip()
        if selection.isdigit():
            choice_index = int(selection)
            if 1 <= choice_index <= len(ui_packages):
                return ui_packages[choice_index - 1]
        if selection in ui_packages:
            return selection

        console.print(
            f"[bold red]Error:[/] Invalid choice '{selection}'. "
            f"Enter 1-{len(ui_packages)} or one of: {allowed_choices}"
        )


@generate_app.command()
def storybook(
    ui_package: Annotated[
        str | None,
        typer.Option(
            "--ui-package", help="UI package to target when multiple libraries exist."
        ),
    ] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Preview changes without writing.")
    ] = False,
) -> None:
    """Add a Storybook package for the UI library."""
    ctx = RunContext(dry_run=dry_run, project_dir=Path.cwd())

    ui_packages = _find_ui_packages(ctx.project_dir)
    if not ui_packages:
        if dry_run and ui_package is not None:
            ui_packages = [ui_package]
        else:
            typer.echo(_NO_UI_LIBRARY_ERROR)
            raise typer.Exit(1)

    if ui_package is not None:
        if ui_package not in ui_packages:
            allowed = ", ".join(ui_packages)
            typer.echo(
                f"[rpr] Error: Unknown UI package '{ui_package}'. Valid: {allowed}"
            )
            raise typer.Exit(1)
        ui_pkg = ui_package
    else:
        ui_pkg = _choose_ui_package(ui_packages)
    sb_root = ctx.project_dir / "packages" / "node" / "sb"

    console.print(
        f"\n[bold]Generating Storybook package:[/] sb (importing from {ui_pkg})\n"
    )

    ensure_npm_workspaces(ctx, package_name=ctx.project_dir.name)
    _write_root_storybook_dependency(ctx)

    storybook_dir = sb_root / ".storybook"
    src_root = sb_root / "src"
    starter_story = (
        ctx.project_dir
        / "packages"
        / "node"
        / ui_pkg
        / "src"
        / "stories"
        / "Example.stories.tsx"
    )
    ctx.ensure_dir(storybook_dir)
    ctx.ensure_dir(src_root)
    ctx.ensure_dir(starter_story.parent)

    _write_sb_package_json(ctx, sb_root, ui_pkg)
    _write_sb_project_json(ctx, sb_root)
    _write_sb_tsconfig(ctx, sb_root)
    _write_sb_eslint_config(ctx, sb_root)
    _write_sb_index_html(ctx, sb_root)
    _write_sb_main_tsx(ctx, src_root)
    _write_sb_app(ctx, src_root, ui_pkg)
    _write_sb_app_test(ctx, src_root, ui_pkg)
    _write_sb_vite_config(ctx, sb_root)
    _write_sb_main(ctx, storybook_dir / "main.ts", ui_pkg)
    _write_sb_preview(ctx, storybook_dir / "preview.ts", ui_pkg)
    _write_example_story(ctx, starter_story, ui_pkg)

    ctx.preview_dependencies(
        manager="npm",
        target="workspace root",
        dev=list(ROOT_STORYBOOK_DEV_DEPENDENCIES),
    )
    ctx.preview_dependencies(
        manager="npm",
        target="packages/node/sb",
        runtime=list(storybook_package_dependencies(ui_pkg)),
        dev=list(STORYBOOK_DEV_DEPENDENCIES),
    )

    if not dry_run:
        ctx.run_command(["npm", "install"], cwd=ctx.project_dir)

    ctx.run_command(
        [
            "npx",
            "nx",
            "g",
            "@nx/storybook:configuration",
            "--project=sb",
            "--uiFramework=@storybook/react-vite",
            "--interactionTests=true",
        ],
        cwd=ctx.project_dir,
        supports_dry_run=ctx.project_dir.exists(),
    )

    console.print(f"\n[bold green]Done![/] Storybook created at {sb_root}")
    console.print("  Run with: npx nx storybook sb")


def _write_root_storybook_dependency(ctx: RunContext) -> None:
    write_package_json(
        ctx,
        ctx.project_dir / "package.json",
        defaults={
            "name": ctx.project_dir.name,
            "private": True,
        },
        dev_dependencies=ROOT_STORYBOOK_DEV_DEPENDENCIES,
    )


def _write_sb_package_json(ctx: RunContext, sb_root: Path, ui_pkg: str) -> None:
    write_package_json(
        ctx,
        sb_root / "package.json",
        defaults={
            "name": "@repo/sb",
            "version": "0.1.0",
            "private": True,
            "type": "module",
        },
        dependencies=storybook_package_dependencies(ui_pkg),
        dev_dependencies=STORYBOOK_DEV_DEPENDENCIES,
    )


def _write_sb_project_json(ctx: RunContext, sb_root: Path) -> None:
    project = {
        "name": "sb",
        "root": "packages/node/sb",
        "targets": {
            "serve": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "npx vite",
                    "cwd": "packages/node/sb",
                },
            },
            "build": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "npx vite build",
                    "cwd": "packages/node/sb",
                },
            },
            "lint": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "npx eslint .",
                    "cwd": "packages/node/sb",
                },
            },
            "test": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "npx vitest run",
                    "cwd": "packages/node/sb",
                },
            },
            "typecheck": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "npx tsc --noEmit",
                    "cwd": "packages/node/sb",
                },
            },
            "storybook": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "storybook dev -p 6006 -c packages/node/sb/.storybook",
                },
            },
            "build-storybook": {
                "executor": "nx:run-commands",
                "options": {
                    "command": "storybook build -c packages/node/sb/.storybook -o dist/storybook",
                },
            },
        },
    }
    ctx.write_file(sb_root / "project.json", json.dumps(project, indent=2) + "\n")


def _write_sb_tsconfig(ctx: RunContext, sb_root: Path) -> None:
        content = """{
    "extends": "../../../tsconfig.base.json",
    "compilerOptions": {
        "jsx": "react-jsx",
        "outDir": "dist",
        "rootDir": "src"
    },
    "include": ["src", ".storybook"]
}
"""
        ctx.write_file(sb_root / "tsconfig.json", content)


def _write_sb_eslint_config(ctx: RunContext, sb_root: Path) -> None:
        content = """import baseConfig from "../../../eslint.config.mjs";

export default [...baseConfig];
"""
        ctx.write_file(sb_root / "eslint.config.mjs", content)


def _write_sb_index_html(ctx: RunContext, sb_root: Path) -> None:
        content = """<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Storybook Host</title>
    </head>
    <body>
        <div id="root"></div>
        <script type="module" src="/src/main.tsx"></script>
    </body>
</html>
"""
        ctx.write_file(sb_root / "index.html", content)


def _write_sb_main_tsx(ctx: RunContext, src_root: Path) -> None:
        content = """import React from "react";
import ReactDOM from "react-dom/client";
import { App } from "./App";

ReactDOM.createRoot(document.getElementById("root")!).render(
    <React.StrictMode>
        <App />
    </React.StrictMode>,
);
"""
        ctx.write_file(src_root / "main.tsx", content)


def _write_sb_app(ctx: RunContext, src_root: Path, ui_pkg: str) -> None:
        content = f"""import {{ uiPackageName }} from "@repo/{ui_pkg}";

export const storybookHostTitle = "Storybook Host";

export const App = () => {{
    return (
        <div>
            <h1>{{storybookHostTitle}}</h1>
            <p>Rendering stories from {{uiPackageName}}</p>
        </div>
    );
}};
"""
        ctx.write_file(src_root / "App.tsx", content)


def _write_sb_app_test(ctx: RunContext, src_root: Path, ui_pkg: str) -> None:
        content = """import { describe, expect, it } from "vitest";

import { storybookHostTitle } from "./App";


describe("storybook host", () => {
    it("exports a stable host title", () => {
        expect(storybookHostTitle).toBe("Storybook Host");
    });
});
"""
        ctx.write_file(src_root / "App.test.ts", content)


def _write_sb_vite_config(ctx: RunContext, sb_root: Path) -> None:
        content = """import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
    plugins: [react()],
});
"""
        ctx.write_file(sb_root / "vite.config.ts", content)


def _write_sb_main(ctx: RunContext, path: Path, ui_pkg: str) -> None:
    content = f"""import type {{ StorybookConfig }} from "@storybook/react-vite";

const config: StorybookConfig = {{
  stories: [
    "../../{ui_pkg}/src/**/*.stories.@(ts|tsx)",
  ],
  addons: ["@storybook/addon-essentials"],
  framework: {{
    name: "@storybook/react-vite",
    options: {{}},
  }},
}};

export default config;
"""
    ctx.write_file(path, content)


def _write_sb_preview(ctx: RunContext, path: Path, ui_pkg: str) -> None:
    content = """import { appTheme } from "@repo/__UI_PKG__";
import { CssBaseline, ThemeProvider } from "@mui/material";
import type { Preview } from "@storybook/react";
import { Fragment, createElement } from "react";

const preview: Preview = {
  decorators: [
    (Story) =>
      createElement(
        ThemeProvider,
        { theme: appTheme },
        createElement(
          Fragment,
          null,
          createElement(CssBaseline),
          createElement(Story),
        ),
      ),
  ],
  parameters: {
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
  },
};

export default preview;
""".replace("__UI_PKG__", ui_pkg)
    ctx.write_file(path, content)


def _write_example_story(ctx: RunContext, path: Path, ui_pkg: str) -> None:
    content = f"""import type {{ Meta, StoryObj }} from "@storybook/react";
import {{ uiPackageName }} from "../index";

const ExampleComponent = () => <div>Hello from {{uiPackageName}}</div>;

const meta: Meta<typeof ExampleComponent> = {{
  title: "{ui_pkg}/Example",
  component: ExampleComponent,
}};

export default meta;
type Story = StoryObj<typeof ExampleComponent>;

export const Default: Story = {{}};
"""
    ctx.write_file(path, content)
