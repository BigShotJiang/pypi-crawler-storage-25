from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from pprint import pformat
import re
from collections.abc import Mapping

from rpr.dependency_manifest_data import MANIFEST

MANIFEST_DATA_PATH = Path(__file__).with_name("dependency_manifest_data.py")


def get_dependency_manifest() -> dict[str, dict[str, dict[str, str]]]:
    return deepcopy(MANIFEST)


def render_dependency_manifest_module(
    manifest: dict[str, dict[str, dict[str, str]]],
) -> str:
    body = pformat(manifest, width=88, sort_dicts=False)
    return (
        "from __future__ import annotations\n\n"
        "# This file is maintained by `rpr refresh manifest`.\n"
        "# Keep the structure stable so the refresh command can rewrite it safely.\n\n"
        f"MANIFEST = {body}\n"
    )


def _mapping_section(name: str) -> dict[str, str]:
    return {
        dependency: entry["specifier"]
        for dependency, entry in MANIFEST[name].items()
    }


def _list_section(name: str) -> list[str]:
    return [entry["specifier"] for entry in MANIFEST[name].values()]

ROOT_NODE_DEV_DEPENDENCIES = _mapping_section("root_node_dev_dependencies")

ROOT_STORYBOOK_DEV_DEPENDENCIES = _mapping_section(
    "root_storybook_dev_dependencies"
)

UI_LIBRARY_DEPENDENCIES = _mapping_section("ui_library_dependencies")

UI_LIBRARY_DEV_DEPENDENCIES = _mapping_section("ui_library_dev_dependencies")

WEB_APP_DEV_DEPENDENCIES = _mapping_section("web_app_dev_dependencies")

STORYBOOK_DEPENDENCIES = _mapping_section("storybook_dependencies")

STORYBOOK_DEV_DEPENDENCIES = _mapping_section("storybook_dev_dependencies")

DOMAIN_RUNTIME_DEPENDENCIES = _list_section("domain_runtime_dependencies")

DOMAIN_MIGRATION_DEPENDENCIES = _list_section("domain_migration_dependencies")

FASTAPI_SPEC = MANIFEST["api_runtime_base_dependencies"]["fastapi"]["specifier"]
UVICORN_SPEC = MANIFEST["api_runtime_base_dependencies"]["uvicorn[standard]"][
    "specifier"
]
API_RUNTIME_BASE_DEPENDENCIES = [FASTAPI_SPEC, UVICORN_SPEC]

PYO3_VERSION = MANIFEST["engine"]["pyo3"]["specifier"]
MATURIN_SPEC = MANIFEST["engine"]["maturin"]["specifier"]


def web_app_dependencies(ui_pkg_name: str) -> dict[str, str]:
    return {
        f"@repo/{ui_pkg_name}": "workspace:*",
        "react": UI_LIBRARY_DEPENDENCIES["react"],
        "react-dom": UI_LIBRARY_DEPENDENCIES["react-dom"],
    }


def storybook_package_dependencies(ui_pkg_name: str) -> dict[str, str]:
    return {
        f"@repo/{ui_pkg_name}": "workspace:*",
        **STORYBOOK_DEPENDENCIES,
    }


def api_runtime_dependencies(name: str) -> list[str]:
    return [f"{name}-domain", *API_RUNTIME_BASE_DEPENDENCIES]


def domain_dependencies(*, include_migrations: bool) -> list[str]:
    dependencies = list(DOMAIN_RUNTIME_DEPENDENCIES)
    if include_migrations:
        dependencies.extend(DOMAIN_MIGRATION_DEPENDENCIES)
    return dependencies


def dependency_names(specs: list[str]) -> set[str]:
    return {dependency_name(spec) for spec in specs}


def mapping_dependency_names(specs: Mapping[str, str]) -> set[str]:
    return set(specs)


def dependency_name(spec: str) -> str:
    match = re.match(r"^[A-Za-z0-9_.-]+(?:\[[^\]]+\])?", spec)
    if match is None:
        return spec
    return match.group(0)


def tech_stack_instruction_variables() -> dict[str, str]:
    return {
        "tech_stack_workspace": (
            "NX for workspace orchestration and UV for Python environments and dependency management"
        ),
        "tech_stack_frontend": (
            "React ({react}), TanStack Query ({query}), TanStack Router ({router}), "
            "MUI ({mui}), Vite ({vite}), and Vitest ({vitest}) on the Node/UI side"
        ).format(
            react=UI_LIBRARY_DEPENDENCIES["react"],
            query=UI_LIBRARY_DEPENDENCIES["@tanstack/react-query"],
            router=UI_LIBRARY_DEPENDENCIES["@tanstack/react-router"],
            mui=UI_LIBRARY_DEPENDENCIES["@mui/material"],
            vite=UI_LIBRARY_DEV_DEPENDENCIES["vite"],
            vitest=UI_LIBRARY_DEV_DEPENDENCIES["vitest"],
        ),
        "tech_stack_backend": (
            "FastAPI ({fastapi}), Uvicorn ({uvicorn}), SQLModel, Alembic, and Dependency Injector on the Python side"
        ).format(
            fastapi=FASTAPI_SPEC.removeprefix("fastapi"),
            uvicorn=UVICORN_SPEC.removeprefix("uvicorn[standard]"),
        ),
        "tech_stack_engine": (
            "Rust with PyO3 ({pyo3}) and Maturin ({maturin}) for the engine package"
        ).format(
            pyo3=PYO3_VERSION,
            maturin=MATURIN_SPEC.removeprefix("maturin"),
        ),
        "tech_stack_storybook": (
            "Storybook ({storybook}) for isolated UI development"
        ).format(storybook=STORYBOOK_DEV_DEPENDENCIES["storybook"]),
        "rust_engine_pyo3_dependency": (
            f'pyo3 = {{ version = "{PYO3_VERSION}", features = ["extension-module"] }}'
        ),
    }