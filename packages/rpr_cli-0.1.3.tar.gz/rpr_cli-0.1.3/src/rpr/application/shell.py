from __future__ import annotations

import argparse
import shlex
from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar, Protocol

import typer

from rpr.agent.bootstrap import ChatRuntimeBundle
from rpr.agent.control import TurnControl
from rpr.application.catalog import COMMAND_CATALOG, chat_commands, usage_string
from rpr.application.checks import collect_check_report
from rpr.ui.theme import SETTING_DEFINITIONS, settings_manager


class ShellArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise ValueError(message)


class ShellPresenter(Protocol):
    def flush(self) -> None: ...

    def heading(self, text: str) -> None: ...

    def info(self, message: str) -> None: ...

    def success(self, message: str) -> None: ...

    def warning(self, message: str) -> None: ...

    def error(self, message: str) -> None: ...

    def table(self, title: str, columns: list[str], rows: list[list[str]]) -> None: ...

    def status_row(
        self,
        icon_char: str,
        area: str,
        path: str,
        status: bool,
        suggestion: str | None = None,
    ) -> None: ...

    def on_setting_changed(self, key: str) -> None: ...


class ShellInputService(Protocol):
    async def prompt(self, label: str, *, default: str | None = None) -> str: ...

    async def confirm(self, label: str, *, default: bool = False) -> bool: ...


@dataclass(slots=True, frozen=True)
class SlashCommandSpec:
    name: str
    usage: str
    description: str


@dataclass(slots=True, frozen=True)
class ParsedSlashCommand:
    name: str
    args: list[str]


class CommandShellService:
    _instance: ClassVar[CommandShellService | None] = None

    def __init__(self) -> None:
        self._bundle: ChatRuntimeBundle | None = None
        self._presenter: ShellPresenter | None = None
        self._prompts: ShellInputService | None = None
        self._command_specs = {
            cmd.name: SlashCommandSpec(
                name=cmd.name,
                usage=usage_string(cmd),
                description=cmd.description,
            )
            for cmd in chat_commands(COMMAND_CATALOG)
        }

    @classmethod
    def instance(cls) -> CommandShellService:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def configure(
        self,
        *,
        bundle: ChatRuntimeBundle,
        presenter: ShellPresenter,
        prompts: ShellInputService,
    ) -> None:
        self._bundle = bundle
        self._presenter = presenter
        self._prompts = prompts

    @property
    def command_specs(self) -> list[SlashCommandSpec]:
        return [self._command_specs[name] for name in sorted(self._command_specs)]

    @property
    def _active_bundle(self) -> ChatRuntimeBundle:
        if self._bundle is None:
            raise RuntimeError("Command shell service is not configured.")
        return self._bundle

    @property
    def _active_presenter(self) -> ShellPresenter:
        if self._presenter is None:
            raise RuntimeError("Command shell service is not configured.")
        return self._presenter

    @property
    def _active_prompts(self) -> ShellInputService:
        if self._prompts is None:
            raise RuntimeError("Command shell service is not configured.")
        return self._prompts

    async def handle_input(
        self, user_input: str, *, control: TurnControl | None = None
    ) -> bool:
        normalized = user_input.strip()
        if not normalized:
            return True

        if normalized.lower() in {"exit", "quit"}:
            normalized = "/exit"

        if not normalized.startswith("/"):
            await self._active_bundle.runtime.execute_turn(normalized, control=control)
            return True

        parsed = self._parse_slash_command(normalized)
        if parsed is None:
            return True

        handlers = {
            "help": self._handle_help,
            "exit": self._handle_exit,
            "settings": self._handle_settings,
            "init": self._handle_init,
            "generate": self._handle_generate,
            "sync": self._handle_sync,
            "add": self._handle_add,
            "check": self._handle_check,
            "map": self._handle_map,
        }
        handler = handlers.get(parsed.name)
        if handler is None:
            self._active_presenter.error(f"Unknown slash command: /{parsed.name}")
            self._active_presenter.info(
                "Run /help to inspect the supported command surface."
            )
            return True

        try:
            return await handler(parsed)
        except ValueError as exc:
            self._active_presenter.error(str(exc))
            return True
        except Exception as exc:
            self._active_presenter.error(f"Command failed: {exc}")
            return True

    def _parse_slash_command(self, raw_input: str) -> ParsedSlashCommand | None:
        command_body = raw_input[1:].strip()
        if not command_body:
            self._active_presenter.error(
                "Empty slash command. Run /help to inspect the command surface."
            )
            return None

        try:
            tokens = shlex.split(command_body)
        except ValueError as exc:
            self._active_presenter.error(f"Unable to parse command: {exc}")
            return None

        if not tokens:
            self._active_presenter.error(
                "Empty slash command. Run /help to inspect the command surface."
            )
            return None

        return ParsedSlashCommand(name=tokens[0].lower(), args=tokens[1:])

    def _parse_args(
        self, parser: ShellArgumentParser, args: list[str]
    ) -> argparse.Namespace | None:
        try:
            return parser.parse_args(args)
        except ValueError as exc:
            self._active_presenter.error(str(exc))
            return None

    def _invoke_command(self, callback, /, *args, **kwargs) -> int:
        try:
            callback(*args, **kwargs)
        except typer.Exit as exc:
            return int(exc.exit_code or 0)
        return 0

    async def _handle_help(self, parsed: ParsedSlashCommand) -> bool:
        del parsed
        rows = [
            [spec.name, spec.usage, spec.description] for spec in self.command_specs
        ]
        self._active_presenter.table(
            "Slash Commands", ["Command", "Usage", "Description"], rows
        )
        self._active_presenter.info(
            "Session state: "
            f"approval_mode={self._active_bundle.session.approval_mode.value}, "
            f"project_root={self._active_bundle.ctx.project_dir}"
        )
        return True

    async def _handle_exit(self, parsed: ParsedSlashCommand) -> bool:
        del parsed
        self._active_presenter.info("Session ended.")
        return False

    async def _handle_settings(self, parsed: ParsedSlashCommand) -> bool:
        parser = ShellArgumentParser(prog="/settings", add_help=False)
        parser.add_argument("action", nargs="?")
        parser.add_argument("key", nargs="?")
        parser.add_argument("value", nargs="?")
        namespace = self._parse_args(parser, parsed.args)
        if namespace is None:
            return True

        action = None if namespace.action is None else namespace.action.lower()
        if action in {None, "list"}:
            self._render_settings_table()
            if action == "list":
                return True
            return await self._interactive_settings_update()

        if action == "get":
            if not namespace.key:
                raise ValueError("Usage: /settings get <key>")
            self._ensure_setting_exists(namespace.key)
            self._active_presenter.info(
                f"{namespace.key}: {self._format_setting_value(namespace.key)}"
            )
            return True

        if action == "set":
            if not namespace.key:
                raise ValueError("Usage: /settings set <key> <value>")
            self._ensure_setting_exists(namespace.key)
            value = namespace.value
            if value is None:
                value = await self._active_prompts.prompt(
                    f"New value for {namespace.key}",
                    default=self._format_setting_value(namespace.key),
                )
            return await self._apply_setting_change(namespace.key, value)

        raise ValueError(
            "Usage: /settings | /settings get <key> | /settings set <key> <value>"
        )

    async def _handle_init(self, parsed: ParsedSlashCommand) -> bool:
        from rpr.commands import init as init_command

        parser = ShellArgumentParser(prog="/init", add_help=False)
        parser.add_argument("project_name", nargs="?")
        parser.add_argument("--dry-run", action="store_true")
        parser.add_argument("--python", default="3.14")
        namespace = self._parse_args(parser, parsed.args)
        if namespace is None:
            return True

        project_name = namespace.project_name or await self._active_prompts.prompt(
            "Project name"
        )
        if not project_name.strip():
            self._active_presenter.warning("Initialization cancelled.")
            return True

        self._active_presenter.info(f"Running /init for {project_name}.")
        exit_code = self._invoke_command(
            init_command.init,
            project_name=project_name,
            dry_run=namespace.dry_run,
            python_version=namespace.python,
        )
        if exit_code:
            self._active_presenter.error(f"/init finished with exit code {exit_code}.")
        return True

    async def _handle_generate(self, parsed: ParsedSlashCommand) -> bool:
        from rpr.commands.generate import api as generate_api_command
        from rpr.commands.generate import domain as generate_domain_command
        from rpr.commands.generate import engine as generate_engine_command
        from rpr.commands.generate import storybook as generate_storybook_command
        from rpr.commands.generate import ui as generate_ui_command

        parser = ShellArgumentParser(prog="/generate", add_help=False)
        subparsers = parser.add_subparsers(dest="target")

        for name in ("domain", "api", "ui", "engine"):
            subparser = subparsers.add_parser(name, add_help=False)
            subparser.add_argument("name", nargs="?")
            subparser.add_argument("--dry-run", action="store_true")

        storybook_parser = subparsers.add_parser("storybook", add_help=False)
        storybook_parser.add_argument("--dry-run", action="store_true")
        storybook_parser.add_argument("--ui-package")

        namespace = self._parse_args(parser, parsed.args)
        if namespace is None:
            return True
        if namespace.target is None:
            raise ValueError("Usage: /generate <domain|api|ui|engine|storybook> ...")

        if namespace.target == "domain":
            name = namespace.name or await self._active_prompts.prompt("App name")
            self._invoke_command(
                generate_domain_command.domain, name=name, dry_run=namespace.dry_run
            )
            return True
        if namespace.target == "api":
            name = namespace.name or await self._active_prompts.prompt("App name")
            self._invoke_command(
                generate_api_command.api, name=name, dry_run=namespace.dry_run
            )
            return True
        if namespace.target == "ui":
            name = namespace.name or await self._active_prompts.prompt("App name")
            self._invoke_command(
                generate_ui_command.ui, name=name, dry_run=namespace.dry_run
            )
            return True
        if namespace.target == "engine":
            name = namespace.name or await self._active_prompts.prompt("App name")
            self._invoke_command(
                generate_engine_command.engine, name=name, dry_run=namespace.dry_run
            )
            return True

        ui_package = namespace.ui_package
        if not ui_package:
            ui_packages = generate_storybook_command._find_ui_packages(
                self._bundle.ctx.project_dir
            )
            if len(ui_packages) == 1:
                ui_package = ui_packages[0]
            elif len(ui_packages) > 1:
                self._active_presenter.table(
                    "Storybook Targets",
                    ["Package"],
                    [[package] for package in ui_packages],
                )
                ui_package = (
                    await self._active_prompts.prompt(
                        "UI package", default=ui_packages[0]
                    )
                ).strip() or ui_packages[0]

        self._invoke_command(
            generate_storybook_command.storybook,
            dry_run=namespace.dry_run,
            ui_package=ui_package,
        )
        return True

    async def _handle_sync(self, parsed: ParsedSlashCommand) -> bool:
        from rpr.commands import sync as sync_command

        parser = ShellArgumentParser(prog="/sync", add_help=False)
        parser.add_argument("action", nargs="?", default="rules")
        parser.add_argument("--target")
        parser.add_argument("--dry-run", action="store_true")
        namespace = self._parse_args(parser, parsed.args)
        if namespace is None:
            return True
        if namespace.action != "rules":
            raise ValueError("Usage: /sync [rules] [--target cursor] [--dry-run]")

        self._invoke_command(
            sync_command.rules, target=namespace.target, dry_run=namespace.dry_run
        )
        return True

    async def _handle_add(self, parsed: ParsedSlashCommand) -> bool:
        from rpr.commands import add as add_command

        parser = ShellArgumentParser(prog="/add", add_help=False)
        parser.add_argument("action", nargs="?", default="template")
        parser.add_argument("template_id", nargs="?")
        parser.add_argument("--list", action="store_true")
        parser.add_argument("--force", action="store_true")
        parser.add_argument("--name")
        parser.add_argument("--source")
        parser.add_argument("--dry-run", action="store_true")
        namespace = self._parse_args(parser, parsed.args)
        if namespace is None:
            return True
        if namespace.action != "template":
            raise ValueError(
                "Usage: /add template <template-id> [--name app] [--force] [--dry-run]"
            )

        template_id = namespace.template_id
        if template_id is None and not namespace.list:
            template_id = await self._active_prompts.prompt("Template ID")

        self._invoke_command(
            add_command.template,
            template_id=template_id,
            list_templates=namespace.list,
            force=namespace.force,
            name=namespace.name,
            source=namespace.source,
            dry_run=namespace.dry_run,
        )
        return True

    async def _handle_check(self, parsed: ParsedSlashCommand) -> bool:
        parser = ShellArgumentParser(prog="/check", add_help=False)
        parser.add_argument("--group")
        namespace = self._parse_args(parser, parsed.args)
        if namespace is None:
            return True

        report = collect_check_report(
            self._active_bundle.ctx.project_dir, group=namespace.group
        )
        self._active_presenter.heading(f"rpr check — project: {report.project_name}")
        current_group = None
        for result in report.results:
            if result.group != current_group:
                current_group = result.group
                self._active_presenter.info(current_group)
            self._active_presenter.status_row(
                "✓" if result.status else "✗",
                result.area,
                str(result.path),
                result.status,
                result.suggestion,
            )

        failures = sum(1 for result in report.results if not result.status)
        if failures:
            self._active_presenter.error(
                f"Check completed with {failures} failing item(s)."
            )
        else:
            self._active_presenter.success("Check completed with no failing items.")
        return True

    async def _handle_map(self, parsed: ParsedSlashCommand) -> bool:
        from rpr.commands import map as map_command

        parser = ShellArgumentParser(prog="/map", add_help=False)
        parser.add_argument("--root", default=".")
        parser.add_argument("--output", default="code-map.md")
        parser.add_argument("--dry-run", action="store_true")
        namespace = self._parse_args(parser, parsed.args)
        if namespace is None:
            return True

        exit_code = self._invoke_command(
            map_command.map,
            root=Path(namespace.root),
            output=Path(namespace.output),
            dry_run=namespace.dry_run,
        )
        if exit_code:
            self._active_presenter.error(f"/map finished with exit code {exit_code}.")
        return True

    def _render_settings_table(self) -> None:
        rows = []
        for definition, value in settings_manager.describe_settings():
            allowed = (
                ", ".join(definition.choices) if definition.choices else "true, false"
            )
            rows.append([definition.key, value, allowed, definition.description])
        self._active_presenter.table(
            "RPR Settings", ["Key", "Value", "Allowed", "Description"], rows
        )

    async def _interactive_settings_update(self) -> bool:
        key = (
            await self._active_prompts.prompt("Setting to edit (blank to cancel)")
        ).strip()
        if not key:
            self._active_presenter.info("Settings update cancelled.")
            return True

        self._ensure_setting_exists(key)
        definition = SETTING_DEFINITIONS[key]
        allowed = ", ".join(definition.choices) if definition.choices else "true, false"
        self._active_presenter.info(f"Current {key}: {self._format_setting_value(key)}")
        self._active_presenter.info(f"Allowed values: {allowed}")
        value = await self._active_prompts.prompt(
            f"New value for {key}",
            default=self._format_setting_value(key),
        )
        return await self._apply_setting_change(key, value)

    def _ensure_setting_exists(self, key: str) -> None:
        if key not in SETTING_DEFINITIONS:
            raise ValueError(f"Unknown setting: {key}")

    def _format_setting_value(self, key: str) -> str:
        value = settings_manager.get_value(key)
        if isinstance(value, bool):
            return "true" if value else "false"
        return value

    async def _apply_setting_change(self, key: str, value: str) -> bool:
        self._ensure_setting_exists(key)
        if not await self._active_prompts.confirm(
            f"Persist {key} = {value}?", default=True
        ):
            self._active_presenter.info("Settings update cancelled.")
            return True

        try:
            settings_manager.set_value(key, value)
        except ValueError as exc:
            self._active_presenter.error(str(exc))
            return True

        if key == "approval_mode":
            self._active_bundle.session.approval_mode = settings_manager.approval_mode

        self._active_presenter.on_setting_changed(key)
        self._active_presenter.success(
            f"Updated {key} to {self._format_setting_value(key)}."
        )
        return True
