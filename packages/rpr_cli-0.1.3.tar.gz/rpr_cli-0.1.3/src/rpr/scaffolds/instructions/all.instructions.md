---
applyTo: "**"
description: "Project overview, monorepo structure, and tech stack for DDD architecture"
---

# Project Overview

This project uses an NX + UV monorepo with a domain-driven design approach. Applications stay thin and delegate business logic to shared packages.

## Architecture

- **Applications** (`apps/*`): frontend apps, APIs, and other entry points. Keep them focused on transport, composition, and configuration.
- **Packages**: shared domain logic, reusable UI code, Storybook, and Rust-backed engine code.
- **Domain layer**: entities, DTOs, repositories, services, workflows, and dependency injection. Keep boundaries explicit and data flow predictable.

## Tech Stack

- {tech_stack_workspace}
- {tech_stack_frontend}
- {tech_stack_backend}
- {tech_stack_engine}
- {tech_stack_storybook}

## Layout

| Path                            | Purpose                                                                  |
| ------------------------------- | ------------------------------------------------------------------------ |
| `apps/{name}-web`               | Thin frontend application shell                                          |
| `apps/{name}-api`               | FastAPI application                                                      |
| `packages/node/{name}-ui`       | Reusable UI package with components, hooks, services, and state          |
| `packages/node/sb`              | Storybook package                                                        |
| `packages/python/domain`        | Python domain package containing the `src/{name_underscore}_domain` code |
| `packages/python/{name}-engine` | Rust engine package exposed to Python                                    |

## Instructions, Templates, and Scaffolds

- Instruction files describe when to use a pattern and what constraints to follow.
- `setup-guide.instructions.md` captures the NX + UV workspace contract for root setup, project layout, naming, and expected command surfaces.
- `tooling.instructions.md` defines workspace-wide linting, formatting, and pre-commit conventions.
- `tooling-setup.instructions.md` contains detailed setup guidance for root tooling files such as `pyproject.toml`, `nx.json`, `.pre-commit-config.yaml`, and `eslint.config.mjs`.
- Shared utility implementations should live in stable project paths so code can reuse them instead of duplicating the same helpers in multiple places.
- Files in `.github/scaffolds/` are reference examples. Use them as guidance if they exist, but do not force the codebase to match them when local conventions already differ.

## Path-Specific Instructions

- **API**: `api.instructions.md` for routes, dependency injection, and error handling
- **Domain**: `domain.instructions.md` for entities, DTOs, repositories, services, and workflows
- **Frontend**: `frontend.instructions.md` for React, TanStack Query, TanStack Router, and MUI patterns
- **Rust engine**: `rust-engine.instructions.md` for PyO3, Maturin, and NX engine targets
