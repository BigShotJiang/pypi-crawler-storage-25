---
applyTo: "packages/python/*-engine/**"
description: "Rust + PyO3 engine build, lint, and Python bindings"
---

# Rust Engine

Use Rust for performance-sensitive code that needs a Python-facing API. This package uses PyO3 for bindings and Maturin as the Python build backend.

## Structure

- Package root: `packages/python/{name}-engine`
- Rust source: `packages/python/{name}-engine/src/lib.rs`
- Python build metadata: `packages/python/{name}-engine/pyproject.toml`
- Type stubs: keep a `.pyi` file next to the package root for editor support

## Build and Tooling

- Use `{rust_engine_pyo3_dependency}` for Python bindings.
- Use Maturin as the build backend in `pyproject.toml`.
- Keep the PyO3 module name in underscore form so it matches the generated Rust module and stub file names.
- Use Rayon only when the engine actually performs parallel work. Do not add concurrency primitives speculatively.

## NX Targets

- `engine:build` should run `uv run maturin develop` from the engine package directory.
- `engine:lint` should run `cargo clippy --all-targets --all-features -- -D warnings`.
- `engine:format` should run `cargo fmt --check`.

## Binding Conventions

- Keep the Python-facing API small and explicit. Expose a small set of well-typed functions rather than mirroring large internal Rust modules.
- Use `#[pyfunction]` for individual exported functions and register them in the `#[pymodule]` entrypoint.
- Favor simple Python-friendly return types unless there is a strong reason to expose a richer binding surface.
- Update the `.pyi` stub whenever the exported Python API changes.

## Package Boundaries

- Keep domain business rules in the Python domain layer unless the logic is genuinely performance-sensitive or requires Rust-specific capabilities.
- Treat the engine as an implementation detail behind a stable Python-facing contract.
