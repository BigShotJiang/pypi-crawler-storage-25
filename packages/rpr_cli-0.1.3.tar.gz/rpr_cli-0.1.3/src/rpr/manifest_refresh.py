from __future__ import annotations

import json
import re
from copy import deepcopy
from dataclasses import dataclass
from typing import Literal
from urllib.parse import quote
from urllib.request import Request, urlopen

RegistryName = Literal["npm", "pypi", "cratesio"]
RefreshStrategy = Literal["caret", "minimum", "exact", "major-range"]
Manifest = dict[str, dict[str, dict[str, str]]]

_USER_AGENT = "rpr-cli/0.1.1 (+https://github.com/)"


class ManifestRefreshError(RuntimeError):
    pass


@dataclass(frozen=True)
class ManifestChange:
    section: str
    dependency: str
    old_specifier: str
    new_specifier: str
    registry: str
    package: str
    latest_version: str


def fetch_latest_version(
    registry: RegistryName, package: str, *, timeout: float = 10.0
) -> str:
    if registry == "npm":
        url = f"https://registry.npmjs.org/{quote(package, safe='')}/latest"
    elif registry == "pypi":
        url = f"https://pypi.org/pypi/{quote(package, safe='')}/json"
    else:
        url = f"https://crates.io/api/v1/crates/{quote(package, safe='')}"

    request = Request(url, headers={"User-Agent": _USER_AGENT})
    try:
        with urlopen(request, timeout=timeout) as response:
            payload = json.load(response)
    except Exception as exc:  # pragma: no cover - exercised through command tests
        raise ManifestRefreshError(
            f"Failed to fetch {registry} metadata for {package}: {exc}"
        ) from exc

    try:
        if registry == "npm":
            return str(payload["version"])
        if registry == "pypi":
            return str(payload["info"]["version"])
        crate = payload["crate"]
        return str(crate.get("max_stable_version") or crate["max_version"])
    except Exception as exc:  # pragma: no cover - exercised through command tests
        raise ManifestRefreshError(
            f"Registry response for {package} did not include a usable version"
        ) from exc


def refresh_dependency_manifest(
    manifest: Manifest,
    *,
    timeout: float = 10.0,
) -> tuple[Manifest, list[ManifestChange]]:
    refreshed = deepcopy(manifest)
    changes: list[ManifestChange] = []
    latest_version_cache: dict[tuple[str, str], str] = {}

    for section, dependencies in refreshed.items():
        for dependency, entry in dependencies.items():
            registry = entry.get("registry")
            strategy = entry.get("strategy")
            if registry is None or strategy is None:
                continue

            package = entry.get("package", dependency)
            cache_key = (registry, package)
            latest_version = latest_version_cache.get(cache_key)
            if latest_version is None:
                latest_version = fetch_latest_version(registry, package, timeout=timeout)
                latest_version_cache[cache_key] = latest_version

            new_specifier = _format_specifier(strategy, dependency, package, latest_version)
            old_specifier = entry["specifier"]
            if new_specifier == old_specifier:
                continue

            entry["specifier"] = new_specifier
            changes.append(
                ManifestChange(
                    section=section,
                    dependency=dependency,
                    old_specifier=old_specifier,
                    new_specifier=new_specifier,
                    registry=registry,
                    package=package,
                    latest_version=latest_version,
                )
            )

    return refreshed, changes


def _format_specifier(
    strategy: str, dependency: str, package: str, latest_version: str
) -> str:
    if strategy == "caret":
        return f"^{latest_version}"
    if strategy == "minimum":
        if dependency == package:
            return f"{dependency}>={latest_version}"
        return f"{dependency}>={latest_version}"
    if strategy == "exact":
        return latest_version
    if strategy == "major-range":
        next_major = _next_major(latest_version)
        return f"{package}>={latest_version},<{next_major}.0"
    raise ManifestRefreshError(f"Unsupported refresh strategy: {strategy}")


def _next_major(version: str) -> int:
    match = re.match(r"^(\d+)", version)
    if match is None:
        raise ManifestRefreshError(f"Cannot determine next major version for {version}")
    return int(match.group(1)) + 1