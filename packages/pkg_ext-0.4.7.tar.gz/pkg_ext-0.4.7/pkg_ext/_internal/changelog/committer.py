import difflib
import logging
from collections import Counter
from contextlib import suppress

from ask_shell._internal.rich_live import print_to_live
from rich.markdown import Markdown

from pkg_ext._internal.changelog.actions import FixAction
from pkg_ext._internal.changelog.rebase import (
    UnmatchedResolution,
    apply_remap_to_actions,
    build_sha_remap,
    find_stale_shas,
    prompt_unmatched_fix,
    remove_actions_by_sha,
)
from pkg_ext._internal.context import pkg_ctx
from pkg_ext._internal.errors import NoPublicGroupMatch
from pkg_ext._internal.git_usage.state import GitCommit
from pkg_ext._internal.interactive import (
    SKIPPED,
    CommitFixAction,
    select_commit_fix,
    select_commit_rephrased,
    select_group_name_or_skip,
)
from pkg_ext._internal.models import PublicGroup, PublicGroups, as_module_path
from pkg_ext._internal.pkg_state import PkgExtState

logger = logging.getLogger(__name__)


def py_diff(old: str, new: str) -> str:
    old_lines = old.splitlines()
    new_lines = new.splitlines()
    ndiff = list(difflib.ndiff(old_lines, new_lines))
    unified_diff = list(difflib.unified_diff(old_lines, new_lines))
    len_diffs = [
        (len(ndiff), ndiff),
        (len(unified_diff), unified_diff),
    ]
    _, diff = min(len_diffs)
    return "\n".join(diff)


def rich_diff(old: str, new: str) -> Markdown:
    diff = py_diff(old, new)
    return Markdown(
        f"""
```diff
{diff}
```"""
    )


def infer_group(groups: PublicGroups, changes: dict[str, str]) -> str:
    group_counts = Counter()
    for rel_path, diff in changes.items():
        with suppress(NoPublicGroupMatch):
            group = groups.matching_group_by_module_path(as_module_path(rel_path))
            group_counts[group.name] += len(diff.splitlines())
    if not group_counts:
        return ""
    return group_counts.most_common(1)[0][0]


def prompt_for_fix(sha: str, commit_message: str, prompt_text: str) -> FixAction:
    fix = FixAction(
        name="",  # will be set by caller
        short_sha=sha,
        message=commit_message,
        changelog_message=commit_message,
    )
    match select_commit_fix(prompt_text):
        case CommitFixAction.REPHRASE:
            fix.changelog_message = select_commit_rephrased(commit_message)
            fix.rephrased = True
        case CommitFixAction.EXCLUDE:
            fix.ignored = True
    return fix


def fix_changelog_action(commit: GitCommit, ctx: pkg_ctx) -> FixAction | None:
    tool_state = ctx.tool_state
    git_changes = ctx.git_changes
    assert git_changes
    pkg_changes = sorted(
        changed_path for changed_path in commit.file_changes if tool_state.is_pkg_relative(changed_path)
    )
    if not pkg_changes:
        return None
    prompt_context = []
    diff_suffixes = ctx.settings.commit_fix_diff_suffixes
    diffs: dict[str, str] = {}
    for rel_path in pkg_changes:
        if not git_changes.has_change(rel_path) or not rel_path.endswith(diff_suffixes):
            continue
        path = tool_state.full_path(rel_path)
        if not path.exists():
            continue
        new_content = path.read_text()
        old_content = git_changes.old_version(rel_path)
        diffs[rel_path] = diff = py_diff(old_content, new_content)
        prompt_context.extend(
            [
                f"### {rel_path} ###",
                diff,
            ]
        )
    prompt_md = Markdown("\n".join(prompt_context))
    print_to_live(prompt_md)
    commit_message = commit.message
    commit_sha = commit.sha

    groups = tool_state.groups
    group = infer_group(groups, diffs)
    prompt_text = f"commit({commit_sha}): {commit_message}"
    public_group = select_group_name_or_skip(prompt_text, groups, default=group)
    if public_group == SKIPPED:
        return FixAction(
            name="",
            group="",
            short_sha=commit_sha,
            message=commit_message,
            ignored=True,
            author=commit.author,
        )
    assert isinstance(public_group, PublicGroup)
    group = public_group.name

    prompt_text = f"commit({commit_sha}): {commit_message}"
    fix = prompt_for_fix(commit_sha, commit_message, prompt_text)
    fix.name = group
    fix.group = group
    fix.author = commit.author
    return fix


def _resolve_unmatched(unmatched: list[FixAction], commits: list[GitCommit], remap: dict[str, str]) -> set[str]:
    shas_to_remove: set[str] = set()
    for action in unmatched:
        resolution, new_sha = prompt_unmatched_fix(action, commits)
        if resolution == UnmatchedResolution.PICK_COMMIT:
            remap[action.short_sha] = new_sha
        elif resolution == UnmatchedResolution.REMOVE_ENTRY:
            shas_to_remove.add(action.short_sha)
    return shas_to_remove


def _refresh_tool_state_shas(tool_state: PkgExtState, remap: dict[str, str], shas_to_remove: set[str]) -> None:
    for old_sha, new_sha in remap.items():
        for sha_set in (tool_state.ignored_shas, tool_state.included_shas):
            if old_sha in sha_set:
                sha_set.discard(old_sha)
                sha_set.add(new_sha)
    for sha in shas_to_remove:
        tool_state.ignored_shas.discard(sha)
        tool_state.included_shas.discard(sha)


def _resolve_stale_shas(ctx: pkg_ctx) -> None:
    if not ctx._actions:
        return
    commits = ctx.git_changes.commits
    if not commits:
        return
    fix_actions = [a for a in ctx._actions if isinstance(a, FixAction)]
    stale = find_stale_shas(fix_actions, commits)
    if not stale:
        return
    remap, unmatched = build_sha_remap(stale, commits)
    shas_to_remove = _resolve_unmatched(unmatched, commits, remap)
    if remap:
        apply_remap_to_actions(ctx._actions, remap)
    if shas_to_remove:
        ctx._actions = remove_actions_by_sha(ctx._actions, shas_to_remove)
    _refresh_tool_state_shas(ctx.tool_state, remap, shas_to_remove)
    kept_stale = len(unmatched) - len(shas_to_remove)
    logger.info(f"Rebased changelog: {len(remap)} remapped, {len(shas_to_remove)} removed, {kept_stale} kept stale")


def add_git_changes(ctx: pkg_ctx) -> None:
    _resolve_stale_shas(ctx)
    git_changes = ctx.git_changes
    commit_fix_prefixes = ctx.settings.commit_fix_prefixes
    tool_state = ctx.tool_state
    for commit in git_changes.commits:
        if tool_state.sha_processed(commit.sha):
            continue
        message = commit.message
        if not message.startswith(commit_fix_prefixes):
            continue
        if commit_fix := fix_changelog_action(commit, ctx):
            ctx.add_changelog_action(commit_fix)


if __name__ == "__main__":
    from rich.console import Console

    original = "\n".join(f"original-{i}" for i in range(10))
    one = f"{original}\n\nline1\nline2\nline3\nline4"
    two = f"{original}\n\nline1\nline2 changed\nline3"

    Console().print(rich_diff(one, two))
