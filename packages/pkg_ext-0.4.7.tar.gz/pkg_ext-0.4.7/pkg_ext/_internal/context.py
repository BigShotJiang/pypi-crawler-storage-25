from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from pkg_ext._internal.changelog import (
    ChangelogAction,
    ChangelogActionBase,
    action_group,
    changelog_filepath,
    default_changelog_path,
    dump_changelog_actions,
    parse_changelog_file_path,
)
from pkg_ext._internal.errors import NoPublicGroupMatch
from pkg_ext._internal.git_usage import GitChanges
from pkg_ext._internal.models.code_state import PkgCodeState
from pkg_ext._internal.models.groups import PublicGroup
from pkg_ext._internal.pkg_state import PkgExtState
from pkg_ext._internal.settings import PkgSettings


@dataclass
class RunState:
    old_version: str = ""
    new_version: str = ""

    def current_or_next_version(self, is_bump: bool) -> str:
        return self.new_version if is_bump else self.old_version


@dataclass
class pkg_ctx:
    settings: PkgSettings
    tool_state: PkgExtState
    code_state: PkgCodeState
    git_changes: GitChanges
    run_state: RunState = field(default_factory=RunState)
    explicit_pr: int = 0

    _actions: list[ChangelogAction] = field(default_factory=list)
    _actions_dumped: bool = True

    @property
    def changelog_path(self) -> Path:
        pr = self.explicit_pr or self.git_changes.current_pr
        return changelog_filepath(self.settings.changelog_dir, pr)

    def __post_init__(self):
        changelog_dir = self.settings.changelog_dir
        path = self.changelog_path
        default_path = default_changelog_path(changelog_dir)
        dump_to_disk = False
        if default_path.exists() and path != default_path:
            self._actions.extend(parse_changelog_file_path(default_path))
            default_path.unlink()
            dump_to_disk = True
        if path.exists():
            self._actions.extend(parse_changelog_file_path(path))
        if dump_to_disk:
            dump_changelog_actions(path, self._actions)

    def add_versions(self, old_version: str, new_version: str):
        self.run_state.old_version = old_version
        self.run_state.new_version = new_version

    def add_changelog_action(self, action: ChangelogActionBase) -> None:
        self._actions.append(action)  # type: ignore[arg-type]
        self.tool_state.add_changelog_actions([action])  # type: ignore[arg-type]

    def pr_changelog_actions(self) -> list[ChangelogAction]:
        if self._actions_dumped:
            return parse_changelog_file_path(self.changelog_path)
        return self._actions

    def get_action_group(self, action: ChangelogAction) -> PublicGroup:
        if group_name := action_group(action):
            return self.tool_state.groups.get_or_create_group(group_name)
        raise NoPublicGroupMatch()

    def __enter__(self) -> pkg_ctx:
        self._actions_dumped = False
        return self

    def __exit__(self, *_):
        self._actions_dumped = True
        if actions := self._actions:
            dump_changelog_actions(self.changelog_path, actions)
