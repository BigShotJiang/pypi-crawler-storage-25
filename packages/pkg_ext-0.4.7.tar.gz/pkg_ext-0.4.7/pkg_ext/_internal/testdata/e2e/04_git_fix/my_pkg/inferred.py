def inferred():
    return "inferred"
