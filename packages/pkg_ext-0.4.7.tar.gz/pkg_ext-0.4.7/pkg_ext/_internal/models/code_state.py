from __future__ import annotations

from pydoc import locate
from typing import Any, Iterable

from model_lib import Entity
from pydantic import model_validator
from zero_3rdparty.object_name import as_name

from pkg_ext._internal.errors import LocateError, RefSymbolNotInCodeError

from .py_files import PkgSrcFile, PkgTestFile
from .py_symbols import RefSymbol
from .ref_state import RefStateWithSymbol
from .types import SymbolRefId, ref_id_module, ref_id_name


class PkgCodeState(Entity):
    pkg_import_name: str
    import_id_refs: dict[str, RefSymbol]
    files: list[PkgSrcFile | PkgTestFile]

    def _add_transitive_dependencies(self) -> None:
        while True:
            new_dependencies = False
            for file in self.files:
                for other_file in self.files:
                    if file == other_file or other_file in file.dependencies:
                        continue
                    if file._depend_from_import(other_file):
                        file.dependencies.add(other_file)
                        new_dependencies = True
            if not new_dependencies:
                break

    @model_validator(mode="after")
    def validate_and_prepare(self):
        if not self.import_id_refs:
            raise ValueError("No code state found")
        self._add_transitive_dependencies()
        self.files.sort()
        return self

    def ref_symbol(self, name_or_local_id: str) -> RefSymbol:
        if ref := self.import_id_refs.get(name_or_local_id):
            return ref
        matches: list[RefSymbol] = []
        for ref in self.import_id_refs.values():
            if ref.local_id == name_or_local_id:
                return ref
            if ref.name == name_or_local_id:
                matches.append(ref)
        if len(matches) == 1:
            return matches[0]
        if matches:
            local_ids = [m.local_id for m in matches]
            raise RefSymbolNotInCodeError(f"{name_or_local_id} is ambiguous, matches: {local_ids}")
        raise RefSymbolNotInCodeError(name_or_local_id)

    @property
    def named_refs(self) -> dict[str, RefStateWithSymbol]:
        return {ref.local_id: RefStateWithSymbol(name=ref.name, symbol=ref) for ref in self.import_id_refs.values()}

    def lookup(self, ref: RefSymbol) -> Any:
        full_reference_id = ref.full_id(self.pkg_import_name)
        py_any = locate(full_reference_id)
        if py_any is None:
            raise LocateError(full_reference_id)
        return py_any

    def as_local_ref(self, any: Any) -> RefSymbol | None:
        import_id = as_name(any)
        pkg_prefix = f"{self.pkg_import_name}."
        if import_id.startswith(pkg_prefix):
            name = ref_id_name(import_id)
            if len(name) == 1:  # most likely a TypeAlias, like T, which are not stored
                return None
            return self.import_id_refs[import_id]

    def sort_refs(self, refs: Iterable[SymbolRefId]) -> list[SymbolRefId]:
        def lookup_in_file(ref: SymbolRefId) -> tuple[int, str]:
            module_name = ref_id_module(ref)
            ref_name = ref_id_name(ref)
            for i, file in enumerate(self.files):
                for symbol in file.iterate_ref_symbols():
                    if symbol.name == ref_name and file.module_local_path == module_name:
                        return i, ref_name
            raise ValueError(f"ref not found in any file: {ref}")

        return sorted(refs, key=lookup_in_file)

    def sort_rel_paths_by_dependecy_order(self, paths: Iterable[str], reverse: bool = True) -> list[str]:
        """assume a.py:
        from my_pkg.b import b
        def a():
            b()
        Then the order will be b, a
        If reverse=True, a, b # reversed dependency order
        """

        def key_in_files(rel_path: str) -> int:
            for i, file in enumerate(self.files):
                if file.relative_path == rel_path:
                    return i
            raise ValueError(f"rel_path not found in any file: {rel_path}")

        return sorted(paths, key=key_in_files, reverse=reverse)
