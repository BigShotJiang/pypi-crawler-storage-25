from __future__ import annotations

import dataclasses
import enum
import inspect
import re
import types
import typing
from collections.abc import Iterator
from contextlib import contextmanager, suppress
from contextvars import ContextVar
from pathlib import Path
from typing import Any, Callable, ClassVar, Literal, NamedTuple, Union, get_args, get_origin, get_type_hints

from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined
from typer.models import ArgumentInfo, ParameterInfo

from pkg_ext._internal.models.api_dump import (
    CallableSignature,
    ClassFieldInfo,
    CLIParamInfo,
    FuncParamInfo,
    ParamDefault,
    ParamKind,
)

CLI_CONTEXT_TYPE_NAMES = frozenset({"Context", "typer.Context", "click.Context"})

_PARAM_KIND_MAP = {
    inspect.Parameter.POSITIONAL_ONLY: ParamKind.POSITIONAL_ONLY,
    inspect.Parameter.POSITIONAL_OR_KEYWORD: ParamKind.POSITIONAL_OR_KEYWORD,
    inspect.Parameter.VAR_POSITIONAL: ParamKind.VAR_POSITIONAL,
    inspect.Parameter.KEYWORD_ONLY: ParamKind.KEYWORD_ONLY,
    inspect.Parameter.VAR_KEYWORD: ParamKind.VAR_KEYWORD,
}

# Pattern to detect memory-address based repr like <object object at 0x100346830>
_MEMORY_ADDRESS_PATTERN = re.compile(r"^<(?P<type_info>.+) at 0x[0-9a-fA-F]+>$")
# Pattern to strip memory addresses from any string (for embedded references)
_MEMORY_ADDRESS_INLINE = re.compile(r"<(?P<type_info>[^<>]+) at 0x[0-9a-fA-F]+>")


class DocReprContext(NamedTuple):
    pkg_dir: Path
    repo_root: Path | None = None


_doc_repr_ctx_var: ContextVar[DocReprContext | None] = ContextVar("_doc_repr_ctx", default=None)


@contextmanager
def doc_repr_context(pkg_dir: Path, repo_root: Path | None = None) -> Iterator[None]:
    token = _doc_repr_ctx_var.set(DocReprContext(pkg_dir=pkg_dir, repo_root=repo_root))
    try:
        yield
    finally:
        _doc_repr_ctx_var.reset(token)


def path_repr_for_docs(path: Path, ctx: DocReprContext) -> str:
    resolved = path.resolve()
    anchor = ctx.pkg_dir.resolve()
    if resolved == anchor:
        return "Path('.')"
    with suppress(ValueError):
        rel = resolved.relative_to(anchor)
        return f"Path('{rel.as_posix()}')"
    if ctx.repo_root:
        repo = ctx.repo_root.resolve()
        if resolved == repo:
            return "Path('.')"
        with suppress(ValueError):
            rel = resolved.relative_to(repo)
            return f"Path('{rel.as_posix()}')"
    return "Path('<outside package>')"


def strip_memory_addresses(s: str) -> str:
    """Remove memory addresses from any string containing <... at 0x...> patterns."""
    return _MEMORY_ADDRESS_INLINE.sub(r"<\g<type_info>>", s)


def stable_repr(value: Any) -> str:
    """Return a stable repr for a value, normalizing memory addresses.

    Sentinel objects like `object()` produce repr strings with memory addresses
    (e.g., `<object object at 0x100346830>`) that change between Python runs.
    This function normalizes such reprs to a stable form like `<object>`.
    """
    if isinstance(value, Path) and (ctx := _doc_repr_ctx_var.get()):
        return path_repr_for_docs(value, ctx)
    raw_repr = repr(value)
    if match := _MEMORY_ADDRESS_PATTERN.match(raw_repr):
        type_info = match.group("type_info")
        return f"<{type_info}>"
    return strip_memory_addresses(raw_repr)


def _annotation_str(annotation: Any) -> str | None:
    """Convert annotation to string using simple names, not full module paths."""
    if annotation is inspect.Parameter.empty:
        return None
    if annotation is None or annotation is type(None):
        return "None"
    if isinstance(annotation, type):
        return annotation.__name__

    # Handle Union types (X | Y or Union[X, Y])
    origin = get_origin(annotation)
    # Python 3.10+ uses types.UnionType for X | Y syntax
    if isinstance(annotation, types.UnionType):
        args = typing.get_args(annotation)
        arg_strs = [_annotation_str(arg) for arg in args]
        return " | ".join(a for a in arg_strs if a)

    if origin is not None:
        args = typing.get_args(annotation)
        if origin is Union:
            # Union type - join args with |
            arg_strs = [_annotation_str(arg) for arg in args]
            return " | ".join(a for a in arg_strs if a)
        # Generic type like list[str], dict[str, int]
        origin_name = origin.__name__ if hasattr(origin, "__name__") else str(origin)
        if args:
            arg_strs = [_annotation_str(arg) for arg in args]
            return f"{origin_name}[{', '.join(a for a in arg_strs if a)}]"
        return origin_name

    # Callable param specs: get_args(Callable[[A, B], R]) returns ([A, B], R)
    # where the first element is a plain list — recurse into it
    if isinstance(annotation, list):
        arg_strs = [_annotation_str(arg) for arg in annotation]
        return f"[{', '.join(a for a in arg_strs if a)}]"

    return str(annotation)


def _normalize_module(module: str, pkg_name: str = "") -> str:
    """Normalize internal module paths by dropping trailing underscore-prefixed segments.

    Examples:
        - pathlib._local -> pathlib
        - collections._abc -> collections
        - mypackage._internal.utils -> mypackage (unless within mypackage itself)

    If pkg_name is provided, internal modules within that package are preserved.
    """
    parts = module.split(".")
    # Drop trailing parts that start with underscore (internal implementation details)
    while len(parts) > 1 and parts[-1].startswith("_"):
        # Keep internal modules if they're part of the current package
        if pkg_name and parts[0] == pkg_name:
            break
        parts.pop()
    return ".".join(parts)


def _annotation_import(annotation: Any, pkg_name: str = "") -> str | None:
    """Extract the full import path for a type annotation.

    Handles union types (X | Y) by returning imports for all component types.
    Returns None for builtins.
    """
    if annotation is inspect.Parameter.empty:
        return None

    # Handle Union types (X | Y or Union[X, Y])
    if isinstance(annotation, types.UnionType):
        # Return first non-builtin import from union components
        for arg in typing.get_args(annotation):
            if result := _annotation_import(arg, pkg_name):
                return result
        return None

    origin = get_origin(annotation)
    if origin is Union:
        for arg in typing.get_args(annotation):
            if result := _annotation_import(arg, pkg_name):
                return result
        return None

    if isinstance(annotation, type):
        module = annotation.__module__
        name = annotation.__name__
        if module == "builtins":
            return None
        module = _normalize_module(module, pkg_name)
        return f"{module}.{name}"
    return None


def _collect_all_annotation_imports(annotation: Any, pkg_name: str = "") -> list[str]:
    """Collect ALL import paths from a type annotation, including all union members."""
    imports: list[str] = []

    if annotation is inspect.Parameter.empty:
        return imports

    # Handle Union types - collect from all components
    if isinstance(annotation, types.UnionType):
        for arg in typing.get_args(annotation):
            imports.extend(_collect_all_annotation_imports(arg, pkg_name))
        return imports

    origin = get_origin(annotation)
    if origin is Union:
        for arg in typing.get_args(annotation):
            imports.extend(_collect_all_annotation_imports(arg, pkg_name))
        return imports

    # Handle generic types like list[SomeType]
    if origin is not None:
        for arg in typing.get_args(annotation):
            imports.extend(_collect_all_annotation_imports(arg, pkg_name))
        return imports

    if isinstance(annotation, type):
        module = annotation.__module__
        name = annotation.__name__
        if module != "builtins":
            module = _normalize_module(module, pkg_name)
            imports.append(f"{module}.{name}")

    return imports


def parse_param_default(param: inspect.Parameter) -> ParamDefault | None:
    if param.default is inspect.Parameter.empty:
        return None
    with suppress(ImportError):
        from pydantic.fields import FieldInfo

        if isinstance(param.default, FieldInfo):
            if param.default.default_factory is not None:
                return ParamDefault(value_repr="...", is_factory=True)
            return ParamDefault(value_repr=stable_repr(param.default.default))
    return ParamDefault(value_repr=stable_repr(param.default))


def _parse_func_param(param: inspect.Parameter, resolved_annotation: Any | None = None) -> FuncParamInfo:
    annotation = resolved_annotation if resolved_annotation is not None else param.annotation
    return FuncParamInfo(
        name=param.name,
        kind=_PARAM_KIND_MAP[param.kind],
        type_annotation=_annotation_str(annotation),
        type_imports=_collect_all_annotation_imports(annotation),
        default=parse_param_default(param),
    )


def parse_signature(obj: Callable) -> CallableSignature:
    try:
        sig = inspect.signature(obj)
    except (ValueError, TypeError):
        return CallableSignature()

    # Resolve string annotations to actual types
    try:
        hints = get_type_hints(obj)
    except Exception:
        hints = {}

    params = [_parse_func_param(p, hints.get(p.name)) for p in sig.parameters.values()]
    return_hint = hints.get("return")
    return CallableSignature(
        parameters=params,
        return_annotation=_annotation_str(return_hint) if return_hint else None,
        return_type_imports=_collect_all_annotation_imports(return_hint) if return_hint else [],
    )


_MRO_FILTER = frozenset({"object", "ABC", "Protocol", "Generic"})


def parse_mro_bases(cls: type) -> tuple[list[str], int]:
    """Return (MRO bases, count of direct bases)."""
    mro = [c.__name__ for c in cls.__mro__[1:] if c.__name__ not in _MRO_FILTER]
    num_direct = sum(1 for base in cls.__bases__ if base is not object)
    return mro, num_direct


def _parse_field_default(field: Any) -> ParamDefault | None:
    if isinstance(field, FieldInfo):
        if field.default_factory is not None:
            return ParamDefault(value_repr="...", is_factory=True)
        if field.default is not PydanticUndefined:
            return ParamDefault(value_repr=stable_repr(field.default))
    return None


def _extract_env_vars(cls: type, field_name: str) -> list[str] | None:
    try:
        from pydantic_settings import BaseSettings
        from pydantic_settings.sources import EnvSettingsSource

        if not issubclass(cls, BaseSettings):
            return None
        model_config = cls.model_config
        source = EnvSettingsSource(
            cls,
            case_sensitive=model_config.get("case_sensitive"),  # type: ignore
            env_prefix=model_config.get("env_prefix"),  # type: ignore
            env_nested_delimiter=model_config.get("env_nested_delimiter"),  # type: ignore
        )
        model_field = cls.model_fields[field_name]
        field_infos = source._extract_field_info(model_field, field_name)
        return [info[1] for info in field_infos]
    except (ImportError, Exception):
        return None


def _parse_pydantic_fields(cls: type) -> list[ClassFieldInfo]:
    fields: list[ClassFieldInfo] = []
    for name, field in cls.model_fields.items():  # type: ignore
        if name.startswith("_"):
            continue
        fields.append(
            ClassFieldInfo(
                name=name,
                type_annotation=_annotation_str(field.annotation),
                type_imports=_collect_all_annotation_imports(field.annotation),
                default=_parse_field_default(field),
                is_class_var=False,
                is_computed=False,
                description=field.description,
                deprecated=field.deprecated,
                env_vars=_extract_env_vars(cls, name),
            )
        )
    if hasattr(cls, "model_computed_fields"):
        for name, computed in cls.model_computed_fields.items():  # type: ignore
            if name.startswith("_"):
                continue
            fields.append(
                ClassFieldInfo(
                    name=name,
                    type_annotation=_annotation_str(computed.return_type),
                    type_imports=_collect_all_annotation_imports(computed.return_type),
                    is_computed=True,
                    description=computed.description if hasattr(computed, "description") else None,
                )
            )
    return fields


def _parse_dataclass_fields(cls: type) -> list[ClassFieldInfo]:
    try:
        hints = get_type_hints(cls)
    except NameError:
        hints = getattr(cls, "__annotations__", {})
    fields: list[ClassFieldInfo] = []
    for f in dataclasses.fields(cls):
        if f.name.startswith("_"):
            continue
        annotation = hints.get(f.name)
        is_class_var = get_origin(annotation) is ClassVar
        default: ParamDefault | None = None
        if f.default is not dataclasses.MISSING:
            default = ParamDefault(value_repr=stable_repr(f.default))
        elif f.default_factory is not dataclasses.MISSING:
            default = ParamDefault(value_repr="...", is_factory=True)
        fields.append(
            ClassFieldInfo(
                name=f.name,
                type_annotation=_annotation_str(annotation),
                type_imports=_collect_all_annotation_imports(annotation),
                default=default,
                is_class_var=is_class_var,
            )
        )
    return fields


def parse_class_fields(cls: type) -> list[ClassFieldInfo] | None:
    with suppress(ImportError):
        from pydantic import BaseModel

        if isinstance(cls, type) and issubclass(cls, BaseModel):
            return _parse_pydantic_fields(cls)
    if dataclasses.is_dataclass(cls):
        return _parse_dataclass_fields(cls)
    return None


def _has_cli_context_param(func: Callable) -> bool:
    """Check if function has a typer/click Context parameter."""
    try:
        hints = get_type_hints(func)
    except Exception:
        return False
    for hint in hints.values():
        type_name = getattr(hint, "__name__", None) or str(hint)
        if type_name in CLI_CONTEXT_TYPE_NAMES:
            return True
    return False


def is_cli_command(func: Callable) -> bool:
    """Check if a function is a typer CLI command by looking for ParameterInfo defaults or Context params."""
    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError):
        return False
    has_param_info = any(isinstance(p.default, ParameterInfo) for p in sig.parameters.values())
    return has_param_info or _has_cli_context_param(func)


def _resolve_cli_flags(param_name: str, param_info: Any) -> list[str]:
    """Resolve CLI flags from ParameterInfo, auto-generating if empty."""
    if param_info.param_decls:
        return list(param_info.param_decls)
    return [f"--{param_name.replace('_', '-')}"]


def _extract_choices(annotation: Any) -> list[str] | None:
    """Extract choices from Enum or Literal type annotations."""
    if isinstance(annotation, type) and issubclass(annotation, enum.Enum):
        if issubclass(annotation, enum.StrEnum):
            return [str(member) for member in annotation]
        return [member.name for member in annotation]
    origin = get_origin(annotation)
    if origin is Literal:
        return [str(arg) for arg in get_args(annotation)]
    return None


def is_cli_required_for_docs(info: ParameterInfo) -> bool:
    return info.default is ... and info.default_factory is None


def _cli_default_object_for_docs(info: ParameterInfo) -> Any:
    if info.default is ...:
        if info.default_factory is None:
            raise ValueError("required CLI parameter has no default to materialize")
        return info.default_factory()
    return info.default


def _format_envvar(envvar: str | list[str] | None) -> str | None:
    """Format envvar to a single string."""
    if envvar is None:
        return None
    if isinstance(envvar, list):
        return envvar[0] if envvar else None
    return envvar


def extract_cli_params(func: Callable) -> list[CLIParamInfo]:
    try:
        sig = inspect.signature(func)
        hints = get_type_hints(func)
    except Exception:
        return []

    params: list[CLIParamInfo] = []
    for name, param in sig.parameters.items():
        if not isinstance(param.default, ParameterInfo):
            continue
        info = param.default
        annotation = hints.get(name)
        is_arg = isinstance(info, ArgumentInfo)
        required = is_cli_required_for_docs(info)
        default_repr: str | None = None
        if not required:
            default_repr = stable_repr(_cli_default_object_for_docs(info))
        params.append(
            CLIParamInfo(
                param_name=name,
                type_annotation=_annotation_str(annotation),
                flags=[] if is_arg else _resolve_cli_flags(name, info),
                help=info.help,
                default_repr=default_repr,
                required=required,
                envvar=_format_envvar(info.envvar),
                is_argument=is_arg,
                hidden=info.hidden,
                choices=_extract_choices(annotation),
            )
        )
    return params
