from __future__ import annotations

from contextlib import suppress
from pathlib import Path

from model_lib import Entity
from pydantic import DirectoryPath, Field

from pkg_ext._internal.changelog.actions import (
    ChangelogAction,
    DeleteAction,
    DeprecatedAction,
    ExperimentalAction,
    FixAction,
    GAAction,
    GroupModuleAction,
    KeepPrivateAction,
    MakePublicAction,
    RenameAction,
)
from pkg_ext._internal.config import Stability
from pkg_ext._internal.errors import RefSymbolNotInCodeError
from pkg_ext._internal.models.code_state import PkgCodeState
from pkg_ext._internal.models.groups import PublicGroups
from pkg_ext._internal.models.py_symbols import RefSymbol
from pkg_ext._internal.models.ref_state import RefState, RefStateType, RefStateWithSymbol
from pkg_ext._internal.models.types import qualified_name, ref_id_module, ref_id_name


class PkgExtState(Entity):
    repo_root: DirectoryPath
    changelog_dir: DirectoryPath
    pkg_path: DirectoryPath
    refs: dict[str, RefState] = Field(
        default_factory=dict,
        description="Mapping of reference names to their states. Use with caution, inferred by changelog_dir entries.",
    )
    groups: PublicGroups = Field(
        default_factory=PublicGroups,
        description="Use with caution, inferred by changelog_dir entries.",
    )
    decided_local_ids: set[str] = Field(
        default_factory=set,
        description="local_ids that have a make_public or keep_private decision",
    )
    ignored_shas: set[str] = Field(
        default_factory=set,
        description="Fix commits not included in the changelog",
    )
    included_shas: set[str] = Field(
        default_factory=set,
        description="Fix commits included in the changelog",
    )
    group_stability: dict[str, Stability] = Field(
        default_factory=dict,
        description="Group name to stability level. Absence means GA.",
    )
    symbol_stability: dict[str, Stability] = Field(
        default_factory=dict,
        description="Key = {group}.{symbol}, value = stability level.",
    )
    arg_stability: dict[str, Stability] = Field(
        default_factory=dict,
        description="Key = {group}.{symbol}.{arg}, value = stability level.",
    )
    deprecation_replacements: dict[str, str] = Field(
        default_factory=dict,
        description="Key = target (group/symbol/arg), value = replacement suggestion.",
    )

    def code_ref(self, code_state: PkgCodeState, group: str, name: str) -> RefSymbol | None:
        key = qualified_name(group, name)
        if state := self.refs.get(key):
            if state.exist_in_code:
                if grp := self.groups.name_to_group.get(group):
                    for owned_ref in grp.owned_refs:
                        if owned_ref.endswith(f".{name}"):
                            with suppress(RefSymbolNotInCodeError):
                                return code_state.ref_symbol(owned_ref)
                with suppress(RefSymbolNotInCodeError):
                    return code_state.ref_symbol(name)
        return None

    def sha_processed(self, sha: str) -> bool:
        return sha in self.ignored_shas or sha in self.included_shas

    def current_state(self, group: str, ref_name: str) -> RefState:
        key = qualified_name(group, ref_name)
        if state := self.refs.get(key):
            return state
        self.refs[key] = state = RefState(name=ref_name)
        return state

    def update_state(self, action: ChangelogAction) -> None:
        match action:
            case MakePublicAction(name=name, group=group, full_path=full_path):
                self._handle_make_public(name, group, full_path)
            case KeepPrivateAction(name=name, full_path=full_path):
                self._handle_keep_private(name, full_path)
            case DeleteAction(name=name, group=group_name):
                self._handle_delete(name, group_name)
            case RenameAction(name=name, group=group, old_name=old_name):
                self._handle_rename(name, group, old_name)
            case GroupModuleAction(name=group_name, module_path=module_path):
                self.groups.add_module(group_name, module_path)
            case FixAction(short_sha=sha, ignored=ignored):
                (self.ignored_shas if ignored else self.included_shas).add(sha)
            case ExperimentalAction() | GAAction() | DeprecatedAction():
                self._update_stability(action)

    def _handle_make_public(self, name: str, group: str, full_path: str) -> None:
        state = self.current_state(group, name)
        state.type = RefStateType.EXPOSED
        grp = self.groups.get_or_create_group(group)
        grp.owned_refs.add(full_path)
        grp.owned_modules.add(ref_id_module(full_path))
        self.decided_local_ids.add(full_path)

    def _handle_keep_private(self, name: str, full_path: str) -> None:
        key = full_path or name
        if state := self.refs.get(key):
            state.type = RefStateType.HIDDEN
        else:
            self.refs[key] = RefState(name=name, type=RefStateType.HIDDEN)
        if full_path:
            self.decided_local_ids.add(full_path)
        for grp in self.groups.groups:
            grp.owned_refs.discard(full_path)

    def _handle_delete(self, name: str, group_name: str) -> None:
        state = self.current_state(group_name, name)
        state.type = RefStateType.DELETED
        if grp := self.groups.name_to_group.get(group_name):
            matching = {r for r in grp.owned_refs if r.endswith(f".{name}")}
            grp.owned_refs -= matching

    def _handle_rename(self, name: str, group: str, old_name: str) -> None:
        state = self.current_state(group, name)
        old_state = self.current_state(group, old_name)
        old_state.type = RefStateType.DELETED
        state.type = RefStateType.EXPOSED

    def _stability_from_action(self, action: ChangelogAction) -> Stability:
        match action:
            case ExperimentalAction():
                return Stability.experimental
            case GAAction():
                return Stability.ga
            case DeprecatedAction():
                return Stability.deprecated
        raise ValueError(f"Unknown stability action: {action}")

    def _update_stability(self, action: ExperimentalAction | GAAction | DeprecatedAction) -> None:
        stability = self._stability_from_action(action)
        target = str(action.target)
        match target:
            case "group":
                self.group_stability[action.name] = stability
                if isinstance(action, DeprecatedAction) and action.replacement:
                    self.deprecation_replacements[action.name] = action.replacement
            case "symbol":
                key = f"{action.group}.{action.name}"
                self.symbol_stability[key] = stability
                if isinstance(action, DeprecatedAction) and action.replacement:
                    self.deprecation_replacements[key] = action.replacement
            case "arg":
                key = f"{action.parent}.{action.name}"
                self.arg_stability[key] = stability
                if isinstance(action, DeprecatedAction) and action.replacement:
                    self.deprecation_replacements[key] = action.replacement

    def get_group_stability(self, group: str) -> Stability:
        return self.group_stability.get(group, Stability.ga)

    def get_symbol_stability(self, group: str, symbol: str) -> Stability:
        key = f"{group}.{symbol}"
        if key in self.symbol_stability:
            return self.symbol_stability[key]
        return self.get_group_stability(group)

    def get_arg_stability(self, group: str, symbol: str, arg: str) -> Stability:
        key = f"{group}.{symbol}.{arg}"
        if key in self.arg_stability:
            return self.arg_stability[key]
        return self.get_symbol_stability(group, symbol)

    def is_group_ga(self, group: str) -> bool:
        return self.get_group_stability(group) == Stability.ga

    def get_deprecation_replacement(self, key: str) -> str:
        return self.deprecation_replacements.get(key, "")

    def reconcile_with_code(self, import_id_refs: dict[str, RefSymbol]) -> int:
        """Run reconcile_moved_refs and update decided_local_ids for moved symbols."""
        count, moved_to = self.groups.reconcile_moved_refs(import_id_refs)
        if moved_to:
            self.decided_local_ids.update(moved_to)
        all_owned = {ref for group in self.groups.groups for ref in group.owned_refs}
        stale_ids = self.decided_local_ids - all_owned
        if stale_ids:
            owned_by_name: dict[str, set[str]] = {}
            for ref_id in all_owned:
                owned_by_name.setdefault(ref_id_name(ref_id), set()).add(ref_id)
            for stale_id in stale_ids:
                if current := owned_by_name.get(ref_id_name(stale_id)):
                    self.decided_local_ids.update(current)
        return count

    def has_decision(self, local_id: str) -> bool:
        return local_id in self.decided_local_ids

    def removed_refs(self, code: PkgCodeState) -> list[tuple[str, RefState]]:
        active_local_ids = {ref.local_id for ref in code.import_id_refs.values()}
        result: list[tuple[str, RefState]] = []
        for key, state in self.refs.items():
            if state.type not in {RefStateType.EXPOSED, RefStateType.DEPRECATED}:
                continue
            group = key.rsplit(".", 1)[0] if "." in key else ""
            if grp := self.groups.name_to_group.get(group):
                owned_for_name = {r for r in grp.owned_refs if r.endswith(f".{state.name}")}
                if owned_for_name & active_local_ids:
                    continue
            elif state.name in {ref.name for ref in code.import_id_refs.values()}:
                # Fallback for legacy refs without group info: any symbol with the
                # same short name still in code prevents marking as removed.
                continue
            result.append((group, state))
        return result

    def added_refs(self, active_refs: dict[str, RefStateWithSymbol]) -> dict[str, RefStateWithSymbol]:
        return {local_id: ref for local_id, ref in active_refs.items() if not self.has_decision(local_id)}

    def add_changelog_actions(self, actions: list[ChangelogAction]) -> None:
        assert actions, "must add at least one action"
        for action in actions:
            self.update_state(action)

    def is_exposed(self, group: str, ref_name: str) -> bool:
        key = qualified_name(group, ref_name)
        if state := self.refs.get(key):
            return state.type in {RefStateType.EXPOSED, RefStateType.DEPRECATED}
        return False

    def exposed_refs(self, group: str, active_refs: dict[str, RefStateWithSymbol]) -> dict[str, RefSymbol]:
        return {
            state.symbol.local_id: state.symbol for state in active_refs.values() if self.is_exposed(group, state.name)
        }

    def is_pkg_relative(self, rel_path: str) -> bool:
        pkg_rel_path = self.pkg_path.relative_to(self.repo_root)
        return rel_path.startswith(str(pkg_rel_path))

    def full_path(self, rel_path_repo: str) -> Path:
        return self.repo_root / rel_path_repo
