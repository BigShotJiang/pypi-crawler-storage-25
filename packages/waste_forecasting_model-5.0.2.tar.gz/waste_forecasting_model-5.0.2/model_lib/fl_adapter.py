"""
Federated Learning adapter layer for model_lib.

Design goals
------------
* Decoupled from any specific FL framework — the FL framework imports *this*,
  not the other way around.
* Works over SQS (messages carry serialised model parameter diffs).
* Supports heterogeneous model registries (not just WastePredictor).
* Neural-network parameters use FedAvg; tree-based models use quality-weighted
  model selection (trees are not additively averageable).

Architecture
------------
                        ┌──────────────────────┐
                        │  FederatedModelAdapter│  ← abstract contract
                        │  (ABC)               │
                        └──────────┬───────────┘
                                   │
                 ┌─────────────────┼─────────────────┐
                 │                 │                 │
     WastePredictorFLAdapter   (your next model)  …
                 │
         ┌───────┴────────┐
         │ get_params()   │  → dict[str, np.ndarray]  (for SQS payload)
         │ set_params()   │  ← dict[str, np.ndarray]
         │ local_train()  │  trains on local DataFrame, returns updated params
         │ serialize()    │  → bytes  (full model, for server aggregation)
         │ deserialize()  │  ← bytes
         └────────────────┘

SQS message contract
--------------------
Each SQS message body is JSON with fields:
    {
        "event":        "FL_PARAMS_UPDATE" | "FL_MODEL_BROADCAST",
        "model_id":     "waste_predictor_v4",
        "client_id":    "<uuid>",
        "round":        <int>,
        "num_samples":  <int>,          # for weighted FedAvg
        "params":       "<base64>",     # base64(pickle(dict[str, np.ndarray]))
        "metrics":      { "r2": … }
    }
"""
from __future__ import annotations

import abc
import base64
import io
import pickle
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Type

import numpy as np
import pandas as pd


# ── SQS message schema ────────────────────────────────────────────────────────

class FLEventType(str, Enum):
    PARAMS_UPDATE = "FL_PARAMS_UPDATE"        # client → server
    MODEL_BROADCAST = "FL_MODEL_BROADCAST"    # server → clients
    ROUND_START = "FL_ROUND_START"            # server → clients (trigger training)
    ROUND_COMPLETE = "FL_ROUND_COMPLETE"      # server → orchestrator


@dataclass
class FLMessage:
    """Typed wrapper for every FL SQS message."""

    event: FLEventType
    model_id: str
    client_id: str
    round: int
    num_samples: int
    params: Optional[Dict[str, np.ndarray]] = None
    metrics: Dict[str, float] = field(default_factory=dict)
    extra: Dict[str, Any] = field(default_factory=dict)

    # ── Serialisation to / from SQS JSON body ────────────────────────

    def to_sqs_body(self) -> str:
        import json

        payload = {
            "event": self.event.value,
            "model_id": self.model_id,
            "client_id": self.client_id,
            "round": self.round,
            "num_samples": self.num_samples,
            "metrics": self.metrics,
            "extra": self.extra,
        }
        if self.params is not None:
            payload["params"] = base64.b64encode(
                pickle.dumps(self.params, protocol=4)
            ).decode("ascii")
        return json.dumps(payload)

    @classmethod
    def from_sqs_body(cls, body: str) -> "FLMessage":
        import json

        d = json.loads(body)
        params: Optional[Dict[str, np.ndarray]] = None
        if "params" in d:
            params = pickle.loads(base64.b64decode(d["params"]))

        return cls(
            event=FLEventType(d["event"]),
            model_id=d["model_id"],
            client_id=d["client_id"],
            round=int(d["round"]),
            num_samples=int(d["num_samples"]),
            params=params,
            metrics=d.get("metrics", {}),
            extra=d.get("extra", {}),
        )


# ── Abstract adapter ──────────────────────────────────────────────────────────

class FederatedModelAdapter(abc.ABC):
    """
    Abstract contract every model must implement to participate in FL via SQS.

    Concrete subclasses are registered in :data:`MODEL_REGISTRY` so the
    FL framework can instantiate the right adapter from a model_id string.
    """

    #: Unique stable identifier for this model type (used in SQS messages).
    MODEL_ID: str = ""

    # ── Parameter exchange ────────────────────────────────────────────

    @abc.abstractmethod
    def get_params(self) -> Dict[str, np.ndarray]:
        """
        Return the trainable parameters as a flat dict of numpy arrays.

        For neural networks: PyTorch state-dict tensors → numpy.
        For tree models: serialised bytes wrapped in a 1-D uint8 array.
        """

    @abc.abstractmethod
    def set_params(self, params: Dict[str, np.ndarray]) -> None:
        """Apply parameter dict received from the aggregation server."""

    # ── Local training ────────────────────────────────────────────────

    @abc.abstractmethod
    def local_train(
        self,
        train_df: pd.DataFrame,
        *,
        epochs: int = 50,
        verbose: bool = False,
    ) -> Dict[str, np.ndarray]:
        """
        Train on local data and return updated parameters.

        Returns the *same* structure as ``get_params()``.
        """

    # ── Full-model serialisation (for server-side aggregation) ────────

    @abc.abstractmethod
    def serialize(self) -> bytes:
        """Serialise the full model to bytes."""

    @classmethod
    @abc.abstractmethod
    def deserialize(cls, data: bytes) -> "FederatedModelAdapter":
        """Reconstruct from bytes produced by :meth:`serialize`."""

    # ── FedAvg aggregation (server-side, static) ──────────────────────

    @staticmethod
    @abc.abstractmethod
    def aggregate(
        params_list: List[Dict[str, np.ndarray]],
        weights: Optional[List[float]] = None,
    ) -> Dict[str, np.ndarray]:
        """
        Aggregate a list of parameter dicts into one.

        Parameters
        ----------
        params_list:
            One dict per client.
        weights:
            Per-client weights (e.g. num_samples).  Uniform if None.
        """

    # ── Metrics ───────────────────────────────────────────────────────

    @abc.abstractmethod
    def evaluate(self, test_df: pd.DataFrame) -> Dict[str, float]:
        """Return evaluation metrics on an held-out DataFrame."""

    # ── SQS helper ───────────────────────────────────────────────────

    def build_update_message(
        self,
        params: Dict[str, np.ndarray],
        round_: int,
        num_samples: int,
        client_id: Optional[str] = None,
        metrics: Optional[Dict[str, float]] = None,
    ) -> FLMessage:
        return FLMessage(
            event=FLEventType.PARAMS_UPDATE,
            model_id=self.MODEL_ID,
            client_id=client_id or str(uuid.uuid4()),
            round=round_,
            num_samples=num_samples,
            params=params,
            metrics=metrics or {},
        )


# ── Model registry ────────────────────────────────────────────────────────────

MODEL_REGISTRY: Dict[str, Type[FederatedModelAdapter]] = {}


def register_model(cls: Type[FederatedModelAdapter]) -> Type[FederatedModelAdapter]:
    """Class decorator that registers a FederatedModelAdapter subclass."""
    if not cls.MODEL_ID:
        raise ValueError(f"{cls.__name__} must define MODEL_ID")
    MODEL_REGISTRY[cls.MODEL_ID] = cls
    return cls


def get_adapter(model_id: str) -> Type[FederatedModelAdapter]:
    try:
        return MODEL_REGISTRY[model_id]
    except KeyError:
        raise KeyError(
            f"No FL adapter registered for model_id={model_id!r}. "
            f"Available: {list(MODEL_REGISTRY)}"
        )


# ── WastePredictor FL adapter ─────────────────────────────────────────────────

@register_model
class WastePredictorFLAdapter(FederatedModelAdapter):
    """
    Federated Learning adapter for WastePredictionModel V5 (XGBoost, 9 targets).

    Parameter strategy
    ------------------
    Each of the 9 XGBoost models is serialised as a ``uint8`` byte array.
    XGBoost boosters cannot be additively averaged (unlike neural-network
    weights), so FedAvg uses **quality-weighted model selection**: the client
    with the highest reported R² for each target provides the winning model.

    SQS payload keys:  ``"xgb::<target_name>"``
    """

    MODEL_ID = "waste_predictor_v5"

    def __init__(self, model_path: Optional[str] = None) -> None:
        from model_lib.predictor import WastePredictor
        self._predictor = WastePredictor(model_path)
        self._predictor._ensure_loaded()

    # ── Helpers ───────────────────────────────────────────────────────

    @property
    def _waste_model(self):
        """Return the underlying WastePredictionModel instance."""
        return self._predictor._model

    # ── Parameter exchange ────────────────────────────────────────────

    def get_params(self) -> Dict[str, np.ndarray]:
        """Serialise each XGBoost model as a uint8 byte array."""
        params: Dict[str, np.ndarray] = {}
        for target, model in self._waste_model.models_.items():
            params[f"xgb::{target}"] = np.frombuffer(
                pickle.dumps(model, protocol=4), dtype=np.uint8
            )
        return params

    def set_params(self, params: Dict[str, np.ndarray]) -> None:
        """Restore XGBoost models from byte arrays."""
        for key, value in params.items():
            if key.startswith("xgb::"):
                target = key[len("xgb::"):]
                model = pickle.loads(value.tobytes())
                self._waste_model.models_[target] = model

    # ── Local training ────────────────────────────────────────────────

    def local_train(
        self,
        train_df: pd.DataFrame,
        *,
        epochs: int = 50,      # kept for API compatibility, not used by XGBoost
        verbose: bool = False,
    ) -> Dict[str, np.ndarray]:
        """
        Retrain all 9 XGBoost models on local data and return updated params.
        Uses the same hyperparameters as the original training run.
        """
        from model_lib._core.architecture import WastePredictionModel
        from sklearn.model_selection import train_test_split

        # Hold out 10% for early-stopping validation
        tr_df, va_df = train_test_split(train_df, test_size=0.10, random_state=42)
        new_model = WastePredictionModel()
        new_model.fit(tr_df, va_df, verbose=verbose)

        # Replace inner models and scaler
        self._waste_model.models_ = new_model.models_
        self._waste_model.scaler_ = new_model.scaler_

        return self.get_params()

    # ── Full-model serialisation ──────────────────────────────────────

    def serialize(self) -> bytes:
        return pickle.dumps(self._waste_model, protocol=4)

    @classmethod
    def deserialize(cls, data: bytes) -> "WastePredictorFLAdapter":
        waste_model = pickle.loads(data)
        adapter = cls.__new__(cls)
        from model_lib.predictor import WastePredictor
        import threading
        wp = WastePredictor.__new__(WastePredictor)
        wp._model = waste_model
        wp._model_path = None
        wp._lock = threading.Lock()
        adapter._predictor = wp
        return adapter

    # ── FedAvg aggregation (quality-weighted model selection) ─────────

    @staticmethod
    def aggregate(
        params_list: List[Dict[str, np.ndarray]],
        weights: Optional[List[float]] = None,
    ) -> Dict[str, np.ndarray]:
        """
        For XGBoost: quality-weighted model selection.
        The client with the highest weight (e.g. highest R²) wins per target.
        Trees are not additively averageable.
        """
        if not params_list:
            raise ValueError("params_list is empty")
        n = len(params_list)
        w = np.array(weights, dtype=float) if weights else np.ones(n)
        best_idx = int(np.argmax(w))
        # All XGBoost keys from the best-performing client
        return {k: v for k, v in params_list[best_idx].items()}

    # ── Metrics ───────────────────────────────────────────────────────

    def evaluate(self, test_df: pd.DataFrame) -> Dict[str, float]:
        from sklearn.metrics import mean_absolute_error, r2_score, mean_squared_error
        from model_lib.types import OUTPUT_COLUMNS

        y_true = test_df[OUTPUT_COLUMNS].values
        y_pred = self._predictor.predict_batch(test_df).values
        r2_per = r2_score(y_true, y_pred, multioutput="raw_values")
        return {
            "r2":   float(r2_score(y_true, y_pred)),
            "mae":  float(mean_absolute_error(y_true, y_pred)),
            "rmse": float(np.sqrt(mean_squared_error(y_true, y_pred))),
            "r2_per_target": dict(zip(OUTPUT_COLUMNS, r2_per.tolist())),
        }