# -*- coding: utf-8 -*-
"""
features.py -- Physics-informed feature engineering for salt-pond waste prediction.
Salt-Pond Bittern Waste Valorisation Research, Puttalam, Sri Lanka.

Input schema (6 observable variables)
--------------------------------------
  production_volume  (float) -- monthly production in 50 kg bags
  rain_sum           (float) -- monthly total rainfall (mm)
  temperature_mean   (float) -- monthly mean temperature (deg C)
  humidity_mean      (float) -- monthly mean relative humidity (%)
  wind_speed_mean    (float) -- monthly mean wind speed (m/s)
  Month              (int)   -- calendar month 1-12

Engineered features (19 total) -- see individual docstrings below.

Target strategy
---------------
Six targets are predicted by ML; three solid composition targets are
derived from Total_Solid_Waste_kg using Puttalam-calibrated fractions:

  ML targets (6):
    Total_Solid_Waste_kg          -- driven by production, highly learnable
    Liquid_Waste_Bittern_Liters   -- driven by production, highly learnable
    Total_Waste_kg                -- solid + liquid, highly learnable
    Potential_Epsom_Salt_kg       -- driven by production x season Mg
    Potential_Potash_kg           -- driven by production x season K
    Potential_Magnesium_Oil_Liters-- driven by liquid waste volume

  All 9 targets are now ML-predicted. Solid composition fractions are
  physics-informed in generator_v3.py using retrograde solubility (Freyer &
  Voigt 2003) and rainfall dilution effects, giving a learnable seasonal
  signal. Post-prediction, enforce_solid_consistency scales the three solid
  components to sum exactly to Total_Solid_Waste_kg.

References
----------
[LIT-1] FAO. (1998). Crop evapotranspiration. FAO Irrigation and Drainage
        Paper 56. https://www.fao.org/3/x0490e/x0490e00.htm
[LIT-8] Rodrigo et al. -- Development of a Multi-Nutrient Fertilizer from
        Liquid Waste of Solar Salt Manufacturing Process, Puttalam.
        DOI: 10.13140/RG.2.1.3503.3525
"""

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Column name constants -- single source of truth
# ---------------------------------------------------------------------------

RAW_INPUT_COLS = [
    "production_volume",
    "rain_sum",
    "temperature_mean",
    "humidity_mean",
    "wind_speed_mean",
    "Month",
]

ENGINEERED_FEATURE_NAMES = [
    # Raw inputs
    "production_volume",
    "log_production",
    "sqrt_production",
    "rain_sum",
    "temperature_mean",
    "humidity_mean",
    "wind_speed_mean",
    # Physics driver
    "evaporation_potential",
    # Cyclical month encoding
    "month_sin",
    "month_cos",
    # Season binary flags (key for Mg-concentration signal)
    "is_dry_season",
    "is_monsoon",
    # Rainfall indices
    "wet_index",
    "dry_index",
    # Concentration proxy: high EP + low rain -> concentrated bittern -> high Mg
    "concentration_proxy",
    # Interaction terms
    "evap_x_production",
    "rain_x_production",
    "season_x_production",
    "rain_sq",
]

# All 9 targets are now ML-predicted.
# Solid composition fractions (Gypsum, Limestone, Industrial Salt) are physics-
# informed in the generator: gypsum/limestone increase with temperature (retrograde
# solubility, Freyer & Voigt 2003) and decrease with excess rainfall (dilution).
# Industrial Salt is the dominant remainder (~95%). All three are learnable from
# the 6 observable input features, unlike the previous Dirichlet random draw.
ML_TARGET_COLS = [
    "Total_Solid_Waste_kg",
    "Solid_Waste_Gypsum_kg",
    "Solid_Waste_Limestone_kg",
    "Solid_Waste_Industrial_Salt_kg",
    "Liquid_Waste_Bittern_Liters",
    "Total_Waste_kg",
    "Potential_Epsom_Salt_kg",
    "Potential_Potash_kg",
    "Potential_Magnesium_Oil_Liters",
]

# TARGET_COLS is identical to ML_TARGET_COLS -- all outputs are ML-predicted.
TARGET_COLS = ML_TARGET_COLS

# Solid components that must sum to Total_Solid_Waste_kg (used by
# enforce_solid_consistency after prediction).
SOLID_COMPONENTS = [
    "Solid_Waste_Gypsum_kg",
    "Solid_Waste_Limestone_kg",
    "Solid_Waste_Industrial_Salt_kg",
]


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Transform raw input columns into the engineered feature matrix.

    Parameters
    ----------
    df : pd.DataFrame containing RAW_INPUT_COLS.

    Returns
    -------
    pd.DataFrame with columns matching ENGINEERED_FEATURE_NAMES.
    """
    _check_input_cols(df)

    f = pd.DataFrame(index=df.index)

    pv   = df["production_volume"].values.astype(float)
    rain = df["rain_sum"].values.astype(float)
    temp = df["temperature_mean"].values.astype(float)
    hum  = df["humidity_mean"].values.astype(float)
    wind = df["wind_speed_mean"].values.astype(float)
    mon  = df["Month"].values.astype(float)

    # --- Raw inputs ---
    f["production_volume"] = pv
    f["log_production"]    = np.log1p(pv)
    f["sqrt_production"]   = np.sqrt(np.clip(pv, 0.0, None))
    f["rain_sum"]          = rain
    f["temperature_mean"]  = temp
    f["humidity_mean"]     = hum
    f["wind_speed_mean"]   = wind

    # --- Physics: Evaporation Potential [LIT-1] ---
    # EP = (Temp * Wind) / (Humidity + 1)
    # Higher EP => faster evaporation => higher brine concentration => higher
    # Mg per unit bittern => higher valorisation potential.
    evap = (temp * wind) / (hum + 1.0)
    f["evaporation_potential"] = evap

    # --- Cyclical month encoding ---
    # Sine/cosine encoding preserves the Dec->Jan continuity that a raw
    # integer encoding would break.
    f["month_sin"] = np.sin(2.0 * np.pi * mon / 12.0)
    f["month_cos"] = np.cos(2.0 * np.pi * mon / 12.0)

    # --- Season binary flags (Puttalam NW coast definition) ---
    # Critical for Mg-concentration signal: Dry Season has ~20 g/L Mg vs
    # Monsoon ~11 g/L. Without explicit season flags the model must infer
    # this entirely from month encoding, which is noisy.
    mon_int = mon.astype(int)
    f["is_dry_season"] = (
        (mon_int == 12) | ((mon_int >= 1) & (mon_int <= 4))
    ).astype(float)   # Dec-Apr
    f["is_monsoon"]    = (
        (mon_int >= 5) & (mon_int <= 9)
    ).astype(float)   # May-Sep
    # Inter-monsoon (Oct-Nov) is implicit as both flags == 0

    # --- Rainfall indices ---
    wet = rain / (rain + 100.0)        # bounded [0,1]
    f["wet_index"] = wet
    f["dry_index"] = 1.0 - wet

    # --- Concentration proxy ---
    # Higher evaporation AND lower rainfall -> more concentrated bittern
    # -> higher Mg g/L -> higher Epsom/Potash potential per litre.
    # The +0.1 floor prevents division by zero for dry months.
    f["concentration_proxy"] = evap / (wet + 0.1)

    # --- Interaction terms ---
    f["evap_x_production"]  = evap * pv / 1e5
    f["rain_x_production"]  = rain * pv / 1e8
    # Season-production interaction: captures that Dry (high Mg, lower prod)
    # and Monsoon (low Mg, higher prod) have opposite Mg-volume relationships.
    season_sign = f["is_dry_season"].values - f["is_monsoon"].values
    f["season_x_production"] = season_sign * f["log_production"].values
    f["rain_sq"]              = (rain / 100.0) ** 2

    return f[ENGINEERED_FEATURE_NAMES]



def _check_input_cols(df: "pd.DataFrame") -> None:
    missing = [c for c in RAW_INPUT_COLS if c not in df.columns]
    if missing:
        raise ValueError(
            "Input DataFrame is missing required columns: " + str(missing) + "\n"
            "Required: " + str(RAW_INPUT_COLS)
        )


# ---------------------------------------------------------------------------
# Post-prediction: derive solid composition fractions
# ---------------------------------------------------------------------------

def enforce_solid_consistency(predictions: "pd.DataFrame") -> "pd.DataFrame":
    """
    After ML prediction, rescale the three solid components (Gypsum, Limestone,
    Industrial Salt) so they sum exactly to Total_Solid_Waste_kg, preserving
    their predicted relative proportions.

    All nine outputs are ML-predicted. This post-processing step enforces the
    physical mass-balance constraint: components cannot exceed the whole.
    """
    import numpy as np
    df = predictions.copy()
    if not all(c in df.columns for c in SOLID_COMPONENTS + ["Total_Solid_Waste_kg"]):
        return df
    solid_sum    = df[SOLID_COMPONENTS].sum(axis=1)
    target_total = df["Total_Solid_Waste_kg"]
    scale = np.where(solid_sum > 1e-9, target_total / solid_sum, 1.0)
    for col in SOLID_COMPONENTS:
        df[col] = (df[col] * scale).clip(0)
    return df
