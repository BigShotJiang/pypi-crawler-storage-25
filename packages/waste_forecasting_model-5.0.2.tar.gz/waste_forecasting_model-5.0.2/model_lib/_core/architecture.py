"""
Core model architecture stubs for backwards-compatibility deserialization.

V3 note
-------
The active model is now ``WastePredictionModel`` from
``salt-waste-predction-model/train.py``.  That class is serialised into
``model.pkl`` and loaded directly by the loader — it carries its own
``engineer_features`` call internally, so no feature engineering is needed here.

These stubs are retained **solely** so that any legacy V2 pickle files
(which embed ``train.AdvancedFeatureEngineer``, ``GradientBoostingWasteModel``,
etc. in their class paths) can still be deserialized without import errors.
The ``_CompatUnpickler`` in loader.py remaps those paths to this module.

Do NOT use these classes for new model training or inference.
"""
from __future__ import annotations

import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")


# ── V3 output columns (single source of truth for architecture module) ────────

OUTPUT_COLS = [
    "Total_Solid_Waste_kg",
    "Solid_Waste_Gypsum_kg",         # physics-based (retrograde solubility, Freyer & Voigt 2003)
    "Solid_Waste_Limestone_kg",      # physics-based (retrograde solubility, Freyer & Voigt 2003)
    "Solid_Waste_Industrial_Salt_kg",
    "Liquid_Waste_Bittern_Liters",
    "Total_Waste_kg",
    "Potential_Epsom_Salt_kg",
    "Potential_Potash_kg",
    "Potential_Magnesium_Oil_Liters",
]


# ── Legacy V2 stubs (deserialization only — not used for inference) ───────────

class AdvancedFeatureEngineer:
    """Legacy V2 stub — retained for pickle deserialization only."""

    OUTPUT_COLS = [
        'Total_Waste_kg',
        'Solid_Waste_Gypsum_kg',
        'Solid_Waste_Limestone_kg',
        'Solid_Waste_Industrial_Salt_kg',
        'Total_Solid_Waste_kg',
        'Liquid_Waste_Bittern_Liters',
        'Bittern_Mg_Concentration_gL',
        'Bittern_K_Concentration_gL',
        'Bittern_SO4_Concentration_gL',
        'Bittern_Ca_Concentration_gL',
        'Bittern_Magnesium_kg',
        'Bittern_Potassium_kg',
        'Bittern_Sulfate_kg',
        'Bittern_Calcium_kg',
    ]

    def __init__(self) -> None:
        self.feature_names: list = []
        self.prod_mean = None
        self.prod_std = None

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError("V2 AdvancedFeatureEngineer is a deserialization stub only.")

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError("V2 AdvancedFeatureEngineer is a deserialization stub only.")


class GradientBoostingWasteModel:
    """Legacy V2 stub — retained for pickle deserialization only."""

    def __init__(self, n_estimators=300, learning_rate=0.05, max_depth=4):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.max_depth = max_depth
        self.models = {}
        self.scalers = {}
        self.feature_engineer = AdvancedFeatureEngineer()
        self.output_cols = AdvancedFeatureEngineer.OUTPUT_COLS

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError("V2 GradientBoostingWasteModel is a deserialization stub only.")


class StackedEnsembleModel:
    """Legacy V2 stub — retained for pickle deserialization only."""

    def __init__(self):
        self.feature_engineer = AdvancedFeatureEngineer()
        self.output_cols = AdvancedFeatureEngineer.OUTPUT_COLS
        self.models = {}
        self.scaler_X = None

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError("V2 StackedEnsembleModel is a deserialization stub only.")


class NeuralNetworkTrainer:
    """Legacy V2 stub — retained for pickle deserialization only."""

    def __init__(self, epochs=600, lr=0.001, patience=40):
        self.epochs = epochs
        self.lr = lr
        self.patience = patience
        self.feature_engineer = AdvancedFeatureEngineer()
        self.output_cols = AdvancedFeatureEngineer.OUTPUT_COLS

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError("V2 NeuralNetworkTrainer is a deserialization stub only.")


class ProductionWastePredictor:
    """Legacy V2 stub — retained for pickle deserialization only."""

    def __init__(self):
        self.models = {}
        self.weights = {}
        self.feature_engineer = AdvancedFeatureEngineer()
        self.output_cols = AdvancedFeatureEngineer.OUTPUT_COLS
        self.test_metrics = {}

    def predict(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError("V2 ProductionWastePredictor is a deserialization stub only.")

# =============================================================================
# V5 MODEL -- WastePredictionModel
# This is the canonical class that pickle uses when loading model.pkl.
# The loader remaps train.WastePredictionModel → model_lib._core.architecture
# so this class must be present here with a working predict() method.
# =============================================================================

class WastePredictionModel:
    """
    V5 physics-based waste prediction model (XGBoost, 9 targets).
    Loaded via model_lib._core.loader when deserialising model.pkl.

    Attributes set by pickle restore:
        models_  : dict[str, XGBRegressor]  -- one model per output target
        scaler_  : RobustScaler             -- fitted feature scaler
        metrics_ : dict                     -- training metrics
    """

    def __init__(self) -> None:
        self.models_:  dict = {}
        self.scaler_         = None   # restored by pickle
        self.metrics_: dict  = {}

    def predict(self, df):
        """Predict all 9 waste/valorisation targets from raw inputs."""
        import numpy as np
        import pandas as pd
        from model_lib.features import (
            engineer_features,
            enforce_solid_consistency,
            TARGET_COLS,
        )
        X    = engineer_features(df)
        X_sc = pd.DataFrame(self.scaler_.transform(X), columns=list(X.columns))

        preds = {}
        for target, model in self.models_.items():
            preds[target] = np.expm1(model.predict(X_sc)).clip(0)

        result = pd.DataFrame(preds, index=df.index)
        result = enforce_solid_consistency(result)
        return result[[c for c in TARGET_COLS if c in result.columns]]
