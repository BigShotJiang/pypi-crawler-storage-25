"""model_lib._core — internal model components (not part of public API)."""
