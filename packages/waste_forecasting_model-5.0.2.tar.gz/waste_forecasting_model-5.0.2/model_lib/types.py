"""
Typed contracts for WastePredictor inputs and outputs.
Import these in any consumer: FL clients, API routes, tests, event handlers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ── Input ──────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class PredictionInput:
    """
    Validated input for a single prediction (V3 model).

    Example
    -------
    >>> inp = PredictionInput(
    ...     production_volume=50_000,
    ...     rain_sum=200.0,
    ...     temperature_mean=28.0,
    ...     humidity_mean=85.0,
    ...     wind_speed_mean=15.0,
    ...     month=6,
    ... )
    """
    production_volume: float
    rain_sum: float
    temperature_mean: float
    humidity_mean: float
    wind_speed_mean: float
    month: int = 6

    def __post_init__(self) -> None:
        if not (1 <= self.month <= 12):
            raise ValueError(f"month must be 1-12, got {self.month}")
        if self.production_volume < 0:
            raise ValueError("production_volume must be >= 0")
        if not (0 <= self.humidity_mean <= 100):
            raise ValueError("humidity_mean must be 0-100")

    def to_dict(self) -> Dict[str, float]:
        return {
            "production_volume": self.production_volume,
            "rain_sum": self.rain_sum,
            "temperature_mean": self.temperature_mean,
            "humidity_mean": self.humidity_mean,
            "wind_speed_mean": self.wind_speed_mean,
            "Month": float(self.month),
        }


# ── Output ─────────────────────────────────────────────────────────────────

OUTPUT_COLUMNS: List[str] = [
    "Total_Solid_Waste_kg",
    "Solid_Waste_Gypsum_kg",         # physics-based (retrograde solubility, Freyer & Voigt 2003)
    "Solid_Waste_Limestone_kg",      # physics-based (retrograde solubility, Freyer & Voigt 2003)
    "Solid_Waste_Industrial_Salt_kg",
    "Liquid_Waste_Bittern_Liters",
    "Total_Waste_kg",
    "Potential_Epsom_Salt_kg",
    "Potential_Potash_kg",
    "Potential_Magnesium_Oil_Liters",
]

INPUT_COLUMNS: List[str] = [
    "production_volume",
    "rain_sum",
    "temperature_mean",
    "humidity_mean",
    "wind_speed_mean",
    "Month",  # capital-M, as expected by engineer_features
]


@dataclass
class PredictionResult:
    """
    Strongly-typed wrapper for model output (V3 model - 9 ML-predicted outputs).

    All nine outputs are predicted directly by the ML model (WastePredictionModel).
    Solid waste components (gypsum and limestone) are physics-informed via
    retrograde solubility (Freyer & Voigt 2003) — they are no longer fixed fractions
    but vary with temperature and rainfall season.

    Access fields directly or call `.to_dict()` for JSON serialisation.
    """
    total_solid_waste_kg: float
    solid_waste_gypsum_kg: float
    solid_waste_limestone_kg: float
    solid_waste_industrial_salt_kg: float
    liquid_waste_bittern_liters: float
    total_waste_kg: float
    potential_epsom_salt_kg: float
    potential_potash_kg: float
    potential_magnesium_oil_liters: float
    model_version: str = "unknown"
    confidence: Optional[float] = None

    @classmethod
    def from_dict(cls, d: Dict[str, float], model_version: str = "unknown") -> "PredictionResult":
        return cls(
            total_solid_waste_kg=d["Total_Solid_Waste_kg"],
            solid_waste_gypsum_kg=d["Solid_Waste_Gypsum_kg"],
            solid_waste_limestone_kg=d["Solid_Waste_Limestone_kg"],
            solid_waste_industrial_salt_kg=d["Solid_Waste_Industrial_Salt_kg"],
            liquid_waste_bittern_liters=d["Liquid_Waste_Bittern_Liters"],
            total_waste_kg=d["Total_Waste_kg"],
            potential_epsom_salt_kg=d["Potential_Epsom_Salt_kg"],
            potential_potash_kg=d["Potential_Potash_kg"],
            potential_magnesium_oil_liters=d["Potential_Magnesium_Oil_Liters"],
            model_version=model_version,
        )

    def to_dict(self) -> Dict[str, float]:
        return {
            "Total_Solid_Waste_kg": self.total_solid_waste_kg,
            "Solid_Waste_Gypsum_kg": self.solid_waste_gypsum_kg,
            "Solid_Waste_Limestone_kg": self.solid_waste_limestone_kg,
            "Solid_Waste_Industrial_Salt_kg": self.solid_waste_industrial_salt_kg,
            "Liquid_Waste_Bittern_Liters": self.liquid_waste_bittern_liters,
            "Total_Waste_kg": self.total_waste_kg,
            "Potential_Epsom_Salt_kg": self.potential_epsom_salt_kg,
            "Potential_Potash_kg": self.potential_potash_kg,
            "Potential_Magnesium_Oil_Liters": self.potential_magnesium_oil_liters,
        }
