"""
waste-forecasting-model v2.3.0 — Portable waste prediction with S3 model management.

Installation
------------
    # With S3 support (recommended)
    pip install waste-forecasting-model[sqs]
    
    # Basic installation
    pip install waste-forecasting-model

Public API
----------
    from model_lib import WastePredictor, predict_waste, download_model_from_s3
    from model_lib import PredictionInput, PredictionResult

Quick Start
-----------
    # Basic prediction
    predictor = WastePredictor()
    result = predictor.predict(
        production_volume=50_000,
        rain_sum=200,
        temperature_mean=28,
        humidity_mean=85,
        wind_speed_mean=15,
        month=6,
    )
    print(f"Total waste: {result.total_waste_kg} kg")

Download Model from S3
----------------------
    # Download and use model from S3
    from model_lib import download_model_from_s3, WastePredictor
    
    path = download_model_from_s3("s3://bucket/models/waste_predictor_v5.pkl")
    predictor = WastePredictor(model_path=str(path))
    
    # Or hot-reload existing predictor
    predictor = WastePredictor()
    info = predictor.download_and_update_model("s3://bucket/models/model.pkl")
    print(f"Updated to v{info['version']}")

AWS Configuration
-----------------
Set AWS credentials via:
    - Environment: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY
    - File: ~/.aws/credentials
    - IAM role (EC2/Lambda)

Model Location
--------------
Default search paths:
    1. $WASTE_PREDICTOR_MODEL_PATH (environment variable)
    2. ~/.model_lib/waste_predictor_v4.pkl
    3. <package>/artifacts/waste_predictor_v4.pkl
    4. ./waste_predictor_v4.pkl (current working directory)

S3 Download saves to:
    - Current working directory by default
    - Or custom path via destination parameter
"""
from importlib.metadata import PackageNotFoundError, version

from model_lib.predictor import WastePredictor, predict_waste
from model_lib._core.loader import download_model_from_s3
from model_lib.types import (
    OUTPUT_COLUMNS,
    INPUT_COLUMNS,
    PredictionInput,
    PredictionResult,
)

try:
    __version__: str = version("waste-forecasting-model")
except PackageNotFoundError:   # editable / source install
    __version__ = "0.0.0.dev"

__all__ = [
    # Core prediction
    "WastePredictor",
    "predict_waste",
    # Model management
    "download_model_from_s3",
    # Typed contracts
    "PredictionInput",
    "PredictionResult",
    "OUTPUT_COLUMNS",
    "INPUT_COLUMNS",
    # Metadata
    "__version__",
]
