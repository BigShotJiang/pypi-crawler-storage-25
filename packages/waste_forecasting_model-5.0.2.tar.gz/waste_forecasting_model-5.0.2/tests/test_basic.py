"""
Basic tests for waste-forecasting-model package
"""
import pytest
import pandas as pd
from model_lib import (
    WastePredictor,
    predict_waste,
    PredictionInput,
    PredictionResult,
    OUTPUT_COLUMNS,
    INPUT_COLUMNS,
)


class TestModelLoading:
    """Test model loading and initialization"""

    def test_predictor_loads(self):
        """Test that predictor loads without errors"""
        predictor = WastePredictor()
        assert predictor is not None
        assert predictor.version is not None

    def test_predictor_has_outputs(self):
        """Test that predictor has correct output columns"""
        predictor = WastePredictor()
        assert len(predictor.OUTPUT_COLS) == 14
        assert predictor.OUTPUT_COLS == OUTPUT_COLUMNS


class TestSinglePrediction:
    """Test single prediction methods"""

    def test_predict_basic(self):
        """Test basic predict method"""
        predictor = WastePredictor()
        result = predictor.predict(
            production_volume=50000,
            rain_sum=200,
            temperature_mean=28,
            humidity_mean=85,
            wind_speed_mean=15,
            month=6,
        )
        assert isinstance(result, PredictionResult)
        assert result.total_waste_kg > 0
        assert result.solid_waste_gypsum_kg > 0
        assert result.liquid_waste_bittern_liters > 0

    def test_predict_dict(self):
        """Test dictionary-based prediction"""
        predictor = WastePredictor()
        result = predictor.predict_dict({
            'production_volume': 50000,
            'rain_sum': 200,
            'temperature_mean': 28,
            'humidity_mean': 85,
            'wind_speed_mean': 15,
            'month': 6,
        })
        assert isinstance(result, dict)
        assert 'Total_Waste_kg' in result
        assert result['Total_Waste_kg'] > 0

    def test_predict_typed(self):
        """Test typed prediction with PredictionInput"""
        predictor = WastePredictor()
        input_data = PredictionInput(
            production_volume=50000,
            rain_sum=200,
            temperature_mean=28,
            humidity_mean=85,
            wind_speed_mean=15,
            month=6,
        )
        result = predictor.predict_typed(input_data)
        assert isinstance(result, PredictionResult)
        assert result.total_waste_kg > 0

    def test_module_level_predict(self):
        """Test module-level convenience function"""
        result = predict_waste(
            production_volume=50000,
            rain_sum=200,
            temperature_mean=28,
            humidity_mean=85,
            wind_speed_mean=15,
        )
        assert isinstance(result, dict)
        assert 'Total_Waste_kg' in result


class TestBatchPrediction:
    """Test batch prediction functionality"""

    def test_batch_prediction(self):
        """Test batch prediction with DataFrame"""
        predictor = WastePredictor()
        df = pd.DataFrame([
            {
                'production_volume': 50000,
                'rain_sum': 200, 'temperature_mean': 28,
                'humidity_mean': 85, 'wind_speed_mean': 15,
                'Month': 6, 'Year': 2026
            },
            {
                'production_volume': 45000,
                'rain_sum': 150, 'temperature_mean': 30,
                'humidity_mean': 75, 'wind_speed_mean': 18,
                'Month': 8, 'Year': 2026
            }
        ])
        result = predictor.predict_batch(df)
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2
        assert len(result.columns) == 14


class TestOutputFormat:
    """Test output format and structure"""

    def test_all_14_outputs(self):
        """Test that all 14 outputs are present"""
        predictor = WastePredictor()
        result = predictor.predict(
            production_volume=50000,
            rain_sum=200,
            temperature_mean=28,
            humidity_mean=85,
            wind_speed_mean=15,
        )
        result_dict = result.to_dict()
        assert len(result_dict) == 14
        
        expected_keys = [
            'Total_Waste_kg',
            'Solid_Waste_Gypsum_kg',
            'Solid_Waste_Limestone_kg',
            'Solid_Waste_Industrial_Salt_kg',
            'Total_Solid_Waste_kg',
            'Liquid_Waste_Bittern_Liters',
            'Bittern_Mg_Concentration_gL',
            'Bittern_K_Concentration_gL',
            'Bittern_SO4_Concentration_gL',
            'Bittern_Ca_Concentration_gL',
            'Bittern_Magnesium_kg',
            'Bittern_Potassium_kg',
            'Bittern_Sulfate_kg',
            'Bittern_Calcium_kg',
        ]
        for key in expected_keys:
            assert key in result_dict

    def test_output_types(self):
        """Test that outputs are numeric"""
        predictor = WastePredictor()
        result = predictor.predict(
            production_volume=50000,
            rain_sum=200,
            temperature_mean=28,
            humidity_mean=85,
            wind_speed_mean=15,
        )
        assert isinstance(result.total_waste_kg, (int, float))
        assert isinstance(result.solid_waste_gypsum_kg, (int, float))
        assert isinstance(result.bittern_mg_concentration_gl, (int, float))


class TestInputValidation:
    """Test input validation"""

    def test_invalid_month(self):
        """Test that invalid month raises error"""
        with pytest.raises(ValueError):
            PredictionInput(
                production_volume=50000,
                rain_sum=200,
                temperature_mean=28,
                humidity_mean=85,
                wind_speed_mean=15,
                month=13,  # Invalid
            )

    def test_invalid_humidity(self):
        """Test that invalid humidity raises error"""
        with pytest.raises(ValueError):
            PredictionInput(
                production_volume=50000,
                rain_sum=200,
                temperature_mean=28,
                humidity_mean=150,  # Invalid
                wind_speed_mean=15,
            )

    def test_negative_production(self):
        """Test that negative production raises error"""
        with pytest.raises(ValueError):
            PredictionInput(
                production_volume=-1000,  # Invalid
                rain_sum=200,
                temperature_mean=28,
                humidity_mean=85,
                wind_speed_mean=15,
            )


class TestRangeValidation:
    """Test that predictions are within reasonable ranges"""

    def test_positive_outputs(self):
        """Test that all outputs are non-negative"""
        predictor = WastePredictor()
        result = predictor.predict(
            production_volume=50000,
            rain_sum=200,
            temperature_mean=28,
            humidity_mean=85,
            wind_speed_mean=15,
        )
        assert result.total_waste_kg >= 0
        assert result.solid_waste_gypsum_kg >= 0
        assert result.liquid_waste_bittern_liters >= 0
        assert result.bittern_magnesium_kg >= 0

    def test_concentration_ranges(self):
        """Test that concentrations are within reasonable ranges"""
        predictor = WastePredictor()
        result = predictor.predict(
            production_volume=50000,
            rain_sum=200,
            temperature_mean=28,
            humidity_mean=85,
            wind_speed_mean=15,
        )
        # Concentrations should be positive and reasonable (< 100 g/L)
        assert 0 < result.bittern_mg_concentration_gl < 100
        assert 0 < result.bittern_k_concentration_gl < 100
        assert 0 < result.bittern_so4_concentration_gl < 100


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
