"""
Test package initialization and exports
"""
import pytest


def test_package_imports():
    """Test that all main exports are available"""
    from model_lib import (
        WastePredictor,
        predict_waste,
        PredictionInput,
        PredictionResult,
        OUTPUT_COLUMNS,
        INPUT_COLUMNS,
        download_model_from_s3,
        __version__,
    )
    
    assert WastePredictor is not None
    assert predict_waste is not None
    assert PredictionInput is not None
    assert PredictionResult is not None
    assert OUTPUT_COLUMNS is not None
    assert INPUT_COLUMNS is not None
    assert download_model_from_s3 is not None
    assert __version__ is not None


def test_version_format():
    """Test that version follows semantic versioning"""
    from model_lib import __version__
    
    # Should be format: X.Y.Z or X.Y.Z.dev
    parts = __version__.split('.')
    assert len(parts) >= 3, f"Version should be X.Y.Z format, got: {__version__}"


def test_output_columns_count():
    """Test that OUTPUT_COLUMNS has 14 items"""
    from model_lib import OUTPUT_COLUMNS
    
    assert len(OUTPUT_COLUMNS) == 14


def test_input_columns_count():
    """Test that INPUT_COLUMNS has 8 items"""
    from model_lib import INPUT_COLUMNS
    
    assert len(INPUT_COLUMNS) == 8


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
