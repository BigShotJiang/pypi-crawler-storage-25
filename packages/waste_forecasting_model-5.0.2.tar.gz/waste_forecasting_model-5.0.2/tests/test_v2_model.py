"""
Test script for V3 model integration
"""
import sys
sys.path.insert(0, 'd:\\Research\\model_lib')

from model_lib import WastePredictor, predict_waste

print("="*70)
print("Testing V3 Model with model_lib")
print("="*70)

# Test 1: Load predictor
print("\n[Test 1] Loading WastePredictor...")
try:
    predictor = WastePredictor()
    print("✓ WastePredictor loaded successfully")
    print(f"  Model version: {predictor.version}")
    print(f"  Output columns: {len(predictor.OUTPUT_COLS)}")
    assert len(predictor.OUTPUT_COLS) == 9, f"Expected 9 output cols, got {len(predictor.OUTPUT_COLS)}"
except Exception as e:
    print(f"✗ Failed to load predictor: {e}")
    sys.exit(1)

# Test 2: Single prediction with typed result
print("\n[Test 2] Single prediction (typed)...")
try:
    result = predictor.predict(
        production_volume=50000,
        rain_sum=200,
        temperature_mean=28,
        humidity_mean=85,
        wind_speed_mean=15,
        month=6,
    )
    print("✓ Prediction successful")
    print(f"  Total Solid Waste: {result.total_solid_waste_kg:.2f} kg")
    print(f"  Total Waste: {result.total_waste_kg:.2f} kg")
    print(f"  Solid Waste (Gypsum): {result.solid_waste_gypsum_kg:.2f} kg")
    print(f"  Solid Waste (Limestone): {result.solid_waste_limestone_kg:.2f} kg")
    print(f"  Bittern Volume: {result.liquid_waste_bittern_liters:.2f} L")
    print(f"  Potential Epsom Salt: {result.potential_epsom_salt_kg:.2f} kg")
    print(f"  Potential Potash: {result.potential_potash_kg:.2f} kg")
    print(f"  Potential Magnesium Oil: {result.potential_magnesium_oil_liters:.2f} L")
except Exception as e:
    print(f"✗ Prediction failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 3: Dictionary-based prediction
print("\n[Test 3] Dictionary-based prediction...")
try:
    result_dict = predictor.predict_dict({
        'production_volume': 45000,
        'rain_sum': 150,
        'temperature_mean': 30,
        'humidity_mean': 75,
        'wind_speed_mean': 18,
        'month': 8,
    })
    print("✓ Dictionary prediction successful")
    print(f"  Total Waste: {result_dict['Total_Waste_kg']:.2f} kg")
    print(f"  Total Solid Waste: {result_dict['Total_Solid_Waste_kg']:.2f} kg")
    print(f"  Potential Epsom Salt: {result_dict['Potential_Epsom_Salt_kg']:.2f} kg")
except Exception as e:
    print(f"✗ Dictionary prediction failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 4: Module-level convenience function (year param accepted but ignored)
print("\n[Test 4] Module-level predict_waste function...")
try:
    result_dict = predict_waste(
        production_volume=55000,
        rain_sum=100,
        temperature_mean=29,
        humidity_mean=80,
        wind_speed_mean=16,
        month=3,
        year=2026,  # backward-compat: accepted but ignored by V3 model
    )
    print("✓ Module function successful")
    print(f"  Total Waste: {result_dict['Total_Waste_kg']:.2f} kg")
    print(f"  Limestone: {result_dict['Solid_Waste_Limestone_kg']:.2f} kg")
    print(f"  Industrial Salt: {result_dict['Solid_Waste_Industrial_Salt_kg']:.2f} kg")
    print(f"  Potential Potash: {result_dict['Potential_Potash_kg']:.2f} kg")
except Exception as e:
    print(f"✗ Module function failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 5: Batch prediction
print("\n[Test 5] Batch prediction...")
try:
    import pandas as pd
    test_data = pd.DataFrame([
        {
            'production_volume': 40000,
            'rain_sum': 250,
            'temperature_mean': 27,
            'humidity_mean': 90,
            'wind_speed_mean': 12,
            'Month': 10,
        },
        {
            'production_volume': 52000,
            'rain_sum': 50,
            'temperature_mean': 31,
            'humidity_mean': 70,
            'wind_speed_mean': 20,
            'Month': 4,
        }
    ])

    results_df = predictor.predict_batch(test_data)
    print("✓ Batch prediction successful")
    print(f"  Predictions shape: {results_df.shape}")
    assert results_df.shape[1] == 9, f"Expected 9 output cols, got {results_df.shape[1]}"
    print(f"\n  Sample results:")
    for i, row in results_df.iterrows():
        print(f"    Row {i}: Total Waste = {row['Total_Waste_kg']:.2f} kg")
except Exception as e:
    print(f"✗ Batch prediction failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 6: Verify all 9 outputs are present
print("\n[Test 6] Verify all 9 output columns...")
try:
    expected_cols = [
        'Total_Solid_Waste_kg',
        'Solid_Waste_Gypsum_kg',
        'Solid_Waste_Limestone_kg',
        'Solid_Waste_Industrial_Salt_kg',
        'Liquid_Waste_Bittern_Liters',
        'Total_Waste_kg',
        'Potential_Epsom_Salt_kg',
        'Potential_Potash_kg',
        'Potential_Magnesium_Oil_Liters',
    ]

    result_dict = predict_waste(
        production_volume=50000,
        rain_sum=200,
        temperature_mean=28,
        humidity_mean=85,
        wind_speed_mean=15
    )

    missing = [col for col in expected_cols if col not in result_dict]
    if missing:
        print(f"✗ Missing columns: {missing}")
        sys.exit(1)

    # Verify old Bittern chemistry columns are NOT present
    old_cols = [
        'Bittern_Mg_Concentration_gL',
        'Bittern_K_Concentration_gL',
        'Bittern_SO4_Concentration_gL',
        'Bittern_Ca_Concentration_gL',
        'Bittern_Magnesium_kg',
        'Bittern_Potassium_kg',
        'Bittern_Sulfate_kg',
        'Bittern_Calcium_kg',
    ]
    unexpected = [col for col in old_cols if col in result_dict]
    if unexpected:
        print(f"✗ Unexpected old V2 columns present: {unexpected}")
        sys.exit(1)

    print("✓ All 9 output columns present, no old Bittern chemistry columns")
    for col in expected_cols:
        print(f"  {col}: {result_dict[col]:.2f}")
except Exception as e:
    print(f"✗ Output verification failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 7: Gypsum and limestone fractions vary by season (not constant)
print("\n[Test 7] Gypsum/limestone fractions vary by season...")
try:
    import pandas as pd
    # Compare dry season (Month=4, low rain, high temp) vs wet season (Month=11, high rain)
    dry = predict_waste(
        production_volume=50000, rain_sum=30,
        temperature_mean=33, humidity_mean=65,
        wind_speed_mean=18, month=4,
    )
    wet = predict_waste(
        production_volume=50000, rain_sum=350,
        temperature_mean=27, humidity_mean=92,
        wind_speed_mean=10, month=11,
    )

    dry_gypsum_frac = dry['Solid_Waste_Gypsum_kg'] / dry['Total_Solid_Waste_kg']
    wet_gypsum_frac = wet['Solid_Waste_Gypsum_kg'] / wet['Total_Solid_Waste_kg']

    print(f"  Dry season gypsum fraction:  {dry_gypsum_frac:.4f}")
    print(f"  Wet season gypsum fraction:  {wet_gypsum_frac:.4f}")

    if abs(dry_gypsum_frac - wet_gypsum_frac) > 1e-6:
        print("✓ Gypsum fraction varies by season (physics-based, not fixed)")
    else:
        print("✗ Gypsum fraction is identical across seasons — check model physics")

    dry_lime_frac = dry['Solid_Waste_Limestone_kg'] / dry['Total_Solid_Waste_kg']
    wet_lime_frac = wet['Solid_Waste_Limestone_kg'] / wet['Total_Solid_Waste_kg']
    print(f"  Dry season limestone fraction: {dry_lime_frac:.4f}")
    print(f"  Wet season limestone fraction: {wet_lime_frac:.4f}")

    if abs(dry_lime_frac - wet_lime_frac) > 1e-6:
        print("✓ Limestone fraction varies by season (physics-based, not fixed)")
    else:
        print("✗ Limestone fraction is identical across seasons — check model physics")

except Exception as e:
    print(f"✗ Seasonal variation test failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "="*70)
print("ALL TESTS PASSED ✓")
print("="*70)
print("\nModel is ready for publishing!")
