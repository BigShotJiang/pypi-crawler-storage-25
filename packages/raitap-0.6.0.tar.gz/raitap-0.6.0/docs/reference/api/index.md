# API Reference

The first implementation documents the stable public package surfaces only. Internal
implementation modules are intentionally left out of the primary navigation tree.

```{toctree}
:maxdepth: 1

data
metrics
models
semantics_base
tracking
transparency
robustness
```
