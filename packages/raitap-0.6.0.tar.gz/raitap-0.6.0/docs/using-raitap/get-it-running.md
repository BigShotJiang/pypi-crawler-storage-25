# Running a quick example

This page shows how to get RAITAP running quickly, with a **simple pre-defined example**. If you want to see how to fully configure your own assessment, skip to the {doc}`configuration/index` page.

:::{note}

This page assumes you have **already installed RAITAP**. If you didn't, see the {doc}`installation` page.
:::

## 1. Install dependencies

Our pre-defined example uses a PyTorch model and runs both a transparency assessment (Captum) and a robustness assessment (torchattacks FGSM). Hence, we install the dependencies:

```{install-tabs}
:uv:
uv add "raitap[captum,torchattacks,reporting,torch-cpu]"

:pip:
pip install "raitap[captum,torchattacks,reporting,torch-cpu]"
```

:::{note}

The example is light enough to run on a CPU, hence we used `torch-cpu`. Feel free to **use another execution profile** (e.g. `torch-cuda`). Refer to {ref}`execution-dependencies` for more details.
:::

## 2. Run the example

Our pre-defined example is the default config shipped with RAITAP. This means you do not need to specify any options to run it. It uses the
`imagenet_samples` demo dataset (four ImageNet images bundled with ground-truth labels) so metrics and robustness run with real targets out of the box.

```{install-tabs}
:uv:
uv run raitap

:pip:
raitap
```

## 3. Inspect the output

After the run is complete, the `outputs` directory can be found in the directory you ran RAITAP from.

It will contain the run's metadata, the transparency assessment (attributions and visualisations), the robustness assessment (adversarial examples, per-sample verdicts, and an image-pair visualisation), and a PDF report under `reports/`. Refer to the {doc}`understanding-outputs` page for more details.
