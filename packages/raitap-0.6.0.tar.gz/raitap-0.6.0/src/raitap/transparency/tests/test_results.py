from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any
from unittest.mock import MagicMock

import matplotlib.pyplot as plt
import pytest
import torch

from raitap.configs import resolve_run_dir, set_output_root
from raitap.configs.schema import AppConfig
from raitap.transparency.contracts import (
    ExplanationOutputSpace,
    ExplanationPayloadKind,
    ExplanationScope,
    ExplanationSemantics,
    ExplanationTarget,
    InputSpec,
    MethodFamily,
    OutputSpaceSpec,
    SampleSelection,
    ScopeDefinitionStep,
)
from raitap.transparency.explainers.base_explainer import AttributionOnlyExplainer
from raitap.transparency.results import (
    ConfiguredVisualiser,
    ExplanationResult,
    VisualisationResult,
    _serialisable,
)
from raitap.transparency.visualisers import ShapImageVisualiser
from raitap.transparency.visualisers.base_visualiser import BaseVisualiser

if TYPE_CHECKING:
    from _pytest.monkeypatch import MonkeyPatch
    from matplotlib.figure import Figure

    from raitap.transparency.contracts import VisualisationContext


def _semantics(
    *,
    method_families: frozenset[MethodFamily] = frozenset({MethodFamily.GRADIENT}),
) -> ExplanationSemantics:
    return ExplanationSemantics(
        scope=ExplanationScope.LOCAL,
        scope_definition_step=ScopeDefinitionStep.EXPLAINER_OUTPUT,
        payload_kind=ExplanationPayloadKind.ATTRIBUTIONS,
        method_families=method_families,
        target=ExplanationTarget(target=0),
        sample_selection=SampleSelection(
            sample_ids=["stable-1"],
            sample_display_names=["Display 1"],
        ),
        input_spec=InputSpec(
            kind="image",
            shape=(1, 3, 4, 4),
            layout="NCHW",
            feature_names=None,
            metadata={"kind": "image", "layout": "NCHW"},
        ),
        output_space=OutputSpaceSpec(
            space=ExplanationOutputSpace.INPUT_FEATURES,
            shape=(1, 3, 4, 4),
            layout="NCHW",
        ),
    )


def _make_explanation(run_dir: Path, *, explainer_name: str | None = "exp") -> ExplanationResult:
    return ExplanationResult(
        attributions=torch.randn(1, 3, 4, 4),
        inputs=torch.randn(1, 3, 4, 4),
        run_dir=run_dir,
        experiment_name="test-exp",
        explainer_target="raitap.transparency.CaptumExplainer",
        algorithm="Saliency",
        semantics=_semantics(),
        explainer_name=explainer_name,
    )


class _IdentityExplainer(AttributionOnlyExplainer, register=False):
    algorithm = "Saliency"
    explainer_framework = "Captum"

    def compute_attributions(
        self,
        model: torch.nn.Module,
        inputs: torch.Tensor,
        **kwargs: Any,
    ) -> torch.Tensor:
        del model, kwargs
        return inputs.clone()


def test_resolve_run_dir_uses_hydra_runtime(monkeypatch: MonkeyPatch) -> None:
    class _HydraRuntime:
        output_dir = "hydra-output"

    class _HydraConfig:
        runtime = _HydraRuntime()

    monkeypatch.setattr("raitap.configs.utils.HydraConfig.get", lambda: _HydraConfig())
    assert resolve_run_dir(subdir="transparency") == Path("hydra-output") / "transparency"


def test_resolve_run_dir_falls_back_to_config_output_dir(
    monkeypatch: MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(
        "raitap.configs.utils.HydraConfig.get",
        lambda: (_ for _ in ()).throw(ValueError("not initialised")),
    )
    config = AppConfig()
    set_output_root(config, tmp_path)
    assert resolve_run_dir(config, subdir="transparency") == tmp_path / "transparency"


def test_base_explainer_uses_unified_output_root(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(
        "raitap.configs.utils.HydraConfig.get",
        lambda: (_ for _ in ()).throw(ValueError("not initialised")),
    )
    explainer = _IdentityExplainer()
    inputs = torch.randn(1, 3, 4, 4)

    result = explainer.explain(
        torch.nn.Identity(),
        inputs,
        output_root=tmp_path,
        raitap_kwargs={
            "input_metadata": InputSpec(
                kind="image",
                shape=tuple(inputs.shape),
                layout="NCHW",
                metadata={"kind": "image", "layout": "NCHW"},
            )
        },
    )

    assert result.run_dir == tmp_path / "transparency"
    assert (tmp_path / "transparency" / "attributions.pt").exists()


def test_serialisable_handles_runtimeerror_from_item() -> None:
    tensor = torch.randn(2, 2)
    result = _serialisable(tensor)
    assert isinstance(result, str)
    assert "tensor" in result


def test_serialisable_converts_nested_set_and_dict() -> None:
    value = {"tags": {"a", "b"}, "nested": {"k": 1}}
    result = _serialisable(value)
    assert sorted(result["tags"]) == ["a", "b"]
    assert result["nested"]["k"] == 1


def test_explanation_result_requires_explicit_semantics(tmp_path: Path) -> None:
    with pytest.raises(TypeError, match="semantics"):
        ExplanationResult(  # type: ignore[call-arg]
            attributions=torch.randn(1, 3, 4, 4),
            inputs=torch.randn(1, 3, 4, 4),
            run_dir=tmp_path / "exp_missing_semantics",
            experiment_name="e",
            explainer_target="t",
            algorithm="a",
        )


def test_explanation_metadata_summarises_tensor_call_kwargs(tmp_path: Path) -> None:
    run_dir = tmp_path / "exp_call_kwargs_summary"
    explanation = ExplanationResult(
        attributions=torch.randn(1, 3, 4, 4),
        inputs=torch.randn(1, 3, 4, 4),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="a",
        semantics=_semantics(),
        kwargs={"show_sample_names": True},
        call_kwargs={
            "target": 7,
            "background_data": torch.randn(2, 3, 4, 4),
            "nested": {"baselines": torch.zeros(1, 3, 4, 4)},
        },
    )

    metadata = explanation._metadata()

    assert metadata["kwargs"] == {"show_sample_names": True}
    call_kwargs = metadata["call_kwargs"]
    assert call_kwargs["target"] == 7
    assert call_kwargs["background_data"] == {
        "type": "torch.Tensor",
        "shape": [2, 3, 4, 4],
        "dtype": "torch.float32",
        "device": "cpu",
    }
    assert call_kwargs["nested"]["baselines"] == {
        "type": "torch.Tensor",
        "shape": [1, 3, 4, 4],
        "dtype": "torch.float32",
        "device": "cpu",
    }


def test_explanation_metadata_serializes_semantics_to_json(tmp_path: Path) -> None:
    run_dir = tmp_path / "exp_semantics"
    explanation = ExplanationResult(
        attributions=torch.randn(1, 3, 4, 4),
        inputs=torch.randn(1, 3, 4, 4),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="raitap.transparency.CaptumExplainer",
        algorithm="Saliency",
        semantics=_semantics(),
    )

    explanation.write_artifacts()

    metadata = json.loads((run_dir / "metadata.json").read_text(encoding="utf-8"))
    assert metadata["semantics"]["scope"] == "local"
    assert metadata["semantics"]["scope_definition_step"] == "explainer_output"
    assert metadata["semantics"]["payload_kind"] == "attributions"
    assert metadata["semantics"]["method_families"] == ["gradient"]
    assert metadata["semantics"]["target"] == {"target": 0, "label": None}
    assert metadata["semantics"]["sample_selection"] == {
        "sample_ids": ["stable-1"],
        "sample_display_names": ["Display 1"],
    }
    assert metadata["semantics"]["input_spec"]["kind"] == "image"
    assert metadata["semantics"]["input_spec"]["layout"] == "NCHW"
    assert metadata["semantics"]["output_space"]["space"] == "input_features"


def test_explanation_log_no_visualisers_logs_run_directory(tmp_path: Path) -> None:
    run_dir = tmp_path / "exp"
    explanation = _make_explanation(run_dir)
    explanation.write_artifacts()
    tracker = MagicMock()

    explanation.log(tracker, artifact_path="transparency", use_subdirectory=True)

    tracker.log_artifacts.assert_called_once_with(
        run_dir,
        target_subdirectory="transparency/exp",
    )


def test_explanation_log_with_visualisers_stages_explanation_only(tmp_path: Path) -> None:
    run_dir = tmp_path / "exp"
    explanation = _make_explanation(run_dir)
    explanation.write_artifacts()
    explanation.visualiser_targets = ["raitap.transparency.CaptumImageVisualiser"]
    explanation._metadata = MagicMock(return_value={"visualisers": []})  # type: ignore[method-assign]
    tracker = MagicMock()

    explanation.log(tracker, artifact_path="transparency", use_subdirectory=False)

    explanation._metadata.assert_called_once_with(visualiser_targets=[])  # type: ignore[attr-defined]
    tracker.log_artifacts.assert_called_once()


def test_explanation_log_uses_run_dir_name_fallback_when_explainer_name_is_unset(
    tmp_path: Path,
) -> None:
    run_dir = tmp_path / "run123"
    explanation = _make_explanation(run_dir, explainer_name=None)
    explanation.write_artifacts()
    tracker = MagicMock()

    explanation.log(tracker, artifact_path="transparency", use_subdirectory=True)

    tracker.log_artifacts.assert_called_once_with(
        run_dir,
        target_subdirectory=f"transparency/{run_dir.name}",
    )


def test_visualisation_log_uses_same_fallback_as_explanation(tmp_path: Path) -> None:
    run_dir = tmp_path / "run123"
    explanation = _make_explanation(run_dir, explainer_name=None)

    output_path = tmp_path / "vis.png"
    output_path.write_bytes(b"not-a-real-png-but-a-file")

    visualisation = VisualisationResult(
        explanation=explanation,
        figure=MagicMock(),
        visualiser_name="SomeVisualiser",
        visualiser_target="some.target",
        output_path=output_path,
    )

    tracker = MagicMock()
    visualisation.log(tracker, artifact_path="transparency", use_subdirectory=True)

    assert tracker.log_artifacts.call_count == 1
    args, kwargs = tracker.log_artifacts.call_args
    assert isinstance(args[0], Path)
    assert args[0].name == run_dir.name
    assert kwargs["target_subdirectory"] == f"transparency/{run_dir.name}"


def test_explanation_visualise_merges_inputs_and_attributions_from_kwargs(
    tmp_path: Path,
) -> None:
    """Config/call-site may pass inputs/attributions without duplicating keyword args."""

    default_attr = torch.tensor([1.0])
    default_inp = torch.tensor([2.0])
    override_attr = torch.tensor([3.0])
    override_inp = torch.tensor([4.0])

    class _RecordingVisualiser(BaseVisualiser):
        def __init__(self) -> None:
            self.last: tuple[torch.Tensor, torch.Tensor | None, dict[str, Any]] | None = None

        def visualise(
            self,
            attributions: torch.Tensor,
            inputs: torch.Tensor | None = None,
            *,
            context: VisualisationContext | None = None,
            **kw: Any,
        ) -> Figure:
            del context
            self.last = (attributions, inputs, dict(kw))
            fig, _ax = plt.subplots(figsize=(1, 1))
            return fig

    run_dir = tmp_path / "exp"
    explanation = ExplanationResult(
        attributions=default_attr,
        inputs=default_inp,
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="a",
        semantics=_semantics(),
        visualisers=[
            ConfiguredVisualiser(
                visualiser=_RecordingVisualiser(),
                call_kwargs={
                    "inputs": override_inp,
                    "attributions": override_attr,
                    "title": "x",
                },
            )
        ],
    )
    explanation.write_artifacts()

    explanation.visualise()

    vis = explanation.visualisers[0].visualiser
    assert isinstance(vis, _RecordingVisualiser)
    assert vis.last is not None
    attr, inp, extra = vis.last
    assert torch.equal(attr, override_attr)
    assert inp is not None and torch.equal(inp, override_inp)
    assert extra == {"title": "x"}

    explanation2 = _make_explanation(tmp_path / "exp2")
    explanation2.write_artifacts()
    rec = _RecordingVisualiser()
    explanation2.visualisers = [ConfiguredVisualiser(visualiser=rec, call_kwargs={})]
    explanation2.visualise(inputs=override_inp)
    assert rec.last is not None
    _a, inp2, _e = rec.last
    assert inp2 is not None and torch.equal(inp2, override_inp)


def test_explanation_visualise_adds_generic_sample_name_title_when_opted_in(tmp_path: Path) -> None:
    class _RecordingVisualiser(BaseVisualiser):
        def __init__(self) -> None:
            self.last_kwargs: dict[str, Any] = {}

        def visualise(
            self,
            attributions: torch.Tensor,
            inputs: torch.Tensor | None = None,
            *,
            context: VisualisationContext | None = None,
            **kw: Any,
        ) -> Figure:
            del attributions, inputs, context
            self.last_kwargs = dict(kw)
            fig, _ax = plt.subplots(figsize=(1, 1))
            return fig

    run_dir = tmp_path / "exp_generic_title"
    rec = _RecordingVisualiser()
    explanation = ExplanationResult(
        attributions=torch.randn(2, 3, 4, 4),
        inputs=torch.randn(2, 3, 4, 4),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="a",
        semantics=_semantics(),
        visualisers=[
            ConfiguredVisualiser(
                visualiser=rec,
                call_kwargs={"show_sample_names": True},
            )
        ],
        kwargs={"sample_names": ["ISIC_1", "ISIC_2"]},
    )
    explanation.write_artifacts()

    [result] = explanation.visualise()

    assert rec.last_kwargs == {}
    assert result.figure.get_suptitle() == "ISIC_1 (+1)"


def test_explanation_visualise_uses_explainer_level_show_sample_names_default(
    tmp_path: Path,
) -> None:
    class _ContextRecordingVisualiser(BaseVisualiser):
        def __init__(self) -> None:
            self.last_show_sample_names: bool | None = None
            self.last_sample_names: list[str] = []

        def visualise(
            self,
            attributions: torch.Tensor,
            inputs: torch.Tensor | None = None,
            *,
            context: VisualisationContext | None = None,
            **kw: Any,
        ) -> Figure:
            del attributions, inputs, kw
            self.last_show_sample_names = context.show_sample_names if context is not None else None
            sample_names = context.sample_names if context is not None else None
            self.last_sample_names = [] if sample_names is None else list(sample_names)
            fig, _ax = plt.subplots(figsize=(1, 1))
            return fig

    run_dir = tmp_path / "exp_explainer_level_show_names"
    vis = _ContextRecordingVisualiser()
    explanation = ExplanationResult(
        attributions=torch.randn(2, 3, 4, 4),
        inputs=torch.randn(2, 3, 4, 4),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="a",
        semantics=_semantics(),
        visualisers=[ConfiguredVisualiser(visualiser=vis, call_kwargs={})],
        kwargs={
            "sample_names": ["ISIC_1", "ISIC_2"],
            "show_sample_names": True,
        },
    )
    explanation.write_artifacts()

    explanation.visualise()

    assert vis.last_show_sample_names is True
    assert vis.last_sample_names == ["ISIC_1", "ISIC_2"]


def test_explanation_visualise_trims_sample_names_for_shorter_batch(tmp_path: Path) -> None:
    class _SampleNameVisualiser(BaseVisualiser):
        def __init__(self) -> None:
            self.received_names: list[str] = []

        def visualise(
            self,
            attributions: torch.Tensor,
            inputs: torch.Tensor | None = None,
            *,
            context: VisualisationContext | None = None,
            **kw: Any,
        ) -> Figure:
            del attributions, inputs, kw
            sample_names = context.sample_names if context is not None else None
            show_sample_names = context.show_sample_names if context is not None else False
            self.received_names = [] if sample_names is None else list(sample_names)
            fig, _ax = plt.subplots(figsize=(1, 1))
            if show_sample_names and self.received_names:
                fig.suptitle(self.received_names[0])
            return fig

    run_dir = tmp_path / "exp_trim_names"
    vis = _SampleNameVisualiser()
    explanation = ExplanationResult(
        attributions=torch.randn(1, 3, 4, 4),
        inputs=torch.randn(1, 3, 4, 4),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="a",
        semantics=_semantics(),
        visualisers=[
            ConfiguredVisualiser(
                visualiser=vis,
                call_kwargs={"show_sample_names": True},
            )
        ],
        kwargs={"sample_names": ["ISIC_1", "ISIC_2", "ISIC_3"]},
    )
    explanation.write_artifacts()

    explanation.visualise()

    assert vis.received_names == ["ISIC_1"]


def test_report_visualisation_resets_visualiser_sample_index_for_sliced_batch(
    tmp_path: Path,
) -> None:
    class _SampleIndexVisualiser(BaseVisualiser):
        def __init__(self) -> None:
            self.sample_index = 2
            self.seen_attribution: torch.Tensor | None = None

        def visualise(
            self,
            attributions: torch.Tensor,
            inputs: torch.Tensor | None = None,
            *,
            context: VisualisationContext | None = None,
            **kw: Any,
        ) -> Figure:
            del inputs, context, kw
            self.seen_attribution = attributions[self.sample_index].clone()
            fig, _ax = plt.subplots(figsize=(1, 1))
            return fig

    run_dir = tmp_path / "exp_report_sample_index"
    vis = _SampleIndexVisualiser()
    attributions = torch.tensor([[1.0], [2.0], [3.0]])
    explanation = ExplanationResult(
        attributions=attributions,
        inputs=torch.zeros(3, 1),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="a",
        semantics=_semantics(),
        visualisers=[ConfiguredVisualiser(visualiser=vis)],
    )
    explanation.write_artifacts()

    rendered = explanation.render_visualisations_for_scope(
        scope="local",
        sample_index=1,
    )

    assert len(rendered) == 1
    assert rendered[0].visualiser_name == "_SampleIndexVisualiser_0"
    assert rendered[0].scope == ExplanationScope.LOCAL
    assert rendered[0].output_path == Path("_SampleIndexVisualiser_0.png")
    assert vis.sample_index == 2
    assert vis.seen_attribution is not None
    assert torch.equal(vis.seen_attribution, attributions[1])


def test_render_visualisation_for_scope_targets_one_visualiser_and_forwards_kwargs(
    tmp_path: Path,
) -> None:
    class _KwargVisualiser(BaseVisualiser):
        def __init__(self) -> None:
            self.received_kwargs: dict[str, Any] = {}
            self.received_names: list[str] = []
            self.seen_attribution: torch.Tensor | None = None

        def visualise(
            self,
            attributions: torch.Tensor,
            inputs: torch.Tensor | None = None,
            *,
            context: VisualisationContext | None = None,
            **kw: Any,
        ) -> Figure:
            del inputs
            self.received_kwargs = dict(kw)
            self.received_names = [] if context is None else list(context.sample_names or [])
            self.seen_attribution = attributions.clone()
            fig, _ax = plt.subplots(figsize=(1, 1))
            return fig

    first = _KwargVisualiser()
    second = _KwargVisualiser()
    attributions = torch.tensor([[1.0], [2.0], [3.0]])
    explanation = ExplanationResult(
        attributions=attributions,
        inputs=torch.zeros(3, 1),
        run_dir=tmp_path / "exp_single_visualiser",
        experiment_name="e",
        explainer_target="t",
        algorithm="a",
        semantics=_semantics(),
        kwargs={"sample_names": ["a", "b", "c"], "show_sample_names": True},
        visualisers=[
            ConfiguredVisualiser(visualiser=first, call_kwargs={"alpha": 0.1}),
            ConfiguredVisualiser(visualiser=second, call_kwargs={"alpha": 0.2}),
        ],
    )

    rendered = explanation.render_visualisation_for_scope(
        1,
        scope="local",
        sample_index=2,
        alpha=0.9,
        include_original_input=False,
    )

    assert rendered is not None
    assert rendered.visualiser_name == "_KwargVisualiser_1"
    assert first.received_kwargs == {}
    assert second.received_kwargs == {"alpha": 0.9, "include_original_input": False}
    assert second.received_names == ["c"]
    assert second.seen_attribution is not None
    assert torch.equal(second.seen_attribution, attributions[2:3])


def test_render_visualisation_for_scope_returns_none_for_scope_mismatch(tmp_path: Path) -> None:
    class _CohortVisualiser(BaseVisualiser):
        produces_scope = ExplanationScope.COHORT

        def visualise(
            self,
            attributions: torch.Tensor,
            inputs: torch.Tensor | None = None,
            *,
            context: VisualisationContext | None = None,
            **kw: Any,
        ) -> Figure:
            del attributions, inputs, context, kw
            fig, _ax = plt.subplots(figsize=(1, 1))
            return fig

    explanation = ExplanationResult(
        attributions=torch.zeros(1, 1),
        inputs=torch.zeros(1, 1),
        run_dir=tmp_path / "exp_scope_mismatch",
        experiment_name="e",
        explainer_target="t",
        algorithm="a",
        semantics=_semantics(),
        visualisers=[ConfiguredVisualiser(visualiser=_CohortVisualiser())],
    )

    assert explanation.render_visualisation_for_scope(0, scope="local") is None


def test_explanation_visualise_forwards_algorithm_when_supported(tmp_path: Path) -> None:
    class _AlgorithmVisualiser(BaseVisualiser):
        def __init__(self) -> None:
            self.last_algorithm: str | None = None
            self.last_kwargs: dict[str, Any] = {}

        def visualise(
            self,
            attributions: torch.Tensor,
            inputs: torch.Tensor | None = None,
            *,
            context: VisualisationContext | None = None,
            **kw: Any,
        ) -> Figure:
            del attributions, inputs
            self.last_algorithm = context.algorithm if context is not None else None
            self.last_kwargs = dict(kw)
            fig, _ax = plt.subplots(figsize=(1, 1))
            return fig

    run_dir = tmp_path / "exp_algorithm_forward"
    vis = _AlgorithmVisualiser()
    explanation = ExplanationResult(
        attributions=torch.randn(1, 3, 4, 4),
        inputs=torch.randn(1, 3, 4, 4),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="IntegratedGradients",
        semantics=_semantics(),
        visualisers=[ConfiguredVisualiser(visualiser=vis)],
    )
    explanation.write_artifacts()

    explanation.visualise()

    assert vis.last_algorithm == "IntegratedGradients"
    assert vis.last_kwargs == {}


def test_explanation_visualise_sets_shap_image_default_title_from_algorithm(tmp_path: Path) -> None:
    run_dir = tmp_path / "exp_shap_title"
    explanation = ExplanationResult(
        attributions=torch.randn(1, 3, 8, 8),
        inputs=torch.rand(1, 3, 8, 8),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="GradientExplainer",
        semantics=_semantics(
            method_families=frozenset({MethodFamily.SHAPLEY, MethodFamily.GRADIENT})
        ),
        visualisers=[ConfiguredVisualiser(visualiser=ShapImageVisualiser(show_colorbar=False))],
    )
    explanation.write_artifacts()

    [result] = explanation.visualise()

    titles = [ax.get_title() for ax in result.figure.axes if ax.get_title()]
    assert titles == ["Original Image", "GradientExplainer (SHAP)"]


def test_explanation_visualise_preserves_shap_constructor_title(tmp_path: Path) -> None:
    run_dir = tmp_path / "exp_shap_constructor_title"
    explanation = ExplanationResult(
        attributions=torch.randn(1, 3, 8, 8),
        inputs=torch.rand(1, 3, 8, 8),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="GradientExplainer",
        semantics=_semantics(
            method_families=frozenset({MethodFamily.SHAPLEY, MethodFamily.GRADIENT})
        ),
        visualisers=[
            ConfiguredVisualiser(
                visualiser=ShapImageVisualiser(title="Configured SHAP", show_colorbar=False)
            )
        ],
    )
    explanation.write_artifacts()

    [result] = explanation.visualise()

    titles = [ax.get_title() for ax in result.figure.axes if ax.get_title()]
    assert titles == ["Original Image", "Configured SHAP"]


def test_explanation_visualise_preserves_explicit_shap_image_title(tmp_path: Path) -> None:
    run_dir = tmp_path / "exp_shap_explicit_title"
    explanation = ExplanationResult(
        attributions=torch.randn(1, 3, 8, 8),
        inputs=torch.rand(1, 3, 8, 8),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="GradientExplainer",
        semantics=_semantics(
            method_families=frozenset({MethodFamily.SHAPLEY, MethodFamily.GRADIENT})
        ),
        visualisers=[
            ConfiguredVisualiser(
                visualiser=ShapImageVisualiser(title="Configured SHAP", show_colorbar=False),
            )
        ],
    )
    explanation.write_artifacts()

    [result] = explanation.visualise(title="Runtime SHAP")

    titles = [ax.get_title() for ax in result.figure.axes if ax.get_title()]
    assert titles == ["Original Image", "Runtime SHAP"]


def test_explanation_visualise_forwards_algorithm_to_shap_subclasses(tmp_path: Path) -> None:
    class _SubclassedShapImageVisualiser(ShapImageVisualiser):
        pass

    run_dir = tmp_path / "exp_shap_subclass_title"
    explanation = ExplanationResult(
        attributions=torch.randn(1, 3, 8, 8),
        inputs=torch.rand(1, 3, 8, 8),
        run_dir=run_dir,
        experiment_name="e",
        explainer_target="t",
        algorithm="DeepExplainer",
        semantics=_semantics(
            method_families=frozenset({MethodFamily.SHAPLEY, MethodFamily.GRADIENT})
        ),
        visualisers=[
            ConfiguredVisualiser(visualiser=_SubclassedShapImageVisualiser(show_colorbar=False))
        ],
    )
    explanation.write_artifacts()

    [result] = explanation.visualise()

    titles = [ax.get_title() for ax in result.figure.axes if ax.get_title()]
    assert titles == ["Original Image", "DeepExplainer (SHAP)"]
