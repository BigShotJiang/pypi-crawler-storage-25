from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ModelConfig:
    # Path to a local .pt / .pth / .onnx file, or a built-in name (e.g. "resnet50").
    source: str | None = None
    # Architecture spec used when ``source`` points at a state-dict (``.pt`` /
    # ``.pth`` containing a ``dict``). Must be the name of a torchvision model
    # builder callable that accepts ``weights=`` and ``num_classes=`` kwargs
    # (e.g. ``"resnet18"``, ``"vit_b_16"``). Other ``torchvision.models``
    # attributes (constants, helpers) are not valid here.
    arch: str | None = None
    # Number of output classes used to instantiate the architecture before
    # ``load_state_dict``. Required together with ``arch`` for state-dict loading.
    num_classes: int | None = None
    # Whether to construct the architecture with ImageNet pretrained weights
    # before loading the state-dict. Usually ``False`` since weights come from
    # the state-dict itself.
    pretrained: bool = False
    # Opt-in to loading checkpoints that require unsafe pickle deserialisation
    # (i.e. pickled ``nn.Module`` files that fail ``weights_only=True``). This
    # executes arbitrary code embedded in the file and MUST only be enabled for
    # checkpoints from a fully trusted source. Default refuses such files and
    # asks the user to re-save as a state-dict or TorchScript archive.
    allow_unsafe_pickle: bool = False


@dataclass
class LabelsConfig:
    # Optional path to a labels file (currently CSV/TSV/Parquet).
    source: str | None = None
    # Optional sample-id column for filename alignment (e.g. "image").
    id_column: str | None = None
    # Optional class-label column; when omitted, one-hot numeric columns are used via argmax.
    column: str | None = None
    # Optional parsing strategy for labels: "index", "one_hot", or "argmax".
    encoding: str | None = None
    # Strategy for matching label-file ids to discovered sample files. One of:
    #   "auto"          — pick "relative_path" if any id contains "/" or "\\"; else "stem".
    #   "relative_path" — ids are resolved as posix-style paths relative to ``data.source``
    #                     (supports nested ImageFolder layouts with colliding stems).
    #   "stem"          — legacy flat-dir behaviour: match by ``Path(id).stem`` only.
    id_strategy: str = "auto"


@dataclass
class DataConfig:
    name: str = "isic2018"
    description: str | None = None
    # Path to a local dir, or a named sample set (e.g. "imagenet_samples")
    source: str | None = None
    # Optional model-forward batch size for predictions/metrics. None uses the pipeline default.
    forward_batch_size: int | None = None
    # Optional input-modality metadata (``kind``, ``feature_names``, ``layout``, ...).
    # Forwarded to ``infer_input_spec`` so semantics and visualisers see the correct
    # modality for non-image data such as ACAS Xu's 5-feature tabular vector.
    input_metadata: dict[str, Any] | None = None
    labels: LabelsConfig = field(default_factory=LabelsConfig)


@dataclass
class TransparencyConfig:
    # Hydra _target_: points to an ExplainerAdapter
    # (e.g. AttributionOnlyExplainer or FullExplainer subclass)
    # Overridden by the transparency config-group YAML (transparency=captum / shap).
    _target_: str = "CaptumExplainer"
    algorithm: str = "IntegratedGradients"
    # Constructor kwargs for the explainer / underlying library method (e.g. Captum
    # ``IntegratedGradients(model, **kwargs)``, SHAP ``GradientExplainer(model, data, **kwargs)``).
    constructor: dict[str, Any] = field(default_factory=dict)
    # Per-call kwargs forwarded verbatim to the underlying library
    # (Captum ``.attribute()``, SHAP ``.shap_values()``, etc.).
    # Any value that is a dict with a ``source`` key is treated as a data-source reference
    # and loaded as a tensor at runtime.  Example for SHAP background data::
    #
    #   call:
    #     background_data:
    #       source: "imagenet_samples"
    #       n_samples: 50
    call: dict[str, Any] = field(default_factory=dict)
    # RAITAP-owned runtime options such as batch_size, progress bars, and
    # sample-name metadata. These keys are not forwarded to the explainability library.
    raitap: dict[str, Any] = field(default_factory=dict)
    # Each entry needs at least ``_target_``; ``constructor`` / ``call`` are optional
    # (same split as explainer). Default is minimal: Captum explainer + image visualiser.
    visualisers: list[Any] = field(default_factory=lambda: [{"_target_": "CaptumImageVisualiser"}])


@dataclass
class RobustnessConfig:
    # Hydra _target_: points to a BaseAssessor subclass
    # (e.g. EmpiricalAttackAssessor or FormalVerificationAssessor implementation).
    # Overridden by the robustness config-group YAML
    # (robustness=torchattacks_pgd / foolbox_lin_pgd).
    _target_: str = "TorchattacksAssessor"
    algorithm: str = "PGD"
    # Constructor kwargs forwarded to the assessor's ``__init__``. For torchattacks
    # adapters this is where attack hyperparameters live (eps, alpha, steps), since
    # torchattacks consumes them at attack-instance construction.
    constructor: dict[str, Any] = field(default_factory=dict)
    # Per-call kwargs forwarded verbatim to the assessor at ``assess()`` time. For
    # foolbox adapters this is where the runtime budget (eps / epsilons) lives.
    # Any value that is a dict with a ``source`` key is treated as a data-source
    # reference and loaded as a tensor at runtime.
    call: dict[str, Any] = field(default_factory=dict)
    # RAITAP-owned runtime options such as batch_size, progress bars, and
    # sample-name metadata. Not forwarded to the underlying library.
    raitap: dict[str, Any] = field(default_factory=dict)
    # Each entry needs at least ``_target_``; ``constructor`` / ``call`` are optional.
    # Default is the empirical image-pair visualiser.
    visualisers: list[Any] = field(default_factory=lambda: [{"_target_": "ImagePairVisualiser"}])


@dataclass
class MetricsConfig:
    _target_: str = "ClassificationMetrics"
    task: str = "multiclass"
    num_classes: int | None = None


@dataclass
class TrackingConfig:
    _target_: str = "MLFlowTracker"
    output_forwarding_url: str | None = None
    backend_store_uri: str | None = None
    default_artifact_root: str | None = None
    log_model: bool = False
    open_when_done: bool = True


@dataclass
class ReportingConfig:
    """Configuration for report generation."""

    _target_: str = "HTMLReporter"
    filename: str = "report"
    sample_selection: list[int | str] | None = None
    include_config: bool = True
    include_metadata: bool = True
    multirun_report: bool = True
    show_original_per_explainer: bool = False
    show_redundant_robustness_panels: bool = False
    call: dict[str, Any] = field(default_factory=dict)


@dataclass
class AppConfig:
    model: ModelConfig = field(default_factory=ModelConfig)
    data: DataConfig = field(default_factory=DataConfig)
    transparency: dict[str, Any] = field(default_factory=lambda: {"default": TransparencyConfig()})
    robustness: dict[str, Any] = field(default_factory=dict)
    metrics: MetricsConfig = field(default_factory=MetricsConfig)
    tracking: TrackingConfig = field(default_factory=TrackingConfig)
    reporting: ReportingConfig | None = None  # Optional, null by default
    hardware: str = "gpu"
    experiment_name: str = "Experiment"
