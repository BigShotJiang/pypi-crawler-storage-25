import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any
import dramatiq
from loguru import logger
from turbo_agent_core.schema.jobs import TaskSpec, AgentPayload, InlineExecutorConfig
from turbo_agent_core.schema.enums import RunType, TaskAction
from turbo_agent_core.schema.agents import Agent, Character
from turbo_agent_core.schema.states import Conversation, Message
from turbo_agent_core.schema.events import (
    ExecutorMetadata,
    RunLifecycleCreatedEvent,
    RunLifecycleCreatedPayload,
    RunLifecycleFailedEvent,
    RunLifecycleFailedPayload,
    UserInfo,
)
from turbo_agent_core.utils.identity import build_ephemeral_executor_id, build_executor_id, parse_run_type
from turbo_agent_job.dramatiq_broker import broker as dramatiq_broker
from turbo_agent_job.settings import settings
from turbo_agent_runtime.executors.character import CharacterRuntime
from turbo_agent_runtime.executors.agent import AgentRuntime
from turbo_agent_job.customization import get_worker_customizer

import redis.asyncio as redis
from turbo_agent_store.stream import RedisRuntimeMonitor, monitor_object, set_monitor_context


# Initialize Runtime Monitor
# Remove module-level init which causes event loop issues
# init_runtime_monitor(settings.REDIS_RESULT_URL)

# Force register queues to the broker so the worker listens to them
# even if no actor is explicitly bound to them via decorator.
# This allows dynamic routing to these queues while using a single 'execute_task' actor.
# Use underscores instead of dots because Dramatiq validates queue names.
KNOWN_QUEUES = [
    "ta_job_online_external",
    "ta_job_online_internal",
    "ta_job_offline_external",
    "ta_job_offline_internal"
]
for q in KNOWN_QUEUES:
    dramatiq_broker.queues.add(q)


@dramatiq.actor(broker=dramatiq_broker)
def execute_task(task_spec_dict: dict):
    """
    执行任务（基于 TaskSpec）
    """
    try:
        # 1. 反序列化 TaskSpec
        task_spec = _deserialize_task_spec(task_spec_dict)
        logger.info(
            "Worker 接收到任务，完整 TaskSpec 如下:\n{}",
            task_spec.model_dump_json(indent=2, exclude_none=True),
        )
        
        # 2. 异步执行任务
        asyncio.run(_execute_task_async(task_spec))
        
    except Exception as e:
        logger.exception("Worker 处理任务时发生异常: {}", e) # Remove f-string with {e} to avoid loguru formatting error with dicts
        # Re-raise to ensure Dramatiq handles retries/failures
        raise


def _deserialize_task_spec(task_spec_dict: dict[str, Any]) -> TaskSpec:
    """显式反序列化 TaskSpec。

    关键原因：
    - worker 运行期可能仍持有旧版 TaskSpec schema；
    - 旧 schema 会把 executor 误按 Agent/Character/Tool 联合类型校验；
    - 这里先对主体做标准校验，再单独按 InlineExecutorConfig 解析 executor，避免内联执行器被误判。
    """
    normalized = dict(task_spec_dict)
    raw_executor = normalized.pop("executor", None)

    task_spec = TaskSpec.model_validate({**normalized, "executor": None})

    if raw_executor is not None:
        executor = raw_executor if isinstance(raw_executor, InlineExecutorConfig) else InlineExecutorConfig.model_validate(raw_executor)
        object.__setattr__(task_spec, "executor", executor)

    return task_spec


async def _execute_task_async(task_spec: TaskSpec):
    """
    异步执行任务逻辑
    """
    customizer = get_worker_customizer()
    conversation: Conversation | None = None
    monitor: RedisRuntimeMonitor | None = None
    # Create and set monitor for this execution context (loop)
    try:
         redis_client = redis.from_url(settings.REDIS_RESULT_URL, decode_responses=False)
         monitor = RedisRuntimeMonitor(redis_client)
         monitor.start()
         set_monitor_context(monitor)
    except Exception as e:
         logger.error(f"Failed to initialize monitor: {e}")
         return

    try:
        # 1. 解析操作类型
        if task_spec.action != TaskAction.START:
            logger.warning(f"目前 Worker 仅部分支持 START 操作，收到: {task_spec.action}")
            # TODO: 支持 RETRY/RESUME/INTERRUPT
            return
        
        # 2. 准备输入 (Conversation)
        payload = task_spec.payload
        if not isinstance(payload, AgentPayload):
            logger.error(f"Character 需要 AgentPayload，收到: {type(payload)}")
            return

        fallback_conversation = _build_fallback_conversation(
            payload=payload,
            task_id=task_spec.task_id,
        )

        conversation = await customizer.prepare_conversation(task_spec, fallback_conversation)
        executor_schema = await customizer.prepare_executor(task_spec, conversation)
        if not isinstance(executor_schema, (Character, Agent)):
            logger.error(f"目前仅支持 Character/Agent 类型的执行器，收到: {type(executor_schema)}")
            return

        if executor_schema.tools is None:
            executor_schema.tools = []

        # 诊断日志：打印 prepare_executor 后的完整执行器数据
        logger.info(
            "Worker 执行器准备完成，完整数据如下:\n{}",
            executor_schema.model_dump_json(indent=2, exclude_none=True),
        )

        if isinstance(executor_schema, Character):
            logger.info(f"正在启动 Character: {executor_schema.name} (ID: {executor_schema.id})")
            runtime = CharacterRuntime(**executor_schema.model_dump())
        else:
            logger.info(f"正在启动 Agent: {executor_schema.name} (ID: {executor_schema.id})")
            runtime = AgentRuntime(**executor_schema.model_dump())

        prepared_runtime = await customizer.prepare_runtime(task_spec, conversation, runtime)
        conversation = prepared_runtime.conversation
        runtime_kwargs = dict(prepared_runtime.runtime_kwargs)
        trace_id = task_spec.trace_id or task_spec.task_id or str(uuid.uuid4())

        await customizer.mark_conversation_running(task_spec, conversation)

        if task_spec.user:
            runtime_kwargs.setdefault("user_info", task_spec.user.model_dump(exclude_none=True))
            runtime_kwargs.setdefault("user_id", task_spec.user.id)
            runtime_kwargs.setdefault("username", task_spec.user.username or task_spec.user.firstname or task_spec.user.id)

        logger.info(f"开始流式执行 (Conversation ID: {conversation.id}, Trace ID: {trace_id})")

        if task_spec.user:
             logger.info(f"Worker 绑定用户信息: {task_spec.user.id} role={task_spec.user.role}")

        # 4.1 绑定监控器并设置 Trace ID
        monitor_object(runtime, user_info=task_spec.user, override_trace_id=trace_id)
        
        # 4.2 执行
        # 这里的事件将自动通过 monitor_object 注入的逻辑发送到 Redis Stream
        async for _ in runtime.a_stream(input=conversation, leaf_message_id=payload.leaf_id, **runtime_kwargs):
            pass # 仅驱动生成器运行

        await customizer.mark_conversation_finished(task_spec, conversation)
        logger.info(f"任务 {task_spec.task_id} 执行完成")

    except Exception as e:
        if conversation is not None:
            try:
                await customizer.mark_conversation_failed(task_spec, conversation, e)
            except Exception as status_err:
                logger.error("Worker 更新会话 error 状态失败: {}", status_err)
        logger.exception(
            "执行任务时发生未捕获异常: task_id={}, trace_id={}, conversation_id={}, error={}",
            task_spec.task_id,
            task_spec.trace_id,
            getattr(task_spec.payload, "conversation_id", None),
            e,
        )
        await _emit_failure_events(monitor, task_spec, e)
        raise
    finally:
        if monitor is not None:
            await monitor.close()


def _build_fallback_conversation(
    payload: AgentPayload,
    task_id: str,
) -> Conversation:
    """基于 payload 构造最小可运行的 Conversation。"""
    messages = list(payload.messages or [])
    current_input = payload.current_input

    if isinstance(current_input, dict):
        if "id" not in current_input:
            current_input["id"] = str(uuid.uuid4())
        try:
            msg = Message.model_validate(current_input)
        except Exception:
            msg = Message(id=str(uuid.uuid4()), role="user", content=str(current_input))
        messages.append(msg)
    elif isinstance(current_input, Message):
        messages.append(current_input)

    return Conversation(
        id=payload.conversation_id or task_id,
        messages=messages,
    )


def _build_executor_event_context(task_spec: TaskSpec) -> tuple[str, Any, ExecutorMetadata]:
    """基于 TaskSpec 中的执行器描述构造错误事件所需的元数据。"""
    executor = task_spec.executor
    executor_id = task_spec.executor_id

    if executor_id:
        resolved_executor_id = executor_id
    elif isinstance(executor, InlineExecutorConfig):
        resolved_executor_id = build_ephemeral_executor_id(executor, executor.run_type)
    else:
        resolved_executor_id = f"unknown:{task_spec.task_id}"

    executor_type = _normalize_executor_type(getattr(executor, "run_type", None))
    metadata = ExecutorMetadata(
        id=getattr(executor, "id", None) or resolved_executor_id,
        name=getattr(executor, "name", None) or getattr(executor, "name_id", None) or resolved_executor_id,
        belong_to_project_path=getattr(executor, "belong_to_project_path", None),
        name_id=getattr(executor, "name_id", None),
        description=getattr(executor, "description", None),
        avatar_uri=getattr(executor, "avatar_uri", None),
        run_type=(executor_type.value if hasattr(executor_type, "value") else executor_type),
        version_id=getattr(executor, "version_id", None),
        version=getattr(executor, "version_tag", None) or getattr(executor, "version", None),
    )
    return resolved_executor_id, executor_type, metadata


def _normalize_executor_type(raw_executor_type: Any) -> RunType | None:
    if isinstance(raw_executor_type, RunType):
        return raw_executor_type
    if raw_executor_type is None:
        return None
    return parse_run_type(str(raw_executor_type))


def _resolve_failure_executor_type(raw_executor_type: Any):
    normalized = _normalize_executor_type(raw_executor_type)
    if normalized is not None:
        return normalized
    return parse_run_type("None")


def _build_failure_events(task_spec: TaskSpec, error: Exception) -> tuple[RunLifecycleCreatedEvent, RunLifecycleFailedEvent]:
    trace_id = task_spec.trace_id or task_spec.task_id or str(uuid.uuid4())
    run_id = str(uuid.uuid4())
    ts_ms = datetime.now(timezone.utc).timestamp() * 1000

    executor_id, raw_executor_type, executor_metadata = _build_executor_event_context(task_spec)
    executor_type = _resolve_failure_executor_type(raw_executor_type)
    user_id = task_spec.user.id if task_spec.user else "unknown"
    username = (task_spec.user.username or task_spec.user.firstname or task_spec.user.id) if task_spec.user else "unknown"

    created_event = RunLifecycleCreatedEvent(
        trace_id=trace_id,
        trace_path=[],
        run_id=run_id,
        run_path=[run_id],
        executor_id=executor_id,
        executor_type=executor_type,
        executor_path=[executor_id],
        executor_metadata=executor_metadata,
        user_metadata=UserInfo(id=str(user_id), username=str(username)),
        timestamp=ts_ms,
        payload=RunLifecycleCreatedPayload(input_data=None),
    )
    failed_event = RunLifecycleFailedEvent(
        trace_id=trace_id,
        trace_path=[],
        run_id=run_id,
        run_path=[run_id],
        executor_id=executor_id,
        executor_type=executor_type,
        executor_path=[executor_id],
        timestamp=ts_ms + 1,
        payload=RunLifecycleFailedPayload(
            error={"code": type(error).__name__, "message": str(error)},
        ),
    )
    return created_event, failed_event


async def _emit_failure_events(monitor: RedisRuntimeMonitor | None, task_spec: TaskSpec, error: Exception) -> None:
    if monitor is None:
        logger.error(
            "无法发布错误事件流：monitor 未初始化，task_id={}, trace_id={}, error_type={}, error={}",
            task_spec.task_id,
            task_spec.trace_id,
            type(error).__name__,
            error,
        )
        return

    try:
        created_event, failed_event = _build_failure_events(task_spec, error)
        monitor.write(created_event)
        monitor.write(failed_event)
        logger.info(
            "已发布错误事件流: trace_id={}, run_id={}, error_type={}, error={}",
            created_event.trace_id,
            created_event.run_id,
            type(error).__name__,
            error,
        )
    except Exception as emit_err:
        logger.error(
            "发布错误事件流失败: task_id={}, trace_id={}, error_type={}, emit_error={}",
            task_spec.task_id,
            task_spec.trace_id,
            type(error).__name__,
            emit_err,
        )
