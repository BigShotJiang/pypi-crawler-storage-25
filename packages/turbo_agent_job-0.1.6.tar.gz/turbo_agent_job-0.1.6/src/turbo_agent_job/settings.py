import os
from pathlib import Path
from uuid import uuid4
from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# 仅加载“运行命令所在目录”的 .env（与 store 模块策略一致）
_cwd_env_path = Path(os.getcwd()) / ".env"
if _cwd_env_path.exists():
    load_dotenv(dotenv_path=_cwd_env_path, override=True)


class Settings(BaseSettings):
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_CACHE_URL: str = "redis://localhost:6379/1"
    REDIS_RESULT_URL: str = "redis://localhost:6379/2"
    LOGURU_LEVEL: str = "INFO"
    TA_STORE_CONSUMER: str | None = Field(default=None)

    # 不再让 pydantic 自动读固定路径 env_file，完全依赖上方 cwd/.env + 进程环境变量
    model_config = SettingsConfigDict(
        env_file=None,
        extra="ignore",
    )

    def get_store_consumer_name(self) -> str:
        return self.TA_STORE_CONSUMER or f"consumer-{uuid4().hex[:8]}"

settings = Settings()
