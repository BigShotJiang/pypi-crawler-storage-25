#!/usr/bin/env python3

"""
Task Tracker CLI
Usage:
  task-cli add "Buy groceries"
  task-cli update 1 "Buy groceries and cook dinner"
  task-cli delete 1
  task-cli mark-in-progress 1
  task-cli mark-done 1
  task-cli list
  task-cli list done
  task-cli list todo
  task-cli list in-progress
"""

import argparse
import sys
import json
import os
from datetime import datetime

TASKS_FILE = "tasks.json"


def load_tasks() -> list:
    if not os.path.exists(TASKS_FILE):
        return []
    with open(TASKS_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []


def save_tasks(tasks: list) -> None:
    with open(TASKS_FILE, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2, ensure_ascii=False)


def next_id(tasks: list) -> int:
    return max((t["id"] for t in tasks), default=0) + 1


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def find_task(tasks, id: int):
    index_task = -1
    for i in range(0, len(tasks)):
        if tasks[i]["id"] == id:
            index_task = i
    if index_task == -1:
        print(f"Error: task with ID `{id}` not found")
        sys.exit(1)
    return index_task

# ---- COMMANDS ----


def cmd_list(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    if args.status:
        tasks = [t for t in tasks if t["status"] == args.status]

    for task in tasks:
        print(f"""Task {task["id"]}: {task["description"]}
    status: {task["status"]}
    createdAt: {task["createdAt"]}
    updateAt: {task["updatedAt"]}
""")


def cmd_add(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    task = {
        "id": next_id(tasks),
        "description": args.description,
        "status": "todo",
        "createdAt": now(),
        "updatedAt": now(),
    }
    tasks.append(task)
    save_tasks(tasks)
    print(f"Task added successfully (ID: {task['id']})")


def cmd_update(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    # find
    index_update_task = find_task(tasks, args.id)
    # update
    tasks[index_update_task]["description"] = args.description
    tasks[index_update_task]["updatedAt"] = now()
    # save
    save_tasks(tasks)
    updated_task = tasks[index_update_task]
    print("Updated successfully")
    print(f"""Task {updated_task["id"]}: {updated_task["description"]}
    status: {updated_task["status"]}
    createdAt: {updated_task["createdAt"]}
    updateAt: {updated_task["updatedAt"]}""")


def cmd_delete(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    index_delete_task = find_task(tasks, args.id)
    delete_task = tasks[index_delete_task]

    print("Deleting")
    print(f"""Task {delete_task["id"]}: {delete_task["description"]}
    status: {delete_task["status"]}
    createdAt: {delete_task["createdAt"]}
    updateAt: {delete_task["updatedAt"]}""")

    del tasks[index_delete_task]
    save_tasks(tasks)
    print("Deleted successfully")

def cmd_mark_in_progress(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    index_update_task = find_task(tasks, args.id)
    update_task = tasks[index_update_task]
    print("Mark in progress")
    print(f"""Task {update_task["id"]}: {update_task["description"]}
    status: {update_task["status"]} -> in-progress
    createdAt: {update_task["createdAt"]}
    updateAt: {update_task["updatedAt"]}""")

    tasks[index_update_task]["status"] = "in-progress"
    save_tasks(tasks)
    print("Mark-in-progress successfully")

def cmd_mark_done(args: argparse.Namespace) -> None:
    tasks = load_tasks()
    index_update_task = find_task(tasks, args.id)
    update_task = tasks[index_update_task]
    print("Mark in progress")
    print(f"""Task {update_task["id"]}: {update_task["description"]}
    status: {update_task["status"]} -> done
    createdAt: {update_task["createdAt"]}
    updateAt: {update_task["updatedAt"]}""")

    tasks[index_update_task]["status"] = "done"
    save_tasks(tasks)
    print("Mark-in-progress successfully")


def main():
    parser = argparse.ArgumentParser(
        prog="task-cli", description="A simple task tracker CLI"
    )

    subparser = parser.add_subparsers(dest="command")
    subparser.required = True

    # task-cli add <task-desc>
    add_sub_parser = subparser.add_parser("add", help="Add a new task")
    add_sub_parser.add_argument("description", help="Task description")
    add_sub_parser.set_defaults(func=cmd_add)

    # task-cli list <done, todo, in-progress>
    list_sub_parser = subparser.add_parser("list", help="List tasks")
    list_sub_parser.add_argument(
        "status",
        nargs="?",  # không bắt buộc
        choices=["done", "todo", "in-progress"],
        help="Filter by status",
    )
    list_sub_parser.set_defaults(func=cmd_list)

    # task-cli update <task-id> <task-desc>
    update_sub_parser = subparser.add_parser("update", help="Update a task")
    update_sub_parser.add_argument("id", help="Task ID", type=int)
    update_sub_parser.add_argument("description", help="New description")
    update_sub_parser.set_defaults(func=cmd_update)

    # task-cli delete <task-id>
    delete_sub_parser = subparser.add_parser("delete", help="Delete a task")
    delete_sub_parser.add_argument("id", help="Task ID", type=int)
    delete_sub_parser.set_defaults(func=cmd_delete)

    # task-cli mark-in-progress <task-id>
    mark_in_progress_parser = subparser.add_parser("mark-in-progress", help="Mark task in-progress")
    mark_in_progress_parser.add_argument("id", help="Task ID", type=int)
    mark_in_progress_parser.set_defaults(func=cmd_mark_in_progress)

    # task-cli mark-done <task-id>
    mark_done_parser = subparser.add_parser("mark-done", help="Mark task done")
    mark_done_parser.add_argument("id", help="Task ID", type=int)
    mark_done_parser.set_defaults(func=cmd_mark_done)

    # parse arguments
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
