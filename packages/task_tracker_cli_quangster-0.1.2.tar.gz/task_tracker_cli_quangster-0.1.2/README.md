# Task Tracker CLI

A small command-line task tracker for managing local tasks from the terminal.

## Features

- Add new tasks with an auto-incrementing ID.
- List all tasks.
- Filter tasks by status: `todo`, `in-progress`, or `done`.
- Update an existing task description.
- Mark a task as in progress.
- Mark a task as done.
- Delete a task by ID.
- Store task data locally in a `tasks.json` file in the current working directory.

## Installation

```bash
pip install task-tracker-cli-quangster
```

Or with uv:

```bash
uv tool install task-tracker-cli-quangster
```

## Usage

Add a task:

```bash
task-cli add "Buy groceries"
```

List tasks:

```bash
task-cli list
```

Filter tasks by status:

```bash
task-cli list todo
task-cli list in-progress
task-cli list done
```

Update a task:

```bash
task-cli update 1 "Buy groceries and cook dinner"
```

Change task status:

```bash
task-cli mark-in-progress 1
task-cli mark-done 1
```

Delete a task:

```bash
task-cli delete 1
```

## Data Storage

Tasks are saved in `tasks.json` in the directory where you run `task-cli`.
