"""Merge tools.

Provides tools for merging revisions and managing merge conflicts.
"""

from mcp.types import TextContent

from hg_mcp.decorators import handle_repo_errors, json_tool
from hg_mcp.helpers import run_hg_command, sanitize_input, validate_repo_path
from hg_mcp.server import mcp


@mcp.tool()
@handle_repo_errors
async def hg_merge(repo_path: str = ".", revision: str = "") -> str:
    """Merge another revision into the current working directory.

    Equivalent to 'git merge'.

    **Note:** Mercurial requires explicit merges; no fast-forward by default.
    """
    path = validate_repo_path(repo_path)
    args = ["merge"]
    if revision:
        try:
            safe_revision = sanitize_input(revision, max_length=200)
        except ValueError as e:
            return f"Error: Invalid revision - {e}"
        args.append(safe_revision)
    return await run_hg_command(args, cwd=path)


@mcp.tool()
@handle_repo_errors
@json_tool
async def hg_resolve(repo_path: str = ".") -> list[TextContent]:
    """List and manage merge conflicts.

    Equivalent to 'git status' during a merge.
    """
    path = validate_repo_path(repo_path)
    return await run_hg_command(["resolve", "--list"], cwd=path)  # type: ignore[return-value]
