import argparse
import os
import pickle
import sys
from pathlib import Path

import numpy as np
from prettyPlot.plotting import plt, pretty_labels

from bird.utilities.ofio import *

from .label_plot import label_conv

parser = argparse.ArgumentParser(description="Plot Qoi")
parser.add_argument(
    "-sf",
    "--studyFolder",
    type=str,
    metavar="",
    required=False,
    help="studyFolder to analyze",
    nargs="+",
    default=[],
)

parser.add_argument(
    "-vl",
    "--var_list",
    type=str,
    metavar="",
    required=False,
    help="variables to analyze",
    nargs="+",
    default=[
        "GH",
        "GH_height",
        "d",
        "CO2_liq",
        "CO_liq",
        "H2_liq",
        "kla_CO2",
        "kla_CO",
        "kla_H2",
    ],
)
parser.add_argument(
    "-pv",
    "--param_value",
    type=float,
    metavar="",
    required=False,
    help="parameter value",
    nargs="+",
    default=[],
)

parser.add_argument(
    "-pn",
    "--param_name",
    type=str,
    metavar="",
    required=False,
    help="parameter name",
    default=None,
)
parser.add_argument(
    "-ff",
    "--figureFolder",
    type=str,
    metavar="",
    required=False,
    help="figureFolder",
    default=None,
)


args = parser.parse_args()
figureFolder = "Figures"
figure_qoi_Folder = os.path.join(figureFolder, args.figureFolder, "qoi")
figure_qoiConv_Folder = os.path.join(
    figureFolder, args.figureFolder, "qoi_conv"
)
Path(figure_qoi_Folder).mkdir(parents=True, exist_ok=True)
Path(figure_qoiConv_Folder).mkdir(parents=True, exist_ok=True)
var_names = args.var_list
param_name = args.param_name
param_vals = args.param_value
study_folders = args.studyFolder
case_folders = ["circle", "side_sparger", "multiring_4"]
case_names = ["Circle", "Side sparger", "Multiring"]

for case_folder in case_folders:
    os.makedirs(os.path.join(figure_qoi_Folder, case_folder), exist_ok=True)
    os.makedirs(
        os.path.join(figure_qoiConv_Folder, case_folder), exist_ok=True
    )
for param_val in param_vals:
    os.makedirs(
        os.path.join(figure_qoi_Folder, f"acrossDesign_{param_val:.2g}"),
        exist_ok=True,
    )


qoi = {}

for study_folder in study_folders:
    qoi[study_folder] = {}
    for case_folder in case_folders:
        print(f"Case : {study_folder}/{case_folder}")
        with open(
            os.path.join(study_folder, case_folder, "qoi.pkl"), "rb"
        ) as f:
            qoi[study_folder][case_folder] = pickle.load(f)

for case_folder in case_folders:
    for var_name in var_names:
        fig = plt.figure()
        var_val = [
            qoi[study_folder][case_folder][var_name]
            for study_folder in study_folders
        ]
        plt.plot(param_vals, var_val, "o", color="k")
        pretty_labels(label_conv(param_name), label_conv(var_name), 14)
        plt.savefig(
            os.path.join(figure_qoi_Folder, case_folder, f"{var_name}.png")
        )
        plt.savefig(
            os.path.join(figure_qoi_Folder, case_folder, f"{var_name}.eps")
        )
        plt.close()

for study_folder, param_val in zip(study_folders, param_vals):
    for var_name in var_names:
        fig = plt.figure()
        var_val = [
            qoi[study_folder][case_folder][var_name]
            for case_folder in case_folders
        ]
        plot_bar_names(case_names, var_val, title=var_name)
        plt.savefig(
            os.path.join(
                figure_qoi_Folder,
                f"acrossDesign_{param_val:.2g}",
                f"{var_name}.png",
            )
        )
        plt.savefig(
            os.path.join(
                figure_qoi_Folder,
                f"acrossDesign_{param_val:.2g}",
                f"{var_name}.eps",
            )
        )
        plt.close()

        # rescaled version
        fig = plt.figure()
        plot_bar_names(case_names, var_val, title=var_name)
        ax = plt.gca()
        mean_val = np.mean(var_val)
        ax.set_ylim([mean_val - mean_val * 5e-2, mean_val + mean_val * 5e-2])
        plt.savefig(
            os.path.join(
                figure_qoi_Folder,
                f"acrossDesign_{param_val:.2g}",
                f"{var_name}_zoom.png",
            )
        )
        plt.savefig(
            os.path.join(
                figure_qoi_Folder,
                f"acrossDesign_{param_val:.2g}",
                f"{var_name}_zoom.eps",
            )
        )
        plt.close()

qoi_conv = {}

for study_folder in study_folders:
    qoi_conv[study_folder] = {}
    for case_folder in case_folders:
        print(f"Case : {study_folder}/{case_folder}")
        with open(
            os.path.join(study_folder, case_folder, "qoi_conv.pkl"), "rb"
        ) as f:
            qoi_conv[study_folder][case_folder] = pickle.load(f)

for case_folder in case_folders:
    for var_name in var_names:
        fig = plt.figure()
        for study_folder in study_folders:
            plt.plot(
                qoi_conv[study_folder][case_folder][var_name]["x"],
                qoi_conv[study_folder][case_folder][var_name]["y"],
                linewidth=2,
                color="k",
            )
        for study_folder in study_folders:
            plt.plot(
                qoi_conv[study_folder][case_folder][var_name]["x"][-1],
                qoi_conv[study_folder][case_folder][var_name]["y"][-1],
                "*",
                markersize=15,
                color="k",
            )
        pretty_labels("t [s]", label_conv(var_name), 14)
        plt.savefig(
            os.path.join(figure_qoiConv_Folder, case_folder, f"{var_name}.png")
        )
        plt.savefig(
            os.path.join(figure_qoiConv_Folder, case_folder, f"{var_name}.eps")
        )
        plt.close()
