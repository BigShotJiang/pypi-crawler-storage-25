from bird.utilities.ofio import read_global_vars

case_folder = "."
globalVars = read_global_vars(case_folder=case_folder, cross_ref=True)
breakpoint()
