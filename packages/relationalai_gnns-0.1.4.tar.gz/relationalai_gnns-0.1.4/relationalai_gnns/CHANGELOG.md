# Changelog

## v0.1.? - (TBD)

### Features

- **Diagnostics framework for job error handling**: Added a new `diagnostics` module with `PermissionDiagnostic` and `LogPatternDiagnostic` classes that detect known error patterns during job monitoring (log streaming and status checks) and provide enhanced, actionable error messages.

- **Database/Schema permission error detection**: Automatically detect Snowflake database and schema permission errors and raise `PermissionError` with detailed SQL grant instructions including the configured database/schema names.

- **Out-of-memory error detection**: Detect OOM errors (process exit code -9) during training and raise `MemoryError` with a recommendation to use a larger instance.

---

## v0.1.1 - (02-23-2026)

### Features

- **Skip table reference validation for non-Snowflake connectors**: Allow Snowflake connectors that read CSVs and not only tables by skipping table reference validation for non-Snowflake connector types.

---

## v0.1.0 - (02-11-2026)

### Features

- **Simplified model operations**: Removed `experiment_name` parameter from `delete_model()`, `register_model()`, and `predict()`. Experiment name is now automatically resolved from `model_run_id`.

- **Schema and dtype validation**: Added validation in `predict()` to ensure inference datasets match training dataset structure. New `align_dtypes` parameter automatically aligns data types when set to `True`.

- **Enhanced prediction logic**: Improved `predict()` method with better validation and support for three inference scenarios: using training dataset, custom test table, or new dataset.

- **Foreign key sorting**: Added automatic sorting of foreign keys in `TableSchema` for consistent schema ordering.

- **File locking**: Implemented thread-safe file locking for model registry and mapping file operations to prevent race conditions.

### Documentation

- Updated directory structure documentation in `config.py` for better clarity.

---

## v0.0.4 - (01-26-2026)

---

## v0.0.3 - (01-21-2026)

---

## v0.0.1 - (01-13-2026)

- First release of `GNN SDK`
