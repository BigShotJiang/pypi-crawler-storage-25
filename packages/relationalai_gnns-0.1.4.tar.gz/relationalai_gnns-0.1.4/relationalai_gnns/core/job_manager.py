import json
import re
import time
from typing import List, Optional

import requests

from relationalai_gnns.common.exceptions import JobManagerError, JobMonitorError
from relationalai_gnns.common.job_models import JobStatus, JobTypes, PayloadTypes

from .api_request_handler import APIRequestHandler
from .config_trainer import ExperimentConfig
from .connector import BaseConnector
from .diagnostics import LogDiagnostic, LogPatternDiagnostic, PermissionDiagnostic
from .utils import get_results_views


class JobHandler:
    def __init__(self, connector: BaseConnector):
        self.connector = connector
        self.base_url = f"{connector.endpoint_url}/v1alpha1"
        # Initalize API Handler
        self.api_handler = APIRequestHandler(self.connector)

    @staticmethod
    def _print_json(response: requests.Response):
        """Helper function, print .json payload of a Response object."""
        json_payload = response.json()
        print(json.dumps(json_payload, indent=4))


class JobMonitor(JobHandler):
    """Helper class to monitor a single job."""

    def __init__(
        self,
        connector: BaseConnector,
        job_id: str,
        job_type: Optional[str] = None,
        experiment_config: Optional[ExperimentConfig] = None,
    ):
        super().__init__(connector)
        self.job_id = job_id
        self.job_type = job_type
        self.experiment_config = experiment_config

        # Register the diagnostics
        self.diagnostics: List[LogDiagnostic] = [
            PermissionDiagnostic(experiment_config),
            LogPatternDiagnostic(),
        ]

    def get_status(self, enhance_error_msg: bool = True) -> dict[str, str]:
        """
        Get the current job status.

        :param enhance_error_msg: Whether to enhance error messages with diagnostic information. Defaults to True.
        :type enhance_error_msg: bool
        :returns: Job status response data including job_id, status, and other metadata.
        :rtype: dict
        """
        try:
            payload = {"payload_type": PayloadTypes.REQUEST_JOB_STATUS, "job_id": self.job_id}

            response_data = self.api_handler.make_request(payload)

            if self.job_type in [JobTypes.INFERENCE, JobTypes.TRAIN_INFERENCE] and self.connector.is_native_app:
                source_views = get_results_views(response_data, self.connector.app_name)
                if source_views:
                    response_data["source_views"] = source_views

            # Check if job failed due to known errors and enhance the error message
            if enhance_error_msg and response_data.get("status") == JobStatus.FAILED and "error" in response_data:
                response_data["error"] = self._enhance_error_msg(response_data["error"])

            return response_data

        except Exception as e:
            raise JobMonitorError(f"❌ Error retrieving job status: {str(e)}", code="get_status:Exception")

    def _check_status_and_raise(self) -> None:
        """
        Check the current job status and raise an error if the job has failed.

        This method calls get_status() and if the job has failed, it checks the error message against all registered
        diagnostics. If a known error pattern is detected, the corresponding diagnostic will raise a specific error with
        detailed instructions. Otherwise, a generic RuntimeError is raised.

        :raises PermissionError: If a database/schema permission error is detected
        :raises MemoryError: If an OOM error is detected
        :raises RuntimeError: If the job failed for other reasons
        :raises JobMonitorError: If there's an error retrieving the job status
        """
        status_response = self.get_status(enhance_error_msg=False)

        if status_response.get("status") == JobStatus.FAILED:
            error_msg = status_response.get("error", "Job failed with no error message provided")

            # Check against all registered diagnostics
            self._check_and_raise_known_errors(error_msg)

            # If no diagnostic raised an error, raise a generic RuntimeError
            raise RuntimeError(f"Job {self.job_id} failed: {error_msg}")

    def _check_and_raise_known_errors(self, log: str):
        """
        Iterates through diagnostics and raises the specific error if found.

        :param log: The log message to check.
        :type log: str
        :raises: Specific error types (e.g., PermissionError) if detected by any diagnostic.
        """
        for diagnostic in self.diagnostics:
            if diagnostic.detect_error(log):
                diagnostic.check_and_raise(log)

    def _enhance_error_msg(self, log: str) -> str:
        """
        Passes the log through diagnostics to see if anyone wants to enhance it.

        :param log: The log message to potentially enhance.
        :type log: str
        :returns: Enhanced message if any diagnostic modifies it, otherwise the original log.
        :rtype: str
        """
        for diagnostic in self.diagnostics:
            if diagnostic.detect_error(log):
                return diagnostic.enhance_error_message(log)

        return log

    @property
    def model_run_id(self) -> str:
        """
        Return the model run ID if the job is completed.

        Raises:
            JobMonitorError: If no model has been trained yet.
        """
        status_response = self.get_status()
        if status_response.get("status") == "COMPLETED":
            return self.job_id

        raise JobMonitorError(
            "❌ No model has been trained. Please train a model first.", code="model_run_id:RequestException"
        )

    @property
    def experiment_name(self):
        """Get the experiment name for the current job."""

        try:
            payload = {"payload_type": PayloadTypes.REQUEST_JOB_STATUS, "job_id": self.job_id}
            response_data = self.api_handler.make_request(payload)
            return response_data["experiment_name"]

        except Exception as e:
            raise JobMonitorError(f"❌ Error retrieving job experiment name: {e}", code="experiment_name:Exception")

    def register_model(
        self, model_name: str, version_name: str, database_name: str, schema_name: str, comment: Optional[str] = None
    ):
        """
        Registers a model in the Model Registry for the current job.

        This method attempts to register a trained model under the specified name.
        Registration is only allowed for jobs of type TRAIN or TRAIN_INFERENCE, and if
        a valid `model_run_id` exists. Duplicate version names for a job are not allowed.

        :param model_name: The name to assign to the registered model.
        :type model_name: str
        """

        if self.job_type is None:
            raise JobMonitorError(
                "❌ Cannot register model: job type is not set. The job may not have been fetched properly.",
                code="register_model:no_job_type",
            )

        if self.job_type not in [JobTypes.TRAIN, JobTypes.TRAIN_INFERENCE]:
            raise JobMonitorError(
                f"❌ Cannot register model for job type {self.job_type.value}.", code="register_model:bad_job_type"
            )

        if not self.model_run_id:
            raise JobMonitorError(
                "❌ Cannot register model with missing model_run_id.", code="register_model:no_model_run_id"
            )

        payload = {
            "payload_type": PayloadTypes.REGISTER_MODEL,
            "model_name": model_name,
            "version_name": version_name,
            "database_name": database_name,
            "schema_name": schema_name,
            "model_run_id": self.model_run_id,
            "experiment_name": self.experiment_name,
            "comment": comment,
        }

        try:
            registered_model = self.api_handler.make_request(payload)

            print(
                f"✅ Successfully registered model "
                f"'{registered_model['database_name']}.{registered_model['schema_name']}."
                f"{registered_model['model_name']}.{registered_model['version_name']}' "
                f"for job '{self.job_id}'"
            )

        except Exception as e:
            error_msg = re.sub(r"To auto-generate `version_name`, skip that argument\.", "", str(e)).strip()
            raise JobMonitorError(f"❌ Error during model registration: {error_msg}", code="register_model:Exception")

    def cancel(self):
        """Removes a job from the queue if the job is in the queue or terminates a running job if the job is active."""
        try:
            if not self.connector.is_native_app:
                url = f"{self.base_url}/jobs/cancel/{self.job_id}"
                response = requests.post(url, headers=self.connector.headers, timeout=60)
                response.raise_for_status()
                return self._print_json(response)
            else:
                self.connector.cancel_job(self.job_id)

        except requests.RequestException:
            error_message = self.api_handler._parse_request_exception(response)
            raise JobMonitorError(error_message, code="cancel:RequestException")

        except Exception as e:
            raise JobMonitorError(f"❌ Error canceling job: {e}", code="cancel:Exception")

    def stream_logs(self):
        """
        Monitor logs for a specific job ID and display them to the user.

        Checks for database and schema permission errors and memory errors during log streaming.

        :raises PermissionError: If a database or schema permission error is detected (e.g., database or schema does not
            exist, or the GNN RelationalAI Native App lacks permissions).
        :raises MemoryError: If an out-of-memory error is detected (e.g., process exited with code -9).
        :raises JobMonitorError: If an unexpected error occurs during the streaming process (e.g., connection loss, API
            failures).
        """

        print(f"\nMonitoring logs for job ID: {self.job_id}")
        print("-" * 80)

        try:
            if self.connector.is_native_app:
                self._stream_logs_is_native_app()
            else:
                self._stream_logs_http_approach()
        except KeyboardInterrupt:
            print("\nStopped log streaming.")
        except PermissionError:
            raise
        except MemoryError:
            raise
        except Exception as e:
            raise JobMonitorError(f"❌ Error streaming logs: {e}", code="stream_logs:Exception")

        print("\nLog monitoring completed!")

    def _stream_logs_http_approach(self):
        """Stream logs using HTTP streaming approach."""
        url = f"{self.base_url}/jobs/logs/{self.job_id}"

        with requests.get(url, headers=self.connector.headers, stream=True, timeout=None) as response:
            if response.status_code != 200:
                raise JobMonitorError(
                    f"❌ Error accessing logs. Status code: {response.status_code}", code="stream_logs:exception"
                )

            for line in response.iter_lines():
                if not line:
                    continue

                decoded_line = line.decode("utf-8")
                self._check_and_raise_known_errors(decoded_line)
                print(self.clean_log_message(decoded_line))

                # Stop after training completes
                if f"JOB_END:{self.job_id}" in decoded_line:
                    print(decoded_line)
                    print("-" * 80)
                    print(f"Training job {self.job_id} completed!")
                    break

    def _stream_logs_is_native_app(self):
        """Stream logs using SQL approach with continuation token."""
        continuation_token = ""

        while True:
            response = self.connector.get_job_events(self.job_id, continuation_token)

            # Print event logs to stdout
            for event in response["events"]:
                log_message = event["event"]["message"]
                self._check_and_raise_known_errors(log_message)
                print(self.clean_log_message(log_message))

            # Check if we need to continue fetching more logs
            continuation_token = response["continuation_token"]
            if not continuation_token:
                break

    @staticmethod
    def clean_log_message(log: str):
        if "| user_id" in log:
            clean_log = log.split("| user_id")[0].strip()
        else:
            clean_log = log

        return clean_log

    def materialize_results(self, overwrite_results: bool = False):
        """
        Export job results to permanent tables after completion.

        :param overwrite_results: If True, overwrite existing tables. If False (default), raise an error if tables
            already exist.
        :type overwrite_results: bool
        """
        job_status = self._wait_for_completion()

        if job_status["status"] == JobStatus.COMPLETED:
            self._create_tables(job_status, overwrite_results=overwrite_results)
        else:
            raise RuntimeError(f"Job failed: {job_status}")

    def _wait_for_completion(self):
        """Poll job status until completion."""
        while True:
            status = self.get_status()

            if status["status"] not in [JobStatus.RUNNING, JobStatus.QUEUED]:
                return status

            time.sleep(5)

        # TODO: updtate the connector after some time to avoid sesssions errors

    def _create_tables(self, job_status, overwrite_results: bool = False):
        """Create all result tables from job export paths."""
        job_id = job_status["job_id"].replace("-", "_")
        export_paths = job_status["export_paths"]

        # Get all table paths
        all_paths = [export_paths["predictions"]]

        if "embeddings" in export_paths:
            all_paths += list(export_paths["embeddings"].values())

        for table_path in all_paths:
            table_name = table_path.split(".")[-1]
            view_name = f"job_{job_id}_{table_name}"
            source_view = f"{self.connector.app_name}.RESULTS.{view_name}"

            create_stmt = "CREATE OR REPLACE TABLE" if overwrite_results else "CREATE TABLE"
            sql = f"{create_stmt} {table_path} AS SELECT * FROM {source_view}"
            self.connector._exec(sql)
            # Drop the corresponding internal table after export
            internal_table_name = f"{view_name}_INTERNAL"
            self.connector._exec(f"call {self.connector.app_name}.api.drop_result_table('{internal_table_name}');")


class JobManager(JobHandler):
    """Helper class to monitor all jobs in queue."""

    def show_jobs(self):
        """Returns the queue status."""
        payload = {"payload_type": PayloadTypes.REQUEST_QUEUE_STATUS}

        try:
            return self.api_handler.make_request(payload)
        except Exception:
            raise JobManagerError("❌ Error getting queue status.", code="show_jobs:Exception")

    def fetch_job(self, job_id: str) -> JobMonitor:
        """
        Fetch a job by its ID.

        :param job_id: Unique identifier of the job to fetch.
        :type job_id: str
        :returns: A dictionary or object representing the fetched job and its metadata.
        :rtype: dict or Job
        :raises JobManagerError: If the job ID is invalid or the job cannot be found.
        """
        job = JobMonitor(connector=self.connector, job_id=job_id)
        try:
            status = job.get_status()
            # Populate job_type from status response if available
            if "job_type" in status and status["job_type"]:
                job.job_type = status["job_type"]
        except JobMonitorError:
            raise JobManagerError("❌ Unknown job status: None", code="fetch_job:Exception")
        return job

    def cancel_job(self, job_id: str):
        """
        Cancel a job by its ID.

        Removes the job from the queue if it is queued, or terminates it if it is currently running.

        :param job_id: Unique identifier of the job to cancel.
        :type job_id: str
        :returns: The result of the cancel operation.
        :rtype: Any
        :raises JobManagerError: If the job cannot be found or is in a non-cancellable state.
        """
        try:
            job = self.fetch_job(job_id)
        except JobManagerError:
            raise JobManagerError("❌ Unknown job status: None", code="cancel_job:Exception")

        return job.cancel()
