import copy
import json
from typing import Optional

from relationalai_gnns.common.dataset_model import TaskMeta, TaskType
from relationalai_gnns.common.exceptions import ValidationError
from relationalai_gnns.common.export import OutputConfig
from relationalai_gnns.common.job_models import JobTypes, ModelSelectionStrategy, PayloadTypes

from .api_request_handler import APIRequestHandler
from .config_trainer import ExperimentConfig, TrainerConfig
from .connector import BaseConnector, LocalConnector, SnowflakeConnectorDirectAccess
from .dataset import Dataset
from .job_manager import JobMonitor
from .utils import (
    diff_metadata_dtypes,
    diff_metadata_schema,
    extract_all_table_paths,
    find_missing_test_table_required_columns,
    map_dtypes,
)


class Trainer:
    def __init__(self, connector: BaseConnector, config: TrainerConfig):
        """
        Trainer class for the GNN-RLE.

        Initializes and manages the training process for a GNN model.

        :param connector: Connector object used to interact with the data source.
        :type connector: Connector
        :param config: Configuration object containing all training hyperparameters.
        :type config: TrainerConfig
        """

        self.connector = connector
        self.api_handler = APIRequestHandler(connector)
        self.config = config.to_dict()

    def _add_inference_export_config(self, **model_params):
        """Get dataset metadata from MLflow artifacts."""

        payload = {
            "payload_type": PayloadTypes.ADD_INFERENCE_EXPORT,
            "config": self.config,
            **{k: v for k, v in model_params.items() if v is not None},
        }
        return self.api_handler.make_request(payload)

    def _submit_job(self, dataset_metadata: dict, job_type: JobTypes) -> JobMonitor:
        """
        Helper method to submit a job request to the remote training system.

        Args:
            dataset_metadata (dict): The dataset metadata for training/inference.
            job_type (JobTypes): The type of job - "train", "inference", or "both".

        Returns:
            JobMonitor: An object representing the submitted job.
        """
        payload = {
            "payload_type": PayloadTypes.JOB,
            "dataset_metadata": dataset_metadata,
            "model_configuration": self.config,
            "job_type": job_type,
        }
        tables = extract_all_table_paths(dataset_metadata)
        job_data = self.api_handler.make_request(payload, tables)

        if self.connector.is_native_app:
            payload_logs = {
                "payload_type": PayloadTypes.SEND_LOGS,
                "job_id": job_data["job_id"],
                "stream_name": "progress",
            }

            _ = self.api_handler.make_request(payload_logs)

        if job_data:
            job_monitor = JobMonitor(
                connector=self.connector,
                job_id=job_data["job_id"],
                job_type=job_type,
                experiment_config=ExperimentConfig(**self.config["experiment"]),
            )
            return job_monitor

    def _get_dataset_metadata(self, **params):
        """Get dataset metadata from model artifacts."""
        payload = {
            "payload_type": PayloadTypes.REQUEST_DATASET_CONFIG,
            **{k: v for k, v in params.items() if v is not None},
        }
        return self.api_handler.make_request(payload)

    def _get_test_table_info(self, source):
        payload = {
            "payload_type": PayloadTypes.FETCH_TABLE,
            "source": source,
            "connector": self.connector.connector_type,
        }

        json_data = self.api_handler.make_request(payload, [source])
        column_names = json_data["columns"]
        column_dtypes = json_data["dtypes"]
        return column_names, column_dtypes

    def fit(self, dataset: Dataset) -> JobMonitor:
        """
        Submit a training job.

        :param dataset: The dataset to be used for training.
        :type dataset: Dataset
        :returns: An object to monitor the submitted job, check its status, track model progress, and retrieve metrics
            after training.
        :rtype: JobMonitor
        """
        # Validate task has required splits for training
        dataset.task_description.validate_for_training()
        return self._submit_job(dataset_metadata=dataset.metadata_dict, job_type=JobTypes.TRAIN)

    def predict(
        self,
        output_alias: str,
        output_config: Optional[OutputConfig] = None,
        test_batch_size: int = 128,
        dataset: Optional[Dataset] = None,
        test_table: Optional[str] = None,
        model_run_id: Optional[str] = None,
        registered_model_key: Optional[str] = None,
        extract_embeddings: bool = False,
        materialize_results: bool = True,
        overwrite_results: bool = False,
        flatten_output: bool = False,
        align_dtypes: bool = False,
    ) -> JobMonitor:
        """
        Submits an inference job using a trained model to generate predictions on test data.

        This method performs the following steps:
        1. Validates that exactly one model selection method is provided (model_run_id or registered_model_key)
        2. Validates that dataset and test_table are not both provided (mutually exclusive)
        3. Retrieves the dataset metadata from the model artifacts (training dataset)
        4. Handles three inference cases:
           a. Neither dataset nor test_table provided (Case 1):
              - Uses the complete training dataset (graph + test table)
              - Validates training dataset has a test table defined
           b. test_table provided (Case 2):
              - Uses training dataset graph with custom test table
              - Validates test_table has required columns
           c. dataset provided (Case 3):
              - Uses new dataset (graph + test table)
              - Validates dataset has a test table defined
              - Validates schema matches training dataset
              - Handles dtype differences based on align_dtypes parameter
        5. Configures inference parameters and output settings based on the output_config type
        6. Submits the inference job and returns a JobMonitor for tracking progress

        If materialize_results is True and the connector is a native app, the method will wait for
        the job to complete and materialize the results. Otherwise, the job runs asynchronously.

        Model Selection (required):
            Exactly one of the following must be provided:
            - `registered_model_key`: Use a registered model from the model registry
            (format: 'database.schema.model.version', e.g. 'my_database.my_schema.my_model.1')
            - `model_run_id`: Use a model from a specific training run

        Dataset and Test Table Selection:
            One of the following three options (dataset and test_table are mutually exclusive):

            a. Neither `dataset` nor `test_table` provided (Case 1):
               - Inference uses the complete dataset that the model was trained on
               - Both the graph and the original test table are reused
               - The training dataset must have a test table defined

            b. `test_table` provided, `dataset` not provided (Case 2):
               - Inference uses the graph from the dataset that the model was trained on
               - The specified test table is used for inference, replacing the original test table
               - The test table must have the same schema as the task tables from the original dataset
                 (with the label column being optional)

            c. `dataset` provided, `test_table` not provided (Case 3):
               - Inference uses the graph and test table from the newly provided dataset
               - The schema (tables, columns, keys, relationships) of the new dataset must match
                 the schema of the dataset the model was trained on
               - The provided dataset must have a test table defined
               - Schema validation happens first; if schemas differ, a ValidationError is raised
               - After schema validation, dtype handling depends on `align_dtypes`:
                 * If `align_dtypes=True`: dtypes are automatically aligned to match the model
                 * If `align_dtypes=False`: dtypes are validated and a ValidationError is raised if mismatched

            Note: `dataset` and `test_table` are mutually exclusive (cannot provide both)

        :param output_alias: An alias to append to the result tables of predictions and embeddings.
        :type output_alias: str

        :param output_config: Configuration specifying where to save results.
                            Use `OutputConfig.snowflake()` for Snowflake or `OutputConfig.local()` for local files.
                            Optional — when None, no export configuration is set and results are not exported.
                            Must be provided when `materialize_results=True`.
        :type output_config: OutputConfig, optional

        :param test_batch_size: Test batch size to use during inference. Defaults to 128.
        :type test_batch_size: int, optional

        :param dataset: Dataset to run inference on. Optional - if not provided, uses the training dataset.
                       If provided, its schema must match the dataset schema the model was trained on,
                       and it must have a test table defined.
                       Cannot be used together with `test_table`.
        :type dataset: Dataset, optional

        :param test_table: Fully qualified path to a custom test table. Optional - if not provided, uses the
                         dataset's test table (either from provided dataset or training dataset).
                         When provided, inference uses the graph from the dataset that the model was trained on,
                         and this test table replaces the original test table.
                         Must have the same schema as the task tables from the training dataset (label column optional).
                         Cannot be used together with `dataset`.
        :type test_table: str, optional

        :param registered_model_key: Fully qualified model key in the format 'database.schema.model.version'.
                                   Mutually exclusive with `model_run_id`.
        :type registered_model_key: str, optional

        :param model_run_id: Run inference using this specific model run ID.
                           Mutually exclusive with `registered_model_key`.
        :type model_run_id: str, optional

        :param extract_embeddings: If True, extract node embeddings in addition to predictions.
        :type extract_embeddings: bool, optional

        :param materialize_results: If True and connector is a native app, wait for job completion and create
                                   permanent tables. This makes the method run synchronously (blocking).
                                   Defaults to True.
        :type materialize_results: bool

        :param overwrite_results: If True, overwrite existing tables when materializing results.
                                 Only has effect when materialize_results is True. Defaults to False.
        :type overwrite_results: bool

        :param flatten_output: If True, flatten the inference output (used in Multi-label Node Classification
                              and Link Prediction). Drops ground truth column (if present) for all tasks.
        :type flatten_output: bool

        :param align_dtypes: If True and dataset is provided, automatically align dataset dtypes
                            to match the model's expected dtypes after schema validation.
                            If False, dtype mismatches will raise a ValidationError.
                            Schema validation (structure) always happens regardless of this parameter.
        :type align_dtypes: bool, optional

        :returns: An object representing the submitted job, which can be used to monitor job status, retrieve metrics,
                 and track progress.
        :rtype: JobMonitor

        :raises ValidationError: If neither `model_run_id` nor `registered_model_key` is provided.
        :raises ValidationError: If both `model_run_id` and `registered_model_key` are provided.
        :raises ValidationError: If both `dataset` and `test_table` are provided.
        :raises ValidationError: If the training dataset (when neither dataset nor test_table provided) or the provided
                                dataset (when dataset provided) does not have a test table defined.
        :raises ValidationError: If a new dataset is provided but its schema (structure) is incompatible with the
                                training dataset schema.
        :raises ValidationError: If a new dataset is provided, align_dtypes=False, and dtypes are incompatible with
                                the training dataset dtypes.
        :raises ValidationError: If a custom test_table is provided but its schema doesn't match the training dataset's
                                task table schema.
        """

        # Step 1: Validate input requirements
        if dataset and test_table:
            raise ValidationError("Specify only one of `dataset` or `test_table` parameter. Not both.")

        if not model_run_id and not registered_model_key:
            raise ValidationError("Specify either `model_run_id` or `registered_model_key`. One must be provided.")

        if model_run_id and registered_model_key:
            raise ValidationError("Specify only one of `model_run_id` or `registered_model_key`. Not both.")

        # Validate that output_config is provided when materialize_results is True,
        # since materialization requires export paths that are configured via output_config.
        if output_config is None and materialize_results:
            raise ValidationError(
                "Cannot materialize results without an output configuration. "
                "Either provide `output_config` or set `materialize_results=False`."
            )

        model_selection_strategy = (
            ModelSelectionStrategy.REGISTERED if registered_model_key else ModelSelectionStrategy.CUSTOM_RUN
        )

        # Step 2: Obtain dataset metadata and validate
        # Retrieve metadata from the model artifacts (training dataset schema)
        try:
            retrieved_metadata_dict = self._get_dataset_metadata(
                model_run_id=model_run_id,
                registered_model_key=registered_model_key,
                model_selection_strategy=model_selection_strategy,
            )
        except (ValidationError, RuntimeError) as e:
            # catch error with registered model key, see issue:
            # https://github.com/RelationalAI/gnn-learning-engine/issues/458
            if registered_model_key and "not found" in str(e).lower():
                raise ValidationError(
                    f"The provided registered_model_key '{registered_model_key}' does not exist. "
                    f"Please verify the key is correct (format: 'database.schema.model.version')."
                ) from None
            raise

        if not dataset and not test_table:
            # Case 1: Neither dataset nor test_table provided - use complete training dataset
            metadata_dict = retrieved_metadata_dict

            # Validate that training dataset has a test table
            test_table_source = metadata_dict.get("task", {}).get("source", {}).get("test")
            if not test_table_source:
                raise ValidationError(
                    "The training dataset does not have a test table. "
                    "Please provide a test_table parameter to run inference."
                )

        elif test_table:
            # Case 2: test_table provided - use training dataset graph with custom test table
            metadata_dict = retrieved_metadata_dict
            column_names, _ = self._get_test_table_info(test_table)

            task_meta = TaskMeta.model_validate(metadata_dict["task"])
            if task_meta.task_type in [TaskType.LINK_PREDICTION, TaskType.REPEATED_LINK_PREDICTION]:
                missing_columns = find_missing_test_table_required_columns(
                    column_names=column_names,
                    time_column=metadata_dict["task"].get("time_column"),
                    source_entity_column=metadata_dict["task"].get("source_entity_column"),
                )
            else:
                missing_columns = find_missing_test_table_required_columns(
                    column_names=column_names,
                    time_column=metadata_dict["task"].get("time_column"),
                    target_entity_column=metadata_dict["task"].get("target_entity_column"),
                )

            if missing_columns:
                raise ValidationError(f"Test table validation failed: Missing required columns: {missing_columns}")
            metadata_dict["task"]["source"]["test"] = test_table

        else:
            # Case 3: dataset provided - use new dataset with schema validation
            metadata_dict = copy.deepcopy(dataset.metadata_dict)

            # Validate that provided dataset has a test table
            test_table_source = metadata_dict.get("task", {}).get("source", {}).get("test")
            if not test_table_source:
                raise ValidationError(
                    "The provided dataset does not have a test table. "
                    "Either provide a dataset with a test table or use the test_table parameter."
                )

            # Validate schema matches
            schema_diff = diff_metadata_schema(metadata_dict, retrieved_metadata_dict)
            if schema_diff:
                raise ValidationError(
                    f"Schema validation failed: Inference dataset schema incompatible with trained model.\n\n"
                    f"Schema differences:\n{json.dumps(schema_diff, indent=2)}\n\n"
                    f"The model expects the same column names and relationships used during training."
                )

            # Handle dtype differences
            if align_dtypes:
                map_dtypes(retrieved_metadata_dict, metadata_dict)
            else:
                dtype_diff = diff_metadata_dtypes(retrieved_metadata_dict, metadata_dict)
                if dtype_diff:
                    raise ValidationError(
                        f"Dtype validation failed: Inference dataset dtypes incompatible with trained model.\n\n"
                        f"Dtype differences:\n{json.dumps(dtype_diff, indent=2)}\n\n"
                        f"The model expects the same column dtypes used during training.\n"
                        f"Hint: Try running predict() again with align_dtypes=True to automatically align data types."
                    )

        # Step 3: Configure inference and export parameters.
        # When output_config is provided, configure the export destination (snowflake or local).
        # When output_config is None, only send inference parameters (no export destination).
        if output_config is not None:
            if output_config.type == "snowflake":
                snowflake_settings = output_config.settings
                self.config = self._add_inference_export_config(
                    test_batch_size=test_batch_size,
                    model_selection_strategy=model_selection_strategy,
                    model_run_id=model_run_id,
                    registered_model_key=registered_model_key,
                    extract_embeddings=extract_embeddings,
                    output_alias=output_alias,
                    database_name=snowflake_settings.database_name,
                    schema_name=snowflake_settings.schema_name,
                    flatten_output=flatten_output,
                )
                # Check write permissions when materializing to Snowflake
                if (
                    materialize_results
                    and self.connector.connector_type == "snowflake"
                    and not isinstance(self.connector, LocalConnector)
                    and not isinstance(self.connector, SnowflakeConnectorDirectAccess)
                ):
                    self._check_write_permissions(snowflake_settings.database_name, snowflake_settings.schema_name)

            elif output_config.type == "local":
                local_settings = output_config.settings
                self.config = self._add_inference_export_config(
                    test_batch_size=test_batch_size,
                    model_selection_strategy=model_selection_strategy,
                    model_run_id=model_run_id,
                    registered_model_key=registered_model_key,
                    extract_embeddings=extract_embeddings,
                    output_alias=output_alias,
                    artifacts_dir=local_settings.artifacts_dir,
                    extension=local_settings.extension,
                    flatten_output=flatten_output,
                )
        else:
            # No export destination — send only inference parameters so the backend
            # knows how to run inference (batch size, model selection, etc.) without
            # configuring an export destination.
            self.config = self._add_inference_export_config(
                test_batch_size=test_batch_size,
                model_selection_strategy=model_selection_strategy,
                model_run_id=model_run_id,
                registered_model_key=registered_model_key,
                extract_embeddings=extract_embeddings,
                flatten_output=flatten_output,
            )

        # Step 4: Submit the inference job and return a monitor to track progress
        job = self._submit_job(dataset_metadata=metadata_dict, job_type=JobTypes.INFERENCE)
        if materialize_results and self.connector.is_native_app:
            job.materialize_results(overwrite_results=overwrite_results)
        return job

    def fit_predict(
        self,
        dataset: Dataset,
        output_alias: str,
        output_config: Optional[OutputConfig] = None,
        test_batch_size: int = 128,
        extract_embeddings: bool = False,
        materialize_results: bool = True,
        overwrite_results: bool = False,
        flatten_output: bool = False,
    ) -> JobMonitor:
        """
        Submits a job that performs both training and inference.

        Validates that task has all required splits (train, validation, and test).

        This function trains a GNN model using the provided dataset and then runs inference on the test data. The
        dataset must include a test table.

        If materialize_results is True, the method waits for the job to complete and creates permanent tables. This
        causes the method to run synchronously (blocking) rather than executing in the background.

        :param dataset: The dataset to be used for training and inference. Must include a test table.
        :type dataset: Dataset
        :param output_config: Configuration specifying where to save results. Use `OutputConfig.local()` or
            `OutputConfig.snowflake()`. Optional — when None, no export configuration is set and results are not
            exported. Must be provided when `materialize_results=True`.
        :type output_config: OutputConfig, optional
        :param output_alias: An alias to append to the result tables for predictions and embeddings.
        :type output_alias: str
        :param test_batch_size: Test batch size to use during inference. Defaults to 128.
        :type test_batch_size: int, optional
        :param extract_embeddings: Set to True to extract node embeddings.
        :type extract_embeddings: bool
        :param materialize_results: If True, wait for job completion and create permanent tables. This makes the method
            run synchronously (blocking) instead of in the background.
        :type materialize_results: bool
        :param overwrite_results: If True, overwrite existing tables when materializing results.
            Only has effect when materialize_results is True. Defaults to False.
        :type overwrite_results: bool
        :param flatten_output: If True - Flatten the inference output
        (used in Multi-label Node Classification and Link Prediction).
            Drop ground truth column (if present) for all tasks.
        :type flatten_output: bool
        :returns: An object representing the submitted job. This object can be used to check job status, retrieve
            training metrics, and monitor progress.
        :rtype: JobMonitor :example: # Snowflake output trainer.fit_predict( dataset=dataset,
            output_config=OutputConfig.snowflake( database_name="SYNTHETIC_ACADEMIC_RANKING_DB", schema_name="PUBLIC" ),
            output_alias="my_predictions" )
        raises: ValidationError: If task has no train and validation splits.
        raises: ValidationError: If task has no test split.
        """
        # Validate task has all required splits
        dataset.task_description.validate_for_training()
        dataset.task_description.validate_for_inference()

        # Validate that output_config is provided when materialize_results is True,
        # since materialization requires export paths that are configured via output_config.
        if output_config is None and materialize_results:
            raise ValidationError(
                "Cannot materialize results without an output configuration. "
                "Either provide `output_config` or set `materialize_results=False`."
            )

        # Configure inference and export parameters.
        # When output_config is provided, configure the export destination (snowflake or local).
        # When output_config is None, only send inference parameters (no export destination).
        if output_config is not None:
            if output_config.type == "snowflake":
                snowflake_settings = output_config.settings
                self.config = self._add_inference_export_config(
                    test_batch_size=test_batch_size,
                    model_selection_strategy="current",
                    model_run_id=None,
                    registered_model_key=None,
                    extract_embeddings=extract_embeddings,
                    output_alias=output_alias,
                    database_name=snowflake_settings.database_name,
                    schema_name=snowflake_settings.schema_name,
                    flatten_output=flatten_output,
                )
                # Check write permissions when materializing to Snowflake
                if (
                    materialize_results
                    and self.connector.connector_type == "snowflake"
                    and not isinstance(self.connector, LocalConnector)
                    and not isinstance(self.connector, SnowflakeConnectorDirectAccess)
                ):
                    self._check_write_permissions(snowflake_settings.database_name, snowflake_settings.schema_name)

            elif output_config.type == "local":
                local_settings = output_config.settings
                self.config = self._add_inference_export_config(
                    test_batch_size=test_batch_size,
                    model_selection_strategy="current",
                    model_run_id=None,
                    registered_model_key=None,
                    extract_embeddings=extract_embeddings,
                    output_alias=output_alias,
                    artifacts_dir=local_settings.artifacts_dir,
                    extension=local_settings.extension,
                    flatten_output=flatten_output,
                )
        else:
            # No export destination — send only inference parameters so the backend
            # knows how to run inference (batch size, model selection, etc.) without
            # configuring an export destination.
            self.config = self._add_inference_export_config(
                test_batch_size=test_batch_size,
                model_selection_strategy="current",
                model_run_id=None,
                registered_model_key=None,
                extract_embeddings=extract_embeddings,
                flatten_output=flatten_output,
            )

        job = self._submit_job(dataset_metadata=dataset.metadata_dict, job_type=JobTypes.TRAIN_INFERENCE)
        if materialize_results and self.connector.is_native_app:
            job.materialize_results(overwrite_results=overwrite_results)
        return job

    def _check_write_permissions(self, database_name: str, schema_name: str) -> None:
        """
        Check if the current role has write permissions to the specified database and schema.

        Args:
            database_name (str): Name of the database to check
            schema_name (str): Name of the schema to check

        Raises:
            PermissionError: If the role lacks write permissions
        """
        try:
            self.connector._exec(f"USE ROLE {self.connector.role}")
            self.connector._exec(f"USE DATABASE {database_name}")
            self.connector._exec(f"USE SCHEMA {schema_name}")
            self.connector._exec("CREATE OR REPLACE TABLE test_write (id INT)")
            self.connector._exec("DROP TABLE test_write")
        except Exception as e:
            raise PermissionError(f"Error: {str(e)}") from e
