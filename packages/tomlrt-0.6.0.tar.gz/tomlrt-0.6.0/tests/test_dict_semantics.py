"""Tables really are :class:`dict` subclasses now.

These tests pin the user-visible Pythonic behaviours that the
view-based predecessor could not provide: ``isinstance(t, dict)``,
``**t`` unpacking, ``dict``-typed APIs accepting tables directly,
held references behaving like ordinary Python references, and
identity stability for repeated lookups.
"""

from __future__ import annotations

import json

import pytest

import tomlrt
from _toml_str import td
from tomlrt import AoT, Table


def _src() -> str:
    return td("""
        title = "demo"

        [tool]
        name = "x"

        [tool.poetry]
        version = "0.1"

        [[entries]]
        k = 1

        [[entries]]
        k = 2
        """)


def test_document_is_dict() -> None:
    doc = tomlrt.parse(_src())
    assert isinstance(doc, dict)
    assert isinstance(doc["tool"], dict)
    assert isinstance(doc["tool"]["poetry"], dict)


def test_inline_table_is_dict() -> None:
    doc = tomlrt.parse("t = { a = 1, b = 2 }\n")
    assert isinstance(doc["t"], dict)


def test_dict_unpack_spread() -> None:
    doc = tomlrt.parse(_src())
    spread = {**doc["tool"]}
    assert spread == {"name": "x", "poetry": doc["tool"]["poetry"]}


def test_json_dumps_via_to_dict() -> None:
    doc = tomlrt.parse(
        td("""
        a = 1
        b = "two"
        [c]
        x = 3
        """)
    )
    # Direct json.dumps still needs to_dict for datetime-free trees,
    # but now the result of to_dict is interchangeable with a plain dict.
    assert json.loads(json.dumps(doc.to_dict())) == {"a": 1, "b": "two", "c": {"x": 3}}


def test_repeated_lookup_returns_same_object() -> None:
    doc = tomlrt.parse(_src())
    assert doc["tool"] is doc["tool"]
    assert doc["tool"]["poetry"] is doc["tool"]["poetry"]
    assert doc["entries"] is doc["entries"]


def test_held_reference_orphans_on_delete() -> None:
    doc = tomlrt.parse(_src())
    held = doc["tool"]
    del doc["tool"]
    # Held reference still has its own data...
    assert held["name"] == "x"
    # ...but mutations through it are silently invisible to the document.
    held["new"] = 99
    assert "new" not in tomlrt.dumps(doc)
    assert "[tool]" not in tomlrt.dumps(doc)


def test_held_reference_does_not_resurrect() -> None:
    doc = tomlrt.parse('[tool]\nname = "x"\n')
    held = doc["tool"]
    del doc["tool"]
    doc["tool"] = {"name": "y"}
    # The held reference is *not* the same object as the new binding.
    assert held is not doc["tool"]
    assert held["name"] == "x"
    assert doc["tool"]["name"] == "y"


def test_set_table_returns_object_stored_in_dict() -> None:
    doc = tomlrt.parse("")
    t = doc.install("a.b", Table.section())
    assert t is doc["a"]["b"]


def test_set_aot_returns_object_stored_in_dict() -> None:
    doc = tomlrt.parse("")
    doc["things"] = AoT()
    aot = doc["things"]
    assert aot is doc["things"]


def test_empty_aot_appendable_after_set() -> None:
    doc = tomlrt.parse("")
    doc["things"] = AoT()
    aot = doc["things"]
    aot.add({"k": 1})
    assert tomlrt.dumps(doc).strip().endswith("k = 1")
    # And still the same object.
    assert aot is doc["things"]


def test_dict_typed_isinstance_check() -> None:
    """Common downstream guard: ``isinstance(x, dict)`` now passes."""
    doc = tomlrt.parse("[a]\nx = 1\n")

    def consumer(d: dict[str, object]) -> int:
        assert isinstance(d, dict)
        return len(d)

    assert consumer(doc["a"]) == 1


def test_update_via_kwargs_and_mapping() -> None:
    doc = tomlrt.parse("[a]\nx = 1\n")
    doc["a"].update({"y": 2}, z=3)
    assert doc["a"]["x"] == 1
    assert doc["a"]["y"] == 2
    assert doc["a"]["z"] == 3
    rendered = tomlrt.dumps(doc)
    assert "y = 2" in rendered
    assert "z = 3" in rendered


def test_update_via_iterable_of_pairs() -> None:
    doc = tomlrt.parse("")
    doc.update([("a", 1), ("b", 2)])
    assert doc["a"] == 1
    assert doc["b"] == 2


def test_setdefault_existing_returns_stored() -> None:
    doc = tomlrt.parse("[a]\nx = 1\n")
    a = doc["a"]
    result = a.setdefault("x", 99)
    assert result == 1
    assert a["x"] == 1


def test_setdefault_missing_inserts_and_returns() -> None:
    doc = tomlrt.parse("[a]\nx = 1\n")
    a = doc["a"]
    result = a.setdefault("y", 42)
    assert result == 42
    assert a["y"] == 42
    assert "y = 42" in tomlrt.dumps(doc)


def test_clear_removes_keys_from_cst() -> None:
    doc = tomlrt.parse("a = 1\nb = 2\n")
    doc.clear()
    assert dict(doc) == {}
    assert tomlrt.dumps(doc) == ""


def test_pop_returns_orphaned_table() -> None:
    doc = tomlrt.parse("[a]\nx = 1\n")
    held_first = doc["a"]
    popped = doc.pop("a")
    # Same object that was in dict storage; now orphaned.
    assert popped is held_first
    assert "a" not in doc
    assert popped["x"] == 1


def test_pop_default_when_missing() -> None:
    doc = tomlrt.parse("")
    sentinel = object()
    assert doc.pop("missing", sentinel) is sentinel


def test_popitem_lifo() -> None:
    doc = tomlrt.parse(
        td("""
        a = 1
        b = 2
        c = 3
        """)
    )
    k, v = doc.popitem()
    assert (k, v) == ("c", 3)


def test_or_operator_in_place() -> None:
    doc = tomlrt.parse("a = 1\n")
    doc |= {"b": 2}
    assert doc["a"] == 1
    assert doc["b"] == 2


def test_copy_returns_plain_dict() -> None:
    doc = tomlrt.parse("[a]\nx = 1\n")
    snap = doc.copy()
    assert isinstance(snap, dict)
    assert not isinstance(snap, tomlrt.Table)
    # Mutations to snap don't reach the document.
    snap["new"] = 9
    assert "new" not in doc


def test_round_trip_unchanged_after_parse() -> None:
    """Populating dict storage at parse-time must not perturb the CST."""
    src = _src()
    assert tomlrt.dumps(tomlrt.parse(src)) == src


def test_mutation_through_held_child_visible_via_parent() -> None:
    doc = tomlrt.parse("[a]\nx = 1\n")
    a = doc["a"]
    a["y"] = 2
    assert doc["a"]["y"] == 2
    assert a is doc["a"]


def test_replace_value_invalidates_old_wrapper() -> None:
    doc = tomlrt.parse("[a]\nx = 1\n")
    old_a = doc["a"]
    doc["a"] = {"y": 9}
    assert old_a is not doc["a"]
    assert doc["a"]["y"] == 9
    assert "x" not in doc["a"]


def test_inline_promotion_returns_dict_storage_object() -> None:
    doc = tomlrt.parse('pkg = { name = "x" }\n')
    promoted = doc.promote_inline("pkg")
    assert promoted is doc["pkg"]
    assert isinstance(doc["pkg"], dict)


def test_aot_promotion_returns_dict_storage_object() -> None:
    doc = tomlrt.parse("xs = [{ k = 1 }, { k = 2 }]\n")
    promoted = doc.promote_array("xs")
    assert promoted is doc["xs"]


def test_del_then_set_table_does_not_revive_held_ref() -> None:
    doc = tomlrt.parse("[a]\nx = 1\n")
    held = doc["a"]
    del doc["a"]
    doc["a"] = Table.section()
    new = doc["a"]
    assert new is doc["a"]
    assert held is not new


def test_table_equals_plain_dict_with_same_keys() -> None:
    doc = tomlrt.parse(
        td("""
        [a]
        x = 1
        y = 2
        """)
    )
    assert doc["a"] == {"x": 1, "y": 2}


def test_keys_values_items_match_dict_protocol() -> None:
    doc = tomlrt.parse("a = 1\nb = 2\n")
    assert list(doc.keys()) == ["a", "b"]
    assert list(doc.values()) == [1, 2]
    assert list(doc.items()) == [("a", 1), ("b", 2)]


def test_table_unhashable_like_dict() -> None:
    doc = tomlrt.parse("a = 1\n")
    with pytest.raises(TypeError):
        hash(doc)


def test_detached_set_table_does_not_revive_in_doc() -> None:
    doc = tomlrt.parse("[outer]\nx = 1\n")
    held = doc["outer"]
    del doc["outer"]
    assert isinstance(held, tomlrt.Table)
    held["nested"] = Table.section({"deep": "data"})
    assert tomlrt.dumps(doc) == ""
    # Held subtree still reflects its own structural changes.
    assert dict(held["nested"]) == {"deep": "data"}


def test_detached_aot_add_does_not_revive_in_doc() -> None:
    doc = tomlrt.parse(
        td("""
        [[entries]]
        k = 1
        [[entries]]
        k = 2
        """)
    )
    held = doc.aot("entries")
    del doc["entries"]
    held.add({"k": 999})
    assert tomlrt.dumps(doc) == ""
    assert [dict(e) for e in held] == [{"k": 1}, {"k": 2}, {"k": 999}]


def test_detached_aot_entry_set_table_does_not_revive() -> None:
    doc = tomlrt.parse("[[entries]]\nk = 1\n")
    held_aot = doc.aot("entries")
    held_entry = held_aot[0]
    del doc["entries"]
    held_entry["sub"] = Table.section({"a": 1})
    held_entry["new"] = 42
    assert tomlrt.dumps(doc) == ""
    assert held_entry["new"] == 42
    assert dict(held_entry["sub"]) == {"a": 1}


def test_detached_aot_replaced_does_not_revive() -> None:
    doc = tomlrt.parse("[[entries]]\nk = 1\n")
    held = doc.aot("entries")
    doc["entries"] = "REPLACED"
    held.add({"k": 999})
    assert tomlrt.dumps(doc) == 'entries = "REPLACED"\n'
