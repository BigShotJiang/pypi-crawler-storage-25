"""
BSG-IDE - Beamer Slide Generator IDE - Create professional LaTeX presentations with multimedia support
Version: 5.1.2
"""

__version__ = "5.1.2"
__author__ = "Ninan Sajeeth Philip"
__license__ = "MIT"

from .BSG_IDE import BeamerSlideEditor, launch_ide
from .BeamerSlideGenerator import get_beamer_preamble, process_media, process_input_file

__all__ = [
    "BeamerSlideEditor",
    "launch_ide",
    "get_beamer_preamble",
    "process_media",
    "process_input_file",
]