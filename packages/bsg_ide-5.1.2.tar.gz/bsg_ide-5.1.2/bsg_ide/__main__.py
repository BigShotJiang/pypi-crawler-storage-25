"""Main entry point"""

from .BSG_IDE import launch_ide

if __name__ == "__main__":
    launch_ide()