#!/usr/bin/env python3
from setuptools import setup, find_packages
from pathlib import Path

__version__ = "5.1.2"

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else "Beamer Slide Generator IDE - Create professional LaTeX presentations with multimedia support"

setup(
    name="bsg-ide",
    version=__version__,
    author="Ninan Sajeeth Philip",
    author_email="nsp@airis4d.com",
    description="Beamer Slide Generator IDE - Create professional LaTeX presentations with multimedia support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/sajeethphilip/Beamer-Slide-Generator",
    license="MIT",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "bsg_ide": ["resources/*.png", "*.py"],
    },
    install_requires=[
        "customtkinter>=5.2.0",
        "Pillow>=9.0.0",
        "requests>=2.25.0",
        "latexcodec>=2.0.0",
    ],
    extras_require={
        "full": ["opencv-python>=4.5.0", "yt-dlp>=2023.0.0", "pyspellchecker>=0.7.0", "PyMuPDF>=1.23.0"],
        "video": ["opencv-python>=4.5.0", "yt-dlp>=2023.0.0"],
        "spellcheck": ["pyspellchecker>=0.7.0"],
        "pdf": ["PyMuPDF>=1.23.0"],
    },
    entry_points={
        "console_scripts": [
            "bsg-ide = bsg_ide.BSG_IDE:launch_ide",
            "bsg = bsg_ide.BSG_IDE:launch_ide",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
    ],
    keywords="latex beamer presentation slides generator ide",
    zip_safe=False,
)