import random

def generate_numbers(config):
    """
    Generate lottery numbers based on a config dict.

    Required keys:
        white_min, white_max, white_count

    Optional keys:
        replace (bool) – default False
        special_name (str or None)
        special_max (int) – required only if special_name is not None
    """

    w_min = config["white_min"]
    w_max = config["white_max"]
    w_count = config["white_count"]

    # Default replace to False if not provided
    replace = config.get("replace", False)

    if replace:
        white_balls = [random.randint(w_min, w_max) for _ in range(w_count)]
    else:
        white_balls = random.sample(range(w_min, w_max + 1), w_count)

    special_name = config.get("special_name")
    special = None

    if special_name:
        s_max = config["special_max"]
        special = random.randint(1, s_max)

    return white_balls, special
