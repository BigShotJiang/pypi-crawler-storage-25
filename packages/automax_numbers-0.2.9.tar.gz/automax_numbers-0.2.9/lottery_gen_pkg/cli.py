from .core import generate_numbers

GAME_CONFIG = {
    "1": {
        "name": "Powerball",
        "white_min": 1,
        "white_max": 69,
        "white_count": 5,
        "special_name": "Powerball",
        "special_max": 26,
        "replace": False,
    },
    "2": {
        "name": "Mega Millions",
        "white_min": 1,
        "white_max": 70,
        "white_count": 5,
        "special_name": "Mega Ball",
        "special_max": 25,
        "replace": False,
    },
    "3": {
        "name": "Multi-Match",
        "white_min": 1,
        "white_max": 43,
        "white_count": 6,
        "special_name": None,
        "special_max": None,
        "replace": False,
    },
}

def main():
    print("\n--- Lottery Number Generator ---")
    print("1. Powerball")
    print("2. Mega Millions")
    print("3. Multi-Match")
    print("Q. Quit")

    choice = input("\nSelect a game: ").strip()

    if choice.upper() == "Q":
        return

    if choice not in GAME_CONFIG:
        print("Invalid choice.")
        return

    config = GAME_CONFIG[choice]
    white_balls, special = generate_numbers(config)

    print(f"\n--- {config['name']} ---")
    print("White balls:", white_balls)

    if config["special_name"] and special is not None:
        print(f"{config['special_name']}: {special}")

