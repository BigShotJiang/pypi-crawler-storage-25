from .core import generate_numbers

__all__ = ["generate_numbers"]


