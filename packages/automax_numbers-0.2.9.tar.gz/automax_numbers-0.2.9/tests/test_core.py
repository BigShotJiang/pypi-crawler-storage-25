import pytest
from lottery_gen_pkg.core import generate_numbers


def test_basic_white_ball_generation():
    config = {
        "white_min": 1,
        "white_max": 10,
        "white_count": 5,
        "special_name": None,
    }

    white_balls, special = generate_numbers(config)

    assert len(white_balls) == 5
    assert all(1 <= n <= 10 for n in white_balls)
    assert special is None


def test_no_replace_logic():
    config = {
        "white_min": 1,
        "white_max": 20,
        "white_count": 5,
        "special_name": None,
        # replace omitted → defaults to False
    }

    white_balls, _ = generate_numbers(config)

    # sample() guarantees uniqueness
    assert len(white_balls) == len(set(white_balls))


def test_with_special_ball():
    config = {
        "white_min": 1,
        "white_max": 69,
        "white_count": 5,
        "special_name": "Powerball",
        "special_max": 26,
    }

    white_balls, special = generate_numbers(config)

    assert len(white_balls) == 5
    assert 1 <= special <= 26


def test_replace_true_allows_duplicates():
    config = {
        "white_min": 1,
        "white_max": 5,
        "white_count": 10,
        "replace": True,
        "special_name": None,
    }

    white_balls, _ = generate_numbers(config)

    # duplicates allowed when replace=True
    assert len(white_balls) == 10
    assert any(white_balls.count(n) > 1 for n in set(white_balls))
