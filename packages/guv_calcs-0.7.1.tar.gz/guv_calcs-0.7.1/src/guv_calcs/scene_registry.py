from dataclasses import dataclass, field
from collections.abc import MutableMapping, Iterator
from typing import Generic, TypeVar, Optional, Dict, Callable
import warnings

import numpy as np

from .geometry import RoomDimensions
from .lamp import Lamp
from .calc_zone import CalcZone
from .reflectance import Surface
from .object import Object


T = TypeVar("T")


@dataclass(eq=False)
class Registry(Generic[T], MutableMapping[str, T]):
    """A thin wrapper around dict[str, T] with consistent ID/collision behavior."""

    base_id = "item"
    expected_type: type | None = None
    on_collision: str = "increment"  # "error" | "overwrite" | "increment"
    dims: Optional[Callable[[], "RoomDimensions"]] = None
    _items: Dict[str, T] = field(default_factory=dict)

    # ---- MutableMapping protocol ----
    def __getitem__(self, key: str) -> T:
        return self._items[key]

    def __setitem__(self, key: str, value: T) -> None:
        self._items[key] = value

    def __delitem__(self, key: str) -> None:
        del self._items[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def __eq__(self, other):
        if not isinstance(other, Registry):
            return NotImplemented
        return dict(self._items) == dict(other._items)

    def require(self, key: str):
        try:
            return self._items[key]
        except KeyError as e:
            raise KeyError(
                f"Unknown id: {key!r}. Available: {list(self._items.keys())}"
            ) from e

    def remove(self, key: str):
        try:
            return self._items.pop(key)
        except KeyError as e:
            raise KeyError(f"Cannot remove {key!r}; not found.") from e

    def clear(self) -> None:
        self._items.clear()

    def _unique_id(self, base: str) -> str:
        if base not in self._items:
            return base
        prefix = base + "-"
        max_suffix = 1  # 1 corresponds to plain `base` being present
        for key in self.keys():
            if key == base:
                max_suffix = max(max_suffix, 1)
            elif key.startswith(prefix):
                rest = key[len(prefix) :]
                if rest.isdigit():
                    n = int(rest)
                    if n > max_suffix:
                        max_suffix = n
        # Next free number
        return f"{base}-{max_suffix + 1}"

    def _get_coords(self, obj: T) -> np.ndarray | None:
        """Return (N, 3) world-space coordinates for boundary checking."""
        return None

    def check_position(self, obj: T, tol: float = 1e-3) -> str | None:
        """Check object coordinates against room polygon boundary."""
        if self.dims is None:
            return None
        coords = self._get_coords(obj)
        if coords is None or len(coords) == 0:
            return None
        room_dims = self.dims()
        for x, y, z in coords:
            if (not room_dims.polygon.contains_point_inclusive(x, y, tol=tol)
                    or z < -tol or z > room_dims.z + tol):
                msg = f"{obj.name} exceeds room boundaries!"
                warnings.warn(msg, stacklevel=2)
                return msg
        return None

    def get_position_warnings(self, tol: float = 1e-3):
        dct = {}
        for obj_id, obj in self.items():
            dct[obj_id] = self.check_position(obj, tol=tol)
        return dct

    def nudge_into_bounds(self, tol: float = 1e-3):
        """Nudge all items into room bounds. Returns dict of {id: obj} for moved items."""
        if self.dims is None:
            return {}
        room_dims = self.dims()
        moved = {}
        for obj_id, obj in self.items():
            if hasattr(obj, 'nudge_into_bounds'):
                if obj.nudge_into_bounds(room_dims):
                    moved[obj_id] = obj
        return moved

    def _validate(self, obj: T) -> T:
        """Type check + position check. Override for additional validation."""
        if self.expected_type and not isinstance(obj, self.expected_type):
            raise TypeError(f"Must be {self.expected_type.__name__}, not {type(obj).__name__}")
        self.check_position(obj)
        return obj

    def validate(self):
        for obj_id, obj in self.items():
            self._validate(obj)

    def add(self, obj, on_collision=None):
        policy = on_collision or self.on_collision
        obj = self._validate(obj)
        key = getattr(obj, "id", None) or self.base_id
        if key in self._items:
            if policy == "error":
                raise KeyError(f"ID {key!r} already exists.")
            if policy == "increment":
                key = self._unique_id(key)
            # OVERWRITE keeps key as-is
        obj._assign_id(key)
        self._items[key] = obj
        # self.on_added(key, obj)  # hook
        return key

    @property
    def calc_state(self) -> tuple:
        tpl = ()
        for val in self.values():
            if hasattr(val, "calc_state"):
                tpl += val.calc_state
        return tpl

    @property
    def update_state(self) -> tuple:
        tpl = ()
        for val in self.values():
            if hasattr(val, "update_state"):
                tpl += val.update_state
        return tpl


@dataclass(eq=False)
class LampRegistry(Registry["Lamp"]):
    base_id = "Lamp"
    expected_type: type | None = Lamp

    def _get_coords(self, lamp):
        return lamp.geometry.get_bounding_box_corners()

    def _validate(self, lamp):
        lamp = super()._validate(lamp)
        if lamp.surface.units != self.dims().units:
            lamp.set_units(self.dims().units)
        return lamp

    @property
    def wavelengths(self) -> dict:
        return {k: v.wavelength for k, v in self.items()}
        
    def valid(self) -> dict:
        return {k: v for k,v in self.items() if v.enabled and v.ies is not None}

@dataclass(eq=False)
class ZoneRegistry(Registry["CalcZone"]):
    base_id = "CalcZone"
    expected_type: type | None = CalcZone

    def _get_coords(self, zone):
        return zone.coords


@dataclass(eq=False)
class SurfaceRegistry(Registry["Surface"]):
    base_id = "Surface"
    expected_type: type | None = Surface


@dataclass(eq=False)
class ObjectRegistry(Registry[Object]):
    """Registry for Object instances within a Room."""
    base_id = "Object"
    expected_type: type | None = Object

    def _get_coords(self, obj):
        all_verts = []
        for surface in obj.surfaces.values():
            all_verts.append(surface.plane.geometry.boundary_vertices)
        if all_verts:
            return np.vstack(all_verts)
        return None


@dataclass(eq=False)
class RoomRegistry(Registry["Room"]):
    """Registry for Room objects within a Project."""
    base_id = "Room"
    expected_type: type | None = None  # set lazily to avoid circular import

    def _validate(self, room):
        # Lazy import avoids a module-level circular dependency with room.py
        if self.expected_type is None:
            from .room import Room
            self.expected_type = Room
        return super()._validate(room)
