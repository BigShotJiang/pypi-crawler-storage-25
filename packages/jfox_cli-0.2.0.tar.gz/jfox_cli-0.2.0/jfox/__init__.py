"""JFox - Zettelkasten 知识管理工具"""

__version__ = "0.2.0"
__author__ = "User"
__email__ = "user@example.com"
