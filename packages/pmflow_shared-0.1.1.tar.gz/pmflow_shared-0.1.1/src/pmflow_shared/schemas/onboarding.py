from pydantic import BaseModel


class OnboardingChecklistItem(BaseModel):
    key: str
    label: str
    description: str
    completed: bool


class OnboardingRead(BaseModel):
    dismissed: bool
    checklist_items: list[OnboardingChecklistItem]
    all_completed: bool


class OnboardingUpdate(BaseModel):
    dismissed: bool | None = None
