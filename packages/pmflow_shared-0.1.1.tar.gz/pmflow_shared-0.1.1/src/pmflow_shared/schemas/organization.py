import uuid
from datetime import datetime

from pydantic import BaseModel

from pmflow_shared.enums import OrgRole


class OrganizationCreate(BaseModel):
    name: str
    slug: str
    lark_app_id: str
    lark_app_secret: str  # transient, not persisted in DB
    lark_brand: str = "feishu"


class OrganizationRead(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    lark_app_id: str
    lark_brand: str
    lark_folder_token: str | None
    created_by: uuid.UUID
    created_at: datetime
    updated_at: datetime
    my_role: OrgRole | None = None


class OrganizationUpdate(BaseModel):
    name: str | None = None
    lark_folder_token: str | None = None


class OrgMemberRead(BaseModel):
    user_id: uuid.UUID
    email: str
    name: str
    role: OrgRole
    feishu_linked: bool
    joined_at: datetime


class OrgInvitationCreate(BaseModel):
    email: str
    role: OrgRole = OrgRole.MEMBER


class OrgInvitationRead(BaseModel):
    id: uuid.UUID
    organization_id: uuid.UUID
    email: str
    role: OrgRole
    token: str
    invited_by: uuid.UUID
    created_at: datetime
    expires_at: datetime
    accepted_at: datetime | None


class OrgInvitationInfo(BaseModel):
    """Public invitation info (no auth required) for the invite accept page."""
    org_name: str
    org_slug: str
    email: str
    role: OrgRole
    expired: bool
    accepted: bool
