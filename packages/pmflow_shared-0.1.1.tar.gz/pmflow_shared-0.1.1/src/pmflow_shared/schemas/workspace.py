import uuid
from datetime import datetime

from pydantic import BaseModel

from pmflow_shared.enums import WorkspaceRole


class WorkspaceCreate(BaseModel):
    name: str
    slug: str
    description: str | None = None
    organization_id: uuid.UUID | None = None


class WorkspaceUpdate(BaseModel):
    name: str | None = None
    description: str | None = None


class WorkspaceRead(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    description: str | None
    organization_id: uuid.UUID | None
    organization_name: str | None = None
    created_by: uuid.UUID
    created_at: datetime
    updated_at: datetime


class WorkspaceMemberAdd(BaseModel):
    email: str
    role: WorkspaceRole = WorkspaceRole.MEMBER


class WorkspaceMemberRead(BaseModel):
    user_id: uuid.UUID
    role: WorkspaceRole
    joined_at: datetime


class WorkspaceMemberReadWithUser(BaseModel):
    user_id: uuid.UUID
    email: str
    name: str
    role: WorkspaceRole
    joined_at: datetime


class WorkspaceInvitationCreate(BaseModel):
    email: str
    role: WorkspaceRole = WorkspaceRole.MEMBER


class WorkspaceInvitationRead(BaseModel):
    id: uuid.UUID
    workspace_id: uuid.UUID
    email: str
    role: WorkspaceRole
    token: str
    invited_by: uuid.UUID
    created_at: datetime
    expires_at: datetime
    accepted_at: datetime | None


class WorkspaceInvitationInfo(BaseModel):
    """Public invitation info (no auth required) for the invite accept page."""
    workspace_name: str
    workspace_slug: str
    email: str
    role: WorkspaceRole
    expired: bool
    accepted: bool
