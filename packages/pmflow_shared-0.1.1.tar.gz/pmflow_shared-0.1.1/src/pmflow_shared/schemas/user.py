import uuid
from datetime import datetime

from pydantic import BaseModel, EmailStr


class UserCreate(BaseModel):
    email: EmailStr
    name: str
    password: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserRead(BaseModel):
    id: uuid.UUID
    email: str
    name: str
    avatar_url: str | None
    feishu_open_id: str | None = None
    is_active: bool
    onboarding_completed: bool
    created_at: datetime


# --- Auth response schemas ---


class AuthResponse(BaseModel):
    user: UserRead
    message: str = "ok"


# --- API Token schemas ---


class TokenCreate(BaseModel):
    name: str
    expires_in_days: int | None = None


class TokenRead(BaseModel):
    id: uuid.UUID
    name: str
    token_prefix: str
    token_plain: str
    last_used_at: datetime | None
    expires_at: datetime | None
    is_active: bool
    created_at: datetime
