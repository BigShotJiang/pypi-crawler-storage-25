import uuid
from datetime import datetime

from pydantic import BaseModel

from pmflow_shared.enums import IssueStatus, IssueType


class IssueCreate(BaseModel):
    title: str
    description: str | None = None
    type: IssueType = IssueType.TASK
    priority: int = 0
    assignee_id: uuid.UUID | None = None
    parent_id: uuid.UUID | None = None


class IssueUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    type: IssueType | None = None
    priority: int | None = None
    assignee_id: uuid.UUID | None = None
    parent_id: uuid.UUID | None = None


class IssueStatusUpdate(BaseModel):
    status: IssueStatus


class IssueRead(BaseModel):
    id: uuid.UUID
    workspace_id: uuid.UUID
    title: str
    description: str | None
    type: IssueType
    status: IssueStatus
    priority: int
    assignee_id: uuid.UUID | None
    parent_id: uuid.UUID | None
    sequence_num: int
    created_by: uuid.UUID
    created_at: datetime
    updated_at: datetime


class IssueListResponse(BaseModel):
    issues: list[IssueRead]
    done_total: int
