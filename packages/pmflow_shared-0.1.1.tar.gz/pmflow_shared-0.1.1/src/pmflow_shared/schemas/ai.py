import uuid
from datetime import datetime

from pydantic import BaseModel

from pmflow_shared.enums import MessageRole


class ConversationCreate(BaseModel):
    title: str
    purpose: str = "prd"


class ConversationRead(BaseModel):
    id: uuid.UUID
    issue_id: uuid.UUID | None
    workspace_id: uuid.UUID | None
    title: str
    purpose: str
    created_by: uuid.UUID
    created_at: datetime


class SendMessage(BaseModel):
    content: str


class MessageRead(BaseModel):
    id: uuid.UUID
    conversation_id: uuid.UUID
    role: MessageRole
    content: str
    extra_data: dict | None
    created_at: datetime
