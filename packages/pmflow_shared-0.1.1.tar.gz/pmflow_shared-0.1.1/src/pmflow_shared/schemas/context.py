import uuid
from datetime import datetime

from pydantic import BaseModel

from pmflow_shared.enums import ContextType


class ContextCreate(BaseModel):
    type: ContextType
    title: str
    description: str | None = None
    feishu_doc_token: str | None = None
    feishu_doc_url: str | None = None
    url: str | None = None
    content: str | None = None


class LinkFeishuDocBody(BaseModel):
    """Create/update a Feishu doc with content, or link an existing one."""
    title: str
    markdown: str | None = None
    feishu_doc_url: str | None = None
    feishu_doc_token: str | None = None
    create_new: bool = False


class ContextRead(BaseModel):
    id: uuid.UUID
    issue_id: uuid.UUID | None
    workspace_id: uuid.UUID | None
    type: ContextType
    title: str
    description: str | None
    feishu_doc_token: str | None
    feishu_doc_url: str | None
    storage_key: str | None
    file_name: str | None
    file_size: int | None
    mime_type: str | None
    url: str | None
    content: str | None
    created_by: uuid.UUID
    created_at: datetime
    updated_at: datetime
