from enum import Enum


class IssueStatus(str, Enum):
    TODO = "todo"
    DOING = "doing"
    DONE = "done"
    BLOCKED = "blocked"


class IssueType(str, Enum):
    FEATURE = "feature"
    BUG = "bug"
    TASK = "task"
    EPIC = "epic"


class ContextType(str, Enum):
    FEISHU_DOC = "feishu_doc"
    IMAGE = "image"
    AUDIO = "audio"
    MARKDOWN = "markdown"
    FEISHU_SHEET = "feishu_sheet"
    EXCEL = "excel"
    HTML_PROTOTYPE = "html_prototype"
    OTHER_FILE = "other_file"


class WorkspaceRole(str, Enum):
    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"


class OrgRole(str, Enum):
    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"


class MessageRole(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
