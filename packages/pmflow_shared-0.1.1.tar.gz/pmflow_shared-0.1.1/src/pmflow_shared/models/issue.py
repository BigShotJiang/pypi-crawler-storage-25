import uuid

from sqlalchemy import UniqueConstraint
from sqlmodel import Field, SQLModel

from pmflow_shared.enums import IssueStatus, IssueType
from pmflow_shared.models.base import TimestampMixin, new_uuid


class Issue(TimestampMixin, SQLModel, table=True):
    __table_args__ = (
        UniqueConstraint("workspace_id", "sequence_num", name="uq_issue_workspace_seq"),
    )

    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    workspace_id: uuid.UUID = Field(foreign_key="workspace.id", index=True)
    title: str
    description: str | None = None
    type: IssueType = Field(default=IssueType.TASK)
    status: IssueStatus = Field(default=IssueStatus.TODO, index=True)
    priority: int = Field(default=0)
    assignee_id: uuid.UUID | None = Field(default=None, foreign_key="user.id")
    parent_id: uuid.UUID | None = Field(default=None, foreign_key="issue.id")
    sequence_num: int
    created_by: uuid.UUID = Field(foreign_key="user.id")
