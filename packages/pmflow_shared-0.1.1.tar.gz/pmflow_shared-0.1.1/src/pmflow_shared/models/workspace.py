import uuid
from datetime import datetime, timedelta
from secrets import token_urlsafe

from sqlmodel import Field, SQLModel

from pmflow_shared.enums import WorkspaceRole
from pmflow_shared.models.base import TimestampMixin, new_uuid


def _default_expires_at() -> datetime:
    return datetime.utcnow() + timedelta(days=7)


class Workspace(TimestampMixin, SQLModel, table=True):
    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    name: str = Field(index=True)
    slug: str = Field(unique=True, index=True)
    description: str | None = None
    created_by: uuid.UUID = Field(foreign_key="user.id")
    organization_id: uuid.UUID | None = Field(default=None, foreign_key="organization.id", index=True)
    issue_counter: int = Field(default=0)


class WorkspaceMember(SQLModel, table=True):
    __tablename__ = "workspace_member"

    workspace_id: uuid.UUID = Field(foreign_key="workspace.id", primary_key=True)
    user_id: uuid.UUID = Field(foreign_key="user.id", primary_key=True)
    role: WorkspaceRole = Field(default=WorkspaceRole.MEMBER)
    joined_at: datetime = Field(default_factory=datetime.utcnow)


class WorkspaceInvitation(SQLModel, table=True):
    __tablename__ = "workspace_invitation"

    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    workspace_id: uuid.UUID = Field(foreign_key="workspace.id", index=True)
    email: str = Field(index=True)
    role: WorkspaceRole = Field(default=WorkspaceRole.MEMBER)
    token: str = Field(default_factory=lambda: token_urlsafe(32), unique=True, index=True)
    invited_by: uuid.UUID = Field(foreign_key="user.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime = Field(default_factory=_default_expires_at)
    accepted_at: datetime | None = None
