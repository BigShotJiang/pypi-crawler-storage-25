import uuid
from datetime import datetime

from sqlmodel import Field, SQLModel

from pmflow_shared.models.base import new_uuid


class ApiToken(SQLModel, table=True):
    __tablename__ = "api_token"

    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    user_id: uuid.UUID = Field(foreign_key="user.id", index=True)
    name: str
    token_hash: str = Field(unique=True, index=True)
    token_prefix: str
    token_plain: str = Field(default="")
    last_used_at: datetime | None = None
    expires_at: datetime | None = None
    is_active: bool = Field(default=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
