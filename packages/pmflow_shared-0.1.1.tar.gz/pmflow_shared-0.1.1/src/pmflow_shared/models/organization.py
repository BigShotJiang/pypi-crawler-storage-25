import uuid
from datetime import datetime, timedelta
from secrets import token_urlsafe

from sqlmodel import Field, SQLModel

from pmflow_shared.enums import OrgRole
from pmflow_shared.models.base import TimestampMixin, new_uuid


def _default_expires_at() -> datetime:
    return datetime.utcnow() + timedelta(days=7)


class Organization(TimestampMixin, SQLModel, table=True):
    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    name: str = Field(index=True)
    slug: str = Field(unique=True, index=True)
    lark_app_id: str = Field(unique=True, index=True)
    lark_brand: str = Field(default="feishu")
    lark_folder_token: str | None = None
    created_by: uuid.UUID | None = Field(default=None, foreign_key="user.id")
    is_system: bool = Field(default=False)


class OrgMember(SQLModel, table=True):
    __tablename__ = "org_member"

    organization_id: uuid.UUID = Field(foreign_key="organization.id", primary_key=True)
    user_id: uuid.UUID = Field(foreign_key="user.id", primary_key=True)
    role: OrgRole = Field(default=OrgRole.MEMBER)
    feishu_open_id: str | None = None
    joined_at: datetime = Field(default_factory=datetime.utcnow)


class OrgInvitation(SQLModel, table=True):
    __tablename__ = "org_invitation"

    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    organization_id: uuid.UUID = Field(foreign_key="organization.id", index=True)
    email: str = Field(index=True)
    role: OrgRole = Field(default=OrgRole.MEMBER)
    token: str = Field(default_factory=lambda: token_urlsafe(32), unique=True, index=True)
    invited_by: uuid.UUID = Field(foreign_key="user.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime = Field(default_factory=_default_expires_at)
    accepted_at: datetime | None = None
