import uuid
from datetime import datetime

from sqlmodel import Field, SQLModel


class SpaceOnboarding(SQLModel, table=True):
    __tablename__ = "space_onboarding"

    workspace_id: uuid.UUID = Field(foreign_key="workspace.id", primary_key=True)
    user_id: uuid.UUID = Field(foreign_key="user.id", primary_key=True)
    coach_marks_completed: bool = Field(default=False)
    checklist_dismissed: bool = Field(default=False)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
