import uuid

from sqlalchemy import CheckConstraint
from sqlmodel import Field, SQLModel

from pmflow_shared.enums import ContextType
from pmflow_shared.models.base import TimestampMixin, new_uuid


class Context(TimestampMixin, SQLModel, table=True):
    __table_args__ = (
        CheckConstraint(
            "issue_id IS NOT NULL OR workspace_id IS NOT NULL",
            name="ck_context_has_scope",
        ),
    )

    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    issue_id: uuid.UUID | None = Field(default=None, foreign_key="issue.id", index=True)
    workspace_id: uuid.UUID | None = Field(default=None, foreign_key="workspace.id", index=True)
    type: ContextType
    title: str
    description: str | None = None

    # type=feishu_doc / feishu_sheet
    feishu_doc_token: str | None = None
    feishu_doc_url: str | None = None

    # type=image / audio / excel / other_file
    storage_key: str | None = None
    file_name: str | None = None
    file_size: int | None = None
    mime_type: str | None = None

    # all types: optional external URL
    url: str | None = None

    # type=markdown
    content: str | None = None

    created_by: uuid.UUID = Field(foreign_key="user.id")
