import uuid

from sqlmodel import Field, SQLModel

from pmflow_shared.models.base import TimestampMixin, new_uuid


class User(TimestampMixin, SQLModel, table=True):
    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    email: str = Field(unique=True, index=True)
    name: str
    hashed_password: str
    avatar_url: str | None = None
    feishu_open_id: str | None = Field(default=None, index=True)
    is_active: bool = Field(default=True)
    onboarding_completed: bool = Field(default=False)
