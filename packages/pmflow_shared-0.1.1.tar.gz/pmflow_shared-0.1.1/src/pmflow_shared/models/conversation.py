import uuid
from datetime import datetime

from sqlalchemy import Column
from sqlalchemy.types import JSON
from sqlmodel import Field, SQLModel

from pmflow_shared.enums import MessageRole
from pmflow_shared.models.base import new_uuid


class Conversation(SQLModel, table=True):
    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    issue_id: uuid.UUID | None = Field(default=None, foreign_key="issue.id", index=True)
    workspace_id: uuid.UUID | None = Field(default=None, foreign_key="workspace.id", index=True)
    title: str
    purpose: str = Field(default="prd")
    created_by: uuid.UUID = Field(foreign_key="user.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Message(SQLModel, table=True):
    id: uuid.UUID = Field(default_factory=new_uuid, primary_key=True)
    conversation_id: uuid.UUID = Field(foreign_key="conversation.id", index=True)
    role: MessageRole
    content: str
    extra_data: dict | None = Field(default=None, sa_column=Column("extra_data", JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)
