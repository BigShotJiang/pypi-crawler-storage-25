# pmflow-shared

Shared models, schemas, and enums for [pmflow](https://github.com/zhanglaixian/pmflow) — an integrated project management and AI-assisted development platform.

This package is primarily used as a dependency by `pmflow-cli` and `pmflow-server`. You typically don't need to install it directly.

## Installation

```bash
pip install pmflow-shared
```
