"""OneShotClient — HTTP client with x402 payment flow.

Ports the ``OneShot`` class from ``libs/agent-sdk/src/index.ts``.
Handles: quote -> pay -> poll lifecycle for paid tools, and simple
GET/POST for free endpoints.
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Optional

import httpx
from eth_account import Account

from oneshot._errors import (
    ContentBlockedError,
    JobError,
    JobTimeoutError,
    OneShotError,
    ToolError,
    ValidationError,
)
from oneshot.x402 import (
    build_zero_cost_authorization,
    encode_payment_header,
    parse_payment_required,
    sign_payment_authorization,
)

SDK_VERSION = "0.8.3"

# ---------------------------------------------------------------------------
# Environment configuration
# ---------------------------------------------------------------------------

_BASE_URL = "https://win.oneshotagent.com"
_CHAIN_ID = 8453
_USDC_ADDRESS = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"

_POLL_INTERVAL = 2.0  # seconds
_MAX_POLL_RETRIES = 3


class OneShotClient:
    """Synchronous + async HTTP client for the OneShot API.

    Supports the full x402 quote-then-pay lifecycle for paid tools and
    simple requests for free endpoints.
    """

    def __init__(
        self,
        private_key: str,
        *,
        base_url: Optional[str] = None,
        debug: bool = False,
    ) -> None:
        self.base_url = base_url or _BASE_URL
        self.chain_id: int = _CHAIN_ID
        self.usdc_address: str = _USDC_ADDRESS
        self.debug = debug

        # Derive wallet address from private key
        self._private_key = private_key
        acct = Account.from_key(private_key)
        self.address: str = acct.address

    # ------------------------------------------------------------------
    # Headers
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        return {
            "Content-Type": "application/json",
            "X-Agent-ID": self.address,
            "X-OneShot-SDK-Version": SDK_VERSION,
        }

    def _log(self, msg: str) -> None:
        if self.debug:
            print(f"[OneShot] {msg}")

    # ------------------------------------------------------------------
    # Paid tool flow  (POST -> 402 -> sign -> POST w/ payment -> poll)
    # ------------------------------------------------------------------

    def call_tool(
        self,
        endpoint: str,
        payload: dict[str, Any],
        *,
        max_cost: Optional[float] = None,
        timeout_sec: int = 120,
        wait_for_phones: bool = False,
        phone_timeout_sec: int = 360,
    ) -> Any:
        """Execute a paid tool call (blocking). Handles the full x402 flow.

        Set ``wait_for_phones=True`` to keep polling AFTER status=completed
        until Apollo's async phone-reveal webhook delivers phone numbers
        (or until ``phone_timeout_sec`` expires, default 6 min — Apollo says
        "several minutes"). Default is False for backwards compat.
        """
        return asyncio.get_event_loop().run_until_complete(
            self.acall_tool(
                endpoint,
                payload,
                max_cost=max_cost,
                timeout_sec=timeout_sec,
                wait_for_phones=wait_for_phones,
                phone_timeout_sec=phone_timeout_sec,
            )
        )

    async def acall_tool(
        self,
        endpoint: str,
        payload: dict[str, Any],
        *,
        max_cost: Optional[float] = None,
        timeout_sec: int = 120,
        wait_for_phones: bool = False,
        phone_timeout_sec: int = 360,
    ) -> Any:
        """Execute a paid tool call (async). Handles the full x402 flow."""
        url = f"{self.base_url}{endpoint}"

        async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
            # Step 1 — Initial POST (expect 402 for paid tools)
            resp = await client.post(url, headers=self._headers(), json=payload)

            # Handle validation / content-blocked errors
            if resp.status_code == 400:
                data = resp.json()
                err_type = data.get("error", "")
                if err_type == "content_blocked":
                    raise ContentBlockedError(
                        data.get("message", "Content blocked"),
                        data.get("categories", []),
                    )
                raise ValidationError(
                    data.get("message", "Invalid request"), "request"
                )

            # If not 402, this might be a free tool that returned directly
            if resp.status_code != 402:
                resp.raise_for_status()
                result = resp.json()
                # Handle async jobs
                if isinstance(result, dict) and result.get("request_id") and result.get("status") in (
                    "pending",
                    "processing",
                ):
                    return await self._poll_job(
                        client,
                        result["request_id"],
                        timeout_sec,
                        wait_for_phones=wait_for_phones,
                        phone_timeout_sec=phone_timeout_sec,
                    )
                return result.get("data", result)

            # Step 2 — Parse 402 response
            # Parse x402 v2 PaymentRequired from PAYMENT-REQUIRED header
            parsed_req = parse_payment_required(
                resp.headers.get("payment-required")
            )
            accepted = parsed_req["accepted"]

            quote_data = resp.json()
            payment_request = quote_data["payment_request"]
            context = quote_data.get("context", {})
            quote_id = context.get("quote_id")

            # Check max_cost
            total = context.get("total") or context.get("pricing", {}).get("total")
            if max_cost is not None and total is not None:
                if float(total) > max_cost:
                    raise OneShotError(
                        f"Quote ${total} exceeds max_cost ${max_cost}"
                    )

            self._log(f"Payment required: {payment_request['amount']} USDC")

            # Step 3 — Sign x402 payment (zero-cost auth if credits cover full cost)
            amount = float(payment_request["amount"])
            if amount == 0:
                self._log("Credits cover full cost — sending zero-cost authorization")
                auth = build_zero_cost_authorization(
                    from_address=self.address,
                    to_address=payment_request["recipient"],
                    accepted=accepted,
                    resource=parsed_req.get("resource"),
                    extensions=parsed_req.get("extensions"),
                )
                headers = {
                    **self._headers(),
                    "payment-signature": encode_payment_header(auth),
                }
                if quote_id:
                    headers["x-quote-id"] = quote_id
                resp2 = await client.post(url, headers=headers, json=payload)
            else:
                auth = sign_payment_authorization(
                    private_key=self._private_key,
                    from_address=self.address,
                    to_address=payment_request["recipient"],
                    amount=payment_request["amount"],
                    token_address=payment_request["token_address"],
                    chain_id=payment_request["chain_id"],
                    network=f"eip155:{payment_request['chain_id']}",
                    accepted=accepted,
                    resource=parsed_req.get("resource"),
                    extensions=parsed_req.get("extensions"),
                )

                # Step 4 — Re-POST with payment headers (x402 format)
                headers = {
                    **self._headers(),
                    "payment-signature": encode_payment_header(auth),
                }
                if quote_id:
                    headers["x-quote-id"] = quote_id

                resp2 = await client.post(url, headers=headers, json=payload)

            if resp2.status_code not in (200, 201, 202):
                raise ToolError(
                    "Tool request failed after payment",
                    resp2.status_code,
                    resp2.text,
                )

            result = resp2.json()

            # Step 5 — Poll if async job
            if isinstance(result, dict) and result.get("request_id") and result.get("status") in (
                "pending",
                "processing",
            ):
                self._log(f"Job queued: {result['request_id']}")
                return await self._poll_job(
                    client,
                    result["request_id"],
                    timeout_sec,
                    wait_for_phones=wait_for_phones,
                    phone_timeout_sec=phone_timeout_sec,
                )

            return result.get("data", result)

    # ------------------------------------------------------------------
    # Free endpoint helpers
    # ------------------------------------------------------------------

    def call_free_get(
        self,
        endpoint: str,
        params: Optional[dict[str, str]] = None,
    ) -> Any:
        """GET a free endpoint (blocking)."""
        return asyncio.get_event_loop().run_until_complete(
            self.acall_free_get(endpoint, params)
        )

    async def acall_free_get(
        self,
        endpoint: str,
        params: Optional[dict[str, str]] = None,
    ) -> Any:
        """GET a free endpoint (async)."""
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
            resp = await client.get(url, headers=self._headers(), params=params)
            if not resp.is_success:
                raise ToolError(f"GET {endpoint} failed", resp.status_code, resp.text)
            return resp.json()

    def call_free_post(
        self,
        endpoint: str,
        payload: Optional[dict[str, Any]] = None,
    ) -> Any:
        """POST to a free endpoint (blocking)."""
        return asyncio.get_event_loop().run_until_complete(
            self.acall_free_post(endpoint, payload)
        )

    async def acall_free_post(
        self,
        endpoint: str,
        payload: Optional[dict[str, Any]] = None,
    ) -> Any:
        """POST to a free endpoint (async)."""
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
            resp = await client.post(url, headers=self._headers(), json=payload or {})
            if not resp.is_success:
                raise ToolError(f"POST {endpoint} failed", resp.status_code, resp.text)
            return resp.json()

    def call_free_patch(
        self,
        endpoint: str,
        payload: Optional[dict[str, Any]] = None,
    ) -> Any:
        """PATCH a free endpoint (blocking)."""
        return asyncio.get_event_loop().run_until_complete(
            self.acall_free_patch(endpoint, payload)
        )

    async def acall_free_patch(
        self,
        endpoint: str,
        payload: Optional[dict[str, Any]] = None,
    ) -> Any:
        """PATCH a free endpoint (async)."""
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
            resp = await client.patch(url, headers=self._headers(), json=payload or {})
            if not resp.is_success:
                raise ToolError(f"PATCH {endpoint} failed", resp.status_code, resp.text)
            # PATCH may return empty body (204)
            if resp.status_code == 204 or not resp.text:
                return {"success": True}
            return resp.json()

    def call_free_delete(
        self,
        endpoint: str,
    ) -> Any:
        """DELETE a free endpoint (blocking)."""
        return asyncio.get_event_loop().run_until_complete(
            self.acall_free_delete(endpoint)
        )

    async def acall_free_delete(
        self,
        endpoint: str,
    ) -> Any:
        """DELETE a free endpoint (async)."""
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as client:
            resp = await client.delete(url, headers=self._headers())
            if not resp.is_success:
                raise ToolError(f"DELETE {endpoint} failed", resp.status_code, resp.text)
            if resp.status_code == 204 or not resp.text:
                return {"success": True}
            return resp.json()

    # ------------------------------------------------------------------
    # Browser
    # ------------------------------------------------------------------

    def browser(
        self,
        task: str,
        *,
        output_schema: Optional[dict[str, Any]] = None,
        start_url: Optional[str] = None,
        allowed_domains: Optional[list[str]] = None,
        profile_id: Optional[str] = None,
        secrets: Optional[dict[str, str]] = None,
        max_steps: Optional[int] = None,
        max_cost: Optional[float] = None,
        timeout_sec: int = 300,
    ) -> Any:
        """Run a browser automation task. Blocking."""
        return asyncio.get_event_loop().run_until_complete(
            self.abrowser(
                task, output_schema=output_schema, start_url=start_url,
                allowed_domains=allowed_domains, profile_id=profile_id,
                secrets=secrets, max_steps=max_steps, max_cost=max_cost,
                timeout_sec=timeout_sec,
            )
        )

    async def abrowser(
        self,
        task: str,
        *,
        output_schema: Optional[dict[str, Any]] = None,
        start_url: Optional[str] = None,
        allowed_domains: Optional[list[str]] = None,
        profile_id: Optional[str] = None,
        secrets: Optional[dict[str, str]] = None,
        max_steps: Optional[int] = None,
        max_cost: Optional[float] = None,
        timeout_sec: int = 300,
    ) -> Any:
        """Run a browser automation task. Async."""
        payload: dict[str, Any] = {"task": task}
        if output_schema is not None:
            payload["output_schema"] = output_schema
        if start_url is not None:
            payload["start_url"] = start_url
        if allowed_domains is not None:
            payload["allowed_domains"] = allowed_domains
        if profile_id is not None:
            payload["profile_id"] = profile_id
        if secrets is not None:
            payload["secrets"] = secrets
        if max_steps is not None:
            payload["max_steps"] = max_steps
        return await self.acall_tool(
            "/v1/tools/browser", payload, max_cost=max_cost, timeout_sec=timeout_sec,
        )

    def create_browser_profile(self, name: str) -> dict:
        """Create a persistent browser profile. Blocking."""
        return self.call_free_post("/v1/tools/browser/profiles", {"name": name})

    async def acreate_browser_profile(self, name: str) -> dict:
        """Create a persistent browser profile. Async."""
        return await self.acall_free_post("/v1/tools/browser/profiles", {"name": name})

    def list_browser_profiles(self) -> list:
        """List all browser profiles. Blocking."""
        return self.call_free_get("/v1/tools/browser/profiles")

    async def alist_browser_profiles(self) -> list:
        """List all browser profiles. Async."""
        return await self.acall_free_get("/v1/tools/browser/profiles")

    def delete_browser_profile(self, profile_id: str) -> dict:
        """Delete a browser profile. Blocking."""
        return self.call_free_delete(f"/v1/tools/browser/profiles/{profile_id}")

    async def adelete_browser_profile(self, profile_id: str) -> dict:
        """Delete a browser profile. Async."""
        return await self.acall_free_delete(f"/v1/tools/browser/profiles/{profile_id}")

    # ------------------------------------------------------------------
    # Paid tool convenience methods
    # ------------------------------------------------------------------

    def research(self, topic: str, *, depth: str = "deep", **kwargs: Any) -> Any:
        """Run deep web research on a topic. Blocking."""
        return self.call_tool("/v1/tools/research", {"topic": topic, "depth": depth, **kwargs})

    async def aresearch(self, topic: str, *, depth: str = "deep", **kwargs: Any) -> Any:
        """Run deep web research on a topic. Async."""
        return await self.acall_tool("/v1/tools/research", {"topic": topic, "depth": depth, **kwargs})

    def web_search(self, query: str, *, max_results: int = 5, **kwargs: Any) -> Any:
        """Search the web. Blocking."""
        return self.call_tool("/v1/tools/search", {"query": query, "max_results": max_results, **kwargs})

    async def aweb_search(self, query: str, *, max_results: int = 5, **kwargs: Any) -> Any:
        """Search the web. Async."""
        return await self.acall_tool("/v1/tools/search", {"query": query, "max_results": max_results, **kwargs})

    def web_read(self, url: str, **kwargs: Any) -> Any:
        """Read a web page and extract content as markdown. Blocking."""
        return self.call_tool("/v1/tools/web-read", {"url": url, **kwargs})

    async def aweb_read(self, url: str, **kwargs: Any) -> Any:
        """Read a web page and extract content as markdown. Async."""
        return await self.acall_tool("/v1/tools/web-read", {"url": url, **kwargs})

    def email(self, to: str, subject: str, body: str, *, from_domain: Optional[str] = None, **kwargs: Any) -> Any:
        """Send an email. Blocking."""
        payload: dict[str, Any] = {"to": to, "subject": subject, "body": body, **kwargs}
        if from_domain:
            payload["from_domain"] = from_domain
        return self.call_tool("/v1/tools/email/send", payload)

    async def aemail(self, to: str, subject: str, body: str, *, from_domain: Optional[str] = None, **kwargs: Any) -> Any:
        """Send an email. Async."""
        payload: dict[str, Any] = {"to": to, "subject": subject, "body": body, **kwargs}
        if from_domain:
            payload["from_domain"] = from_domain
        return await self.acall_tool("/v1/tools/email/send", payload)

    def voice(self, objective: str, target_number: str, **kwargs: Any) -> Any:
        """Make an AI voice call. Blocking."""
        return self.call_tool("/v1/tools/voice/call", {"objective": objective, "target_number": target_number, **kwargs})

    async def avoice(self, objective: str, target_number: str, **kwargs: Any) -> Any:
        """Make an AI voice call. Async."""
        return await self.acall_tool("/v1/tools/voice/call", {"objective": objective, "target_number": target_number, **kwargs})

    def sms(self, message: str, to_number: str, **kwargs: Any) -> Any:
        """Send an SMS message. Blocking."""
        return self.call_tool("/v1/tools/sms/send", {"message": message, "to_number": to_number, **kwargs})

    async def asms(self, message: str, to_number: str, **kwargs: Any) -> Any:
        """Send an SMS message. Async."""
        return await self.acall_tool("/v1/tools/sms/send", {"message": message, "to_number": to_number, **kwargs})

    def people_search(self, **kwargs: Any) -> Any:
        """Search for people by job title, company, etc. Blocking."""
        return self.call_tool("/v1/tools/research/people", kwargs)

    async def apeople_search(self, **kwargs: Any) -> Any:
        """Search for people by job title, company, etc. Async."""
        return await self.acall_tool("/v1/tools/research/people", kwargs)

    def enrich_profile(self, **kwargs: Any) -> Any:
        """Enrich a person's profile from LinkedIn URL, email, or name. Blocking."""
        return self.call_tool("/v1/tools/enrich/profile", kwargs)

    async def aenrich_profile(self, **kwargs: Any) -> Any:
        """Enrich a person's profile from LinkedIn URL, email, or name. Async."""
        return await self.acall_tool("/v1/tools/enrich/profile", kwargs)

    def find_email(self, company_domain: str, *, full_name: Optional[str] = None, first_name: Optional[str] = None, last_name: Optional[str] = None, **kwargs: Any) -> Any:
        """Find a person's email address. Blocking."""
        payload: dict[str, Any] = {"company_domain": company_domain, **kwargs}
        if full_name:
            payload["full_name"] = full_name
        if first_name:
            payload["first_name"] = first_name
        if last_name:
            payload["last_name"] = last_name
        return self.call_tool("/v1/tools/enrich/email", payload)

    async def afind_email(self, company_domain: str, *, full_name: Optional[str] = None, first_name: Optional[str] = None, last_name: Optional[str] = None, **kwargs: Any) -> Any:
        """Find a person's email address. Async."""
        payload: dict[str, Any] = {"company_domain": company_domain, **kwargs}
        if full_name:
            payload["full_name"] = full_name
        if first_name:
            payload["first_name"] = first_name
        if last_name:
            payload["last_name"] = last_name
        return await self.acall_tool("/v1/tools/enrich/email", payload)

    def verify_email(self, email: str) -> Any:
        """Verify email deliverability. Blocking."""
        return self.call_tool("/v1/tools/verify/email", {"email": email})

    async def averify_email(self, email: str) -> Any:
        """Verify email deliverability. Async."""
        return await self.acall_tool("/v1/tools/verify/email", {"email": email})

    def deep_research_person(self, **kwargs: Any) -> Any:
        """Deep research on a person. Blocking."""
        return self.call_tool("/v1/tools/research/person", kwargs)

    async def adeep_research_person(self, **kwargs: Any) -> Any:
        """Deep research on a person. Async."""
        return await self.acall_tool("/v1/tools/research/person", kwargs)

    def social_profiles(self, **kwargs: Any) -> Any:
        """Discover social media profiles. Blocking."""
        return self.call_tool("/v1/tools/research/social", kwargs)

    async def asocial_profiles(self, **kwargs: Any) -> Any:
        """Discover social media profiles. Async."""
        return await self.acall_tool("/v1/tools/research/social", kwargs)

    def article_search(self, name: str, company: str, **kwargs: Any) -> Any:
        """Find articles by or about a person. Blocking."""
        return self.call_tool("/v1/tools/research/articles", {"name": name, "company": company, **kwargs})

    async def aarticle_search(self, name: str, company: str, **kwargs: Any) -> Any:
        """Find articles by or about a person. Async."""
        return await self.acall_tool("/v1/tools/research/articles", {"name": name, "company": company, **kwargs})

    def person_newsfeed(self, social_media_url: str, **kwargs: Any) -> Any:
        """Get recent social posts from a person. Blocking."""
        return self.call_tool("/v1/tools/research/newsfeed", {"social_media_url": social_media_url, **kwargs})

    async def aperson_newsfeed(self, social_media_url: str, **kwargs: Any) -> Any:
        """Get recent social posts from a person. Async."""
        return await self.acall_tool("/v1/tools/research/newsfeed", {"social_media_url": social_media_url, **kwargs})

    def person_interests(self, **kwargs: Any) -> Any:
        """Analyze a person's interests from their digital footprint. Blocking."""
        return self.call_tool("/v1/tools/research/interests", kwargs)

    async def aperson_interests(self, **kwargs: Any) -> Any:
        """Analyze a person's interests from their digital footprint. Async."""
        return await self.acall_tool("/v1/tools/research/interests", kwargs)

    def person_interactions(self, social_media_url: str, **kwargs: Any) -> Any:
        """Get a person's social interactions. Blocking."""
        return self.call_tool("/v1/tools/research/interactions", {"social_media_url": social_media_url, **kwargs})

    async def aperson_interactions(self, social_media_url: str, **kwargs: Any) -> Any:
        """Get a person's social interactions. Async."""
        return await self.acall_tool("/v1/tools/research/interactions", {"social_media_url": social_media_url, **kwargs})

    def commerce_search(self, query: str, *, limit: int = 10, **kwargs: Any) -> Any:
        """Search for products. Blocking."""
        return self.call_tool("/v1/tools/commerce/search", {"query": query, "limit": limit, **kwargs})

    async def acommerce_search(self, query: str, *, limit: int = 10, **kwargs: Any) -> Any:
        """Search for products. Async."""
        return await self.acall_tool("/v1/tools/commerce/search", {"query": query, "limit": limit, **kwargs})

    def commerce_buy(self, product_url: str, shipping_address: dict[str, Any], **kwargs: Any) -> Any:
        """Purchase a product. Blocking."""
        return self.call_tool("/v1/tools/commerce/buy", {"product_url": product_url, "shipping_address": shipping_address, **kwargs})

    async def acommerce_buy(self, product_url: str, shipping_address: dict[str, Any], **kwargs: Any) -> Any:
        """Purchase a product. Async."""
        return await self.acall_tool("/v1/tools/commerce/buy", {"product_url": product_url, "shipping_address": shipping_address, **kwargs})

    def build(self, product: dict[str, Any], **kwargs: Any) -> Any:
        """Build a website. Blocking."""
        return self.call_tool("/v1/tools/build", {"product": product, **kwargs})

    async def abuild(self, product: dict[str, Any], **kwargs: Any) -> Any:
        """Build a website. Async."""
        return await self.acall_tool("/v1/tools/build", {"product": product, **kwargs})

    # ------------------------------------------------------------------
    # Balance
    # ------------------------------------------------------------------

    def get_balance(self) -> dict:
        """Get unified balance (on-chain USDC + credits). Blocking."""
        return self.call_free_get("/v1/tools/balance")

    async def aget_balance(self) -> dict:
        """Get unified balance (on-chain USDC + credits). Async."""
        return await self.acall_free_get("/v1/tools/balance")

    # ------------------------------------------------------------------
    # Job polling
    # ------------------------------------------------------------------

    async def _poll_job(
        self,
        client: httpx.AsyncClient,
        request_id: str,
        timeout_sec: int,
        *,
        wait_for_phones: bool = False,
        phone_timeout_sec: int = 360,
    ) -> Any:
        start = time.monotonic()
        retries = 0

        while (time.monotonic() - start) < timeout_sec:
            try:
                resp = await client.get(
                    f"{self.base_url}/v1/requests/{request_id}",
                    headers=self._headers(),
                )
                if not resp.is_success:
                    raise ToolError(
                        "Failed to check job status",
                        resp.status_code,
                        resp.text,
                    )

                job = resp.json()

                if job.get("status") == "completed":
                    self._log("Job completed")
                    result = job.get("result") or job
                    # Propagate request_id into the result so callers always have it
                    if isinstance(result, dict) and "request_id" not in result and job.get("request_id"):
                        result["request_id"] = job["request_id"]
                    # Optional second phase: keep polling for Apollo phone-reveal
                    # callbacks. Only fires when the caller explicitly opts in
                    # AND the result still has phones_pending=true (set by the
                    # worker when Apollo enrichment is awaiting an async webhook).
                    # Backwards-compat: existing callers see no change.
                    if wait_for_phones and self._is_phones_pending(result):
                        return await self._poll_for_phones(
                            client,
                            request_id,
                            phone_timeout_sec,
                            initial_result=result,
                        )
                    return result

                if job.get("status") == "failed":
                    raise JobError(
                        f"Job failed: {job.get('error', 'Unknown')}",
                        request_id,
                        str(job.get("error", "Unknown")),
                    )

                retries = 0
                await asyncio.sleep(_POLL_INTERVAL)

            except (OneShotError, JobError):
                raise
            except Exception:
                retries += 1
                if retries > _MAX_POLL_RETRIES:
                    raise
                await asyncio.sleep(_POLL_INTERVAL * (2 ** (retries - 1)))

        elapsed_ms = int((time.monotonic() - start) * 1000)
        raise JobTimeoutError(request_id, elapsed_ms)

    @staticmethod
    def _is_phones_pending(result: Any) -> bool:
        """Detects whether a result is awaiting Apollo's async phone-reveal
        webhook. Tolerates two shapes: the unwrapped result ``{phones_pending}``
        and the deep_research_person wrapper ``{result: {phones_pending}}``.

        Mirrors the TS SDK's _isPhonesPending — kept in lockstep so the worker
        contract works for both SDKs.
        """
        if not isinstance(result, dict):
            return False
        if result.get("phones_pending") is True:
            return True
        inner = result.get("result")
        if isinstance(inner, dict) and inner.get("phones_pending") is True:
            return True
        return False

    async def _poll_for_phones(
        self,
        client: httpx.AsyncClient,
        request_id: str,
        timeout_sec: int,
        *,
        initial_result: Any = None,
    ) -> Any:
        """Slow poll loop (5s cadence) for Apollo phone-reveal callbacks.

        The webhook handler in soul-hunt-api UPDATEs jobs.result_data with
        phones once Apollo POSTs them. We poll the GET endpoint until phones
        arrive (phones_pending flips false) or ``timeout_sec`` expires. On
        timeout we return the last snapshot — phones_pending will still be
        True so the consumer knows phones never arrived.

        Soft-fails on transient HTTP errors and returns the most recent
        successful snapshot to avoid losing the sync result we already have.
        """
        deadline = time.monotonic() + timeout_sec
        interval = 5.0
        last_result: Any = initial_result

        while time.monotonic() < deadline:
            try:
                resp = await client.get(
                    f"{self.base_url}/v1/requests/{request_id}",
                    headers=self._headers(),
                )
                if not resp.is_success:
                    if last_result is not None:
                        return last_result
                    raise ToolError(
                        "Failed to check job status",
                        resp.status_code,
                        resp.text,
                    )
                job = resp.json()
                last_result = job.get("result", job)
                if isinstance(last_result, dict) and "request_id" not in last_result and job.get("request_id"):
                    last_result["request_id"] = job["request_id"]
                if not self._is_phones_pending(last_result):
                    return last_result
            except (OneShotError, JobError):
                raise
            except Exception:
                if last_result is not None:
                    return last_result
                raise
            await asyncio.sleep(interval)

        # Timeout — return the last snapshot. phones_pending is still True
        # so the caller knows phones never arrived.
        return last_result
