"""Tests for request_id propagation in OneShotClient._poll_job.

Verifies that `request_id` from the job envelope is injected into the
final result dict when the result itself doesn't already contain it.
Mirrors the TypeScript SDK's tests in tests/unit/sdk-request-id.test.ts.

Run with:
    cd packages/oneshot-python && uv run pytest tests/test_request_id.py -v
    # or
    cd packages/oneshot-python && python -m pytest tests/test_request_id.py -v
"""

import asyncio
from typing import Any
from unittest.mock import MagicMock

import pytest

from oneshot.client import OneShotClient

TEST_PRIVATE_KEY = "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"
TEST_BASE_URL = "http://test.local"
TEST_REQUEST_ID = "req_test_abc123"


def make_client() -> OneShotClient:
    return OneShotClient(
        private_key=TEST_PRIVATE_KEY,
        base_url=TEST_BASE_URL,
    )


# ── Mock httpx.AsyncClient ──────────────────────────────────────────


def _make_mock_response(status_code: int = 200, json_data: Any = None) -> MagicMock:
    resp = MagicMock()
    resp.is_success = 200 <= status_code < 300
    resp.status_code = status_code
    resp.json = MagicMock(return_value=json_data or {})
    resp.text = ""
    return resp


class _MockHttpxClient:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    async def get(self, url, headers=None):
        self.calls.append({"url": url, "headers": headers})
        if not self.responses:
            raise RuntimeError(f"Unexpected get to {url}")
        next_resp = self.responses.pop(0)
        if isinstance(next_resp, Exception):
            raise next_resp
        return next_resp


# ═══════════════════════════════════════════════════════════════════
# _poll_job request_id injection
# ═══════════════════════════════════════════════════════════════════


class TestRequestIdPropagation:
    """Verifies that _poll_job injects request_id from the job envelope
    into the result dict."""

    def test_injects_request_id_when_missing(self):
        """Result without request_id gets it from the job envelope."""
        client = make_client()
        mock_http = _MockHttpxClient([
            _make_mock_response(200, {
                "request_id": TEST_REQUEST_ID,
                "status": "completed",
                "result": {"url": "https://example.com", "markdown": "# Hello"},
            }),
        ])

        result = asyncio.get_event_loop().run_until_complete(
            client._poll_job(mock_http, TEST_REQUEST_ID, timeout_sec=5)
        )

        assert result["request_id"] == TEST_REQUEST_ID
        assert result["url"] == "https://example.com"
        assert result["markdown"] == "# Hello"

    def test_does_not_overwrite_existing_request_id(self):
        """Result that already has request_id keeps its own value."""
        client = make_client()
        mock_http = _MockHttpxClient([
            _make_mock_response(200, {
                "request_id": TEST_REQUEST_ID,
                "status": "completed",
                "result": {
                    "request_id": "req_original_keep",
                    "url": "https://example.com",
                },
            }),
        ])

        result = asyncio.get_event_loop().run_until_complete(
            client._poll_job(mock_http, TEST_REQUEST_ID, timeout_sec=5)
        )

        assert result["request_id"] == "req_original_keep"

    def test_handles_null_result(self):
        """When result is null, falls back to job envelope (which has request_id)."""
        client = make_client()
        mock_http = _MockHttpxClient([
            _make_mock_response(200, {
                "request_id": TEST_REQUEST_ID,
                "status": "completed",
                "result": None,
            }),
        ])

        result = asyncio.get_event_loop().run_until_complete(
            client._poll_job(mock_http, TEST_REQUEST_ID, timeout_sec=5)
        )

        # Falls back to the job dict which has request_id
        assert result["request_id"] == TEST_REQUEST_ID
        assert result["status"] == "completed"

    def test_handles_non_dict_result(self):
        """Non-dict result (e.g. string) should not crash."""
        client = make_client()
        mock_http = _MockHttpxClient([
            _make_mock_response(200, {
                "request_id": TEST_REQUEST_ID,
                "status": "completed",
                "result": "plain string result",
            }),
        ])

        result = asyncio.get_event_loop().run_until_complete(
            client._poll_job(mock_http, TEST_REQUEST_ID, timeout_sec=5)
        )

        # String result — can't inject request_id, returned as-is
        assert result == "plain string result"

    def test_polls_until_completed(self):
        """Polls through processing states until completed, then injects request_id."""
        client = make_client()
        mock_http = _MockHttpxClient([
            _make_mock_response(200, {"request_id": TEST_REQUEST_ID, "status": "processing"}),
            _make_mock_response(200, {"request_id": TEST_REQUEST_ID, "status": "processing"}),
            _make_mock_response(200, {
                "request_id": TEST_REQUEST_ID,
                "status": "completed",
                "result": {"data": "final"},
            }),
        ])

        result = asyncio.get_event_loop().run_until_complete(
            client._poll_job(mock_http, TEST_REQUEST_ID, timeout_sec=30)
        )

        assert len(mock_http.calls) == 3
        assert result["request_id"] == TEST_REQUEST_ID
        assert result["data"] == "final"

    def test_no_request_id_in_job_envelope(self):
        """If the job envelope has no request_id, result is returned as-is."""
        client = make_client()
        mock_http = _MockHttpxClient([
            _make_mock_response(200, {
                "status": "completed",
                "result": {"data": "no_rid"},
            }),
        ])

        result = asyncio.get_event_loop().run_until_complete(
            client._poll_job(mock_http, TEST_REQUEST_ID, timeout_sec=5)
        )

        assert "request_id" not in result
        assert result["data"] == "no_rid"
