from deadband_protocol import Deadband, MultiDeadband


def test_epsilon_scaling():
    db = Deadband(k=1.0)
    assert db.epsilon(100) == 0.01
    assert db.epsilon(1000) == 0.001
    assert db.epsilon(10) == 0.1


def test_floor_and_ceiling():
    db = Deadband(k=1.0, floor=0.01, ceiling=0.5)
    assert db.epsilon(10000) == 0.01  # hits floor
    assert db.epsilon(1) == 0.5  # hits ceiling
    assert db.epsilon(10) == 0.1  # normal


def test_within():
    db = Deadband(k=1.0)
    assert db.within(0.005, 100) is True
    assert db.within(0.02, 100) is False


def test_snap_check():
    db = Deadband(k=1.0)
    assert db.snap_check(0.0, 100) == "exact"
    assert db.snap_check(0.005, 100) == "within_deadband"
    assert db.snap_check(0.02, 100) == "outside_deadband"


def test_multi_deadband():
    md = MultiDeadband()
    md.add("angle", Deadband(k=0.01))
    md.add("distance", Deadband(k=0.001))
    assert md.all_within({"angle": 0.005, "distance": 0.0005}) is True
    assert md.violations({"angle": 0.02, "distance": 0.0005}) == ["angle"]
