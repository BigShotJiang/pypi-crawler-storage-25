"""Deadband Protocol — adaptive tolerance for constraint theory."""

__version__ = "0.2.0"


class Deadband:
    """Adaptive deadband with epsilon(c) = k/c scaling.
    
    Provides configurable tolerance floors and ceilings for
    snap operations on Pythagorean manifolds.
    """
    
    def __init__(self, k: float = 1.0, floor: float = 1e-10, ceiling: float = 1.0):
        self.k = k
        self.floor = floor
        self.ceiling = ceiling
    
    def epsilon(self, c: float) -> float:
        """Compute adaptive tolerance for constraint distance c."""
        eps = self.k / max(c, 1e-15)
        return max(self.floor, min(eps, self.ceiling))
    
    def within(self, distance: float, c: float) -> bool:
        """Check if distance is within the deadband for constraint c."""
        return distance <= self.epsilon(c)
    
    def snap_check(self, distance: float, c: float) -> str:
        """Classify snap result: 'exact', 'within_deadband', or 'outside_deadband'."""
        if distance == 0.0:
            return "exact"
        if self.within(distance, c):
            return "within_deadband"
        return "outside_deadband"


class MultiDeadband:
    """Manages multiple deadbands for multi-manifold constraint satisfaction."""
    
    def __init__(self, bands: dict = None):
        self.bands = bands or {}
    
    def add(self, name: str, band: Deadband):
        self.bands[name] = band
    
    def all_within(self, distances: dict) -> bool:
        """Check if all distances are within their respective deadbands."""
        return all(
            band.within(dist, max(dist, 1e-15))
            for name, dist in distances.items()
            if name in self.bands
        )
    
    def violations(self, distances: dict) -> list:
        """Return list of constraint names that violate their deadband."""
        return [
            name for name, dist in distances.items()
            if name in self.bands and not self.bands[name].within(dist, max(dist, 1e-15))
        ]
