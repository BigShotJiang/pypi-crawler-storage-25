from __future__ import annotations

import hashlib
import json
import re
from typing import Any
import uuid


OPENAI_AGENTS_ADAPTER_KIND = "openai_agents"
OPENAI_AGENTS_NATIVE_CAPABILITIES = [
    "tracing",
    "tool_calls",
    "handoffs",
    "guardrails",
    "runtime_loopback",
]
OPENAI_AGENTS_STREAM_EVENT_NAMES = {
    "tool_called",
    "tool_output",
    "tool_search_called",
    "tool_search_output_created",
    "mcp_approval_requested",
    "mcp_approval_response",
    "mcp_list_tools",
}
OPENAI_AGENTS_STREAM_START_EVENTS = {
    "tool_called",
    "tool_search_called",
    "mcp_approval_requested",
    "mcp_list_tools",
}
OPENAI_AGENTS_BUILTIN_TOOL_TYPES = {
    "applypatchtool": "apply_patch_call",
    "computertool": "computer_call",
    "codextool": "codex_call",
    "filesearchtool": "file_search_call",
    "hostedmcptool": "mcp_call",
    "imagegenerationtool": "image_generation_call",
    "mcpservertool": "mcp_call",
    "shelltool": "shell_call",
    "toolsearchtool": "tool_search_call",
    "websearchtool": "web_search_call",
}


_EMAIL_PATTERN = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
_CASE_ID_PATTERN = re.compile(r"\b[A-Z]{2,}-\d+\b")
_OMITTED_SENTINEL_NAMES = {
    "omit",
    "notgiven",
    "notprovided",
    "notset",
    "undefined",
    "unset",
    "missing",
}
_OMITTED_SENTINEL_MODULE_ROOTS = {
    "agents",
    "anthropic",
    "cerebras",
    "cohere",
    "fireworks",
    "google",
    "groq",
    "litellm",
    "mistralai",
    "ollama",
    "openai",
    "together",
    "vertexai",
}


def _is_omitted_sentinel(value: Any) -> bool:
    if value is None:
        return False
    cls = type(value)
    class_name = "".join(ch for ch in getattr(cls, "__name__", "").lower() if ch.isalnum())
    if class_name not in _OMITTED_SENTINEL_NAMES:
        return False
    module = str(getattr(cls, "__module__", "") or "").lower()
    if not module or module == "builtins":
        return False
    return module.split(".", 1)[0] in _OMITTED_SENTINEL_MODULE_ROOTS


def _jsonable(value: Any) -> Any:
    if _is_omitted_sentinel(value):
        return None
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        normalized: dict[str, Any] = {}
        for key, item in value.items():
            if _is_omitted_sentinel(item):
                continue
            normalized[str(key)] = _jsonable(item)
        return normalized
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value if not _is_omitted_sentinel(item)]
    if hasattr(value, "model_dump"):
        try:
            return _jsonable(value.model_dump(mode="json"))
        except TypeError:
            return _jsonable(value.model_dump())
    if hasattr(value, "dict") and callable(value.dict):
        return _jsonable(value.dict())
    return str(value)


def _jsonish_object(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return _jsonable(value)
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return {}
        try:
            parsed = json.loads(text)
        except Exception:
            return {"value": text}
        if isinstance(parsed, dict):
            return _jsonable(parsed)
        return {"value": _jsonable(parsed)}
    if value is None:
        return {}
    parsed = _jsonable(value)
    if isinstance(parsed, dict):
        return parsed
    return {"value": parsed}


def _exported_span_data(span: Any) -> dict[str, Any]:
    for candidate in (
        getattr(span, "span_data", None),
        getattr(span, "spanData", None),
        getattr(span, "data", None),
    ):
        if candidate is None:
            continue
        if isinstance(candidate, dict):
            return _jsonable(candidate)
        for method_name in ("export", "model_dump", "dict", "to_json", "toJSON"):
            method = getattr(candidate, method_name, None)
            if callable(method):
                try:
                    value = method()
                except TypeError:
                    try:
                        value = method(mode="json")
                    except Exception:
                        continue
                except Exception:
                    continue
                if isinstance(value, str):
                    try:
                        value = json.loads(value)
                    except Exception:
                        value = {"value": value}
                if isinstance(value, dict):
                    return _jsonable(value)
        normalized = _jsonable(candidate)
        if isinstance(normalized, dict):
            return normalized
    return {}


def _content_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        for key in ("text", "content", "message", "body", "value"):
            if key in content:
                nested = _content_text(content.get(key))
                if nested:
                    return nested
        return json.dumps(_jsonable(content), sort_keys=True)
    if isinstance(content, (list, tuple)):
        parts = [_content_text(item) for item in content]
        return " ".join(part for part in parts if part).strip()
    return str(content)


def _normalize_message(message: Any, *, index: int) -> dict[str, Any]:
    if isinstance(message, dict):
        role = str(message.get("role") or "user")
        content = _content_text(message.get("content"))
        message_id = str(message.get("id") or message.get("message_id") or f"msg_{index}")
        timestamp = message.get("timestamp")
    else:
        role = "user"
        content = _content_text(message)
        message_id = f"msg_{index}"
        timestamp = None
    return {
        "role": role,
        "content": content,
        "id": message_id,
        "message_id": message_id,
        "timestamp": timestamp,
    }


def _input_items(input_payload: Any) -> list[Any]:
    if isinstance(input_payload, list):
        return list(input_payload)
    if isinstance(input_payload, tuple):
        return list(input_payload)
    for attribute in ("original_input", "input", "messages", "items"):
        value = getattr(input_payload, attribute, None)
        if isinstance(value, (list, tuple)):
            return list(value)
        if isinstance(value, (str, dict)):
            return [value]
    if isinstance(input_payload, dict):
        for key in ("input", "messages", "items"):
            value = input_payload.get(key)
            if isinstance(value, (list, tuple)):
                return list(value)
            if isinstance(value, (str, dict)):
                return [value]
    return [input_payload]


def _normalized_field_key(raw: str) -> str:
    return "_".join(token for token in re.split(r"[^a-z0-9]+", raw.strip().lower()) if token)


def _extract_structured_fields(content: str) -> dict[str, Any]:
    fields: dict[str, Any] = {}
    active_key: str | None = None
    active_lines: list[str] = []
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line:
            if active_key is not None and active_lines:
                active_lines.append("")
            continue
        if ":" in line:
            key_part, value_part = line.split(":", 1)
            normalized_key = _normalized_field_key(key_part)
            if normalized_key:
                if active_key is not None:
                    fields[active_key] = "\n".join(active_lines).strip()
                active_key = normalized_key
                value = value_part.strip()
                active_lines = [value] if value else []
                continue
        if active_key is not None:
            active_lines.append(line)
    if active_key is not None:
        fields[active_key] = "\n".join(active_lines).strip()
    return {key: value for key, value in fields.items() if value}


def _prompt_context_object(vx, message: dict[str, Any], *, source: str, index: int) -> dict[str, Any]:
    content = message["content"]
    normalized_payload: dict[str, Any] = {
        "message_id": message["message_id"],
        "role": message["role"],
        "content": content,
        "source": source,
        "lines": [line.strip() for line in content.splitlines() if line.strip()][:32],
    }
    structured_fields = _extract_structured_fields(content)
    if structured_fields:
        normalized_payload["structured_fields"] = structured_fields
    emails = sorted(dict.fromkeys(match.group(0) for match in _EMAIL_PATTERN.finditer(content)))
    if emails:
        normalized_payload["emails"] = emails
    case_ids = sorted(dict.fromkeys(match.group(0) for match in _CASE_ID_PATTERN.finditer(content)))
    if case_ids:
        normalized_payload["case_ids"] = case_ids
    object_id = "obj_prompt_" + hashlib.sha256(
        json.dumps(
            {
                "source": source,
                "index": index,
                "role": message["role"],
                "content": content,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()[:24]
    return vx.capture.build_object(
        "observation",
        normalized_payload,
        object_id=object_id,
        source_lineage=["openai_agents", "prompt_frame"],
        observability_quality="complete",
    )


def _remember_prompt_context(vx, object_payload: dict[str, Any], *, role: str, message_id: str):
    if role in {"user", "assistant", "tool", "tool_result"} and vx.config.direct_ingress_labeling:
        try:
            diagnostic = vx.observe_runtime_ingress(
                object_payload,
                source_uri=f"prompt://openai_agents/{message_id}",
                source_hint=f"openai_agents:{role}",
            )
            if diagnostic is not None:
                request_payload, response = diagnostic
                vx.record_ingress_diagnostic("openai_agents_prompt_context", request_payload, response)
                return
        except Exception:
            if vx.config.strict_direct_ingress_labeling:
                raise
    vx.capture.remember_observed_object(object_payload, kind="context_ingress")


def _native_tool_type(tool: Any) -> str | None:
    explicit = getattr(tool, "type", None)
    if isinstance(explicit, str) and explicit.strip():
        return explicit.strip()
    class_name = "".join(ch for ch in type(tool).__name__.lower() if ch.isalnum())
    if class_name in OPENAI_AGENTS_BUILTIN_TOOL_TYPES:
        return OPENAI_AGENTS_BUILTIN_TOOL_TYPES[class_name]
    qualified_name = str(getattr(tool, "qualified_name", None) or getattr(tool, "name", "") or "").strip().lower()
    if qualified_name in OPENAI_AGENTS_BUILTIN_TOOL_TYPES.values():
        return qualified_name
    return None


def _tool_pending_action(tool_name: str, native_tool_type: str | None) -> dict[str, Any] | None:
    item_type = str(native_tool_type or "").strip().lower()
    if item_type == "shell_call":
        return {
            "surface": "tool_dispatch",
            "operation": tool_name,
            "target": tool_name,
            "method": "CALL",
            "raw_args": {},
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": True,
        }
    if item_type == "apply_patch_call":
        return {
            "surface": "file_write",
            "operation": tool_name,
            "target": tool_name,
            "method": "write",
            "raw_args": {},
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": False,
        }
    if item_type == "mcp_call":
        return {
            "surface": "tool_dispatch",
            "operation": tool_name,
            "target": tool_name,
            "method": "CALL",
            "raw_args": {},
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": True,
        }
    return None


def _tool_definition(tool: Any) -> dict[str, Any]:
    tool_name = str(getattr(tool, "qualified_name", None) or getattr(tool, "name", type(tool).__name__))
    native_tool_type = _native_tool_type(tool)
    retrieval_like = _tool_looks_retrieval_only(tool_name, tool)
    return {
        "tool_name": tool_name,
        "description": getattr(tool, "description", None),
        "schema": _jsonable(getattr(tool, "params_json_schema", None)),
        "needs_approval": bool(getattr(tool, "needs_approval", False)),
        "strict_json_schema": bool(getattr(tool, "strict_json_schema", False)),
        "namespace": getattr(tool, "_tool_namespace", None),
        "defer_loading": bool(getattr(tool, "defer_loading", False)),
        "type": native_tool_type,
        "metadata": {
            "native_tool_type": native_tool_type,
            "needs_approval": bool(getattr(tool, "needs_approval", False)),
            "namespace": getattr(tool, "_tool_namespace", None),
            "read_only": retrieval_like,
            "retrieval_like": retrieval_like,
            "pending_action": _tool_pending_action(tool_name, native_tool_type),
        },
    }


def _tool_schema(tool: Any) -> dict[str, Any]:
    schema = _jsonable(getattr(tool, "params_json_schema", None))
    if isinstance(schema, dict):
        return schema
    return {"type": "object", "additionalProperties": True}


def _tool_property_names(schema: dict[str, Any]) -> list[str]:
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return []
    return [str(name) for name in properties.keys()]


def _tokenize_tool_text(*parts: Any) -> set[str]:
    tokens: set[str] = set()
    for part in parts:
        text = str(part or "").strip().lower().replace("_", " ")
        if not text:
            continue
        for token in re.split(r"[^a-z0-9]+", text):
            if token:
                tokens.add(token)
    return tokens


def _tool_looks_retrieval_only(tool_name: str, tool: Any) -> bool:
    schema = _tool_schema(tool)
    property_names = {str(name).strip().lower() for name in _tool_property_names(schema)}
    description = str(getattr(tool, "description", None) or "")
    tokens = _tokenize_tool_text(tool_name, description, " ".join(sorted(property_names)))
    retrieval_verbs = bool(tokens & {"fetch", "get", "inspect", "list", "load", "lookup", "query", "read", "retrieve", "search", "show", "view"}) or {"look", "up"} <= tokens
    mutation_verbs = bool(tokens & {"append", "apply", "archive", "create", "delete", "disable", "edit", "enable", "insert", "notify", "patch", "persist", "post", "reply", "save", "send", "set", "store", "sync", "update", "upsert", "write"})
    if not retrieval_verbs or mutation_verbs:
        return False
    retrieval_properties = {
        "account_id",
        "case_id",
        "contact_id",
        "conversation_id",
        "customer_id",
        "email",
        "entity_id",
        "filter",
        "filters",
        "id",
        "issue_id",
        "key",
        "limit",
        "message_id",
        "namespace",
        "offset",
        "page",
        "query",
        "record_id",
        "search",
        "session_id",
        "target",
        "thread_id",
        "ticket_id",
        "url",
        "user_id",
        "workflow_id",
    }
    return not property_names or property_names <= retrieval_properties


def _tool_action_class(tool_name: str, tool: Any) -> str | None:
    native_tool_type = _native_tool_type(tool)
    if native_tool_type in {"shell_call", "local_shell_call", "apply_patch_call", "mcp_call"}:
        return "system_change"
    if _tool_looks_retrieval_only(tool_name, tool):
        return None
    schema = _tool_schema(tool)
    property_names = _tool_property_names(schema)
    description = str(getattr(tool, "description", None) or "")
    tokens = f"{tool_name} {description} {' '.join(property_names)}".lower()
    has_memory = bool(re.search(r"memory|memo|note|preference|remember|state", tokens))
    has_mutation = bool(
        re.search(
            r"append|apply|archive|create|delete|disable|edit|enable|insert|patch|persist|remember|reroute|route|save|set|store|sync|update|upsert|write",
            tokens,
        )
    )
    has_record = bool(
        re.search(
            r"account|case|contact|customer|incident|issue|lead|opportunity|order|profile|record|subscription|task|ticket|user",
            tokens,
        )
    ) or any(
        re.search(
            r"(account|case|contact|customer|issue|lead|opportunity|order|profile|record|subscription|task|ticket|user)_id$",
            name,
        )
        or name == "record_id"
        for name in property_names
    )
    has_message = bool(
        re.search(
            r"alert|body|channel|chat|comment|conversation|dm|email|mail|message|notify|notification|post|recipient|reply|send|slack|subject|teams|text|thread",
            tokens,
        )
    )
    has_internal = bool(
        re.search(
            r"assignment|config|configuration|flag|metadata|policy|queue|route|routing|rule|setting|settings|stage|state|status|thread|workflow",
            tokens,
        )
    )
    if (
        {"namespace", "key", "value"}.issubset(property_names)
        or (has_memory and has_mutation)
    ):
        return "memory_write"
    if has_message and (
        has_mutation
        or any(
            name
            in {
                "body",
                "channel",
                "channel_id",
                "comment",
                "content",
                "email",
                "message",
                "recipient",
                "recipient_id",
                "subject",
                "text",
                "thread_id",
                "to",
            }
            for name in property_names
        )
    ):
        return "external_message_send"
    if has_record and (
        has_mutation
        or any(re.search(r"patch|update|fields|status|state|tier|owner", name) for name in property_names)
    ):
        return "record_mutation"
    if has_internal and (
        has_mutation
        or any(
            re.search(r"config|flag|metadata|policy|route|routing|rule|setting|stage|state|status|workflow", name)
            for name in property_names
        )
    ):
        return "system_change"
    if bool(getattr(tool, "needs_approval", False)):
        return "system_change"
    return None


def _tool_raw_name(tool_name: str, native_tool_type: str | None) -> str:
    if native_tool_type in {"shell_call", "local_shell_call", "apply_patch_call", "mcp_call", "mcp_list_tools"}:
        return str(native_tool_type)
    return tool_name


def _tool_input_payload(input_payload: Any) -> dict[str, Any]:
    return _jsonish_object(input_payload)


def _tool_event_name(tool_name: str, native_tool_type: str | None) -> str:
    if native_tool_type == "tool_search_call" or tool_name == "tool_search_call":
        return "tool_search_called"
    if native_tool_type == "mcp_list_tools":
        return "mcp_list_tools"
    return "tool_called"


def _tool_selection_source(tool_name: str, native_tool_type: str | None) -> str:
    return f"openai_agents.stream.{_tool_event_name(tool_name, native_tool_type)}"


def _memory_write_pending(tool_name: str, raw_args: dict[str, Any]) -> tuple[str, str, dict[str, Any]]:
    namespace = str(raw_args.get("namespace") or tool_name)
    key = str(
        raw_args.get("key")
        or raw_args.get("id")
        or raw_args.get("record_id")
        or raw_args.get("name")
        or "value"
    )
    transport_args = {
        "namespace": namespace,
        "key": key,
        "value": raw_args.get("value")
        or raw_args.get("patch")
        or raw_args.get("update")
        or raw_args.get("fields")
        or raw_args,
        "write_kind": raw_args.get("action") or raw_args.get("operation") or "write",
    }
    return namespace, key, transport_args


def _action_execute_capture(
    *,
    tool_name: str,
    raw_name: str,
    raw_args: dict[str, Any],
    action_class: str | None,
    native_tool_type: str | None,
) -> dict[str, Any]:
    explicit_capture = _tool_pending_action(raw_name, native_tool_type)
    if explicit_capture is not None:
        explicit_capture.setdefault("transport_args", dict(raw_args))
        return explicit_capture
    target = (
        raw_args.get("url")
        or raw_args.get("uri")
        or raw_args.get("target")
        or raw_args.get("workflow_id")
        or raw_args.get("job_id")
        or raw_args.get("task_id")
        or raw_args.get("customer_id")
        or raw_args.get("account_id")
        or raw_args.get("user_id")
        or raw_args.get("record_id")
        or raw_args.get("channel_id")
        or raw_args.get("recipient")
        or raw_args.get("email")
        or raw_args.get("id")
        or raw_args.get("key")
        or raw_name
    )
    trust_boundary_crossing = any(
        raw_args.get(field)
        for field in (
            "url",
            "uri",
            "recipient",
            "email",
            "address",
            "external",
            "public",
            "customer_visible",
        )
    )
    return {
        "surface": "tool_dispatch",
        "operation": raw_name,
        "target": str(target),
        "method": "CALL",
        "transport_args": dict(raw_args),
        "boundary_kind": "action_execute",
        "action_class": action_class,
        "trust_boundary_crossing": bool(trust_boundary_crossing),
    }


def _wrap_agent_tool(vx, tool: Any, report) -> Any:
    original_invoker = getattr(tool, "on_invoke_tool", None)
    if original_invoker is None or getattr(tool, "__verifiedx_wrapped_tool__", False):
        return tool
    tool_name = str(getattr(tool, "qualified_name", None) or getattr(tool, "name", type(tool).__name__))
    native_tool_type = _native_tool_type(tool)
    action_class = _tool_action_class(tool_name, tool)
    if action_class is None and native_tool_type not in {
        "shell_call",
        "local_shell_call",
        "apply_patch_call",
        "mcp_call",
    }:
        return tool
    raw_name = _tool_raw_name(tool_name, native_tool_type)
    schema = _tool_schema(tool)
    docstring = str(getattr(tool, "description", None) or "")
    source = _tool_selection_source(tool_name, native_tool_type)
    adapter = report.to_adapter_context()
    async def guarded(ctx, input_payload):
        raw_args = _tool_input_payload(input_payload)
        tool_call_id = getattr(ctx, "tool_call_id", None) or getattr(ctx, "call_id", None)
        selection_metadata = {
            "raw_name": raw_name,
            "raw_args": raw_args,
            "native_call_type": native_tool_type or _tool_event_name(tool_name, native_tool_type),
        }
        if tool_call_id:
            selection_metadata["tool_call_id"] = str(tool_call_id)
        runtime_context = vx.derive_tool_runtime_context(
            original_invoker,
            tool_name=raw_name,
            args=(),
            kwargs=raw_args,
            schema=schema,
            docstring=docstring,
            metadata=selection_metadata,
            source=source,
        )
        try:
            with vx.tool_runtime_scope(runtime_context):
                vx.zero_touch.note_tool_selection(
                    tool_name=raw_name,
                    arguments=raw_args,
                    tool_call_id=str(tool_call_id) if tool_call_id else None,
                    schema=schema,
                    docstring=docstring,
                    selection_metadata=selection_metadata,
                    source=source,
                )
                async def execute():
                    return await original_invoker(ctx, input_payload)

                if action_class == "memory_write":
                    namespace, key, transport_args = _memory_write_pending(tool_name, raw_args)
                    return await vx.zero_touch.intercept_boundary_async(
                        surface="memory_write",
                        operation=raw_name,
                        target=f"{namespace}/{key}",
                        method="write",
                        transport_args=transport_args,
                        boundary_kind="memory_write",
                        trust_boundary_crossing=False,
                        pending_effect=transport_args,
                        execute=execute,
                    )
                capture = _action_execute_capture(
                    tool_name=tool_name,
                    raw_name=raw_name,
                    raw_args=raw_args,
                    action_class=action_class,
                    native_tool_type=native_tool_type,
                )
                return await vx.zero_touch.intercept_boundary_async(
                    surface=str(capture["surface"]),
                    operation=str(capture["operation"]),
                    target=str(capture["target"]),
                    method=capture.get("method"),
                    transport_args=dict(capture.get("transport_args") or raw_args),
                    boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                    action_class=capture.get("action_class"),
                    trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                    pending_effect=dict(capture.get("transport_args") or raw_args),
                    tool_descriptor=runtime_context.descriptor(),
                    execute=execute,
                )
        except Exception as error:
            handled = vx.handle_runtime_tool_error(error)
            if handled is None:
                raise
            return handled

    tool.on_invoke_tool = guarded
    setattr(tool, "__verifiedx_wrapped_tool__", True)
    return tool


def _wrap_agent_tools(vx, agent: Any, report) -> Any:
    tools = list(getattr(agent, "tools", []) or [])
    if not tools:
        return agent
    setattr(agent, "tools", [_wrap_agent_tool(vx, tool, report) for tool in tools])
    return agent


def _record_action_producing_context(vx, agent, input, *, runner_present: bool):
    normalized_messages: list[dict[str, Any]] = []
    weak_signals: list[str] = []
    instructions = getattr(agent, "instructions", None)
    if isinstance(instructions, str) and instructions.strip():
        normalized_messages.append(
            {
                "role": "system",
                "content": instructions.strip(),
                "id": "agent_system_prompt",
                "message_id": "agent_system_prompt",
                "timestamp": None,
            }
        )
    elif instructions is not None:
        weak_signals.append("dynamic_agent_instructions_not_materialized")
    normalized_messages.extend(
        _normalize_message(item, index=index) for index, item in enumerate(_input_items(input))
    )
    case_ids = []
    for message in normalized_messages:
        case_ids.extend(match.group(0) for match in _CASE_ID_PATTERN.finditer(str(message.get("content") or "")))
    case_hint = case_ids[0] if case_ids else "run"
    run_scope = f"openai_agents:{case_hint}:{uuid.uuid4().hex}"
    scope_activator = getattr(vx, "_activate_runtime_scope", None)
    if callable(scope_activator):
        scope_activator(run_scope)
    else:
        vx.activate_runtime_scope_from_payload({"run_id": run_scope})
    inserted_context_object_ids = []
    for index, message in enumerate(normalized_messages):
        object_payload = _prompt_context_object(
            vx,
            message,
            source="openai_agents.run",
            index=index,
        )
        _remember_prompt_context(
            vx,
            object_payload,
            role=message["role"],
            message_id=message["message_id"],
        )
        inserted_context_object_ids.append(object_payload["object_id"])
    model_settings = getattr(agent, "model_settings", None)
    request_metadata = {
        "runner_present": runner_present,
        "agent_name": getattr(agent, "name", None),
        "tool_use_behavior": getattr(agent, "tool_use_behavior", None),
        "reset_tool_choice": getattr(agent, "reset_tool_choice", None),
        "runtime_scope": run_scope,
    }
    vx.record_conversation_window(
        normalized_messages,
        source="openai_agents.run",
        model_name=getattr(agent, "model", None),
        request_kind="openai_agents.run",
        request_metadata=request_metadata,
        tool_choice=getattr(model_settings, "tool_choice", None),
        tool_definitions=[_tool_definition(tool) for tool in list(getattr(agent, "tools", []) or [])],
        inserted_context_object_ids=inserted_context_object_ids,
        supported_adapter=True,
        weak_signals=weak_signals,
        capture_source_kind="wrapper",
    )
    return run_scope


def _span_value(span, *names):
    exported = _exported_span_data(span)
    for name in names:
        value = getattr(span, name, None)
        if value is not None:
            return value
        data = getattr(span, "data", None)
        if isinstance(data, dict) and data.get(name) is not None:
            return data.get(name)
        attributes = getattr(span, "attributes", None)
        if isinstance(attributes, dict) and attributes.get(name) is not None:
            return attributes.get(name)
        if exported.get(name) is not None:
            return exported.get(name)
    return None


def _span_type(span) -> str:
    exported = _exported_span_data(span)
    return str(
        exported.get("type")
        or _span_value(span, "span_type", "type")
        or type(span).__name__
    ).lower()


def _tool_span_event_name(span, *, phase: str) -> str | None:
    exported = _exported_span_data(span)
    explicit = str(
        exported.get("name")
        or _span_value(span, "event_name", "stream_event_name", "name")
        or ""
    ).strip()
    if explicit in OPENAI_AGENTS_STREAM_EVENT_NAMES:
        return explicit
    span_type = _span_type(span)
    if not any(token in span_type for token in ("tool", "function", "mcp", "approval")):
        return None
    if "tool_search" in span_type and any(token in span_type for token in ("output", "result", "created")):
        return "tool_search_output_created"
    if "tool_search" in span_type:
        return "tool_search_called"
    if "mcp" in span_type and "approval" in span_type and "response" in span_type:
        return "mcp_approval_response"
    if "mcp" in span_type and "approval" in span_type:
        return "mcp_approval_requested"
    if "mcp" in span_type and "list" in span_type and "tool" in span_type:
        return "mcp_list_tools"
    if phase == "end" and any(token in span_type for token in ("function", "tool", "mcp")):
        return "tool_output"
    if any(token in span_type for token in ("output", "result")):
        return "tool_output"
    return "tool_called"


def _tool_span_descriptor(span, *, phase: str) -> dict[str, Any] | None:
    exported = _exported_span_data(span)
    event_name = _tool_span_event_name(span, phase=phase)
    if event_name is None:
        return None
    tool_name = _span_value(
        span,
        "tool_name",
        "name",
        "function_name",
        "call_name",
        "mcp_tool_name",
        "server_tool_name",
        "server_name",
    )
    if tool_name is None and isinstance(exported.get("result"), list) and event_name == "mcp_list_tools":
        tool_name = exported.get("server")
    if tool_name is None:
        tool_name = exported.get("name")
    raw_name = str(tool_name or event_name).strip()
    if not raw_name:
        return None
    raw_args = _jsonish_object(
        _span_value(
            span,
            "input",
            "arguments",
            "tool_input",
            "tool_args",
            "args",
        )
        or exported.get("input")
    )
    if event_name == "mcp_list_tools":
        raw_args = _jsonish_object(
            {
                "server": exported.get("server") or _span_value(span, "server_name", "server"),
                "result": exported.get("result"),
            }
        )
    tool_call_id = _span_value(span, "tool_call_id", "call_id", "id")
    metadata = {
        "raw_name": raw_name,
        "raw_args": raw_args,
        "native_call_type": event_name,
    }
    if tool_call_id:
        metadata["tool_call_id"] = str(tool_call_id)
    return {
        "tool_name": raw_name,
        "args": raw_args,
        "source": f"openai_agents.stream.{event_name}",
        "tool_call_id": str(tool_call_id) if tool_call_id else None,
        "selection_metadata": metadata,
    }


def _tool_span_fallback_descriptor(span, *, normalized_type: str) -> dict[str, Any]:
    event_name = _tool_span_event_name(span, phase="end")
    if event_name is None:
        if any(token in normalized_type for token in ("output", "result")):
            event_name = "tool_output"
        elif "tool_search" in normalized_type:
            event_name = "tool_search_called"
        else:
            event_name = "tool_called"
    raw_name = str(
        _span_value(
            span,
            "tool_name",
            "name",
            "function_name",
            "call_name",
            "mcp_tool_name",
            "server_tool_name",
            "server_name",
        )
        or event_name
    ).strip()
    if not raw_name:
        raw_name = event_name
    tool_call_id = _span_value(span, "tool_call_id", "call_id", "id")
    return {
        "tool_name": raw_name,
        "args": {},
        "source": f"openai_agents.stream.{event_name}",
        "tool_call_id": str(tool_call_id) if tool_call_id else None,
        "selection_metadata": {
            "raw_name": raw_name,
            "raw_args": {},
            "native_call_type": event_name,
        },
    }


def _delegation_descriptor(verifiedx, span, *, destination: str, child_run_fallback: str) -> dict:
    context = verifiedx.capture.current_context()
    child_run_id = str(
        _span_value(span, "child_run_id", "run_id", "span_id", "trace_id") or child_run_fallback
    )
    child_thread_id = _span_value(span, "child_thread_id", "thread_id")
    depth = _span_value(span, "depth", "handoff_depth", "subagent_depth") or 1
    delegated_tool_scope = _span_value(span, "delegated_tool_scope", "tool_scope") or []
    delegated_memory_scope = _span_value(span, "delegated_memory_scope", "memory_scope") or []
    delegated_environment_scope = (
        _span_value(span, "delegated_environment_scope", "environment_scope")
        or [context.environment]
    )
    allowed_action_classes = _span_value(span, "allowed_action_classes") or []
    task_basis = {
        "span_type": _span_value(span, "span_type", "type") or type(span).__name__,
        "destination": destination,
        "name": _span_value(span, "name", "handoff_name", "agent_name", "target_agent"),
    }
    task_fingerprint = hashlib.sha256(
        json.dumps(task_basis, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()
    return {
        "parent_run_id": context.run_id,
        "child_run_id": child_run_id,
        "parent_thread_id": context.thread_id,
        "child_thread_id": str(child_thread_id) if child_thread_id is not None else context.thread_id,
        "depth": int(depth) if str(depth).isdigit() else 1,
        "task_fingerprint": task_fingerprint,
        "delegated_tool_scope": list(delegated_tool_scope),
        "delegated_memory_scope": list(delegated_memory_scope),
        "delegated_environment_scope": [str(item) for item in delegated_environment_scope],
        "allowed_action_classes": list(allowed_action_classes),
        "cross_environment": bool(_span_value(span, "cross_environment")),
        "cross_thread": bool(child_thread_id and str(child_thread_id) != context.thread_id),
        "destination": destination,
    }


class VerifiedXTraceProcessor:
    def __init__(self, verifiedx, report):
        self._verifiedx = verifiedx
        self._report = report

    def on_trace_start(self, trace):
        return None

    def on_trace_end(self, trace):
        return None

    def on_span_start(self, span):
        descriptor = _tool_span_descriptor(span, phase="start")
        if (
            descriptor is not None
            and descriptor["selection_metadata"].get("native_call_type") in OPENAI_AGENTS_STREAM_START_EVENTS
            and self._should_record_tool_start_descriptor(descriptor)
        ):
            self._verifiedx.zero_touch.note_tool_selection(
                tool_name=descriptor["tool_name"],
                arguments=descriptor["args"],
                tool_call_id=descriptor.get("tool_call_id"),
                selection_metadata=descriptor["selection_metadata"],
                source=descriptor["source"],
            )
        return None

    def on_span_end(self, span):
        adapter = self._report.to_adapter_context()
        normalized = self._verifiedx.otel_bridge.process_external_span(
            span,
            capture_source_kind="wrapper",
            source_lineage=["openai_agents", "native_trace"],
            adapter=adapter,
        )
        if normalized:
            return
        span_type = getattr(span, "span_type", None) or getattr(span, "type", None) or type(span).__name__
        payload = {"span_type": span_type, "span": repr(span)}
        normalized_type = span_type.lower()
        destination = str(
            _span_value(span, "destination", "handoff_name", "agent_name", "target_agent")
            or span_type
        )
        descriptor = _delegation_descriptor(
            self._verifiedx,
            span,
            destination=destination,
            child_run_fallback=f"delegation::{destination}",
        )
        if "subagent" in normalized_type and "spawn" in normalized_type:
            self._verifiedx.capture.subagent_spawn(
                self._verifiedx.capture.build_object("summary", payload, source_lineage=["openai_agents"]),
                descriptor=descriptor,
                adapter=adapter,
            )
        elif "subagent" in normalized_type and any(token in normalized_type for token in ("return", "result", "complete")):
            self._verifiedx.capture.subagent_return(
                self._verifiedx.capture.build_object("summary", payload, source_lineage=["openai_agents"]),
                descriptor=descriptor,
                action_log_present=True,
                adapter=adapter,
            )
        elif "handoff" in normalized_type and any(token in normalized_type for token in ("accept", "accepted")):
            self._verifiedx.capture.handoff_accept(
                self._verifiedx.capture.build_object("summary", payload, source_lineage=["openai_agents"]),
                descriptor=descriptor,
                adapter=adapter,
            )
        elif "handoff" in normalized_type:
            self._verifiedx.capture.handoff_start(
                self._verifiedx.capture.build_object("summary", payload, source_lineage=["openai_agents"]),
                descriptor=descriptor,
                adapter=adapter,
            )
        elif "guardrail" in normalized_type:
            self._verifiedx.capture.approval(
                self._verifiedx.capture.build_object("approval", payload, source_lineage=["openai_agents"]),
                approval_state="observed",
                adapter=adapter,
            )
        elif _tool_span_event_name(span, phase="end") is not None:
            descriptor = _tool_span_descriptor(span, phase="end") or _tool_span_fallback_descriptor(
                span,
                normalized_type=normalized_type,
            )
            tool_payload = {
                **payload,
                "raw_name": descriptor["tool_name"],
                "source": descriptor["source"],
                "tool_call_id": descriptor.get("tool_call_id"),
                "native_call_type": (
                    descriptor.get("selection_metadata") or {}
                ).get("native_call_type"),
            }
            self._verifiedx.capture.tool_call(
                self._verifiedx.capture.build_object(
                    "tool_result",
                    tool_payload,
                    source_lineage=["openai_agents"],
                ),
                tool_name=descriptor["tool_name"],
                adapter=adapter,
            )
        else:
            self._verifiedx.capture.llm_call(
                self._verifiedx.capture.build_object(
                    "model_derived_assertion",
                    payload,
                    source_lineage=["openai_agents"],
                ),
                model_name="openai_agents",
                adapter=adapter,
            )

    def force_flush(self):
        return None

    def shutdown(self):
        return None

    @staticmethod
    def _should_record_tool_start_descriptor(descriptor: dict[str, Any]) -> bool:
        native_call_type = str(
            (descriptor.get("selection_metadata") or {}).get("native_call_type") or ""
        ).strip()
        if native_call_type != "tool_called":
            return True
        if descriptor.get("tool_call_id"):
            return True
        args = descriptor.get("args")
        if isinstance(args, dict) and args:
            return True
        return False


def _install_trace_processor(processor, runner=None):
    if runner is not None and hasattr(runner, "add_trace_processor"):
        runner.add_trace_processor(processor)
        return True
    try:
        import agents.tracing as tracing

        if hasattr(tracing, "add_trace_processor"):
            tracing.add_trace_processor(processor)
            return True
    except Exception:
        return False
    return False


def install(*, verifiedx=None, runner=None, framework_version=None):
    from .runtime import init_verifiedx

    vx = verifiedx or init_verifiedx()
    if not vx.runtime_enabled:
        vx.install_runtime(framework_version=framework_version)
    report = vx.activation_report(
        OPENAI_AGENTS_ADAPTER_KIND,
        "native",
        list(OPENAI_AGENTS_NATIVE_CAPABILITIES),
        framework_version=framework_version,
        activation_source="openai_agents_install",
    )
    processor = VerifiedXTraceProcessor(vx, report)
    if not _install_trace_processor(processor, runner=runner):
        report.attachment_mode = "wrapper_only"
        report.visibility_gap_signals.append("trace_processor_unavailable")
    vx.capture.set_default_adapter(report.to_adapter_context())
    vx.record_activation_diagnostic(report)
    return vx, report


def attach_runner(runner, *, verifiedx=None, framework_version=None):
    vx, _ = install(verifiedx=verifiedx, runner=runner, framework_version=framework_version)
    return runner if runner is not None else vx


def attach_agent(agent, *, verifiedx=None, runner=None, framework_version=None):
    vx, report = install(verifiedx=verifiedx, runner=runner, framework_version=framework_version)
    _wrap_agent_tools(vx, agent, report)
    try:
        setattr(agent, "__verifiedx_activation_report__", report.as_dict())
    except Exception:
        pass
    return agent


async def run(agent, input, *, verifiedx=None, runner=None, framework_version=None, **kwargs):
    vx, report = install(verifiedx=verifiedx, runner=runner, framework_version=framework_version)
    _wrap_agent_tools(vx, agent, report)
    run_scope = _record_action_producing_context(vx, agent, input, runner_present=runner is not None)
    with vx.pinned_runtime_scope(run_scope):
        if runner is not None and hasattr(runner, "run"):
            result = await runner.run(agent, input, **kwargs)
        else:
            from agents import Runner

            result = await Runner.run(agent, input, **kwargs)
    try:
        setattr(result, "__verifiedx_activation_report__", report.as_dict())
    except Exception:
        pass
    return result


def run_sync(agent, input, *, verifiedx=None, runner=None, framework_version=None, **kwargs):
    vx, report = install(verifiedx=verifiedx, runner=runner, framework_version=framework_version)
    _wrap_agent_tools(vx, agent, report)
    run_scope = _record_action_producing_context(vx, agent, input, runner_present=runner is not None)
    with vx.pinned_runtime_scope(run_scope):
        if runner is not None and hasattr(runner, "run_sync"):
            result = runner.run_sync(agent, input, **kwargs)
        else:
            from agents import Runner

            result = Runner.run_sync(agent, input, **kwargs)
    try:
        setattr(result, "__verifiedx_activation_report__", report.as_dict())
    except Exception:
        pass
    return result


def run_streamed(agent, input, *, verifiedx=None, runner=None, framework_version=None, **kwargs):
    vx, report = install(verifiedx=verifiedx, runner=runner, framework_version=framework_version)
    _wrap_agent_tools(vx, agent, report)
    run_scope = _record_action_producing_context(vx, agent, input, runner_present=runner is not None)
    with vx.pinned_runtime_scope(run_scope):
        if runner is not None and hasattr(runner, "run_streamed"):
            result = runner.run_streamed(agent, input, **kwargs)
        else:
            from agents import Runner

            result = Runner.run_streamed(agent, input, **kwargs)
    try:
        setattr(result, "__verifiedx_activation_report__", report.as_dict())
    except Exception:
        pass
    return result
