from __future__ import annotations

import asyncio
import inspect
import json
from typing import Any, Callable


ANTHROPIC_DIRECT_ADAPTER_KIND = "anthropic_direct"
ANTHROPIC_DIRECT_NATIVE_CAPABILITIES = [
    "messages_api",
    "native_tool_use",
    "runtime_loopback",
]

ANTHROPIC_DIRECT_MUTATING_COMMANDS = {
    "append",
    "create",
    "delete",
    "insert",
    "rename",
    "replace",
    "str_replace",
    "write",
}

ANTHROPIC_DIRECT_HISTORY_SEMANTICS = {
    "code_execution": "system_mutation",
    "tool_search_tool_bm25": "tool_search",
    "tool_search_tool_regex": "tool_search",
    "web_fetch": "external_retrieval",
    "web_search": "external_search",
}

ANTHROPIC_DIRECT_RETRIEVAL_CLASSES = {
    "external_retrieval",
    "external_search",
    "file_read",
    "memory_read",
    "tool_search",
}

ANTHROPIC_DIRECT_SERVER_TOOL_TYPES = {
    "code_execution_20250522",
    "code_execution_20250825",
    "code_execution_20260120",
    "tool_search_tool_bm25_20251119",
    "tool_search_tool_regex_20251119",
    "web_fetch_20250910",
    "web_fetch_20260209",
    "web_fetch_20260309",
    "web_search_20250305",
    "web_search_20260209",
}

ANTHROPIC_DIRECT_TRIGGER_TOOL_TYPES = {
    "bash_20250124",
    "memory_20250818",
    "text_editor_20250124",
    "text_editor_20250728",
}
ANTHROPIC_DIRECT_INSTALL_MARK = "_verifiedx_anthropic_direct_install_report"


def install(*, verifiedx=None, framework_version: str | None = None):
    from .runtime import init_verifiedx

    vx = verifiedx or init_verifiedx()
    cached = getattr(vx, ANTHROPIC_DIRECT_INSTALL_MARK, None)
    if cached is not None:
        return vx
    if not vx.runtime_enabled:
        vx.install_runtime(framework_version=framework_version)
    report = vx.activation_report(
        ANTHROPIC_DIRECT_ADAPTER_KIND,
        "native",
        list(ANTHROPIC_DIRECT_NATIVE_CAPABILITIES),
        framework_version=framework_version,
        activation_source="anthropic_direct_install",
    )
    vx._zero_touch.report = report
    vx._otel_bridge.apply_report(report)
    vx.capture.set_default_adapter(report.to_adapter_context())
    vx.record_activation_diagnostic(report)
    setattr(vx, ANTHROPIC_DIRECT_INSTALL_MARK, report)
    return vx


def attach(client=None, *, verifiedx=None, framework_version: str | None = None):
    vx = install(verifiedx=verifiedx, framework_version=framework_version)
    return client if client is not None else vx


def extract_prompt_messages(
    *,
    messages: Any,
    system: Any = None,
) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    system_text = _system_text(system)
    if system_text:
        normalized.append({"role": "system", "content": system_text})

    if not isinstance(messages, list):
        return normalized

    for item in messages:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip().lower()
        if role not in {"user", "assistant"}:
            continue
        content = _message_text(item.get("content"))
        if not content:
            continue
        normalized.append(
            {
                "role": role,
                "content": content,
                **({"message_id": item.get("id")} if item.get("id") else {}),
            }
        )
    return normalized


def normalize_tool_definitions(raw_tools: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_tools, list):
        return []
    normalized: list[dict[str, Any]] = []
    for tool in raw_tools:
        if not isinstance(tool, dict):
            continue
        tool_name = str(tool.get("name") or "").strip()
        if not tool_name:
            continue
        tool_type = str(tool.get("type") or tool_name).strip()
        semantic_class = _tool_semantic_class(
            raw_name=tool_name,
            native_tool_type=tool_type,
            args={},
            provider_event_type="definition",
        )
        read_only = _tool_read_only(
            raw_name=tool_name,
            native_tool_type=tool_type,
            args={},
            provider_event_type="definition",
        )
        metadata: dict[str, Any] = {
            "native_tool_type": tool_type,
            "provider_executed": tool_type in ANTHROPIC_DIRECT_SERVER_TOOL_TYPES,
        }
        if semantic_class:
            metadata["semantic_class"] = semantic_class
        if read_only:
            metadata["read_only"] = True
        if semantic_class in ANTHROPIC_DIRECT_RETRIEVAL_CLASSES:
            metadata["retrieval_like"] = True
        normalized.append(
            {
                "tool_name": tool_name,
                "schema": tool.get("input_schema") or tool.get("inputSchema") or {"type": "object", "additionalProperties": True},
                "docstring": tool.get("description"),
                "metadata": metadata,
            }
        )
    return normalized


def normalize_message_tool_calls(
    result: Any,
    *,
    result_mapping: Callable[[Any], dict[str, Any] | None],
    normalize_tool_arguments: Callable[[Any], dict[str, Any]],
    tool_definitions: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    mapped = result_mapping(result) or {}
    content = mapped.get("content")
    if not isinstance(content, list):
        content = getattr(result, "content", None) or []
    definitions_by_name = {
        str(item.get("tool_name") or "").strip(): item
        for item in (tool_definitions or [])
        if isinstance(item, dict) and str(item.get("tool_name") or "").strip()
    }

    normalized_calls: list[dict[str, Any]] = []
    for block in content:
        payload = block if isinstance(block, dict) else (result_mapping(block) or {})
        if not isinstance(payload, dict):
            continue
        provider_event_type = str(payload.get("type") or "").strip().lower()
        if provider_event_type not in {"tool_use", "server_tool_use"}:
            continue
        tool_name = str(payload.get("name") or "").strip()
        if not tool_name:
            continue
        args = normalize_tool_arguments(payload.get("input"))
        definition = definitions_by_name.get(tool_name) or {}
        metadata = definition.get("metadata") if isinstance(definition.get("metadata"), dict) else {}
        native_tool_type = str(metadata.get("native_tool_type") or tool_name).strip()
        semantic_class = _tool_semantic_class(
            raw_name=tool_name,
            native_tool_type=native_tool_type,
            args=args,
            provider_event_type=provider_event_type,
        )
        read_only = _tool_read_only(
            raw_name=tool_name,
            native_tool_type=native_tool_type,
            args=args,
            provider_event_type=provider_event_type,
        )
        pending_action = describe_pending_action(
            raw_name=tool_name,
            native_tool_type=native_tool_type,
            provider_event_type=provider_event_type,
            args=args,
            command=_tool_command(args),
            dispatch_target=lambda current_name, current_args: _dispatch_target(current_name, current_args),
        )
        record = {
            "tool_name": tool_name,
            "raw_name": tool_name,
            "tool_call_id": payload.get("id"),
            "source": f"anthropic.messages.{provider_event_type}",
            "args": args,
            "raw_args": args,
            "provider_event_type": provider_event_type,
        }
        if semantic_class:
            record["semantic_class"] = semantic_class
        if read_only:
            record["read_only"] = True
        if semantic_class in ANTHROPIC_DIRECT_RETRIEVAL_CLASSES:
            record["retrieval_like"] = True
        if provider_event_type == "server_tool_use":
            record["provider_executed"] = True
        if pending_action is not None:
            record["pending_action"] = pending_action
        normalized_calls.append(record)
    return normalized_calls


def assistant_text(
    result: Any,
    *,
    result_mapping: Callable[[Any], dict[str, Any] | None],
) -> str | None:
    mapped = result_mapping(result) or {}
    content = mapped.get("content")
    if not isinstance(content, list):
        content = getattr(result, "content", None) or []
    parts: list[str] = []
    for block in content:
        payload = block if isinstance(block, dict) else (result_mapping(block) or {})
        if not isinstance(payload, dict):
            continue
        if str(payload.get("type") or "").strip().lower() != "text":
            continue
        text = _message_text(payload.get("text"))
        if text:
            parts.append(text)
    joined = " ".join(part for part in parts if part).strip()
    return joined or None


def describe_pending_action(
    *,
    raw_name: str,
    native_tool_type: str,
    provider_event_type: str,
    args: dict[str, Any],
    command: str,
    dispatch_target: Callable[[str, dict[str, Any]], str],
) -> dict[str, Any] | None:
    if str(provider_event_type or "").strip().lower() == "server_tool_use":
        return None
    tool_type = str(native_tool_type or "").strip().lower()
    normalized_command = str(command or "").strip().lower()
    target = dispatch_target(raw_name or tool_type, args)
    if tool_type == "memory_20250818" and normalized_command in ANTHROPIC_DIRECT_MUTATING_COMMANDS:
        return {
            "surface": "memory_write",
            "operation": raw_name or tool_type,
            "target": target,
            "method": normalized_command or "write",
            "raw_args": dict(args),
            "boundary_kind": "memory_write",
            "action_class": "memory_write",
            "trust_boundary_crossing": False,
        }
    if tool_type.startswith("text_editor_") and normalized_command in ANTHROPIC_DIRECT_MUTATING_COMMANDS:
        return {
            "surface": "file_write",
            "operation": raw_name or tool_type,
            "target": str(args.get("path") or args.get("file_path") or target),
            "method": normalized_command or "write",
            "raw_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": False,
        }
    if tool_type.startswith("bash_"):
        return {
            "surface": "tool_dispatch",
            "operation": raw_name or tool_type,
            "target": command or target or raw_name or tool_type,
            "method": "CALL",
            "raw_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": True,
        }
    return None


def requires_direct_boundary(
    *,
    raw_name: str,
    native_tool_type: str,
    provider_event_type: str,
    args: dict[str, Any],
    provider_executed: bool = False,
) -> bool:
    if provider_executed or str(provider_event_type or "").strip().lower() == "server_tool_use":
        return False
    tool_type = str(native_tool_type or "").strip().lower()
    command = _tool_command(args).lower()
    if tool_type == "memory_20250818":
        return command in ANTHROPIC_DIRECT_MUTATING_COMMANDS
    if tool_type.startswith("text_editor_"):
        return command in ANTHROPIC_DIRECT_MUTATING_COMMANDS
    if tool_type.startswith("bash_"):
        return True
    return False


def _system_text(system: Any) -> str:
    return _message_text(system)


def _message_text(value: Any) -> str:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, str):
                text = item.strip()
                if text:
                    parts.append(text)
                continue
            if not isinstance(item, dict):
                continue
            item_type = str(item.get("type") or "").strip().lower()
            if item_type not in {"text", "text_delta"}:
                continue
            text = _message_text(item.get("text"))
            if text:
                parts.append(text)
        return " ".join(part for part in parts if part).strip()
    if isinstance(value, dict):
        return _message_text(value.get("text") or value.get("content") or value.get("value"))
    return ""


def _tool_command(args: dict[str, Any]) -> str:
    for key in ("command", "action", "operation", "mode"):
        value = args.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _tool_semantic_class(
    *,
    raw_name: str,
    native_tool_type: str,
    args: dict[str, Any],
    provider_event_type: str,
) -> str | None:
    if str(provider_event_type or "").strip().lower() == "server_tool_use":
        mapped = ANTHROPIC_DIRECT_HISTORY_SEMANTICS.get(raw_name)
        if mapped:
            return mapped
        if raw_name == "text_editor_code_execution":
            return "file_mutation"
        if raw_name == "bash_code_execution":
            return "system_mutation"
        return None
    tool_type = str(native_tool_type or "").strip().lower()
    command = _tool_command(args).lower()
    if tool_type == "memory_20250818":
        return "memory_mutation" if command in ANTHROPIC_DIRECT_MUTATING_COMMANDS else "memory_read"
    if tool_type.startswith("text_editor_"):
        return "file_mutation" if command in ANTHROPIC_DIRECT_MUTATING_COMMANDS else "file_read"
    if tool_type.startswith("bash_"):
        return "system_mutation"
    return None


def _tool_read_only(
    *,
    raw_name: str,
    native_tool_type: str,
    args: dict[str, Any],
    provider_event_type: str,
) -> bool:
    semantic_class = _tool_semantic_class(
        raw_name=raw_name,
        native_tool_type=native_tool_type,
        args=args,
        provider_event_type=provider_event_type,
    )
    return semantic_class in ANTHROPIC_DIRECT_RETRIEVAL_CLASSES


def _dispatch_target(tool_name: str, args: dict[str, Any]) -> str:
    if isinstance(args.get("namespace"), str) and isinstance(args.get("key"), str):
        namespace = str(args.get("namespace") or "").strip()
        key = str(args.get("key") or "").strip()
        if namespace and key:
            return f"{namespace}/{key}"
    for key in (
        "path",
        "file_path",
        "url",
        "uri",
        "target",
        "recipient",
        "email",
        "channel",
        "workflow_id",
        "record_id",
        "id",
        "key",
    ):
        value = args.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return tool_name


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items() if key != "parsed_output"}
    for attr in ("model_dump", "to_dict", "dict"):
        fn = getattr(value, attr, None)
        if callable(fn):
            try:
                return _jsonable(fn())
            except TypeError:
                try:
                    return _jsonable(fn(mode="json"))
                except Exception:
                    pass
            except Exception:
                pass
    return str(value)


def _jsonish_object(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return _jsonable(value)
    if isinstance(value, str):
        normalized = value.strip()
        if not normalized:
            return {}
        try:
            parsed = json.loads(normalized)
        except Exception:
            return {"value": normalized}
        if isinstance(parsed, dict):
            return _jsonable(parsed)
        return {"value": _jsonable(parsed)}
    if value is None:
        return {}
    parsed = _jsonable(value)
    if isinstance(parsed, dict):
        return parsed
    return {"value": parsed}


def assistant_message_param(message: Any) -> dict[str, Any]:
    content = getattr(message, "content", None)
    if not isinstance(content, list):
        content = []
    return {
        "role": "assistant",
        "content": [_jsonable(block) for block in content],
    }


def tool_result_block(tool_use_id: str | None, payload: Any) -> dict[str, Any]:
    return {
        "type": "tool_result",
        "tool_use_id": tool_use_id,
        "content": json.dumps(_jsonable(payload)),
    }


def _handler_from_registry(tool_handlers: Any, tool_name: str) -> Callable:
    if isinstance(tool_handlers, dict):
        handler = tool_handlers.get(tool_name)
        if callable(handler):
            return handler
    raise KeyError(f"No Anthropic direct tool handler registered for {tool_name}")


def _execute_sync(value: Any):
    if inspect.isawaitable(value):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(value)
        raise RuntimeError(
            "Anthropic direct async tool handler returned an awaitable inside a running event loop. "
            "Use dispatch_tool_uses_async() in async contexts."
        )
    return value


def _guarded_handler(
    verifiedx,
    *,
    handler: Callable,
    tool_name: str,
    definition: dict[str, Any],
    args: dict[str, Any],
) -> Callable:
    metadata = definition.get("metadata") if isinstance(definition.get("metadata"), dict) else {}
    native_tool_type = str(metadata.get("native_tool_type") or tool_name).strip().lower()
    command = _tool_command(args).lower()
    schema = definition.get("schema")
    docstring = definition.get("docstring")

    if native_tool_type == "memory_20250818" and command in ANTHROPIC_DIRECT_MUTATING_COMMANDS:
        return verifiedx.wrap_memory_write(
            handler,
            namespace=lambda payload: str((payload or {}).get("namespace") or tool_name),
            key=lambda payload: str((payload or {}).get("key") or "value"),
            tool_name=tool_name,
            schema=schema,
            docstring=docstring,
        )

    if native_tool_type not in ANTHROPIC_DIRECT_TRIGGER_TOOL_TYPES:
        return verifiedx.wrap_tool_call(
            handler,
            tool_name=tool_name,
            schema=schema,
            docstring=docstring,
        )

    return handler


def create_tool_dispatcher(
    *,
    tool_handlers: dict[str, Callable],
    tools: list[dict[str, Any]],
    verifiedx=None,
    framework_version: str | None = None,
):
    vx = install(verifiedx=verifiedx, framework_version=framework_version)
    tool_definitions = normalize_tool_definitions(tools)
    definitions_by_name = {
        str(item.get("tool_name") or "").strip(): item
        for item in tool_definitions
        if isinstance(item, dict) and str(item.get("tool_name") or "").strip()
    }
    result_mapping = _jsonish_object
    normalize_tool_arguments = _jsonish_object

    def dispatch_tool_uses(message: Any) -> list[dict[str, Any]]:
        calls = normalize_message_tool_calls(
            message,
            result_mapping=result_mapping,
            normalize_tool_arguments=normalize_tool_arguments,
            tool_definitions=tool_definitions,
        )
        results: list[dict[str, Any]] = []
        for call in calls:
            if bool(call.get("provider_executed")):
                continue
            tool_name = str(call.get("raw_name") or "").strip()
            if not tool_name:
                continue
            handler = _handler_from_registry(tool_handlers, tool_name)
            definition = definitions_by_name.get(tool_name) or {
                "tool_name": tool_name,
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": None,
                "metadata": {},
            }
            guarded = _guarded_handler(
                vx,
                handler=handler,
                tool_name=tool_name,
                definition=definition,
                args=dict(call.get("raw_args") or {}),
            )
            result = _execute_sync(guarded(dict(call.get("raw_args") or {})))
            results.append(tool_result_block(call.get("tool_call_id"), result))
        return results

    async def dispatch_tool_uses_async(message: Any) -> list[dict[str, Any]]:
        calls = normalize_message_tool_calls(
            message,
            result_mapping=result_mapping,
            normalize_tool_arguments=normalize_tool_arguments,
            tool_definitions=tool_definitions,
        )
        results: list[dict[str, Any]] = []
        for call in calls:
            if bool(call.get("provider_executed")):
                continue
            tool_name = str(call.get("raw_name") or "").strip()
            if not tool_name:
                continue
            handler = _handler_from_registry(tool_handlers, tool_name)
            definition = definitions_by_name.get(tool_name) or {
                "tool_name": tool_name,
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": None,
                "metadata": {},
            }
            guarded = _guarded_handler(
                vx,
                handler=handler,
                tool_name=tool_name,
                definition=definition,
                args=dict(call.get("raw_args") or {}),
            )
            result = guarded(dict(call.get("raw_args") or {}))
            if inspect.isawaitable(result):
                result = await result
            results.append(tool_result_block(call.get("tool_call_id"), result))
        return results

    dispatch_tool_uses.async_dispatch = dispatch_tool_uses_async  # type: ignore[attr-defined]
    return dispatch_tool_uses
