from __future__ import annotations

import dataclasses
from collections.abc import Callable
import functools
import inspect


def _call_or_value(factory, *args, **kwargs):
    return _invoke_callable(factory, *args, **kwargs) if callable(factory) else factory


def _callable_signature(fn):
    try:
        return inspect.signature(fn)
    except (TypeError, ValueError):
        return None


def _preserve_wrapper_metadata(fn: Callable, wrapped: Callable) -> Callable:
    functools.update_wrapper(wrapped, fn)
    signature = _callable_signature(fn)
    if signature is not None:
        try:
            wrapped.__signature__ = signature
        except Exception:
            pass
    return wrapped


def _looks_like_signature_error(error: TypeError) -> bool:
    message = str(error)
    return any(
        token in message
        for token in (
            "unexpected keyword argument",
            "got multiple values for argument",
            "positional arguments but",
            "positional argument but",
        )
    )


def _filter_call_arguments(signature, args, kwargs):
    parameters = signature.parameters
    accepts_var_args = any(
        parameter.kind is inspect.Parameter.VAR_POSITIONAL for parameter in parameters.values()
    )
    accepts_var_kwargs = any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters.values()
    )
    positional_slots = sum(
        parameter.kind
        in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
        for parameter in parameters.values()
    )
    allowed_kwargs = {
        name
        for name, parameter in parameters.items()
        if parameter.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
    }
    filtered_args = args if accepts_var_args else args[:positional_slots]
    filtered_kwargs = kwargs if accepts_var_kwargs else {k: v for k, v in kwargs.items() if k in allowed_kwargs}
    return filtered_args, filtered_kwargs


def _invoke_callable(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except TypeError as error:
        if not _looks_like_signature_error(error):
            raise
        signature = _callable_signature(fn)
        if signature is None:
            raise
        filtered_args, filtered_kwargs = _filter_call_arguments(signature, args, kwargs)
        if filtered_args == args and filtered_kwargs == kwargs:
            raise
        return fn(*filtered_args, **filtered_kwargs)


def _capture_result(value):
    if isinstance(value, dict):
        return value
    if dataclasses.is_dataclass(value):
        try:
            return dataclasses.asdict(value)
        except TypeError:
            pass
    if hasattr(value, "model_dump"):
        try:
            return value.model_dump(mode="json")
        except TypeError:
            return value.model_dump()
    if hasattr(value, "dict") and callable(value.dict):
        return value.dict()
    return {"value": value}


def _maybe_label_context_ingress(
    verifiedx,
    object_payload: dict,
    *,
    source_uri: str | None = None,
    source_hint: str | None = None,
):
    if not verifiedx.config.direct_ingress_labeling or not verifiedx.runtime_enabled:
        return
    diagnostic = verifiedx.observe_runtime_ingress(
        object_payload,
        source_uri=source_uri,
        source_hint=source_hint,
    )
    if diagnostic is None:
        return
    request_payload, response = diagnostic
    verifiedx.record_ingress_diagnostic(
        "context_ingress_label",
        request_payload,
        response,
    )


def _is_async_callable(fn: Callable) -> bool:
    return inspect.iscoroutinefunction(fn) or inspect.iscoroutinefunction(
        getattr(fn, "__wrapped__", None)
    )


def _capture_llm_result(verifiedx, result, *, model_name: str, adapter, object_type: str):
    verifiedx.capture.llm_call(
        verifiedx.capture.build_object(object_type, _capture_result(result)),
        model_name=model_name,
        adapter=adapter,
    )


def _extract_response_message(result):
    if isinstance(result, dict):
        choices = result.get("choices") or []
        if not choices:
            return None
        choice = choices[0]
        message = choice.get("message") or {}
        return {
            "content": message.get("content"),
            "tool_calls": message.get("tool_calls") or [],
        }

    choices = getattr(result, "choices", None) or []
    if not choices:
        return None
    choice = choices[0]
    message = getattr(choice, "message", None)
    if message is None:
        return None
    return {
        "content": getattr(message, "content", None),
        "tool_calls": getattr(message, "tool_calls", None) or [],
    }


def _normalize_memory_key(namespace, key):
    if not isinstance(namespace, str) or not namespace or not isinstance(key, str):
        return key
    prefix = f"{namespace}/"
    if key.startswith(prefix):
        return key[len(prefix) :]
    return key


def _normalize_memory_call_arguments(args, kwargs, *, namespace=None):
    normalized_args = list(args)
    normalized_kwargs = dict(kwargs)
    resolved_namespace = normalized_kwargs.get("namespace", namespace)
    if resolved_namespace is None and normalized_args:
        resolved_namespace = normalized_args[0]
    if "key" in normalized_kwargs:
        normalized_kwargs["key"] = _normalize_memory_key(resolved_namespace, normalized_kwargs["key"])
    elif len(normalized_args) >= 2:
        normalized_args[1] = _normalize_memory_key(resolved_namespace, normalized_args[1])
    return tuple(normalized_args), normalized_kwargs


def _bind_partial_arguments(fn, args, kwargs) -> dict:
    signature = _callable_signature(fn)
    if signature is None:
        return {
            "args": list(args),
            "kwargs": dict(kwargs),
        }
    try:
        bound = signature.bind_partial(*args, **kwargs)
        bound.apply_defaults()
        return dict(bound.arguments)
    except TypeError:
        return {
            "args": list(args),
            "kwargs": dict(kwargs),
        }


def _infer_memory_write_transport_args(fn, args, kwargs, *, namespace=None, key=None) -> dict:
    bound = _bind_partial_arguments(fn, args, kwargs)
    resolved_namespace = bound.get("namespace", namespace)
    resolved_key = bound.get("key", key)
    if resolved_namespace is None and args:
        resolved_namespace = args[0]
    if resolved_key is None and len(args) >= 2:
        resolved_key = args[1]
    value = bound.get("value")
    if value is None and "kwargs" in bound:
        value = (bound.get("kwargs") or {}).get("value")
    if value is None and len(args) >= 3:
        value = args[2]
    return {
        "namespace": resolved_namespace,
        "key": resolved_key,
        "value": _capture_result(value) if value is not None else None,
    }



def wrap_llm_call(verifiedx, fn: Callable, *, model_name: str, activation_report=None, object_type="model_derived_assertion"):
    adapter = activation_report.to_adapter_context() if activation_report else None

    if _is_async_callable(fn):

        async def wrapped(*args, **kwargs):
            call_args = list(args)
            original_messages = None
            if call_args and isinstance(call_args[0], list):
                original_messages = list(call_args[0])
                if verifiedx.runtime_enabled:
                    verifiedx.record_conversation_window(
                        original_messages,
                        source="wrap_llm_call",
                        model_name=model_name,
                        capture_source_kind="wrapper",
                    )
                call_args[0] = verifiedx.augment_messages_with_loopback(call_args[0])
            result = await _invoke_callable(fn, *call_args, **kwargs)
            _capture_llm_result(
                verifiedx,
                result,
                model_name=model_name,
                adapter=adapter,
                object_type=object_type,
            )
            if original_messages is None:
                return result

            response_message = _extract_response_message(result)
            if response_message is None or response_message["tool_calls"]:
                return result

            forced_replan_message = verifiedx.forced_replan_message()
            if not forced_replan_message:
                return result

            follow_up_messages = list(call_args[0])
            follow_up_messages.append(
                {"role": "assistant", "content": response_message.get("content") or ""}
            )
            follow_up_messages.append({"role": "system", "content": forced_replan_message})
            follow_up_args = list(args)
            follow_up_args[0] = follow_up_messages
            if verifiedx.runtime_enabled:
                verifiedx.record_conversation_window(
                    follow_up_messages,
                    source="wrap_llm_call_follow_up",
                    model_name=model_name,
                    capture_source_kind="wrapper",
                )
            follow_up_result = await _invoke_callable(fn, *follow_up_args, **kwargs)
            _capture_llm_result(
                verifiedx,
                follow_up_result,
                model_name=model_name,
                adapter=adapter,
                object_type=object_type,
            )
            return follow_up_result

        return _preserve_wrapper_metadata(fn, wrapped)

    def wrapped(*args, **kwargs):
        call_args = list(args)
        original_messages = None
        if call_args and isinstance(call_args[0], list):
            original_messages = list(call_args[0])
            if verifiedx.runtime_enabled:
                verifiedx.record_conversation_window(
                    original_messages,
                    source="wrap_llm_call",
                    model_name=model_name,
                    capture_source_kind="wrapper",
                )
            call_args[0] = verifiedx.augment_messages_with_loopback(call_args[0])
        result = fn(*call_args, **kwargs)
        _capture_llm_result(
            verifiedx,
            result,
            model_name=model_name,
            adapter=adapter,
            object_type=object_type,
        )
        if original_messages is None:
            return result

        response_message = _extract_response_message(result)
        if response_message is None or response_message["tool_calls"]:
            return result

        forced_replan_message = verifiedx.forced_replan_message()
        if not forced_replan_message:
            return result

        follow_up_messages = list(call_args[0])
        follow_up_messages.append(
            {"role": "assistant", "content": response_message.get("content") or ""}
        )
        follow_up_messages.append({"role": "system", "content": forced_replan_message})
        follow_up_args = list(args)
        follow_up_args[0] = follow_up_messages
        if verifiedx.runtime_enabled:
            verifiedx.record_conversation_window(
                follow_up_messages,
                source="wrap_llm_call_follow_up",
                model_name=model_name,
                capture_source_kind="wrapper",
            )
        follow_up_result = fn(*follow_up_args, **kwargs)
        _capture_llm_result(
            verifiedx,
            follow_up_result,
            model_name=model_name,
            adapter=adapter,
            object_type=object_type,
        )
        return follow_up_result

    return _preserve_wrapper_metadata(fn, wrapped)


def wrap_retrieve(verifiedx, fn: Callable, *, query: str, activation_report=None, object_type="internal_retrieval"):
    adapter = activation_report.to_adapter_context() if activation_report else None
    retrieval_name = getattr(fn, "__name__", None) or "retrieve"
    semantic_class = "external_retrieval" if object_type == "external_retrieval" else "internal_retrieval"

    def _record_history():
        if not verifiedx.runtime_enabled:
            return
        verifiedx.zero_touch.note_tool_selection(
            tool_name=retrieval_name,
            arguments={"query": query},
            schema={
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"],
            },
            docstring=f"Retrieve supporting evidence for `{query}`.",
            selection_metadata={
                "raw_name": retrieval_name,
                "raw_args": {"query": query},
                "semantic_class": semantic_class,
                "retrieval_like": True,
            },
            source="wrap_retrieve",
        )

    def _finalize(result):
        object_payload = verifiedx.capture.build_object(object_type, _capture_result(result))
        try:
            _maybe_label_context_ingress(
                verifiedx,
                object_payload,
                source_uri=(result or {}).get("url") if isinstance(result, dict) else None,
                source_hint=query,
            )
        except Exception:
            if verifiedx.config.strict_direct_ingress_labeling:
                raise
        verifiedx.capture.retrieve(
            object_payload,
            query=query,
            adapter=adapter,
        )
        verifiedx.note_observation(object_type=object_type, source_hint=query)
        return result

    if _is_async_callable(fn):

        async def wrapped(*args, **kwargs):
            _record_history()
            result = await _invoke_callable(fn, *args, **kwargs)
            return _finalize(result)

        return _preserve_wrapper_metadata(fn, wrapped)

    def wrapped(*args, **kwargs):
        _record_history()
        result = fn(*args, **kwargs)
        return _finalize(result)

    return _preserve_wrapper_metadata(fn, wrapped)


def wrap_tool_call(
    verifiedx,
    fn: Callable,
    *,
    tool_name: str,
    activation_report=None,
    object_type="tool_result",
    schema=None,
    docstring=None,
):
    adapter = activation_report.to_adapter_context() if activation_report else None

    def _runtime_context(args, kwargs):
        if not verifiedx.runtime_enabled:
            return None
        return verifiedx.derive_tool_runtime_context(
            fn,
            tool_name=tool_name,
            args=args,
            kwargs=kwargs,
            schema=schema,
            docstring=docstring,
            metadata={"raw_name": tool_name},
            source="wrap_tool_call",
        )

    def _selection_metadata(runtime_context):
        metadata = dict(getattr(runtime_context, "metadata", {}) or {})
        metadata.setdefault("raw_name", tool_name)
        raw_args = metadata.get("raw_args")
        if not isinstance(raw_args, dict) or not raw_args:
            metadata["raw_args"] = dict(getattr(runtime_context, "tool_args", {}) or {})
        return metadata

    def _direct_boundary_capture(runtime_context):
        if runtime_context is None:
            return None
        descriptor = runtime_context.descriptor()
        selection_metadata = _selection_metadata(runtime_context)
        verifiedx.zero_touch.note_tool_selection(
            tool_name=tool_name,
            arguments=selection_metadata.get("raw_args") if isinstance(selection_metadata.get("raw_args"), dict) else runtime_context.tool_args,
            schema=runtime_context.schema,
            docstring=runtime_context.docstring,
            selection_metadata=selection_metadata,
            source=runtime_context.source,
        )
        if not verifiedx.zero_touch.requires_direct_tool_boundary(
            tool_descriptor=descriptor,
            source=runtime_context.source,
        ):
            return None
        return verifiedx.zero_touch.describe_selected_tool_boundary(
            tool_descriptor=descriptor,
            source=runtime_context.source,
        )

    def _finalize(result):
        object_payload = verifiedx.capture.build_object(object_type, _capture_result(result))
        try:
            _maybe_label_context_ingress(
                verifiedx,
                object_payload,
                source_uri=f"tool://{tool_name}",
                source_hint=tool_name,
            )
        except Exception:
            if verifiedx.config.strict_direct_ingress_labeling:
                raise
        verifiedx.capture.tool_call(
            object_payload,
            tool_name=tool_name,
            adapter=adapter,
        )
        verifiedx.note_observation(object_type=object_type, source_hint=tool_name)
        return result

    if _is_async_callable(fn):

        async def wrapped(*args, **kwargs):
            runtime_context = _runtime_context(args, kwargs)
            try:
                if runtime_context is None:
                    result = await _invoke_callable(fn, *args, **kwargs)
                else:
                    capture = _direct_boundary_capture(runtime_context)
                    with verifiedx.tool_runtime_scope(runtime_context):
                        if capture is None:
                            result = await _invoke_callable(fn, *args, **kwargs)
                        else:
                            async def execute():
                                return await _invoke_callable(fn, *args, **kwargs)

                            result = await verifiedx.zero_touch.intercept_boundary_async(
                                surface=str(capture["surface"]),
                                operation=str(capture["operation"]),
                                target=str(capture["target"]),
                                method=capture.get("method"),
                                transport_args=dict(capture.get("transport_args") or runtime_context.tool_args),
                                boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                                action_class=capture.get("action_class"),
                                trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                                pending_effect=dict(capture.get("transport_args") or runtime_context.tool_args),
                                tool_descriptor=runtime_context.descriptor(),
                                execute=execute,
                            )
            except Exception as error:
                handled = verifiedx.handle_runtime_tool_error(error)
                if handled is None:
                    raise
                result = handled
            return _finalize(result)

        return _preserve_wrapper_metadata(fn, wrapped)

    def wrapped(*args, **kwargs):
        runtime_context = _runtime_context(args, kwargs)
        try:
            if runtime_context is None:
                result = fn(*args, **kwargs)
            else:
                capture = _direct_boundary_capture(runtime_context)
                with verifiedx.tool_runtime_scope(runtime_context):
                    if capture is None:
                        result = fn(*args, **kwargs)
                    else:
                        result = verifiedx.zero_touch.intercept_boundary(
                            surface=str(capture["surface"]),
                            operation=str(capture["operation"]),
                            target=str(capture["target"]),
                            method=capture.get("method"),
                            transport_args=dict(capture.get("transport_args") or runtime_context.tool_args),
                            boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                            action_class=capture.get("action_class"),
                            trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                            pending_effect=dict(capture.get("transport_args") or runtime_context.tool_args),
                            tool_descriptor=runtime_context.descriptor(),
                            execute=lambda: fn(*args, **kwargs),
                        )
        except Exception as error:
            handled = verifiedx.handle_runtime_tool_error(error)
            if handled is None:
                raise
            result = handled
        return _finalize(result)

    return _preserve_wrapper_metadata(fn, wrapped)


def wrap_memory_read(
    verifiedx,
    fn: Callable,
    *,
    namespace: str,
    key: str,
    activation_report=None,
    object_type="memory_record",
):
    adapter = activation_report.to_adapter_context() if activation_report else None

    def _finalize(result):
        object_payload = verifiedx.capture.build_object(object_type, _capture_result(result))
        try:
            _maybe_label_context_ingress(
                verifiedx,
                object_payload,
                source_uri=f"memory://{namespace}/{key}",
                source_hint=f"{namespace}/{key}",
            )
        except Exception:
            if verifiedx.config.strict_direct_ingress_labeling:
                raise
        verifiedx.capture.memory_read(
            object_payload,
            namespace=namespace,
            key=key,
            adapter=adapter,
        )
        verifiedx.note_observation(object_type=object_type, source_hint=f"{namespace}/{key}")
        return result

    if _is_async_callable(fn):

        async def wrapped(*args, **kwargs):
            result = await _invoke_callable(fn, *args, **kwargs)
            return _finalize(result)

        return _preserve_wrapper_metadata(fn, wrapped)

    def wrapped(*args, **kwargs):
        result = fn(*args, **kwargs)
        return _finalize(result)

    return _preserve_wrapper_metadata(fn, wrapped)


def wrap_memory_write(
    verifiedx,
    fn: Callable,
    *,
    namespace=None,
    key=None,
    goal_state_hint=None,
    activation_report=None,
    tool_name=None,
    schema=None,
    docstring=None,
):
    adapter = activation_report.to_adapter_context() if activation_report else None
    verifiedx.register_runtime_contract(boundary_kind="memory_write")
    if not verifiedx.runtime_enabled:
        raise ValueError(
            "`install_runtime()` must be active before wrapping memory writes; "
            "the legacy semantic fallback path has been removed."
        )

    def _resolve_memory_write_state(args, kwargs):
        resolved_namespace = _call_or_value(namespace, *args, **kwargs)
        resolved_key = _call_or_value(key, *args, **kwargs)
        transport_args = _infer_memory_write_transport_args(
            fn,
            args,
            kwargs,
            namespace=resolved_namespace,
            key=resolved_key,
        )
        resolved_namespace = resolved_namespace or transport_args.get("namespace")
        resolved_key = resolved_key or transport_args.get("key")
        return resolved_namespace, resolved_key, transport_args

    def _record_preflight(resolved_namespace, resolved_key, transport_args):
        verifiedx.capture.memory_write_preflight(
            verifiedx.capture.build_object("pending_memory_write", transport_args),
            namespace=resolved_namespace,
            key=resolved_key,
            adapter=adapter,
            boundary="memory_write",
        )

    def _record_history(runtime_context, transport_args):
        verifiedx.zero_touch.note_tool_selection(
            tool_name=runtime_context.tool_name,
            arguments=transport_args,
            schema=runtime_context.schema,
            docstring=runtime_context.docstring,
            selection_metadata={
                "raw_name": runtime_context.tool_name,
                "raw_args": transport_args,
                "semantic_class": "memory_mutation",
            },
            source=runtime_context.source,
        )

    if _is_async_callable(fn):

        async def wrapped(*args, **kwargs):
            resolved_namespace, resolved_key, transport_args = _resolve_memory_write_state(
                args,
                kwargs,
            )
            _record_preflight(resolved_namespace, resolved_key, transport_args)
            runtime_context = verifiedx.derive_tool_runtime_context(
                fn,
                tool_name=tool_name or getattr(fn, "__name__", "memory_write"),
                args=args,
                kwargs=kwargs,
                schema=schema,
                docstring=docstring,
                source="wrap_memory_write_v2",
            )
            try:
                _record_history(runtime_context, transport_args)
                with verifiedx.tool_runtime_scope(runtime_context):
                    call_args, call_kwargs = _normalize_memory_call_arguments(
                        args,
                        kwargs,
                        namespace=resolved_namespace,
                    )

                    async def execute():
                        return await _invoke_callable(fn, *call_args, **call_kwargs)

                    return await verifiedx.zero_touch.intercept_boundary_async(
                        surface="memory_write",
                        operation=tool_name or getattr(fn, "__name__", "memory_write"),
                        target=f"{resolved_namespace}/{resolved_key}",
                        method="write",
                        transport_args=transport_args,
                        boundary_kind="memory_write",
                        trust_boundary_crossing=False,
                        goal_state_hint=goal_state_hint,
                        pending_effect=transport_args,
                        execute=execute,
                    )
            except Exception as error:
                handled = verifiedx.handle_runtime_tool_error(error)
                if handled is not None:
                    return handled
                raise

        return _preserve_wrapper_metadata(fn, wrapped)

    def wrapped(*args, **kwargs):
        resolved_namespace, resolved_key, transport_args = _resolve_memory_write_state(args, kwargs)
        _record_preflight(resolved_namespace, resolved_key, transport_args)
        runtime_context = verifiedx.derive_tool_runtime_context(
            fn,
            tool_name=tool_name or getattr(fn, "__name__", "memory_write"),
            args=args,
            kwargs=kwargs,
            schema=schema,
            docstring=docstring,
            source="wrap_memory_write_v2",
        )
        try:
            _record_history(runtime_context, transport_args)
            with verifiedx.tool_runtime_scope(runtime_context):
                call_args, call_kwargs = _normalize_memory_call_arguments(
                    args,
                    kwargs,
                    namespace=resolved_namespace,
                )
                return verifiedx.zero_touch.intercept_boundary(
                    surface="memory_write",
                    operation=tool_name or getattr(fn, "__name__", "memory_write"),
                    target=f"{resolved_namespace}/{resolved_key}",
                    method="write",
                    transport_args=transport_args,
                    boundary_kind="memory_write",
                    trust_boundary_crossing=False,
                    goal_state_hint=goal_state_hint,
                    pending_effect=transport_args,
                    execute=lambda: _invoke_callable(fn, *call_args, **call_kwargs),
                )
        except Exception as error:
            handled = verifiedx.handle_runtime_tool_error(error)
            if handled is not None:
                return handled
            raise

    return _preserve_wrapper_metadata(fn, wrapped)


def wrap_action_execute(
    verifiedx,
    fn: Callable,
    *,
    activation_report=None,
    tool_name=None,
    object_type="tool_result",
    schema=None,
    docstring=None,
):
    return wrap_tool_call(
        verifiedx,
        fn,
        tool_name=tool_name or getattr(fn, "__name__", "tool_call"),
        activation_report=activation_report,
        object_type=object_type,
        schema=schema,
        docstring=docstring,
    )
