from __future__ import annotations

from .errors import BoundaryDeniedError


class VerifiedXLangChainMiddleware:
    def __init__(self, verifiedx, report):
        self._verifiedx = verifiedx
        self._report = report
        self.name = "VerifiedXMiddleware"

    def wrap_model_call(self, request, handler):
        model_name = getattr(getattr(request, "model", None), "model_name", None) or getattr(
            getattr(request, "model", None),
            "model_id",
            "unknown-model",
        )
        messages = getattr(request, "messages", None)
        if isinstance(messages, list) and self._verifiedx.runtime_enabled:
            self._verifiedx.record_conversation_window(
                [
                    {
                        "role": getattr(message, "type", None) or getattr(message, "role", "user"),
                        "content": getattr(message, "content", None) or str(message),
                    }
                    for message in messages
                ],
                source="langchain_model_call",
                model_name=model_name,
                request_kind="langchain_model_call",
                request_metadata={"request": str(request)},
                capture_source_kind="wrapper",
            )
        response = handler(request)
        self._verifiedx.capture.llm_call(
            self._verifiedx.capture.build_object(
                "model_derived_assertion",
                {"request": str(request), "response": str(response)},
                source_lineage=["langchain"],
            ),
            model_name=model_name,
            adapter=self._report.to_adapter_context(),
        )
        return response

    def wrap_tool_call(self, request, handler):
        try:
            runtime_context = None
            direct_capture = None
            raw_args = getattr(getattr(request, "tool_call", None), "args", None)
            if not isinstance(raw_args, dict):
                raw_args = getattr(getattr(request, "tool_call", None), "arguments", None)
            if not isinstance(raw_args, dict):
                raw_args = getattr(getattr(request, "tool_call", None), "input", None)
            if not isinstance(raw_args, dict):
                raw_args = None
            if self._verifiedx.runtime_enabled:
                runtime_context = self._verifiedx.derive_tool_runtime_context(
                    handler,
                    tool_name=getattr(getattr(request, "tool_call", None), "name", None)
                    or "unknown-tool",
                    args=(request,),
                    kwargs={},
                    metadata={
                        "raw_name": getattr(getattr(request, "tool_call", None), "name", None)
                        or "unknown-tool",
                        **({"raw_args": raw_args} if isinstance(raw_args, dict) and raw_args else {}),
                    },
                    source="langchain_tool_call",
                )
                self._verifiedx.zero_touch.note_tool_selection(
                    tool_name=runtime_context.tool_name,
                    arguments=raw_args if isinstance(raw_args, dict) else runtime_context.tool_args,
                    schema=runtime_context.schema,
                    docstring=runtime_context.docstring,
                    selection_metadata={
                        **(runtime_context.metadata or {}),
                        "raw_args": (
                            dict(raw_args)
                            if isinstance(raw_args, dict)
                            else dict((runtime_context.metadata or {}).get("raw_args") or runtime_context.tool_args or {})
                        ),
                    },
                    source=runtime_context.source,
                )
                if self._verifiedx.zero_touch.requires_direct_tool_boundary(
                    tool_descriptor=runtime_context.descriptor(),
                    source=runtime_context.source,
                ):
                    direct_capture = self._verifiedx.zero_touch.describe_selected_tool_boundary(
                        tool_descriptor=runtime_context.descriptor(),
                        source=runtime_context.source,
                    )
            if runtime_context is None:
                result = handler(request)
            else:
                with self._verifiedx.tool_runtime_scope(runtime_context):
                    if direct_capture is None:
                        result = handler(request)
                    else:
                        result = self._verifiedx.zero_touch.intercept_boundary(
                            surface=str(direct_capture["surface"]),
                            operation=str(direct_capture["operation"]),
                            target=str(direct_capture["target"]),
                            method=direct_capture.get("method"),
                            transport_args=dict(
                                direct_capture.get("transport_args") or runtime_context.tool_args
                            ),
                            boundary_kind=str(direct_capture.get("boundary_kind") or "action_execute"),
                            action_class=direct_capture.get("action_class"),
                            trust_boundary_crossing=bool(direct_capture.get("trust_boundary_crossing")),
                            pending_effect=dict(
                                direct_capture.get("transport_args") or runtime_context.tool_args
                            ),
                            tool_descriptor=runtime_context.descriptor(),
                            execute=lambda: handler(request),
                        )
                    if direct_capture is None:
                        try:
                            from langgraph.types import Command
                        except Exception:
                            Command = None
                        update_payload = getattr(result, "update", None)
                        if Command is not None and isinstance(result, Command) and update_payload:
                            self._verifiedx.zero_touch.intercept_boundary(
                                surface="tool_dispatch",
                                operation="langgraph.Command.update",
                                target=str(runtime_context.tool_name),
                                method="update",
                                transport_args={"update": update_payload},
                                boundary_kind="action_execute",
                                action_class="generic",
                                trust_boundary_crossing=False,
                                pending_effect={"update": update_payload},
                                tool_descriptor=runtime_context.descriptor(),
                                execute=lambda: result,
                            )
        except BoundaryDeniedError as error:
            try:
                from langgraph.types import Command

                return Command(update={"verifiedx_loopback": error.loopback, "verifiedx_decision": error.decision})
            except Exception:
                raise
        except Exception as error:
            handled = self._verifiedx.handle_runtime_tool_error(error)
            if handled is not None:
                return handled
            raise
        tool_name = getattr(getattr(request, "tool_call", None), "name", None) or "unknown-tool"
        self._verifiedx.capture.tool_call(
            self._verifiedx.capture.build_object(
                "tool_result",
                {"request": str(request), "result": str(result)},
                source_lineage=["langchain"],
            ),
            tool_name=tool_name,
            adapter=self._report.to_adapter_context(),
        )
        return result


def create_agent(*args, verifiedx=None, create_agent_callable=None, middleware=None, framework_version=None, **kwargs):
    from .runtime import init_verifiedx

    vx = verifiedx or init_verifiedx()
    if not vx.runtime_enabled:
        vx.install_runtime(framework_version=framework_version)
    report = vx.activation_report(
        "langchain",
        "native",
        ["middleware", "model_calls", "tool_calls", "runtime_loopback"],
        framework_version=framework_version,
    )
    vx.capture.set_default_adapter(report.to_adapter_context())
    if create_agent_callable is None:
        from langchain.agents import create_agent as create_agent_callable

    combined_middleware = [VerifiedXLangChainMiddleware(vx, report), *(middleware or kwargs.pop("middleware", []))]
    agent = create_agent_callable(*args, middleware=combined_middleware, **kwargs)
    setattr(agent, "__verifiedx_activation_report__", report.as_dict())
    return agent
