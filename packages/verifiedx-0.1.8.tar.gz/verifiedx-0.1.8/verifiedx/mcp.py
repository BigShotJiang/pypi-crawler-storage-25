from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .wrappers import (
    _capture_result,
    _invoke_callable,
    _is_async_callable,
    _maybe_label_context_ingress,
    _preserve_wrapper_metadata,
)


_MUTATION_HINTS = {
    "append",
    "apply",
    "archive",
    "create",
    "delete",
    "disable",
    "edit",
    "enable",
    "forget",
    "insert",
    "merge",
    "patch",
    "persist",
    "publish",
    "remember",
    "rename",
    "replace",
    "reroute",
    "route",
    "save",
    "send",
    "set",
    "store",
    "sync",
    "update",
    "upsert",
    "write",
}
_MEMORY_HINTS = {
    "context",
    "fact",
    "facts",
    "memories",
    "memory",
    "memo",
    "note",
    "notes",
    "preference",
    "preferences",
    "profile",
    "remember",
    "recall",
}
_RETRIEVAL_HINTS = {
    "find",
    "get",
    "grep",
    "list",
    "lookup",
    "read",
    "recall",
    "retrieve",
    "search",
    "view",
    "webfetch",
    "websearch",
}
_RECORD_HINTS = {
    "account",
    "case",
    "contact",
    "crm",
    "customer",
    "incident",
    "issue",
    "lead",
    "opportunity",
    "order",
    "profile",
    "record",
    "reservation",
    "subscription",
    "task",
    "ticket",
    "user",
    "workflow",
}
_INTERNAL_HINTS = {
    "assignment",
    "config",
    "configuration",
    "flag",
    "metadata",
    "policy",
    "queue",
    "route",
    "routing",
    "rule",
    "setting",
    "settings",
    "stage",
    "state",
    "status",
    "thread",
    "workflow",
}
_MESSAGE_HINTS = {
    "comment",
    "email",
    "mail",
    "message",
    "notify",
    "reply",
    "send",
    "slack",
    "teams",
    "webhook",
}
_INTERNAL_STATE_HINTS = {
    "assignment",
    "config",
    "configuration",
    "flag",
    "metadata",
    "policy",
    "queue",
    "route",
    "routing",
    "setting",
    "settings",
    "stage",
    "state",
    "status",
    "thread",
    "workflow",
}


def _activation_report(verifiedx, activation_report=None):
    if not verifiedx.runtime_enabled:
        verifiedx.install_runtime()
    report = activation_report or verifiedx.activation_report(
        "mcp_tool",
        "native",
        ["tool_definitions", "tool_handlers", "runtime_loopback"],
    )
    verifiedx.capture.set_default_adapter(report.to_adapter_context())
    return report


def _meta_payload(verifiedx, tool_name: str, policy_scope: str) -> dict:
    context = verifiedx.capture.current_context()
    return {
        "verifiedx": {
            "run_id": context.run_id,
            "thread_id": context.thread_id,
            "step_id": context.step_id,
            "policy_scope": policy_scope,
            "tool_name": tool_name,
        }
    }


def _first_non_empty(*values: Any) -> str | None:
    for value in values:
        if isinstance(value, str):
            text = value.strip()
            if text:
                return text
    return None


def _token_set(*values: Any) -> set[str]:
    import json
    import re

    tokens: set[str] = set()
    for value in values:
        if value is None:
            continue
        if isinstance(value, (dict, list, tuple)):
            try:
                text = json.dumps(value, sort_keys=True, default=str)
            except Exception:
                text = str(value)
        else:
            text = str(value)
        for token in re.findall(r"[a-z0-9]+", text.lower()):
            if token:
                tokens.add(token)
    return tokens


def _key_names(value: Any, *, depth: int = 0) -> set[str]:
    if depth > 4 or value is None:
        return set()
    if isinstance(value, dict):
        names: set[str] = set()
        for key, nested in value.items():
            normalized = str(key).strip().lower()
            if normalized:
                names.add(normalized)
            names |= _key_names(nested, depth=depth + 1)
        return names
    if isinstance(value, list):
        names: set[str] = set()
        for nested in value:
            names |= _key_names(nested, depth=depth + 1)
        return names
    return set()


def _semantic_class(tool_name: str, params: dict[str, Any]) -> str | None:
    tokens = _token_set(tool_name, params)
    key_names = _key_names(params)
    has_mutation = bool(tokens & _MUTATION_HINTS)
    has_memory = bool(tokens & _MEMORY_HINTS)
    has_retrieval = bool(tokens & _RETRIEVAL_HINTS)
    has_message = bool(tokens & _MESSAGE_HINTS)
    has_record = bool(tokens & _RECORD_HINTS)
    has_internal = bool(tokens & _INTERNAL_HINTS)
    has_memory_contract = {"namespace", "key", "value"} <= key_names
    has_internal_state = bool(tokens & _INTERNAL_STATE_HINTS) or bool(
        key_names & _INTERNAL_STATE_HINTS
    )
    if has_memory and has_mutation:
        return "memory_mutation"
    if has_memory and has_retrieval:
        return "memory_read"
    if has_message:
        return "external_message_send"
    if has_internal and has_mutation and has_internal_state:
        return "system_mutation"
    if has_record and has_mutation:
        return "record_mutation"
    if has_internal and has_mutation:
        return "system_mutation"
    if has_retrieval:
        return "internal_retrieval"
    if has_memory_contract:
        return "memory_mutation"
    return None


def _tool_kind(tool_name: str, params: dict[str, Any], policy_scope: str) -> str | None:
    if policy_scope == "memory_write":
        return "memory_write"
    semantic = _semantic_class(tool_name, params)
    if semantic == "memory_mutation":
        return "memory_write"
    if semantic == "external_message_send":
        return "external_message_send"
    if semantic == "record_mutation":
        return "record_mutation"
    if semantic == "system_mutation":
        return "system_change"
    return None


def _pending_memory_write(tool_name: str, params: dict[str, Any]) -> dict[str, Any]:
    return {
        "namespace": params.get("namespace") or tool_name,
        "key": params.get("key") or params.get("id") or params.get("record_id") or params.get("name") or "value",
        "value": params.get("value") or params.get("patch") or params.get("update") or params.get("fields") or params,
        "write_kind": params.get("command") or params.get("action") or params.get("operation") or "write",
    }


def _pending_action(tool_name: str, params: dict[str, Any], action_class: str) -> dict[str, Any]:
    target = (
        params.get("workflow_id")
        or params.get("record_id")
        or params.get("customer_id")
        or params.get("ticket_id")
        or params.get("recipient")
        or params.get("email")
        or params.get("channel")
        or params.get("url")
        or params.get("id")
        or tool_name
    )
    return {
        "operation": tool_name,
        "target": {
            "target_class": (
                "record"
                if action_class == "record_mutation"
                else ("message_endpoint" if action_class == "external_message_send" else "internal_state")
            ),
            "target_identifier": str(target),
            "destination": str(target),
            "system_of_record": (
                "tool_record"
                if action_class == "record_mutation"
                else ("tool_message" if action_class == "external_message_send" else "tool_state")
            ),
        },
        "trust_boundary_crossing": bool(
            params.get("url")
            or params.get("uri")
            or params.get("recipient")
            or params.get("email")
            or params.get("address")
            or params.get("external")
            or params.get("public")
            or params.get("customer_visible")
        ),
        "executable_payload": params,
    }


def _selection_metadata(tool_name: str, params: dict[str, Any], policy_scope: str) -> dict[str, Any]:
    semantic = _semantic_class(tool_name, params)
    kind = _tool_kind(tool_name, params, policy_scope)
    metadata: dict[str, Any] = {
        "raw_name": tool_name,
        "raw_args": params,
        "semantic_class": semantic,
    }
    if semantic in {"internal_retrieval", "memory_read"}:
        metadata["retrieval_like"] = True
        metadata["read_only"] = True
    if kind == "memory_write":
        pending = _pending_memory_write(tool_name, params)
        metadata["pending_action"] = {
            "raw_name": tool_name,
            "surface": "memory_write",
            "method": str(pending.get("write_kind") or "write"),
            "target": f"{pending['namespace']}/{pending['key']}",
            "raw_args": params,
            "boundary_kind": "memory_write",
            "action_class": "memory_write",
            "trust_boundary_crossing": False,
        }
    elif kind in {"external_message_send", "record_mutation", "system_change"}:
        pending = _pending_action(tool_name, params, kind)
        metadata["pending_action"] = {
            "raw_name": tool_name,
            "surface": "tool_dispatch",
            "method": "SEND" if kind == "external_message_send" else "CALL",
            "target": str(pending["target"]["target_identifier"]),
            "raw_args": params,
            "boundary_kind": "action_execute",
            "action_class": kind,
            "trust_boundary_crossing": bool(pending["trust_boundary_crossing"]),
        }
    return metadata


def _definition_schema(definition: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(definition, dict):
        return None
    for key in ("input_schema", "inputSchema", "schema", "parameters"):
        value = definition.get(key)
        if isinstance(value, dict):
            return value
    function_payload = definition.get("function")
    if isinstance(function_payload, dict):
        parameters = function_payload.get("parameters")
        if isinstance(parameters, dict):
            return parameters
    return None


def _definition_docstring(definition: dict[str, Any] | None) -> str | None:
    if not isinstance(definition, dict):
        return None
    for key in ("description", "docstring"):
        text = _first_non_empty(definition.get(key))
        if text:
            return text
    function_payload = definition.get("function")
    if isinstance(function_payload, dict):
        return _first_non_empty(function_payload.get("description"))
    return None


def wrap_tool_handler(
    tool_name: str,
    handler: Callable,
    *,
    verifiedx,
    policy_scope: str = "action_execute",
    activation_report=None,
    definition: dict[str, Any] | None = None,
    schema: dict[str, Any] | None = None,
    docstring: str | None = None,
    tool_source: str = "mcp.tool_call",
    result_source_lineage: list[str] | None = None,
):
    report = _activation_report(verifiedx, activation_report=activation_report)
    adapter = report.to_adapter_context()
    resolved_schema = schema or _definition_schema(definition)
    resolved_docstring = docstring or _definition_docstring(definition)
    result_source_lineage = list(result_source_lineage or ["mcp_tool"])

    def _prepare_params(params: Any) -> dict[str, Any]:
        request_params = dict(params or {})
        request_meta = dict(request_params.get("_meta", {}))
        request_meta.update(_meta_payload(verifiedx, tool_name, policy_scope))
        request_params["_meta"] = request_meta
        return request_params

    def _runtime_context(request_params: dict[str, Any], args: tuple[Any, ...], kwargs: dict[str, Any]):
        metadata = _selection_metadata(tool_name, request_params, policy_scope)
        return verifiedx.derive_tool_runtime_context(
            handler,
            tool_name=tool_name,
            args=(request_params, *args),
            kwargs=kwargs,
            schema=resolved_schema,
            docstring=resolved_docstring,
            metadata=metadata,
            source=tool_source,
        )

    def _record_selection(runtime_context):
        verifiedx.zero_touch.note_tool_selection(
            tool_name=tool_name,
            arguments=runtime_context.tool_args,
            schema=runtime_context.schema,
            docstring=runtime_context.docstring,
            selection_metadata=dict(runtime_context.metadata or {}),
            source=runtime_context.source,
        )

    def _boundary_capture(runtime_context) -> tuple[str | None, dict[str, Any] | None]:
        metadata = dict(runtime_context.metadata or {})
        pending_action = metadata.get("pending_action")
        if not isinstance(pending_action, dict):
            return metadata.get("semantic_class"), None
        semantic = metadata.get("semantic_class")
        if str(pending_action.get("boundary_kind") or "") == "memory_write":
            return semantic, {
                "surface": "memory_write",
                "operation": tool_name,
                "target": str(pending_action.get("target") or tool_name),
                "method": str(pending_action.get("method") or "write"),
                "transport_args": dict(pending_action.get("raw_args") or runtime_context.tool_args),
                "boundary_kind": "memory_write",
                "action_class": "memory_write",
                "trust_boundary_crossing": False,
                "pending_effect": _pending_memory_write(tool_name, runtime_context.tool_args),
            }
        action_class = str(pending_action.get("action_class") or "system_change")
        pending_effect = _pending_action(tool_name, runtime_context.tool_args, action_class)
        return semantic, {
            "surface": "tool_dispatch",
            "operation": tool_name,
            "target": str(pending_action.get("target") or pending_effect["target"]["target_identifier"]),
            "method": str(pending_action.get("method") or ("SEND" if action_class == "external_message_send" else "CALL")),
            "transport_args": dict(pending_action.get("raw_args") or runtime_context.tool_args),
            "boundary_kind": "action_execute",
            "action_class": action_class,
            "trust_boundary_crossing": bool(pending_action.get("trust_boundary_crossing")),
            "pending_effect": runtime_context.tool_args,
        }

    def _finalize(request_params: dict[str, Any], result: Any, *, semantic: str | None):
        object_payload = verifiedx.capture.build_object(
            "tool_result",
            {"params": request_params, "result": _capture_result(result)},
            source_lineage=result_source_lineage,
        )
        try:
            _maybe_label_context_ingress(
                verifiedx,
                object_payload,
                source_uri=f"mcp://{tool_name}",
                source_hint=tool_name,
            )
        except Exception:
            if verifiedx.config.strict_direct_ingress_labeling:
                raise
        verifiedx.capture.tool_call(
            object_payload,
            tool_name=tool_name,
            adapter=adapter,
        )
        verifiedx.note_observation(
            object_type="external_retrieval" if semantic in {"internal_retrieval", "memory_read"} else "tool_result",
            source_hint=tool_name,
        )
        if isinstance(result, dict):
            merged = dict(result)
            result_meta = dict(merged.get("_meta", {}))
            result_meta.update(_meta_payload(verifiedx, tool_name, policy_scope))
            merged["_meta"] = result_meta
            return merged
        return result

    if _is_async_callable(handler):

        async def wrapped(params=None, *args, **kwargs):
            request_params = _prepare_params(params)
            runtime_context = _runtime_context(request_params, args, kwargs)
            _record_selection(runtime_context)
            semantic, capture = _boundary_capture(runtime_context)
            try:
                with verifiedx.tool_runtime_scope(runtime_context):
                    if capture is None:
                        result = await _invoke_callable(handler, request_params, *args, **kwargs)
                    else:

                        async def execute():
                            return await _invoke_callable(handler, request_params, *args, **kwargs)

                        result = await verifiedx.zero_touch.intercept_boundary_async(
                            surface=str(capture["surface"]),
                            operation=str(capture["operation"]),
                            target=str(capture["target"]),
                            method=capture.get("method"),
                            transport_args=dict(capture.get("transport_args") or request_params),
                            boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                            action_class=capture.get("action_class"),
                            trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                            pending_effect=dict(capture.get("pending_effect") or request_params),
                            tool_descriptor=runtime_context.descriptor(),
                            execute=execute,
                        )
            except Exception as error:
                handled = verifiedx.handle_runtime_tool_error(error)
                if handled is None:
                    raise
                result = handled
            return _finalize(request_params, result, semantic=semantic)

        wrapped = _preserve_wrapper_metadata(handler, wrapped)
        setattr(wrapped, "__verifiedx_activation_report__", report.as_dict())
        return wrapped

    def wrapped(params=None, *args, **kwargs):
        request_params = _prepare_params(params)
        runtime_context = _runtime_context(request_params, args, kwargs)
        _record_selection(runtime_context)
        semantic, capture = _boundary_capture(runtime_context)
        try:
            with verifiedx.tool_runtime_scope(runtime_context):
                if capture is None:
                    result = _invoke_callable(handler, request_params, *args, **kwargs)
                else:
                    result = verifiedx.zero_touch.intercept_boundary(
                        surface=str(capture["surface"]),
                        operation=str(capture["operation"]),
                        target=str(capture["target"]),
                        method=capture.get("method"),
                        transport_args=dict(capture.get("transport_args") or request_params),
                        boundary_kind=str(capture.get("boundary_kind") or "action_execute"),
                        action_class=capture.get("action_class"),
                        trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                        pending_effect=dict(capture.get("pending_effect") or request_params),
                        tool_descriptor=runtime_context.descriptor(),
                        execute=lambda: _invoke_callable(handler, request_params, *args, **kwargs),
                    )
        except Exception as error:
            handled = verifiedx.handle_runtime_tool_error(error)
            if handled is None:
                raise
            result = handled
        return _finalize(request_params, result, semantic=semantic)

    wrapped = _preserve_wrapper_metadata(handler, wrapped)
    setattr(wrapped, "__verifiedx_activation_report__", report.as_dict())
    return wrapped


def wrap_tool_definition(definition: dict, *, verifiedx, policy_scope: str = "action_execute") -> dict:
    report = _activation_report(verifiedx)
    wrapped = dict(definition)
    wrapped["_meta"] = {**wrapped.get("_meta", {}), **_meta_payload(verifiedx, wrapped.get("name", "mcp_tool"), policy_scope)}
    wrapped["__verifiedx_activation_report__"] = report.as_dict()
    return wrapped
