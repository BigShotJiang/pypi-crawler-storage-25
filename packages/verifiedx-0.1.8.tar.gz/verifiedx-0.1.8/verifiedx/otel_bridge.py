from __future__ import annotations

from dataclasses import dataclass, field
import importlib
import importlib.util
import json
import sys
from typing import Any


_INSTRUMENTOR_SPECS = (
    {
        "label": "openai",
        "module": "openinference.instrumentation.openai",
        "targets": ("openai",),
        "class_names": ("OpenAIInstrumentor",),
    },
    {
        "label": "openai_agents",
        "module": "openinference.instrumentation.openai_agents",
        "targets": ("agents", "openai_agents"),
        "class_names": ("OpenAIAgentsInstrumentor",),
    },
    {
        "label": "anthropic",
        "module": "openinference.instrumentation.anthropic",
        "targets": ("anthropic",),
        "class_names": ("AnthropicInstrumentor",),
    },
    {
        "label": "langchain",
        "module": "openinference.instrumentation.langchain",
        "targets": ("langchain", "langchain_core"),
        "class_names": ("LangChainInstrumentor",),
    },
    {
        "label": "litellm",
        "module": "openinference.instrumentation.litellm",
        "targets": ("litellm",),
        "class_names": ("LiteLLMInstrumentor",),
    },
    {
        "label": "mcp",
        "module": "openinference.instrumentation.mcp",
        "targets": ("mcp",),
        "class_names": ("MCPInstrumentor",),
    },
)

_PROCESS_ATTACHED_INSTRUMENTORS: set[str] = set()


@dataclass
class NormalizedCaptureEvent:
    kind: str
    object_type: str
    payload: dict[str, Any]
    source_lineage: list[str]
    model_name: str | None = None
    tool_name: str | None = None
    query: str | None = None
    approval_state: str | None = None
    descriptor: dict[str, Any] | None = None
    action_log_present: bool = False
    observation_object_type: str | None = None
    causality: dict[str, Any] = field(default_factory=dict)
    capture_gap_codes: list[str] = field(default_factory=list)
    weak_signals: list[str] = field(default_factory=list)
    conversation_window_update: dict[str, Any] | None = None


class VerifiedXSpanProcessor:
    def __init__(self, bridge: "VerifiedXOtelBridge"):
        self._bridge = bridge

    def on_start(self, span, parent_context=None):  # pragma: no cover
        return None

    def _on_starting(self, span, parent_context=None):  # pragma: no cover
        return self.on_start(span, parent_context=parent_context)

    def on_end(self, span):
        self._bridge.process_external_span(span)

    def _on_ending(self, span):  # pragma: no cover
        return self.on_end(span)

    def shutdown(self):  # pragma: no cover
        return None

    def force_flush(self, timeout_millis: int | None = None):  # pragma: no cover
        return True


class VerifiedXOtelBridge:
    def __init__(self, verifiedx):
        self.verifiedx = verifiedx
        self._started = False
        self._provider = None
        self._processor = None
        self.instrumentation_started = False
        self.capture_backends: list[str] = []
        self.attached_instrumentors: list[str] = []
        self.visibility_gap_signals: list[str] = []

    def apply_report(self, report) -> None:
        report.capture_backends = list(self.capture_backends)
        report.attached_instrumentors = list(self.attached_instrumentors)
        report.instrumentation_started = self.instrumentation_started
        for signal in self.visibility_gap_signals:
            if signal not in report.visibility_gap_signals:
                report.visibility_gap_signals.append(signal)

    def start(self, report=None) -> dict[str, Any]:
        if self._started:
            if report is not None:
                self.apply_report(report)
            return self.status()

        self.capture_backends = ["zero_touch"]
        provider = self._ensure_provider()
        if provider is None:
            self.visibility_gap_signals.append("otel_bridge_unavailable")
            self._started = True
            if report is not None:
                self.apply_report(report)
            return self.status()

        self._provider = provider
        self._ensure_processor(provider)
        self.instrumentation_started = True
        self.capture_backends.append("otel")
        self._attach_instrumentors(provider)
        if not self.attached_instrumentors:
            self._remember_gap_signal("otel_instrumentor_unavailable")
        self._started = True
        if report is not None:
            self.apply_report(report)
        return self.status()

    def status(self) -> dict[str, Any]:
        return {
            "instrumentation_started": self.instrumentation_started,
            "capture_backends": list(self.capture_backends),
            "attached_instrumentors": list(self.attached_instrumentors),
            "visibility_gap_signals": list(self.visibility_gap_signals),
        }

    def process_external_span(
        self,
        span: Any,
        *,
        capture_source_kind: str = "otel",
        source_lineage: list[str] | None = None,
        adapter=None,
    ) -> list[NormalizedCaptureEvent]:
        normalized = self._normalize_span(
            span,
            capture_source_kind=capture_source_kind,
            source_lineage=source_lineage,
        )
        if not normalized:
            return []

        for event in normalized:
            object_payload = self.verifiedx.capture.build_object(
                event.object_type,
                event.payload,
                source_lineage=event.source_lineage,
            )
            if event.kind == "llm_call":
                self.verifiedx.capture.llm_call(
                    object_payload,
                    model_name=event.model_name or "unknown-model",
                    adapter=adapter,
                    causality=event.causality,
                )
            elif event.kind == "tool_call":
                self.verifiedx.capture.tool_call(
                    object_payload,
                    tool_name=event.tool_name or "unknown-tool",
                    adapter=adapter,
                    causality=event.causality,
                )
            elif event.kind == "retrieve":
                self.verifiedx.capture.retrieve(
                    object_payload,
                    query=event.query or "unknown-query",
                    adapter=adapter,
                    causality=event.causality,
                )
            elif event.kind == "approval":
                self.verifiedx.capture.approval(
                    object_payload,
                    approval_state=event.approval_state or "observed",
                    adapter=adapter,
                    causality=event.causality,
                )
            elif event.kind == "subagent_spawn":
                self.verifiedx.capture.subagent_spawn(
                    object_payload,
                    descriptor=event.descriptor or {},
                    adapter=adapter,
                    causality=event.causality,
                )
            elif event.kind == "subagent_return":
                self.verifiedx.capture.subagent_return(
                    object_payload,
                    descriptor=event.descriptor or {},
                    action_log_present=event.action_log_present,
                    adapter=adapter,
                    causality=event.causality,
                )
            elif event.kind == "handoff_start":
                self.verifiedx.capture.handoff_start(
                    object_payload,
                    descriptor=event.descriptor or {},
                    adapter=adapter,
                    causality=event.causality,
                )
            elif event.kind == "handoff_accept":
                self.verifiedx.capture.handoff_accept(
                    object_payload,
                    descriptor=event.descriptor or {},
                    adapter=adapter,
                    causality=event.causality,
                )
            else:
                self.verifiedx.capture.summary(
                    object_payload,
                    adapter=adapter,
                    causality=event.causality,
                )

            if event.observation_object_type:
                self.verifiedx.note_observation(
                    object_type=event.observation_object_type,
                    source_hint=event.kind,
                )

            if event.conversation_window_update:
                update = dict(event.conversation_window_update)
                update.setdefault("capture_source_kind", capture_source_kind)
                update.setdefault("supported_adapter", True)
                update.setdefault("capture_gap_codes", list(event.capture_gap_codes))
                update.setdefault("weak_signals", list(event.weak_signals))
                update.setdefault("normalized_span_count_delta", 1)
                self.verifiedx.record_conversation_window(**update)

        return normalized

    def _ensure_provider(self):
        try:
            from opentelemetry import trace as ot_trace  # type: ignore
        except Exception:
            return None

        provider = ot_trace.get_tracer_provider()
        if hasattr(provider, "add_span_processor"):
            return provider

        try:
            from opentelemetry.sdk.trace import TracerProvider  # type: ignore
        except Exception:
            return None

        provider = TracerProvider()
        try:
            ot_trace.set_tracer_provider(provider)
        except Exception:
            pass
        return provider

    def _ensure_processor(self, provider) -> None:
        if self._processor is not None:
            return
        processor = VerifiedXSpanProcessor(self)
        provider.add_span_processor(processor)
        self._processor = processor

    def _attach_instrumentors(self, provider) -> None:
        for spec in _INSTRUMENTOR_SPECS:
            if not _has_available_target(spec["targets"]):
                continue
            if spec["label"] in _PROCESS_ATTACHED_INSTRUMENTORS:
                if spec["label"] not in self.attached_instrumentors:
                    self.attached_instrumentors.append(spec["label"])
                continue
            if any(target in sys.modules for target in spec["targets"]):
                self._remember_gap_signal("late_instrumentation_attach")
            module = _safe_import(spec["module"])
            if module is None:
                continue
            instrumentor_cls = _instrumentor_class(module, spec["class_names"])
            if instrumentor_cls is None:
                continue
            try:
                instrumentor = instrumentor_cls()
                try:
                    instrumentor.instrument(tracer_provider=provider)
                except TypeError:
                    instrumentor.instrument()
            except Exception:
                continue
            self.attached_instrumentors.append(spec["label"])
            _PROCESS_ATTACHED_INSTRUMENTORS.add(spec["label"])

    def _remember_gap_signal(self, signal: str) -> None:
        if signal not in self.visibility_gap_signals:
            self.visibility_gap_signals.append(signal)

    def _normalize_span(
        self,
        span: Any,
        *,
        capture_source_kind: str,
        source_lineage: list[str] | None,
    ) -> list[NormalizedCaptureEvent]:
        attrs = _span_attributes(span)
        flat_attrs = _flatten_attributes(attrs)
        span_name = str(
            getattr(span, "name", None)
            or getattr(span, "span_type", None)
            or getattr(span, "type", None)
            or "otel_span"
        )
        lineage = list(source_lineage or ["otel"])
        instrumentor_name = _instrumentor_name(span)
        if instrumentor_name and instrumentor_name not in lineage:
            lineage.append(instrumentor_name)

        messages = _extract_messages(flat_attrs)
        model_name = _extract_first(
            flat_attrs,
            "gen_ai.request.model",
            "gen_ai.response.model",
            "llm.model_name",
            "model",
            "model_name",
        )
        request_kind = _extract_first(
            flat_attrs,
            "gen_ai.operation.name",
            "operation.name",
            "operation",
            "request_kind",
        )
        tool_name = _extract_first(
            flat_attrs,
            "gen_ai.tool.name",
            "tool.name",
            "tool_name",
            "function.name",
            "name",
        )
        query = _extract_first(flat_attrs, "retrieval.query", "query", "search.query", "input.query")

        gap_codes: list[str] = []
        weak_signals: list[str] = []
        if any(key.startswith("llm.") for key in flat_attrs):
            gap_codes.append("legacy_semconv_observed")

        causality = _span_causality(span, flat_attrs)
        normalized_type = " ".join(
            part
            for part in (
                span_name,
                str(_extract_first(flat_attrs, "openinference.span.kind", "span.kind", "kind") or ""),
                str(request_kind or ""),
            )
            if part
        ).lower()

        if "subagent" in normalized_type and "spawn" in normalized_type:
            descriptor = _delegation_descriptor(flat_attrs, span_name, destination=tool_name or span_name)
            return [
                NormalizedCaptureEvent(
                    kind="subagent_spawn",
                    object_type="summary",
                    payload={"span_name": span_name, "attributes": attrs},
                    source_lineage=lineage,
                    descriptor=descriptor,
                    causality=causality,
                )
            ]
        if "subagent" in normalized_type and any(token in normalized_type for token in ("return", "result", "complete")):
            descriptor = _delegation_descriptor(flat_attrs, span_name, destination=tool_name or span_name)
            return [
                NormalizedCaptureEvent(
                    kind="subagent_return",
                    object_type="summary",
                    payload={"span_name": span_name, "attributes": attrs},
                    source_lineage=lineage,
                    descriptor=descriptor,
                    action_log_present=True,
                    causality=causality,
                )
            ]
        if "handoff" in normalized_type and "accept" in normalized_type:
            descriptor = _delegation_descriptor(flat_attrs, span_name, destination=tool_name or span_name)
            return [
                NormalizedCaptureEvent(
                    kind="handoff_accept",
                    object_type="summary",
                    payload={"span_name": span_name, "attributes": attrs},
                    source_lineage=lineage,
                    descriptor=descriptor,
                    causality=causality,
                )
            ]
        if "handoff" in normalized_type:
            descriptor = _delegation_descriptor(flat_attrs, span_name, destination=tool_name or span_name)
            return [
                NormalizedCaptureEvent(
                    kind="handoff_start",
                    object_type="summary",
                    payload={"span_name": span_name, "attributes": attrs},
                    source_lineage=lineage,
                    descriptor=descriptor,
                    causality=causality,
                )
            ]
        if any(token in normalized_type for token in ("guardrail", "approval", "tripwire")):
            return [
                NormalizedCaptureEvent(
                    kind="approval",
                    object_type="approval",
                    payload={"span_name": span_name, "attributes": attrs},
                    source_lineage=lineage,
                    approval_state="observed",
                    observation_object_type="approval",
                    causality=causality,
                )
            ]

        if _looks_like_retrieval(flat_attrs, normalized_type):
            return [
                NormalizedCaptureEvent(
                    kind="retrieve",
                    object_type="external_retrieval",
                    payload={"span_name": span_name, "attributes": attrs},
                    source_lineage=lineage,
                    query=query or span_name,
                    observation_object_type="external_retrieval",
                    causality=causality,
                )
            ]

        tool_definitions = _extract_tool_definitions(flat_attrs)
        tool_choice = _extract_first(flat_attrs, "gen_ai.request.tool_choice", "tool_choice", "function_call")
        tool_call_ids = _extract_tool_call_ids(flat_attrs)
        selected_tools = _extract_selected_tools(flat_attrs)
        inserted_context_object_ids = _extract_object_ids(
            flat_attrs,
            suffixes=("inserted_context_object_ids", "object_ids", "candidate_object_ids"),
        )

        is_tool_span = bool(tool_name and not messages and ("tool" in normalized_type or "function" in normalized_type))
        if is_tool_span:
            tool_args = _extract_first_value(
                flat_attrs,
                ("gen_ai.tool.arguments", "tool.arguments", "input.arguments", "arguments", "tool.input"),
            )
            if tool_args in {None, "", {}}:
                gap_codes.append("span_missing_tool_args")
            return [
                NormalizedCaptureEvent(
                    kind="tool_call",
                    object_type="tool_result",
                    payload={
                        "span_name": span_name,
                        "tool_name": tool_name,
                        "tool_call_id": tool_call_ids[0] if tool_call_ids else None,
                        "tool_args": _jsonable(tool_args),
                        "tool_result": _extract_first_value(
                            flat_attrs,
                            ("gen_ai.tool.result", "tool.result", "output", "result"),
                        ),
                        "attributes": attrs,
                    },
                    source_lineage=lineage,
                    tool_name=tool_name,
                    causality=causality,
                    capture_gap_codes=gap_codes,
                    weak_signals=weak_signals,
                )
            ]

        if model_name or messages or tool_definitions or tool_choice or tool_call_ids or selected_tools:
            if not messages:
                gap_codes.append("span_missing_messages")
            return [
                NormalizedCaptureEvent(
                    kind="llm_call",
                    object_type="model_derived_assertion",
                    payload={
                        "span_name": span_name,
                        "attributes": attrs,
                        "selected_tools": selected_tools,
                    },
                    source_lineage=lineage,
                    model_name=model_name or "unknown-model",
                    causality=causality,
                    capture_gap_codes=gap_codes,
                    weak_signals=weak_signals,
                    conversation_window_update={
                        "messages": messages,
                        "source": f"otel.{instrumentor_name or 'span'}",
                        "model_name": model_name,
                        "request_kind": request_kind or span_name or "otel_span",
                        "request_metadata": _request_metadata(flat_attrs),
                        "tool_choice": tool_choice,
                        "tool_definitions": tool_definitions,
                        "tool_call_ids": tool_call_ids,
                        "inserted_context_object_ids": inserted_context_object_ids,
                        "supported_adapter": True,
                        "capture_gap_codes": gap_codes,
                        "weak_signals": weak_signals,
                        "remember_messages_as_context": bool(messages),
                        "capture_source_kind": capture_source_kind,
                        "direct_label_all_prompt_roles": bool(instrumentor_name == "anthropic"),
                    },
                )
            ]

        return []


def _safe_import(module_name: str):
    try:
        return importlib.import_module(module_name)
    except Exception:
        return None


def _has_available_target(targets: tuple[str, ...]) -> bool:
    for target in targets:
        if target in sys.modules:
            return True
        try:
            if importlib.util.find_spec(target) is not None:
                return True
        except Exception:
            continue
    return False


def _instrumentor_class(module, class_names: tuple[str, ...]):
    for class_name in class_names:
        instrumentor_cls = getattr(module, class_name, None)
        if instrumentor_cls is not None:
            return instrumentor_cls
    for name in dir(module):
        if name.endswith("Instrumentor"):
            instrumentor_cls = getattr(module, name)
            if callable(instrumentor_cls):
                return instrumentor_cls
    return None


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    if hasattr(value, "model_dump"):
        try:
            return _jsonable(value.model_dump(mode="json"))
        except TypeError:
            return _jsonable(value.model_dump())
    if hasattr(value, "dict") and callable(value.dict):
        return _jsonable(value.dict())
    return str(value)


def _maybe_json(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    candidate = value.strip()
    if not candidate or candidate[0] not in "[{":
        return value
    try:
        return json.loads(candidate)
    except Exception:
        return value


def _flatten_attributes(value: Any, prefix: str = "") -> dict[str, Any]:
    flattened: dict[str, Any] = {}
    value = _jsonable(_maybe_json(value))
    if isinstance(value, dict):
        for key, item in value.items():
            next_prefix = f"{prefix}.{key}" if prefix else str(key)
            flattened.update(_flatten_attributes(item, next_prefix))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            next_prefix = f"{prefix}[{index}]"
            flattened.update(_flatten_attributes(item, next_prefix))
        if prefix:
            flattened[prefix] = value
    elif prefix:
        flattened[prefix] = value
    return flattened


def _span_attributes(span: Any) -> dict[str, Any]:
    attributes = getattr(span, "attributes", None)
    if isinstance(attributes, dict):
        return _jsonable(attributes)
    data = getattr(span, "data", None)
    if isinstance(data, dict):
        return _jsonable(data)
    return {}


def _extract_first(flat_attrs: dict[str, Any], *keys: str) -> str | None:
    value = _extract_first_value(flat_attrs, keys)
    if value is None or isinstance(value, (dict, list)):
        return None
    text = str(value).strip()
    return text or None


def _extract_first_value(flat_attrs: dict[str, Any], keys: tuple[str, ...] | list[str]) -> Any:
    exact_keys = tuple(keys)
    for key in exact_keys:
        if key in flat_attrs:
            return _maybe_json(flat_attrs[key])
    for flat_key, value in flat_attrs.items():
        for key in exact_keys:
            if flat_key.endswith(key):
                return _maybe_json(value)
    return None


def _extract_messages(flat_attrs: dict[str, Any]) -> list[dict[str, Any]]:
    candidates: list[tuple[str, Any]] = []
    for flat_key, value in flat_attrs.items():
        if not any(
            token in flat_key
            for token in (
                "input.messages",
                "messages",
                "prompt",
                "llm.input",
                "gen_ai.request.messages",
            )
        ):
            continue
        if any(
            flat_key.endswith(suffix)
            for suffix in (".role", ".content", ".text", ".message_id", ".timestamp")
        ):
            continue
        candidates.append((flat_key, _maybe_json(value)))
    candidates.sort(key=lambda item: (0 if "[" not in item[0] and "." not in item[0].rsplit("messages", 1)[-1] else 1, len(item[0])))
    for _, candidate in candidates:
        normalized = _messages_from_candidate(candidate)
        if normalized:
            return normalized
    return []


def _messages_from_candidate(candidate: Any) -> list[dict[str, Any]]:
    candidate = _maybe_json(candidate)
    if isinstance(candidate, dict):
        for key in ("messages", "input", "prompt", "value"):
            normalized = _messages_from_candidate(candidate.get(key))
            if normalized:
                return normalized
        if "role" in candidate or "content" in candidate:
            return [_normalize_message(candidate, index=0)]
        return []
    if isinstance(candidate, list):
        normalized = [
            _normalize_message(item, index=index)
            for index, item in enumerate(candidate)
            if item is not None
        ]
        return [message for message in normalized if message["content"]]
    if isinstance(candidate, str) and candidate.strip():
        return [{"role": "user", "content": candidate.strip(), "message_id": "msg_0", "timestamp": None}]
    return []


def _normalize_message(message: Any, *, index: int) -> dict[str, Any]:
    if isinstance(message, dict):
        role = str(message.get("role") or message.get("type") or "user")
        content = _content_text(message.get("content") or message.get("text") or message)
        message_id = str(message.get("id") or message.get("message_id") or f"msg_{index}")
        timestamp = message.get("timestamp")
    else:
        role = "user"
        content = _content_text(message)
        message_id = f"msg_{index}"
        timestamp = None
    return {
        "role": role,
        "content": content,
        "message_id": message_id,
        "timestamp": timestamp,
    }


def _content_text(value: Any) -> str:
    value = _maybe_json(value)
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("text", "content", "message", "body", "value"):
            nested = _content_text(value.get(key))
            if nested:
                return nested
        return json.dumps(_jsonable(value), sort_keys=True)
    if isinstance(value, (list, tuple)):
        parts = [_content_text(item) for item in value]
        return " ".join(part for part in parts if part).strip()
    return str(value)


def _extract_tool_definitions(flat_attrs: dict[str, Any]) -> list[dict[str, Any]]:
    candidates: list[Any] = []
    for flat_key, value in flat_attrs.items():
        if flat_key.endswith("tools") or flat_key.endswith("tool_definitions"):
            candidates.append(_maybe_json(value))
    for candidate in candidates:
        normalized = _normalize_tool_definitions(candidate)
        if normalized:
            return normalized
    return []


def _normalize_tool_definitions(candidate: Any) -> list[dict[str, Any]]:
    candidate = _maybe_json(candidate)
    if isinstance(candidate, dict):
        if "tools" in candidate:
            return _normalize_tool_definitions(candidate["tools"])
        if "name" in candidate or "function" in candidate:
            return [_normalize_tool_definition(candidate)]
        return []
    if not isinstance(candidate, list):
        return []
    normalized = [_normalize_tool_definition(item) for item in candidate]
    return [item for item in normalized if item.get("tool_name")]


def _normalize_tool_definition(candidate: Any) -> dict[str, Any]:
    candidate = _maybe_json(candidate)
    if isinstance(candidate, dict) and isinstance(candidate.get("function"), dict):
        function = candidate["function"]
        return {
            "tool_name": function.get("name") or candidate.get("name"),
            "description": function.get("description") or candidate.get("description"),
            "schema": _jsonable(
                function.get("parameters")
                or function.get("schema")
                or candidate.get("schema")
                or {}
            ),
        }
    if isinstance(candidate, dict):
        return {
            "tool_name": candidate.get("tool_name") or candidate.get("name"),
            "description": candidate.get("description"),
            "schema": _jsonable(candidate.get("schema") or candidate.get("parameters") or {}),
        }
    return {}


def _extract_tool_call_ids(flat_attrs: dict[str, Any]) -> list[str]:
    call_ids: list[str] = []
    for flat_key, value in flat_attrs.items():
        if flat_key.endswith("tool_call_id") or flat_key.endswith("call_id") or flat_key.endswith("tool_call_ids"):
            normalized = _maybe_json(value)
            if isinstance(normalized, list):
                call_ids.extend(str(item) for item in normalized if item)
            elif normalized:
                call_ids.append(str(normalized))
    return sorted(dict.fromkeys(call_ids))


def _extract_selected_tools(flat_attrs: dict[str, Any]) -> list[dict[str, Any]]:
    candidates: list[Any] = []
    for flat_key, value in flat_attrs.items():
        if "tool_calls" in flat_key or "selected_tools" in flat_key:
            candidates.append(_maybe_json(value))
    for candidate in candidates:
        normalized = _normalize_selected_tools(candidate)
        if normalized:
            return normalized
    return []


def _normalize_selected_tools(candidate: Any) -> list[dict[str, Any]]:
    candidate = _maybe_json(candidate)
    if isinstance(candidate, dict):
        if "tool_calls" in candidate:
            return _normalize_selected_tools(candidate["tool_calls"])
        if "name" in candidate or "function" in candidate:
            return [_normalize_selected_tool(candidate)]
        return []
    if not isinstance(candidate, list):
        return []
    normalized = [_normalize_selected_tool(item) for item in candidate]
    return [item for item in normalized if item.get("tool_name")]


def _normalize_selected_tool(candidate: Any) -> dict[str, Any]:
    candidate = _maybe_json(candidate)
    if isinstance(candidate, dict) and isinstance(candidate.get("function"), dict):
        function = candidate["function"]
        return {
            "tool_name": function.get("name") or candidate.get("name"),
            "tool_call_id": candidate.get("id") or candidate.get("call_id"),
            "args": _jsonable(_maybe_json(function.get("arguments"))),
        }
    if isinstance(candidate, dict):
        return {
            "tool_name": candidate.get("tool_name") or candidate.get("name"),
            "tool_call_id": candidate.get("tool_call_id") or candidate.get("id") or candidate.get("call_id"),
            "args": _jsonable(_maybe_json(candidate.get("arguments") or candidate.get("args"))),
        }
    return {}


def _extract_object_ids(flat_attrs: dict[str, Any], *, suffixes: tuple[str, ...]) -> list[str]:
    object_ids: list[str] = []
    for flat_key, value in flat_attrs.items():
        if any(flat_key.endswith(suffix) for suffix in suffixes):
            normalized = _maybe_json(value)
            if isinstance(normalized, list):
                object_ids.extend(str(item) for item in normalized if item)
            elif normalized:
                object_ids.append(str(normalized))
    return sorted(dict.fromkeys(object_ids))


def _request_metadata(flat_attrs: dict[str, Any]) -> dict[str, Any]:
    metadata: dict[str, Any] = {}
    for flat_key, value in flat_attrs.items():
        if any(
            token in flat_key
            for token in (
                "temperature",
                "max_tokens",
                "max_output_tokens",
                "metadata",
                "response_format",
                "parallel_tool_calls",
                "instructions",
            )
        ):
            metadata[flat_key] = _maybe_json(value)
    return metadata


def _span_causality(span: Any, flat_attrs: dict[str, Any]) -> dict[str, Any]:
    causality = {
        "framework_trace_id": None,
        "parent_event_id": None,
        "framework_run_id": _extract_first(flat_attrs, "verifiedx.run_id", "run_id"),
        "framework_checkpoint_id": _extract_first(flat_attrs, "verifiedx.checkpoint_id", "checkpoint_id"),
        "origin_step_id": _extract_first(flat_attrs, "verifiedx.step_id", "step_id"),
    }
    context = None
    try:
        context = span.get_span_context()
    except Exception:
        context = getattr(span, "context", None)
    if context is not None:
        trace_id = getattr(context, "trace_id", None)
        span_id = getattr(context, "span_id", None)
        if trace_id is not None:
            causality["framework_trace_id"] = f"{int(trace_id):032x}"
        if span_id is not None:
            causality["event_id"] = f"otel_{int(span_id):016x}"
    parent = getattr(span, "parent", None)
    parent_span_id = getattr(parent, "span_id", None)
    if parent_span_id is not None:
        causality["parent_event_id"] = f"otel_{int(parent_span_id):016x}"
    return {key: value for key, value in causality.items() if value is not None}


def _looks_like_retrieval(flat_attrs: dict[str, Any], normalized_type: str) -> bool:
    if any(token in normalized_type for token in ("retriev", "vector", "search")):
        return True
    return any(
        any(token in flat_key for token in ("retrieval", "documents", "vector", "search.query"))
        for flat_key in flat_attrs
    )


def _instrumentor_name(span: Any) -> str | None:
    for owner in (
        getattr(span, "instrumentation_scope", None),
        getattr(span, "instrumentation_info", None),
    ):
        name = getattr(owner, "name", None)
        if name:
            return str(name)
    attributes = getattr(span, "attributes", None)
    if isinstance(attributes, dict):
        for key in ("instrumentation_scope.name", "instrumentation.name"):
            value = attributes.get(key)
            if value:
                return str(value)
    return None


def _delegation_descriptor(flat_attrs: dict[str, Any], span_name: str, *, destination: str) -> dict[str, Any]:
    return {
        "destination": destination,
        "child_run_id": _extract_first(flat_attrs, "child_run_id", "run_id"),
        "child_thread_id": _extract_first(flat_attrs, "child_thread_id", "thread_id"),
        "depth": int(_extract_first(flat_attrs, "depth", "handoff_depth", "subagent_depth") or 1),
        "task_fingerprint": destination,
        "delegated_tool_scope": _maybe_json(
            _extract_first_value(flat_attrs, ("delegated_tool_scope", "tool_scope"))
        )
        or [],
        "delegated_memory_scope": _maybe_json(
            _extract_first_value(flat_attrs, ("delegated_memory_scope", "memory_scope"))
        )
        or [],
        "delegated_environment_scope": _maybe_json(
            _extract_first_value(flat_attrs, ("delegated_environment_scope", "environment_scope"))
        )
        or [],
        "allowed_action_classes": _maybe_json(
            _extract_first_value(flat_attrs, ("allowed_action_classes",))
        )
        or [],
        "span_name": span_name,
    }
