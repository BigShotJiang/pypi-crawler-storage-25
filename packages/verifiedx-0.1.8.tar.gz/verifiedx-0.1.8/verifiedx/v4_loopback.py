from __future__ import annotations

import json
import hashlib
from typing import Any

V4_BOUNDARY_PREFLIGHT_PATH = "/v4/runtime/boundaries/preflight"
V4_EXECUTION_REPORT_PATH = "/v4/runtime/boundaries/executions/report"


def _stable_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=str)


def hash_json(value: Any) -> str:
    return hashlib.sha256(_stable_json(value).encode("utf-8")).hexdigest()


def compute_candidate_hash(envelope: dict[str, Any], decision_context: dict[str, Any]) -> str:
    return hash_json(
        {
            "run_id": envelope.get("run_id"),
            "step_id": envelope.get("step_id"),
            "pending_action": decision_context.get("pending_action"),
            "provider": decision_context.get("provider"),
            "framework": decision_context.get("framework"),
        }
    )


def build_execution_anchor(
    *,
    envelope: dict[str, Any],
    boundary_kind: str,
    surface: str,
    operation: str,
    target: str,
    method: str | None,
    transport_args: dict[str, Any],
    trust_boundary_crossing: bool,
    decision_context: dict[str, Any],
) -> dict[str, Any]:
    return {
        "protocol_version": "v4",
        "boundary_kind": boundary_kind,
        "envelope": envelope,
        "decision_context": decision_context,
        "downstream_trace": {
            "surface": surface,
            "operation": operation,
            "target": target,
            "method": method,
            "args": transport_args,
            "metadata": {"runtime_install": True, "protocol_version": "v4"},
            "trust_boundary_crossing": trust_boundary_crossing,
        },
    }


def build_execution_report_payload(
    *,
    observed_boundary: dict[str, Any],
    candidate_hash: str,
    decision_id: str | None,
    boundary_kind: str,
    surface: str,
    operation: str,
    target: str,
    method: str | None,
    transport_args: dict[str, Any],
    result: Any,
    side_effect_executed: bool,
    error_message: str | None = None,
) -> dict[str, Any]:
    return {
        "observed_execution": {
            "envelope": observed_boundary["envelope"],
            "boundary_kind": boundary_kind,
            "decision_id": decision_id,
            "candidate_hash": candidate_hash,
            "downstream_trace": {
                "surface": surface,
                "operation": operation,
                "target": target,
                "method": method,
                "args": transport_args,
                "metadata": {"runtime_install": True, "protocol_version": "v4"},
                "trust_boundary_crossing": (
                    (observed_boundary.get("downstream_trace") or {}).get("trust_boundary_crossing")
                ),
            },
            "result": result,
            "side_effect_executed": side_effect_executed,
            "error_message": error_message,
            "metadata": {"runtime_install": True, "protocol_version": "v4"},
        }
    }


def post_preflight(client, payload: dict[str, Any], idempotency_key: str | None = None) -> dict:
    return client._post_json(V4_BOUNDARY_PREFLIGHT_PATH, payload, idempotency_key)


async def post_preflight_async(
    client,
    payload: dict[str, Any],
    idempotency_key: str | None = None,
) -> dict:
    return await client._post_json_async(V4_BOUNDARY_PREFLIGHT_PATH, payload, idempotency_key)


def post_execution_report(client, payload: dict[str, Any], idempotency_key: str | None = None) -> dict:
    return client._post_json(V4_EXECUTION_REPORT_PATH, payload, idempotency_key)


async def post_execution_report_async(
    client,
    payload: dict[str, Any],
    idempotency_key: str | None = None,
) -> dict:
    return await client._post_json_async(V4_EXECUTION_REPORT_PATH, payload, idempotency_key)
