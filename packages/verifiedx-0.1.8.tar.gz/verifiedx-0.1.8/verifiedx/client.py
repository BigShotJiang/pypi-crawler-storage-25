from __future__ import annotations

import asyncio
import gzip
import json
import uuid
from urllib import request as urllib_request
from urllib.error import HTTPError

from .config import VerifiedXConfig
from .errors import SandboxLimitReachedError, VerifiedXApiError
from .generated import (
    DECISION_PATH_TEMPLATE,
    EVENTS_BATCH_PATH,
    V4_BOUNDARY_PREFLIGHT_PATH,
    V4_EXECUTION_REPORT_PATH,
    V4_TAINT_PROBE_PATH,
)
from .zero_touch import suppress_runtime_capture

_GZIP_MIN_BYTES = 8192


class BoundaryClient:
    def __init__(self, config: VerifiedXConfig, transport=None):
        self.config = config
        self._transport = transport

    def _idempotency_key(self) -> str:
        return f"vx-{uuid.uuid4().hex}"

    def _headers(self, idempotency_key: str | None) -> dict[str, str]:
        headers = {"content-type": "application/json"}
        if self.config.api_key:
            headers["authorization"] = f"Bearer {self.config.api_key}"
        if idempotency_key:
            headers["idempotency-key"] = idempotency_key
        return headers

    @staticmethod
    def encode_json_body(payload: dict) -> tuple[bytes, int, str | None]:
        logical_body = json.dumps(payload).encode("utf-8")
        wire_body = logical_body
        encoding = None
        if len(logical_body) > _GZIP_MIN_BYTES:
            compressed = gzip.compress(logical_body)
            if len(compressed) < len(logical_body):
                wire_body = compressed
                encoding = "gzip"
        return wire_body, len(logical_body), encoding

    @staticmethod
    def _api_error(status: int | None, payload_text: str, reason: str | None):
        body = None
        if payload_text:
            try:
                body = json.loads(payload_text)
            except json.JSONDecodeError:
                body = payload_text

        error_payload = body.get("error") if isinstance(body, dict) and isinstance(body.get("error"), dict) else None
        message = None
        code = None
        retryable = None

        if error_payload is not None:
            message = error_payload.get("message")
            code = error_payload.get("code")
            retryable = error_payload.get("retryable")
        elif isinstance(body, dict):
            message = body.get("message")
            code = body.get("code")
            retryable = body.get("retryable")

        message = message or payload_text or reason or (
            f"VerifiedX API request failed with HTTP {status}" if status is not None else "VerifiedX API request failed"
        )

        if code == "sandbox_limit_reached":
            return SandboxLimitReachedError(
                message=message,
                status=status,
                retryable=retryable,
                body=body,
            )

        return VerifiedXApiError(
            message,
            status=status,
            code=code,
            retryable=retryable,
            body=body,
        )

    def _post_json(self, path: str, payload: dict, idempotency_key: str | None = None) -> dict:
        headers = self._headers(idempotency_key or self._idempotency_key())
        if self._transport is not None:
            return self._transport("POST", path, headers, payload)
        body, _, encoding = self.encode_json_body(payload)
        if encoding is not None:
            headers["content-encoding"] = encoding

        req = urllib_request.Request(
            f"{self.config.base_url.rstrip('/')}{path}",
            data=body,
            headers=headers,
            method="POST",
        )
        try:
            with suppress_runtime_capture():
                response = urllib_request.urlopen(req, timeout=self.config.timeout_seconds)
            with response:
                return json.loads(response.read().decode("utf-8"))
        except HTTPError as error:
            payload = error.read().decode("utf-8")
            raise self._api_error(error.code, payload, error.reason) from error

    def _get_json(self, path: str) -> dict:
        headers = self._headers(None)
        if self._transport is not None:
            return self._transport("GET", path, headers, None)

        req = urllib_request.Request(
            f"{self.config.base_url.rstrip('/')}{path}",
            headers=headers,
            method="GET",
        )
        try:
            with suppress_runtime_capture():
                response = urllib_request.urlopen(req, timeout=self.config.timeout_seconds)
            with response:
                return json.loads(response.read().decode("utf-8"))
        except HTTPError as error:
            payload = error.read().decode("utf-8")
            raise self._api_error(error.code, payload, error.reason) from error

    async def _post_json_async(
        self,
        path: str,
        payload: dict,
        idempotency_key: str | None = None,
    ) -> dict:
        return await asyncio.to_thread(self._post_json, path, payload, idempotency_key)

    async def _get_json_async(self, path: str) -> dict:
        return await asyncio.to_thread(self._get_json, path)

    def health_live(self) -> dict:
        return self._get_json("/health/live")

    def events_batch(self, payload: dict, idempotency_key: str | None = None) -> dict:
        return self._post_json(EVENTS_BATCH_PATH, payload, idempotency_key)

    def taint_probe(self, payload: dict, idempotency_key: str | None = None) -> dict:
        return self._post_json(V4_TAINT_PROBE_PATH, payload, idempotency_key)

    async def taint_probe_async(
        self,
        payload: dict,
        idempotency_key: str | None = None,
    ) -> dict:
        return await self._post_json_async(V4_TAINT_PROBE_PATH, payload, idempotency_key)

    def boundary_preflight(self, payload: dict, idempotency_key: str | None = None) -> dict:
        return self._post_json(V4_BOUNDARY_PREFLIGHT_PATH, payload, idempotency_key)

    async def boundary_preflight_async(
        self,
        payload: dict,
        idempotency_key: str | None = None,
    ) -> dict:
        return await self._post_json_async(V4_BOUNDARY_PREFLIGHT_PATH, payload, idempotency_key)

    def execution_report(self, payload: dict, idempotency_key: str | None = None) -> dict:
        return self._post_json(V4_EXECUTION_REPORT_PATH, payload, idempotency_key)

    async def execution_report_async(
        self,
        payload: dict,
        idempotency_key: str | None = None,
    ) -> dict:
        return await self._post_json_async(V4_EXECUTION_REPORT_PATH, payload, idempotency_key)

    def get_decision(self, decision_id: str) -> dict:
        return self._get_json(DECISION_PATH_TEMPLATE.format(decision_id=decision_id))

    async def get_decision_async(self, decision_id: str) -> dict:
        return await self._get_json_async(DECISION_PATH_TEMPLATE.format(decision_id=decision_id))
