from __future__ import annotations

import argparse
import importlib.util
import json
import sys

from .config import VerifiedXConfig
from .runtime import init_verifiedx


def _detect_frameworks() -> dict[str, bool]:
    modules = {
        "langgraph": "langgraph",
        "langchain": "langchain",
        "openai_agents": "agents",
        "claude_agent_sdk": "claude_agent_sdk",
        "mcp": "mcp",
    }
    return {name: importlib.util.find_spec(module) is not None for name, module in modules.items()}


def doctor_command() -> int:
    config = VerifiedXConfig.from_env(require_api_key=False)
    vx = init_verifiedx(config=config)
    report = {
        "config": {
            "base_url": config.base_url,
            "org_id": config.org_id,
            "project_id": config.project_id,
            "environment": config.environment,
            "agent_id": config.agent_id,
            "api_key_configured": bool(config.api_key),
        },
        "frameworks": _detect_frameworks(),
        "health": None,
    }
    if config.api_key:
        try:
            report["health"] = vx.client.health_live()
        except Exception as error:  # pragma: no cover
            report["health"] = {"status": "unreachable", "error": str(error)}
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="verifiedx")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("doctor")
    args = parser.parse_args(argv)
    if args.command == "doctor":
        return doctor_command()
    parser.print_help()
    return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main(sys.argv[1:]))
