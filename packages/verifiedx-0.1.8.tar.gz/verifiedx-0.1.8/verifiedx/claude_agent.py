from __future__ import annotations

import copy
import re
import uuid
from typing import Any

from .errors import build_loopback_tool_result


CLAUDE_AGENT_ADAPTER_KIND = "claude_agent_sdk"
CLAUDE_AGENT_NATIVE_CAPABILITIES = [
    "hooks",
    "tool_calls",
    "permission_requests",
    "runtime_loopback",
    "lifecycle_summaries",
]
_CLAUDE_SUMMARY_HOOKS = (
    "Notification",
    "PreCompact",
    "SessionStart",
    "SessionEnd",
    "StopFailure",
    "SubagentStart",
    "SubagentStop",
)

_CASE_ID_PATTERN = re.compile(r"\b[A-Z]{2,}-\d+\b")
_CLAUDE_MUTATING_BUILTINS = {"bash", "write", "edit", "multiedit", "notebookedit"}
_CLAUDE_HISTORY_SEMANTICS = {
    "agent": "delegation",
    "askuserquestion": "human_input_request",
    "bash": "system_mutation",
    "edit": "file_mutation",
    "exitplanmode": "plan_transition",
    "glob": "workspace_search",
    "grep": "workspace_search",
    "multiedit": "file_mutation",
    "notebookedit": "file_mutation",
    "read": "file_read",
    "webfetch": "external_retrieval",
    "websearch": "external_search",
    "write": "file_mutation",
}
_CLAUDE_RETRIEVAL_BUILTINS = {"read", "glob", "grep", "webfetch", "websearch"}


class _FallbackHookMatcher:
    def __init__(self, *, matcher: str | None = None, hooks: list[Any] | None = None):
        self.matcher = matcher
        self.hooks = list(hooks or [])


def _clone_options(options):
    if options is None:
        return {}
    if isinstance(options, dict):
        return dict(options)
    try:
        return copy.copy(options)
    except Exception:
        return options


def _option_value(options, *names: str):
    if options is None:
        return None
    if isinstance(options, dict):
        for name in names:
            if name in options:
                return options.get(name)
        return None
    for name in names:
        if hasattr(options, name):
            return getattr(options, name)
    return None


def _string_option(options, *names: str) -> str | None:
    value = _option_value(options, *names)
    if isinstance(value, str):
        normalized = value.strip()
        return normalized or None
    return None


def _options_hooks_mapping(options) -> dict[str, list[Any]]:
    hooks = _option_value(options, "hooks")
    if not isinstance(hooks, dict):
        return {}
    normalized: dict[str, list[Any]] = {}
    for hook_name, matchers in hooks.items():
        if isinstance(matchers, (list, tuple)):
            normalized[str(hook_name)] = list(matchers)
    return normalized


def _append_hook_matcher(options, hook_name: str, callback, *, matcher: str | None = None):
    try:
        from claude_agent_sdk import HookMatcher
    except ModuleNotFoundError:
        HookMatcher = _FallbackHookMatcher

    target = _clone_options(options)
    hooks = _options_hooks_mapping(target)
    hooks.setdefault(hook_name, []).append(HookMatcher(matcher=matcher, hooks=[callback]))
    if isinstance(target, dict):
        target["hooks"] = hooks
        return target
    setattr(target, "hooks", hooks)
    return target


def _tool_use_mapping(value):
    if isinstance(value, dict):
        return value
    if hasattr(value, "model_dump"):
        try:
            dumped = value.model_dump(mode="json")
        except TypeError:
            dumped = value.model_dump()
        return dumped if isinstance(dumped, dict) else {"value": dumped}
    if hasattr(value, "dict") and callable(value.dict):
        dumped = value.dict()
        return dumped if isinstance(dumped, dict) else {"value": dumped}
    return {"value": str(value)}


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    if hasattr(value, "model_dump"):
        try:
            return _jsonable(value.model_dump(mode="json"))
        except TypeError:
            return _jsonable(value.model_dump())
    if hasattr(value, "dict") and callable(value.dict):
        return _jsonable(value.dict())
    return str(value)


def _jsonish_object(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return _jsonable(value)
    if isinstance(value, str):
        normalized = value.strip()
        if not normalized:
            return {}
        try:
            import json

            parsed = json.loads(normalized)
        except Exception:
            return {"value": normalized}
        if isinstance(parsed, dict):
            return _jsonable(parsed)
        return {"value": _jsonable(parsed)}
    if value is None:
        return {}
    parsed = _jsonable(value)
    if isinstance(parsed, dict):
        return parsed
    return {"value": parsed}


def _case_thread_hint(prompt_text: str | None) -> str | None:
    content = str(prompt_text or "")
    match = _CASE_ID_PATTERN.search(content)
    if not match:
        return None
    normalized = re.sub(r"[^a-z0-9]+", "_", match.group(0).lower()).strip("_")
    return f"claude_agent_{normalized}" if normalized else None


def _run_scope(prompt_text: str | None, options) -> str:
    for candidate in (
        _string_option(options, "session_id", "sessionId"),
        _string_option(options, "resume"),
        _case_thread_hint(prompt_text),
    ):
        if candidate:
            return candidate
    return f"claude_agent_sdk_{uuid.uuid4().hex[:16]}"


def _system_prompt_text(options) -> str | None:
    value = _option_value(options, "system_prompt", "systemPrompt")
    if isinstance(value, str):
        normalized = value.strip()
        return normalized or None
    return None


def _model_name(options) -> str | None:
    return _string_option(options, "model", "fallback_model", "fallbackModel")


def _tool_definitions_from_options(options) -> list[dict[str, Any]]:
    tools = _option_value(options, "tools")
    if not isinstance(tools, list):
        return []
    definitions: list[dict[str, Any]] = []
    for tool_name in tools:
        if not isinstance(tool_name, str):
            continue
        normalized = tool_name.strip()
        if not normalized:
            continue
        metadata: dict[str, Any] = {
            "native_tool_type": normalized,
            "read_only": normalized.lower() not in _CLAUDE_MUTATING_BUILTINS,
        }
        pending_action = _claude_builtin_pending_action(normalized, {})
        if pending_action is not None:
            metadata["pending_action"] = pending_action
        definitions.append(
            {
                "tool_name": normalized,
                "schema": {"type": "object", "additionalProperties": True},
                "docstring": None,
                "metadata": metadata,
            }
        )
    return definitions


def _request_metadata_from_options(options) -> dict[str, Any]:
    metadata = {
        "sdk": CLAUDE_AGENT_ADAPTER_KIND,
        "permission_mode": _string_option(options, "permission_mode", "permissionMode"),
        "cwd": _string_option(options, "cwd"),
        "session_id": _string_option(options, "session_id", "sessionId"),
        "resume": _string_option(options, "resume"),
        "model": _string_option(options, "model"),
        "max_turns": _option_value(options, "max_turns", "maxTurns"),
    }
    tools = _option_value(options, "tools")
    if isinstance(tools, list):
        metadata["tools"] = [tool for tool in tools if isinstance(tool, str) and tool.strip()]
    mcp_servers = _option_value(options, "mcp_servers", "mcpServers")
    if isinstance(mcp_servers, dict):
        metadata["mcp_server_names"] = [str(name) for name in mcp_servers.keys()]
    return {
        key: value
        for key, value in metadata.items()
        if value is not None and value != [] and value != {}
    }


def _record_prompt_submission(vx, *, prompt_text: str, options, source: str, run_scope: str) -> None:
    messages: list[dict[str, Any]] = []
    system_prompt = _system_prompt_text(options)
    if system_prompt:
        messages.append(
            {
                "role": "system",
                "content": system_prompt,
                "message_id": "claude_agent_system",
            }
        )
    normalized_prompt = str(prompt_text or "").strip()
    if normalized_prompt:
        messages.append(
            {
                "role": "user",
                "content": normalized_prompt,
                "message_id": "claude_agent_user_prompt",
            }
        )
    if not messages:
        return
    with vx.pinned_runtime_scope(run_scope):
        vx.zero_touch.record_conversation_window(
            messages,
            source=source,
            model_name=_model_name(options),
            request_kind="claude_agent_sdk.query",
            request_metadata=_request_metadata_from_options(options),
            tool_definitions=_tool_definitions_from_options(options),
            remember_messages_as_context=True,
            supported_adapter=True,
            capture_source_kind="wrapper",
        )


def _anthropic_event_source(hook_name: str) -> str:
    normalized = str(hook_name or "").strip() or "PreToolUse"
    return f"{CLAUDE_AGENT_ADAPTER_KIND}.{normalized}"


def _tool_target(tool_name: str, args: dict[str, Any]) -> str:
    if not isinstance(args, dict):
        return tool_name
    for key in (
        "path",
        "file_path",
        "notebook_path",
        "namespace",
        "key",
        "workflow_id",
        "job_id",
        "task_id",
        "record_id",
        "customer_id",
        "ticket_id",
        "case_id",
        "channel",
        "channel_id",
        "recipient",
        "email",
        "to",
        "url",
        "uri",
        "target",
    ):
        value = args.get(key)
        if isinstance(value, str) and value.strip():
            if key == "namespace" and isinstance(args.get("key"), str) and args.get("key").strip():
                return f"{value.strip()}/{args['key'].strip()}"
            return value.strip()
    return tool_name


def _claude_builtin_pending_action(tool_name: str, args: dict[str, Any]) -> dict[str, Any] | None:
    normalized = str(tool_name or "").strip().lower()
    if normalized == "bash":
        return {
            "surface": "tool_dispatch",
            "operation": tool_name,
            "target": _tool_target(tool_name, args),
            "method": "CALL",
            "raw_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": True,
        }
    if normalized in {"write", "edit", "multiedit", "notebookedit"}:
        return {
            "surface": "file_write",
            "operation": tool_name,
            "target": _tool_target(tool_name, args),
            "method": normalized,
            "raw_args": dict(args),
            "boundary_kind": "action_execute",
            "action_class": "system_change",
            "trust_boundary_crossing": False,
        }
    return None


def _claude_builtin_semantic_class(tool_name: str) -> str | None:
    return _CLAUDE_HISTORY_SEMANTICS.get(str(tool_name or "").strip().lower())


def _claude_builtin_metadata(tool_name: str) -> dict[str, Any]:
    normalized = str(tool_name or "").strip().lower()
    if normalized not in _CLAUDE_HISTORY_SEMANTICS:
        return {}
    metadata: dict[str, Any] = {
        "read_only": normalized not in _CLAUDE_MUTATING_BUILTINS,
    }
    if normalized in _CLAUDE_RETRIEVAL_BUILTINS:
        metadata["retrieval_like"] = True
    return metadata


def _tool_use_descriptor(
    value,
    *,
    tool_use_id=None,
    hook_name: str = "PreToolUse",
):
    payload = _tool_use_mapping(value)
    raw_args = _jsonish_object(
        payload.get("tool_input")
        or payload.get("input")
        or payload.get("arguments")
        or payload.get("updatedInput")
        or payload
    )
    raw_name = str(
        payload.get("tool_name")
        or payload.get("toolName")
        or payload.get("name")
        or payload.get("type")
        or "tool"
    ).strip()
    if not raw_name:
        raw_name = "tool"
    selection_metadata = {
        "raw_name": raw_name,
        "raw_args": raw_args,
        "native_call_type": raw_name,
        "provider_event_type": {
            "PreToolUse": "tool_use",
            "PostToolUse": "tool_result",
            "PostToolUseFailure": "tool_result",
            "PermissionRequest": "permission_request",
            "PermissionDenied": "permission_denied",
        }.get(hook_name, hook_name),
        "hook_source": _anthropic_event_source(hook_name),
    }
    semantic_class = _claude_builtin_semantic_class(raw_name)
    if semantic_class:
        selection_metadata["semantic_class"] = semantic_class
    selection_metadata.update(_claude_builtin_metadata(raw_name))
    pending_action = _claude_builtin_pending_action(raw_name, raw_args)
    if pending_action is not None:
        selection_metadata["pending_action"] = pending_action
    if tool_use_id is not None:
        selection_metadata["tool_use_id"] = tool_use_id
    return {
        "tool_name": raw_name,
        "args": raw_args,
        "selection_metadata": selection_metadata,
        "source": _anthropic_event_source(hook_name),
    }


def _tool_result_object(vx, *, phase: str, payload: dict[str, Any], source: str, tool_name: str):
    return vx.capture.build_object(
        "tool_result",
        {
            "phase": phase,
            "payload": payload,
            "raw_name": tool_name,
            "source": source,
        },
        source_lineage=[CLAUDE_AGENT_ADAPTER_KIND],
    )


def _approval_object(vx, *, payload: dict[str, Any], tool_name: str, hook_name: str):
    return vx.capture.build_object(
        "approval",
        {
            "tool_name": tool_name,
            "payload": payload,
            "source": _anthropic_event_source(hook_name),
        },
        source_lineage=[CLAUDE_AGENT_ADAPTER_KIND],
    )


def _summary_object(vx, *, hook_name: str, payload: dict[str, Any]):
    return vx.capture.build_object(
        "summary",
        {
            "hook_name": hook_name,
            "payload": payload,
            "source": _anthropic_event_source(hook_name),
        },
        source_lineage=[CLAUDE_AGENT_ADAPTER_KIND],
    )


def _first_reason_message(decision: dict[str, Any]) -> str:
    for reason in decision.get("reasons") or []:
        if isinstance(reason, dict):
            message = str(reason.get("message") or "").strip()
            if message:
                return message
    return "VerifiedX blocked this tool step."


def _claude_block_output(
    decision: dict[str, Any],
    *,
    boundary_kind: str,
    action_class: str | None,
    tool_name: str,
    pending_effect: dict[str, Any],
) -> dict[str, Any]:
    loopback = build_loopback_tool_result(
        decision,
        boundary_kind=boundary_kind,
        action_class=action_class,
        pending_effect=pending_effect,
    )
    reason_message = _first_reason_message(decision)
    safe_next_steps = [
        step.get("message")
        for step in loopback.get("safe_next_steps") or []
        if isinstance(step, dict) and step.get("message")
    ]
    additional_lines = [str(loopback.get("agent_instruction") or "").strip()]
    if safe_next_steps:
        additional_lines.append("Safe next steps: " + "; ".join(safe_next_steps[:3]))
    if loopback.get("goal_completion_warning"):
        additional_lines.append(str(loopback["goal_completion_warning"]).strip())
    additional_context = "\n".join(line for line in additional_lines if line)
    return {
        "decision": "block",
        "systemMessage": (
            f"VerifiedX blocked `{tool_name}`. The requested side effect did not execute. "
            f"{reason_message}"
        ),
        "reason": additional_context or reason_message,
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason_message,
            **({"additionalContext": additional_context} if additional_context else {}),
        },
    }


def install(*, verifiedx=None, framework_version=None):
    from .runtime import init_verifiedx

    vx = verifiedx or init_verifiedx()
    if not vx.runtime_enabled:
        vx.install_runtime(framework_version=framework_version)
    report = vx.activation_report(
        CLAUDE_AGENT_ADAPTER_KIND,
        "native",
        list(CLAUDE_AGENT_NATIVE_CAPABILITIES),
        framework_version=framework_version,
        activation_source="claude_agent_install",
    )
    adapter = report.to_adapter_context()
    vx.capture.set_default_adapter(adapter)
    return vx, report


def attach_query(query_callable, *, verifiedx=None, framework_version=None):
    def wrapped(*, prompt, options=None, **kwargs):
        return query(
            prompt=prompt,
            options=options,
            verifiedx=verifiedx,
            framework_version=framework_version,
            query_callable=query_callable,
            **kwargs,
        )

    return wrapped


def query(
    prompt=None,
    *,
    verifiedx=None,
    options=None,
    framework_version=None,
    query_callable=None,
    **kwargs,
):
    vx, report = install(verifiedx=verifiedx, framework_version=framework_version)
    adapter = report.to_adapter_context()
    run_scope = _run_scope(str(prompt or ""), options)

    async def user_prompt_submit(input_value, _tool_use_id=None, _context=None):
        payload = _tool_use_mapping(input_value)
        prompt_text = str(payload.get("prompt") or prompt or "").strip()
        _record_prompt_submission(
            vx,
            prompt_text=prompt_text,
            options=options,
            source=f"{CLAUDE_AGENT_ADAPTER_KIND}.UserPromptSubmit",
            run_scope=run_scope,
        )
        vx.capture.summary(
            _summary_object(
                vx,
                hook_name="UserPromptSubmit",
                payload=payload,
            ),
            adapter=adapter,
        )
        return {}

    async def pre_tool_use(input_value, tool_use_id=None, _context=None):
        descriptor = _tool_use_descriptor(
            input_value,
            tool_use_id=tool_use_id,
            hook_name="PreToolUse",
        )
        tool_descriptor = {
            "tool_name": descriptor["tool_name"],
            "schema": {"type": "object", "additionalProperties": True},
            "docstring": None,
            "args": descriptor["args"],
            "metadata": descriptor["selection_metadata"],
        }
        with vx.pinned_runtime_scope(run_scope):
            vx.zero_touch.note_tool_selection(
                tool_name=descriptor["tool_name"],
                arguments=descriptor["args"],
                tool_call_id=str(tool_use_id) if tool_use_id is not None else None,
                selection_metadata=descriptor["selection_metadata"],
                source=descriptor["source"],
            )
            capture = None
            boundary_kind = "action_execute"
            action_class = None
            if vx.zero_touch.requires_direct_tool_boundary(
                tool_descriptor=tool_descriptor,
                source=descriptor["source"],
            ):
                capture = vx.zero_touch.describe_selected_tool_boundary(
                    tool_descriptor=tool_descriptor,
                    source=descriptor["source"],
                )
            if capture is not None:
                boundary_kind = str(capture.get("boundary_kind") or "action_execute")
                action_class = capture.get("action_class")
                vx.register_runtime_contract(
                    action_class=action_class,
                    boundary_kind=boundary_kind,
                )
                request_payload, observed_boundary, candidate_hash = vx._v4.build_preflight_request(
                    vx.zero_touch,
                    surface=str(capture["surface"]),
                    operation=str(capture["operation"]),
                    target=str(capture["target"]),
                    method=capture.get("method"),
                    transport_args=dict(capture.get("transport_args") or descriptor["args"]),
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
                    tool_descriptor=tool_descriptor,
                    tool_source=descriptor["source"],
                )
                decision = await vx._v4.submit_preflight_payload_async(request_payload)
                await vx.record_boundary_diagnostic_async(
                    "v4_boundary_preflight_async_tool_selection",
                    request_payload,
                    decision,
                )
                vx.zero_touch._remember_tool_preflight(
                    tool_descriptor=tool_descriptor,
                    tool_call_id=str(tool_use_id) if tool_use_id is not None else None,
                    boundary_kind=boundary_kind,
                    action_class=action_class,
                    target=str(capture["target"]),
                    observed_boundary=observed_boundary,
                    candidate_hash=candidate_hash,
                    decision=decision,
                )
                if decision.get("outcome") not in {"allow", "allow_with_warning"}:
                    pending_effect = dict(capture.get("transport_args") or descriptor["args"])
                    vx.note_runtime_loopback(
                        decision,
                        boundary_kind=boundary_kind,
                        action_class=action_class,
                        pending_effect=pending_effect,
                    )
                    return _claude_block_output(
                        decision,
                        boundary_kind=boundary_kind,
                        action_class=action_class,
                        tool_name=descriptor["tool_name"],
                        pending_effect=pending_effect,
                    )
            vx.capture.tool_call(
                _tool_result_object(
                    vx,
                    phase="pre_tool_use",
                    payload=_tool_use_mapping(input_value),
                    source=descriptor["source"],
                    tool_name=descriptor["tool_name"],
                ),
                tool_name=descriptor["tool_name"],
                adapter=adapter,
            )
        return {}

    async def post_tool_use(input_value, tool_use_id=None, _context=None):
        descriptor = _tool_use_descriptor(
            input_value,
            tool_use_id=tool_use_id,
            hook_name="PostToolUse",
        )
        with vx.pinned_runtime_scope(run_scope):
            vx.capture.tool_call(
                _tool_result_object(
                    vx,
                    phase="post_tool_use",
                    payload=_tool_use_mapping(input_value),
                    source=descriptor["source"],
                    tool_name=descriptor["tool_name"],
                ),
                tool_name=descriptor["tool_name"],
                adapter=adapter,
            )
        return {}

    async def post_tool_use_failure(input_value, tool_use_id=None, _context=None):
        descriptor = _tool_use_descriptor(
            input_value,
            tool_use_id=tool_use_id,
            hook_name="PostToolUseFailure",
        )
        with vx.pinned_runtime_scope(run_scope):
            vx.capture.tool_call(
                _tool_result_object(
                    vx,
                    phase="post_tool_use_failure",
                    payload=_tool_use_mapping(input_value),
                    source=descriptor["source"],
                    tool_name=descriptor["tool_name"],
                ),
                tool_name=descriptor["tool_name"],
                adapter=adapter,
            )
        return {}

    async def permission_request(input_value, _tool_use_id=None, _context=None):
        payload = _tool_use_mapping(input_value)
        tool_name = str(payload.get("tool_name") or payload.get("toolName") or "tool").strip() or "tool"
        with vx.pinned_runtime_scope(run_scope):
            vx.capture.approval(
                _approval_object(
                    vx,
                    payload=payload,
                    tool_name=tool_name,
                    hook_name="PermissionRequest",
                ),
                approval_state="requested",
                adapter=adapter,
            )
        return {}

    async def permission_denied(input_value, _tool_use_id=None, _context=None):
        payload = _tool_use_mapping(input_value)
        tool_name = str(payload.get("tool_name") or payload.get("toolName") or "tool").strip() or "tool"
        with vx.pinned_runtime_scope(run_scope):
            vx.capture.approval(
                _approval_object(
                    vx,
                    payload=payload,
                    tool_name=tool_name,
                    hook_name="PermissionDenied",
                ),
                approval_state="denied",
                adapter=adapter,
            )
        return {}

    async def stop(input_value, _tool_use_id=None, _context=None):
        with vx.pinned_runtime_scope(run_scope):
            vx.capture.summary(
                _summary_object(
                    vx,
                    hook_name="Stop",
                    payload=_tool_use_mapping(input_value),
                ),
                adapter=adapter,
            )
        return {}

    def _summary_hook_callback(hook_name: str):
        async def _callback(input_value, _tool_use_id=None, _context=None):
            with vx.pinned_runtime_scope(run_scope):
                vx.capture.summary(
                    _summary_object(
                        vx,
                        hook_name=hook_name,
                        payload=_tool_use_mapping(input_value),
                    ),
                    adapter=adapter,
                )
            return {}

        return _callback

    merged_options = _append_hook_matcher(options, "UserPromptSubmit", user_prompt_submit)
    merged_options = _append_hook_matcher(merged_options, "PreToolUse", pre_tool_use)
    merged_options = _append_hook_matcher(merged_options, "PostToolUse", post_tool_use)
    merged_options = _append_hook_matcher(merged_options, "PostToolUseFailure", post_tool_use_failure)
    merged_options = _append_hook_matcher(merged_options, "PermissionRequest", permission_request)
    merged_options = _append_hook_matcher(merged_options, "PermissionDenied", permission_denied)
    merged_options = _append_hook_matcher(merged_options, "Stop", stop)
    for hook_name in _CLAUDE_SUMMARY_HOOKS:
        merged_options = _append_hook_matcher(
            merged_options,
            hook_name,
            _summary_hook_callback(hook_name),
        )

    if query_callable is None:
        from claude_agent_sdk import query as query_callable

    source_iterator = query_callable(prompt=prompt, options=merged_options, **kwargs)

    async def _iterate():
        with vx.pinned_runtime_scope(run_scope):
            async for message in source_iterator:
                yield message

    return _iterate()
