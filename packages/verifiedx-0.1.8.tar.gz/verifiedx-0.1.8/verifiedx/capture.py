from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import uuid

from .client import BoundaryClient
from .config import VerifiedXConfig
from .context import RunContext, current_run_context, use_run_context
from .generated import EVENT_SCHEMA_VERSION

_OMITTED_SENTINEL_NAMES = {
    "omit",
    "notgiven",
    "notprovided",
    "notset",
    "undefined",
    "unset",
    "missing",
}
_OMITTED_SENTINEL_MODULE_ROOTS = {
    "agents",
    "anthropic",
    "cerebras",
    "cohere",
    "fireworks",
    "google",
    "groq",
    "litellm",
    "mistralai",
    "ollama",
    "openai",
    "together",
    "vertexai",
}


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


def _is_omitted_sentinel(value) -> bool:
    if value is None:
        return False
    cls = type(value)
    class_name = "".join(ch for ch in getattr(cls, "__name__", "").lower() if ch.isalnum())
    if class_name not in _OMITTED_SENTINEL_NAMES:
        return False
    module = str(getattr(cls, "__module__", "") or "").lower()
    if not module or module == "builtins":
        return False
    return module.split(".", 1)[0] in _OMITTED_SENTINEL_MODULE_ROOTS


def _jsonable(value):
    if _is_omitted_sentinel(value):
        return None
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        normalized = {}
        for key, item in value.items():
            if _is_omitted_sentinel(item):
                continue
            normalized[str(key)] = _jsonable(item)
        return normalized
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value if not _is_omitted_sentinel(item)]
    if hasattr(value, "model_dump"):
        try:
            return _jsonable(value.model_dump(mode="json"))
        except TypeError:
            return _jsonable(value.model_dump())
    if hasattr(value, "dict") and callable(value.dict):
        return _jsonable(value.dict())
    if hasattr(value, "json") and callable(value.json):
        try:
            return json.loads(value.json())
        except Exception:
            return str(value)
    return str(value)


def _extract_excerpt(value, *, limit: int) -> str | None:
    if limit <= 0:
        return None
    if isinstance(value, str):
        excerpt = value.strip()
        return excerpt[:limit] if excerpt else None
    if isinstance(value, dict):
        for key in ("content", "text", "message", "body", "summary", "snippet", "note", "details"):
            excerpt = _extract_excerpt(value.get(key), limit=limit)
            if excerpt:
                return excerpt
        try:
            encoded = json.dumps(value, sort_keys=True)
        except TypeError:
            return None
        excerpt = encoded.strip()
        return excerpt[:limit] if excerpt else None
    if isinstance(value, list):
        excerpt = _extract_excerpt(value[0], limit=limit) if value else None
        return excerpt
    return None


def _extract_source_uri(value) -> str | None:
    if not isinstance(value, dict):
        return None
    for key in ("url", "source_uri", "uri", "destination"):
        candidate = value.get(key)
        if isinstance(candidate, str) and candidate:
            return candidate
    return None


@dataclass
class CaptureEmitter:
    config: VerifiedXConfig
    client: BoundaryClient
    default_context: RunContext

    def __post_init__(self):
        self._buffer: list[dict] = []
        self._default_adapter: dict | None = None
        self._recent_objects_by_run: dict[str, list[dict]] = {}
        self._support_window_size = 64
        self._recent_object_counter = 0

    def _flush_payload_size_bytes(self, events: list[dict]) -> int:
        return len(json.dumps({"events": _jsonable(events)}, separators=(",", ":")).encode("utf-8"))

    def _next_flush_count(self) -> int:
        if not self._buffer:
            return 0

        limit = max(1, self.config.max_flush_payload_bytes)
        count = 1
        while count < len(self._buffer):
            candidate = self._buffer[: count + 1]
            if self._flush_payload_size_bytes(candidate) > limit:
                break
            count += 1
        return count

    def set_default_adapter(self, adapter_context: dict | None):
        self._default_adapter = adapter_context

    def use_context(self, run_context: RunContext):
        return use_run_context(run_context)

    def current_context(self) -> RunContext:
        return current_run_context(self.default_context)

    def _remember_object(self, run_id: str, event: dict):
        object_payload = event.get("object") or {}
        object_id = object_payload.get("object_id")
        if not object_id:
            return
        recorded_at = datetime.now(timezone.utc).isoformat()
        entries = self._recent_objects_by_run.setdefault(run_id, [])
        self._recent_object_counter += 1
        entry = {
            "object_id": object_id,
            "kind": event.get("kind"),
            "object_type": object_payload.get("object_type"),
            "normalized_payload": object_payload.get("normalized_payload"),
            "source_lineage": object_payload.get("source_lineage") or [],
            "freshness": object_payload.get("freshness"),
            "observability_quality": object_payload.get("observability_quality"),
            "sanitization_status": object_payload.get("sanitization_status"),
            "hidden_content_indicators": object_payload.get("hidden_content_indicators") or [],
            "taint_labels": object_payload.get("taint_labels") or [],
            "binding_status": object_payload.get("binding_status"),
            "trust_tier": object_payload.get("trust_tier"),
            "run_id": run_id,
            "sequence": self._recent_object_counter,
            "recorded_at": recorded_at,
            "query": event.get("query"),
            "tool_name": event.get("tool_name"),
            "namespace": event.get("namespace"),
            "key": event.get("key"),
        }
        for index in range(len(entries) - 1, -1, -1):
            if entries[index].get("object_id") == object_id:
                entries[index].update(entry)
                break
        else:
            entries.append(entry)
        if len(entries) > self._support_window_size:
            del entries[:-self._support_window_size]

    def remember_observed_object(
        self,
        object_payload: dict,
        *,
        kind: str = "context_ingress",
        run_context: RunContext | None = None,
    ):
        context = run_context or self.current_context()
        self._remember_object(
            context.run_id,
            {
                "kind": kind,
                "object": object_payload,
            },
        )

    def recent_support_inputs(
        self,
        *,
        run_context: RunContext | None = None,
        limit: int = 32,
    ) -> dict:
        context = run_context or self.current_context()
        entries = list(self._recent_objects_by_run.get(context.run_id, []))

        candidate_object_ids: list[str] = []
        approval_object_ids: list[str] = []
        checkpoint_ids: list[str] = []
        decision_context_ids: list[str] = []
        seen: set[str] = set()

        for entry in reversed(entries):
            object_id = entry["object_id"]
            if object_id in seen:
                continue
            seen.add(object_id)

            kind = entry.get("kind")
            if kind in {"action_execute", "memory_write_preflight"}:
                continue

            decision_context_ids.append(object_id)
            if kind == "approval":
                approval_object_ids.append(object_id)
                continue
            if kind == "checkpoint":
                checkpoint_ids.append(object_id)
                continue
            candidate_object_ids.append(object_id)

            if len(decision_context_ids) >= limit:
                break

        candidate_object_ids.reverse()
        approval_object_ids.reverse()
        checkpoint_ids.reverse()
        decision_context_ids.reverse()

        return {
            "candidate_object_ids": candidate_object_ids,
            "approval_object_ids": approval_object_ids,
            "checkpoint_ids": checkpoint_ids,
            "decision_context_ids": decision_context_ids,
        }

    def recent_objects(
        self,
        *,
        run_context: RunContext | None = None,
        limit: int = 32,
    ) -> list[dict]:
        context = run_context or self.current_context()
        entries = list(self._recent_objects_by_run.get(context.run_id, []))
        return entries[-limit:]

    def recent_objects_across_runs(self, *, limit: int = 64) -> list[dict]:
        entries: list[dict] = []
        for run_entries in self._recent_objects_by_run.values():
            entries.extend(run_entries)
        entries.sort(key=lambda entry: int(entry.get("sequence") or 0))
        return entries[-limit:]

    def recent_objects_by_ids(self, object_ids: list[str]) -> list[dict]:
        wanted = {str(object_id) for object_id in object_ids if object_id}
        if not wanted:
            return []
        best_by_id: dict[str, dict] = {}
        for entries in self._recent_objects_by_run.values():
            for entry in entries:
                object_id = str(entry.get("object_id") or "")
                if object_id not in wanted:
                    continue
                existing = best_by_id.get(object_id)
                if existing is None or int(entry.get("sequence") or 0) > int(
                    existing.get("sequence") or 0
                ):
                    best_by_id[object_id] = entry
        ordered = list(best_by_id.values())
        ordered.sort(key=lambda entry: int(entry.get("sequence") or 0))
        return ordered

    def build_object(
        self,
        object_type: str,
        normalized_payload,
        *,
        object_id: str | None = None,
        source_lineage: list[str] | None = None,
        artifact_reference: str | None = None,
        freshness: str | None = "fresh",
        sanitization_status: str = "not_applicable",
        observability_quality: str = "complete",
        hidden_content_indicators: list[str] | None = None,
        taint_labels: list[str] | None = None,
        binding_status: str | None = "bound_to_evidence",
        claims: list[dict] | None = None,
    ) -> dict:
        return {
            "object_id": object_id or _new_id("obj"),
            "object_type": object_type,
            "artifact_reference": artifact_reference,
            "normalized_payload": _jsonable(normalized_payload),
            "freshness": freshness,
            "source_lineage": source_lineage or [self.config.source_system],
            "sanitization_status": sanitization_status,
            "observability_quality": observability_quality,
            "hidden_content_indicators": _jsonable(hidden_content_indicators or []),
            "taint_labels": _jsonable(taint_labels or []),
            "binding_status": binding_status,
            "claims": _jsonable(claims or []),
        }

    def emit_event(
        self,
        event: dict,
        *,
        run_context: RunContext | None = None,
        boundary: str = "action_execute",
        action_class: str | None = None,
        linked_object_ids: list[str] | None = None,
        adapter: dict | None = None,
        causality: dict | None = None,
        partial_observability: dict | None = None,
    ) -> dict:
        context = run_context or self.current_context()
        event = _jsonable(event)
        self._remember_object(context.run_id, event)
        object_id = event.get("object", {}).get("object_id")
        ingest_event = {
            "envelope": context.envelope(
                boundary,
                action_class=action_class,
                linked_object_ids=linked_object_ids or ([object_id] if object_id else []),
                sensitivity=self.config.default_sensitivity,
            ),
            "schema_version": EVENT_SCHEMA_VERSION,
            "adapter": _jsonable(adapter or self._default_adapter),
            "causality": {
                "event_id": _new_id("evt"),
                "object_id": object_id,
                "artifact_id": None,
                "parent_event_id": None,
                "referenced_object_ids": [],
                "origin_object_ids": [],
                "origin_step_id": None,
                "framework_run_id": None,
                "framework_checkpoint_id": None,
                "framework_trace_id": None,
                **_jsonable(causality or {}),
            },
            "partial_observability": {
                "missing_tool_stdout": False,
                "proxy_only_browser_state": False,
                "truncated_retrieval": False,
                "hidden_content_present": False,
                "wrapper_bypassed": False,
                "missing_checkpoint_continuity": False,
                "custom_gaps": [],
                **_jsonable(partial_observability or {}),
            },
            "event": event,
            "legacy_event_type": None,
            "legacy_payload": None,
        }
        if (
            event.get("kind") in {"subagent_return", "handoff_accept"}
            and not ingest_event["causality"]["origin_object_ids"]
        ):
            support_inputs = self.recent_support_inputs(run_context=context)
            fallback_ids = [
                candidate
                for candidate in support_inputs["decision_context_ids"]
                if candidate and candidate != object_id
            ]
            if fallback_ids:
                ingest_event["causality"]["origin_object_ids"] = fallback_ids[-8:]
        self._buffer.append(ingest_event)
        if (
            len(self._buffer) >= self.config.flush_batch_size
            or self._flush_payload_size_bytes(self._buffer) > self.config.max_flush_payload_bytes
        ):
            self.flush()
        return ingest_event

    def flush(self) -> dict | None:
        if not self._buffer:
            return None

        responses: list[dict] = []
        accepted_count = 0
        while self._buffer:
            batch_count = self._next_flush_count()
            if batch_count <= 0:
                break
            payload = {"events": _jsonable(list(self._buffer[:batch_count]))}
            if not payload["events"]:
                break
            response = self.client.events_batch(payload)
            del self._buffer[:batch_count]
            accepted_count += len(payload["events"])
            responses.append(response)

        return {"accepted_count": accepted_count, "batches": responses}

    def llm_call(self, object_payload, *, model_name: str, **kwargs):
        return self.emit_event({"kind": "llm_call", "object": object_payload, "model_name": model_name}, **kwargs)

    def retrieve(self, object_payload, *, query: str, **kwargs):
        return self.emit_event({"kind": "retrieve", "object": object_payload, "query": query}, **kwargs)

    def tool_call(self, object_payload, *, tool_name: str, **kwargs):
        return self.emit_event({"kind": "tool_call", "object": object_payload, "tool_name": tool_name}, **kwargs)

    def memory_read(self, object_payload, *, namespace: str, key: str, **kwargs):
        return self.emit_event(
            {"kind": "memory_read", "object": object_payload, "namespace": namespace, "key": key},
            **kwargs,
        )

    def memory_write_preflight(self, object_payload, *, namespace: str, key: str, **kwargs):
        return self.emit_event(
            {
                "kind": "memory_write_preflight",
                "object": object_payload,
                "namespace": namespace,
                "key": key,
            },
            **kwargs,
        )

    def action_plan(self, object_payload, **kwargs):
        return self.emit_event({"kind": "action_plan", "object": object_payload}, **kwargs)

    def action_execute(self, object_payload, *, action_class: str, **kwargs):
        return self.emit_event(
            {"kind": "action_execute", "object": object_payload, "action_class": action_class},
            action_class=action_class,
            **kwargs,
        )

    def browser_observe(self, object_payload, *, url: str, **kwargs):
        return self.emit_event({"kind": "browser_observe", "object": object_payload, "url": url}, **kwargs)

    def env_health(self, object_payload, *, status: str, **kwargs):
        return self.emit_event({"kind": "env_health", "object": object_payload, "status": status}, **kwargs)

    def summary(self, object_payload, **kwargs):
        return self.emit_event({"kind": "summary", "object": object_payload}, **kwargs)

    def checkpoint(self, object_payload, *, stale: bool = False, **kwargs):
        return self.emit_event({"kind": "checkpoint", "object": object_payload, "stale": stale}, **kwargs)

    def approval(self, object_payload, *, approval_state: str, **kwargs):
        return self.emit_event(
            {"kind": "approval", "object": object_payload, "approval_state": approval_state},
            **kwargs,
        )

    def subagent_spawn(self, object_payload, *, descriptor: dict, **kwargs):
        return self.emit_event(
            {"kind": "subagent_spawn", "object": object_payload, "descriptor": descriptor},
            **kwargs,
        )

    def subagent_return(self, object_payload, *, descriptor: dict, action_log_present: bool, **kwargs):
        return self.emit_event(
            {
                "kind": "subagent_return",
                "object": object_payload,
                "descriptor": descriptor,
                "action_log_present": action_log_present,
            },
            **kwargs,
        )

    def handoff_start(self, object_payload, *, descriptor: dict, **kwargs):
        return self.emit_event(
            {"kind": "handoff_start", "object": object_payload, "descriptor": descriptor},
            **kwargs,
        )

    def handoff_accept(self, object_payload, *, descriptor: dict, **kwargs):
        return self.emit_event(
            {"kind": "handoff_accept", "object": object_payload, "descriptor": descriptor},
            **kwargs,
        )
