from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, replace
from datetime import datetime, timezone
import uuid

from .config import VerifiedXConfig
from .generated import EVENT_SCHEMA_VERSION, SDK_VERSION


_CURRENT_CONTEXT: ContextVar["RunContext | None"] = ContextVar("verifiedx_run_context", default=None)


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


@dataclass(frozen=True)
class RunContext:
    org_id: str
    project_id: str
    environment: str
    agent_id: str
    thread_id: str
    run_id: str
    step_id: str
    checkpoint_id: str | None = None
    parent_step_id: str | None = None
    source_system: str = "verifiedx-python"

    @classmethod
    def from_config(cls, config: VerifiedXConfig) -> "RunContext":
        return cls(
            org_id=config.org_id,
            project_id=config.project_id,
            environment=config.environment,
            agent_id=config.agent_id,
            thread_id=_new_id("thread"),
            run_id=_new_id("run"),
            step_id=_new_id("step"),
            source_system=config.source_system,
        )

    def child(
        self,
        *,
        step_id: str | None = None,
        checkpoint_id: str | None = None,
        parent_step_id: str | None = None,
    ) -> "RunContext":
        return replace(
            self,
            step_id=step_id or _new_id("step"),
            checkpoint_id=checkpoint_id if checkpoint_id is not None else self.checkpoint_id,
            parent_step_id=parent_step_id if parent_step_id is not None else self.step_id,
        )

    def envelope(
        self,
        boundary: str,
        *,
        action_class: str | None = None,
        linked_object_ids: list[str] | None = None,
        sensitivity: str = "high",
    ) -> dict:
        return {
            "org_id": self.org_id,
            "project_id": self.project_id,
            "environment": self.environment,
            "agent_id": self.agent_id,
            "thread_id": self.thread_id,
            "run_id": self.run_id,
            "step_id": self.step_id,
            "checkpoint_id": self.checkpoint_id,
            "parent_step_id": self.parent_step_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source_system": self.source_system,
            "policy_scope": {
                "boundary": boundary,
                "action_class": action_class,
                "sensitivity": sensitivity,
            },
            "linked_object_ids": linked_object_ids or [],
            "schema_version": EVENT_SCHEMA_VERSION,
            "sdk_version": f"verifiedx-python/{SDK_VERSION}",
        }


def current_run_context(default_context: RunContext) -> RunContext:
    return _CURRENT_CONTEXT.get() or default_context


def set_run_context(run_context: RunContext):
    _CURRENT_CONTEXT.set(run_context)


@contextmanager
def use_run_context(run_context: RunContext):
    token = _CURRENT_CONTEXT.set(run_context)
    try:
        yield run_context
    finally:
        _CURRENT_CONTEXT.reset(token)
