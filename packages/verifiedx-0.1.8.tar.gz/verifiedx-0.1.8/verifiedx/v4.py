from __future__ import annotations

from typing import Any

from .v4_capture import build_decision_context
from .v4_loopback import (
    build_execution_anchor,
    build_execution_report_payload,
    compute_candidate_hash,
    post_execution_report,
    post_execution_report_async,
    post_preflight,
    post_preflight_async,
)


class V4RuntimeLane:
    def __init__(self, verifiedx):
        self.verifiedx = verifiedx

    def _enrich_decision(self, decision: dict[str, Any]) -> dict[str, Any]:
        receipt = self.verifiedx.note_decision_receipt(decision)
        if receipt is not None:
            decision["decision_receipt"] = receipt
        return decision

    def build_preflight_request(
        self,
        installer,
        *,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        boundary_kind: str,
        action_class: str | None,
        trust_boundary_crossing: bool | None,
        tool_descriptor: dict[str, Any] | None,
        tool_source: str | None,
    ) -> tuple[dict[str, Any], dict[str, Any], str]:
        observed_refs = installer.recent_object_refs(
            tool_descriptor=tool_descriptor,
            target=target,
            transport_args=transport_args,
        )
        envelope = self.verifiedx.capture.current_context().envelope(
            boundary_kind,
            action_class=None if boundary_kind == "memory_write" else action_class,
            linked_object_ids=[
                reference["object_id"] for reference in observed_refs if reference.get("object_id")
            ][:16],
            sensitivity=installer._guess_sensitivity(surface=surface, method=method),
        )
        decision_context = build_decision_context(
            installer,
            surface=surface,
            operation=operation,
            target=target,
            method=method,
            transport_args=transport_args,
            boundary_kind=boundary_kind,
            trust_boundary_crossing=trust_boundary_crossing,
            tool_descriptor=tool_descriptor,
        )
        candidate_hash = compute_candidate_hash(envelope, decision_context)
        observed_boundary = build_execution_anchor(
            envelope=envelope,
            boundary_kind=boundary_kind,
            surface=surface,
            operation=operation,
            target=target,
            method=method,
            transport_args=transport_args,
            trust_boundary_crossing=bool(trust_boundary_crossing),
            decision_context=decision_context,
        )
        return {
            "envelope": envelope,
            "decision_context": decision_context,
        }, observed_boundary, candidate_hash

    def preflight(
        self,
        installer,
        *,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        boundary_kind: str,
        action_class: str | None,
        trust_boundary_crossing: bool | None,
        tool_descriptor: dict[str, Any] | None,
        tool_source: str | None,
    ) -> tuple[dict[str, Any], dict[str, Any], str]:
        payload, observed_boundary, candidate_hash = self.build_preflight_request(
            installer,
            surface=surface,
            operation=operation,
            target=target,
            method=method,
            transport_args=transport_args,
            boundary_kind=boundary_kind,
            action_class=action_class,
            trust_boundary_crossing=trust_boundary_crossing,
            tool_descriptor=tool_descriptor,
            tool_source=tool_source,
        )
        decision = self._enrich_decision(post_preflight(self.verifiedx.client, payload))
        return decision, observed_boundary, candidate_hash

    def submit_preflight_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._enrich_decision(post_preflight(self.verifiedx.client, payload))

    async def preflight_async(
        self,
        installer,
        *,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        boundary_kind: str,
        action_class: str | None,
        trust_boundary_crossing: bool | None,
        tool_descriptor: dict[str, Any] | None,
        tool_source: str | None,
    ) -> tuple[dict[str, Any], dict[str, Any], str]:
        payload, observed_boundary, candidate_hash = self.build_preflight_request(
            installer,
            surface=surface,
            operation=operation,
            target=target,
            method=method,
            transport_args=transport_args,
            boundary_kind=boundary_kind,
            action_class=action_class,
            trust_boundary_crossing=trust_boundary_crossing,
            tool_descriptor=tool_descriptor,
            tool_source=tool_source,
        )
        decision = self._enrich_decision(await post_preflight_async(self.verifiedx.client, payload))
        return decision, observed_boundary, candidate_hash

    async def submit_preflight_payload_async(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._enrich_decision(await post_preflight_async(self.verifiedx.client, payload))

    def report_execution(
        self,
        *,
        observed_boundary: dict[str, Any],
        candidate_hash: str,
        decision_id: str | None,
        boundary_kind: str,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        result: Any,
        side_effect_executed: bool,
        error_message: str | None = None,
    ) -> dict[str, Any]:
        payload = build_execution_report_payload(
            observed_boundary=observed_boundary,
            candidate_hash=candidate_hash,
            decision_id=decision_id,
            boundary_kind=boundary_kind,
            surface=surface,
            operation=operation,
            target=target,
            method=method,
            transport_args=transport_args,
            result=result,
            side_effect_executed=side_effect_executed,
            error_message=error_message,
        )
        return post_execution_report(self.verifiedx.client, payload)

    async def report_execution_async(
        self,
        *,
        observed_boundary: dict[str, Any],
        candidate_hash: str,
        decision_id: str | None,
        boundary_kind: str,
        surface: str,
        operation: str,
        target: str,
        method: str | None,
        transport_args: dict[str, Any],
        result: Any,
        side_effect_executed: bool,
        error_message: str | None = None,
    ) -> dict[str, Any]:
        payload = build_execution_report_payload(
            observed_boundary=observed_boundary,
            candidate_hash=candidate_hash,
            decision_id=decision_id,
            boundary_kind=boundary_kind,
            surface=surface,
            operation=operation,
            target=target,
            method=method,
            transport_args=transport_args,
            result=result,
            side_effect_executed=side_effect_executed,
            error_message=error_message,
        )
        return await post_execution_report_async(self.verifiedx.client, payload)
