from __future__ import annotations

import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from typing import Sequence

from .runtime import init_verifiedx
from .zero_touch import (
    RuntimeBoundaryDeniedError,
    RuntimeExecutionFailureError,
    _shell_command_boundary_details,
)


_TMUX_SEND_COMMANDS = {"send", "send-keys"}
_TMUX_SEND_KEY_VALUE_OPTIONS = {"-c", "-N", "-t"}
_TMUX_SEND_KEY_FLAG_CHARS = set("FHKlMRX")
_TMUX_CONTROL_KEYS = {"C-m", "Enter", "KPEnter"}
_TMUX_BLOCK_EXIT_CODE = 70


def _enabled(name: str) -> bool:
    return str(os.environ.get(name, "")).strip().lower() in {"1", "true", "yes", "on"}


def _should_intercept_tmux() -> bool:
    return _enabled("VERIFIEDX_AUTO_INIT") and bool(os.environ.get("VERIFIEDX_API_KEY"))


def _path_is_verifiedx_tmux_shim(path_value: str) -> bool:
    if not path_value:
        return False
    try:
        candidate = Path(path_value)
    except Exception:
        return False
    if candidate.is_dir():
        candidate = candidate / "tmux"
    if not candidate.is_file():
        return False
    try:
        contents = candidate.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return False
    return "verifiedx.tmux_shim" in contents


def _path_entry_is_verifiedx_tmux_shim(directory: str) -> bool:
    return _path_is_verifiedx_tmux_shim(directory)


def _searchable_tmux_path() -> str:
    shim_dir = os.environ.get("VERIFIEDX_TMUX_SHIM_DIR")
    current_script_dir = None
    if sys.argv and sys.argv[0]:
        try:
            current_script_dir = str(Path(sys.argv[0]).resolve().parent)
        except Exception:
            current_script_dir = None
    kept_dirs: list[str] = []
    for directory in os.get_exec_path():
        if not directory:
            continue
        try:
            normalized = str(Path(directory).resolve())
        except Exception:
            normalized = directory
        if shim_dir:
            try:
                if normalized == str(Path(shim_dir).resolve()):
                    continue
            except Exception:
                if directory == shim_dir:
                    continue
        if current_script_dir and normalized == current_script_dir:
            continue
        if _path_entry_is_verifiedx_tmux_shim(directory):
            continue
        kept_dirs.append(directory)
    return os.pathsep.join(kept_dirs)


def _resolve_real_tmux() -> str:
    override = str(os.environ.get("VERIFIEDX_TMUX_REAL") or "").strip()
    if override:
        if not _path_is_verifiedx_tmux_shim(override):
            return override
    resolved = shutil.which("tmux", path=_searchable_tmux_path())
    if not resolved:
        raise FileNotFoundError("Unable to find the real tmux binary after excluding the VerifiedX shim path.")
    if _path_is_verifiedx_tmux_shim(resolved):
        raise FileNotFoundError("Resolved tmux path still points at the VerifiedX shim.")
    return resolved


def _tmux_send_command_index(argv: Sequence[str]) -> int | None:
    for index, token in enumerate(argv):
        if token in _TMUX_SEND_COMMANDS:
            return index
    return None


def _is_tmux_flag_cluster(token: str) -> bool:
    if not token.startswith("-") or token.startswith("--") or len(token) <= 2:
        return False
    return set(token[1:]) <= _TMUX_SEND_KEY_FLAG_CHARS


def _extract_send_keys_command(argv: Sequence[str]) -> str | None:
    command_index = _tmux_send_command_index(argv)
    if command_index is None:
        return None
    keys: list[str] = []
    index = command_index + 1
    parsing_tmux_options = True
    while index < len(argv):
        token = argv[index]
        if parsing_tmux_options and token in _TMUX_SEND_KEY_VALUE_OPTIONS and index + 1 < len(argv):
            index += 2
            continue
        if parsing_tmux_options and token.startswith(("-c", "-N", "-t")) and len(token) > 2:
            index += 1
            continue
        if parsing_tmux_options and token.startswith("-") and (
            token in {"-F", "-H", "-K", "-l", "-M", "-R", "-X"} or _is_tmux_flag_cluster(token)
        ):
            index += 1
            continue
        parsing_tmux_options = False
        keys.append(token)
        index += 1
    while keys and keys[-1] in _TMUX_CONTROL_KEYS:
        keys.pop()
    command_parts = [part for part in keys if part]
    if len(command_parts) == 1:
        command_text = str(command_parts[0]).strip()
    else:
        command_text = shlex.join(command_parts).strip()
    return command_text or None


def _write_stream_bytes(stream_name: str, payload: bytes) -> None:
    if not payload:
        return
    stream = getattr(sys, stream_name, None)
    if stream is None:
        return
    buffer = getattr(stream, "buffer", None)
    if buffer is not None:
        buffer.write(payload)
        buffer.flush()
        return
    stream.write(payload.decode("utf-8", errors="replace"))
    stream.flush()


def _write_stderr_line(message: str) -> None:
    if not message:
        return
    stream = getattr(sys, "stderr", None)
    if stream is None:
        return
    stream.write(message.rstrip() + "\n")
    stream.flush()


def _run_real_tmux(real_tmux: str, argv: Sequence[str]) -> dict[str, int | bool]:
    completed = subprocess.run(
        [real_tmux, *argv],
        capture_output=True,
        check=False,
    )
    _write_stream_bytes("stdout", completed.stdout or b"")
    _write_stream_bytes("stderr", completed.stderr or b"")
    return {
        "ok": completed.returncode == 0,
        "returncode": int(completed.returncode),
        "status": "ok" if completed.returncode == 0 else "error",
    }


def _block_message(error: RuntimeBoundaryDeniedError) -> str:
    tool_result = error.tool_result()
    reasons = tool_result.get("reasons") or []
    primary_reason = None
    if reasons and isinstance(reasons[0], dict):
        primary_reason = reasons[0].get("message")
    if isinstance(primary_reason, str) and primary_reason.strip():
        return f"VerifiedX blocked this terminal side effect. {primary_reason.strip()}"
    return "VerifiedX blocked this terminal side effect."


def _passthrough(real_tmux: str, argv: Sequence[str]) -> int:
    return int(_run_real_tmux(real_tmux, argv).get("returncode", 1))


def main(argv: Sequence[str] | None = None) -> int:
    effective_argv = list(sys.argv[1:] if argv is None else argv)
    real_tmux = _resolve_real_tmux()
    command_text = _extract_send_keys_command(effective_argv)
    if command_text is None or not _should_intercept_tmux():
        return _passthrough(real_tmux, effective_argv)

    try:
        verifiedx = init_verifiedx()
        if not verifiedx.runtime_enabled:
            verifiedx.install_runtime()
    except Exception:
        if _enabled("VERIFIEDX_STRICT_AUTO_INIT"):
            raise
        return _passthrough(real_tmux, effective_argv)

    capture = _shell_command_boundary_details(None, command=command_text)
    if capture is None:
        return _passthrough(real_tmux, effective_argv)

    try:
        result = verifiedx.zero_touch.intercept_boundary(
            surface=str(capture["surface"]),
            operation=str(capture["operation"]),
            target=str(capture["target"]),
            method=capture.get("method"),
            transport_args=dict(capture.get("transport_args") or {}),
            boundary_kind=capture.get("boundary_kind"),
            action_class=capture.get("action_class"),
            trust_boundary_crossing=bool(capture.get("trust_boundary_crossing")),
            tool_descriptor=capture.get("tool_descriptor"),
            execute=lambda: _run_real_tmux(real_tmux, effective_argv),
        )
    except RuntimeBoundaryDeniedError as error:
        _write_stderr_line(_block_message(error))
        return _TMUX_BLOCK_EXIT_CODE
    except RuntimeExecutionFailureError as error:
        return int(error.tool_result.get("returncode") or 1)
    if isinstance(result, dict):
        return int(result.get("returncode", 0))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
