from __future__ import annotations

from dataclasses import dataclass
import os
import socket


def _env(name: str, default: str | None = None) -> str | None:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    return value


def _env_any(names: tuple[str, ...], default: str | None = None) -> str | None:
    for name in names:
        value = _env(name)
        if value is not None:
            return value
    return default


def _env_bool(name: str, default: bool = False) -> bool:
    value = _env(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class VerifiedXConfig:
    api_key: str | None
    base_url: str
    org_id: str
    project_id: str
    environment: str
    agent_id: str
    source_system: str
    timeout_seconds: float
    flush_batch_size: int
    max_flush_payload_bytes: int
    default_sensitivity: str
    debug_decisions: bool
    debug_fetch_decisions: bool
    debug_dir: str | None
    direct_ingress_labeling: bool
    strict_direct_ingress_labeling: bool
    max_ingress_excerpt_chars: int

    @classmethod
    def from_env(cls, require_api_key: bool = True) -> "VerifiedXConfig":
        api_key = _env("VERIFIEDX_API_KEY")
        if require_api_key and not api_key:
            raise ValueError("VERIFIEDX_API_KEY is required")
        return cls(
            api_key=api_key,
            base_url=_env("VERIFIEDX_BASE_URL", "https://api.verifiedx.me")
            or "https://api.verifiedx.me",
            org_id=_env_any(("VERIFIEDX_ORG_ID", "VERIFIEDX_ORG_SLUG"), "org_1") or "org_1",
            project_id=_env_any(
                ("VERIFIEDX_PROJECT_ID", "VERIFIEDX_PROJECT_SLUG"),
                "project_1",
            )
            or "project_1",
            environment=_env_any(
                ("VERIFIEDX_ENVIRONMENT", "VERIFIEDX_ENV_SLUG"),
                "prod",
            )
            or "prod",
            agent_id=_env("VERIFIEDX_AGENT_ID", f"python-{socket.gethostname()}") or "python-agent",
            source_system=_env("VERIFIEDX_SOURCE_SYSTEM", "verifiedx-python") or "verifiedx-python",
            timeout_seconds=float(_env("VERIFIEDX_TIMEOUT_SECONDS", "120") or "120"),
            flush_batch_size=int(_env("VERIFIEDX_FLUSH_BATCH_SIZE", "50") or "50"),
            max_flush_payload_bytes=int(
                _env("VERIFIEDX_MAX_FLUSH_PAYLOAD_BYTES", "7000") or "7000"
            ),
            default_sensitivity=_env("VERIFIEDX_DEFAULT_SENSITIVITY", "high") or "high",
            debug_decisions=_env_bool("VERIFIEDX_DEBUG_DECISIONS", False),
            debug_fetch_decisions=_env_bool("VERIFIEDX_DEBUG_FETCH_DECISIONS", False),
            debug_dir=_env("VERIFIEDX_DEBUG_DIR"),
            direct_ingress_labeling=_env_bool("VERIFIEDX_DIRECT_INGRESS_LABELING", True),
            strict_direct_ingress_labeling=_env_bool(
                "VERIFIEDX_STRICT_DIRECT_INGRESS_LABELING",
                False,
            ),
            max_ingress_excerpt_chars=int(
                _env("VERIFIEDX_MAX_INGRESS_EXCERPT_CHARS", "1200") or "1200"
            ),
        )
