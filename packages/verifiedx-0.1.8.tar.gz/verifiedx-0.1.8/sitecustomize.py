from __future__ import annotations

import os
from pathlib import Path
import tempfile


def _enabled(name: str) -> bool:
    return str(os.environ.get(name, "")).strip().lower() in {"1", "true", "yes", "on"}


def _materialize_runtime_shims(source_dir: Path) -> Path | None:
    try:
        runtime_dir = Path(
            os.environ.get("VERIFIEDX_RUNTIME_SHIM_DIR")
            or (Path(tempfile.gettempdir()) / "verifiedx-runtime-bin")
        )
        runtime_dir.mkdir(parents=True, exist_ok=True)
        for source in source_dir.iterdir():
            if not source.is_file():
                continue
            target = runtime_dir / source.name
            payload = source.read_bytes()
            if not target.exists() or target.read_bytes() != payload:
                temporary_target = target.with_suffix(f"{target.suffix}.tmp")
                temporary_target.write_bytes(payload)
                os.replace(temporary_target, target)
            target.chmod(0o755)
        return runtime_dir
    except Exception:
        return None


def _prepend_runtime_shims_to_path() -> None:
    bin_dir = Path(__file__).resolve().parent / "verifiedx" / "bin"
    if not bin_dir.is_dir():
        return
    preferred_dir = _materialize_runtime_shims(bin_dir) or bin_dir
    current_path = os.environ.get("PATH", "")
    parts = [part for part in current_path.split(os.pathsep) if part]
    normalized_preferred = os.path.normcase(os.path.normpath(str(preferred_dir)))
    if any(os.path.normcase(os.path.normpath(part)) == normalized_preferred for part in parts):
        return
    os.environ["PATH"] = (
        str(preferred_dir) if not current_path else f"{preferred_dir}{os.pathsep}{current_path}"
    )


def _auto_init_verifiedx() -> None:
    if not _enabled("VERIFIEDX_AUTO_INIT"):
        return
    _prepend_runtime_shims_to_path()
    if not os.environ.get("VERIFIEDX_API_KEY"):
        return
    try:
        from verifiedx import init_verifiedx

        verifiedx = init_verifiedx()
        if not verifiedx.runtime_enabled:
            verifiedx.install_runtime()
    except Exception:
        if _enabled("VERIFIEDX_STRICT_AUTO_INIT"):
            raise


_auto_init_verifiedx()
