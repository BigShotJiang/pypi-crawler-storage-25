"""Glassbox SDK Python — agent-agnostic.

API publique (stable) :

    from glassbox_sdk import Client, Descriptor, Decision, Config, FailMode
    from glassbox_sdk import (
        GlassboxError,
        GlassboxAuthError,
        GlassboxUnreachableError,
        GlassboxRejected,
        GlassboxRateLimited,
        GlassboxConfigError,
    )

Quickstart :

    client = Client.from_env()
    descriptor = Descriptor.shell_command(command="rm -rf /tmp/cache")
    decision = client.preflight(descriptor=descriptor, client_request_id="uuid-1")
    if decision.is_approved:
        ...  # exécute l'action
    else:
        ...  # bloque
"""

from __future__ import annotations

from glassbox_sdk.client import Client, FetchedConfig, OrgSettings
from glassbox_sdk.config import Config, FailMode
from glassbox_sdk.decision import Decision, DecisionStatus
from glassbox_sdk.descriptor import Descriptor
from glassbox_sdk.exceptions import (
    GlassboxAuthError,
    GlassboxConfigError,
    GlassboxError,
    GlassboxRateLimited,
    GlassboxRejected,
    GlassboxUnreachableError,
)

__version__ = "0.1.0"

__all__ = [
    "Client",
    "Config",
    "Decision",
    "DecisionStatus",
    "Descriptor",
    "FailMode",
    "FetchedConfig",
    "GlassboxAuthError",
    "GlassboxConfigError",
    "GlassboxError",
    "GlassboxRateLimited",
    "GlassboxRejected",
    "GlassboxUnreachableError",
    "OrgSettings",
    "__version__",
]
