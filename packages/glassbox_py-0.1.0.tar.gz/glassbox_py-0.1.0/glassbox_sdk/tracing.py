"""Logger structuré pour le SDK.

Si `structlog` est installé (extra `[logging]`), on utilise sa config par
défaut vers stderr. Sinon fallback sur `logging` stdlib avec un format simple.

L'objectif n'est pas de gérer la production logs côté agent (c'est le rôle de
l'app hôte) mais de donner au caller des messages diagnostiquables quand
quelque chose part en vrille (auth invalide, unreachable, redact appliqué).
"""

from __future__ import annotations

import logging
import sys
from typing import Any, Protocol


class Logger(Protocol):
    def debug(self, msg: str, **kwargs: Any) -> None: ...
    def info(self, msg: str, **kwargs: Any) -> None: ...
    def warning(self, msg: str, **kwargs: Any) -> None: ...
    def error(self, msg: str, **kwargs: Any) -> None: ...


def get_logger(name: str = "glassbox_sdk") -> Logger:
    try:
        import structlog

        structlog.configure(
            processors=[
                structlog.processors.add_log_level,
                structlog.processors.TimeStamper(fmt="iso"),
                structlog.dev.ConsoleRenderer(),
            ]
        )
        return structlog.get_logger(name)  # type: ignore[no-any-return]
    except ImportError:
        logger = logging.getLogger(name)
        if not logger.handlers:
            handler = logging.StreamHandler(sys.stderr)
            handler.setFormatter(
                logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s")
            )
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return _StdlibLoggerAdapter(logger)


class _StdlibLoggerAdapter:
    """Adapte logging.Logger au protocole structlog (kwargs → message suffix)."""

    def __init__(self, logger: logging.Logger) -> None:
        self._logger = logger

    @staticmethod
    def _fmt(msg: str, kwargs: dict[str, Any]) -> str:
        if not kwargs:
            return msg
        kv = " ".join(f"{k}={v!r}" for k, v in kwargs.items())
        return f"{msg} {kv}"

    def debug(self, msg: str, **kwargs: Any) -> None:
        self._logger.debug(self._fmt(msg, kwargs))

    def info(self, msg: str, **kwargs: Any) -> None:
        self._logger.info(self._fmt(msg, kwargs))

    def warning(self, msg: str, **kwargs: Any) -> None:
        self._logger.warning(self._fmt(msg, kwargs))

    def error(self, msg: str, **kwargs: Any) -> None:
        self._logger.error(self._fmt(msg, kwargs))
