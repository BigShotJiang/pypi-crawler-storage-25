"""Heuristique de redaction des secrets — séparator-bounded.

Mirror EXACT de src/lib/agents/redact.ts (P1). Toute divergence brise la
cohérence wire entre SDK et serveur (le serveur redacterait à nouveau ce
qui n'a pas été redacté côté plugin → différence de payload audité).

Stratégie : on normalise la clé (camelCase → snake_case + lowercase) puis on
matche soit la clé entière, soit un de ses segments (séparateurs `_`, `-`, `.`).
Évite les faux positifs `tokenize`, `authorize`, `oauthCallbackUrl`.
"""

from __future__ import annotations

import re
from typing import Any

SENSITIVE_KEYS = frozenset(
    {
        "password",
        "token",
        "secret",
        "api_key",
        "apikey",
        "auth",
        "authorization",
    }
)
REDACTED = "[REDACTED]"
_CAMEL_TO_SNAKE = re.compile(r"([a-z])([A-Z])")
_SEPARATORS = re.compile(r"[_\-.]+")


def _is_sensitive_key(key: str) -> bool:
    lower = key.lower()
    if lower in SENSITIVE_KEYS:
        return True
    # Normalise camelCase → snake_case puis lowercase.
    normalized = _CAMEL_TO_SNAKE.sub(r"\1_\2", key).lower()
    if normalized in SENSITIVE_KEYS:
        return True
    # Match si l'un des segments séparés par `_`, `-`, `.` est sensible.
    parts = _SEPARATORS.split(normalized)
    return any(p in SENSITIVE_KEYS for p in parts)


def redact_secrets(value: Any) -> Any:
    """Retourne une copie profonde avec les valeurs des clés sensibles masquées.

    À appeler AVANT tout logging ou tout envoi HTTP d'un payload reçu de
    l'agent (descriptor, args, command, ...).
    """
    if value is None:
        return None
    if isinstance(value, dict):
        return {
            k: (REDACTED if _is_sensitive_key(k) else redact_secrets(v)) for k, v in value.items()
        }
    if isinstance(value, list):
        return [redact_secrets(item) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_secrets(item) for item in value)
    return value
