"""Hiérarchie d'exceptions du SDK.

Les callers (adaptateurs Hermes / n8n / custom) catch `GlassboxError` pour
intercepter tout problème SDK sans connaître les détails.
"""

from __future__ import annotations


class GlassboxError(Exception):
    """Base — tout ce que le SDK peut lever."""


class GlassboxConfigError(GlassboxError):
    """Config invalide ou incomplète (URL, token, fail_mode)."""


class GlassboxAuthError(GlassboxError):
    """401 / 403 du serveur — token absent, invalide, révoqué."""


class GlassboxUnreachableError(GlassboxError):
    """Réseau down, timeout DNS, TLS handshake échoué."""


class GlassboxRejected(GlassboxError):
    """Pre-flight a retourné rejected / auto_rejected / expired.

    Le caller doit interpréter comme une demande explicite d'arrêt de l'action.
    """

    def __init__(self, status: str, reason: str | None = None) -> None:
        self.status = status
        self.reason = reason
        super().__init__(f"Pre-flight {status}: {reason or 'no reason given'}")


class GlassboxRateLimited(GlassboxError):
    """429 — retry après backoff côté caller (ou drop si fire-and-forget)."""
