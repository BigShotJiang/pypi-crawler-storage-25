"""Modèle Descriptor + builders typés pour les action_type courantes.

Le Descriptor est le payload commun poussé vers /api/agents/events ET
/api/agents/preflight. Il est sérialisé en camelCase pour matcher le contrat
HTTP P1 (zod schemas dans src/app/api/agents/*).
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class Descriptor(BaseModel):
    """Description structurée d'une action agent.

    Côté Python on reste en snake_case ; `to_wire()` convertit en camelCase
    pour le serveur Glassbox.
    """

    model_config = ConfigDict(populate_by_name=True, frozen=True)

    action_type: str = Field(..., description="ex: file_write, payment, shell_command")
    descriptor: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    # Builders typés — les helpers les plus courants. Les autres tools utilisent
    # le constructeur direct + descriptor brut.

    @classmethod
    def file_write(cls, path: str, size: int | None = None, **extra: Any) -> Descriptor:
        return cls(
            action_type="file_write",
            descriptor={"path": path, **({"size": size} if size is not None else {}), **extra},
        )

    @classmethod
    def file_delete(cls, path: str, **extra: Any) -> Descriptor:
        return cls(action_type="file_delete", descriptor={"path": path, **extra})

    @classmethod
    def shell_command(cls, command: str, **extra: Any) -> Descriptor:
        return cls(action_type="shell_command", descriptor={"command": command, **extra})

    @classmethod
    def network_read(cls, url: str, method: str = "GET", **extra: Any) -> Descriptor:
        return cls(action_type="network_read", descriptor={"url": url, "method": method, **extra})

    @classmethod
    def network_write(cls, url: str, method: str, **extra: Any) -> Descriptor:
        return cls(action_type="network_write", descriptor={"url": url, "method": method, **extra})

    @classmethod
    def payment(
        cls, amount: float, currency: str | None = None, provider: str | None = None, **extra: Any
    ) -> Descriptor:
        payload: dict[str, Any] = {"amount": amount}
        if currency is not None:
            payload["currency"] = currency
        if provider is not None:
            payload["provider"] = provider
        payload.update(extra)
        return cls(action_type="payment", descriptor=payload)

    @classmethod
    def external_message(
        cls, recipient: str, excerpt: str | None = None, **extra: Any
    ) -> Descriptor:
        payload: dict[str, Any] = {"recipient": recipient}
        if excerpt is not None:
            payload["excerpt"] = excerpt
        payload.update(extra)
        return cls(action_type="external_message", descriptor=payload)

    # Sérialisation wire — camelCase comme attendu par les zod schemas P1.

    def to_wire(
        self,
        *,
        agent_name: str | None = None,
        agent_source: str | None = None,
        client_request_id: str | None = None,
    ) -> dict[str, Any]:
        """Forme attendue par POST /api/agents/preflight."""
        out: dict[str, Any] = {
            "actionType": self.action_type,
            "descriptor": dict(self.descriptor),
            "metadata": dict(self.metadata),
        }
        if agent_name is not None:
            out["agentName"] = agent_name
        if agent_source is not None:
            out["agentSource"] = agent_source
        if client_request_id is not None:
            out["clientRequestId"] = client_request_id
        return out

    def to_event_wire(
        self,
        *,
        external_id: str,
        source: str,
        type: str,
        agent_name: str | None = None,
        started_at: str | None = None,
        duration_ms: int | None = None,
        total_tokens: int | None = None,
        cost_usd: float | None = None,
        preflight_decision_id: str | None = None,
    ) -> dict[str, Any]:
        """Forme attendue par POST /api/agents/events."""
        out: dict[str, Any] = {
            "externalId": external_id,
            "source": source,
            "type": type,
            "actionType": self.action_type,
            "descriptor": dict(self.descriptor),
            "metadata": dict(self.metadata),
        }
        if agent_name is not None:
            out["agentName"] = agent_name
        if started_at is not None:
            out["startedAt"] = started_at
        if duration_ms is not None:
            out["durationMs"] = duration_ms
        if total_tokens is not None:
            out["totalTokens"] = total_tokens
        if cost_usd is not None:
            out["costUsd"] = cost_usd
        if preflight_decision_id is not None:
            out["preflightDecisionId"] = preflight_decision_id
        return out
