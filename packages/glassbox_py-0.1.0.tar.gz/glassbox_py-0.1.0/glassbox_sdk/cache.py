"""Cache TTL en mémoire — utilisé pour rules + settings côté plugin.

Volume très faible attendu (1 entrée "config" par instance plugin), pas besoin
de LRU ni de structure complexe. Thread-safe via dict atomique CPython suffit
pour l'usage agent-side (un seul thread d'event loop typique).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")


def _now() -> float:
    """Indirection pour permettre le freeze des tests via monkeypatch."""
    return time.monotonic()


@dataclass
class _Entry(Generic[T]):
    value: T
    expires_at: float


class TTLCache(Generic[T]):
    def __init__(self, ttl_seconds: float) -> None:
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds doit être > 0")
        self._ttl = ttl_seconds
        self._store: dict[str, _Entry[T]] = {}

    def get(self, key: str) -> T | None:
        entry = self._store.get(key)
        if entry is None:
            return None
        if _now() >= entry.expires_at:
            self._store.pop(key, None)
            return None
        return entry.value

    def set(self, key: str, value: T) -> None:
        self._store[key] = _Entry(value=value, expires_at=_now() + self._ttl)

    def invalidate(self, key: str) -> None:
        self._store.pop(key, None)

    def clear(self) -> None:
        self._store.clear()
