"""Décision failsafe quand le réseau Glassbox est inaccessible.

`reject` (défaut sécurité) : on bloque toute action critique. C'est une
exigence stricte de la spec §7 (Glassbox unreachable + fail_mode=reject →
action critique bloquée).

`log_only` (opt-in dev) : on laisse passer mais on log un warning. Réservé
au développement local pour ne pas bloquer une session de test.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from glassbox_sdk.decision import Decision

FailMode = Literal["reject", "log_only"]


def failsafe_decision(*, reason: str, fail_mode: FailMode) -> Decision:
    # Import local pour éviter le cycle d'import.
    from glassbox_sdk.decision import Decision

    if fail_mode == "reject":
        return Decision(
            id=None,
            status="auto_rejected",
            matched_rule_id=None,
            decided_by=None,
            expires_at=None,
            reason=f"Glassbox unreachable + fail_mode=reject ({reason})",
        )
    return Decision(
        id=None,
        status="auto_approved",
        matched_rule_id=None,
        decided_by=None,
        expires_at=None,
        reason=f"Glassbox unreachable + fail_mode=log_only — action autorisée ({reason})",
    )
