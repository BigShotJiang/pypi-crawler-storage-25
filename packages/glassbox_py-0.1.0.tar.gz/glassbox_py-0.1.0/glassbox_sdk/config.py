"""Loader de config Glassbox — env vars OU fichier TOML.

Précédence : args explicites > env vars > TOML > défauts.

`fail_mode="reject"` est le défaut sécurisé (cf. spec §7). `log_only` est opt-in
explicite pour le développement local.
"""

from __future__ import annotations

import os
import re
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from glassbox_sdk.exceptions import GlassboxConfigError

FailMode = Literal["reject", "log_only"]
_VALID_FAIL_MODES: tuple[FailMode, ...] = ("reject", "log_only")
_ENV_VAR_INTERP = re.compile(r"\$\{([A-Z_][A-Z0-9_]*)\}")


@dataclass(frozen=True)
class Config:
    api_url: str
    api_token: str
    agent_name: str
    agent_source: str = "glassbox-sdk-python"
    fail_mode: FailMode = "reject"
    cache_ttl_seconds: int = 60
    request_timeout_seconds: float = 10.0
    sse_total_timeout_seconds: float = 360.0  # > preflight_timeout_seconds (300s) côté serveur

    @classmethod
    def from_env(cls) -> Config:
        api_url = os.environ.get("GLASSBOX_API_URL", "").strip()
        api_token = os.environ.get("GLASSBOX_API_TOKEN", "").strip()
        agent_name = os.environ.get("GLASSBOX_AGENT_NAME", "Unknown-Agent").strip()
        agent_source = os.environ.get("GLASSBOX_AGENT_SOURCE", "glassbox-sdk-python").strip()
        fail_mode_raw = os.environ.get("GLASSBOX_FAIL_MODE", "reject").strip()
        cache_ttl = int(os.environ.get("GLASSBOX_CACHE_TTL_SECONDS", "60"))
        return cls._validate(
            api_url=api_url,
            api_token=api_token,
            agent_name=agent_name,
            agent_source=agent_source,
            fail_mode_raw=fail_mode_raw,
            cache_ttl=cache_ttl,
        )

    @classmethod
    def from_toml(cls, path: str | Path) -> Config:
        p = Path(path)
        if not p.exists():
            raise GlassboxConfigError(f"Config TOML introuvable : {p}")
        with p.open("rb") as f:
            data = tomllib.load(f)
        section = data.get("glassbox", {})
        api_url = _interpolate_env(section.get("api_url", "")).strip()
        api_token = _interpolate_env(section.get("api_token", "")).strip()
        agent_name = _interpolate_env(section.get("agent_name", "Unknown-Agent")).strip()
        agent_source = _interpolate_env(section.get("agent_source", "glassbox-sdk-python")).strip()
        fail_mode_raw = section.get("fail_mode", "reject")
        cache_ttl = int(section.get("cache_ttl_seconds", 60))
        return cls._validate(
            api_url=api_url,
            api_token=api_token,
            agent_name=agent_name,
            agent_source=agent_source,
            fail_mode_raw=fail_mode_raw,
            cache_ttl=cache_ttl,
        )

    @classmethod
    def _validate(
        cls,
        *,
        api_url: str,
        api_token: str,
        agent_name: str,
        agent_source: str,
        fail_mode_raw: str,
        cache_ttl: int,
    ) -> Config:
        if not api_url:
            raise GlassboxConfigError("api_url manquant (GLASSBOX_API_URL)")
        if not api_url.startswith("https://"):
            raise GlassboxConfigError(f"api_url doit commencer par https:// (reçu: {api_url})")
        if not api_token:
            raise GlassboxConfigError("api_token manquant (GLASSBOX_API_TOKEN)")
        if fail_mode_raw not in _VALID_FAIL_MODES:
            raise GlassboxConfigError(
                f"fail_mode invalide '{fail_mode_raw}' — autorisés : {_VALID_FAIL_MODES}"
            )
        return cls(
            api_url=api_url.rstrip("/"),
            api_token=api_token,
            agent_name=agent_name,
            agent_source=agent_source,
            fail_mode=fail_mode_raw,
            cache_ttl_seconds=cache_ttl,
        )


def _interpolate_env(value: str) -> str:
    """Remplace `${VAR}` par `os.environ["VAR"]` dans une string."""
    if not isinstance(value, str):
        return value

    def repl(m: re.Match[str]) -> str:
        return os.environ.get(m.group(1), "")

    return _ENV_VAR_INTERP.sub(repl, value)
