"""Modèle Decision — résultat d'un appel preflight (auto ou humain).

`status` reflète le cycle de vie côté serveur P1 (cf. preflight_decisions.status
CHECK constraint) :

  pending          en attente d'une décision humaine
  approved         humain a validé via PWA
  rejected         humain a rejeté
  expired          délai dépassé sans réponse
  auto_approved    règle utilisateur a matché → auto-approve
  auto_rejected    règle utilisateur a matché → auto-reject

Côté SDK on regroupe via `is_approved` / `is_rejected` / `is_pending`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

DecisionStatus = Literal[
    "pending", "approved", "rejected", "expired", "auto_approved", "auto_rejected"
]

_APPROVED = {"approved", "auto_approved"}
_REJECTED = {"rejected", "auto_rejected", "expired"}


@dataclass(frozen=True)
class Decision:
    id: str | None
    status: DecisionStatus
    matched_rule_id: str | None
    decided_by: str | None
    expires_at: str | None
    reason: str | None

    @property
    def is_approved(self) -> bool:
        return self.status in _APPROVED

    @property
    def is_rejected(self) -> bool:
        return self.status in _REJECTED

    @property
    def is_pending(self) -> bool:
        return self.status == "pending"

    @classmethod
    def from_wire(cls, payload: dict[str, Any]) -> Decision:
        """Convertit la réponse JSON camelCase du serveur P1."""
        return cls(
            id=payload.get("id"),
            status=payload["status"],
            matched_rule_id=payload.get("matchedRuleId"),
            decided_by=payload.get("decidedBy"),
            expires_at=payload.get("expiresAt"),
            reason=payload.get("reason"),
        )
