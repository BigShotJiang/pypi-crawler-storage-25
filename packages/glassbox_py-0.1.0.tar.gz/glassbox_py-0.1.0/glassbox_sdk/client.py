"""Client HTTP Glassbox — events + preflight + config + SSE wait.

Instancié 1x par process agent et passé aux hooks. Stateful pour le cache TTL.

Le SSE est lu via `httpx.stream` qui supporte `Content-Type: text/event-stream`
en streaming. On parse événement par événement : `event:` puis `data:` puis
ligne vide = trigger de dispatch.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

import httpx

from glassbox_sdk.cache import TTLCache
from glassbox_sdk.config import Config
from glassbox_sdk.decision import Decision
from glassbox_sdk.descriptor import Descriptor
from glassbox_sdk.exceptions import (
    GlassboxAuthError,
    GlassboxError,
    GlassboxRateLimited,
    GlassboxUnreachableError,
)
from glassbox_sdk.failsafe import failsafe_decision
from glassbox_sdk.redact import redact_secrets
from glassbox_sdk.tracing import get_logger


@dataclass(frozen=True)
class OrgSettings:
    autonomy_default_decision: str
    preflight_timeout_seconds: int
    panic_mode: bool


@dataclass(frozen=True)
class FetchedConfig:
    version: str
    fetched_at: str
    settings: OrgSettings
    rules: list[dict[str, Any]] = field(default_factory=list)


class Client:
    """Client générique Glassbox (sync). Pour async voir AsyncClient (futur)."""

    def __init__(self, config: Config, http: httpx.Client | None = None) -> None:
        self._config = config
        self._http = http or httpx.Client(
            base_url=config.api_url,
            timeout=config.request_timeout_seconds,
            headers={"User-Agent": f"glassbox-sdk-python/0.1 ({config.agent_source})"},
        )
        self._cache: TTLCache[FetchedConfig] = TTLCache(ttl_seconds=config.cache_ttl_seconds)
        self._log = get_logger("glassbox_sdk.client")

    @classmethod
    def from_env(cls) -> Client:
        return cls(config=Config.from_env())

    @classmethod
    def from_toml(cls, path: str) -> Client:
        return cls(config=Config.from_toml(path))

    # --- Events (fire-and-forget côté caller) ---

    def push_event(
        self,
        *,
        external_id: str,
        source: str,
        type: str,
        descriptor: Descriptor,
        started_at: str | None = None,
        duration_ms: int | None = None,
        total_tokens: int | None = None,
        cost_usd: float | None = None,
        preflight_decision_id: str | None = None,
    ) -> str | None:
        """POST /api/agents/events. Retourne l'event_id ou None si swallowed."""
        # Redaction côté SDK avant envoi (cf. spec §7 sécurité).
        safe = Descriptor(
            action_type=descriptor.action_type,
            descriptor=redact_secrets(descriptor.descriptor),
            metadata=redact_secrets(descriptor.metadata),
        )
        body = safe.to_event_wire(
            external_id=external_id,
            source=source,
            type=type,
            agent_name=self._config.agent_name,
            started_at=started_at,
            duration_ms=duration_ms,
            total_tokens=total_tokens,
            cost_usd=cost_usd,
            preflight_decision_id=preflight_decision_id,
        )
        try:
            resp = self._http.post("/api/agents/events", json=body, headers=self._auth_headers())
        except httpx.RequestError as e:
            raise GlassboxUnreachableError(str(e)) from e
        self._raise_for_status(resp)
        data = resp.json()
        return data.get("id")  # type: ignore[no-any-return]

    # --- Preflight ---

    def preflight(
        self,
        *,
        descriptor: Descriptor,
        client_request_id: str,
        wait: bool = True,
    ) -> Decision:
        """POST /api/agents/preflight. Si status=pending et wait=True, ouvre un SSE."""
        safe = Descriptor(
            action_type=descriptor.action_type,
            descriptor=redact_secrets(descriptor.descriptor),
            metadata=redact_secrets(descriptor.metadata),
        )
        body = safe.to_wire(
            agent_name=self._config.agent_name,
            agent_source=self._config.agent_source,
            client_request_id=client_request_id,
        )
        try:
            resp = self._http.post("/api/agents/preflight", json=body, headers=self._auth_headers())
        except httpx.RequestError as e:
            self._log.warning("Glassbox unreachable, applying failsafe", error=str(e))
            return failsafe_decision(reason=str(e), fail_mode=self._config.fail_mode)

        self._raise_for_status(resp)
        decision = Decision.from_wire(resp.json())
        if not decision.is_pending or not wait or decision.id is None:
            return decision
        return self._wait_decision(decision_id=decision.id)

    def _wait_decision(self, *, decision_id: str) -> Decision:
        """Connecte le SSE GET /api/agents/preflight/:id/wait et bloque."""
        url = f"/api/agents/preflight/{decision_id}/wait"
        try:
            with self._http.stream(
                "GET",
                url,
                headers=self._auth_headers(),
                timeout=self._config.sse_total_timeout_seconds,
            ) as resp:
                if resp.status_code == 401:
                    raise GlassboxAuthError("Token invalide ou révoqué (SSE wait).")
                if resp.status_code == 404:
                    raise GlassboxError(f"Preflight {decision_id} introuvable.")
                if resp.status_code != 200:
                    raise GlassboxError(f"SSE wait status inattendu : {resp.status_code}")

                event_name: str | None = None
                data_buf: list[str] = []
                for line in resp.iter_lines():
                    if line.startswith("event:"):
                        event_name = line[len("event:") :].strip()
                    elif line.startswith("data:"):
                        data_buf.append(line[len("data:") :].strip())
                    elif line == "":
                        # Fin d'événement — dispatch.
                        if event_name == "status" and data_buf:
                            payload = json.loads("\n".join(data_buf))
                            return Decision.from_wire(payload)
                        # event: ping → ignore et continue.
                        event_name = None
                        data_buf = []
        except httpx.RequestError as e:
            self._log.warning("SSE wait unreachable", error=str(e))
            return failsafe_decision(reason=str(e), fail_mode=self._config.fail_mode)

        # Stream fermé sans status → fail-safe.
        return failsafe_decision(
            reason="SSE closed without final status",
            fail_mode=self._config.fail_mode,
        )

    # --- Config (cache TTL 60s par défaut) ---

    def fetch_config(self, force: bool = False) -> FetchedConfig:
        if not force:
            cached = self._cache.get("config")
            if cached is not None:
                return cached
        try:
            resp = self._http.get("/api/agents/config", headers=self._auth_headers())
        except httpx.RequestError as e:
            raise GlassboxUnreachableError(str(e)) from e
        self._raise_for_status(resp)
        data = resp.json()
        settings_raw = data.get("settings") or {}
        cfg = FetchedConfig(
            version=str(data.get("version", "")),
            fetched_at=str(data.get("fetchedAt", "")),
            settings=OrgSettings(
                autonomy_default_decision=settings_raw.get(
                    "autonomyDefaultDecision", "require_approval"
                ),
                preflight_timeout_seconds=int(settings_raw.get("preflightTimeoutSeconds", 300)),
                panic_mode=bool(settings_raw.get("panicMode", False)),
            ),
            rules=list(data.get("rules", [])),
        )
        self._cache.set("config", cfg)
        return cfg

    # --- Internes ---

    def _auth_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._config.api_token}",
            "Content-Type": "application/json",
        }

    @staticmethod
    def _raise_for_status(resp: httpx.Response) -> None:
        if resp.status_code in (401, 403):
            raise GlassboxAuthError(f"Auth refusée ({resp.status_code}).")
        if resp.status_code == 429:
            raise GlassboxRateLimited("Rate limit dépassé.")
        if resp.status_code >= 400:
            try:
                detail = resp.json()
            except Exception:
                detail = resp.text
            raise GlassboxError(f"HTTP {resp.status_code} : {detail}")
