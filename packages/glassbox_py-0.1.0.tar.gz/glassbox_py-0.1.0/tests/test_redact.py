"""Tests miroir EXACT de src/lib/agents/redact.test.ts (P1).

Toute divergence ici signale une régression de cohérence wire entre SDK et
serveur — risque de corruption silencieuse de la timeline + audit logs.
"""

from glassbox_sdk.redact import redact_secrets


def test_redact_keys_password_token_secret_api_key():
    inp = {
        "command": "echo hi",
        "password": "supersecret",
        "api_key": "sk-abc123",
        "token": "gbx_xxx",
        "secret": "value",
    }
    out = redact_secrets(inp)
    assert out["command"] == "echo hi"
    assert out["password"] == "[REDACTED]"
    assert out["api_key"] == "[REDACTED]"
    assert out["token"] == "[REDACTED]"
    assert out["secret"] == "[REDACTED]"


def test_redact_in_nested_objects():
    inp = {"user": {"name": "alice", "password": "secret"}}
    out = redact_secrets(inp)
    assert out["user"]["name"] == "alice"
    assert out["user"]["password"] == "[REDACTED]"


def test_redact_in_arrays():
    inp = {"items": [{"token": "abc"}, {"ok": True}]}
    out = redact_secrets(inp)
    assert out["items"][0]["token"] == "[REDACTED]"
    assert out["items"][1]["ok"] is True


def test_case_insensitive_keys():
    inp = {"Password": "x", "API_KEY": "y"}
    out = redact_secrets(inp)
    assert out["Password"] == "[REDACTED]"
    assert out["API_KEY"] == "[REDACTED]"


def test_camelcase_and_composite_keys():
    inp = {
        "apiKey": "sk-camel",
        "ApiKey": "sk-pascal",
        "auth_token": "bearer-xxx",
        "Authorization": "Bearer foo",
    }
    out = redact_secrets(inp)
    assert out["apiKey"] == "[REDACTED]"
    assert out["ApiKey"] == "[REDACTED]"
    assert out["auth_token"] == "[REDACTED]"
    assert out["Authorization"] == "[REDACTED]"


def test_NOT_redact_false_positives():
    """Régression de bug critique côté P1 : `lower.includes(s)` matchait trop.

    Ces clés sont métier (verbe / identifiant / URL) et NE doivent PAS être
    redactées — sinon corruption silencieuse de timeline + audit.
    """
    inp = {
        "tokenize": "fn ref",
        "tokenized": True,
        "authorize": "verb",
        "oauthCallbackUrl": "https://example.com/cb",
        "username": "alice",
        "passwordless": False,
    }
    out = redact_secrets(inp)
    assert out["tokenize"] == "fn ref"
    assert out["tokenized"] is True
    assert out["authorize"] == "verb"
    assert out["oauthCallbackUrl"] == "https://example.com/cb"
    assert out["username"] == "alice"
    assert out["passwordless"] is False


def test_no_crash_on_none_or_scalars():
    assert redact_secrets(None) is None
    assert redact_secrets("hello") == "hello"
    assert redact_secrets(42) == 42
    assert redact_secrets(True) is True
