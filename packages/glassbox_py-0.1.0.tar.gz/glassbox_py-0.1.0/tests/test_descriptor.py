"""Tests des modèles Descriptor.

Le Descriptor est ce que l'agent envoie à Glassbox pour décrire une action
(pre-flight ou event timeline). Le wire format doit matcher EXACTEMENT
src/app/api/agents/preflight/route.ts P1 (zod BodySchema).
"""

from glassbox_sdk.descriptor import Descriptor


def test_file_write_builder():
    d = Descriptor.file_write(path="docs/important.md", size=1234)
    assert d.action_type == "file_write"
    payload = d.to_wire()
    assert payload["actionType"] == "file_write"
    assert payload["descriptor"]["path"] == "docs/important.md"
    assert payload["descriptor"]["size"] == 1234


def test_network_read_builder():
    d = Descriptor.network_read(url="https://example.com/api", method="GET")
    payload = d.to_wire()
    assert payload["actionType"] == "network_read"
    assert payload["descriptor"]["url"] == "https://example.com/api"
    assert payload["descriptor"]["method"] == "GET"


def test_payment_builder():
    d = Descriptor.payment(amount=9.50, currency="EUR", provider="stripe")
    payload = d.to_wire()
    assert payload["actionType"] == "payment"
    assert payload["descriptor"]["amount"] == 9.50
    assert payload["descriptor"]["currency"] == "EUR"


def test_message_builder():
    d = Descriptor.external_message(recipient="@user", excerpt="Salut, voici le rapport")
    payload = d.to_wire()
    assert payload["descriptor"]["recipient"] == "@user"
    assert payload["descriptor"]["excerpt"] == "Salut, voici le rapport"


def test_raw_builder_with_metadata():
    d = Descriptor(
        action_type="custom_op",
        descriptor={"foo": "bar"},
        metadata={"session_id": "abc-123", "client_id": "X"},
    )
    payload = d.to_wire()
    assert payload["actionType"] == "custom_op"
    assert payload["metadata"]["session_id"] == "abc-123"


def test_camel_case_conversion():
    """Le SDK accepte snake_case côté Python, émet camelCase côté wire."""
    d = Descriptor.file_write(path="x", size=10)
    payload = d.to_wire(agent_name="Hermes-Terminal", agent_source="hermes-plugin")
    assert payload["agentName"] == "Hermes-Terminal"
    assert payload["agentSource"] == "hermes-plugin"


def test_event_payload_includes_external_id():
    d = Descriptor.file_write(path="x", size=10)
    payload = d.to_event_wire(
        external_id="hermes-evt-1",
        source="hermes-plugin",
        type="tool_use",
        agent_name="Hermes",
        duration_ms=42,
    )
    assert payload["externalId"] == "hermes-evt-1"
    assert payload["durationMs"] == 42
    assert payload["type"] == "tool_use"
