"""Fixtures pytest partagées."""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from glassbox_sdk.config import Config


@pytest.fixture
def config() -> Config:
    return Config(
        api_url="https://glassbox.test",
        api_token="gbx_test_xxxx",
        agent_name="Test-Agent",
        agent_source="test-suite",
        fail_mode="reject",
        cache_ttl_seconds=60,
    )


def make_mock_transport(handler: Any) -> httpx.MockTransport:
    """Helper pour créer un MockTransport HTTPX avec un handler simple."""
    return httpx.MockTransport(handler)
