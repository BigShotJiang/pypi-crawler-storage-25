"""Tests de la décision failsafe quand Glassbox unreachable / SDK error."""

from glassbox_sdk.failsafe import failsafe_decision


def test_reject_mode_blocks_action():
    d = failsafe_decision(reason="connection refused", fail_mode="reject")
    assert d.is_rejected
    assert "Glassbox unreachable" in d.reason


def test_log_only_mode_allows():
    d = failsafe_decision(reason="connection refused", fail_mode="log_only")
    assert d.is_approved
    assert "log_only" in d.reason
