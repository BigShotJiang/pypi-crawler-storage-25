"""Tests du modèle Decision."""

from glassbox_sdk.decision import Decision


def test_status_helpers():
    d = Decision(
        id="abc",
        status="approved",
        matched_rule_id=None,
        decided_by="user-1",
        expires_at=None,
        reason="manual",
    )
    assert d.is_approved
    assert not d.is_rejected
    assert not d.is_pending


def test_auto_approved_is_approved():
    d = Decision(
        id="x",
        status="auto_approved",
        matched_rule_id="rule-1",
        decided_by=None,
        expires_at=None,
        reason="rule",
    )
    assert d.is_approved


def test_auto_rejected_is_rejected():
    d = Decision(
        id="x",
        status="auto_rejected",
        matched_rule_id="rule-1",
        decided_by=None,
        expires_at=None,
        reason="rule",
    )
    assert d.is_rejected


def test_expired_is_rejected():
    d = Decision(
        id="x",
        status="expired",
        matched_rule_id=None,
        decided_by=None,
        expires_at=None,
        reason="timeout",
    )
    assert d.is_rejected


def test_pending_status():
    d = Decision(
        id="x",
        status="pending",
        matched_rule_id=None,
        decided_by=None,
        expires_at=None,
        reason=None,
    )
    assert d.is_pending
    assert not d.is_approved
    assert not d.is_rejected


def test_from_wire():
    """Réponse du serveur Glassbox P1 (camelCase) → modèle Python (snake_case)."""
    wire = {
        "id": "uuid-1",
        "status": "auto_approved",
        "matchedRuleId": "rule-uuid",
        "expiresAt": "2026-05-08T14:35:00Z",
        "reason": "Règle 'auto lecture seule' a matché",
    }
    d = Decision.from_wire(wire)
    assert d.id == "uuid-1"
    assert d.status == "auto_approved"
    assert d.matched_rule_id == "rule-uuid"
    assert d.expires_at == "2026-05-08T14:35:00Z"
    assert d.reason.startswith("Règle")
