"""Tests du loader de config (env vars + TOML)."""

import textwrap
from pathlib import Path

import pytest

from glassbox_sdk.config import Config
from glassbox_sdk.exceptions import GlassboxConfigError


def test_from_env_complete(monkeypatch):
    monkeypatch.setenv("GLASSBOX_API_URL", "https://glassbox.example.com")
    monkeypatch.setenv("GLASSBOX_API_TOKEN", "gbx_test")
    monkeypatch.setenv("GLASSBOX_AGENT_NAME", "Hermes-Terminal")
    cfg = Config.from_env()
    assert cfg.api_url == "https://glassbox.example.com"
    assert cfg.api_token == "gbx_test"
    assert cfg.agent_name == "Hermes-Terminal"
    assert cfg.fail_mode == "reject"  # défaut sécurité


def test_from_env_missing_url(monkeypatch):
    monkeypatch.delenv("GLASSBOX_API_URL", raising=False)
    monkeypatch.setenv("GLASSBOX_API_TOKEN", "gbx_test")
    with pytest.raises(GlassboxConfigError, match="api_url"):
        Config.from_env()


def test_from_env_rejects_http(monkeypatch):
    monkeypatch.setenv("GLASSBOX_API_URL", "http://glassbox.example.com")
    monkeypatch.setenv("GLASSBOX_API_TOKEN", "gbx_test")
    with pytest.raises(GlassboxConfigError, match="https://"):
        Config.from_env()


def test_fail_mode_log_only(monkeypatch):
    monkeypatch.setenv("GLASSBOX_API_URL", "https://x.example.com")
    monkeypatch.setenv("GLASSBOX_API_TOKEN", "gbx_test")
    monkeypatch.setenv("GLASSBOX_FAIL_MODE", "log_only")
    cfg = Config.from_env()
    assert cfg.fail_mode == "log_only"


def test_from_toml_file(tmp_path: Path, monkeypatch):
    monkeypatch.delenv("GLASSBOX_API_URL", raising=False)
    monkeypatch.delenv("GLASSBOX_API_TOKEN", raising=False)
    monkeypatch.setenv("GBX_T", "gbx_secret_xyz")
    f = tmp_path / "config.toml"
    f.write_text(
        textwrap.dedent(
            """
            [glassbox]
            api_url = "https://glassbox.example.com"
            api_token = "${GBX_T}"
            agent_name = "Custom-Agent"
            fail_mode = "reject"
            """
        )
    )
    cfg = Config.from_toml(f)
    assert cfg.api_url == "https://glassbox.example.com"
    assert cfg.api_token == "gbx_secret_xyz"  # env interpolation
    assert cfg.agent_name == "Custom-Agent"


def test_from_env_invalid_fail_mode(monkeypatch):
    monkeypatch.setenv("GLASSBOX_API_URL", "https://x.example.com")
    monkeypatch.setenv("GLASSBOX_API_TOKEN", "gbx_test")
    monkeypatch.setenv("GLASSBOX_FAIL_MODE", "yolo")
    with pytest.raises(GlassboxConfigError, match="fail_mode"):
        Config.from_env()
