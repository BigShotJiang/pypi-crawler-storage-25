"""Tests du cache TTL (rules + settings côté plugin)."""

from glassbox_sdk.cache import TTLCache


def test_set_and_get():
    cache: TTLCache[str] = TTLCache(ttl_seconds=60)
    cache.set("k", "v")
    assert cache.get("k") == "v"


def test_miss_returns_none():
    cache: TTLCache[str] = TTLCache(ttl_seconds=60)
    assert cache.get("nope") is None


def test_expiration(monkeypatch):
    cache: TTLCache[str] = TTLCache(ttl_seconds=10)
    fake_now = [1000.0]

    def now() -> float:
        return fake_now[0]

    monkeypatch.setattr("glassbox_sdk.cache._now", now)
    cache.set("k", "v")
    assert cache.get("k") == "v"
    fake_now[0] = 1011.0  # 11s plus tard, > TTL
    assert cache.get("k") is None


def test_overwrite_resets_ttl(monkeypatch):
    cache: TTLCache[str] = TTLCache(ttl_seconds=10)
    fake_now = [1000.0]
    monkeypatch.setattr("glassbox_sdk.cache._now", lambda: fake_now[0])
    cache.set("k", "v1")
    fake_now[0] = 1009.9
    cache.set("k", "v2")
    fake_now[0] = 1019.0  # < new TTL
    assert cache.get("k") == "v2"


def test_invalidate():
    cache: TTLCache[int] = TTLCache(ttl_seconds=60)
    cache.set("k", 42)
    cache.invalidate("k")
    assert cache.get("k") is None


def test_clear():
    cache: TTLCache[str] = TTLCache(ttl_seconds=60)
    cache.set("a", "1")
    cache.set("b", "2")
    cache.clear()
    assert cache.get("a") is None
    assert cache.get("b") is None
