"""Tests du Client SDK contre un MockTransport HTTPX."""

from __future__ import annotations

import json

import httpx
import pytest

from glassbox_sdk.client import Client
from glassbox_sdk.config import Config
from glassbox_sdk.descriptor import Descriptor
from glassbox_sdk.exceptions import (
    GlassboxAuthError,
    GlassboxRateLimited,
    GlassboxUnreachableError,
)


def make_client(config: Config, handler) -> Client:  # type: ignore[type-arg]
    transport = httpx.MockTransport(handler)
    http = httpx.Client(transport=transport, base_url=config.api_url)
    return Client(config=config, http=http)


def test_post_event_201(config: Config) -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured["url"] = str(req.url)
        captured["headers"] = dict(req.headers)
        captured["body"] = json.loads(req.content)
        return httpx.Response(201, json={"id": "evt-uuid-1"})

    client = make_client(config, handler)
    descriptor = Descriptor.file_write(path="docs/x.md", size=10)
    event_id = client.push_event(
        external_id="ext-1",
        source="test",
        type="tool_use",
        descriptor=descriptor,
    )
    assert event_id == "evt-uuid-1"
    assert str(captured["url"]).endswith("/api/agents/events")
    headers = captured["headers"]
    assert isinstance(headers, dict)
    assert headers["authorization"] == "Bearer gbx_test_xxxx"
    body = captured["body"]
    assert isinstance(body, dict)
    assert body["externalId"] == "ext-1"
    assert body["actionType"] == "file_write"


def test_get_config_200(config: Config) -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            json={
                "version": "abc123",
                "fetchedAt": "2026-05-08T14:00:00Z",
                "settings": {
                    "autonomyDefaultDecision": "require_approval",
                    "preflightTimeoutSeconds": 300,
                    "panicMode": False,
                },
                "rules": [],
            },
        )

    client = make_client(config, handler)
    cfg = client.fetch_config()
    assert cfg.settings.panic_mode is False
    assert cfg.settings.preflight_timeout_seconds == 300
    assert cfg.rules == []
    # Cache hit immédiat → pas de refetch.
    cfg2 = client.fetch_config()
    assert cfg2.version == cfg.version


def test_401_raises_auth_error(config: Config) -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": {"code": "invalid_token"}})

    client = make_client(config, handler)
    with pytest.raises(GlassboxAuthError):
        client.push_event(
            external_id="ext-1",
            source="test",
            type="tool_use",
            descriptor=Descriptor.file_write(path="x", size=1),
        )


def test_429_raises_rate_limited(config: Config) -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(429, json={"error": {"code": "rate_limit_exceeded"}})

    client = make_client(config, handler)
    with pytest.raises(GlassboxRateLimited):
        client.push_event(
            external_id="ext-1",
            source="test",
            type="tool_use",
            descriptor=Descriptor.file_write(path="x", size=1),
        )


def test_unreachable_raises(config: Config) -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("nope")

    client = make_client(config, handler)
    with pytest.raises(GlassboxUnreachableError):
        client.fetch_config()


def test_redact_applied_before_send(config: Config) -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(req.content)
        return httpx.Response(201, json={"id": "x"})

    client = make_client(config, handler)
    descriptor = Descriptor(
        action_type="custom",
        descriptor={"command": "echo hi", "password": "secret123"},
    )
    client.push_event(external_id="e1", source="t", type="x", descriptor=descriptor)
    # Le serveur ne doit jamais voir 'secret123' — la redaction côté SDK le masque.
    body = captured["body"]
    assert isinstance(body, dict)
    assert body["descriptor"]["command"] == "echo hi"
    assert body["descriptor"]["password"] == "[REDACTED]"


def test_preflight_auto_approved(config: Config) -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(
            201,
            json={
                "id": "pf-1",
                "status": "auto_approved",
                "matchedRuleId": "rule-x",
                "expiresAt": "2026-05-08T14:35:00Z",
                "reason": "Règle lecture seule",
            },
        )

    client = make_client(config, handler)
    decision = client.preflight(
        descriptor=Descriptor.network_read(url="https://x.com"),
        client_request_id="req-1",
    )
    assert decision.is_approved
    assert decision.id == "pf-1"
    assert decision.matched_rule_id == "rule-x"


def test_preflight_pending_then_sse_approved(config: Config) -> None:
    """Flow complet pending → SSE wait → status approved."""

    def handler(req: httpx.Request) -> httpx.Response:
        if str(req.url).endswith("/api/agents/preflight"):
            return httpx.Response(
                201,
                json={
                    "id": "pf-42",
                    "status": "pending",
                    "matchedRuleId": None,
                    "expiresAt": "2026-05-08T14:35:00Z",
                    "reason": "Aucune règle ne match",
                },
            )
        # SSE wait
        if "/wait" in str(req.url):
            sse_body = (
                'event: status\ndata: {"id":"pf-42","status":"approved","decidedBy":"user-1"}\n\n'
            )
            return httpx.Response(
                200,
                content=sse_body.encode(),
                headers={"content-type": "text/event-stream"},
            )
        return httpx.Response(404)

    client = make_client(config, handler)
    decision = client.preflight(
        descriptor=Descriptor.shell_command(command="rm -rf /tmp/cache"),
        client_request_id="req-42",
        wait=True,
    )
    assert decision.is_approved
    assert decision.id == "pf-42"
    assert decision.decided_by == "user-1"


def test_preflight_pending_sse_rejected(config: Config) -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        if str(req.url).endswith("/api/agents/preflight"):
            return httpx.Response(
                201,
                json={
                    "id": "pf-7",
                    "status": "pending",
                    "matchedRuleId": None,
                    "expiresAt": "2026-05-08T14:35:00Z",
                    "reason": "",
                },
            )
        sse_body = 'event: status\ndata: {"id":"pf-7","status":"rejected","decidedBy":"user-1"}\n\n'
        return httpx.Response(
            200,
            content=sse_body.encode(),
            headers={"content-type": "text/event-stream"},
        )

    client = make_client(config, handler)
    decision = client.preflight(
        descriptor=Descriptor.shell_command(command="rm -rf /"),
        client_request_id="req-rej",
        wait=True,
    )
    assert decision.is_rejected


def test_preflight_failsafe_on_unreachable(config: Config) -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("network down")

    client = make_client(config, handler)
    decision = client.preflight(
        descriptor=Descriptor.shell_command(command="ls"),
        client_request_id="req-x",
    )
    # fail_mode=reject → décision auto_rejected synthétique.
    assert decision.is_rejected
    assert "unreachable" in (decision.reason or "")


def test_preflight_failsafe_log_only_passes() -> None:
    cfg = Config(
        api_url="https://x.test",
        api_token="t",
        agent_name="A",
        agent_source="t",
        fail_mode="log_only",
    )

    def handler(req: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("network down")

    client = make_client(cfg, handler)
    decision = client.preflight(
        descriptor=Descriptor.shell_command(command="ls"),
        client_request_id="req-x",
    )
    assert decision.is_approved
    assert "log_only" in (decision.reason or "")
