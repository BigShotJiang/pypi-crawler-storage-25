"""Tests for schema support."""
