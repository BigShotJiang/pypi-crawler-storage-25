"""Tests for term factories."""
