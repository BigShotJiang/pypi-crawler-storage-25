"""RDF parser tests."""
