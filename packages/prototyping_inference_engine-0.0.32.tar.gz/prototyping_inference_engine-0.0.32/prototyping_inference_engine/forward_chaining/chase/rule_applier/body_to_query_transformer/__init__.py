"""Forward chaining package."""
