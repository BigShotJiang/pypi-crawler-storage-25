"""
Package: atom evaluators.
"""
