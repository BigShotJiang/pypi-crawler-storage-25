"""
Package: query evaluators.
"""
