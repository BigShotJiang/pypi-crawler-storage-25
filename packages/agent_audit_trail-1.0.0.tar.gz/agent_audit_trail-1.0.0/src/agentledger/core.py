"""Core SDK — the one-line initialization interface."""

from __future__ import annotations

from typing import Any, Optional

from agentledger.models import ActionType, LogEntry
from agentledger.storage.sqlite_backend import SQLiteBackend

_ledger: Optional[_Ledger] = None


class _Ledger:
    def __init__(self, agent_id: str, db_path: str = "agentledger.db"):
        self.agent_id = agent_id
        self.storage = SQLiteBackend(db_path)

    def log(
        self,
        action_type: ActionType,
        input: Any = None,
        output: Any = None,
        reasoning: Optional[str] = None,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        tokens_in: Optional[int] = None,
        tokens_out: Optional[int] = None,
        latency_ms: Optional[float] = None,
        correlation_id: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> LogEntry:
        entry = LogEntry(
            agent_id=self.agent_id,
            action_type=action_type,
            input=input,
            output=output,
            reasoning=reasoning,
            model=model,
            provider=provider,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
            correlation_id=correlation_id,
            metadata=metadata or {},
        )
        prev_hash = self.storage.get_latest_hash()
        entry.seal(prev_hash)
        self.storage.append(entry)
        return entry


def init(agent_id: str = "default", db_path: str = "agentledger.db") -> _Ledger:
    """Initialize AgentLedger. Call once at startup."""
    global _ledger
    _ledger = _Ledger(agent_id=agent_id, db_path=db_path)
    return _ledger


def get_ledger() -> _Ledger:
    """Get the initialized ledger instance."""
    if _ledger is None:
        raise RuntimeError("AgentLedger not initialized. Call agentledger.init() first.")
    return _ledger


def log_event(
    action_type: str,
    input: Any = None,
    output: Any = None,
    **kwargs,
) -> LogEntry:
    """Log an event to the ledger. Convenience wrapper."""
    ledger = get_ledger()
    return ledger.log(
        action_type=ActionType(action_type),
        input=input,
        output=output,
        **kwargs,
    )
