"""AgentLedger — Tamper-proof compliance audit trail for AI agents."""

__version__ = "1.0.0"

from agentledger.core import init, log_event, get_ledger

__all__ = ["init", "log_event", "get_ledger", "__version__"]
