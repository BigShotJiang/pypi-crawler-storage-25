"""FastAPI query API for AgentLedger."""

from __future__ import annotations

from typing import Optional

from fastapi import FastAPI, Query
from pydantic import BaseModel

from agentledger.storage.sqlite_backend import SQLiteBackend

app = FastAPI(title="AgentLedger API", version="1.0.0")

_storage: Optional[SQLiteBackend] = None


def get_storage() -> SQLiteBackend:
    global _storage
    if _storage is None:
        _storage = SQLiteBackend()
    return _storage


class ChainStatus(BaseModel):
    valid: bool
    broken_at: Optional[str] = None
    entries_checked: int


@app.get("/logs")
def query_logs(
    agent_id: Optional[str] = Query(None),
    correlation_id: Optional[str] = Query(None),
    action_type: Optional[str] = Query(None),
    since: Optional[str] = Query(None),
    until: Optional[str] = Query(None),
    limit: int = Query(100, le=1000),
    offset: int = Query(0, ge=0),
):
    storage = get_storage()
    entries = storage.query(
        agent_id=agent_id,
        correlation_id=correlation_id,
        action_type=action_type,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
    )
    return {"entries": [e.model_dump() for e in entries], "count": len(entries)}


@app.get("/logs/{entry_id}")
def get_entry(entry_id: str):
    storage = get_storage()
    entries = storage.query(limit=10000)
    for e in entries:
        if e.id == entry_id:
            return e.model_dump()
    from fastapi import HTTPException
    raise HTTPException(status_code=404, detail="Entry not found")


@app.get("/stats")
def get_stats():
    storage = get_storage()
    total = storage.count()
    return {"total_entries": total}


@app.get("/verify")
def verify_chain(limit: int = Query(1000, le=100000)):
    storage = get_storage()
    valid, broken_id = storage.verify_chain(limit=limit)
    return ChainStatus(
        valid=valid,
        broken_at=broken_id,
        entries_checked=min(limit, storage.count()),
    )


@app.post("/export")
def export_logs(
    agent_id: Optional[str] = Query(None),
    correlation_id: Optional[str] = Query(None),
    since: Optional[str] = Query(None),
    until: Optional[str] = Query(None),
    format: str = Query("json", pattern="^(json|csv)$"),
):
    """Export logs as JSON or CSV."""
    from fastapi.responses import PlainTextResponse
    import csv
    import io

    storage = get_storage()
    entries = storage.query(
        agent_id=agent_id,
        correlation_id=correlation_id,
        since=since,
        until=until,
        limit=10000,
    )

    if format == "csv":
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["id", "timestamp", "agent_id", "action_type", "correlation_id",
                         "model", "provider", "tokens_in", "tokens_out", "latency_ms",
                         "input", "output"])
        for e in entries:
            writer.writerow([e.id, e.timestamp, e.agent_id, e.action_type.value,
                             e.correlation_id, e.model, e.provider, e.tokens_in,
                             e.tokens_out, e.latency_ms, str(e.input)[:200], str(e.output)[:200]])
        return PlainTextResponse(content=output.getvalue(), media_type="text/csv")

    return {"entries": [e.model_dump(mode="json") for e in entries], "count": len(entries)}


@app.get("/reports/{template}")
def generate_report(
    template: str,
    agent_id: Optional[str] = Query(None),
):
    """Generate a compliance report. Templates: eu-ai-act, soc2, audit."""
    from fastapi.responses import PlainTextResponse
    from agentledger.reports import eu_ai_act, soc2

    storage = get_storage()

    if template == "eu-ai-act":
        report = eu_ai_act.generate_report(storage, agent_id)
    elif template == "soc2":
        report = soc2.generate_report(storage, agent_id)
    elif template == "audit":
        # Basic audit report
        entries = storage.query(agent_id=agent_id, limit=10000)
        lines = [
            "# Audit Report",
            "",
            f"**Total entries:** {len(entries)}",
            "",
            "## Actions Log",
            "",
            "| Timestamp | Agent | Action | Model | Input (truncated) |",
            "|-----------|-------|--------|-------|-------------------|",
        ]
        for e in entries[:100]:
            lines.append(f"| {e.timestamp} | {e.agent_id} | {e.action_type.value} | {e.model or '-'} | {str(e.input)[:50]} |")
        if len(entries) > 100:
            lines.append(f"\n*... and {len(entries) - 100} more entries*")
        report = "\n".join(lines)
    else:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Unknown template: {template}. Available: eu-ai-act, soc2, audit")

    return PlainTextResponse(content=report, media_type="text/markdown")


@app.get("/health")
def health():
    from agentledger import __version__
    return {"status": "ok", "version": __version__}
