"""Auto-capture adapter for the Anthropic Python SDK."""

from __future__ import annotations

import time
from typing import Any

from agentledger.models import ActionType


def patch_anthropic():
    """Monkey-patch anthropic.Anthropic.messages.create to auto-log calls."""
    try:
        import anthropic
    except ImportError:
        return  # anthropic not installed, skip

    from agentledger.core import get_ledger

    _original_create = anthropic.resources.messages.Messages.create

    def _logged_create(self, *args, **kwargs) -> Any:
        ledger = get_ledger()
        start = time.perf_counter()

        try:
            response = _original_create(self, *args, **kwargs)
        except Exception as exc:
            elapsed = (time.perf_counter() - start) * 1000
            ledger.log(
                action_type=ActionType.ERROR,
                input={"model": kwargs.get("model"), "messages": str(kwargs.get("messages", ""))[:500]},
                output=str(exc)[:500],
                model=kwargs.get("model"),
                provider="anthropic",
                latency_ms=elapsed,
            )
            raise

        elapsed = (time.perf_counter() - start) * 1000

        # Extract usage
        usage = getattr(response, "usage", None)
        tokens_in = getattr(usage, "input_tokens", None) if usage else None
        tokens_out = getattr(usage, "output_tokens", None) if usage else None

        # Extract tool use
        has_tool_use = any(
            getattr(block, "type", "") == "tool_use"
            for block in getattr(response, "content", [])
        )

        action = ActionType.TOOL_USE if has_tool_use else ActionType.LLM_CALL

        ledger.log(
            action_type=action,
            input={"model": kwargs.get("model"), "messages": str(kwargs.get("messages", ""))[:500]},
            output=str(getattr(response, "content", ""))[:500],
            model=kwargs.get("model") or getattr(response, "model", None),
            provider="anthropic",
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=elapsed,
        )

        return response

    anthropic.resources.messages.Messages.create = _logged_create
