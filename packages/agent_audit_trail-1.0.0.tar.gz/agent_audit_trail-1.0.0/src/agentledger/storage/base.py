"""Abstract storage backend."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from agentledger.models import LogEntry


class StorageBackend(ABC):
    @abstractmethod
    def append(self, entry: LogEntry) -> None:
        """Append a sealed log entry."""

    @abstractmethod
    def get_latest_hash(self) -> str:
        """Return the hash of the most recent entry, or empty string if none."""

    @abstractmethod
    def query(
        self,
        agent_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        action_type: Optional[str] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[LogEntry]:
        """Query log entries with filters."""

    @abstractmethod
    def count(self, **filters) -> int:
        """Count entries matching filters."""

    @abstractmethod
    def verify_chain(self, limit: int = 1000) -> tuple[bool, Optional[str]]:
        """Verify hash chain integrity. Returns (valid, first_broken_id)."""
