"""SQLite storage backend with append-only semantics and hash chain."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Optional

from agentledger.models import ActionType, LogEntry


_SCHEMA = """
CREATE TABLE IF NOT EXISTS log_entries (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    action_type TEXT NOT NULL,
    correlation_id TEXT,
    input TEXT,
    output TEXT,
    reasoning TEXT,
    model TEXT,
    provider TEXT,
    tokens_in INTEGER,
    tokens_out INTEGER,
    latency_ms REAL,
    metadata TEXT,
    prev_hash TEXT,
    entry_hash TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_agent_id ON log_entries(agent_id);
CREATE INDEX IF NOT EXISTS idx_correlation_id ON log_entries(correlation_id);
CREATE INDEX IF NOT EXISTS idx_timestamp ON log_entries(timestamp);
CREATE INDEX IF NOT EXISTS idx_action_type ON log_entries(action_type);
"""


class SQLiteBackend:
    def __init__(self, db_path: str = "agentledger.db"):
        self.db_path = Path(db_path)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def append(self, entry: LogEntry) -> None:
        self._conn.execute(
            """INSERT INTO log_entries
            (id, timestamp, agent_id, action_type, correlation_id,
             input, output, reasoning, model, provider,
             tokens_in, tokens_out, latency_ms, metadata,
             prev_hash, entry_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                entry.id,
                entry.timestamp.isoformat(),
                entry.agent_id,
                entry.action_type.value,
                entry.correlation_id,
                json.dumps(entry.input) if entry.input is not None else None,
                json.dumps(entry.output) if entry.output is not None else None,
                entry.reasoning,
                entry.model,
                entry.provider,
                entry.tokens_in,
                entry.tokens_out,
                entry.latency_ms,
                json.dumps(entry.metadata),
                entry.prev_hash,
                entry.entry_hash,
            ),
        )
        self._conn.commit()

    def get_latest_hash(self) -> str:
        row = self._conn.execute(
            "SELECT entry_hash FROM log_entries ORDER BY timestamp DESC LIMIT 1"
        ).fetchone()
        return row[0] if row else ""

    def query(
        self,
        agent_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        action_type: Optional[str] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[LogEntry]:
        conditions = []
        params: list = []

        if agent_id:
            conditions.append("agent_id = ?")
            params.append(agent_id)
        if correlation_id:
            conditions.append("correlation_id = ?")
            params.append(correlation_id)
        if action_type:
            conditions.append("action_type = ?")
            params.append(action_type)
        if since:
            conditions.append("timestamp >= ?")
            params.append(since)
        if until:
            conditions.append("timestamp <= ?")
            params.append(until)

        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        sql = f"SELECT * FROM log_entries {where} ORDER BY timestamp ASC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_entry(r) for r in rows]

    def count(self, **filters) -> int:
        conditions = []
        params: list = []
        for key, val in filters.items():
            if val is not None:
                conditions.append(f"{key} = ?")
                params.append(val)
        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        row = self._conn.execute(f"SELECT COUNT(*) FROM log_entries {where}", params).fetchone()
        return row[0]

    def verify_chain(self, limit: int = 1000) -> tuple[bool, Optional[str]]:
        rows = self._conn.execute(
            "SELECT * FROM log_entries ORDER BY timestamp ASC LIMIT ?", (limit,)
        ).fetchall()

        prev_hash = ""
        for row in rows:
            entry = self._row_to_entry(row)
            expected = entry.compute_hash(prev_hash)
            if entry.entry_hash != expected:
                return False, entry.id
            prev_hash = entry.entry_hash
        return True, None

    def _row_to_entry(self, row) -> LogEntry:
        return LogEntry(
            id=row[0],
            timestamp=row[1],
            agent_id=row[2],
            action_type=ActionType(row[3]),
            correlation_id=row[4],
            input=json.loads(row[5]) if row[5] else None,
            output=json.loads(row[6]) if row[6] else None,
            reasoning=row[7],
            model=row[8],
            provider=row[9],
            tokens_in=row[10],
            tokens_out=row[11],
            latency_ms=row[12],
            metadata=json.loads(row[13]) if row[13] else {},
            prev_hash=row[14],
            entry_hash=row[15],
        )
