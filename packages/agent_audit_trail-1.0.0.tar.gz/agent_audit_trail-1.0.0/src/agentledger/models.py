"""Core data models for AgentLedger."""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class ActionType(str, Enum):
    LLM_CALL = "llm_call"
    TOOL_USE = "tool_use"
    DECISION = "decision"
    OUTCOME = "outcome"
    ERROR = "error"
    HUMAN_APPROVAL = "human_approval"


class LogEntry(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    agent_id: str
    action_type: ActionType
    correlation_id: Optional[str] = None

    # What happened
    input: Any = None
    output: Any = None
    reasoning: Optional[str] = None

    # Context
    model: Optional[str] = None
    provider: Optional[str] = None
    tokens_in: Optional[int] = None
    tokens_out: Optional[int] = None
    latency_ms: Optional[float] = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    # Tamper detection
    prev_hash: Optional[str] = None
    entry_hash: Optional[str] = None

    def compute_hash(self, prev_hash: str = "") -> str:
        """Compute hash for this entry based on content + previous hash."""
        payload = json.dumps(
            {
                "id": self.id,
                "timestamp": self.timestamp.isoformat(),
                "agent_id": self.agent_id,
                "action_type": self.action_type.value,
                "input": str(self.input),
                "output": str(self.output),
                "prev_hash": prev_hash,
            },
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode()).hexdigest()

    def seal(self, prev_hash: str = "") -> LogEntry:
        """Set prev_hash and compute entry_hash. Returns self for chaining."""
        self.prev_hash = prev_hash
        self.entry_hash = self.compute_hash(prev_hash)
        return self
