"""CLI for AgentLedger — query logs, generate reports, verify chain."""

from __future__ import annotations

import argparse
import json
import sys

from agentledger.storage.sqlite_backend import SQLiteBackend
from agentledger.reports import eu_ai_act, soc2


def main():
    parser = argparse.ArgumentParser(description="AgentLedger CLI")
    parser.add_argument("--db", default="agentledger.db", help="Database path")
    sub = parser.add_subparsers(dest="command")

    # query
    q = sub.add_parser("query", help="Query log entries")
    q.add_argument("--agent-id", help="Filter by agent ID")
    q.add_argument("--correlation-id", help="Filter by correlation ID")
    q.add_argument("--action-type", help="Filter by action type")
    q.add_argument("--since", help="Start time (ISO format)")
    q.add_argument("--until", help="End time (ISO format)")
    q.add_argument("--limit", type=int, default=50)
    q.add_argument("--format", choices=["json", "table"], default="table")

    # verify
    sub.add_parser("verify", help="Verify hash chain integrity")

    # report
    r = sub.add_parser("report", help="Generate compliance report")
    r.add_argument("template", choices=["eu-ai-act", "soc2"])
    r.add_argument("--agent-id", help="Filter by agent ID")
    r.add_argument("--output", "-o", help="Output file (default: stdout)")

    # stats
    sub.add_parser("stats", help="Show log statistics")

    # serve
    s = sub.add_parser("serve", help="Start the query API server")
    s.add_argument("--host", default="0.0.0.0")
    s.add_argument("--port", type=int, default=8100)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return

    storage = SQLiteBackend(args.db)

    if args.command == "query":
        entries = storage.query(
            agent_id=args.agent_id,
            correlation_id=args.correlation_id,
            action_type=args.action_type,
            since=args.since,
            until=args.until,
            limit=args.limit,
        )
        if args.format == "json":
            print(json.dumps([e.model_dump(mode="json") for e in entries], indent=2))
        else:
            for e in entries:
                print(f"[{e.timestamp}] {e.agent_id} | {e.action_type.value} | {str(e.input)[:60]}")

    elif args.command == "verify":
        valid, broken_id = storage.verify_chain()
        if valid:
            print("Hash chain integrity: VERIFIED")
        else:
            print(f"Hash chain BROKEN at entry: {broken_id}")
            sys.exit(1)

    elif args.command == "report":
        generators = {"eu-ai-act": eu_ai_act, "soc2": soc2}
        report = generators[args.template].generate_report(storage, args.agent_id)
        if args.output:
            with open(args.output, "w") as f:
                f.write(report)
            print(f"Report written to {args.output}")
        else:
            print(report)

    elif args.command == "stats":
        total = storage.count()
        print(f"Total entries: {total}")
        valid, _ = storage.verify_chain()
        print(f"Chain integrity: {'VERIFIED' if valid else 'BROKEN'}")

    elif args.command == "serve":
        import uvicorn
        from agentledger.api.app import app
        uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
