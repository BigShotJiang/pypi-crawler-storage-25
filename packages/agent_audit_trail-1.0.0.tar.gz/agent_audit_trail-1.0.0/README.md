# AgentLedger

**Tamper-proof compliance audit trail for AI agents.**

[![PyPI](https://img.shields.io/pypi/v/agentledger?color=blue&logo=pypi&logoColor=white)](https://pypi.org/project/agent-audit-trail/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green)](LICENSE)

One-line SDK integration. SHA-256 hash-chained logs. Pre-built compliance reports for **EU AI Act Article 12** and **SOC 2 Type II**. The EU AI Act high-risk system rules take effect **August 2, 2026**.

## Quick Start

```python
import agentledger

# Initialize (one line)
ledger = agentledger.init(agent_id="my-agent")

# Log an AI action
agentledger.log_event(
    action_type="llm_call",
    input="What is the capital of France?",
    output="The capital of France is Paris.",
    model="claude-sonnet-4-20250514",
    provider="anthropic",
    tokens_in=12,
    tokens_out=8,
    latency_ms=340,
)
```

That's it. Every action is hash-chained and tamper-detectable.

## Features

- **Tamper-proof** — SHA-256 hash chain links every log entry to the previous one. If any entry is modified, the chain breaks.
- **EU AI Act Article 12** — Pre-built compliance report covering logging capability, traceability, integrity, and retention requirements.
- **SOC 2 Type II** — Evidence report for CC6.1, CC7.2, CC7.3, and CC8.1 trust service criteria.
- **One-line SDK** — `agentledger.init()` and you're logging. No configuration files, no infrastructure.
- **Local-first** — SQLite storage with WAL mode. No cloud dependency. Your data stays on your machine.
- **REST API** — FastAPI server for querying logs, exporting (JSON/CSV), and generating reports.
- **CLI** — Query, verify, generate reports, and serve the API from the command line.
- **Auto-capture** — Anthropic SDK adapter for automatic logging of all API calls.

## Installation

```bash
pip install agent-audit-trail
```

## CLI Usage

```bash
# Query recent logs
agentledger query --agent-id my-agent --limit 20

# Verify hash chain integrity
agentledger verify

# Generate EU AI Act compliance report
agentledger report eu-ai-act --output report.md

# Generate SOC 2 evidence report
agentledger report soc2

# Show statistics
agentledger stats

# Start the API server
agentledger serve --port 8100
```

## REST API

Start the server with `agentledger serve`, then:

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/logs` | Query log entries (filters: agent_id, action_type, since, until) |
| `GET` | `/logs/{id}` | Get a single entry |
| `GET` | `/stats` | Log statistics |
| `GET` | `/verify` | Verify hash chain integrity |
| `POST` | `/export` | Export logs as JSON or CSV |
| `GET` | `/reports/eu-ai-act` | EU AI Act Article 12 compliance report |
| `GET` | `/reports/soc2` | SOC 2 Type II evidence report |
| `GET` | `/reports/audit` | Basic audit trail report |
| `GET` | `/health` | Health check |

## Architecture

```
┌─────────────────────────────┐
│  Your AI Agent Code         │
│                             │
│  import agentledger         │
│  agentledger.init(...)      │
│  agentledger.log_event(...) │
└──────────┬──────────────────┘
           │ SDK appends entries
           ▼
┌──────────────────────────────┐
│  Append-Only Storage         │
│  SQLite + WAL mode           │
│  SHA-256 hash chain          │
└──────────┬───────────────────┘
           │
     ┌─────┴─────┐
     ▼           ▼
┌─────────┐ ┌──────────┐
│  CLI    │ │  FastAPI  │
│  query  │ │  /logs    │
│  verify │ │  /verify  │
│  report │ │  /reports │
└─────────┘ └──────────┘
```

## Action Types

| Type | Description |
|------|-------------|
| `llm_call` | LLM API calls (input, output, model, tokens) |
| `tool_use` | Tool/function invocations |
| `decision` | Agent decisions with reasoning |
| `outcome` | Final outcomes and results |
| `error` | Error events |
| `human_approval` | Human-in-the-loop approvals |

## Anthropic Auto-Capture

```python
from agentledger.adapters.anthropic_adapter import patch_anthropic

# Automatically logs all Anthropic API calls
patch_anthropic(agent_id="my-agent")
```

## Why AgentLedger?

| Feature | AgentLedger | LangSmith | Braintrust | Helicone |
|---------|------------|-----------|------------|----------|
| Tamper detection | SHA-256 chain | No | No | No |
| EU AI Act reports | Built-in | No | No | No |
| SOC 2 reports | Built-in | No | No | No |
| Local-first | SQLite | Cloud only | Cloud only | Proxy |
| Framework-agnostic | Yes | LangChain | Eval-focused | Proxy |
| Open source | MIT | Partial | Partial | Partial |

## License

MIT
