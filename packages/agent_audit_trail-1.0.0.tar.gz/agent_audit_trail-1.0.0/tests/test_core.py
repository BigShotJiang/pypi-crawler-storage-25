"""Tests for AgentLedger core SDK."""

import os
import tempfile

import agentledger
from agentledger.models import ActionType
from agentledger.reports import eu_ai_act, soc2


def test_init_and_log():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        ledger = agentledger.init(agent_id="test-agent", db_path=db_path)

        entry = ledger.log(
            action_type=ActionType.LLM_CALL,
            input={"prompt": "Hello"},
            output={"text": "Hi there"},
            model="claude-sonnet-4-20250514",
            provider="anthropic",
            tokens_in=10,
            tokens_out=5,
            latency_ms=150.0,
        )

        assert entry.entry_hash is not None
        assert entry.prev_hash == ""
        assert entry.agent_id == "test-agent"

        # Second entry should chain
        entry2 = ledger.log(
            action_type=ActionType.TOOL_USE,
            input={"tool": "search"},
            output={"results": []},
        )
        assert entry2.prev_hash == entry.entry_hash

    finally:
        os.unlink(db_path)


def test_query_and_verify():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        ledger = agentledger.init(agent_id="test-agent", db_path=db_path)

        for i in range(5):
            ledger.log(
                action_type=ActionType.LLM_CALL,
                input={"prompt": f"Message {i}"},
                output={"text": f"Response {i}"},
                correlation_id="chain-1",
            )

        # Query
        entries = ledger.storage.query(agent_id="test-agent")
        assert len(entries) == 5

        entries = ledger.storage.query(correlation_id="chain-1")
        assert len(entries) == 5

        # Verify chain
        valid, broken = ledger.storage.verify_chain()
        assert valid is True
        assert broken is None

    finally:
        os.unlink(db_path)


def test_eu_ai_act_report():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        ledger = agentledger.init(agent_id="compliance-test", db_path=db_path)
        ledger.log(action_type=ActionType.LLM_CALL, input="test", output="response", model="claude-sonnet-4-20250514")

        report = eu_ai_act.generate_report(ledger.storage, "compliance-test")
        assert "Article 12" in report
        assert "PASSED" in report
        assert "compliance-test" in report

    finally:
        os.unlink(db_path)


def test_soc2_report():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        ledger = agentledger.init(agent_id="soc2-test", db_path=db_path)
        ledger.log(action_type=ActionType.DECISION, input="test", output="approved")

        report = soc2.generate_report(ledger.storage, "soc2-test")
        assert "SOC 2" in report
        assert "VERIFIED" in report

    finally:
        os.unlink(db_path)
