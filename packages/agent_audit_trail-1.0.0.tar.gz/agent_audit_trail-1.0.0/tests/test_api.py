"""Tests for the AgentLedger FastAPI endpoints."""

import os
import tempfile

import pytest
from fastapi.testclient import TestClient

import agentledger
from agentledger.api.app import app, get_storage, _storage
from agentledger.models import ActionType
from agentledger.storage.sqlite_backend import SQLiteBackend


@pytest.fixture
def db_path():
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        path = f.name
    yield path
    os.unlink(path)


@pytest.fixture
def seeded_client(db_path):
    """Client with pre-seeded log entries."""
    import agentledger.api.app as api_mod

    storage = SQLiteBackend(db_path)
    api_mod._storage = storage

    ledger = agentledger.init(agent_id="api-test", db_path=db_path)
    for i in range(3):
        ledger.log(
            action_type=ActionType.LLM_CALL,
            input=f"prompt {i}",
            output=f"response {i}",
            model="gpt-4o",
            provider="openai",
            tokens_in=10,
            tokens_out=5,
            latency_ms=100.0,
            correlation_id="workflow-1",
        )
    ledger.log(
        action_type=ActionType.DECISION,
        input="should we proceed?",
        output="yes",
        reasoning="all checks passed",
    )

    client = TestClient(app)
    yield client
    api_mod._storage = None


class TestHealthEndpoint:
    def test_health(self, seeded_client):
        resp = seeded_client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["version"] == "1.0.0"


class TestLogsEndpoint:
    def test_list_logs(self, seeded_client):
        resp = seeded_client.get("/logs")
        assert resp.status_code == 200
        data = resp.json()
        assert data["count"] == 4

    def test_filter_by_agent(self, seeded_client):
        resp = seeded_client.get("/logs?agent_id=api-test")
        assert resp.status_code == 200
        assert resp.json()["count"] == 4

    def test_filter_by_action_type(self, seeded_client):
        resp = seeded_client.get("/logs?action_type=decision")
        assert resp.status_code == 200
        assert resp.json()["count"] == 1

    def test_filter_by_correlation(self, seeded_client):
        resp = seeded_client.get("/logs?correlation_id=workflow-1")
        assert resp.status_code == 200
        assert resp.json()["count"] == 3

    def test_pagination(self, seeded_client):
        resp = seeded_client.get("/logs?limit=2&offset=0")
        assert resp.json()["count"] == 2

    def test_get_single_entry(self, seeded_client):
        logs = seeded_client.get("/logs?limit=1").json()
        entry_id = logs["entries"][0]["id"]
        resp = seeded_client.get(f"/logs/{entry_id}")
        assert resp.status_code == 200
        assert resp.json()["id"] == entry_id

    def test_get_missing_entry(self, seeded_client):
        resp = seeded_client.get("/logs/nonexistent-id")
        assert resp.status_code == 404


class TestStatsEndpoint:
    def test_stats(self, seeded_client):
        resp = seeded_client.get("/stats")
        assert resp.status_code == 200
        assert resp.json()["total_entries"] == 4


class TestVerifyEndpoint:
    def test_verify_valid_chain(self, seeded_client):
        resp = seeded_client.get("/verify")
        assert resp.status_code == 200
        data = resp.json()
        assert data["valid"] is True
        assert data["broken_at"] is None


class TestExportEndpoint:
    def test_export_json(self, seeded_client):
        resp = seeded_client.post("/export?format=json")
        assert resp.status_code == 200
        data = resp.json()
        assert "entries" in data
        assert data["count"] == 4

    def test_export_csv(self, seeded_client):
        resp = seeded_client.post("/export?format=csv")
        assert resp.status_code == 200
        assert "text/csv" in resp.headers["content-type"]
        lines = resp.text.strip().split("\n")
        assert len(lines) == 5  # header + 4 entries


class TestReportsEndpoint:
    def test_eu_ai_act_report(self, seeded_client):
        resp = seeded_client.get("/reports/eu-ai-act")
        assert resp.status_code == 200
        assert "Article 12" in resp.text

    def test_soc2_report(self, seeded_client):
        resp = seeded_client.get("/reports/soc2")
        assert resp.status_code == 200
        assert "SOC 2" in resp.text

    def test_audit_report(self, seeded_client):
        resp = seeded_client.get("/reports/audit")
        assert resp.status_code == 200
        assert "Audit Report" in resp.text

    def test_unknown_template(self, seeded_client):
        resp = seeded_client.get("/reports/unknown")
        assert resp.status_code == 404
