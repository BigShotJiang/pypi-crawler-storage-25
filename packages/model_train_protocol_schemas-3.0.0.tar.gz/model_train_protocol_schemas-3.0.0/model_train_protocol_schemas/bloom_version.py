BLOOM_VERSION: str = "1.2.1"
