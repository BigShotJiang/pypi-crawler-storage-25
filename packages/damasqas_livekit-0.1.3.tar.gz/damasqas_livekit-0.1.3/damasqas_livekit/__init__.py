"""
Damasqas Voice AI Infrastructure Monitoring.

Usage:
    import damasqas_livekit
    damasqas_livekit.monitor(session)

That's it. Set DAMASQAS_TOKEN as an env var.
"""

import os
import logging
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from livekit.agents import AgentSession

from damasqas_livekit._collector import EventCollector
from damasqas_livekit._transport import get_or_create_transport
from damasqas_livekit._version import __version__

__all__ = ["monitor", "__version__"]

logger = logging.getLogger("damasqas_livekit")

_active_collectors: dict[int, EventCollector] = {}


def monitor(
    session: "AgentSession",
    *,
    token: Optional[str] = None,
    url: Optional[str] = None,
) -> None:
    """
    Attach Damasqas monitoring to a LiveKit AgentSession.

    Call this AFTER session.start(). Captures every event the session
    emits and forwards it to the Damasqas ingestion API.

    Args:
        session: A started LiveKit AgentSession.
        token: Damasqas API token. Default: reads DAMASQAS_TOKEN env var.
        url: Damasqas ingestion URL. Default: reads DAMASQAS_URL env var,
             falls back to https://connect.damasqas.com/api/v1/voice/ingest

    Environment Variables:
        DAMASQAS_TOKEN: Required. Your workspace API key.
        DAMASQAS_URL: Optional. Override the ingestion endpoint.
    """
    resolved_token = token or os.environ.get("DAMASQAS_TOKEN")
    if not resolved_token:
        logger.warning(
            "damasqas_livekit.monitor(): DAMASQAS_TOKEN not set. "
            "Monitoring disabled. Set the env var and redeploy."
        )
        return

    resolved_url = (
        url
        or os.environ.get("DAMASQAS_URL")
        or "https://connect.damasqas.com/api/v1/voice/ingest"
    )

    # Extract workspace ID from token: dq_<workspace>_<secret>
    workspace_id = _extract_workspace(resolved_token)

    transport = get_or_create_transport(
        url=resolved_url,
        token=resolved_token,
    )

    collector = EventCollector(
        session=session,
        transport=transport,
        workspace_id=workspace_id,
    )
    collector.attach()

    # Track active collectors for cleanup
    _active_collectors[id(session)] = collector

    logger.info(
        "damasqas_livekit: monitoring attached (workspace=%s, url=%s)",
        workspace_id or "from-token",
        resolved_url,
    )


def _extract_workspace(token: str) -> Optional[str]:
    """Extract workspace ID from token format dq_<workspace>_<secret>."""
    if token.startswith("dq_"):
        parts = token.split("_", 2)
        if len(parts) >= 3:
            return parts[1]
    return None


