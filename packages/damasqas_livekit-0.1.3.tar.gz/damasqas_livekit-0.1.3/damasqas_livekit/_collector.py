"""
Collects all events from a LiveKit AgentSession and batches them
for transport to the Damasqas ingestion API.

Supports both legacy (metrics_collected) and modern (session_usage_updated /
ChatMessage.metrics) LiveKit event APIs.
"""

import asyncio
import inspect
import time
import logging
from typing import Optional, Any
from dataclasses import dataclass, field

from damasqas_livekit._transport import MetricsTransport

logger = logging.getLogger("damasqas_livekit")


@dataclass
class TurnMetrics:
    """Accumulates all metrics for a single speech turn (grouped by speech_id)."""

    speech_id: str
    started_at: float = 0.0

    # STT
    stt_provider: Optional[str] = None
    stt_duration_ms: Optional[int] = None
    stt_audio_duration_ms: Optional[int] = None
    stt_error: Optional[str] = None

    # LLM
    llm_provider: Optional[str] = None
    llm_model: Optional[str] = None
    llm_ttft_ms: Optional[int] = None
    llm_total_duration_ms: Optional[int] = None
    llm_input_tokens: Optional[int] = None
    llm_output_tokens: Optional[int] = None
    llm_cached_tokens: Optional[int] = None
    llm_tokens_per_second: Optional[float] = None
    llm_cancelled: bool = False
    llm_error: Optional[str] = None

    # TTS
    tts_provider: Optional[str] = None
    tts_ttfb_ms: Optional[int] = None
    tts_duration_ms: Optional[int] = None
    tts_audio_duration_ms: Optional[int] = None
    tts_characters: Optional[int] = None
    tts_cancelled: bool = False
    tts_error: Optional[str] = None

    # VAD
    vad_speech_duration_ms: Optional[int] = None
    vad_silence_duration_ms: Optional[int] = None

    # EOU
    eou_latency_ms: Optional[int] = None

    # Interruption
    interruption_occurred: bool = False
    interruption_overlap_ms: Optional[int] = None

    # Tool calls
    tool_calls: list = field(default_factory=list)

    # Computed
    e2e_latency_ms: Optional[int] = None

    def compute_e2e(self) -> None:
        parts = [self.stt_duration_ms, self.llm_ttft_ms, self.tts_ttfb_ms]
        if all(p is not None for p in parts):
            self.e2e_latency_ms = sum(parts)  # type: ignore[arg-type]


def _s_to_ms(val: Any) -> Optional[int]:
    if val is None:
        return None
    return int(val * 1000)


class EventCollector:
    """
    Attaches to all AgentSession events and collects telemetry.

    LiveKit 1.5.x EventTypes (from livekit/agents/voice/events.py):
      user_state_changed, agent_state_changed, user_input_transcribed,
      conversation_item_added, agent_false_interruption, overlapping_speech,
      function_tools_executed, metrics_collected (deprecated),
      session_usage_updated, speech_created, error, close
    """

    def __init__(
        self,
        session: Any,
        transport: MetricsTransport,
        workspace_id: Optional[str],
    ):
        self._session = session
        self._transport = transport
        self._workspace_id = workspace_id
        self._room_sid: Optional[str] = None
        self._room_name: Optional[str] = None
        self._room_resolved = False
        self._turns: dict[str, TurnMetrics] = {}
        self._turn_index = 0
        self._session_start = time.time()
        self._flush_task: Optional[asyncio.Task] = None
        self._handler_count = 0
        self._pending_tasks: set[asyncio.Task] = set()

    def _spawn(self, coro) -> None:
        task = asyncio.create_task(coro)
        self._pending_tasks.add(task)
        task.add_done_callback(self._pending_tasks.discard)

    def attach(self) -> None:
        s = self._session

        def _sync(async_fn):
            def wrapper(*args, **kwargs):
                self._spawn(async_fn(*args, **kwargs))
            return wrapper

        event_map = {
            "metrics_collected": self._on_metrics,
            "session_usage_updated": self._on_usage_updated,
            "function_tools_executed": self._on_tools_executed,
            "user_input_transcribed": self._on_user_transcript,
            "conversation_item_added": self._on_conversation_item,
            "agent_state_changed": self._on_state_changed,
            "speech_created": self._on_speech_created,
            "close": self._on_close,
        }

        for event_name, handler in event_map.items():
            try:
                s.on(event_name, _sync(handler))
            except Exception as e:
                logger.warning("damasqas_livekit: failed to register %s: %s", event_name, e)

        self._flush_task = None

        try:
            asyncio.get_event_loop().call_later(15, lambda: self._spawn(self._health_check()))
        except RuntimeError:
            pass

    async def _health_check(self) -> None:
        if self._handler_count == 0:
            logger.warning(
                "damasqas_livekit: NO event handlers fired after 15s. "
                "Check DAMASQAS_TOKEN and LiveKit SDK version."
            )

    async def _resolve_room(self) -> None:
        if self._room_resolved:
            return
        self._room_resolved = True
        try:
            room = None
            if hasattr(self._session, "room") and self._session.room:
                room = self._session.room
            elif hasattr(self._session, "_room_io") and self._session._room_io:
                room = self._session._room_io._room

            if room is None:
                return

            sid = room.sid
            if inspect.isawaitable(sid):
                sid = await sid
            self._room_sid = sid

            name = room.name
            if inspect.isawaitable(name):
                name = await name
            self._room_name = name

            logger.info("damasqas_livekit: resolved room=%s sid=%s", self._room_name, self._room_sid)
        except Exception as e:
            logger.warning("damasqas_livekit: room resolution failed: %s", e)

    async def _flush_loop(self) -> None:
        while True:
            await asyncio.sleep(5)
            now = time.time()
            stale = [sid for sid, t in self._turns.items() if (now - t.started_at) > 10]
            for sid in stale:
                await self._flush_turn(sid)

    def _ensure_flush_loop(self) -> None:
        if self._flush_task is not None:
            return
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                self._flush_task = asyncio.ensure_future(self._flush_loop())
        except RuntimeError:
            pass

    # ── metrics_collected (legacy, deprecated in 1.5.x) ─────────

    async def _on_metrics(self, ev: Any) -> None:
        try:
            self._handler_count += 1
            await self._resolve_room()
            self._ensure_flush_loop()

            # ev: MetricsCollectedEvent { metrics: AgentMetrics }
            m = ev.metrics
            speech_id = getattr(m, "speech_id", None) or f"unknown_{time.time()}"
            type_name = type(m).__name__.lower()
            logger.info("damasqas_livekit: metrics_collected type=%s speech_id=%s", type_name, speech_id)

            if speech_id not in self._turns:
                self._turns[speech_id] = TurnMetrics(speech_id=speech_id, started_at=time.time())
            turn = self._turns[speech_id]

            if "stt" in type_name:
                turn.stt_provider = getattr(m, "label", None)
                turn.stt_duration_ms = _s_to_ms(getattr(m, "duration", None))
                turn.stt_audio_duration_ms = _s_to_ms(getattr(m, "audio_duration", None))
                turn.stt_error = str(m.error) if getattr(m, "error", None) else None
            elif "llm" in type_name and "realtime" not in type_name:
                turn.llm_provider = getattr(m, "label", None)
                turn.llm_model = getattr(m, "model", None)
                if turn.llm_ttft_ms is None:
                    turn.llm_ttft_ms = _s_to_ms(getattr(m, "ttft", None))
                dur = _s_to_ms(getattr(m, "duration", None))
                if dur is not None:
                    turn.llm_total_duration_ms = (turn.llm_total_duration_ms or 0) + dur
                inp = getattr(m, "prompt_tokens", None)
                if inp is not None:
                    turn.llm_input_tokens = (turn.llm_input_tokens or 0) + inp
                out = getattr(m, "completion_tokens", None)
                if out is not None:
                    turn.llm_output_tokens = (turn.llm_output_tokens or 0) + out
                turn.llm_tokens_per_second = getattr(m, "tokens_per_second", None)
                turn.llm_cancelled = getattr(m, "cancelled", False)
                turn.llm_error = str(m.error) if getattr(m, "error", None) else None
            elif "tts" in type_name:
                turn.tts_provider = getattr(m, "label", None)
                turn.tts_ttfb_ms = _s_to_ms(getattr(m, "ttfb", None))
                turn.tts_duration_ms = _s_to_ms(getattr(m, "duration", None))
                turn.tts_audio_duration_ms = _s_to_ms(getattr(m, "audio_duration", None))
                turn.tts_characters = getattr(m, "characters_count", None)
                turn.tts_cancelled = getattr(m, "cancelled", False)
                turn.tts_error = str(m.error) if getattr(m, "error", None) else None
            elif "vad" in type_name:
                turn.vad_speech_duration_ms = _s_to_ms(getattr(m, "speech_duration", None))
                turn.vad_silence_duration_ms = _s_to_ms(getattr(m, "silence_duration", None))
            elif "eou" in type_name:
                turn.eou_latency_ms = _s_to_ms(getattr(m, "duration", None))

            if (turn.stt_duration_ms is not None
                    and turn.llm_ttft_ms is not None
                    and turn.tts_ttfb_ms is not None):
                turn.compute_e2e()
                await self._flush_turn(speech_id)
        except Exception as e:
            logger.warning("damasqas_livekit: _on_metrics error: %s", e)

    # ── session_usage_updated (modern, 1.5.x) ───────────────────

    async def _on_usage_updated(self, ev: Any) -> None:
        """ev: SessionUsageUpdatedEvent { usage: AgentSessionUsage { model_usage: list[ModelUsage] } }"""
        try:
            self._handler_count += 1
            await self._resolve_room()
            logger.info("damasqas_livekit: session_usage_updated fired")

            model_data = []
            for mu in getattr(ev.usage, "model_usage", []):
                model_data.append({
                    "kind": type(mu).__name__,
                    "provider": getattr(mu, "provider", None),
                    "model": getattr(mu, "model", None),
                    "input_tokens": getattr(mu, "input_tokens", None),
                    "output_tokens": getattr(mu, "output_tokens", None),
                    "characters_count": getattr(mu, "characters_count", None),
                    "audio_duration": getattr(mu, "audio_duration", None),
                })

            await self._transport.send({
                "type": "usage_updated",
                "workspace_id": self._workspace_id,
                "room_sid": self._room_sid,
                "room_name": self._room_name,
                "timestamp": time.time(),
                "model_usage": model_data,
            })
        except Exception as e:
            logger.warning("damasqas_livekit: _on_usage_updated error: %s", e)

    # ── function_tools_executed ──────────────────────────────────

    async def _on_tools_executed(self, ev: Any) -> None:
        """ev: FunctionToolsExecutedEvent { function_calls, function_call_outputs, .zipped() }"""
        try:
            self._handler_count += 1
            await self._resolve_room()
            logger.info("damasqas_livekit: function_tools_executed fired")

            tools_data = []
            for call, output in ev.zipped():
                record: dict[str, Any] = {
                    "name": call.name,
                    "call_id": call.call_id,
                }
                if output is not None:
                    record["success"] = not getattr(output, "is_error", False)
                    record["result"] = getattr(output, "result", None)
                tools_data.append(record)

            await self._transport.send({
                "type": "tool_calls",
                "workspace_id": self._workspace_id,
                "room_sid": self._room_sid,
                "room_name": self._room_name,
                "timestamp": time.time(),
                "tools": tools_data,
            })
        except Exception as e:
            logger.warning("damasqas_livekit: _on_tools_executed error: %s", e)

    # ── user_input_transcribed ───────────────────────────────────

    async def _on_user_transcript(self, ev: Any) -> None:
        """ev: UserInputTranscribedEvent { transcript, is_final, language }"""
        try:
            if not ev.is_final:
                return
            self._handler_count += 1
            await self._resolve_room()
            logger.info("damasqas_livekit: user_input_transcribed (final)")
            await self._transport.send({
                "type": "transcript",
                "workspace_id": self._workspace_id,
                "room_sid": self._room_sid,
                "room_name": self._room_name,
                "timestamp": time.time(),
                "role": "user",
                "text": ev.transcript,
                "language": getattr(ev, "language", None),
            })
        except Exception as e:
            logger.warning("damasqas_livekit: _on_user_transcript error: %s", e)

    # ── conversation_item_added ──────────────────────────────────

    async def _on_conversation_item(self, ev: Any) -> None:
        """
        ev: ConversationItemAddedEvent { item: ChatMessage }
        ChatMessage.metrics is a MetricsReport TypedDict:
          User:      transcription_delay, end_of_turn_delay, on_user_turn_completed_delay
          Assistant: llm_node_ttft, tts_node_ttfb, e2e_latency
          Both:      started_speaking_at, stopped_speaking_at
        """
        try:
            self._handler_count += 1
            await self._resolve_room()
            self._ensure_flush_loop()

            item = ev.item
            role = getattr(item, "role", "unknown")
            logger.info("damasqas_livekit: conversation_item_added role=%s", role)

            # Extract ChatMessage.metrics (MetricsReport TypedDict)
            metrics = getattr(item, "metrics", None)
            if metrics and isinstance(metrics, dict) and len(metrics) > 0:
                self._extract_chat_metrics(metrics, item)

            if role == "assistant":
                await self._transport.send({
                    "type": "transcript",
                    "workspace_id": self._workspace_id,
                    "room_sid": self._room_sid,
                    "room_name": self._room_name,
                    "timestamp": time.time(),
                    "role": "agent",
                    "text": getattr(item, "text_content", "") or "",
                    "interrupted": getattr(item, "interrupted", False),
                })
        except Exception as e:
            logger.warning("damasqas_livekit: _on_conversation_item error: %s", e)

    def _extract_chat_metrics(self, metrics: dict, item: Any) -> None:
        """Extract per-turn latency from MetricsReport TypedDict."""
        try:
            speech_id = getattr(item, "id", f"msg_{time.time()}")
            role = getattr(item, "role", "unknown")
            turn = TurnMetrics(speech_id=speech_id, started_at=0.0)

            if role == "assistant":
                turn.llm_ttft_ms = _s_to_ms(metrics.get("llm_node_ttft"))
                turn.tts_ttfb_ms = _s_to_ms(metrics.get("tts_node_ttfb"))
                turn.e2e_latency_ms = _s_to_ms(metrics.get("e2e_latency"))
            elif role == "user":
                turn.stt_duration_ms = _s_to_ms(metrics.get("transcription_delay"))
                turn.eou_latency_ms = _s_to_ms(metrics.get("end_of_turn_delay"))

            if turn.e2e_latency_ms is None:
                turn.compute_e2e()

            self._turns[speech_id] = turn

            logger.info(
                "damasqas_livekit: ChatMessage.metrics role=%s "
                "llm_ttft=%sms tts_ttfb=%sms e2e=%sms stt=%sms eou=%sms",
                role, turn.llm_ttft_ms, turn.tts_ttfb_ms,
                turn.e2e_latency_ms, turn.stt_duration_ms, turn.eou_latency_ms,
            )
        except Exception as e:
            logger.warning("damasqas_livekit: metrics extraction error: %s", e)

    # ── agent_state_changed ──────────────────────────────────────

    async def _on_state_changed(self, ev: Any) -> None:
        """ev: AgentStateChangedEvent { old_state, new_state }"""
        try:
            self._handler_count += 1
            await self._resolve_room()
            await self._transport.send({
                "type": "state_change",
                "workspace_id": self._workspace_id,
                "room_sid": self._room_sid,
                "room_name": self._room_name,
                "timestamp": time.time(),
                "old_state": ev.old_state,
                "new_state": ev.new_state,
            })
        except Exception as e:
            logger.warning("damasqas_livekit: _on_state_changed error: %s", e)

    # ── speech_created ───────────────────────────────────────────

    async def _on_speech_created(self, ev: Any) -> None:
        """ev: SpeechCreatedEvent { source, user_initiated }"""
        try:
            self._handler_count += 1
            await self._resolve_room()
            logger.info("damasqas_livekit: speech_created source=%s", ev.source)
            await self._transport.send({
                "type": "speech_created",
                "workspace_id": self._workspace_id,
                "room_sid": self._room_sid,
                "room_name": self._room_name,
                "timestamp": time.time(),
                "source": ev.source,
                "user_initiated": ev.user_initiated,
            })
        except Exception as e:
            logger.warning("damasqas_livekit: _on_speech_created error: %s", e)

    # ── close ────────────────────────────────────────────────────

    async def _on_close(self, ev: Any) -> None:
        """ev: CloseEvent { reason: CloseReason(enum), error }"""
        try:
            self._handler_count += 1
            logger.info("damasqas_livekit: close fired — flushing")
            await self._resolve_room()

            if self._flush_task:
                self._flush_task.cancel()

            in_flight = [t for t in self._pending_tasks if t is not asyncio.current_task()]
            if in_flight:
                await asyncio.gather(*in_flight, return_exceptions=True)

            for speech_id in list(self._turns.keys()):
                await self._flush_turn(speech_id)

            error_info = None
            if ev.error is not None:
                error_info = {"type": type(ev.error).__name__, "message": str(ev.error)}

            reason = ev.reason
            if hasattr(reason, "value"):
                reason = reason.value

            await self._transport.send({
                "type": "session_close",
                "workspace_id": self._workspace_id,
                "room_sid": self._room_sid,
                "room_name": self._room_name,
                "timestamp": time.time(),
                "reason": reason,
                "error": error_info,
                "session_duration_s": round(time.time() - self._session_start, 2),
                "total_turns": self._turn_index,
            })

            await self._transport.close()
            logger.info("damasqas_livekit: closed — %d turns, %d handler calls",
                        self._turn_index, self._handler_count)
        except Exception as e:
            logger.warning("damasqas_livekit: _on_close error: %s", e)

    # ── flush ────────────────────────────────────────────────────

    async def _flush_turn(self, speech_id: str) -> None:
        if speech_id not in self._turns:
            return

        turn = self._turns.pop(speech_id)
        self._turn_index += 1
        turn.compute_e2e()

        await self._transport.send({
            "type": "turn_metrics",
            "workspace_id": self._workspace_id,
            "room_sid": self._room_sid,
            "room_name": self._room_name,
            "turn_index": self._turn_index,
            "speech_id": turn.speech_id,
            "timestamp": turn.started_at,
            "stt_provider": turn.stt_provider,
            "stt_duration_ms": turn.stt_duration_ms,
            "stt_audio_duration_ms": turn.stt_audio_duration_ms,
            "stt_error": turn.stt_error,
            "llm_provider": turn.llm_provider,
            "llm_model": turn.llm_model,
            "llm_ttft_ms": turn.llm_ttft_ms,
            "llm_total_duration_ms": turn.llm_total_duration_ms,
            "llm_input_tokens": turn.llm_input_tokens,
            "llm_output_tokens": turn.llm_output_tokens,
            "llm_cached_tokens": turn.llm_cached_tokens,
            "llm_tokens_per_second": turn.llm_tokens_per_second,
            "llm_cancelled": turn.llm_cancelled,
            "llm_error": turn.llm_error,
            "tts_provider": turn.tts_provider,
            "tts_ttfb_ms": turn.tts_ttfb_ms,
            "tts_duration_ms": turn.tts_duration_ms,
            "tts_audio_duration_ms": turn.tts_audio_duration_ms,
            "tts_characters": turn.tts_characters,
            "tts_cancelled": turn.tts_cancelled,
            "tts_error": turn.tts_error,
            "vad_speech_duration_ms": turn.vad_speech_duration_ms,
            "vad_silence_duration_ms": turn.vad_silence_duration_ms,
            "eou_latency_ms": turn.eou_latency_ms,
            "interruption_occurred": turn.interruption_occurred,
            "interruption_overlap_ms": turn.interruption_overlap_ms,
            "e2e_latency_ms": turn.e2e_latency_ms,
            "tool_calls": turn.tool_calls,
        })
