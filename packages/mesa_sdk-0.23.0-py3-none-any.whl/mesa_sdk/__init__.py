"""Official Mesa Python SDK."""

try:
    from importlib.metadata import version as _version

    __version__ = _version("mesa-sdk")
except Exception:
    __version__ = "0.0.0-dev"

from mesa_sdk._mesa import Mesa
from mesa_sdk.errors import (
    ApiError,
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    InvalidApiUrlError,
    MesaError,
    MissingApiKeyError,
    NotFoundError,
    OrgResolutionError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from mesa_sdk.types import Author, FileChange, FileDelete, FileUpsert

__all__ = [
    "ApiError",
    "AuthenticationError",
    "Author",
    "AuthorizationError",
    "ConflictError",
    "FileChange",
    "FileDelete",
    "FileUpsert",
    "InvalidApiUrlError",
    "Mesa",
    "MesaError",
    "MissingApiKeyError",
    "NotFoundError",
    "OrgResolutionError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
]
