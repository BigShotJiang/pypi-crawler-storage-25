from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

from mesa_rest.api.org import whoami as whoami_api

from mesa_sdk._client import create_client, unwrap
from mesa_sdk._resources import (
    ApiKeys,
    Bookmarks,
    Changes,
    Content,
    Diffs,
    OrgResource,
    Repos,
    Webhooks,
)
from mesa_sdk.errors import ApiError, InvalidApiUrlError, MissingApiKeyError, OrgResolutionError

if TYPE_CHECKING:
    from mesa_rest.client import AuthenticatedClient
    from mesa_rest.models.whoami_response_200 import WhoamiResponse200

DEFAULT_API_URL = "https://api.mesa.dev/v1"
API_KEY_ENV_VAR = "MESA_API_KEY"


def _resolve_api_key(api_key: str | None) -> str:
    key = (api_key or "").strip() or os.environ.get(API_KEY_ENV_VAR, "").strip()
    if not key:
        raise MissingApiKeyError(API_KEY_ENV_VAR)
    return key


def _normalize_url(url: str) -> str:
    try:
        parsed = urlparse(url)
    except ValueError as exc:
        raise InvalidApiUrlError(url) from exc

    if parsed.scheme not in ("https", "http"):
        raise InvalidApiUrlError(url)

    return url.rstrip("/")


class Mesa:
    """Async Mesa SDK client.

    Usage::

        async with Mesa(api_key="mk_...") as mesa:
            repos = await mesa.repos.list()
    """

    api_key: str
    api_url: str

    repos: Repos
    bookmarks: Bookmarks
    changes: Changes
    content: Content
    diffs: Diffs
    api_keys: ApiKeys
    org: OrgResource
    webhooks: Webhooks
    raw: AuthenticatedClient

    _cached_org: str | None
    _cached_whoami: WhoamiResponse200 | None

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_url: str = DEFAULT_API_URL,
        org: str | None = None,
        user_agent: str | None = None,
    ) -> None:
        self.api_key = _resolve_api_key(api_key)
        self.api_url = _normalize_url(api_url.strip())
        self._cached_org = org.strip() if org else None
        self._cached_whoami = None

        self.raw = create_client(
            api_key=self.api_key,
            api_url=self.api_url,
            user_agent=user_agent,
        )

        self.repos = Repos(self.raw, self.resolve_org)
        self.bookmarks = Bookmarks(self.raw, self.resolve_org)
        self.changes = Changes(self.raw, self.resolve_org)
        self.content = Content(self.raw, self.resolve_org)
        self.diffs = Diffs(self.raw, self.resolve_org)
        self.api_keys = ApiKeys(self.raw, self.resolve_org)
        self.org = OrgResource(self.raw, self.resolve_org)
        self.webhooks = Webhooks(self.raw, self.resolve_org)

    async def resolve_org(self, org: str | None = None) -> str:
        if org and org.strip():
            return org.strip()
        if self._cached_org:
            return self._cached_org
        try:
            whoami = await self.whoami()
        except ApiError:
            raise
        except Exception as exc:
            raise OrgResolutionError(
                "Unable to resolve default organization from /whoami. "
                "Provide `org` per call or verify your API key scopes."
            ) from exc
        self._cached_org = whoami.org.slug
        return self._cached_org

    async def whoami(self) -> WhoamiResponse200:
        if self._cached_whoami is not None:
            return self._cached_whoami

        resp = await whoami_api.asyncio_detailed(client=self.raw)
        result = unwrap(resp)
        self._cached_whoami = result
        self._cached_org = result.org.slug
        return result

    async def __aenter__(self) -> Mesa:
        await self.raw.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.raw.__aexit__(*args)
