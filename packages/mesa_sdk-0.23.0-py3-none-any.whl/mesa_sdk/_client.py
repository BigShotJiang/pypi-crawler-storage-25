from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from mesa_rest.client import AuthenticatedClient

from mesa_sdk.errors import raise_for_status

if TYPE_CHECKING:
    from mesa_rest.types import Response

T = TypeVar("T")

SDK_USER_AGENT = "mesa-sdk-python"


def create_client(
    *,
    api_key: str,
    api_url: str,
    user_agent: str | None = None,
) -> AuthenticatedClient:
    """Create an AuthenticatedClient configured for the Mesa API."""
    ua = f"{SDK_USER_AGENT} {user_agent}" if user_agent else SDK_USER_AGENT
    return AuthenticatedClient(
        base_url=api_url,
        token=api_key,
        prefix="Bearer",
        headers={"User-Agent": ua},
        raise_on_unexpected_status=False,
    )


def unwrap(response: Response[T]) -> T:
    """Extract the parsed response body, raising a typed error for non-2xx status codes."""
    raise_for_status(response.status_code, response.parsed)
    return response.parsed  # type: ignore[return-value]
