"""Shared JSON-RPC output helpers for mcp.py and gateway.py."""

from __future__ import annotations

import json
import sys
from typing import Any

MCP_VERSION = "2025-11-25"


def _write_result(req_id: Any, result: dict[str, Any]) -> None:
    response = {"jsonrpc": "2.0", "id": req_id, "result": result}
    sys.stdout.write(json.dumps(response) + "\n")
    sys.stdout.flush()


def _write_error(
    req_id: Any, code: int, message: str, *, data: dict[str, Any] | None = None
) -> None:
    error_obj: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        error_obj["data"] = data
    response = {
        "jsonrpc": "2.0",
        "id": req_id,
        "error": error_obj,
    }
    sys.stdout.write(json.dumps(response) + "\n")
    sys.stdout.flush()


def _write_notification(method: str, params: dict[str, Any]) -> None:
    """Write a JSON-RPC notification (no id field, no response expected)."""
    notification = {"jsonrpc": "2.0", "method": method, "params": params}
    sys.stdout.write(json.dumps(notification) + "\n")
    sys.stdout.flush()


def _stderr(message: str) -> None:
    sys.stderr.write(message + "\n")
    sys.stderr.flush()
