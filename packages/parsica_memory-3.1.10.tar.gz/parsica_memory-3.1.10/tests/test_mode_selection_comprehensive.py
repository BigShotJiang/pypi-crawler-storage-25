"""
Comprehensive tests for Parsica 3.0 Intelligent Mode Selection.

Covers:
- Sprint 1: API + mode policy plumbing
- Sprint 2: Enrichment gating
- Sprint 3: Fact/decomposition gating  
- Sprint 4: Unified Layer 7 intent + mode controller
- Sprint 5: Fallback / graceful degradation
"""

import tempfile
import pytest

from parsica_memory.entry import MemoryEntry
from parsica_memory.search import (
    SearchEngine, SearchResult, ModeController, ModePolicy, IntentReranker,
)
from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem


# ─── Helpers ────────────────────────────────────────────────────────────────

def _entry(content, **kwargs):
    """Create a MemoryEntry with optional overrides."""
    m = MemoryEntry(
        content,
        kwargs.pop("source", "test"),
        kwargs.pop("line", 1),
        kwargs.pop("category", "general"),
    )
    for k, v in kwargs.items():
        setattr(m, k, v)
    return m


def _enriched_entry(content, summary="", keywords=None, queries=None, **kwargs):
    """Create a MemoryEntry with enrichment fields populated."""
    m = _entry(content, **kwargs)
    m.enriched_summary = summary or ""
    m.search_keywords = keywords or []
    m.search_queries = queries or []
    return m


# ═══════════════════════════════════════════════════════════════════════════
# Sprint 1: API + Mode Policy Plumbing
# ═══════════════════════════════════════════════════════════════════════════

class TestModeControllerClassification:
    """Test that ModeController classifies queries correctly."""

    def test_recent_mode_temporal_keywords(self):
        queries = [
            "what happened yesterday",
            "latest update on the project",
            "most recent discussion",
            "what did we just talk about",
            "today's meeting notes",
            "this morning's standup",
            "recently discussed topics",
        ]
        for q in queries:
            mode, _ = ModeController.classify_search_mode(q)
            assert mode == "recent", f"Expected 'recent' for '{q}', got '{mode}'"

    def test_precision_mode_value_queries(self):
        queries = [
            "what is the exact timeout value",
            "how much did the enrichment cost",
            "how many memories are stored",
            "v2.3.1",
            "30ms",
        ]
        for q in queries:
            mode, _ = ModeController.classify_search_mode(q)
            assert mode == "precision", f"Expected 'precision' for '{q}', got '{mode}'"

    def test_deep_mode_audit_queries(self):
        queries = [
            "list all deployment failures",
            "every instance of timeout errors",
            "connection between Alice and the bug",
            "audit evidence for the release",
            "full history of config changes",
        ]
        for q in queries:
            mode, _ = ModeController.classify_search_mode(q)
            assert mode == "deep", f"Expected 'deep' for '{q}', got '{mode}'"

    def test_semantic_mode_referential_queries(self):
        queries = [
            "the thing about that project",
            "which one was it",
            "what did we discuss about parsica",
            "remember when we talked about indexing",
        ]
        for q in queries:
            mode, _ = ModeController.classify_search_mode(q)
            assert mode == "semantic", f"Expected 'semantic' for '{q}', got '{mode}'"

    def test_semantic_mode_short_ambiguous_queries(self):
        """Short queries without strong signals go to semantic mode."""
        queries = ["memory", "search", "parsica"]
        for q in queries:
            mode, _ = ModeController.classify_search_mode(q)
            assert mode == "semantic", f"Expected 'semantic' for '{q}', got '{mode}'"

    def test_default_mode_general_queries(self):
        """Longer queries without specific patterns go to default."""
        queries = [
            "tell me about memory retrieval systems",
            "how does the search engine work internally",
            "explain the BM25 scoring algorithm",
        ]
        for q in queries:
            mode, _ = ModeController.classify_search_mode(q)
            assert mode == "default", f"Expected 'default' for '{q}', got '{mode}'"

    def test_empty_query_returns_semantic(self):
        """Empty query has 0 tokens → treated as short ambiguous → semantic."""
        mode, _ = ModeController.classify_search_mode("")
        assert mode == "semantic"

    def test_mode_priority_deep_over_recent(self):
        """Deep should win over recent when both signals present."""
        # "list all" is deep, "yesterday" is recent — deep should win
        # because deep patterns are checked first
        mode, _ = ModeController.classify_search_mode("list all changes from yesterday")
        assert mode == "deep"


class TestModePolicyFlags:
    """Test that ModePolicy objects have correct feature flags."""

    def test_recent_policy(self):
        p = ModeController.get_policy("what happened yesterday")
        assert p.mode == "recent"
        assert p.include_enrichment is False
        assert p.include_facts is False
        assert p.enrichment_weight_multiplier == 0.0

    def test_semantic_policy(self):
        p = ModeController.get_policy("the thing about that project")
        assert p.mode == "semantic"
        assert p.include_enrichment is True
        assert p.include_facts is False
        assert p.enrichment_weight_multiplier > 1.0  # boosted

    def test_precision_policy(self):
        p = ModeController.get_policy("what is the exact timeout")
        assert p.mode == "precision"
        assert p.include_enrichment is False
        assert p.include_facts is True
        assert p.jaccard_threshold < 0.40  # lower for atomic facts

    def test_deep_policy(self):
        p = ModeController.get_policy("list all audit evidence")
        assert p.mode == "deep"
        assert p.include_enrichment is True
        assert p.include_facts is True

    def test_default_policy(self):
        p = ModeController.get_policy("explain the BM25 scoring algorithm")
        assert p.mode == "default"
        assert p.include_enrichment is True
        assert p.include_facts is False
        assert p.enrichment_weight_multiplier == 1.0

    def test_explicit_mode_overrides_auto(self):
        """Passing mode='deep' explicitly should not auto-classify."""
        p = ModeController.get_policy("what happened yesterday", mode="deep")
        assert p.mode == "deep"
        assert p.include_facts is True

    def test_normalize_mode_invalid(self):
        assert ModeController.normalize_mode("invalid") == "auto"
        assert ModeController.normalize_mode(None) == "auto"
        assert ModeController.normalize_mode("") == "auto"

    def test_normalize_mode_valid(self):
        for mode in ("auto", "recent", "semantic", "precision", "deep", "default"):
            assert ModeController.normalize_mode(mode) == mode

    def test_policy_has_fallback_enabled(self):
        p = ModeController.get_policy("recent query yesterday")
        assert p.fallback_enabled is True


class TestSearchEngineModePassthrough:
    """Test that mode parameter flows through SearchEngine.search()."""

    def test_mode_parameter_accepted(self):
        engine = SearchEngine()
        mem = _entry("Important technical decision about architecture")
        engine.build_index([mem])
        # Should not raise
        results = engine.search("architecture", [mem], mode="auto")
        assert isinstance(results, list)

    def test_explicit_mode_respected(self):
        engine = SearchEngine()
        mem = _entry("The timeout is 30 seconds for API calls")
        fact = _entry("API timeout is 30 seconds", memory_type="fact", parent_hash="abc123")
        engine.build_index([mem, fact])
        
        # Default mode: facts deprioritized
        default_results = engine.search("timeout", [mem, fact], mode="default")
        # Precision mode: facts get full weight
        precision_results = engine.search("timeout", [mem, fact], mode="precision")
        
        # Both should return results
        assert default_results
        assert precision_results


# ═══════════════════════════════════════════════════════════════════════════
# Sprint 2: Enrichment Gating
# ═══════════════════════════════════════════════════════════════════════════

class TestEnrichmentGating:
    """Test that enrichment fields are correctly gated per mode."""

    def setup_method(self):
        self.engine = SearchEngine()
        # Create a memory only findable via enrichment (vocabulary gap)
        self.mem = _enriched_entry(
            "We had a long discussion about the web backend framework choice.",
            summary="FastAPI was selected as the web framework for all backend services",
            keywords=["fastapi", "framework", "backend"],
            queries=["which web framework do we use", "what framework runs the backend"],
        )
        self.engine.build_index([self.mem])

    def test_semantic_mode_uses_enrichment(self):
        """Semantic mode should use enrichment fields (that's its purpose)."""
        results = self.engine.search("FastAPI", [self.mem], mode="semantic")
        assert results, "semantic mode should find entries via enrichment"

    def test_precision_mode_disables_enrichment(self):
        """Precision mode should not use enrichment fields."""
        # "FastAPI" only appears in enriched_summary, not raw content
        results = self.engine.search("FastAPI", [self.mem], mode="precision")
        # May still match if "FastAPI" is in raw content or through other means
        # The key test: enrichment-only matches should score lower or not appear
        if results:
            # Check that enrichment-specific markers are NOT in matched terms
            for r in results:
                assert "enriched_match" not in r.matched_terms
                assert "doc2query_match" not in r.matched_terms

    def test_recent_mode_disables_enrichment(self):
        """Recent mode should skip enrichment fields.
        
        Note: If fallback triggers (recent → default), enrichment may appear
        in the fallback results. We test with fallback disabled to verify
        the mode's own behavior.
        """
        from parsica_memory.search import ModePolicy
        policy = ModePolicy(
            mode="recent", include_enrichment=False, include_facts=False,
            jaccard_threshold=0.40, enrichment_weight_multiplier=0.0,
            fallback_enabled=False, reason="test",
        )
        results = self.engine.search("framework", [self.mem], mode="recent", mode_policy=policy)
        if results:
            for r in results:
                assert "enriched_match" not in r.matched_terms
                assert "doc2query_match" not in r.matched_terms

    def test_default_mode_uses_enrichment(self):
        """Default mode should use enrichment at normal weight."""
        results = self.engine.search("framework", [self.mem], mode="default")
        assert results, "default mode should use enrichment"

    def test_enrichment_weight_multiplier_affects_scoring(self):
        """Semantic mode should give higher enrichment weight than default."""
        semantic_results = self.engine.search("FastAPI", [self.mem], mode="semantic")
        default_results = self.engine.search("FastAPI", [self.mem], mode="default")
        
        # Both should find results if enrichment is available
        # Semantic mode has enrichment_weight_multiplier > 1.0
        # This doesn't guarantee higher absolute scores, but enrichment signals should matter


# ═══════════════════════════════════════════════════════════════════════════
# Sprint 3: Fact/Decomposition Gating
# ═══════════════════════════════════════════════════════════════════════════

class TestFactGating:
    """Test that decomposed fact entries are correctly gated per mode."""

    def setup_method(self):
        self.engine = SearchEngine()
        self.parent = _entry(
            "System configuration review: database timeout is 30 seconds, cache expiry is 24 hours"
        )
        self.fact1 = _entry(
            "Database connection timeout is 30 seconds",
            memory_type="fact",
            parent_hash=self.parent.hash,
        )
        self.fact2 = _entry(
            "Cache expiry is set to 24 hours",
            memory_type="fact",
            parent_hash=self.parent.hash,
        )
        self.memories = [self.parent, self.fact1, self.fact2]
        self.engine.build_index(self.memories)

    def test_precision_mode_includes_facts(self):
        """Precision mode should include decomposed facts at full weight."""
        results = self.engine.search("database timeout", self.memories, mode="precision")
        assert results
        facts = [r for r in results if getattr(r.entry, "parent_hash", "")]
        assert facts, "precision mode should include facts"
        # Facts should NOT have the deprioritization marker
        for r in facts:
            assert "fact_deprioritized" not in r.matched_terms

    def test_deep_mode_includes_facts(self):
        """Deep mode should include all facts."""
        results = self.engine.search("database timeout cache expiry", self.memories, mode="deep")
        assert results
        facts = [r for r in results if getattr(r.entry, "parent_hash", "")]
        assert facts, "deep mode should include facts"

    def test_default_mode_deprioritizes_facts(self):
        """Default mode should deprioritize facts via scoring penalty."""
        results = self.engine.search("database timeout", self.memories, mode="default")
        assert results
        # Facts may still appear but should be marked as deprioritized
        facts = [r for r in results if getattr(r.entry, "parent_hash", "")]
        if facts:
            assert any("fact_deprioritized" in r.matched_terms for r in facts)

    def test_recent_mode_deprioritizes_facts(self):
        """Recent mode should deprioritize facts."""
        results = self.engine.search("database timeout", self.memories, mode="recent")
        if results:
            facts = [r for r in results if getattr(r.entry, "parent_hash", "")]
            if facts:
                assert any("fact_deprioritized" in r.matched_terms for r in facts)

    def test_facts_still_searchable_in_default_mode(self):
        """Ensure facts are not completely excluded — just penalized."""
        results = self.engine.search("database timeout", self.memories, mode="default")
        # The fact should still appear in results somewhere
        all_content = [r.entry.content for r in results]
        assert any("Database connection timeout" in c for c in all_content), \
            "Fact should still be searchable in default mode (just deprioritized)"


# ═══════════════════════════════════════════════════════════════════════════
# Sprint 4: Unified Layer 7 (Intent + Mode Controller)
# ═══════════════════════════════════════════════════════════════════════════

class TestIntentModeIntegration:
    """Test that intent detection works alongside mode classification."""

    def test_intent_and_mode_are_orthogonal(self):
        """Intent and mode serve different purposes — both should work."""
        # A query can be "temporal" intent AND "deep" mode
        query = "when did we list all the deployment failures"
        intents = IntentReranker.detect_intent(query)
        mode, _ = ModeController.classify_search_mode(query)
        
        assert "temporal" in intents, "Should detect temporal intent"
        assert mode == "deep", "Should classify as deep mode"

    def test_policy_carries_intents(self):
        """ModePolicy should carry intent information."""
        query = "when did this happen"
        intents = IntentReranker.detect_intent(query)
        policy = ModeController.get_policy(query, intents=intents)
        assert policy.intents == intents

    def test_search_applies_both_intent_and_mode(self):
        """SearchEngine.search() should apply both intent reranking and mode gating."""
        engine = SearchEngine()
        mem1 = _entry("Meeting on 2026-03-15 about production deployment issues")
        mem2 = _entry("We discussed deployment strategy at length with the team")
        engine.build_index([mem1, mem2])

        # "when" query → temporal intent → should boost mem1 (has date)
        results = engine.search("when did we discuss deployment", [mem1, mem2])
        assert results
        # Both should match, but mem1 (with date) should rank higher due to intent boost


# ═══════════════════════════════════════════════════════════════════════════
# Sprint 5: Fallback / Graceful Degradation
# ═══════════════════════════════════════════════════════════════════════════

class TestFallback:
    """Test fallback logic for weak auto-mode results."""

    def test_should_fallback_on_empty_results(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("something", mode="recent")
        assert engine._should_fallback(policy, [], 10) is True

    def test_should_not_fallback_on_default_mode(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("something", mode="default")
        assert engine._should_fallback(policy, [], 10) is False

    def test_should_not_fallback_on_good_results(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("something", mode="recent")
        # Mock SearchResult objects with good relevance
        mock_results = [
            SearchResult(
                entry=_entry("result 1"), score=10.0, relevance=0.9,
                matched_terms=["test"], explanation="test"
            ),
            SearchResult(
                entry=_entry("result 2"), score=8.0, relevance=0.8,
                matched_terms=["test"], explanation="test"
            ),
        ]
        assert engine._should_fallback(policy, mock_results, 10) is False

    def test_should_fallback_on_low_relevance(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("something", mode="recent")
        mock_results = [
            SearchResult(
                entry=_entry("weak result"), score=0.5, relevance=0.15,
                matched_terms=["test"], explanation="test"
            ),
        ]
        assert engine._should_fallback(policy, mock_results, 10) is True

    def test_fallback_policy_disables_further_fallback(self):
        """Fallback policy must have fallback_enabled=False to prevent recursion."""
        engine = SearchEngine()
        policy = ModeController.get_policy("something", mode="recent")
        fallback = engine._fallback_policy(policy)
        assert fallback is not None
        assert fallback.fallback_enabled is False

    def test_fallback_chain_recent_to_default(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("", mode="recent")
        fallback = engine._fallback_policy(policy)
        assert fallback.mode == "default"

    def test_fallback_chain_precision_to_deep(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("", mode="precision")
        fallback = engine._fallback_policy(policy)
        assert fallback.mode == "deep"

    def test_fallback_chain_semantic_to_default(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("", mode="semantic")
        fallback = engine._fallback_policy(policy)
        assert fallback.mode == "default"

    def test_fallback_chain_deep_to_default(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("", mode="deep")
        fallback = engine._fallback_policy(policy)
        assert fallback.mode == "default"

    def test_no_fallback_from_default(self):
        engine = SearchEngine()
        policy = ModeController.get_policy("", mode="default")
        fallback = engine._fallback_policy(policy)
        assert fallback is None

    def test_fallback_actually_broadens_results(self):
        """When precision mode returns weak results, fallback should broaden."""
        engine = SearchEngine()
        # Only enrichment can bridge this vocabulary gap
        mem = _enriched_entry(
            "The system architecture uses microservices for scalability",
            summary="Microservice architecture chosen for horizontal scaling",
            keywords=["microservices", "scaling", "architecture"],
            queries=["what architecture pattern do we use"],
        )
        engine.build_index([mem])

        # "how many" triggers precision mode, which disables enrichment.
        # Fallback should broaden to deep mode which enables enrichment.
        results = engine.search("architecture pattern", [mem], mode="auto")
        assert results, "Fallback should produce results when initial mode is too restrictive"


# ═══════════════════════════════════════════════════════════════════════════
# Integration: MemorySystem level
# ═══════════════════════════════════════════════════════════════════════════

class TestMemorySystemModeIntegration:
    """Test mode selection at the MemorySystem level."""

    def setup_method(self):
        self.tmpdir = tempfile.mkdtemp()
        self.mem = MemorySystem(workspace=self.tmpdir, agent_name="test-agent")
        self.mem.load()

    def test_search_default_mode_is_auto(self):
        """Default mode parameter should be 'auto'."""
        self.mem.ingest("Important fact about database configuration", source="chat")
        results = self.mem.search("database")
        assert results  # should work without specifying mode

    def test_search_explicit_mode(self):
        """All explicit modes should be accepted."""
        self.mem.ingest("The timeout value is 30 seconds for all API endpoints", source="chat")
        for mode_name in ("auto", "recent", "semantic", "precision", "deep", "default"):
            results = self.mem.search("timeout", mode=mode_name)
            # Should not raise regardless of mode

    def test_backward_compatibility(self):
        """Existing callers without mode= should still work."""
        self.mem.ingest("We deployed the new version of the API", source="chat")
        
        # Old-style call (no mode parameter)
        results = self.mem.search("deploy")
        assert results

    def test_mode_in_cache_key(self):
        """Different modes should have different cache keys."""
        self.mem.ingest("The deployment happened on Tuesday morning", source="chat")
        
        # Search with two different modes
        auto_results = self.mem.search("deployment", mode="auto")
        deep_results = self.mem.search("deployment", mode="deep")
        
        # Both should return results (cache shouldn't cross-contaminate)
        assert auto_results
        assert deep_results


# ═══════════════════════════════════════════════════════════════════════════
# Edge Cases
# ═══════════════════════════════════════════════════════════════════════════

class TestEdgeCases:
    """Edge cases for mode selection."""

    def test_mode_frozen_dataclass(self):
        """ModePolicy should be frozen (immutable)."""
        p = ModeController.get_policy("test query")
        with pytest.raises(AttributeError):
            p.mode = "hacked"

    def test_multi_entity_detection_deep_mode(self):
        """Queries with 2+ proper nouns should classify as deep."""
        query = "Relationship between Alice Smith and Bob Jones in the project"
        mode, _ = ModeController.classify_search_mode(query)
        assert mode == "deep"

    def test_version_number_triggers_precision(self):
        """Standalone version numbers should trigger precision mode."""
        mode, _ = ModeController.classify_search_mode("v2.3.1 release notes")
        assert mode == "precision"

    def test_unit_number_triggers_precision(self):
        """Numbers with units should trigger precision mode."""
        mode, _ = ModeController.classify_search_mode("500ms latency budget")
        assert mode == "precision"


# ═══════════════════════════════════════════════════════════════════════════
# v5.1.1 — Scales of Justice Round 1 regression tests
# ═══════════════════════════════════════════════════════════════════════════


class TestWindowFactGating:
    """HIGH 2: Fact-only constituents inside a winning window must be penalized."""

    def test_window_with_fact_constituents_penalized_in_default_mode(self):
        """Windows containing fact entries should receive a proportional penalty
        when the mode doesn't include facts (e.g. default, recent).
        Prevents facts from 'smuggling' back into results via windows."""
        engine = SearchEngine()
        # Create a parent and multiple fact children
        parent = _entry("We discussed deployment strategy and timeout configuration.")
        fact1 = _entry("The timeout value is 30 seconds.", parent_hash=parent.hash)
        fact2 = _entry("The retry count is 3.", parent_hash=parent.hash)
        non_fact = _entry("We reviewed the deployment pipeline and timeout approach.")
        memories = [parent, fact1, fact2, non_fact]
        engine.build_index(memories)

        # Default mode: facts should be deprioritized
        results = engine.search("timeout deployment", memories, mode="default")
        # Check that window_fact_deprioritized appears in matched_terms
        # for any window result that contains fact constituents
        for r in results:
            if hasattr(r.entry, 'source_ids'):
                source_ids = r.entry.source_ids
                has_fact = any(
                    getattr(m, 'parent_hash', '') for m in memories
                    if m.hash in source_ids
                )
                if has_fact:
                    assert "window_fact_deprioritized" in r.matched_terms, \
                        f"Window with fact constituents should be penalized in default mode"

    def test_window_with_fact_constituents_not_penalized_in_precision_mode(self):
        """In precision mode (include_facts=True), windows with fact
        constituents should NOT receive the fact penalty."""
        engine = SearchEngine()
        parent = _entry("We discussed the timeout configuration.")
        fact = _entry("The timeout value is 30 seconds.", parent_hash=parent.hash)
        memories = [parent, fact]
        engine.build_index(memories)

        results = engine.search("timeout value", memories, mode="precision")
        for r in results:
            assert "window_fact_deprioritized" not in r.matched_terms

    def test_window_with_fact_constituents_penalized_in_recent_mode(self):
        """Recent mode excludes facts, so windows with fact content should
        receive the proportional penalty."""
        engine = SearchEngine()
        parent = _entry("We discussed the timeout configuration.")
        fact = _entry("The timeout value is 30 seconds.", parent_hash=parent.hash)
        memories = [parent, fact]
        engine.build_index(memories)

        results = engine.search("timeout value", memories, mode="recent")
        for r in results:
            if hasattr(r.entry, 'source_ids'):
                source_ids = r.entry.source_ids
                has_fact = any(
                    getattr(m, 'parent_hash', '') for m in memories
                    if m.hash in source_ids
                )
                if has_fact:
                    assert "window_fact_deprioritized" in r.matched_terms


class TestFallbackQualityGating:
    """MEDIUM 4: Fallback with one strong specialized result should not broaden."""

    def test_single_strong_result_no_fallback(self):
        """A single result with high relevance should NOT trigger fallback.
        The specialized mode found what it needed."""
        engine = SearchEngine()
        policy = ModeController.get_policy("something", mode="recent")
        # Single strong result: relevance 0.85 = strong match
        mock_results = [
            SearchResult(
                entry=_entry("strong precise answer"),
                score=5.0, relevance=0.85,
                matched_terms=["strong"], explanation="test"
            ),
        ]
        assert engine._should_fallback(policy, mock_results, 10) is False, \
            "A single strong result should not trigger fallback"

    def test_single_weak_result_triggers_fallback(self):
        """A single result with low relevance SHOULD trigger fallback."""
        engine = SearchEngine()
        policy = ModeController.get_policy("something", mode="recent")
        mock_results = [
            SearchResult(
                entry=_entry("weak result"),
                score=0.5, relevance=0.15,
                matched_terms=["test"], explanation="test"
            ),
        ]
        assert engine._should_fallback(policy, mock_results, 10) is True, \
            "A single weak result should still trigger fallback"

    def test_multiple_results_no_fallback_when_strong(self):
        """Multiple results where top result is strong should not fallback."""
        engine = SearchEngine()
        policy = ModeController.get_policy("something", mode="precision")
        mock_results = [
            SearchResult(
                entry=_entry("best result"), score=5.0, relevance=0.95,
                matched_terms=["test"], explanation="test"
            ),
            SearchResult(
                entry=_entry("second result"), score=4.0, relevance=0.80,
                matched_terms=["test"], explanation="test"
            ),
        ]
        assert engine._should_fallback(policy, mock_results, 10) is False


class TestEntityClassifierPrecision:
    """MEDIUM 3: Capitalized non-entity queries should not auto-classify as deep."""

    def test_sentence_initial_capitalization_not_counted(self):
        """Words that are only capitalized because they start a sentence should
        not count as proper nouns for multi-entity detection."""
        # "Hello World" — both capitalized but "Hello" is sentence-initial
        mode, reason = ModeController.classify_search_mode(
            "Hello there how are you doing today Friend"
        )
        assert mode != "deep" or "multi-entity" not in reason, \
            "Sentence-initial words should not trigger multi-entity deep mode"

    def test_question_initial_capitalization_not_deep(self):
        """Common question patterns with sentence-initial caps should NOT
        be classified as multi-entity deep."""
        # "What happened with the Server and Database" — What is sentence-initial
        mode, reason = ModeController.classify_search_mode(
            "What happened with the Config and Settings for the deployment"
        )
        # Should NOT be deep/multi-entity — "What" is sentence-initial,
        # "Config" and "Settings" are the only true caps, but they're
        # generic terms, not named entities with relational cues
        if mode == "deep":
            assert "multi-entity" not in reason, \
                "Generic capitalized words without relational cues should not trigger multi-entity"

    def test_true_multi_entity_with_relational_cue_is_deep(self):
        """Genuine multi-entity queries with relational cues SHOULD be deep."""
        mode, reason = ModeController.classify_search_mode(
            "What is the connection between Parsica and FastAPI across the codebase"
        )
        assert mode == "deep", \
            "True multi-entity query with relational cues should be deep"

    def test_multiple_proper_nouns_without_relational_cue_not_deep(self):
        """Two proper nouns without relational cues should not auto-classify as deep."""
        mode, reason = ModeController.classify_search_mode(
            "Tell me about the Parsica and FastAPI setup"
        )
        # "Tell" is sentence-initial, so only Parsica and FastAPI count.
        # Without relational cues and with only 2 entities, this should NOT
        # be deep/multi-entity
        if mode == "deep":
            assert "multi-entity" not in reason

    def test_three_proper_nouns_without_cue_is_deep(self):
        """Three or more true proper nouns is a strong enough signal for deep
        even without explicit relational cues."""
        mode, reason = ModeController.classify_search_mode(
            "the relationship between Parsica and FastAPI and Docker in our stack"
        )
        assert mode == "deep"
