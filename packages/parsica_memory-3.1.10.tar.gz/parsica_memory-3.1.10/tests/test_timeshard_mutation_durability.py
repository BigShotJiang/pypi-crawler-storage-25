"""
Tests for time-shard mutation durability (v2.6.1 blocker fix).

Proves that delete_source(), forget(), and save() correctly persist
mutations to weekly shard files so deleted/forgotten memories do NOT
resurrect on reload.

Storage invariant under test:
    In time-shard mode (use_sharding=False, sharding=True), save()
    rewrites the weekly JSONL shard files from in-memory truth via
    rewrite_entries(). Mutations are durable across load/save cycles.
"""

import json
import os
import tempfile
import pytest

from parsica_memory.core_v4 import MemorySystemV4


def _make_system(workspace: str, **kwargs) -> MemorySystemV4:
    """Create a MemorySystem in time-shard mode (the mode under test)."""
    defaults = dict(
        workspace=workspace,
        use_sharding=False,    # disable enterprise shards
        sharding=True,         # enable v4.6 time-window shards
        use_indexing=False,    # minimize noise
        graph_intelligence=False,
        quality_routing=False,
        semantic_expansion=False,
        tiered_storage=False,
    )
    defaults.update(kwargs)
    return MemorySystemV4(**defaults)


def _reload_system(workspace: str, **kwargs) -> MemorySystemV4:
    """Create a fresh MemorySystem pointed at the same workspace (simulates restart)."""
    return _make_system(workspace, **kwargs)


# ── save() routing ──────────────────────────────────────────────────────


class TestSaveRouting:
    """Verify save() calls _save_v46_sharded(), not _save_legacy(), in time-shard mode."""

    def test_save_creates_shard_files_not_legacy(self, tmp_path):
        ws = str(tmp_path)
        mem = _make_system(ws)
        mem.ingest("This is a test memory for shard save routing verification", source="test")
        mem.save()

        # Shard files should exist
        shard_files = [f for f in os.listdir(ws) if f.startswith("memories_") and f.endswith(".jsonl")]
        assert len(shard_files) >= 1, "No shard files created by save()"

        # Legacy file should NOT be the authoritative source
        # (It may or may not exist — the key test is that shards contain the data)
        for sf in shard_files:
            with open(os.path.join(ws, sf)) as fh:
                lines = [l.strip() for l in fh if l.strip()]
            assert len(lines) >= 1, f"Shard file {sf} is empty after save()"

    def test_save_returns_workspace_path(self, tmp_path):
        ws = str(tmp_path)
        mem = _make_system(ws)
        mem.ingest("This is a test memory that should go into time shards properly", source="test")
        result = mem.save()
        assert result == ws


# ── delete_source durability ────────────────────────────────────────────


class TestDeleteSourceDurability:
    """delete_source() in time-shard mode must persist across reload."""

    def test_delete_source_persists_across_reload(self, tmp_path):
        ws = str(tmp_path)
        mem = _make_system(ws)

        # Ingest two memories from different sources
        mem.ingest("Memory from source_a about widgets and gadgets design", source="a", source_url="http://source-a.com")
        mem.ingest("Memory from source_b about rockets and satellites launch", source="b", source_url="http://source-b.com")
        mem.save()
        assert len(mem.memories) == 2

        # Delete source_a
        result = mem.delete_source("http://source-a.com")
        assert result["deleted"] == 1
        assert len(mem.memories) == 1
        assert mem.memories[0].content.startswith("Memory from source_b")

        # Reload from disk — source_a must NOT resurrect
        mem2 = _reload_system(ws)
        assert len(mem2.memories) == 1, f"Expected 1 memory after reload, got {len(mem2.memories)}"
        assert mem2.memories[0].content.startswith("Memory from source_b")

    def test_delete_source_removes_shard_entry(self, tmp_path):
        """After delete_source + save, the shard JSONL should not contain the deleted entry."""
        ws = str(tmp_path)
        mem = _make_system(ws)
        mem.ingest("Alpha memory about technology and software engineering", source="alpha", source_url="http://alpha.com")
        mem.save()

        # Read shard file — should have the entry
        shard_files = [f for f in os.listdir(ws) if f.startswith("memories_") and f.endswith(".jsonl")]
        assert len(shard_files) >= 1
        shard_path = os.path.join(ws, shard_files[0])
        with open(shard_path) as fh:
            before_lines = [l.strip() for l in fh if l.strip()]
        assert len(before_lines) == 1

        # Delete it
        mem.delete_source("http://alpha.com")

        # Shard file should now be empty or removed
        if os.path.exists(shard_path):
            with open(shard_path) as fh:
                after_lines = [l.strip() for l in fh if l.strip()]
            assert len(after_lines) == 0, "Shard file still contains deleted entry"
        # If file was removed entirely, that's also correct


# ── forget() durability ─────────────────────────────────────────────────


class TestForgetDurability:
    """forget() in time-shard mode must persist across reload."""

    def test_forget_topic_persists_across_reload(self, tmp_path):
        ws = str(tmp_path)
        mem = _make_system(ws)
        mem.ingest("The quantum computing project is progressing well with new results", source="meeting")
        mem.ingest("Server infrastructure needs upgrading to handle the increased load", source="meeting")
        mem.save()
        assert len(mem.memories) == 2

        # Forget topic "quantum"
        result = mem.forget(topic="quantum")
        assert len(result["removed"]) == 1
        assert len(mem.memories) == 1

        # Reload — "quantum" memory must NOT resurrect
        mem2 = _reload_system(ws)
        assert len(mem2.memories) == 1, f"Expected 1 memory after reload, got {len(mem2.memories)}"
        assert "quantum" not in mem2.memories[0].content.lower()

    def test_forget_entity_persists_across_reload(self, tmp_path):
        ws = str(tmp_path)
        mem = _make_system(ws)
        mem.ingest("Alice designed the new authentication module for the platform", source="notes")
        mem.ingest("Bob reviewed the authentication module code and approved it", source="notes")
        mem.save()
        assert len(mem.memories) == 2

        # Forget entity "Alice"
        result = mem.forget(entity="Alice")
        assert len(result["removed"]) >= 1

        remaining_before = len(mem.memories)

        # Reload — "Alice" memory must NOT resurrect
        mem2 = _reload_system(ws)
        assert len(mem2.memories) == remaining_before
        for m in mem2.memories:
            assert "Alice" not in m.content

    def test_forget_before_date_persists_across_reload(self, tmp_path):
        ws = str(tmp_path)
        mem = _make_system(ws)
        mem.ingest("Very old memory about legacy systems from the early days of computing", source="archive")
        mem.ingest("Recent memory about modern cloud native architecture and deployment", source="current")
        mem.save()

        initial_count = len(mem.memories)
        assert initial_count >= 1  # at least some survived gating

        # Forget everything before tomorrow (should clear all)
        from datetime import datetime, timedelta, timezone
        tomorrow = (datetime.now(timezone.utc) + timedelta(days=1)).strftime("%Y-%m-%d")
        result = mem.forget(before_date=tomorrow)
        assert len(mem.memories) == 0

        # Reload — nothing should come back
        mem2 = _reload_system(ws)
        assert len(mem2.memories) == 0, f"Expected 0 memories after reload, got {len(mem2.memories)}"


# ── no resurrection via weekly shards after mutation ────────────────────


class TestNoResurrection:
    """Combined tests proving memories cannot come back after mutation + reload."""

    def test_ingest_delete_reload_cycle(self, tmp_path):
        """Full lifecycle: ingest → save → delete → reload → verify gone."""
        ws = str(tmp_path)

        # Phase 1: ingest
        mem = _make_system(ws)
        mem.ingest("Confidential project plan for Q3 budget allocation and review", source="plan", source_url="http://plan.com")
        mem.ingest("Public roadmap for the new product feature release schedule", source="roadmap", source_url="http://roadmap.com")
        mem.save()
        assert len(mem.memories) == 2

        # Phase 2: delete one source
        mem.delete_source("http://plan.com")
        assert len(mem.memories) == 1

        # Phase 3: reload
        mem2 = _reload_system(ws)
        assert len(mem2.memories) == 1
        assert "roadmap" in mem2.memories[0].content.lower()

        # Phase 4: forget the remaining one
        mem2.forget(topic="roadmap")
        assert len(mem2.memories) == 0

        # Phase 5: reload again
        mem3 = _reload_system(ws)
        assert len(mem3.memories) == 0

    def test_multiple_mutations_persist(self, tmp_path):
        """Multiple rounds of ingest-and-delete, each persisted correctly."""
        ws = str(tmp_path)
        mem = _make_system(ws)

        # Round 1
        mem.ingest("First batch of memories about machine learning algorithms", source="batch1", source_url="http://batch1.com")
        mem.save()
        mem.delete_source("http://batch1.com")
        assert len(mem.memories) == 0

        # Round 2
        mem.ingest("Second batch of memories about database optimization techniques", source="batch2", source_url="http://batch2.com")
        mem.save()

        # Reload — only batch2 should exist
        mem2 = _reload_system(ws)
        assert len(mem2.memories) == 1
        assert "database" in mem2.memories[0].content.lower()

    def test_compact_does_not_resurrect(self, tmp_path):
        """compact() should not bring back forgotten memories."""
        ws = str(tmp_path)
        mem = _make_system(ws)
        mem.ingest("Memory that will be forgotten about neural network training", source="test")
        mem.ingest("Memory that will survive about distributed systems design patterns", source="test")
        mem.save()
        assert len(mem.memories) == 2

        mem.forget(topic="neural")
        assert len(mem.memories) == 1

        # Compact should maintain the post-forget state
        mem.compact()

        mem2 = _reload_system(ws)
        assert len(mem2.memories) == 1
        assert "neural" not in mem2.memories[0].content.lower()

    def test_flush_does_not_resurrect(self, tmp_path):
        """flush() should not bring back forgotten memories."""
        ws = str(tmp_path)
        mem = _make_system(ws)
        mem.ingest("Temporary memory about experimental feature flag configurations", source="test")
        mem.save()

        mem.forget(topic="experimental")
        assert len(mem.memories) == 0

        mem.flush()

        mem2 = _reload_system(ws)
        assert len(mem2.memories) == 0


# ── shards.py rewrite_entries ───────────────────────────────────────────


class TestRewriteEntries:
    """Direct tests for TimeShardManager.rewrite_entries()."""

    def test_rewrite_removes_obsolete_shards(self, tmp_path):
        from parsica_memory.shards import ShardManager as TimeShardManager
        from parsica_memory.entry import MemoryEntry

        ws = str(tmp_path)
        mgr = TimeShardManager(ws)

        # Write two entries
        e1 = MemoryEntry("First entry about cloud computing infrastructure", "test", 1, "general")
        e2 = MemoryEntry("Second entry about container orchestration platforms", "test", 2, "general")
        mgr.write_entry(e1)
        mgr.write_entry(e2)

        shards_before = mgr.list_shards()
        assert len(shards_before) >= 1

        # Rewrite with only e2
        mgr.rewrite_entries([e2])

        # Reload all — only e2 should be present
        all_entries = mgr.load_all_shards()
        assert len(all_entries) == 1
        assert all_entries[0].hash == e2.hash

    def test_rewrite_does_not_overwrite_protected_shards(self, tmp_path):
        """Protected shards must not be rewritten even if hot entries map to them."""
        from parsica_memory.shards import ShardManager as TimeShardManager
        from parsica_memory.entry import MemoryEntry
        from datetime import datetime, timedelta, timezone

        ws = str(tmp_path)
        mgr = TimeShardManager(ws)

        # Create an entry timestamped in the past (simulates warm-tier data)
        old_dt = datetime.now(timezone.utc) - timedelta(days=10)
        old_entry = MemoryEntry("Old warm-tier data that must be preserved intact", "warm", 1, "general")
        old_entry.created = old_dt.isoformat()

        # Write the warm-tier entry to its shard
        mgr.write_entry(old_entry)
        old_shard_name = mgr._shard_name(old_dt)
        assert old_shard_name in mgr.list_shards()

        # Read the original warm shard content
        import json
        with open(os.path.join(ws, old_shard_name)) as f:
            original_lines = [l.strip() for l in f if l.strip()]
        assert len(original_lines) == 1

        # Now create a hot-tier entry whose timestamp ALSO maps to the old shard
        # (simulates a promoted entry or manually backdated entry)
        hot_entry = MemoryEntry("Hot-tier entry that maps to the warm shard week", "hot", 1, "general")
        hot_entry.created = old_dt.isoformat()

        # Rewrite with hot_entry but protect the old shard
        mgr.rewrite_entries([hot_entry], protected_shards={old_shard_name})

        # The protected shard should still contain the original warm data,
        # NOT be overwritten with only the hot entry
        with open(os.path.join(ws, old_shard_name)) as f:
            after_lines = [l.strip() for l in f if l.strip()]

        after_contents = [json.loads(l)["content"] for l in after_lines]
        assert "Old warm-tier data that must be preserved intact" in after_contents, \
            "Protected shard was overwritten — warm data lost"

    def test_rewrite_with_empty_list_removes_all_shards(self, tmp_path):
        from parsica_memory.shards import ShardManager as TimeShardManager
        from parsica_memory.entry import MemoryEntry

        ws = str(tmp_path)
        mgr = TimeShardManager(ws)

        e1 = MemoryEntry("Entry to be completely removed from all shard storage", "test", 1, "general")
        mgr.write_entry(e1)
        assert len(mgr.list_shards()) >= 1

        # Rewrite with empty list
        mgr.rewrite_entries([])

        # All shard files should be removed
        assert len(mgr.list_shards()) == 0
        assert len(mgr.load_all_shards()) == 0


# ── delete_source broken code path (v2.6.1 fix) ────────────────────────


class TestDeleteSourceIndexWALCleanup:
    """Verify the v4.6 index WAL cleanup in delete_source() actually runs."""

    def test_index_wal_purged_after_delete_source(self, tmp_path):
        ws = str(tmp_path)
        mem = _make_system(ws)

        # Ingest something
        mem.ingest("Important document about financial planning and investment strategy", source="test", source_url="http://doc.com")
        mem.save()

        # The index WAL should have an entry
        idx_wal_path = os.path.join(ws, ".parsica_wal.jsonl")
        # May or may not have entries depending on flush state

        # Delete it — this should NOT raise (previously it did: string / operator)
        result = mem.delete_source("http://doc.com")
        assert result["deleted"] == 1
        assert "error" not in result  # No silent errors
