"""Tests for v3.1.8 — Peer-to-peer store sync (PeerSync + SyncResult)."""

import hashlib
import json
import os
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from parsica_memory.sync import PeerSync, SyncResult


def _make_entry(content: str, hours_ago: float = 0, extra: dict = None) -> dict:
    """Build a minimal entry dict matching Parsica conventions."""
    created = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat()
    h = hashlib.md5(f"test:0:{content}".encode()).hexdigest()[:12]
    entry = {
        "hash": h,
        "content": content,
        "source": "test",
        "line": 0,
        "category": "general",
        "created": created,
        "last_accessed": created,
        "access_count": 0,
        "importance": 1.0,
        "confidence": 0.5,
        "sentiment": {},
        "tags": [],
        "related": [],
    }
    if extra:
        entry.update(extra)
    return entry


def _write_shard(store_dir: str, entries: list, shard_name: str = "shard_2026-03_general.json"):
    """Write a shard file into store_dir/shards/."""
    shards_dir = os.path.join(store_dir, "shards")
    os.makedirs(shards_dir, exist_ok=True)
    path = os.path.join(shards_dir, shard_name)
    with open(path, "w") as f:
        json.dump({"memories": entries, "count": len(entries)}, f)


def _write_wal(store_dir: str, entries: list):
    """Write a WAL file into store_dir."""
    wal_path = os.path.join(store_dir, ".parsica_wal.jsonl")
    with open(wal_path, "w") as f:
        for entry in entries:
            f.write(json.dumps(entry) + "\n")


def _read_local_wal(store_dir: str) -> list:
    """Read the local WAL and return list of entry dicts."""
    wal_path = os.path.join(store_dir, ".parsica_wal.jsonl")
    entries = []
    if os.path.exists(wal_path):
        with open(wal_path) as f:
            for line in f:
                stripped = line.strip()
                if stripped:
                    entries.append(json.loads(stripped))
    return entries


class TestPeerSync(unittest.TestCase):
    """Tests for PeerSync.sync()."""

    def setUp(self):
        self._tmpdir = tempfile.mkdtemp()
        # Structure:  workspace/local_store/  and  workspace/peer_store/
        self.local_store = os.path.join(self._tmpdir, "local", "store")
        self.peer_store = os.path.join(self._tmpdir, "peer", "store")
        os.makedirs(os.path.join(self.local_store, "shards"), exist_ok=True)
        os.makedirs(os.path.join(self.peer_store, "shards"), exist_ok=True)

    def tearDown(self):
        import shutil
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    # ── test_sync_new_memories ──────────────────────────────────────────

    def test_sync_new_memories(self):
        """Peer has entries not in local → synced."""
        peer_entries = [
            _make_entry("Alpha memory from peer"),
            _make_entry("Beta memory from peer"),
        ]
        _write_shard(self.peer_store, peer_entries)

        ps = PeerSync(self.local_store)
        result = ps.sync(hours=24, peers=[self.peer_store])

        self.assertEqual(result.synced, 2)
        self.assertEqual(result.skipped, 0)
        self.assertEqual(len(result.errors), 0)

        # Verify entries landed in local WAL
        wal = _read_local_wal(self.local_store)
        self.assertEqual(len(wal), 2)

    # ── test_sync_dedup_by_hash ─────────────────────────────────────────

    def test_sync_dedup_by_hash(self):
        """Peer has same hash as local → skipped."""
        shared_entry = _make_entry("Shared knowledge between peers")
        # Write to both local and peer
        _write_shard(self.local_store, [shared_entry])
        _write_shard(self.peer_store, [shared_entry])

        ps = PeerSync(self.local_store)
        result = ps.sync(hours=24, peers=[self.peer_store])

        self.assertEqual(result.synced, 0)
        self.assertEqual(result.skipped, 1)

    # ── test_sync_provenance ────────────────────────────────────────────

    def test_sync_provenance(self):
        """Synced entries have synced_from field set to peer path."""
        peer_entries = [_make_entry("Memory with provenance tracking")]
        _write_shard(self.peer_store, peer_entries)

        ps = PeerSync(self.local_store)
        ps.sync(hours=24, peers=[self.peer_store])

        wal = _read_local_wal(self.local_store)
        self.assertEqual(len(wal), 1)
        self.assertIn("synced_from", wal[0])
        self.assertEqual(wal[0]["synced_from"], os.path.abspath(self.peer_store))

    # ── test_sync_respects_time_window ──────────────────────────────────

    def test_sync_respects_time_window(self):
        """Old entries outside the time window are skipped."""
        recent = _make_entry("Recent entry", hours_ago=2)
        old = _make_entry("Old entry from days ago", hours_ago=48)
        _write_shard(self.peer_store, [recent, old])

        ps = PeerSync(self.local_store)
        result = ps.sync(hours=6, peers=[self.peer_store])

        # Only the recent entry should be synced
        self.assertEqual(result.synced, 1)
        wal = _read_local_wal(self.local_store)
        self.assertEqual(wal[0]["content"], "Recent entry")

    # ── test_sync_hours_validation ──────────────────────────────────────

    def test_sync_hours_validation(self):
        """hours > 24 or < 1 raises ValueError."""
        ps = PeerSync(self.local_store)

        with self.assertRaises(ValueError):
            ps.sync(hours=25, peers=[self.peer_store])

        with self.assertRaises(ValueError):
            ps.sync(hours=0, peers=[self.peer_store])

        with self.assertRaises(ValueError):
            ps.sync(hours=-1, peers=[self.peer_store])

    # ── test_sync_missing_peer ──────────────────────────────────────────

    def test_sync_missing_peer(self):
        """Nonexistent peer path → error in SyncResult, not crash."""
        ps = PeerSync(self.local_store)
        result = ps.sync(hours=24, peers=["/nonexistent/path/to/peer"])

        self.assertEqual(result.synced, 0)
        self.assertGreater(len(result.errors), 0)
        self.assertIn("not found", result.errors[0])

    # ── test_sync_empty_peer ────────────────────────────────────────────

    def test_sync_empty_peer(self):
        """Peer with no shards → SyncResult with 0 synced."""
        ps = PeerSync(self.local_store)
        result = ps.sync(hours=24, peers=[self.peer_store])

        self.assertEqual(result.synced, 0)
        self.assertEqual(result.skipped, 0)
        self.assertEqual(len(result.errors), 0)

    # ── test_sync_reads_wal ─────────────────────────────────────────────

    def test_sync_reads_wal(self):
        """Entries in peer WAL (not yet in shards) are also synced."""
        wal_entry = _make_entry("WAL-only entry on peer")
        _write_wal(self.peer_store, [wal_entry])

        ps = PeerSync(self.local_store)
        result = ps.sync(hours=24, peers=[self.peer_store])

        self.assertEqual(result.synced, 1)
        wal = _read_local_wal(self.local_store)
        self.assertEqual(wal[0]["content"], "WAL-only entry on peer")

    # ── test_sync_idempotent ────────────────────────────────────────────

    def test_sync_idempotent(self):
        """Running sync twice gives 0 new on second run."""
        peer_entries = [_make_entry("Idempotency test entry")]
        _write_shard(self.peer_store, peer_entries)

        ps = PeerSync(self.local_store)
        result1 = ps.sync(hours=24, peers=[self.peer_store])
        self.assertEqual(result1.synced, 1)

        # Second sync — the entry is now in local WAL so should be skipped
        result2 = ps.sync(hours=24, peers=[self.peer_store])
        self.assertEqual(result2.synced, 0)
        self.assertEqual(result2.skipped, 1)

    # ── test_sync_result_accuracy ───────────────────────────────────────

    def test_sync_result_accuracy(self):
        """Counts in SyncResult match actual operations."""
        # 3 entries on peer; 1 already in local
        e1 = _make_entry("Unique entry 1")
        e2 = _make_entry("Unique entry 2")
        e_shared = _make_entry("Shared entry")

        _write_shard(self.local_store, [e_shared])
        _write_shard(self.peer_store, [e1, e2, e_shared])

        ps = PeerSync(self.local_store)
        result = ps.sync(hours=24, peers=[self.peer_store])

        self.assertEqual(result.synced, 2)
        self.assertEqual(result.skipped, 1)
        self.assertEqual(len(result.errors), 0)

        wal = _read_local_wal(self.local_store)
        self.assertEqual(len(wal), 2)


class TestDailyLogSync(unittest.TestCase):
    """Tests for PeerSync.sync_daily_logs()."""

    def setUp(self):
        self._tmpdir = tempfile.mkdtemp()
        # Stores live inside a workspace directory:
        #   workspace/store/  (the store dir passed to PeerSync)
        #   workspace/memory/ (daily logs — sibling of store, relative to parent)
        self.local_ws = os.path.join(self._tmpdir, "local")
        self.local_store = os.path.join(self.local_ws, "store")
        self.local_memory = os.path.join(self.local_ws, "memory")
        os.makedirs(self.local_store, exist_ok=True)
        os.makedirs(self.local_memory, exist_ok=True)

        self.peer_ws = os.path.join(self._tmpdir, "peer")
        self.peer_store = os.path.join(self.peer_ws, "store")
        self.peer_memory = os.path.join(self.peer_ws, "memory")
        os.makedirs(self.peer_store, exist_ok=True)
        os.makedirs(self.peer_memory, exist_ok=True)

    def tearDown(self):
        import shutil
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    def _today_filename(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d") + ".md"

    # ── test_daily_log_merge ────────────────────────────────────────────

    def test_daily_log_merge(self):
        """Merges new lines, skips duplicates."""
        fname = self._today_filename()

        # Local has 2 lines
        with open(os.path.join(self.local_memory, fname), "w") as f:
            f.write("Line A\nLine B\n")

        # Peer has 3 lines (2 overlap, 1 new)
        with open(os.path.join(self.peer_memory, fname), "w") as f:
            f.write("Line A\nLine B\nLine C\n")

        ps = PeerSync(self.local_store)
        merged = ps.sync_daily_logs(hours=24, peers=[self.peer_store])

        self.assertEqual(merged, 1)  # Only "Line C" is new

        with open(os.path.join(self.local_memory, fname)) as f:
            lines = f.read().splitlines()
        self.assertEqual(len(lines), 3)
        self.assertIn("Line C", lines)

    # ── test_daily_log_preserves_order ──────────────────────────────────

    def test_daily_log_preserves_order(self):
        """Chronological order is maintained — existing first, new appended."""
        fname = self._today_filename()

        with open(os.path.join(self.local_memory, fname), "w") as f:
            f.write("08:00 Morning standup\n09:00 Code review\n")

        with open(os.path.join(self.peer_memory, fname), "w") as f:
            f.write("08:00 Morning standup\n10:00 Deploy to staging\n")

        ps = PeerSync(self.local_store)
        ps.sync_daily_logs(hours=24, peers=[self.peer_store])

        with open(os.path.join(self.local_memory, fname)) as f:
            lines = f.read().splitlines()

        # Existing lines come first, then the new appended line
        self.assertEqual(lines[0], "08:00 Morning standup")
        self.assertEqual(lines[1], "09:00 Code review")
        self.assertEqual(lines[2], "10:00 Deploy to staging")


class TestSyncResult(unittest.TestCase):
    """SyncResult dataclass sanity checks."""

    def test_defaults(self):
        r = SyncResult()
        self.assertEqual(r.synced, 0)
        self.assertEqual(r.skipped, 0)
        self.assertEqual(r.errors, [])
        self.assertEqual(r.log_lines_merged, 0)

    def test_mutable_errors_list(self):
        """Each SyncResult gets its own errors list (not shared)."""
        r1 = SyncResult()
        r2 = SyncResult()
        r1.errors.append("oops")
        self.assertEqual(len(r2.errors), 0)


if __name__ == "__main__":
    unittest.main()
