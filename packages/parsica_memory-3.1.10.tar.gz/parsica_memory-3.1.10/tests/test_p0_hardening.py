import json
import os
import tempfile
import unittest.mock

import pytest

from parsica_memory import MemorySystem
from parsica_memory.manager import MemoryManager
from parsica_memory.performance import WALManager


def test_memory_manager_user_paths_are_contained_and_deterministic():
    """v3.0: path containment REJECTS invalid user_ids."""
    tmp = tempfile.mkdtemp()
    mm = MemoryManager(tmp)
    with pytest.raises(ValueError):
        mm._user_path("../../escaped_test_pm")
    safe_path = mm._user_path("safe_user_123")
    root = os.path.realpath(tmp)
    assert os.path.realpath(str(safe_path)).startswith(root + os.sep)


def test_memory_manager_clear_does_not_escape_store_root():
    """v3.0: invalid user_ids rejected, traversal impossible."""
    tmp = tempfile.mkdtemp()
    mm = MemoryManager(tmp)
    with pytest.raises(ValueError):
        mm._user_path("../../escaped_test_pm")


def test_wal_append_is_durable_on_each_write():
    tmp = tempfile.mkdtemp()
    wal = WALManager(tmp)
    wal.append({"hash": "abc123", "content": "durable wal entry"})

    assert os.path.exists(wal.wal_path)
    with open(wal.wal_path, encoding="utf-8") as fh:
        data = fh.read()
    assert "durable wal entry" in data


def test_flush_rewrites_wal_to_keep_only_new_entries_added_during_flush():
    tmp = tempfile.mkdtemp()
    mem = MemorySystem(workspace=tmp, agent_name="test-agent")
    mem._wal.flush_interval = 10_000
    mem.ingest("First flush target memory entry alpha beta", source="test")
    initial_pending = mem._wal.load_pending()
    assert len(initial_pending) == 1

    original_save = mem.save

    def save_with_concurrent_append():
        result = original_save()
        mem._wal.append({
            "hash": "late-entry-hash",
            "content": "late entry appended during flush",
            "source": "test",
            "category": "general",
        })
        return result

    mem.save = save_with_concurrent_append
    result = mem.flush()

    assert result["flushed_entries"] == 1
    pending_after = mem._wal.load_pending()
    assert len(pending_after) == 1
    assert pending_after[0]["hash"] == "late-entry-hash"



def test_compact_rewrites_wal_to_keep_only_new_entries_added_during_compaction():
    tmp = tempfile.mkdtemp()
    mem = MemorySystem(workspace=tmp, agent_name="test-agent")
    mem._wal.flush_interval = 10_000
    mem.ingest("Compaction target memory entry alpha beta gamma", source="test")

    original_save = mem.save

    def save_with_concurrent_append():
        result = original_save()
        mem._wal.append({
            "hash": "late-compact-hash",
            "content": "late entry appended during compact",
            "source": "test",
            "category": "general",
        })
        return result

    mem.save = save_with_concurrent_append
    mem.compact()

    pending_after = mem._wal.load_pending()
    assert len(pending_after) == 1
    assert pending_after[0]["hash"] == "late-compact-hash"



def test_sharded_save_removes_obsolete_shards_and_prevents_deleted_memory_resurrection():
    tmp = tempfile.mkdtemp()
    mem = MemorySystem(workspace=tmp, agent_name="test-agent")
    mem._wal.flush_interval = 10_000

    mem.ingest("Shard deletion memory one topic alpha beta gamma", source="test", category="topic-a")
    mem.ingest("Shard deletion memory two topic delta epsilon zeta", source="test", category="topic-b")
    mem.save()

    shards_dir = os.path.join(tmp, "shards")
    shard_files_before = sorted(f for f in os.listdir(shards_dir) if f.endswith(".json"))
    assert len(shard_files_before) == 2

    mem.memories = [m for m in mem.memories if m.category != "topic-b"]
    mem._hashes = {m.hash for m in mem.memories}
    mem._content_norms = {m.content.strip().lower() for m in mem.memories}
    mem._wal.clear()  # simulate deletion having been durably incorporated before reload
    mem.save()

    shard_files_after = sorted(f for f in os.listdir(shards_dir) if f.endswith(".json"))
    assert len(shard_files_after) == 1

    reloaded = MemorySystem(workspace=tmp, agent_name="test-agent")
    contents = [m.content for m in reloaded.memories]
    assert any("memory one" in c for c in contents)
    assert not any("memory two" in c for c in contents)


# ==========================================================================
# P0-1 hardened edge-case tests: path traversal
# ==========================================================================

@pytest.mark.parametrize("malicious_id", [
    "../sibling",
    "../../grandparent",
    "/etc/passwd",
    "foo/../../bar",
    ".",
    "..",
    "normal/../../../escape",
    "\x00null",
    "a" * 500,   # very long
    "",
])
def test_user_path_always_contained_for_adversarial_ids(malicious_id):
    """Every user_id, no matter how adversarial, must resolve under the store root."""
    tmp = tempfile.mkdtemp()
    mm = MemoryManager(tmp)
    root = os.path.realpath(tmp)

    # _user_path should either return a path under root or raise ValueError
    try:
        user_path = mm._user_path(malicious_id)
        resolved = os.path.realpath(str(user_path))
        assert resolved.startswith(root + os.sep), (
            f"user_id={malicious_id!r} resolved to {resolved} which escapes root {root}"
        )
    except ValueError:
        pass  # explicitly rejected — that's fine


def test_different_user_ids_map_to_different_paths():
    """Two distinct user IDs must never collide in the filesystem."""
    tmp = tempfile.mkdtemp()
    mm = MemoryManager(tmp)
    p1 = mm._user_path("alice")
    p2 = mm._user_path("bob")
    assert p1 != p2


def test_same_user_id_is_deterministic():
    """Same user_id must always resolve to the same path."""
    tmp = tempfile.mkdtemp()
    mm = MemoryManager(tmp)
    assert mm._user_path("user-123") == mm._user_path("user-123")


# ==========================================================================
# P0-2 hardened edge-case tests: WAL durability
# ==========================================================================

def test_wal_survives_multiple_appends():
    """All appended entries must be recoverable from disk after multiple writes."""
    tmp = tempfile.mkdtemp()
    wal = WALManager(tmp)

    for i in range(10):
        wal.append({"hash": f"h{i}", "content": f"entry-{i}"})

    pending = wal.load_pending()
    assert len(pending) == 10
    for i in range(10):
        assert pending[i]["hash"] == f"h{i}"


def test_flush_preserves_wal_when_save_fails():
    """If save() raises, the WAL must NOT be cleared — entries must survive."""
    tmp = tempfile.mkdtemp()
    mem = MemorySystem(workspace=tmp, agent_name="test-agent")
    mem._wal.flush_interval = 10_000  # prevent auto-flush

    # Ingest a memory (goes to WAL)
    mem.ingest("Critical data that must not be lost alpha beta gamma", source="test")
    wal_before = mem._wal.load_pending()
    assert len(wal_before) == 1

    # Make save() fail
    with unittest.mock.patch.object(mem, "save", side_effect=IOError("disk full")):
        try:
            mem.flush()
        except IOError:
            pass

    # WAL must still contain the entry
    wal_after = mem._wal.load_pending()
    assert len(wal_after) >= 1, "WAL was cleared despite save() failure — data loss!"
    assert any("Critical data" in e.get("content", "") for e in wal_after)


def test_compact_preserves_wal_when_save_fails():
    """If save() raises during compact, the WAL must NOT be cleared."""
    tmp = tempfile.mkdtemp()
    mem = MemorySystem(workspace=tmp, agent_name="test-agent")
    mem._wal.flush_interval = 10_000

    mem.ingest("Compaction safety test memory alpha beta gamma delta", source="test")
    wal_before = mem._wal.load_pending()
    assert len(wal_before) == 1

    with unittest.mock.patch.object(mem, "save", side_effect=IOError("disk full")):
        try:
            mem.compact()
        except IOError:
            pass

    wal_after = mem._wal.load_pending()
    assert len(wal_after) >= 1, "WAL was cleared despite save() failure in compact — data loss!"


def test_wal_replay_deduplicates():
    """WAL replay must not produce duplicate memories (idempotency invariant)."""
    tmp = tempfile.mkdtemp()
    mem = MemorySystem(workspace=tmp, agent_name="test-agent")
    mem._wal.flush_interval = 10_000

    mem.ingest("Dedup test memory entry alpha beta gamma delta epsilon", source="test")
    mem.save()
    count_after_save = len(mem.memories)

    # Manually append the same entry hash to the WAL (simulates crash-before-clear)
    existing_entry = mem.memories[0]
    mem._wal.append(existing_entry.to_dict())

    # Reload — should not produce a duplicate
    reloaded = MemorySystem(workspace=tmp, agent_name="test-agent")
    assert len(reloaded.memories) == count_after_save


# ==========================================================================
# P0-3 hardened edge-case tests: shard resurrection
# ==========================================================================

def test_forget_then_save_removes_shard_and_prevents_resurrection():
    """Using forget() followed by save() must remove the obsolete shard file.

    forget_topic() matches on content text, so we use a topic string that
    appears in the content of the entries we want removed.
    """
    tmp = tempfile.mkdtemp()
    mem = MemorySystem(workspace=tmp, agent_name="test-agent")
    mem._wal.flush_interval = 10_000

    # "removeme" appears in the content so forget_topic will match it
    mem.ingest("removeme target memory alpha beta gamma delta epsilon", source="test", category="removeme")
    mem.ingest("Keep this memory alpha beta gamma delta zeta eta theta", source="test", category="keepme")
    mem.save()

    shards_dir = os.path.join(tmp, "shards")
    files_before = set(f for f in os.listdir(shards_dir) if f.startswith("shard_"))
    assert len(files_before) == 2

    # Forget all memories whose content contains "removeme"
    result = mem.forget(topic="removeme")
    assert len(result["removed"]) == 1, f"Expected 1 removed, got {len(result['removed'])}"
    mem.save()

    files_after = set(f for f in os.listdir(shards_dir) if f.startswith("shard_"))
    assert len(files_after) < len(files_before), "Obsolete shard file was not removed after forget()"

    # Reload and verify no resurrection
    reloaded = MemorySystem(workspace=tmp, agent_name="test-agent")
    contents = [m.content for m in reloaded.memories]
    assert not any("removeme" in c for c in contents), "Deleted memory resurrected after reload!"
    assert any("Keep this" in c for c in contents)


def test_shard_index_is_cleaned_after_obsolete_shard_removal():
    """The shard index must not reference shards that have been deleted."""
    tmp = tempfile.mkdtemp()
    mem = MemorySystem(workspace=tmp, agent_name="test-agent")
    mem._wal.flush_interval = 10_000

    mem.ingest("Index cleanup test memory alpha beta gamma", source="test", category="cat-a")
    mem.ingest("Index cleanup test memory two delta epsilon", source="test", category="cat-b")
    mem.save()

    # Delete all cat-b memories
    mem.memories = [m for m in mem.memories if m.category != "cat-b"]
    mem._hashes = {m.hash for m in mem.memories}
    mem.save()

    # Check that the shard index on disk only references existing files
    index_path = os.path.join(tmp, "memory_index.json")
    if os.path.exists(index_path):
        with open(index_path) as f:
            index_data = json.load(f)
        shards_dir = os.path.join(tmp, "shards")
        for shard_info in index_data.get("shards", []):
            shard_file = os.path.join(shards_dir, shard_info["filename"])
            assert os.path.exists(shard_file), (
                f"Shard index references non-existent file: {shard_info['filename']}"
            )
