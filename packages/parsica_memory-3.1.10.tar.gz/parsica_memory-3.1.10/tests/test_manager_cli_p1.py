import json
from types import SimpleNamespace

from parsica_memory.cli import cmd_init
from parsica_memory.manager import MemoryManager


def test_manager_export_exports_real_entries(tmp_path):
    store = tmp_path / "store"
    out = tmp_path / "export.json"

    mm = MemoryManager(str(store))
    assert mm.ingest_raw("user-a", "Important launch note that should be exported.") is True
    assert mm.ingest_raw("user-a", "Another durable memory entry for export coverage.") is True

    count = mm.export("user-a", str(out))
    payload = json.loads(out.read_text())

    assert count == 2
    assert payload["entry_count"] == 2
    assert len(payload["entries"]) == 2
    assert any("Important launch note" in e["content"] for e in payload["entries"])


def test_manager_stats_discovers_users_from_disk_after_restart(tmp_path):
    store = tmp_path / "store"

    mm1 = MemoryManager(str(store))
    assert mm1.ingest_raw("user-one", "User one durable note that survives restart.") is True
    assert mm1.ingest_raw("user-two", "User two durable note that survives restart.") is True

    mm2 = MemoryManager(str(store))
    stats = mm2.stats()

    assert stats["user_count"] == 2
    assert stats["total_entries"] == 2
    assert len(stats["per_user"]) == 2
    assert sorted(stats["per_user"].values()) == [1, 1]


def test_cli_init_non_tty_falls_back_to_headless(tmp_path, monkeypatch, capsys):
    workspace = tmp_path / "workspace"
    args = SimpleNamespace(
        workspace=str(workspace),
        agent_name="ci-agent",
        force=False,
        headless=False,
    )

    monkeypatch.setattr("parsica_memory.cli.sys.stdin.isatty", lambda: False)
    monkeypatch.setattr("parsica_memory.cli.sys.stdout.isatty", lambda: False)

    code = cmd_init(args)
    out = capsys.readouterr().out

    assert code == 0
    assert "falling back to --headless" in out.lower()
    assert (workspace / "parsica_config.json").exists() or (workspace / "antaris_config.json").exists()

    config_name = "parsica_config.json" if (workspace / "parsica_config.json").exists() else "antaris_config.json"
    cfg = json.loads((workspace / config_name).read_text())
    assert cfg["agent_name"] == "ci-agent"
