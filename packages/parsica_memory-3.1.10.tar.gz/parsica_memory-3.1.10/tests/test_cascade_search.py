"""Tests for v3.1.7 — Archive enrichment + cascade search."""

import json
import os
import sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from parsica_memory import MemorySystem
from parsica_memory.archive import ConversationArchive


# --- Archive enrichment ---

def test_enrich_summary_called_during_rotate(tmp_path):
    """When an enricher is set, rotate() should call it on summaries."""
    enrichment_calls = []

    def mock_enricher(text):
        enrichment_calls.append(text)
        return {
            "search_queries": ["test query 1", "test query 2"],
            "search_keywords": ["keyword1", "keyword2"],
        }

    archive = ConversationArchive(str(tmp_path), enricher=mock_enricher, retention_days=0)

    # Create an old daily file
    today = datetime.now()
    old_day = (today - timedelta(days=1)).strftime("%Y-%m-%d")
    daily_path = os.path.join(str(tmp_path), "memory", f"{old_day}.md")
    with open(daily_path, "w") as f:
        f.write("## checkpoint\n- user: Hello world\n- assistant: Hi there\n")

    archive.rotate()

    assert len(enrichment_calls) > 0
    # Check archive.md contains the enrichment
    archive_content = open(archive.archive_path).read()
    assert "**Queries:**" in archive_content
    assert "test query 1" in archive_content
    assert "**Keywords:**" in archive_content
    assert "keyword1" in archive_content


def test_enrich_summary_graceful_when_no_enricher(tmp_path):
    """Without enricher, rotate works normally without enrichment lines."""
    archive = ConversationArchive(str(tmp_path), retention_days=0)

    today = datetime.now()
    old_day = (today - timedelta(days=1)).strftime("%Y-%m-%d")
    daily_path = os.path.join(str(tmp_path), "memory", f"{old_day}.md")
    with open(daily_path, "w") as f:
        f.write("## checkpoint\n- user: Test content\n")

    archive.rotate()

    archive_content = open(archive.archive_path).read()
    assert "**Queries:**" not in archive_content
    assert "Summary" in archive_content


def test_enrich_summary_handles_enricher_failure(tmp_path):
    """If enricher raises, rotation still succeeds without enrichment."""

    def broken_enricher(text):
        raise RuntimeError("API down")

    archive = ConversationArchive(str(tmp_path), enricher=broken_enricher, retention_days=0)

    today = datetime.now()
    old_day = (today - timedelta(days=1)).strftime("%Y-%m-%d")
    daily_path = os.path.join(str(tmp_path), "memory", f"{old_day}.md")
    with open(daily_path, "w") as f:
        f.write("## checkpoint\n- user: Test content\n")

    # Should not raise
    rotated = archive.rotate()
    assert rotated == 1
    assert os.path.exists(archive.archive_path)


def test_enriched_terms_searchable_in_archive(tmp_path):
    """Enriched queries/keywords in archive should be BM25-searchable."""

    def mock_enricher(text):
        return {
            "search_queries": ["vegetarian restaurant recommendations"],
            "search_keywords": ["vegetarian", "restaurant", "dining"],
        }

    archive = ConversationArchive(str(tmp_path), enricher=mock_enricher, retention_days=0)

    today = datetime.now()
    old_day = (today - timedelta(days=1)).strftime("%Y-%m-%d")
    daily_path = os.path.join(str(tmp_path), "memory", f"{old_day}.md")
    with open(daily_path, "w") as f:
        f.write("## checkpoint\n- user: I prefer plant-based meals when eating out\n")

    archive.rotate()

    # Search using enriched vocabulary (not in original text)
    results = archive.search_archive("vegetarian restaurant")
    assert len(results) > 0
    assert results[0]["score"] > 0


def test_set_doc2query_enricher(tmp_path):
    """set_doc2query_enricher should update the enricher callable."""
    archive = ConversationArchive(str(tmp_path))
    assert archive._enricher is None

    def my_enricher(text):
        return {"search_queries": [], "search_keywords": []}

    archive.set_doc2query_enricher(my_enricher)
    assert archive._enricher is my_enricher

    archive.set_doc2query_enricher(None)
    assert archive._enricher is None


# --- Cascade search ---

def test_cascade_search_never_mode(tmp_path):
    """include_archive='never' should not touch archive even with weak results."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("The sky is blue", source="test")
    mem.save()

    # Create archive with different content
    archive_dir = os.path.join(str(tmp_path), "memory")
    os.makedirs(archive_dir, exist_ok=True)
    with open(os.path.join(archive_dir, "archive.md"), "w") as f:
        f.write("# 2026\n## March\n### 2026-03-01\n#### Summary\n- Discussed pizza preferences\n")

    results = mem.search("pizza preferences", include_archive="never")
    # Should NOT find archive content
    archive_hits = [r for r in results if getattr(r, 'source', '') == 'archive']
    assert len(archive_hits) == 0


def test_cascade_search_always_mode(tmp_path):
    """include_archive='always' should include archive results."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("The sky is blue", source="test")
    mem.save()

    archive_dir = os.path.join(str(tmp_path), "memory")
    os.makedirs(archive_dir, exist_ok=True)
    with open(os.path.join(archive_dir, "archive.md"), "w") as f:
        f.write("# 2026\n## March\n### 2026-03-01\n#### Summary\n- Discussed pizza preferences and toppings\n")

    results = mem.search("pizza preferences toppings", include_archive="always")
    archive_hits = [r for r in results if getattr(r, 'source', '') == 'archive']
    assert len(archive_hits) > 0


def test_cascade_search_auto_mode_with_weak_results(tmp_path):
    """include_archive='auto' should cascade when main results are insufficient."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    # Only one unrelated memory in main store
    mem.ingest("The weather is sunny today", source="test")
    mem.save()

    archive_dir = os.path.join(str(tmp_path), "memory")
    os.makedirs(archive_dir, exist_ok=True)
    with open(os.path.join(archive_dir, "archive.md"), "w") as f:
        f.write("# 2026\n## March\n### 2026-03-01\n#### Summary\n- Discussed favorite Italian restaurants and pasta recipes\n")

    # Search for something only in the archive — main store has nothing relevant
    results = mem.search("Italian restaurants pasta", limit=5, include_archive="auto")
    # Should cascade and find archive content since main has < limit//2 relevant results
    contents = [getattr(r, 'content', '') for r in results]
    assert any("Italian" in c or "pasta" in c for c in contents)


def test_cascade_search_does_not_break_on_missing_archive(tmp_path):
    """Cascade should handle missing archive gracefully."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("Test content", source="test")
    mem.save()

    # No archive exists — should not crash
    results = mem.search("test", include_archive="always")
    assert isinstance(results, list)


def test_cascade_default_is_never(tmp_path):
    """Default include_archive should be 'never' for backward compat."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("Test content", source="test")
    mem.save()

    # Default search should not cascade
    results = mem.search("test")
    assert isinstance(results, list)
