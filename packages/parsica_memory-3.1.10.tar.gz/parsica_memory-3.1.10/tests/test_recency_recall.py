from datetime import datetime, timedelta, timezone

from parsica_memory.entry import MemoryEntry
from parsica_memory.search import SearchEngine, SearchResult


def _entry(content: str, hours_ago: float, hash_value: str) -> MemoryEntry:
    # Use UTC-aware timestamps to match the fixed _parse_created behavior
    created = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat()
    entry = MemoryEntry(content=content, source="test", created=created)
    entry.hash = hash_value
    return entry


def _result(entry: MemoryEntry, score: float = 1.0) -> SearchResult:
    return SearchResult(
        entry=entry,
        score=score,
        relevance=1.0,
        matched_terms=["test"],
        explanation="test",
    )


def test_recency_recall_returns_recent():
    engine = SearchEngine()
    recent = _entry("recent", 0.5, "r1")
    old = _entry("old", 5, "o1")

    results = engine.recency_recall([old, recent], recency_limit=10, recency_window_hours=2)

    assert [e.hash for e in results] == ["r1"]


def test_recency_recall_respects_limit():
    engine = SearchEngine()
    entries = [_entry(f"e{i}", i * 0.1, f"h{i}") for i in range(5)]

    results = engine.recency_recall(entries, recency_limit=3, recency_window_hours=2)

    assert len(results) == 3


def test_recency_recall_sorted_newest_first():
    engine = SearchEngine()
    oldest = _entry("oldest", 1.5, "h1")
    middle = _entry("middle", 1.0, "h2")
    newest = _entry("newest", 0.1, "h3")

    results = engine.recency_recall([middle, oldest, newest], recency_limit=10, recency_window_hours=2)

    assert [e.hash for e in results] == ["h3", "h2", "h1"]


def test_should_skip_when_semantic_covers():
    engine = SearchEngine()
    semantic = [
        _result(_entry("recent1", 0.2, "a")),
        _result(_entry("recent2", 0.4, "b")),
    ]

    assert engine.should_skip_recency(semantic, recency_window_hours=2, recency_limit=4) is True


def test_should_not_skip_when_semantic_lacks_recent():
    engine = SearchEngine()
    semantic = [
        _result(_entry("old1", 5, "a")),
        _result(_entry("old2", 6, "b")),
        _result(_entry("recent", 0.2, "c")),
    ]

    assert engine.should_skip_recency(semantic, recency_window_hours=2, recency_limit=4) is False


def test_recency_dedup_with_semantic():
    engine = SearchEngine()
    shared = _entry("shared", 0.1, "dup")
    extra_recent = _entry("extra", 0.2, "new")
    old_semantic = _entry("semantic", 4, "old")

    combined = engine.combine_semantic_and_recency(
        [_result(shared), _result(old_semantic)],
        [shared, extra_recent, old_semantic],
        recency_limit=3,
        recency_window_hours=2,
    )

    hashes = []
    for item in combined:
        entry = getattr(item, "entry", item)
        hashes.append(entry.hash)

    assert hashes.count("dup") == 1
    assert "new" in hashes
    # All items should be SearchResult (recency entries wrapped)
    for item in combined:
        assert isinstance(item, SearchResult), f"Expected SearchResult, got {type(item)}"


def test_recency_entries_wrapped_in_search_result():
    """Recency-injected entries should be wrapped in SearchResult for type consistency."""
    engine = SearchEngine()
    recent = _entry("recent_only", 0.3, "wrap1")

    combined = engine.combine_semantic_and_recency(
        [],  # no semantic results
        [recent],
        recency_limit=5,
        recency_window_hours=2,
    )

    assert len(combined) == 1
    assert isinstance(combined[0], SearchResult)
    assert combined[0].entry.hash == "wrap1"
    assert combined[0].score == 0.0
    assert "recency_injection" in combined[0].matched_terms


def test_recency_with_naive_timestamps():
    """Naive timestamps (no timezone) should be treated as UTC."""
    engine = SearchEngine()
    # Create entry with naive timestamp (no timezone info)
    naive_ts = (datetime.now(timezone.utc) - timedelta(hours=0.5)).replace(tzinfo=None).isoformat()
    entry = MemoryEntry(content="naive", source="test", created=naive_ts)
    entry.hash = "naive1"

    results = engine.recency_recall([entry], recency_limit=10, recency_window_hours=2)
    assert len(results) == 1
    assert results[0].hash == "naive1"
