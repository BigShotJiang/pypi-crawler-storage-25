#!/usr/bin/env python3
"""
Test fuzzy dedup functionality (Sprint 2).

v5.3.1: Tests for fuzzy dedup, sighting tracking, and confidence threshold filtering.
"""

import json
import tempfile
import shutil
from datetime import datetime
from pathlib import Path

from parsica_memory.core_v4 import MemorySystemV4, _jaccard_similarity
from parsica_memory.entry import MemoryEntry
from parsica_memory.manager import MemoryManager


class TestJaccardSimilarity:
    """Test the Jaccard similarity helper function."""
    
    def test_identical_texts(self):
        """Identical texts should have similarity of 1.0."""
        text = "The cat sat on the mat"
        assert _jaccard_similarity(text, text) == 1.0
    
    def test_completely_different_texts(self):
        """Completely different texts should have similarity of 0.0."""
        text_a = "The cat sat on the mat"
        text_b = "Dogs love playing fetch"
        assert _jaccard_similarity(text_a, text_b) == 0.0
    
    def test_partial_overlap(self):
        """Texts with partial overlap should return proper ratio."""
        text_a = "The cat sat on the mat"
        text_b = "The dog sat on the chair"
        # Common words: "the", "sat", "on", "the" -> 3 unique common words
        # Union: "the", "cat", "sat", "on", "mat", "dog", "chair" -> 7 words
        # Expected: 3/7 ≈ 0.4286
        similarity = _jaccard_similarity(text_a, text_b)
        assert abs(similarity - 3/7) < 0.001
    
    def test_empty_strings(self):
        """Empty strings should return 0.0."""
        assert _jaccard_similarity("", "hello") == 0.0
        assert _jaccard_similarity("hello", "") == 0.0
        assert _jaccard_similarity("", "") == 0.0
    
    def test_case_insensitive(self):
        """Similarity should be case-insensitive."""
        text_a = "The Cat SAT"
        text_b = "the cat sat"
        assert _jaccard_similarity(text_a, text_b) == 1.0


class TestSightingTracking:
    """Test sighting_count and last_sighted fields."""
    
    def test_memory_entry_defaults(self):
        """New entries should have zero sighting count."""
        entry = MemoryEntry("Test content")
        assert entry.sighting_count == 0
        assert entry.last_sighted == ""
    
    def test_serialization_empty(self):
        """Empty sighting data should not be serialized."""
        entry = MemoryEntry("Test content")
        data = entry.to_dict()
        assert "sighting_count" not in data
        assert "last_sighted" not in data
    
    def test_serialization_populated(self):
        """Non-empty sighting data should be serialized."""
        entry = MemoryEntry("Test content")
        entry.sighting_count = 5
        entry.last_sighted = "2026-03-13T17:00:00"
        
        data = entry.to_dict()
        assert data["sighting_count"] == 5
        assert data["last_sighted"] == "2026-03-13T17:00:00"
    
    def test_deserialization(self):
        """Sighting data should deserialize correctly."""
        data = {
            "content": "Test content",
            "sighting_count": 3,
            "last_sighted": "2026-03-13T16:00:00"
        }
        entry = MemoryEntry.from_dict(data)
        assert entry.sighting_count == 3
        assert entry.last_sighted == "2026-03-13T16:00:00"
    
    def test_backward_compatibility(self):
        """Old entries without sighting data should load with defaults."""
        data = {
            "content": "Test content",
            "source": "test",
            "line": 1,
            "category": "general"
        }
        entry = MemoryEntry.from_dict(data)
        assert entry.sighting_count == 0
        assert entry.last_sighted == ""


class TestFuzzyDedup:
    """Test fuzzy deduplication during ingest."""
    
    def setup_method(self):
        """Set up clean memory system for each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.mem = MemorySystemV4(self.temp_dir, agent_name="test")
        self.mem._initialize()
    
    def teardown_method(self):
        """Clean up after each test."""
        if hasattr(self, 'temp_dir'):
            shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_find_similar_fact_exists(self):
        """_find_similar_fact should find existing similar fact."""
        # Add a fact
        self.mem.ingest("The cat likes fish", memory_type="fact")
        
        # Search for similar fact
        result = self.mem._find_similar_fact("The cat loves fish", threshold=0.5)
        assert result is not None
        assert result.content == "The cat likes fish"
    
    def test_find_similar_fact_not_exists(self):
        """_find_similar_fact should return None for different fact."""
        # Add a fact
        self.mem.ingest("The cat likes fish", memory_type="fact")
        
        # Search for completely different fact
        result = self.mem._find_similar_fact("Dogs love playing fetch", threshold=0.5)
        assert result is None
    
    def test_find_similar_fact_only_checks_facts(self):
        """_find_similar_fact should only check fact type memories."""
        # Add a non-fact memory
        self.mem.ingest("The cat likes fish", memory_type="episodic")
        
        # Search should not find it even if similar
        result = self.mem._find_similar_fact("The cat loves fish", threshold=0.5)
        assert result is None
    
    def test_threshold_filtering(self):
        """_find_similar_fact should respect threshold."""
        # Add a fact
        self.mem.ingest("Python is a great programming language", memory_type="fact")
        
        # High threshold should not match
        result = self.mem._find_similar_fact("Python is a great programming language system", threshold=0.9)
        assert result is None  # 6/7 = 0.857 < 0.9
        
        # Lower threshold should match
        result = self.mem._find_similar_fact("Python is a great programming language system", threshold=0.8)
        assert result is not None  # 6/7 = 0.857 > 0.8
    
    def test_dedup_manual_facts(self):
        """Duplicate manual facts should be deduplicated."""
        # Add first fact
        count1 = self.mem.ingest("Python is a great programming language", memory_type="fact")
        assert count1 == 1
        
        # Add similar fact (similarity = 6/7 = 0.857 > 0.85 threshold)
        count2 = self.mem.ingest("Python is a great programming language system", memory_type="fact") 
        assert count2 == 0  # No new entries
        
        # Should only have one memory
        assert len(self.mem.memories) == 1
        
        # Original fact should have increased sighting count
        fact = self.mem.memories[0]
        assert fact.sighting_count == 1
        assert fact.last_sighted != ""
        assert fact.confidence > 0.5  # Should be bumped
    
    def test_dedup_different_facts(self):
        """Different facts should both be stored."""
        # Add first fact
        count1 = self.mem.ingest("The cat likes fish", memory_type="fact")
        assert count1 == 1
        
        # Add different fact
        count2 = self.mem.ingest("Dogs love playing fetch", memory_type="fact")
        assert count2 == 1
        
        # Should have two memories
        assert len(self.mem.memories) == 2
        
        # Neither should have sighting count bumped
        for memory in self.mem.memories:
            assert memory.sighting_count == 0
    
    def test_dedup_decomposed_facts(self):
        """Decomposed facts should also be deduplicated."""
        # Create a memory entry with decomposed provenance
        entry = MemoryEntry("Python is a great programming language", memory_type="fact")
        entry.provenance = "decomposed"
        self.mem.memories.append(entry)
        self.mem._hashes.add(entry.hash)
        # Register in the fact word index so _find_similar_fact can locate it
        self.mem._index_fact(entry)
        
        # Test the dedup logic for similar content
        existing = self.mem._find_similar_fact("Python is a great programming language system", threshold=0.85)
        assert existing is not None
        assert existing.content == "Python is a great programming language"
    
    def test_confidence_boost(self):
        """Deduplicated facts should boost confidence, access count."""
        # Add first fact with low confidence
        self.mem.ingest("Python is a great programming language", memory_type="fact")
        original = self.mem.memories[0]
        original.confidence = 0.6
        original.access_count = 2
        
        # Add similar fact (similarity = 6/7 = 0.857 > 0.85)
        self.mem.ingest("Python is a great programming language system", memory_type="fact")
        
        # Check boosts
        assert original.confidence == 0.65  # 0.6 + 0.05
        assert original.access_count == 3  # 2 + 1
        assert original.sighting_count == 1
    
    def test_confidence_cap(self):
        """Confidence should be capped at 1.0."""
        # Add first fact with high confidence
        self.mem.ingest("Python is a great programming language", memory_type="fact")
        original = self.mem.memories[0]
        original.confidence = 0.98
        
        # Add similar fact (similarity = 6/7 = 0.857 > 0.85)
        self.mem.ingest("Python is a great programming language system", memory_type="fact")
        
        # Confidence should be capped
        assert original.confidence == 1.0


class TestConfidenceThreshold:
    """Test confidence_floor parameter in search."""
    
    def setup_method(self):
        """Set up memory system with test data."""
        self.temp_dir = tempfile.mkdtemp()
        self.mem = MemorySystemV4(self.temp_dir, agent_name="test")
        self.mem._initialize()
        
        # Add memories with different confidence levels
        entry1 = MemoryEntry("High confidence memory", memory_type="fact")
        entry1.confidence = 0.9
        self.mem.memories.append(entry1)
        
        entry2 = MemoryEntry("Medium confidence memory", memory_type="fact")
        entry2.confidence = 0.5
        self.mem.memories.append(entry2)
        
        entry3 = MemoryEntry("Low confidence memory", memory_type="fact")
        entry3.confidence = 0.2
        self.mem.memories.append(entry3)
    
    def teardown_method(self):
        """Clean up after each test."""
        if hasattr(self, 'temp_dir'):
            shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_no_confidence_floor(self):
        """Default confidence_floor=0.0 should return all results."""
        results = self.mem.search("confidence memory", confidence_floor=0.0)
        assert len(results) == 3
    
    def test_medium_confidence_floor(self):
        """Medium confidence floor should filter low confidence."""
        # Assume relevance scores around 0.5-1.0 for matches
        # With confidence 0.5 * relevance ~0.5 = ~0.25, should pass floor 0.2
        # With confidence 0.2 * relevance ~0.5 = ~0.1, should fail floor 0.2
        results = self.mem.search("confidence memory", confidence_floor=0.2)
        assert len(results) >= 2  # High and medium should pass
    
    def test_high_confidence_floor(self):
        """High confidence floor should filter most results."""
        results = self.mem.search("confidence memory", confidence_floor=0.8)
        # Only high confidence * relevance should pass
        assert len(results) >= 0  # Could be 0 or 1 depending on relevance scores
    
    def test_impossible_confidence_floor(self):
        """Impossible confidence floor should return empty results."""
        results = self.mem.search("confidence memory", confidence_floor=2.0)
        assert len(results) == 0
    
    def test_explain_mode_with_confidence_floor(self):
        """Confidence floor should work with explain=True."""
        results = self.mem.search("confidence memory", confidence_floor=0.2, explain=True)
        # Should return SearchResult objects, not just entries
        assert len(results) >= 0
        for result in results:
            assert hasattr(result, 'entry')
            assert hasattr(result, 'score') or hasattr(result, 'relevance')


class TestMemoryManagerIntegration:
    """Test MemoryManager integration with confidence_floor."""
    
    def setup_method(self):
        """Set up memory manager."""
        self.temp_dir = tempfile.mkdtemp()
        self.manager = MemoryManager(self.temp_dir)
        
        # Add test data
        self.manager.ingest_raw("user1", "High confidence fact", memory_type="fact")
        self.manager.ingest_raw("user1", "Low confidence fact", memory_type="fact")
        
        # Manually adjust confidence levels
        store = self.manager._get_store("user1")
        if len(store.memories) >= 2:
            store.memories[0].confidence = 0.9
            store.memories[1].confidence = 0.2
    
    def teardown_method(self):
        """Clean up."""
        if hasattr(self, 'temp_dir'):
            shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_recall_with_confidence_floor(self):
        """MemoryManager.recall should accept confidence_floor."""
        # Test without confidence floor
        results_all = self.manager.recall("user1", "confidence fact")
        
        # Test with confidence floor
        results_filtered = self.manager.recall("user1", "confidence fact", confidence_floor=0.5)
        
        # Should have fewer or equal results with floor
        assert len(results_filtered) <= len(results_all)
    
    def test_search_with_confidence_floor(self):
        """MemoryManager.search should accept confidence_floor."""
        # Test without confidence floor
        results_all = self.manager.search("user1", "confidence fact")
        
        # Test with confidence floor
        results_filtered = self.manager.search("user1", "confidence fact", confidence_floor=0.5)
        
        # Should have fewer or equal results with floor
        assert len(results_filtered) <= len(results_all)
    
    def test_backward_compatibility(self):
        """Methods without confidence_floor should work as before."""
        # Should work without confidence_floor parameter
        recall_results = self.manager.recall("user1", "fact")
        search_results = self.manager.search("user1", "fact")
        
        assert isinstance(recall_results, list)
        assert isinstance(search_results, list)


class TestEdgeCases:
    """Test edge cases and error conditions."""
    
    def setup_method(self):
        """Set up for edge case testing."""
        self.temp_dir = tempfile.mkdtemp()
        self.mem = MemorySystemV4(self.temp_dir, agent_name="test")
        self.mem._initialize()
    
    def teardown_method(self):
        """Clean up."""
        if hasattr(self, 'temp_dir'):
            shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_empty_memories_find_similar(self):
        """_find_similar_fact should handle empty memory store."""
        result = self.mem._find_similar_fact("Test content", threshold=0.5)
        assert result is None
    
    def test_missing_sighting_attributes(self):
        """Should handle entries without sighting attributes gracefully."""
        # Create entry without sighting attributes
        entry = MemoryEntry("Test fact", memory_type="fact")
        delattr(entry, 'sighting_count')  # Simulate old entry
        self.mem.memories.append(entry)
        # Register in the fact word index so _find_similar_fact can locate it
        self.mem._index_fact(entry)
        
        # Should handle missing attribute gracefully in dedup logic
        result = self.mem._find_similar_fact("Test fact similar", threshold=0.5)
        assert result is not None
    
    def test_zero_threshold(self):
        """Threshold of 0.0 should match any non-empty content."""
        self.mem.ingest("Some content", memory_type="fact")
        result = self.mem._find_similar_fact("Completely different", threshold=0.0)
        # Jaccard returns 0.0 for completely different words, so should NOT match
        assert result is None
    
    def test_one_threshold(self):
        """Threshold of 1.0 should only match identical content."""
        self.mem.ingest("Exact content here", memory_type="fact")
        
        # Should not match similar
        result = self.mem._find_similar_fact("Exact content different", threshold=1.0)
        assert result is None
        
        # Should match identical
        result = self.mem._find_similar_fact("Exact content here", threshold=1.0)
        assert result is not None


if __name__ == "__main__":
    # Quick manual test
    print("Running basic fuzzy dedup tests...")
    
    # Test Jaccard similarity
    print("Jaccard similarity tests:")
    assert _jaccard_similarity("the cat sat", "the cat sat") == 1.0
    assert _jaccard_similarity("the cat sat", "the dog sat") > 0
    assert _jaccard_similarity("the cat sat", "birds fly high") == 0.0
    print("✓ Jaccard similarity working")
    
    # Test memory entry sighting tracking
    print("Entry sighting tracking tests:")
    entry = MemoryEntry("Test")
    assert entry.sighting_count == 0
    entry.sighting_count = 3
    data = entry.to_dict()
    assert data["sighting_count"] == 3
    restored = MemoryEntry.from_dict(data)
    assert restored.sighting_count == 3
    print("✓ Sighting tracking working")
    
    print("All basic tests passed!")