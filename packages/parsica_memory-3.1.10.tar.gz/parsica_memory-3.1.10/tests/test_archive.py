"""Tests for parsica_memory.archive — ConversationArchive.

v3.1.6: 20 tests covering checkpoint, summarize, rotate, search_archive,
and get_recent, plus MemorySystem integration.
"""

import os
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta

from parsica_memory.archive import ConversationArchive


class TestConversationArchive(unittest.TestCase):
    """Unit tests for ConversationArchive standalone usage."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.archive = ConversationArchive(self.tmpdir)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    # ── checkpoint ────────────────────────────────────────────────────────

    def test_checkpoint_creates_daily_file(self):
        """Checkpoint creates a memory/YYYY-MM-DD.md file."""
        path = self.archive.checkpoint(
            [{"role": "user", "content": "Need to review the deploy checklist."}],
            "moro",
            "2026-03-28T10:00:00",
        )
        self.assertTrue(os.path.exists(path))
        self.assertIn("2026-03-28.md", path)
        text = open(path, encoding="utf-8").read()
        self.assertIn("deploy checklist", text)

    def test_checkpoint_appends_multiple_entries(self):
        """Multiple checkpoints on the same day append to the same file."""
        self.archive.checkpoint(
            ["first checkpoint"], "moro", "2026-03-28T10:00:00",
        )
        self.archive.checkpoint(
            ["second checkpoint"], "moro", "2026-03-28T14:00:00",
        )
        path = os.path.join(self.tmpdir, "memory", "2026-03-28.md")
        text = open(path, encoding="utf-8").read()
        self.assertIn("first checkpoint", text)
        self.assertIn("second checkpoint", text)

    def test_checkpoint_uses_current_date_when_timestamp_missing(self):
        """Checkpoint without timestamp uses current date."""
        path = self.archive.checkpoint(["hello world"], "moro")
        today = datetime.now().strftime("%Y-%m-%d")
        self.assertIn(today, path)
        self.assertTrue(os.path.exists(path))

    def test_checkpoint_handles_dict_turns(self):
        """Checkpoint handles dict turns with role/content."""
        path = self.archive.checkpoint(
            [{"role": "user", "content": "What is the plan?"},
             {"role": "assistant", "content": "We build the archive system."}],
            "moro",
            "2026-03-28T15:00:00",
        )
        text = open(path, encoding="utf-8").read()
        self.assertIn("What is the plan", text)
        self.assertIn("archive system", text)

    def test_checkpoint_skips_empty_content(self):
        """Turns with empty content are omitted."""
        path = self.archive.checkpoint(
            ["", "   ", "Real content here"],
            "moro",
            "2026-03-28T15:00:00",
        )
        text = open(path, encoding="utf-8").read()
        self.assertIn("Real content here", text)
        # Empty strings should not appear as turn lines
        lines = [l for l in text.splitlines() if l.startswith("- ")]
        self.assertEqual(len(lines), 1)

    # ── summarize ─────────────────────────────────────────────────────────

    def test_summarize_returns_bullet_lines(self):
        """summarize() returns bullet-style lines."""
        summary = self.archive.summarize([
            "user: We need to ship the archive feature this week.",
            "assistant: I will build checkpointing, rotation, and search.",
            "user: Keep it zero dependency and easy to test.",
        ])
        self.assertTrue(len(summary) > 0)
        # Should have at least one bullet line
        self.assertTrue(any(line.strip().startswith("-") for line in summary.splitlines()))

    def test_summarize_uses_callback_when_available(self):
        """When summarizer callback is set, its output is used."""
        archive = ConversationArchive(
            self.tmpdir,
            summarizer=lambda text: "line 1\nline 2\nline 3",
        )
        summary = archive.summarize(["some conversation"])
        self.assertIn("line 1", summary)

    def test_summarize_falls_back_when_callback_fails(self):
        """If summarizer raises, extractive fallback is used."""
        def boom(text):
            raise RuntimeError("API error")

        archive = ConversationArchive(self.tmpdir, summarizer=boom)
        summary = archive.summarize([
            "Important discussion about architecture patterns and memory systems",
        ])
        # Should still produce something
        self.assertTrue(len(summary) > 0)

    def test_summarize_empty_turns(self):
        """Empty turns list returns a no-content message."""
        summary = self.archive.summarize([])
        self.assertTrue(len(summary) > 0)  # Returns a fallback message

    # ── rotate ────────────────────────────────────────────────────────────

    def test_rotate_moves_old_files_to_archive_and_deletes_daily(self):
        """Files older than 7 days are rotated into archive.md and deleted."""
        old_day = (datetime.now() - timedelta(days=8)).date().isoformat()
        self.archive.checkpoint(
            ["Discussed archive rotation strategy"], "moro", f"{old_day}T10:00:00",
        )
        old_path = os.path.join(self.tmpdir, "memory", f"{old_day}.md")
        self.assertTrue(os.path.exists(old_path))

        rotated = self.archive.rotate()
        self.assertGreaterEqual(rotated, 1)
        self.assertFalse(os.path.exists(old_path))

        # archive.md should exist with content
        self.assertTrue(os.path.exists(self.archive.archive_path))
        text = open(self.archive.archive_path, encoding="utf-8").read()
        self.assertIn(old_day, text)

    def test_rotate_keeps_recent_files(self):
        """Files within 7 days are NOT rotated."""
        recent_day = (datetime.now() - timedelta(days=2)).date().isoformat()
        self.archive.checkpoint(
            ["Recent conversation should stay put"], "moro", f"{recent_day}T10:00:00",
        )
        recent_path = os.path.join(self.tmpdir, "memory", f"{recent_day}.md")

        rotated = self.archive.rotate()
        self.assertEqual(rotated, 0)
        self.assertTrue(os.path.exists(recent_path))

    def test_rotate_sorts_archive_newest_first(self):
        """Newer rotated entries appear before older ones in archive.md."""
        older = (datetime.now() - timedelta(days=10)).date().isoformat()
        newer = (datetime.now() - timedelta(days=8)).date().isoformat()
        self.archive.checkpoint(["older item"], "moro", f"{older}T10:00:00")
        self.archive.checkpoint(["newer item"], "moro", f"{newer}T10:00:00")

        self.archive.rotate()
        text = open(self.archive.archive_path, encoding="utf-8").read()
        self.assertIn(older, text)
        self.assertIn(newer, text)
        # Newer date should appear before older
        self.assertLess(text.index(newer), text.index(older))

    def test_rotate_appends_to_existing_archive(self):
        """Rotation appends new content alongside existing archive content."""
        # Create a pre-existing archive
        os.makedirs(os.path.join(self.tmpdir, "memory"), exist_ok=True)
        with open(self.archive.archive_path, "w", encoding="utf-8") as fh:
            fh.write("# 2025\n## December\n### 2025-12-25\nold archive block\n")

        old_day = (datetime.now() - timedelta(days=8)).date().isoformat()
        self.archive.checkpoint(["fresh old day"], "moro", f"{old_day}T09:00:00")
        self.archive.rotate()

        text = open(self.archive.archive_path, encoding="utf-8").read()
        self.assertIn(old_day, text)
        self.assertIn("2025-12-25", text)  # Original content preserved

    def test_rotate_empty_store(self):
        """Rotate on empty memory dir returns 0."""
        rotated = self.archive.rotate()
        self.assertEqual(rotated, 0)

    # ── search_archive ────────────────────────────────────────────────────

    def test_search_archive_finds_daily_files(self):
        """Search finds content in active daily files."""
        self.archive.checkpoint(
            ["Discussed PostgreSQL migration plan"], "moro", "2026-03-28T10:00:00",
        )
        results = self.archive.search_archive("PostgreSQL migration")
        self.assertGreaterEqual(len(results), 1)
        self.assertTrue(any("PostgreSQL" in r.get("content", "") or
                            "PostgreSQL" in r.get("snippet", "")
                            for r in results))

    def test_search_archive_respects_limit(self):
        """Limit parameter caps the number of results."""
        self.archive.checkpoint(["postgres alpha"], "moro", "2026-03-28T10:00:00")
        self.archive.checkpoint(["postgres beta"], "moro", "2026-03-28T11:00:00")
        self.archive.checkpoint(["postgres gamma"], "moro", "2026-03-28T12:00:00")

        results = self.archive.search_archive("postgres", limit=1)
        self.assertLessEqual(len(results), 1)

    def test_search_archive_includes_archive_md_sections(self):
        """Search covers archive.md content too."""
        os.makedirs(os.path.join(self.tmpdir, "memory"), exist_ok=True)
        with open(self.archive.archive_path, "w", encoding="utf-8") as fh:
            fh.write(
                "# 2026\n## March\n### 2026-03-10\n\n"
                "#### Summary\n- Deploy discussion\n\n"
                "#### Raw\n- user: archive search should find this deploy note\n"
            )
        results = self.archive.search_archive("deploy", limit=5)
        self.assertGreaterEqual(len(results), 1)

    def test_search_archive_returns_score(self):
        """Search results include a numeric score."""
        self.archive.checkpoint(
            ["A long note about semantic retrieval and archive indexing"],
            "moro",
            "2026-03-28T10:00:00",
        )
        results = self.archive.search_archive("semantic retrieval")
        self.assertGreaterEqual(len(results), 1)
        self.assertIn("score", results[0])
        self.assertIsInstance(results[0]["score"], (int, float))

    def test_search_empty_query(self):
        """Empty query returns empty results."""
        self.archive.checkpoint(["some data"], "moro", "2026-03-28T10:00:00")
        results = self.archive.search_archive("")
        self.assertEqual(results, [])

    # ── get_recent ────────────────────────────────────────────────────────

    def test_get_recent_returns_newest_first(self):
        """get_recent returns content from recent files, newest first."""
        self.archive.checkpoint(["older"], "moro", "2026-03-20T10:00:00")
        self.archive.checkpoint(["newer"], "moro", "2026-03-21T10:00:00")

        content = self.archive.get_recent(days=5)
        self.assertIn("newer", content)
        self.assertIn("older", content)
        # Newer should appear before older (list is reverse sorted)
        self.assertLess(content.index("newer"), content.index("older"))

    def test_get_recent_handles_zero_days(self):
        """get_recent(days=0) returns empty string."""
        self.archive.checkpoint(["something"], "moro", "2026-03-28T10:00:00")
        content = self.archive.get_recent(days=0)
        self.assertEqual(content, "")


class TestMemorySystemArchiveIntegration(unittest.TestCase):
    """Tests that MemorySystem correctly delegates to ConversationArchive."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            from parsica_memory import MemorySystem
            self.mem = MemorySystem(
                workspace=self.tmpdir,
                use_sharding=False,
                sharding=False,
            )

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_memory_system_exposes_archive_helper(self):
        """MemorySystem has an .archive attribute."""
        self.assertTrue(hasattr(self.mem, "archive"))
        self.assertIsInstance(self.mem.archive, ConversationArchive)

    def test_memory_system_checkpoint_conversation(self):
        """checkpoint_conversation() delegates to archive."""
        path = self.mem.checkpoint_conversation(
            [{"role": "user", "content": "Integration test turn"}],
            timestamp="2026-03-28T16:00:00",
        )
        self.assertTrue(os.path.exists(path))
        text = open(path, encoding="utf-8").read()
        self.assertIn("Integration test turn", text)

    def test_memory_system_search_archive(self):
        """search_archive() is callable from MemorySystem."""
        self.mem.checkpoint_conversation(
            ["Search integration test content"],
            timestamp="2026-03-28T16:00:00",
        )
        results = self.mem.search_archive("integration test")
        # Should return a list (possibly empty if no match, but callable)
        self.assertIsInstance(results, list)

    def test_memory_system_rotate_archive(self):
        """rotate_archive() is callable from MemorySystem."""
        result = self.mem.rotate_archive()
        self.assertIsInstance(result, int)

    def test_memory_system_get_recent_archive(self):
        """get_recent_archive() is callable from MemorySystem."""
        result = self.mem.get_recent_archive(days=2)
        self.assertIsInstance(result, str)


if __name__ == "__main__":
    unittest.main()
