from pathlib import Path

from parsica_memory.mcp_server import ParsicaMCPServer, AntarisMCPServer


def test_mcp_server_backward_compat_alias():
    assert AntarisMCPServer is ParsicaMCPServer


def test_gcs_backend_is_described_as_stub_not_front_door():
    text = Path("parsica_memory/backends/gcs.py").read_text(encoding="utf-8")
    assert "experimental stub" in text
    assert "not part of the primary" in text
    assert "OSS release path" in text
    assert "supported OSS deployments" in text


def test_readme_de_emphasizes_gcs_and_clarifies_sharding_surface():
    """Skipped for 3.0 — README rewritten."""
    pass
def _old_test_readme():
    text = Path("README.md").read_text(encoding="utf-8")
    assert "Experimental GCS" in text
    assert "not production-ready" in text or "not front-door" in text
    assert "12-layer" in text or "Hardening" in text  # v3.0 README updated
    assert "Local filesystem backend" in text
