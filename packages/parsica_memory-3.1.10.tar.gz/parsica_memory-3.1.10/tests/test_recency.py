"""Tests for parsica-memory recency recall feature (v2.3.0)."""
import pytest
from datetime import datetime, timezone, timedelta
from parsica_memory import MemorySystem
from parsica_memory.entry import MemoryEntry
from parsica_memory.search import search_by_recency
import tempfile, os


def make_entry(content, hours_ago=0.0, channel=""):
    dt = datetime.now(timezone.utc) - timedelta(hours=hours_ago)
    e = MemoryEntry(content=content, source="test", created=dt.isoformat())
    e.source_channel = channel
    return e


class TestSearchByRecency:
    def test_within_window(self):
        entries = [make_entry("recent", hours_ago=1.0)]
        result = search_by_recency(entries, hours=6.0)
        assert len(result) == 1

    def test_outside_window(self):
        entries = [make_entry("old", hours_ago=10.0)]
        result = search_by_recency(entries, hours=6.0)
        assert len(result) == 0

    def test_sorted_newest_first(self):
        entries = [
            make_entry("older", hours_ago=3.0),
            make_entry("newer", hours_ago=1.0),
            make_entry("oldest", hours_ago=5.0),
        ]
        result = search_by_recency(entries, hours=6.0)
        assert result[0].content == "newer"
        assert result[-1].content == "oldest"

    def test_limit_enforced(self):
        entries = [make_entry(f"msg{i}", hours_ago=float(i)) for i in range(10)]
        result = search_by_recency(entries, hours=24.0, limit=3)
        assert len(result) == 3

    def test_channel_exclusion(self):
        entries = [
            make_entry("keep", hours_ago=1.0, channel="discord:123"),
            make_entry("exclude", hours_ago=1.0, channel="slack:456"),
        ]
        result = search_by_recency(entries, hours=6.0, exclude_channel="slack:456")
        assert len(result) == 1
        assert result[0].content == "keep"

    def test_empty_store(self):
        result = search_by_recency([], hours=6.0)
        assert result == []

    def test_missing_timestamp_skipped(self):
        e = MemoryEntry(content="no timestamp", source="test")
        e.created = None
        result = search_by_recency([e], hours=6.0)
        assert result == []

    def test_naive_timestamp_treated_as_local(self):
        """Entries with naive timestamps (MemoryEntry default) should be compared
        against local time, not UTC — otherwise timezone offset causes false negatives."""
        # Create entry with naive local timestamp (what MemoryEntry does by default)
        e = MemoryEntry(content="naive timestamp entry", source="test")
        # e.created is set to datetime.now().isoformat() — naive local time
        result = search_by_recency([e], hours=1.0)
        assert len(result) == 1


class TestRecallRecent:
    def test_recall_recent_basic(self, tmp_path):
        ms = MemorySystem(str(tmp_path))
        # Content must be substantial enough to pass ingest quality filters (>= 15 chars, not noise)
        ms.ingest("The team decided to use FastAPI as the primary web framework for backend services", source="discord", source_channel="discord:111")
        ms.ingest("We should migrate the database to PostgreSQL for better performance and reliability", source="slack", source_channel="slack:222")
        results = ms.recall_recent(hours=1.0, limit=10)
        assert len(results) == 2

    def test_recall_recent_exclude_channel(self, tmp_path):
        ms = MemorySystem(str(tmp_path))
        ms.ingest("The team decided to use FastAPI as the primary web framework for backend services", source="discord", source_channel="discord:111")
        ms.ingest("We should migrate the database to PostgreSQL for better performance and reliability", source="slack", source_channel="slack:222")
        results = ms.recall_recent(hours=1.0, limit=10, exclude_channel="discord:111")
        assert all(r.source_channel != "discord:111" for r in results)
