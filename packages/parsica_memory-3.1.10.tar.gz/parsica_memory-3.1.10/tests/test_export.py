import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from parsica_memory import MemorySystem, export_archive, export_memories


def _mem(tmp_path):
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("Today we decided to use PostgreSQL for analytics", source="meeting", category="strategic")
    mem.ingest("Deploy the API this week after PostgreSQL migration", source="ops", category="tactical")
    return mem


def test_export_memories_json(tmp_path):
    mem = _mem(tmp_path)
    data = json.loads(export_memories(mem, range_name="all", format="json"))
    assert data["count"] == 2
    assert len(data["entries"]) == 2


def test_export_memories_jsonl(tmp_path):
    mem = _mem(tmp_path)
    out = export_memories(mem, range_name="all", format="jsonl")
    lines = [l for l in out.splitlines() if l.strip()]
    assert len(lines) == 2
    assert all("content" in json.loads(line) for line in lines)


def test_export_memories_markdown(tmp_path):
    mem = _mem(tmp_path)
    out = export_memories(mem, range_name="all", format="markdown")
    assert out.startswith("# Memories Export")
    assert "PostgreSQL" in out


def test_export_archive_json(tmp_path):
    mem = _mem(tmp_path)
    data = json.loads(export_archive(mem, range_name="all", format="json"))
    assert "archive" in data.get("title", "").lower() or "archive" in str(data).lower()


def test_export_topic_filter(tmp_path):
    mem = _mem(tmp_path)
    data = json.loads(export_memories(mem, range_name="all", topic="analytics", format="json"))
    assert len(data["entries"]) >= 1
    assert any("analytics" in e["content"].lower() for e in data["entries"])


def test_export_range_today(tmp_path):
    mem = _mem(tmp_path)
    data = json.loads(export_memories(mem, range_name="today", format="json"))
    assert len(data["entries"]) == 2


def test_export_invalid_range_raises(tmp_path):
    mem = _mem(tmp_path)
    import pytest
    with pytest.raises(ValueError):
        export_memories(mem, range_name="year", format="json")


def test_export_invalid_format_raises(tmp_path):
    mem = _mem(tmp_path)
    import pytest
    with pytest.raises(ValueError):
        export_memories(mem, range_name="all", format="xml")


def test_memorysystem_export_active_wrapper(tmp_path):
    mem = _mem(tmp_path)
    data = json.loads(mem.export_active(format="json"))
    assert data["count"] == 2


def test_memorysystem_export_archive_wrapper(tmp_path):
    mem = _mem(tmp_path)
    raw = mem.export_archive_view(format="json")
    data = json.loads(raw)
    # Archive export may have "count" (fallback) or "archive"/"daily_files" (real archive)
    assert "title" in data or "archive" in data
