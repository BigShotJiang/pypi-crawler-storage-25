"""Tests for parsica-memory v4.7.0 — Tiered Storage.

Covers TierManager classification, warm-tier on-demand loading,
shard hash tracking, cold-tier opt-in, and MemorySystem integration.
"""

import json
import os
import tempfile
import time
from datetime import datetime, timedelta, timezone
from typing import List
from unittest.mock import patch

import pytest

from parsica_memory.tiers import TierManager, HOT_DAYS, WARM_DAYS, WARM_FALLBACK_THRESHOLD
from parsica_memory.entry import MemoryEntry


# ── Helpers ────────────────────────────────────────────────────────────────


def _shard_name(dt: datetime) -> str:
    year, week, _ = dt.isocalendar()
    return f"memories_{year}-W{week:02d}.jsonl"


def _write_shard(workspace: str, shard_name: str, entries: List[dict]) -> str:
    path = os.path.join(workspace, shard_name)
    with open(path, "w") as f:
        for e in entries:
            f.write(json.dumps(e) + "\n")
    return path


def _make_entry(content: str, hash_val: str = None) -> MemoryEntry:
    e = MemoryEntry(content=content)
    if hash_val:
        e.hash = hash_val
    return e


# ── TierManager.classify_shards ────────────────────────────────────────────


def test_classify_hot_shard():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws, hot_days=3, warm_days=14)
        now = datetime.now(timezone.utc)
        hot_name = _shard_name(now)  # this week = hot
        hot, warm, cold = mgr.classify_shards([hot_name])
        assert hot_name in hot
        assert hot_name not in warm
        assert hot_name not in cold


def test_classify_warm_shard():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws, hot_days=3, warm_days=14)
        now = datetime.now(timezone.utc)
        warm_dt = now - timedelta(days=14)  # previous full week that has aged out of hot
        warm_name = _shard_name(warm_dt)
        hot, warm, cold = mgr.classify_shards([warm_name])
        assert warm_name in warm
        assert warm_name not in hot
        assert warm_name not in cold


def test_classify_cold_shard():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws, hot_days=3, warm_days=14)
        now = datetime.now(timezone.utc)
        cold_dt = now - timedelta(days=30)  # 30 days ago = cold
        cold_name = _shard_name(cold_dt)
        hot, warm, cold = mgr.classify_shards([cold_name])
        assert cold_name in cold
        assert cold_name not in hot
        assert cold_name not in warm


def test_classify_mixed_shards():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws, hot_days=3, warm_days=14)
        now = datetime.now(timezone.utc)
        hot_name = _shard_name(now)
        warm_name = _shard_name(now - timedelta(days=14))
        cold_name = _shard_name(now - timedelta(days=30))
        hot, warm, cold = mgr.classify_shards([hot_name, warm_name, cold_name])
        assert hot_name in hot
        assert warm_name in warm
        assert cold_name in cold


def test_classify_unknown_format_defaults_warm():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        hot, warm, cold = mgr.classify_shards(["unknown_shard.jsonl"])
        assert "unknown_shard.jsonl" in warm


def test_classify_empty_list():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        hot, warm, cold = mgr.classify_shards([])
        assert hot == warm == cold == []


# ── TierManager.load_warm ──────────────────────────────────────────────────


def test_load_warm_reads_entries():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        now = datetime.now(timezone.utc)
        shard_name = _shard_name(now - timedelta(days=7))
        entry = _make_entry("warm memory")
        _write_shard(ws, shard_name, [entry.to_dict()])
        result = mgr.load_warm([shard_name])
        assert len(result) == 1
        assert result[0].content == "warm memory"


def test_load_warm_deduplicates():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        now = datetime.now(timezone.utc)
        s1 = _shard_name(now - timedelta(days=7))
        s2 = _shard_name(now - timedelta(days=10))
        entry = _make_entry("shared memory")
        _write_shard(ws, s1, [entry.to_dict()])
        _write_shard(ws, s2, [entry.to_dict()])
        result = mgr.load_warm([s1, s2])
        contents = [r.content for r in result]
        assert contents.count("shared memory") == 1


def test_load_warm_caches_results():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        now = datetime.now(timezone.utc)
        shard_name = _shard_name(now - timedelta(days=7))
        entry = _make_entry("cached memory")
        _write_shard(ws, shard_name, [entry.to_dict()])
        # First load populates cache
        mgr.load_warm([shard_name])
        # Overwrite the shard file — should still return cached result
        _write_shard(ws, shard_name, [_make_entry("new memory").to_dict()])
        result = mgr.load_warm([shard_name])
        assert any(r.content == "cached memory" for r in result)


def test_load_warm_missing_shard_returns_empty():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        result = mgr.load_warm(["nonexistent_shard.jsonl"])
        assert result == []


def test_invalidate_warm_cache():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        now = datetime.now(timezone.utc)
        shard_name = _shard_name(now - timedelta(days=7))
        entry = _make_entry("original")
        _write_shard(ws, shard_name, [entry.to_dict()])
        mgr.load_warm([shard_name])
        mgr.invalidate_warm_cache(shard_name)
        # After invalidation, re-reading from disk should reflect new content
        _write_shard(ws, shard_name, [_make_entry("updated").to_dict()])
        result = mgr.load_warm([shard_name])
        assert any(r.content == "updated" for r in result)


# ── Shard hash tracking ────────────────────────────────────────────────────


def test_shard_hash_returns_string():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        shard_name = "memories_2026-W09.jsonl"
        _write_shard(ws, shard_name, [{"content": "test"}])
        h = mgr.shard_hash(shard_name)
        assert isinstance(h, str) and len(h) == 16


def test_shard_hash_missing_file():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        h = mgr.shard_hash("nonexistent.jsonl")
        assert h == ""


def test_shard_hash_changes_on_content_change():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        shard_name = "memories_2026-W09.jsonl"
        _write_shard(ws, shard_name, [{"content": "v1"}])
        h1 = mgr.shard_hash(shard_name)
        _write_shard(ws, shard_name, [{"content": "v2"}])
        h2 = mgr.shard_hash(shard_name)
        assert h1 != h2


def test_get_changed_shards():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        shard_name = "memories_2026-W09.jsonl"
        _write_shard(ws, shard_name, [{"content": "v1"}])
        mgr.save_hashes([shard_name])
        # No change yet
        assert mgr.get_changed_shards([shard_name]) == []
        # Change the file
        _write_shard(ws, shard_name, [{"content": "v2"}])
        changed = mgr.get_changed_shards([shard_name])
        assert shard_name in changed


def test_save_and_load_hashes_persists():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        shard_name = "memories_2026-W09.jsonl"
        _write_shard(ws, shard_name, [{"content": "test"}])
        mgr.save_hashes([shard_name])
        # Create a new manager — should load persisted hashes
        mgr2 = TierManager(ws)
        assert shard_name in mgr2._known_hashes
        assert mgr2._known_hashes[shard_name] == mgr._known_hashes[shard_name]


# ── should_promote ────────────────────────────────────────────────────────


def test_should_promote_requires_min_accesses():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        entry = _make_entry("promotable")
        entry.last_accessed = datetime.now(timezone.utc).isoformat()
        assert not mgr.should_promote(entry, access_count=1)
        assert mgr.should_promote(entry, access_count=2)


def test_should_promote_requires_recent_access():
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        entry = _make_entry("old access")
        entry.last_accessed = (
            datetime.now(timezone.utc) - timedelta(hours=25)
        ).isoformat()
        assert not mgr.should_promote(entry, access_count=5)


def test_should_promote_stale_last_accessed():
    """Entry with last_accessed older than 24h should not promote."""
    with tempfile.TemporaryDirectory() as ws:
        mgr = TierManager(ws)
        entry = _make_entry("stale access time")
        # Simulate last_accessed being 2 days ago (outside 24h window)
        entry.last_accessed = (
            datetime.now(timezone.utc) - timedelta(hours=48)
        ).isoformat()
        assert not mgr.should_promote(entry, access_count=5)


# ── MemorySystem integration ───────────────────────────────────────────────


def test_memory_system_hot_only_load():
    """Hot-only load: only recent entries in self.memories on startup."""
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as ws:
        # Write a hot shard and a cold shard
        now = datetime.now(timezone.utc)
        hot_entry = _make_entry("hot memory")
        cold_entry = _make_entry("cold memory")
        hot_entry.hash = "hotabc123"
        cold_entry.hash = "coldabc123"
        hot_entry.created = now.isoformat()
        cold_entry.created = (now - timedelta(days=30)).isoformat()

        _write_shard(ws, _shard_name(now), [hot_entry.to_dict()])
        _write_shard(ws, _shard_name(now - timedelta(days=30)), [cold_entry.to_dict()])

        mem = MemorySystem(ws, use_sharding=False, sharding=True, tiered_storage=True)
        contents = [m.content for m in mem.memories]
        assert "hot memory" in contents
        assert "cold memory" not in contents


def test_memory_system_warm_fallback_triggers():
    """Warm fallback: sparse hot results trigger warm shard load."""
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as ws:
        now = datetime.now(timezone.utc)
        # Hot shard has one irrelevant entry
        hot_entry = _make_entry("completely unrelated topic xyz")
        hot_entry.created = now.isoformat()
        _write_shard(ws, _shard_name(now), [hot_entry.to_dict()])

        # Warm shard has a relevant entry
        warm_entry = _make_entry("artificial intelligence machine learning")
        warm_entry.created = (now - timedelta(days=7)).isoformat()
        _write_shard(ws, _shard_name(now - timedelta(days=7)), [warm_entry.to_dict()])

        mem = MemorySystem(ws, use_sharding=False, sharding=True, tiered_storage=True)
        results = mem.search("artificial intelligence machine learning")
        contents = [r.content for r in results]
        assert "artificial intelligence machine learning" in contents


def test_memory_system_cold_excluded_by_default():
    """Cold entries must NOT appear in default search results."""
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as ws:
        now = datetime.now(timezone.utc)
        # Only a cold shard exists
        cold_entry = _make_entry("ancient history deep past memory")
        cold_entry.created = (now - timedelta(days=60)).isoformat()
        _write_shard(ws, _shard_name(now - timedelta(days=60)), [cold_entry.to_dict()])

        mem = MemorySystem(ws, use_sharding=False, sharding=True, tiered_storage=True)
        results = mem.search("ancient history deep past memory")
        contents = [r.content for r in results]
        assert "ancient history deep past memory" not in contents


def test_memory_system_include_cold():
    """include_cold=True must surface cold entries."""
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as ws:
        now = datetime.now(timezone.utc)
        cold_entry = _make_entry("ancient history deep past memory")
        cold_entry.created = (now - timedelta(days=60)).isoformat()
        _write_shard(ws, _shard_name(now - timedelta(days=60)), [cold_entry.to_dict()])

        mem = MemorySystem(ws, use_sharding=False, sharding=True, tiered_storage=True)
        results = mem.search("ancient history deep past memory", include_cold=True)
        contents = [r.content for r in results]
        assert "ancient history deep past memory" in contents


def test_tiered_storage_disabled_loads_all():
    """When tiered_storage=False, all shards load normally (v4.6 behaviour)."""
    from parsica_memory import MemorySystem
    with tempfile.TemporaryDirectory() as ws:
        now = datetime.now(timezone.utc)
        recent = _make_entry("recent entry")
        recent.created = now.isoformat()
        old = _make_entry("old entry from two weeks ago")
        old.created = (now - timedelta(days=10)).isoformat()
        _write_shard(ws, _shard_name(now), [recent.to_dict()])
        _write_shard(ws, _shard_name(now - timedelta(days=10)), [old.to_dict()])

        mem = MemorySystem(ws, use_sharding=False, sharding=True, tiered_storage=False)
        contents = [m.content for m in mem.memories]
        assert "recent entry" in contents
        assert "old entry from two weeks ago" in contents
