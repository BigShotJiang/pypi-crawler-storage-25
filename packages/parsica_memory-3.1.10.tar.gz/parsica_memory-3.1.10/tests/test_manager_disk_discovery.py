"""Tests for MemoryManager aggregate stats — disk user discovery after restart.

Validates P1-2: MemoryManager.stats(user_id=None) must discover user stores
from disk, not just from the in-process _stores cache.  After a restart
(new MemoryManager instance), all previously-written user stores should be
visible in aggregate stats with correct entry counts.
"""

import os
import tempfile
import shutil

import pytest

from parsica_memory import MemoryManager


class TestManagerDiskDiscovery:
    """Verify that stats() discovers users from disk after restart."""

    def _ingest_long(self, mm, user_id, user_msg, bot_msg):
        """Ingest with messages long enough to pass the noise filter (≥20 chars)."""
        assert len(user_msg) >= 20, f"user_msg too short: {user_msg!r}"
        assert len(bot_msg) >= 20, f"bot_msg too short: {bot_msg!r}"
        result = mm.ingest(user_id, user_msg, bot_msg)
        assert result, f"Ingest failed for user={user_id}"

    def test_aggregate_stats_after_restart_discovers_users(self):
        """New MemoryManager should see users written by a prior instance."""
        with tempfile.TemporaryDirectory() as tmp:
            # Session 1: create stores for two users
            mm1 = MemoryManager(tmp)
            self._ingest_long(mm1, "alice",
                              "Tell me about machine learning and its applications.",
                              "Machine learning is a subset of artificial intelligence that enables systems to learn.")
            self._ingest_long(mm1, "bob",
                              "What is cloud computing and how does it work?",
                              "Cloud computing is the delivery of computing services over the internet.")

            # Session 2: brand new manager (simulates restart)
            mm2 = MemoryManager(tmp)
            stats = mm2.stats()

            assert stats["user_count"] >= 2, f"Expected at least 2 users, got {stats['user_count']}"
            assert stats["total_entries"] > 0, f"Expected entries > 0 after restart, got {stats['total_entries']}"

    def test_aggregate_stats_merges_disk_and_inmemory(self):
        """Stats should include both disk-discovered and newly-created users."""
        with tempfile.TemporaryDirectory() as tmp:
            # Session 1
            mm1 = MemoryManager(tmp)
            self._ingest_long(mm1, "alice",
                              "Tell me about machine learning and its applications.",
                              "Machine learning is a subset of artificial intelligence.")

            # Session 2: new user + existing disk user
            mm2 = MemoryManager(tmp)
            self._ingest_long(mm2, "charlie",
                              "What is quantum computing and why does it matter?",
                              "Quantum computing uses quantum bits to process information exponentially.")

            stats = mm2.stats()
            assert stats["user_count"] >= 2, f"Expected at least 2 users, got {stats['user_count']}"
            # At least one entry from alice (disk) and one from charlie (in-memory)
            assert stats["total_entries"] >= 2

    def test_per_user_stats_single_user(self):
        """stats(user_id='alice') should work for a specific user."""
        with tempfile.TemporaryDirectory() as tmp:
            mm = MemoryManager(tmp)
            self._ingest_long(mm, "alice",
                              "Tell me about machine learning and its applications.",
                              "Machine learning is a subset of artificial intelligence.")

            stats = mm.stats("alice")
            assert stats["user_id"] == "alice"
            assert stats["entry_count"] > 0
            assert stats["store_size_bytes"] > 0

    def test_export_returns_nonzero_entries(self):
        """MemoryManager.export() should return all stored entries, not zero."""
        with tempfile.TemporaryDirectory() as tmp:
            mm = MemoryManager(tmp)
            self._ingest_long(mm, "alice",
                              "Tell me about machine learning and its applications.",
                              "Machine learning is a subset of artificial intelligence.")
            self._ingest_long(mm, "alice",
                              "What is deep learning and how does it relate to ML?",
                              "Deep learning is a branch of machine learning using neural networks.")

            out = os.path.join(tmp, "export.json")
            count = mm.export("alice", out)
            assert count > 0, "export() must return > 0 entries for a populated store"
