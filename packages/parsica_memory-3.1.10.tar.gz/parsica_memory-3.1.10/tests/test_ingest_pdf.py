"""Tests for parsica_memory.ingest_pdf — PDF capability layer."""

import os
import tempfile
import textwrap
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


# ── Import the module under test ──────────────────────────────────────

from parsica_memory.ingest_pdf import (
    PDFIngester,
    PDFResult,
    PDFChunk,
    PDFPage,
    PDFMetadata,
    ExtractionMethod,
    _clean_text,
    _detect_section_headings,
    _chunk_text,
    _content_hash,
    extract_text,
    extract_chunks,
    ingest_pdf,
    MIN_TEXT_LENGTH,
    MIN_CHUNK_LENGTH,
    MAX_CHUNK_LENGTH,
)


# ── Helper: create a minimal text PDF using pypdf ──────────────────────

def _create_text_pdf(path: str, pages_text: list[str]) -> str:
    """Create a simple text PDF with pypdf for testing."""
    try:
        from pypdf import PdfWriter
    except ImportError:
        from PyPDF2 import PdfWriter

    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas as rl_canvas
    import io

    writer = PdfWriter()

    for text in pages_text:
        packet = io.BytesIO()
        c = rl_canvas.Canvas(packet, pagesize=letter)
        # Simple text rendering
        y = 750
        for line in text.split('\n'):
            if y < 50:
                break
            c.drawString(72, y, line)
            y -= 14
        c.showPage()
        c.save()
        packet.seek(0)

        try:
            from pypdf import PdfReader
        except ImportError:
            from PyPDF2 import PdfReader
        reader = PdfReader(packet)
        writer.add_page(reader.pages[0])

    with open(path, 'wb') as f:
        writer.write(f)

    return path


def _create_minimal_pdf(path: str, page_count: int = 1) -> str:
    """Create a minimal valid PDF without reportlab (just empty pages).

    Uses raw PDF syntax for a truly minimal test fixture.
    """
    # Minimal PDF with blank pages that have text objects
    header = b"%PDF-1.4\n"
    
    objects = []
    pages_refs = []
    obj_num = 1

    # Catalog will be object 1
    catalog_num = obj_num
    obj_num += 1

    # Pages will be object 2
    pages_num = obj_num
    obj_num += 1

    # Create page objects
    for i in range(page_count):
        page_num = obj_num
        obj_num += 1
        content_num = obj_num
        obj_num += 1
        font_num = obj_num
        obj_num += 1

        text = f"This is page {i + 1} of the test document. It contains enough text to meet the minimum chunk length for testing purposes."
        content = f"BT /F1 12 Tf 72 750 Td ({text}) Tj ET".encode()

        objects.append((font_num, f"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>".encode()))
        objects.append((content_num, f"<< /Length {len(content)} >>\nstream\n".encode() + content + b"\nendstream"))
        objects.append((page_num, f"<< /Type /Page /Parent {pages_num} 0 R /Contents {content_num} 0 R /Resources << /Font << /F1 {font_num} 0 R >> >> /MediaBox [0 0 612 792] >>".encode()))
        pages_refs.append(f"{page_num} 0 R")

    # Build pages object
    kids = " ".join(pages_refs)
    objects.append((pages_num, f"<< /Type /Pages /Kids [{kids}] /Count {page_count} >>".encode()))

    # Catalog
    objects.append((catalog_num, f"<< /Type /Catalog /Pages {pages_num} 0 R >>".encode()))

    # Write PDF
    body = header
    xref_offsets = {}
    for num, data in sorted(objects, key=lambda x: x[0]):
        xref_offsets[num] = len(body)
        body += f"{num} 0 obj\n".encode() + data + b"\nendobj\n"

    xref_offset = len(body)
    body += b"xref\n"
    body += f"0 {obj_num}\n".encode()
    body += b"0000000000 65535 f \n"
    for i in range(1, obj_num):
        offset = xref_offsets.get(i, 0)
        body += f"{offset:010d} 00000 n \n".encode()

    body += b"trailer\n"
    body += f"<< /Size {obj_num} /Root {catalog_num} 0 R >>\n".encode()
    body += b"startxref\n"
    body += f"{xref_offset}\n".encode()
    body += b"%%EOF\n"

    with open(path, 'wb') as f:
        f.write(body)

    return path


# ── Tests: helper functions ────────────────────────────────────────────

class TestCleanText:
    def test_collapse_whitespace(self):
        assert _clean_text("hello   world") == "hello world"

    def test_normalize_linebreaks(self):
        assert _clean_text("a\n\n\n\n\nb") == "a\n\nb"

    def test_remove_null_bytes(self):
        assert _clean_text("hello\x00world") == "helloworld"

    def test_fix_ligatures(self):
        assert _clean_text("of\ufb01ce") == "office"
        assert _clean_text("\ufb02ow") == "flow"

    def test_empty_string(self):
        assert _clean_text("") == ""
        assert _clean_text(None) == ""

    def test_strips_whitespace(self):
        assert _clean_text("  hello  ") == "hello"


class TestContentHash:
    def test_deterministic(self):
        h1 = _content_hash("test content")
        h2 = _content_hash("test content")
        assert h1 == h2

    def test_different_content(self):
        h1 = _content_hash("content a")
        h2 = _content_hash("content b")
        assert h1 != h2

    def test_length(self):
        h = _content_hash("test")
        assert len(h) == 16


class TestDetectSectionHeadings:
    def test_all_caps_heading(self):
        text = "Some intro text.\n\nINTRODUCTION\n\nMore text follows."
        headings = _detect_section_headings(text)
        heading_texts = [h[1] for h in headings]
        assert "INTRODUCTION" in heading_texts

    def test_numbered_section(self):
        text = "Preface.\n\n1.1 Background\n\nSome content."
        headings = _detect_section_headings(text)
        heading_texts = [h[1] for h in headings]
        assert any("1.1 Background" in h for h in heading_texts)

    def test_chapter_heading(self):
        text = "Previous content.\n\nChapter 3 Results\n\nResults are here."
        headings = _detect_section_headings(text)
        heading_texts = [h[1] for h in headings]
        assert any("Chapter 3" in h for h in heading_texts)

    def test_no_headings(self):
        text = "Just a regular paragraph with some text that isn't a heading."
        headings = _detect_section_headings(text)
        assert len(headings) == 0


class TestChunkText:
    def test_short_text_single_chunk(self):
        text = "A" * 100
        chunks = _chunk_text(text, page=1, source_file="test.pdf",
                             method=ExtractionMethod.DIRECT)
        assert len(chunks) == 1
        assert chunks[0].page == 1
        assert chunks[0].extraction_method == ExtractionMethod.DIRECT

    def test_long_text_multiple_chunks(self):
        # Create text longer than MAX_CHUNK_LENGTH
        paragraphs = [f"Paragraph {i}. " + ("word " * 100) for i in range(10)]
        text = "\n\n".join(paragraphs)
        chunks = _chunk_text(text, page=1, source_file="test.pdf",
                             method=ExtractionMethod.DIRECT)
        assert len(chunks) > 1
        for chunk in chunks:
            assert len(chunk.text) <= MAX_CHUNK_LENGTH + 200  # allow some flex

    def test_empty_text_no_chunks(self):
        chunks = _chunk_text("", page=1, source_file="test.pdf",
                             method=ExtractionMethod.DIRECT)
        assert len(chunks) == 0

    def test_below_minimum_no_chunks(self):
        chunks = _chunk_text("short", page=1, source_file="test.pdf",
                             method=ExtractionMethod.DIRECT)
        assert len(chunks) == 0

    def test_provenance_preserved(self):
        text = "This is a substantial paragraph with enough content. " * 5
        chunks = _chunk_text(text, page=3, source_file="/path/to/doc.pdf",
                             method=ExtractionMethod.LAYOUT, confidence=0.95)
        assert len(chunks) >= 1
        assert chunks[0].page == 3
        assert chunks[0].source_file == "/path/to/doc.pdf"
        assert chunks[0].extraction_method == ExtractionMethod.LAYOUT
        assert chunks[0].confidence == 0.95

    def test_content_hash_set(self):
        text = "A decent paragraph with content for testing purposes. " * 3
        chunks = _chunk_text(text, page=1, source_file="test.pdf",
                             method=ExtractionMethod.DIRECT)
        assert all(chunk.content_hash for chunk in chunks)


# ── Tests: PDFChunk dataclass ──────────────────────────────────────────

class TestPDFChunk:
    def test_auto_hash(self):
        chunk = PDFChunk(
            text="Hello world",
            page=1,
            chunk_index=0,
            source_file="test.pdf",
            extraction_method=ExtractionMethod.DIRECT,
        )
        assert chunk.content_hash
        assert len(chunk.content_hash) == 16

    def test_explicit_hash(self):
        chunk = PDFChunk(
            text="Hello",
            page=1,
            chunk_index=0,
            source_file="test.pdf",
            extraction_method=ExtractionMethod.DIRECT,
            content_hash="custom_hash_value",
        )
        assert chunk.content_hash == "custom_hash_value"


# ── Tests: PDFResult ───────────────────────────────────────────────────

class TestPDFResult:
    def test_full_text(self):
        pages = [
            PDFPage(1, "Page one text.", ExtractionMethod.DIRECT),
            PDFPage(2, "Page two text.", ExtractionMethod.DIRECT),
        ]
        result = PDFResult(
            source_file="test.pdf",
            metadata=PDFMetadata(page_count=2),
            pages=pages,
            chunks=[],
        )
        assert "Page one text." in result.full_text
        assert "Page two text." in result.full_text

    def test_total_words(self):
        pages = [
            PDFPage(1, "one two three", ExtractionMethod.DIRECT),
            PDFPage(2, "four five", ExtractionMethod.DIRECT),
        ]
        result = PDFResult("test.pdf", PDFMetadata(), pages, [])
        assert result.total_words == 5

    def test_extraction_methods_used(self):
        pages = [
            PDFPage(1, "text", ExtractionMethod.DIRECT),
            PDFPage(2, "ocr text", ExtractionMethod.OCR),
        ]
        result = PDFResult("test.pdf", PDFMetadata(), pages, [])
        assert ExtractionMethod.DIRECT in result.extraction_methods_used
        assert ExtractionMethod.OCR in result.extraction_methods_used

    def test_to_memory_entries(self):
        chunks = [
            PDFChunk(
                text="Important finding from page 3.",
                page=3,
                chunk_index=0,
                source_file="/docs/paper.pdf",
                extraction_method=ExtractionMethod.DIRECT,
                section_heading="RESULTS",
            ),
        ]
        result = PDFResult(
            source_file="/docs/paper.pdf",
            metadata=PDFMetadata(title="My Paper", author="Test Author"),
            pages=[],
            chunks=chunks,
        )
        entries = result.to_memory_entries(category="research")
        assert len(entries) == 1
        e = entries[0]
        assert e["content"] == "Important finding from page 3."
        assert e["source"].startswith("pdf:paper.pdf:p3")
        assert "RESULTS" in e["source"]
        assert e["category"] == "research"
        assert e["metadata"]["page"] == 3
        assert e["metadata"]["document_title"] == "My Paper"

    def test_summary(self):
        result = PDFResult(
            source_file="/docs/test.pdf",
            metadata=PDFMetadata(title="Test", page_count=5),
            pages=[PDFPage(1, "hello world", ExtractionMethod.DIRECT)],
            chunks=[],
            extraction_time_ms=123.4,
        )
        s = result.summary()
        assert "test.pdf" in s
        assert "123ms" in s


# ── Tests: PDFIngester ─────────────────────────────────────────────────

class TestPDFIngester:
    def test_file_not_found(self):
        ingester = PDFIngester(use_ocr=False)
        result = ingester.ingest("/nonexistent/file.pdf")
        assert len(result.errors) > 0
        assert "not found" in result.errors[0].lower()

    def test_ingest_real_pdf(self, tmp_path):
        """Test with a real generated PDF (requires reportlab or minimal PDF)."""
        pdf_path = str(tmp_path / "test.pdf")
        try:
            _create_minimal_pdf(pdf_path, page_count=3)
        except Exception:
            pytest.skip("Could not create test PDF")

        ingester = PDFIngester(use_ocr=False)
        result = ingester.ingest(pdf_path)

        assert result.page_count == 3
        assert len(result.errors) == 0
        assert result.metadata.page_count == 3
        # Should have extracted some text from our minimal PDF
        if result.full_text.strip():
            assert result.total_words > 0

    def test_specific_pages(self, tmp_path):
        """Test extracting only specific pages."""
        pdf_path = str(tmp_path / "test.pdf")
        try:
            _create_minimal_pdf(pdf_path, page_count=5)
        except Exception:
            pytest.skip("Could not create test PDF")

        ingester = PDFIngester(use_ocr=False)
        result = ingester.ingest(pdf_path, pages=[1, 3])

        assert result.page_count == 2
        page_nums = [p.page_number for p in result.pages]
        assert 1 in page_nums
        assert 3 in page_nums
        assert 2 not in page_nums

    def test_ocr_disabled(self, tmp_path):
        pdf_path = str(tmp_path / "test.pdf")
        _create_minimal_pdf(pdf_path)

        ingester = PDFIngester(use_ocr=False)
        result = ingester.ingest(pdf_path)
        # Should not attempt OCR
        assert ExtractionMethod.OCR not in result.extraction_methods_used

    def test_custom_chunk_sizes(self, tmp_path):
        pdf_path = str(tmp_path / "test.pdf")
        _create_minimal_pdf(pdf_path)

        ingester = PDFIngester(
            use_ocr=False,
            max_chunk_length=500,
            min_chunk_length=20,
        )
        result = ingester.ingest(pdf_path)
        for chunk in result.chunks:
            assert len(chunk.text) >= 20


# ── Tests: convenience functions ───────────────────────────────────────

class TestConvenienceFunctions:
    def test_extract_text(self, tmp_path):
        pdf_path = str(tmp_path / "test.pdf")
        try:
            _create_minimal_pdf(pdf_path)
        except Exception:
            pytest.skip("Could not create test PDF")

        text = extract_text(pdf_path)
        assert isinstance(text, str)

    def test_extract_chunks(self, tmp_path):
        pdf_path = str(tmp_path / "test.pdf")
        try:
            _create_minimal_pdf(pdf_path)
        except Exception:
            pytest.skip("Could not create test PDF")

        chunks = extract_chunks(pdf_path)
        assert isinstance(chunks, list)
        for c in chunks:
            assert "text" in c
            assert "page" in c
            assert "method" in c
            assert "hash" in c


# ── Tests: ExtractionMethod enum ──────────────────────────────────────

class TestExtractionMethod:
    def test_values(self):
        assert ExtractionMethod.DIRECT.value == "direct"
        assert ExtractionMethod.LAYOUT.value == "layout"
        assert ExtractionMethod.OCR.value == "ocr"
        assert ExtractionMethod.EMPTY.value == "empty"


# ── Tests: import from package ─────────────────────────────────────────

class TestPackageImports:
    def test_import_from_parsica_memory(self):
        from parsica_memory import PDFIngester as PI
        assert PI is PDFIngester

    def test_import_convenience_functions(self):
        from parsica_memory import pdf_extract_text, pdf_extract_chunks, ingest_pdf
        assert callable(pdf_extract_text)
        assert callable(pdf_extract_chunks)
        assert callable(ingest_pdf)


# ── Tests: PDFMetadata ─────────────────────────────────────────────────

class TestPDFMetadata:
    def test_defaults(self):
        m = PDFMetadata()
        assert m.title == ""
        assert m.page_count == 0
        assert m.is_encrypted is False

    def test_with_values(self):
        m = PDFMetadata(
            title="My Document",
            author="Test Author",
            page_count=10,
            file_size=50000,
        )
        assert m.title == "My Document"
        assert m.author == "Test Author"
        assert m.page_count == 10
