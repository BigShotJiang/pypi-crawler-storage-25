"""Tests for SearchResult.search_provenance property (v3.1.6 expanded)."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from parsica_memory import MemorySystem


def test_search_result_provenance_has_expected_fields(tmp_path):
    """Provenance dict contains all v3.1.6 fields."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("PostgreSQL migration succeeded", source="deploy", category="tactical", source_channel="discord:123")
    result = mem.search("PostgreSQL", explain=True)[0]
    prov = result.search_provenance
    expected_keys = {"source", "created", "tags", "source_channel", "score", "matched_terms", "breakdown"}
    assert set(prov.keys()) == expected_keys


def test_search_result_provenance_is_read_only_property(tmp_path):
    """Cannot reassign .search_provenance (it's a @property)."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("JWT auth uses refresh tokens", source="docs")
    result = mem.search("JWT", explain=True)[0]
    import pytest
    with pytest.raises(AttributeError):
        result.search_provenance = {}


def test_search_result_provenance_breakdown_is_dict(tmp_path):
    """breakdown field is always a dict (never None)."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("Database backup strategy needs review", source="planning")
    result = mem.search("backup", explain=True)[0]
    assert isinstance(result.search_provenance["breakdown"], dict)


def test_search_result_provenance_source_channel_defaults_empty(tmp_path):
    """source_channel defaults to empty string when not set."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("Call with ops team tomorrow", source="calendar")
    result = mem.search("ops", explain=True)[0]
    assert result.search_provenance["source_channel"] == ""


def test_search_result_provenance_score_is_rounded(tmp_path):
    """Score is rounded to 4 decimal places."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("The API returns a 500 error", source="logs")
    result = mem.search("500 error", explain=True)[0]
    score = result.search_provenance["score"]
    assert score == round(score, 4)


def test_search_result_provenance_matched_terms_is_list(tmp_path):
    """matched_terms is always a list."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("Redis cache invalidation strategy", source="arch")
    result = mem.search("Redis cache", explain=True)[0]
    mt = result.search_provenance["matched_terms"]
    assert isinstance(mt, list)


def test_search_result_provenance_source_channel_preserved(tmp_path):
    """source_channel is preserved when set on the entry."""
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("Deployed v2 to staging", source="ci", source_channel="discord:456")
    result = mem.search("staging", explain=True)[0]
    assert result.search_provenance["source_channel"] == "discord:456"
