"""Tests for Parsica Memory v3.1 — Quality Levers + Transparency.

Tests:
1. Score breakdown in search results
2. Enhanced _explain output includes breakdown
3. InputGate classifications
4. CLI explain command
5. CLI enrich command (coverage mode)
6. _score_entry returns 3-tuple with breakdown
7. Enrichment/decomposition toggle wiring affects ingest behavior
"""
import os
import sys
import tempfile
from types import SimpleNamespace
import pytest

# Ensure parsica_memory is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestScoreBreakdown:
    """Test that search results include per-component score breakdowns."""

    def test_search_result_has_breakdown(self):
        """SearchResult objects should have a _breakdown attribute after v3.1."""
        from parsica_memory.core import MemorySystem
        with tempfile.TemporaryDirectory() as ws:
            ms = MemorySystem(workspace=ws, agent_name='test')
            ms.ingest("The database migration failed on Tuesday", source='test')
            ms.ingest("We decided to use PostgreSQL for the project", source='test')
            ms.save()

            results = ms.search("database", explain=True)
            assert len(results) > 0
            for r in results:
                assert hasattr(r, '_breakdown'), "SearchResult should have _breakdown attribute"
                assert isinstance(r._breakdown, dict), "_breakdown should be a dict"

    def test_breakdown_contains_expected_keys(self):
        """Breakdown dict should contain standard scoring components."""
        from parsica_memory.core import MemorySystem
        with tempfile.TemporaryDirectory() as ws:
            ms = MemorySystem(workspace=ws, agent_name='test')
            ms.ingest("The API endpoint returns a 500 error", source='test')
            ms.save()

            results = ms.search("API error", explain=True)
            assert len(results) > 0
            bd = results[0]._breakdown
            assert 'final_score' in bd
            assert 'terms_matched' in bd

    def test_explanation_includes_breakdown(self):
        """The explanation string should include breakdown info."""
        from parsica_memory.core import MemorySystem
        with tempfile.TemporaryDirectory() as ws:
            ms = MemorySystem(workspace=ws, agent_name='test')
            ms.ingest("Critical security vulnerability in the auth module", source='test')
            ms.save()

            results = ms.search("security vulnerability", explain=True)
            assert len(results) > 0
            assert 'breakdown' in results[0].explanation


class TestInputGating:
    """Test that InputGate classifies content correctly."""

    def test_p0_security(self):
        from parsica_memory.gating import InputGate
        gate = InputGate()
        assert gate.classify("Critical security breach detected in production") == "P0"

    def test_p1_decision(self):
        from parsica_memory.gating import InputGate
        gate = InputGate()
        assert gate.classify("We decided to use React for the frontend") == "P1"

    def test_p3_greeting(self):
        from parsica_memory.gating import InputGate
        gate = InputGate()
        assert gate.classify("hi") == "P3"

    def test_p3_short(self):
        from parsica_memory.gating import InputGate
        gate = InputGate()
        assert gate.classify("ok") == "P3"

    def test_should_store_filters_p3(self):
        from parsica_memory.gating import InputGate
        gate = InputGate()
        assert gate.should_store("hi") is False
        assert gate.should_store("The server crashed with OOM error") is True

    def test_route_returns_dict(self):
        from parsica_memory.gating import InputGate
        gate = InputGate()
        result = gate.route("Budget approved for Q3")
        assert 'priority' in result
        assert 'category' in result
        assert 'store' in result


class TestCLIExplain:
    """Test the parsica explain CLI command."""

    def test_explain_command_exists(self):
        """The explain command should be registered in the CLI parser."""
        from parsica_memory.cli import main
        with pytest.raises(SystemExit) as exc:
            main(['explain', '--help'])
        assert exc.value.code == 0

    def test_enrich_command_exists(self):
        """The enrich command should be registered in the CLI parser."""
        from parsica_memory.cli import main
        with pytest.raises(SystemExit) as exc:
            main(['enrich', '--help'])
        assert exc.value.code == 0

    def test_enrich_coverage_on_empty_workspace(self):
        """Coverage mode on an empty workspace should work."""
        from parsica_memory.cli import main
        with tempfile.TemporaryDirectory() as ws:
            result = main(['enrich', '--workspace', ws, '--coverage'])
            assert result == 0


class TestSearchEngineScoreEntry:
    """Test that _score_entry returns breakdown dict."""

    def test_score_entry_returns_3_tuple(self):
        """_score_entry should return (score, matched, breakdown)."""
        from parsica_memory.core import MemorySystem

        with tempfile.TemporaryDirectory() as ws:
            ms = MemorySystem(workspace=ws, agent_name='test')
            ms.ingest("The deployment pipeline uses Docker containers", source='test')
            ms.save()

            engine = ms.search_engine
            engine.build_index(ms.memories)
            tokens = engine._tokenize("Docker deployment")
            result = engine._score_entry(ms.memories[0], tokens, "docker deployment")
            assert len(result) == 3, f"Expected 3-tuple, got {len(result)}-tuple"
            score, matched, breakdown = result
            assert isinstance(score, (int, float))
            assert isinstance(matched, list)
            assert isinstance(breakdown, dict)


class TestV31ToggleWiring:
    def test_enrichment_toggle_disables_ingest_enrichment(self):
        from parsica_memory.core_v4 import MemorySystemV4

        calls = []

        def enricher(text):
            calls.append(text)
            return {
                "summary": "Enriched summary",
                "tags": ["alpha"],
                "keywords": ["beta"],
            }

        with tempfile.TemporaryDirectory() as ws:
            ms = MemorySystemV4(workspace=ws, agent_name='test', enricher=enricher)
            ms._enrichment_enabled = False
            ms.ingest("This memory should not be enriched during ingest", source='test')
            assert calls == []
            assert len(ms.memories) == 1
            assert getattr(ms.memories[0], 'enriched_summary', '') == ''

    def test_decomposition_toggle_disables_fact_creation(self):
        from parsica_memory.core_v4 import MemorySystemV4

        def enricher(_text):
            return {
                "summary": "summary",
                "facts": ["Parsica stores memory as durable facts."],
            }

        with tempfile.TemporaryDirectory() as ws:
            ms = MemorySystemV4(workspace=ws, agent_name='test', enricher=enricher)
            ms._enrichment_enabled = True
            ms._decomposition_enabled = False
            ms.ingest("Parsica stores memory durably.", source='test')
            assert len(ms.memories) == 1
            assert all(m.memory_type != 'fact' for m in ms.memories)

    def test_decomposition_toggle_enables_fact_creation(self):
        from parsica_memory.core_v4 import MemorySystemV4

        def enricher(_text):
            return {
                "summary": "summary",
                "facts": ["Parsica stores memory as durable facts."],
            }

        with tempfile.TemporaryDirectory() as ws:
            ms = MemorySystemV4(workspace=ws, agent_name='test', enricher=enricher)
            ms._enrichment_enabled = True
            ms._decomposition_enabled = True
            ms.ingest("Parsica stores memory durably.", source='test')
            assert any(m.memory_type == 'fact' for m in ms.memories)

    def test_pipeline_bridge_toggle_targets_memory_state(self):
        bridge_path = os.path.join(os.path.dirname(__file__), '..', 'openclaw-plugin', 'pipeline_bridge.py')
        text = open(bridge_path, encoding='utf-8').read()
        assert "mem._enrichment_enabled = bool(enabled)" in text
        assert "mem._decomposition_enabled = bool(enabled)" in text
