"""Tests for parsica_memory.proactive — ProactiveMemory."""

import json
import os
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from parsica_memory import MemorySystem, ProactiveMemory


# --- Scan ---

def test_proactive_scan_creates_note(tmp_path):
    pm = ProactiveMemory(tmp_path)
    created = pm.scan("u1", "I need to submit the report tomorrow")
    assert len(created) == 1
    assert created[0]["category"] in {"task", "temporal"}
    assert (tmp_path / "proactive" / "u1.json").exists()


def test_proactive_scan_ignores_empty(tmp_path):
    pm = ProactiveMemory(tmp_path)
    assert pm.scan("u1", "") == []


def test_proactive_scan_ignores_unmatched(tmp_path):
    pm = ProactiveMemory(tmp_path)
    assert pm.scan("u1", "The weather is nice today") == []


def test_proactive_safe_key_filename(tmp_path):
    pm = ProactiveMemory(tmp_path)
    pm.scan("discord:user/123", "I need to renew my license tomorrow")
    files = list((tmp_path / "proactive").glob("*.json"))
    assert len(files) == 1


# --- Surface + Temporal Scheduling ---

def test_proactive_surface_immediate_note_on_greeting(tmp_path):
    """Notes WITHOUT surface_after should surface immediately on greeting."""
    pm = ProactiveMemory(tmp_path)
    # "I love hiking" → preference, no temporal → no surface_after
    pm.scan("u1", "I love hiking in the mountains")
    surfaced = pm.surface("u1", "good morning")
    assert surfaced
    assert "hiking" in surfaced[0].lower()


def test_proactive_surface_after_respected(tmp_path):
    """Notes with future surface_after should NOT surface until that time."""
    pm = ProactiveMemory(tmp_path)
    pm.scan("u1", "I need to call the bank tomorrow")
    # "tomorrow" sets surface_after to tomorrow 7am — should NOT surface now
    surfaced = pm.surface("u1", "good morning")
    assert surfaced == []


def test_proactive_surface_after_past_does_surface(tmp_path):
    """Notes with surface_after in the PAST should surface."""
    pm = ProactiveMemory(tmp_path)
    path = tmp_path / "proactive" / "u1.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
    path.write_text(json.dumps([{
        "text": "call the bank",
        "category": "task",
        "created": yesterday,
        "surface_after": yesterday,  # in the past
        "surfaced": False,
    }]))
    surfaced = pm.surface("u1", "hi")
    assert surfaced
    assert "call the bank" in surfaced[0]


def test_proactive_does_not_surface_without_greeting(tmp_path):
    pm = ProactiveMemory(tmp_path)
    pm.scan("u1", "I love cooking Italian food")
    assert pm.surface("u1", "what's the weather") == []


def test_proactive_marks_note_surfaced(tmp_path):
    pm = ProactiveMemory(tmp_path)
    pm.scan("u1", "I love cooking Italian food")
    pm.surface("u1", "hi")
    notes = json.loads((tmp_path / "proactive" / "u1.json").read_text())
    assert any(n["surfaced"] is True for n in notes)


def test_proactive_multiple_surface_calls_do_not_repeat(tmp_path):
    pm = ProactiveMemory(tmp_path)
    pm.scan("u1", "I prefer dark mode for everything")
    first = pm.surface("u1", "hi")
    assert first
    second = pm.surface("u1", "hi")
    assert second == []


# --- Get Active ---

def test_proactive_get_active_returns_dicts(tmp_path):
    pm = ProactiveMemory(tmp_path)
    pm.scan("u1", "My favorite color is blue")
    active = pm.get_active("u1", "morning")
    assert isinstance(active, list)
    assert len(active) > 0
    assert isinstance(active[0], dict)


# --- Prune ---

def test_proactive_prune_removes_old_surfaced_notes(tmp_path):
    pm = ProactiveMemory(tmp_path)
    path = tmp_path / "proactive" / "u1.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps([
        {"text": "old", "category": "task", "created": "2000-01-01T00:00:00+00:00", "surface_after": "", "surfaced": True},
        {"text": "new", "category": "task", "created": "2999-01-01T00:00:00+00:00", "surface_after": "", "surfaced": True},
    ]))
    removed = pm.prune("u1", days=7)
    assert removed == 1
    remaining = json.loads(path.read_text())
    assert len(remaining) == 1
    assert remaining[0]["text"] == "new"


# --- Temporal extraction ---

def test_proactive_tomorrow_sets_surface_after(tmp_path):
    pm = ProactiveMemory(tmp_path)
    created = pm.scan("u1", "I need to renew my license tomorrow")
    assert created[0]["surface_after"]


def test_proactive_tonight_sets_surface_after(tmp_path):
    pm = ProactiveMemory(tmp_path)
    created = pm.scan("u1", "I have a meeting tonight")
    assert created[0]["surface_after"]


# --- MemorySystem integration ---

def test_memorysystem_has_proactive(tmp_path):
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    assert hasattr(mem, "proactive")
    assert isinstance(mem.proactive, ProactiveMemory)


def test_memorysystem_scan_proactive(tmp_path):
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    result = mem.scan_proactive("u1", "I prefer dark mode")
    assert isinstance(result, list)


def test_memorysystem_ingest_triggers_proactive_scan(tmp_path):
    mem = MemorySystem(workspace=str(tmp_path), use_sharding=False, enable_read_cache=False)
    mem.ingest("I love Italian food", session_id="s1")
    # The ingest should have triggered a proactive scan
    active = mem.proactive.get_active("s1", "hi")
    assert active
