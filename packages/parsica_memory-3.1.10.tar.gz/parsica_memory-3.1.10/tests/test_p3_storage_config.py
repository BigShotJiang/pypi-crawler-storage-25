import json
from types import SimpleNamespace
from parsica_memory.cli import cmd_init
from parsica_memory.manager import MemoryManager

def test_storage_mode_tiered_storage(tmp_path):
    mm = MemoryManager(str(tmp_path / "store"), storage_mode="tiered_storage")
    assert mm._storage_mode == "tiered_storage"

def test_storage_mode_enterprise(tmp_path):
    mm = MemoryManager(str(tmp_path / "store"), storage_mode="enterprise")
    assert mm._storage_mode == "enterprise"

def test_storage_mode_legacy(tmp_path):
    mm = MemoryManager(str(tmp_path / "store"), storage_mode="legacy")
    assert mm._storage_mode == "legacy"

def test_storage_mode_default_is_none(tmp_path):
    mm = MemoryManager(str(tmp_path / "store"))
    assert mm._storage_mode is None

def test_storage_mode_rejects_unknown(tmp_path):
    try:
        MemoryManager(str(tmp_path / "store"), storage_mode="mystery")
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError")

def test_storage_mode_aliases(tmp_path):
    mm1 = MemoryManager(str(tmp_path / "s1"), storage_mode="sharded")
    assert mm1._storage_mode == "enterprise"
    mm2 = MemoryManager(str(tmp_path / "s2"), storage_mode="tiered")
    assert mm2._storage_mode == "tiered_storage"

def test_cli_init_writes_storage_mode(tmp_path, monkeypatch, capsys):
    workspace = tmp_path / "workspace"
    args = SimpleNamespace(workspace=str(workspace), agent_name="ci-agent", force=False, headless=True)
    monkeypatch.setattr("parsica_memory.cli.sys.stdin.isatty", lambda: False)
    monkeypatch.setattr("parsica_memory.cli.sys.stdout.isatty", lambda: False)
    code = cmd_init(args)
    assert code == 0
    config_name = "parsica_config.json" if (workspace / "parsica_config.json").exists() else "antaris_config.json"
    cfg = json.loads((workspace / config_name).read_text())
    assert cfg["settings"]["storage_mode"] == "legacy"
