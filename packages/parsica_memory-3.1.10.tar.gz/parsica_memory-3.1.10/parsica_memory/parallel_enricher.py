"""parallel_enricher.py - Multi-key parallel enrichment runner.

Splits un-enriched memories evenly across multiple API keys and enriches
them concurrently, one thread per key. Supports foreground and background
execution modes.

Example usage::

    from parsica_memory.parallel_enricher import ParallelEnricher

    enricher = ParallelEnricher(
        workspace="./my-store",
        keys=[
            {"key": "sk-ant-...", "provider": "anthropic", "model": "claude-haiku-4-5"},
            {"key": "sk-...", "provider": "openai", "model": "gpt-4o-mini"},
        ],
        decompose=True,
    )

    # Foreground (blocking)
    stats = enricher.run(progress_fn=lambda done, total: print(f"{done}/{total}"))

    # Background (non-blocking)
    job_id = enricher.run_background()
    # … later …
    status = enricher.status(job_id)
"""

from __future__ import annotations

import threading
import time
import uuid
from typing import Callable, Dict, List, Optional

# ---------------------------------------------------------------------------
# Lazy imports - keep module importable even if parsica_memory isn't fully
# installed yet (e.g. during editable-install testing).
# ---------------------------------------------------------------------------


def _import_deps():
    from parsica_memory.core_v4 import MemorySystemV4 as MemorySystem  # noqa: F401
    from parsica_memory.enrichers import smart_enricher, _detect_provider  # noqa: F401
    from parsica_memory.entry import MemoryEntry  # noqa: F401

    return MemorySystem, smart_enricher, _detect_provider, MemoryEntry


class ParallelEnricher:
    """Run enrichment in parallel threads, one per API key.

    Parameters
    ----------
    workspace:
        Path to the MemorySystem workspace directory.
    keys:
        List of key config dicts.  Each dict must have a ``"key"`` field and
        may optionally include ``"provider"`` and ``"model"``.  If
        ``"provider"`` is omitted it is auto-detected from the key prefix via
        ``_detect_provider``.
    decompose:
        When *True* (default), the enricher also extracts atomic facts and
        stores them as separate ``memory_type="fact"`` entries - identical to
        the behaviour added to ``re_enrich(decompose=True)``.
    agent_name:
        Optional agent name passed to ``MemorySystem``.  Defaults to
        ``"parallel-enricher"``.
    overwrite:
        When *True*, re-enrich entries that already have an
        ``enriched_summary``.  Defaults to *False* (idempotent).
    """

    def __init__(
        self,
        workspace: str,
        keys: List[Dict],
        decompose: bool = True,
        agent_name: str = "parallel-enricher",
        overwrite: bool = False,
    ) -> None:
        if not keys:
            raise ValueError("At least one key must be provided.")

        self.workspace = workspace
        self.keys = keys
        self.decompose = decompose
        self.agent_name = agent_name
        self.overwrite = overwrite

        # Background job state: job_id -> status dict
        self._jobs: Dict[str, Dict] = {}
        self._jobs_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self, progress_fn: Optional[Callable[[int, int], None]] = None) -> Dict:
        """Run parallel enrichment in the current thread (blocking).

        Parameters
        ----------
        progress_fn:
            Optional callable ``(enriched_so_far: int, total: int)`` fired
            after each entry is enriched, from any worker thread.  Must be
            thread-safe.

        Returns
        -------
        dict with keys:
            ``enriched`` - total entries enriched
            ``facts_created`` - total fact entries created (decompose mode)
            ``errors`` - total exceptions swallowed
            ``duration_s`` - wall-clock seconds
            ``per_key`` - per-key sub-stats list
        """
        return self._run_sync(progress_fn=progress_fn)

    def run_background(self) -> str:
        """Start enrichment in a background daemon thread.

        Returns
        -------
        str
            A *job_id* you can pass to :meth:`status` to poll progress.
        """
        job_id = str(uuid.uuid4())
        with self._jobs_lock:
            self._jobs[job_id] = {
                "state": "running",
                "enriched": 0,
                "total": 0,
                "facts_created": 0,
                "errors": 0,
                "started_at": time.time(),
                "finished_at": None,
                "result": None,
            }

        def _worker():
            def _progress(done: int, total: int) -> None:
                with self._jobs_lock:
                    self._jobs[job_id]["enriched"] = done
                    self._jobs[job_id]["total"] = total

            try:
                result = self._run_sync(progress_fn=_progress)
            except Exception as exc:
                result = {"error": str(exc)}

            with self._jobs_lock:
                self._jobs[job_id]["state"] = "done"
                self._jobs[job_id]["finished_at"] = time.time()
                self._jobs[job_id]["result"] = result
                if result:
                    self._jobs[job_id]["enriched"] = result.get("enriched", 0)
                    self._jobs[job_id]["facts_created"] = result.get("facts_created", 0)
                    self._jobs[job_id]["errors"] = result.get("errors", 0)

        # Issue 2 fix: use daemon=False so the thread is not killed on process exit.
        t = threading.Thread(target=_worker, daemon=False, name=f"parallel-enricher-{job_id[:8]}")
        t.start()
        return job_id

    def status(self, job_id: str) -> Dict:
        """Return the current status of a background job.

        Parameters
        ----------
        job_id:
            The id returned by :meth:`run_background`.

        Returns
        -------
        dict with keys:
            ``state`` - ``"running"`` or ``"done"``
            ``enriched`` - entries enriched so far
            ``total`` - total entries to process
            ``facts_created`` - fact entries created (decompose mode)
            ``errors`` - errors swallowed
            ``started_at`` - Unix timestamp
            ``finished_at`` - Unix timestamp or *None*
            ``result`` - final stats dict (only set when ``state == "done"``)

        Raises
        ------
        KeyError
            If *job_id* is unknown.
        """
        with self._jobs_lock:
            if job_id not in self._jobs:
                raise KeyError(f"Unknown job_id: {job_id!r}")
            return dict(self._jobs[job_id])

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_sync(
        self, progress_fn: Optional[Callable[[int, int], None]] = None
    ) -> Dict:
        """Core implementation: build enrichers, partition work, run threads."""
        MemorySystem, smart_enricher, _detect_provider, MemoryEntry = _import_deps()

        # ── 1. Load the MemorySystem (no enricher - we manage enrichment here) ──
        mem = MemorySystem(self.workspace, agent_name=self.agent_name)

        # ── 2. Identify un-enriched entries ──
        if self.overwrite:
            targets = [
                e for e in mem.memories if e.memory_type != "fact"
            ]
        else:
            targets = [
                e for e in mem.memories
                if e.memory_type != "fact"
                and not getattr(e, "enriched_summary", "")
            ]

        total = len(targets)
        if total == 0:
            return {
                "enriched": 0,
                "facts_created": 0,
                "errors": 0,
                "duration_s": 0.0,
                "per_key": [],
            }

        # ── 3. Build enricher callables from key configs ──
        enrichers = []
        for cfg in self.keys:
            raw_key = cfg.get("key", "").strip()
            if not raw_key:
                continue
            provider = cfg.get("provider") or _detect_provider(raw_key)
            model = cfg.get("model") or None
            base_url = cfg.get("base_url") or None
            fn = smart_enricher(raw_key, model=model, base_url=base_url)
            if fn is not None:
                enrichers.append({"enricher": fn, "key_hint": raw_key[:12] + "…", "provider": provider})

        if not enrichers:
            raise ValueError("No valid enrichers could be constructed from the provided keys.")

        # ── 4. Partition entries evenly across enrichers ──
        slices = _partition(targets, len(enrichers))

        # ── 5. Shared state ──
        lock = threading.Lock()
        global_enriched_count = [0]
        global_facts_count = [0]
        global_errors_count = [0]
        per_key_stats: List[Dict] = [{} for _ in enrichers]

        start_ts = time.time()

        # ── 6. Worker factory ──
        def make_worker(enricher_fn, entry_slice, slot_idx):
            def worker():
                local_enriched = 0
                local_facts = 0
                local_errors = 0

                for entry in entry_slice:
                    try:
                        enrichment = enricher_fn(entry.content)
                        if enrichment and isinstance(enrichment, dict):
                            with lock:
                                # Update entry fields
                                if enrichment.get("tags"):
                                    entry.tags = sorted(
                                        set(entry.tags)
                                        | {t.lower() for t in enrichment["tags"]}
                                    )
                                if enrichment.get("summary"):
                                    entry.enriched_summary = str(enrichment["summary"])
                                if enrichment.get("keywords"):
                                    entry.search_keywords = [
                                        str(k).lower() for k in enrichment["keywords"]
                                    ]
                                if enrichment.get("search_queries"):
                                    entry.search_queries = [
                                        str(q) for q in enrichment["search_queries"]
                                    ]
                                mem._feed_cooccurrence_from_enrichment(entry.content, enrichment)
                                mem._enrichment_count += 1

                                # Fact decomposition
                                if self.decompose:
                                    facts = enrichment.get("facts", [])
                                    if facts and isinstance(facts, list):
                                        for fact_text in facts:
                                            if (
                                                not isinstance(fact_text, str)
                                                or len(fact_text.strip()) < 10
                                            ):
                                                continue
                                            fact_entry = MemoryEntry(
                                                fact_text.strip(),
                                                source=entry.source,
                                                line=0,
                                                category=entry.category,
                                                memory_type="fact",
                                                session_id=getattr(entry, "session_id", ""),
                                                agent_id=getattr(
                                                    entry, "agent_id", mem.agent_name
                                                ),
                                            )
                                            fact_entry.provenance = "decomposed"
                                            fact_entry.parent_hash = entry.hash
                                            fact_entry.confidence = 0.8
                                            fact_entry.tags = list(
                                                getattr(entry, "tags", [])
                                            )

                                            if fact_entry.hash in mem._hashes:
                                                continue
                                            fact_norm = fact_text.strip().lower()
                                            if fact_norm in mem._content_norms:
                                                continue
                                            existing = mem._find_similar_fact(
                                                fact_entry.content, threshold=0.85
                                            )
                                            if existing is not None:
                                                mem._bump_sighting(existing)
                                                continue

                                            mem.memories.append(fact_entry)
                                            mem._hashes.add(fact_entry.hash)
                                            mem._content_norms.add(fact_norm)
                                            mem._index_fact(fact_entry)
                                            mem.search_engine.mark_dirty()
                                            if mem.use_indexing and mem.index_manager:
                                                mem.index_manager.add_memory(fact_entry)
                                            mem._wal.append(fact_entry.to_dict())
                                            local_facts += 1

                            local_enriched += 1

                            # Atomic progress counter
                            with lock:
                                global_enriched_count[0] += 1
                                # Issue 1 fix: do NOT add local_facts here — it's
                                # cumulative and would double-count on every iteration.
                                # global_facts_count is updated ONCE after the loop.
                                if progress_fn:
                                    try:
                                        progress_fn(global_enriched_count[0], total)
                                    except Exception:
                                        pass

                        # Issue 4 fix: basic rate limiting between entries
                        time.sleep(0.1)

                    except Exception as exc:
                        error_str = str(exc)
                        if (
                            "429" in error_str
                            or "rate" in error_str.lower()
                            or "overloaded" in error_str.lower()
                        ):
                            time.sleep(5)  # Back off on rate limit; don't count as error
                        else:
                            local_errors += 1
                            with lock:
                                global_errors_count[0] += 1

                # Issue 1 fix: update global_facts_count ONCE here, after the
                # worker's loop finishes, using the final local_facts total.
                with lock:
                    global_facts_count[0] += local_facts

                per_key_stats[slot_idx] = {
                    "enriched": local_enriched,
                    "facts_created": local_facts,
                    "errors": local_errors,
                }

            return worker

        # ── 7. Launch threads ──
        threads = []
        for idx, (enricher_info, entry_slice) in enumerate(zip(enrichers, slices)):
            t = threading.Thread(
                target=make_worker(enricher_info["enricher"], entry_slice, idx),
                daemon=False,
                name=f"enricher-{idx}-{enricher_info['provider']}",
            )
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # ── 8. Persist ──
        if global_enriched_count[0]:
            mem.search_engine.mark_dirty()
            try:
                mem.save()
            except Exception:
                pass
            try:
                mem._cooccurrence.save()
            except Exception:
                pass

        duration = time.time() - start_ts

        # Annotate per-key stats with provider/model info
        for idx, stat in enumerate(per_key_stats):
            if idx < len(enrichers):
                stat["key_hint"] = enrichers[idx]["key_hint"]
                stat["provider"] = enrichers[idx]["provider"]

        return {
            "enriched": global_enriched_count[0],
            "facts_created": global_facts_count[0],
            "errors": global_errors_count[0],
            "duration_s": round(duration, 2),
            "per_key": per_key_stats,
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _partition(items: list, n: int) -> List[list]:
    """Split *items* into *n* roughly equal sub-lists."""
    if n <= 0:
        return [items]
    size = max(1, len(items) // n)
    slices = []
    for i in range(n):
        start = i * size
        # Last slice gets any remainder
        end = start + size if i < n - 1 else len(items)
        slices.append(items[start:end])
    return slices


# ---------------------------------------------------------------------------
# Wizard helpers: key-rate estimation and un-enriched count
# ---------------------------------------------------------------------------

#: Approximate memories-per-minute for a standard API key.
STANDARD_RATE: int = 50

#: Approximate memories-per-minute for an OAuth key (sk-ant-oat prefix).
OAUTH_RATE: int = 10


def _key_rate(api_key: str) -> int:
    """Return estimated memories-per-minute throughput for *api_key*."""
    if api_key.startswith("sk-ant-oat"):
        return OAUTH_RATE
    return STANDARD_RATE


def _combined_rate(api_keys: List[str]) -> int:
    """Return combined throughput across all *api_keys*."""
    return sum(_key_rate(k) for k in api_keys)


def estimate_minutes(memory_count: int, api_keys: List[str]) -> int:
    """Estimate enrichment time in minutes.

    Args:
        memory_count: Number of un-enriched memories.
        api_keys: List of API keys that will be used in parallel.

    Returns:
        Estimated minutes (minimum 1 when count > 0, else 0).
    """
    if not api_keys or memory_count == 0:
        return 0
    rate = _combined_rate(api_keys)
    return max(1, round(memory_count / rate))


def _scan_json_file(path, total: int, unenriched: int):
    """Scan a single JSON/JSONL file and return updated (total, unenriched) counts."""
    import json
    from pathlib import Path

    path = Path(path)
    try:
        suffix = path.suffix.lower()
        if suffix == ".jsonl":
            with open(path) as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                        total += 1
                        if _record_is_unenriched(record):
                            unenriched += 1
                    except json.JSONDecodeError:
                        pass
        elif suffix == ".json":
            with open(path) as fh:
                data = json.load(fh)
            records = (
                data if isinstance(data, list)
                else data.get("memories", data.get("records", []))
            )
            for record in records:
                total += 1
                if _record_is_unenriched(record):
                    unenriched += 1
    except Exception:
        pass
    return total, unenriched


def count_unenriched(workspace: str) -> int:
    """Count memories in *workspace* that lack enrichment metadata.

    Scans JSONL/JSON memory store files for records without
    ``enriched_summary`` or ``tags`` fields.

    Returns 0 if workspace or memory store is not found.
    """
    import json
    from pathlib import Path

    ws = Path(workspace)
    # Issue 5 fix: add memory_metadata.json to candidates
    store_candidates = [
        ws / "memories.jsonl",
        ws / "memories.json",
        ws / "store.jsonl",
        ws / "store.json",
        ws / "memory_metadata.json",
    ]

    for store_path in store_candidates:
        if store_path.exists():
            return _count_unenriched_in_file(store_path)

    # Check sharded stores (flat-file shards)
    total = 0
    unenriched = 0
    for shard_file in list(ws.glob("shard_*.jsonl")) + list(ws.glob("memories_*.jsonl")):
        total, unenriched = _scan_json_file(shard_file, total, unenriched)

    # Issue 5 fix: also check shards/ subdirectory format
    shards_dir = ws / "shards"
    if shards_dir.is_dir():
        for shard_file in shards_dir.glob("*.json"):
            total, unenriched = _scan_json_file(shard_file, total, unenriched)

    return unenriched


def _count_unenriched_in_file(path) -> int:
    """Count records in a single file that lack enrichment metadata."""
    import json
    from pathlib import Path

    path = Path(path)
    count = 0
    try:
        suffix = path.suffix.lower()
        if suffix == ".jsonl":
            with open(path) as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                        if _record_is_unenriched(record):
                            count += 1
                    except json.JSONDecodeError:
                        pass
        elif suffix == ".json":
            with open(path) as fh:
                data = json.load(fh)
            records = (
                data if isinstance(data, list)
                else data.get("memories", data.get("records", []))
            )
            for record in records:
                if _record_is_unenriched(record):
                    count += 1
    except Exception:
        pass
    return count


def _record_is_unenriched(record: dict) -> bool:
    """Return True if *record* does not have enrichment metadata."""
    has_summary = bool(record.get("enriched_summary") or record.get("summary"))
    has_tags = bool(record.get("tags"))
    return not (has_summary and has_tags)
