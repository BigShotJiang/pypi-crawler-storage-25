"""
Team Memory — Shared memory pools with RBAC, conflict resolution, and cross-agent recall.

Enables multiple agents to share a common memory pool with role-based access control,
deterministic conflict resolution, and the ability to query other agents' private memories.

Architecture:
- SharedPool: The core shared memory container
- AgentRole: READER (read-only), WRITER (read+write), COORDINATOR (full control)
- AgentConfig: Agent registration with role and trust score
- File locking: Uses existing FileLock for concurrent access safety
"""

import json
import os
import glob
import re
import time
from dataclasses import dataclass, asdict
from enum import Enum
from typing import List, Dict, Optional

from .entry import MemoryEntry
from .search import SearchEngine
from .locking import FileLock


class AgentRole(Enum):
    """Agent roles in a shared memory pool."""
    READER = "reader"
    WRITER = "writer" 
    COORDINATOR = "coordinator"


@dataclass
class AgentConfig:
    """Agent configuration for shared memory pool access."""
    agent_id: str
    role: AgentRole
    trust_score: float = 1.0  # 0.0 - 1.0


class SharedPool:
    """A shared memory pool accessible by multiple agents.
    
    Per-agent private memories live in the normal MemorySystem store.
    Shared knowledge lives here, namespaced separately.
    
    Storage layout:
    - {workspace}/.shared_pools/{pool_name}.json       → pool state
    - {workspace}/.shared_pools/{pool_name}_entries.jsonl → memory entries
    
    Access control:
    - READER: read() only
    - WRITER: read() + write() 
    - COORDINATOR: all methods + update_trust() + cross_agent_recall()
    
    Conflict resolution:
    - Higher trust_score wins
    - Equal trust: newer timestamp wins
    - Coordinator writes always win regardless of trust
    """
    
    def __init__(self, workspace: str, pool_name: str,
                 conflict_detection: bool = True,
                 conflict_threshold: float = 0.6):
        """
        Args:
            workspace: Path to memory workspace.
            pool_name: Unique name for this shared pool.
            conflict_detection: If False, skip conflict detection entirely.
                Useful when false positives are a problem or content is known-unique.
                Default True.
            conflict_threshold: Word-overlap ratio [0.0–1.0] required to flag a
                conflict. Higher = stricter (fewer false positives). Default 0.6.
        """
        self.workspace = workspace
        self.pool_name = pool_name
        self._conflict_detection = conflict_detection
        self._conflict_threshold = conflict_threshold
        self._pool_dir = os.path.join(workspace, ".shared_pools")
        self._state_path = os.path.join(self._pool_dir, f"{pool_name}.json")
        self._entries_path = os.path.join(self._pool_dir, f"{pool_name}_entries.jsonl")
        
        # Ensure pool directory exists
        os.makedirs(self._pool_dir, exist_ok=True)
        
        # Initialize empty state if needed
        if not os.path.exists(self._state_path):
            self._save_state({
                "version": 1,
                "pool_name": pool_name,
                "created_ts": time.time(),
                "agents": {},
                "entry_count": 0,
                "last_modified_ts": time.time()
            })
    
    def register_agent(self, config: AgentConfig) -> None:
        """Register an agent with a role in this pool."""
        with FileLock(self._state_path):
            state = self._load_state()
            state["agents"][config.agent_id] = {
                "role": config.role.value,
                "trust_score": max(0.0, min(1.0, config.trust_score)),  # Clamp to [0,1]
                "last_write_ts": time.time()
            }
            state["last_modified_ts"] = time.time()
            self._save_state(state)
    
    def write(self, agent_id: str, content: str, metadata: dict = None) -> Optional[str]:
        """Write to shared pool. Returns entry_id or None if not permitted."""
        agent_config = self.get_agent_config(agent_id)
        if not agent_config:
            return None  # Unregistered agent
            
        if agent_config.role == AgentRole.READER:
            return None  # Readers cannot write
        
        # Create memory entry
        entry = MemoryEntry(
            content=content,
            source=f"shared_pool:{self.pool_name}",
            category="shared",
            agent_id=agent_id
        )
        
        if metadata:
            # Apply metadata fields that exist on MemoryEntry
            for key, value in metadata.items():
                if hasattr(entry, key):
                    setattr(entry, key, value)
        
        # Convert to dict and add shared pool marker
        entry_dict = entry.to_dict()
        entry_dict["shared_pool"] = self.pool_name
        
        # Handle conflicts if entry with same hash exists
        with FileLock(self._entries_path):
            existing_entry = self._find_entry_by_hash(entry.hash)
            if existing_entry and self._conflict_detection:
                # Resolve conflict (gated by conflict_detection flag)
                resolved_entry = self.resolve_conflict(
                    entry.hash, 
                    entry, 
                    MemoryEntry.from_dict(existing_entry)
                )
                entry_dict = resolved_entry.to_dict()
                entry_dict["shared_pool"] = self.pool_name
                
                # Replace existing entry
                self._replace_entry(entry.hash, entry_dict)
            elif existing_entry:
                # conflict_detection disabled — overwrite with incoming
                self._replace_entry(entry.hash, entry_dict)
            else:
                # Append new entry
                self._append_entry(entry_dict)
                
                # Update entry count in state
                with FileLock(self._state_path):
                    state = self._load_state()
                    state["entry_count"] += 1
                    state["last_modified_ts"] = time.time()
                    if agent_id in state["agents"]:
                        state["agents"][agent_id]["last_write_ts"] = time.time()
                    self._save_state(state)
        
        return entry.hash
    
    def read(self, agent_id: str, query: str = None, limit: int = 10) -> List[MemoryEntry]:
        """Read from shared pool. All registered agents can read."""
        agent_config = self.get_agent_config(agent_id)
        if not agent_config:
            return []  # Unregistered agent cannot read
        
        # Load all entries from pool
        entries = self._load_all_entries()
        
        if not entries:
            return []
        
        if query is None:
            # Return recent entries (no search)
            entries.sort(key=lambda e: e.created, reverse=True)
            return entries[:limit]
        else:
            # BM25 search
            search_engine = SearchEngine()
            search_engine.build_index(entries)
            results = search_engine.search(query, entries, limit=limit)
            return [result.entry for result in results]
    
    def cross_agent_recall(self, requesting_agent: str, target_agent: str, 
                          target_workspace: str, query: str) -> List[MemoryEntry]:
        """Query: 'what does target_agent know about query?'
        
        Searches target agent's private store for relevant memories.
        Requires COORDINATOR role or explicit permission.
        """
        requesting_config = self.get_agent_config(requesting_agent)
        if not requesting_config or requesting_config.role != AgentRole.COORDINATOR:
            return []  # Permission denied
        
        # Scan target agent's private memory files
        matches = []
        
        # Look for shard files in target workspace
        # Pattern: {target_workspace}/agent_*.jsonl or similar
        shard_patterns = [
            os.path.join(target_workspace, f"*{target_agent}*.jsonl"),
            os.path.join(target_workspace, "*.jsonl"),  # Fallback to all jsonl files
        ]
        
        query_tokens = self._tokenize(query.lower())
        if not query_tokens:
            return []
            
        for pattern in shard_patterns:
            shard_files = glob.glob(pattern)
            for shard_file in shard_files:
                try:
                    with open(shard_file, 'r') as f:
                        for line in f:
                            line = line.strip()
                            if not line:
                                continue
                            try:
                                entry_data = json.loads(line)
                                # Filter by target agent if agent_id field exists
                                if 'agent_id' in entry_data and entry_data['agent_id'] != target_agent:
                                    continue
                                    
                                # Simple BM25-style matching
                                content = entry_data.get('content', '').lower()
                                content_tokens = self._tokenize(content)
                                
                                # Calculate simple relevance score
                                matches_found = sum(1 for token in query_tokens if token in content_tokens)
                                if matches_found > 0:
                                    relevance = matches_found / len(query_tokens)
                                    if relevance > 0.3:  # Minimum relevance threshold
                                        entry = MemoryEntry.from_dict(entry_data)
                                        matches.append((entry, relevance))
                                        
                            except json.JSONDecodeError:
                                continue
                except (OSError, IOError):
                    continue
        
        # Sort by relevance and return top entries
        matches.sort(key=lambda x: x[1], reverse=True)
        return [entry for entry, _ in matches[:10]]  # Limit to top 10
    
    def resolve_conflict(self, entry_id: str, incoming: MemoryEntry, 
                        existing: MemoryEntry) -> MemoryEntry:
        """Deterministic conflict resolution.
        
        Rules:
        1. Coordinator writes always win
        2. Higher trust_score wins 
        3. Equal trust: newer timestamp wins
        """
        incoming_agent = incoming.agent_id if hasattr(incoming, 'agent_id') else ""
        existing_agent = existing.agent_id if hasattr(existing, 'agent_id') else ""
        
        incoming_config = self.get_agent_config(incoming_agent)
        existing_config = self.get_agent_config(existing_agent)
        
        # Rule 1: Coordinator writes always win
        if incoming_config and incoming_config.role == AgentRole.COORDINATOR:
            return incoming
        if existing_config and existing_config.role == AgentRole.COORDINATOR:
            return existing
            
        # Rule 2: Higher trust score wins
        incoming_trust = incoming_config.trust_score if incoming_config else 0.0
        existing_trust = existing_config.trust_score if existing_config else 0.0
        
        if incoming_trust > existing_trust:
            return incoming
        elif existing_trust > incoming_trust:
            return existing
            
        # Rule 3: Equal trust - newer timestamp wins
        incoming_ts = self._parse_timestamp(incoming.created)
        existing_ts = self._parse_timestamp(existing.created)
        
        return incoming if incoming_ts >= existing_ts else existing
    
    def update_trust(self, coordinator_id: str, target_agent: str, delta: float) -> bool:
        """Adjust trust score. Only COORDINATORs can call this."""
        coordinator_config = self.get_agent_config(coordinator_id)
        if not coordinator_config or coordinator_config.role != AgentRole.COORDINATOR:
            return False
        
        with FileLock(self._state_path):
            state = self._load_state()
            if target_agent not in state["agents"]:
                return False
                
            # Apply delta and clamp to [0.0, 1.0]
            current_trust = state["agents"][target_agent]["trust_score"]
            new_trust = max(0.0, min(1.0, current_trust + delta))
            state["agents"][target_agent]["trust_score"] = new_trust
            state["last_modified_ts"] = time.time()
            self._save_state(state)
            
        return True
    
    def get_agent_config(self, agent_id: str) -> Optional[AgentConfig]:
        """Get agent's role and trust score."""
        state = self._load_state()
        if agent_id not in state["agents"]:
            return None
            
        agent_data = state["agents"][agent_id]
        return AgentConfig(
            agent_id=agent_id,
            role=AgentRole(agent_data["role"]),
            trust_score=agent_data["trust_score"]
        )
    
    def get_stats(self) -> dict:
        """Pool statistics: entry count, agent count, last write ts."""
        state = self._load_state()
        return {
            "pool_name": state["pool_name"],
            "entry_count": state["entry_count"],
            "agent_count": len(state["agents"]),
            "created_ts": state["created_ts"],
            "last_modified_ts": state["last_modified_ts"],
            "agents": {
                agent_id: {
                    "role": data["role"],
                    "trust_score": data["trust_score"],
                    "last_write_ts": data.get("last_write_ts", 0)
                }
                for agent_id, data in state["agents"].items()
            }
        }
    
    # Private helper methods
    
    def _load_state(self) -> dict:
        """Load pool state from JSON file."""
        try:
            with open(self._state_path, 'r') as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            # Return default state if file is missing or corrupted
            return {
                "version": 1,
                "pool_name": self.pool_name,
                "created_ts": time.time(),
                "agents": {},
                "entry_count": 0,
                "last_modified_ts": time.time()
            }
    
    def _save_state(self, state: dict) -> None:
        """Save pool state to JSON file."""
        try:
            with open(self._state_path, 'w') as f:
                json.dump(state, f, indent=2)
        except OSError:
            pass  # Non-fatal
    
    def _append_entry(self, entry_dict: dict) -> None:
        """Append entry to JSONL file."""
        try:
            with open(self._entries_path, 'a') as f:
                json.dump(entry_dict, f, separators=(',', ':'))
                f.write('\n')
        except OSError:
            pass  # Non-fatal
    
    def _replace_entry(self, entry_hash: str, new_entry_dict: dict) -> None:
        """Replace existing entry with same hash."""
        if not os.path.exists(self._entries_path):
            return
            
        temp_path = self._entries_path + ".tmp"
        try:
            with open(self._entries_path, 'r') as infile, \
                 open(temp_path, 'w') as outfile:
                for line in infile:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry_data = json.loads(line)
                        if entry_data.get("hash") == entry_hash:
                            # Replace with new entry
                            json.dump(new_entry_dict, outfile, separators=(',', ':'))
                        else:
                            # Keep existing entry
                            json.dump(entry_data, outfile, separators=(',', ':'))
                        outfile.write('\n')
                    except json.JSONDecodeError:
                        # Keep malformed lines as-is
                        outfile.write(line + '\n')
            
            # Atomic replace
            os.replace(temp_path, self._entries_path)
        except OSError:
            # Cleanup temp file on error
            if os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except OSError:
                    pass
    
    def _find_entry_by_hash(self, entry_hash: str) -> Optional[dict]:
        """Find entry by hash in JSONL file."""
        if not os.path.exists(self._entries_path):
            return None
            
        try:
            with open(self._entries_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry_data = json.loads(line)
                        if entry_data.get("hash") == entry_hash:
                            return entry_data
                    except json.JSONDecodeError:
                        continue
        except OSError:
            pass
        
        return None
    
    def _load_all_entries(self) -> List[MemoryEntry]:
        """Load all entries from JSONL file."""
        entries = []
        
        if not os.path.exists(self._entries_path):
            return entries
            
        try:
            with open(self._entries_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry_data = json.loads(line)
                        # Remove shared_pool field before creating MemoryEntry
                        entry_data.pop("shared_pool", None)
                        entry = MemoryEntry.from_dict(entry_data)
                        entries.append(entry)
                    except (json.JSONDecodeError, KeyError, ValueError):
                        continue
        except OSError:
            pass
        
        return entries
    
    def _tokenize(self, text: str) -> List[str]:
        """Simple tokenization for cross-agent recall search."""
        return [
            word.lower() for word in re.findall(r'\w{2,}', text)
            if len(word) >= 2
        ]
    
    def _parse_timestamp(self, timestamp_str: str) -> float:
        """Parse ISO timestamp to float for comparison."""
        try:
            # Handle ISO format timestamps
            from datetime import datetime
            if 'T' in timestamp_str:
                # ISO format
                dt = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                return dt.timestamp()
            else:
                # Assume it's already a float/int as string
                return float(timestamp_str)
        except (ValueError, TypeError):
            return 0.0