"""
Google Cloud Storage backend scaffold for parsica-memory.

Status: experimental stub. The interface is present for future backend work,
but the backend is not production-ready and is not part of the primary
OSS release path.
"""


class GCSMemoryBackend:
    """Google Cloud Storage backend scaffold for parsica-memory.

    This class preserves the planned backend interface without presenting it as
    a current front-door deployment option. The local filesystem backend
    remains the supported default path for the OSS release.

    Requires: google-cloud-storage (optional dependency)
    """

    def __init__(
        self,
        bucket: str,
        prefix: str = "",
        credentials_path: str = None,
    ):
        self.bucket = bucket
        self.prefix = prefix
        self._available = self._check_gcs_available()

    def _check_gcs_available(self) -> bool:
        try:
            import google.cloud.storage  # noqa
            return True
        except ImportError:
            return False

    def is_available(self) -> bool:
        """Return True if the google-cloud-storage package is installed."""
        return self._available

    def read_file(self, path: str) -> str:
        raise NotImplementedError(
            "GCSMemoryBackend.read_file() is still a stub (planned for v4.3.0). "
            "Use the local filesystem backend for supported OSS deployments."
        )

    def write_file(self, path: str, content: str) -> None:
        raise NotImplementedError(
            "GCSMemoryBackend.write_file() is still a stub. "
            "Use the local filesystem backend for supported OSS deployments."
        )

    def list_files(self, prefix: str = "") -> list[str]:
        raise NotImplementedError(
            "GCSMemoryBackend.list_files() is still a stub."
        )

    def delete_file(self, path: str) -> None:
        raise NotImplementedError(
            "GCSMemoryBackend.delete_file() is still a stub."
        )
