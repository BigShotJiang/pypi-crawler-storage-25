"""
parsica_memory.backends — pluggable storage backends for MemorySystem.

Available backends (stable):
  (none yet — local file storage is the default and requires no backend import)

Experimental / stub backends (not exported by default):
  GCSMemoryBackend — Google Cloud Storage (experimental stub; not production-ready)

To use an experimental backend, import it explicitly:
  from parsica_memory.backends.gcs import GCSMemoryBackend  # raises on use
"""

# GCSMemoryBackend is NOT in __all__ — it is a stub that raises NotImplementedError.
# Import it explicitly if you need to test the interface or extend it.
# Do NOT use in production.

__all__: list = []  # No stable backends exported yet
