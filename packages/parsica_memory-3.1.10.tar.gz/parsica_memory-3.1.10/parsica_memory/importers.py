"""
parsica_memory.importers - Import memories from other systems.

Supports:
    - mem0 (Qdrant export / JSON)
    - Memvid (video-encoded memory manifests)
    - MEMO (graph-based memory)
    - Zep (PostgreSQL JSON export)
    - LangMem (LangChain memory backends)
    - OpenAI (conversation history export)
    - Generic: JSON, JSONL, SQLite, Markdown, CSV

Usage:
    from parsica_memory.importers import detect_and_import

    result = detect_and_import(
        input_path="./mem0_export.json",
        workspace="./memory",
        source="auto",
        merge=True,
        dry_run=False,
    )
"""

from __future__ import annotations

import csv
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional


def detect_and_import(
    input_path: str,
    workspace: str,
    source: str = "auto",
    merge: bool = True,
    dry_run: bool = False,
) -> Dict:
    """Detect format and import memories into a parsica-memory workspace.

    Args:
        input_path: File or directory to import from.
        workspace: Target parsica-memory workspace.
        source: Source format hint. "auto" to detect.
        merge: If True, merge with existing. If False, replace.
        dry_run: If True, report what would happen without writing.

    Returns:
        dict with keys: count, format, skipped
    """
    path = Path(input_path)

    if source == "auto":
        source = _detect_format(path)

    converter = _CONVERTERS.get(source)
    if not converter:
        raise ValueError(f"Unknown source format: {source}. "
                         f"Supported: {', '.join(_CONVERTERS.keys())}")

    # Extract memories from source format
    memories = converter(path)

    if dry_run:
        return {"count": len(memories), "format": source, "skipped": 0}

    # Import into workspace
    count, skipped = _import_to_workspace(memories, workspace, merge)
    return {"count": count, "format": source, "skipped": skipped}


# -- Format detection --------------------------------------------------------

def _detect_format(path: Path) -> str:
    """Auto-detect the source format from file/directory structure."""
    if path.is_dir():
        # Check for known directory structures
        if (path / "collection" / "qdrant").exists() or (path / "qdrant").exists():
            return "mem0"
        if any(path.glob("*.mp4")) or (path / "manifest.json").exists():
            return "memvid"
        if (path / "graph.json").exists() or (path / "nodes.json").exists():
            return "memo"
        if any(path.glob("*.md")):
            return "markdown"
        return "json"

    name = path.name.lower()
    suffix = path.suffix.lower()

    # File-based detection
    if suffix == ".jsonl":
        return "jsonl"
    if suffix == ".csv":
        return "csv"
    if suffix in (".db", ".sqlite", ".sqlite3"):
        return "sqlite"
    if suffix in (".md", ".markdown"):
        return "markdown"

    # JSON content sniffing
    if suffix == ".json":
        try:
            with open(path) as f:
                data = json.load(f)
            if isinstance(data, dict):
                if "results" in data and "memories" in data.get("results", [{}])[0:1]:
                    return "mem0"
                if "messages" in data or "mapping" in data:
                    return "openai"
                if "sessions" in data and "facts" in data:
                    return "zep"
                if "memory" in data and "graph" in data:
                    return "memo"
            return "json"
        except Exception:
            return "json"

    return "json"


# -- Converters --------------------------------------------------------------
# Each converter takes a Path and returns List[dict] with at minimum:
#   {"content": str, "source": str}
# Optional fields: category, session_id, source_channel, created, metadata

def _convert_mem0(path: Path) -> List[dict]:
    """Import from mem0 export (JSON with vector metadata)."""
    memories = []
    files = list(path.glob("**/*.json")) if path.is_dir() else [path]

    for f in files:
        try:
            data = json.loads(f.read_text())
            # mem0 stores memories as {"results": [{"memory": "text", "metadata": {...}}]}
            items = data if isinstance(data, list) else data.get("results", data.get("memories", []))
            for item in items:
                text = item.get("memory", item.get("text", item.get("content", "")))
                if not text or len(text.strip()) < 5:
                    continue
                memories.append({
                    "content": text.strip(),
                    "source": f"mem0:{f.stem}",
                    "category": item.get("category", "imported"),
                    "created": item.get("created_at", item.get("timestamp", "")),
                    "metadata": {k: v for k, v in item.items()
                                 if k not in ("memory", "text", "content", "embedding", "vector")},
                })
        except Exception:
            continue
    return memories


def _convert_memvid(path: Path) -> List[dict]:
    """Import from Memvid (video-encoded memory)."""
    memories = []
    # Memvid stores a manifest.json with text chunks
    manifest = path / "manifest.json" if path.is_dir() else path
    if manifest.exists():
        try:
            data = json.loads(manifest.read_text())
            chunks = data.get("chunks", data.get("frames", []))
            for chunk in chunks:
                text = chunk.get("text", chunk.get("content", ""))
                if text and len(text.strip()) > 5:
                    memories.append({
                        "content": text.strip(),
                        "source": "memvid:import",
                        "category": "imported",
                    })
        except Exception:
            pass
    return memories


def _convert_memo(path: Path) -> List[dict]:
    """Import from MEMO (graph-based memory)."""
    memories = []
    files = [path / "graph.json", path / "nodes.json"] if path.is_dir() else [path]

    for f in files:
        if not f.exists():
            continue
        try:
            data = json.loads(f.read_text())
            nodes = data.get("nodes", data if isinstance(data, list) else [])
            for node in nodes:
                text = node.get("content", node.get("text", node.get("summary", "")))
                if text and len(text.strip()) > 5:
                    memories.append({
                        "content": text.strip(),
                        "source": "memo:import",
                        "category": node.get("type", "imported"),
                    })
        except Exception:
            continue
    return memories


def _convert_zep(path: Path) -> List[dict]:
    """Import from Zep (PostgreSQL temporal graph export)."""
    memories = []
    files = list(path.glob("**/*.json")) if path.is_dir() else [path]

    for f in files:
        try:
            data = json.loads(f.read_text())
            # Zep exports sessions with facts
            sessions = data.get("sessions", [data] if "facts" in data else [])
            for session in sessions:
                for fact in session.get("facts", []):
                    text = fact.get("fact", fact.get("content", ""))
                    if text and len(text.strip()) > 5:
                        memories.append({
                            "content": text.strip(),
                            "source": f"zep:{session.get('session_id', 'import')}",
                            "category": "semantic",
                            "created": fact.get("created_at", ""),
                        })
                # Also grab messages
                for msg in session.get("messages", []):
                    text = msg.get("content", "")
                    if text and len(text.strip()) > 10:
                        memories.append({
                            "content": text.strip(),
                            "source": f"zep:{session.get('session_id', 'import')}",
                            "category": "episodic",
                            "created": msg.get("created_at", ""),
                        })
        except Exception:
            continue
    return memories


def _convert_langmem(path: Path) -> List[dict]:
    """Import from LangMem / LangChain memory backends."""
    memories = []
    files = list(path.glob("**/*.json")) if path.is_dir() else [path]

    for f in files:
        try:
            data = json.loads(f.read_text())
            # LangChain chat_history format
            items = data if isinstance(data, list) else data.get("history", data.get("messages", []))
            for item in items:
                if isinstance(item, str):
                    if len(item.strip()) > 10:
                        memories.append({"content": item.strip(), "source": "langmem:import", "category": "episodic"})
                elif isinstance(item, dict):
                    text = item.get("content", item.get("text", item.get("page_content", "")))
                    if text and len(text.strip()) > 10:
                        memories.append({
                            "content": text.strip(),
                            "source": f"langmem:{item.get('type', 'import')}",
                            "category": "episodic",
                            "created": item.get("timestamp", ""),
                        })
        except Exception:
            continue

    # Also check for SQLite
    for db in (list(path.glob("**/*.db")) if path.is_dir() else []):
        memories.extend(_convert_sqlite(db))

    return memories


def _convert_openai(path: Path) -> List[dict]:
    """Import from OpenAI conversation history export."""
    memories = []
    files = list(path.glob("**/*.json")) if path.is_dir() else [path]

    for f in files:
        try:
            data = json.loads(f.read_text())
            # OpenAI exports have a "mapping" dict of message nodes
            if "mapping" in data:
                for node_id, node in data["mapping"].items():
                    msg = node.get("message")
                    if not msg:
                        continue
                    content = msg.get("content", {})
                    parts = content.get("parts", [])
                    text = " ".join(str(p) for p in parts if isinstance(p, str))
                    if text and len(text.strip()) > 10:
                        memories.append({
                            "content": text.strip(),
                            "source": f"openai:{msg.get('author', {}).get('role', 'unknown')}",
                            "category": "episodic",
                            "created": msg.get("create_time", ""),
                        })
            # Array of conversations
            elif isinstance(data, list):
                for conv in data:
                    mapping = conv.get("mapping", {})
                    for node in mapping.values():
                        msg = node.get("message")
                        if not msg:
                            continue
                        parts = msg.get("content", {}).get("parts", [])
                        text = " ".join(str(p) for p in parts if isinstance(p, str))
                        if text and len(text.strip()) > 10:
                            memories.append({
                                "content": text.strip(),
                                "source": f"openai:{msg.get('author', {}).get('role', 'unknown')}",
                                "category": "episodic",
                            })
        except Exception:
            continue
    return memories


def _convert_json(path: Path) -> List[dict]:
    """Import from generic JSON (array of objects or parsica-memory export)."""
    memories = []
    files = list(path.glob("**/*.json")) if path.is_dir() else [path]

    for f in files:
        try:
            data = json.loads(f.read_text())
            items = data if isinstance(data, list) else data.get("memories", data.get("entries", []))
            for item in items:
                if isinstance(item, str):
                    if len(item.strip()) > 5:
                        memories.append({"content": item.strip(), "source": "json:import"})
                elif isinstance(item, dict):
                    text = item.get("content", item.get("text", item.get("memory", "")))
                    if text and len(text.strip()) > 5:
                        memories.append({
                            "content": text.strip(),
                            "source": item.get("source", "json:import"),
                            "category": item.get("category", "imported"),
                            "session_id": item.get("session_id", ""),
                            "created": item.get("created", item.get("timestamp", "")),
                        })
        except Exception:
            continue
    return memories


def _convert_jsonl(path: Path) -> List[dict]:
    """Import from JSONL (one JSON object per line)."""
    memories = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
                text = item.get("content", item.get("text", item.get("memory", "")))
                if text and len(text.strip()) > 5:
                    memories.append({
                        "content": text.strip(),
                        "source": item.get("source", "jsonl:import"),
                        "category": item.get("category", "imported"),
                        "session_id": item.get("session_id", ""),
                        "created": item.get("created", ""),
                    })
            except json.JSONDecodeError:
                continue
    return memories


def _convert_sqlite(path: Path) -> List[dict]:
    """Import from SQLite database (common for LangChain, custom stores)."""
    memories = []
    try:
        conn = sqlite3.connect(str(path))
        cursor = conn.cursor()
        # Try common table names
        for table in ["messages", "memories", "chat_history", "history", "entries"]:
            try:
                cursor.execute(f"SELECT * FROM {table} LIMIT 1")
                columns = [desc[0] for desc in cursor.description]
                # Find the text column
                text_col = None
                for candidate in ["content", "text", "message", "body", "memory"]:
                    if candidate in columns:
                        text_col = candidate
                        break
                if not text_col:
                    text_col = columns[0] if columns else None
                if not text_col:
                    continue

                cursor.execute(f"SELECT * FROM {table}")
                for row in cursor.fetchall():
                    row_dict = dict(zip(columns, row))
                    text = str(row_dict.get(text_col, ""))
                    if text and len(text.strip()) > 10:
                        memories.append({
                            "content": text.strip(),
                            "source": f"sqlite:{table}",
                            "category": "imported",
                        })
            except sqlite3.OperationalError:
                continue
        conn.close()
    except Exception:
        pass
    return memories


def _convert_markdown(path: Path) -> List[dict]:
    """Import from Markdown files (daily logs, notes, docs)."""
    memories = []
    files = list(path.glob("**/*.md")) if path.is_dir() else [path]

    for f in files:
        try:
            text = f.read_text()
            # Split by headers or double newlines
            sections = text.split("\n## ")
            for section in sections:
                section = section.strip()
                if len(section) > 20:
                    memories.append({
                        "content": section[:2000],  # cap at 2K chars per section
                        "source": f"markdown:{f.stem}",
                        "category": "imported",
                    })
        except Exception:
            continue
    return memories


def _convert_csv(path: Path) -> List[dict]:
    """Import from CSV (looks for content/text/message column)."""
    memories = []
    try:
        with open(path, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Find text column
                text = (row.get("content") or row.get("text") or
                        row.get("message") or row.get("memory") or "")
                if text and len(text.strip()) > 10:
                    memories.append({
                        "content": text.strip(),
                        "source": row.get("source", "csv:import"),
                        "category": row.get("category", "imported"),
                    })
    except Exception:
        pass
    return memories


# -- Converter registry ------------------------------------------------------

_CONVERTERS = {
    "mem0": _convert_mem0,
    "memvid": _convert_memvid,
    "memo": _convert_memo,
    "zep": _convert_zep,
    "langmem": _convert_langmem,
    "openai": _convert_openai,
    "json": _convert_json,
    "jsonl": _convert_jsonl,
    "sqlite": _convert_sqlite,
    "markdown": _convert_markdown,
    "csv": _convert_csv,
}


# -- Import to workspace ----------------------------------------------------

def _import_to_workspace(
    memories: List[dict],
    workspace: str,
    merge: bool = True,
) -> tuple:
    """Write extracted memories into a parsica-memory workspace.

    Returns (imported_count, skipped_count).
    """
    from .core_v4 import MemorySystemV4

    # Load agent name from config if available
    agent_name = None
    config_path = os.path.join(workspace, "antaris_config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                agent_name = json.load(f).get("agent_name")
        except Exception:
            pass

    ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
    ms.load()

    existing_hashes = {m.hash for m in ms.memories} if merge else set()
    imported = 0
    skipped = 0

    for mem in memories:
        content = mem["content"]
        # Quick dedup check
        import hashlib
        h = hashlib.sha256(content.encode()).hexdigest()[:16]
        if h in existing_hashes:
            skipped += 1
            continue

        ms.ingest(
            content,
            source=mem.get("source", "import"),
            category=mem.get("category", "imported"),
            session_id=mem.get("session_id", ""),
        )
        existing_hashes.add(h)
        imported += 1

    ms.save()
    return imported, skipped
