"""Export helpers for Parsica Memory.

Supports time ranges, optional topic filtering via the existing BM25 search
engine, and json/markdown/jsonl output formats. Pure stdlib.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Iterable, List, Optional

from .entry import MemoryEntry


def _parse_created(entry: MemoryEntry) -> Optional[datetime]:
    raw = getattr(entry, "created", "") or ""
    if not raw:
        return None
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def _filter_by_range(entries: Iterable[MemoryEntry], range_name: str) -> List[MemoryEntry]:
    range_name = (range_name or "all").lower()
    entries = list(entries)
    if range_name == "all":
        return entries

    now = datetime.now(timezone.utc)
    if range_name == "today":
        cutoff = now - timedelta(days=1)
    elif range_name == "week":
        cutoff = now - timedelta(days=7)
    elif range_name == "month":
        cutoff = now - timedelta(days=30)
    else:
        raise ValueError(f"Unsupported range: {range_name}")

    filtered = []
    for entry in entries:
        created = _parse_created(entry)
        if created and created >= cutoff:
            filtered.append(entry)
    return filtered


def _topic_filter(memory_system, entries: List[MemoryEntry], topic: Optional[str]) -> List[MemoryEntry]:
    if not topic:
        return entries
    # P1 fix: cap limit to prevent OOM on large stores
    search_limit = min(max(len(entries) * 5, 50), 5000)
    results = memory_system.search(topic, limit=search_limit, explain=True)
    allowed = {r.entry.hash for r in results}
    return [e for e in entries if e.hash in allowed]


def _entry_to_dict(entry: MemoryEntry) -> dict:
    return {
        "hash": getattr(entry, "hash", ""),
        "content": getattr(entry, "content", ""),
        "source": getattr(entry, "source", ""),
        "timestamp": getattr(entry, "created", ""),
        "category": getattr(entry, "category", "general"),
        "memory_type": getattr(entry, "memory_type", "episodic"),
        "tags": list(getattr(entry, "tags", []) or []),
        "channel": getattr(entry, "source_channel", ""),
    }


def export_memories(memory_system, range_name: str = "all", topic: Optional[str] = None,
                    format: str = "json") -> str:
    entries = list(getattr(memory_system, "memories", []) or [])
    entries = _filter_by_range(entries, range_name)
    entries = _topic_filter(memory_system, entries, topic)
    return _render_export(entries, format=format, title="Memories Export")


def export_archive(memory_system, range_name: str = "all", topic: Optional[str] = None,
                   format: str = "json") -> str:
    """Export the conversation archive (archive.md + daily files), NOT the memory store.

    Falls back to memory store export if no ConversationArchive is configured.
    """
    archive = getattr(memory_system, "archive", None)
    if archive is None:
        # No archive configured — fall back to memory export
        return export_memories(memory_system, range_name=range_name, topic=topic, format=format)

    # Read actual archive content
    import os
    archive_content = ""
    archive_path = os.path.join(str(archive.workspace), "memory", "archive.md")
    if os.path.exists(archive_path):
        with open(archive_path, "r", encoding="utf-8") as f:
            archive_content = f.read()

    # Also read active daily files
    daily_dir = os.path.join(str(archive.workspace), "memory")
    daily_content = []
    if os.path.isdir(daily_dir):
        for fname in sorted(os.listdir(daily_dir), reverse=True):
            if fname.endswith(".md") and fname != "archive.md" and len(fname) == 13:  # YYYY-MM-DD.md
                fpath = os.path.join(daily_dir, fname)
                with open(fpath, "r", encoding="utf-8") as f:
                    daily_content.append({"date": fname[:-3], "content": f.read()})

    format = (format or "json").lower()
    if format == "json":
        return json.dumps({
            "title": "Conversation Archive",
            "archive": archive_content,
            "daily_files": daily_content,
        }, indent=2)
    elif format == "markdown":
        parts = ["# Conversation Archive\n"]
        if archive_content:
            parts.append("## Permanent Archive\n")
            parts.append(archive_content)
            parts.append("")
        if daily_content:
            parts.append("## Recent Daily Logs\n")
            for d in daily_content:
                parts.append(f"### {d['date']}\n")
                parts.append(d["content"])
                parts.append("")
        return "\n".join(parts).rstrip() + "\n"
    elif format == "jsonl":
        lines = []
        if archive_content:
            lines.append(json.dumps({"type": "archive", "content": archive_content}))
        for d in daily_content:
            lines.append(json.dumps({"type": "daily", "date": d["date"], "content": d["content"]}))
        return "\n".join(lines)
    else:
        raise ValueError(f"Unsupported format: {format}")


def _render_export(entries: List[MemoryEntry], format: str = "json", title: str = "Export") -> str:
    format = (format or "json").lower()
    rows = [_entry_to_dict(e) for e in entries]

    if format == "json":
        return json.dumps({"title": title, "count": len(rows), "entries": rows}, indent=2)

    if format == "jsonl":
        return "\n".join(json.dumps(row) for row in rows)

    if format == "markdown":
        lines = [f"# {title}", "", f"Count: {len(rows)}", ""]
        for row in rows:
            lines.append(f"## {row['timestamp'] or 'unknown time'}")
            lines.append(f"- Source: {row['source']}")
            lines.append(f"- Category: {row['category']}")
            lines.append(f"- Type: {row['memory_type']}")
            if row["channel"]:
                lines.append(f"- Channel: {row['channel']}")
            if row["tags"]:
                lines.append(f"- Tags: {', '.join(row['tags'])}")
            lines.append("")
            lines.append(row["content"])
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    raise ValueError(f"Unsupported format: {format}")
