"""Proactive memory surfacing for Parsica Memory.

Stores lightweight proactive notes in ``workspace/proactive/`` and can surface
upcoming items or greeting-triggered reminders without touching the scoring
pipeline. Pure stdlib.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_NOTE_PATTERNS = [
    (r"(?:i have|i've got|there's) (?:a |an )?(\w+ )?(?:meeting|appointment|call|interview|deadline|event)", "event"),
    (r"(?:i need to|i have to|i should|i must|remind me to|don't let me forget) (.+)", "task"),
    (r"(?:tomorrow|tonight|this evening|this afternoon|next week|on monday|on tuesday|on wednesday|on thursday|on friday|on saturday|on sunday)", "temporal"),
    (r"(?:my (?:favorite|favourite) .+ is|i (?:love|hate|prefer|like|dislike) )", "preference"),
    (r"(?:i'm going to|i'll be|i plan to|planning to) (.+)", "plan"),
]

_GREETING_PATTERNS = [
    r"(?:good morning|morning|hey|hi|hello|what's up|sup|howdy|yo)",
    r"(?:i'm back|back again|here again)",
]


class ProactiveMemory:
    """Persist and surface proactive notes per user/session key."""

    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)
        self.store_dir = self.workspace / "proactive"
        self.store_dir.mkdir(parents=True, exist_ok=True)

    def scan(self, key: str, text: str) -> List[Dict]:
        """Scan text for proactive notes and persist matches."""
        text = (text or "").strip()
        if not text:
            return []

        text_lower = text.lower()
        created: List[Dict] = []
        notes = self._load(key)

        for pattern, category in _NOTE_PATTERNS:
            if re.search(pattern, text_lower):
                note = {
                    "text": text[:500],
                    "category": category,
                    "created": datetime.now(timezone.utc).isoformat(),
                    "surface_after": self._extract_temporal(text_lower) or "",
                    "surfaced": False,
                }
                notes.append(note)
                created.append(note)
                break

        if created:
            self._save(key, notes)
        return created

    def get_active(self, key: str, text: str = "") -> List[Dict]:
        """Return notes that should surface now and mark them surfaced.

        Respects ``surface_after``: notes with a future ``surface_after``
        timestamp are skipped until that time has passed.
        """
        text = (text or "").strip().lower()
        is_greeting = bool(text) and any(re.search(p, text) for p in _GREETING_PATTERNS)
        if text and not is_greeting:
            return []

        notes = self._load(key)
        now = datetime.now(timezone.utc)
        active: List[Dict] = []

        for note in notes:
            if note.get("surfaced"):
                continue
            # P0 fix: respect surface_after scheduling
            surface_after = note.get("surface_after", "")
            if surface_after:
                try:
                    target = datetime.fromisoformat(surface_after)
                    if target.tzinfo is None:
                        target = target.replace(tzinfo=timezone.utc)
                    if now < target:
                        continue  # not yet time to surface
                except (ValueError, TypeError):
                    pass  # malformed timestamp — surface anyway
            active.append(note)
            note["surfaced"] = True

        if active:
            self._save(key, notes)
        return active

    def surface(self, key: str, text: str = "") -> List[str]:
        return [n.get("text", "") for n in self.get_active(key, text=text)]

    def prune(self, key: Optional[str] = None, days: int = 7) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        removed = 0
        paths = [self._path(key)] if key else sorted(self.store_dir.glob("*.json"))

        for path in paths:
            if not path.exists():
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue

            kept = []
            for note in data:
                created_raw = note.get("created", "")
                try:
                    created = datetime.fromisoformat(created_raw)
                    if created.tzinfo is None:
                        created = created.replace(tzinfo=timezone.utc)
                except Exception:
                    kept.append(note)
                    continue

                if note.get("surfaced") and created < cutoff:
                    removed += 1
                    continue
                kept.append(note)

            path.write_text(json.dumps(kept, indent=2), encoding="utf-8")

        return removed

    def _extract_temporal(self, text: str) -> str:
        now = datetime.now(timezone.utc)
        if "tomorrow" in text:
            return (now + timedelta(days=1)).replace(hour=7, minute=0, second=0, microsecond=0).isoformat()
        if "tonight" in text or "this evening" in text:
            return now.replace(hour=18, minute=0, second=0, microsecond=0).isoformat()
        if "this afternoon" in text:
            return now.replace(hour=15, minute=0, second=0, microsecond=0).isoformat()
        if "next week" in text:
            return (now + timedelta(weeks=1)).replace(hour=9, minute=0, second=0, microsecond=0).isoformat()
        return ""

    def _path(self, key: str) -> Path:
        safe = re.sub(r"[^a-zA-Z0-9_.-]+", "_", key or "default")
        return self.store_dir / f"{safe}.json"

    def _load(self, key: str) -> List[Dict]:
        path = self._path(key)
        if not path.exists():
            return []
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            logger.debug("Failed to load proactive notes from %s", path, exc_info=True)
            return []

    def _save(self, key: str, notes: List[Dict]) -> None:
        self._path(key).write_text(json.dumps(notes, indent=2), encoding="utf-8")
