#!/usr/bin/env python3
"""
Parsica Memory store cleanup — purge transport metadata contamination.

Removes entries from WAL and shards that contain Discord/OpenClaw transport
scaffolding that was accidentally ingested as memory content.

Usage:
    python -m parsica_memory.cleanup /path/to/memory_store
    python -m parsica_memory.cleanup /path/to/memory_store --dry-run
"""
import json
import os
import sys
from pathlib import Path

TRANSPORT_PATTERNS = [
    '[media attached',
    '[ANTARIS-SUITE MEMORY',
    '[PARSICA-MEMORY',
    'Conversation info (untrusted',
    'Sender (untrusted',
    '[Discord ',
    '[Inter-session message]',
    'OpenClaw runtime context',
    'To send an image back',
]

def is_contaminated(entry):
    """Check if a memory entry contains transport metadata."""
    if isinstance(entry, str):
        text = entry
    elif isinstance(entry, dict):
        text = ' '.join(str(entry.get(k, '')) for k in ('text', 'content', 'user_text', 'assistant_text'))
    else:
        return False
    return any(p in text for p in TRANSPORT_PATTERNS)


def clean_wal(store_path: Path, dry_run: bool = False):
    """Clean the WAL file of contaminated entries."""
    wal_path = store_path / '.parsica_wal.jsonl'
    if not wal_path.exists():
        print(f'No WAL found at {wal_path}')
        return 0

    clean_lines = []
    removed = 0
    with open(wal_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                if is_contaminated(entry):
                    removed += 1
                    continue
                clean_lines.append(line)
            except json.JSONDecodeError:
                clean_lines.append(line)  # Keep unparseable lines

    if not dry_run and removed > 0:
        # Backup then overwrite
        backup = wal_path.with_suffix('.jsonl.bak-cleanup')
        wal_path.rename(backup)
        with open(wal_path, 'w') as f:
            for line in clean_lines:
                f.write(line + '\n')

    print(f'WAL: {removed} contaminated entries removed ({len(clean_lines)} kept)')
    return removed


def clean_shards(store_path: Path, dry_run: bool = False):
    """Clean shard files of contaminated entries."""
    shard_dir = store_path / 'shards'
    if not shard_dir.exists():
        print(f'No shards directory at {shard_dir}')
        return 0

    total_removed = 0
    for shard_file in sorted(shard_dir.glob('*.json')):
        if shard_file.suffix == '.tmp':
            continue
        try:
            with open(shard_file) as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            print(f'  SKIP {shard_file.name}: {e}')
            continue

        memories = data.get('memories', [])
        if not memories:
            continue

        clean = [m for m in memories if not is_contaminated(m)]
        removed = len(memories) - len(clean)

        if removed > 0:
            print(f'  {shard_file.name}: {removed} removed ({len(clean)} kept)')
            total_removed += removed

            if not dry_run:
                data['memories'] = clean
                data['count'] = len(clean)
                # Write to temp then rename (atomic)
                tmp = shard_file.with_suffix('.tmp')
                with open(tmp, 'w') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
                    f.write('\n')
                tmp.rename(shard_file)

    print(f'Shards: {total_removed} contaminated entries removed')
    return total_removed


def update_index(store_path: Path, dry_run: bool = False):
    """Update memory_index.json counts after cleanup."""
    idx_path = store_path / 'memory_index.json'
    if not idx_path.exists():
        return

    with open(idx_path) as f:
        idx = json.load(f)

    shard_dir = store_path / 'shards'
    for shard_entry in idx.get('shards', []):
        filename = shard_entry.get('filename', '')
        shard_path = shard_dir / filename
        if shard_path.exists():
            try:
                with open(shard_path) as f:
                    data = json.load(f)
                shard_entry['count'] = len(data.get('memories', []))
            except:
                pass

    if not dry_run:
        with open(idx_path, 'w') as f:
            json.dump(idx, f, indent=2, ensure_ascii=False)
            f.write('\n')

    print('memory_index.json updated')


def main():
    if len(sys.argv) < 2:
        print(f'Usage: {sys.argv[0]} /path/to/memory_store [--dry-run]')
        sys.exit(1)

    store_path = Path(sys.argv[1])
    dry_run = '--dry-run' in sys.argv

    if dry_run:
        print('=== DRY RUN (no files modified) ===')

    print(f'Store: {store_path}')
    wal_removed = clean_wal(store_path, dry_run)
    shard_removed = clean_shards(store_path, dry_run)
    if not dry_run:
        update_index(store_path, dry_run)
    print(f'\nTotal removed: {wal_removed + shard_removed}')


if __name__ == '__main__':
    main()
