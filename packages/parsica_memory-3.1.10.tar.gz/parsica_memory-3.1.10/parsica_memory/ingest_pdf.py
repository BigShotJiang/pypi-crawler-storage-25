"""PDF ingestion — text extraction, OCR fallback, chunking, provenance.

Architecture
~~~~~~~~~~~~
Three-tier extraction strategy:
  1. **Direct text extraction** (pypdf) — fast, zero-cost, handles text PDFs
  2. **Layout-aware extraction** (pdfminer.six) — better structure preservation
  3. **OCR fallback** (pdf2image + pytesseract) — scanned/image PDFs

All tiers preserve page-level provenance. Output is a list of ``PDFChunk``
dataclasses with source file, page number, section info, and content hash.

Dependencies
~~~~~~~~~~~~
Required: pypdf (already installed)
Optional (graceful degradation):
  - pdfminer.six — better layout extraction
  - pdf2image + pytesseract — OCR for scanned PDFs
  - pillow — image processing for OCR

Usage
~~~~~
    from parsica_memory.ingest_pdf import PDFIngester

    ingester = PDFIngester()
    result = ingester.ingest("/path/to/document.pdf")

    # Result contains extracted chunks with provenance
    for chunk in result.chunks:
        print(f"Page {chunk.page}: {chunk.text[:100]}...")

    # Or get the full text
    print(result.full_text)

    # Feed directly into Parsica memory
    for chunk in result.to_memory_entries():
        memory_system.ingest(chunk["content"], source=chunk["source"],
                             category=chunk["category"])

Backward compatibility
~~~~~~~~~~~~~~~~~~~~~~
The original ``from_pdf()`` interface is preserved for any existing callers.
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

_log = logging.getLogger("parsica_memory.ingest_pdf")

# ── Constants ──────────────────────────────────────────────────────────

MIN_TEXT_LENGTH = 30        # Minimum chars to consider a page as having text
MIN_CHUNK_LENGTH = 50       # Minimum chars per output chunk
MAX_CHUNK_LENGTH = 2000     # Target max chars per chunk (soft limit)
OCR_CONFIDENCE_THRESHOLD = 40  # Minimum tesseract confidence (0-100)
# Legacy alias used by the original from_pdf() interface
MIN_PAGE_TEXT_CHARS = 20


# ── Data types ─────────────────────────────────────────────────────────

class ExtractionMethod(Enum):
    """How text was extracted from a page."""
    DIRECT = "direct"           # pypdf text extraction
    LAYOUT = "layout"           # pdfminer.six layout analysis
    OCR = "ocr"                 # tesseract OCR from rendered image
    EMPTY = "empty"             # No text could be extracted


@dataclass
class PDFChunk:
    """A chunk of text extracted from a PDF with full provenance."""
    text: str
    page: int                   # 1-indexed page number
    chunk_index: int            # 0-indexed within the page
    source_file: str            # Original file path or URL
    extraction_method: ExtractionMethod
    content_hash: str = ""
    section_heading: str = ""   # Detected section heading, if any
    confidence: float = 1.0     # Extraction confidence (0-1)
    char_offset: int = 0        # Character offset within the page text
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.content_hash:
            self.content_hash = _content_hash(self.text)


@dataclass
class PDFMetadata:
    """PDF document metadata."""
    title: str = ""
    author: str = ""
    subject: str = ""
    creator: str = ""
    producer: str = ""
    page_count: int = 0
    file_size: int = 0
    creation_date: str = ""
    modification_date: str = ""
    is_encrypted: bool = False
    has_images: bool = False
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PDFPage:
    """Extraction result for a single page."""
    page_number: int            # 1-indexed
    text: str
    method: ExtractionMethod
    confidence: float = 1.0
    has_images: bool = False
    word_count: int = 0

    def __post_init__(self):
        self.word_count = len(self.text.split()) if self.text else 0


@dataclass
class PDFResult:
    """Complete result of PDF ingestion."""
    source_file: str
    metadata: PDFMetadata
    pages: List[PDFPage]
    chunks: List[PDFChunk]
    extraction_time_ms: float = 0.0
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    @property
    def full_text(self) -> str:
        """Concatenated text from all pages."""
        return "\n\n".join(p.text for p in self.pages if p.text)

    @property
    def page_count(self) -> int:
        return len(self.pages)

    @property
    def total_words(self) -> int:
        return sum(p.word_count for p in self.pages)

    @property
    def extraction_methods_used(self) -> set:
        return {p.method for p in self.pages}

    def to_memory_entries(
        self,
        category: str = "document",
        include_metadata: bool = True,
    ) -> List[Dict[str, Any]]:
        """Convert chunks to dicts ready for parsica-memory ingestion.

        Each entry includes provenance in the source field:
            "pdf:<filename>:p<page>[:<section>]"
        """
        entries = []
        filename = Path(self.source_file).name

        for chunk in self.chunks:
            source_parts = [f"pdf:{filename}:p{chunk.page}"]
            if chunk.section_heading:
                # Sanitize section heading for source string
                safe_heading = re.sub(r'[^a-zA-Z0-9_ -]', '', chunk.section_heading)[:60]
                source_parts.append(safe_heading.strip())
            source = ":".join(source_parts)

            entry: Dict[str, Any] = {
                "content": chunk.text,
                "source": source,
                "category": category,
                "metadata": {
                    "page": chunk.page,
                    "extraction_method": chunk.extraction_method.value,
                    "content_hash": chunk.content_hash,
                    "chunk_index": chunk.chunk_index,
                },
            }
            if include_metadata and self.metadata.title:
                entry["metadata"]["document_title"] = self.metadata.title
            if include_metadata and self.metadata.author:
                entry["metadata"]["document_author"] = self.metadata.author

            entries.append(entry)

        return entries

    def summary(self) -> str:
        """Human-readable summary of the extraction."""
        methods = ", ".join(m.value for m in self.extraction_methods_used)
        lines = [
            f"PDF: {Path(self.source_file).name}",
            f"  Pages: {self.page_count}",
            f"  Words: {self.total_words:,}",
            f"  Chunks: {len(self.chunks)}",
            f"  Methods: {methods}",
            f"  Time: {self.extraction_time_ms:.0f}ms",
        ]
        if self.metadata.title:
            lines.insert(1, f"  Title: {self.metadata.title}")
        if self.warnings:
            lines.append(f"  Warnings: {len(self.warnings)}")
        if self.errors:
            lines.append(f"  Errors: {len(self.errors)}")
        return "\n".join(lines)


# ── Helpers ────────────────────────────────────────────────────────────

def _content_hash(text: str) -> str:
    """SHA-256 prefix for deduplication."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _clean_text(text: str) -> str:
    """Normalize whitespace and remove common PDF artifacts."""
    if not text:
        return ""
    # Collapse multiple whitespace (but preserve paragraph breaks)
    text = re.sub(r'[ \t]+', ' ', text)
    # Normalize line breaks
    text = re.sub(r'\n{3,}', '\n\n', text)
    # Remove null bytes and control chars (except newline, tab)
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text)
    # Fix common ligature issues
    text = text.replace('\ufb01', 'fi').replace('\ufb02', 'fl')
    text = text.replace('\ufb00', 'ff').replace('\ufb03', 'ffi').replace('\ufb04', 'ffl')
    return text.strip()


def _detect_section_headings(text: str) -> List[Tuple[int, str]]:
    """Detect likely section headings and their char offsets.

    Returns list of (char_offset, heading_text).
    """
    headings = []
    lines = text.split('\n')
    offset = 0
    for line in lines:
        stripped = line.strip()
        # Heuristic: short lines in UPPER CASE or ending with specific patterns
        if stripped and len(stripped) < 100:
            is_heading = False
            # ALL CAPS lines (at least 3 chars, mostly alpha)
            if (len(stripped) >= 3 and stripped.isupper() and
                    sum(c.isalpha() for c in stripped) > len(stripped) * 0.5):
                is_heading = True
            # Numbered sections: "1.", "1.1", "Chapter 1", "Section 2.3"
            elif re.match(r'^(\d+\.[\d.]*\s+|Chapter\s+\d|Section\s+[\d.]+)', stripped, re.I):
                is_heading = True
            # Lines that are bold-ish (surrounded by ** in extracted text)
            elif stripped.startswith('**') and stripped.endswith('**'):
                is_heading = True

            if is_heading:
                headings.append((offset, stripped))

        offset += len(line) + 1  # +1 for newline

    return headings


def _chunk_text(
    text: str,
    page: int,
    source_file: str,
    method: ExtractionMethod,
    confidence: float = 1.0,
    max_chunk_length: int = MAX_CHUNK_LENGTH,
    min_chunk_length: int = MIN_CHUNK_LENGTH,
) -> List[PDFChunk]:
    """Split page text into chunks, respecting paragraph boundaries.

    Chunks are split at paragraph breaks (double newlines), falling back
    to sentence boundaries, then hard splits at max_chunk_length.
    """
    if not text or len(text.strip()) < min_chunk_length:
        return []

    # Detect section headings for provenance
    headings = _detect_section_headings(text)

    # Split into paragraphs
    paragraphs = re.split(r'\n\n+', text.strip())

    chunks: List[PDFChunk] = []
    current_text = ""
    current_heading = ""
    char_offset = 0

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        # Check if this paragraph is a heading
        for h_offset, h_text in headings:
            if para.strip() == h_text.strip():
                current_heading = h_text
                break

        # Would adding this paragraph exceed max length?
        if current_text and len(current_text) + len(para) + 2 > max_chunk_length:
            # Flush current chunk
            if len(current_text.strip()) >= min_chunk_length:
                chunks.append(PDFChunk(
                    text=current_text.strip(),
                    page=page,
                    chunk_index=len(chunks),
                    source_file=source_file,
                    extraction_method=method,
                    section_heading=current_heading,
                    confidence=confidence,
                    char_offset=char_offset,
                ))
            char_offset += len(current_text) + 2
            current_text = ""

        # If a single paragraph exceeds max, split by sentences
        if len(para) > max_chunk_length:
            # Flush any accumulated text first
            if current_text and len(current_text.strip()) >= min_chunk_length:
                chunks.append(PDFChunk(
                    text=current_text.strip(),
                    page=page,
                    chunk_index=len(chunks),
                    source_file=source_file,
                    extraction_method=method,
                    section_heading=current_heading,
                    confidence=confidence,
                    char_offset=char_offset,
                ))
                char_offset += len(current_text) + 2
                current_text = ""

            # Split long paragraph by sentences
            sentences = re.split(r'(?<=[.!?])\s+', para)
            sent_buffer = ""
            for sent in sentences:
                if sent_buffer and len(sent_buffer) + len(sent) + 1 > max_chunk_length:
                    if len(sent_buffer.strip()) >= min_chunk_length:
                        chunks.append(PDFChunk(
                            text=sent_buffer.strip(),
                            page=page,
                            chunk_index=len(chunks),
                            source_file=source_file,
                            extraction_method=method,
                            section_heading=current_heading,
                            confidence=confidence,
                            char_offset=char_offset,
                        ))
                    char_offset += len(sent_buffer) + 1
                    sent_buffer = ""
                sent_buffer = (sent_buffer + " " + sent).strip() if sent_buffer else sent

            # Remainder from sentence splitting
            if sent_buffer:
                if len(sent_buffer.strip()) >= min_chunk_length:
                    chunks.append(PDFChunk(
                        text=sent_buffer.strip(),
                        page=page,
                        chunk_index=len(chunks),
                        source_file=source_file,
                        extraction_method=method,
                        section_heading=current_heading,
                        confidence=confidence,
                        char_offset=char_offset,
                    ))
                char_offset += len(sent_buffer) + 2
        else:
            # Normal accumulation
            current_text = (current_text + "\n\n" + para).strip() if current_text else para

    # Flush remaining
    if current_text and len(current_text.strip()) >= min_chunk_length:
        chunks.append(PDFChunk(
            text=current_text.strip(),
            page=page,
            chunk_index=len(chunks),
            source_file=source_file,
            extraction_method=method,
            section_heading=current_heading,
            confidence=confidence,
            char_offset=char_offset,
        ))

    return chunks


# ── Extraction backends ────────────────────────────────────────────────

def _extract_pypdf(pdf_path: str) -> Tuple[List[PDFPage], PDFMetadata, List[str]]:
    """Tier 1: Direct text extraction via pypdf.

    Fast and reliable for text-based PDFs. Returns empty text for
    scanned/image pages.
    """
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader  # type: ignore[no-redef]
        except ImportError:
            return [], PDFMetadata(), ["pypdf/PyPDF2 not installed"]

    warnings: List[str] = []
    try:
        reader = PdfReader(pdf_path)
    except Exception as e:
        return [], PDFMetadata(), [f"Failed to open PDF: {e}"]

    # Extract metadata
    meta = PDFMetadata(
        page_count=len(reader.pages),
        file_size=os.path.getsize(pdf_path),
        is_encrypted=reader.is_encrypted,
    )
    if reader.metadata:
        meta.title = reader.metadata.get("/Title", "") or ""
        meta.author = reader.metadata.get("/Author", "") or ""
        meta.subject = reader.metadata.get("/Subject", "") or ""
        meta.creator = reader.metadata.get("/Creator", "") or ""
        meta.producer = reader.metadata.get("/Producer", "") or ""
        meta.raw = {k: str(v) for k, v in (reader.metadata or {}).items()
                    if isinstance(k, str)}

    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception:
            warnings.append("PDF is encrypted and could not be decrypted")
            return [], meta, warnings

    # Extract text page by page
    pages: List[PDFPage] = []
    for i, page in enumerate(reader.pages):
        try:
            text = page.extract_text() or ""
            text = _clean_text(text)
            # Check if page has images (heuristic for OCR need)
            has_images = False
            try:
                if hasattr(page, 'images') and page.images:
                    has_images = True
                elif '/XObject' in (page.get('/Resources') or {}):
                    has_images = True
            except Exception:
                pass

            pages.append(PDFPage(
                page_number=i + 1,
                text=text,
                method=ExtractionMethod.DIRECT if text else ExtractionMethod.EMPTY,
                has_images=has_images,
            ))
        except Exception as e:
            warnings.append(f"Page {i+1}: extraction failed ({e})")
            pages.append(PDFPage(
                page_number=i + 1,
                text="",
                method=ExtractionMethod.EMPTY,
            ))

    meta.has_images = any(p.has_images for p in pages)
    return pages, meta, warnings


def _extract_pdfminer(pdf_path: str) -> Tuple[List[PDFPage], List[str]]:
    """Tier 2: Layout-aware extraction via pdfminer.six.

    Better at preserving document structure (columns, tables, etc.)
    than pypdf. Falls back gracefully if not installed.
    """
    try:
        from pdfminer.high_level import extract_pages
        from pdfminer.layout import LTTextContainer, LAParams
    except ImportError:
        return [], ["pdfminer.six not installed — skipping layout extraction"]

    warnings: List[str] = []
    pages: List[PDFPage] = []

    try:
        laparams = LAParams(
            line_margin=0.5,
            word_margin=0.1,
            char_margin=2.0,
            boxes_flow=0.5,
        )

        for i, page_layout in enumerate(extract_pages(pdf_path, laparams=laparams)):
            text_parts: List[str] = []
            for element in page_layout:
                if isinstance(element, LTTextContainer):
                    text_parts.append(element.get_text())

            text = _clean_text("\n".join(text_parts))
            pages.append(PDFPage(
                page_number=i + 1,
                text=text,
                method=ExtractionMethod.LAYOUT if text else ExtractionMethod.EMPTY,
            ))
    except Exception as e:
        warnings.append(f"pdfminer extraction failed: {e}")

    return pages, warnings


def _extract_ocr(
    pdf_path: str,
    pages_to_ocr: Optional[List[int]] = None,
    dpi: int = 300,
    language: str = "eng",
) -> Tuple[List[PDFPage], List[str]]:
    """Tier 3: OCR via pdf2image + pytesseract.

    Renders PDF pages as images and runs tesseract OCR. Only processes
    pages specified in ``pages_to_ocr`` (1-indexed). If None, processes
    all pages.

    Requires system-level tesseract installation.
    """
    try:
        import pytesseract
        from pdf2image import convert_from_path
    except ImportError as e:
        return [], [f"OCR dependencies not installed: {e}"]

    # Verify tesseract binary is available
    try:
        pytesseract.get_tesseract_version()
    except Exception:
        return [], ["tesseract binary not found — install via: brew install tesseract"]

    warnings: List[str] = []
    pages: List[PDFPage] = []

    try:
        # Convert specific pages or all pages
        if pages_to_ocr:
            images = convert_from_path(
                pdf_path,
                dpi=dpi,
                first_page=min(pages_to_ocr),
                last_page=max(pages_to_ocr),
            )
            image_page_nums = list(range(min(pages_to_ocr), max(pages_to_ocr) + 1))
        else:
            images = convert_from_path(pdf_path, dpi=dpi)
            image_page_nums = list(range(1, len(images) + 1))

        for img, page_num in zip(images, image_page_nums):
            if pages_to_ocr and page_num not in pages_to_ocr:
                continue

            try:
                # Run OCR with detailed data for confidence
                ocr_data = pytesseract.image_to_data(
                    img, lang=language, output_type=pytesseract.Output.DICT
                )

                # Filter by confidence
                words = []
                confidences = []
                for j, word in enumerate(ocr_data['text']):
                    conf = int(ocr_data['conf'][j])
                    if conf >= OCR_CONFIDENCE_THRESHOLD and word.strip():
                        words.append(word)
                        confidences.append(conf)

                text = _clean_text(" ".join(words))
                avg_confidence = (sum(confidences) / len(confidences) / 100.0
                                  if confidences else 0.0)

                pages.append(PDFPage(
                    page_number=page_num,
                    text=text,
                    method=ExtractionMethod.OCR if text else ExtractionMethod.EMPTY,
                    confidence=avg_confidence,
                    has_images=True,
                ))
            except Exception as e:
                warnings.append(f"OCR failed for page {page_num}: {e}")
                pages.append(PDFPage(
                    page_number=page_num,
                    text="",
                    method=ExtractionMethod.EMPTY,
                    has_images=True,
                ))

    except Exception as e:
        warnings.append(f"PDF-to-image conversion failed: {e}")

    return pages, warnings


# ── Main Ingester ──────────────────────────────────────────────────────

class PDFIngester:
    """High-level PDF ingestion with automatic tier selection.

    Parameters
    ----------
    use_ocr : bool
        Enable OCR fallback for pages without extractable text.
    ocr_dpi : int
        DPI for rendering pages to images (OCR tier).
    ocr_language : str
        Tesseract language code (default: "eng").
    prefer_layout : bool
        Prefer pdfminer.six layout extraction over pypdf when available.
    max_chunk_length : int
        Target maximum characters per chunk.
    min_chunk_length : int
        Minimum characters for a chunk to be emitted.
    min_page_text_chars : int
        Legacy parameter — alias for min_chunk_length threshold on page text.
    """

    def __init__(
        self,
        use_ocr: bool = True,
        ocr_dpi: int = 300,
        ocr_language: str = "eng",
        prefer_layout: bool = False,
        max_chunk_length: int = MAX_CHUNK_LENGTH,
        min_chunk_length: int = MIN_CHUNK_LENGTH,
        min_page_text_chars: int = MIN_PAGE_TEXT_CHARS,
    ):
        self.use_ocr = use_ocr
        self.ocr_dpi = ocr_dpi
        self.ocr_language = ocr_language
        self.prefer_layout = prefer_layout
        self.max_chunk_length = max_chunk_length
        self.min_chunk_length = min_chunk_length
        self.min_page_text_chars = min_page_text_chars

    def available(self) -> bool:
        """Check if any PDF extraction backend is available."""
        try:
            from pypdf import PdfReader
            return True
        except ImportError:
            pass
        try:
            from PyPDF2 import PdfReader  # type: ignore[no-redef]
            return True
        except ImportError:
            pass
        return False

    def ingest(
        self,
        pdf_path: str,
        pages: Optional[Sequence[int]] = None,
    ) -> PDFResult:
        """Ingest a PDF file and return structured extraction result.

        Parameters
        ----------
        pdf_path : str
            Path to the PDF file.
        pages : Sequence[int], optional
            Specific pages to extract (1-indexed). None = all pages.

        Returns
        -------
        PDFResult
            Structured result with pages, chunks, metadata, and provenance.
        """
        t0 = time.monotonic()
        pdf_path = os.path.abspath(pdf_path)
        all_warnings: List[str] = []
        all_errors: List[str] = []

        if not os.path.exists(pdf_path):
            return PDFResult(
                source_file=pdf_path,
                metadata=PDFMetadata(),
                pages=[],
                chunks=[],
                errors=[f"File not found: {pdf_path}"],
            )

        # ── Tier 1: pypdf extraction ──
        _log.info("PDF ingest: tier 1 (pypdf) for %s", pdf_path)
        pypdf_pages, metadata, pypdf_warnings = _extract_pypdf(pdf_path)
        all_warnings.extend(pypdf_warnings)

        if not pypdf_pages and not metadata.page_count:
            return PDFResult(
                source_file=pdf_path,
                metadata=metadata,
                pages=[],
                chunks=[],
                errors=["Failed to read PDF with any available backend"],
                warnings=all_warnings,
            )

        # ── Tier 2: pdfminer layout extraction (optional) ──
        layout_pages: Dict[int, PDFPage] = {}
        if self.prefer_layout:
            _log.info("PDF ingest: tier 2 (pdfminer) for %s", pdf_path)
            pdfminer_pages, pm_warnings = _extract_pdfminer(pdf_path)
            all_warnings.extend(pm_warnings)
            layout_pages = {p.page_number: p for p in pdfminer_pages}

        # ── Merge and identify pages needing OCR ──
        final_pages: List[PDFPage] = []
        ocr_needed: List[int] = []

        for pp in pypdf_pages:
            # Filter to requested pages
            if pages and pp.page_number not in pages:
                continue

            # Choose best extraction for this page
            if self.prefer_layout and pp.page_number in layout_pages:
                lp = layout_pages[pp.page_number]
                # Use layout version if it has more text
                if len(lp.text) > len(pp.text) * 1.1:
                    final_pages.append(lp)
                    continue

            if len(pp.text.strip()) >= MIN_TEXT_LENGTH:
                final_pages.append(pp)
            else:
                # Page has little/no text — might be scanned
                final_pages.append(pp)
                if pp.has_images or len(pp.text.strip()) < MIN_TEXT_LENGTH:
                    ocr_needed.append(pp.page_number)

        # ── Tier 3: OCR for pages without text ──
        if ocr_needed and self.use_ocr:
            _log.info("PDF ingest: tier 3 (OCR) for %d pages of %s",
                       len(ocr_needed), pdf_path)
            ocr_pages, ocr_warnings = _extract_ocr(
                pdf_path,
                pages_to_ocr=ocr_needed,
                dpi=self.ocr_dpi,
                language=self.ocr_language,
            )
            all_warnings.extend(ocr_warnings)

            # Replace empty pages with OCR results
            ocr_map = {p.page_number: p for p in ocr_pages}
            for i, fp in enumerate(final_pages):
                if fp.page_number in ocr_map and len(fp.text.strip()) < MIN_TEXT_LENGTH:
                    ocr_page = ocr_map[fp.page_number]
                    if len(ocr_page.text.strip()) > len(fp.text.strip()):
                        final_pages[i] = ocr_page

        elif ocr_needed and not self.use_ocr:
            all_warnings.append(
                f"{len(ocr_needed)} page(s) may be scanned images "
                f"but OCR is disabled"
            )

        # ── Chunking ──
        all_chunks: List[PDFChunk] = []
        for page in final_pages:
            chunks = _chunk_text(
                page.text,
                page=page.page_number,
                source_file=pdf_path,
                method=page.method,
                confidence=page.confidence,
                max_chunk_length=self.max_chunk_length,
                min_chunk_length=self.min_chunk_length,
            )
            all_chunks.extend(chunks)

        elapsed_ms = (time.monotonic() - t0) * 1000

        result = PDFResult(
            source_file=pdf_path,
            metadata=metadata,
            pages=final_pages,
            chunks=all_chunks,
            extraction_time_ms=elapsed_ms,
            warnings=all_warnings,
            errors=all_errors,
        )

        _log.info("PDF ingest complete: %s", result.summary().replace('\n', ' | '))
        return result

    def ingest_to_memory(
        self,
        pdf_path: str,
        workspace: str,
        category: str = "document",
        agent_name: Optional[str] = None,
        pages: Optional[Sequence[int]] = None,
    ) -> Dict[str, Any]:
        """Ingest a PDF directly into a parsica-memory workspace.

        Convenience method that combines extraction + memory ingestion.

        Returns
        -------
        dict
            {count, chunks, warnings, errors, summary}
        """
        result = self.ingest(pdf_path, pages=pages)

        if result.errors and not result.chunks:
            return {
                "count": 0,
                "chunks": 0,
                "warnings": result.warnings,
                "errors": result.errors,
                "summary": "Ingestion failed",
            }

        # Import into parsica-memory
        entries = result.to_memory_entries(category=category)

        try:
            from .core_v4 import MemorySystemV4

            ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
            ms.load()

            existing_hashes = {m.hash for m in ms.memories}
            ingested = 0

            for entry in entries:
                h = _content_hash(entry["content"])
                if h in existing_hashes:
                    continue
                ms.ingest(
                    entry["content"],
                    source=entry["source"],
                    category=entry["category"],
                )
                existing_hashes.add(h)
                ingested += 1

            ms.save()
        except Exception as e:
            _log.error("Failed to ingest into memory: %s", e)
            return {
                "count": 0,
                "chunks": len(result.chunks),
                "warnings": result.warnings,
                "errors": result.errors + [f"Memory ingestion failed: {e}"],
                "summary": result.summary(),
            }

        return {
            "count": ingested,
            "chunks": len(result.chunks),
            "warnings": result.warnings,
            "errors": result.errors,
            "summary": result.summary(),
        }

    # ── Backward compatibility with original from_pdf() interface ──

    def from_pdf(self, path: str) -> List[Dict]:
        """Legacy interface: extract page-level chunks from a PDF.

        Returns list of dicts with keys: text, source_url, content_hash,
        page_number, page_label, provenance, extraction_method, needs_ocr.

        New code should use ``ingest()`` instead.
        """
        if not os.path.exists(path):
            return []
        if not self.available():
            _log.warning("PDF extraction unavailable for %s: pypdf not installed", path)
            return []

        source_root = f"file://{os.path.abspath(path)}"
        result = self.ingest(path)
        legacy_results: List[Dict] = []

        # Map new enum values to legacy string values for backward compat
        _legacy_method_map = {
            ExtractionMethod.DIRECT: "direct_text",
            ExtractionMethod.LAYOUT: "layout_text",
            ExtractionMethod.OCR: "ocr",
            ExtractionMethod.EMPTY: "empty",
        }

        for page in result.pages:
            if not page.text:
                continue
            page_url = f"{source_root}#page={page.page_number}"
            needs_ocr = len(page.text) < self.min_page_text_chars
            legacy_method = _legacy_method_map.get(page.method, page.method.value)
            legacy_results.append({
                "text": page.text,
                "source_url": page_url,
                "content_hash": _content_hash(f"{page.page_number}:{page.text}"),
                "page_number": page.page_number,
                "page_label": f"page {page.page_number}",
                "provenance": {
                    "type": "pdf_page",
                    "file_path": os.path.abspath(path),
                    "page_number": page.page_number,
                    "total_pages": result.metadata.page_count,
                    "extraction_method": legacy_method,
                },
                "extraction_method": legacy_method,
                "needs_ocr": needs_ocr,
            })

        return legacy_results


# ── Convenience functions ──────────────────────────────────────────────

def extract_text(pdf_path: str, pages: Optional[Sequence[int]] = None) -> str:
    """Quick text extraction from a PDF. Returns full text."""
    ingester = PDFIngester(use_ocr=False)
    result = ingester.ingest(pdf_path, pages=pages)
    return result.full_text


def extract_chunks(
    pdf_path: str,
    max_chunk_length: int = MAX_CHUNK_LENGTH,
    pages: Optional[Sequence[int]] = None,
) -> List[Dict[str, Any]]:
    """Extract text chunks with provenance. Returns list of dicts."""
    ingester = PDFIngester(use_ocr=False, max_chunk_length=max_chunk_length)
    result = ingester.ingest(pdf_path, pages=pages)
    return [
        {
            "text": c.text,
            "page": c.page,
            "section": c.section_heading,
            "method": c.extraction_method.value,
            "hash": c.content_hash,
        }
        for c in result.chunks
    ]


def ingest_pdf(
    pdf_path: str,
    workspace: str,
    category: str = "document",
    use_ocr: bool = True,
) -> Dict[str, Any]:
    """One-shot PDF → parsica-memory ingestion."""
    ingester = PDFIngester(use_ocr=use_ocr)
    return ingester.ingest_to_memory(pdf_path, workspace, category=category)
