"""
Quality Routing for parsica-memory

Tracks which recalled memories were actually useful by observing follow-up search patterns.
When a user searches and then searches again with a closely related query shortly after,
the entries from the first search that overlap with the second were clearly useful.
Boost their importance. Entries that never get this signal decay faster.
"""

import json
import os
import time
import re
from dataclasses import dataclass, asdict
from typing import Dict, List, Set, Tuple, Optional, Any

# Try to import fcntl for Unix file locking, fall back to no-op on Windows
try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False


# Stopwords set (hardcoded, stdlib only)
_STOPWORDS = frozenset({
    "the","a","an","is","are","was","were","be","been","being",
    "have","has","had","do","does","did","will","would","could",
    "should","may","might","shall","can","need","dare","ought",
    "used","to","in","on","at","by","for","with","about","against",
    "of","and","or","but","not","no","nor","so","yet","both",
    "either","neither","just","very","too","also","than","as",
    "that","this","these","those","it","its","i","me","my","we",
    "our","you","your","he","she","they","them","their","what",
    "which","who","when","where","how","if","then","from","into",
})


@dataclass
class QualitySignal:
    """A quality signal for a memory entry."""
    entry_hash: str        # memory entry hash
    query: str             # query that surfaced it
    signal_type: str       # "useful" | "stale"
    timestamp: float
    session_id: str = ""
    agent_id: str = ""


class OutcomeTracker:
    """
    Records quality signals for memory entries.
    Persists to {workspace}/.quality_signals.jsonl (append-only).
    Thread-safe via file locking (fcntl on unix, no-op fallback on win).
    """
    
    SIGNALS_FILE = ".quality_signals.jsonl"
    
    def __init__(self, workspace: str):
        """Initialize OutcomeTracker with workspace path."""
        try:
            self.workspace = workspace
            self.signals_path = os.path.join(workspace, self.SIGNALS_FILE)
            # Ensure workspace directory exists
            os.makedirs(workspace, exist_ok=True)
        except Exception:
            # Non-fatal fallback
            self.workspace = "."
            self.signals_path = self.SIGNALS_FILE
    
    def _append_signal(self, signal: QualitySignal) -> None:
        """Append a signal to the signals file with file locking."""
        try:
            with open(self.signals_path, "a", encoding="utf-8") as f:
                if HAS_FCNTL:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                json_line = json.dumps(asdict(signal), separators=(',', ':'))
                f.write(json_line + "\n")
                f.flush()
                if HAS_FCNTL:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        except Exception:
            # Non-fatal - signal recording failure shouldn't break the system
            pass
    
    def record_useful(self, entry_hash: str, query: str, 
                      session_id: str = "", agent_id: str = "") -> None:
        """Append a 'useful' signal for this entry."""
        try:
            signal = QualitySignal(
                entry_hash=entry_hash,
                query=query,
                signal_type="useful",
                timestamp=time.time(),
                session_id=session_id,
                agent_id=agent_id
            )
            self._append_signal(signal)
        except Exception:
            # Non-fatal
            pass
    
    def record_stale(self, entry_hash: str, query: str,
                     session_id: str = "", agent_id: str = "") -> None:
        """Append a 'stale' signal for this entry."""
        try:
            signal = QualitySignal(
                entry_hash=entry_hash,
                query=query,
                signal_type="stale",
                timestamp=time.time(),
                session_id=session_id,
                agent_id=agent_id
            )
            self._append_signal(signal)
        except Exception:
            # Non-fatal
            pass
    
    def _read_all_signals(self) -> List[QualitySignal]:
        """Read all signals from the signals file."""
        signals = []
        try:
            if not os.path.exists(self.signals_path):
                return signals
            
            with open(self.signals_path, "r", encoding="utf-8") as f:
                if HAS_FCNTL:
                    fcntl.flock(f.fileno(), fcntl.LOCK_SH)
                
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        signal = QualitySignal(**data)
                        signals.append(signal)
                    except Exception:
                        # Skip corrupt lines
                        continue
                
                if HAS_FCNTL:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        except Exception:
            # Non-fatal - return empty list
            pass
        
        return signals
    
    def get_signal_counts(self, entry_hash: str) -> Dict[str, int]:
        """Return {"useful": int, "stale": int} for a specific entry."""
        try:
            signals = self._read_all_signals()
            useful_count = sum(1 for s in signals 
                             if s.entry_hash == entry_hash and s.signal_type == "useful")
            stale_count = sum(1 for s in signals 
                            if s.entry_hash == entry_hash and s.signal_type == "stale")
            return {"useful": useful_count, "stale": stale_count}
        except Exception:
            # Non-fatal fallback
            return {"useful": 0, "stale": 0}
    
    def get_top_entries(self, n: int = 20) -> List[Tuple[str, int]]:
        """Return [(hash, useful_count)] sorted by useful_count desc."""
        try:
            signals = self._read_all_signals()
            useful_counts = {}
            
            for signal in signals:
                if signal.signal_type == "useful":
                    useful_counts[signal.entry_hash] = useful_counts.get(signal.entry_hash, 0) + 1
            
            # Sort by count descending, then by hash for stable ordering
            sorted_entries = sorted(useful_counts.items(), 
                                  key=lambda x: (-x[1], x[0]))
            
            return sorted_entries[:n]
        except Exception:
            # Non-fatal fallback
            return []
    
    def flush_to_scores(self, memories: List[Any], boost_factor: float = 0.15,
                        decay_factor: float = 0.05) -> int:
        """
        Batch-update importance scores for entries in `memories` list
        based on accumulated signals.
        - entries with useful_count > 0: importance *= (1 + boost_factor * useful_count)
        - entries with stale_count > 0 and useful_count == 0: importance *= (1 - decay_factor)
        - Caps importance at 1.0.
        - Returns number of entries updated.
        - Non-fatal.
        """
        try:
            signals = self._read_all_signals()
            
            # Build signal counts by entry hash
            signal_counts = {}
            for signal in signals:
                if signal.entry_hash not in signal_counts:
                    signal_counts[signal.entry_hash] = {"useful": 0, "stale": 0}
                signal_counts[signal.entry_hash][signal.signal_type] += 1
            
            updated_count = 0
            
            for memory in memories:
                try:
                    # Memory entries should have a 'hash' attribute and 'importance' attribute
                    entry_hash = getattr(memory, 'hash', None)
                    if not entry_hash or not hasattr(memory, 'importance'):
                        continue
                    
                    counts = signal_counts.get(entry_hash, {"useful": 0, "stale": 0})
                    useful_count = counts["useful"]
                    stale_count = counts["stale"]
                    
                    if useful_count > 0:
                        # Boost for useful signals
                        memory.importance *= (1 + boost_factor * useful_count)
                        updated_count += 1
                    elif stale_count > 0:
                        # Decay for stale signals (only if no useful signals)
                        memory.importance *= (1 - decay_factor)
                        updated_count += 1
                    
                    # Cap importance at 1.0
                    memory.importance = min(1.0, memory.importance)
                    
                except Exception:
                    # Skip individual memory entries that fail
                    continue
            
            return updated_count
            
        except Exception:
            # Non-fatal fallback
            return 0
    
    def clear_signals(self) -> None:
        """Truncate the signals file (after flush_to_scores)."""
        try:
            with open(self.signals_path, "w", encoding="utf-8") as f:
                if HAS_FCNTL:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                # Truncate by opening in write mode
                pass
        except Exception:
            # Non-fatal
            pass


class QualityRouter:
    """
    Detects follow-up search patterns and infers quality signals.
    
    Usage in search():
        router = QualityRouter(workspace)
        router.observe_search(query, results, session_id, agent_id)
        # On next search in same session: router detects overlap → records signals
    """
    
    OVERLAP_WINDOW_SECONDS = 300   # 5 min — searches within this window are related
    MIN_TOKEN_OVERLAP = 2          # min shared non-stopword tokens to count as follow-up
    
    def __init__(self, workspace: str):
        """Initialize QualityRouter with workspace path."""
        try:
            self.tracker = OutcomeTracker(workspace)
            # Session state (in-memory only, not persisted)
            # Format: {session_id: {"query": str, "result_hashes": set, "timestamp": float}}
            self._session_state: Dict[str, Dict[str, Any]] = {}
        except Exception:
            # Non-fatal fallback
            self.tracker = None
            self._session_state = {}
    
    def _tokenize_query(self, query: str) -> Set[str]:
        """Tokenize query and remove stopwords."""
        try:
            # Simple tokenization - split on non-alphanumeric, lowercase
            tokens = set(re.findall(r'\b\w+\b', query.lower()))
            # Remove stopwords
            return tokens - _STOPWORDS
        except Exception:
            # Non-fatal fallback
            return set()
    
    def _queries_related(self, query1: str, query2: str) -> bool:
        """Check if two queries are related based on token overlap."""
        try:
            tokens1 = self._tokenize_query(query1)
            tokens2 = self._tokenize_query(query2)
            
            # Count overlapping tokens
            overlap = len(tokens1.intersection(tokens2))
            return overlap >= self.MIN_TOKEN_OVERLAP
        except Exception:
            # Non-fatal fallback
            return False
    
    def observe_search(
        self,
        query: str,
        results: List[Any],          # List of SearchResult (have .entry.hash and .entry.content)
        session_id: str = "",
        agent_id: str = "",
    ) -> int:
        """
        Compare this query against the previous search in this session.
        If queries are related (MIN_TOKEN_OVERLAP shared tokens within OVERLAP_WINDOW_SECONDS),
        record 'useful' signals for entries that appeared in BOTH searches.
        Returns number of signals recorded.
        Non-fatal (returns 0 on any error).
        """
        try:
            if not self.tracker or not session_id:
                return 0
            
            current_time = time.time()
            signals_recorded = 0
            
            # Extract result hashes from current search
            current_hashes = set()
            for result in results:
                try:
                    # Results should have .entry.hash
                    if hasattr(result, 'entry') and hasattr(result.entry, 'hash'):
                        current_hashes.add(result.entry.hash)
                except Exception:
                    continue
            
            # Check if we have a previous search in this session
            if session_id in self._session_state:
                prev_search = self._session_state[session_id]
                prev_query = prev_search["query"]
                prev_hashes = prev_search["result_hashes"]
                prev_timestamp = prev_search["timestamp"]
                
                # Check if within time window and queries are related
                time_diff = current_time - prev_timestamp
                if (time_diff <= self.OVERLAP_WINDOW_SECONDS and
                    self._queries_related(query, prev_query)):
                    
                    # Find overlapping entries (appeared in both searches)
                    overlapping_hashes = prev_hashes.intersection(current_hashes)
                    
                    # Record useful signals for overlapping entries
                    for entry_hash in overlapping_hashes:
                        self.tracker.record_useful(entry_hash, query, session_id, agent_id)
                        signals_recorded += 1
            
            # Update session state with current search
            self._session_state[session_id] = {
                "query": query,
                "result_hashes": current_hashes,
                "timestamp": current_time
            }
            
            return signals_recorded
            
        except Exception:
            # Non-fatal fallback
            return 0
    
    def get_tracker(self) -> Optional[OutcomeTracker]:
        """Return the underlying OutcomeTracker."""
        return self.tracker