"""PowerPoint (.pptx) ingestion — slide extraction, structure analysis, chunking, provenance.

Architecture
~~~~~~~~~~~~
Uses python-pptx to extract text from slides, including:
  - Slide titles and body text
  - Speaker notes
  - Table contents
  - Grouped shapes / SmartArt text
  - Slide layout and master slide names

All extraction preserves slide-level provenance. Output is a list of ``PPTXChunk``
dataclasses with source file, slide number, shape info, and content hash.

Dependencies
~~~~~~~~~~~~
Required: python-pptx
Optional: pillow (for image extraction metadata)

Usage
~~~~~
    from parsica_memory.ingest_pptx import PPTXIngester

    ingester = PPTXIngester()
    result = ingester.ingest("/path/to/deck.pptx")

    # Result contains extracted chunks with provenance
    for chunk in result.chunks:
        print(f"Slide {chunk.slide}: {chunk.text[:100]}...")

    # Structured deck overview
    print(result.summary())

    # Deck structure map (for quick deck-reading workflows)
    for slide_info in result.structure():
        print(f"Slide {slide_info['slide']}: {slide_info['title']}")

    # Feed directly into Parsica memory
    for entry in result.to_memory_entries():
        memory_system.ingest(entry["content"], source=entry["source"],
                             category=entry["category"])

Backward compatibility
~~~~~~~~~~~~~~~~~~~~~~
Works alongside ingest_pdf.py. Follows the same architectural patterns
(dataclass results, provenance, chunking, memory integration).
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

_log = logging.getLogger("parsica_memory.ingest_pptx")

# ── Constants ──────────────────────────────────────────────────────────

MIN_TEXT_LENGTH = 20        # Minimum chars to consider a slide as having text
MIN_CHUNK_LENGTH = 30       # Minimum chars per output chunk
MAX_CHUNK_LENGTH = 2000     # Target max chars per chunk (soft limit)


# ── Data types ─────────────────────────────────────────────────────────

class SlideContentType(Enum):
    """What kind of content was extracted from a shape."""
    TITLE = "title"
    BODY = "body"
    TABLE = "table"
    NOTES = "notes"
    GROUP = "group"
    CHART_TITLE = "chart_title"
    OTHER = "other"


@dataclass
class PPTXChunk:
    """A chunk of text extracted from a PPTX with full provenance."""
    text: str
    slide: int                    # 1-indexed slide number
    chunk_index: int              # 0-indexed within the slide
    source_file: str              # Original file path
    content_type: SlideContentType
    content_hash: str = ""
    shape_name: str = ""          # PowerPoint shape name
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.content_hash:
            self.content_hash = _content_hash(self.text)


@dataclass
class PPTXMetadata:
    """PPTX document metadata from core properties."""
    title: str = ""
    author: str = ""
    subject: str = ""
    description: str = ""
    category: str = ""
    last_modified_by: str = ""
    created: str = ""
    modified: str = ""
    slide_count: int = 0
    file_size: int = 0
    slide_width_emu: int = 0
    slide_height_emu: int = 0
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def aspect_ratio(self) -> str:
        """Return human-readable aspect ratio."""
        if not self.slide_width_emu or not self.slide_height_emu:
            return "unknown"
        ratio = self.slide_width_emu / self.slide_height_emu
        if abs(ratio - 16 / 9) < 0.05:
            return "16:9"
        elif abs(ratio - 4 / 3) < 0.05:
            return "4:3"
        elif abs(ratio - 16 / 10) < 0.05:
            return "16:10"
        return f"{ratio:.2f}:1"


@dataclass
class SlideInfo:
    """Extraction result for a single slide."""
    slide_number: int           # 1-indexed
    title: str
    body_text: str
    notes_text: str
    layout_name: str
    shape_count: int
    has_images: bool
    has_tables: bool
    has_charts: bool
    word_count: int = 0
    table_data: List[List[List[str]]] = field(default_factory=list)

    def __post_init__(self):
        combined = f"{self.title} {self.body_text} {self.notes_text}"
        self.word_count = len(combined.split()) if combined.strip() else 0


@dataclass
class PPTXResult:
    """Complete result of PPTX ingestion."""
    source_file: str
    metadata: PPTXMetadata
    slides: List[SlideInfo]
    chunks: List[PPTXChunk]
    extraction_time_ms: float = 0.0
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    @property
    def full_text(self) -> str:
        """Concatenated text from all slides (title + body + notes)."""
        parts = []
        for s in self.slides:
            slide_parts = []
            if s.title:
                slide_parts.append(f"[Slide {s.slide_number}] {s.title}")
            if s.body_text:
                slide_parts.append(s.body_text)
            if s.notes_text:
                slide_parts.append(f"[Notes] {s.notes_text}")
            if slide_parts:
                parts.append("\n".join(slide_parts))
        return "\n\n".join(parts)

    @property
    def slide_count(self) -> int:
        return len(self.slides)

    @property
    def total_words(self) -> int:
        return sum(s.word_count for s in self.slides)

    def structure(self) -> List[Dict[str, Any]]:
        """Return a structured map of the deck — slide titles, content types, etc.

        Useful for quick deck-reading / summarization workflows.
        """
        result = []
        for s in self.slides:
            info: Dict[str, Any] = {
                "slide": s.slide_number,
                "title": s.title or "(untitled)",
                "layout": s.layout_name,
                "word_count": s.word_count,
                "has_images": s.has_images,
                "has_tables": s.has_tables,
                "has_charts": s.has_charts,
                "shapes": s.shape_count,
            }
            if s.notes_text:
                info["has_notes"] = True
                info["notes_preview"] = s.notes_text[:120].replace("\n", " ")
            result.append(info)
        return result

    def to_memory_entries(
        self,
        category: str = "deck",
        include_metadata: bool = True,
        include_notes: bool = True,
    ) -> List[Dict[str, Any]]:
        """Convert chunks to dicts ready for parsica-memory ingestion.

        Each entry includes provenance in the source field:
            "pptx:<filename>:slide<N>[:<content_type>]"
        """
        entries = []
        filename = Path(self.source_file).name

        for chunk in self.chunks:
            source_parts = [f"pptx:{filename}:slide{chunk.slide}"]
            if chunk.content_type != SlideContentType.BODY:
                source_parts.append(chunk.content_type.value)
            source = ":".join(source_parts)

            # Skip notes if not wanted
            if not include_notes and chunk.content_type == SlideContentType.NOTES:
                continue

            entry: Dict[str, Any] = {
                "content": chunk.text,
                "source": source,
                "category": category,
                "metadata": {
                    "slide": chunk.slide,
                    "content_type": chunk.content_type.value,
                    "content_hash": chunk.content_hash,
                    "chunk_index": chunk.chunk_index,
                },
            }
            if include_metadata and self.metadata.title:
                entry["metadata"]["document_title"] = self.metadata.title
            if include_metadata and self.metadata.author:
                entry["metadata"]["document_author"] = self.metadata.author
            if chunk.shape_name:
                entry["metadata"]["shape_name"] = chunk.shape_name

            entries.append(entry)

        return entries

    def summary(self) -> str:
        """Human-readable summary of the extraction."""
        lines = [
            f"PPTX: {Path(self.source_file).name}",
        ]
        if self.metadata.title:
            lines.append(f"  Title: {self.metadata.title}")
        if self.metadata.author:
            lines.append(f"  Author: {self.metadata.author}")
        lines.extend([
            f"  Slides: {self.slide_count}",
            f"  Words: {self.total_words:,}",
            f"  Chunks: {len(self.chunks)}",
            f"  Aspect: {self.metadata.aspect_ratio}",
            f"  Time: {self.extraction_time_ms:.0f}ms",
        ])

        # Content type breakdown
        image_slides = sum(1 for s in self.slides if s.has_images)
        table_slides = sum(1 for s in self.slides if s.has_tables)
        chart_slides = sum(1 for s in self.slides if s.has_charts)
        notes_slides = sum(1 for s in self.slides if s.notes_text)
        if image_slides:
            lines.append(f"  Slides with images: {image_slides}")
        if table_slides:
            lines.append(f"  Slides with tables: {table_slides}")
        if chart_slides:
            lines.append(f"  Slides with charts: {chart_slides}")
        if notes_slides:
            lines.append(f"  Slides with notes: {notes_slides}")

        if self.warnings:
            lines.append(f"  Warnings: {len(self.warnings)}")
        if self.errors:
            lines.append(f"  Errors: {len(self.errors)}")
        return "\n".join(lines)

    def slide_text(self, slide_number: int) -> Optional[str]:
        """Get full text for a specific slide (1-indexed)."""
        for s in self.slides:
            if s.slide_number == slide_number:
                parts = []
                if s.title:
                    parts.append(f"# {s.title}")
                if s.body_text:
                    parts.append(s.body_text)
                if s.notes_text:
                    parts.append(f"\n---\nNotes: {s.notes_text}")
                return "\n\n".join(parts)
        return None


# ── Helpers ────────────────────────────────────────────────────────────

def _content_hash(text: str) -> str:
    """SHA-256 prefix for deduplication."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _clean_text(text: str) -> str:
    """Normalize whitespace and remove common artifacts."""
    if not text:
        return ""
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text)
    return text.strip()


def _extract_shape_text(shape) -> str:
    """Extract text from a single shape, handling text frames and tables."""
    if not hasattr(shape, "text_frame") and not hasattr(shape, "text"):
        return ""
    try:
        if hasattr(shape, "text_frame"):
            paragraphs = []
            for para in shape.text_frame.paragraphs:
                runs_text = "".join(run.text for run in para.runs)
                if runs_text.strip():
                    paragraphs.append(runs_text.strip())
            return "\n".join(paragraphs)
        elif hasattr(shape, "text"):
            return shape.text.strip()
    except Exception:
        return ""
    return ""


def _extract_table_text(table) -> Tuple[str, List[List[str]]]:
    """Extract text from a table shape, returning both formatted text and raw data."""
    rows_data: List[List[str]] = []
    for row in table.rows:
        cells = []
        for cell in row.cells:
            cells.append(cell.text.strip())
        rows_data.append(cells)

    # Format as markdown-style table
    if not rows_data:
        return "", []

    lines = []
    # Header row
    if rows_data:
        lines.append("| " + " | ".join(rows_data[0]) + " |")
        lines.append("| " + " | ".join("---" for _ in rows_data[0]) + " |")
        for row in rows_data[1:]:
            # Pad row to match header length
            padded = row + [""] * (len(rows_data[0]) - len(row))
            lines.append("| " + " | ".join(padded[:len(rows_data[0])]) + " |")

    return "\n".join(lines), rows_data


def _extract_group_text(shape) -> str:
    """Recursively extract text from grouped shapes."""
    texts = []
    try:
        for child_shape in shape.shapes:
            if hasattr(child_shape, "shapes"):
                # Nested group
                texts.append(_extract_group_text(child_shape))
            else:
                t = _extract_shape_text(child_shape)
                if t:
                    texts.append(t)
    except Exception:
        pass
    return "\n".join(t for t in texts if t)


# ── Main Ingester ──────────────────────────────────────────────────────

class PPTXIngester:
    """High-level PPTX ingestion with structure analysis.

    Parameters
    ----------
    include_notes : bool
        Include speaker notes in extraction.
    include_tables : bool
        Include table content in extraction.
    max_chunk_length : int
        Target maximum characters per chunk.
    min_chunk_length : int
        Minimum characters for a chunk to be emitted.
    """

    def __init__(
        self,
        include_notes: bool = True,
        include_tables: bool = True,
        max_chunk_length: int = MAX_CHUNK_LENGTH,
        min_chunk_length: int = MIN_CHUNK_LENGTH,
    ):
        self.include_notes = include_notes
        self.include_tables = include_tables
        self.max_chunk_length = max_chunk_length
        self.min_chunk_length = min_chunk_length

    @staticmethod
    def available() -> bool:
        """Check if python-pptx is available."""
        try:
            import pptx  # noqa: F401
            return True
        except ImportError:
            return False

    def ingest(
        self,
        pptx_path: str,
        slides: Optional[Sequence[int]] = None,
    ) -> PPTXResult:
        """Ingest a PPTX file and return structured extraction result.

        Parameters
        ----------
        pptx_path : str
            Path to the .pptx file.
        slides : Sequence[int], optional
            Specific slides to extract (1-indexed). None = all slides.

        Returns
        -------
        PPTXResult
            Structured result with slides, chunks, metadata, and provenance.
        """
        t0 = time.monotonic()
        pptx_path = os.path.abspath(pptx_path)
        all_warnings: List[str] = []
        all_errors: List[str] = []

        if not os.path.exists(pptx_path):
            return PPTXResult(
                source_file=pptx_path,
                metadata=PPTXMetadata(),
                slides=[],
                chunks=[],
                errors=[f"File not found: {pptx_path}"],
            )

        try:
            from pptx import Presentation
            from pptx.util import Emu
        except ImportError:
            return PPTXResult(
                source_file=pptx_path,
                metadata=PPTXMetadata(),
                slides=[],
                chunks=[],
                errors=["python-pptx not installed. Run: pip install python-pptx"],
            )

        try:
            prs = Presentation(pptx_path)
        except Exception as e:
            return PPTXResult(
                source_file=pptx_path,
                metadata=PPTXMetadata(),
                slides=[],
                chunks=[],
                errors=[f"Failed to open PPTX: {e}"],
            )

        # ── Extract metadata ──
        metadata = PPTXMetadata(
            slide_count=len(prs.slides),
            file_size=os.path.getsize(pptx_path),
            slide_width_emu=prs.slide_width if prs.slide_width else 0,
            slide_height_emu=prs.slide_height if prs.slide_height else 0,
        )

        if prs.core_properties:
            cp = prs.core_properties
            metadata.title = cp.title or ""
            metadata.author = cp.author or ""
            metadata.subject = cp.subject or ""
            metadata.description = cp.comments or ""
            metadata.category = cp.category or ""
            metadata.last_modified_by = cp.last_modified_by or ""
            if cp.created:
                metadata.created = str(cp.created)
            if cp.modified:
                metadata.modified = str(cp.modified)

        # ── Extract slides ──
        slide_infos: List[SlideInfo] = []
        all_chunks: List[PPTXChunk] = []

        for slide_idx, slide in enumerate(prs.slides):
            slide_num = slide_idx + 1

            # Filter to requested slides
            if slides and slide_num not in slides:
                continue

            # Extract title
            title = ""
            if slide.shapes.title:
                title = _clean_text(slide.shapes.title.text or "")

            # Extract body text, tables, images, charts
            body_parts: List[str] = []
            has_images = False
            has_tables = False
            has_charts = False
            table_data_list: List[List[List[str]]] = []

            for shape in slide.shapes:
                try:
                    # Skip the title shape (already extracted)
                    if shape == slide.shapes.title:
                        continue

                    # Tables
                    if shape.has_table:
                        has_tables = True
                        if self.include_tables:
                            table_text, raw_data = _extract_table_text(shape.table)
                            if table_text:
                                body_parts.append(table_text)
                                table_data_list.append(raw_data)

                                # Create table chunk
                                if len(table_text.strip()) >= self.min_chunk_length:
                                    all_chunks.append(PPTXChunk(
                                        text=table_text.strip(),
                                        slide=slide_num,
                                        chunk_index=len(all_chunks),
                                        source_file=pptx_path,
                                        content_type=SlideContentType.TABLE,
                                        shape_name=shape.name,
                                    ))
                        continue

                    # Charts
                    if shape.has_chart:
                        has_charts = True
                        try:
                            chart = shape.chart
                            if hasattr(chart, 'chart_title') and chart.chart_title:
                                ct_text = chart.chart_title.text_frame.text.strip()
                                if ct_text:
                                    body_parts.append(f"[Chart: {ct_text}]")
                                    if len(ct_text) >= self.min_chunk_length:
                                        all_chunks.append(PPTXChunk(
                                            text=f"Chart: {ct_text}",
                                            slide=slide_num,
                                            chunk_index=len(all_chunks),
                                            source_file=pptx_path,
                                            content_type=SlideContentType.CHART_TITLE,
                                            shape_name=shape.name,
                                        ))
                        except Exception:
                            pass
                        continue

                    # Images
                    if shape.shape_type is not None:
                        try:
                            from pptx.enum.shapes import MSO_SHAPE_TYPE
                            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                                has_images = True
                                continue
                        except (ImportError, AttributeError):
                            pass

                    # Group shapes
                    if hasattr(shape, "shapes"):
                        group_text = _extract_group_text(shape)
                        if group_text:
                            body_parts.append(group_text)
                            if len(group_text.strip()) >= self.min_chunk_length:
                                all_chunks.append(PPTXChunk(
                                    text=group_text.strip(),
                                    slide=slide_num,
                                    chunk_index=len(all_chunks),
                                    source_file=pptx_path,
                                    content_type=SlideContentType.GROUP,
                                    shape_name=shape.name,
                                ))
                        continue

                    # Regular text shapes
                    if shape.has_text_frame:
                        shape_text = _extract_shape_text(shape)
                        if shape_text:
                            body_parts.append(shape_text)

                except Exception as e:
                    all_warnings.append(
                        f"Slide {slide_num}, shape '{getattr(shape, 'name', '?')}': {e}"
                    )

            body_text = _clean_text("\n\n".join(body_parts))

            # Extract speaker notes
            notes_text = ""
            if self.include_notes and slide.has_notes_slide:
                try:
                    notes_tf = slide.notes_slide.notes_text_frame
                    if notes_tf:
                        notes_text = _clean_text(notes_tf.text or "")
                except Exception as e:
                    all_warnings.append(f"Slide {slide_num} notes extraction failed: {e}")

            # Layout name
            layout_name = ""
            try:
                layout_name = slide.slide_layout.name or ""
            except Exception:
                pass

            # Build SlideInfo
            si = SlideInfo(
                slide_number=slide_num,
                title=title,
                body_text=body_text,
                notes_text=notes_text,
                layout_name=layout_name,
                shape_count=len(slide.shapes),
                has_images=has_images,
                has_tables=has_tables,
                has_charts=has_charts,
                table_data=table_data_list,
            )
            slide_infos.append(si)

            # ── Create chunks for title + body ──
            # Title chunk
            if title and len(title.strip()) >= self.min_chunk_length:
                all_chunks.append(PPTXChunk(
                    text=title.strip(),
                    slide=slide_num,
                    chunk_index=len(all_chunks),
                    source_file=pptx_path,
                    content_type=SlideContentType.TITLE,
                ))

            # Body chunks (split long body text)
            if body_text and len(body_text.strip()) >= self.min_chunk_length:
                # If body fits in one chunk, create one
                if len(body_text) <= self.max_chunk_length:
                    all_chunks.append(PPTXChunk(
                        text=body_text.strip(),
                        slide=slide_num,
                        chunk_index=len(all_chunks),
                        source_file=pptx_path,
                        content_type=SlideContentType.BODY,
                    ))
                else:
                    # Split by paragraphs
                    paragraphs = re.split(r'\n\n+', body_text.strip())
                    buffer = ""
                    for para in paragraphs:
                        if buffer and len(buffer) + len(para) + 2 > self.max_chunk_length:
                            if len(buffer.strip()) >= self.min_chunk_length:
                                all_chunks.append(PPTXChunk(
                                    text=buffer.strip(),
                                    slide=slide_num,
                                    chunk_index=len(all_chunks),
                                    source_file=pptx_path,
                                    content_type=SlideContentType.BODY,
                                ))
                            buffer = ""
                        buffer = (buffer + "\n\n" + para).strip() if buffer else para

                    if buffer and len(buffer.strip()) >= self.min_chunk_length:
                        all_chunks.append(PPTXChunk(
                            text=buffer.strip(),
                            slide=slide_num,
                            chunk_index=len(all_chunks),
                            source_file=pptx_path,
                            content_type=SlideContentType.BODY,
                        ))

            # Notes chunk
            if notes_text and len(notes_text.strip()) >= self.min_chunk_length:
                all_chunks.append(PPTXChunk(
                    text=notes_text.strip(),
                    slide=slide_num,
                    chunk_index=len(all_chunks),
                    source_file=pptx_path,
                    content_type=SlideContentType.NOTES,
                ))

        elapsed_ms = (time.monotonic() - t0) * 1000

        return PPTXResult(
            source_file=pptx_path,
            metadata=metadata,
            slides=slide_infos,
            chunks=all_chunks,
            extraction_time_ms=elapsed_ms,
            warnings=all_warnings,
            errors=all_errors,
        )

    def ingest_to_memory(
        self,
        pptx_path: str,
        workspace: str,
        category: str = "deck",
        agent_name: Optional[str] = None,
        slides: Optional[Sequence[int]] = None,
    ) -> Dict[str, Any]:
        """Ingest a PPTX directly into a parsica-memory workspace.

        Returns
        -------
        dict
            {count, chunks, warnings, errors, summary}
        """
        result = self.ingest(pptx_path, slides=slides)

        if result.errors and not result.chunks:
            return {
                "count": 0,
                "chunks": 0,
                "warnings": result.warnings,
                "errors": result.errors,
                "summary": "Ingestion failed",
            }

        entries = result.to_memory_entries(category=category)

        try:
            from .core_v4 import MemorySystemV4

            ms = MemorySystemV4(workspace=workspace, agent_name=agent_name)
            ms.load()

            existing_hashes = {m.hash for m in ms.memories}
            ingested = 0

            for entry in entries:
                h = _content_hash(entry["content"])
                if h in existing_hashes:
                    continue
                ms.ingest(
                    entry["content"],
                    source=entry["source"],
                    category=entry["category"],
                )
                existing_hashes.add(h)
                ingested += 1

            ms.save()
        except Exception as e:
            _log.error("Failed to ingest into memory: %s", e)
            return {
                "count": 0,
                "chunks": len(result.chunks),
                "warnings": result.warnings,
                "errors": result.errors + [f"Memory ingestion failed: {e}"],
                "summary": result.summary(),
            }

        return {
            "count": ingested,
            "chunks": len(result.chunks),
            "warnings": result.warnings,
            "errors": result.errors,
            "summary": result.summary(),
        }


# ── Convenience functions ──────────────────────────────────────────────

def extract_text(pptx_path: str, slides: Optional[Sequence[int]] = None) -> str:
    """Quick text extraction from a PPTX. Returns full text."""
    ingester = PPTXIngester()
    result = ingester.ingest(pptx_path, slides=slides)
    return result.full_text


def extract_structure(pptx_path: str) -> List[Dict[str, Any]]:
    """Extract deck structure map (slide titles, types, word counts)."""
    ingester = PPTXIngester()
    result = ingester.ingest(pptx_path)
    return result.structure()


def extract_slide(pptx_path: str, slide_number: int) -> Optional[str]:
    """Extract text from a specific slide (1-indexed)."""
    ingester = PPTXIngester()
    result = ingester.ingest(pptx_path, slides=[slide_number])
    return result.slide_text(slide_number)


def summarize_deck(pptx_path: str) -> str:
    """Return a human-readable summary of the deck."""
    ingester = PPTXIngester()
    result = ingester.ingest(pptx_path)
    return result.summary()


def ingest_pptx(
    pptx_path: str,
    workspace: str,
    category: str = "deck",
) -> Dict[str, Any]:
    """One-shot PPTX → parsica-memory ingestion."""
    ingester = PPTXIngester()
    return ingester.ingest_to_memory(pptx_path, workspace, category=category)
