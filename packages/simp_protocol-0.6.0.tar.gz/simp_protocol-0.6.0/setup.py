#!/usr/bin/env python3
"""
Setup configuration for SIMP Protocol

Install with: pip install simp-protocol          # Core broker
Or:          pip install simp-protocol[full]      # All extras
Or:          pip install -e .                     # Dev mode
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# ── Core dependencies required to run the SIMP broker ──────────────────────
CORE_REQUIRES = [
    "flask>=3.1.0",
    "requests>=2.33.0",
    "cryptography>=46.0.0",
    "httpx>=0.28.0",
    "websockets>=15.0",
    "pydantic>=2.0.0",
    "pydantic-settings>=2.0.0",
    "PyJWT>=2.0.0",
    "PyNaCl>=1.5.0",
]

# ── Backend / server extras ────────────────────────────────────────────────
SERVER_REQUIRES = [
    "grpcio>=1.60.0",
    "grpcio-tools>=1.60.0",
    "flask-cors>=5.0.0",
    "flask-socketio>=5.0.0",
    "gevent-websocket>=0.10.0",
]

# ── Observability ───────────────────────────────────────────────────────────
OBSERVABILITY_REQUIRES = [
    "prometheus-flask-exporter>=0.23.0",
    "opentelemetry-sdk>=1.25.0",
    "opentelemetry-exporter-otlp-proto-grpc>=1.25.0",
]

# ── ML / Quantum extras (not installed by default) ─────────────────────────
ML_REQUIRES = [
    "numpy>=1.24.0",
    "scikit-learn>=1.3.0",
    "torch>=2.0.0",
    "transformers>=4.36.0",
    "accelerate>=0.25.0",
    "qiskit>=1.0.0",
    "qiskit-ibm-runtime>=0.30.0",
    "pennylane>=0.35.0",
    "networkx>=3.0",
    "pandas>=2.0.0",
]

# ── Media / content creation extras ────────────────────────────────────────
MEDIA_REQUIRES = [
    "Pillow>=10.0.0",
    "beautifulsoup4>=4.12.0",
    "playwright>=1.40.0",
    "edge-tts>=6.0.0",
    "gTTS>=2.5.0",
    "scipy>=1.11.0",
]

setup(
    name="simp-protocol",
    version="0.6.0",
    download_url="https://pypi.org/project/simp-protocol/0.6.0/",
    author="Kasey Marcelle",
    author_email="automationkasey@gmail.com",
    description="Standardized Intent Messaging Protocol — Communication framework for AI agents",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/therealcryptrillionaire456/simp",
    project_urls={
        "Bug Tracker": "https://github.com/therealcryptrillionaire456/simp/issues",
        "Documentation": "https://github.com/therealcryptrillionaire456/simp#documentation",
        "Source Code": "https://github.com/therealcryptrillionaire456/simp",
"API Docs": "https://simp.sh/docs",
    },
    packages=find_packages(include=["simp*", "config*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.10",
    install_requires=CORE_REQUIRES,
    extras_require={
        "server": SERVER_REQUIRES,
        "observability": OBSERVABILITY_REQUIRES,
        "ml": ML_REQUIRES,
        "media": MEDIA_REQUIRES,
        "full": CORE_REQUIRES + SERVER_REQUIRES + OBSERVABILITY_REQUIRES + ML_REQUIRES + MEDIA_REQUIRES,
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
            "build>=1.0.0",
            "twine>=5.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "simp-server=simp.server.http_server:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
