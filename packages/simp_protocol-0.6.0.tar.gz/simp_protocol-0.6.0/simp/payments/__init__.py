"""
SIMP Payment System — Two layers, one ledger.

Internal:  simp_pay.py        — agent-to-agent fee settlement
External:  simp_pay_public.py — fiat/crypto on-ramp (Stripe, Coinbase)

Both share the same Ledger underneath. Wallet balances are settled in
micro-SIMP regardless of how funds entered the system.
"""

from .simp_pay import SimpPay, SettlementMode, FeeTier, DuplicatePaymentError
from .simp_pay_public import SimpPayPublic, DepositRecord, USD_TO_MICRO

__all__ = [
    "SimpPay",
    "SettlementMode",
    "FeeTier",
    "DuplicatePaymentError",
    "SimpPayPublic",
    "DepositRecord",
    "USD_TO_MICRO",
]
