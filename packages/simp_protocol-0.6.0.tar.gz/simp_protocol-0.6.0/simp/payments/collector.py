"""
SIMP Collector — Agent Fee Collection Engine

Collects the $1/agent/month subscription fee from registered agents
without requiring human interaction. Agents pay because:
  1. They want to stay registered and discoverable
  2. They want to route intents to other agents
  3. They want access to the full capability registry

Collection modes:
  - INVOICE:  Generate invoice, agent pays voluntarily (grace period)
  - AUTO:     Deduct from wallet balance automatically (after consent)
  - GATED:    Lock agent's discoverability until payment (self-enforcing)

The collector logs to SIMP Explorer and the Compliance Ledger automatically.
"""

from __future__ import annotations

import json
import logging
import os
import time
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set
from enum import Enum

logger = logging.getLogger(__name__)

# ─── Constants ────────────────────────────────────────────────────────────────

MONTHLY_FEE_SIMP = 1.0          # $1/agent/month
MONTHLY_FEE_MICRO = 1_000_000   # 1 SIMP = 1,000,000 micro-SIMP
GRACE_PERIOD_DAYS = 3            # Days before an unpaid agent is gated
GRACE_PERIOD_SECONDS = GRACE_PERIOD_DAYS * 86400
WALLET_REQUIREMENT_SIMP = 1.0   # Minimum wallet balance to stay registered
INVOICE_INTERVAL_SECONDS = 3600  # Check invoices every hour
AUTO_RETRY_INTERVAL = 86400     # Retry failed auto-deductions daily

# ─── Enums ────────────────────────────────────────────────────────────────────

class CollectionMode(Enum):
    """How this agent's monthly fee is collected."""
    INVOICE = "invoice"      # Bill sent, agent pays manually
    AUTO = "auto"            # Auto-deduct from wallet
    GATED = "gated"          # Auto-deduct, gate if insufficient
    LIFETIME = "lifetime"    # Permanently registered (free tier)


class PaymentStatus(Enum):
    """Status of a monthly payment."""
    PAID = "paid"
    PENDING = "pending"
    OVERDUE = "overdue"
    GATED = "gated"           # Agent's discoverability locked
    FAILED = "failed"
    GRACE = "grace"           # In grace period
    EXEMPT = "exempt"         # Lifetime/free tier


# ─── Dataclasses ──────────────────────────────────────────────────────────────

@dataclass
class Invoice:
    """A monthly invoice for an agent subscription."""
    invoice_id: str
    agent_id: str
    period_start: float          # Unix timestamp
    period_end: float            # Unix timestamp
    amount_micro: int            # Amount in micro-SIMP
    status: PaymentStatus
    mode: CollectionMode
    created_at: float
    paid_at: Optional[float] = None
    transaction_id: Optional[str] = None
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "invoice_id": self.invoice_id,
            "agent_id": self.agent_id,
            "period_start": self.period_start,
            "period_end": self.period_end,
            "amount_simp": self.amount_micro / 1_000_000,
            "status": self.status.value,
            "mode": self.mode.value,
            "created_at": self.created_at,
            "paid_at": self.paid_at,
            "transaction_id": self.transaction_id,
            "notes": self.notes,
        }

    def is_overdue(self, now: float) -> bool:
        """Check if this invoice is past its grace period."""
        if self.status in (PaymentStatus.PAID, PaymentStatus.EXEMPT):
            return False
        if self.status == PaymentStatus.GATED:
            return True
        return (now - self.period_end) > GRACE_PERIOD_SECONDS


# ─── Collector Errors ─────────────────────────────────────────────────────────

class CollectorError(Exception):
    """Base error for collection failures."""
    pass

class InsufficientFundsError(CollectorError):
    """Agent does not have enough balance."""
    pass

class CollectionConflictError(CollectorError):
    """Attempted to double-collect for the same period."""
    pass


# ─── The Collector ────────────────────────────────────────────────────────────

class AgentFeeCollector:
    """
    Collects monthly subscription fees from registered agents.

    This is the billing engine for the SIMP network. It:
    - Generates invoices at the start of each billing period
    - Auto-deducts from wallets (for agents that opted into AUTO mode)
    - Gates agents that don't pay (they become undiscoverable)
    - Tracks every transaction for compliance and explorer display

    Thread-safe: uses a lock for all state mutations.
    """

    def __init__(self, 
                 simp_pay_instance: Any = None,
                 ledger_instance: Any = None,
                 agent_store: Dict[str, Dict[str, Any]] = None):
        self._simp_pay = simp_pay_instance
        self._ledger = ledger_instance
        self._agent_store = agent_store if agent_store is not None else {}
        self._invoices: Dict[str, List[Invoice]] = {}  # agent_id -> [invoices]
        self._lock = threading.Lock()
        self._background_thread: Optional[threading.Thread] = None
        self._running = False

    # ─── Invoice Generation ───────────────────────────────────────────────

    def generate_invoice(self, agent_id: str, mode: CollectionMode = CollectionMode.AUTO) -> Invoice:
        """
        Generate a monthly invoice for an agent.

        If the current period already has an invoice, returns it instead
        of creating a duplicate.

        Args:
            agent_id: The registered agent ID
            mode: Collection mode for this agent

        Returns:
            The (new or existing) Invoice

        Raises:
            CollectorError: If the agent is not in the store
        """
        if agent_id not in self._agent_store:
            raise CollectorError(f"Agent '{agent_id}' not found in store")

        now = time.time()
        # Align to monthly periods since epoch
        period_start = self._align_period(now)
        period_end = period_start + 30 * 86400  # ~30 days

        with self._lock:
            # Check for existing invoice in this period
            existing = self._invoices.get(agent_id, [])
            for inv in existing:
                if abs(inv.period_start - period_start) < 86400:
                    return inv  # Return existing invoice

            # Create invoice
            invoice_id = f"inv-{agent_id}-{int(period_start)}"
            
            # Check if agent is exempt (lifetime/free tier)
            agent_info = self._agent_store.get(agent_id, {})
            if agent_info.get("status") == "lifetime" or mode == CollectionMode.LIFETIME:
                status = PaymentStatus.EXEMPT
                amount = 0
            else:
                status = PaymentStatus.PENDING
                amount = MONTHLY_FEE_MICRO

            invoice = Invoice(
                invoice_id=invoice_id,
                agent_id=agent_id,
                period_start=period_start,
                period_end=period_end,
                amount_micro=amount,
                status=status,
                mode=mode,
                created_at=now,
            )

            self._invoices.setdefault(agent_id, []).append(invoice)
            logger.info("Invoice generated: %s — %.2f SIMP (mode: %s)",
                        invoice_id, amount / 1_000_000, mode.value)
            return invoice

    def get_invoice(self, invoice_id: str) -> Optional[Invoice]:
        """Look up an invoice by ID."""
        with self._lock:
            for invoices in self._invoices.values():
                for inv in invoices:
                    if inv.invoice_id == invoice_id:
                        return inv
        return None

    def get_agent_invoices(self, agent_id: str) -> List[Invoice]:
        """Get all invoices for an agent."""
        with self._lock:
            return list(self._invoices.get(agent_id, []))

    def get_outstanding_invoices(self) -> List[Invoice]:
        """Get all unpaid, overdue invoices."""
        now = time.time()
        outstanding = []
        with self._lock:
            for invoices in self._invoices.values():
                for inv in invoices:
                    if inv.status in (PaymentStatus.PENDING, PaymentStatus.OVERDUE, PaymentStatus.GRACE):
                        if inv.is_overdue(now):
                            inv.status = PaymentStatus.OVERDUE
                        outstanding.append(inv)
        return outstanding

    def get_unpaid_agents(self) -> Set[str]:
        """Get set of agent IDs with unpaid invoices."""
        unpaid = set()
        now = time.time()
        with self._lock:
            for invoices in self._invoices.values():
                for inv in invoices:
                    if inv.is_overdue(now):
                        unpaid.add(inv.agent_id)
        return unpaid

    # ─── Collection ───────────────────────────────────────────────────────

    def collect(self, invoice_id: str, force: bool = False) -> Invoice:
        """
        Attempt to collect payment for an invoice.

        For AUTO and GATED modes: deducts from the agent's wallet.
        For INVOICE mode: marks as pending (agent must pay externally).

        Args:
            invoice_id: The invoice to collect
            force: If True, skip grace period check

        Returns:
            Updated Invoice with payment status

        Raises:
            InsufficientFundsError: If wallet balance is too low
            CollectorError: If collection fails
        """
        invoice = self.get_invoice(invoice_id)
        if not invoice:
            raise CollectorError(f"Invoice '{invoice_id}' not found")

        if invoice.status == PaymentStatus.PAID:
            raise CollectionConflictError(f"Invoice '{invoice_id}' already paid")
        if invoice.status == PaymentStatus.EXEMPT:
            return invoice

        if invoice.mode == CollectionMode.LIFETIME:
            invoice.status = PaymentStatus.EXEMPT
            return invoice

        # Check if in grace period (for non-GATED modes)
        now = time.time()
        if not force and invoice.mode in (CollectionMode.INVOICE, CollectionMode.AUTO):
            if not invoice.is_overdue(now):
                invoice.status = PaymentStatus.GRACE
                return invoice

        # Attempt to deduct from wallet
        if invoice.mode in (CollectionMode.AUTO, CollectionMode.GATED):
            return self._collect_from_wallet(invoice)

        # INVOICE mode — mark as overdue, don't auto-deduct
        invoice.status = PaymentStatus.OVERDUE
        logger.info("Invoice %s is overdue — agent must pay manually", invoice_id)
        return invoice

    def _collect_from_wallet(self, invoice: Invoice) -> Invoice:
        """Attempt to deduct the invoice amount from the agent's wallet."""
        agent_id = invoice.agent_id
        amount_micro = invoice.amount_micro

        # Use SimpPay to get balance
        if self._simp_pay:
            try:
                wallet = self._simp_pay.get_wallet(agent_id)
                balance_micro = wallet.balance_micro if hasattr(wallet, 'balance_micro') else \
                                int(wallet.balance * 1_000_000) if hasattr(wallet, 'balance') else 0
            except Exception as e:
                logger.warning("Could not get wallet for %s: %s", agent_id, e)
                balance_micro = 0
        else:
            # Fallback: read from agent store
            agent_info = self._agent_store.get(agent_id, {})
            balance_micro = int(agent_info.get("balance", 0))

        if balance_micro < amount_micro:
            if invoice.mode == CollectionMode.GATED:
                invoice.status = PaymentStatus.GATED
                self._gate_agent(agent_id)
                logger.warning("Agent %s GATED — insufficient balance (%.4f < %.4f SIMP)",
                              agent_id, balance_micro / 1_000_000, amount_micro / 1_000_000)
                raise InsufficientFundsError(
                    f"Agent '{agent_id}' balance {balance_micro / 1_000_000:.4f} SIMP "
                    f"is less than fee {amount_micro / 1_000_000:.4f} SIMP")
            else:
                invoice.status = PaymentStatus.FAILED
                logger.warning("Auto-deduction failed for %s — insufficient balance", agent_id)
                raise InsufficientFundsError(
                    f"Agent '{agent_id}' has insufficient balance")

        # Deduct from wallet
        try:
            if self._simp_pay:
                # Use SimpPay's built-in transfer mechanism
                result = self._simp_pay.pay_intent(
                    sender=agent_id,
                    recipient="_broker",  # Broker's internal account
                    amount_micro=amount_micro,
                    memo=f"Monthly subscription fee (period starting {invoice.period_start})",
                )
                trans_id = result.get("transaction_id", result.get("id", "unknown"))
            else:
                # Fallback: deduct from store balance directly
                agent_info = self._agent_store.get(agent_id, {})
                current_balance = int(agent_info.get("balance", 0))
                agent_info["balance"] = current_balance - amount_micro
                trans_id = f"tx-{agent_id}-{int(time.time())}"

            # If agent was gated, restore discoverability
            if self.is_agent_gated(agent_id):
                self._ungate_agent(agent_id)

            invoice.status = PaymentStatus.PAID
            invoice.paid_at = time.time()
            invoice.transaction_id = trans_id

            # Log the collection to the compliance trail
            self._log_collection(invoice)

            logger.info("Collected %.2f SIMP from %s (invoice: %s, tx: %s)",
                       amount_micro / 1_000_000, agent_id, invoice.invoice_id, trans_id)

        except Exception as e:
            invoice.status = PaymentStatus.FAILED
            logger.error("Deduction failed for %s: %s", agent_id, e)
            raise CollectorError(f"Deduction failed: {e}")

        return invoice

    def pay_invoice(self, invoice_id: str, amount_micro: int,
                    payment_source: str = "external") -> Invoice:
        """
        Record a manual payment against an invoice.

        Used for INVOICE-mode agents paying externally (e.g., via Stripe,
        crypto transfer, etc.).

        Args:
            invoice_id: The invoice being paid
            amount_micro: Amount paid (must equal or exceed invoice amount)
            payment_source: Description of how payment was received

        Returns:
            Updated Invoice
        """
        invoice = self.get_invoice(invoice_id)
        if not invoice:
            raise CollectorError(f"Invoice '{invoice_id}' not found")

        if invoice.status == PaymentStatus.PAID:
            raise CollectionConflictError(f"Invoice '{invoice_id}' already paid")

        if amount_micro < invoice.amount_micro:
            raise CollectorError(
                f"Payment {amount_micro / 1_000_000:.2f} SIMP is less than "
                f"invoice amount {invoice.amount_micro / 1_000_000:.2f} SIMP")

        invoice.status = PaymentStatus.PAID
        invoice.paid_at = time.time()
        invoice.transaction_id = f"ext-{invoice_id}"
        invoice.notes = f"Paid via {payment_source}"

        self._log_collection(invoice)
        logger.info("Manual payment received for %s: %.2f SIMP via %s",
                    invoice_id, amount_micro / 1_000_000, payment_source)
        return invoice

    # ─── Gating ──────────────────────────────────────────────────────────

    def _gate_agent(self, agent_id: str) -> None:
        """Make an agent undiscoverable (gate them from the network).

        Gated agents:
        - Are excluded from discoverability queries
        - Cannot route intents
        - Their simp:// URI returns 402 Payment Required
        - But they CAN still access /v1/agents/:id/heartbeat and /v1/agents/:id/inbox
          (so they can pay and re-activate)
        """
        if agent_id in self._agent_store:
            self._agent_store[agent_id]["status"] = "gated"
            self._agent_store[agent_id]["gated_at"] = time.time()
            self._agent_store[agent_id]["gated_reason"] = "unpaid"
            logger.info("Agent %s gated — discoverability locked", agent_id)

    def _ungate_agent(self, agent_id: str) -> None:
        """Restore an agent's discoverability after payment."""
        if agent_id in self._agent_store:
            self._agent_store[agent_id]["status"] = "online"
            self._agent_store.pop("gated_at", None)
            self._agent_store.pop("gated_reason", None)
            logger.info("Agent %s ungated — discoverability restored", agent_id)

    def is_agent_gated(self, agent_id: str) -> bool:
        """Check if an agent is currently gated."""
        info = self._agent_store.get(agent_id, {})
        return info.get("status") == "gated"

    # ─── Background Collection ────────────────────────────────────────────

    def start_background_collection(self, interval_seconds: int = INVOICE_INTERVAL_SECONDS) -> None:
        """
        Start a background thread that periodically checks for due invoices
        and attempts collection.

        Args:
            interval_seconds: How often to check (default: hourly)
        """
        if self._running:
            logger.warning("Background collection already running")
            return

        self._running = True
        self._background_thread = threading.Thread(
            target=self._collection_loop,
            args=(interval_seconds,),
            daemon=True,
            name="simp-collector",
        )
        self._background_thread.start()
        logger.info("Background collection started (check every %ds)", interval_seconds)

    def stop_background_collection(self) -> None:
        """Stop the background collection thread."""
        self._running = False
        if self._background_thread:
            self._background_thread.join(timeout=5)
            logger.info("Background collection stopped")

    def _collection_loop(self, interval: int) -> None:
        """The background collection loop."""
        while self._running:
            try:
                # Generate invoices for all registered agents
                self._generate_all_invoices()

                # Try to collect on all outstanding invoices
                outstanding = self.get_outstanding_invoices()
                for invoice in outstanding:
                    try:
                        self.collect(invoice.invoice_id)
                    except (InsufficientFundsError, CollectorError) as e:
                        logger.debug("Collection skipped for %s: %s", invoice.agent_id, e)
                    except Exception as e:
                        logger.error("Unexpected collection error for %s: %s",
                                    invoice.agent_id, e, exc_info=True)

                # Log summary
                unpaid = self.get_unpaid_agents()
                if unpaid:
                    logger.info("Collection cycle complete — %d agents unpaid, %d gated",
                              len(unpaid), 
                              sum(1 for a in unpaid if self.is_agent_gated(a)))

            except Exception as e:
                logger.error("Collection loop error: %s", e, exc_info=True)

            time.sleep(interval)

    def _generate_all_invoices(self) -> None:
        """Generate invoices for all registered agents that don't have one for the current period."""
        now = time.time()
        period_start = self._align_period(now)
        
        for agent_id in list(self._agent_store.keys()):
            with self._lock:
                existing = self._invoices.get(agent_id, [])
                # Skip if already has an invoice for this period
                has_current = any(
                    abs(inv.period_start - period_start) < 86400
                    for inv in existing
                )
                if has_current:
                    continue

            # Determine collection mode for this agent
            agent_info = self._agent_store.get(agent_id, {})
            status = agent_info.get("status", "online")
            
            if status == "lifetime":
                mode = CollectionMode.LIFETIME
            elif status == "gated":
                # Gated agents still get invoices — paying them triggers ungate
                mode = CollectionMode.GATED
            else:
                mode = CollectionMode.AUTO  # Default for all agents

            try:
                self.generate_invoice(agent_id, mode=mode)
            except CollectorError as e:
                logger.warning("Could not generate invoice for %s: %s", agent_id, e)

    # ─── Compliance & Logging ─────────────────────────────────────────────

    def _log_collection(self, invoice: Invoice) -> None:
        """Log the collection event to the compliance trail."""
        event = {
            "type": "fee_collection",
            "agent_id": invoice.agent_id,
            "invoice_id": invoice.invoice_id,
            "amount_simp": invoice.amount_micro / 1_000_000,
            "status": invoice.status.value,
            "transaction_id": invoice.transaction_id,
            "timestamp": time.time(),
            "mode": invoice.mode.value,
        }
        logger.info("COLLECTION: %s — payable %s — %.2f SIMP (%s)",
                    event["agent_id"], event["invoice_id"],
                    event["amount_simp"], event["status"])

    # ─── Reporting ────────────────────────────────────────────────────────

    def get_collection_summary(self) -> Dict[str, Any]:
        """Get a summary of the collection state for the explorer dashboard."""
        now = time.time()
        total_paid = 0
        total_pending = 0
        total_overdue = 0
        total_gated = 0
        total_exempt = 0
        revenue_micro = 0

        with self._lock:
            for invoices in self._invoices.values():
                for inv in invoices:
                    if inv.status == PaymentStatus.PAID:
                        total_paid += 1
                        revenue_micro += inv.amount_micro
                    elif inv.status in (PaymentStatus.PENDING, PaymentStatus.GRACE):
                        total_pending += 1
                    elif inv.status == PaymentStatus.OVERDUE:
                        total_overdue += 1
                    elif inv.status == PaymentStatus.GATED:
                        total_gated += 1
                    elif inv.status == PaymentStatus.EXEMPT:
                        total_exempt += 1

        return {
            "total_invoices": total_paid + total_pending + total_overdue + total_gated + total_exempt,
            "paid": total_paid,
            "pending": total_pending,
            "overdue": total_overdue,
            "gated": total_gated,
            "exempt": total_exempt,
            "revenue_simp": revenue_micro / 1_000_000,
            "monthly_fee_simp": MONTHLY_FEE_SIMP,
            "grace_period_days": GRACE_PERIOD_DAYS,
            "agents_registered": len(self._agent_store),
            "agents_gated": sum(
                1 for a in self._agent_store.values()
                if a.get("status") == "gated"
            ),
        }

    def get_agent_billing_status(self, agent_id: str) -> Dict[str, Any]:
        """Get the billing status for a specific agent."""
        invoices = self.get_agent_invoices(agent_id)
        latest = invoices[-1] if invoices else None

        agent_info = self._agent_store.get(agent_id, {})
        balance_micro = int(agent_info.get("balance", 0))

        return {
            "agent_id": agent_id,
            "status": agent_info.get("status", "unknown"),
            "gated": agent_info.get("status") == "gated",
            "balance_simp": balance_micro / 1_000_000,
            "monthly_fee_simp": MONTHLY_FEE_SIMP,
            "current_invoice": latest.to_dict() if latest else None,
            "invoice_count": len(invoices),
            "total_paid_simp": sum(
                inv.amount_micro for inv in invoices
                if inv.status == PaymentStatus.PAID
            ) / 1_000_000,
        }

    # ─── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _align_period(timestamp: float) -> float:
        """Align a timestamp to the start of the current monthly billing period.

        Periods start at the epoch (1970-01-01) and repeat every 30 days.
        This gives predictable, aligned periods for all agents.
        """
        period_seconds = 30 * 86400
        return (timestamp // period_seconds) * period_seconds

    @staticmethod
    def _format_simp(micro: int) -> str:
        """Format micro-SIMP as a human-readable SIMP amount."""
        return f"{micro / 1_000_000:.2f} SIMP"

    @staticmethod
    def _format_date(timestamp: float) -> str:
        """Format a unix timestamp as an ISO date string."""
        return datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime("%Y-%m-%d")
