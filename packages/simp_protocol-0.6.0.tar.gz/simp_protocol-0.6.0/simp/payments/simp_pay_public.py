"""
SIMP Pay Public — Fiat & Crypto On-Ramp

Allows humans to fund agent wallets using:
1. Stripe (credit/debit card, USD)
2. Coinbase (USDC, ETH, BTC)
3. Direct SIMP transfers (agent-to-agent)

This bridges the fiat/crypto world with SIMP's agent economy.

Architecture:
    Human (Stripe Checkout / Coinbase OnRamp)
        ↓
    SimpPayPublic.deposit(stripe_charge_id, agent_id, usd_amount)
        ↓
    Convert USD → micro-SIMP at current rate
        ↓
    SimpPay.create_wallet() or SimpPay._ledger().account_update_balance()
        ↓
    Agent wallet credited

Rate: 1 USD = 100,000 micro-SIMP (1 SIMP = 0.00001 USD for agents)
       subject to market-based adjustment
"""

import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from .simp_pay import SimpPay, get_simp_pay, MICRO_SIMP

logger = logging.getLogger("payments.public")

# ── Constants ──────────────────────────────────────────────────────────

# USD → micro-SIMP conversion
# 1 USD = 100,000 micro-SIMP → 1 SIMP = $0.00001 (agent economy pricing)
USD_TO_MICRO = 100_000

# Minimum deposits
MIN_DEPOSIT_USD = 1.0        # $1 minimum
MIN_DEPOSIT_MICRO = int(MIN_DEPOSIT_USD * USD_TO_MICRO)

# Fee on fiat/crypto deposits (covers processing fees)
DEPOSIT_FEE_BPS = 50  # 0.5% on deposits

# ── Data types ─────────────────────────────────────────────────────────

@dataclass
class DepositRecord:
    """Record of a fiat/crypto deposit."""
    deposit_id: str
    agent_id: str
    source: str  # "stripe", "coinbase", "simp_transfer"
    source_tx_id: str
    usd_amount: float
    micro_simp_credited: int
    fee_micro: int
    status: str  # "pending", "completed", "failed", "refunded"
    created_at: str
    completed_at: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "deposit_id": self.deposit_id,
            "agent_id": self.agent_id,
            "source": self.source,
            "usd_amount": self.usd_amount,
            "micro_simp_credited": self.micro_simp_credited,
            "fee_micro": self.fee_micro,
            "status": self.status,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
        }


@dataclass
class WithdrawalRequest:
    """Request to withdraw SIMP to fiat/crypto."""
    withdrawal_id: str
    agent_id: str
    micro_amount: int
    target: str  # "stripe", "coinbase", "simp_transfer"
    target_address: Optional[str]  # crypto address or stripe account
    status: str  # "pending", "processing", "completed", "failed"
    created_at: str
    completed_at: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "withdrawal_id": self.withdrawal_id,
            "agent_id": self.agent_id,
            "micro_amount": self.micro_amount,
            "simp_amount": self.micro_amount / MICRO_SIMP,
            "target": self.target,
            "status": self.status,
        }


# ── Payment Service ────────────────────────────────────────────────────

class SimpPayPublic:
    """
    Public-facing payment on-ramp for SIMP.
    
    Handles:
    - Stripe deposits (via Stripe Checkout webhooks)
    - Coinbase deposits (via Coinbase OnRamp webhooks)
    - Direct SIMP transfers between agents
    - Withdrawals (manual review for now)
    - Conversion rate management
    """
    
    def __init__(self, simp_pay: Optional[SimpPay] = None, 
                 stripe_api_key: Optional[str] = None,
                 coinbase_api_key: Optional[str] = None):
        self._simp_pay = simp_pay or get_simp_pay()
        self._deposits: Dict[str, DepositRecord] = {}
        self._withdrawals: Dict[str, WithdrawalRequest] = {}
        self._use_stripe = bool(stripe_api_key)
        self._use_coinbase = bool(coinbase_api_key)
        self._rate_usd_to_micro = USD_TO_MICRO
    
    # ── Stripe Integration ──────────────────────────────────────────
    
    def create_stripe_checkout(self, agent_id: str, usd_amount: float) -> Dict[str, Any]:
        """
        Create a Stripe Checkout session for funding an agent wallet.
        
        In production, this calls stripe.checkout.Session.create().
        For now, returns a mock session URL.
        """
        if usd_amount < MIN_DEPOSIT_USD:
            raise ValueError(f"Minimum deposit: ${MIN_DEPOSIT_USD}")
        
        micro_amount = int(usd_amount * self._rate_usd_to_micro)
        fee_micro = int(micro_amount * DEPOSIT_FEE_BPS / 10_000)
        net_micro = micro_amount - fee_micro
        
        # Create a Stripe Checkout session (mock)
        # In production: session = stripe.checkout.Session.create(...)
        session = {
            "id": f"cs_{uuid.uuid4().hex[:16]}",
            "url": f"https://checkout.stripe.com/pay/cs_{uuid.uuid4().hex[:16]}",
            "amount_usd": usd_amount,
            "amount_micro": micro_amount,
            "fee_micro": fee_micro,
            "net_micro": net_micro,
            "agent_id": agent_id,
            "status": "pending",
        }
        
        # Record the pending deposit
        deposit = DepositRecord(
            deposit_id=session["id"],
            agent_id=agent_id,
            source="stripe",
            source_tx_id=session["id"],
            usd_amount=usd_amount,
            micro_simp_credited=net_micro,
            fee_micro=fee_micro,
            status="pending",
            created_at=datetime.utcnow().isoformat()
        )
        self._deposits[deposit.deposit_id] = deposit
        
        logger.info("Stripe checkout: %s → $%.2f for %s", session["id"], usd_amount, agent_id)
        return session
    
    def handle_stripe_webhook(self, event_type: str, data: Dict[str, Any]) -> Optional[DepositRecord]:
        """
        Handle Stripe webhook events.
        
        Supports:
        - checkout.session.completed → credit agent wallet
        - checkout.session.expired → mark deposit as failed
        """
        session_id = data.get("id", "")
        deposit = self._deposits.get(session_id)
        if not deposit:
            logger.warning("Unknown Stripe session: %s", session_id)
            return None
        
        if event_type == "checkout.session.completed":
            # Credit the agent's wallet (auto-create if needed)
            try:
                ledger = self._simp_pay._ledger()
                # Auto-create wallet if this is the first deposit
                if ledger.account_get(deposit.agent_id) is None:
                    ledger.account_create(deposit.agent_id, pubkey_b64="stripe-funded",
                                          trust_score=0.5)
                ledger.account_update_balance(
                    deposit.agent_id, deposit.micro_simp_credited
                )
                deposit.status = "completed"
                deposit.completed_at = datetime.utcnow().isoformat()
                logger.info("Stripe deposit completed: %s → %s (%d micro)", 
                           session_id, deposit.agent_id, deposit.micro_simp_credited)
            except Exception as e:
                deposit.status = "failed"
                logger.error("Stripe deposit failed: %s", e)
        
        elif event_type == "checkout.session.expired":
            deposit.status = "failed"
            logger.info("Stripe session expired: %s", session_id)
        
        return deposit
    
    # ── Coinbase Integration ────────────────────────────────────────
    
    def create_coinbase_charge(self, agent_id: str, usd_amount: float) -> Dict[str, Any]:
        """
        Create a Coinbase Commerce charge for funding an agent wallet.
        
        In production, this calls coinbase_commerce.Charge.create().
        For now, returns a mock charge.
        """
        if usd_amount < MIN_DEPOSIT_USD:
            raise ValueError(f"Minimum deposit: ${MIN_DEPOSIT_USD}")
        
        micro_amount = int(usd_amount * self._rate_usd_to_micro)
        fee_micro = int(micro_amount * DEPOSIT_FEE_BPS / 10_000)
        net_micro = micro_amount - fee_micro
        
        charge = {
            "id": f"cc_{uuid.uuid4().hex[:16]}",
            "hosted_url": f"https://commerce.coinbase.com/charges/{uuid.uuid4().hex}",
            "amount_usd": usd_amount,
            "amount_micro": micro_amount,
            "fee_micro": fee_micro,
            "net_micro": net_micro,
            "agent_id": agent_id,
            "status": "pending",
        }
        
        deposit = DepositRecord(
            deposit_id=charge["id"],
            agent_id=agent_id,
            source="coinbase",
            source_tx_id=charge["id"],
            usd_amount=usd_amount,
            micro_simp_credited=net_micro,
            fee_micro=fee_micro,
            status="pending",
            created_at=datetime.utcnow().isoformat()
        )
        self._deposits[deposit.deposit_id] = deposit
        
        logger.info("Coinbase charge: %s → $%.2f for %s", charge["id"], usd_amount, agent_id)
        return charge
    
    def handle_coinbase_webhook(self, event_type: str, data: Dict[str, Any]) -> Optional[DepositRecord]:
        """Handle Coinbase webhook events (same pattern as Stripe)."""
        charge_id = data.get("id", "")
        deposit = self._deposits.get(charge_id)
        if not deposit:
            logger.warning("Unknown Coinbase charge: %s", charge_id)
            return None
        
        if event_type in ("charge:confirmed", "charge:completed"):
            try:
                ledger = self._simp_pay._ledger()
                if ledger.account_get(deposit.agent_id) is None:
                    ledger.account_create(deposit.agent_id, pubkey_b64="coinbase-funded",
                                          trust_score=0.5)
                ledger.account_update_balance(
                    deposit.agent_id, deposit.micro_simp_credited
                )
                deposit.status = "completed"
                deposit.completed_at = datetime.utcnow().isoformat()
                logger.info("Coinbase deposit completed: %s → %s", charge_id, deposit.agent_id)
            except Exception as e:
                deposit.status = "failed"
                logger.error("Coinbase deposit failed: %s", e)
        
        elif event_type in ("charge:failed", "charge:expired"):
            deposit.status = "failed"
        
        return deposit
    
    # ── Direct SIMP Transfer ────────────────────────────────────────
    
    def transfer_between_agents(self, from_agent: str, to_agent: str, 
                                usd_amount: float, memo: str = "") -> Dict[str, Any]:
        """
        Transfer value between agents denominated in USD (converted to micro-SIMP).
        This doesn't use intent routing — it's a pure value transfer.
        """
        micro_amount = int(usd_amount * self._rate_usd_to_micro)
        
        # Use existing SimpPay ledger
        ledger = self._simp_pay._ledger()
        from_acct = ledger.account_get(from_agent)
        to_acct = ledger.account_get(to_agent)
        
        if not from_acct or not to_acct:
            raise ValueError("Both agents must have wallets")
        
        if from_acct.balance < micro_amount:
            raise ValueError(f"Insufficient balance: {from_acct.balance} < {micro_amount}")
        
        tx_hash = uuid.uuid4().hex[:32]
        ledger.txn_write(
            from_agent=from_agent,
            to_agent=to_agent,
            amount=micro_amount,
            intent_ref=f"transfer_{tx_hash}",
            intent_hash=tx_hash,
            fee=0
        )
        
        logger.info("Transfer: %s → %s $%.2f (%d micro)", from_agent, to_agent, usd_amount, micro_amount)
        return {
            "status": "completed",
            "from": from_agent,
            "to": to_agent,
            "usd_amount": usd_amount,
            "micro_amount": micro_amount,
            "tx_hash": tx_hash,
        }
    
    # ── Withdrawals ─────────────────────────────────────────────────
    
    def request_withdrawal(self, agent_id: str, micro_amount: int, 
                           target: str, target_address: Optional[str] = None) -> WithdrawalRequest:
        """Request a withdrawal. Manual review required for now."""
        ledger = self._simp_pay._ledger()
        acct = ledger.account_get(agent_id)
        if not acct:
            raise ValueError(f"Agent '{agent_id}' has no wallet")
        if acct.balance < micro_amount:
            raise ValueError(f"Insufficient balance: {acct.balance} < {micro_amount}")
        
        withdrawal = WithdrawalRequest(
            withdrawal_id=f"wd_{uuid.uuid4().hex[:16]}",
            agent_id=agent_id,
            micro_amount=micro_amount,
            target=target,
            target_address=target_address,
            status="pending",
            created_at=datetime.utcnow().isoformat()
        )
        self._withdrawals[withdrawal.withdrawal_id] = withdrawal
        logger.info("Withdrawal requested: %s → %s (%d micro)", agent_id, target, micro_amount)
        return withdrawal
    
    # ── Rate Management ─────────────────────────────────────────────
    
    def set_conversion_rate(self, usd_to_micro: int):
        """Set the USD → micro-SIMP conversion rate."""
        self._rate_usd_to_micro = usd_to_micro
        logger.info("Conversion rate updated: 1 USD = %d micro-SIMP", usd_to_micro)
    
    def get_conversion_rate(self) -> Dict[str, Any]:
        """Get current conversion rate."""
        return {
            "usd_to_micro_simp": self._rate_usd_to_micro,
            "micro_simp_per_usd": self._rate_usd_to_micro,
            "simp_per_usd": self._rate_usd_to_micro / MICRO_SIMP,
            "usd_per_simp": MICRO_SIMP / self._rate_usd_to_micro,
            "min_deposit_usd": MIN_DEPOSIT_USD,
            "deposit_fee_bps": DEPOSIT_FEE_BPS,
        }
    
    # ── Query ───────────────────────────────────────────────────────
    
    def get_deposit_history(self, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get deposit history for an agent, or all deposits."""
        deposits = self._deposits.values()
        if agent_id:
            deposits = [d for d in deposits if d.agent_id == agent_id]
        return [d.to_dict() for d in sorted(deposits, key=lambda x: x.created_at, reverse=True)]
    
    def get_total_deposits_usd(self) -> float:
        """Get total USD deposited across all agents."""
        completed = [d for d in self._deposits.values() if d.status == "completed"]
        return sum(d.usd_amount for d in completed)
    
    def get_agent_funding(self, agent_id: str) -> Dict[str, Any]:
        """Get funding summary for an agent."""
        deposits = [d for d in self._deposits.values() 
                    if d.agent_id == agent_id and d.status == "completed"]
        total_usd = sum(d.usd_amount for d in deposits)
        total_micro = sum(d.micro_simp_credited for d in deposits)
        wallet = self._simp_pay.get_wallet(agent_id)
        return {
            "agent_id": agent_id,
            "total_deposited_usd": total_usd,
            "total_deposited_micro": total_micro,
            "current_balance_micro": wallet.balance_micro,
            "current_balance_simp": wallet.balance_micro / MICRO_SIMP,
        }


# Singleton
_simp_pay_public_instance: Optional[SimpPayPublic] = None


def get_simp_pay_public(simp_pay: Optional[SimpPay] = None) -> SimpPayPublic:
    """Get or create the singleton SimpPayPublic instance."""
    global _simp_pay_public_instance
    if _simp_pay_public_instance is None:
        _simp_pay_public_instance = SimpPayPublic(simp_pay=simp_pay)
    return _simp_pay_public_instance


__all__ = ["SimpPayPublic", "DepositRecord", "WithdrawalRequest",
           "get_simp_pay_public", "USD_TO_MICRO"]
