"""
SIMP Pay — The micropayment layer for Agentic HTTPS.

Every agent that registers gets a wallet. Every intent routed through SIMP
carries a micropayment. The $1/agent/month base fee funds the network.

Design
------
- Monetary values stored as integers in MICRO_SIMP (1 SIMP = 1,000,000 micro-SIMP)
- Three settlement modes: INSTANT, BATCH, CHANNEL
- Fee estimates based on intent complexity, agent trust score, and network load
- Idempotent payments via tx_hash deduplication
- Integration with the existing Ledger for persistence

Settlement Modes
----------------
INSTANT  : Deduct + credit atomically on intent delivery (default for trust >= 3.0)
BATCH    : Accumulate micro-fees, settle on cooldown or explicit flush
CHANNEL  : Off-chain balance channel for high-volume agent pairs (future)
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

# ─── Constants ────────────────────────────────────────────────────────────────

MICRO_SIMP = 1_000_000          # 1 SIMP = 1,000,000 micro-SIMP
STARTER_CREDIT = 1 * MICRO_SIMP # $1.00 starter credit
BASE_MONTHLY_FEE = 1 * MICRO_SIMP   # $1/agent/month
DEFAULT_PER_INTENT_BPS = 10     # 0.1% per intent (in basis points)
NETWORK_FEE_BPS = 1             # 0.01% network fee
MIN_FEE_MICRO = 1               # Minimum 1 micro-SIMP fee
DEFAULT_LEDGER_PATH = Path.home() / ".simp" / "tokens" / "ledger.db"

# ─── Enums ────────────────────────────────────────────────────────────────────


class SettlementMode(Enum):
    """How payments are settled between agents."""
    INSTANT = "instant"    # Per-intent, atomic
    BATCH = "batch"        # Accumulate, settle on flush
    CHANNEL = "channel"    # Off-chain balance channel (future)


class FeeTier(Enum):
    """Fee tier based on agent trust level."""
    TRUSTED = "trusted"        # Trust >= 4.0: 50% discount
    STANDARD = "standard"      # Trust >= 2.0: standard rate
    BASIC = "basic"            # Trust >= 0.5: 2x standard
    UNTRUSTED = "untrusted"    # Trust < 0.5: 5x standard (discouraged)


# ─── Dataclasses ──────────────────────────────────────────────────────────────


@dataclass
class IntentPayment:
    """Payment record for a single intent routing."""
    payment_id: str
    sender_agent_id: str
    receiver_agent_id: str
    intent_id: str
    amount_micro: int          # Total amount in micro-SIMP
    fee_micro: int             # SIMP network fee deducted
    sender_pay_micro: int      # Amount sender pays (amount + fee)
    receiver_credit_micro: int # Amount receiver gets (amount - fee_share)
    fee_share_bps: int         # Receiver's fee share in basis points
    settlement_mode: SettlementMode
    status: str                # "pending", "settled", "disputed", "refunded"
    tx_hash: str               # Unique transaction hash (idempotency key)
    created_at: str
    settled_at: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["settlement_mode"] = self.settlement_mode.value
        d["amount_simp"] = self.amount_micro / MICRO_SIMP
        d["fee_simp"] = self.fee_micro / MICRO_SIMP
        return d


@dataclass
class BalanceSnapshot:
    """Wallet balance snapshot."""
    agent_id: str
    balance_micro: int
    pending_in_micro: int      # Unsettled incoming payments
    pending_out_micro: int     # Unsettled outgoing payments
    escrowed_micro: int        # In escrow
    last_settled_at: str
    trust_score: float

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["balance_simp"] = self.balance_micro / MICRO_SIMP
        d["pending_in_simp"] = self.pending_in_micro / MICRO_SIMP
        d["pending_out_simp"] = self.pending_out_micro / MICRO_SIMP
        d["escrowed_simp"] = self.escrowed_micro / MICRO_SIMP
        return d


@dataclass
class PaymentSettlement:
    """Record of a batch or channel settlement."""
    settlement_id: str
    mode: SettlementMode
    payments: List[str]         # Payment IDs settled
    total_amount_micro: int
    total_fee_micro: int
    settled_at: str
    status: str                 # "completed", "pending", "failed"
    tx_chain: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(d)
        d["mode"] = self.mode.value
        d["total_amount_simp"] = self.total_amount_micro / MICRO_SIMP
        d["total_fee_simp"] = self.total_fee_micro / MICRO_SIMP
        return d


# ─── SimpPay — The payment engine ─────────────────────────────────────────────


class SimpPayError(Exception):
    """Base error for SIMP Pay operations."""
    pass


class InsufficientBalanceError(SimpPayError):
    """Sender has insufficient balance for the intent."""
    pass


class AgentNotRegisteredError(SimpPayError):
    """Agent has no wallet."""
    pass


class DuplicatePaymentError(SimpPayError):
    """Payment with same tx_hash already exists."""
    pass


class SimpPay:
    """
    SIMP Pay — micropayment engine for agent-to-agent transactions.

    Provides wallet management, fee estimation, intent payment, and settlement
    — all backed by the existing simplicial ledger.
    """

    def __init__(
        self,
        ledger_path: Path = DEFAULT_LEDGER_PATH,
        per_intent_bps: int = DEFAULT_PER_INTENT_BPS,
        network_fee_bps: int = NETWORK_FEE_BPS,
    ):
        self._ledger_path = ledger_path
        self._per_intent_bps = per_intent_bps
        self._network_fee_bps = network_fee_bps
        self._pending: Dict[str, IntentPayment] = {}
        self._settled: Dict[str, PaymentSettlement] = {}
        self._batch_queues: Dict[str, List[IntentPayment]] = {}  # agent_id -> pending batch
        self._ledger_instance = None
        logger.info(
            "SimpPay initialized (%.1f%% per-intent, %.2f%% network fee)",
            per_intent_bps / 100, network_fee_bps / 100,
        )

    # ── Ledger access ──────────────────────────────────────────────────────

    def _ledger(self):
        """Lazy-load the ledger singleton."""
        if self._ledger_instance is None:
            from simp.tokens.ledger import Ledger
            self._ledger_instance = Ledger(path=self._ledger_path)
        return self._ledger_instance

    # ── Wallet management ──────────────────────────────────────────────────

    def create_wallet(self, agent_id: str, public_key: str, initial_credit: int = STARTER_CREDIT, trust_score: float = 5.0) -> BalanceSnapshot:
        """
        Create a wallet for a new agent. Idempotent — returns existing wallet
        if one already exists.
        """
        ledger = self._ledger()
        account = ledger.account_get_or_create(agent_id, public_key, trust_score=trust_score)
        if account.balance == 0 and initial_credit > 0:
            ledger.account_update_balance(agent_id, initial_credit)
            logger.info("Created wallet for %s with %d micro-SIMP", agent_id, initial_credit)
            account = ledger.account_get(agent_id)
        return self.get_wallet(agent_id)

    def get_wallet(self, agent_id: str) -> BalanceSnapshot:
        """Get wallet balance and pending state for an agent."""
        ledger = self._ledger()
        account = ledger.account_get(agent_id)
        if account is None:
            raise AgentNotRegisteredError(f"Agent '{agent_id}' has no wallet")

        # Calculate pending amounts from in-flight payments
        pending_in = sum(
            p.receiver_credit_micro
            for p in self._pending.values()
            if p.receiver_agent_id == agent_id and p.status == "pending"
        )
        pending_out = sum(
            p.sender_pay_micro
            for p in self._pending.values()
            if p.sender_agent_id == agent_id and p.status == "pending"
        )

        # Escrowed amount from ledger
        escrowed = 0
        try:
            # Use ledger escrow API if available
            if hasattr(ledger, 'escrow_get_by_participant'):
                escrows = ledger.escrow_get_by_participant(agent_id)
                escrowed = sum(e.amount for e in escrows if e.state == 'LOCKED')
        except Exception:
            pass

        # Determine trust score
        trust_score = getattr(account, 'trust_score', 0.5)
        try:
            from simp.mesh.trust_scorer import score_for
            profile = score_for(agent_id)
            if profile and hasattr(profile, 'score'):
                trust_score = profile.score
        except Exception:
            pass

        now = datetime.now(timezone.utc).isoformat()
        return BalanceSnapshot(
            agent_id=agent_id,
            balance_micro=account.balance,
            pending_in_micro=pending_in,
            pending_out_micro=pending_out,
            escrowed_micro=escrowed,
            last_settled_at=now,
            trust_score=trust_score,
        )

    def get_balance_simp(self, agent_id: str) -> float:
        """Quick balance in SIMP units."""
        try:
            wallet = self.get_wallet(agent_id)
            return wallet.balance_micro / MICRO_SIMP
        except AgentNotRegisteredError:
            return 0.0

    def _safe_balance(self, agent_id: str) -> int:
        """Get balance without raising. Returns 0 if wallet doesn't exist."""
        try:
            return self.get_wallet(agent_id).balance_micro
        except (AgentNotRegisteredError, Exception):
            return 0

    # ── Fee estimation ─────────────────────────────────────────────────────

    def _fee_tier(self, trust_score: float) -> FeeTier:
        """Determine fee tier from trust score."""
        if trust_score >= 4.0:
            return FeeTier.TRUSTED
        elif trust_score >= 2.0:
            return FeeTier.STANDARD
        elif trust_score >= 0.5:
            return FeeTier.BASIC
        else:
            return FeeTier.UNTRUSTED

    def _tier_multiplier(self, tier: FeeTier) -> float:
        """Fee multiplier for a given tier."""
        multipliers = {
            FeeTier.TRUSTED: 0.5,
            FeeTier.STANDARD: 1.0,
            FeeTier.BASIC: 2.0,
            FeeTier.UNTRUSTED: 5.0,
        }
        return multipliers.get(tier, 1.0)

    def estimate_fee(
        self,
        sender_agent_id: str,
        receiver_agent_id: str,
        intent_value_micro: int = 0,
        trust_score: Optional[float] = None,
        mode: SettlementMode = SettlementMode.INSTANT,
    ) -> Dict[str, Any]:
        """
        Estimate the fee for routing an intent.

        Returns breakdown of costs in micro-SIMP and human-readable SIMP.
        """
        # Get sender trust score
        if trust_score is None:
            try:
                wallet = self.get_wallet(sender_agent_id)
                trust_score = wallet.trust_score
            except AgentNotRegisteredError:
                trust_score = 0.0

        tier = self._fee_tier(trust_score)
        multiplier = self._tier_multiplier(tier)

        # Base per-intent fee
        base_fee = self._per_intent_bps
        adjusted_fee_bps = int(base_fee * multiplier)
        fee_micro = max(
            MIN_FEE_MICRO,
            intent_value_micro * adjusted_fee_bps // 10000,
        )

        # Network fee
        network_fee_micro = max(
            MIN_FEE_MICRO,
            intent_value_micro * self._network_fee_bps // 10000,
        )

        total_fee_micro = fee_micro + network_fee_micro

        # Settlement mode surcharge
        mode_surcharge = {
            SettlementMode.INSTANT: 0,
            SettlementMode.BATCH: -fee_micro // 2,  # 50% discount for batching
            SettlementMode.CHANNEL: fee_micro * 3,   # Premium for off-chain
        }.get(mode, 0)

        total_fee_micro = max(MIN_FEE_MICRO, total_fee_micro + mode_surcharge)
        total_fee_simp = total_fee_micro / MICRO_SIMP

        return {
            "fee_micro": total_fee_micro,
            "fee_simp": round(total_fee_simp, 6),
            "fee_bps": adjusted_fee_bps,
            "network_fee_micro": network_fee_micro,
            "network_fee_simp": round(network_fee_micro / MICRO_SIMP, 6),
            "tier": tier.value,
            "multiplier": multiplier,
            "mode": mode.value,
            "sender_balance_micro": self._safe_balance(sender_agent_id),
        }

    # ── Payment execution ──────────────────────────────────────────────────

    def _make_tx_hash(
        self,
        sender: str,
        receiver: str,
        intent_id: str,
        amount: int,
    ) -> str:
        """Generate a deterministic transaction hash for idempotency.

        Hash = sha256(sender:receiver:intent_id:amount)[:32]
        No randomness or timestamps — repeated calls with the same parameters
        produce the same hash, allowing duplicate detection.
        """
        raw = f"{sender}:{receiver}:{intent_id}:{amount}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    def pay_intent(
        self,
        sender_agent_id: str,
        receiver_agent_id: str,
        intent_id: str,
        amount_micro: int = 0,
        fee_share_bps: int = 500,  # 5% to receiver default
        settlement_mode: SettlementMode = SettlementMode.INSTANT,
        trust_score: Optional[float] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> IntentPayment:
        """
        Pay for an intent routing. Deducts from sender's wallet, credits
        the network fee, and places the receiver's credit in pending.

        For INSTANT mode, settles immediately. For BATCH, queues for later.
        """
        if not sender_agent_id or not receiver_agent_id:
            raise ValueError("sender_agent_id and receiver_agent_id are required")

        # Check both agents have wallets
        try:
            sender_wallet = self.get_wallet(sender_agent_id)
        except AgentNotRegisteredError:
            raise AgentNotRegisteredError(f"Sender '{sender_agent_id}' not registered")

        try:
            receiver_wallet = self.get_wallet(receiver_agent_id)
        except AgentNotRegisteredError:
            raise AgentNotRegisteredError(f"Receiver '{receiver_agent_id}' not registered")

        # Calculate fees
        fee_estimate = self.estimate_fee(
            sender_agent_id, receiver_agent_id, amount_micro,
            trust_score=trust_score or sender_wallet.trust_score,
            mode=settlement_mode,
        )
        fee_micro = fee_estimate["fee_micro"]
        network_fee_micro = fee_estimate["network_fee_micro"]

        # Total sender pays = amount + network fee
        sender_pay_micro = amount_micro + fee_micro

        # Check sender balance
        effective_balance = sender_wallet.balance_micro - sender_wallet.pending_out_micro
        if effective_balance < sender_pay_micro:
            raise InsufficientBalanceError(
                f"Sender '{sender_agent_id}' needs {sender_pay_micro / MICRO_SIMP:.6f} SIMP "
                f"but has {effective_balance / MICRO_SIMP:.6f} available "
                f"(balance: {sender_wallet.balance_micro / MICRO_SIMP:.6f}, "
                f"pending: {sender_wallet.pending_out_micro / MICRO_SIMP:.6f})"
            )

        # Generate payment record with deterministic hash for idempotency
        # hash = sha256(sender:receiver:intent_id:amount) — no timestamp/randomness
        tx_hash = self._make_tx_hash(
            sender_agent_id, receiver_agent_id, intent_id, amount_micro,
        )

        # Check for duplicate
        if tx_hash in {p.tx_hash for p in self._pending.values()}:
            raise DuplicatePaymentError(f"Duplicate payment tx_hash: {tx_hash}")

        now = datetime.now(timezone.utc).isoformat()
        payment = IntentPayment(
            payment_id=f"pay-{uuid.uuid4().hex[:12]}",
            sender_agent_id=sender_agent_id,
            receiver_agent_id=receiver_agent_id,
            intent_id=intent_id,
            amount_micro=amount_micro,
            fee_micro=fee_micro,
            sender_pay_micro=sender_pay_micro,
            receiver_credit_micro=amount_micro,
            fee_share_bps=fee_share_bps,
            settlement_mode=settlement_mode,
            status="pending",
            tx_hash=tx_hash,
            created_at=now,
            metadata=metadata or {},
        )

        if settlement_mode == SettlementMode.INSTANT:
            # Deduct immediately
            self._pending[payment.payment_id] = payment
            self._settle_instant(payment)
        elif settlement_mode == SettlementMode.BATCH:
            # Queue for batch settlement
            self._batch_queues.setdefault(receiver_agent_id, []).append(payment)
            self._pending[payment.payment_id] = payment
            logger.info(
                "Queued batch payment %s: %s -> %s (%d micro-SIMP)",
                payment.payment_id, sender_agent_id, receiver_agent_id, sender_pay_micro,
            )
        else:
            # CHANNEL — mark pending for now
            self._pending[payment.payment_id] = payment
            logger.info(
                "Channel payment %s: %s -> %s (%d micro-SIMP) [pending]",
                payment.payment_id, sender_agent_id, receiver_agent_id, sender_pay_micro,
            )

        return payment

    def _settle_instant(self, payment: IntentPayment) -> None:
        """Atomic INSTANT settlement: deduct sender, credit receiver.

        Uses txn_write for ALL balance mutations — it handles both deduction
        from sender and credit to receiver atomically.
        """
        ledger = self._ledger()
        now_dt = datetime.now(timezone.utc).isoformat()

        try:
            # txn_write handles: from_agent pays (amount + fee), to_agent gets amount
            # So amount here should be the net credit to receiver (amount_micro),
            # with fee_micro as the network fee deduction from sender
            ledger.txn_write(
                from_agent=payment.sender_agent_id,
                to_agent=payment.receiver_agent_id,
                amount=payment.amount_micro,
                intent_ref=payment.intent_id,
                fee=payment.fee_micro,
            )
        except Exception as e:
            logger.error("Ledger txn_write failed for %s: %s", payment.payment_id, e)
            raise

        payment.status = "settled"
        payment.settled_at = now_dt
        logger.info(
            "INSTANT settlement %s: %s -> %s | %d micro-SIMP (fee: %d)",
            payment.payment_id,
            payment.sender_agent_id,
            payment.receiver_agent_id,
            payment.sender_pay_micro,
            payment.fee_micro,
        )

    def settle_batch(self, receiver_agent_id: str) -> Optional[PaymentSettlement]:
        """
        Settle all queued batched payments for a receiver agent.
        Deducts from each sender and credits the receiver in one batch.
        """
        payments = self._batch_queues.pop(receiver_agent_id, [])
        if not payments:
            return None

        ledger = self._ledger()
        total_amount = 0
        total_fee = 0
        payment_ids = []

        for payment in payments:
            try:
                # txn_write handles both sender deduction and receiver credit atomically
                # amount = net credit to receiver, fee = network fee deducted from sender
                ledger.txn_write(
                    from_agent=payment.sender_agent_id,
                    to_agent=payment.receiver_agent_id,
                    amount=payment.amount_micro,
                    intent_ref=payment.intent_id,
                    fee=payment.fee_micro,
                )
                total_amount += payment.amount_micro
                total_fee += payment.fee_micro
                payment.status = "settled"
                payment.settled_at = datetime.now(timezone.utc).isoformat()
                payment_ids.append(payment.payment_id)
            except Exception as e:
                logger.error("Batch settle failed for %s: %s", payment.payment_id, e)

        # No separate receiver credit needed — txn_write already credits

        settlement = PaymentSettlement(
            settlement_id=f"stl-{uuid.uuid4().hex[:12]}",
            mode=SettlementMode.BATCH,
            payments=payment_ids,
            total_amount_micro=total_amount,
            total_fee_micro=total_fee,
            settled_at=datetime.now(timezone.utc).isoformat(),
            status="completed",
        )
        self._settled[settlement.settlement_id] = settlement

        logger.info(
            "BATCH settlement %s: %d payments for %s | %d micro-SIMP (fee: %d)",
            settlement.settlement_id, len(payment_ids), receiver_agent_id,
            total_amount, total_fee,
        )
        return settlement

    def settle_payment(
        self,
        payment_id: str,
        success: bool = True,
    ) -> Optional[IntentPayment]:
        """
        Settle (or refund) a pending payment. Called on intent delivery receipt.
        For INSTANT this is a no-op (already settled). For BATCH/CHANNEL,
        triggers settlement.
        """
        payment = self._pending.get(payment_id)
        if not payment:
            return None

        if payment.settlement_mode == SettlementMode.INSTANT:
            # Already settled atomically
            payment.status = "settled" if success else "refunded"
            return payment

        if success:
            if payment.settlement_mode == SettlementMode.BATCH:
                # Handled by settle_batch()
                pass
            elif payment.settlement_mode == SettlementMode.CHANNEL:
                # Settle now
                self._settle_instant(payment)
        else:
            # Refund: just remove from pending, no deduction happened yet
            payment.status = "refunded"
            logger.info("Refunded payment %s (%s)", payment_id, payment.sender_agent_id)

        return payment

    # ── Monthly fee ─────────────────────────────────────────────────────────

    def collect_monthly_fee(self, agent_id: str) -> Dict[str, Any]:
        """
        Collect the $1/month base fee from an agent's wallet.
        Called by a cron-like process on registration anniversary.
        """
        ledger = self._ledger()
        account = ledger.account_get(agent_id)
        if account is None:
            raise AgentNotRegisteredError(f"Agent '{agent_id}' has no wallet")

        if account.balance < BASE_MONTHLY_FEE:
            # Agent has insufficient funds — mark for grace period
            return {
                "collected": False,
                "agent_id": agent_id,
                "reason": "insufficient_balance",
                "balance_micro": account.balance,
                "required_micro": BASE_MONTHLY_FEE,
            }

        ledger.account_update_balance(agent_id, -BASE_MONTHLY_FEE)
        logger.info("Collected monthly fee of %d micro-SIMP from %s", BASE_MONTHLY_FEE, agent_id)
        return {
            "collected": True,
            "agent_id": agent_id,
            "amount_micro": BASE_MONTHLY_FEE,
            "amount_simp": BASE_MONTHLY_FEE / MICRO_SIMP,
            "remaining_micro": account.balance - BASE_MONTHLY_FEE,
        }

    # ── Payment history ─────────────────────────────────────────────────────

    def get_payment_history(
        self,
        agent_id: str,
        limit: int = 50,
        status: Optional[str] = None,
    ) -> List[IntentPayment]:
        """Get payment history for an agent from in-memory store + ledger."""
        results = []
        for p in list(self._pending.values()) + list(self._settled_payments()):
            if p.sender_agent_id == agent_id or p.receiver_agent_id == agent_id:
                if status is None or p.status == status:
                    results.append(p)
        # Sort by created_at descending
        results.sort(key=lambda p: p.created_at, reverse=True)
        return results[:limit]

    def _settled_payments(self):
        """Yield payments from settled records."""
        for s in self._settled.values():
            for pid in s.payments:
                p = self._pending.get(pid)
                if p and p.status == "settled":
                    yield p

    def get_pending_settlements(self, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get all pending (unsettled) payments, optionally filtered by agent."""
        results = []
        for p in self._pending.values():
            if p.status == "pending":
                if agent_id is None or p.sender_agent_id == agent_id or p.receiver_agent_id == agent_id:
                    results.append(p.to_dict())
        return results

    def get_revenue_stats(self) -> Dict[str, Any]:
        """
        Get aggregate revenue statistics for the SIMP network.
        Total fees collected, agents paying, average per agent, etc.
        """
        total_fees = 0
        total_intents = 0
        agents_seen = set()

        for p in list(self._pending.values()):
            if p.status == "settled":
                total_fees += p.fee_micro
                total_intents += 1
                agents_seen.add(p.sender_agent_id)

        # Add settled batch payments
        for s in self._settled.values():
            total_fees += s.total_fee_micro
            total_intents += len(s.payments)

        return {
            "total_fees_micro": total_fees,
            "total_fees_simp": round(total_fees / MICRO_SIMP, 6),
            "total_intents_routed": total_intents,
            "unique_agents": len(agents_seen),
            "avg_fee_per_intent_micro": total_fees // max(total_intents, 1),
            "avg_fee_per_intent_simp": round(total_fees / max(total_intents, 1) / MICRO_SIMP, 8),
        }

    # ── Dispute handling ──────────────────────────────────────────────────

    def dispute_payment(self, payment_id: str, reason: str) -> IntentPayment:
        """
        Mark a payment as disputed. Freezes the amount in escrow.
        Requires external dispute resolution to resolve.
        """
        payment = self._pending.get(payment_id)
        if not payment:
            # Check settled payments too
            for p in self._pending.values():
                if p.payment_id == payment_id:
                    payment = p
                    break
        if not payment:
            raise ValueError(f"Payment not found: {payment_id}")

        if payment.status != "settled" and payment.status != "pending":
            raise ValueError(f"Cannot dispute payment in status '{payment.status}'")

        payment.status = "disputed"
        logger.warning(
            "Payment disputed: %s | %s -> %s | reason: %s",
            payment_id, payment.sender_agent_id, payment.receiver_agent_id, reason,
        )
        return payment

    def resolve_dispute(
        self,
        payment_id: str,
        resolution: str,  # "refund_sender", "release_to_receiver", "split"
        split_ratio: float = 0.5,
    ) -> IntentPayment:
        """
        Resolve a disputed payment. Can refund sender, release to receiver,
        or split between them.
        """
        payment = self._pending.get(payment_id)
        if not payment:
            raise ValueError(f"Payment not found: {payment_id}")

        if payment.status != "disputed":
            raise ValueError(f"Payment '{payment_id}' is not in disputed status")

        ledger = self._ledger()

        if resolution == "refund_sender":
            ledger.account_update_balance(payment.sender_agent_id, payment.sender_pay_micro)
            payment.status = "refunded"
        elif resolution == "release_to_receiver":
            ledger.account_update_balance(payment.receiver_agent_id, payment.receiver_credit_micro)
            payment.status = "settled"
        elif resolution == "split":
            sender_refund = int(payment.sender_pay_micro * split_ratio)
            receiver_credit = payment.sender_pay_micro - sender_refund
            ledger.account_update_balance(payment.sender_agent_id, sender_refund)
            ledger.account_update_balance(payment.receiver_agent_id, receiver_credit)
            payment.status = "settled"
        else:
            raise ValueError(f"Unknown resolution: {resolution}")

        logger.info(
            "Dispute resolved: %s | resolution=%s | %s",
            payment_id, resolution, payment.status,
        )
        return payment


# ─── Module-level convenience ─────────────────────────────────────────────────

_simp_pay_instance: Optional[SimpPay] = None


def get_simp_pay(
    ledger_path: Path = DEFAULT_LEDGER_PATH,
    per_intent_bps: int = DEFAULT_PER_INTENT_BPS,
    network_fee_bps: int = NETWORK_FEE_BPS,
) -> SimpPay:
    """Get or create the SimpPay singleton."""
    global _simp_pay_instance
    if _simp_pay_instance is None:
        _simp_pay_instance = SimpPay(
            ledger_path=ledger_path,
            per_intent_bps=per_intent_bps,
            network_fee_bps=network_fee_bps,
        )
    return _simp_pay_instance
