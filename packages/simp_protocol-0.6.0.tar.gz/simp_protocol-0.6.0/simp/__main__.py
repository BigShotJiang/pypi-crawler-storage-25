"""
SIMP Protocol — CLI Entry Point

Usage:
    python -m simp start                  Start the broker
    python -m simp start --watchdog       Start with watchdog supervision
    python -m simp status                 Broker status (from heartbeat)
    python -m simp reload                 Hot-reload configuration
    python -m simp upgrade <binary>       Stage a binary upgrade
"""

import os
import sys
import json
import time
import signal
import logging

logger = logging.getLogger("simp.cli")


def cmd_start(args):
    """Start the SIMP broker with optional watchdog supervision."""
    if args.watchdog:
        # Launch the watchdog parent process
        from simp.broker.supervisor import run_watchdog
        run_watchdog()
    else:
        # Start broker directly — strip our subcommand from argv first
        import sys as _sys
        _sys.argv = [a for a in _sys.argv if a != "start"]
        from simp.server.http_server import main as _http_main
        _http_main()


def cmd_status(args):
    """Check broker status from heartbeat file."""
    heartbeat_path = os.environ.get("SIMP_SUPERVISOR_HEARTBEAT", "/tmp/simp_heartbeat")
    try:
        data = json.loads(open(heartbeat_path).read())
        uptime = time.time() - data["timestamp"]
        print(f"SIMP Broker — PID {data['pid']}")
        print(f"  Status:    {data['status']}")
        print(f"  Memory:    {data['memory_mb']} MB")
        print(f"  Uptime:    {uptime:.0f}s ago")
        # Quick HTTP health check
        try:
            import urllib.request
            resp = urllib.request.urlopen("http://127.0.0.1:5555/health", timeout=5)
            health = json.loads(resp.read())
            print(f"  Health:    {health.get('status', 'unknown')}")
        except Exception as e:
            print(f"  Health:    unreachable ({e})")
    except FileNotFoundError:
        print("SIMP Broker is not running (no heartbeat file)")
        sys.exit(1)


def cmd_reload(args):
    """Trigger a hot-reload via the admin endpoint."""
    try:
        import urllib.request
        req = urllib.request.Request(
            "http://127.0.0.1:5555/admin/reload-config",
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        resp = urllib.request.urlopen(req, timeout=10)
        result = json.loads(resp.read())
        print(f"Reload {'succeeded' if result.get('success') else 'failed'}:")
        for action in result.get("actions", []):
            print(f"  ✅ {action}")
        for error in result.get("errors", []):
            print(f"  ❌ {error}")
    except Exception as e:
        print(f"Reload failed: {e}")
        sys.exit(1)


def cmd_upgrade(args):
    """Stage a binary upgrade and signal restart."""
    path = args.binary
    if not path or not os.path.exists(path):
        print(f"Binary not found: {path}")
        sys.exit(1)

    os.environ["SIMP_SUPERVISOR_UPGRADE_PATH"] = os.path.abspath(path)
    print(f"Upgrade staged: {os.path.abspath(path)}")
    print("Signaling broker to restart...")
    os.kill(os.getpid(), signal.SIGTERM)


def main():
    """Main CLI dispatcher."""
    import argparse

    parser = argparse.ArgumentParser(
        description="SIMP Protocol — Standardized Intent Messaging Protocol"
    )
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Start
    start_parser = subparsers.add_parser("start", help="Start the SIMP broker")
    start_parser.add_argument("--watchdog", action="store_true",
                              help="Run under watchdog supervision (auto-restart on crash)")
    start_parser.add_argument("--host", default="127.0.0.1")
    start_parser.add_argument("--port", type=int, default=5555)

    # Status
    subparsers.add_parser("status", help="Check broker status")

    # Reload
    subparsers.add_parser("reload", help="Hot-reload broker configuration")

    # Upgrade
    upgrade_parser = subparsers.add_parser("upgrade", help="Stage a binary upgrade")
    upgrade_parser.add_argument("binary", help="Path to the new broker binary")

    args = parser.parse_args()

    if args.debug:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

    if args.command == "start":
        cmd_start(args)
    elif args.command == "status":
        cmd_status(args)
    elif args.command == "reload":
        cmd_reload(args)
    elif args.command == "upgrade":
        cmd_upgrade(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
