"""
Mesh Topology API — L3-T29

Exposes a REST API for querying mesh topology.
Returns JSON graph of active brokers, agents, and their connections.

Built on top of: PartitionDetector, RoutingTable, CapabilityRegistry, Discovery
"""

import logging
import time
from threading import RLock
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class MeshTopologyService:
    """
    Builds a graph representation of the mesh topology.
    Aggregates data from discovery, routing, and capability systems.
    """

    def __init__(self, local_agent_id: str):
        self.local_agent_id = local_agent_id
        self._lock = RLock()

        # External references (set after construction)
        self._discovery = None
        self._routing_table = None
        self._capability_registry = None
        self._gossip = None
        self._partition_detector = None
        self._health_consensus = None

        self._snapshot_count = 0

    def set_discovery(self, discovery: Any) -> None:
        self._discovery = discovery

    def set_routing_table(self, rt: Any) -> None:
        self._routing_table = rt

    def set_capability_registry(self, reg: Any) -> None:
        self._capability_registry = reg

    def set_gossip(self, gossip: Any) -> None:
        self._gossip = gossip

    def set_partition_detector(self, pd: Any) -> None:
        self._partition_detector = pd

    def set_health_consensus(self, hc: Any) -> None:
        self._health_consensus = hc

    def get_topology(self) -> dict:
        """
        Build a full topology graph of the mesh.

        Returns:
        {
            "nodes": [{"id": "...", "type": "agent|broker", ...}],
            "edges": [{"source": "...", "target": "...", "weight": ...}],
            "statistics": {...}
        }
        """
        with self._lock:
            self._snapshot_count += 1
            nodes: List[dict] = []
            edges: List[dict] = []
            node_ids: set = set()

            # Add ourselves
            nodes.append({
                "id": self.local_agent_id,
                "type": "broker",
                "status": "online",
                "is_local": True,
                "capabilities": [],
                "peer_count": 0,
            })
            node_ids.add(self.local_agent_id)

            # Add peers from gossip
            if self._gossip:
                for peer_id in self._gossip.get_peers():
                    if peer_id not in node_ids:
                        caps = self._gossip.get_capabilities(peer_id)
                        nodes.append({
                            "id": peer_id,
                            "type": "agent",
                            "status": "online",
                            "is_local": False,
                            "capabilities": caps,
                            "peer_count": 0,
                        })
                        node_ids.add(peer_id)
                    edges.append({
                        "source": self.local_agent_id,
                        "target": peer_id,
                        "weight": 1.0,
                        "protocol": "gossip",
                    })

            # Add agents from capability registry
            if self._capability_registry:
                for agent_id in self._capability_registry.list_agents():
                    if agent_id not in node_ids:
                        caps = [
                            e.capability
                            for e in self._capability_registry.get_agent_capabilities(agent_id)
                        ]
                        nodes.append({
                            "id": agent_id,
                            "type": "agent",
                            "status": "online",
                            "is_local": False,
                            "capabilities": caps,
                            "peer_count": 0,
                        })
                        node_ids.add(agent_id)

            # Add agents from discovery
            if self._discovery:
                try:
                    for peer_id, peer_data in self._discovery.get_network_topology().get("peers", {}).items():
                        if peer_id not in node_ids:
                            nodes.append({
                                "id": peer_id,
                                "type": "agent",
                                "status": peer_data.get("status", "unknown"),
                                "is_local": False,
                                "capabilities": peer_data.get("capabilities", []),
                                "peer_count": 0,
                            })
                            node_ids.add(peer_id)
                except Exception:
                    pass

            # Add partitioning info
            partitioned_agents = set()
            if self._partition_detector:
                try:
                    status = self._partition_detector.get_status()
                    if status.get("current_partition"):
                        p_agents = status["current_partition"].get("partition_agents", [])
                        partitioned_agents = set(p_agents)
                        for node in nodes:
                            if node["id"] in partitioned_agents:
                                node["status"] = "partitioned"
                except Exception:
                    pass

            # Add health consensus info
            if self._health_consensus:
                try:
                    degraded = set(self._health_consensus.get_degraded_brokers())
                    for node in nodes:
                        if node["id"] in degraded:
                            node["status"] = "degraded"
                except Exception:
                    pass

            # Update peer counts
            for edge in edges:
                source_id = edge["source"]
                target_id = edge["target"]
                for node in nodes:
                    if node["id"] == source_id:
                        node["peer_count"] = node.get("peer_count", 0) + 1
                    if node["id"] == target_id:
                        node["peer_count"] = node.get("peer_count", 0) + 1

            # Build statistics
            stats = {
                "total_nodes": len(nodes),
                "total_edges": len(edges),
                "online_agents": sum(1 for n in nodes if n.get("status") == "online"),
                "partitioned_agents": len(partitioned_agents),
                "degraded_agents": sum(1 for n in nodes if n.get("status") == "degraded"),
                "snapshot_time": time.time(),
                "snapshot_count": self._snapshot_count,
            }

            # Add routing stats
            if self._routing_table:
                try:
                    stats["routing"] = self._routing_table.get_stats()
                except Exception:
                    pass

            return {
                "nodes": nodes,
                "edges": edges,
                "statistics": stats,
                "local_agent": self.local_agent_id,
            }

    def get_topology_summary(self) -> dict:
        """Lightweight topology summary (no full graph)."""
        topo = self.get_topology()
        return {
            "local_agent": topo["local_agent"],
            "total_nodes": topo["statistics"]["total_nodes"],
            "online": topo["statistics"]["online_agents"],
            "partitioned": topo["statistics"]["partitioned_agents"],
            "degraded": topo["statistics"]["degraded_agents"],
            "edges": topo["statistics"]["total_edges"],
        }


# ---------------------------------------------------------------------------
# L3-T22: Cooperative Transaction Commit (Two-Phase Commit)
# ---------------------------------------------------------------------------


import threading
import uuid


class TransactionPhase:
    PREPARE = "prepare"
    COMMIT = "commit"
    ROLLBACK = "rollback"


class TwoPhaseCommit:
    """
    Two-phase commit protocol for multi-agent transactions.
    
    Phase 1 (PREPARE): Coordinator sends prepare request to all participants.
    Phase 2 (COMMIT/ROLLBACK): If all participants ACK, send COMMIT. Otherwise send ROLLBACK.
    
    Participants must respond within the timeout window.
    """

    def __init__(self, coordinator_id: str, timeout: float = 10.0):
        self.coordinator_id = coordinator_id
        self.timeout = timeout
        self._lock = threading.RLock()
        self._active_transactions: Dict[str, dict] = {}
        self._completed_transactions: List[dict] = []

        # Callbacks
        self._on_prepare: Optional[callable] = None
        self._on_commit: Optional[callable] = None
        self._on_rollback: Optional[callable] = None

    def set_prepare_callback(self, cb: callable) -> None:
        self._on_prepare = cb

    def set_commit_callback(self, cb: callable) -> None:
        self._on_commit = cb

    def set_rollback_callback(self, cb: callable) -> None:
        self._on_rollback = cb

    def begin_transaction(self, participants: List[str], payload: dict = None) -> str:
        """Start a new two-phase commit transaction."""
        tx_id = f"2pc_{uuid.uuid4().hex[:12]}"
        with self._lock:
            self._active_transactions[tx_id] = {
                "tx_id": tx_id,
                "coordinator": self.coordinator_id,
                "participants": participants,
                "payload": payload or {},
                "phase": TransactionPhase.PREPARE,
                "votes": {},  # participant -> bool
                "started_at": time.time(),
                "status": "in_progress",
            }
        logger.info("2PC transaction %s started with %d participants", tx_id, len(participants))
        return tx_id

    def cast_vote(self, tx_id: str, participant: str, can_commit: bool,
                  reason: str = "") -> bool:
        """Cast a vote on a transaction."""
        with self._lock:
            if tx_id not in self._active_transactions:
                return False
            tx = self._active_transactions[tx_id]
            if participant not in tx["participants"]:
                return False
            tx["votes"][participant] = can_commit

            # Check if all voted
            if len(tx["votes"]) == len(tx["participants"]):
                all_yes = all(tx["votes"].values())
                if all_yes:
                    tx["phase"] = TransactionPhase.COMMIT
                    tx["status"] = "committed"
                    if self._on_commit:
                        self._on_commit(tx_id, tx["payload"])
                else:
                    tx["phase"] = TransactionPhase.ROLLBACK
                    tx["status"] = "rolled_back"
                    if self._on_rollback:
                        self._on_rollback(tx_id, reason)

                self._completed_transactions.append(tx)
                del self._active_transactions[tx_id]

            return True

    def check_pending(self) -> List[dict]:
        """Get transactions that haven't received all votes yet."""
        now = time.time()
        expired = []
        with self._lock:
            for tx_id, tx in list(self._active_transactions.items()):
                if now - tx["started_at"] > self.timeout:
                    # Timeout — auto-rollback
                    tx["phase"] = TransactionPhase.ROLLBACK
                    tx["status"] = "timeout_rolled_back"
                    self._completed_transactions.append(tx)
                    expired.append(tx)
                    del self._active_transactions[tx_id]
                    if self._on_rollback:
                        self._on_rollback(tx_id, "timeout")
                # Return remaining pending
            return [
                {
                    "tx_id": tx["tx_id"],
                    "participants": tx["participants"],
                    "votes_received": len(tx["votes"]),
                    "votes_needed": len(tx["participants"]),
                    "elapsed": now - tx["started_at"],
                    "phase": tx["phase"],
                }
                for tx in self._active_transactions.values()
            ]

    def get_history(self, limit: int = 50) -> List[dict]:
        with self._lock:
            return list(self._completed_transactions[-limit:])

    def get_stats(self) -> dict:
        with self._lock:
            committed = sum(1 for t in self._completed_transactions if t["status"] == "committed")
            rolled = sum(1 for t in self._completed_transactions if t["status"] != "committed")
            return {
                "active": len(self._active_transactions),
                "completed": len(self._completed_transactions),
                "committed": committed,
                "rolled_back": rolled,
                "timeout": self.timeout,
            }
