"""
Mesh Audit Log — Immutable Append-Only Audit Trail (Level 3)
============================================================

Provides an append-only audit log for broker-intent actions within the
SIMP mesh. Entries are stored in memory and optionally persisted to a
JSONL file. No deletion or update is permitted — the log is IMMUTABLE.

Thread-safe via threading.Lock.

Design:
  - Each entry: {timestamp, broker_id, intent_id, action, details}
  - Optional JSONL persistence: each append() writes immediately to file
  - Query by time range, broker_id, and/or intent_id
  - Pure Python (stdlib only)
"""

from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class AuditEntry:
    """A single immutable audit log entry."""

    timestamp: float
    broker_id: str
    intent_id: str
    action: str
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "broker_id": self.broker_id,
            "intent_id": self.intent_id,
            "action": self.action,
            "details": self.details,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditEntry":
        return cls(
            timestamp=data["timestamp"],
            broker_id=data["broker_id"],
            intent_id=data["intent_id"],
            action=data["action"],
            details=data.get("details", {}),
        )


class MeshAuditLog:
    """
    Immutable, append-only audit log for the SIMP mesh.

    The log is thread-safe. Entries can be appended but never deleted
    or updated. An optional ``log_path`` enables JSONL persistence.

    Args:
        log_path: Optional path to a JSONL file for persistence.
                  If provided, each append() writes to the file immediately.
        load_existing: If True and log_path points to an existing file,
                       load entries from it on initialization.
    """

    def __init__(
        self,
        log_path: Optional[str] = None,
        load_existing: bool = False,
    ) -> None:
        self._lock = threading.Lock()
        self._entries: List[AuditEntry] = []
        self._log_path: Optional[str] = log_path

        if load_existing and log_path:
            self._load_existing_entries()

    # ── Internal helpers ──────────────────────────────────────────────

    def _load_existing_entries(self) -> None:
        """Load entries from an existing JSONL file on startup."""
        import os

        if not os.path.isfile(self._log_path):  # type: ignore[arg-type]
            return
        loaded = 0
        with open(self._log_path, "r") as f:  # type: ignore[arg-type]
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    self._entries.append(AuditEntry.from_dict(data))
                    loaded += 1
                except (json.JSONDecodeError, KeyError) as exc:
                    logger.warning("Skipping malformed audit line: %s", exc)
        if loaded:
            logger.info("Loaded %d existing audit entries from %s", loaded, self._log_path)

    def _append_to_file(self, entry: AuditEntry) -> None:
        """Append a single entry as JSONL to the log file."""
        if not self._log_path:
            return
        import os

        os.makedirs(os.path.dirname(os.path.abspath(self._log_path)), exist_ok=True)
        with open(self._log_path, "a") as f:
            f.write(json.dumps(entry.to_dict()) + "\n")

    # ── Public API ────────────────────────────────────────────────────

    def append(
        self,
        broker_id: str,
        intent_id: str,
        action: str,
        details: Optional[Dict[str, Any]] = None,
        timestamp: Optional[float] = None,
    ) -> AuditEntry:
        """
        Append a new audit entry.

        Args:
            broker_id: The broker that performed the action.
            intent_id: The intent associated with the action.
            action: A short action label (e.g. "created", "forwarded", "resolved").
            details: Optional dict with additional context.
            timestamp: Optional Unix timestamp (defaults to time.time()).

        Returns:
            The newly created AuditEntry.
        """
        entry = AuditEntry(
            timestamp=timestamp if timestamp is not None else time.time(),
            broker_id=broker_id,
            intent_id=intent_id,
            action=action,
            details=details or {},
        )
        with self._lock:
            self._entries.append(entry)
            self._append_to_file(entry)
        logger.debug("Audit entry appended: broker=%s intent=%s action=%s", broker_id, intent_id, action)
        return entry

    def query(
        self,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
        broker_id: Optional[str] = None,
        intent_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Query audit entries with optional filters.

        Args:
            start_time: Include entries at or after this timestamp.
            end_time: Include entries at or before this timestamp.
            broker_id: Filter to entries from this broker.
            intent_id: Filter to entries for this intent.

        Returns:
            List of entry dicts matching the filters.
        """
        with self._lock:
            results = list(self._entries)

        if start_time is not None:
            results = [e for e in results if e.timestamp >= start_time]
        if end_time is not None:
            results = [e for e in results if e.timestamp <= end_time]
        if broker_id is not None:
            results = [e for e in results if e.broker_id == broker_id]
        if intent_id is not None:
            results = [e for e in results if e.intent_id == intent_id]

        return [e.to_dict() for e in results]

    def get_all(self) -> List[Dict[str, Any]]:
        """
        Returns a list of all audit entries (as dicts).

        Returns:
            All entries in insertion order.
        """
        with self._lock:
            return [e.to_dict() for e in list(self._entries)]

    def get_count(self) -> int:
        """
        Returns the total number of entries in the log.

        Returns:
            Entry count.
        """
        with self._lock:
            return len(self._entries)

    def export_json(self, path: str) -> None:
        """
        Export all entries to a JSON file (list of dicts).

        Args:
            path: Filesystem path for the output JSON file.
        """
        import os

        entries = self.get_all()
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w") as f:
            json.dump(entries, f, indent=2)
        logger.info("Exported %d audit entries to %s", len(entries), path)


# ── Verification Block ────────────────────────────────────────────────

if __name__ == "__main__":
    import os
    import tempfile

    print("=" * 60)
    print("MeshAuditLog Verification")
    print("=" * 60)

    with tempfile.TemporaryDirectory() as tmpdir:
        jsonl_path = os.path.join(tmpdir, "audit.jsonl")

        # 1. Basic in-memory log
        log = MeshAuditLog()
        assert log.get_count() == 0
        print("[✓] Empty log created")

        # 2. Append entries
        e1 = log.append(broker_id="broker_a", intent_id="intent_1", action="created", details={"priority": "high"})
        e2 = log.append(broker_id="broker_b", intent_id="intent_1", action="forwarded", details={"to": "broker_c"})
        e3 = log.append(broker_id="broker_a", intent_id="intent_2", action="resolved")
        assert log.get_count() == 3
        print(f"[✓] 3 entries appended (count={log.get_count()})")

        # 3. Immutability check — ensure no delete/update methods exist
        assert not hasattr(log, "delete")
        assert not hasattr(log, "update")
        assert not hasattr(log, "remove")
        print("[✓] Immutability confirmed: no delete/update methods")

        # 4. get_all()
        all_ = log.get_all()
        assert len(all_) == 3
        assert all_[0]["action"] == "created"
        assert all_[1]["action"] == "forwarded"
        print(f"[✓] get_all() returns {len(all_)} entries")

        # 5. Query by broker_id
        broker_a_entries = log.query(broker_id="broker_a")
        assert len(broker_a_entries) == 2
        print(f"[✓] query(broker_id='broker_a') → {len(broker_a_entries)} entries")

        # 6. Query by intent_id
        intent_1_entries = log.query(intent_id="intent_1")
        assert len(intent_1_entries) == 2
        print(f"[✓] query(intent_id='intent_1') → {len(intent_1_entries)} entries")

        # 7. Query by time range
        now = time.time()
        future_entries = log.query(start_time=now + 1_000_000)
        assert len(future_entries) == 0
        past_entries = log.query(end_time=now + 1)
        assert len(past_entries) == 3
        print("[✓] query() with time filters works")

        # 8. Combined filter
        combo = log.query(broker_id="broker_a", intent_id="intent_1")
        assert len(combo) == 1
        assert combo[0]["action"] == "created"
        print(f"[✓] Combined filter (broker_a + intent_1) → {len(combo)} entry")

        # 9. Export to JSON
        json_path = os.path.join(tmpdir, "audit_export.json")
        log.export_json(json_path)
        assert os.path.isfile(json_path)
        with open(json_path) as f:
            exported = json.load(f)
        assert len(exported) == 3
        print(f"[✓] export_json() → {len(exported)} entries written")

        # 10. Persistence with JSONL
        log2 = MeshAuditLog(log_path=jsonl_path, load_existing=False)
        log2.append(broker_id="broker_c", intent_id="intent_3", action="started")
        assert log2.get_count() == 1
        assert os.path.isfile(jsonl_path)
        with open(jsonl_path) as f:
            lines = f.readlines()
        assert len(lines) == 1
        print(f"[✓] JSONL persistence: {len(lines)} line(s) written")

        # 11. Load existing from JSONL
        log3 = MeshAuditLog(log_path=jsonl_path, load_existing=True)
        assert log3.get_count() == 1
        assert log3.get_all()[0]["intent_id"] == "intent_3"
        print(f"[✓] Loaded {log3.get_count()} entry(s) from existing JSONL")

        # 12. Thread safety (concurrent appends)
        import concurrent.futures

        def threaded_append(log: MeshAuditLog, idx: int) -> None:
            log.append(broker_id=f"t_broker_{idx}", intent_id=f"t_intent_{idx}", action="thread_test")

        log4 = MeshAuditLog()
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(threaded_append, log4, i) for i in range(50)]
            concurrent.futures.wait(futures)
        assert log4.get_count() == 50
        print(f"[✓] Thread safety: 50 concurrent appends → count={log4.get_count()}")

    print()
    print("All MeshAuditLog tests PASSED ✓")
