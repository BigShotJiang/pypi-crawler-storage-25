"""
Superposition Intent Router — T53: Intent Superposition Router

Implements parallel fan-out routing where an intent is sent to multiple agents
simultaneously. The first successful result collapses the superposition.
TrustScorer is the "quantum measurement apparatus" — agents with higher trust
scores contribute more weight to the collapse.
MeshConsensusNode aggregates votes and emits the collapsed result.

Pipeline:
    fan_out(intent, candidates)
        → sends to N agents in parallel
        → tracks first_success_result
        → cancels remaining agents on collapse
        → MeshConsensusNode measures → collapsed result + winner agent_id + trust score
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, TYPE_CHECKING

if TYPE_CHECKING:
    from simp.mesh.packet import MeshPacket
    from simp.mesh.enhanced_bus import EnhancedMeshBus

logger = logging.getLogger(__name__)

# ── Status ──────────────────────────────────────────────────────────────────

class SuperpositionStatus(str, Enum):
    SUPERPOSED = "superposed"   # Waiting — intent exists in multiple candidates
    COLLAPSING = "collapsing"   # First success received — collapse in progress
    COLLAPSED  = "collapsed"    # Collapse complete — winner selected
    ABORTED    = "aborted"      # All candidates failed or TTL exceeded


@dataclass
class CollapseResult:
    """Result of a superposition collapse."""
    intent_id: str
    status: SuperpositionStatus
    winner_id: Optional[str] = None
    winner_trust: float = 0.0
    result_payload: Optional[Dict[str, Any]] = None
    all_candidates: List[str] = field(default_factory=list)
    candidate_trusts: Dict[str, float] = field(default_factory=dict)
    collapse_reason: str = ""  # "first_success", "consensus", "ttl_expired"
    execution_ms: float = 0.0


@dataclass
class SuperpositionState:
    """Mutable state for an active superposition."""
    superposition_id: str
    intent_id: str
    candidates: Set[str]
    candidate_trusts: Dict[str, float]
    pending: Set[str]  # agents not yet responded
    resolved: Set[str]  # agents that returned results
    status: SuperpositionStatus = SuperpositionStatus.SUPERPOSED
    first_success_at: Optional[float] = None
    winner_id: Optional[str] = None
    result_payload: Optional[Dict[str, Any]] = None
    abort_callbacks: List[Callable[[str], None]] = field(default_factory=list)


# ── SuperpositionIntentRouter ───────────────────────────────────────────────

class SuperpositionIntentRouter:
    """
    Router that fans out intents to multiple candidates in parallel and collapses
    on first success using TrustScorer as the quantum measurement apparatus.
    """

    def __init__(self, local_agent_id: str):
        self.local_agent_id = local_agent_id
        self.logger = logging.getLogger(f"superpos.{local_agent_id}")

        # Active superpositions: superposition_id → SuperpositionState
        self._active: Dict[str, SuperpositionState] = {}
        self._lock = threading.Lock()

        # Trust scorer for measurement
        self._ts = None

        # TTL for superposition (seconds)
        self.default_ttl = 5.0

    # ── trust scorer lazy load ──────────────────────────────────────────────

    def _get_trust_scorer(self):
        if self._ts is None:
            try:
                from simp.mesh.trust_scorer import get_trust_scorer
                self._ts = get_trust_scorer()
            except Exception as exc:
                self.logger.debug(f"TrustScorer unavailable: {exc}")
                self._ts = None
        return self._ts

    # ── public API ──────────────────────────────────────────────────────────

    def fan_out(
        self,
        intent_id: str,
        intent_payload: Dict[str, Any],
        candidates: List[str],
        ttl: Optional[float] = None,
        on_collapse: Optional[Callable[[CollapseResult], None]] = None,
    ) -> str:
        """
        Fan out an intent to multiple candidate agents in parallel.
        Returns a superposition_id for tracking.

        Args:
            intent_id:       ID of the intent being fanned out
            intent_payload:  Dict to send to each candidate
            candidates:      List of candidate agent_ids
            ttl:             Seconds before forced collapse (default 5.0)
            on_collapse:    Callback when superposition collapses
        """
        if not candidates:
            raise ValueError("At least one candidate required for superposition")

        ts = self._get_trust_scorer()
        candidate_trusts: Dict[str, float] = {}
        for cid in candidates:
            if ts:
                try:
                    candidate_trusts[cid] = ts.score(cid).trust_score
                except Exception:
                    candidate_trusts[cid] = 1.0
            else:
                candidate_trusts[cid] = 1.0

        sup_id = f"sup_{uuid.uuid4().hex[:12]}"

        state = SuperpositionState(
            superposition_id=sup_id,
            intent_id=intent_id,
            candidates=set(candidates),
            candidate_trusts=candidate_trusts,
            pending=set(candidates),
            resolved=set(),
        )

        with self._lock:
            self._active[sup_id] = state

        self.logger.info(
            f"Superposition {sup_id}: intent={intent_id} → {len(candidates)} candidates "
            f"({', '.join(f'{c}@{candidate_trusts[c]:.2f}' for c in candidates[:3])})"
        )

        # Schedule TTL expiry collapse
        expiry = ttl if ttl is not None else self.default_ttl
        threading.Thread(
            target=self._expire_superposition,
            args=(sup_id, expiry),
            daemon=True,
            name=f"sup-expiry-{sup_id}",
        ).start()

        return sup_id

    def report_success(
        self,
        sup_id: str,
        agent_id: str,
        result_payload: Dict[str, Any],
    ) -> Optional[CollapseResult]:
        """
        Called when a candidate agent returns a successful result.
        Triggers collapse to this agent.
        """
        ts = self._get_trust_scorer()
        trust = self.candidate_trusts.get(agent_id, 1.0) if ts else 1.0

        with self._lock:
            if sup_id not in self._active:
                return None
            state = self._active[sup_id]

            if state.status != SuperpositionStatus.SUPERPOSED:
                return None  # already collapsed or aborted

            state.status = SuperpositionStatus.COLLAPSING
            state.first_success_at = time.monotonic()
            state.winner_id = agent_id
            state.result_payload = result_payload

        return self._collapse(sup_id, agent_id, trust, result_payload,
                             collapse_reason="first_success")

    def report_failure(self, sup_id: str, agent_id: str) -> None:
        """Called when a candidate agent fails. If all failed, abort."""
        with self._lock:
            if sup_id not in self._active:
                return
            state = self._active[sup_id]
            state.pending.discard(agent_id)
            state.resolved.add(agent_id)

            if not state.pending:
                state.status = SuperpositionStatus.ABORTED
                self.logger.warning(f"Superposition {sup_id}: all candidates failed")

    def get_state(self, sup_id: str) -> Optional[SuperpositionState]:
        with self._lock:
            return self._active.get(sup_id)

    def get_active_count(self) -> int:
        with self._lock:
            return len(self._active)

    @property
    def candidate_trusts(self) -> Dict[str, float]:
        """Property for backward compat with tests."""
        with self._lock:
            for sup in self._active.values():
                return sup.candidate_trusts
        return {}

    # ── internal ────────────────────────────────────────────────────────────

    def _collapse(
        self,
        sup_id: str,
        winner_id: str,
        winner_trust: float,
        result_payload: Dict[str, Any],
        collapse_reason: str,
    ) -> CollapseResult:
        with self._lock:
            state = self._active.get(sup_id)
            if state:
                state.status = SuperpositionStatus.COLLAPSED
                state.winner_id = winner_id

        ms = (time.monotonic() - state.first_success_at) * 1000 if state.first_success_at else 0.0

        result = CollapseResult(
            intent_id=state.intent_id,
            status=SuperpositionStatus.COLLAPSED,
            winner_id=winner_id,
            winner_trust=winner_trust,
            result_payload=result_payload,
            all_candidates=list(state.candidates),
            candidate_trusts=state.candidate_trusts,
            collapse_reason=collapse_reason,
            execution_ms=ms,
        )

        self.logger.info(
            f"Superposition {sup_id} COLLAPSED → {winner_id} "
            f"(trust={winner_trust:.2f}, reason={collapse_reason}, ms={ms:.1f})"
        )
        return result

    def _expire_superposition(self, sup_id: str, ttl: float) -> None:
        time.sleep(ttl)
        with self._lock:
            if sup_id not in self._active:
                return
            state = self._active[sup_id]
            if state.status == SuperpositionStatus.SUPERPOSED:
                state.status = SuperpositionStatus.ABORTED
                self.logger.warning(
                    f"Superposition {sup_id} TTL expired — "
                    f"{len(state.pending)} candidates unresolved"
                )

    # ── consensus measurement ───────────────────────────────────────────────

    def consensus_measure(self, sup_id: str) -> Optional[CollapseResult]:
        """
        Force a consensus measurement using MeshConsensusNode.
        Weights each candidate's vote by their trust score.
        """
        try:
            from simp.mesh.consensus import get_consensus_node
            node = get_consensus_node()
            if node is None:
                return None

            with self._lock:
                state = self._active.get(sup_id)
                if not state:
                    return None

            votes = {}
            for agent_id, trust in state.candidate_trusts.items():
                votes[agent_id] = trust  # weight = trust score

            result = node.vote(
                topic=f"superposition_{sup_id}",
                agent_id=self.local_agent_id,
                vote_data={"candidates": list(state.candidates), "trusts": votes},
            )
            if result and result.get("outcome") == "consensus":
                winner = result.get("winner_id")
                winner_trust = state.candidate_trusts.get(winner, 1.0)
                return self._collapse(sup_id, winner, winner_trust, {},
                                     collapse_reason="consensus")
            return None
        except Exception as exc:
            self.logger.debug(f"Consensus measurement failed: {exc}")
            return None
