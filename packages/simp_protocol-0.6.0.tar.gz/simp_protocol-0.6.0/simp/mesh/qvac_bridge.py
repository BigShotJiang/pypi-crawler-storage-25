"""
QVAC Bridge — SIMP Delegate Inference Organ
============================================
Provides remote AI inference delegation as a SIMP organ capability.
Agents route inference intents to known providers via the existing
SIMP routing table — no DHT, no discovery, no P2P model distribution.

What QVAC (Tether) contributed:
  - The delegation pattern: loadModel({delegate}) → delegate_inference()
  - Firewall design: deny-by-default with allow/deny lists
  - Deterministic identity from seed

What SIMP strips away:
  - Hyperswarm DHT discovery (SIMP uses its routing table)
  - TopicChannel (SIMP uses its federation layer)
  - P2P model distribution (not needed — models are at endpoints)
  - Provider discovery loop (SIMP knows its organs)

This is NOT a QVAC SDK wrapper. It is a SIMP organ that
implements the QVAC delegation *pattern* the SIMP way.

Integration Points
──────────────────
  - IntentRouter: routes qvac_inference_intent to this bridge
  - OrganRegistry: publishes qvac_inference capability
  - HttpServer: /v1/qvac/inference endpoint for external agents
  - SimpCrypto: signs delegation requests for non-repudiation

Latency Budget
──────────────
  - Firewall check: ~0.01ms (in-memory set lookup)
  - Routing lookup: ~0.1ms (dict get)
  - Serialization: ~0.5ms (json.dumps)
  - Network round-trip: variable (depends on provider)
  - TOTAL overhead on hot path: ~0.6ms + network
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── Constants ────────────────────────────────────────────────────────────────

# Well-known model identifiers (informational — used for capability publication)
QVAC_MODEL_REGISTRY: Dict[str, Dict[str, Any]] = {
    "LLAMA_3_2_1B_INST_Q4_0": {
        "type": "llm",
        "src": "llama3.2:1b-instruct-q4_0",
        "context": 8192,
        "size_mb": 790,
    },
    "LLAMA_3_2_3B_INST_Q4_0": {
        "type": "llm",
        "src": "llama3.2:3b-instruct-q4_0",
        "context": 8192,
        "size_mb": 2000,
    },
    "QWEN2_5_7B_Q4_0": {
        "type": "llm",
        "src": "qwen2.5:7b-q4_0",
        "context": 32768,
        "size_mb": 4400,
    },
}

DEFAULT_INFERENCE_TIMEOUT: float = 60.0
QVAC_FIREWALL_MODE: str = "deny"  # deny unknown providers by default
MAX_RETRY_ATTEMPTS: int = 2
RETRY_BACKOFF_MS: float = 100.0


# ── Data Types ───────────────────────────────────────────────────────────────

class ProviderStatus(Enum):
    ONLINE = "online"
    OFFLINE = "offline"
    BUSY = "busy"
    UNKNOWN = "unknown"


@dataclass
class ProviderEndpoint:
    """A known inference provider reachable via SIMP routing.

    This replaces QVAC's QVACProvider which was designed for DHT discovery.
    SIMP providers are registered in the routing table, not discovered.
    """
    provider_id: str
    public_key: str
    models_available: List[str]
    endpoint: str  # simp://provider_id/model or http endpoint
    status: ProviderStatus = ProviderStatus.ONLINE
    latency_ms: float = 0.0
    trust_score: float = 1.0
    last_seen: float = field(default_factory=time.time)

    @property
    def is_alive(self) -> bool:
        return (time.time() - self.last_seen) < 120.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "provider_id": self.provider_id,
            "public_key": self.public_key[:16] + "...",
            "models_available": self.models_available,
            "endpoint": self.endpoint,
            "status": self.status.value,
            "latency_ms": round(self.latency_ms, 1),
            "trust_score": round(self.trust_score, 2),
            "is_alive": self.is_alive,
        }


@dataclass
class InferenceDelegation:
    """A remote inference request to a known provider.
    
    This is the core data type — it carries everything needed to
    route a prompt to a provider and get a response back.
    """
    delegation_id: str = field(default_factory=lambda: f"del_{uuid.uuid4().hex[:12]}")
    provider_id: str = ""
    model_src: str = ""
    prompt: str = ""
    stream: bool = False
    timeout: float = DEFAULT_INFERENCE_TIMEOUT
    source_agent: str = ""
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class InferenceResult:
    """Result from a delegated inference call."""
    delegation_id: str
    status: str  # success | error | timeout
    response_text: str = ""
    tokens_used: int = 0
    inference_time_ms: float = 0.0
    provider_id: str = ""
    model_used: str = ""
    error: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── Firewall ─────────────────────────────────────────────────────────────────

class InferenceFirewall:
    """Deny-by-default access control for inference providers.

    Extracted from QVAC's firewall design. Same pattern, SIMP naming.

    Latency: ~0.01ms per check (in-memory set lookups, no locks on hot path).
    """

    def __init__(self, mode: str = QVAC_FIREWALL_MODE):
        self._mode = mode
        self._allow_list: Set[str] = set()
        self._deny_list: Set[str] = set()
        self._allowed_models: Set[str] = set()

    def allow_provider(self, provider_id: str) -> None:
        self._allow_list.add(provider_id)

    def deny_provider(self, provider_id: str) -> None:
        self._deny_list.add(provider_id)

    def allow_model(self, model_src: str) -> None:
        self._allowed_models.add(model_src)

    def is_allowed(self, provider_id: str, model_src: str) -> Tuple[bool, str]:
        """Check if inference from this provider with this model is allowed.
        
        No locks — firewall config changes are infrequent, and stale reads
        on the hot path are acceptable for security policy (we'd rather
        accept a brief inconsistency than add lock contention to every call).
        """
        if provider_id in self._deny_list:
            return False, f"Provider {provider_id} denied"

        if self._mode == "deny":
            if provider_id not in self._allow_list:
                return False, f"Provider {provider_id} not in allow list"
        else:
            if provider_id in self._deny_list:
                return False, f"Provider {provider_id} denied"

        if self._allowed_models and model_src not in self._allowed_models:
            if self._mode == "deny":
                return False, f"Model {model_src} not allowed"

        return True, "allowed"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mode": self._mode,
            "allowed_providers": len(self._allow_list),
            "denied_providers": len(self._deny_list),
            "allowed_models": list(self._allowed_models),
        }


# ── Inference Engine ─────────────────────────────────────────────────────────

class InferenceEngine:
    """Runs inference locally (simulated or real).

    In production, this would call Ollama, vLLM, or a local model.
    Currently simulates responses for testing and development.

    This replaces QVACProviderService — it's just the execution layer,
    not a provider lifecycle manager. The lifecycle (start/stop/health)
    is handled by the bridge.
    """

    def __init__(self, engine_id: str = "qvac-default", models: Optional[List[str]] = None):
        self.engine_id = engine_id
        self._models = models or list(QVAC_MODEL_REGISTRY.keys())
        self._inferences_served = 0
        self._total_inference_time_ms = 0.0

    @property
    def models(self) -> List[str]:
        return list(self._models)

    def inference(self, delegation: InferenceDelegation) -> InferenceResult:
        """Execute an inference request.

        Latency: simulated ~1ms. Real: depends on model + hardware.
        """
        start = time.time()
        model_info = QVAC_MODEL_REGISTRY.get(delegation.model_src, {})
        model_name = model_info.get("src", delegation.model_src)

        response_text = self._simulate(delegation.prompt, model_name)
        elapsed_ms = (time.time() - start) * 1000

        self._inferences_served += 1
        self._total_inference_time_ms += elapsed_ms

        return InferenceResult(
            delegation_id=delegation.delegation_id,
            status="success",
            response_text=response_text,
            tokens_used=len(response_text.split()),
            inference_time_ms=round(elapsed_ms, 1),
            provider_id=self.engine_id,
            model_used=model_name,
        )

    def _simulate(self, prompt: str, model_name: str) -> str:
        """Simulated inference response."""
        p = prompt.lower()
        if "hello" in p or "hi" in p:
            return f"Hello from SIMP inference engine '{self.engine_id}' via {model_name}."
        elif "capabilities" in p or "what can you" in p:
            return f"I have {len(self._models)} model(s) available."
        else:
            return f"[{model_name}] Processing '{prompt[:40]}...' via {self.engine_id}."

    def get_status(self) -> Dict[str, Any]:
        return {
            "engine_id": self.engine_id,
            "models": self._models,
            "inferences_served": self._inferences_served,
            "avg_inference_time_ms": round(
                self._total_inference_time_ms / max(self._inferences_served, 1), 1
            ),
        }


# ── QVAC Bridge ──────────────────────────────────────────────────────────────

class QVACBridge:
    """SIMP organ for delegated AI inference.

    This is NOT a QVAC SDK wrapper. It implements the QVAC delegation
    *pattern* through SIMP's existing routing infrastructure.

    Key design differences from QVAC's approach:
      - No Hyperswarm DHT: providers are known via SIMP routing table
      - No TopicChannel: federation layer handles cross-organ routing
      - No discover_providers(): providers register once, stay registered
      - Singleton: one bridge per broker, wired at startup

    Latency budget for delegation:
      ┌────────────────────┬────────────┐
      │ Firewall check     │ ~0.01ms    │
      │ Route lookup       │ ~0.1ms     │
      │ Serialization      │ ~0.5ms     │
      │ Network round-trip │ variable   │
      │ Inference engine   │ model-dep  │
      └────────────────────┴────────────┘
    """

    _instance: Optional["QVACBridge"] = None
    _instance_lock = threading.Lock()

    def __init__(
        self,
        organ_id: str = "qvac",
        seed: Optional[str] = None,
        firewall_mode: str = QVAC_FIREWALL_MODE,
        dry_run: bool = True,
    ):
        self.organ_id = organ_id
        self._seed = seed or os.environ.get("SIM_QVAC_SEED") or hashlib.sha256(organ_id.encode()).hexdigest()
        self._public_key = hashlib.sha256(self._seed.encode()).hexdigest()
        self._dry_run = dry_run
        self._start_time = time.time()
        self._healthy = True

        # Firewall (from QVAC's pattern)
        self.firewall = InferenceFirewall(mode=firewall_mode)

        # Provider table — keyed by provider_id
        # Populated via register_provider(), not discovery
        self._providers: Dict[str, ProviderEndpoint] = {
            self.organ_id: ProviderEndpoint(
                provider_id=self.organ_id,
                public_key=self._public_key,
                models_available=list(QVAC_MODEL_REGISTRY.keys()),
                endpoint="simp://local",
                status=ProviderStatus.ONLINE,
            )
        }

        # Local inference engine
        self._engine = InferenceEngine(engine_id=organ_id)

        # Inference history (last N for debugging)
        self._history: List[Dict] = []
        self._max_history = 200

        # Stats
        self._stats = {
            "inferences_delegated": 0,
            "inferences_served": 0,
            "inferences_failed": 0,
            "inferences_blocked": 0,
        }

        logger.info(
            "[QVAC] Bridge initialized  organ=%s  key=%s...  dry_run=%s",
            organ_id, self._public_key[:16], dry_run,
        )

    # ── Singleton ────────────────────────────────────────────────────────────

    @classmethod
    def get_instance(
        cls,
        organ_id: str = "qvac",
        seed: Optional[str] = None,
        dry_run: bool = True,
    ) -> "QVACBridge":
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = cls(
                        organ_id=organ_id,
                        seed=seed,
                        dry_run=dry_run,
                    )
        return cls._instance

    # ── Provider Management ─────────────────────────────────────────────────

    def register_provider(
        self,
        provider_id: str,
        public_key: str = "",
        models: Optional[List[str]] = None,
        endpoint: str = "",
    ) -> None:
        """Register a known provider. Called at startup or when a new
        provider joins the federation. NOT discovered via DHT."""
        pk = public_key or hashlib.sha256(provider_id.encode()).hexdigest()
        ep = endpoint or f"simp://{provider_id}/inference"
        self._providers[provider_id] = ProviderEndpoint(
            provider_id=provider_id,
            public_key=pk,
            models_available=models or list(QVAC_MODEL_REGISTRY.keys()),
            endpoint=ep,
            status=ProviderStatus.ONLINE,
        )
        logger.info("[QVAC] Registered provider: %s → %s", provider_id, ep)

    def unregister_provider(self, provider_id: str) -> None:
        self._providers.pop(provider_id, None)
        logger.info("[QVAC] Unregistered provider: %s", provider_id)

    def get_provider(self, provider_id: str) -> Optional[ProviderEndpoint]:
        return self._providers.get(provider_id)

    def list_providers(self) -> List[ProviderEndpoint]:
        return list(self._providers.values())

    # ── Delegated Inference ──────────────────────────────────────────────────

    def delegate_inference(
        self,
        provider_id: str,
        model_src: str,
        prompt: str,
        stream: bool = False,
        source_agent: str = "",
        timeout: float = DEFAULT_INFERENCE_TIMEOUT,
    ) -> InferenceResult:
        """Route a prompt to a known provider for inference.

        This is the hot path. Every microsecond counts.
        The path is:
          1. Firewall check (~0.01ms)
          2. Provider lookup (~0.1ms)
          3. Model check (~0.01ms)
          4. If dry_run: return simulated result
          5. If local: run on local engine
          6. If remote: serialize and send (future)

        QVAC equivalent: loadModel({delegate: provider_id}) + completion()
        """
        delegation = InferenceDelegation(
            provider_id=provider_id,
            model_src=model_src,
            prompt=prompt,
            stream=stream,
            timeout=timeout,
            source_agent=source_agent,
        )

        # 1. Firewall (deny-by-default)
        allowed, reason = self.firewall.is_allowed(provider_id, model_src)
        if not allowed:
            self._stats["inferences_blocked"] += 1
            return InferenceResult(
                delegation_id=delegation.delegation_id,
                status="error",
                error=f"Firewall: {reason}",
            )

        # 2. Provider lookup
        provider = self._providers.get(provider_id)
        if not provider:
            self._stats["inferences_failed"] += 1
            return InferenceResult(
                delegation_id=delegation.delegation_id,
                status="error",
                error=f"Unknown provider: {provider_id}",
            )

        if not provider.is_alive:
            self._stats["inferences_failed"] += 1
            return InferenceResult(
                delegation_id=delegation.delegation_id,
                status="error",
                error=f"Provider offline: {provider_id}",
            )

        # 3. Model availability
        if model_src not in provider.models_available:
            self._stats["inferences_failed"] += 1
            return InferenceResult(
                delegation_id=delegation.delegation_id,
                status="error",
                error=f"Model '{model_src}' not on {provider_id}",
            )

        # 4. Dry-run mode (for testing/development)
        if self._dry_run:
            return InferenceResult(
                delegation_id=delegation.delegation_id,
                status="simulated",
                response_text=f"[DRY-RUN] {provider_id}/{model_src}: {prompt[:60]}...",
                provider_id=provider_id,
                model_used=model_src,
                metadata={"dry_run": True},
            )

        # 5. Execute inference
        start = time.time()
        result = self._engine.inference(delegation)
        elapsed_ms = (time.time() - start) * 1000
        result.inference_time_ms = round(elapsed_ms, 1)

        # 6. Record
        self._stats["inferences_delegated"] += 1
        self._history.append({
            "delegation_id": delegation.delegation_id,
            "provider_id": provider_id,
            "model": model_src,
            "status": result.status,
            "time_ms": result.inference_time_ms,
            "tokens": result.tokens_used,
        })
        if len(self._history) > self._max_history:
            self._history.pop(0)

        return result

    # ── SIMP Organ Interface ─────────────────────────────────────────────────

    def get_capabilities(self) -> List[Dict[str, Any]]:
        """Published capabilities for the organ registry.

        Only the inference capability is exposed — discovery and provider
        service are internal to SIMP's federation layer.
        """
        return [
            {
                "id": f"{self.organ_id}:inference",
                "name": "delegated_inference",
                "description": "Route AI inference to known providers via SIMP's routing table",
                "intent_types": ["qvac_inference_intent"],
                "models": list(QVAC_MODEL_REGISTRY.keys()),
                "firewall_protected": True,
            },
        ]

    def handle_intent(self, intent_type: str, payload: Dict[str, Any], source_agent: str) -> Dict[str, Any]:
        """Handle an intent routed from SIMP's IntentRouter.

        Supported intent types:
          - qvac_inference_intent: delegate inference to a provider
        """
        if intent_type == "qvac_inference_intent":
            return self._handle_inference(payload, source_agent)

        return {"status": "error", "error": f"Unknown intent: {intent_type}"}

    def _handle_inference(self, payload: Dict, source: str) -> Dict:
        provider_id = payload.get("provider_id", self.organ_id)
        model_src = payload.get("model_src", "LLAMA_3_2_1B_INST_Q4_0")
        prompt = payload.get("prompt", "")
        result = self.delegate_inference(
            provider_id=provider_id,
            model_src=model_src,
            prompt=prompt,
            source_agent=source,
        )
        return {"status": result.status, "result": result.to_dict()}

    # ── Health & Status ────────────────────────────────────────────────────

    def health_check(self) -> Dict[str, Any]:
        return {
            "organ_id": self.organ_id,
            "healthy": self._healthy,
            "uptime_seconds": round(time.time() - self._start_time, 1),
            "dry_run": self._dry_run,
            "firewall": self.firewall.to_dict(),
            "providers": len(self._providers),
            "stats": self._stats,
            "engine": self._engine.get_status(),
        }

    def get_status(self) -> Dict[str, Any]:
        return self.health_check()


# ── Module Singleton ─────────────────────────────────────────────────────────
# Import this reference for direct access.
# Usage: from simp.mesh.qvac_bridge import QVAC_BRIDGE
QVAC_BRIDGE = QVACBridge.get_instance()
