"""
Mesh-wide Ed25519 Key Rotation — Level 3 Mesh Protocol

Manages Ed25519 keypair rotation across the mesh.
Old keys remain valid for a ``grace_period`` (default 60s) after rotation
to allow zero-downtime credential transitions.

Maintains a per-broker history of ``[(pubkey, timestamp)]`` for audit trail.

Thread-safe via RLock.
"""

import logging
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class CredentialRotator:
    """Mesh-wide Ed25519 key rotation manager.

    Generates new Ed25519 keypairs, broadcasts new public keys to all
    peer brokers, and maintains a history of all active and recent keys.

    Grace period: old keys remain valid for 60 seconds after rotation,
    allowing in-flight operations to complete.

    Thread-safe: all mutable state guarded by ``_lock``.
    """

    GRACE_PERIOD: float = 60.0

    def __init__(self, broker_id: str) -> None:
        self.broker_id = broker_id
        self._lock = threading.RLock()

        # broker_id -> list of (pubkey_bytes, timestamp) tuples
        self._key_history: Dict[str, List[Tuple[bytes, float]]] = {}

        # broker_id -> current active public key
        self._current_keys: Dict[str, bytes] = {}

        # The local broker's own current keypair
        self._local_private_key: Optional[bytes] = None
        self._local_public_key: Optional[bytes] = None

        logger.info("CredentialRotator initialized for %s", broker_id)

    # ------------------------------------------------------------------
    # Key rotation API
    # ------------------------------------------------------------------

    def rotate_keys(self, broker_id: str) -> Tuple[bytes, bytes]:
        """Generate a new Ed25519 keypair for ``broker_id`` and broadcast.

        If ``broker_id`` matches this rotator's broker_id, generates a
        new local keypair using PyNaCl. Otherwise, creates a placeholder
        keypair for tracking purposes.

        Returns:
            (private_key_bytes, public_key_bytes) of the NEW keypair.
        """
        from nacl.signing import SigningKey  # PyNaCl — already a dep

        sk = SigningKey.generate()
        priv = bytes(sk)
        pub = bytes(sk.verify_key)

        with self._lock:
            now = time.time()

            if broker_id not in self._key_history:
                self._key_history[broker_id] = []
            self._key_history[broker_id].append((pub, now))

            self._current_keys[broker_id] = pub

            if broker_id == self.broker_id:
                self._local_private_key = priv
                self._local_public_key = pub

            logger.info(
                "New Ed25519 keypair generated for %s — pubkey fingerprint: %s",
                broker_id,
                pub.hex()[:16],
            )

        # Broadcast to all known peer brokers
        self.broadcast_new_key(broker_id, pub)

        return priv, pub

    def broadcast_new_key(self, broker_id: str, new_pubkey: bytes) -> None:
        """Broadcast a new public key to all known peer brokers.

        In a real mesh, this would send over MeshBus or the gossip protocol.
        Default implementation logs the broadcast.
        """
        with self._lock:
            peers = [bid for bid in self._current_keys if bid != self.broker_id]
        logger.info(
            "Broadcasting new key for %s (pubkey: %s...) to %d peers",
            broker_id,
            new_pubkey.hex()[:16],
            len(peers),
        )

    def receive_key(self, broker_id: str, new_pubkey: bytes, timestamp: float) -> None:
        """Receive and store a new public key from a peer broker.

        Appends to the key history for ``broker_id`` and updates the
        current active key.

        Args:
            broker_id: The broker whose key was rotated.
            new_pubkey: The new Ed25519 public key (32 bytes).
            timestamp: Unix timestamp of when the key was generated.
        """
        with self._lock:
            if broker_id not in self._key_history:
                self._key_history[broker_id] = []
            self._key_history[broker_id].append((new_pubkey, timestamp))
            self._current_keys[broker_id] = new_pubkey
            logger.info(
                "Received new key for %s (pubkey: %s...) from timestamp %s",
                broker_id,
                new_pubkey.hex()[:16],
                timestamp,
            )

    def get_key(self, broker_id: str) -> Optional[bytes]:
        """Return the current active public key for ``broker_id``.

        Returns ``None`` if no key is known for that broker.
        """
        with self._lock:
            return self._current_keys.get(broker_id)

    # ------------------------------------------------------------------
    # Key validation
    # ------------------------------------------------------------------

    def is_key_valid(self, broker_id: str, pubkey: bytes) -> bool:
        """Check if a public key is currently valid for ``broker_id``.

        Valid means:
          - It IS the current active key, OR
          - It is a previous key that is still within the grace period (60s).

        Thread-safe.
        """
        with self._lock:
            current = self._current_keys.get(broker_id)
            if current == pubkey:
                return True

            # Check history for grace-period keys
            history = self._key_history.get(broker_id, [])
            for key_bytes, ts in history:
                if key_bytes == pubkey and (time.time() - ts) <= self.GRACE_PERIOD:
                    return True
            return False

    # ------------------------------------------------------------------
    # History & audit
    # ------------------------------------------------------------------

    def get_key_history(self, broker_id: str) -> List[Tuple[bytes, float]]:
        """Return the full key rotation history for a broker.

        Returns list of ``(pubkey_bytes, timestamp)`` tuples.
        """
        with self._lock:
            return list(self._key_history.get(broker_id, []))

    def get_all_brokers(self) -> List[str]:
        """Return list of all brokers with known keys."""
        with self._lock:
            return list(self._current_keys.keys())

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_status(self) -> Dict[str, Any]:
        """Return status dict with operational metrics."""
        with self._lock:
            return {
                "broker_id": self.broker_id,
                "brokers_with_keys": len(self._current_keys),
                "has_local_keypair": self._local_public_key is not None,
                "grace_period_seconds": self.GRACE_PERIOD,
                "key_histories": {
                    bid: [(k.hex()[:16], ts) for k, ts in hist[-3:]]
                    for bid, hist in self._key_history.items()
                },
            }


# ---------------------------------------------------------------------------
# Verification block
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import time

    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(message)s")

    rotator = CredentialRotator(broker_id="broker-alpha")

    # Generate a keypair for ourselves
    priv, pub = rotator.rotate_keys("broker-alpha")
    print(f"Generated local keypair: pub={pub.hex()[:16]}...")

    # Verify we can retrieve it
    retrieved = rotator.get_key("broker-alpha")
    assert retrieved == pub, "get_key should return the current public key"
    print(f"Key retrieval: {retrieved.hex()[:16]}... ✓")

    # Simulate receiving a key from a peer broker
    from nacl.signing import SigningKey
    peer_sk = SigningKey.generate()
    peer_pub = bytes(peer_sk.verify_key)

    rotator.receive_key("broker-beta", peer_pub, time.time())
    retrieved_peer = rotator.get_key("broker-beta")
    assert retrieved_peer == peer_pub, "should retrieve peer's key"
    print(f"Peer key stored & retrieved: {retrieved_peer.hex()[:16]}... ✓")

    # Test key history
    history = rotator.get_key_history("broker-alpha")
    assert len(history) == 1, "should have 1 entry in history"
    print(f"History length for broker-alpha: {len(history)} ✓")

    # Rotate again to verify history grows
    priv2, pub2 = rotator.rotate_keys("broker-alpha")
    history = rotator.get_key_history("broker-alpha")
    assert len(history) == 2, "should have 2 entries after second rotation"
    print(f"History length after second rotation: {len(history)} ✓")

    # Verify only current key is returned by get_key
    current = rotator.get_key("broker-alpha")
    assert current == pub2, "get_key should return the newest key"
    print(f"Current key is new one: {current.hex()[:16]}... ✓")

    # Test key validity
    assert rotator.is_key_valid("broker-alpha", pub2), "current key should be valid"
    assert rotator.is_key_valid("broker-alpha", pub), "previous key should be valid (within grace)"
    print("Key validity checks passed ✓")

    # get_all_brokers test
    all_brokers = rotator.get_all_brokers()
    assert "broker-alpha" in all_brokers
    assert "broker-beta" in all_brokers
    print(f"All brokers: {all_brokers} ✓")

    print("\n=== CredentialRotator Verification ===")
    print(f"Status: {rotator.get_status()}")
    print("All assertions passed ✓")
