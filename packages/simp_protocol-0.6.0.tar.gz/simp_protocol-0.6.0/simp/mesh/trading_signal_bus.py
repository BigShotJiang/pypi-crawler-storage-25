"""
Trading Signal Bus — the parasympathetic nervous system of the trading body.

All organs communicate via publish/subscribe through this bus. It also runs
background optimization (heartbeat) even when no organ asks for it.
"""

import logging
import threading
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger(__name__)


def _utcnow() -> str:
    """Return ISO-8601 UTC timestamp string."""
    return datetime.now(timezone.utc).isoformat()


class TradingSignalBus:
    """Mesh signal bus for the trading body. All organs communicate via this."""

    # Signal types
    PRICE_SIGNAL = "price_signal"
    ARB_OPPORTUNITY = "arb_opportunity"
    BROKER_DECISION = "broker_decision"
    EXECUTION_RESULT = "execution_result"
    LESSON_SIGNAL = "lesson_signal"
    THRESHOLD_UPDATE = "threshold_update"
    VENUE_SCORE = "venue_score"
    EXTERNAL_SIGNAL = "external_signal"
    MESH_HEALTH = "mesh_health"

    def __init__(self, max_history: int = 10000):
        self.subscribers: Dict[str, List[Callable]] = defaultdict(list)
        self.signal_history: List[Dict] = []
        self.max_history = max_history
        self._stop_optimization = threading.Event()
        self._optimization_thread: Optional[threading.Thread] = None
        self._start_background_optimization()

    def publish(self, signal_type: str, payload: Dict[str, Any]) -> None:
        """Publish a signal to all subscribers. Callbacks run in background threads."""
        record = {"type": signal_type, "payload": payload, "ts": _utcnow()}
        self.signal_history.append(record)
        # Cap history: when over max, drop oldest half
        if len(self.signal_history) > self.max_history:
            self.signal_history = self.signal_history[-self.max_history // 2 :]
        for callback in self.subscribers.get(signal_type, []):
            try:
                t = threading.Thread(target=self._safe_callback, args=(callback, payload), daemon=True)
                t.start()
            except Exception as e:
                log.error(f"Signal subscriber error for {signal_type}: {e}")

    def _safe_callback(self, callback: Callable, payload: Dict[str, Any]) -> None:
        """Run subscriber callback in background thread."""
        try:
            callback(payload)
        except Exception as e:
            log.error(f"Callback error: {e}")

    def subscribe(self, signal_type: str, callback: Callable) -> None:
        """Subscribe to a signal type."""
        self.subscribers[signal_type].append(callback)

    def unsubscribe(self, signal_type: str, callback: Callable) -> bool:
        """Unsubscribe a callback from a signal type. Returns True if found and removed."""
        if signal_type in self.subscribers:
            try:
                self.subscribers[signal_type].remove(callback)
                return True
            except ValueError:
                pass
        return False

    def get_recent_signals(self, signal_type: str, n: int = 100) -> List[Dict]:
        """Get recent signals of a given type."""
        return [r for r in self.signal_history if r["type"] == signal_type][-n:]

    def get_all_signal_types(self) -> List[str]:
        """Return list of all signal types that have been published."""
        return list(self.signal_history_by_type().keys())

    def signal_history_by_type(self) -> Dict[str, List[Dict]]:
        """Return all signals grouped by type."""
        result: Dict[str, List[Dict]] = defaultdict(list)
        for record in self.signal_history:
            result[record["type"]].append(record)
        return result

    def _start_background_optimization(self) -> None:
        """Parasympathetic: continuously optimize without being asked.

        This runs in a background thread, analyzing signal history and publishing
        LESSON_SIGNAL back into the Mesh. The organs don't know this is happening.
        Like a heartbeat. Like breathing. Like the body's subconscious optimization
        while you sleep.
        """
        self._stop_optimization.clear()
        self._optimization_thread = threading.Thread(
            target=self._optimization_loop, daemon=True, name="signal-bus-optimization"
        )
        self._optimization_thread.start()
        log.info("Signal bus background optimization started")

    def _optimization_loop(self) -> None:
        """Background loop that runs every 60 seconds."""
        while not self._stop_optimization.wait(60):  # 60-second cycle
            try:
                self._analyze_execution_results()
                self._update_venue_scores()
                self._check_threshold_drift()
                self._emit_mesh_health()
            except Exception as e:
                log.error(f"Background optimization error: {e}")

    def _analyze_execution_results(self) -> None:
        """Analyze recent execution results → extract lessons → publish LESSON_SIGNAL."""
        results = self.get_recent_signals(self.EXECUTION_RESULT, n=50)
        if len(results) < 3:
            return  # Need minimum samples

        # Aggregate slippage and PnL from recent executions
        total_slippage = 0.0
        total_pnl = 0.0
        total_fees = 0.0
        count = 0

        for record in results:
            payload = record["payload"]
            result = payload.get("result", {})
            total_slippage += result.get("slippage_bps", 0.0)
            total_pnl += result.get("pnl_usd", 0.0)
            total_fees += result.get("fees_usd", 0.0)
            count += 1

        if count == 0:
            return

        avg_slippage = total_slippage / count
        avg_pnl = total_pnl / count
        avg_fees = total_fees / count

        # Extract simple lesson based on patterns
        lessons = []
        if avg_slippage > 20.0:
            lessons.append(
                {"type": "high_slippage", "value": avg_slippage, "threshold": 20.0}
            )
        if avg_pnl < 0:
            lessons.append(
                {"type": "negative_pnl", "value": avg_pnl, "count": count}
            )
        if avg_fees > 1.0:
            lessons.append(
                {"type": "high_fees", "value": avg_fees, "threshold": 1.0}
            )

        if lessons:
            self.publish(
                self.LESSON_SIGNAL,
                {
                    "lesson_count": len(lessons),
                    "samples": count,
                    "avg_slippage_bps": round(avg_slippage, 3),
                    "avg_pnl_usd": round(avg_pnl, 4),
                    "avg_fees_usd": round(avg_fees, 4),
                    "lessons": lessons,
                    "ts": _utcnow(),
                },
            )

    def _update_venue_scores(self) -> None:
        """Update venue scores based on recent execution performance."""
        results = self.get_recent_signals(self.EXECUTION_RESULT, n=100)
        if len(results) < 5:
            return

        # Group by venue
        venue_data: Dict[str, Dict[str, float]] = defaultdict(lambda: {
            "slippage_sum": 0.0,
            "success_count": 0,
            "total_count": 0,
            "pnl_sum": 0.0,
        })

        for record in results:
            payload = record["payload"]
            result = payload.get("result", {})
            venue = result.get("venue", "unknown")
            venue_data[venue]["slippage_sum"] += result.get("slippage_bps", 0.0)
            venue_data[venue]["total_count"] += 1
            if result.get("status") == "executed":
                venue_data[venue]["success_count"] += 1
            venue_data[venue]["pnl_sum"] += result.get("pnl_usd", 0.0)

        for venue, data in venue_data.items():
            if data["total_count"] == 0:
                continue
            success_rate = data["success_count"] / data["total_count"]
            avg_slippage = data["slippage_sum"] / data["total_count"]
            # Score: higher is better (low slippage, high success rate, positive pnl)
            score = (success_rate * 50) + (max(0, 30 - avg_slippage) / 3) + (
                max(0, data["pnl_sum"]) * 10
            )
            self.publish(
                self.VENUE_SCORE,
                {
                    "venue": venue,
                    "score": round(score, 3),
                    "success_rate": round(success_rate, 3),
                    "avg_slippage_bps": round(avg_slippage, 3),
                    "sample_size": data["total_count"],
                    "ts": _utcnow(),
                },
            )

    def _check_threshold_drift(self) -> None:
        """Check for threshold drift based on recent lessons."""
        lessons = self.get_recent_signals(self.LESSON_SIGNAL, n=20)
        if len(lessons) < 5:
            return

        # Detect persistent high-slippage pattern
        high_slip_count = sum(
            1 for l in lessons
            if l["payload"].get("type") == "high_slippage"
        )
        if high_slip_count >= 5:
            # Publish a threshold update suggesting tighter slippage tolerance
            self.publish(
                self.THRESHOLD_UPDATE,
                {
                    "parameter": "max_acceptable_slippage_bps",
                    "current_value": 25.0,
                    "suggested_value": 20.0,
                    "reason": f"{high_slip_count}/20 recent lessons show high slippage",
                    "ts": _utcnow(),
                },
            )

    def _emit_mesh_health(self) -> None:
        """Publish mesh health signal."""
        self.publish(
            self.MESH_HEALTH,
            {
                "subscriber_count": sum(len(v) for v in self.subscribers.values()),
                "signal_type_count": len(self.subscribers),
                "history_size": len(self.signal_history),
                "optimization_running": (
                    self._optimization_thread is not None
                    and self._optimization_thread.is_alive()
                ),
                "ts": _utcnow(),
            },
        )

    def stop(self) -> None:
        """Stop background optimization. Call on shutdown."""
        self._stop_optimization.set()
        if self._optimization_thread is not None:
            self._optimization_thread.join(timeout=5)
        log.info("Signal bus background optimization stopped")

    def __del__(self):
        try:
            self.stop()
        except Exception:
            pass


# Global singleton
_signal_bus: Optional["TradingSignalBus"] = None


def get_signal_bus() -> "TradingSignalBus":
    """Return the global TradingSignalBus singleton."""
    global _signal_bus
    if _signal_bus is None:
        _signal_bus = TradingSignalBus()
    return _signal_bus