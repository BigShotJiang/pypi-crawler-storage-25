"""
Media Bridge — L4-T38: Multi-Platform Media Organ Bridge
=========================================================
Unified bridge for multi-platform media operations: YouTube, Twitter/X,
TikTok, Instagram, and RSS/News aggregation.

Capabilities
────────────
  - Content publishing (post text, images, video across platforms)
  - Content analysis (sentiment, trend detection, topic extraction)
  - Scheduled posting queue
  - Multi-platform analytics aggregation
  - Trend detection across platforms

QVAC-Inspired Features
──────────────────────
  - Topic-based channel discovery (like Hyperswarm topics)
  - Firewall controls per platform (allow/deny posting)
  - Delegated content analysis (route analysis to specialist models)

Integration Points
──────────────────
  - CapabilityRegistry: register media capabilities
  - IntentRouter: route content_intent, publish_intent, analyze_intent
  - ModelGateway: route content analysis to specialist models
"""

from __future__ import annotations

import hashlib
import json
import logging
import random
import re
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── Enums & Constants ────────────────────────────────────────────────────────

class PlatformType(Enum):
    YOUTUBE = "youtube"
    TWITTER = "twitter"
    TIKTOK = "tiktok"
    INSTAGRAM = "instagram"
    RSS = "rss"
    NEWS = "news"
    ALL = "all"


class ContentType(Enum):
    TEXT = "text"
    IMAGE = "image"
    VIDEO = "video"
    LINK = "link"
    POLL = "poll"


class PublishStatus(Enum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    PUBLISHED = "published"
    FAILED = "failed"
    DELETED = "deleted"


# Defaults
MEDIA_FIREWALL_MODE = "deny"
MAX_POST_LENGTH = 280  # Twitter default
RATE_LIMIT_PER_HOUR = 50  # posts per hour max


# ── Dataclasses ──────────────────────────────────────────────────────────────

@dataclass
class MediaCredentials:
    """Platform credentials (in-memory only)."""
    platform: PlatformType
    account_id: str
    api_key_hash: str  # SHA-256
    label: str = ""


@dataclass
class ContentPost:
    """A piece of content to publish."""
    post_id: str = field(default_factory=lambda: f"post_{uuid.uuid4().hex[:12]}")
    platform: PlatformType = PlatformType.TWITTER
    content_type: ContentType = ContentType.TEXT
    text: str = ""
    media_urls: List[str] = field(default_factory=list)
    scheduled_at: Optional[str] = None
    status: PublishStatus = PublishStatus.DRAFT
    source_agent: str = ""
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    published_at: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> Tuple[bool, str]:
        """Validate content before publishing."""
        if not self.text and not self.media_urls:
            return False, "Content must have text or media"
        if self.platform == PlatformType.TWITTER and len(self.text) > MAX_POST_LENGTH:
            return False, f"Text exceeds {MAX_POST_LENGTH} characters"
        return True, "valid"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PublishResult:
    """Result of publishing content to a platform."""
    post_id: str
    status: str  # published | failed | scheduled
    platform_post_id: str = ""
    platform_url: str = ""
    error: Optional[str] = None
    latency_ms: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ContentAnalysis:
    """Analysis result of content."""
    analysis_id: str = field(default_factory=lambda: f"ana_{uuid.uuid4().hex[:12]}")
    text: str = ""
    sentiment: float = 0.0  # -1.0 to 1.0
    topics: List[str] = field(default_factory=list)
    entities: List[str] = field(default_factory=list)
    language: str = ""
    toxicity: float = 0.0
    summary: str = ""
    model_used: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TrendSnapshot:
    """A trending topic across platforms."""
    trend_id: str = field(default_factory=lambda: f"trend_{uuid.uuid4().hex[:8]}")
    keyword: str = ""
    platform: PlatformType = PlatformType.ALL
    volume: int = 0
    velocity: float = 0.0  # change per hour
    sentiment: float = 0.0
    related_topics: List[str] = field(default_factory=list)
    detected_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── Platform Firewall ────────────────────────────────────────────────────────

class MediaFirewall:
    """
    Controls which platforms and content types are allowed.
    QVAC-inspired: deny-by-default, explicit allow for each platform.
    """

    def __init__(self, mode: str = MEDIA_FIREWALL_MODE):
        self._mode = mode
        self._allow_platforms: Set[PlatformType] = set()
        self._deny_platforms: Set[PlatformType] = set()
        self._allow_content_types: Set[ContentType] = set()
        self._lock = threading.RLock()

    def allow_platform(self, platform: PlatformType) -> None:
        with self._lock:
            self._allow_platforms.add(platform)

    def deny_platform(self, platform: PlatformType) -> None:
        with self._lock:
            self._deny_platforms.add(platform)

    def is_publishing_allowed(self, platform: PlatformType, content_type: ContentType) -> Tuple[bool, str]:
        with self._lock:
            if platform in self._deny_platforms:
                return False, f"Platform {platform.value} is denied"
            if self._mode == "deny" and platform not in self._allow_platforms:
                return False, f"Platform {platform.value} not in allow list"
            if self._allow_content_types and content_type not in self._allow_content_types:
                if self._mode == "deny":
                    return False, f"Content type {content_type.value} not allowed"
            return True, "allowed"

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "mode": self._mode,
                "allowed_platforms": [p.value for p in self._allow_platforms],
                "denied_platforms": [p.value for p in self._deny_platforms],
                "allowed_content_types": [c.value for c in self._allow_content_types],
            }


# ── Media Bridge (Main Organ) ────────────────────────────────────────────────

class MediaBridge:
    """
    Media Bridge — Multi-Platform Content Organ.

    Provides unified access to YouTube, Twitter, TikTok, Instagram, RSS/news.
    """

    _instance: Optional["MediaBridge"] = None
    _lock = threading.Lock()

    def __init__(
        self,
        organ_id: str = "media",
        firewall_mode: str = MEDIA_FIREWALL_MODE,
        dry_run: bool = True,
    ):
        self.organ_id = organ_id
        self._dry_run = dry_run
        self._lock = threading.RLock()
        self._start_time = time.time()
        self._healthy = True

        # Firewall
        self.firewall = MediaFirewall(mode=firewall_mode)

        # Credentials store
        self._credentials: Dict[str, MediaCredentials] = {}

        # Publishing queue
        self._publish_queue: List[ContentPost] = []
        self._publish_history: List[Dict] = []
        self._max_history = 500

        # Rate limiting per platform
        self._rate_limits: Dict[str, List[float]] = {}  # platform → timestamps
        self._rate_limit_per_hour = RATE_LIMIT_PER_HOUR

        # Trend tracking
        self._trends: List[TrendSnapshot] = []

        # Stats
        self._stats = {
            "posts_published": 0,
            "posts_scheduled": 0,
            "posts_failed": 0,
            "analyses_performed": 0,
            "trends_detected": 0,
            "accounts_connected": 0,
        }

        logger.info("[Media] Bridge initialized  organ=%s  dry_run=%s  firewall=%s",
                    organ_id, dry_run, firewall_mode)

    @classmethod
    def get_instance(
        cls,
        organ_id: str = "media",
        firewall_mode: str = MEDIA_FIREWALL_MODE,
        dry_run: bool = True,
    ) -> "MediaBridge":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls(
                        organ_id=organ_id,
                        firewall_mode=firewall_mode,
                        dry_run=dry_run,
                    )
        return cls._instance

    # ── Publishing ──────────────────────────────────────────────────────────

    def publish(self, post: ContentPost) -> PublishResult:
        """Publish content to a platform."""
        # Validate
        valid, msg = post.validate()
        if not valid:
            return PublishResult(post_id=post.post_id, status="failed", error=msg)

        # Firewall
        allowed, reason = self.firewall.is_publishing_allowed(post.platform, post.content_type)
        if not allowed:
            self._stats["posts_failed"] += 1
            return PublishResult(post_id=post.post_id, status="failed", error=reason)

        # Rate limit
        if not self._check_rate_limit(post.platform):
            self._stats["posts_failed"] += 1
            return PublishResult(post_id=post.post_id, status="failed", error="Rate limit exceeded")

        # Schedule check
        if post.scheduled_at:
            post.status = PublishStatus.SCHEDULED
            self._stats["posts_scheduled"] += 1
            self._publish_queue.append(post)
            return PublishResult(post_id=post.post_id, status="scheduled")

        # Dry-run
        if self._dry_run:
            post.status = PublishStatus.PUBLISHED
            self._stats["posts_published"] += 1
            logger.info("[Media] Dry-run: would publish to %s: %s",
                        post.platform.value, post.text[:50])
            return PublishResult(
                post_id=post.post_id,
                status="simulated",
                platform_post_id=f"sim_{uuid.uuid4().hex[:8]}",
                metadata={"dry_run": True},
            )

        # Publish (simulated)
        post.status = PublishStatus.PUBLISHED
        post.published_at = datetime.now(timezone.utc).isoformat()
        self._stats["posts_published"] += 1

        result = PublishResult(
            post_id=post.post_id,
            status="published",
            platform_post_id=f"pub_{uuid.uuid4().hex[:12]}",
            platform_url=f"https://{post.platform.value}.com/post/{uuid.uuid4().hex[:8]}",
            latency_ms=random.uniform(100, 500),
        )

        self._log_publish(post, result)
        return result

    def _check_rate_limit(self, platform: PlatformType) -> bool:
        now = time.time()
        key = platform.value
        with self._lock:
            if key not in self._rate_limits:
                self._rate_limits[key] = []
            # Clean old entries (older than 1 hour)
            self._rate_limits[key] = [t for t in self._rate_limits[key] if now - t < 3600]
            if len(self._rate_limits[key]) >= self._rate_limit_per_hour:
                return False
            self._rate_limits[key].append(now)
            return True

    def _log_publish(self, post: ContentPost, result: PublishResult) -> None:
        entry = {
            "post": post.to_dict(),
            "result": result.to_dict(),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._publish_history.append(entry)
        if len(self._publish_history) > self._max_history:
            self._publish_history.pop(0)

    # ── Content Analysis ────────────────────────────────────────────────────

    def analyze_content(self, text: str) -> ContentAnalysis:
        """Analyze content for sentiment, topics, entities, toxicity."""
        analysis = ContentAnalysis(text=text)

        # Sentiment (simple keyword-based)
        positive_words = {"good", "great", "excellent", "amazing", "love", "awesome", "fantastic"}
        negative_words = {"bad", "terrible", "awful", "hate", "horrible", "worst", "poor"}
        words = set(text.lower().split())
        pos_count = len(words & positive_words)
        neg_count = len(words & negative_words)
        total = pos_count + neg_count
        analysis.sentiment = round((pos_count - neg_count) / max(total, 1), 2)

        # Topic extraction (simple noun-phrase detection)
        topics = re.findall(r'#(\w+)', text)
        analysis.topics = topics[:5]

        # Language detection (simple)
        analysis.language = "en"

        # Toxicity (simple word-based)
        toxic_words = {"spam", "scam", "fraud", "abuse"}
        toxic_count = len(words & toxic_words)
        analysis.toxicity = round(min(toxic_count / 5.0, 1.0), 2)

        # Summary (first sentence)
        sentences = text.split(".")
        analysis.summary = sentences[0][:100] if sentences else text[:100]

        analysis.model_used = "simp-media-analyzer"
        self._stats["analyses_performed"] += 1

        return analysis

    # ── Trend Detection ─────────────────────────────────────────────────────

    def detect_trends(self, platform: Optional[PlatformType] = None) -> List[TrendSnapshot]:
        """Detect trending topics (simulated)."""
        sample_trends = [
            TrendSnapshot(keyword="AI Agents", volume=12500, velocity=3.5, sentiment=0.7, platform=PlatformType.TWITTER),
            TrendSnapshot(keyword="DeFi Summer", volume=8900, velocity=2.1, sentiment=0.4, platform=PlatformType.TWITTER),
            TrendSnapshot(keyword="Quantum Computing", volume=5600, velocity=1.8, sentiment=0.6, platform=PlatformType.ALL),
            TrendSnapshot(keyword="P2P AI", volume=3200, velocity=4.2, sentiment=0.8, platform=PlatformType.TWITTER),
            TrendSnapshot(keyword="SIMP Protocol", volume=1500, velocity=0.5, sentiment=0.9, platform=PlatformType.ALL),
        ]

        if platform:
            trends = [t for t in sample_trends if t.platform == platform or t.platform == PlatformType.ALL]
        else:
            trends = sample_trends

        with self._lock:
            self._trends = trends
            self._stats["trends_detected"] = len(trends)

        return trends

    # ── Account Management ──────────────────────────────────────────────────

    def connect_account(self, platform: PlatformType, account_id: str, api_key: str) -> bool:
        """Connect a platform account (credential storage)."""
        creds = MediaCredentials(
            platform=platform,
            account_id=account_id,
            api_key_hash=hashlib.sha256(api_key.encode()).hexdigest(),
        )
        with self._lock:
            key = f"{platform.value}:{account_id}"
            self._credentials[key] = creds
            self._stats["accounts_connected"] = len(self._credentials)
            logger.info("[Media] Connected account: %s/%s", platform.value, account_id)
        return True

    # ── Capabilities ────────────────────────────────────────────────────────

    def get_capabilities(self) -> List[Dict[str, Any]]:
        return [
            {
                "id": f"{self.organ_id}:publish",
                "name": "content_publishing",
                "description": "Publish content to social media platforms",
                "intent_types": ["publish_intent", "content_intent", "post_intent"],
                "platforms": [p.value for p in PlatformType],
                "firewall_protected": True,
            },
            {
                "id": f"{self.organ_id}:analyze",
                "name": "content_analysis",
                "description": "Analyze content for sentiment, topics, entities, toxicity",
                "intent_types": ["analyze_intent", "content_analysis_intent"],
            },
            {
                "id": f"{self.organ_id}:trends",
                "name": "trend_detection",
                "description": "Detect trending topics across platforms",
                "intent_types": ["trend_intent", "trend_detect_intent"],
            },
        ]

    def handle_intent(self, intent_type: str, payload: Dict[str, Any], source_agent: str) -> Dict[str, Any]:
        handlers = {
            "publish_intent": self._handle_publish_intent,
            "content_intent": self._handle_publish_intent,
            "post_intent": self._handle_publish_intent,
            "analyze_intent": self._handle_analyze_intent,
            "content_analysis_intent": self._handle_analyze_intent,
            "trend_intent": self._handle_trend_intent,
            "trend_detect_intent": self._handle_trend_intent,
        }
        handler = handlers.get(intent_type)
        if not handler:
            return {"status": "error", "error": f"Unknown intent: {intent_type}"}
        return handler(payload, source_agent)

    def _handle_publish_intent(self, payload: Dict, source: str) -> Dict:
        platform_str = payload.get("platform", "twitter")
        text = payload.get("text", "")
        content_type_str = payload.get("content_type", "text")

        try:
            platform = PlatformType(platform_str)
            content_type = ContentType(content_type_str)
        except ValueError:
            return {"status": "error", "error": f"Invalid platform/type: {platform_str}/{content_type_str}"}

        post = ContentPost(
            platform=platform,
            content_type=content_type,
            text=text,
            source_agent=source,
        )
        result = self.publish(post)
        return {"status": result.status, "result": result.to_dict()}

    def _handle_analyze_intent(self, payload: Dict, source: str) -> Dict:
        text = payload.get("text", "")
        analysis = self.analyze_content(text)
        return {"status": "ok", "analysis": analysis.to_dict()}

    def _handle_trend_intent(self, payload: Dict, source: str) -> Dict:
        platform_str = payload.get("platform", "all")
        platform = None
        if platform_str != "all":
            try:
                platform = PlatformType(platform_str)
            except ValueError:
                pass
        trends = self.detect_trends(platform)
        return {"status": "ok", "trends": [t.to_dict() for t in trends[:10]]}

    # ── Health ──────────────────────────────────────────────────────────────

    def health_check(self) -> Dict[str, Any]:
        uptime = time.time() - self._start_time
        return {
            "organ_id": self.organ_id,
            "healthy": self._healthy,
            "uptime_seconds": round(uptime, 1),
            "dry_run": self._dry_run,
            "firewall": self.firewall.to_dict(),
            "accounts_connected": self._stats["accounts_connected"],
            "stats": self._stats,
        }

    def get_status(self) -> Dict[str, Any]:
        return self.health_check()


# ── Module Singleton ─────────────────────────────────────────────────────────

MEDIA_BRIDGE = MediaBridge.get_instance()
