"""
Federation Protocol — T62: Cross-Mesh Federation (Mesh-of-Meshes)

Enables multiple SIMP mesh instances to federate — agents from Mesh A can send
intents to agents in Mesh B, with trust established via the federation handshake.
"""
import asyncio
import json
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from simp.mesh.https_bridge import HTTPSBridge


class MeshConnectionState(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    HANDSHAKE_SENT = "handshake_sent"
    HANDSHAKE_RECEIVED = "handshake_received"
    CONNECTED = "connected"
    FAILED = "failed"


@dataclass
class MeshPeer:
    """Represents a remote mesh instance in the federation."""
    mesh_id: str
    display_name: str
    endpoint: str  # Base HTTPS URL of remote mesh
    connection_state: MeshConnectionState = MeshConnectionState.DISCONNECTED
    connected_at: Optional[float] = None
    last_seen: Optional[float] = None
    latency_ms: Optional[float] = None
    agent_count: int = 0
    collective_trust_score: float = 3.0  # Aggregated from participating agents
    capabilities: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FederationHandshake:
    """A federation handshake record between two meshes."""
    local_mesh_id: str
    remote_mesh_id: str
    initiated_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    secret_token: Optional[str] = None
    accepted: bool = False
    rejection_reason: Optional[str] = None


@dataclass
class CrossMeshPacket:
    """A packet tunneling through the federation."""
    source_mesh: str
    source_agent: str
    dest_mesh: str
    dest_agent: str
    intent_type: str
    payload: Dict[str, Any]
    correlation_id: Optional[str] = None
    ttl_seconds: float = 30.0
    packet_id: str = field(default_factory=lambda: uuid.uuid4().hex)


class FederationProtocol:
    """
    Manages mesh-of-meshes federation.

    Flow:
    1. Mesh A → Mesh B: HELLO {mesh_id, agent_card, trust_score}
    2. Mesh B → Mesh A: ACCEPT/REJECT {peer_mesh_id, capabilities}
    3. Both sides commit peer to TrustGraph
    4. Cross-mesh intents tunneled via HTTPS bridge
    """

    def __init__(self, https_bridge: Optional["HTTPSBridge"] = None):
        self._https_bridge = https_bridge
        self._mesh_id = f"mesh_{uuid.uuid4().hex[:8]}"
        self._peers: Dict[str, MeshPeer] = {}
        self._handshakes: Dict[str, FederationHandshake] = {}
        self._stats: Dict[str, int] = {
            "handshakes_initiated": 0,
            "handshakes_completed": 0,
            "cross_mesh_packets_sent": 0,
            "cross_mesh_packets_received": 0,
            "rejected_connections": 0,
        }
        self._lock = threading.RLock()

    def get_mesh_id(self) -> str:
        return self._mesh_id

    def set_https_bridge(self, bridge: "HTTPSBridge") -> None:
        self._https_bridge = bridge

    def initiate_handshake(self, remote_endpoint: str, display_name: str = "") -> str:
        """Initiate a federation handshake with a remote mesh."""
        handshake_id = uuid.uuid4().hex

        with self._lock:
            # Check if already connected or handshaking
            for peer in self._peers.values():
                if peer.endpoint == remote_endpoint:
                    if peer.connection_state == MeshConnectionState.CONNECTED:
                        return peer.mesh_id
                    if peer.connection_state in (MeshConnectionState.CONNECTING,
                                                   MeshConnectionState.HANDSHAKE_SENT):
                        return peer.mesh_id

            peer = MeshPeer(
                mesh_id=handshake_id,
                display_name=display_name or remote_endpoint,
                endpoint=remote_endpoint,
                connection_state=MeshConnectionState.CONNECTING,
            )
            self._peers[handshake_id] = peer
            self._stats["handshakes_initiated"] += 1

            hs = FederationHandshake(
                local_mesh_id=self._mesh_id,
                remote_mesh_id=handshake_id,
            )
            self._handshakes[handshake_id] = hs

        return handshake_id

    def complete_handshake(self, peer_mesh_id: str, accepted: bool,
                          secret_token: Optional[str] = None,
                          rejection_reason: Optional[str] = None) -> bool:
        """Complete a handshake initiated by the remote mesh."""
        with self._lock:
            if peer_mesh_id not in self._peers:
                return False

            peer = self._peers[peer_mesh_id]

            if accepted:
                peer.connection_state = MeshConnectionState.CONNECTED
                peer.connected_at = time.time()
                self._stats["handshakes_completed"] += 1
                if peer_mesh_id in self._handshakes:
                    self._handshakes[peer_mesh_id].completed_at = time.time()
                    self._handshakes[peer_mesh_id].secret_token = secret_token
                    self._handshakes[peer_mesh_id].accepted = True
            else:
                peer.connection_state = MeshConnectionState.FAILED
                self._stats["rejected_connections"] += 1
                if peer_mesh_id in self._handshakes:
                    self._handshakes[peer_mesh_id].rejection_reason = rejection_reason

            return accepted

    def send_cross_mesh_intent(self, dest_mesh: str, dest_agent: str,
                                intent_type: str, payload: Dict[str, Any],
                                correlation_id: Optional[str] = None) -> Optional[str]:
        """Send an intent to an agent in a remote mesh."""
        with self._lock:
            peer = self._peers.get(dest_mesh)
            if not peer or peer.connection_state != MeshConnectionState.CONNECTED:
                return None

        packet = CrossMeshPacket(
            source_mesh=self._mesh_id,
            source_agent="local",
            dest_mesh=dest_mesh,
            dest_agent=dest_agent,
            intent_type=intent_type,
            payload=payload,
            correlation_id=correlation_id,
        )
        with self._lock:
            self._stats["cross_mesh_packets_sent"] += 1

        if self._https_bridge is not None:
            try:
                tunnel_payload = {
                    "packet_id": packet.packet_id,
                    "source_mesh": packet.source_mesh,
                    "source_agent": packet.source_agent,
                    "dest_agent": packet.dest_agent,
                    "intent_type": packet.intent_type,
                    "payload": packet.payload,
                    "correlation_id": packet.correlation_id,
                    "timestamp": time.time(),
                }
                # Actual transport would go through https_bridge here
            except Exception:
                pass

        return packet.packet_id

    def receive_cross_mesh_packet(self, payload: Dict[str, Any]) -> Optional[CrossMeshPacket]:
        """Reconstruct a CrossMeshPacket from a tunneled payload."""
        try:
            packet = CrossMeshPacket(
                source_mesh=payload["source_mesh"],
                source_agent=payload["source_agent"],
                dest_mesh=self._mesh_id,
                dest_agent=payload["dest_agent"],
                intent_type=payload["intent_type"],
                payload=payload["payload"],
                correlation_id=payload.get("correlation_id"),
                packet_id=payload.get("packet_id", uuid.uuid4().hex),
            )
            with self._lock:
                self._stats["cross_mesh_packets_received"] += 1
            return packet
        except (KeyError, TypeError):
            return None

    def get_peer(self, mesh_id: str) -> Optional[MeshPeer]:
        return self._peers.get(mesh_id)

    def get_all_peers(self) -> List[MeshPeer]:
        return list(self._peers.values())

    def get_connected_peers(self) -> List[MeshPeer]:
        return [p for p in self._peers.values()
                if p.connection_state == MeshConnectionState.CONNECTED]

    def get_stats(self) -> Dict[str, int]:
        return dict(self._stats)


_federation_protocol: Optional[FederationProtocol] = None


def get_federation_protocol() -> FederationProtocol:
    global _federation_protocol
    if _federation_protocol is None:
        _federation_protocol = FederationProtocol()
    return _federation_protocol
