#!/usr/bin/env python3
"""
ExperienceCollector — SIMP Mesh Experience & Outcome Tracker
============================================================
Thread-safe singleton that captures every model interaction with reward signals.

Captures:
  - Legal contract analysis outcomes
  - BRP threat evaluations
  - Trading signal results
  - Orchestration decisions

Design: 10k ring buffer in memory + periodic SQLite flush.

Usage:
    from simp.mesh.experience_collector import get_experience_collector, Experience

    ec = get_experience_collector()
    ec.record(Experience(
        query_id="q-001",
        agent_id="alpha-goose",
        intent_type="legal",
        model_key="legal",
        prompt="Analyze SAFE agreement...",
        response_text="...",
        outcome="success",
        reward_signal=0.8,
        latency_ms=1234.5,
        confidence=0.92,
        timestamp=time.time(),
        metadata={},
    ))
    stats = ec.get_outcome_stats("legal")
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from collections import deque
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

RING_BUFFER_SIZE = 10_000
SQLITE_PATH = Path(__file__).resolve().parent.parent.parent / "data" / "experience.db"
SQLITE_FLUSH_INTERVAL = 60  # seconds between SQLite flushes
SQLITE_BATCH_SIZE = 100     # rows per flush


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

class Outcome(str, Enum):
    """Outcome labels for model interactions."""
    SUCCESS = "success"
    FAILURE = "failure"
    ESCALATED = "escalated"


@dataclass
class Experience:
    """
    A single model interaction with outcome and reward signal.

    Attributes:
        query_id: Unique identifier for this query (UUID string)
        agent_id: ID of the agent that initiated the request
        intent_type: Intent category (legal, threat, trading, orchestration)
        model_key: Specific model key used (legal, threat, trading, orchestration)
        prompt: The input prompt text
        response_text: The model's response text
        outcome: "success" | "failure" | "escalated"
        reward_signal: float from -1.0 (catastrophic) to 1.0 (ideal), derived from outcome
        latency_ms: Model inference latency in milliseconds
        confidence: Model confidence score (0.0–1.0)
        timestamp: Unix timestamp when the experience was recorded
        metadata: Additional context (threat_level, P&L, contract_id, etc.)
    """
    query_id: str
    agent_id: str
    intent_type: str
    model_key: str
    prompt: str
    response_text: str
    outcome: str  # "success" | "failure" | "escalated"
    reward_signal: float
    latency_ms: float
    confidence: float
    timestamp: float
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.query_id:
            self.query_id = str(uuid.uuid4())
        if self.outcome not in ("success", "failure", "escalated"):
            # Auto-correct raw outcome values
            pass

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        # Serialize metadata
        d["metadata"] = json.dumps(d["metadata"], default=str)
        return d

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "Experience":
        d = dict(d)
        if isinstance(d.get("metadata"), str):
            d["metadata"] = json.loads(d["metadata"])
        return Experience(**d)


# ---------------------------------------------------------------------------
# Outcome → Reward Signal mapping
# ---------------------------------------------------------------------------

def compute_reward(outcome: str, metadata: Optional[Dict[str, Any]] = None) -> float:
    """
    Derive a reward signal from outcome and metadata.

    Base mappings:
      success  → +1.0
      failure  → -0.5
      escalated → 0.0

    Overrides from metadata:
      - threat_level (critical=+0.5 boost, high=+0.25)
      - signed_contract: True → +1.0 bonus
      - P&L_delta: positive → scale reward up to +1.5
      - P&L_delta: negative → scale reward down to -1.5
    """
    base: Dict[str, float] = {
        Outcome.SUCCESS: 1.0,
        Outcome.FAILURE: -0.5,
        Outcome.ESCALATED: 0.0,
    }
    signal = base.get(outcome, 0.0)

    if metadata:
        threat_level = metadata.get("threat_level", "").lower()
        if threat_level in ("critical", "high"):
            signal += 0.25
        signed = metadata.get("signed_contract", False)
        if signed:
            signal += 1.0
        pl = metadata.get("P&L_delta")
        if pl is not None:
            try:
                pl_val = float(pl)
                signal += max(-0.5, min(0.5, pl_val / 10000.0))
            except (TypeError, ValueError):
                pass

    return max(-1.0, min(1.5, signal))


# ---------------------------------------------------------------------------
# ExperienceCollector
# ---------------------------------------------------------------------------

class ExperienceCollector:
    """
    Thread-safe singleton that stores model interaction experiences.

    Architecture:
      - Ring buffer (deque): last RING_BUFFER_SIZE experiences in memory
      - SQLite: persistent long-term storage, flushed periodically
      - Flush triggers: interval-based (every SQLITE_FLUSH_INTERVAL seconds)
        OR when buffer exceeds SQLITE_BATCH_SIZE pending records

    Thread-safety: all public methods acquire self._lock.
    """

    def __init__(
        self,
        sqlite_path: Optional[str] = None,
        ring_buffer_size: int = RING_BUFFER_SIZE,
        flush_interval: int = SQLITE_FLUSH_INTERVAL,
        batch_size: int = SQLITE_BATCH_SIZE,
    ) -> None:
        self._lock = threading.RLock()
        self._ring: Deque[Experience] = deque(maxlen=ring_buffer_size)
        self._pending_flush: List[Experience] = []
        self._last_flush_time = time.monotonic()
        self._flush_interval = flush_interval
        self._batch_size = batch_size

        # SQLite setup
        if sqlite_path:
            self._db_path = Path(sqlite_path)
        else:
            self._db_path = SQLITE_PATH
        self._init_sqlite()

        # Background flush timer
        self._shutdown = threading.Event()
        self._flush_thread: Optional[threading.Thread] = None

    # -------------------------------------------------------------------------
    # SQLite init
    # -------------------------------------------------------------------------

    def _init_sqlite(self) -> None:
        """Create the experiences table if it doesn't exist."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS experiences (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                query_id        TEXT NOT NULL,
                agent_id        TEXT NOT NULL,
                intent_type     TEXT NOT NULL,
                model_key       TEXT NOT NULL,
                prompt          TEXT NOT NULL,
                response_text   TEXT NOT NULL,
                outcome         TEXT NOT NULL,
                reward_signal   REAL NOT NULL,
                latency_ms      REAL NOT NULL,
                confidence      REAL NOT NULL,
                timestamp       REAL NOT NULL,
                metadata        TEXT NOT NULL,
                created_at      TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_model_key ON experiences(model_key)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_timestamp ON experiences(timestamp)
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_outcome ON experiences(outcome)
        """)
        conn.commit()
        conn.close()
        logger.info("[ExperienceCollector] SQLite initialized at %s", self._db_path)

    # -------------------------------------------------------------------------
    # record
    # -------------------------------------------------------------------------

    def record(self, experience: Experience) -> str:
        """
        Record a model interaction experience.

        Stores in ring buffer immediately. Batches for SQLite flush.

        Args:
            experience: The Experience dataclass to record.

        Returns:
            The query_id of the recorded experience.
        """
        with self._lock:
            self._ring.append(experience)
            self._pending_flush.append(experience)

            # Check if we should flush to SQLite
            should_flush = (
                len(self._pending_flush) >= self._batch_size
                or (time.monotonic() - self._last_flush_time) >= self._flush_interval
            )
            if should_flush:
                self._flush_sqlite_locked()

        return experience.query_id

    # -------------------------------------------------------------------------
    # retrieve
    # -------------------------------------------------------------------------

    def get_experiences(
        self,
        model_key: str,
        limit: int = 1000,
        outcome: Optional[str] = None,
    ) -> List[Experience]:
        """
        Retrieve experiences for a given model key.

        Args:
            model_key: Filter by model key (legal, threat, trading, orchestration)
            limit: Maximum number of experiences to return
            outcome: Optional filter by outcome ("success", "failure", "escalated")

        Returns:
            List of Experience objects (most recent first).
        """
        with self._lock:
            results = [
                e for e in reversed(self._ring)
                if e.model_key == model_key
                and (outcome is None or e.outcome == outcome)
            ]
            return results[:limit]

    def get_recent(self, limit: int = 100) -> List[Experience]:
        """
        Return the most recent *limit* experiences for debugging.

        Returns:
            List of Experience objects (most recent last).
        """
        with self._lock:
            return list(self._ring)[-limit:]

    def get_outcome_stats(self, model_key: str) -> Dict[str, Any]:
        """
        Compute aggregated outcome statistics for a model key.

        Returns:
            Dict with success_rate, avg_reward, total_count, failure_count,
            escalated_count, avg_latency_ms, avg_confidence.
        """
        with self._lock:
            exps = [e for e in self._ring if e.model_key == model_key]

        if not exps:
            return {
                "model_key": model_key,
                "total_count": 0,
                "success_count": 0,
                "failure_count": 0,
                "escalated_count": 0,
                "success_rate": 0.0,
                "avg_reward": 0.0,
                "avg_latency_ms": 0.0,
                "avg_confidence": 0.0,
            }

        total = len(exps)
        successes = sum(1 for e in exps if e.outcome == "success")
        failures = sum(1 for e in exps if e.outcome == "failure")
        escalations = sum(1 for e in exps if e.outcome == "escalated")

        rewards = [e.reward_signal for e in exps]
        latencies = [e.latency_ms for e in exps]
        confidences = [e.confidence for e in exps]

        return {
            "model_key": model_key,
            "total_count": total,
            "success_count": successes,
            "failure_count": failures,
            "escalated_count": escalations,
            "success_rate": round(successes / total, 4) if total > 0 else 0.0,
            "avg_reward": round(sum(rewards) / len(rewards), 4) if rewards else 0.0,
            "avg_latency_ms": round(sum(latencies) / len(latencies), 1) if latencies else 0.0,
            "avg_confidence": round(sum(confidences) / len(confidences), 4) if confidences else 0.0,
        }

    # -------------------------------------------------------------------------
    # SQLITE flush (internal)
    # -------------------------------------------------------------------------

    def _flush_sqlite_locked(self) -> None:
        """Flush pending experiences to SQLite. Must be called with _lock held."""
        if not self._pending_flush:
            return

        rows_to_write = self._pending_flush[:]
        self._pending_flush.clear()
        self._last_flush_time = time.monotonic()

        try:
            conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
            conn.executemany(
                """
                INSERT INTO experiences (
                    query_id, agent_id, intent_type, model_key,
                    prompt, response_text, outcome, reward_signal,
                    latency_ms, confidence, timestamp, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [tuple(exp.to_dict().values()) for exp in rows_to_write],
            )
            conn.commit()
            conn.close()
            logger.debug(
                "[ExperienceCollector] Flushed %d experiences to SQLite",
                len(rows_to_write),
            )
        except Exception as exc:
            logger.error("[ExperienceCollector] SQLite flush failed: %s", exc)
            # Re-queue failed rows back to pending (at front, avoid infinite loop)
            self._pending_flush = rows_to_write + self._pending_flush

    # -------------------------------------------------------------------------
    # periodic flush
    # -------------------------------------------------------------------------

    def start_periodic_flush(self) -> None:
        """Start a background thread that flushes to SQLite periodically."""
        if self._flush_thread is not None:
            return

        def flush_loop() -> None:
            while not self._shutdown.is_set():
                self._shutdown.wait(timeout=self._flush_interval)
                if self._shutdown.is_set():
                    break
                with self._lock:
                    self._flush_sqlite_locked()

        self._flush_thread = threading.Thread(target=flush_loop, daemon=True)
        self._flush_thread.start()
        logger.info("[ExperienceCollector] Periodic flush started (interval=%ds)", self._flush_interval)

    def flush(self) -> int:
        """
        Force an immediate flush to SQLite. Returns number of rows flushed.

        Returns:
            Number of experiences written to SQLite.
        """
        with self._lock:
            count = len(self._pending_flush)
            self._flush_sqlite_locked()
            return count

    def shutdown(self) -> None:
        """Stop the background flush thread and flush remaining records."""
        self._shutdown.set()
        if self._flush_thread is not None:
            self._flush_thread.join(timeout=5.0)
        with self._lock:
            self._flush_sqlite_locked()
        logger.info("[ExperienceCollector] shutdown complete")

    # -------------------------------------------------------------------------
    # persistence helpers
    # -------------------------------------------------------------------------

    def replay_from_sqlite(self, model_key: Optional[str] = None, limit: int = 5000) -> int:
        """
        Load experiences from SQLite into the ring buffer.

        Args:
            model_key: Optional filter — only load experiences for this model_key
            limit: Maximum rows to load (oldest first)

        Returns:
            Number of rows loaded into the ring buffer.
        """
        with self._lock:
            conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
            if model_key:
                rows = conn.execute(
                    """
                    SELECT * FROM experiences
                    WHERE model_key = ?
                    ORDER BY timestamp ASC
                    LIMIT ?
                    """,
                    (model_key, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM experiences ORDER BY timestamp ASC LIMIT ?",
                    (limit,),
                ).fetchall()
            conn.close()

            count = 0
            for row in rows:
                try:
                    # Map row to Experience (id is first col)
                    d = {
                        "query_id": row[1],
                        "agent_id": row[2],
                        "intent_type": row[3],
                        "model_key": row[4],
                        "prompt": row[5],
                        "response_text": row[6],
                        "outcome": row[7],
                        "reward_signal": row[8],
                        "latency_ms": row[9],
                        "confidence": row[10],
                        "timestamp": row[11],
                        "metadata": row[12],
                    }
                    exp = Experience.from_dict(d)
                    self._ring.append(exp)
                    count += 1
                except Exception as exc:
                    logger.warning("[ExperienceCollector] replay skipped row: %s", exc)

            logger.info("[ExperienceCollector] Replayed %d experiences from SQLite", count)
            return count


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_collector_instance: Optional[ExperienceCollector] = None
_collector_lock = threading.Lock()


def get_experience_collector() -> ExperienceCollector:
    """Return the process-level ExperienceCollector singleton."""
    global _collector_instance
    with _collector_lock:
        if _collector_instance is None:
            _collector_instance = ExperienceCollector()
            _collector_instance.start_periodic_flush()
    return _collector_instance