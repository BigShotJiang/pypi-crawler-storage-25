"""
Quantum State Vector Broadcasting — T66

Broadcasts quantum execution results (state vectors, expectation values, measurement
counts) to the mesh so multiple agents can observe and collapse the superposition.
"""
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from simp.mesh.enhanced_bus import EnhancedMeshBus


@dataclass
class QuantumResultPayload:
    """A quantum execution result ready for mesh broadcast."""
    circuit_id: str
    circuit_design: Dict[str, Any]  # Gate sequence, parameters
    state_vector: List[complex]  # Complex amplitude array
    expectation_values: Dict[str, float]  # observable → value
    measurement_counts: Dict[str, int]  # outcome → shots
    source_agent_id: str
    backend: str  # "ibm_quantum" | "pennylane" | "local_simulator"
    num_qubits: int
    num_shots: int
    execution_time_ms: float
    created_at: float = field(default_factory=time.time)
    result_id: str = field(default_factory=lambda: __import__("uuid").uuid4().hex)


@dataclass
class ObserverCollapse:
    """Records how a single agent collapsed a quantum superposition."""
    agent_id: str
    preferred_outcome: str
    collapse_weight: float  # Based on trust score
    observed_at: float = field(default_factory=time.time)


@dataclass
class QuantumResultRecord:
    """Tracks a single quantum result broadcast and its observer collapses."""
    payload: QuantumResultPayload
    observer_collapses: List[ObserverCollapse] = field(default_factory=list)
    consensus_reached: bool = False
    broadcast_at: float = field(default_factory=time.time)


class QuantumResultBroadcaster:
    """
    Broadcasts quantum execution results to the mesh.

    Flow:
    1. QuantumIntelligentAgent → IBMQuantumAdapter.execute_algorithm()
    2. QuantumResultPayload → QuantumResultBroadcaster.broadcast()
    3. Broadcast on quantum_results channel
    4. N agents "observe" → each collapses to preferred outcome
    5. L5 consensus aggregates interpretations weighted by trust score
    """

    def __init__(self, mesh_bus: Optional["EnhancedMeshBus"] = None):
        self._mesh_bus = mesh_bus
        self._broadcast_log: List[QuantumResultRecord] = []
        self._stats: Dict[str, int] = {
            "results_broadcast": 0,
            "observer_observations": 0,
            "consensus_reached": 0,
        }
        self._lock = threading.RLock()

    def set_mesh_bus(self, mesh_bus: "EnhancedMeshBus") -> None:
        self._mesh_bus = mesh_bus

    def broadcast(self, payload: QuantumResultPayload) -> bool:
        """Broadcast a quantum result over the mesh."""
        record = QuantumResultRecord(payload=payload)
        with self._lock:
            self._broadcast_log.append(record)
            self._stats["results_broadcast"] += 1

        if self._mesh_bus is None:
            return True

        try:
            self._mesh_bus.publish(
                channel="quantum_results",
                payload={
                    "result_id": payload.result_id,
                    "circuit_id": payload.circuit_id,
                    "circuit_design": payload.circuit_design,
                    "state_vector": [
                        {"re": c.real, "im": c.imag} for c in payload.state_vector
                    ],
                    "expectation_values": payload.expectation_values,
                    "measurement_counts": payload.measurement_counts,
                    "source_agent_id": payload.source_agent_id,
                    "backend": payload.backend,
                    "num_qubits": payload.num_qubits,
                    "num_shots": payload.num_shots,
                    "execution_time_ms": payload.execution_time_ms,
                    "created_at": payload.created_at,
                },
            )
            return True
        except Exception:
            return False

    def receive_result(self, payload: Dict[str, Any]) -> Optional[QuantumResultPayload]:
        """Reconstruct a QuantumResultPayload from a mesh broadcast."""
        try:
            state_vector = [
                complex(d["re"], d["im"]) for d in payload["state_vector"]
            ]
            return QuantumResultPayload(
                result_id=payload.get("result_id", ""),
                circuit_id=payload["circuit_id"],
                circuit_design=payload["circuit_design"],
                state_vector=state_vector,
                expectation_values=payload["expectation_values"],
                measurement_counts=payload["measurement_counts"],
                source_agent_id=payload["source_agent_id"],
                backend=payload["backend"],
                num_qubits=payload["num_qubits"],
                num_shots=payload["num_shots"],
                execution_time_ms=payload["execution_time_ms"],
                created_at=payload.get("created_at", time.time()),
            )
        except (KeyError, TypeError):
            return None

    def record_observer_collapse(self, result_id: str, agent_id: str,
                                   preferred_outcome: str,
                                   collapse_weight: float) -> None:
        """Record how an agent collapsed a quantum result."""
        with self._lock:
            for record in reversed(self._broadcast_log):
                if record.payload.result_id == result_id:
                    collapse = ObserverCollapse(
                        agent_id=agent_id,
                        preferred_outcome=preferred_outcome,
                        collapse_weight=collapse_weight,
                    )
                    record.observer_collapses.append(collapse)
                    self._stats["observer_observations"] += 1
                    break

    def get_broadcast_log(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [
                {
                    "result_id": r.payload.result_id,
                    "circuit_id": r.payload.circuit_id,
                    "source_agent_id": r.payload.source_agent_id,
                    "observer_count": len(r.observer_collapses),
                    "consensus_reached": r.consensus_reached,
                    "broadcast_at": r.broadcast_at,
                }
                for r in self._broadcast_log
            ]

    def get_stats(self) -> Dict[str, int]:
        return dict(self._stats)


# Singleton
_broadcaster: Optional[QuantumResultBroadcaster] = None


def get_quantum_result_broadcaster() -> QuantumResultBroadcaster:
    global _broadcaster
    if _broadcaster is None:
        _broadcaster = QuantumResultBroadcaster()
    return _broadcaster
