"""
Intent Retry Router — L3 mesh module

Routes intents across brokers with automatic retry and failover.
When a broker fails to process an intent, the retry router selects
the next alternate broker from a pre-configured list.

Design:
- Primary broker attempted first, then alternates in order
- Max retries limits total attempts across all brokers
- Route history tracks every broker tried (success or failure)
- Failure callback selects next alternate automatically
- Thread-safe via RLock for concurrent routing and retry
"""

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class RouteAttempt:
    """Record of a single routing attempt."""
    broker_id: str
    timestamp: float
    success: bool
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "broker_id": self.broker_id,
            "timestamp": self.timestamp,
            "success": self.success,
            "result": self.result,
            "error": self.error,
        }


class RetryExhaustedError(Exception):
    """Raised when all retries have been exhausted."""
    pass


class RetryRouter:
    """Routes intents with automatic retry and broker failover.

    Each intent has a preferred broker. If that broker fails, alternates
    are tried in order until one succeeds or the retry limit is reached.

    Usage:
        router = RetryRouter()
        router.register_broker("broker-alpha", deliver_fn)
        router.register_broker("broker-beta", deliver_fn)

        result = router.route_with_retry(
            intent={"intent_id": "001"},
            preferred_broker="broker-alpha",
            alternate_brokers=["broker-beta", "broker-gamma"],
            max_retries=2,
        )
    """

    def __init__(self):
        self._lock = threading.RLock()

        # Registered brokers: broker_id -> routing function
        # routing_fn signature: (intent: dict) -> dict
        self._brokers: Dict[str, Callable[[Dict[str, Any]], Dict[str, Any]]] = {}

        # Route state: intent_id -> RetryState
        self._routes: Dict[str, "RetryState"] = {}

        # Callbacks
        self._on_failure_callback: Optional[Callable[[str, str], None]] = None
        self._on_success_callback: Optional[Callable[[str, Dict[str, Any]], None]] = None

        # Stats
        self._stats = {
            "routes_initiated": 0,
            "routes_succeeded": 0,
            "routes_failed": 0,
            "retries_attempted": 0,
            "broker_failovers": 0,
        }

        logger.info("RetryRouter initialized")

    # ------------------------------------------------------------------ #
    # Broker Registration
    # ------------------------------------------------------------------ #

    def register_broker(self, broker_id: str,
                        router_fn: Callable[[Dict[str, Any]], Dict[str, Any]]) -> None:
        """Register a broker with its routing function.

        The routing function receives the intent dict and should return
        a result dict on success, or raise an exception on failure.

        Args:
            broker_id: Unique broker identifier.
            router_fn: Callable that takes (intent: dict) -> result: dict.
        """
        with self._lock:
            self._brokers[broker_id] = router_fn
            logger.info("Registered broker %s", broker_id)

    def unregister_broker(self, broker_id: str) -> bool:
        """Remove a broker registration.

        Args:
            broker_id: Broker identifier.

        Returns:
            True if broker was removed, False if not found.
        """
        with self._lock:
            if broker_id not in self._brokers:
                return False
            del self._brokers[broker_id]
            logger.info("Unregistered broker %s", broker_id)
            return True

    def get_registered_brokers(self) -> List[str]:
        """Return list of all registered broker IDs."""
        with self._lock:
            return list(self._brokers.keys())

    # ------------------------------------------------------------------ #
    # Routing with Retry
    # ------------------------------------------------------------------ #

    def route_with_retry(self, intent: Dict[str, Any],
                         preferred_broker: str,
                         alternate_brokers: Optional[List[str]] = None,
                         max_retries: int = 2) -> Dict[str, Any]:
        """Route an intent with automatic retry on failure.

        Tries the preferred_broker first. On failure, tries each
        alternate broker in order until one succeeds or max_retries
        is exhausted.

        Args:
            intent: Intent dict. Must contain 'intent_id'.
            preferred_broker: Primary broker to try first.
            alternate_brokers: List of alternate brokers, tried in order
                               after preferred fails.
            max_retries: Maximum total retry attempts across all brokers.
                         Default 2. (preferred + alternates up to this count)

        Returns:
            Result dict from the successful broker.

        Raises:
            ValueError: If preferred_broker is not registered.
            RetryExhaustedError: If all retries are exhausted with no success.
        """
        intent_id = intent.get("intent_id", str(uuid.uuid4()))
        if alternate_brokers is None:
            alternate_brokers = []

        with self._lock:
            if preferred_broker not in self._brokers:
                raise ValueError(
                    f"Preferred broker '{preferred_broker}' not registered"
                )

            # Create route state
            state = RetryState(
                intent_id=intent_id,
                preferred_broker=preferred_broker,
                alternate_brokers=list(alternate_brokers),
                max_retries=max_retries,
            )
            self._routes[intent_id] = state
            self._stats["routes_initiated"] += 1

        # Build attempt list: preferred first, then alternates
        attempt_brokers = [preferred_broker] + list(alternate_brokers)

        for attempt_index, broker_id in enumerate(attempt_brokers):
            if attempt_index > max_retries:
                break

            # Check if we've exceeded max_retries
            if attempt_index > 0:
                with self._lock:
                    state.retry_count = attempt_index
                    self._stats["retries_attempted"] += 1
                    if attempt_index > 1:
                        self._stats["broker_failovers"] += 1

            try:
                # Attempt delivery
                with self._lock:
                    router_fn = self._brokers.get(broker_id)
                    if router_fn is None:
                        raise ValueError(f"Broker '{broker_id}' not registered")

                result = router_fn(intent)

                # Success
                with self._lock:
                    attempt = RouteAttempt(
                        broker_id=broker_id,
                        timestamp=time.time(),
                        success=True,
                        result=result,
                    )
                    state.attempts.append(attempt)
                    state.successful_broker = broker_id
                    self._stats["routes_succeeded"] += 1

                # Fire success callback
                if self._on_success_callback:
                    try:
                        self._on_success_callback(intent_id, result)
                    except Exception as e:
                        logger.error("on_success callback error: %s", e)

                logger.info("Intent %s succeeded on broker %s "
                            "(attempt %d/%d)",
                            intent_id, broker_id,
                            attempt_index + 1, max_retries + 1)
                return result

            except Exception as e:
                error_msg = str(e)

                # Record failure
                with self._lock:
                    attempt = RouteAttempt(
                        broker_id=broker_id,
                        timestamp=time.time(),
                        success=False,
                        error=error_msg,
                    )
                    state.attempts.append(attempt)
                    state.last_error = error_msg

                # Fire failure callback
                if self._on_failure_callback:
                    try:
                        self._on_failure_callback(intent_id, broker_id)
                    except Exception as exc:
                        logger.error("on_failure callback error: %s", exc)

                logger.warning("Intent %s failed on broker %s "
                               "(attempt %d/%d): %s",
                               intent_id, broker_id,
                               attempt_index + 1, max_retries + 1,
                               error_msg)

                # If this was the last attempt, raise
                if attempt_index >= len(attempt_brokers) - 1 or \
                   attempt_index >= max_retries:
                    with self._lock:
                        self._stats["routes_failed"] += 1
                    raise RetryExhaustedError(
                        f"Intent {intent_id} failed after "
                        f"{attempt_index + 1} attempt(s). "
                        f"Brokers tried: {', '.join(attempt_brokers[:attempt_index + 1])}. "
                        f"Last error: {error_msg}"
                    )

        # Should not reach here, but just in case
        raise RetryExhaustedError(
            f"Intent {intent_id} failed after exhausting retries"
        )

    # ------------------------------------------------------------------ #
    # Callbacks
    # ------------------------------------------------------------------ #

    def on_failure(self,
                   callback: Callable[[str, str], None]) -> None:
        """Register a callback fired when a broker fails.

        The callback receives (intent_id, failed_broker_id).

        Args:
            callback: Function (intent_id: str, failed_broker: str) -> None.
        """
        self._on_failure_callback = callback

    def on_success(self,
                   callback: Callable[[str, Dict[str, Any]], None]) -> None:
        """Register a callback fired on successful delivery.

        The callback receives (intent_id, result_dict).

        Args:
            callback: Function (intent_id: str, result: dict) -> None.
        """
        self._on_success_callback = callback

    # ------------------------------------------------------------------ #
    # Queries
    # ------------------------------------------------------------------ #

    def get_retry_count(self, intent_id: str) -> Optional[int]:
        """Return the number of retries attempted for an intent.

        Args:
            intent_id: Intent identifier.

        Returns:
            Number of retries, or None if intent not tracked.
        """
        with self._lock:
            state = self._routes.get(intent_id)
            if state is None:
                return None
            return state.retry_count

    def get_route_history(self, intent_id: str) -> Optional[List[Dict[str, Any]]]:
        """Return the list of brokers tried for an intent.

        Each entry contains broker_id, success status, timestamp,
        and error (if failed).

        Args:
            intent_id: Intent identifier.

        Returns:
            List of attempt dicts, or None if intent not tracked.
        """
        with self._lock:
            state = self._routes.get(intent_id)
            if state is None:
                return None
            return [a.to_dict() for a in state.attempts]

    def get_route_state(self, intent_id: str) -> Optional[Dict[str, Any]]:
        """Get full routing state for an intent."""
        with self._lock:
            state = self._routes.get(intent_id)
            if state is None:
                return None
            return state.to_dict()

    def get_stats(self) -> Dict[str, Any]:
        """Return retry routing statistics."""
        with self._lock:
            return {
                **dict(self._stats),
                "registered_brokers": len(self._brokers),
                "active_routes": sum(
                    1 for s in self._routes.values()
                    if s.successful_broker is None
                ),
            }

    def clear_history(self) -> int:
        """Clear all route history. Returns count of cleared routes."""
        with self._lock:
            count = len(self._routes)
            self._routes.clear()
            return count


@dataclass
class RetryState:
    """Internal state tracking for a single intent's retry routing."""
    intent_id: str
    preferred_broker: str
    alternate_brokers: List[str]
    max_retries: int
    retry_count: int = 0
    attempts: List[RouteAttempt] = field(default_factory=list)
    successful_broker: Optional[str] = None
    last_error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "intent_id": self.intent_id,
            "preferred_broker": self.preferred_broker,
            "alternate_brokers": self.alternate_brokers,
            "max_retries": self.max_retries,
            "retry_count": self.retry_count,
            "attempts": [a.to_dict() for a in self.attempts],
            "successful_broker": self.successful_broker,
            "last_error": self.last_error,
            "succeeded": self.successful_broker is not None,
        }


# ===================================================================== #
# Verification Block
# ===================================================================== #
if __name__ == "__main__":
    logging.basicConfig(level=logging.WARNING,
                        format="%(levelname)s: %(message)s")

    print("=== RetryRouter Verification ===\n")

    router = RetryRouter()
    results_log = []
    failures_log = []

    # Callbacks
    def on_success(intent_id, result):
        results_log.append((intent_id, result))

    def on_failure(intent_id, failed_broker):
        failures_log.append((intent_id, failed_broker))

    router.on_success(on_success)
    router.on_failure(on_failure)

    # Create broker routing functions

    # Broker that always succeeds
    def reliable_broker(intent):
        return {"status": "ok", "broker": "broker-reliable",
                "echo": intent.get("payload", {})}

    # Broker that fails twice then succeeds
    fail_count = {"count": 0}
    def flaky_broker(intent):
        fail_count["count"] += 1
        if fail_count["count"] <= 2:
            raise RuntimeError("Temporary failure")
        return {"status": "ok", "broker": "broker-flaky"}

    # Broker that always fails
    def failing_broker(intent):
        raise RuntimeError("Permanent failure")

    # Register brokers
    router.register_broker("broker-reliable", reliable_broker)
    router.register_broker("broker-flaky", flaky_broker)
    router.register_broker("broker-failing", failing_broker)

    print(f"✓ Registered 3 brokers: {router.get_registered_brokers()}")

    # Test 1: Successful route on first try (preferred broker)
    intent = {"intent_id": "test-001", "payload": {"hello": "world"}}
    result = router.route_with_retry(
        intent=intent,
        preferred_broker="broker-reliable",
        alternate_brokers=["broker-flaky", "broker-failing"],
        max_retries=2,
    )
    assert result["status"] == "ok"
    assert result["broker"] == "broker-reliable"
    assert router.get_retry_count("test-001") == 0
    print(f"✓ test-001: Succeeded on preferred broker (broker-reliable)")

    # Test 2: Route with flaky broker (fails then succeeds)
    intent2 = {"intent_id": "test-002", "payload": {}}
    result2 = router.route_with_retry(
        intent=intent2,
        preferred_broker="broker-flaky",
        alternate_brokers=["broker-reliable"],
        max_retries=3,
    )
    assert result2["status"] == "ok"
    # The flaky broker itself succeeded on 3rd attempt with 2 retries
    print(f"✓ test-002: Succeeded on broker-flaky after retries")

    # Test 3: Route that needs failover (all fail but last alternate succeeds)
    # Reset flaky counter then use it as alternate
    fail_count["count"] = 0
    intent3 = {"intent_id": "test-003", "payload": {}}
    result3 = router.route_with_retry(
        intent=intent3,
        preferred_broker="broker-failing",
        alternate_brokers=["broker-reliable"],
        max_retries=2,
    )
    assert result3["status"] == "ok"
    assert result3["broker"] == "broker-reliable"
    print(f"✓ test-003: Failed over from broker-failing to broker-reliable")

    # Check route history for test-003
    history = router.get_route_history("test-003")
    assert history is not None
    assert len(history) == 2, f"Expected 2 attempts, got {len(history)}"
    assert history[0]["broker_id"] == "broker-failing"
    assert history[0]["success"] is False
    assert history[1]["broker_id"] == "broker-reliable"
    assert history[1]["success"] is True
    print(f"✓ test-003 route history: {len(history)} attempts (first failed, second succeeded)")

    # Test 4: All brokers fail
    intent4 = {"intent_id": "test-004", "payload": {}}
    try:
        router.route_with_retry(
            intent=intent4,
            preferred_broker="broker-failing",
            alternate_brokers=["broker-failing"],  # same failing broker
            max_retries=2,
        )
        assert False, "Should have raised RetryExhaustedError"
    except RetryExhaustedError as e:
        print(f"✓ test-004: Correctly raised RetryExhaustedError: {e}")

    # Test 5: Unregistered broker
    try:
        router.route_with_retry(
            intent={"intent_id": "test-005"},
            preferred_broker="broker-unknown",
            max_retries=1,
        )
        assert False, "Should have raised ValueError"
    except ValueError:
        print(f"✓ test-005: Correctly raised ValueError for unknown broker")

    # Test 6: Retry count and history
    count = router.get_retry_count("test-003")
    assert count == 1, f"Expected 1 retry, got {count}"
    print(f"✓ test-003 retry count: {count}")

    count_unknown = router.get_retry_count("non-existent")
    assert count_unknown is None
    print(f"✓ Non-existent intent returns None for retry count")

    # Test 7: Callbacks
    assert len(results_log) == 3, f"Expected 3 success callbacks, got {len(results_log)}"
    assert len(failures_log) >= 2, f"Expected >=2 failure callbacks, got {len(failures_log)}"
    print(f"✓ Callbacks: {len(results_log)} successes, {len(failures_log)} failures")

    # Test 8: Stats
    stats = router.get_stats()
    assert stats["routes_initiated"] == 4  # test-001 through test-004 + none for test-005
    assert stats["routes_succeeded"] >= 3
    assert stats["routes_failed"] == 1
    print(f"✓ Stats: {stats}")

    # Test 9: Unregister broker
    unreg = router.unregister_broker("broker-failing")
    assert unreg is True
    assert "broker-failing" not in router.get_registered_brokers()
    print(f"✓ Unregistered broker-failing. Remaining: {router.get_registered_brokers()}")

    # Test 10: Clear history
    cleared = router.clear_history()
    assert cleared >= 4, f"Expected >=4 cleared routes, got {cleared}"
    assert router.get_route_history("test-001") is None
    print(f"✓ Cleared {cleared} route histories")

    print("\n=== All RetryRouter tests passed! ===\n")
