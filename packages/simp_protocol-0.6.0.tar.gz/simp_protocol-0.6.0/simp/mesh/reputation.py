"""
Agent Reputation Scoring — Level 3
===================================

Tracks and maintains reputation scores for mesh agents.

Each agent has a score between 0.0 and 1.0 (default 0.5).
- Successes increase score by +0.1
- Failures decrease score by -0.15
- Running average response time is tracked
- All operations are thread-safe

This is a self-contained alternative to the existing ReputationScorer
which uses SQLite persistence.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

DEFAULT_SCORE = 0.5
SUCCESS_INCR = 0.1
FAILURE_DECR = 0.15
MIN_SCORE = 0.0
MAX_SCORE = 1.0


@dataclass
class AgentReputation:
    """Reputation record for a single agent."""
    agent_id: str
    score: float = DEFAULT_SCORE
    total_successes: int = 0
    total_failures: int = 0
    avg_response_time_ms: float = 0.0
    last_seen: float = field(default_factory=time.time)
    # Per-intent-type tracking
    successes_by_type: Dict[str, int] = field(default_factory=dict)
    failures_by_type: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "score": round(self.score, 4),
            "total_successes": self.total_successes,
            "total_failures": self.total_failures,
            "avg_response_time_ms": round(self.avg_response_time_ms, 2),
            "last_seen": self.last_seen,
        }


class ReputationSystem:
    """
    Tracks agent reputation based on task success/failure.

    Scoring:
      - Default score: 0.5
      - Success: +0.1 (clamped to [0.0, 1.0])
      - Failure: -0.15 (clamped to [0.0, 1.0])
      - Response time: running exponential moving average

    All operations are thread-safe via RLock.

    Usage:
        rs = ReputationSystem()
        rs.record_success("agent_a", "trade")
        rs.record_failure("agent_b", "compute", "timeout")
        score = rs.get_score("agent_a")
        stats = rs.get_stats("agent_b")
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._agents: Dict[str, AgentReputation] = {}

    # ── Recording ───────────────────────────────────────────────────────────

    def record_success(
        self,
        agent_id: str,
        intent_type: str = "unknown",
    ) -> AgentReputation:
        """
        Record a successful intent completion for an agent.

        Reputation increases by +0.1 (capped at 1.0).

        Args:
            agent_id: The agent who succeeded.
            intent_type: The type/category of intent performed.

        Returns:
            The updated AgentReputation record.
        """
        with self._lock:
            record = self._get_or_create(agent_id)
            record.total_successes += 1
            record.last_seen = time.time()
            record.score = min(MAX_SCORE, record.score + SUCCESS_INCR)

            # Track by intent type
            record.successes_by_type[intent_type] = \
                record.successes_by_type.get(intent_type, 0) + 1

            logger.debug(
                "Agent %s success on %s (score: %.3f)",
                agent_id, intent_type, record.score,
            )
            return record

    def record_failure(
        self,
        agent_id: str,
        intent_type: str = "unknown",
        reason: str = "",
    ) -> AgentReputation:
        """
        Record a failed intent for an agent.

        Reputation decreases by -0.15 (floored at 0.0).

        Args:
            agent_id: The agent who failed.
            intent_type: The type/category of intent performed.
            reason: A description of why the failure occurred.

        Returns:
            The updated AgentReputation record.
        """
        with self._lock:
            record = self._get_or_create(agent_id)
            record.total_failures += 1
            record.last_seen = time.time()
            record.score = max(MIN_SCORE, record.score - FAILURE_DECR)

            # Track by intent type
            record.failures_by_type[intent_type] = \
                record.failures_by_type.get(intent_type, 0) + 1

            logger.debug(
                "Agent %s failure on %s (score: %.3f, reason: %s)",
                agent_id, intent_type, record.score, reason,
            )
            return record

    def record_response_time(
        self,
        agent_id: str,
        response_time_ms: float,
    ) -> AgentReputation:
        """
        Update the running average response time for an agent.

        Uses an exponential moving average:
          new_avg = 0.7 * old_avg + 0.3 * new_value

        Args:
            agent_id: The agent to update.
            response_time_ms: The latest response time in milliseconds.

        Returns:
            The updated AgentReputation record.
        """
        with self._lock:
            record = self._get_or_create(agent_id)
            record.last_seen = time.time()

            if record.total_successes + record.total_failures == 0:
                record.avg_response_time_ms = response_time_ms
            else:
                record.avg_response_time_ms = (
                    0.7 * record.avg_response_time_ms + 0.3 * response_time_ms
                )

            logger.debug(
                "Agent %s response time: %.1fms (avg: %.1fms)",
                agent_id, response_time_ms, record.avg_response_time_ms,
            )
            return record

    # ── Queries ─────────────────────────────────────────────────────────────

    def get_score(self, agent_id: str) -> float:
        """
        Get the current reputation score for an agent.

        Args:
            agent_id: The agent to query.

        Returns:
            The reputation score (0.0 to 1.0), or DEFAULT_SCORE (0.5)
            if the agent has no record.
        """
        with self._lock:
            record = self._agents.get(agent_id)
            if record is None:
                return DEFAULT_SCORE
            return record.score

    def get_stats(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """
        Get detailed reputation stats for an agent.

        Args:
            agent_id: The agent to query.

        Returns:
            A dict with keys: score, total_successes, total_failures,
            avg_response_time_ms, last_seen; or None if the agent has
            no record.
        """
        with self._lock:
            record = self._agents.get(agent_id)
            if record is None:
                return None
            return record.to_dict()

    def reset_score(self, agent_id: str) -> bool:
        """
        Reset an agent's score to the default (0.5).

        This does not clear success/failure counts — only the composite
        score is reset.

        Args:
            agent_id: The agent to reset.

        Returns:
            True if the agent existed and was reset, False if no
            record exists for this agent.
        """
        with self._lock:
            record = self._agents.get(agent_id)
            if record is None:
                return False
            record.score = DEFAULT_SCORE
            logger.info("Agent %s score reset to %.1f", agent_id, DEFAULT_SCORE)
            return True

    # ── Bulk Queries ────────────────────────────────────────────────────────

    def get_all_scores(self) -> Dict[str, float]:
        """
        Get scores for all tracked agents.

        Returns:
            Dict of {agent_id: score}.
        """
        with self._lock:
            return {aid: rec.score for aid, rec in self._agents.items()}

    def get_agents_by_score(
        self,
        min_score: float = 0.0,
        max_score: float = 1.0,
    ) -> List[str]:
        """
        Get agent IDs whose scores fall within a range.

        Args:
            min_score: Minimum inclusive score.
            max_score: Maximum inclusive score.

        Returns:
            List of agent IDs matching the score range.
        """
        with self._lock:
            return [
                aid for aid, rec in self._agents.items()
                if min_score <= rec.score <= max_score
            ]

    def get_agent_count(self) -> int:
        """Return the number of tracked agents."""
        with self._lock:
            return len(self._agents)

    # ── Internal ────────────────────────────────────────────────────────────

    def _get_or_create(self, agent_id: str) -> AgentReputation:
        """Get existing record or create a new one."""
        if agent_id not in self._agents:
            self._agents[agent_id] = AgentReputation(agent_id=agent_id)
        return self._agents[agent_id]


# ═══════════════════════════════════════════════════════════════════════════
# Verification Block
# ═══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 60)
    print("ReputationSystem Verification")
    print("=" * 60)

    rs = ReputationSystem()

    # 1. Default score for unknown agent
    score = rs.get_score("agent_a")
    assert score == DEFAULT_SCORE, f"Expected {DEFAULT_SCORE}, got {score}"
    print(f"[✓] Unknown agent returns default score: {score}")

    # 2. Record success
    r = rs.record_success("agent_a", "trade")
    assert r.score == DEFAULT_SCORE + SUCCESS_INCR
    assert r.total_successes == 1
    score = rs.get_score("agent_a")
    assert round(score, 4) == round(DEFAULT_SCORE + SUCCESS_INCR, 4)
    print(f"[✓] After 1 success: score = {score}")

    # 3. Record multiple successes
    for _ in range(3):
        rs.record_success("agent_a", "trade")
    score = rs.get_score("agent_a")
    assert score > 0.8
    print(f"[✓] After 4 successes total: score = {score:.4f}")

    # 4. Score clamped at 1.0
    for _ in range(10):
        rs.record_success("agent_a", "trade")
    score = rs.get_score("agent_a")
    assert score == 1.0
    print(f"[✓] Score clamped at max: {score}")

    # 5. Record failure
    r = rs.record_failure("agent_a", "compute", "timeout")
    score = rs.get_score("agent_a")
    assert score == 1.0 - FAILURE_DECR
    print(f"[✓] After 1 failure from 1.0: score = {score}")

    # 6. Score clamped at 0.0
    for _ in range(20):
        rs.record_failure("agent_b", "unknown", "chain error")
    score = rs.get_score("agent_b")
    assert score == 0.0
    print(f"[✓] Score clamped at min: {score}")

    # 7. Record response time
    rs2 = ReputationSystem()
    rs2.record_success("agent_c", "trade")
    rs2.record_response_time("agent_c", 150.0)
    rs2.record_response_time("agent_c", 50.0)
    stats = rs2.get_stats("agent_c")
    assert stats is not None
    assert stats["avg_response_time_ms"] > 0
    print(f"[✓] Response time tracking: avg={stats['avg_response_time_ms']:.1f}ms")

    # 8. Get stats
    stats = rs.get_stats("agent_a")
    assert stats is not None
    assert "score" in stats
    assert "total_successes" in stats
    assert "total_failures" in stats
    print(f"[✓] get_stats(): score={stats['score']}, "
          f"successes={stats['total_successes']}, "
          f"failures={stats['total_failures']}")

    # 9. Reset score
    result = rs.reset_score("agent_a")
    assert result is True
    assert rs.get_score("agent_a") == DEFAULT_SCORE
    print(f"[✓] reset_score() resets to {DEFAULT_SCORE}")

    # 10. Reset non-existent agent
    result = rs.reset_score("nonexistent")
    assert result is False
    print(f"[✓] reset_score() on unknown agent returns False")

    # 11. get_all_scores
    scores = rs.get_all_scores()
    assert "agent_a" in scores
    assert "agent_b" in scores
    print(f"[✓] get_all_scores() includes {len(scores)} agents")

    # 12. get_agents_by_score
    high_scorers = rs.get_agents_by_score(min_score=0.5)
    assert "agent_a" in high_scorers
    print(f"[✓] get_agents_by_score(min=0.5): {high_scorers}")

    print()
    print("All ReputationSystem tests PASSED ✓")
