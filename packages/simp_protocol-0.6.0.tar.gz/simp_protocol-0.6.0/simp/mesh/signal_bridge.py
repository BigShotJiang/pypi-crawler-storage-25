"""
Signal Mesh Bridge
==================

Bridges the intelligence module to the SIMP mesh bus so that
financial signals propagate with or without network connectivity.

How it works:
- Intelligence agents publish signals as MeshPackets on "financial_signals" channel
- EnhancedMeshBus handles store-and-forward (SQLite-backed OfflineMessageStore)
- GossipRouter floods signals to all connected peers when online
- When offline, messages are queued locally and drained on reconnect
- Receiving agents process signals and trigger trading actions

Architecture:
    Intelligence Agent → SignalMeshBridge → EnhancedMeshBus → [Gossip/Offline] → Mesh Peers
                         ↑                                                        ↓
                    Local Brain                                         Remote Brains
                    (no net)                                              (full mesh)
"""

import asyncio
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Optional, Dict, List, Any, Callable, TYPE_CHECKING
from dataclasses import dataclass, field

from simp.mesh.packet import (
    MeshPacket,
    MessageType,
    Priority,
    create_event_packet,
)
from simp.mesh.enhanced_bus import get_enhanced_mesh_bus, EnhancedMeshBus
try:
    from simp.quantumarb.intelligence.multi_agent import TradingSignal
except ImportError:
    TradingSignal = None

try:
    from simp.quantumarb.intelligence.self_learning import SelfLearningEngine
except ImportError:
    SelfLearningEngine = None

from simp.financial.a2a_schema import AgentDecisionSummary, Side, RiskPosture, A2APlan

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Financial signal packet types
# ─────────────────────────────────────────────────────────────────────────────

FINANCIAL_SIGNALS_CHANNEL = "financial_signals"
SIGNAL_REQUEST_CHANNEL = "signal_requests"
INTELLIGENCE_AGENT_ID = "intelligence_agent"


@dataclass
class FinancialSignal:
    """
    Serializable financial signal that travels across the mesh.

    This is the wire format for signals exchanged between mesh nodes.
    It is NOT the internal TradingSignal — it is a MeshPacket payload.
    """
    signal_id: str
    symbol: str
    direction: str           # "long" | "short" | "pass"
    confidence: float
    entry_price: float
    stop_loss: Optional[float]
    take_profit: Optional[float]
    position_size: float
    source_agent: str        # e.g. "StrategyAgent", "lstm", "quantum"
    regime: str              # "trending" | "ranging" | "volatile"
    reasoning: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    expires_at: float = field(default=lambda: time.time() + 300)  # 5 min TTL

    def to_dict(self) -> dict:
        return {
            "signal_id": self.signal_id,
            "symbol": self.symbol,
            "direction": self.direction,
            "confidence": self.confidence,
            "entry_price": self.entry_price,
            "stop_loss": self.stop_loss,
            "take_profit": self.take_profit,
            "position_size": self.position_size,
            "source_agent": self.source_agent,
            "regime": self.regime,
            "reasoning": self.reasoning,
            "timestamp": self.timestamp,
            "expires_at": self.expires_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "FinancialSignal":
        return cls(**d)

    @classmethod
    def from_trading_signal(cls, ts: TradingSignal, regime: str = "unknown") -> "FinancialSignal":
        return cls(
            signal_id=f"{ts.symbol}_{ts.timestamp}_{ts.agent_source[:8]}",
            symbol=ts.symbol,
            direction=ts.direction,
            confidence=ts.confidence,
            entry_price=float(sum(ts.entry_price) / 2),
            stop_loss=float(ts.stop_loss) if ts.stop_loss else None,
            take_profit=float(ts.take_profit) if ts.take_profit else None,
            position_size=ts.position_size,
            source_agent=ts.agent_source,
            regime=regime,
            reasoning=ts.reasoning,
            timestamp=ts.timestamp,
        )

    def to_agent_decision_summary(self) -> AgentDecisionSummary:
        """Convert to A2A schema AgentDecisionSummary."""
        side_map = {"long": Side.BUY, "short": Side.SELL, "pass": Side.HOLD}
        return AgentDecisionSummary(
            agent_name=f"mesh:{self.source_agent}",
            instrument=self.symbol,
            side=side_map.get(self.direction, Side.HOLD),
            quantity=self.position_size,
            units="USD",
            confidence=self.confidence,
            rationale=self.reasoning,
            timestamp=self.timestamp,
        )

    def is_expired(self) -> bool:
        return time.time() > self.expires_at


# ─────────────────────────────────────────────────────────────────────────────
# Signal Mesh Bridge
# ─────────────────────────────────────────────────────────────────────────────

class SignalMeshBridge:
    """
    Bridges the intelligence multi-agent system to the SIMP mesh bus.

    Responsibilities:
    1. Register intelligence agents as mesh participants
    2. Convert TradingSignals → MeshPackets and publish to mesh
    3. Subscribe to incoming financial_signals channel
    4. Route received signals to the appropriate handlers
    5. Maintain a local signal cache for offline access
    6. Track signal provenance for audit

    The bridge is designed to be long-running. It:
    - Publishes signals as soon as they are generated (no polling)
    - Listens for signals from other mesh nodes
    - Drains the offline store on reconnection
    - Handles mesh disconnections gracefully
    """

    def __init__(
        self,
        agent_id: str = INTELLIGENCE_AGENT_ID,
        bus: Optional[EnhancedMeshBus] = None,
        self_learning: Optional[SelfLearningEngine] = None,
        signal_ttl_seconds: int = 300,
        max_signal_age_seconds: int = 600,
    ):
        self.agent_id = agent_id
        self.bus = bus or get_enhanced_mesh_bus()
        self.self_learning = self_learning
        self.signal_ttl = signal_ttl_seconds
        self.max_signal_age = max_signal_age_seconds

        # Local signal cache (recent signals from mesh peers)
        self._signal_cache: Dict[str, FinancialSignal] = {}
        self._cache_lock = threading.Lock()

        # Subscriptions
        self._signal_handlers: List[Callable[[FinancialSignal], None]] = []

        # Stats
        self._stats = {
            "published": 0,
            "received": 0,
            "expired_dropped": 0,
            "offline_stored": 0,
            "offline_drained": 0,
        }

        # Registration state
        self._registered = False
        self._running = False
        self._poll_task: Optional[asyncio.Task] = None

    # ── Registration ──────────────────────────────────────────────────────────

    def register(self) -> bool:
        """
        Register this agent with the mesh bus.

        This makes the agent discoverable and allows it to receive
        messages destined for the intelligence agent.
        """
        try:
            self.bus.register_agent(self.agent_id)
            self._registered = True
            logger.info(f"SignalMeshBridge registered as {self.agent_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to register with mesh bus: {e}")
            return False

    def unregister(self):
        """Unregister from the mesh bus."""
        try:
            self.bus.unregister_agent(self.agent_id)
            self._registered = False
            logger.info(f"SignalMeshBridge unregistered")
        except Exception as e:
            logger.error(f"Failed to unregister: {e}")

    # ── Publishing signals ────────────────────────────────────────────────────

    def publish_signal(self, signal: FinancialSignal) -> bool:
        """
        Publish a financial signal to the mesh.

        This uses the EnhancedMeshBus which:
        - Sends to online peers immediately (gossip)
        - Stores in SQLite offline store for offline peers
        - Tracks delivery receipts

        Args:
            signal: The financial signal to publish

        Returns:
            True if the packet was accepted by the bus
        """
        if not self._registered:
            logger.warning("Cannot publish: not registered with mesh bus")
            return False

        try:
            packet = create_event_packet(
                sender_id=self.agent_id,
                recipient_id="*",  # Broadcast to all
                channel=FINANCIAL_SIGNALS_CHANNEL,
                payload={
                    "type": "financial_signal",
                    "signal": signal.to_dict(),
                },
                priority=Priority.HIGH if signal.confidence > 0.7 else Priority.NORMAL,
                ttl_seconds=self.signal_ttl,
                meta={
                    "source": "intelligence_module",
                    "symbol": signal.symbol,
                    "direction": signal.direction,
                    "confidence": signal.confidence,
                },
            )

            # Use broadcast_channel which handles both live and offline delivery
            self.bus.broadcast_channel(
                channel=FINANCIAL_SIGNALS_CHANNEL,
                sender_id=self.agent_id,
                payload=packet.payload,
                priority=packet.priority,
            )

            self._stats["published"] += 1
            logger.debug(f"Published signal {signal.signal_id} for {signal.symbol}")
            return True

        except Exception as e:
            logger.error(f"Failed to publish signal: {e}")
            return False

    def publish_signal_from_trading_signal(
        self,
        ts: TradingSignal,
        regime: str = "unknown",
    ) -> bool:
        """Convenience: publish directly from a TradingSignal."""
        return self.publish_signal(FinancialSignal.from_trading_signal(ts, regime))

    # ── Subscribing to signals ────────────────────────────────────────────────

    def subscribe_to_signals(
        self,
        handler: Callable[[FinancialSignal], None],
    ) -> None:
        """
        Register a handler for incoming financial signals.

        Handlers are called synchronously in the mesh polling thread.
        Keep handlers fast to avoid blocking the bus.
        """
        self._signal_handlers.append(handler)

    def _handle_mesh_packet(self, packet: MeshPacket) -> None:
        """
        Process an incoming MeshPacket from the bus.

        This is called by the poll loop when we receive a packet
        addressed to this agent or on a subscribed channel.
        """
        try:
            # Only process financial signal packets
            if packet.channel != FINANCIAL_SIGNALS_CHANNEL:
                return

            payload = packet.payload
            if not isinstance(payload, dict):
                return

            if payload.get("type") != "financial_signal":
                return

            signal_data = payload.get("signal")
            if not signal_data:
                return

            signal = FinancialSignal.from_dict(signal_data)

            # Drop expired signals
            if signal.is_expired():
                self._stats["expired_dropped"] += 1
                logger.debug(f"Dropped expired signal {signal.signal_id}")
                return

            # Cache the signal
            with self._cache_lock:
                self._signal_cache[signal.signal_id] = signal

            # Dispatch to handlers
            for handler in self._signal_handlers:
                try:
                    handler(signal)
                except Exception as e:
                    logger.error(f"Signal handler error: {e}")

            self._stats["received"] += 1
            logger.debug(f"Received signal {signal.signal_id} from {signal.source_agent}")

        except Exception as e:
            logger.error(f"Error processing mesh packet: {e}")

    # ── Local signal cache ────────────────────────────────────────────────────

    def get_recent_signals(
        self,
        symbol: Optional[str] = None,
        max_age_seconds: Optional[int] = None,
    ) -> List[FinancialSignal]:
        """
        Get recent signals from the local cache.

        Args:
            symbol: Filter by symbol (None = all symbols)
            max_age_seconds: Filter by age (None = use max_signal_age)

        Returns:
            List of recent FinancialSignals, newest first
        """
        max_age = max_age_seconds or self.max_signal_age
        cutoff = time.time() - max_age

        with self._cache_lock:
            signals = []
            for sig in self._signal_cache.values():
                try:
                    sig_time = datetime.fromisoformat(
                        sig.timestamp.replace('Z', '+00:00')
                    ).timestamp()
                    if sig_time < cutoff:
                        continue
                    if symbol and sig.symbol != symbol:
                        continue
                    signals.append(sig)
                except (ValueError, TypeError):
                    continue

            # Sort newest first
            signals.sort(
                key=lambda s: datetime.fromisoformat(
                    s.timestamp.replace('Z', '+00:00')
                ).timestamp(),
                reverse=True,
            )

            return signals

    def get_signal_consensus(
        self,
        symbol: str,
        min_confidence: float = 0.5,
    ) -> Dict[str, Any]:
        """
        Compute consensus direction from recent signals for a symbol.

        Uses a simple majority vote weighted by confidence.
        """
        signals = self.get_recent_signals(symbol=symbol)
        if not signals:
            return {"direction": "pass", "confidence": 0.0, "signal_count": 0}

        directions = {"long": 0.0, "short": 0.0, "pass": 0.0}
        total_weight = 0.0

        for sig in signals:
            if sig.confidence < min_confidence:
                continue
            directions[sig.direction] += sig.confidence
            total_weight += sig.confidence

        if total_weight == 0:
            return {"direction": "pass", "confidence": 0.0, "signal_count": len(signals)}

        # Normalize
        for d in directions:
            directions[d] /= total_weight

        best_direction = max(directions, key=directions.get)
        return {
            "direction": best_direction,
            "confidence": directions[best_direction],
            "weights": directions,
            "signal_count": len(signals),
            "signals": [s.signal_id for s in signals[:5]],  # Top 5
        }

    # ── A2A Integration ───────────────────────────────────────────────────────

    def signals_to_a2a_plan(
        self,
        symbol: str,
        risk_posture: RiskPosture = RiskPosture.NEUTRAL,
    ) -> A2APlan:
        """
        Convert recent mesh signals into an A2APlan for the financial layer.

        This feeds mesh signals into the existing A2A protocol.
        """
        consensus = self.get_signal_consensus(symbol)

        # Get cached signals
        signals = self.get_recent_signals(symbol=symbol)

        # Convert to AgentDecisionSummary
        decisions = [sig.to_agent_decision_summary() for sig in signals[:10]]

        if not decisions:
            from simp.financial.a2a_schema import PortfolioPosture
            return A2APlan(
                decisions=[],
                portfolio_posture=PortfolioPosture(
                    aggregate_exposure={},
                    risk_posture=risk_posture,
                ),
                execution_allowed=False,
                execution_reason="No mesh signals available",
            )

        # Build portfolio posture from signal consensus
        direction = consensus["direction"]
        exposure = {}
        if direction == "long":
            exposure[symbol] = consensus["confidence"] * 10000  # Scale to USD
        elif direction == "short":
            exposure[symbol] = -consensus["confidence"] * 10000

        from simp.financial.a2a_schema import PortfolioPosture

        posture = PortfolioPosture(
            aggregate_exposure=exposure,
            risk_posture=risk_posture,
        )

        return A2APlan(
            decisions=decisions,
            portfolio_posture=posture,
            execution_allowed=consensus["confidence"] > 0.6,
            execution_reason=f"Mesh consensus: {direction} ({consensus['confidence']:.2f})",
        )

    # ── Polling loop ─────────────────────────────────────────────────────────

    async def _poll_loop(self):
        """
        Async polling loop that drains messages from the bus.

        In a production system this would be event-driven (callbacks from
        the bus). For simplicity, we poll at 1-second intervals.
        """
        logger.info("SignalMeshBridge poll loop started")
        while self._running:
            try:
                if self._registered:
                    # Drain offline store for this agent
                    offline_packets = self.bus.offline_store.fetch_for_agent(self.agent_id)
                    for pkt_data in offline_packets:
                        try:
                            if isinstance(pkt_data, dict):
                                packet = MeshPacket.from_dict(pkt_data)
                            else:
                                continue
                            self._handle_mesh_packet(packet)
                            self.bus.offline_store.mark_delivered(packet.message_id)
                            self._stats["offline_drained"] += 1
                        except Exception as e:
                            logger.error(f"Error draining offline packet: {e}")

            except Exception as e:
                logger.error(f"Poll loop error: {e}")

            await asyncio.sleep(1.0)

        logger.info("SignalMeshBridge poll loop stopped")

    def start(self) -> bool:
        """Start the bridge (register + start polling)."""
        if self._running:
            return True

        if not self.register():
            return False

        self._running = True
        self._poll_task = asyncio.create_task(self._poll_loop())
        logger.info("SignalMeshBridge started")
        return True

    def stop(self):
        """Stop the bridge."""
        self._running = False
        if self._poll_task:
            self._poll_task.cancel()
        self.unregister()
        logger.info("SignalMeshBridge stopped")

    @property
    def stats(self) -> dict:
        return {
            **self._stats,
            "cached_signals": len(self._signal_cache),
            "registered": self._registered,
            "running": self._running,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Intelligence Agent with mesh transport
# ─────────────────────────────────────────────────────────────────────────────

class MeshReadyIntelligenceAgent:
    """
    A drop-in replacement for the intelligence multi-agent system
    that is mesh-native: all TradingSignals are broadcast on the mesh
    and incoming signals trigger local processing.

    This is how the intelligence module becomes a first-class mesh citizen:
    - StrategyAgent signals → mesh broadcast
    - Incoming mesh signals → trigger analysis/response
    - Works fully offline (messages queued in SQLite)
    - No network required for local operation
    """

    def __init__(
        self,
        agent_id: str = INTELLIGENCE_AGENT_ID,
        bus: Optional[EnhancedMeshBus] = None,
        self_learning: Optional[SelfLearningEngine] = None,
    ):
        from simp.quantumarb.intelligence.multi_agent import create_trading_team

        self.agent_id = agent_id
        self.bridge = SignalMeshBridge(
            agent_id=agent_id,
            bus=bus,
            self_learning=self_learning,
        )
        self.orchestrator = create_trading_team()
        self.self_learning = self_learning

        # Register mesh signal handler
        self.bridge.subscribe_to_signals(self._on_mesh_signal)

    def _on_mesh_signal(self, signal: FinancialSignal):
        """
        Handle an incoming mesh signal.

        When a remote mesh node publishes a signal, we:
        1. Record it in self-learning engine
        2. Aggregate it with local signals
        3. Optionally trigger re-analysis
        """
        logger.info(
            f"Mesh signal received: {signal.symbol} {signal.direction} "
            f"(conf={signal.confidence:.2f}) from {signal.source_agent}"
        )

        if self.self_learning:
            # Record the signal in self-learning
            self.self_learning.learn_from_market_outcome(
                symbol=signal.symbol,
                regime=signal.regime,
                trade_action=signal.direction,
                market_outcome="pending",  # Unknown until execution
                price_change=0.0,
            )

    def start(self) -> bool:
        """Start the agent and the mesh bridge."""
        return self.bridge.start()

    def stop(self):
        """Stop the agent and the mesh bridge."""
        self.bridge.stop()

    def publish_local_signal(self, ts: TradingSignal, regime: str) -> bool:
        """Publish a local signal to mesh peers."""
        return self.bridge.publish_signal_from_trading_signal(ts, regime)

    def get_mesh_consensus(self, symbol: str) -> Dict[str, Any]:
        """Get consensus from all mesh peers for a symbol."""
        return self.bridge.get_signal_consensus(symbol)

    @property
    def stats(self) -> dict:
        return {
            "bridge": self.bridge.stats,
            "orchestrator_running": self.bridge._running,
        }
