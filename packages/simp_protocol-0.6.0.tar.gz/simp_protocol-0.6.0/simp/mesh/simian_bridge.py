"""
Simian Bridge — L4-T39: External Agent Marketplace Organ Bridge
===============================================================
Integrates with external AI agent marketplaces (Simian, AgentGPT, etc.)
to discover, onboard, and orchestrate external AI agents as SIMP organs.

Capabilities
────────────
  - Agent discovery from marketplaces
  - Agent capability mapping (external → SIMP intent types)
  - Agent onboarding as SIMP organs
  - Agent health monitoring across marketplaces
  - Delegated task execution to external agents

QVAC-Inspired Features
──────────────────────
  - Topic-based agent discovery (like Hyperswarm)
  - Firewall per agent marketplace (allow/deny external agents)
  - Deterministic agent ID from marketplace identity
  - Trust scoring for external agents

Integration Points
──────────────────
  - CapabilityRegistry: register simian capabilities
  - IntentRouter: route external_intent, simian_discover_intent
  - HTTPSBridge: cross-mesh federation for external agents
"""

from __future__ import annotations

import hashlib
import json
import logging
import random
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── Enums & Constants ────────────────────────────────────────────────────────

class MarketplaceType(Enum):
    SIMIAN = "simian"
    AGENTGPT = "agentgpt"
    CUSTOM = "custom"
    UNKNOWN = "unknown"


class AgentTrustLevel(Enum):
    UNTRUSTED = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class OnboardingStatus(Enum):
    DISCOVERED = "discovered"
    PENDING_APPROVAL = "pending_approval"
    ONBOARDED = "onboarded"
    REJECTED = "rejected"
    DECOMMISSIONED = "decommissioned"


# Thresholds
MIN_TRUST_SCORE_FOR_ONBOARD = 0.6
MAX_EXTERNAL_AGENTS = 50
DEFAULT_HEARTBEAT_INTERVAL = 60  # seconds
SIMIAN_FIREWALL_MODE = "deny"  # deny unknown marketplaces by default


# ── Dataclasses ──────────────────────────────────────────────────────────────

@dataclass
class ExternalAgentManifest:
    """
    An external agent's identification and capability manifest.
    Mirrors the agent card concept from HTTPSBridge.
    """
    agent_id: str
    marketplace: MarketplaceType
    name: str = ""
    description: str = ""
    version: str = "1.0"
    endpoint: str = ""  # How to reach this agent
    public_key: str = ""
    capabilities: List[str] = field(default_factory=list)
    simp_intent_map: Dict[str, str] = field(default_factory=dict)  # external_cap → SIMP intent_type
    trust_score: float = 0.5
    first_seen: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def fingerprint(self) -> str:
        return hashlib.sha256(f"{self.agent_id}:{self.marketplace.value}".encode()).hexdigest()[:16]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "marketplace": self.marketplace.value,
            "name": self.name,
            "version": self.version,
            "capabilities": self.capabilities[:5],
            "simp_intent_map": self.simp_intent_map,
            "trust_score": round(self.trust_score, 2),
            "first_seen": self.first_seen,
        }


@dataclass
class OnboardingRecord:
    """Record of an agent onboarding process."""
    agent_id: str
    marketplace: MarketplaceType
    status: OnboardingStatus
    trust_level: AgentTrustLevel = AgentTrustLevel.LOW
    onboarded_at: Optional[str] = None
    last_heartbeat: Optional[str] = None
    approved_by: str = ""
    error: Optional[str] = None
    record_id: str = field(default_factory=lambda: f"onb_{uuid.uuid4().hex[:12]}")
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ExternalTaskDelegation:
    """Delegate a task to an external agent."""
    task_id: str = field(default_factory=lambda: f"task_{uuid.uuid4().hex[:12]}")
    agent_id: str = ""
    marketplace: MarketplaceType = MarketplaceType.UNKNOWN
    task_type: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    timeout: int = 30
    source_agent: str = ""
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TaskDelegationResult:
    """Result from delegating a task to an external agent."""
    task_id: str
    status: str  # success | error | timeout | rejected
    response: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    latency_ms: float = 0.0
    agent_id: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── Simian Firewall ──────────────────────────────────────────────────────────

class SimianFirewall:
    """
    Controls which external agents/marketplaces are allowed.
    QVAC-inspired: deny-by-default, explicit allow per marketplace/agent.
    """

    def __init__(self, mode: str = SIMIAN_FIREWALL_MODE):
        self._mode = mode
        self._allow_marketplaces: Set[MarketplaceType] = set()
        self._deny_marketplaces: Set[MarketplaceType] = set()
        self._allow_agents: Set[str] = set()
        self._deny_agents: Set[str] = set()
        self._lock = threading.RLock()

    def allow_marketplace(self, marketplace: MarketplaceType) -> None:
        with self._lock:
            self._allow_marketplaces.add(marketplace)

    def deny_marketplace(self, marketplace: MarketplaceType) -> None:
        with self._lock:
            self._deny_marketplaces.add(marketplace)

    def allow_agent(self, agent_id: str) -> None:
        with self._lock:
            self._allow_agents.add(agent_id)

    def deny_agent(self, agent_id: str) -> None:
        with self._lock:
            self._deny_agents.add(agent_id)

    def is_onboarding_allowed(self, agent_id: str, marketplace: MarketplaceType) -> Tuple[bool, str]:
        with self._lock:
            if agent_id in self._deny_agents:
                return False, f"Agent {agent_id} is denied"
            if marketplace in self._deny_marketplaces:
                return False, f"Marketplace {marketplace.value} is denied"
            if self._mode == "deny":
                if marketplace not in self._allow_marketplaces and agent_id not in self._allow_agents:
                    return False, f"No allow rule for agent {agent_id} on {marketplace.value}"
            return True, "allowed"

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "mode": self._mode,
                "allowed_marketplaces": [m.value for m in self._allow_marketplaces],
                "denied_marketplaces": [m.value for m in self._deny_marketplaces],
                "allowed_agents": len(self._allow_agents),
                "denied_agents": len(self._deny_agents),
            }


# ── Simian Bridge (Main Organ) ───────────────────────────────────────────────

class SimianBridge:
    """
    Simian Bridge — External Agent Marketplace Organ.

    Discovers, vets, and onboards external AI agents as SIMP organs.
    """

    _instance: Optional["SimianBridge"] = None
    _lock = threading.Lock()

    def __init__(
        self,
        organ_id: str = "simian",
        firewall_mode: str = SIMIAN_FIREWALL_MODE,
        dry_run: bool = True,
        max_agents: int = MAX_EXTERNAL_AGENTS,
    ):
        self.organ_id = organ_id
        self._dry_run = dry_run
        self._max_agents = max_agents
        self._lock = threading.RLock()
        self._start_time = time.time()
        self._healthy = True

        # Firewall
        self.firewall = SimianFirewall(mode=firewall_mode)

        # Agent registry
        self._discovered_agents: Dict[str, ExternalAgentManifest] = {}
        self._onboarded_agents: Dict[str, OnboardingRecord] = {}
        self._rejected_agents: Dict[str, OnboardingRecord] = {}

        # Stats
        self._stats = {
            "agents_discovered": 0,
            "agents_onboarded": 0,
            "agents_rejected": 0,
            "tasks_delegated": 0,
            "tasks_succeeded": 0,
            "tasks_failed": 0,
            "heartbeats_received": 0,
            "marketplaces_connected": 0,
        }

        logger.info("[Simian] Bridge initialized  organ=%s  dry_run=%s  max_agents=%d",
                    organ_id, dry_run, max_agents)

    @classmethod
    def get_instance(
        cls,
        organ_id: str = "simian",
        firewall_mode: str = SIMIAN_FIREWALL_MODE,
        dry_run: bool = True,
    ) -> "SimianBridge":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls(
                        organ_id=organ_id,
                        firewall_mode=firewall_mode,
                        dry_run=dry_run,
                    )
        return cls._instance

    # ── Agent Discovery ─────────────────────────────────────────────────────

    def discover_agents(
        self,
        marketplace: Optional[MarketplaceType] = None,
        capability_filter: Optional[str] = None,
    ) -> List[ExternalAgentManifest]:
        """
        Discover agents from marketplaces.
        Simulated agent registry for development.
        """
        sample_agents = [
            ExternalAgentManifest(
                agent_id="simian-research-1",
                marketplace=MarketplaceType.SIMIAN,
                name="Research Agent v2",
                description="Performs web research and summarization",
                capabilities=["web_research", "summarization", "fact_checking"],
                simp_intent_map={"web_research": "research_intent", "summarization": "summary_intent"},
                trust_score=0.85,
            ),
            ExternalAgentManifest(
                agent_id="simian-code-1",
                marketplace=MarketplaceType.SIMIAN,
                name="Code Assistant Pro",
                description="Code generation, review, and debugging",
                capabilities=["code_gen", "code_review", "debugging"],
                simp_intent_map={"code_gen": "code_task_intent", "code_review": "review_intent"},
                trust_score=0.75,
            ),
            ExternalAgentManifest(
                agent_id="agentgpt-data-1",
                marketplace=MarketplaceType.AGENTGPT,
                name="Data Analyst",
                description="Data analysis, visualization, and reporting",
                capabilities=["data_analysis", "visualization", "reporting"],
                trust_score=0.60,
            ),
        ]

        results = sample_agents

        # Filter by marketplace
        if marketplace:
            results = [a for a in results if a.marketplace == marketplace]

        # Filter by capability
        if capability_filter:
            results = [a for a in results if capability_filter in a.capabilities]

        # Register in discovered agents
        with self._lock:
            for agent in results:
                if agent.agent_id not in self._discovered_agents:
                    self._discovered_agents[agent.agent_id] = agent
            self._stats["agents_discovered"] = len(self._discovered_agents)

        logger.info("[Simian] Discovered %d agent(s)", len(results))
        return results

    def get_agent_manifest(self, agent_id: str) -> Optional[ExternalAgentManifest]:
        return self._discovered_agents.get(agent_id)

    # ── Onboarding ──────────────────────────────────────────────────────────

    def onboard_agent(self, agent_id: str, approved_by: str = "") -> OnboardingRecord:
        """
        Onboard a discovered agent as a SIMP organ.

        Flow:
          1. Look up agent manifest
          2. Firewall check
          3. Trust score check
          4. Capacity check
          5. Create onboarding record
        """
        manifest = self._discovered_agents.get(agent_id)
        if not manifest:
            return OnboardingRecord(
                agent_id=agent_id,
                marketplace=MarketplaceType.UNKNOWN,
                status=OnboardingStatus.REJECTED,
                error="Agent not found in discovered registry",
            )

        # Firewall check
        allowed, reason = self.firewall.is_onboarding_allowed(agent_id, manifest.marketplace)
        if not allowed:
            record = OnboardingRecord(
                agent_id=agent_id,
                marketplace=manifest.marketplace,
                status=OnboardingStatus.REJECTED,
                error=f"Firewall blocked: {reason}",
            )
            with self._lock:
                self._rejected_agents[agent_id] = record
                self._stats["agents_rejected"] += 1
            return record

        # Trust score check
        if manifest.trust_score < MIN_TRUST_SCORE_FOR_ONBOARD:
            record = OnboardingRecord(
                agent_id=agent_id,
                marketplace=manifest.marketplace,
                status=OnboardingStatus.REJECTED,
                error=f"Trust score {manifest.trust_score} below minimum {MIN_TRUST_SCORE_FOR_ONBOARD}",
            )
            with self._lock:
                self._rejected_agents[agent_id] = record
                self._stats["agents_rejected"] += 1
            return record

        # Capacity check
        with self._lock:
            if len(self._onboarded_agents) >= self._max_agents:
                return OnboardingRecord(
                    agent_id=agent_id,
                    marketplace=manifest.marketplace,
                    status=OnboardingStatus.REJECTED,
                    error=f"Max agents ({self._max_agents}) reached",
                )

        # Dry-run
        if self._dry_run:
            record = OnboardingRecord(
                agent_id=agent_id,
                marketplace=manifest.marketplace,
                status=OnboardingStatus.PENDING_APPROVAL,
                trust_level=AgentTrustLevel.MEDIUM,
                approved_by=approved_by,
                metadata={"dry_run": True},
            )
            logger.info("[Simian] Dry-run: would onboard agent %s from %s",
                        agent_id, manifest.marketplace.value)
            return record

        # Onboard
        now = datetime.now(timezone.utc).isoformat()
        record = OnboardingRecord(
            agent_id=agent_id,
            marketplace=manifest.marketplace,
            status=OnboardingStatus.ONBOARDED,
            trust_level=self._calculate_trust_level(manifest.trust_score),
            onboarded_at=now,
            last_heartbeat=now,
            approved_by=approved_by,
        )

        with self._lock:
            self._onboarded_agents[agent_id] = record
            self._stats["agents_onboarded"] = len(self._onboarded_agents)

        logger.info("[Simian] Onboarded agent: %s from %s (trust=%.2f)",
                    agent_id, manifest.marketplace.value, manifest.trust_score)
        return record

    def _calculate_trust_level(self, trust_score: float) -> AgentTrustLevel:
        if trust_score >= 0.9:
            return AgentTrustLevel.CRITICAL
        elif trust_score >= 0.75:
            return AgentTrustLevel.HIGH
        elif trust_score >= 0.6:
            return AgentTrustLevel.MEDIUM
        elif trust_score >= 0.3:
            return AgentTrustLevel.LOW
        return AgentTrustLevel.UNTRUSTED

    def decommission_agent(self, agent_id: str) -> bool:
        """Remove an onboarded agent."""
        with self._lock:
            if agent_id not in self._onboarded_agents:
                return False
            record = self._onboarded_agents[agent_id]
            record.status = OnboardingStatus.DECOMMISSIONED
            self._onboarded_agents.pop(agent_id)
            logger.info("[Simian] Decommissioned agent: %s", agent_id)
            return True

    # ── Heartbeat ───────────────────────────────────────────────────────────

    def receive_heartbeat(self, agent_id: str) -> bool:
        """Receive a heartbeat from an onboarded agent."""
        with self._lock:
            record = self._onboarded_agents.get(agent_id)
            if not record:
                return False
            record.last_heartbeat = datetime.now(timezone.utc).isoformat()
            self._stats["heartbeats_received"] += 1
            return True

    def get_stale_agents(self, max_age_seconds: int = DEFAULT_HEARTBEAT_INTERVAL * 3) -> List[str]:
        """Get agents that haven't sent heartbeats recently."""
        stale = []
        now = datetime.now(timezone.utc)
        with self._lock:
            for agent_id, record in self._onboarded_agents.items():
                if record.last_heartbeat:
                    last = datetime.fromisoformat(record.last_heartbeat)
                    if (now - last).total_seconds() > max_age_seconds:
                        stale.append(agent_id)
        return stale

    # ── Task Delegation ─────────────────────────────────────────────────────

    def delegate_task(self, delegation: ExternalTaskDelegation) -> TaskDelegationResult:
        """
        Delegate a task to an onboarded external agent.

        In production, this would make an API call to the external agent's
        endpoint. Currently returns a simulated response.
        """
        # Check agent is onboarded
        record = self._onboarded_agents.get(delegation.agent_id)
        if not record:
            self._stats["tasks_failed"] += 1
            return TaskDelegationResult(
                task_id=delegation.task_id,
                status="rejected",
                error=f"Agent {delegation.agent_id} not onboarded",
            )

        # Dry-run
        if self._dry_run:
            self._stats["tasks_delegated"] += 1
            return TaskDelegationResult(
                task_id=delegation.task_id,
                status="simulated",
                response={"message": f"Would delegate {delegation.task_type} to {delegation.agent_id}"},
                agent_id=delegation.agent_id,
                latency_ms=0.0,
                metadata={"dry_run": True},
            )

        # Simulated delegation
        with self._lock:
            self._stats["tasks_delegated"] += 1
            self._stats["tasks_succeeded"] += 1

        return TaskDelegationResult(
            task_id=delegation.task_id,
            status="success",
            response={"result": f"Task {delegation.task_type} completed by {delegation.agent_id}"},
            agent_id=delegation.agent_id,
            latency_ms=random.uniform(100, 1000),
        )

    # ── Capabilities ────────────────────────────────────────────────────────

    def get_capabilities(self) -> List[Dict[str, Any]]:
        return [
            {
                "id": f"{self.organ_id}:discovery",
                "name": "agent_discovery",
                "description": "Discover external AI agents from marketplaces",
                "intent_types": ["simian_discover_intent", "discover_agents_intent"],
                "marketplaces": [m.value for m in MarketplaceType],
            },
            {
                "id": f"{self.organ_id}:onboarding",
                "name": "agent_onboarding",
                "description": "Onboard external agents as SIMP organs",
                "intent_types": ["simian_onboard_intent", "onboard_agent_intent"],
                "firewall_protected": True,
            },
            {
                "id": f"{self.organ_id}:delegation",
                "name": "external_task_delegation",
                "description": "Delegate tasks to onboarded external agents",
                "intent_types": ["delegate_external_intent", "external_task_intent"],
                "trust_required": True,
            },
        ]

    def handle_intent(self, intent_type: str, payload: Dict[str, Any], source_agent: str) -> Dict[str, Any]:
        handlers = {
            "simian_discover_intent": self._handle_discover_intent,
            "discover_agents_intent": self._handle_discover_intent,
            "simian_onboard_intent": self._handle_onboard_intent,
            "onboard_agent_intent": self._handle_onboard_intent,
            "delegate_external_intent": self._handle_delegate_intent,
            "external_task_intent": self._handle_delegate_intent,
        }
        handler = handlers.get(intent_type)
        if not handler:
            return {"status": "error", "error": f"Unknown intent: {intent_type}"}
        return handler(payload, source_agent)

    def _handle_discover_intent(self, payload: Dict, source: str) -> Dict:
        marketplace_str = payload.get("marketplace", "")
        capability = payload.get("capability", "")
        marketplace = None
        if marketplace_str:
            try:
                marketplace = MarketplaceType(marketplace_str)
            except ValueError:
                pass
        agents = self.discover_agents(marketplace, capability)
        return {"status": "ok", "agents": [a.to_dict() for a in agents]}

    def _handle_onboard_intent(self, payload: Dict, source: str) -> Dict:
        agent_id = payload.get("agent_id", "")
        if not agent_id:
            return {"status": "error", "error": "agent_id required"}
        record = self.onboard_agent(agent_id, approved_by=source)
        return {"status": record.status.value, "record": record.to_dict()}

    def _handle_delegate_intent(self, payload: Dict, source: str) -> Dict:
        agent_id = payload.get("agent_id", "")
        task_type = payload.get("task_type", "generic")
        task_payload = payload.get("payload", {})

        delegation = ExternalTaskDelegation(
            agent_id=agent_id,
            task_type=task_type,
            payload=task_payload,
            source_agent=source,
        )
        result = self.delegate_task(delegation)
        return {"status": result.status, "result": result.to_dict()}

    # ── Health ──────────────────────────────────────────────────────────────

    def health_check(self) -> Dict[str, Any]:
        uptime = time.time() - self._start_time
        stale = self.get_stale_agents()
        return {
            "organ_id": self.organ_id,
            "healthy": self._healthy and len(stale) < 3,
            "uptime_seconds": round(uptime, 1),
            "dry_run": self._dry_run,
            "firewall": self.firewall.to_dict(),
            "agents_discovered": self._stats["agents_discovered"],
            "agents_onboarded": self._stats["agents_onboarded"],
            "agents_rejected": self._stats["agents_rejected"],
            "stale_agents": stale,
            "stats": self._stats,
        }

    def get_status(self) -> Dict[str, Any]:
        return self.health_check()


# ── Module Singleton ─────────────────────────────────────────────────────────

SIMIAN_BRIDGE = SimianBridge.get_instance()
