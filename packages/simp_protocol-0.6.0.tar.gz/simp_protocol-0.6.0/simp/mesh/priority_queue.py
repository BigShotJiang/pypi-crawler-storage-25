"""
Intent Priority Queuing — L3 mesh module

Dedicated multi-level priority queue for intents (distinct from
Python's queue.PriorityQueue). Provides CRITICAL/HIGH/NORMAL/LOW
levels with FIFO ordering within each priority level.

Design:
- 4 priority levels: CRITICAL (4), HIGH (3), NORMAL (2), LOW (1)
- Thread-safe via RLock for concurrent enqueue/dequeue from mesh threads
- Within same priority level, intents are dequeued in FIFO order
- Internal implementation uses per-priority dequeues for clean FIFO
"""

import heapq
import logging
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class PriorityLevel(IntEnum):
    """Priority levels. Higher value = higher priority."""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class QueuedIntent:
    """An intent queued at a specific priority level.

    Each intent carries a monotonic sequence number within its priority
    level to enforce FIFO ordering within that level.
    """
    intent_id: str
    intent_type: str = "generic"
    payload: Dict[str, Any] = field(default_factory=dict)
    priority: PriorityLevel = PriorityLevel.NORMAL
    created_at: float = field(default_factory=time.time)
    sequence: int = 0  # Monotonic sequence within priority level
    metadata: Dict[str, Any] = field(default_factory=dict)
    sender: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "intent_id": self.intent_id,
            "intent_type": self.intent_type,
            "priority": self.priority.name,
            "priority_value": self.priority.value,
            "created_at": self.created_at,
            "sequence": self.sequence,
            "sender": self.sender,
        }


class PriorityQueue:
    """Multi-level priority queue for intents.

    Not to be confused with queue.PriorityQueue from the standard library.
    This implementation uses per-priority deques for clean FIFO ordering
    within each priority level, with higher-priority items always dequeued first.

    Priority levels (from highest to lowest):
        CRITICAL (4) — processed before everything
        HIGH (3)     — processed before normal/low
        NORMAL (2)   — default priority
        LOW (1)      — processed when nothing else pending
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)

        # Per-priority FIFO deques: PriorityLevel -> deque of QueuedIntent
        self._queues: Dict[PriorityLevel, deque] = {
            PriorityLevel.CRITICAL: deque(),
            PriorityLevel.HIGH: deque(),
            PriorityLevel.NORMAL: deque(),
            PriorityLevel.LOW: deque(),
        }

        # Fast intent lookup: intent_id -> QueuedIntent
        self._intent_map: Dict[str, QueuedIntent] = {}

        # Monotonic sequence counter for FIFO within each priority
        self._sequences: Dict[PriorityLevel, int] = {
            PriorityLevel.CRITICAL: 0,
            PriorityLevel.HIGH: 0,
            PriorityLevel.NORMAL: 0,
            PriorityLevel.LOW: 0,
        }

        # Stats
        self._stats = {
            "enqueued": 0,
            "dequeued": 0,
            "removed": 0,
            "cleared": 0,
        }

        logger.info("PriorityQueue initialized")

    # ------------------------------------------------------------------ #
    # Core Operations
    # ------------------------------------------------------------------ #

    def enqueue(self, intent: Dict[str, Any],
                priority_level: PriorityLevel = PriorityLevel.NORMAL) -> str:
        """Add an intent to the queue at the specified priority level.

        Args:
            intent: Intent dict. Must contain 'intent_id'. May contain
                    'intent_type', 'payload', 'sender'.
            priority_level: PriorityLevel enum value.

        Returns:
            The intent_id of the enqueued intent.
        """
        intent_id = intent.get("intent_id", str(uuid.uuid4()))

        with self._condition:
            seq = self._sequences[priority_level]
            self._sequences[priority_level] = seq + 1

            qi = QueuedIntent(
                intent_id=intent_id,
                intent_type=intent.get("intent_type", "generic"),
                payload=intent.get("payload", {}),
                priority=priority_level,
                created_at=time.time(),
                sequence=seq,
                metadata=intent.get("metadata", {}),
                sender=intent.get("sender", ""),
            )

            self._queues[priority_level].append(qi)
            self._intent_map[intent_id] = qi
            self._stats["enqueued"] += 1

            self._condition.notify()

        logger.debug("Enqueued %s at %s (seq=%d)",
                     intent_id, priority_level.name, seq)
        return intent_id

    def dequeue(self, timeout: Optional[float] = None) -> Optional[QueuedIntent]:
        """Remove and return the highest-priority intent.

        CRITICAL is dequeued before HIGH, HIGH before NORMAL, NORMAL before LOW.
        Within the same priority, FIFO ordering is maintained.

        Args:
            timeout: Maximum seconds to block if queue is empty.
                     None = block indefinitely, 0 = non-blocking.

        Returns:
            QueuedIntent or None if queue is empty and timeout expires.
        """
        with self._condition:
            deadline = time.time() + timeout if timeout is not None else None

            while True:
                # Check timeout
                if deadline is not None and time.time() >= deadline:
                    return None

                # Find highest-priority non-empty queue
                for level in (PriorityLevel.CRITICAL, PriorityLevel.HIGH,
                              PriorityLevel.NORMAL, PriorityLevel.LOW):
                    if self._queues[level]:
                        qi = self._queues[level].popleft()
                        self._intent_map.pop(qi.intent_id, None)
                        self._stats["dequeued"] += 1
                        logger.debug("Dequeued %s from %s (seq=%d)",
                                     qi.intent_id, level.name, qi.sequence)
                        return qi

                # All queues empty — wait
                if deadline is not None:
                    remaining = deadline - time.time()
                    if remaining <= 0:
                        return None
                    self._condition.wait(timeout=min(remaining, 1.0))
                else:
                    self._condition.wait(timeout=1.0)

    def dequeue_nonblock(self) -> Optional[QueuedIntent]:
        """Non-blocking dequeue. Returns None if queue is empty."""
        return self.dequeue(timeout=0)

    def peek(self) -> Optional[QueuedIntent]:
        """Return the highest-priority intent without removing it.

        Returns:
            QueuedIntent or None if queue is empty.
        """
        with self._condition:
            for level in (PriorityLevel.CRITICAL, PriorityLevel.HIGH,
                          PriorityLevel.NORMAL, PriorityLevel.LOW):
                if self._queues[level]:
                    return self._queues[level][0]
            return None

    def remove(self, intent_id: str) -> bool:
        """Remove a specific intent from the queue by its ID.

        This is an O(n) operation as it must scan the deque to find
        and remove the intent.

        Args:
            intent_id: ID of the intent to remove.

        Returns:
            True if intent was found and removed, False otherwise.
        """
        with self._condition:
            if intent_id not in self._intent_map:
                return False

            qi = self._intent_map[intent_id]
            level = qi.priority

            # Scan the deque to find and remove the intent
            found = False
            new_deque = deque()
            while self._queues[level]:
                item = self._queues[level].popleft()
                if item.intent_id == intent_id:
                    found = True
                    self._stats["removed"] += 1
                else:
                    new_deque.append(item)
            self._queues[level] = new_deque

            self._intent_map.pop(intent_id, None)

            if found:
                logger.debug("Removed %s from %s", intent_id, level.name)
            return found

    # ------------------------------------------------------------------ #
    # Queries
    # ------------------------------------------------------------------ #

    def length(self) -> int:
        """Return total number of intents across all priority levels."""
        with self._condition:
            return sum(len(q) for q in self._queues.values())

    def length_by_priority(self) -> Dict[str, int]:
        """Return dict mapping priority names to item counts.

        Returns:
            e.g., {"CRITICAL": 2, "HIGH": 0, "NORMAL": 5, "LOW": 1}
        """
        with self._condition:
            return {
                level.name: len(self._queues[level])
                for level in (
                    PriorityLevel.CRITICAL,
                    PriorityLevel.HIGH,
                    PriorityLevel.NORMAL,
                    PriorityLevel.LOW,
                )
            }

    def clear(self) -> int:
        """Remove all intents from the queue.

        Returns:
            Number of intents that were in the queue before clearing.
        """
        with self._condition:
            total = sum(len(q) for q in self._queues.values())
            for level in self._queues:
                self._queues[level].clear()
            self._intent_map.clear()
            self._stats["cleared"] += 1
            logger.info("Cleared %d intents from queue", total)
            return total

    def get_intent(self, intent_id: str) -> Optional[Dict[str, Any]]:
        """Get details for a specific intent by ID without removing it."""
        with self._condition:
            qi = self._intent_map.get(intent_id)
            if qi is None:
                return None
            return qi.to_dict()

    def list_intents(self) -> List[Dict[str, Any]]:
        """Return all intents in the queue, highest priority first."""
        with self._condition:
            result = []
            for level in (PriorityLevel.CRITICAL, PriorityLevel.HIGH,
                          PriorityLevel.NORMAL, PriorityLevel.LOW):
                for qi in self._queues[level]:
                    result.append(qi.to_dict())
            return result

    def get_stats(self) -> Dict[str, Any]:
        """Return queue statistics."""
        with self._condition:
            return {
                **dict(self._stats),
                "current_length": self.length(),
                "by_priority": self.length_by_priority(),
            }

    def is_empty(self) -> bool:
        """Return True if the queue has no intents."""
        return self.length() == 0


# ===================================================================== #
# Verification Block
# ===================================================================== #
if __name__ == "__main__":
    logging.basicConfig(level=logging.WARNING,
                        format="%(levelname)s: %(message)s")

    print("=== PriorityQueue Verification ===\n")

    q = PriorityQueue()

    # Verify initial state
    assert q.is_empty(), "Queue should be empty initially"
    assert q.length() == 0, "Length should be 0"
    assert q.peek() is None, "Peek on empty should return None"
    assert q.dequeue_nonblock() is None, "Dequeue on empty should return None"
    print("✓ Initial state correct")

    # Enqueue items at different priorities
    q.enqueue({"intent_id": "normal-1"}, PriorityLevel.NORMAL)
    q.enqueue({"intent_id": "low-1"}, PriorityLevel.LOW)
    q.enqueue({"intent_id": "critical-1"}, PriorityLevel.CRITICAL)
    q.enqueue({"intent_id": "high-1"}, PriorityLevel.HIGH)
    q.enqueue({"intent_id": "normal-2"}, PriorityLevel.NORMAL)

    assert q.length() == 5, f"Expected 5, got {q.length()}"
    print(f"✓ Enqueued 5 intents. Total: {q.length()}")

    # Check length by priority
    by_pri = q.length_by_priority()
    assert by_pri["CRITICAL"] == 1
    assert by_pri["HIGH"] == 1
    assert by_pri["NORMAL"] == 2
    assert by_pri["LOW"] == 1
    print(f"✓ By priority: {by_pri}")

    # Verify priority ordering (CRITICAL first)
    first = q.dequeue()
    assert first is not None and first.intent_id == "critical-1", \
        f"Expected critical-1, got {first.intent_id if first else None}"
    print(f"✓ Dequeue #1: {first.intent_id} ({first.priority.name})")

    second = q.dequeue()
    assert second is not None and second.intent_id == "high-1", \
        f"Expected high-1, got {second.intent_id if second else None}"
    print(f"✓ Dequeue #2: {second.intent_id} ({second.priority.name})")

    # Next two should be normal-1 then normal-2 (FIFO within NORMAL)
    third = q.dequeue()
    assert third is not None and third.intent_id == "normal-1", \
        f"Expected normal-1, got {third.intent_id if third else None}"
    print(f"✓ Dequeue #3: {third.intent_id} ({third.priority.name})")

    fourth = q.dequeue()
    assert fourth is not None and fourth.intent_id == "normal-2", \
        f"Expected normal-2, got {fourth.intent_id if fourth else None}"
    print(f"✓ Dequeue #4: {fourth.intent_id} ({fourth.priority.name})")

    fifth = q.dequeue()
    assert fifth is not None and fifth.intent_id == "low-1", \
        f"Expected low-1, got {fifth.intent_id if fifth else None}"
    print(f"✓ Dequeue #5: {fifth.intent_id} ({fifth.priority.name})")

    # Queue should be empty now
    assert q.is_empty(), "Queue should be empty after dequeuing all"
    print("✓ Queue empty after draining")

    # Test remove()
    q.enqueue({"intent_id": "keep-me"}, PriorityLevel.NORMAL)
    q.enqueue({"intent_id": "remove-me"}, PriorityLevel.HIGH)
    q.enqueue({"intent_id": "keep-me-2"}, PriorityLevel.LOW)

    removed = q.remove("remove-me")
    assert removed, "remove() should return True"
    assert q.length() == 2, f"Expected 2, got {q.length()}"
    assert q.get_intent("remove-me") is None, "remove-me should be gone"
    assert q.get_intent("keep-me") is not None, "keep-me should remain"
    print(f"✓ remove('remove-me') successful. Length: {q.length()}")

    # Test clear()
    q.clear()
    assert q.is_empty(), "Queue should be empty after clear"
    print(f"✓ clear() emptied the queue")

    # Test dequeue with timeout (blocking wait that times out)
    import time as _time
    start = _time.time()
    result = q.dequeue(timeout=0.5)
    elapsed = _time.time() - start
    assert result is None, "dequeue with timeout on empty should return None"
    assert 0.4 <= elapsed <= 1.0, \
        f"Timeout should be ~0.5s, took {elapsed:.2f}s"
    print(f"✓ dequeue(timeout=0.5) returned None after {elapsed:.2f}s")

    # Test peek
    q.enqueue({"intent_id": "peek-test"}, PriorityLevel.CRITICAL)
    peeked = q.peek()
    assert peeked is not None and peeked.intent_id == "peek-test", \
        "peek() should return the highest priority item"
    assert q.length() == 1, "peek() should not remove the item"
    print(f"✓ peek() = {peeked.intent_id}, length still {q.length()}")

    # Test stats
    stats = q.get_stats()
    print(f"✓ Stats: enqueued={stats['enqueued']}, dequeued={stats['dequeued']}")

    # Test concurrent safety (basic)
    results = []
    def producer():
        for i in range(10):
            q.enqueue({"intent_id": f"concurrent-{i}"}, PriorityLevel.NORMAL)

    def consumer():
        for _ in range(10):
            item = q.dequeue(timeout=2.0)
            if item:
                results.append(item.intent_id)

    t1 = threading.Thread(target=producer)
    t2 = threading.Thread(target=consumer)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    assert len(results) == 10, f"Expected 10 concurrent results, got {len(results)}"
    print(f"✓ Concurrent test: {len(results)} intents consumed successfully")

    q.clear()
    print("\n=== All PriorityQueue tests passed! ===\n")
