"""Cooperative two-phase commit (2PC) transaction manager.

Implements the 2PC protocol with phases:
    INIT → PREPARING → PREPARED → COMMITTING → COMMITTED
                      ↘ ABORTING → ABORTED

A 30-second timeout in PREPARING triggers auto-rollback.
Thread-safe throughout.
"""

from __future__ import annotations

import threading
import time
from enum import Enum
from typing import Any


class Phase(str, Enum):
    """Transaction phases for the two-phase commit protocol."""

    INIT = "INIT"
    PREPARING = "PREPARING"
    PREPARED = "PREPARED"
    COMMITTING = "COMMITTING"
    COMMITTED = "COMMITTED"
    ABORTING = "ABORTING"
    ABORTED = "ABORTED"


# Timeout in seconds for the PREPARING phase
_PREPARE_TIMEOUT = 30.0


class TwoPhaseCommit:
    """Thread-safe coordinator for the two-phase commit protocol.

    Participants are agents identified by string IDs.  The protocol:

    1. ``begin_transaction(tx_id, participants)``  → INIT
    2. ``prepare(tx_id, agent_id)``                → PREPARING → PREPARED
       ``abort_prepare(tx_id, agent_id, reason)``  → PREPARING → ABORTING
    3. ``commit(tx_id)``                           → COMMITTING → COMMITTED
    4. ``rollback(tx_id)``                         → ABORTING → ABORTED

    If not all participants have responded within 30 seconds of entering
    PREPARING, the coordinator automatically rolls back.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # tx_id -> {
        #   "tx_id": str,
        #   "phase": Phase,
        #   "participants": set[str],
        #   "prepared": set[str],
        #   "committed": set[str],
        #   "aborted": list[tuple[str, str]],  # (agent_id, reason)
        #   "prepare_start": float | None,
        #   "finalized": bool,
        # }
        self._transactions: dict[str, dict[str, Any]] = {}
        self._timer: threading.Timer | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def begin_transaction(
        self,
        tx_id: str,
        participants: list[str],
    ) -> bool:
        """Start a new two-phase commit transaction.

        Args:
            tx_id: Unique transaction identifier.
            participants: List of agent IDs participating in the commit.

        Returns:
            True if transaction was created, False if tx_id already exists
            or participants list is empty.
        """
        if not tx_id or not participants:
            return False
        unique_participants = list(dict.fromkeys(participants))
        with self._lock:
            if tx_id in self._transactions:
                return False
            self._transactions[tx_id] = {
                "tx_id": tx_id,
                "phase": Phase.INIT,
                "participants": set(unique_participants),
                "prepared": set(),
                "committed": set(),
                "aborted": [],  # list of (agent_id, reason)
                "prepare_start": None,
                "finalized": False,
            }
        return True

    def prepare(self, tx_id: str, agent_id: str) -> bool:
        """Vote 'prepare' (ready to commit) for a transaction.

        Transitions the phase to PREPARING if this is the first vote,
        then to PREPARED when *all* participants have voted prepare.

        Args:
            tx_id: Transaction identifier.
            agent_id: The agent casting the vote.

        Returns:
            True if the vote was recorded, False if the agent is not a
            participant, the transaction is in the wrong phase, or is
            already finalized.
        """
        with self._lock:
            tx = self._transactions.get(tx_id)
            if tx is None or tx["finalized"]:
                return False
            if agent_id not in tx["participants"]:
                return False

            # Only accept prepare votes in INIT or PREPARING
            if tx["phase"] not in (Phase.INIT, Phase.PREPARING):
                return False

            # Transition to PREPARING on first vote
            if tx["phase"] == Phase.INIT:
                tx["phase"] = Phase.PREPARING
                tx["prepare_start"] = time.time()
                self._schedule_timeout(tx_id)

            tx["prepared"].add(agent_id)

            # Check if all participants have prepared
            if tx["prepared"] == tx["participants"]:
                tx["phase"] = Phase.PREPARED
                # Cancel timeout since we're now fully prepared
                self._cancel_timeout()
        return True

    def abort_prepare(self, tx_id: str, agent_id: str, reason: str = "") -> bool:
        """Vote to abort during the prepare phase.

        Args:
            tx_id: Transaction identifier.
            agent_id: The agent casting the vote.
            reason: Optional reason for the abort.

        Returns:
            True if the abort vote was recorded.
        """
        with self._lock:
            tx = self._transactions.get(tx_id)
            if tx is None or tx["finalized"]:
                return False
            if agent_id not in tx["participants"]:
                return False
            if tx["phase"] not in (Phase.INIT, Phase.PREPARING):
                return False

            tx["phase"] = Phase.ABORTING
            tx["aborted"].append((agent_id, reason))
            tx["phase"] = Phase.ABORTED
            tx["finalized"] = True
            self._cancel_timeout()
        return True

    def commit(self, tx_id: str) -> bool:
        """Commit the transaction after all participants have prepared.

        Transitions PREPARED → COMMITTING → COMMITTED.

        Args:
            tx_id: Transaction identifier.

        Returns:
            True if commit was successful, False if phase is not PREPARED.
        """
        with self._lock:
            tx = self._transactions.get(tx_id)
            if tx is None or tx["finalized"]:
                return False
            if tx["phase"] != Phase.PREPARED:
                return False

            tx["phase"] = Phase.COMMITTING
            # Record all participants as committed
            tx["committed"] = set(tx["participants"])
            tx["phase"] = Phase.COMMITTED
            tx["finalized"] = True
        return True

    def rollback(self, tx_id: str) -> bool:
        """Roll back the transaction (abort from non-PREPARED phase).

        Can be called from INIT, PREPARING, or PREPARED.

        Args:
            tx_id: Transaction identifier.

        Returns:
            True if rollback was initiated.
        """
        with self._lock:
            tx = self._transactions.get(tx_id)
            if tx is None or tx["finalized"]:
                return False
            if tx["phase"] in (Phase.COMMITTED, Phase.ABORTED):
                return False

            tx["phase"] = Phase.ABORTING
            # If no specific abort reasons exist, add a coordinator abort
            if not tx["aborted"]:
                tx["aborted"].append(("coordinator", "Coordinator-initiated rollback"))
            tx["phase"] = Phase.ABORTED
            tx["finalized"] = True
            self._cancel_timeout()
        return True

    def get_status(self, tx_id: str) -> dict[str, Any] | None:
        """Return the current status of a transaction.

        Returns a dict with keys:
            tx_id, phase, participants (list), prepared (list),
            committed (list), aborted (list of (agent, reason)),
            finalized (bool)
        or None if the transaction doesn't exist.
        """
        with self._lock:
            tx = self._transactions.get(tx_id)
            if tx is None:
                return None
            return {
                "tx_id": tx["tx_id"],
                "phase": tx["phase"].value,
                "participants": sorted(tx["participants"]),
                "prepared": sorted(tx["prepared"]),
                "committed": sorted(tx["committed"]),
                "aborted": list(tx["aborted"]),
                "finalized": tx["finalized"],
            }

    def remove_transaction(self, tx_id: str) -> bool:
        """Remove a completed/finalized transaction from tracking.

        Args:
            tx_id: Transaction identifier.

        Returns:
            True if removed, False if not found.
        """
        with self._lock:
            return self._transactions.pop(tx_id, None) is not None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _schedule_timeout(self, tx_id: str) -> None:
        """Schedule auto-rollback after the prepare timeout."""
        self._cancel_timeout()
        self._timer = threading.Timer(_PREPARE_TIMEOUT, self._auto_rollback, args=[tx_id])
        self._timer.daemon = True
        self._timer.start()

    def _cancel_timeout(self) -> None:
        """Cancel the pending timeout timer."""
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

    def _auto_rollback(self, tx_id: str) -> None:
        """Called when the prepare phase times out."""
        with self._lock:
            tx = self._transactions.get(tx_id)
            if tx is None or tx["finalized"]:
                return
            if tx["phase"] == Phase.PREPARING:
                tx["phase"] = Phase.ABORTING
                tx["aborted"].append(("timeout", "Prepare phase timed out after 30s"))
                tx["phase"] = Phase.ABORTED
                tx["finalized"] = True


# -----------------------------------------------------------------------
# Verification block
# -----------------------------------------------------------------------
if __name__ == "__main__":
    tpc = TwoPhaseCommit()

    # Start a transaction
    ok = tpc.begin_transaction("tx-001", ["agent-a", "agent-b", "agent-c"])
    assert ok, "begin_transaction should succeed"
    assert not tpc.begin_transaction("tx-001", ["x"]), "Duplicate ID should fail"

    # Check initial status
    status = tpc.get_status("tx-001")
    assert status is not None
    assert status["phase"] == Phase.INIT.value

    # Prepare votes
    tpc.prepare("tx-001", "agent-a")
    status = tpc.get_status("tx-001")
    assert status["phase"] == Phase.PREPARING.value, f"Expected PREPARING, got {status['phase']}"

    tpc.prepare("tx-001", "agent-b")
    assert tpc.get_status("tx-001")["phase"] == Phase.PREPARING.value

    tpc.prepare("tx-001", "agent-c")
    status = tpc.get_status("tx-001")
    assert status["phase"] == Phase.PREPARED.value, f"Expected PREPARED, got {status['phase']}"
    assert len(status["prepared"]) == 3

    # Commit
    ok = tpc.commit("tx-001")
    assert ok, "commit should succeed"
    status = tpc.get_status("tx-001")
    assert status["phase"] == Phase.COMMITTED.value, f"Expected COMMITTED, got {status['phase']}"
    assert status["finalized"] is True

    # Test abort path
    tpc2 = TwoPhaseCommit()
    tpc2.begin_transaction("tx-002", ["a1", "a2"])
    tpc2.prepare("tx-002", "a1")
    tpc2.abort_prepare("tx-002", "a2", "Insufficient funds")
    status = tpc2.get_status("tx-002")
    assert status["phase"] == Phase.ABORTED.value, f"Expected ABORTED, got {status['phase']}"
    assert len(status["aborted"]) == 1
    assert status["aborted"][0][0] == "a2"

    # Test coordinator rollback
    tpc3 = TwoPhaseCommit()
    tpc3.begin_transaction("tx-003", ["a1", "a2"])
    tpc3.prepare("tx-003", "a1")
    tpc3.rollback("tx-003")
    status = tpc3.get_status("tx-003")
    assert status["phase"] == Phase.ABORTED.value

    # Test ineligible participant
    assert tpc3.prepare("tx-003", "unknown") is False
    assert tpc3.abort_prepare("tx-003", "unknown", "x") is False

    # Test remove
    tpc3.remove_transaction("tx-003")
    assert tpc3.get_status("tx-003") is None

    # Test commit on non-PREPARED fails
    tpc4 = TwoPhaseCommit()
    tpc4.begin_transaction("tx-004", ["a1", "a2"])
    assert tpc4.commit("tx-004") is False, "Cannot commit from INIT"

    print("All TwoPhaseCommit tests passed.")
