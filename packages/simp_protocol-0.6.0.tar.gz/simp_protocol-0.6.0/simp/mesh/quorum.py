"""Agent quorum for state changes.

Implements a thread-safe quorum voting mechanism where at least 67%
of registered agents must approve a change before it is enacted.
"""

from __future__ import annotations

import math
import threading
import time
from typing import Any


class QuorumManager:
    """Thread-safe agent quorum for approving or rejecting state changes.

    A quorum requires >= 67% approval (rounded up, minimum 2 agents)
    from the registered agent set for a given change proposal.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # change_id -> {
        #   "change_id": str,
        #   "desc": str,
        #   "agent_ids": list[str],
        #   "approvals": set[str],
        #   "rejections": set[str],
        #   "timestamp": float,
        #   "finalized": bool,
        # }
        self._changes: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def propose_change(
        self,
        change_id: str,
        change_desc: str,
        agent_ids: list[str],
    ) -> bool:
        """Propose a new state change for quorum voting.

        Args:
            change_id: Unique identifier for this change proposal.
            change_desc: Human-readable description of the change.
            agent_ids: List of agent IDs that are eligible to vote.

        Returns:
            True if the proposal was created, False if change_id already exists.
        """
        if not change_id or not agent_ids:
            return False
        # Deduplicate while preserving insertion order-ish
        unique_agents = list(dict.fromkeys(agent_ids))
        if len(unique_agents) < 2:
            return False

        with self._lock:
            if change_id in self._changes:
                return False
            self._changes[change_id] = {
                "change_id": change_id,
                "desc": change_desc,
                "agent_ids": unique_agents,
                "approvals": set(),
                "rejections": set(),
                "timestamp": time.time(),
                "finalized": False,
            }
        return True

    def approve(self, change_id: str, agent_id: str) -> bool:
        """Cast an approval vote for a change proposal.

        Args:
            change_id: The change to approve.
            agent_id: The agent casting the vote.

        Returns:
            True if the vote was recorded, False if the agent is ineligible,
            the change doesn't exist, or it is already finalized.
        """
        with self._lock:
            change = self._changes.get(change_id)
            if change is None or change["finalized"]:
                return False
            if agent_id not in change["agent_ids"]:
                return False
            change["approvals"].add(agent_id)
            # Remove from rejections if they previously rejected
            change["rejections"].discard(agent_id)
        return True

    def reject(self, change_id: str, agent_id: str) -> bool:
        """Cast a rejection vote for a change proposal.

        Args:
            change_id: The change to reject.
            agent_id: The agent casting the vote.

        Returns:
            True if the vote was recorded, False if the agent is ineligible,
            the change doesn't exist, or it is already finalized.
        """
        with self._lock:
            change = self._changes.get(change_id)
            if change is None or change["finalized"]:
                return False
            if agent_id not in change["agent_ids"]:
                return False
            change["rejections"].add(agent_id)
            change["approvals"].discard(agent_id)
        return True

    def get_status(self, change_id: str) -> dict[str, Any] | None:
        """Return the current status of a change proposal.

        Returns a dict with keys:
            change_id, desc, approvals (list), rejections (list),
            total, approved (bool), finalized (bool)
        or None if the change doesn't exist.
        """
        with self._lock:
            change = self._changes.get(change_id)
            if change is None:
                return None
            total = len(change["agent_ids"])
            approvals = list(change["approvals"])
            rejections = list(change["rejections"])
            approved = self._quorum_met_locked(change)
            return {
                "change_id": change["change_id"],
                "desc": change["desc"],
                "approvals": approvals,
                "rejections": rejections,
                "total": total,
                "approved": approved,
                "finalized": change["finalized"],
            }

    def is_quorum_met(self, change_id: str) -> bool:
        """Check whether quorum (>= 67%) has approved the change.

        Args:
            change_id: The change proposal to check.

        Returns:
            True if approvals meet or exceed the 67% threshold.
        """
        with self._lock:
            change = self._changes.get(change_id)
            if change is None:
                return False
            return self._quorum_met_locked(change)

    def get_pending_changes(self) -> list[dict[str, Any]]:
        """Return all change proposals that are not yet finalized."""
        results: list[dict[str, Any]] = []
        with self._lock:
            for cid, change in self._changes.items():
                if not change["finalized"]:
                    total = len(change["agent_ids"])
                    results.append({
                        "change_id": cid,
                        "desc": change["desc"],
                        "approvals": list(change["approvals"]),
                        "rejections": list(change["rejections"]),
                        "total": total,
                        "approved": self._quorum_met_locked(change),
                        "finalized": False,
                    })
        return results

    def finalize(self, change_id: str) -> bool:
        """Mark a change proposal as finalized (no more voting).

        Args:
            change_id: The change to finalize.

        Returns:
            True if finalized, False if change doesn't exist.
        """
        with self._lock:
            change = self._changes.get(change_id)
            if change is None:
                return False
            change["finalized"] = True
        return True

    def remove_change(self, change_id: str) -> bool:
        """Remove a completed/expired change proposal from tracking.

        Args:
            change_id: The change to remove.

        Returns:
            True if removed, False if not found.
        """
        with self._lock:
            return self._changes.pop(change_id, None) is not None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _quorum_met_locked(self, change: dict[str, Any]) -> bool:
        """Check quorum (caller must hold self._lock)."""
        total = len(change["agent_ids"])
        if total == 0:
            return False
        # 67% threshold, rounded up, minimum 2
        threshold = max(2, math.ceil(total * 0.67))
        return len(change["approvals"]) >= threshold


# -----------------------------------------------------------------------
# Verification block
# -----------------------------------------------------------------------
if __name__ == "__main__":
    qm = QuorumManager()

    # Propose a change with 3 agents
    ok = qm.propose_change("ch-001", "Upgrade broker protocol", ["agent-a", "agent-b", "agent-c"])
    assert ok, "propose_change should succeed"
    assert not qm.propose_change("ch-001", "Duplicate", ["x", "y"]), "Duplicate ID should fail"

    # Vote: one approval is not enough
    qm.approve("ch-001", "agent-a")
    status = qm.get_status("ch-001")
    assert status is not None
    assert status["approved"] is False, "1/3 should not meet quorum"

    # Second approval → quorum met (2 >= ceil(3 * 0.67) = 3... wait, ceil(2.01) = 3)
    # Actually: 3 * 0.67 = 2.01, ceil = 3, min(3, 2) = 3 → need 3/3 for total=3
    # Let's test with 4 agents to get a proper threshold
    qm2 = QuorumManager()
    qm2.propose_change("ch-002", "Config update", ["a1", "a2", "a3", "a4"])
    # 4 * 0.67 = 2.68, ceil = 3, max(3, 2) = 3 → need 3/4
    qm2.approve("ch-002", "a1")
    qm2.approve("ch-002", "a2")
    assert qm2.is_quorum_met("ch-002") is False, "2/4 should not meet quorum"
    qm2.approve("ch-002", "a3")
    assert qm2.is_quorum_met("ch-002") is True, "3/4 should meet quorum"

    # Test rejection
    qm2.reject("ch-002", "a3")
    assert qm2.is_quorum_met("ch-002") is False, "After rejection quorum should drop"

    # Test pending changes
    pending = qm.get_pending_changes()
    assert any(c["change_id"] == "ch-001" for c in pending)

    # Test finalize
    qm.finalize("ch-001")
    assert qm.approve("ch-001", "agent-b") is False, "Finalized change should reject votes"
    assert qm.get_status("ch-001")["finalized"] is True

    # Test remove
    qm.remove_change("ch-001")
    assert qm.get_status("ch-001") is None, "Removed change should return None"

    # Ineligible agent
    assert qm.approve("ch-002", "nonexistent") is False

    # Edge: min 2 agents
    qm3 = QuorumManager()
    assert qm3.propose_change("ch-003", "Minor", ["single"]) is False, "Need >= 2 agents"

    print("All QuorumManager tests passed.")
