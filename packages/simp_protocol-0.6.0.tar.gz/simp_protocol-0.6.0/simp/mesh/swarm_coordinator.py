"""
Multi-Agent Swarm Coordinator — Level 3 Swarm Coordination
===========================================================

Provides an M:T (many-to-many) messaging framework for coordinating
swarms of agents working collaboratively on intents.

A single swarm has:
  - One leader agent (assigns subtasks)
  - Multiple member agents (execute subtasks)
  - An internal message queue for thread-safe communication

Design:
  - Thread-safe via RLock
  - Pure Python (no external deps)
  - Subtask lifecycle: pending → in_progress → complete | failed
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class SubtaskStatus(Enum):
    """Lifecycle states for a subtask within a swarm."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    FAILED = "failed"


@dataclass
class Subtask:
    """A single unit of work assigned to one agent in the swarm."""
    subtask_id: str
    agent_id: str
    description: str
    status: SubtaskStatus = SubtaskStatus.PENDING
    result: Any = None
    error: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    assigned_at: Optional[float] = None
    completed_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "subtask_id": self.subtask_id,
            "agent_id": self.agent_id,
            "description": self.description,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at,
            "assigned_at": self.assigned_at,
            "completed_at": self.completed_at,
        }


@dataclass
class Swarm:
    """Represents a collection of agents working on a shared intent."""
    swarm_id: str
    intent_id: str
    leader_id: Optional[str] = None
    members: List[str] = field(default_factory=list)
    subtasks: Dict[str, Subtask] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    dismissed: bool = False
    dismissed_at: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "swarm_id": self.swarm_id,
            "intent_id": self.intent_id,
            "leader_id": self.leader_id,
            "members": list(self.members),
            "subtask_count": len(self.subtasks),
            "created_at": self.created_at,
            "dismissed": self.dismissed,
            "dismissed_at": self.dismissed_at,
        }


class SwarmCoordinator:
    """
    Coordinates multi-agent swarms using M:T (many-to-many) messaging.

    A swarm is created for a specific intent, with a set of member agents.
    One member is designated as the leader, who can delegate subtasks
    to other members. Members report completion or failure of subtasks.

    Usage:
        coord = SwarmCoordinator()
        swarm = coord.create_swarm("intent_001", ["agent_a", "agent_b", "agent_c"])
        coord.assign_leader(swarm.swarm_id, "agent_a")
        coord.delegate_subtask(swarm.swarm_id, "agent_b", "Process dataset A")
        coord.report_subtask_complete(swarm.swarm_id, "agent_b", subtask_id, result)
        status = coord.get_swarm_status(swarm.swarm_id)
        results = coord.dismiss_swarm(swarm.swarm_id)
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._swarms: Dict[str, Swarm] = {}
        # Internal message queue: list of (swarm_id, sender, recipient, msg_type, payload)
        self._message_queue: List[Tuple[str, str, str, str, Dict[str, Any]]] = []
        self._message_callbacks: List[Callable[[str, str, str, str, Dict[str, Any]], None]] = []

    # ── Swarm Lifecycle ──────────────────────────────────────────────────────

    def create_swarm(self, intent_id: str, agent_ids: List[str]) -> Swarm:
        """
        Create a new swarm to work on an intent.

        Args:
            intent_id: The intent the swarm will work toward.
            agent_ids: List of agent IDs that will be members of the swarm.

        Returns:
            The newly created Swarm instance.

        Raises:
            ValueError: If agent_ids is empty.
        """
        if not agent_ids:
            raise ValueError("Cannot create a swarm with zero agents")

        swarm_id = str(uuid.uuid4())
        swarm = Swarm(
            swarm_id=swarm_id,
            intent_id=intent_id,
            members=list(agent_ids),
        )

        with self._lock:
            self._swarms[swarm_id] = swarm
            self._enqueue_message(swarm_id, "system", "*", "swarm_created", {
                "swarm_id": swarm_id,
                "intent_id": intent_id,
                "agent_ids": agent_ids,
            })

        logger.info(
            "Swarm %s created for intent %s with %d agents",
            swarm_id[:8], intent_id, len(agent_ids),
        )
        return swarm

    def assign_leader(self, swarm_id: str, agent_id: str) -> bool:
        """
        Promote an agent to leader of the swarm.

        The leader must be a member of the swarm.

        Args:
            swarm_id: The ID of the swarm.
            agent_id: The agent ID to designate as leader.

        Returns:
            True if the leader was assigned; False if the swarm does not
            exist or the agent is not a member.
        """
        with self._lock:
            swarm = self._swarms.get(swarm_id)
            if swarm is None:
                logger.warning("Cannot assign leader: swarm %s not found", swarm_id[:8])
                return False
            if agent_id not in swarm.members:
                logger.warning(
                    "Cannot assign leader: agent %s not in swarm %s",
                    agent_id, swarm_id[:8],
                )
                return False

            swarm.leader_id = agent_id
            self._enqueue_message(swarm_id, "system", agent_id, "leader_assigned", {
                "swarm_id": swarm_id,
                "agent_id": agent_id,
            })

            logger.info("Agent %s assigned as leader of swarm %s", agent_id, swarm_id[:8])
            return True

    def get_leader(self, swarm_id: str) -> Optional[str]:
        """
        Get the leader agent ID for a swarm.

        Args:
            swarm_id: The ID of the swarm.

        Returns:
            The leader's agent ID, or None if no leader is assigned
            or the swarm does not exist.
        """
        with self._lock:
            swarm = self._swarms.get(swarm_id)
            if swarm is None:
                return None
            return swarm.leader_id

    def dismiss_swarm(self, swarm_id: str) -> Dict[str, Any]:
        """
        End the swarm and return aggregated results.

        Once dismissed, no more subtasks can be assigned for this swarm.

        Args:
            swarm_id: The ID of the swarm to dismiss.

        Returns:
            A dict with aggregated results, or an empty dict if the swarm
            does not exist.

        Raises:
            ValueError: If the swarm has already been dismissed.
        """
        with self._lock:
            swarm = self._swarms.get(swarm_id)
            if swarm is None:
                logger.warning("Cannot dismiss: swarm %s not found", swarm_id[:8])
                return {}
            if swarm.dismissed:
                raise ValueError(f"Swarm {swarm_id[:8]} has already been dismissed")

            swarm.dismissed = True
            swarm.dismissed_at = time.time()

            # Aggregate subtask results
            subtasks = list(swarm.subtasks.values())
            pending = [s for s in subtasks if s.status == SubtaskStatus.PENDING]
            in_progress = [s for s in subtasks if s.status == SubtaskStatus.IN_PROGRESS]
            complete = [s for s in subtasks if s.status == SubtaskStatus.COMPLETE]
            failed = [s for s in subtasks if s.status == SubtaskStatus.FAILED]

            aggregated = {
                "swarm_id": swarm_id,
                "intent_id": swarm.intent_id,
                "leader_id": swarm.leader_id,
                "members": list(swarm.members),
                "total_subtasks": len(subtasks),
                "pending": len(pending),
                "in_progress": len(in_progress),
                "complete": len(complete),
                "failed": len(failed),
                "complete_results": [s.to_dict() for s in complete],
                "failed_results": [s.to_dict() for s in failed],
                "dismissed_at": swarm.dismissed_at,
            }

            self._enqueue_message(swarm_id, "system", "*", "swarm_dismissed", {
                "swarm_id": swarm_id,
                "aggregated": aggregated,
            })

            logger.info(
                "Swarm %s dismissed (%d complete, %d failed)",
                swarm_id[:8], len(complete), len(failed),
            )
            return aggregated

    # ── Subtask Delegation ───────────────────────────────────────────────────

    def delegate_subtask(
        self,
        swarm_id: str,
        agent_id: str,
        subtask: str,
    ) -> Optional[str]:
        """
        Assign a subtask from the leader to a member agent.

        Args:
            swarm_id: The ID of the swarm.
            agent_id: The member agent to delegate to.
            subtask: A description of the subtask work.

        Returns:
            The subtask_id if delegated successfully, or None if the swarm
            does not exist, the agent is not a member, there is no leader,
            or the swarm has been dismissed.
        """
        with self._lock:
            swarm = self._swarms.get(swarm_id)
            if swarm is None:
                logger.warning("Cannot delegate: swarm %s not found", swarm_id[:8])
                return None
            if swarm.dismissed:
                logger.warning("Cannot delegate: swarm %s has been dismissed", swarm_id[:8])
                return None
            if swarm.leader_id is None:
                logger.warning("Cannot delegate: swarm %s has no leader", swarm_id[:8])
                return None
            if agent_id not in swarm.members:
                logger.warning(
                    "Cannot delegate: agent %s not in swarm %s",
                    agent_id, swarm_id[:8],
                )
                return None

            subtask_id = str(uuid.uuid4())
            st = Subtask(
                subtask_id=subtask_id,
                agent_id=agent_id,
                description=subtask,
                status=SubtaskStatus.IN_PROGRESS,
                assigned_at=time.time(),
            )
            swarm.subtasks[subtask_id] = st

            self._enqueue_message(swarm_id, swarm.leader_id, agent_id, "subtask_delegated", {
                "subtask_id": subtask_id,
                "description": subtask,
            })

            logger.info(
                "Subtask %s delegated to agent %s in swarm %s",
                subtask_id[:8], agent_id, swarm_id[:8],
            )
            return subtask_id

    def report_subtask_complete(
        self,
        swarm_id: str,
        agent_id: str,
        subtask_id: str,
        result: Any,
    ) -> bool:
        """
        Report a subtask as successfully completed by a member.

        Args:
            swarm_id: The ID of the swarm.
            agent_id: The member agent reporting completion.
            subtask_id: The ID of the subtask being completed.
            result: The result data from the completed subtask.

        Returns:
            True if the report was accepted; False if the swarm or subtask
            does not exist, or the agent doesn't match the assignee.
        """
        with self._lock:
            swarm = self._swarms.get(swarm_id)
            if swarm is None:
                return False

            st = swarm.subtasks.get(subtask_id)
            if st is None:
                logger.warning(
                    "Subtask %s not found in swarm %s",
                    subtask_id[:8], swarm_id[:8],
                )
                return False
            if st.agent_id != agent_id:
                logger.warning(
                    "Agent %s is not the assignee of subtask %s",
                    agent_id, subtask_id[:8],
                )
                return False

            st.status = SubtaskStatus.COMPLETE
            st.result = result
            st.completed_at = time.time()

            self._enqueue_message(swarm_id, agent_id, swarm.leader_id or "*", "subtask_complete", {
                "subtask_id": subtask_id,
                "result": result,
            })

            logger.info(
                "Subtask %s completed by agent %s in swarm %s",
                subtask_id[:8], agent_id, swarm_id[:8],
            )
            return True

    def report_subtask_failed(
        self,
        swarm_id: str,
        agent_id: str,
        subtask_id: str,
        error: str,
    ) -> bool:
        """
        Report a subtask as failed by a member.

        Args:
            swarm_id: The ID of the swarm.
            agent_id: The member agent reporting failure.
            subtask_id: The ID of the subtask that failed.
            error: A description of the error that occurred.

        Returns:
            True if the report was accepted; False if the swarm or subtask
            does not exist, or the agent doesn't match the assignee.
        """
        with self._lock:
            swarm = self._swarms.get(swarm_id)
            if swarm is None:
                return False

            st = swarm.subtasks.get(subtask_id)
            if st is None:
                logger.warning(
                    "Subtask %s not found in swarm %s",
                    subtask_id[:8], swarm_id[:8],
                )
                return False
            if st.agent_id != agent_id:
                logger.warning(
                    "Agent %s is not the assignee of subtask %s",
                    agent_id, subtask_id[:8],
                )
                return False

            st.status = SubtaskStatus.FAILED
            st.error = error
            st.completed_at = time.time()

            self._enqueue_message(swarm_id, agent_id, swarm.leader_id or "*", "subtask_failed", {
                "subtask_id": subtask_id,
                "error": error,
            })

            logger.info(
                "Subtask %s failed by agent %s in swarm %s: %s",
                subtask_id[:8], agent_id, swarm_id[:8], error,
            )
            return True

    # ── Status & Introspection ───────────────────────────────────────────────

    def get_swarm_status(self, swarm_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the full status of a swarm.

        Args:
            swarm_id: The ID of the swarm.

        Returns:
            A dict with leader, members, and subtask counts by status,
            or None if the swarm does not exist.
        """
        with self._lock:
            swarm = self._swarms.get(swarm_id)
            if swarm is None:
                return None

            subtasks = list(swarm.subtasks.values())
            pending = [s for s in subtasks if s.status == SubtaskStatus.PENDING]
            in_progress = [s for s in subtasks if s.status == SubtaskStatus.IN_PROGRESS]
            complete = [s for s in subtasks if s.status == SubtaskStatus.COMPLETE]
            failed = [s for s in subtasks if s.status == SubtaskStatus.FAILED]

            return {
                "swarm_id": swarm_id,
                "intent_id": swarm.intent_id,
                "leader_id": swarm.leader_id,
                "members": list(swarm.members),
                "subtasks": {
                    "pending": [s.to_dict() for s in pending],
                    "in_progress": [s.to_dict() for s in in_progress],
                    "complete": [s.to_dict() for s in complete],
                    "failed": [s.to_dict() for s in failed],
                    "total": len(subtasks),
                },
                "created_at": swarm.created_at,
                "dismissed": swarm.dismissed,
            }

    def get_swarm_members(self, swarm_id: str) -> Optional[List[str]]:
        """
        Get the list of member agent IDs for a swarm.

        Args:
            swarm_id: The ID of the swarm.

        Returns:
            A list of member agent IDs, or None if the swarm does not exist.
        """
        with self._lock:
            swarm = self._swarms.get(swarm_id)
            if swarm is None:
                return None
            return list(swarm.members)

    # ── Messaging ────────────────────────────────────────────────────────────

    def send_message(
        self,
        swarm_id: str,
        sender: str,
        recipient: str,
        msg_type: str,
        payload: Dict[str, Any],
    ) -> bool:
        """
        Send an M:T message within a swarm context.

        Args:
            swarm_id: The target swarm.
            sender: The sending agent ID.
            recipient: The recipient agent ID ("*" for all).
            msg_type: A message type identifier.
            payload: The message payload.

        Returns:
            True if the message was queued; False if the swarm does not exist.
        """
        with self._lock:
            if swarm_id not in self._swarms:
                return False
            self._enqueue_message(swarm_id, sender, recipient, msg_type, payload)
            return True

    def drain_messages(
        self,
        swarm_id: Optional[str] = None,
        max_messages: int = 100,
    ) -> List[Tuple[str, str, str, str, Dict[str, Any]]]:
        """
        Drain pending messages from the internal queue.

        Args:
            swarm_id: If set, only drain messages for this swarm.
            max_messages: Maximum number of messages to drain.

        Returns:
            A list of (swarm_id, sender, recipient, msg_type, payload) tuples.
        """
        with self._lock:
            if swarm_id is None:
                to_drain = self._message_queue[:max_messages]
                self._message_queue = self._message_queue[max_messages:]
            else:
                matching = []
                remaining = []
                for msg in self._message_queue:
                    if msg[0] == swarm_id and len(matching) < max_messages:
                        matching.append(msg)
                    else:
                        remaining.append(msg)
                self._message_queue = remaining
                to_drain = matching
            return to_drain

    def register_message_callback(
        self,
        callback: Callable[[str, str, str, str, Dict[str, Any]], None],
    ) -> None:
        """
        Register a callback invoked on every enqueued message.

        The callback receives (swarm_id, sender, recipient, msg_type, payload).
        """
        self._message_callbacks.append(callback)

    def _enqueue_message(
        self,
        swarm_id: str,
        sender: str,
        recipient: str,
        msg_type: str,
        payload: Dict[str, Any],
    ) -> None:
        """Internal: enqueue a message and notify callbacks."""
        msg = (swarm_id, sender, recipient, msg_type, payload)
        self._message_queue.append(msg)
        for cb in self._message_callbacks:
            try:
                cb(swarm_id, sender, recipient, msg_type, payload)
            except Exception as exc:
                logger.error("Message callback error: %s", exc)

    # ── Utility ──────────────────────────────────────────────────────────────

    def list_swarms(self) -> List[Dict[str, Any]]:
        """Return summary dicts for all tracked swarms."""
        with self._lock:
            return [s.to_dict() for s in self._swarms.values()]

    def get_swarm(self, swarm_id: str) -> Optional[Swarm]:
        """Direct access to the Swarm dataclass (thread-safe)."""
        with self._lock:
            return self._swarms.get(swarm_id)


# ═══════════════════════════════════════════════════════════════════════════
# Verification Block
# ═══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 60)
    print("SwarmCoordinator Verification")
    print("=" * 60)

    coord = SwarmCoordinator()

    # 1. Create a swarm
    swarm = coord.create_swarm("intent_trade_optimization", ["agent_a", "agent_b", "agent_c"])
    assert swarm is not None
    print(f"[✓] Created swarm {swarm.swarm_id[:8]} for intent: {swarm.intent_id}")

    # 2. Assign leader
    result = coord.assign_leader(swarm.swarm_id, "agent_a")
    assert result is True
    assert coord.get_leader(swarm.swarm_id) == "agent_a"
    print(f"[✓] Leader assigned: agent_a")

    # 3. Verify leader retrieval
    leader = coord.get_leader(swarm.swarm_id)
    assert leader == "agent_a"
    print(f"[✓] get_leader() returns: {leader}")

    # 4. Delegate subtasks
    st1 = coord.delegate_subtask(swarm.swarm_id, "agent_b", "Analyze market data")
    st2 = coord.delegate_subtask(swarm.swarm_id, "agent_c", "Compute optimal portfolio")
    st3 = coord.delegate_subtask(swarm.swarm_id, "agent_b", "Validate risk parameters")
    assert all([st1, st2, st3])
    print(f"[✓] Delegated 3 subtasks")

    # 5. Report subtask complete
    result = coord.report_subtask_complete(swarm.swarm_id, "agent_b", st1, {"market": "bullish"})
    assert result is True
    print(f"[✓] Subtask {st1[:8]} reported complete by agent_b")

    # 6. Report subtask failed
    result = coord.report_subtask_failed(swarm.swarm_id, "agent_c", st2, "Insufficient data")
    assert result is True
    print(f"[✓] Subtask {st2[:8]} reported failed by agent_c")

    # 7. Get swarm members
    members = coord.get_swarm_members(swarm.swarm_id)
    assert members == ["agent_a", "agent_b", "agent_c"]
    print(f"[✓] Swarm members: {members}")

    # 8. Get swarm status
    status = coord.get_swarm_status(swarm.swarm_id)
    assert status is not None
    assert status["leader_id"] == "agent_a"
    assert status["subtasks"]["total"] == 3
    assert len(status["subtasks"]["complete"]) == 1
    assert len(status["subtasks"]["failed"]) == 1
    assert len(status["subtasks"]["in_progress"]) == 1
    print(f"[✓] Swarm status: {status['subtasks']['total']} total, "
          f"{len(status['subtasks']['complete'])} complete, "
          f"{len(status['subtasks']['failed'])} failed, "
          f"{len(status['subtasks']['in_progress'])} in_progress")

    # 9. Test M:T messaging
    msg_sent = coord.send_message(
        swarm.swarm_id, "agent_b", "*", "status_update", {"progress": 0.8}
    )
    assert msg_sent is True
    drained = coord.drain_messages(swarm.swarm_id, max_messages=10)
    assert len(drained) > 0
    print(f"[✓] M:T messaging: {len(drained)} messages drained")

    # 10. Dismiss swarm
    aggregated = coord.dismiss_swarm(swarm.swarm_id)
    assert aggregated["total_subtasks"] == 3
    print(f"[✓] Swarm dismissed: {aggregated['complete']} complete, "
          f"{aggregated['failed']} failed")

    # 11. Test edge cases
    # Re-dismiss raises ValueError
    try:
        coord.dismiss_swarm(swarm.swarm_id)
        print("[✗] Should have raised ValueError on re-dismiss")
    except ValueError:
        print("[✓] Re-dismiss raises ValueError (expected)")

    # Unknown swarm returns None
    assert coord.get_swarm_status("nonexistent") is None
    print("[✓] Unknown swarm returns None")

    # Cannot assign non-member as leader
    result = coord.assign_leader(swarm.swarm_id, "agent_z")
    assert result is False
    print("[✓] Non-member leader assignment rejected")

    # Delegate to non-member fails
    result = coord.delegate_subtask(swarm.swarm_id, "agent_z", "Bad task")
    assert result is None
    print("[✓] Non-member delegation rejected")

    # Cannot create swarm with zero agents
    try:
        coord.create_swarm("bad_intent", [])
        print("[✗] Should have raised ValueError for empty agent list")
    except ValueError:
        print("[✓] Empty agent list raises ValueError (expected)")

    print()
    print("All SwarmCoordinator tests PASSED ✓")
