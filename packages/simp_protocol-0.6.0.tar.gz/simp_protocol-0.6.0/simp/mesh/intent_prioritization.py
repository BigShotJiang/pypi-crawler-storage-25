"""
Intent Priority Queuing & Deadline Enforcement — L3-T12, L3-T13, L3-T15

Priority queue ensures critical intents are processed before normal/low ones.
Deadline enforcement cancels expired intents and notifies senders.
Retry across brokers: if Broker A delegates to B and B fails, A retries on C.

Design:
- Multi-level priority queue (critical > high > normal > low)
- Priority inheritance: if a high-prio intent depends on a normal-prio one,
  the dependency is temporarily boosted to high
- Deadline: each intent has a deadline. Expired intents → Cancelled.
- Retry: configurable retry count, exponential backoff, alternate broker
"""

import heapq
import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class Priority(Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


@dataclass(order=True)
class PriorityIntent:
    """An intent in the priority queue. Sortable by priority and age.
    
    NOTE: heapq is a min-heap, so we use NEGATED priority for storage.
    The `priority` field stores the actual value (higher=more important),
    but in the heap we store (-priority, created_at, intent) so that
    CRITICAL(3) becomes -3 and sorts before LOW(0).
    """
    _heap_priority: int = field(init=False, repr=False, compare=True)  # Negative priority for heap
    priority: int = field(compare=False)  # Actual priority (3=CRITICAL, 0=LOW)
    created_at: float = field(compare=True)  # Earlier = processed first at same priority
    intent_id: str = field(compare=False)
    intent_type: str = field(compare=False)
    intent_id: str = field(compare=False)
    intent_type: str = field(compare=False)
    payload: dict = field(default_factory=dict, compare=False)
    deadline: Optional[float] = field(default=None, compare=False)
    sender: str = field(default="unknown", compare=False)
    retry_count: int = field(default=0, compare=False)
    max_retries: int = field(default=3, compare=False)
    status: str = field(default="queued", compare=False)

    def to_dict(self) -> dict:
        return {
            "intent_id": self.intent_id,
            "intent_type": self.intent_type,
            "priority": Priority(self.priority).name if self.priority in [p.value for p in Priority] else str(self.priority),
            "created_at": self.created_at,
            "deadline": self.deadline,
            "sender": self.sender,
            "retry_count": self.retry_count,
            "max_retries": self.max_retries,
            "status": self.status,
            "expired": self.is_expired() if self.deadline else False,
        }

    def is_expired(self) -> bool:
        if self.deadline is None:
            return False
        return time.time() > self.deadline

    def should_retry(self) -> bool:
        return self.retry_count < self.max_retries and not self.is_expired()


@dataclass
class RetryPolicy:
    """Retry configuration for intents."""
    max_retries: int = 3
    base_delay: float = 1.0  # seconds
    max_delay: float = 60.0
    backoff_factor: float = 2.0
    jitter: bool = True
    alternate_broker: bool = True


class IntentPriorityQueue:
    """
    Multi-level priority queue for intents.

    - critical (3): processed before everything
    - high (2): processed before normal/low
    - normal (1): default priority
    - low (0): processed when nothing else is pending
    """

    def __init__(self):
        self._queue: List[PriorityIntent] = []
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)
        self._intent_map: Dict[str, PriorityIntent] = {}  # intent_id -> intent
        self._deadline_check_interval = 5.0  # seconds

        # Processing stats
        self._stats = {
            "enqueued": 0,
            "dequeued": 0,
            "expired": 0,
            "retried": 0,
            "priority_boosts": 0,
        }

        logger.info("IntentPriorityQueue initialized")

    def enqueue(self, intent: PriorityIntent) -> None:
        """Add an intent to the queue."""
        with self._condition:
            # Store negated priority so heapq pops highest first
            intent._heap_priority = -intent.priority
            heapq.heappush(self._queue, intent)
            self._intent_map[intent.intent_id] = intent
            self._stats["enqueued"] += 1
            self._condition.notify()
            logger.debug("Enqueued %s (priority=%s, deadline=%s)",
                         intent.intent_id, Priority(intent.priority).name,
                         intent.deadline)

    def dequeue(self, timeout: Optional[float] = None) -> Optional[PriorityIntent]:
        """
        Pop the highest-priority intent. Blocks until one is available or timeout.
        """
        with self._condition:
            deadline = time.time() + timeout if timeout else None

            while True:
                # Check timeout
                if deadline and time.time() >= deadline:
                    return None

                # Remove expired intents
                self._purge_expired()

                if self._queue:
                    # Peek at highest priority
                    intent = self._queue[0]
                    if intent.is_expired():
                        heapq.heappop(self._queue)
                        self._stats["expired"] += 1
                        del self._intent_map[intent.intent_id]
                        logger.info("Dequeued expired intent %s", intent.intent_id)
                        continue

                    heapq.heappop(self._queue)
                    intent.status = "processing"
                    self._stats["dequeued"] += 1
                    return intent

                # Wait for new intents
                remaining = deadline - time.time() if deadline else 1.0
                if remaining <= 0:
                    return None
                self._condition.wait(timeout=min(remaining, 1.0))

    def peek(self) -> Optional[PriorityIntent]:
        """Look at the highest-priority intent without removing it."""
        with self._condition:
            self._purge_expired()
            if self._queue:
                return self._queue[0]
            return None

    def boost_priority(self, intent_id: str, new_priority: int) -> bool:
        """
        Priority inheritance: temporarily boost an intent's priority.
        Used when a high-priority intent depends on a normal-priority one.
        """
        with self._condition:
            if intent_id not in self._intent_map:
                return False

            intent = self._intent_map[intent_id]
            if intent.priority < new_priority:
                intent.priority = new_priority
                heapq.heapify(self._queue)
                self._stats["priority_boosts"] += 1
                logger.info("Boosted priority of %s to %s",
                            intent_id, Priority(new_priority).name)
                return True
            return False

    def cancel(self, intent_id: str) -> bool:
        """Cancel a queued intent."""
        with self._condition:
            if intent_id not in self._intent_map:
                return False
            intent = self._intent_map[intent_id]
            intent.status = "cancelled"
            # Remove from heap (lazy removal — filtered on dequeue)
            del self._intent_map[intent_id]
            # Rebuild heap (expensive but correct)
            self._queue = [i for i in self._queue if i.intent_id != intent_id]
            heapq.heapify(self._queue)
            logger.info("Cancelled intent %s", intent_id)
            return True

    def _purge_expired(self) -> int:
        """Remove expired intents from the queue."""
        now = time.time()
        # Filter expired intents from heap
        before = len(self._queue)
        self._queue = [i for i in self._queue if not i.is_expired()]
        heapq.heapify(self._queue)
        purged = before - len(self._queue)
        if purged:
            # Also clean up intent map
            self._intent_map = {
                iid: intent for iid, intent in self._intent_map.items()
                if not intent.is_expired()
            }
            self._stats["expired"] += purged
        return purged

    def queue_size(self) -> int:
        with self._condition:
            return len(self._queue)

    def get_stats(self) -> dict:
        with self._condition:
            return dict(self._stats)


class DeadlineEnforcer:
    """
    Enforces intent deadlines. Runs in background thread, checks every 5s.
    Expired intents are cancelled and senders are notified.
    """

    def __init__(self, queue: IntentPriorityQueue):
        self._queue = queue
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._on_expired: Optional[Callable[[PriorityIntent], None]] = None
        self._check_count = 0
        self._expired_count = 0

    def set_expired_callback(self, cb: Callable[[PriorityIntent], None]) -> None:
        self._on_expired = cb

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name="DeadlineEnforcer")
        self._thread.start()
        logger.info("DeadlineEnforcer started")

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _run(self) -> None:
        while self._running:
            try:
                self._check_deadlines()
            except Exception as e:
                logger.error("Deadline check error: %s", e)
            time.sleep(5.0)

    def _check_deadlines(self) -> None:
        """Check all queued intents for expired deadlines."""
        self._check_count += 1
        # The queue handles expiry during dequeue, but we also check here
        # to proactively cancel expired intents
        purged = self._queue._purge_expired()
        if purged:
            self._expired_count += purged
            logger.info("Deadline enforcer cancelled %d expired intents", purged)

    def get_stats(self) -> dict:
        return {
            "check_count": self._check_count,
            "expired_count": self._expired_count,
            "running": self._running,
        }


class RetryManager:
    """
    Manages intent retry across brokers.
    Uses exponential backoff with jitter. Can retry on alternate brokers.
    """

    def __init__(self, policy: Optional[RetryPolicy] = None):
        self._policy = policy or RetryPolicy()
        self._lock = threading.RLock()
        self._retry_queue: Dict[str, Tuple[float, PriorityIntent]] = {}
        self._retry_count: Dict[str, int] = {}
        self._alternate_brokers: Dict[str, List[str]] = {}  # intent_type -> [brokers]

        # Callback for when an intent should be retried on an alternate broker
        self._on_retry: Optional[Callable[[PriorityIntent, Optional[str]], None]] = None

        self._running = False
        self._thread: Optional[threading.Thread] = None

        logger.info("RetryManager initialized (max_retries=%d, backoff=%.1fx)",
                     policy.max_retries if policy else 3,
                     policy.backoff_factor if policy else 2.0)

    def set_retry_callback(self, cb: Callable[[PriorityIntent, Optional[str]], None]) -> None:
        self._on_retry = cb

    def register_alternate_broker(self, intent_type: str, broker_id: str) -> None:
        """Register an alternate broker for retrying a specific intent type."""
        with self._lock:
            if intent_type not in self._alternate_brokers:
                self._alternate_brokers[intent_type] = []
            if broker_id not in self._alternate_brokers[intent_type]:
                self._alternate_brokers[intent_type].append(broker_id)

    def schedule_retry(self, intent: PriorityIntent,
                       failed_broker: Optional[str] = None) -> bool:
        """Schedule a retry with exponential backoff."""
        with self._lock:
            key = intent.intent_id
            self._retry_count[key] = self._retry_count.get(key, 0) + 1
            attempt = self._retry_count[key]

            if attempt > intent.max_retries:
                logger.warning("Max retries exceeded for %s (%d/%d)",
                               intent.intent_id, attempt, intent.max_retries)
                return False

            # Calculate delay with exponential backoff and jitter
            delay = min(
                self._policy.base_delay * (self._policy.backoff_factor ** (attempt - 1)),
                self._policy.max_delay
            )
            if self._policy.jitter:
                import random
                delay *= random.uniform(0.5, 1.5)

            retry_at = time.time() + delay
            self._retry_queue[key] = (retry_at, intent)
            logger.info("Scheduled retry %d/%d for %s in %.1fs%s",
                        attempt, intent.max_retries, intent.intent_id, delay,
                        f" (alt broker)" if self._policy.alternate_broker else "")
            return True

    def _get_alternate_broker(self, intent_type: str) -> Optional[str]:
        """Get an alternate broker for an intent type."""
        with self._lock:
            brokers = self._alternate_brokers.get(intent_type, [])
            if not brokers:
                return None
            # Round-robin: use the first one and rotate
            broker = brokers[0]
            brokers.append(brokers.pop(0))
            return broker

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._retry_loop, daemon=True,
                                        name="RetryManager")
        self._thread.start()
        logger.info("RetryManager started")

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _retry_loop(self) -> None:
        while self._running:
            try:
                self._process_retries()
            except Exception as e:
                logger.error("Retry loop error: %s", e)
            time.sleep(1.0)

    def _process_retries(self) -> None:
        """Process due retries."""
        now = time.time()
        due: List[PriorityIntent] = []

        with self._lock:
            due_keys = [
                key for key, (t, intent) in self._retry_queue.items()
                if t <= now
            ]
            for key in due_keys:
                _, intent = self._retry_queue.pop(key)
                due.append(intent)

        for intent in due:
            if intent.is_expired():
                logger.info("Skipping retry for expired intent %s", intent.intent_id)
                continue

            # Find alternate broker if configured
            alt_broker = None
            if self._policy.alternate_broker:
                alt_broker = self._get_alternate_broker(intent.intent_type)

            if self._on_retry:
                self._on_retry(intent, alt_broker)

    def get_stats(self) -> dict:
        with self._lock:
            return {
                "pending_retries": len(self._retry_queue),
                "total_retries": sum(self._retry_count.values()),
                "policy": {
                    "max_retries": self._policy.max_retries,
                    "base_delay": self._policy.base_delay,
                    "backoff_factor": self._policy.backoff_factor,
                    "alternate_broker": self._policy.alternate_broker,
                },
                "alternate_brokers": {
                    k: len(v) for k, v in self._alternate_brokers.items()
                },
            }
