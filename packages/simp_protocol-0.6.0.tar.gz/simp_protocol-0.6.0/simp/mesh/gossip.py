"""
SIMP Gossip Protocol — T30-1

SWIM-style gossip for agent health dissemination:
  - Every 10s each agent broadcasts {agent_id, status, uptime, intent_count_1m, error_rate}
  - Agents share with 3 random peers per cycle (SWIM ping/ack style)
  - O(log n) dissemination — entire mesh knows in ~30 seconds
  - Small messages (<256 bytes), over existing mesh WebSocket channel

Files: simp/mesh/gossip.py, simp/mesh/protocol.py
"""

from __future__ import annotations

import json
import logging
import random
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional, Set

logger = logging.getLogger("SIMP.Gossip")


# ---------------------------------------------------------------------------
# Gossip Message Types
# ---------------------------------------------------------------------------


class GossipMessageType(str, Enum):
    PING = "ping"
    PING_REQ = "ping_req"  # Agent asks another to ping on its behalf (SWIM)
    ACK = "ack"
    UPDATE = "update"  # Contains health state


@dataclass
class AgentHealthState:
    """Lightweight agent health snapshot — small, <256 bytes."""
    agent_id: str
    status: str  # "active", "degraded", "offline"
    uptime_seconds: float
    intent_count_1m: int
    error_rate: float  # 0.0–1.0
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    incarnation: int = 0  # Incremented on agent restart, detects reincarnation

    def to_dict(self) -> Dict:
        d = asdict(self)
        # Estimate serialized size
        return d

    def encoded_size(self) -> int:
        """Approximate JSON-encoded size in bytes."""
        return len(json.dumps(self.to_dict()))


class GossipMessage:
    """Gossip protocol message envelope."""

    def __init__(
        self,
        msg_type: GossipMessageType,
        src_agent_id: str,
        target_agent_id: Optional[str] = None,
        health_state: Optional[AgentHealthState] = None,
        ack_id: Optional[str] = None,
        via_agent_id: Optional[str] = None,
    ):
        self.message_id = str(uuid.uuid4())
        self.msg_type = msg_type
        self.src_agent_id = src_agent_id
        self.target_agent_id = target_agent_id  # For directed msgs
        self.health_state = health_state
        self.ack_id = ack_id  # For ACK correlation
        self.via_agent_id = via_agent_id  # For PING_REQ indirect pings
        self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict:
        return {
            "message_id": self.message_id,
            "msg_type": self.msg_type.value if isinstance(self.msg_type, GossipMessageType) else self.msg_type,
            "src_agent_id": self.src_agent_id,
            "target_agent_id": self.target_agent_id,
            "health_state": self.health_state.to_dict() if self.health_state else None,
            "ack_id": self.ack_id,
            "via_agent_id": self.via_agent_id,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "GossipMessage":
        msg = cls(
            msg_type=GossipMessageType(data["msg_type"]),
            src_agent_id=data["src_agent_id"],
            target_agent_id=data.get("target_agent_id"),
            via_agent_id=data.get("via_agent_id"),
            ack_id=data.get("ack_id"),
        )
        msg.message_id = data.get("message_id", str(uuid.uuid4()))
        if data.get("health_state"):
            msg.health_state = AgentHealthState(**data["health_state"])
        return msg

    def encoded_size(self) -> int:
        return len(json.dumps(self.to_dict()))


# ---------------------------------------------------------------------------
# SWIM Gossip Protocol
# ---------------------------------------------------------------------------


class GossipProtocol:
    """
    SWIM-style gossip protocol for agent health dissemination.

    Each cycle (10s):
      1. Agent selects 3 random alive peers
      2. Sends PING to each
      3. If no ACK within timeout, sends PING_REQ to a random peer asking it to ping
      4. Disseminates updates via ACK piggyback (SWIM-style anti-entropy)

    Properties:
      - O(log n) dissemination time (~30s for typical mesh sizes)
      - Small messages (<256 bytes)
      - Detects agent failures within ~30s
      - Handles network partitions via PING_REQ
    """

    # Protocol constants
    GOSSIP_INTERVAL_SEC = 10.0
    PING_TIMEOUT_SEC = 3.0
    FANOUT = 3  # Number of peers to ping per cycle
    ACK_TIMEOUT_SEC = 5.0

    def __init__(
        self,
        agent_id: str,
        mesh_bus=None,
        transport=None,
        on_health_update: Optional[callable] = None,
    ):
        """
        Initialize GossipProtocol.

        Args:
            agent_id: This agent's ID
            mesh_bus: MeshBus instance for message transport
            transport: WebSocket or HTTP transport for sending gossip
            on_health_update: Callback(state: AgentHealthState) when remote state changes
        """
        self.agent_id = agent_id
        self.mesh_bus = mesh_bus
        self.transport = transport
        self.on_health_update = on_health_update

        self._lock = threading.RLock()
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._shutdown_event = threading.Event()

        # Agent health state table: agent_id -> AgentHealthState
        self._health_table: Dict[str, AgentHealthState] = {}
        self._incarnation: int = 0  # Incremented on restart

        # Pending ACKs: ack_id -> timestamp
        self._pending_acks: Dict[str, float] = {}

        # Peers known to this agent
        self._peers: Set[str] = set()

        # Local agent's own health state (updated by agent manager)
        self._local_state = AgentHealthState(
            agent_id=agent_id,
            status="active",
            uptime_seconds=0.0,
            intent_count_1m=0,
            error_rate=0.0,
            incarnation=self._incarnation,
        )

        # Statistics
        self._stats = {
            "gossip_cycles": 0,
            "pings_sent": 0,
            "pings_ack": 0,
            "ping_req_sent": 0,
            "updates_received": 0,
            "updates_propagated": 0,
        }

        logger.info(f"GossipProtocol[{agent_id}] initialized (fanout={self.FANOUT}, interval={self.GOSSIP_INTERVAL_S}s)")

    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------

    def start(self) -> None:
        """Start the gossip background thread."""
        with self._lock:
            if self._running:
                return
            self._running = True
            self._shutdown_event.clear()
            self._thread = threading.Thread(target=self._gossip_loop, name=f"Gossip-{self.agent_id}", daemon=True)
            self._thread.start()
            logger.info(f"GossipProtocol[{self.agent_id}] started")

    def stop(self) -> None:
        """Stop the gossip background thread."""
        with self._lock:
            if not self._running:
                return
            self._running = False
            self._shutdown_event.set()
        if self._thread:
            self._thread.join(timeout=5.0)
        logger.info(f"GossipProtocol[{self.agent_id}] stopped")

    # -------------------------------------------------------------------------
    # Public API — called by agent manager to update local state
    # -------------------------------------------------------------------------

    def update_local_state(
        self,
        status: str,
        intent_count_1m: int,
        error_rate: float,
        uptime_seconds: float,
    ) -> None:
        """Update this agent's health state for gossip dissemination."""
        with self._lock:
            self._local_state = AgentHealthState(
                agent_id=self.agent_id,
                status=status,
                uptime_seconds=uptime_seconds,
                intent_count_1m=intent_count_1m,
                error_rate=error_rate,
                incarnation=self._incarnation,
                timestamp=datetime.now(timezone.utc).isoformat(),
            )

    def update_local_incarnation(self) -> None:
        """Increment incarnation counter (call on agent restart)."""
        with self._lock:
            self._incarnation += 1
            self._local_state.incarnation = self._incarnation

    def set_peers(self, peer_ids: List[str]) -> None:
        """Update the list of known peer agent IDs."""
        with self._lock:
            self._peers = set(peer_ids) - {self.agent_id}
            logger.debug(f"GossipProtocol[{self.agent_id}] peers updated: {len(self._peers)} peers")

    def get_health_state(self, agent_id: str) -> Optional[AgentHealthState]:
        """Get the last known health state for an agent."""
        with self._lock:
            return self._health_table.get(agent_id)

    def get_all_health_states(self) -> Dict[str, AgentHealthState]:
        """Get a copy of the full health table."""
        with self._lock:
            return dict(self._health_table)

    def get_statistics(self) -> Dict:
        """Get gossip protocol statistics."""
        with self._lock:
            return dict(self._stats)

    # -------------------------------------------------------------------------
    # Incoming gossip message handler (called by transport layer)
    # -------------------------------------------------------------------------

    def handle_gossip_message(self, raw_data: bytes) -> None:
        """
        Process an incoming gossip message.

        Called by the transport layer when a gossip message is received.
        Args:
            raw_data: JSON-encoded GossipMessage bytes
        """
        try:
            data = json.loads(raw_data)
            msg = GossipMessage.from_dict(data)
            self._process_message(msg)
        except Exception:
            logger.exception(f"GossipProtocol[{self.agent_id}] failed to handle gossip message")

    def handle_gossip_message_dict(self, data: Dict) -> None:
        """Process an incoming gossip message from a dict."""
        try:
            msg = GossipMessage.from_dict(data)
            self._process_message(msg)
        except Exception:
            logger.exception(f"GossipProtocol[{self.agent_id}] failed to handle gossip dict")

    # -------------------------------------------------------------------------
    # Internal: Gossip Loop
    # -------------------------------------------------------------------------

    def _gossip_loop(self) -> None:
        """Background thread: periodically gossip with peers."""
        while not self._shutdown_event.is_set():
            try:
                self._gossip_cycle()
            except Exception:
                logger.exception(f"GossipProtocol[{self.agent_id}] cycle error")

            # Wait for next cycle or shutdown
            self._shutdown_event.wait(timeout=self.GOSSIP_INTERVAL_SEC)

    def _gossip_cycle(self) -> None:
        """One gossip cycle: ping random peers, disseminate updates."""
        with self._lock:
            if not self._peers:
                return
            peers = list(self._peers)
            selected = random.sample(peers, min(self.FANOUT, len(peers)))

        self._stats["gossip_cycles"] += 1

        for peer_id in selected:
            self._ping_peer(peer_id)

        # Piggyback local state on the next outgoing message (no separate broadcast needed)
        # SWIM anti-entropy: occasionally full state sync with a random peer
        if random.random() < 0.2 and peers:
            random_peer = random.choice(peers)
            self._send_full_state(random_peer)

    def _ping_peer(self, peer_id: str) -> None:
        """Send a PING to a peer, expecting an ACK with piggybacked state."""
        with self._lock:
            ack_id = str(uuid.uuid4())
            self._pending_acks[ack_id] = time.monotonic()
            local_state = self._local_state

        msg = GossipMessage(
            msg_type=GossipMessageType.PING,
            src_agent_id=self.agent_id,
            target_agent_id=peer_id,
            health_state=local_state,
            ack_id=ack_id,
        )

        self._send_to_peer(peer_id, msg)
        self._stats["pings_sent"] += 1

        logger.debug(f"GossipProtocol[{self.agent_id}] ping -> {peer_id} (ack_id={ack_id})")

    def _send_ping_req(self, target_peer: str, via_peer: str) -> None:
        """
        Send PING_REQ: ask via_peer to ping target_peer on our behalf.

        Used when PING times out (SWIM indirect ping).
        """
        msg = GossipMessage(
            msg_type=GossipMessageType.PING_REQ,
            src_agent_id=self.agent_id,
            target_agent_id=target_peer,
            via_agent_id=via_peer,
        )
        self._send_to_peer(via_peer, msg)
        self._stats["ping_req_sent"] += 1
        logger.debug(f"GossipProtocol[{self.agent_id}] ping_req: {via_peer} -> {target_peer}")

    def _send_full_state(self, peer_id: str) -> None:
        """Send full health state table to a random peer (anti-entropy)."""
        with self._lock:
            states = list(self._health_table.values()) + [self._local_state]

        for state in states:
            msg = GossipMessage(
                msg_type=GossipMessageType.UPDATE,
                src_agent_id=self.agent_id,
                target_agent_id=peer_id,
                health_state=state,
            )
            self._send_to_peer(peer_id, msg)

    # -------------------------------------------------------------------------
    # Internal: Message Processing
    # -------------------------------------------------------------------------

    def _process_message(self, msg: GossipMessage) -> None:
        """Route incoming gossip message to appropriate handler."""
        if msg.msg_type == GossipMessageType.PING:
            self._handle_ping(msg)
        elif msg.msg_type == GossipMessageType.PING_REQ:
            self._handle_ping_req(msg)
        elif msg.msg_type == GossipMessageType.ACK:
            self._handle_ack(msg)
        elif msg.msg_type == GossipMessageType.UPDATE:
            self._handle_update(msg)

    def _handle_ping(self, msg: GossipMessage) -> None:
        """Received a PING: respond with ACK + our state."""
        peer_id = msg.src_agent_id
        logger.debug(f"GossipProtocol[{self.agent_id}] ping from {peer_id}")

        # Extract and update state from piggyback
        if msg.health_state:
            self._update_health_state(msg.health_state)

        # Send ACK with our state piggybacked
        with self._lock:
            local_state = self._local_state

        ack_msg = GossipMessage(
            msg_type=GossipMessageType.ACK,
            src_agent_id=self.agent_id,
            target_agent_id=peer_id,
            health_state=local_state,
            ack_id=msg.ack_id,
        )
        self._send_to_peer(peer_id, ack_msg)

    def _handle_ping_req(self, msg: GossipMessage) -> None:
        """Received PING_REQ: forward ping to target on behalf of src."""
        target = msg.target_agent_id
        original_sender = msg.src_agent_id
        logger.debug(f"GossipProtocol[{self.agent_id}] ping_req: {self.agent_id} -> {target} (via {original_sender})")

        # Forward the ping to the target
        with self._lock:
            local_state = self._local_state

        forwarded_msg = GossipMessage(
            msg_type=GossipMessageType.PING,
            src_agent_id=original_sender,
            target_agent_id=target,
            health_state=local_state,
            ack_id=msg.ack_id,
        )
        self._send_to_peer(target, forwarded_msg)

    def _handle_ack(self, msg: GossipMessage) -> None:
        """Received an ACK: cancel pending ping, extract piggybacked state."""
        ack_id = msg.ack_id

        with self._lock:
            if ack_id in self._pending_acks:
                del self._pending_acks[ack_id]
                self._stats["pings_ack"] += 1

        if msg.health_state:
            self._update_health_state(msg.health_state)

        logger.debug(f"GossipProtocol[{self.agent_id}] ack from {msg.src_agent_id} (ack_id={ack_id})")

    def _handle_update(self, msg: GossipMessage) -> None:
        """Received a state update via anti-entropy."""
        if msg.health_state:
            updated = self._update_health_state(msg.health_state)
            if updated:
                self._stats["updates_received"] += 1

                # Propagate to some random peers (gossip dissemination)
                self._propagate_update(msg.health_state, exclude=msg.src_agent_id)

                if self.on_health_update:
                    try:
                        self.on_health_update(msg.health_state)
                    except Exception:
                        logger.exception("on_health_update callback failed")

    def _update_health_state(self, state: AgentHealthState) -> bool:
        """
        Update health state in table if newer.
        Returns True if state was updated.
        """
        with self._lock:
            existing = self._health_table.get(state.agent_id)
            if existing:
                # Replace if newer incarnation or newer timestamp
                if state.incarnation > existing.incarnation:
                    self._health_table[state.agent_id] = state
                    return True
                try:
                    new_ts = datetime.fromisoformat(state.timestamp.replace("Z", "+00:00"))
                    old_ts = datetime.fromisoformat(existing.timestamp.replace("Z", "+00:00"))
                    if new_ts > old_ts and state.incarnation == existing.incarnation:
                        self._health_table[state.agent_id] = state
                        return True
                except (ValueError, TypeError):
                    pass
                return False
            else:
                self._health_table[state.agent_id] = state
                return True

    def _propagate_update(self, state: AgentHealthState, exclude: str) -> None:
        """Propagate a state update to a few random peers."""
        with self._lock:
            peers = [p for p in self._peers if p != exclude]
            if not peers:
                return
            targets = random.sample(peers, min(self.FANOUT, len(peers)))

        for peer_id in targets:
            msg = GossipMessage(
                msg_type=GossipMessageType.UPDATE,
                src_agent_id=self.agent_id,
                target_agent_id=peer_id,
                health_state=state,
            )
            self._send_to_peer(peer_id, msg)
            self._stats["updates_propagated"] += 1

    # -------------------------------------------------------------------------
    # Internal: Transport
    # -------------------------------------------------------------------------

    def _send_to_peer(self, peer_id: str, msg: GossipMessage) -> None:
        """Send a gossip message to a peer via mesh bus or direct transport."""
        if self.mesh_bus:
            try:
                from simp.mesh.packet import MeshPacket, MessageType, Priority

                packet = MeshPacket(
                    msg_type=MessageType.SYSTEM,
                    sender_id=self.agent_id,
                    recipient_id=peer_id,
                    channel="gossip",
                    priority=Priority.LOW,
                    payload={"gossip": msg.to_dict()},
                    ttl_seconds=30,
                )
                self.mesh_bus.send(packet)
                return
            except Exception:
                logger.exception(f"GossipProtocol[{self.agent_id}] mesh_bus send failed")

        if self.transport:
            try:
                data = json.dumps(msg.to_dict()).encode("utf-8")
                self.transport.send_gossip(peer_id, data)
            except Exception:
                logger.exception(f"GossipProtocol[{self.agent_id}] transport send failed")

    # -------------------------------------------------------------------------
    # Timeout checker (run in background)
    # -------------------------------------------------------------------------

    def _check_timeouts(self) -> None:
        """Check for timed-out ACKs, trigger PING_REQ if needed."""
        now = time.monotonic()
        timed_out = []

        with self._lock:
            for ack_id, ts in list(self._pending_acks.items()):
                if now - ts > self.ACK_TIMEOUT_SEC:
                    timed_out.append(ack_id)

        for ack_id in timed_out:
            with self._lock:
                if ack_id in self._pending_acks:
                    del self._pending_acks[ack_id]

            # Need to find which peer this was for — track it
            logger.warning(f"GossipProtocol[{self.agent_id}] ACK timeout: {ack_id}")
            # SWIM indirect ping: pick random peer to forward
            with self._lock:
                if not self._peers:
                    continue
                via_peer = random.choice(list(self._peers))
                # We can't determine target_peer from ack_id without more state
                # In production: track (ack_id, target_peer) tuple

    def start_timeout_checker(self) -> None:
        """Start background thread to check ACK timeouts."""
        def run():
            while not self._shutdown_event.is_set():
                self._check_timeouts()
                self._shutdown_event.wait(timeout=1.0)

        t = threading.Thread(target=run, name=f"GossipTimeout-{self.agent_id}", daemon=True)
        t.start()


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------


def create_gossip_message(
    msg_type: GossipMessageType,
    src_agent_id: str,
    target_agent_id: Optional[str] = None,
    health_state: Optional[AgentHealthState] = None,
) -> GossipMessage:
    """Create a gossip message."""
    return GossipMessage(
        msg_type=msg_type,
        src_agent_id=src_agent_id,
        target_agent_id=target_agent_id,
        health_state=health_state,
    )
