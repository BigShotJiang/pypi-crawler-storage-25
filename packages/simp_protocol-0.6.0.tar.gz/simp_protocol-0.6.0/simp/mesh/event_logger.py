"""
MeshEventLogger — Daily-rotating JSONL writer for mesh bus events.

Writes to ``~/.simp/logs/mesh/mesh_events_YYYY-MM-DD.jsonl`` with fields:
    timestamp, event_type, agent_id, channel, message

Designed to be called by EnhancedMeshBus._log_event or used standalone.
"""

from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger("SIMP.Mesh.EventLogger")


class MeshEventLogger:
    """
    Thread-safe daily-rotating JSONL writer for mesh events.

    Usage::

        logger = MeshEventLogger()
        logger.log("message_sent", agent_id="alpha-goose", channel="quantum", message="ping")
    """

    def __init__(self, log_dir: Optional[str] = None) -> None:
        """
        Args:
            log_dir: Directory for mesh event logs.
                     Defaults to ``~/.simp/logs/mesh``.
        """
        if log_dir is None:
            log_dir = Path.home() / ".simp" / "logs" / "mesh"
        self._log_dir = Path(log_dir)
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _log_file_for(self, dt: datetime) -> Path:
        """Return the daily log file path for the given date."""
        return self._log_dir / f"mesh_events_{dt.date().isoformat()}.jsonl"

    def log(
        self,
        event_type: str,
        agent_id: str = "unknown",
        channel: str = "",
        message: str = "",
        data: Optional[Dict[str, Any]] = None,
        timestamp: Optional[str] = None,
    ) -> None:
        """
        Append a mesh event to today's daily log file.

        Args:
            event_type:  Event type string (e.g. "message_sent", "agent_registered").
            agent_id:    Agent that originated or received the event.
            channel:     Mesh channel the event pertains to.
            message:     Human-readable message content.
            data:        Additional structured data to attach.
            timestamp:   ISO-8600 timestamp string. Defaults to now (UTC).
        """
        if timestamp is None:
            timestamp = datetime.now(timezone.utc).isoformat()

        record: Dict[str, Any] = {
            "timestamp": timestamp,
            "event_type": event_type,
            "agent_id": agent_id,
            "channel": channel,
            "message": message,
        }
        if data:
            record["data"] = data

        log_file = self._log_file_for(datetime.now(timezone.utc))

        with self._lock:
            try:
                with open(log_file, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(record, default=str) + "\n")
            except OSError as exc:
                logger.warning("MeshEventLogger: failed to write to %s — %s", log_file, exc)

    # Convenience helpers for common event types

    def log_agent_registered(self, agent_id: str, channel: str = "system") -> None:
        self.log("agent_registered", agent_id=agent_id, channel=channel)

    def log_agent_deregistered(self, agent_id: str, channel: str = "system") -> None:
        self.log("agent_deregistered", agent_id=agent_id, channel=channel)

    def log_message_sent(self, agent_id: str, channel: str, message: str = "") -> None:
        self.log("message_sent", agent_id=agent_id, channel=channel, message=message)

    def log_message_expired(self, agent_id: str, channel: str, message: str = "") -> None:
        self.log("message_expired", agent_id=agent_id, channel=channel, message=message)

    def log_payment_channel_opened(self, agent_id: str, channel: str = "") -> None:
        self.log("payment_channel_opened", agent_id=agent_id, channel=channel)