"""
Evolution Pipeline — T67: Propose → Design → Vote → Deploy → Evolve

Full autonomous loop:
1. Discover: QuantumArb identifies new arb pattern
2. Design: QuantumAlgorithmDesigner produces QuantumCircuitDesign
3. Propose: EvolutionPipeline.propose_upgrade() → MeshConsensusNode for L5 vote
4. Vote: Agents vote APPROVE/ABSTAIN/DENY weighted by trust score
5. Deploy: Approved circuit → CodePayload → mesh broadcast
6. Evolve: Successful execution → IMITATION learning → skill promotion
"""
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from simp.mesh.enhanced_bus import EnhancedMeshBus
    from simp.mesh.consensus import MeshConsensusNode


class ProposalState(Enum):
    PENDING = "pending"
    VOTING = "voting"
    APPROVED = "approved"
    REJECTED = "rejected"
    DEPLOYED = "deployed"
    EXPIRED = "expired"


class VoteChoice(Enum):
    APPROVE = "approve"
    ABSTAIN = "abstain"
    DENY = "deny"


@dataclass
class CircuitProposal:
    """A proposal for a new quantum circuit to be deployed."""
    proposal_id: str
    circuit_id: str
    circuit_design: Dict[str, Any]  # Gate sequence, parameters, qubit map
    proposer_agent_id: str
    proposer_trust_score: float
    description: str
    expected_benchmark_delta: float  # Expected improvement
    state: ProposalState = ProposalState.PENDING
    created_at: float = field(default_factory=time.time)
    voting_deadline: Optional[float] = None
    votes_for: float = 0.0
    votes_against: float = 0.0
    voters: Dict[str, VoteChoice] = field(default_factory=dict)

    def voting_power(self, agent_id: str, trust_score: float,
                      choice: VoteChoice) -> float:
        """Return the voting power for a given vote."""
        if choice == VoteChoice.ABSTAIN:
            return 0.0
        return trust_score

    def cast_vote(self, agent_id: str, choice: VoteChoice,
                  trust_score: float) -> None:
        old_choice = self.voters.get(agent_id)
        if old_choice == choice:
            return  # No change

        power = self.voting_power(agent_id, trust_score, choice)

        # Remove old vote
        if old_choice == VoteChoice.APPROVE:
            self.votes_for -= power
        elif old_choice == VoteChoice.DENY:
            self.votes_against -= power

        # Add new vote
        if choice == VoteChoice.APPROVE:
            self.votes_for += power
        elif choice == VoteChoice.DENY:
            self.votes_against += power

        self.voters[agent_id] = choice

    def tally(self, quorum_threshold: float = 0.75) -> Optional[bool]:
        """Tally votes and return the outcome. None if no quorum."""
        total = self.votes_for + self.votes_against
        quorum_denominator = self.votes_for + self.votes_against
        if total == 0:
            return None

        # Abstentions don't count toward quorum
        if self.votes_for / total >= quorum_threshold:
            return True
        if self.votes_against / total >= quorum_threshold:
            return False
        return None  # No quorum reached yet


@dataclass
class EvolutionPipeline:
    """
    Orchestrates the full autonomous evolution loop.

    Flow:
    1. propose_circuit(circuit_design, proposer) → CircuitProposal
    2. open_voting(proposal_id) → starts L5 consensus vote
    3. cast_vote(proposal_id, agent, choice, trust_score)
    4. tally_and_deploy(proposal_id) → if approved, broadcast as CodePayload
    5. Execution + IMITATION learning → skill promotion
    """
    proposals: Dict[str, CircuitProposal] = field(default_factory=dict)
    deployed_circuits: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    _stats: Dict[str, int] = field(default_factory=lambda: {
        "proposals_created": 0,
        "proposals_approved": 0,
        "proposals_rejected": 0,
        "circuits_deployed": 0,
        "imitations_triggered": 0,
    })
    _lock: Any = field(default_factory=lambda: threading.RLock())

    def __post_init__(self):
        object.__setattr__(self, '_lock', threading.RLock())

    def propose_circuit(self, circuit_id: str, circuit_design: Dict[str, Any],
                        proposer_agent_id: str, proposer_trust_score: float,
                        description: str,
                        expected_benchmark_delta: float) -> CircuitProposal:
        """Create a new circuit proposal."""
        proposal = CircuitProposal(
            proposal_id=uuid.uuid4().hex,
            circuit_id=circuit_id,
            circuit_design=circuit_design,
            proposer_agent_id=proposer_agent_id,
            proposer_trust_score=proposer_trust_score,
            description=description,
            expected_benchmark_delta=expected_benchmark_delta,
        )
        with self._lock:
            self.proposals[proposal.proposal_id] = proposal
            self._stats["proposals_created"] += 1
        return proposal

    def open_voting(self, proposal_id: str, ttl_seconds: float = 300.0) -> bool:
        """Open voting on a proposal."""
        with self._lock:
            if proposal_id not in self.proposals:
                return False
            proposal = self.proposals[proposal_id]
            if proposal.state != ProposalState.PENDING:
                return False
            proposal.state = ProposalState.VOTING
            proposal.voting_deadline = time.time() + ttl_seconds
        return True

    def cast_vote(self, proposal_id: str, agent_id: str,
                   choice: VoteChoice, trust_score: float) -> bool:
        """Cast a vote on a proposal."""
        with self._lock:
            if proposal_id not in self.proposals:
                return False
            proposal = self.proposals[proposal_id]
            if proposal.state != ProposalState.VOTING:
                return False
            if proposal.voting_deadline and time.time() > proposal.voting_deadline:
                proposal.state = ProposalState.EXPIRED
                return False
            proposal.cast_vote(agent_id, choice, trust_score)
        return True

    def tally_and_deploy(self, proposal_id: str,
                          quorum_threshold: float = 0.75) -> Optional[bool]:
        """Tally votes and deploy if approved."""
        with self._lock:
            if proposal_id not in self.proposals:
                return None
            proposal = self.proposals[proposal_id]

        result = proposal.tally(quorum_threshold)

        with self._lock:
            if result is True:
                proposal.state = ProposalState.APPROVED
                self._stats["proposals_approved"] += 1
            elif result is False:
                proposal.state = ProposalState.REJECTED
                self._stats["proposals_rejected"] += 1
            else:
                return None  # No quorum

        return result

    def mark_deployed(self, proposal_id: str) -> bool:
        """Mark a proposal as deployed."""
        with self._lock:
            if proposal_id not in self.proposals:
                return False
            proposal = self.proposals[proposal_id]
            if proposal.state != ProposalState.APPROVED:
                return False
            proposal.state = ProposalState.DEPLOYED
            self.deployed_circuits[proposal.circuit_id] = {
                "proposal_id": proposal_id,
                "circuit_design": proposal.circuit_design,
                "deployed_at": time.time(),
                "proposer": proposal.proposer_agent_id,
            }
            self._stats["circuits_deployed"] += 1
        return True

    def get_proposal(self, proposal_id: str) -> Optional[CircuitProposal]:
        return self.proposals.get(proposal_id)

    def get_pending_proposals(self) -> List[CircuitProposal]:
        return [p for p in self.proposals.values()
                if p.state in (ProposalState.PENDING, ProposalState.VOTING)]

    def get_stats(self) -> Dict[str, int]:
        return dict(self._stats)


_pipeline: Optional[EvolutionPipeline] = None


def get_evolution_pipeline() -> EvolutionPipeline:
    global _pipeline
    if _pipeline is None:
        _pipeline = EvolutionPipeline()
    return _pipeline
