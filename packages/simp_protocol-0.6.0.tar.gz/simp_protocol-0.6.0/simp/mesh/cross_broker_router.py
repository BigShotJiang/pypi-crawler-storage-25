"""
Cross-Broker Intent Routing — L3 mesh module

Routes intents between broker nodes in the SIMP mesh network.
Each route has a receipt tracking the full lifecycle (UUID, source, target,
timestamp, status). Thread-safe for concurrent broker operations.

Design:
- Brokers register with their capabilities for capability-based routing
- Each cross-broker route gets a unique receipt, tracked through completion
- Routing decisions use broker capability matching
- Thread-safe via RLock for concurrent access from multiple broker threads
"""

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class RouteStatus(Enum):
    """Status of a cross-broker route."""
    PENDING = "pending"
    IN_TRANSIT = "in_transit"
    DELIVERED = "delivered"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class RouteReceipt:
    """Receipt tracking a cross-broker intent route.

    Each hop of an intent across brokers generates a receipt so the
    origin broker can trace exactly where the intent went and what happened.
    """
    receipt_id: str
    intent_id: str
    source_broker: str
    target_broker: str
    timestamp: float
    status: RouteStatus
    intent: Dict[str, Any] = field(default_factory=dict)
    result: Optional[Dict[str, Any]] = field(default=None)
    completed_at: Optional[float] = field(default=None)
    error: Optional[str] = field(default=None)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "receipt_id": self.receipt_id,
            "intent_id": self.intent_id,
            "source_broker": self.source_broker,
            "target_broker": self.target_broker,
            "timestamp": self.timestamp,
            "status": self.status.value,
            "completed_at": self.completed_at,
            "error": self.error,
            "result_available": self.result is not None,
        }

    def complete(self, result: Dict[str, Any]) -> None:
        """Mark this route receipt as completed with a result."""
        self.status = RouteStatus.COMPLETED
        self.result = result
        self.completed_at = time.time()

    def fail(self, error: str) -> None:
        """Mark this route receipt as failed."""
        self.status = RouteStatus.FAILED
        self.error = error
        self.completed_at = time.time()


@dataclass
class BrokerRegistration:
    """Registration info for a peer broker in the mesh."""
    broker_id: str
    address: str
    capabilities: List[str]
    registered_at: float
    last_seen: float
    active: bool = True


class CrossBrokerRouter:
    """Routes intents between peer brokers in the SIMP mesh.

    Brokers register themselves with their network address and capabilities.
    When an intent needs routing to a specific capability or broker, this
    router selects the best target and tracks the route lifecycle.
    """

    def __init__(self, local_broker_id: str = "local"):
        self._local_broker_id = local_broker_id
        self._lock = threading.RLock()

        # Registered peer brokers: broker_id -> BrokerRegistration
        self._brokers: Dict[str, BrokerRegistration] = {}

        # In-flight routes: receipt_id -> RouteReceipt
        self._routes: Dict[str, RouteReceipt] = {}

        # Intent index: intent_id -> receipt_id (fast lookup)
        self._intent_to_receipt: Dict[str, str] = {}

        # Callbacks
        self._on_route_started: Optional[Callable[[RouteReceipt], None]] = None
        self._on_route_completed: Optional[Callable[[RouteReceipt], None]] = None

        # Stats
        self._stats = {
            "routes_initiated": 0,
            "routes_completed": 0,
            "routes_failed": 0,
            "brokers_registered": 0,
            "brokers_removed": 0,
        }

        logger.info("CrossBrokerRouter initialized (local_broker_id=%s)", local_broker_id)

    # ------------------------------------------------------------------ #
    # Broker Registration
    # ------------------------------------------------------------------ #

    def register_broker(self, broker_id: str, address: str,
                        capabilities: Optional[List[str]] = None) -> None:
        """Register a peer broker for intent routing.

        Args:
            broker_id: Unique identifier for this broker.
            address: Network address (e.g., 'tcp://10.0.0.1:9000').
            capabilities: List of capability strings this broker supports.
        """
        if capabilities is None:
            capabilities = []

        with self._lock:
            now = time.time()
            if broker_id in self._brokers:
                # Update existing registration
                existing = self._brokers[broker_id]
                existing.address = address
                existing.capabilities = capabilities
                existing.last_seen = now
                existing.active = True
                logger.info("Updated broker %s at %s (capabilities: %s)",
                            broker_id, address, capabilities)
            else:
                self._brokers[broker_id] = BrokerRegistration(
                    broker_id=broker_id,
                    address=address,
                    capabilities=capabilities,
                    registered_at=now,
                    last_seen=now,
                    active=True,
                )
                self._stats["brokers_registered"] += 1
                logger.info("Registered broker %s at %s (capabilities: %s)",
                            broker_id, address, capabilities)

    def remove_broker(self, broker_id: str) -> bool:
        """Remove a peer broker from the routing table.

        Args:
            broker_id: Broker identifier to remove.

        Returns:
            True if broker was found and removed, False otherwise.
        """
        with self._lock:
            if broker_id not in self._brokers:
                logger.warning("Attempted to remove unknown broker %s", broker_id)
                return False
            del self._brokers[broker_id]
            self._stats["brokers_removed"] += 1
            logger.info("Removed broker %s", broker_id)
            return True

    def get_broker_for_capability(self, capability: str) -> Optional[BrokerRegistration]:
        """Find the best broker that supports a given capability.

    Args:
            capability: Capability string to match.

        Returns:
            BrokerRegistration of the best matching broker, or None.
            Uses a simple strategy: first active broker with the capability.
        """
        with self._lock:
            for broker in self._brokers.values():
                if broker.active and capability in broker.capabilities:
                    return broker
            return None

    def list_brokers(self) -> List[Dict[str, Any]]:
        """Return all registered brokers as a list of dicts."""
        with self._lock:
            return [
                {
                    "broker_id": b.broker_id,
                    "address": b.address,
                    "capabilities": b.capabilities,
                    "registered_at": b.registered_at,
                    "last_seen": b.last_seen,
                    "active": b.active,
                }
                for b in self._brokers.values()
            ]

    # ------------------------------------------------------------------ #
    # Intent Routing
    # ------------------------------------------------------------------ #

    def route_intent(self, intent: Dict[str, Any],
                     source_broker: Optional[str] = None,
                     target_broker: Optional[str] = None) -> Optional[str]:
        """Route an intent to a target broker.

        Creates a receipt and tracks the route lifecycle. If target_broker
        is not specified, the source_broker's request will be broadcast to
        all eligible brokers.

        Args:
            intent: The intent payload dict. Must contain 'intent_id'.
            source_broker: Broker sending this intent (default: local).
            target_broker: Target broker to route to. If None, uses
                capability-based routing from intent.get('capability').

        Returns:
            receipt_id (str) if routed successfully, None if no target found.
        """
        intent_id = intent.get("intent_id", str(uuid.uuid4()))
        src = source_broker or self._local_broker_id

        # Determine target if not specified
        tgt = target_broker
        if tgt is None:
            capability = intent.get("capability")
            if capability:
                broker = self.get_broker_for_capability(capability)
                if broker:
                    tgt = broker.broker_id
                else:
                    logger.warning("No broker found for capability '%s'", capability)
                    return None
            else:
                logger.warning("No target_broker or capability in intent")
                return None

        with self._lock:
            receipt = RouteReceipt(
                receipt_id=str(uuid.uuid4()),
                intent_id=intent_id,
                source_broker=src,
                target_broker=tgt,
                timestamp=time.time(),
                status=RouteStatus.PENDING,
                intent=intent,
            )
            self._routes[receipt.receipt_id] = receipt
            self._intent_to_receipt[intent_id] = receipt.receipt_id
            self._stats["routes_initiated"] += 1

        # Fire callback outside lock
        if self._on_route_started:
            try:
                self._on_route_started(receipt)
            except Exception as e:
                logger.error("on_route_started callback error: %s", e)

        # If we have a registered delivery function, use it
        # Otherwise, the route stays PENDING until receive_result is called
        receipt.status = RouteStatus.IN_TRANSIT

        logger.info("Routed intent %s from %s to %s (receipt=%s)",
                    intent_id, src, tgt, receipt.receipt_id)
        return receipt.receipt_id

    def receive_result(self, intent_id: str,
                       result: Dict[str, Any]) -> bool:
        """Receive a result back from a target broker for a routed intent.

        Args:
            intent_id: The intent_id from the original route.
            result: Result payload from the target broker.

        Returns:
            True if the result was matched to a pending route.
        """
        with self._lock:
            receipt_id = self._intent_to_receipt.get(intent_id)
            if receipt_id is None:
                logger.warning("Received result for unknown intent %s", intent_id)
                return False

            receipt = self._routes.get(receipt_id)
            if receipt is None:
                logger.warning("No receipt found for intent %s", intent_id)
                return False

            receipt.complete(result)
            self._stats["routes_completed"] += 1

        if self._on_route_completed:
            try:
                self._on_route_completed(receipt)
            except Exception as e:
                logger.error("on_route_completed callback error: %s", e)

        logger.info("Received result for intent %s (%s)", intent_id, receipt_id)
        return True

    def fail_route(self, intent_id: str, error: str) -> bool:
        """Mark a routed intent as failed.

        Args:
            intent_id: The intent_id to mark as failed.
            error: Error description.

        Returns:
            True if the route was found and marked failed.
        """
        with self._lock:
            receipt_id = self._intent_to_receipt.get(intent_id)
            if receipt_id is None:
                return False
            receipt = self._routes.get(receipt_id)
            if receipt is None:
                return False
            receipt.fail(error)
            self._stats["routes_failed"] += 1

        logger.info("Route failed for intent %s: %s", intent_id, error)
        return True

    # ------------------------------------------------------------------ #
    # Route Queries
    # ------------------------------------------------------------------ #

    def get_pending_routes(self) -> List[Dict[str, Any]]:
        """Return all in-flight (non-completed, non-failed) routes.

        Returns:
            List of route receipt dicts with PENDING, IN_TRANSIT, or
            PROCESSING status.
        """
        active_statuses = {
            RouteStatus.PENDING,
            RouteStatus.IN_TRANSIT,
            RouteStatus.PROCESSING,
        }
        with self._lock:
            return [
                r.to_dict()
                for r in self._routes.values()
                if r.status in active_statuses
            ]

    def get_route_by_receipt(self, receipt_id: str) -> Optional[Dict[str, Any]]:
        """Get a route receipt by its receipt_id."""
        with self._lock:
            receipt = self._routes.get(receipt_id)
            if receipt is None:
                return None
            return receipt.to_dict()

    def get_route_by_intent(self, intent_id: str) -> Optional[Dict[str, Any]]:
        """Get a route receipt by intent_id."""
        with self._lock:
            receipt_id = self._intent_to_receipt.get(intent_id)
            if receipt_id is None:
                return None
            receipt = self._routes.get(receipt_id)
            if receipt is None:
                return None
            return receipt.to_dict()

    def get_all_routes(self) -> List[Dict[str, Any]]:
        """Return all routes ever created."""
        with self._lock:
            return [r.to_dict() for r in self._routes.values()]

    # ------------------------------------------------------------------ #
    # Callbacks
    # ------------------------------------------------------------------ #

    def on_route_started(self, callback: Callable[[RouteReceipt], None]) -> None:
        """Register a callback fired when a route is initiated."""
        self._on_route_started = callback

    def on_route_completed(self, callback: Callable[[RouteReceipt], None]) -> None:
        """Register a callback fired when a route completes."""
        self._on_route_completed = callback

    # ------------------------------------------------------------------ #
    # Stats & Health
    # ------------------------------------------------------------------ #

    def get_stats(self) -> Dict[str, Any]:
        """Return routing statistics."""
        with self._lock:
            stats = dict(self._stats)
            stats["active_brokers"] = len(
                [b for b in self._brokers.values() if b.active]
            )
            stats["total_brokers"] = len(self._brokers)
            stats["pending_routes"] = len(self.get_pending_routes())
            stats["total_routes"] = len(self._routes)
            return stats

    def mark_broker_offline(self, broker_id: str) -> bool:
        """Mark a broker as offline without removing it."""
        with self._lock:
            if broker_id not in self._brokers:
                return False
            self._brokers[broker_id].active = False
            logger.info("Marked broker %s offline", broker_id)
            return True

    def mark_broker_online(self, broker_id: str) -> bool:
        """Mark a broker as online again."""
        with self._lock:
            if broker_id not in self._brokers:
                return False
            self._brokers[broker_id].active = True
            self._brokers[broker_id].last_seen = time.time()
            logger.info("Marked broker %s online", broker_id)
            return True

    def get_broker(self, broker_id: str) -> Optional[Dict[str, Any]]:
        """Get details for a specific broker."""
        with self._lock:
            broker = self._brokers.get(broker_id)
            if broker is None:
                return None
            return {
                "broker_id": broker.broker_id,
                "address": broker.address,
                "capabilities": broker.capabilities,
                "registered_at": broker.registered_at,
                "last_seen": broker.last_seen,
                "active": broker.active,
            }


# ===================================================================== #
# Verification Block
# ===================================================================== #
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(levelname)s %(name)s: %(message)s")

    print("=== CrossBrokerRouter Verification ===\n")

    # Create router
    router = CrossBrokerRouter(local_broker_id="broker-alpha")

    # Register brokers
    router.register_broker("broker-beta", "tcp://10.0.0.2:9000",
                           capabilities=["compute", "storage"])
    router.register_broker("broker-gamma", "tcp://10.0.0.3:9000",
                           capabilities=["ml_inference", "compute"])
    router.register_broker("broker-delta", "tcp://10.0.0.4:9000",
                           capabilities=["storage", "analytics"])
    print(f"Registered 3 brokers. Total: {len(router.list_brokers())}")

    # Find broker by capability
    compute_broker = router.get_broker_for_capability("compute")
    assert compute_broker is not None, "Should find a compute broker"
    print(f"Capability 'compute' → {compute_broker.broker_id}")

    ml_broker = router.get_broker_for_capability("ml_inference")
    assert ml_broker is not None, "Should find an ML broker"
    print(f"Capability 'ml_inference' → {ml_broker.broker_id}")

    missing = router.get_broker_for_capability("quantum")
    assert missing is None, "Should not find unregistered capability"
    print("Capability 'quantum' → None (correct)")

    # Route an intent
    intent = {
        "intent_id": "intent-001",
        "capability": "ml_inference",
        "payload": {"model": "gpt-4", "prompt": "Hello"},
    }
    receipt_id = router.route_intent(intent, source_broker="broker-alpha")
    assert receipt_id is not None, "Route should succeed"
    print(f"\nRouted intent-001 → receipt {receipt_id}")

    # Check pending routes
    pending = router.get_pending_routes()
    assert len(pending) == 1, f"Expected 1 pending, got {len(pending)}"
    print(f"Pending routes: {len(pending)}")

    # Receive result
    result = {"output": "Hello, world!", "tokens": 5}
    success = router.receive_result("intent-001", result)
    assert success, "receive_result should succeed"
    print("Result received for intent-001")

    # Verify route is no longer pending
    pending = router.get_pending_routes()
    assert len(pending) == 0, f"Expected 0 pending, got {len(pending)}"
    print(f"Pending after completion: {len(pending)}")

    # Route without capability (should fail)
    bad_intent = {"intent_id": "intent-002", "payload": {}}
    bad_receipt = router.route_intent(bad_intent)
    assert bad_receipt is None, "Route without target should return None"
    print("\nRoute without target → None (correct)")

    # Remove broker
    removed = router.remove_broker("broker-delta")
    assert removed, "remove_broker should succeed"
    brokers = router.list_brokers()
    assert len(brokers) == 2, f"Expected 2 brokers, got {len(brokers)}"
    print(f"\nRemoved broker-delta. Remaining: {[b['broker_id'] for b in brokers]}")

    # Fail a route
    intent3 = {"intent_id": "intent-003", "capability": "compute"}
    rid3 = router.route_intent(intent3, source_broker="broker-alpha",
                                target_broker="broker-beta")
    assert rid3 is not None
    failed = router.fail_route("intent-003", "Connection timeout")
    assert failed, "fail_route should succeed"
    route3 = router.get_route_by_intent("intent-003")
    assert route3["status"] == "failed", f"Expected 'failed', got {route3['status']}"
    print(f"\nFailed intent-003: status={route3['status']}")

    # Stats
    stats = router.get_stats()
    print(f"\nStats: {stats}")

    # Broker online/offline
    router.mark_broker_offline("broker-beta")
    beta = router.get_broker("broker-beta")
    assert beta["active"] is False, "Broker should be offline"
    router.mark_broker_online("broker-beta")
    beta = router.get_broker("broker-beta")
    assert beta["active"] is True, "Broker should be back online"

    print("\n=== All CrossBrokerRouter tests passed! ===\n")
