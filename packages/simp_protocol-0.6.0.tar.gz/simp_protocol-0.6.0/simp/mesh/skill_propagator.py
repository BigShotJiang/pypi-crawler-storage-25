"""
Skill Bundle Propagation via IMITATION Learning — T55

Enables peer-to-peer QuantumSkill propagation across the mesh.
When an agent successfully executes a skill, the QuantumSkillEvolver
logs the experience and promotes the skill to a bundle that is
broadcast to neighboring agents for IMITATION learning.
"""
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from simp.mesh.enhanced_bus import EnhancedMeshBus


@dataclass
class SkillBundle:
    """A bundle of QuantumSkill objects ready for propagation."""
    skill_id: str
    level: int
    problem_types: List[str]
    success_rate: float
    benchmark_delta: float
    sender_agent_id: str
    sender_trust_score: float
    sample_count: int
    created_at: float = field(default_factory=time.time)
    bundle_id: str = field(default_factory=lambda: __import__("uuid").uuid4().hex)

    def is_quality_eligible(self) -> bool:
        """Check if skill meets quality gates for propagation."""
        return (
            self.benchmark_delta > 0.0
            and self.sample_count >= 10
            and self.success_rate >= 0.7
        )


@dataclass
class SkillPropagationRecord:
    """Tracks a single skill propagation event."""
    bundle: SkillBundle
    recipient_agent_ids: List[str]
    success_count: int = 0
    imitation_count: int = 0
    propagated_at: float = field(default_factory=time.time)


class SkillPropagator:
    """
    Manages skill bundle propagation across the mesh.

    Flow:
    1. Agent executes skill → success
    2. QuantumSkillEvolver.log_experience() → outcome="success"
    3. Skill promoted → SkillPropagator.broadcast_skill() → mesh
    4. Neighbor agent receives → QuantumSkillEvolver.add_skill() (IMITATION)
    """

    def __init__(self, mesh_bus: Optional["EnhancedMeshBus"] = None):
        self._mesh_bus = mesh_bus
        self._propagation_log: List[SkillPropagationRecord] = []
        self._stats: Dict[str, int] = {
            "bundles_created": 0,
            "bundles_broadcast": 0,
            "imitations_triggered": 0,
        }
        self._lock = threading.RLock()

    def set_mesh_bus(self, mesh_bus: "EnhancedMeshBus") -> None:
        self._mesh_bus = mesh_bus

    def create_bundle(
        self,
        skill_id: str,
        level: int,
        problem_types: List[str],
        success_rate: float,
        benchmark_delta: float,
        sender_agent_id: str,
        sender_trust_score: float,
        sample_count: int,
    ) -> SkillBundle:
        """Create a new skill bundle from a promoted skill."""
        bundle = SkillBundle(
            skill_id=skill_id,
            level=level,
            problem_types=problem_types,
            success_rate=success_rate,
            benchmark_delta=benchmark_delta,
            sender_agent_id=sender_agent_id,
            sender_trust_score=sender_trust_score,
            sample_count=sample_count,
        )
        with self._lock:
            self._stats["bundles_created"] += 1
        return bundle

    def broadcast_skill(self, bundle: SkillBundle) -> bool:
        """Broadcast a skill bundle over the mesh."""
        if not bundle.is_quality_eligible():
            return False

        record = SkillPropagationRecord(bundle=bundle, recipient_agent_ids=[])
        with self._lock:
            self._propagation_log.append(record)
            self._stats["bundles_broadcast"] += 1

        if self._mesh_bus is None:
            return True  # Logged even without mesh bus

        try:
            self._mesh_bus.publish(
                channel="skill_broadcasts",
                payload={
                    "bundle_id": bundle.bundle_id,
                    "skill_id": bundle.skill_id,
                    "level": bundle.level,
                    "problem_types": bundle.problem_types,
                    "success_rate": bundle.success_rate,
                    "benchmark_delta": bundle.benchmark_delta,
                    "sender_agent_id": bundle.sender_agent_id,
                    "sender_trust_score": bundle.sender_trust_score,
                    "sample_count": bundle.sample_count,
                    "created_at": bundle.created_at,
                },
            )
            return True
        except Exception:
            return False

    def receive_bundle(self, payload: Dict[str, Any]) -> Optional[SkillBundle]:
        """Reconstruct a SkillBundle from a mesh payload."""
        try:
            bundle = SkillBundle(
                bundle_id=payload.get("bundle_id", ""),
                skill_id=payload["skill_id"],
                level=payload["level"],
                problem_types=payload["problem_types"],
                success_rate=payload["success_rate"],
                benchmark_delta=payload["benchmark_delta"],
                sender_agent_id=payload["sender_agent_id"],
                sender_trust_score=payload["sender_trust_score"],
                sample_count=payload["sample_count"],
                created_at=payload.get("created_at", time.time()),
            )
            with self._lock:
                self._stats["imitations_triggered"] += 1
            return bundle
        except (KeyError, TypeError):
            return None

    def get_stats(self) -> Dict[str, int]:
        return dict(self._stats)

    def get_propagation_log(self) -> List[Dict[str, Any]]:
        """Return logged propagation records."""
        with self._lock:
            return [
                {
                    "bundle_id": r.bundle.bundle_id,
                    "skill_id": r.bundle.skill_id,
                    "recipient_count": len(r.recipient_agent_ids),
                    "success_count": r.success_count,
                    "propagated_at": r.propagated_at,
                }
                for r in self._propagation_log
            ]


# Singleton
_propagator: Optional[SkillPropagator] = None


def get_skill_propagator() -> SkillPropagator:
    global _propagator
    if _propagator is None:
        _propagator = SkillPropagator()
    return _propagator
