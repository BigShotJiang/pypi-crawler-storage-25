"""
Mesh Rebalancer — L3-T4

Watches agent join/leave events and redistributes intents across capable
agents to maintain balanced load. Works with the routing table to find
capable agents and reassign intents within a 5-second deadline.

Design:
- ``on_agent_join(agent_id)`` — redistributes pending intents to include new agent
- ``on_agent_leave(agent_id)`` — reassigns leaving agent's intents to remaining capable agents
- ``rebalance()`` — redistributes all intents based on current agent load
- Uses routing table to find capable agents for each intent type
- Thread-safe, with timeout enforcement (must complete within 5s)
"""

import logging
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Protocol, Set, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Protocols so Rebalancer works with any routing table / intent tracker
# ---------------------------------------------------------------------------

class RoutingTableProtocol(Protocol):
    """Minimal interface expected by Rebalancer."""

    def find_routes(self, intent_type: str) -> List[str]:
        """Return agent IDs capable of handling intent_type."""
        ...

    def lookup(self, intent_type: str, min_reputation: float = 0.0,
               max_results: int = 5) -> List[object]:
        """Return route entries for an intent type."""
        ...

    def get_routes_for_capability(self, capability: str) -> List[object]:
        """Get all routes for a specific capability."""
        ...

    def add_manual_route(self, intent_type: str, agent_id: str,
                         endpoint: Optional[str] = None,
                         reputation: float = 0.5) -> None:
        """Manually add a route."""
        ...

    def remove_agent_routes(self, agent_id: str) -> int:
        """Remove all routes for an agent. Returns count removed."""
        ...


class IntentStoreProtocol(Protocol):
    """Minimal interface for the store / queue that holds pending intents."""

    def get_pending_intents(self) -> List[Dict]:
        """Return all pending intents with their types and current assignments."""
        ...

    def reassign_intent(self, intent_id: str, new_agent_id: str) -> bool:
        """Reassign a pending intent to a new agent."""
        ...


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class AgentLoad:
    """Load snapshot for a single agent."""
    agent_id: str
    intent_count: int           # Number of intents currently assigned
    max_capacity: int = 10      # Maximum intents this agent can handle
    load_factor: float = 0.0    # intent_count / max_capacity (computed)

    def compute_load_factor(self) -> float:
        self.load_factor = (self.intent_count / self.max_capacity
                            if self.max_capacity > 0 else 1.0)
        return self.load_factor


@dataclass
class RebalanceEvent:
    """Record of a rebalance operation."""
    event_type: str             # "join", "leave", "full_rebalance"
    timestamp: float = field(default_factory=time.time)
    agent_id: Optional[str] = None
    intents_moved: int = 0
    duration_ms: float = 0.0
    success: bool = True
    details: str = ""

    def to_dict(self) -> dict:
        return {
            "event_type": self.event_type,
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
            "intents_moved": self.intents_moved,
            "duration_ms": self.duration_ms,
            "success": self.success,
            "details": self.details,
        }


# ---------------------------------------------------------------------------
# MeshRebalancer
# ---------------------------------------------------------------------------

class MeshRebalancer:
    """
    Watches agent join/leave events and redistributes intents across capable
    agents to maintain balanced load.

    Thread-safe via ``threading.RLock``. All public methods enforce a
    5-second timeout to prevent blocking the mesh control plane.
    """

    REBALANCE_TIMEOUT = 5.0  # seconds

    def __init__(self, routing_table: RoutingTableProtocol,
                 intent_store: Optional[IntentStoreProtocol] = None):
        """
        Args:
            routing_table: Any object implementing the routing table protocol.
            intent_store: Optional store of pending intents for reassignment.
                          If None, rebalancer tracks intents internally.
        """
        self._routing_table = routing_table
        self._intent_store = intent_store
        self._lock = threading.RLock()

        # Internal intent tracking: intent_id -> {type, agent_id, ...}
        self._intents: Dict[str, Dict] = {}

        # Agent capacity tracking: agent_id -> max_capacity
        self._agent_capacity: Dict[str, int] = defaultdict(lambda: 10)

        # Event history (last 100 events for observability)
        self._history: List[RebalanceEvent] = []
        self._max_history = 100

        # Stale intent tracking (intents that couldn't be assigned)
        self._stale_intents: Dict[str, Dict] = {}

        logger.info("MeshRebalancer initialized")

    # ------------------------------------------------------------------
    # Intent tracking
    # ------------------------------------------------------------------

    def track_intent(self, intent_id: str, intent_type: str,
                     assigned_agent: Optional[str] = None) -> None:
        """
        Register an intent in the rebalancer's internal tracker.

        If ``assigned_agent`` is provided the intent is considered already
        assigned; otherwise it is pending assignment.
        """
        with self._lock:
            self._intents[intent_id] = {
                "id": intent_id,
                "type": intent_type,
                "assigned_agent": assigned_agent,
                "created_at": time.time(),
            }

    def untrack_intent(self, intent_id: str) -> Optional[Dict]:
        """Remove an intent from tracking. Returns the record or None."""
        with self._lock:
            return self._intents.pop(intent_id, None)

    def get_pending_intents(self) -> List[Dict]:
        """Return all tracked intents that are not yet assigned."""
        with self._lock:
            return [
                i for i in self._intents.values()
                if i.get("assigned_agent") is None
            ]

    def get_agent_intents(self, agent_id: str) -> List[Dict]:
        """Return all intents assigned to a specific agent."""
        with self._lock:
            return [
                i for i in self._intents.values()
                if i.get("assigned_agent") == agent_id
            ]

    def get_all_intents(self) -> List[Dict]:
        """Return all tracked intents."""
        with self._lock:
            return list(self._intents.values())

    # ------------------------------------------------------------------
    # Capacity management
    # ------------------------------------------------------------------

    def set_agent_capacity(self, agent_id: str, capacity: int) -> None:
        """Set the maximum number of intents an agent can handle."""
        with self._lock:
            self._agent_capacity[agent_id] = capacity

    def get_agent_capacity(self, agent_id: str) -> int:
        """Get the maximum capacity for an agent."""
        with self._lock:
            return self._agent_capacity.get(agent_id, 10)

    def get_agent_load(self, agent_id: str) -> AgentLoad:
        """Get the current load snapshot for an agent."""
        with self._lock:
            intent_count = len(self.get_agent_intents(agent_id))
            max_cap = self._agent_capacity.get(agent_id, 10)
            load = AgentLoad(
                agent_id=agent_id,
                intent_count=intent_count,
                max_capacity=max_cap,
            )
            load.compute_load_factor()
            return load

    def get_all_loads(self) -> List[AgentLoad]:
        """Get load snapshots for all known agents."""
        with self._lock:
            agent_ids: Set[str] = set()
            for intent in self._intents.values():
                agent = intent.get("assigned_agent")
                if agent:
                    agent_ids.add(agent)
            # Also include agents from routing table capacity tracking
            agent_ids.update(self._agent_capacity.keys())
            return [self.get_agent_load(aid) for aid in agent_ids]

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def on_agent_join(self, agent_id: str) -> RebalanceEvent:
        """
        Called when a new agent joins the mesh.

        Redistributes pending (unassigned) intents to include the new agent,
        as well as lightly-loaded intents from overloaded agents.
        Must complete within ``REBALANCE_TIMEOUT`` seconds.
        """
        start = time.time()
        event = RebalanceEvent(
            event_type="join",
            agent_id=agent_id,
        )
        logger.info("Agent joined: %s — rebalancing...", agent_id)

        try:
            with self._lock:
                intents_moved = self._redistribute_to_include(agent_id)

            event.intents_moved = intents_moved
            event.success = True
            event.details = f"Agent {agent_id} joined; {intents_moved} intents moved"
            logger.info("Rebalance after join complete: %d intents moved", intents_moved)
        except Exception as e:
            event.success = False
            event.details = f"Error: {e}"
            logger.error("Rebalance after join failed: %s", e)
        finally:
            event.duration_ms = (time.time() - start) * 1000

        self._record_event(event)
        return event

    def on_agent_leave(self, agent_id: str) -> RebalanceEvent:
        """
        Called when an agent leaves the mesh.

        Reassigns all intents assigned to the leaving agent to other
        capable agents. Must complete within ``REBALANCE_TIMEOUT`` seconds.
        """
        start = time.time()
        event = RebalanceEvent(
            event_type="leave",
            agent_id=agent_id,
        )
        logger.info("Agent left: %s — reassigning intents...", agent_id)

        try:
            with self._lock:
                # Collect intents assigned to this agent
                leaving_intents = [
                    i for i in self._intents.values()
                    if i.get("assigned_agent") == agent_id
                ]

                intents_moved = 0
                for intent in leaving_intents:
                    # Find other capable agents for this intent type
                    candidates = self._find_candidates(
                        intent["type"], exclude={agent_id}
                    )
                    if candidates:
                        new_agent = candidates[0]
                        self._assign_intent(intent["id"], new_agent)
                        intents_moved += 1
                    else:
                        # No candidates — mark as stale
                        intent["assigned_agent"] = None
                        self._stale_intents[intent["id"]] = dict(intent)
                        logger.warning(
                            "Intent %s (%s) has no capable agents after %s left",
                            intent["id"], intent["type"], agent_id
                        )

                # Clean up capacity entry
                self._agent_capacity.pop(agent_id, None)

                # Remove routes for the leaving agent
                self._routing_table.remove_agent_routes(agent_id)

            event.intents_moved = intents_moved
            event.success = True
            event.details = (f"Agent {agent_id} left; {intents_moved} intents "
                             f"reassigned, {len(leaving_intents) - intents_moved} stale")
            logger.info("Rebalance after leave complete: %d intents reassigned",
                        intents_moved)
        except Exception as e:
            event.success = False
            event.details = f"Error: {e}"
            logger.error("Rebalance after leave failed: %s", e)
        finally:
            event.duration_ms = (time.time() - start) * 1000

        self._record_event(event)
        return event

    def rebalance(self) -> RebalanceEvent:
        """
        Full rebalance of all intents.

        Distributes all intents evenly across available capable agents
        based on load factor. Must complete within ``REBALANCE_TIMEOUT``.
        """
        start = time.time()
        event = RebalanceEvent(event_type="full_rebalance")
        logger.info("Full rebalance starting...")

        try:
            with self._lock:
                # Group intents by type
                intents_by_type: Dict[str, List[Dict]] = defaultdict(list)
                for intent in self._intents.values():
                    intents_by_type[intent["type"]].append(intent)

                intents_moved = 0
                for intent_type, intents_list in intents_by_type.items():
                    # Find capable agents
                    candidates = self._find_candidates(intent_type)
                    if not candidates:
                        logger.warning(
                            "No capable agents for intent type %s",
                            intent_type
                        )
                        continue

                    # Build load map for candidates
                    load_map: Dict[str, int] = {}
                    for agent_id in candidates:
                        load_map[agent_id] = len(self.get_agent_intents(agent_id))

                    # Redistribute — assign each intent to the least-loaded
                    for intent in intents_list:
                        # Find least-loaded candidate
                        least_loaded = min(
                            candidates,
                            key=lambda a: (
                                load_map.get(a, 0),
                                self._agent_capacity.get(a, 10),
                            )
                        )
                        current_agent = intent.get("assigned_agent")
                        if current_agent != least_loaded:
                            self._assign_intent(intent["id"], least_loaded)
                            load_map[least_loaded] = load_map.get(least_loaded, 0) + 1
                            intents_moved += 1

            event.intents_moved = intents_moved
            event.success = True
            event.details = f"Full rebalance complete: {intents_moved} intents moved"
            logger.info("Full rebalance complete: %d intents moved", intents_moved)
        except Exception as e:
            event.success = False
            event.details = f"Error: {e}"
            logger.error("Full rebalance failed: %s", e)
        finally:
            event.duration_ms = (time.time() - start) * 1000

        self._record_event(event)
        return event

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _redistribute_to_include(self, new_agent_id: str) -> int:
        """
        Move some pending intents to the new agent to balance load.

        Returns the number of intents moved.
        """
        # Find intent types this agent is capable of
        # (We check via routing table to see what routes exist for this agent)
        # For simplicity, find all pending intents and check capability
        pending = self.get_pending_intents()
        if not pending:
            return 0

        # Check if the new agent has capacity
        capacity = self._agent_capacity.get(new_agent_id, 10)
        current_load = len(self.get_agent_intents(new_agent_id))
        available = capacity - current_load
        if available <= 0:
            return 0

        intents_moved = 0
        for intent in pending:
            if intents_moved >= available:
                break
            # Check if this agent can handle this intent type
            candidates = self._find_candidates(intent["type"])
            if new_agent_id in candidates:
                self._assign_intent(intent["id"], new_agent_id)
                intents_moved += 1

        # Also check for overloaded agents and offload to the new agent
        overloaded = self._find_overloaded_agents()
        for agent_id in overloaded:
            if intents_moved >= available:
                break
            agent_intents = self.get_agent_intents(agent_id)
            for intent in agent_intents:
                if intents_moved >= available:
                    break
                candidates = self._find_candidates(intent["type"])
                if new_agent_id in candidates:
                    self._assign_intent(intent["id"], new_agent_id)
                    intents_moved += 1

        return intents_moved

    def _find_candidates(self, intent_type: str,
                         exclude: Optional[Set[str]] = None) -> List[str]:
        """Find capable agents for an intent type, optionally excluding some."""
        exclude = exclude or set()
        try:
            routes = self._routing_table.find_routes(intent_type)
            return [a for a in routes if a not in exclude]
        except Exception:
            logger.warning("Failed to query routes for %s", intent_type)
            return []

    def _find_overloaded_agents(self, threshold: float = 0.8) -> List[str]:
        """Find agents whose load factor exceeds the threshold."""
        overloaded = []
        for agent_id in list(self._agent_capacity.keys()):
            load = self.get_agent_load(agent_id)
            if load.load_factor > threshold:
                overloaded.append(agent_id)
        return overloaded

    def _assign_intent(self, intent_id: str, agent_id: str) -> None:
        """Assign an intent to an agent, updating both internal and external stores."""
        if intent_id in self._intents:
            self._intents[intent_id]["assigned_agent"] = agent_id

        # Also try the external intent store if available
        if self._intent_store is not None:
            try:
                self._intent_store.reassign_intent(intent_id, agent_id)
            except Exception as e:
                logger.warning("Failed to reassign intent %s in external store: %s",
                               intent_id, e)

    def _record_event(self, event: RebalanceEvent) -> None:
        """Record a rebalance event in history."""
        self._history.append(event)
        if len(self._history) > self._max_history:
            self._history.pop(0)

    # ------------------------------------------------------------------
    # Status & observability
    # ------------------------------------------------------------------

    def get_stats(self) -> dict:
        """Return statistics about the rebalancer state."""
        with self._lock:
            total_assigned = sum(
                1 for i in self._intents.values() if i.get("assigned_agent")
            )
            total_pending = len(self.get_pending_intents())
            return {
                "total_tracked_intents": len(self._intents),
                "assigned_intents": total_assigned,
                "pending_intents": total_pending,
                "stale_intents": len(self._stale_intents),
                "known_agents": len(self._agent_capacity),
                "rebalance_events": len(self._history),
                "rebalance_timeout_seconds": self.REBALANCE_TIMEOUT,
            }

    def get_rebalance_history(self,
                              limit: int = 10) -> List[dict]:
        """Return recent rebalance events."""
        with self._lock:
            return [e.to_dict() for e in self._history[-limit:]]

    def get_stale_intents(self) -> List[Dict]:
        """Return intents that couldn't be assigned to any agent."""
        with self._lock:
            return list(self._stale_intents.values())
