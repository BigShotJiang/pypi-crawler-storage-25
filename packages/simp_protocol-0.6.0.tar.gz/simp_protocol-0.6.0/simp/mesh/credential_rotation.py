"""
Mesh Credential Rotation — L3-T7

Broker coordinates Ed25519 key rotation across the mesh.
Old keys valid for 60s grace period during rotation.

Design:
- Rotation Coordinator: designated broker manages rotation schedule
- Two-phase rotation: ANNOUNCE → COMMIT → ACTIVATE
- Grace period: old key valid for 60s after new key activation
- Audit log of all rotations
"""

import json
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class RotationEvent:
    """Record of a credential rotation."""
    broker_id: str
    old_key_fingerprint: str
    new_key_fingerprint: str
    rotation_id: str
    timestamp: float = field(default_factory=time.time)
    status: str = "pending"  # pending, announced, committed, activated, rolled_back
    grace_period_end: Optional[float] = None
    acknowledged_by: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "broker_id": self.broker_id,
            "old_key_fingerprint": self.old_key_fingerprint,
            "new_key_fingerprint": self.new_key_fingerprint,
            "rotation_id": self.rotation_id,
            "timestamp": self.timestamp,
            "status": self.status,
            "grace_period_end": self.grace_period_end,
            "acknowledged_by": self.acknowledged_by,
        }


class CredentialRotationManager:
    """
    Manages Ed25519 key rotation across the mesh.
    Ensures zero-downtime rotation with grace period.
    """

    GRACE_PERIOD = 60.0  # Seconds old key remains valid

    def __init__(self, broker_id: str):
        self.broker_id = broker_id
        self._lock = threading.RLock()
        self._rotation_history: List[RotationEvent] = []
        self._active_rotation: Optional[RotationEvent] = None
        self._current_key_fingerprint: Optional[str] = None
        self._previous_key_fingerprint: Optional[str] = None
        self._previous_key_expiry: Optional[float] = None
        self._rotation_count = 0

        # Peers that have acknowledged the rotation
        self._acks: Dict[str, float] = {}

        logger.info("CredentialRotationManager initialized for %s", broker_id)

    def set_current_key(self, fingerprint: str) -> None:
        """Set the current active key fingerprint."""
        with self._lock:
            self._current_key_fingerprint = fingerprint

    def initiate_rotation(self, new_key_fingerprint: str) -> str:
        """Begin a key rotation. Returns rotation_id."""
        import uuid
        rotation_id = f"rot_{uuid.uuid4().hex[:12]}"

        with self._lock:
            event = RotationEvent(
                broker_id=self.broker_id,
                old_key_fingerprint=self._current_key_fingerprint or "unknown",
                new_key_fingerprint=new_key_fingerprint,
                rotation_id=rotation_id,
                status="announced",
            )
            self._active_rotation = event
            self._rotation_history.append(event)
            self._rotation_count += 1

        logger.info("Key rotation initiated: %s (old=%s -> new=%s)",
                     rotation_id, event.old_key_fingerprint, new_key_fingerprint)
        return rotation_id

    def acknowledge_rotation(self, rotation_id: str, peer_id: str) -> bool:
        """Record a peer's acknowledgment of a rotation."""
        with self._lock:
            if self._active_rotation and self._active_rotation.rotation_id == rotation_id:
                if peer_id not in self._active_rotation.acknowledged_by:
                    self._active_rotation.acknowledged_by.append(peer_id)
                logger.debug("Rotation %s acknowledged by %s", rotation_id, peer_id)
                return True
            return False

    def commit_rotation(self, rotation_id: str) -> bool:
        """
        Commit the rotation. Moves current key to previous (with grace period)
        and sets new key as current.
        """
        with self._lock:
            if not self._active_rotation or self._active_rotation.rotation_id != rotation_id:
                return False

            self._previous_key_fingerprint = self._active_rotation.old_key_fingerprint
            self._previous_key_expiry = time.time() + self.GRACE_PERIOD
            self._current_key_fingerprint = self._active_rotation.new_key_fingerprint
            self._active_rotation.status = "activated"
            self._active_rotation.grace_period_end = self._previous_key_expiry
            self._active_rotation = None

        logger.info("Rotation %s COMMITTED. Old key valid until T+%.0fs",
                     rotation_id, self.GRACE_PERIOD)
        return True

    def rollback_rotation(self, rotation_id: str) -> bool:
        """Rollback a rotation that hasn't been committed yet."""
        with self._lock:
            if not self._active_rotation or self._active_rotation.rotation_id != rotation_id:
                return False
            self._active_rotation.status = "rolled_back"
            self._active_rotation = None
        logger.warning("Rotation %s ROLLED BACK", rotation_id)
        return True

    def is_key_valid(self, key_fingerprint: str) -> bool:
        """
        Check if a key is currently valid (current key OR previous key within grace period).
        """
        with self._lock:
            if key_fingerprint == self._current_key_fingerprint:
                return True
            if (key_fingerprint == self._previous_key_fingerprint
                    and self._previous_key_expiry
                    and time.time() < self._previous_key_expiry):
                return True
            return False

    def get_active_rotation(self) -> Optional[dict]:
        """Get the current in-progress rotation, if any."""
        with self._lock:
            return self._active_rotation.to_dict() if self._active_rotation else None

    def get_stats(self) -> dict:
        with self._lock:
            return {
                "broker_id": self.broker_id,
                "current_key": self._current_key_fingerprint,
                "previous_key": self._previous_key_fingerprint,
                "previous_key_valid_for": max(0, self._previous_key_expiry - time.time()) if self._previous_key_expiry else 0,
                "rotation_count": self._rotation_count,
                "active_rotation": self._active_rotation is not None,
                "history_count": len(self._rotation_history),
            }


# ---------------------------------------------------------------------------
# L3-T8: Mesh Health Consensus
# ---------------------------------------------------------------------------

import random


@dataclass
class HealthVote:
    """A vote from one broker about another broker's health."""
    voter_id: str
    subject_id: str
    healthy: bool
    timestamp: float = field(default_factory=time.time)
    round: int = 0

    def to_dict(self) -> dict:
        return {
            "voter_id": self.voter_id,
            "subject_id": self.subject_id,
            "healthy": self.healthy,
            "timestamp": self.timestamp,
            "round": self.round,
        }


class HealthConsensus:
    """
    Raft-inspired health consensus protocol.

    Brokers vote on each other's health. Quorum = 67% of active brokers.
    If a broker fails to get a majority of healthy votes, it's marked degraded.
    Consensus runs in rounds; each round collects votes from all active brokers.
    """

    def __init__(self, broker_id: str, quorum_pct: float = 0.67,
                 consensus_interval: float = 15.0):
        self.broker_id = broker_id
        self.quorum_pct = quorum_pct
        self.consensus_interval = consensus_interval

        self._lock = threading.RLock()
        self._broker_list: List[str] = []
        self._votes: Dict[str, List[HealthVote]] = {}  # subject_id -> votes
        self._health_state: Dict[str, bool] = {}         # broker_id -> healthy
        self._current_round = 0
        self._last_consensus: float = 0.0

        # Callback when quorum status changes
        self._on_health_change: Optional[callable] = None

        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Stats
        self._consensus_count = 0
        self._degraded_count = 0

        logger.info("HealthConsensus initialized for %s (quorum=%.0f%%)",
                     broker_id, quorum_pct * 100)

    def set_broker_list(self, brokers: List[str]) -> None:
        with self._lock:
            self._broker_list = brokers
            for b in brokers:
                if b not in self._health_state:
                    self._health_state[b] = True  # Default healthy

    def cast_vote(self, voter_id: str, subject_id: str, healthy: bool) -> None:
        """Record a health vote."""
        with self._lock:
            if subject_id not in self._votes:
                self._votes[subject_id] = []
            self._votes[subject_id].append(HealthVote(
                voter_id=voter_id,
                subject_id=subject_id,
                healthy=healthy,
                round=self._current_round,
            ))

    def check_quorum(self) -> Dict[str, bool]:
        """
        Check if quorum reached. Returns {broker_id: healthy} for all brokers.
        Healthy = >50% of votes say healthy AND quorum (67% of brokers voted).
        """
        with self._lock:
            active_count = len(self._broker_list)
            required_votes = max(2, int(active_count * self.quorum_pct))
            results: Dict[str, bool] = {}

            for subject_id in self._broker_list:
                subject_votes = self._votes.get(subject_id, [])
                # Only count votes from current round
                current_votes = [v for v in subject_votes if v.round == self._current_round]

                if len(current_votes) < required_votes:
                    # Not enough votes yet
                    results[subject_id] = self._health_state.get(subject_id, True)
                    continue

                healthy_votes = sum(1 for v in current_votes if v.healthy)
                majority = healthy_votes > len(current_votes) / 2
                results[subject_id] = majority

                # Track changes
                old_state = self._health_state.get(subject_id, True)
                if old_state != majority:
                    logger.info("Health consensus changed for %s: %s -> %s",
                                subject_id, old_state, majority)
                    if not majority:
                        self._degraded_count += 1
                    if self._on_health_change:
                        self._on_health_change(subject_id, majority)

            self._health_state.update(results)
            self._current_round += 1
            self._consensus_count += 1
            self._last_consensus = time.time()

            return dict(self._health_state)

    def get_healthy_brokers(self) -> List[str]:
        """Get list of brokers currently considered healthy."""
        with self._lock:
            return [b for b, h in self._health_state.items() if h]

    def get_degraded_brokers(self) -> List[str]:
        """Get list of degraded brokers."""
        with self._lock:
            return [b for b, h in self._health_state.items() if not h]

    def set_health_change_callback(self, cb: callable) -> None:
        self._on_health_change = cb

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._consensus_loop,
            daemon=True,
            name=f"HealthConsensus-{self.broker_id}",
        )
        self._thread.start()
        logger.info("HealthConsensus started for %s", self.broker_id)

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)

    def _consensus_loop(self) -> None:
        while self._running:
            try:
                self.check_quorum()
            except Exception as e:
                logger.error("Consensus check error: %s", e)
            time.sleep(self.consensus_interval)

    def get_status(self) -> dict:
        with self._lock:
            return {
                "broker_id": self.broker_id,
                "running": self._running,
                "broker_count": len(self._broker_list),
                "quorum_pct": self.quorum_pct,
                "healthy_brokers": self.get_healthy_brokers(),
                "degraded_brokers": self.get_degraded_brokers(),
                "current_round": self._current_round,
                "consensus_count": self._consensus_count,
                "degraded_count": self._degraded_count,
            }

    def to_dict(self) -> dict:
        return self.get_status()
