"""
SIMP Zero-Syscall Hot Path — T30-5

For trusted agents on the same node: shared memory transport for zero syscalls.
  - Zero syscalls for local message passing (multiprocessing.Queue or posix_ipc)
  - Shared memory ring buffer: 65536 slots
  - Futex-like spin-wait primitive

Files: simp/mesh/shmem_transport.py, simp/mesh/__init__.py
"""

from __future__ import annotations

import json
import logging
import mmap
import os
import struct
import sys
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Callable

logger = logging.getLogger("SIMP.ShmemTransport")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

RING_BUFFER_SIZE = 65536  # Number of slots in the shared memory ring buffer
SLOT_SIZE = 4096  # Each slot is 4KB (fits most serialized intents)
HEADER_MAGIC = 0x53494D50  # "SIMP" in ASCII

# Shared memory ring buffer header (first mmap page)
HEADER_FORMAT = "=IIQQQ"  # magic, version, head, tail, slot_size
HEADER_SIZE = struct.calcsize(HEADER_FORMAT)

# Slot header: occupied flag + size
SLOT_HEADER_FORMAT = "=II"  # occupied(1), size(4)
SLOT_HEADER_SIZE = struct.calcsize(SLOT_HEADER_FORMAT)
SLOT_DATA_SIZE = SLOT_SIZE - SLOT_HEADER_SIZE  # Actual payload space


# ---------------------------------------------------------------------------
# Ring Buffer Header
# ---------------------------------------------------------------------------


@dataclass
class RingBufferHeader:
    """Header for the shared memory ring buffer."""
    magic: int = HEADER_MAGIC
    version: int = 1
    head: int = 0  # Write position
    tail: int = 0  # Read position
    slot_size: int = SLOT_SIZE

    def pack(self) -> bytes:
        return struct.pack(HEADER_FORMAT, self.magic, self.version, self.head, self.tail, self.slot_size)

    @classmethod
    def unpack(cls, data: bytes) -> "RingBufferHeader":
        values = struct.unpack(HEADER_FORMAT, data[:HEADER_SIZE])
        return cls(
            magic=values[0],
            version=values[1],
            head=values[2],
            tail=values[3],
            slot_size=values[4],
        )

    def is_valid(self) -> bool:
        return self.magic == HEADER_MAGIC and self.version == 1


# ---------------------------------------------------------------------------
# Slot Operations
# ---------------------------------------------------------------------------


def pack_slot(occupied: int, size: int, data: bytes) -> bytes:
    """Pack a slot: occupied flag + size + data (padded to SLOT_SIZE)."""
    header = struct.pack(SLOT_HEADER_FORMAT, occupied, size)
    padded = data.ljust(SLOT_DATA_SIZE, b"\x00")
    return header + padded


def unpack_slot(slot_data: bytes) -> tuple:
    """Unpack a slot: returns (occupied, size, data)."""
    header = slot_data[:SLOT_HEADER_SIZE]
    occupied, size = struct.unpack(SLOT_HEADER_FORMAT, header)
    data = slot_data[SLOT_HEADER_SIZE:SLOT_HEADER_SIZE + size]
    return occupied, size, data


# ---------------------------------------------------------------------------
# Futex-like Spin Wait
# ---------------------------------------------------------------------------


class SpinWait:
    """
    Futex-like spin-wait primitive for hot-path synchronization.

    Uses a simple shared memory location. Producer/consumer spin-wait
    with exponential back-off when buffer is empty/full.
    """

    def __init__(self, addr: int = 0):
        self._addr = addr
        self._spins = 0

    def wait_for(self, condition: Callable[[], bool], timeout: float = 1.0) -> bool:
        """
        Spin-wait until condition is True or timeout expires.

        Uses progressive back-off to avoid bus lock contention:
          - First 1000 iterations: no delay
          - Next 1000: yield to other threads
          - Beyond: sleep exponentially longer
        """
        deadline = time.monotonic() + timeout
        base_delay = 0.000001  # 1µs

        while not condition():
            if time.monotonic() >= deadline:
                return False

            self._spins += 1

            if self._spins < 1000:
                # Bare spin — no delay
                continue
            elif self._spins < 2000:
                # Yield
                time.sleep(0)
            else:
                # Exponential back-off up to 1ms
                delay = min(base_delay * (2 ** (self._spins - 2000)), 0.001)
                time.sleep(delay)

        return True


# ---------------------------------------------------------------------------
# Shared Memory Ring Buffer
# ---------------------------------------------------------------------------


class ShmemRingBuffer:
    """
    Lock-free ring buffer backed by shared memory (mmap).

    Producers and consumers coordinate via head/tail indices in shared memory.
    This is a single-producer-single-consumer (SPSC) queue.

    Layout:
      - Page 0: header (RingBufferHeader)
      - Pages 1..N: slots (RING_BUFFER_SIZE * SLOT_SIZE bytes)

    Thread-safe for multiple producers or consumers using atomic operations
    on head/tail. In Python we use GIL-protected access for simplicity.
    """

    def __init__(
        self,
        name: str,
        size: int = RING_BUFFER_SIZE,
        create: bool = True,
        path: Optional[Path] = None,
    ):
        """
        Initialize shared memory ring buffer.

        Args:
            name: Unique name for this buffer (used in mmap filename)
            size: Number of slots (default 65536)
            create: If True, create new shared memory; if False, attach to existing
            path: Directory for mmap file (default: /dev/shm on Linux, /tmp on macOS)
        """
        self.name = name
        self.size = size

        # Determine mmap path
        if path is None:
            if sys.platform == "darwin":
                path = Path("/tmp")
            else:
                path = Path("/dev/shm")
        self._path = path / f"simp_shmem_{name}.bin"

        self._mmap: Optional[mmap.mmap] = None
        self._header: Optional[RingBufferHeader] = None
        self._view: memoryview = None  # For faster access

        self._lock = threading.Lock()
        self._spin_wait = SpinWait()

        if create:
            self._create()
        else:
            self._attach()

    def _create(self) -> None:
        """Create new shared memory ring buffer."""
        file_size = HEADER_SIZE + self.size * SLOT_SIZE

        # Create or truncate file
        with open(self._path, "wb") as f:
            f.write(b"\x00" * file_size)

        self._mmap = mmap.mmap(fileno=-1, length=file_size, mmap_flags=mmap.MAP_SHARED)
        self._header = RingBufferHeader(
            magic=HEADER_MAGIC,
            version=1,
            head=0,
            tail=0,
            slot_size=SLOT_SIZE,
        )

        # Write header
        self._mmap[:HEADER_SIZE] = self._header.pack()

        self._view = memoryview(self._mmap)
        logger.info(f"ShmemRingBuffer[{self.name}] created ({self.size} slots @ {SLOT_SIZE}B)")

    def _attach(self) -> None:
        """Attach to existing shared memory ring buffer."""
        with open(self._path, "r+b") as f:
            self._mmap = mmap.mmap(fileno=f.fileno(), length=0, mmap_flags=mmap.MAP_SHARED)

        header_data = bytes(self._mmap[:HEADER_SIZE])
        self._header = RingBufferHeader.unpack(header_data)

        if not self._header.is_valid():
            raise ValueError(f"Invalid ShmemRingBuffer[{self.name}]: bad magic or version")

        self._view = memoryview(self._mmap)
        logger.info(f"ShmemRingBuffer[{self.name}] attached (head={self._header.head}, tail={self._header.tail})")

    def push(self, data: bytes, timeout: float = 1.0) -> bool:
        """
        Push an item onto the ring buffer (producer side).

        Args:
            data: Bytes to push (must fit in SLOT_DATA_SIZE)
            timeout: How long to wait if buffer is full

        Returns:
            True if pushed, False if timeout
        """
        if len(data) > SLOT_DATA_SIZE:
            raise ValueError(f"Data too large: {len(data)} > {SLOT_DATA_SIZE}")

        deadline = time.monotonic() + timeout

        while time.monotonic() < deadline:
            head = self._header.head
            tail = self._header.tail

            # Calculate slots used
            slots_used = (head - tail) % self.size
            slots_free = self.size - slots_used - 1

            if slots_free == 0:
                # Buffer full, wait for consumer
                if not self._spin_wait.wait_for(
                    lambda: self._header.tail != tail,
                    timeout=deadline - time.monotonic(),
                ):
                    return False
                continue

            # Claim this slot
            slot_offset = HEADER_SIZE + (head % self.size) * SLOT_SIZE
            slot_data = pack_slot(1, len(data), data)

            # Write data
            self._mmap[slot_offset:slot_offset + SLOT_SIZE] = slot_data

            # Update head atomically
            self._header.head = (head + 1) % self.size
            self._mmap[:HEADER_SIZE] = self._header.pack()

            return True

        return False

    def pop(self, timeout: float = 1.0) -> Optional[bytes]:
        """
        Pop an item from the ring buffer (consumer side).

        Args:
            timeout: How long to wait if buffer is empty

        Returns:
            bytes if available, None if timeout
        """
        deadline = time.monotonic() + timeout

        while time.monotonic() < deadline:
            tail = self._header.tail
            head = self._header.head

            if tail == head:
                # Buffer empty, wait for producer
                if not self._spin_wait.wait_for(
                    lambda: self._header.head != head,
                    timeout=deadline - time.monotonic(),
                ):
                    return None
                continue

            # Claim this slot
            slot_offset = HEADER_SIZE + (tail % self.size) * SLOT_SIZE
            slot_data = bytes(self._mmap[slot_offset:slot_offset + SLOT_SIZE])
            occupied, size, data = unpack_slot(slot_data)

            if not occupied:
                # Slot not ready yet, retry
                time.sleep(0)
                continue

            # Mark slot as empty
            self._mmap[slot_offset:slot_offset + SLOT_HEADER_SIZE] = pack_slot(0, 0, b"")
            self._header.tail = (tail + 1) % self.size
            self._mmap[:HEADER_SIZE] = self._header.pack()

            return data

        return None

    def is_empty(self) -> bool:
        return self._header.head == self._header.tail

    def is_full(self) -> bool:
        slots_used = (self._header.head - self._header.tail) % self.size
        return slots_used >= self.size - 1

    def approximate_size(self) -> int:
        return (self._header.head - self._header.tail) % self.size

    def close(self) -> None:
        """Close the mmap."""
        if self._mmap:
            self._mmap.close()
            self._mmap = None

    def unlink(self) -> None:
        """Delete the backing file."""
        self._path.unlink(missing_ok=True)
        logger.info(f"ShmemRingBuffer[{self.name}] unlinked")


# ---------------------------------------------------------------------------
# High-Level Transport
# ---------------------------------------------------------------------------


class ShmemTransport:
    """
    Zero-syscall hot-path transport for same-node agent communication.

    Uses shared memory ring buffer for message passing with no socket overhead.

    Features:
      - mmap-backed ring buffer (65536 slots)
      - Spin-wait synchronization (futex-like)
      - Per-agent receive queues via shared memory
      - Signaled wait via threading.Event when slot available

    Usage:
      1. Both agents open same named buffer
      2. Agent A: transport.send(agent_b_id, intent_bytes) -> ring buffer
      3. Agent B: transport.receive() -> intent_bytes
    """

    def __init__(self, agent_id: str, trusted_agents: Optional[List[str]] = None):
        """
        Initialize ShmemTransport.

        Args:
            agent_id: This agent's ID
            trusted_agents: List of agent IDs that are trusted (can use shmem)
        """
        self.agent_id = agent_id
        self.trusted_agents = set(trusted_agents or [])

        self._lock = threading.Lock()
        self._shutdown = False

        # Named ring buffers per peer agent: peer_id -> ShmemRingBuffer
        self._peer_buffers: Dict[str, ShmemRingBuffer] = {}

        # Local receive queue for items pulled from ring buffers
        self._receive_queue: Deque[bytes] = deque()
        self._receive_event = threading.Event()

        # Statistics
        self._stats = {
            "messages_sent": 0,
            "messages_received": 0,
            "bytes_sent": 0,
            "bytes_received": 0,
            "send_timeouts": 0,
            "receive_timeouts": 0,
            "ring_buffer_hits": 0,
        }

        # Background thread for polling ring buffers
        self._poll_thread: Optional[threading.Thread] = None
        self._poll_event = threading.Event()

        logger.info(f"ShmemTransport[{agent_id}] initialized (trusted: {len(self.trusted_agents)})")

    # -------------------------------------------------------------------------
    # Peer Buffer Management
    # -------------------------------------------------------------------------

    def open_peer_buffer(self, peer_id: str, create: bool = True) -> ShmemRingBuffer:
        """
        Open shared memory ring buffer for communication with a peer.

        Args:
            peer_id: The peer's agent ID
            create: If True, create the buffer; if False, attach to existing
        """
        with self._lock:
            if peer_id in self._peer_buffers:
                return self._peer_buffers[peer_id]

            # Name the buffer based on sorted pair to ensure both agents use same name
            names = sorted([self.agent_id, peer_id])
            buf_name = f"{names[0]}_{names[1]}"

            buf = ShmemRingBuffer(name=buf_name, create=create)
            self._peer_buffers[peer_id] = buf
            return buf

    def close_all_buffers(self) -> None:
        """Close all peer buffers."""
        with self._lock:
            for buf in self._peer_buffers.values():
                buf.close()
            self._peer_buffers.clear()

    # -------------------------------------------------------------------------
    # Sending
    # -------------------------------------------------------------------------

    def send(self, peer_id: str, data: bytes, timeout: float = 1.0) -> bool:
        """
        Send data to a peer via shared memory (zero syscall).

        Args:
            peer_id: Target agent ID
            data: Bytes to send
            timeout: Send timeout

        Returns:
            True if sent, False if timeout or error
        """
        if peer_id not in self.trusted_agents:
            logger.warning(f"ShmemTransport[{self.agent_id}] reject send to untrusted {peer_id}")
            return False

        try:
            buf = self.open_peer_buffer(peer_id)
            success = buf.push(data, timeout=timeout)

            if success:
                self._stats["messages_sent"] += 1
                self._stats["bytes_sent"] += len(data)
            else:
                self._stats["send_timeouts"] += 1

            return success

        except Exception:
            logger.exception(f"ShmemTransport[{self.agent_id}] send to {peer_id} failed")
            return False

    def broadcast(self, data: bytes, timeout: float = 1.0) -> int:
        """
        Broadcast data to all trusted peers.

        Returns:
            Number of peers that received the data
        """
        count = 0
        for peer_id in list(self.trusted_agents):
            if self.send(peer_id, data, timeout=timeout):
                count += 1
        return count

    # -------------------------------------------------------------------------
    # Receiving
    # -------------------------------------------------------------------------

    def receive(self, timeout: float = 0.0) -> Optional[bytes]:
        """
        Receive next message (blocking or non-blocking).

        Args:
            timeout: Block for up to this many seconds (0 = non-blocking)

        Returns:
            Bytes if available, None otherwise
        """
        # Fast path: check local queue first
        with self._lock:
            if self._receive_queue:
                return self._receive_queue.popleft()

        # Poll peer buffers
        self._poll_buffers()

        with self._lock:
            if self._receive_queue:
                return self._receive_queue.popleft()

        # Wait for event
        if timeout > 0:
            if self._receive_event.wait(timeout=timeout):
                self._receive_event.clear()
                with self._lock:
                    if self._receive_queue:
                        return self._receive_queue.popleft()
        else:
            self._poll_buffers()
            with self._lock:
                if self._receive_queue:
                    return self._receive_queue.popleft()

        return None

    def _poll_buffers(self) -> None:
        """Poll all peer buffers for new messages (non-blocking)."""
        with self._lock:
            peers = list(self._peer_buffers.keys())

        for peer_id in peers:
            try:
                buf = self._peer_buffers.get(peer_id)
                if buf is None:
                    continue

                data = buf.pop(timeout=0)
                if data:
                    with self._lock:
                        self._receive_queue.append(data)
                        self._receive_event.set()
                    self._stats["messages_received"] += 1
                    self._stats["bytes_received"] += len(data)
                    self._stats["ring_buffer_hits"] += 1

            except Exception:
                logger.exception(f"ShmemTransport[{self.agent_id}] poll buffer {peer_id} failed")

    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------

    def start(self) -> None:
        """Start background polling thread."""
        with self._lock:
            if self._poll_thread and self._poll_thread.is_alive():
                return
            self._poll_event.clear()
            self._poll_thread = threading.Thread(
                target=self._poll_loop,
                name=f"ShmemPoll-{self.agent_id}",
                daemon=True,
            )
            self._poll_thread.start()
            logger.info(f"ShmemTransport[{self.agent_id}] polling thread started")

    def stop(self) -> None:
        """Stop polling thread."""
        self._shutdown = True
        self._poll_event.set()
        if self._poll_thread:
            self._poll_thread.join(timeout=3.0)

    def shutdown(self) -> None:
        """Full shutdown."""
        self.stop()
        self.close_all_buffers()

    # -------------------------------------------------------------------------
    # Internal
    # -------------------------------------------------------------------------

    def _poll_loop(self) -> None:
        """Background thread: poll peer buffers at high frequency."""
        while not self._shutdown:
            self._poll_buffers()

            with self._lock:
                has_messages = bool(self._receive_queue)

            if not has_messages:
                # Sleep briefly before next poll (adaptive)
                self._poll_event.wait(timeout=0.001)  # 1ms base

    # -------------------------------------------------------------------------
    # Statistics
    # -------------------------------------------------------------------------

    def get_statistics(self) -> Dict:
        with self._lock:
            return dict(self._stats)

    def get_receive_queue_size(self) -> int:
        with self._lock:
            return len(self._receive_queue)


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------


def create_shmem_transport(
    agent_id: str,
    trusted_agents: Optional[List[str]] = None,
) -> ShmemTransport:
    """Create a ShmemTransport for an agent."""
    return ShmemTransport(agent_id=agent_id, trusted_agents=trusted_agents)


# ---------------------------------------------------------------------------
# Fallback: multiprocessing.Queue based transport for when /dev/shm unavailable
# ---------------------------------------------------------------------------


class QueueTransport:
    """
    Fallback transport using multiprocessing.Queue when shared memory is unavailable.

    Still much faster than socket-based transport (~5µs vs ~500µs) but does use
    syscalls (pipe/futex). Used on macOS where /dev/shm may have limitations.
    """

    def __init__(self, agent_id: str, trusted_agents: Optional[List[str]] = None):
        import multiprocessing as mp

        self.agent_id = agent_id
        self.trusted_agents = set(trusted_agents or [])
        self._mp = mp

        # Per-peer queues
        self._queues: Dict[str, mp.Queue] = {}

        self._stats = {
            "messages_sent": 0,
            "messages_received": 0,
            "send_timeouts": 0,
        }

    def open_peer_queue(self, peer_id: str) -> None:
        """Create/open queue for peer."""
        if peer_id not in self._queues:
            self._queues[peer_id] = self._mp.Queue(maxsize=1000)

    def send(self, peer_id: str, data: bytes, timeout: float = 1.0) -> bool:
        if peer_id not in self.trusted_agents:
            return False
        try:
            queue = self._queues.get(peer_id)
            if queue is None:
                self.open_peer_queue(peer_id)
                queue = self._queues[peer_id]
            queue.put(data, block=True, timeout=timeout)
            self._stats["messages_sent"] += 1
            return True
        except Exception:
            self._stats["send_timeouts"] += 1
            return False

    def receive(self, timeout: float = 0.0) -> Optional[bytes]:
        # This is for a single queue - caller should use peer-specific
        # This is a simplified fallback; real use would need queue selection
        return None

    def get_statistics(self) -> Dict:
        return dict(self._stats)
