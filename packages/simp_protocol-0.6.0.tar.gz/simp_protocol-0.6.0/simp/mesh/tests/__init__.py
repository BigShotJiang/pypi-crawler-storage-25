"""
Tests for the Trading Signal Bus.
"""