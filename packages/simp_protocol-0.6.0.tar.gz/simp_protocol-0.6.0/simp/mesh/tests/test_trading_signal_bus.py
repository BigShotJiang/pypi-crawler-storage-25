"""
Tests for the Trading Signal Bus — the parasympathetic nervous system.
"""

import time
import threading
from simp.mesh.trading_signal_bus import (
    TradingSignalBus,
    get_signal_bus,
)


class TestTradingSignalBus:
    """Test suite for TradingSignalBus."""

    def test_two_subscribers_receive_signal(self):
        """Two subscribers receive a published signal."""
        bus = TradingSignalBus()
        received = []

        def make_callback(i):
            def cb(payload):
                received.append((i, payload))
            return cb

        bus.subscribe("test_signal", make_callback(0))
        bus.subscribe("test_signal", make_callback(1))

        bus.publish("test_signal", {"value": 42})

        assert len(received) == 2
        assert received[0][0] == 0
        assert received[0][1] == {"value": 42}
        assert received[1][0] == 1
        assert received[1][1] == {"value": 42}

    def test_signal_history_capped_at_10000(self):
        """Signal history is capped at 10000 records."""
        bus = TradingSignalBus(max_history=10000)
        signal_type = "capped_test"

        # Publish 15000 signals
        for i in range(15000):
            bus.publish(signal_type, {"index": i})

        # History should be capped at 10000 (actually at 5000 after the drop)
        # The cap logic drops to half when over max, so 15000 -> 7500
        # But we cap strictly at max_history records max
        assert len(bus.signal_history) <= 10000

        # First record should be from after the drop
        earliest = bus.signal_history[0]
        assert earliest["payload"]["index"] >= 7500

    def test_unsubscribe(self):
        """Subscribers can unsubscribe."""
        bus = TradingSignalBus()
        received = []

        def callback(payload):
            received.append(payload)

        bus.subscribe("unsub_test", callback)
        bus.publish("unsub_test", {"step": 1})
        assert len(received) == 1

        bus.unsubscribe("unsub_test", callback)
        bus.publish("unsub_test", {"step": 2})
        assert len(received) == 1  # no new message

    def test_get_recent_signals(self):
        """Get recent signals of a given type."""
        bus = TradingSignalBus()
        for i in range(250):
            bus.publish("recent_test", {"i": i})

        recent = bus.get_recent_signals("recent_test", n=10)
        assert len(recent) == 10
        # Last one should be the most recent
        assert recent[-1]["payload"]["i"] == 249

    def test_background_optimization_runs(self):
        """Background optimization loop runs without being asked."""
        bus = TradingSignalBus()
        # Give it a moment to run the first cycle
        time.sleep(1.5)

        # Should have emitted MESH_HEALTH signals
        health_signals = bus.get_recent_signals(TradingSignalBus.MESH_HEALTH, n=5)
        assert len(health_signals) >= 1
        assert health_signals[-1]["payload"]["optimization_running"] is True

    def test_analyze_execution_results_publishes_lesson(self):
        """Publishing execution results causes LESSON_SIGNAL to be emitted."""
        bus = TradingSignalBus()

        # Publish some fake execution results
        for i in range(10):
            bus.publish(
                TradingSignalBus.EXECUTION_RESULT,
                {
                    "result": {
                        "slippage_bps": 25.0,
                        "pnl_usd": 0.05,
                        "fees_usd": 0.10,
                        "venue": "coinbase",
                        "status": "executed",
                    }
                },
            )

        # Trigger optimization cycle manually
        bus._analyze_execution_results()

        lessons = bus.get_recent_signals(TradingSignalBus.LESSON_SIGNAL, n=5)
        assert len(lessons) >= 1

    def test_singleton_pattern(self):
        """get_signal_bus returns the same instance."""
        # Reset global
        import simp.mesh.trading_signal_bus as tsb
        tsb._signal_bus = None

        bus1 = get_signal_bus()
        bus2 = get_signal_bus()
        assert bus1 is bus2

    def test_publish_returns_quickly(self):
        """Publish should not block (background subscribers are fire-and-forget)."""
        bus = TradingSignalBus()
        slow_callbackRan = threading.Event()

        def slow_callback(payload):
            time.sleep(2)
            slow_callbackRan.set()

        bus.subscribe("slow_test", slow_callback)

        start = time.time()
        bus.publish("slow_test", {"urgent": True})
        elapsed = time.time() - start

        # Publish should return almost immediately
        assert elapsed < 0.5
        # But the callback still runs in background
        assert slow_callbackRan.wait(timeout=3)


class TestSignalTypes:
    """Verify all signal types are defined."""

    def test_signal_types_exist(self):
        bus = TradingSignalBus()
        assert bus.PRICE_SIGNAL == "price_signal"
        assert bus.ARB_OPPORTUNITY == "arb_opportunity"
        assert bus.BROKER_DECISION == "broker_decision"
        assert bus.EXECUTION_RESULT == "execution_result"
        assert bus.LESSON_SIGNAL == "lesson_signal"
        assert bus.THRESHOLD_UPDATE == "threshold_update"
        assert bus.VENUE_SCORE == "venue_score"
        assert bus.EXTERNAL_SIGNAL == "external_signal"
        assert bus.MESH_HEALTH == "mesh_health"