#!/usr/bin/env python3
"""
Test suite for ExperienceCollector + OutcomeTracker.
Run with: python3 -m pytest simp/mesh/tests/test_experience_collector.py -v
"""
import time
import threading

import pytest

from simp.mesh.experience_collector import (
    Experience,
    ExperienceCollector,
    Outcome,
    compute_reward,
    get_experience_collector,
)


class TestExperienceCollector:
    """Tests for ExperienceCollector."""

    def setup_method(self) -> None:
        """Create a fresh collector for each test (no singleton pollution)."""
        self.ec = ExperienceCollector(
            sqlite_path="/tmp/test_experience.db",
            ring_buffer_size=100,
            flush_interval=3600,   # disable auto-flush in tests
            batch_size=1000,
        )

    def teardown_method(self) -> None:
        self.ec.shutdown()
        import os, pathlib
        p = pathlib.Path("/tmp/test_experience.db")
        if p.exists():
            p.unlink()

    def test_record_and_retrieve(self) -> None:
        exp = Experience(
            query_id="q-test-001",
            agent_id="test-agent",
            intent_type="legal",
            model_key="legal",
            prompt="Analyze this SAFE agreement.",
            response_text="IRAC analysis complete.",
            outcome="success",
            reward_signal=1.0,
            latency_ms=1500.0,
            confidence=0.87,
            timestamp=time.time(),
            metadata={"contract_id": "SAFE-2024-001"},
        )
        qid = self.ec.record(exp)
        assert qid == "q-test-001"

        results = self.ec.get_experiences("legal")
        assert len(results) == 1
        assert results[0].query_id == "q-test-001"
        assert results[0].outcome == "success"

    def test_get_outcome_stats(self) -> None:
        # record several experiences
        for i in range(5):
            self.ec.record(Experience(
                query_id=f"q-stat-{i}",
                agent_id="test-agent",
                intent_type="threat",
                model_key="threat",
                prompt=f"Threat check {i}",
                response_text="clean" if i % 2 == 0 else "medium",
                outcome="success" if i % 2 == 0 else "failure",
                reward_signal=1.0 if i % 2 == 0 else -0.5,
                latency_ms=200.0 + i * 10,
                confidence=0.7 + i * 0.02,
                timestamp=time.time(),
                metadata={},
            ))

        stats = self.ec.get_outcome_stats("threat")
        assert stats["total_count"] == 5
        assert stats["success_count"] == 3
        assert stats["failure_count"] == 2
        assert 0.0 < stats["success_rate"] <= 1.0
        assert -1.0 <= stats["avg_reward"] <= 1.0

    def test_get_recent(self) -> None:
        for i in range(10):
            self.ec.record(Experience(
                query_id=f"q-recent-{i}",
                agent_id="test-agent",
                intent_type="trading",
                model_key="trading",
                prompt=f"Signal {i}",
                response_text="buy" if i % 3 == 0 else "hold",
                outcome="success",
                reward_signal=0.8,
                latency_ms=500.0,
                confidence=0.9,
                timestamp=time.time(),
                metadata={},
            ))
        recent = self.ec.get_recent(limit=3)
        assert len(recent) == 3
        # Most recent are last in the deque
        ids = [r.query_id for r in recent]
        assert "q-recent-7" in ids or "q-recent-8" in ids or "q-recent-9" in ids

    def test_ring_buffer_eviction(self) -> None:
        ec_small = ExperienceCollector(
            sqlite_path="/tmp/test_ring.db",
            ring_buffer_size=5,
            flush_interval=3600,
            batch_size=1000,
        )
        for i in range(10):
            ec_small.record(Experience(
                query_id=f"q-ring-{i}",
                agent_id="test",
                intent_type="legal",
                model_key="legal",
                prompt=f"p{i}",
                response_text="r",
                outcome="success",
                reward_signal=0.5,
                latency_ms=100.0,
                confidence=0.5,
                timestamp=time.time(),
                metadata={},
            ))
        # Ring buffer should cap at 5
        assert len(ec_small.get_experiences("legal")) == 5
        # Oldest entries should be evicted
        assert not any(e.query_id == "q-ring-0" for e in ec_small.get_experiences("legal"))
        ec_small.shutdown()
        import pathlib; pathlib.Path("/tmp/test_ring.db").unlink(missing_ok=True)

    def test_outcome_filter(self) -> None:
        for i in range(6):
            self.ec.record(Experience(
                query_id=f"q-filter-{i}",
                agent_id="test",
                intent_type="legal",
                model_key="legal",
                prompt=f"p{i}",
                response_text="r",
                outcome="success" if i < 4 else "failure",
                reward_signal=1.0 if i < 4 else -0.5,
                latency_ms=100.0,
                confidence=0.5,
                timestamp=time.time(),
                metadata={},
            ))
        all_exps = self.ec.get_experiences("legal")
        success_exps = self.ec.get_experiences("legal", outcome="success")
        failure_exps = self.ec.get_experiences("legal", outcome="failure")
        assert len(all_exps) == 6
        assert len(success_exps) == 4
        assert len(failure_exps) == 2

    def test_compute_reward(self) -> None:
        assert compute_reward("success") == 1.0
        assert compute_reward("failure") == -0.5
        assert compute_reward("escalated") == 0.0
        # contract signed bonus
        assert compute_reward("success", {"signed_contract": True}) == 2.0
        # threat_level boost
        assert compute_reward("success", {"threat_level": "critical"}) == 1.25
        # P&L delta
        assert compute_reward("success", {"P&L_delta": 5000}) == 1.0  # +0.25 capped


class TestExperienceCollectorSingleton:
    """Tests for the module-level singleton."""

    def test_singleton_returns_same_instance(self) -> None:
        ec1 = get_experience_collector()
        ec2 = get_experience_collector()
        assert ec1 is ec2


class TestComputeReward:
    """Tests for compute_reward helper."""

    def test_base_outcomes(self) -> None:
        assert compute_reward("success") == 1.0
        assert compute_reward("failure") == -0.5
        assert compute_reward("escalated") == 0.0

    def test_metadata_overrides(self) -> None:
        assert compute_reward("success", {"signed_contract": True}) == 2.0
        assert compute_reward("success", {"threat_level": "high"}) == 1.25
        assert compute_reward("failure", {"threat_level": "critical"}) == -0.25

    def test_pl_delta_capping(self) -> None:
        large_gain = compute_reward("success", {"P&L_delta": 100_000})
        assert large_gain <= 1.5
        large_loss = compute_reward("failure", {"P&L_delta": -100_000})
        assert large_loss >= -1.5