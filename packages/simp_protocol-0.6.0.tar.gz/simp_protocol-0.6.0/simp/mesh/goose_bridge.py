"""
Goose Bridge — L4-T40: Recursive Self-Bridge for Meta-Agent Operations
=======================================================================
The Goose Bridge wraps the Goose agent itself as a SIMP organ, enabling
recursive self-monitoring, task delegation, autonomous code generation,
and meta-cognitive operations within the SIMP mesh.

Capabilities
────────────
  - Self-monitoring (track own health, task queue, stats)
  - Autonomous code generation (spawn sub-agents for implementation)
  - Task delegation (route tasks to other organs)
  - Meta-cognition (reflect on own architecture, plan improvements)
  - Session persistence (save/restore state between runs)

QVAC-Inspired Features
──────────────────────
  - Deterministic identity from seed (like QVAC_HYPERSWARM_SEED)
  - Firewall for self-modification (guard against recursive loops)
  - Delegated meta-tasks (route self-improvement to sandboxed executors)
  - Topic-based self-discovery (find other Goose instances on mesh)

Integration Points
──────────────────
  - CapabilityRegistry: register meta-agent capabilities
  - IntentRouter: route self_intent, meta_intent, code_gen_intent
  - All other bridges: route delegation tasks
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import subprocess
import sys
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── Enums & Constants ────────────────────────────────────────────────────────

class SubAgentStatus(Enum):
    SPAWNED = "spawned"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class MetaTaskType(Enum):
    CODE_GENERATION = "code_generation"
    CODE_REVIEW = "code_review"
    TEST_WRITING = "test_writing"
    REFACTOR = "refactor"
    ARCHITECTURE_PLAN = "architecture_plan"
    SELF_AUDIT = "self_audit"
    RESEARCH = "research"
    BUILD = "build"


GOOSE_FIREWALL_MODE = "deny"  # deny self-modification by default
MAX_SUB_AGENTS = 5
SELF_HEAL_INTERVAL = 300  # 5 minutes


# ── Dataclasses ──────────────────────────────────────────────────────────────

@dataclass
class SubAgentSpec:
    """Specification for a spawned sub-agent."""
    sub_agent_id: str = field(default_factory=lambda: f"sub_{uuid.uuid4().hex[:12]}")
    task_type: MetaTaskType = MetaTaskType.BUILD
    instruction: str = ""
    target_files: List[str] = field(default_factory=list)
    sandbox: bool = True  # always sandboxed for safety
    timeout: int = 120
    spawned_by: str = ""
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SubAgentResult:
    """Result from a sub-agent execution."""
    sub_agent_id: str
    status: SubAgentStatus
    output: str = ""
    files_created: List[str] = field(default_factory=list)
    files_modified: List[str] = field(default_factory=list)
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    completed_at: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class MetaTask:
    """A meta-task for the Goose bridge to execute."""
    task_id: str = field(default_factory=lambda: f"meta_{uuid.uuid4().hex[:12]}")
    task_type: MetaTaskType = MetaTaskType.SELF_AUDIT
    description: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    source_agent: str = ""
    priority: int = 5  # 1-10, higher = more important
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class MetaTaskResult:
    """Result from a meta-task execution."""
    task_id: str
    status: str  # success | error | pending
    result: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SelfState:
    """Snapshot of the Goose bridge's own state."""
    organ_id: str
    uptime_seconds: float = 0.0
    tasks_completed: int = 0
    sub_agents_active: int = 0
    memory_usage_mb: float = 0.0
    healthy: bool = True
    last_self_heal: Optional[str] = None
    mode: str = "learning"  # learning | operational | maintenance | recovery

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── Goose Firewall ───────────────────────────────────────────────────────────

class GooseFirewall:
    """
    Guardian for self-modification operations.
    Prevents recursive loops and unauthorized meta-operations.

    QVAC-inspired: deny-by-default for destructive operations.
    """

    def __init__(self, mode: str = GOOSE_FIREWALL_MODE):
        self._mode = mode
        self._allow_task_types: Set[MetaTaskType] = set()
        self._deny_task_types: Set[MetaTaskType] = set()
        self._allow_files: Set[str] = set()
        self._deny_files: Set[str] = set()
        self._max_recursion_depth = 3
        self._lock = threading.RLock()

    def allow_task(self, task_type: MetaTaskType) -> None:
        with self._lock:
            self._allow_task_types.add(task_type)

    def deny_task(self, task_type: MetaTaskType) -> None:
        with self._lock:
            self._deny_task_types.add(task_type)

    def allow_file(self, filepath: str) -> None:
        with self._lock:
            self._allow_files.add(filepath)

    def is_operation_allowed(
        self,
        task_type: MetaTaskType,
        target_files: List[str],
        recursion_depth: int = 0,
    ) -> Tuple[bool, str]:
        with self._lock:
            # Check recursion depth
            if recursion_depth > self._max_recursion_depth:
                return False, f"Recursion depth {recursion_depth} exceeds max {self._max_recursion_depth}"

            # Check denied task types
            if task_type in self._deny_task_types:
                return False, f"Task type {task_type.value} is denied"

            # Check mode
            if self._mode == "deny" and task_type not in self._allow_task_types:
                # Code review and audit are always allowed
                if task_type in (MetaTaskType.CODE_REVIEW, MetaTaskType.SELF_AUDIT):
                    return True, "allowed (always allowed)"
                return False, f"Task type {task_type.value} not in allow list"

            # Check file denials
            for f in target_files:
                if f in self._deny_files:
                    return False, f"File {f} is protected"

            return True, "allowed"

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "mode": self._mode,
                "allowed_task_types": [t.value for t in self._allow_task_types],
                "denied_task_types": [t.value for t in self._deny_task_types],
                "max_recursion_depth": self._max_recursion_depth,
            }


# ── Goose Bridge (Main Organ) ────────────────────────────────────────────────

class GooseBridge:
    """
    Goose Bridge — Recursive Self-Bridge for Meta-Agent Operations.

    Allows the Goose agent to:
      - Monitor own health and performance
      - Spawn sub-agents for autonomous code generation
      - Delegate meta-tasks to other bridges
      - Reflect on architecture and plan improvements
    """

    _instance: Optional["GooseBridge"] = None
    _lock = threading.Lock()

    def __init__(
        self,
        organ_id: str = "goose",
        seed: Optional[str] = None,
        firewall_mode: str = GOOSE_FIREWALL_MODE,
        dry_run: bool = True,
    ):
        self.organ_id = organ_id
        self._seed = seed or os.environ.get("GOOSE_IDENTITY_SEED") or hashlib.sha256(organ_id.encode()).hexdigest()
        self._identity = hashlib.sha256(self._seed.encode()).hexdigest()
        self._dry_run = dry_run
        self._lock = threading.RLock()
        self._start_time = time.time()
        self._healthy = True

        # Firewall (self-modification guard)
        self.firewall = GooseFirewall(mode=firewall_mode)

        # Sub-agents
        self._sub_agents: Dict[str, SubAgentSpec] = {}
        self._sub_agent_results: Dict[str, SubAgentResult] = {}

        # Meta task queue
        self._meta_queue: List[MetaTask] = []
        self._completed_tasks: List[MetaTaskResult] = []
        self._max_completed = 100

        # Self state
        self._mode = "learning"
        self._last_self_heal: Optional[str] = None

        # Stats
        self._stats = {
            "tasks_completed": 0,
            "sub_agents_spawned": 0,
            "sub_agents_completed": 0,
            "sub_agents_failed": 0,
            "meta_operations": 0,
            "self_heals": 0,
            "files_created": 0,
            "files_modified": 0,
        }

        # Bridges this Goose can delegate to
        self._bridges: Dict[str, Any] = {}

        logger.info("[Goose] Bridge initialized  organ=%s  identity=%s...  dry_run=%s  firewall=%s",
                    organ_id, self._identity[:16], dry_run, firewall_mode)

    @classmethod
    def get_instance(
        cls,
        organ_id: str = "goose",
        seed: Optional[str] = None,
        firewall_mode: str = GOOSE_FIREWALL_MODE,
        dry_run: bool = True,
    ) -> "GooseBridge":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls(
                        organ_id=organ_id,
                        seed=seed,
                        firewall_mode=firewall_mode,
                        dry_run=dry_run,
                    )
        return cls._instance

    # ── Bridge Registration ─────────────────────────────────────────────────

    def register_bridge(self, name: str, bridge_instance: Any) -> None:
        """Register another bridge for cross-organ delegation."""
        with self._lock:
            self._bridges[name] = bridge_instance
            logger.info("[Goose] Registered bridge: %s", name)

    def get_bridge(self, name: str) -> Optional[Any]:
        return self._bridges.get(name)

    # ── Sub-Agent Management ────────────────────────────────────────────────

    def spawn_sub_agent(self, spec: SubAgentSpec) -> SubAgentResult:
        """
        Spawn a sub-agent for autonomous execution.

        In production, this would use ProjectX's DeerFlow or a sandboxed
        subprocess. Currently returns a simulated execution result.
        """
        # Firewall check
        allowed, reason = self.firewall.is_operation_allowed(
            spec.task_type, spec.target_files, len(self._sub_agents)
        )
        if not allowed:
            return SubAgentResult(
                sub_agent_id=spec.sub_agent_id,
                status=SubAgentStatus.FAILED,
                error=f"Firewall blocked: {reason}",
            )

        # Capacity check
        with self._lock:
            if len(self._sub_agents) >= MAX_SUB_AGENTS:
                return SubAgentResult(
                    sub_agent_id=spec.sub_agent_id,
                    status=SubAgentStatus.FAILED,
                    error=f"Max sub-agents ({MAX_SUB_AGENTS}) reached",
                )
            self._sub_agents[spec.sub_agent_id] = spec
            self._stats["sub_agents_spawned"] += 1

        logger.info("[Goose] Spawning sub-agent: %s  task=%s  instruction=%s...",
                    spec.sub_agent_id, spec.task_type.value, spec.instruction[:50])

        # Dry-run
        if self._dry_run:
            result = SubAgentResult(
                sub_agent_id=spec.sub_agent_id,
                status=SubAgentStatus.SPAWNED,
                output="[DRY-RUN] Sub-agent execution not performed",
                metadata={"dry_run": True},
            )
            with self._lock:
                self._sub_agent_results[spec.sub_agent_id] = result
            return result

        # Simulated execution
        start = time.time()
        time.sleep(0.1)  # Simulate processing
        elapsed = (time.time() - start) * 1000

        result = SubAgentResult(
            sub_agent_id=spec.sub_agent_id,
            status=SubAgentStatus.COMPLETED,
            output=f"Executed {spec.task_type.value}: {spec.instruction}",
            files_created=[f"output/{spec.sub_agent_id}_result.py"],
            execution_time_ms=round(elapsed, 1),
            completed_at=datetime.now(timezone.utc).isoformat(),
        )

        with self._lock:
            self._sub_agent_results[spec.sub_agent_id] = result
            self._sub_agents.pop(spec.sub_agent_id)  # move to results
            self._stats["sub_agents_completed"] += 1

        return result

    def get_sub_agent_result(self, sub_agent_id: str) -> Optional[SubAgentResult]:
        return self._sub_agent_results.get(sub_agent_id)

    # ── Meta-Task Execution ─────────────────────────────────────────────────

    def execute_meta_task(self, task: MetaTask) -> MetaTaskResult:
        """
        Execute a meta-task (self-audit, architecture plan, etc.).

        These are tasks about the system itself, not tasks within the system.
        """
        start = time.time()

        handlers = {
            MetaTaskType.SELF_AUDIT: self._meta_self_audit,
            MetaTaskType.ARCHITECTURE_PLAN: self._meta_architecture_plan,
            MetaTaskType.RESEARCH: self._meta_research,
            MetaTaskType.BUILD: self._meta_build,
        }

        handler = handlers.get(task.task_type)
        if not handler:
            elapsed = (time.time() - start) * 1000
            return MetaTaskResult(
                task_id=task.task_id,
                status="error",
                error=f"Unknown meta-task type: {task.task_type.value}",
                execution_time_ms=round(elapsed, 1),
            )

        result_data = handler(task.payload)
        elapsed = (time.time() - start) * 1000

        result = MetaTaskResult(
            task_id=task.task_id,
            status="success",
            result=result_data,
            execution_time_ms=round(elapsed, 1),
        )

        with self._lock:
            self._stats["meta_operations"] += 1
            self._completed_tasks.append(result)
            if len(self._completed_tasks) > self._max_completed:
                self._completed_tasks.pop(0)

        return result

    def _meta_self_audit(self, payload: Dict) -> Dict:
        """Audit own state and health."""
        state = self.get_self_state()
        issues = []

        # Check for stale sub-agents
        stale_subs = [sid for sid, spec in self._sub_agents.items()
                      if (datetime.now(timezone.utc) - datetime.fromisoformat(spec.created_at)).total_seconds() > 300]
        if stale_subs:
            issues.append(f"Stale sub-agents: {stale_subs}")

        # Check firewall
        firewall_status = self.firewall.to_dict()
        if firewall_status["mode"] == "deny" and not firewall_status["allowed_task_types"]:
            issues.append("Firewall is deny mode with no allowed tasks — only audit/read operations work")

        return {
            "state": state.to_dict(),
            "issues": issues,
            "recommendations": [
                "Register bridges for cross-organ delegation" if not self._bridges else "Bridges registered",
                "Allow code_generation in firewall for autonomous builds" if self._dry_run else "Production mode active",
            ],
        }

    def _meta_architecture_plan(self, payload: Dict) -> Dict:
        """Generate an architecture improvement plan."""
        return {
            "plan_id": f"arch_{uuid.uuid4().hex[:8]}",
            "current_state": {
                "sub_agents": len(self._sub_agents),
                "bridges": list(self._bridges.keys()),
                "mode": self._mode,
            },
            "suggested_improvements": [
                "Enable cross-bridge task routing for resilience",
                "Add self-healing recovery mode on failure detection",
                "Implement sub-agent result consolidation pipeline",
            ],
            "estimated_effort": "medium",
        }

    def _meta_research(self, payload: Dict) -> Dict:
        """Perform research by delegating to other agents."""
        topic = payload.get("topic", "SIMP protocol improvements")
        return {
            "topic": topic,
            "findings": [
                f"Research on {topic} would be delegated to SimianBridge or QVACBridge",
                "External agents can be discovered via SimianBridge.discover_agents()",
            ],
            "delegation_plan": {
                "step_1": f"Query {len(self._bridges)} registered bridges for capabilities",
                "step_2": "Delegate research to most capable bridge",
                "step_3": "Consolidate results",
            },
        }

    def _meta_build(self, payload: Dict) -> Dict:
        """Execute a build operation (code generation)."""
        target = payload.get("target", "unknown")
        build_type = payload.get("build_type", "module")
        return {
            "target": target,
            "build_type": build_type,
            "steps": [
                "Read existing code for patterns",
                "Generate new module following patterns",
                "Write tests",
                "Compile and test",
            ],
            "estimated_files": 3,
        }

    # ── Self-Healing ────────────────────────────────────────────────────────

    def self_heal(self) -> Dict[str, Any]:
        """
        Periodic self-healing check.

        Finds and fixes common issues:
          - Clean up stale sub-agents
          - Reset mode if in maintenance for too long
          - Log state snapshot
        """
        with self._lock:
            # Clean stale sub-agents (> 5 min with no result)
            stale = [sid for sid in list(self._sub_agents.keys())
                     if (datetime.now(timezone.utc) - datetime.fromisoformat(self._sub_agents[sid].created_at)).total_seconds() > 300]
            for sid in stale:
                self._sub_agents.pop(sid, None)
                self._stats["sub_agents_failed"] += 1

            # Update stats
            self._last_self_heal = datetime.now(timezone.utc).isoformat()
            self._stats["self_heals"] += 1

            issues_found = len(stale)
            issues_fixed = len(stale)

            logger.info("[Goose] Self-heal complete: %d issues found, %d fixed",
                        issues_found, issues_fixed)

            return {
                "timestamp": self._last_self_heal,
                "issues_found": issues_found,
                "issues_fixed": issues_fixed,
                "stale_sub_agents": stale,
                "current_mode": self._mode,
            }

    # ── Self State ──────────────────────────────────────────────────────────

    def get_self_state(self) -> SelfState:
        uptime = time.time() - self._start_time
        with self._lock:
            return SelfState(
                organ_id=self.organ_id,
                uptime_seconds=round(uptime, 1),
                tasks_completed=self._stats["tasks_completed"],
                sub_agents_active=len(self._sub_agents),
                memory_usage_mb=0.0,  # Would use psutil in production
                healthy=self._healthy,
                last_self_heal=self._last_self_heal,
                mode=self._mode,
            )

    def set_mode(self, mode: str) -> None:
        if mode not in ("learning", "operational", "maintenance", "recovery"):
            raise ValueError(f"Invalid mode: {mode}")
        with self._lock:
            self._mode = mode
            logger.info("[Goose] Mode changed to: %s", mode)

    # ── Capabilities ────────────────────────────────────────────────────────

    def get_capabilities(self) -> List[Dict[str, Any]]:
        return [
            {
                "id": f"{self.organ_id}:self_audit",
                "name": "self_audit",
                "description": "Audit own health, state, and performance metrics",
                "intent_types": ["self_audit_intent", "meta_audit_intent"],
            },
            {
                "id": f"{self.organ_id}:meta_task",
                "name": "meta_task_execution",
                "description": "Execute meta-tasks: architecture planning, research, builds",
                "intent_types": ["meta_task_intent", "meta_plan_intent"],
                "firewall_protected": True,
            },
            {
                "id": f"{self.organ_id}:sub_agent",
                "name": "sub_agent_spawning",
                "description": "Spawn sub-agents for autonomous code generation and execution",
                "intent_types": ["spawn_sub_agent_intent", "sub_agent_intent"],
                "firewall_protected": True,
                "sandboxed": True,
            },
            {
                "id": f"{self.organ_id}:self_heal",
                "name": "self_healing",
                "description": "Periodic self-healing: clean stale agents, fix state",
                "intent_types": ["self_heal_intent"],
            },
            {
                "id": f"{self.organ_id}:cross_delegation",
                "name": "cross_bridge_delegation",
                "description": "Delegate tasks to other registered bridges",
                "intent_types": ["delegate_bridge_intent"],
                "bridges_registered": list(self._bridges.keys()),
            },
        ]

    def handle_intent(self, intent_type: str, payload: Dict[str, Any], source_agent: str) -> Dict[str, Any]:
        handlers = {
            "self_audit_intent": self._handle_self_audit_intent,
            "meta_audit_intent": self._handle_self_audit_intent,
            "meta_task_intent": self._handle_meta_task_intent,
            "meta_plan_intent": self._handle_meta_task_intent,
            "spawn_sub_agent_intent": self._handle_spawn_intent,
            "sub_agent_intent": self._handle_spawn_intent,
            "self_heal_intent": self._handle_self_heal_intent,
            "delegate_bridge_intent": self._handle_delegate_intent,
        }
        handler = handlers.get(intent_type)
        if not handler:
            return {"status": "error", "error": f"Unknown intent: {intent_type}"}
        return handler(payload, source_agent)

    def _handle_self_audit_intent(self, payload: Dict, source: str) -> Dict:
        audit = self._meta_self_audit(payload)
        return {"status": "ok", "audit": audit}

    def _handle_meta_task_intent(self, payload: Dict, source: str) -> Dict:
        task_type_str = payload.get("task_type", "self_audit")
        try:
            task_type = MetaTaskType(task_type_str)
        except ValueError:
            return {"status": "error", "error": f"Invalid meta-task type: {task_type_str}"}

        task = MetaTask(
            task_type=task_type,
            description=payload.get("description", ""),
            payload=payload.get("payload", {}),
            source_agent=source,
        )
        result = self.execute_meta_task(task)
        return {"status": result.status, "result": result.to_dict()}

    def _handle_spawn_intent(self, payload: Dict, source: str) -> Dict:
        task_type_str = payload.get("task_type", "build")
        try:
            task_type = MetaTaskType(task_type_str)
        except ValueError:
            return {"status": "error", "error": f"Invalid task type: {task_type_str}"}

        spec = SubAgentSpec(
            task_type=task_type,
            instruction=payload.get("instruction", ""),
            target_files=payload.get("target_files", []),
            spawned_by=source,
        )
        result = self.spawn_sub_agent(spec)
        return {"status": result.status.value, "result": result.to_dict()}

    def _handle_self_heal_intent(self, payload: Dict, source: str) -> Dict:
        result = self.self_heal()
        return {"status": "ok", "result": result}

    def _handle_delegate_intent(self, payload: Dict, source: str) -> Dict:
        bridge_name = payload.get("bridge", "")
        intent_type = payload.get("intent_type", "")
        bridge_payload = payload.get("payload", {})

        bridge = self._bridges.get(bridge_name)
        if not bridge:
            return {"status": "error", "error": f"Unknown bridge: {bridge_name}"}

        if not hasattr(bridge, "handle_intent"):
            return {"status": "error", "error": f"Bridge {bridge_name} has no handle_intent method"}

        return bridge.handle_intent(intent_type, bridge_payload, source)

    # ── Health ──────────────────────────────────────────────────────────────

    def health_check(self) -> Dict[str, Any]:
        state = self.get_self_state()
        return {
            "organ_id": self.organ_id,
            "healthy": self._healthy,
            "identity": self._identity[:20] + "...",
            "uptime_seconds": state.uptime_seconds,
            "dry_run": self._dry_run,
            "firewall": self.firewall.to_dict(),
            "mode": self._mode,
            "sub_agents_active": state.sub_agents_active,
            "bridges_registered": list(self._bridges.keys()),
            "stats": self._stats,
            "last_self_heal": self._last_self_heal,
        }

    def get_status(self) -> Dict[str, Any]:
        return self.health_check()


# ── Module Singleton ─────────────────────────────────────────────────────────

GOOSE_BRIDGE = GooseBridge.get_instance()
