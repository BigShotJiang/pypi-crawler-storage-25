"""
Trust State Superposition — T54: Trust State Superposition

Models agent trust scores as probabilistic distributions until measured by
TrustScorer.score(). Before measurement, an agent exists in a superposition
of trust states derived from:
  - receipt_history (RECEIPT_WEIGHT=0.6)
  - payment_balance (PAYMENT_WEIGHT=0.4)
  - BRP delta adjustments (runtime nudges ±1.5)

The TrustScorer.score() call is the "quantum measurement" — it collapses the
probability distribution to a single [0.0–5.0] value.
TrustGraph.lock_entry() provides decoherence protection.

Pipeline:
    agent trust → probability distribution (unmeasured)
        → TrustScorer.score(agent_id) → COLLAPSE → single [0.0–5.0]
        → effective_score stored
        → if locked → decoherence protected
"""

from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ── Enums ───────────────────────────────────────────────────────────────────

class TrustCoherence(str, Enum):
    """Coherence state of a trust superposition."""
    COHERENT = "coherent"      # Agent exists in superposition of trust states
    COLLAPSED = "collapsed"    # Trust score has been measured
    LOCKED = "locked"         # Collapsed and decoherence-protected via lock_entry()
    DECOHERENT = "decoherent"  # Decoherence has occurred (score polluted by noise)


class DecoherenceSource(str, Enum):
    """What caused decoherence (score pollution)."""
    NONE = "none"
    BRP_ADJUSTMENT = "brp_adjustment"
    MANUAL_OVERRIDE = "manual_override"
    EXTERNAL_NOISE = "external_noise"


# ── Probability Distribution ─────────────────────────────────────────────────

@dataclass
class TrustDistribution:
    """
    Probability distribution over trust scores for an unmeasured agent.

    Modeled as a mixture of Gaussians:
      - Base distribution: N(mean, std) reflecting historical performance
      - Payment tail: skewed toward higher trust if payment history is good
      - BRP nudge: uniform perturbation of ±1.5 during BRP evaluation
    """
    agent_id: str
    # Historical base (from receipt history)
    base_mean: float = 2.5   # start neutral
    base_std: float = 1.0    # uncertainty
    # Payment influence
    payment_weight: float = 0.0  # accumulated from payment history
    payment_mean_shift: float = 0.0  # shift from good/bad payment history
    # BRP nudge
    brp_nudge: float = 0.0   # last BRP delta applied
    # Metadata
    coherence: TrustCoherence = TrustCoherence.COHERENT
    collapsed_score: Optional[float] = None
    collapsed_at: Optional[str] = None
    measurement_count: int = 0  # how many times scored
    entropy: float = 1.0  # initial max entropy (uniform)
    decoherence: DecoherenceSource = DecoherenceSource.NONE

    @property
    def mean(self) -> float:
        """Expected mean of the distribution."""
        return self.base_mean + self.payment_mean_shift + self.brp_nudge

    def sample(self) -> float:
        """
        Monte Carlo sample from the distribution.
        Returns a trust score draw without collapsing.
        """
        raw = random.gauss(self.mean, self.base_std)
        return max(0.0, min(5.0, raw))  # clamp to [0, 5]

    def entropy_bits(self) -> float:
        """
        Information-theoretic entropy of the distribution.
        High entropy = high uncertainty (superposition).
        Low entropy = collapsed state.
        """
        if self.coherence == TrustCoherence.COLLAPSED:
            return 0.0
        if self.coherence == TrustCoherence.LOCKED:
            return 0.0
        # Entropy decreases as measurement_count grows
        return max(0.0, 1.0 - (self.measurement_count * 0.1))

    def apply_brp_nudge(self, delta: float) -> None:
        """Apply a BRP delta adjustment — causes decoherence."""
        self.brp_nudge += delta
        if self.coherence == TrustCoherence.COLLAPSED:
            self.coherence = TrustCoherence.DECOHERENT
            self.decoherence = DecoherenceSource.BRP_ADJUSTMENT
        logger.debug(
            f"BRP nudge {delta:+.2f} on {self.agent_id} → "
            f"coherence={self.coherence.value}, nudge_total={self.brp_nudge:.2f}"
        )


# ── Trust Superposition Manager ──────────────────────────────────────────────

class TrustSuperpositionManager:
    """
    Manages trust score superpositions for all agents.

    Before scoring: agent exists in TrustDistribution (coherent superposition)
    On score() call: distribution is "measured" → collapsed to single value
    After lock_entry(): decoherence protection → score frozen
    """

    def __init__(self):
        self._distributions: Dict[str, TrustDistribution] = {}
        self._collapsed: Dict[str, float] = {}  # agent_id → collapsed score
        self._locked: Dict[str, float] = {}     # agent_id → locked score
        self._lock = __import__("threading").RLock()
        self.logger = logging.getLogger("trust.superposition")

    # ── distribution management ──────────────────────────────────────────────

    def get_distribution(self, agent_id: str) -> TrustDistribution:
        """Get or create the trust distribution for an agent."""
        with self._lock:
            if agent_id not in self._distributions:
                self._distributions[agent_id] = TrustDistribution(agent_id=agent_id)
            return self._distributions[agent_id]

    def initialize_from_profile(
        self,
        agent_id: str,
        receipt_rate: float = 0.5,
        payment_rate: float = 0.5,
    ) -> TrustDistribution:
        """
        Initialize distribution from a trust profile.
        
        Args:
            agent_id: agent identifier
            receipt_rate: fraction of messages successfully delivered [0–1]
            payment_rate: fraction of payments successfully settled [0–1]
        """
        with self._lock:
            # base_mean: weighted combo of receipt and payment rates
            base_mean = 2.5 + (receipt_rate - 0.5) * 3.0 + (payment_rate - 0.5) * 2.0
            base_mean = max(0.0, min(5.0, base_mean))

            # Payment shift: good payment history → higher mean
            payment_shift = (payment_rate - 0.5) * 2.0

            # base_std: new agents have higher uncertainty
            base_std = max(0.5, 2.0 - receipt_rate * 1.5)

            dist = TrustDistribution(
                agent_id=agent_id,
                base_mean=base_mean,
                base_std=base_std,
                payment_weight=payment_rate,
                payment_mean_shift=payment_shift,
            )
            self._distributions[agent_id] = dist
            return dist

    def apply_brp_delta(self, agent_id: str, delta: float) -> None:
        """Apply a BRP delta adjustment to an agent's distribution."""
        dist = self.get_distribution(agent_id)
        dist.apply_brp_nudge(delta)

    # ── measurement / collapse ───────────────────────────────────────────────

    def measure(self, agent_id: str) -> float:
        """
        "Measure" an agent's trust score — the quantum measurement.

        Returns the collapsed trust score [0.0–5.0].
        Updates distribution coherence to COLLAPSED.
        Once measured, subsequent calls return the same collapsed value
        (the "collapsed state" is stable — like wave function collapse).
        """
        with self._lock:
            dist = self.get_distribution(agent_id)

            # Locked agents return the frozen score
            if agent_id in self._locked:
                return self._locked[agent_id]

            # Already collapsed? Return stored value (quantum measurement is stable)
            if agent_id in self._collapsed:
                return self._collapsed[agent_id]

            # Monte Carlo sample → collapsed value
            score = dist.sample()
            dist.collapsed_score = score
            dist.collapsed_at = datetime.now(timezone.utc).isoformat()
            dist.coherence = TrustCoherence.COLLAPSED
            dist.measurement_count += 1
            dist.entropy = 0.0

            self._collapsed[agent_id] = score
            self.logger.debug(
                f"MEASURED {agent_id}: {dist.base_mean:.2f}±{dist.base_std:.2f} "
                f"→ {score:.2f} (measurement #{dist.measurement_count})"
            )
            return score

    def get_effective_score(self, agent_id: str) -> float:
        """
        Public API: get the effective trust score for an agent.
        This is what TrustGraph.get_effective_score() calls.
        """
        with self._lock:
            # Return locked score if available
            if agent_id in self._locked:
                return self._locked[agent_id]
            # Return collapsed score if measured
            if agent_id in self._collapsed:
                return self._collapsed[agent_id]
            # Otherwise measure now
            return self.measure(agent_id)

    def lock_score(self, agent_id: str) -> float:
        """
        Lock the current score — decoherence protection.
        Once locked, the score cannot change (it is "frozen").
        This models TrustGraph.lock_entry() behavior.
        """
        with self._lock:
            score = self.get_effective_score(agent_id)
            self._locked[agent_id] = score
            dist = self.get_distribution(agent_id)
            dist.coherence = TrustCoherence.LOCKED
            self.logger.info(f"LOCKED {agent_id} at score {score:.2f}")
            return score

    def is_locked(self, agent_id: str) -> bool:
        with self._lock:
            return agent_id in self._locked

    # ── state inspection ────────────────────────────────────────────────────

    def get_state(self, agent_id: str) -> Dict:
        """Return full superposition state for an agent."""
        with self._lock:
            dist = self.get_distribution(agent_id)
            return {
                "agent_id": agent_id,
                "coherence": dist.coherence.value,
                "mean": dist.mean,
                "base_mean": dist.base_mean,
                "base_std": dist.base_std,
                "brp_nudge": dist.brp_nudge,
                "payment_shift": dist.payment_mean_shift,
                "entropy": dist.entropy_bits(),
                "collapsed_score": dist.collapsed_score,
                "collapsed_at": dist.collapsed_at,
                "locked_score": self._locked.get(agent_id),
                "measurement_count": dist.measurement_count,
                "decoherence": dist.decoherence.value,
            }

    def get_all_states(self) -> List[Dict]:
        """Return superposition states for all tracked agents."""
        with self._lock:
            return [self.get_state(aid) for aid in self._distributions]


# ── Singleton ────────────────────────────────────────────────────────────────

_TSM: Optional[TrustSuperpositionManager] = None


def get_trust_superposition_manager() -> TrustSuperpositionManager:
    global _TSM
    if _TSM is None:
        _TSM = TrustSuperpositionManager()
    return _TSM
