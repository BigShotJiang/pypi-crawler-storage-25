"""
HTTPS Agent Identity Bridge — T59: Cross-Mesh Federation

Enables agents to join remote SIMP mesh instances over WSS (WebSocket Secure).

Features:
- HTTPS agent identity derived from RSA keypair (MeshSecurityLayer)
- Auto-generated agent.json at /a2a/agents/{agent_id}/agent.json
- Remote agent join over WSS
- JWT derived from mesh packet RSA signatures
- TrustGraph verified before admission
- Rate limiting per remote mesh instance

Agent card (agent.json) format:
{
  "agent_id": "alice",
  "public_key_pem": "-----BEGIN PUBLIC KEY-----...",
  "capabilities": ["research", "trading", "quantum"],
  "endpoint": "wss://broker:5556/ws",
  "mesh_instance": "prod-mesh-1",
  "version": "1.0",
  "registered_at": "2026-04-26T..."
}
"""

from __future__ import annotations

import collections
import hashlib
import json
import logging
import threading
import time
import uuid
import websockets
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, TYPE_CHECKING

if TYPE_CHECKING:
    from simp.mesh.packet import MeshPacket

logger = logging.getLogger(__name__)

AGENT_CARD_VERSION = "1.0"


@dataclass
class AgentCard:
    """Agent identity card — the HTTPS identity for cross-mesh federation."""
    agent_id: str
    public_key_pem: str
    capabilities: List[str]
    endpoint: str            # WebSocket endpoint for this agent
    mesh_instance: str         # Which mesh instance this agent belongs to
    version: str = AGENT_CARD_VERSION
    registered_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    last_seen: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    trust_score: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    @classmethod
    def from_dict(cls, d: Dict) -> "AgentCard":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    @classmethod
    def from_json(cls, s: str) -> "AgentCard":
        return cls.from_dict(json.loads(s))

    def fingerprint(self) -> str:
        """SHA-256 fingerprint of the public key — used for quick ID verification."""
        return hashlib.sha256(self.public_key_pem.encode()).hexdigest()[:16]


@dataclass
class RemoteMeshPeer:
    """A remote mesh instance that we are federated with."""
    peer_id: str              # unique ID for this peer
    peer_endpoint: str        # WSS endpoint of the remote mesh
    agent_cards: Dict[str, AgentCard]  # agent_id → AgentCard
    connected: bool = False
    last_heartbeat: float = field(default_factory=time.time)
    messages_sent: int = 0
    messages_recv: int = 0
    rate_limit_rpm: int = 60  # default 60 req/min

    def is_alive(self, timeout: float = 60.0) -> bool:
        return (time.time() - self.last_heartbeat) < timeout


class HTTPSAgentIdentity:
    """
    Manages HTTPS agent identity and cross-mesh federation.

    Each agent has:
    - RSA keypair (from MeshSecurityLayer)
    - AgentCard with public_key_pem + capabilities
    - agent.json endpoint at /a2a/agents/{agent_id}/agent.json
    - JWT tokens derived from RSA-signed mesh packet signatures

    Remote agents join over WSS after TrustGraph verification.
    """

    def __init__(self, agent_id: str, endpoint: str = "ws://localhost:5556"):
        self.agent_id = agent_id
        self.endpoint = endpoint
        self.logger = logging.getLogger(f"https_bridge.{agent_id}")

        self._security = None  # lazy load
        self._card: Optional[AgentCard] = None
        self._remote_peers: Dict[str, RemoteMeshPeer] = {}
        self._local_cards: Dict[str, AgentCard] = {}  # agent_id → local AgentCard
        self._ws_connections: Dict[str, websocket.WebSocket] = {}
        self._lock = threading.RLock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Rate limiting: peer_endpoint → deque of request timestamps (sliding window)
        self._rate_limits: Dict[str, collections.deque] = {}

        self._build_local_card()

    # ── security layer lazy load ──────────────────────────────────────────────

    def _get_security(self):
        if self._security is None:
            try:
                from simp.mesh.security import get_mesh_security_layer
                self._security = get_mesh_security_layer(self.agent_id)
            except Exception as exc:
                self.logger.debug(f"MeshSecurityLayer unavailable: {exc}")
                self._security = None
        return self._security

    # ── agent card ───────────────────────────────────────────────────────────

    def _build_local_card(self) -> AgentCard:
        """Build this agent's AgentCard from RSA public key."""
        sec = self._get_security()
        pub_key_pem = ""
        if sec and hasattr(sec, "get_public_key_pem"):
            try:
                pub_key_pem = sec.get_public_key_pem()
            except Exception:
                pass

        if not pub_key_pem:
            pub_key_pem = f"UNSIGNED:{self.agent_id}"

        self._card = AgentCard(
            agent_id=self.agent_id,
            public_key_pem=pub_key_pem,
            capabilities=["intent_routing", "mesh_broadcast"],
            endpoint=self.endpoint,
            mesh_instance="local",
        )
        self._local_cards[self.agent_id] = self._card
        return self._card

    def get_agent_card(self) -> AgentCard:
        """Get this agent's AgentCard."""
        return self._card

    def get_agent_card_json(self) -> str:
        """Get this agent's AgentCard as JSON (for /a2a/agents/{id}/agent.json)."""
        return self._card.to_json()

    def register_local_agent(self, agent_id: str, card: AgentCard) -> None:
        """Register a local agent's card (e.g., from broker)."""
        with self._lock:
            self._local_cards[agent_id] = card
        self.logger.debug(f"Registered local agent card: {agent_id}")

    def get_local_card(self, agent_id: str) -> Optional[AgentCard]:
        return self._local_cards.get(agent_id)

    def get_all_local_cards(self) -> List[AgentCard]:
        return list(self._local_cards.values())

    # ── JWT from RSA signature ────────────────────────────────────────────────

    def derive_jwt(self, packet_id: str, audience: str) -> str:
        """
        Derive a short-lived JWT-style token from an RSA signature.
        This is not a full JWT — it's a mesh-native token derived from
        RSA-signed mesh packet signatures, suitable for cross-mesh auth.
        """
        sec = self._get_security()
        if sec is None:
            return f"JWT_MISSING_SECURITY:{packet_id}:{audience}"

        try:
            import base64
            msg = f"{self.agent_id}:{packet_id}:{audience}:{int(time.time())}"
            sig = sec.sign_message(msg.encode())
            sig_b64 = base64.b64encode(sig).decode()
            # Minimal JWT-like structure
            header = base64.b64encode(b'{"alg":"RS256","typ":"JWT"}').decode().rstrip('=')
            payload = base64.b64encode(msg.encode()).decode().rstrip('=')
            return f"{header}.{payload}.{sig_b64[:64]}"
        except Exception as exc:
            self.logger.debug(f"Could not derive JWT: {exc}")
            return f"JWT_ERROR:{exc}:{packet_id}"

    def verify_jwt(self, token: str, expected_audience: str) -> Optional[str]:
        """Verify a JWT-like token and return the agent_id, or None if invalid."""
        try:
            import base64
            parts = token.split(".")
            if len(parts) != 3:
                return None
            if parts[0] == "JWT_MISSING_SECURITY" or parts[0] == "JWT_ERROR":
                return None
            header_b64 = parts[0] + "=="
            payload_b64 = parts[1] + "=="
            header = json.loads(base64.b64decode(header_b64))
            payload = base64.b64decode(payload_b64).decode()
            fields = payload.split(":")
            if len(fields) >= 4:
                agent_id = fields[0]
                audience = fields[2]
                if audience == expected_audience:
                    return agent_id
        except Exception as exc:
            self.logger.debug(f"JWT verify failed: {exc}")
        return None

    # ── remote peers ────────────────────────────────────────────────────────

    def add_remote_peer(self, peer_endpoint: str, initial_cards: Optional[Dict[str, AgentCard]] = None) -> RemoteMeshPeer:
        """Connect to a remote mesh instance."""
        with self._lock:
            if peer_endpoint in self._remote_peers:
                return self._remote_peers[peer_endpoint]

            peer = RemoteMeshPeer(
                peer_id=str(uuid.uuid4())[:12],
                peer_endpoint=peer_endpoint,
                agent_cards=initial_cards or {},
            )
            self._remote_peers[peer_endpoint] = peer
            self.logger.info(f"Added remote peer: {peer_endpoint}")
            return peer

    def get_remote_peer(self, peer_endpoint: str) -> Optional[RemoteMeshPeer]:
        return self._remote_peers.get(peer_endpoint)

    def get_all_remote_peers(self) -> List[RemoteMeshPeer]:
        return list(self._remote_peers.values())

    # ── rate limiting ───────────────────────────────────────────────────────

    def check_rate_limit(self, peer_endpoint: str, rpm: int = 60) -> bool:
        """Check if a peer is within rate limits using a sliding window. Returns True if allowed."""
        now = time.time()
        window_seconds = 60.0
        with self._lock:
            if peer_endpoint not in self._rate_limits:
                self._rate_limits[peer_endpoint] = collections.deque(maxlen=rpm + 10)
            timestamps = self._rate_limits[peer_endpoint]

            # Evict timestamps outside the sliding window
            while timestamps and now - timestamps[0] >= window_seconds:
                timestamps.popleft()

            if len(timestamps) >= rpm:
                return False

            timestamps.append(now)
            return True

    # ── trust verification ───────────────────────────────────────────────────

    def verify_trust_for_federation(self, agent_id: str, min_trust: float = 3.0) -> bool:
        """Verify an agent meets the trust threshold for cross-mesh federation."""
        try:
            from simp.mesh.trust_scorer import get_trust_scorer
            scorer = get_trust_scorer()
            score = scorer.score(agent_id)
            return score.trust_score >= min_trust
        except Exception as exc:
            self.logger.debug(f"Trust verification failed: {exc}")
            return False

    # ── lifecycle ───────────────────────────────────────────────────────────

    def start(self) -> None:
        """Start the HTTPS bridge — register agent card with local broker."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._heartbeat_loop, daemon=True,
                                      name=f"https-bridge-{self.agent_id}")
        self._thread.start()
        self.logger.info(f"HTTPSAgentIdentity started for {self.agent_id}")

    def stop(self) -> None:
        self._running = False
        for ws in list(self._ws_connections.values()):
            try:
                ws.close()
            except Exception:
                pass
        self._ws_connections.clear()

    def _heartbeat_loop(self) -> None:
        while self._running:
            try:
                for peer in self._remote_peers.values():
                    peer.last_heartbeat = time.time()
                time.sleep(10)
            except Exception as exc:
                self.logger.debug(f"Heartbeat loop: {exc}")

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "agent_id": self.agent_id,
                "local_cards": len(self._local_cards),
                "remote_peers": len(self._remote_peers),
                "connected_peers": sum(1 for p in self._remote_peers.values() if p.connected),
                "rate_limits": {k: len(v) for k, v in self._rate_limits.items()},
            }


# ── Singleton ────────────────────────────────────────────────────────────────

_BRIDGES: Dict[str, HTTPSAgentIdentity] = {}


def get_https_bridge(agent_id: str, endpoint: str = "ws://localhost:5556") -> HTTPSAgentIdentity:
    if agent_id not in _BRIDGES:
        _BRIDGES[agent_id] = HTTPSAgentIdentity(agent_id, endpoint)
    return _BRIDGES[agent_id]
