"""
SIMP Mesh Topology Optimization — T30-9

Track latency between every agent pair, build latency matrix,
run MST or nearest-neighbor clustering, rebalance routing:
  - High-frequency agent pairs placed in same broker cluster
  - Recalculate every 5 minutes

Files: simp/mesh/topology.py
"""

from __future__ import annotations

import json
import logging
import math
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

logger = logging.getLogger("SIMP.Topology")


# ---------------------------------------------------------------------------
# Latency Matrix Entry
# ---------------------------------------------------------------------------


@dataclass
class LatencyEntry:
    """Latency measurement between two agents."""
    src_agent_id: str
    dst_agent_id: str
    rtt_ms: float  # Round-trip time in milliseconds
    samples: int = 1  # Number of samples averaged
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AgentNode:
    """Node in the topology graph."""
    agent_id: str
    cluster_id: Optional[str] = None
    peer_ids: Set[str] = field(default_factory=set)
    avg_latency_ms: float = 0.0
    status: str = "unknown"
    last_seen: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


# ---------------------------------------------------------------------------
# Topology Graph
# ---------------------------------------------------------------------------


class TopologyGraph:
    """
    Graph representation of the agent mesh topology.

    Nodes = agents
    Edges = latency measurements with sample counts
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._nodes: Dict[str, AgentNode] = {}
        self._edges: Dict[Tuple[str, str], LatencyEntry] = {}  # (a,b) sorted -> entry

    def add_node(self, agent_id: str) -> AgentNode:
        """Add or update a node."""
        with self._lock:
            if agent_id not in self._nodes:
                self._nodes[agent_id] = AgentNode(agent_id=agent_id)
            return self._nodes[agent_id]

    def add_edge(self, src: str, dst: str, rtt_ms: float) -> None:
        """Add or update a latency measurement."""
        with self._lock:
            # Ensure nodes exist
            self.add_node(src)
            self.add_node(dst)

            # Store sorted tuple key for undirected edge
            key = tuple(sorted([src, dst]))
            existing = self._edges.get(key)

            if existing:
                # Exponential moving average
                alpha = 0.3
                new_samples = existing.samples + 1
                new_rtt = alpha * rtt_ms + (1 - alpha) * existing.rtt_ms
                existing.rtt_ms = new_rtt
                existing.samples = new_samples
                existing.timestamp = datetime.now(timezone.utc).isoformat()
            else:
                self._edges[key] = LatencyEntry(
                    src_agent_id=src,
                    dst_agent_id=dst,
                    rtt_ms=rtt_ms,
                )

            # Update peer sets
            self._nodes[src].peer_ids.add(dst)
            self._nodes[dst].peer_ids.add(src)

    def get_edge(self, a: str, b: str) -> Optional[LatencyEntry]:
        """Get latency between two agents."""
        key = tuple(sorted([a, b]))
        return self._edges.get(key)

    def get_latency(self, a: str, b: str) -> Optional[float]:
        """Get current latency estimate between two agents."""
        entry = self.get_edge(a, b)
        return entry.rtt_ms if entry else None

    def get_node(self, agent_id: str) -> Optional[AgentNode]:
        return self._nodes.get(agent_id)

    def get_all_nodes(self) -> List[AgentNode]:
        with self._lock:
            return list(self._nodes.values())

    def get_all_edges(self) -> List[LatencyEntry]:
        with self._lock:
            return list(self._edges.values())

    def get_neighbors(self, agent_id: str) -> List[Tuple[str, float]]:
        """Get neighbor agents with their latencies."""
        node = self._nodes.get(agent_id)
        if not node:
            return []
        neighbors = []
        for peer_id in node.peer_ids:
            entry = self.get_edge(agent_id, peer_id)
            if entry:
                neighbors.append((peer_id, entry.rtt_ms))
        return sorted(neighbors, key=lambda x: x[1])

    def get_cluster(self, agent_id: str) -> Optional[str]:
        """Get the cluster ID for an agent."""
        node = self._nodes.get(agent_id)
        return node.cluster_id if node else None

    def set_cluster(self, agent_id: str, cluster_id: str) -> None:
        """Assign agent to a cluster."""
        node = self.add_node(agent_id)
        node.cluster_id = cluster_id

    def get_agents_in_cluster(self, cluster_id: str) -> List[str]:
        """Get all agents in a cluster."""
        with self._lock:
            return [
                node.agent_id
                for node in self._nodes.values()
                if node.cluster_id == cluster_id
            ]

    def num_nodes(self) -> int:
        return len(self._nodes)

    def num_edges(self) -> int:
        return len(self._edges)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize graph for debugging."""
        with self._lock:
            return {
                "nodes": {
                    aid: {
                        "cluster_id": n.cluster_id,
                        "peer_ids": list(n.peer_ids),
                        "avg_latency_ms": n.avg_latency_ms,
                        "status": n.status,
                    }
                    for aid, n in self._nodes.items()
                },
                "edges": [
                    {
                        "src": e.src_agent_id,
                        "dst": e.dst_agent_id,
                        "rtt_ms": e.rtt_ms,
                        "samples": e.samples,
                    }
                    for e in self._edges.values()
                ],
            }


# ---------------------------------------------------------------------------
# MST-based Topology Optimization
# ---------------------------------------------------------------------------


class TopologyOptimizer:
    """
    Computes optimal mesh topology using Minimum Spanning Tree (MST).

    Algorithm:
      1. Build complete graph with latency weights from measurements
      2. Compute MST using Prim's algorithm
      3. Run nearest-neighbor clustering on the MST
      4. Assign cluster IDs to agents

    Rebalancing suggestions are output as a list of (src, dst, new_route) tuples.
    """

    def __init__(self, graph: TopologyGraph):
        self.graph = graph
        self._lock = threading.RLock()

    def _prim_mst(self, nodes: List[str]) -> List[Tuple[str, str]]:
        """
        Compute MST using Prim's algorithm.

        Returns:
            List of (u, v) edges in the MST
        """
        if not nodes:
            return []
        if len(nodes) == 1:
            return []

        in_mst = {nodes[0]}
        mst_edges = []
        candidates = []  # (latency, u, v)

        def add_candidates(u: str) -> None:
            for v in nodes:
                if v in in_mst:
                    continue
                lat = self.graph.get_latency(u, v)
                if lat is not None:
                    candidates.append((lat, u, v))

        add_candidates(nodes[0])

        while candidates and len(in_mst) < len(nodes):
            candidates.sort()
            lat, u, v = candidates.pop(0)

            if v in in_mst:
                continue

            in_mst.add(v)
            mst_edges.append((u, v))
            add_candidates(v)

        return mst_edges

    def compute_mst(self) -> List[Tuple[str, str]]:
        """Compute MST of the topology graph."""
        with self._lock:
            nodes = list(self.graph.get_all_nodes())
            if not nodes:
                return []
            return self._prim_mst([n.agent_id for n in nodes])

    def cluster_nearest_neighbor(self, n_clusters: int = 4) -> Dict[str, str]:
        """
        Assign agents to clusters using nearest-neighbor clustering.

        Args:
            n_clusters: Target number of clusters

        Returns:
            Dict of agent_id -> cluster_id
        """
        with self._lock:
            nodes = list(self.graph.get_all_nodes())
            if not nodes:
                return {}

            # Sort nodes by average latency to their peers
            sorted_nodes = sorted(
                nodes,
                key=lambda n: sum(
                    self.graph.get_latency(n.agent_id, p) or 0
                    for p in n.peer_ids
                ) / max(len(n.peer_ids), 1)
            )

            # Nearest-neighbor assignment
            cluster_id = 0
            assignments = {}
            unassigned = set(n.agent_id for n in sorted_nodes)

            while unassigned and cluster_id < n_clusters:
                # Start new cluster with the "center-most" unassigned node
                start = sorted_nodes[0]
                if start.agent_id not in unassigned:
                    break

                cluster_members = [start.agent_id]
                unassigned.remove(start.agent_id)
                assignments[start.agent_id] = f"cluster_{cluster_id}"

                # Grow cluster by nearest-neighbor
                while unassigned:
                    nearest = None
                    nearest_lat = float("inf")

                    for member in cluster_members:
                        for peer_id in unassigned:
                            lat = self.graph.get_latency(member, peer_id)
                            if lat is not None and lat < nearest_lat:
                                nearest_lat = lat
                                nearest = peer_id

                    if nearest is None:
                        break

                    cluster_members.append(nearest)
                    unassigned.remove(nearest)
                    assignments[nearest] = f"cluster_{cluster_id}"

                cluster_id += 1

            # Remaining unassigned nodes get last cluster
            for agent_id in unassigned:
                assignments[agent_id] = f"cluster_{cluster_id - 1}"

            return assignments

    def compute_rebalance_suggestions(
        self,
        clusters: Dict[str, str],
    ) -> List[Tuple[str, str, str]]:
        """
        Compute routing rebalance suggestions based on clusters.

        Returns:
            List of (src_agent, dst_agent, new_route) suggesting
            which agent pairs should be routed together.
        """
        suggestions = []

        # Group agents by cluster
        cluster_agents: Dict[str, List[str]] = defaultdict(list)
        for agent_id, cluster_id in clusters.items():
            cluster_agents[cluster_id].append(agent_id)

        # For each cluster, suggest local routing for high-frequency pairs
        for cluster_id, agents in cluster_agents.items():
            for i, a in enumerate(agents):
                for b in agents[i + 1:]:
                    lat = self.graph.get_latency(a, b)
                    if lat is not None:
                        suggestions.append((a, b, f"local:{cluster_id}"))

        return sorted(suggestions, key=lambda x: x[2])


# ---------------------------------------------------------------------------
# Topology Manager
# ---------------------------------------------------------------------------


class TopologyManager:
    """
    Orchestrates topology discovery, measurement, and optimization.

    Responsibilities:
      - Ping all agent pairs periodically to measure latency
      - Maintain latency matrix
      - Run topology optimization every 5 minutes
      - Expose topology state for routing decisions

    Usage:
      manager = TopologyManager(agent_id="alpha-goose")
      manager.start()

      # Get suggested route
      route = manager.get_route("alpha-goose", "beta-goose")
    """

    PING_INTERVAL_SEC = 30.0  # Ping frequency
    OPTIMIZE_INTERVAL_SEC = 300.0  # Topology recalculation frequency

    def __init__(
        self,
        agent_id: str,
        mesh_bus=None,
        gossip_protocol=None,
    ):
        """
        Initialize TopologyManager.

        Args:
            agent_id: This agent's ID
            mesh_bus: MeshBus instance for sending pings
            gossip_protocol: GossipProtocol for sharing latency data
        """
        self.agent_id = agent_id
        self.mesh_bus = mesh_bus
        self.gossip_protocol = gossip_protocol

        self._lock = threading.RLock()
        self._running = False
        self._shutdown_event = threading.Event()

        self._graph = TopologyGraph()
        self._optimizer = TopologyOptimizer(self._graph)

        # Current clusters
        self._clusters: Dict[str, str] = {}

        # Registered agent IDs
        self._agent_ids: Set[str] = set()

        # Statistics
        self._stats = {
            "pings_sent": 0,
            "pings_received": 0,
            "optimizations_run": 0,
            "cluster_changes": 0,
        }

        # Threads
        self._ping_thread: Optional[threading.Thread] = None
        self._optimize_thread: Optional[threading.Thread] = None

        logger.info(f"TopologyManager[{agent_id}] initialized")

    # -------------------------------------------------------------------------
    # Agent Registry
    # -------------------------------------------------------------------------

    def register_agent(self, agent_id: str) -> None:
        """Register an agent for topology tracking."""
        with self._lock:
            self._agent_ids.add(agent_id)
            self._graph.add_node(agent_id)

    def deregister_agent(self, agent_id: str) -> None:
        """Deregister an agent."""
        with self._lock:
            self._agent_ids.discard(agent_id)

    def set_known_agents(self, agent_ids: List[str]) -> None:
        """Set the complete list of known agents."""
        with self._lock:
            self._agent_ids = set(agent_ids)
            for aid in agent_ids:
                self._graph.add_node(aid)

    # -------------------------------------------------------------------------
    # Latency Measurement
    # -------------------------------------------------------------------------

    def ping(self, target_agent_id: str) -> None:
        """
        Send a ping to a target agent to measure latency.

        The ping response updates the latency matrix.
        """
        import uuid

        with self._lock:
            self._stats["pings_sent"] += 1
            ping_id = str(uuid.uuid4())
            start = time.monotonic()

        # Send ping via mesh bus or gossip
        if self.mesh_bus:
            try:
                from simp.mesh.packet import MeshPacket, MessageType, Priority

                packet = MeshPacket(
                    msg_type=MessageType.SYSTEM,
                    sender_id=self.agent_id,
                    recipient_id=target_agent_id,
                    channel="topology",
                    priority=Priority.LOW,
                    payload={
                        "ping_id": ping_id,
                        "timestamp": start,
                        "type": "topology_ping",
                    },
                    ttl_seconds=10,
                )
                self.mesh_bus.send(packet)
            except Exception:
                logger.exception(f"TopologyManager[{self.agent_id}] ping failed")

        logger.debug(f"TopologyManager[{self.agent_id}] ping -> {target_agent_id}")

    def handle_pong(self, ping_id: str, target_agent_id: str, timestamp: float) -> None:
        """
        Handle a pong response from a ping.

        Args:
            ping_id: ID of the original ping
            target_agent_id: Agent that responded
            timestamp: Original ping timestamp (monotonic)
        """
        rtt_ms = (time.monotonic() - timestamp) * 1000

        with self._lock:
            self._graph.add_edge(self.agent_id, target_agent_id, rtt_ms)
            self._stats["pings_received"] += 1

        logger.debug(
            f"TopologyManager[{self.agent_id}] pong from {target_agent_id} "
            f"(rtt={rtt_ms:.2f}ms)"
        )

    def record_latency(self, src: str, dst: str, rtt_ms: float) -> None:
        """Record a latency measurement from gossip or direct measurement."""
        with self._lock:
            self._graph.add_edge(src, dst, rtt_ms)

    # -------------------------------------------------------------------------
    # Routing
    # -------------------------------------------------------------------------

    def get_route(self, src: str, dst: str) -> Optional[str]:
        """
        Get suggested route for sending from src to dst.

        Returns:
            Route description like "local:cluster_0" or "mesh:direct"
        """
        with self._lock:
            src_cluster = self._clusters.get(src)
            dst_cluster = self._clusters.get(dst)

        if src_cluster and src_cluster == dst_cluster:
            return f"local:{src_cluster}"

        # Check direct latency
        lat = self._graph.get_latency(src, dst)
        if lat is not None and lat < 5.0:  # Less than 5ms
            return "mesh:direct"

        return "mesh:broker"

    def get_cluster(self, agent_id: str) -> Optional[str]:
        return self._clusters.get(agent_id)

    def get_latency(self, a: str, b: str) -> Optional[float]:
        return self._graph.get_latency(a, b)

    # -------------------------------------------------------------------------
    # Optimization
    # -------------------------------------------------------------------------

    def run_optimization(self) -> Dict[str, str]:
        """
        Run topology optimization and update clusters.

        Returns:
            New cluster assignments
        """
        with self._lock:
            old_clusters = dict(self._clusters)

            # Compute MST
            mst = self._optimizer.compute_mst()
            logger.debug(
                f"TopologyManager[{self.agent_id}] MST has {len(mst)} edges "
                f"for {self._graph.num_nodes()} nodes"
            )

            # Cluster agents
            n_clusters = min(4, max(1, self._graph.num_nodes() // 3))
            new_clusters = self._optimizer.cluster_nearest_neighbor(n_clusters=n_clusters)

            # Apply clusters to graph
            for agent_id, cluster_id in new_clusters.items():
                self._graph.set_cluster(agent_id, cluster_id)

            self._clusters = new_clusters
            self._stats["optimizations_run"] += 1

            # Count changes
            changes = sum(1 for k, v in new_clusters.items() if old_clusters.get(k) != v)
            self._stats["cluster_changes"] += changes

            if changes > 0:
                logger.info(
                    f"TopologyManager[{self.agent_id}] optimization: "
                    f"{n_clusters} clusters, {changes} changes"
                )

            return new_clusters

    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------

    def start(self) -> None:
        """Start topology monitoring and optimization threads."""
        with self._lock:
            if self._running:
                return
            self._running = True
            self._shutdown_event.clear()

            self._ping_thread = threading.Thread(
                target=self._ping_loop,
                name=f"TopologyPing-{self.agent_id}",
                daemon=True,
            )
            self._ping_thread.start()

            self._optimize_thread = threading.Thread(
                target=self._optimize_loop,
                name=f"TopologyOptimize-{self.agent_id}",
                daemon=True,
            )
            self._optimize_thread.start()

            logger.info(f"TopologyManager[{self.agent_id}] started")

    def stop(self) -> None:
        """Stop topology monitoring."""
        self._running = False
        self._shutdown_event.set()
        if self._ping_thread:
            self._ping_thread.join(timeout=5.0)
        if self._optimize_thread:
            self._optimize_thread.join(timeout=5.0)

    def shutdown(self) -> None:
        """Full shutdown."""
        self.stop()

    # -------------------------------------------------------------------------
    # Internal Loops
    # -------------------------------------------------------------------------

    def _ping_loop(self) -> None:
        """Background thread: periodically ping all known agents."""
        while not self._shutdown_event.is_set():
            try:
                with self._lock:
                    agents = list(self._agent_ids)

                for target in agents:
                    if target != self.agent_id:
                        self.ping(target)

            except Exception:
                logger.exception(f"TopologyManager[{self.agent_id}] ping loop error")

            self._shutdown_event.wait(timeout=self.PING_INTERVAL_SEC)

    def _optimize_loop(self) -> None:
        """Background thread: periodically run topology optimization."""
        while not self._shutdown_event.is_set():
            self._shutdown_event.wait(timeout=self.OPTIMIZE_INTERVAL_SEC)

            if self._shutdown_event.is_set():
                break

            try:
                self.run_optimization()
            except Exception:
                logger.exception(f"TopologyManager[{self.agent_id}] optimize loop error")

    # -------------------------------------------------------------------------
    # Statistics
    # -------------------------------------------------------------------------

    def get_statistics(self) -> Dict[str, Any]:
        """Get topology manager statistics."""
        with self._lock:
            graph_stats = self._graph.to_dict()
            return {
                **dict(self._stats),
                "num_agents": len(self._agent_ids),
                "num_nodes": self._graph.num_nodes(),
                "num_edges": self._graph.num_edges(),
                "num_clusters": len(set(self._clusters.values())),
                "graph": graph_stats,
            }


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------


def create_topology_manager(
    agent_id: str,
    mesh_bus=None,
    gossip_protocol=None,
) -> TopologyManager:
    """Create a TopologyManager instance."""
    return TopologyManager(
        agent_id=agent_id,
        mesh_bus=mesh_bus,
        gossip_protocol=gossip_protocol,
    )
