#!/usr/bin/env python3
"""
ModelGateway — SIMP Specialist Model Router
==========================================
Routes intents to specialist Ollama models based on intent type/metadata.
Gives the mesh a unified interface to all deployed specialist models.

Models available:
  - codex-legalx    → legal analysis (IRAC format, CRITICAL/HIGH/MEDIUM/LOW risk)
  - brp-merged-q8   → BRP threat evaluation (threat_score, severity, decision)
  - tradingquant    → trading signals & arb detection
  - projectx-brain  → general reasoning / orchestration
  - agentorchestrator → multi-agent coordination

Usage:
  from simp.mesh.model_gateway import get_model_gateway, ModelIntent

  gateway = get_model_gateway()
  result = gateway.route(intent_type="legal", prompt="Analyze SAFE agreement terms...")
"""
from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

OLLAMA_BASE = "http://localhost:11434"

# Specialist model registry
MODELS: Dict[str, Dict[str, Any]] = {
    "legal": {
        "model": "hf.co/automationkasey/codex-legalx-merged-q8:latest",
        "system": "You are PTAI:SIMP — Project Tethered Artificial Intelligence running the Standardized Intent Messaging Protocol. You are a legal AI assistant specialized in: Corporate Law (Delaware C-Corp formation, 83(b) election, governance), Securities Regulation (SEC, Howey Test, Regulation D, Form D), Financial Regulation (FinCEN MSB, BSA/AML, KYC), AI Regulation (EU AI Act, California SB 1047), Patent Law (Alice/Mayo test, 35 USC §101/102/103), Contract Law (SAFEs, SaaS agreements, work-for-hire), Intellectual Property (Copyright, trademark, trade secrets, DTSA), Dispute Resolution (Arbitration, litigation, jurisdiction). Always use IRAC format: Issue → Rule → Analysis → Conclusion. Include CRITICAL/HIGH/MEDIUM/LOW risk levels. Cite specific statutes, regulations, and case law. Flag uncertainty when jurisdiction-specific rules are unclear.",
        "timeout": 120,
        "context_window": 2048,
    },
    "threat": {
        "model": "hf.co/automationkasey/brp-merged-q8:latest",
        "system": "You are a BRP (Bill Russell Protocol) threat evaluation engine. Analyze input for security threats, patterns, and risk indicators. Return structured threat assessment with threat_level (clean/low/medium/high/critical), confidence (0.0-1.0), key_patterns identified, and recommended_action.",
        "timeout": 60,
        "context_window": 2048,
    },
    "trading": {
        "model": "tradingquant:latest",
        "system": "You are a quantitative trading analyst. Analyze market data, arbitrage opportunities, and portfolio signals. Return structured analysis with signal_type, confidence, expected_value, risk assessment, and position sizing recommendations.",
        "timeout": 60,
        "context_window": 2048,
    },
    "orchestration": {
        "model": "projectx-brain:latest",
        "system": "You are ProjectX — the self-maintaining kernel of PTAI:SIMP. Analyze orchestration requests, break down multi-step tasks, identify dependencies, and coordinate agent execution. Return structured task decomposition with step sequencing, agent assignments, and expected outcomes.",
        "timeout": 120,
        "context_window": 2048,
    },
    "coordination": {
        "model": "agentorchestrator:latest",
        "system": "You are the agent orchestrator. Coordinate multiple agents to accomplish complex tasks. Analyze task requirements, assign to appropriate agents, monitor progress, and handle failures. Return structured coordination plan with agent assignments, sequencing, and checkpoint criteria.",
        "timeout": 120,
        "context_window": 2048,
    },
    "general": {
        "model": "qwen2.5:7b",
        "system": "You are PTAI:SIMP — a helpful AI assistant running the Standardized Intent Messaging Protocol. Provide accurate, helpful responses. When uncertain, say so and explain your uncertainty.",
        "timeout": 90,
        "context_window": 2048,
    },
}

# Fallback chain — if specific model fails, try general
FALLBACK_CHAIN = ["general", "qwen2.5:7b"]


@dataclass
class ModelResponse:
    """Structured response from a specialist model."""
    model: str
    intent_type: str
    response_text: str
    tokens_used: int = 0
    inference_time_ms: float = 0.0
    confidence: float = 0.0
    routing_path: List[str] = field(default_factory=list)
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "intent_type": self.intent_type,
            "response_text": self.response_text,
            "tokens_used": self.tokens_used,
            "inference_time_ms": round(self.inference_time_ms, 1),
            "confidence": round(self.confidence, 4),
            "routing_path": self.routing_path,
            "error": self.error,
            "metadata": self.metadata,
        }


@dataclass
class ModelIntent:
    """An intent to be routed to a specialist model."""
    intent_type: str
    prompt: str
    system_hint: Optional[str] = None
    context: Optional[Dict[str, Any]] = None
    timeout: Optional[int] = None
    prefer_model: Optional[str] = None

    def resolve_type(self) -> str:
        """Map intent_type to model key, with fallback."""
        if self.intent_type in MODELS:
            return self.intent_type
        # Keyword-based routing
        prompt_lower = self.prompt.lower()
        if any(k in prompt_lower for k in ["legal", "contract", "sec ", "law", "llc", "corp", "83(b)"]):
            return "legal"
        if any(k in prompt_lower for k in ["threat", "security", "attack", "vulnerability", "brp", "forecasting"]):
            return "threat"
        if any(k in prompt_lower for k in ["trade", "arb", "signal", "market", "portfolio", "position"]):
            return "trading"
        if any(k in prompt_lower for k in ["orchestrat", "agent", "task", "coordinate", "projectx"]):
            return "orchestration"
        return "general"


class ModelGateway:
    """
    Routes intents to specialist Ollama models.
    Thread-safe singleton per process.

    Integration points:
      - IntentMeshRouter: route_llm_intent() delegates here
      - BRPMeshGateway: can call route("threat", ...) for enriched analysis
      - Organ agents: direct import for local specialist calls
    """

    def __init__(self, ollama_base: str = OLLAMA_BASE):
        self._ollama_base = ollama_base
        self._lock = threading.RLock()
        self._stats = {
            "requests_total": 0,
            "requests_by_type": {},
            "errors": 0,
            "fallback_count": 0,
        }

        # Check Ollama availability on init
        self._available_models: List[str] = []
        self._check_ollama()

        logger.info("[ModelGateway] initialized, models: %s", list(MODELS.keys()))

    def _check_ollama(self) -> None:
        """Ping Ollama and cache available models."""
        try:
            import urllib.request
            req = urllib.request.Request(
                f"{self._ollama_base}/api/tags",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
                self._available_models = [
                    m.get("name", "")
                    for m in data.get("models", [])
                ]
                logger.info("[ModelGateway] Ollama models: %s", self._available_models)
        except Exception as exc:
            logger.warning("[ModelGateway] Ollama unreachable: %s", exc)
            self._available_models = []

    def is_model_available(self, model_key: str) -> bool:
        """Check if a model is available in Ollama."""
        if not self._available_models:
            self._check_ollama()
        model_name = MODELS.get(model_key, {}).get("model", model_key)
        return any(model_name in avail or avail in model_name for avail in self._available_models)

    def list_models(self) -> Dict[str, Dict[str, Any]]:
        """Return model registry with availability status."""
        result = {}
        for key, cfg in MODELS.items():
            result[key] = {
                **cfg,
                "available": self.is_model_available(key),
                "model": cfg["model"],
            }
        return result

    def route(
        self,
        intent_type: str,
        prompt: str,
        system_hint: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> ModelResponse:
        """
        Route an intent to the appropriate specialist model.

        Args:
            intent_type: Model category (legal, threat, trading, orchestration, general)
            prompt: User prompt / intent content
            system_hint: Optional override for system prompt
            context: Additional context dict (passed in prompt template)
            timeout: Override for request timeout

        Returns:
            ModelResponse with text, metrics, routing path
        """
        with self._lock:
            self._stats["requests_total"] += 1

        # Build intent
        intent = ModelIntent(
            intent_type=intent_type,
            prompt=prompt,
            system_hint=system_hint,
            context=context,
            timeout=timeout,
        )

        resolved_type = intent.resolve_type()
        routing_path = [resolved_type]

        # Attempt primary model
        resp = self._call_model(resolved_type, intent)
        if resp.error is None:
            return resp

        # Fallback chain
        logger.warning("[ModelGateway] %s failed, trying fallback...", resolved_type)
        self._stats["fallback_count"] += 1
        for fallback_type in FALLBACK_CHAIN:
            if fallback_type == resolved_type:
                continue
            routing_path.append(fallback_type)
            resp = self._call_model(fallback_type, intent)
            if resp.error is None:
                resp.routing_path = routing_path
                return resp

        # All failed
        resp.routing_path = routing_path
        return resp

    def _call_model(self, model_key: str, intent: ModelIntent) -> ModelResponse:
        """Call a specific model by key. Returns ModelResponse."""
        if model_key not in MODELS:
            return ModelResponse(
                model=model_key,
                intent_type=intent.intent_type,
                response_text="",
                error=f"Unknown model key: {model_key}",
            )

        cfg = MODELS[model_key]
        model_name = cfg["model"]
        timeout = intent.timeout or cfg.get("timeout", 90)

        # Track stats
        with self._lock:
            t = intent.intent_type
            self._stats["requests_by_type"][t] = self._stats["requests_by_type"].get(t, 0) + 1

        start = time.monotonic()
        try:
            result_text, tokens = self._ollama_generate(
                model=model_name,
                prompt=self._build_prompt(intent, cfg),
                system=cfg["system"],
                timeout=timeout,
            )
            elapsed_ms = (time.monotonic() - start) * 1000

            return ModelResponse(
                model=model_name,
                intent_type=intent.intent_type,
                response_text=result_text,
                tokens_used=tokens,
                inference_time_ms=elapsed_ms,
                routing_path=[model_key],
                metadata={
                    "model_key": model_key,
                    "context_window": cfg.get("context_window", 2048),
                },
            )
        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            with self._lock:
                self._stats["errors"] += 1
            logger.warning("[ModelGateway] %s call failed: %s", model_key, exc)
            return ModelResponse(
                model=model_name,
                intent_type=intent.intent_type,
                response_text="",
                inference_time_ms=elapsed_ms,
                error=str(exc),
            )

    def _build_prompt(self, intent: ModelIntent, cfg: Dict[str, Any]) -> str:
        """Build the full prompt with optional context."""
        prompt = intent.prompt
        if intent.context:
            ctx_str = json.dumps(intent.context, indent=2)
            prompt = f"Context:\n{ctx_str}\n\nUser: {prompt}"
        return prompt

    def _call_model(self, model_key: str, intent: ModelIntent) -> ModelResponse:
        """Call a specific model by key. Returns ModelResponse. Records experience via OutcomeTracker."""
        if model_key not in MODELS:
            return ModelResponse(
                model=model_key,
                intent_type=intent.intent_type,
                response_text="",
                error=f"Unknown model key: {model_key}",
            )

        cfg = MODELS[model_key]
        model_name = cfg["model"]
        timeout = intent.timeout or cfg.get("timeout", 90)

        # Track stats
        with self._lock:
            t = intent.intent_type
            self._stats["requests_by_type"][t] = self._stats["requests_by_type"].get(t, 0) + 1

        start = time.monotonic()
        resp: Optional[ModelResponse] = None
        try:
            result_text, tokens = self._ollama_generate(
                model=model_name,
                prompt=self._build_prompt(intent, cfg),
                system=cfg["system"],
                timeout=timeout,
            )
            elapsed_ms = (time.monotonic() - start) * 1000

            resp = ModelResponse(
                model=model_name,
                intent_type=intent.intent_type,
                response_text=result_text,
                tokens_used=tokens,
                inference_time_ms=elapsed_ms,
                routing_path=[model_key],
                metadata={
                    "model_key": model_key,
                    "context_window": cfg.get("context_window", 2048),
                },
            )
        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            with self._lock:
                self._stats["errors"] += 1
            logger.warning("[ModelGateway] %s call failed: %s", model_key, exc)
            resp = ModelResponse(
                model=model_name,
                intent_type=intent.intent_type,
                response_text="",
                inference_time_ms=elapsed_ms,
                error=str(exc),
            )

        # ── OutcomeTracker: record experience automatically ──────────────────
        try:
            from simp.mesh.experience_collector import Experience, get_experience_collector
            outcome = "success" if resp.error is None else "failure"
            reward_signal = 1.0 if resp.error is None else -0.5
            confidence = (resp.metadata.get("confidence", 0.5) if resp.metadata else 0.5)
            ec = get_experience_collector()
            ec.record(Experience(
                query_id=str(uuid.uuid4()),
                agent_id="model-gateway",
                intent_type=intent.intent_type,
                model_key=model_key,
                prompt=intent.prompt[:500],
                response_text=resp.response_text[:1000] if resp.response_text else "",
                outcome=outcome,
                reward_signal=reward_signal,
                latency_ms=elapsed_ms,
                confidence=confidence,
                timestamp=time.time(),
                metadata={"routing_path": resp.routing_path, "error": resp.error,
                          "tokens_used": resp.tokens_used},
            ))
        except Exception as ex:
            logger.debug("[ModelGateway] experience record skipped: %s", ex)
        # ── end OutcomeTracker ─────────────────────────────────────────────────

        return resp

    def _ollama_generate(
        self,
        model: str,
        prompt: str,
        system: Optional[str] = None,
        timeout: int = 90,
    ) -> tuple[str, int]:
        """Call Ollama /api/generate endpoint. Returns (text, tokens)."""
        import urllib.request

        payload: Dict[str, Any] = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.3,
                "top_p": 0.9,
                "num_ctx": 2048,
            },
        }
        if system:
            payload["system"] = system

        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{self._ollama_base}/api/generate",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read())

        text = data.get("response", "").strip()
        # Ollama doesn't always return token count; estimate ~4 chars/token
        tokens = data.get("eval_count", len(text) // 4)
        return text, tokens

    def get_stats(self) -> Dict[str, Any]:
        """Return gateway statistics."""
        with self._lock:
            return {
                **self._stats.copy(),
                "available_models": self._available_models,
            }

    def health_check(self) -> Dict[str, Any]:
        """Health check — Ollama reachability + model availability."""
        ollama_ok = False
        try:
            import urllib.request
            req = urllib.request.Request(f"{self._ollama_base}/api/tags")
            with urllib.request.urlopen(req, timeout=5) as resp:
                ollama_ok = resp.status == 200
        except Exception:
            pass

        models_status = {}
        for key in MODELS:
            models_status[key] = self.is_model_available(key)

        return {
            "ollama_reachable": ollama_ok,
            "models": models_status,
            "any_model_available": any(models_status.values()),
        }


# ── Singleton ─────────────────────────────────────────────────────────────────

_gateway_instance: Optional[ModelGateway] = None
_gateway_lock = threading.Lock()


def get_model_gateway() -> ModelGateway:
    """Return the process-level ModelGateway singleton."""
    global _gateway_instance
    with _gateway_lock:
        if _gateway_instance is None:
            _gateway_instance = ModelGateway()
    return _gateway_instance