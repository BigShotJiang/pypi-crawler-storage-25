"""Cross-mesh intent signing and verification.

Provides cryptographic signing of cross-mesh intents using Ed25519
(via pyca/cryptography if available, falling back to HMAC-SHA256).

Envelopes wrap intents with origin broker, timestamp, and signature
for auditability and chain-of-trust verification.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
from typing import Any

# -------------------------------------------------------------------
# Attempt to import Ed25519 from pyca/cryptography
# -------------------------------------------------------------------
_USE_ED25519 = False
_ed25519_private_key_cls = None
_ed25519_public_key_cls = None

try:
    from cryptography.hazmat.primitives.asymmetric import ed25519 as _crypto_ed25519

    _USE_ED25519 = True
    _ed25519_private_key_cls = _crypto_ed25519.Ed25519PrivateKey
    _ed25519_public_key_cls = _crypto_ed25519.Ed25519PublicKey
except ImportError:
    pass


def _generate_hmac_key() -> bytes:
    """Generate a 32-byte HMAC key for fallback signing."""
    return os.urandom(32)


def _ed25519_sign(data: bytes, private_key: bytes) -> bytes:
    """Sign *data* using an Ed25519 private key (raw 32-byte seed)."""
    if _USE_ED25519:
        priv = _ed25519_private_key_cls.from_private_bytes(private_key)
        return priv.sign(data)
    raise NotImplementedError("Ed25519 not available")


def _ed25519_verify(data: bytes, signature: bytes, public_key: bytes) -> bool:
    """Verify an Ed25519 signature given the 32-byte public key."""
    if _USE_ED25519:
        try:
            pub = _ed25519_public_key_cls.from_public_bytes(public_key)
            pub.verify(signature, data)
            return True
        except Exception:
            return False
    raise NotImplementedError("Ed25519 not available")


def _hmac_sign(data: bytes, key: bytes) -> bytes:
    """Sign *data* using HMAC-SHA256."""
    return hmac.new(key, data, hashlib.sha256).digest()


def _hmac_verify(data: bytes, signature: bytes, key: bytes) -> bool:
    """Verify an HMAC-SHA256 signature."""
    expected = _hmac_sign(data, key)
    return hmac.compare_digest(signature, expected)


class CrossMeshSigner:
    """Sign and verify cross-mesh intents with Ed25519 (or HMAC fallback).

    Usage::

        signer = CrossMeshSigner()
        private_key = signer.generate_private_key()
        sig, pubkey = signer.sign_intent(b"intent data", private_key)
        assert signer.verify_intent(b"intent data", sig, pubkey)
    """

    def __init__(self) -> None:
        self._use_ed25519 = _USE_ED25519

    # ------------------------------------------------------------------
    # Key generation
    # ------------------------------------------------------------------

    @staticmethod
    def generate_private_key() -> bytes:
        """Generate a fresh private key (Ed25519 seed or HMAC key).

        Returns:
            32 bytes suitable for use with ``sign_intent``.
        """
        if _USE_ED25519:
            priv = _ed25519_private_key_cls.generate()
            return priv.private_bytes_raw()
        return _generate_hmac_key()

    @staticmethod
    def derive_public_key(private_key: bytes) -> bytes:
        """Derive the public key from a private key.

        Args:
            private_key: 32-byte private key.

        Returns:
            32-byte public key.  For the HMAC fallback this returns the
            same 32 bytes (symmetric key).
        """
        if _USE_ED25519:
            priv = _ed25519_private_key_cls.from_private_bytes(private_key)
            return priv.public_key().public_bytes_raw()
        # HMAC fallback: symmetric, so public == private
        return private_key

    # ------------------------------------------------------------------
    # Core signing & verification
    # ------------------------------------------------------------------

    def sign_intent(
        self,
        intent_data: bytes,
        private_key: bytes,
    ) -> tuple[bytes, bytes]:
        """Sign intent data with the broker's private key.

        Args:
            intent_data: Raw bytes of the intent to sign.
            private_key: 32-byte private key.

        Returns:
            Tuple of ``(signature, public_key)``.
        """
        if self._use_ed25519:
            signature = _ed25519_sign(intent_data, private_key)
            pubkey = self.derive_public_key(private_key)
        else:
            signature = _hmac_sign(intent_data, private_key)
            pubkey = private_key  # symmetric
        return signature, pubkey

    def verify_intent(
        self,
        intent_data: bytes,
        signature: bytes,
        public_key: bytes,
    ) -> bool:
        """Verify an intent signature.

        Args:
            intent_data: The original intent bytes.
            signature: Signature to verify.
            public_key: Public key (or HMAC key) to verify against.

        Returns:
            True if the signature is valid, False otherwise.
        """
        if self._use_ed25519:
            return _ed25519_verify(intent_data, signature, public_key)
        return _hmac_verify(intent_data, signature, public_key)

    # ------------------------------------------------------------------
    # Envelope helpers
    # ------------------------------------------------------------------

    def create_signed_envelope(
        self,
        intent: dict[str, Any],
        origin_broker: str,
        private_key: bytes,
    ) -> dict[str, Any]:
        """Wrap an intent in a signed envelope.

        The envelope structure::

            {
                "intent": { ... },
                "origin_broker": "broker-id",
                "timestamp": 1234567890.0,
                "signature": "hex-encoded",
                "pubkey": "hex-encoded"
            }

        Args:
            intent: The intent payload as a JSON-serialisable dict.
            origin_broker: Identifier for the originating broker.
            private_key: 32-byte private key for signing.

        Returns:
            The signed envelope dictionary.
        """
        intent_bytes = json.dumps(intent, sort_keys=True, separators=(",", ":")).encode("utf-8")
        signature, pubkey = self.sign_intent(intent_bytes, private_key)

        envelope: dict[str, Any] = {
            "intent": intent,
            "origin_broker": origin_broker,
            "timestamp": time.time(),
            "signature": signature.hex(),
            "pubkey": pubkey.hex(),
        }
        return envelope

    def verify_envelope(self, envelope: dict[str, Any]) -> dict[str, Any] | None:
        """Verify the signature on a signed envelope.

        Args:
            envelope: The signed envelope dictionary.

        Returns:
            The ``intent`` dict if the signature is valid, None otherwise.
        """
        try:
            intent = envelope.get("intent")
            origin = envelope.get("origin_broker", "")
            signature = bytes.fromhex(envelope.get("signature", ""))
            pubkey = bytes.fromhex(envelope.get("pubkey", ""))
        except (ValueError, TypeError, KeyError):
            return None

        # Re-serialize intent the same way
        intent_bytes = json.dumps(intent, sort_keys=True, separators=(",", ":")).encode("utf-8")

        if self.verify_intent(intent_bytes, signature, pubkey):
            return intent  # type: ignore[return-value]
        return None

    @staticmethod
    def get_chain_of_trust(envelope: dict[str, Any]) -> dict[str, Any]:
        """Extract chain-of-trust metadata from an envelope.

        Args:
            envelope: A signed envelope dict.

        Returns:
            Dict with keys ``origin``, ``timestamp``, ``pubkey``.
            Returns an empty dict if required keys are missing.
        """
        return {
            "origin": envelope.get("origin_broker", ""),
            "timestamp": envelope.get("timestamp", 0.0),
            "pubkey": envelope.get("pubkey", ""),
        }


# -----------------------------------------------------------------------
# Verification block
# -----------------------------------------------------------------------
if __name__ == "__main__":
    signer = CrossMeshSigner()

    # Generate a keypair
    privkey = CrossMeshSigner.generate_private_key()
    pubkey = CrossMeshSigner.derive_public_key(privkey)
    assert len(privkey) == 32
    assert len(pubkey) == 32

    # Sign & verify raw intent
    intent_data = b'{"action": "transfer", "amount": 100}'
    sig, pk = signer.sign_intent(intent_data, privkey)
    assert signer.verify_intent(intent_data, sig, pk), "Signature should verify"
    assert not signer.verify_intent(b"tampered", sig, pk), "Tampered data should fail"

    # Create & verify envelope
    envelope = signer.create_signed_envelope(
        {"action": "transfer", "amount": 100},
        "broker-alpha",
        privkey,
    )
    assert envelope["origin_broker"] == "broker-alpha"
    assert "signature" in envelope
    assert "pubkey" in envelope
    assert "timestamp" in envelope

    result = signer.verify_envelope(envelope)
    assert result is not None, "Envelope should verify"
    assert result["action"] == "transfer"

    # Tampered envelope
    bad_envelope = dict(envelope)
    bad_envelope["intent"]["amount"] = 999999
    assert signer.verify_envelope(bad_envelope) is None, "Tampered envelope should fail"

    # Chain of trust
    cot = CrossMeshSigner.get_chain_of_trust(envelope)
    assert cot["origin"] == "broker-alpha"
    assert cot["timestamp"] > 0

    print("All CrossMeshSigner tests passed.")

    # Report which backend is in use
    backend = "Ed25519 (pyca/cryptography)" if _USE_ED25519 else "HMAC-SHA256 (stdlib fallback)"
    print(f"Using backend: {backend}")
