"""
Entangled Intent Correlation Tracker — T57: Entangled Intent Correlation Tracking

Tracks correlated intent pairs (e.g., buy/sell legs of arbitrage) via
correlation_id on MeshPacket, with HTLC-style enforcement.

Pipeline:
    register_correlation() → CorrelationRecord
    → register_leg_b() links paired leg
    → resolve_leg() on each leg completion
    → both resolved within TTL → RESOLVED
    → one fails or TTL expires → ABORTED/EXPIRED
    → HTLC: PaymentSettler atomic settlement simulation
"""

from __future__ import annotations

import hashlib
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── Status ───────────────────────────────────────────────────────────────────

class CorrelationStatus(str, Enum):
    PENDING  = "pending"   # Both legs not yet sent
    PARTIAL  = "partial"   # One leg sent, waiting for other
    RESOLVED = "resolved"  # Both legs completed within TTL
    EXPIRED  = "expired"   # TTL exceeded before resolution
    ABORTED  = "aborted"    # One leg failed — other must unwind
    CANCELLED = "cancelled"  # Explicitly cancelled by operator


# ── Record ───────────────────────────────────────────────────────────────────

@dataclass
class CorrelationRecord:
    correlation_id: str
    leg_a_id: str = ""           # message_id of leg A
    leg_b_id: str = ""           # message_id of leg B
    status: CorrelationStatus = CorrelationStatus.PENDING
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    ttl_seconds: int = 300       # default 5 minutes
    htlc_hash: str = ""          # Hash of preimage (set when both legs registered)
    htlc_preimage_a: str = ""   # Preimage from leg A (revealed on resolve)
    htlc_preimage_b: str = ""   # Preimage from leg B (revealed on resolve)
    resolved_at: Optional[str] = None
    abort_reason: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def expires_at(self) -> str:
        created = datetime.fromisoformat(self.created_at)
        expiry = created + timedelta(seconds=self.ttl_seconds)
        return expiry.isoformat()

    def is_expired(self) -> bool:
        expiry = datetime.fromisoformat(self.expires_at)
        return datetime.now(timezone.utc) > expiry

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict) -> "CorrelationRecord":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


# ── EntangledIntentTracker ───────────────────────────────────────────────────

class EntangledIntentTracker:
    """
    Tracks correlated intent pairs via correlation_id.

    Typical use for arbitrage:
        leg_a = send_intent(correlation_id=cid, ...)  # buy BTC on Exchange A
        leg_b = send_intent(correlation_id=cid, ...)  # sell BTC on Exchange B
        # Both must resolve within TTL or both unwind
    """

    def __init__(self):
        self._records: Dict[str, CorrelationRecord] = {}
        self._leg_index: Dict[str, str] = {}   # message_id → correlation_id
        self._lock = threading.RLock()
        self.logger = logging.getLogger("entangled.tracker")

    # ── registration ────────────────────────────────────────────────────────

    def register_correlation(
        self,
        correlation_id: str,
        leg_a_id: str,
        ttl_seconds: int = 300,
        htlc_preimage: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> CorrelationRecord:
        """
        Register a new correlation with the first leg already known.

        Args:
            correlation_id: Unique ID for the correlated pair
            leg_a_id:       Message_id of the first leg
            ttl_seconds:    Time window for both legs to resolve
            htlc_preimage:  Optional preimage for HTLC hash lock
            metadata:       Arbitrary context (symbol, side, etc.)
        """
        with self._lock:
            rec = CorrelationRecord(
                correlation_id=correlation_id,
                leg_a_id=leg_a_id,
                ttl_seconds=ttl_seconds,
                htlc_hash=hashlib.sha256(htlc_preimage.encode()).hexdigest() if htlc_preimage else "",
                metadata=metadata or {},
            )
            self._records[correlation_id] = rec
            self._leg_index[leg_a_id] = correlation_id
            self.logger.info(
                f"Registered correlation {correlation_id[:12]} "
                f"(leg_a={leg_a_id[:8]}, ttl={ttl_seconds}s)"
            )
            return rec

    def register_leg_b(
        self,
        correlation_id: str,
        leg_b_id: str,
        htlc_preimage_b: str = "",
    ) -> Optional[CorrelationRecord]:
        """
        Link the second leg to an existing correlation.

        Returns the updated CorrelationRecord, or None if correlation not found.
        """
        with self._lock:
            if correlation_id not in self._records:
                return None
            rec = self._records[correlation_id]
            if rec.status != CorrelationStatus.PENDING:
                return rec  # already resolved/aborted

            rec.leg_b_id = leg_b_id
            rec.htlc_preimage_b = htlc_preimage_b
            rec.status = CorrelationStatus.PARTIAL
            self._leg_index[leg_b_id] = correlation_id

            self.logger.info(
                f"Leg B linked to {correlation_id[:12]} "
                f"(leg_b={leg_b_id[:8]}, status=PARTIAL)"
            )
            return rec

    def register_both_legs(
        self,
        correlation_id: str,
        leg_a_id: str,
        leg_b_id: str,
        ttl_seconds: int = 300,
        htlc_preimage: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> CorrelationRecord:
        """Convenience: register both legs at once."""
        rec = self.register_correlation(correlation_id, leg_a_id, ttl_seconds,
                                        htlc_preimage, metadata)
        self.register_leg_b(correlation_id, leg_b_id)
        return self._records[correlation_id]

    # ── resolution ──────────────────────────────────────────────────────────

    def resolve_leg(
        self,
        leg_message_id: str,
        preimage: str = "",
        success: bool = True,
    ) -> Optional[CorrelationRecord]:
        """
        Mark a leg as resolved (success or failure).

        Args:
            leg_message_id: The message_id of the leg being resolved
            preimage:       HTLC preimage for this leg
            success:        Whether the leg executed successfully

        Returns:
            The updated CorrelationRecord if both legs are now resolved,
            or None if the leg wasn't tracked.
        """
        with self._lock:
            corr_id = self._leg_index.get(leg_message_id)
            if corr_id is None:
                self.logger.debug(f"Leg {leg_message_id[:8]} not tracked")
                return None

            rec = self._records[corr_id]

            # Record preimage
            if leg_message_id == rec.leg_a_id:
                rec.htlc_preimage_a = preimage
            elif leg_message_id == rec.leg_b_id:
                rec.htlc_preimage_b = preimage

            if not success:
                rec.status = CorrelationStatus.ABORTED
                rec.abort_reason = f"leg {leg_message_id[:8]} failed"
                self.logger.warning(
                    f"Correlation {corr_id[:12]} ABORTED: {rec.abort_reason}"
                )
                return rec

            # Both legs now resolved?
            both_resolved = rec.leg_a_id and rec.leg_b_id
            if both_resolved and rec.status != CorrelationStatus.ABORTED:
                rec.status = CorrelationStatus.RESOLVED
                rec.resolved_at = datetime.now(timezone.utc).isoformat()
                self.logger.info(
                    f"Correlation {corr_id[:12]} RESOLVED "
                    f"(leg_a={rec.leg_a_id[:8]}, leg_b={rec.leg_b_id[:8]})"
                )

            return rec

    def abort_correlation(self, correlation_id: str, reason: str) -> Optional[CorrelationRecord]:
        """Explicitly abort a correlation."""
        with self._lock:
            if correlation_id not in self._records:
                return None
            rec = self._records[correlation_id]
            rec.status = CorrelationStatus.ABORTED
            rec.abort_reason = reason
            self.logger.warning(f"Correlation {correlation_id[:12]} ABORTED: {reason}")
            return rec

    # ── TTL expiry ─────────────────────────────────────────────────────────

    def expire_check(self) -> List[str]:
        """
        Check all correlations for TTL expiry.
        Returns list of expired correlation_ids.
        """
        expired_ids: List[str] = []
        with self._lock:
            for corr_id, rec in self._records.items():
                if rec.status in (CorrelationStatus.PENDING, CorrelationStatus.PARTIAL):
                    if rec.is_expired():
                        rec.status = CorrelationStatus.EXPIRED
                        expired_ids.append(corr_id)
                        self.logger.warning(
                            f"Correlation {corr_id[:12]} EXPIRED "
                            f"(ttl={rec.ttl_seconds}s)"
                        )
        return expired_ids

    def cleanup_expired(self, max_age_seconds: int = 3600) -> int:
        """Remove records older than max_age_seconds that are terminal."""
        removed = 0
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=max_age_seconds)
        with self._lock:
            to_remove = []
            for corr_id, rec in self._records.items():
                if rec.status in (CorrelationStatus.RESOLVED,
                                  CorrelationStatus.EXPIRED,
                                  CorrelationStatus.ABORTED,
                                  CorrelationStatus.CANCELLED):
                    created = datetime.fromisoformat(rec.created_at)
                    if created < cutoff:
                        to_remove.append(corr_id)
            for corr_id in to_remove:
                rec = self._records.pop(corr_id)
                self._leg_index.pop(rec.leg_a_id, None)
                self._leg_index.pop(rec.leg_b_id, None)
                removed += 1
        return removed

    # ── queries ────────────────────────────────────────────────────────────

    def get_status(self, correlation_id: str) -> Optional[CorrelationRecord]:
        with self._lock:
            return self._records.get(correlation_id)

    def get_by_leg(self, leg_message_id: str) -> Optional[CorrelationRecord]:
        corr_id = self._leg_index.get(leg_message_id)
        if corr_id is None:
            return None
        return self._records.get(corr_id)

    def get_pending(self) -> List[CorrelationRecord]:
        with self._lock:
            return [
                rec for rec in self._records.values()
                if rec.status in (CorrelationStatus.PENDING, CorrelationStatus.PARTIAL)
            ]

    def get_all(self) -> List[CorrelationRecord]:
        with self._lock:
            return list(self._records.values())

    def get_stats(self) -> Dict[str, int]:
        with self._lock:
            counts: Dict[str, int] = {s.value: 0 for s in CorrelationStatus}
            for rec in self._records.values():
                counts[rec.status.value] += 1
            return counts


# ── Singleton ────────────────────────────────────────────────────────────────

_ET: Optional[EntangledIntentTracker] = None


def get_entangled_tracker() -> EntangledIntentTracker:
    global _ET
    if _ET is None:
        _ET = EntangledIntentTracker()
    return _ET
