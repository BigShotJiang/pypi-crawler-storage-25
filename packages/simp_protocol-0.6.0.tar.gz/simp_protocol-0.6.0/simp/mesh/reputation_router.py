"""
Reputation-Based Routing — Level 3
===================================

Routes intents to the most reputable agents based on their
reputation scores and past performance for specific intent types.

Wraps ReputationSystem with a routing table to provide:
  - Threshold-based agent qualification
  - Best-agent selection per intent type
  - Automatic intent routing

Thread-safe via RLock delegation to ReputationSystem.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Dict, List, Optional, Tuple

from .reputation import ReputationSystem

logger = logging.getLogger(__name__)

DEFAULT_THRESHOLD = 0.7


class ReputationRouter:
    """
    Routes intents to the most reputable qualified agents.

    An agent must have a reputation score >= threshold to be considered
    for routing. The highest-scoring qualified agent for a given intent
    type is selected.

    Usage:
        rs = ReputationSystem()
        router = ReputationRouter(rs)
        router.set_threshold(0.7)
        agent_id = router.route_intent({"action": "trade"}, "trade")
        qualified = router.get_qualified_agents("compute")
        best = router.select_best_agent("trade")
    """

    def __init__(
        self,
        reputation_system: ReputationSystem,
        threshold: float = DEFAULT_THRESHOLD,
    ) -> None:
        """
        Args:
            reputation_system: A ReputationSystem instance for scoring.
            threshold: Minimum reputation score for routing eligibility
                       (default 0.7).
        """
        self._lock = threading.RLock()
        self._rs = reputation_system
        self._threshold = threshold
        # Optional routing table: intent_type -> [agent_id, ...]
        self._routing_table: Dict[str, List[str]] = {}

    # ── Routing Eligibility ─────────────────────────────────────────────────

    def should_route_to(self, agent_id: str) -> bool:
        """
        Check if an agent meets the minimum reputation threshold.

        Args:
            agent_id: The agent to check.

        Returns:
            True if the agent's score >= threshold, False otherwise.
            Returns False for unknown agents (they get the default 0.5
            score, which may be below or at the default threshold of 0.7).
        """
        score = self._rs.get_score(agent_id)
        return score >= self._threshold

    def set_threshold(self, threshold: float) -> None:
        """
        Set the minimum reputation threshold for routing.

        Args:
            threshold: A float between 0.0 and 1.0.

        Raises:
            ValueError: If threshold is outside [0.0, 1.0].
        """
        if not 0.0 <= threshold <= 1.0:
            raise ValueError(f"Threshold must be in [0.0, 1.0], got {threshold}")
        with self._lock:
            self._threshold = threshold
            logger.info("Routing threshold set to %.2f", threshold)

    def get_threshold(self) -> float:
        """
        Get the current routing threshold.

        Returns:
            The current minimum reputation threshold.
        """
        with self._lock:
            return self._threshold

    # ── Qualified Agent Selection ───────────────────────────────────────────

    def get_qualified_agents(self, intent_type: str) -> List[Tuple[str, float]]:
        """
        Get all agents with score >= threshold, optionally filtered by
        intent type.

        If a routing table entry exists for this intent_type, only agents
        in that entry are considered. Otherwise all agents tracked by the
        reputation system are considered.

        Args:
            intent_type: The type/category of intent.

        Returns:
            A list of (agent_id, score) tuples for qualified agents,
            sorted by descending score.
        """
        with self._lock:
            # Get all scores
            all_scores = self._rs.get_all_scores()

            # Filter by routing table if applicable
            if intent_type in self._routing_table:
                eligible = self._routing_table[intent_type]
                agents = {
                    aid: score
                    for aid, score in all_scores.items()
                    if aid in eligible
                }
            else:
                agents = dict(all_scores)

            # Filter by threshold and sort
            qualified = [
                (aid, score)
                for aid, score in agents.items()
                if score >= self._threshold
            ]
            qualified.sort(key=lambda x: x[1], reverse=True)
            return qualified

    def select_best_agent(self, intent_type: str) -> Optional[str]:
        """
        Select the highest-scoring qualified agent for an intent type.

        Args:
            intent_type: The type/category of intent.

        Returns:
            The agent ID with the highest reputation score that meets
            the threshold, or None if no qualified agent is available.
        """
        qualified = self.get_qualified_agents(intent_type)
        if not qualified:
            return None
        return qualified[0][0]

    # ── Intent Routing ─────────────────────────────────────────────────────

    def route_intent(
        self,
        intent: Any,
        intent_type: str,
    ) -> Optional[str]:
        """
        Route an intent to the best qualified agent.

        This is the primary routing method. It selects the highest-scoring
        agent for the given intent type and returns the agent ID.

        Args:
            intent: The intent payload (any serializable data).
            intent_type: The type/category of intent.

        Returns:
            The selected agent ID, or None if no qualified agent is
            available.
        """
        agent_id = self.select_best_agent(intent_type)
        if agent_id is not None:
            logger.info(
                "Routing intent (type=%s) to agent %s (score=%.3f)",
                intent_type, agent_id, self._rs.get_score(agent_id),
            )
        else:
            logger.warning(
                "No qualified agent found for intent type %s (threshold=%.2f)",
                intent_type, self._threshold,
            )
        return agent_id

    # ── Routing Table Management ────────────────────────────────────────────

    def register_agent_for_intent(
        self,
        agent_id: str,
        intent_type: str,
    ) -> None:
        """
        Register an agent as capable of handling a specific intent type.

        Args:
            agent_id: The agent to register.
            intent_type: The intent type the agent can handle.
        """
        with self._lock:
            if intent_type not in self._routing_table:
                self._routing_table[intent_type] = []
            if agent_id not in self._routing_table[intent_type]:
                self._routing_table[intent_type].append(agent_id)
                logger.debug(
                    "Agent %s registered for intent type %s",
                    agent_id, intent_type,
                )

    def unregister_agent_for_intent(
        self,
        agent_id: str,
        intent_type: str,
    ) -> bool:
        """
        Remove an agent from handling a specific intent type.

        Args:
            agent_id: The agent to remove.
            intent_type: The intent type.

        Returns:
            True if the agent was removed, False otherwise.
        """
        with self._lock:
            if intent_type not in self._routing_table:
                return False
            if agent_id not in self._routing_table[intent_type]:
                return False
            self._routing_table[intent_type].remove(agent_id)
            # Clean up empty entries
            if not self._routing_table[intent_type]:
                del self._routing_table[intent_type]
            return True

    def get_routing_table(self) -> Dict[str, List[str]]:
        """
        Get the full routing table.

        Returns:
            A dict mapping intent_type -> list of capable agent IDs.
        """
        with self._lock:
            return {k: list(v) for k, v in self._routing_table.items()}

    def get_agent_intents(self, agent_id: str) -> List[str]:
        """
        Get all intent types a specific agent is registered for.

        Args:
            agent_id: The agent to query.

        Returns:
            A list of intent type strings.
        """
        with self._lock:
            return [
                intent_type
                for intent_type, agents in self._routing_table.items()
                if agent_id in agents
            ]


# ═══════════════════════════════════════════════════════════════════════════
# Verification Block
# ═══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 60)
    print("ReputationRouter Verification")
    print("=" * 60)

    rs = ReputationSystem()
    router = ReputationRouter(rs, threshold=0.7)

    # Setup: build some reputation scores
    rs.record_success("agent_a", "trade")
    rs.record_success("agent_a", "trade")
    rs.record_success("agent_a", "trade")   # score = 0.8

    rs.record_success("agent_b", "trade")
    rs.record_success("agent_b", "trade")   # score = 0.7

    rs.record_success("agent_c", "compute")
    rs.record_success("agent_c", "compute") # score = 0.7

    rs.record_failure("agent_d", "trade", "bad data")  # score = 0.35

    print(f"[ ] agent_a score: {rs.get_score('agent_a'):.3f}")
    print(f"[ ] agent_b score: {rs.get_score('agent_b'):.3f}")
    print(f"[ ] agent_c score: {rs.get_score('agent_c'):.3f}")
    print(f"[ ] agent_d score: {rs.get_score('agent_d'):.3f}")

    # 1. should_route_to
    assert router.should_route_to("agent_a") is True
    assert router.should_route_to("agent_b") is True
    assert router.should_route_to("agent_c") is True
    assert router.should_route_to("agent_d") is False
    print(f"[✓] should_route_to: agent_a=True, agent_b=True, agent_c=True, agent_d=False")

    # 2. set_threshold / get_threshold
    assert router.get_threshold() == DEFAULT_THRESHOLD
    router.set_threshold(0.5)
    assert router.get_threshold() == 0.5
    router.set_threshold(0.7)  # reset
    print(f"[✓] set_threshold/get_threshold: {router.get_threshold()}")

    # 3. Invalid threshold
    try:
        router.set_threshold(1.5)
        print("[✗] Should have raised ValueError for invalid threshold")
    except ValueError:
        print("[✓] ValueError on invalid threshold (expected)")

    # 4. get_qualified_agents
    qualified = router.get_qualified_agents("trade")
    qualified_ids = [aid for aid, _ in qualified]
    assert "agent_a" in qualified_ids
    assert "agent_b" in qualified_ids
    assert "agent_d" not in qualified_ids
    print(f"[✓] get_qualified_agents('trade'): {qualified_ids}")

    # 5. select_best_agent
    best = router.select_best_agent("trade")
    assert best == "agent_a"
    print(f"[✓] select_best_agent('trade'): {best} (score={rs.get_score('agent_a'):.3f})")

    best = router.select_best_agent("compute")
    assert best == "agent_c"
    print(f"[✓] select_best_agent('compute'): {best} (score={rs.get_score('agent_c'):.3f})")

    # 6. Route intent
    agent = router.route_intent({"action": "buy"}, "trade")
    assert agent == "agent_a"
    print(f"[✓] route_intent('trade') routes to: {agent}")

    # 7. No qualified agents (all below threshold)
    rs2 = ReputationSystem()
    router2 = ReputationRouter(rs2, threshold=0.9)
    agent = router2.route_intent({}, "unknown")
    assert agent is None
    print(f"[✓] route_intent returns None when no qualified agents exist")

    # 8. Routing table filtering
    router.register_agent_for_intent("agent_a", "trade")
    router.register_agent_for_intent("agent_c", "compute")
    router.register_agent_for_intent("agent_c", "trade")  # c can also do trade
    rt = router.get_routing_table()
    assert "trade" in rt
    assert "compute" in rt
    assert "agent_a" in rt["trade"]
    assert "agent_c" in rt["trade"]
    print(f"[✓] Routing table: trade={rt['trade']}, compute={rt['compute']}")

    # 9. get_agent_intents
    intents = router.get_agent_intents("agent_c")
    assert "compute" in intents
    assert "trade" in intents
    print(f"[✓] get_agent_intents('agent_c'): {intents}")

    # 10. unregister_agent_for_intent
    result = router.unregister_agent_for_intent("agent_c", "trade")
    assert result is True
    assert "trade" in router.get_routing_table()  # still has agent_a
    print(f"[✓] Unregistered agent_c from trade")

    # 11. Threshold-based filtering changes
    router.set_threshold(0.0)
    assert router.should_route_to("agent_d") is True
    router.set_threshold(0.7)
    print(f"[✓] Threshold 0.0 makes agent_d routable, restored to 0.7")

    print()
    print("All ReputationRouter tests PASSED ✓")
