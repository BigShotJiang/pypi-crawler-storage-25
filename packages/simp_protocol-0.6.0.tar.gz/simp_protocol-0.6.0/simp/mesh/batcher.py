"""
SIMP Message Batching Pipeline — T30-3

Batch intents for up to 1ms OR 50 intents (whichever first):
  - Batch format: {batch_id, intents: [...], size_hint}
  - Reduces TLS handshake overhead (one handshake for N intents)
  - Batch on the way out of broker; each agent de-batches on receipt

Config: batch_max_latency_ms=1, batch_max_size=50

Files: simp/mesh/batcher.py
"""

from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Deque, Dict, List, Optional, Callable

logger = logging.getLogger("SIMP.Batcher")


# ---------------------------------------------------------------------------
# Batch Envelope
# ---------------------------------------------------------------------------


@dataclass
class IntentBatch:
    """
    Batch envelope for grouped intents.

    Attributes:
        batch_id: Unique identifier for this batch
        sender_id: Agent that created the batch
        intents: List of serialized intent dicts
        size_hint: Estimated total serialized size in bytes
        created_at: ISO timestamp of batch creation
        priority: Batch priority level
    """
    batch_id: str
    sender_id: str
    intents: List[Dict[str, Any]]
    size_hint: int = 0
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    priority: str = "normal"  # "critical", "normal", "batch"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> bytes:
        return json.dumps(self.to_dict(), separators=(",", ":")).encode("utf-8")

    @classmethod
    def from_dict(cls, data: Dict) -> "IntentBatch":
        return cls(**data)

    @classmethod
    def from_json(cls, raw: bytes) -> "IntentBatch":
        return cls.from_dict(json.loads(raw))

    def encoded_size(self) -> int:
        """Approximate encoded size in bytes."""
        if self.size_hint:
            return self.size_hint
        return len(self.to_json())


# ---------------------------------------------------------------------------
# Batch Configuration
# ---------------------------------------------------------------------------


@dataclass
class BatchConfig:
    """Configuration for the batching pipeline."""
    batch_max_latency_ms: float = 1.0
    batch_max_size: int = 50
    batch_compress: bool = False  # T30-7: compress batches
    batch_timeout_ms: float = 5.0  # Force flush after this even if incomplete

    @classmethod
    def from_dict(cls, data: Dict) -> "BatchConfig":
        return cls(
            batch_max_latency_ms=float(data.get("batch_max_latency_ms", 1.0)),
            batch_max_size=int(data.get("batch_max_size", 50)),
            batch_compress=data.get("batch_compress", False),
            batch_timeout_ms=float(data.get("batch_timeout_ms", 5.0)),
        )


# ---------------------------------------------------------------------------
# Outbound Batcher
# ---------------------------------------------------------------------------


class OutboundBatcher:
    """
    Batches outgoing intents from one agent to the broker or mesh.

    Operates in the "flush on either condition" pattern:
      - Time deadline: max_latency elapsed since first intent in batch
      - Size deadline: batch reaches max_size intents

    Thread-safe. Calls the provided `send_func` when flushing.
    """

    def __init__(
        self,
        agent_id: str,
        send_func: Callable[[bytes], None],
        config: Optional[BatchConfig] = None,
    ):
        """
        Initialize OutboundBatcher.

        Args:
            agent_id: ID of the agent this batcher belongs to
            send_func: Called with batch JSON bytes when batch is flushed
            config: Batching configuration
        """
        self.agent_id = agent_id
        self.send_func = send_func
        self.config = config or BatchConfig()

        self._lock = threading.RLock()
        self._queue: Deque[Dict[str, Any]] = deque()
        self._batch_start_time: Optional[float] = None  # monotonic time when batch started
        self._flush_event = threading.Event()
        self._shutdown = False

        # Statistics
        self._stats = {
            "batches_sent": 0,
            "intents_batched": 0,
            "batches_flush_timeout": 0,
            "batches_flush_size": 0,
            "batches_flush_manual": 0,
            "current_batch_size": 0,
        }

        logger.debug(
            f"OutboundBatcher[{agent_id}] initialized "
            f"(latency={self.config.batch_max_latency_ms}ms, size={self.config.batch_max_size})"
        )

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    def add(self, intent: Dict[str, Any]) -> None:
        """
        Add an intent to the current batch.
        Flushes automatically when deadline is reached.
        """
        with self._lock:
            if self._shutdown:
                return

            self._queue.append(intent)
            self._stats["current_batch_size"] = len(self._queue)

            # Start batch timer on first intent
            if self._batch_start_time is None:
                self._batch_start_time = time.monotonic()

            # Check if flush needed
            if self._should_flush_unlocked():
                self._flush_unlocked()
            else:
                # Wake the flush thread to recalculate deadline
                self._flush_event.set()

    def add_batch(self, intents: List[Dict[str, Any]]) -> None:
        """Add multiple intents at once."""
        for intent in intents:
            self.add(intent)

    def flush(self) -> int:
        """
        Force an immediate flush of the current batch.

        Returns:
            Number of intents flushed
        """
        with self._lock:
            return self._flush_unlocked()

    def size(self) -> int:
        """Current number of intents in the batch."""
        with self._lock:
            return len(self._queue)

    def get_statistics(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self._stats)

    def shutdown(self) -> None:
        """Flush remaining intents and stop."""
        with self._lock:
            self._shutdown = True
            self._flush_unlocked()
            self._flush_event.set()

    # -------------------------------------------------------------------------
    # Internal
    # -------------------------------------------------------------------------

    def _should_flush_unlocked(self) -> bool:
        """Check if batch should flush (caller must hold lock)."""
        if not self._queue:
            return False

        # Size deadline
        if len(self._queue) >= self.config.batch_max_size:
            return True

        # Time deadline
        if self._batch_start_time is not None:
            elapsed_ms = (time.monotonic() - self._batch_start_time) * 1000
            if elapsed_ms >= self.config.batch_max_latency_ms:
                return True

        return False

    def _flush_unlocked(self) -> int:
        """Flush current batch. Caller must hold lock."""
        if not self._queue:
            return 0

        count = len(self._queue)

        # Build batch
        intents = [self._queue.popleft() for _ in range(count)]
        size_hint = sum(len(json.dumps(i)) for i in intents)

        batch = IntentBatch(
            batch_id=str(uuid.uuid4()),
            sender_id=self.agent_id,
            intents=intents,
            size_hint=size_hint,
        )

        # Reset state
        self._batch_start_time = None
        self._stats["current_batch_size"] = 0
        self._flush_event.clear()

        # Serialize and send
        try:
            data = batch.to_json()
            self.send_func(data)
            self._stats["batches_sent"] += 1
            self._stats["intents_batched"] += count
            logger.debug(
                f"OutboundBatcher[{self.agent_id}] flushed batch {batch.batch_id} "
                f"({count} intents, ~{size_hint} bytes)"
            )
        except Exception:
            logger.exception(f"OutboundBatcher[{self.agent_id}] flush failed")

        return count

    def _flush_loop(self) -> None:
        """Background thread that flushes on time deadline."""
        while not self._shutdown:
            # Wait until next deadline or shutdown
            with self._lock:
                deadline = None
                if self._batch_start_time is not None and self._queue:
                    elapsed = (time.monotonic() - self._batch_start_time) * 1000
                    remaining_ms = self.config.batch_max_latency_ms - elapsed
                    deadline = max(0.001, remaining_ms / 1000.0)  # seconds

            if deadline:
                self._flush_event.wait(timeout=deadline)
            else:
                self._flush_event.wait(timeout=self.config.batch_max_latency_ms)

            with self._lock:
                if self._shutdown:
                    break
                if self._should_flush_unlocked():
                    reason = "timeout" if self._batch_start_time else "size"
                    self._flush_unlocked()
                    if reason == "timeout":
                        self._stats["batches_flush_timeout"] += 1
                    else:
                        self._stats["batches_flush_size"] += 1


# ---------------------------------------------------------------------------
# Inbound De-batch Handler
# ---------------------------------------------------------------------------


class InboundBatchHandler:
    """
    Handles de-batching of received batch messages.

    When a batch is received, this handler unpacks it and forwards
    individual intents to the appropriate recipient queues.
    """

    def __init__(self, local_dispatch_broker=None):
        self.local_dispatch_broker = local_dispatch_broker

        # Statistics
        self._stats = {
            "batches_received": 0,
            "intents_extracted": 0,
            "decompression_failures": 0,
        }

    def handle_batch(self, raw_data: bytes) -> List[Dict[str, Any]]:
        """
        Parse and de-batch a received batch.

        Args:
            raw_data: JSON bytes of an IntentBatch

        Returns:
            List of individual intent dicts

        Raises:
            ValueError: If batch format is invalid
        """
        try:
            batch = IntentBatch.from_json(raw_data)
            self._stats["batches_received"] += 1
            self._stats["intents_extracted"] += len(batch.intents)
            logger.debug(
                f"InboundBatchHandler de-batched {len(batch.intents)} intents "
                f"from batch {batch.batch_id}"
            )
            return batch.intents
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid batch JSON: {e}") from e

    def handle_batch_dict(self, data: Dict) -> List[Dict[str, Any]]:
        """Parse a batch from a dict."""
        batch = IntentBatch.from_dict(data)
        self._stats["batches_received"] += 1
        self._stats["intents_extracted"] += len(batch.intents)
        return batch.intents

    def get_statistics(self) -> Dict[str, Any]:
        return dict(self._stats)


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------


def create_batch(
    agent_id: str,
    intents: List[Dict[str, Any]],
    priority: str = "normal",
) -> IntentBatch:
    """Create a batch from a list of intents."""
    size_hint = sum(len(json.dumps(i)) for i in intents)
    return IntentBatch(
        batch_id=str(uuid.uuid4()),
        sender_id=agent_id,
        intents=intents,
        size_hint=size_hint,
        priority=priority,
    )


def batch_to_json(batch: IntentBatch) -> bytes:
    """Serialize a batch to JSON bytes."""
    return batch.to_json()


def batch_from_json(raw: bytes) -> IntentBatch:
    """Deserialize a batch from JSON bytes."""
    return IntentBatch.from_json(raw)
