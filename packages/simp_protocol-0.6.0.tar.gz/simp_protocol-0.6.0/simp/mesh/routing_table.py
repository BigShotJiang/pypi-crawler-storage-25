"""
Mesh Routing Table — L3-T2

Thread-safe routing table that maps intent types to capable agents.
Refreshed from the CapabilityRegistry every 30s. Supports:

- Exact match routing: "risk_assessment" -> [agent_a, agent_b]
- Wildcard routing: "trade_execution.*" -> all trade agents
- Agent-specific routing: direct to named agent
- Priority-weighted routing: high-reputation agents preferred
- TTL-based route expiry

Built on top of CapabilityRegistry (L3-T1) and MeshDiscovery (discovery.py).
"""

import json
import logging
import threading
import time
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Set, Tuple, Callable

from .capability_registry import CapabilityRegistry, CapabilityEntry, get_capability_registry

logger = logging.getLogger(__name__)


@dataclass
class RouteEntry:
    """A route from intent type to an agent."""
    intent_type: str
    agent_id: str
    endpoint: Optional[str] = None
    reputation: float = 0.5
    priority: int = 0          # Lower = higher priority
    ttl_seconds: int = 300
    created_at: float = field(default_factory=time.time)
    last_used: float = field(default_factory=time.time)

    def is_expired(self) -> bool:
        return (time.time() - self.last_used) > self.ttl_seconds

    def touch(self) -> None:
        self.last_used = time.time()

    def to_dict(self) -> dict:
        return {
            "intent_type": self.intent_type,
            "agent_id": self.agent_id,
            "endpoint": self.endpoint,
            "reputation": self.reputation,
            "priority": self.priority,
            "ttl_seconds": self.ttl_seconds,
            "created_at": self.created_at,
            "last_used": self.last_used,
            "expired": self.is_expired(),
        }


class RoutingTable:
    """
    Routing table mapping intent types -> agent lists.
    Refreshed from CapabilityRegistry on a timer.
    """

    def __init__(self, registry: Optional[CapabilityRegistry] = None,
                 refresh_interval: float = 30.0):
        self._registry = registry or get_capability_registry()
        self._refresh_interval = refresh_interval
        self._lock = threading.RLock()

        # Routing data structures
        self._exact_routes: Dict[str, List[RouteEntry]] = {}    # intent_type -> [routes]
        self._wildcard_routes: Dict[str, List[RouteEntry]] = {} # "prefix.*" -> [routes]
        self._agent_index: Dict[str, List[RouteEntry]] = {}     # agent_id -> [routes]

        # Refresh tracking
        self._last_refresh: float = 0.0
        self._refresh_count: int = 0
        self._dirty = False

        logger.info("RoutingTable initialized (refresh_interval=%ds)", refresh_interval)

    def refresh(self, force: bool = False) -> int:
        """
        Refresh routes from capability registry.
        Returns number of routes added/updated.
        """
        now = time.time()
        if not force and (now - self._last_refresh) < self._refresh_interval:
            return 0

        with self._lock:
            # Clear current routes
            old_count = sum(len(routes) for routes in self._exact_routes.values())
            self._exact_routes.clear()
            self._wildcard_routes.clear()
            self._agent_index.clear()

            # Query all capabilities from registry
            capabilities = self._registry.list_capabilities()
            count = 0

            for cap in capabilities:
                entries = self._registry.query(cap, include_expired=False)
                for entry in entries:
                    if entry.is_expired():
                        continue

                    route = RouteEntry(
                        intent_type=cap,
                        agent_id=entry.agent_id,
                        endpoint=entry.endpoint,
                        reputation=entry.reputation,
                    )

                    # Store in correct index
                    if "*" in cap:
                        if cap not in self._wildcard_routes:
                            self._wildcard_routes[cap] = []
                        self._wildcard_routes[cap].append(route)
                    else:
                        if cap not in self._exact_routes:
                            self._exact_routes[cap] = []
                        self._exact_routes[cap].append(route)

                    # Agent index
                    if entry.agent_id not in self._agent_index:
                        self._agent_index[entry.agent_id] = []
                    self._agent_index[entry.agent_id].append(route)

                    count += 1

            # Sort by reputation (descending) so best agents are first
            for routes in self._exact_routes.values():
                routes.sort(key=lambda r: r.reputation, reverse=True)
            for routes in self._wildcard_routes.values():
                routes.sort(key=lambda r: r.reputation, reverse=True)

            self._last_refresh = now
            self._refresh_count += 1
            self._dirty = True

            logger.info("RoutingTable refreshed: %d routes (%d exact, %d wildcard) from %d capabilities",
                        count, sum(len(v) for v in self._exact_routes.values()),
                        sum(len(v) for v in self._wildcard_routes.values()), len(capabilities))
            return count

    def lookup(self, intent_type: str, min_reputation: float = 0.0,
               max_results: int = 5) -> List[RouteEntry]:
        """
        Find routes for an intent type.

        First checks exact match, then falls back to wildcard.
        Results sorted by reputation descending.
        """
        # Auto-refresh if stale
        if time.time() - self._last_refresh > self._refresh_interval:
            self.refresh()

        with self._lock:
            results: List[RouteEntry] = []

            # Exact match
            if intent_type in self._exact_routes:
                results.extend(self._exact_routes[intent_type])

            # Wildcard match: check if any wildcard prefix matches
            for pattern, routes in self._wildcard_routes.items():
                prefix = pattern.replace(".*", "")
                if intent_type.startswith(prefix):
                    results.extend(routes)

            # Subtype match: e.g., querying "risk_assessment" should match "risk_assessment.var"
            for cap, routes in self._exact_routes.items():
                if cap.startswith(intent_type + "."):
                    results.extend(routes)

            # Deduplicate (keep highest reputation entry per agent)
            seen: Dict[str, RouteEntry] = {}
            for r in results:
                if r.agent_id not in seen or r.reputation > seen[r.agent_id].reputation:
                    seen[r.agent_id] = r
            results = list(seen.values())

            # Filter by reputation
            if min_reputation > 0.0:
                results = [r for r in results if r.reputation >= min_reputation]

            # Sort by reputation
            results.sort(key=lambda r: r.reputation, reverse=True)

            # Limit results
            if max_results > 0:
                results = results[:max_results]

            # Mark as used
            for r in results:
                r.touch()

            return results

    def lookup_agent(self, agent_id: str) -> List[RouteEntry]:
        """Find all routes for a specific agent."""
        with self._lock:
            return list(self._agent_index.get(agent_id, []))

    def get_routes_for_capability(self, capability: str) -> List[RouteEntry]:
        """Get all routes for a specific capability."""
        return self.lookup(capability, max_results=0)

    def add_manual_route(self, intent_type: str, agent_id: str,
                         endpoint: Optional[str] = None,
                         reputation: float = 0.5) -> None:
        """Manually add a route (not from registry)."""
        with self._lock:
            route = RouteEntry(
                intent_type=intent_type,
                agent_id=agent_id,
                endpoint=endpoint,
                reputation=reputation,
            )

            if intent_type not in self._exact_routes:
                self._exact_routes[intent_type] = []
            self._exact_routes[intent_type].append(route)

            if agent_id not in self._agent_index:
                self._agent_index[agent_id] = []
            self._agent_index[agent_id].append(route)

            logger.info("Added manual route: %s -> %s", intent_type, agent_id)

    def remove_agent_routes(self, agent_id: str) -> int:
        """Remove all routes for an agent. Returns count removed."""
        with self._lock:
            count = 0
            # Remove from exact routes
            for routes in self._exact_routes.values():
                before = len(routes)
                routes[:] = [r for r in routes if r.agent_id != agent_id]
                count += before - len(routes)

            # Remove from wildcard routes
            for routes in self._wildcard_routes.values():
                before = len(routes)
                routes[:] = [r for r in routes if r.agent_id != agent_id]
                count += before - len(routes)

            # Remove from agent index
            if agent_id in self._agent_index:
                count += len(self._agent_index[agent_id])
                del self._agent_index[agent_id]

            if count:
                logger.info("Removed %d routes for agent %s", count, agent_id)
            return count

    def get_stats(self) -> dict:
        """Get routing table statistics."""
        with self._lock:
            exact_count = sum(len(v) for v in self._exact_routes.values())
            wildcard_count = sum(len(v) for v in self._wildcard_routes.values())
            return {
                "exact_routes": len(self._exact_routes),
                "wildcard_routes": len(self._wildcard_routes),
                "total_route_entries": exact_count + wildcard_count,
                "unique_agents": len(self._agent_index),
                "last_refresh": self._last_refresh,
                "refresh_count": self._refresh_count,
                "refresh_interval": self._refresh_interval,
                "seconds_since_refresh": time.time() - self._last_refresh if self._last_refresh else -1,
            }

    def to_dict(self) -> dict:
        """Full serializable dump."""
        with self._lock:
            return {
                "routes": {
                    cap: [r.to_dict() for r in routes]
                    for cap, routes in {**self._exact_routes, **self._wildcard_routes}.items()
                },
                "agents": {
                    aid: [r.to_dict() for r in routes]
                    for aid, routes in self._agent_index.items()
                },
                "stats": self.get_stats(),
            }


# Singleton
_table: Optional[RoutingTable] = None
_table_lock = threading.Lock()


def get_routing_table(registry: Optional[CapabilityRegistry] = None) -> RoutingTable:
    """Get or create the singleton RoutingTable."""
    global _table
    if _table is None:
        with _table_lock:
            if _table is None:
                _table = RoutingTable(registry)
    return _table
