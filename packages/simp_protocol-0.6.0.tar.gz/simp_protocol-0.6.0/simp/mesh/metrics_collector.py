"""
Mesh Metrics Collector — Per-Broker Metrics Aggregation (Level 3)
=================================================================

Collects and aggregates metrics from brokers in the SIMP mesh. Supports
registration of brokers, setting individual metrics, aggregation into
a single view, and Prometheus-formatted exposition.

Thread-safe via threading.Lock.
Pure Python (stdlib only).
"""

from __future__ import annotations

import logging
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class BrokerMetrics:
    """Metrics snapshot for a single broker."""

    broker_id: str
    metrics: Dict[str, float] = field(default_factory=dict)
    last_collected: float = 0.0
    last_updated: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "broker_id": self.broker_id,
            "metrics": dict(self.metrics),
            "last_collected": self.last_collected,
            "last_updated": self.last_updated,
        }


class MetricsCollector:
    """
    Aggregates per-broker metrics across the SIMP mesh.

    Brokers can be registered and metrics set for each. The ``collect()``
    method simulates collecting current values from all registered brokers,
    and ``aggregate()`` combines them into a single flat dict.

    Prometheus-formatted output is available via ``expose_prometheus()``.

    Args:
        simulation_noise: If True, collect() adds a small random delta to
                          simulate real-world variation.
    """

    def __init__(self, simulation_noise: bool = False) -> None:
        self._lock = threading.Lock()
        self._brokers: Dict[str, BrokerMetrics] = {}
        self._simulation_noise = simulation_noise

        # Standard metric names tracked across all brokers
        self._standard_metrics: set = {
            "cpu_usage_pct",
            "memory_usage_mb",
            "active_intents",
            "intents_per_sec",
            "messages_per_sec",
            "error_count",
            "latency_p50_ms",
            "latency_p95_ms",
            "latency_p99_ms",
            "connections_active",
            "uptime_seconds",
            "queue_depth",
            "dropped_messages",
        }

    # ── Registration ──────────────────────────────────────────────────

    def register_broker(self, broker_id: str) -> BrokerMetrics:
        """
        Register a broker for metrics collection.

        Args:
            broker_id: Unique broker identifier.

        Returns:
            The new BrokerMetrics instance.
        """
        with self._lock:
            if broker_id in self._brokers:
                logger.debug("Broker '%s' already registered", broker_id)
                return self._brokers[broker_id]

            bm = BrokerMetrics(broker_id=broker_id)
            self._brokers[broker_id] = bm
            logger.info("Registered metrics broker: %s", broker_id)
            return bm

    # ── Setting Metrics ───────────────────────────────────────────────

    def set_metric(
        self,
        broker_id: str,
        metric_name: str,
        value: float,
    ) -> bool:
        """
        Set a metric value for a broker.

        The broker must already be registered via ``register_broker()``.

        Args:
            broker_id: The broker identifier.
            metric_name: Metric name (e.g. 'cpu_usage_pct', 'latency_p50_ms').
            value: Numeric value for the metric.

        Returns:
            True if the metric was set, False if the broker is unknown.
        """
        with self._lock:
            bm = self._brokers.get(broker_id)
            if bm is None:
                logger.warning("set_metric: broker '%s' not registered", broker_id)
                return False

            bm.metrics[metric_name] = value
            bm.last_updated = time.time()
            return True

    # ── Collection & Aggregation ─────────────────────────────────────

    def collect(self) -> Dict[str, BrokerMetrics]:
        """
        "Collect" metrics from all registered brokers.

        This simulates a collection cycle — in a real deployment this would
        pull metrics over the mesh. If ``simulation_noise`` is enabled, a
        small random delta is added to existing numeric metrics.

        Returns:
            Dict of broker_id -> BrokerMetrics.
        """
        import random

        with self._lock:
            now = time.time()
            for bm in self._brokers.values():
                bm.last_collected = now
                if self._simulation_noise and bm.metrics:
                    for key in bm.metrics:
                        noise = random.uniform(-0.05, 0.05)  # ±5%
                        bm.metrics[key] = bm.metrics[key] * (1.0 + noise)

            return {bid: bm for bid, bm in self._brokers.items()}

    def aggregate(self) -> Dict[str, float]:
        """
        Combine all broker metrics into a single flat dict.

        For each standard metric, the aggregate value is the mean across
        all brokers that have that metric set.

        Returns:
            {
                "cpu_usage_pct": 45.2,
                "memory_usage_mb": 1024.0,
                ...
                "_broker_count": 5,
                "_metric_count": 12,
            }
        """
        with self._lock:
            aggregated: Dict[str, List[float]] = defaultdict(list)

            for bm in self._brokers.values():
                for key, val in bm.metrics.items():
                    aggregated[key].append(val)

            result: Dict[str, float] = {}
            for key, values in aggregated.items():
                if values:
                    result[key] = sum(values) / len(values)

            result["_broker_count"] = float(len(self._brokers))
            result["_metric_count"] = float(len(aggregated))
            return result

    # ── Queries ───────────────────────────────────────────────────────

    def get_broker_metrics(self, broker_id: str) -> Optional[Dict[str, Any]]:
        """
        Return metrics for a single broker.

        Args:
            broker_id: The broker to query.

        Returns:
            Metrics dict, or None if unknown.
        """
        with self._lock:
            bm = self._brokers.get(broker_id)
            return bm.to_dict() if bm else None

    def get_aggregated_metrics(self) -> Dict[str, float]:
        """
        Alias for ``aggregate()`` — returns combined metrics.

        Returns:
            Aggregated metrics dict.
        """
        return self.aggregate()

    def get_all_broker_ids(self) -> List[str]:
        """Return all registered broker IDs."""
        with self._lock:
            return list(self._brokers.keys())

    # ── Prometheus Exposition ─────────────────────────────────────────

    def expose_prometheus(self) -> str:
        """
        Return all metrics in Prometheus exposition format.

        https://prometheus.io/docs/instrumenting/exposition_formats/

        Metric names are prefixed with ``simp_`` and sanitized (dots
        replaced with underscores). Each broker's metrics are labeled
        with ``broker_id``.

        Returns:
            Prometheus-formatted string.
        """
        lines: List[str] = []
        lines.append("# HELP simp_mesh_broker_count Number of registered brokers")
        lines.append("# TYPE simp_mesh_broker_count gauge")
        lines.append(f"simp_mesh_broker_count {len(self._brokers)}")

        with self._lock:
            for broker_id, bm in sorted(self._brokers.items()):
                for key, val in sorted(bm.metrics.items()):
                    safe_key = key.replace(".", "_").replace("-", "_")
                    lines.append(f"# HELP simp_{safe_key} Metric from broker")
                    lines.append(f"# TYPE simp_{safe_key} gauge")
                    label = f'broker_id="{broker_id}"'
                    lines.append(f"simp_{safe_key}{{{label}}} {val}")

                # Also expose metadata
                lines.append(f"# HELP simp_last_updated Last update timestamp")
                lines.append(f"# TYPE simp_last_updated gauge")
                lines.append(f'simp_last_updated{{broker_id="{broker_id}"}} {bm.last_updated}')

        lines.append("")
        return "\n".join(lines)


# ── Verification Block ────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("MetricsCollector Verification")
    print("=" * 60)

    mc = MetricsCollector(simulation_noise=False)

    # 1. Register brokers
    b1 = mc.register_broker("broker_a")
    b2 = mc.register_broker("broker_b")
    b3 = mc.register_broker("broker_c")
    assert len(mc.get_all_broker_ids()) == 3
    print(f"[✓] 3 brokers registered: {mc.get_all_broker_ids()}")

    # 2. Duplicate registration returns existing
    dup = mc.register_broker("broker_a")
    assert dup.broker_id == "broker_a"
    print("[✓] Duplicate registration returns existing")

    # 3. Set metrics
    assert mc.set_metric("broker_a", "cpu_usage_pct", 45.2) is True
    assert mc.set_metric("broker_a", "memory_usage_mb", 1024.0)
    assert mc.set_metric("broker_a", "active_intents", 12)
    assert mc.set_metric("broker_b", "cpu_usage_pct", 72.1)
    assert mc.set_metric("broker_b", "memory_usage_mb", 2048.0)
    assert mc.set_metric("broker_b", "latency_p50_ms", 5.5)
    assert mc.set_metric("broker_c", "cpu_usage_pct", 20.0)
    print(f"[✓] Metrics set on 3 brokers")

    # 4. Unknown broker returns False
    assert mc.set_metric("ghost_broker", "cpu_usage_pct", 50.0) is False
    print("[✓] Unknown broker returns False")

    # 5. Get broker metrics (single)
    bm_a = mc.get_broker_metrics("broker_a")
    assert bm_a is not None
    assert bm_a["metrics"]["cpu_usage_pct"] == 45.2
    assert bm_a["metrics"]["memory_usage_mb"] == 1024.0
    print(f"[✓] get_broker_metrics('broker_a'): {len(bm_a['metrics'])} metrics")

    # 6. Unknown broker returns None
    assert mc.get_broker_metrics("ghost") is None
    print("[✓] Unknown broker returns None")

    # 7. Collect
    collected = mc.collect()
    assert len(collected) == 3
    for bid, bm in collected.items():
        assert bm.last_collected > 0
    print(f"[✓] collect() returned data for {len(collected)} brokers")

    # 8. Aggregate
    agg = mc.aggregate()
    assert "_broker_count" in agg
    assert "_metric_count" in agg
    assert agg["_broker_count"] == 3.0
    # cpu_usage_pct should be (45.2 + 72.1 + 20.0) / 3 = 45.77
    expected_cpu = round((45.2 + 72.1 + 20.0) / 3, 2)
    assert abs(agg["cpu_usage_pct"] - expected_cpu) < 0.1
    print(f"[✓] aggregate(): cpu_usage_pct={agg['cpu_usage_pct']:.2f} (expected ~{expected_cpu})")

    # 9. get_aggregated_metrics alias
    agg2 = mc.get_aggregated_metrics()
    assert agg2["_broker_count"] == 3.0
    print("[✓] get_aggregated_metrics() alias works")

    # 10. Prometheus exposition
    prom = mc.expose_prometheus()
    assert prom.startswith("# HELP")
    assert "simp_cpu_usage_pct" in prom
    assert 'broker_id="broker_a"' in prom
    lines = [l for l in prom.split("\n") if l and not l.startswith("#")]
    # Should have 3 brokers * (N metrics + 1 last_updated) + 1 broker_count = >
    assert len(lines) >= 3  # At least broker_count + per-broker entries
    print(f"[✓] expose_prometheus() → {len(lines)} data lines")
    print("    Sample lines:")
    for line in lines[:4]:
        print(f"      {line}")

    # 11. Simulation noise mode
    mc_noise = MetricsCollector(simulation_noise=True)
    mc_noise.register_broker("test_broker")
    mc_noise.set_metric("test_broker", "cpu_usage_pct", 50.0)
    # Collect applies ±5% noise to stored values
    c1 = mc_noise.collect()
    v1 = c1["test_broker"].metrics["cpu_usage_pct"]
    # Noise means value is no longer exactly 50.0
    assert v1 != 50.0, f"Expected noise to modify value, got {v1}"
    assert 40.0 < v1 < 60.0, f"Value {v1} out of expected range"
    print(f"[✓] Simulation noise: 50.0 → {v1:.4f} (within ±5%)")

    # 12. Thread safety
    import concurrent.futures

    def threaded_set(mc: MetricsCollector, idx: int) -> None:
        bid = f"t_broker_{idx}"
        mc.register_broker(bid)
        mc.set_metric(bid, "cpu_usage_pct", float(idx))

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(threaded_set, mc, i) for i in range(30)]
        concurrent.futures.wait(futures)
    all_ids = mc.get_all_broker_ids()
    thread_ids = [bid for bid in all_ids if bid.startswith("t_broker_")]
    assert len(thread_ids) == 30
    agg3 = mc.aggregate()
    assert agg3["_broker_count"] >= 30
    print(f"[✓] Thread safety: 30 concurrent registrations → {len(thread_ids)} new brokers")

    print()
    print("All MetricsCollector tests PASSED ✓")
