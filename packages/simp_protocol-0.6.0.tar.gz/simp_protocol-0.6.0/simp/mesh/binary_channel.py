"""
Binary Streaming Mesh Channels — T58: Binary/Streaming Mesh Channels

Supports:
- Chunked binary blob transfer (1MB chunks, SHA-256 content-addressed)
- Bidirectional streaming channels for real-time data feeds
- Computer-use screenshots (base64 PNG) via projectx_screenshots channel
- Quantum state vectors from IBM/PennyLane

Channels:
- binary_blobs     — chunked binary transfers
- streams         — bidirectional streaming
- projectx_screenshots — base64 PNG screenshots from ProjectX
- quantum_state_vectors — complex amplitude arrays
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import threading
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

CHUNK_SIZE = 1024 * 1024  # 1 MB per chunk

# ── Blob Transfer ─────────────────────────────────────────────────────────────

@dataclass
class BlobChunk:
    """Single chunk of a binary blob."""
    blob_id: str          # content hash of full blob
    chunk_index: int      # 0-based chunk number
    total_chunks: int
    data_b64: str        # base64-encoded chunk data
    size_bytes: int      # actual size of this chunk (may be < CHUNK_SIZE for last)


@dataclass
class BlobManifest:
    """Metadata for a complete blob transfer."""
    blob_id: str              # SHA-256 of full content
    filename: str
    mime_type: str
    total_size: int           # bytes
    total_chunks: int
    chunk_hashes: List[str]   # SHA-256 of each chunk (in order)
    sender_id: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict) -> "BlobManifest":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


class BinaryChannel:
    """
    Chunked binary blob transfer over the mesh.

    Sender:
        manifest = BinaryChannel.create_manifest(data_bytes, filename, mime_type)
        BinaryChannel.send_manifest(manifest, sender_id)
        for chunk in BinaryChannel.chunk_data(data_bytes):
            BinaryChannel.send_chunk(chunk, sender_id)

    Receiver:
        manifest = BinaryChannel.receive_manifest(blob_id)
        chunks = BinaryChannel.receive_all_chunks(blob_id)
        data = BinaryChannel.assemble(chunks)
        assert SHA256(data) == blob_id  # verify integrity
    """

    def __init__(self, bus=None):
        self._bus = bus
        self._manifests: Dict[str, BlobManifest] = {}
        self._chunks: Dict[str, Dict[int, BlobChunk]] = {}  # blob_id → chunk_index → chunk
        self._lock = threading.RLock()
        self.logger = logging.getLogger("binary.channel")

    @staticmethod
    def compute_blob_id(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    @staticmethod
    def create_manifest(
        data: bytes,
        filename: str,
        mime_type: str = "application/octet-stream",
        sender_id: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Tuple[BlobManifest, List[BlobChunk]]:
        """Split data into chunks and return manifest + chunk list."""
        blob_id = hashlib.sha256(data).hexdigest()
        chunks: List[BlobChunk] = []
        chunk_hashes: List[str] = []
        data_b64 = base64.b64encode(data).decode()
        total_chunks = (len(data_b64) + CHUNK_SIZE - 1) // CHUNK_SIZE

        for i in range(total_chunks):
            start = i * CHUNK_SIZE
            end = min(start + CHUNK_SIZE, len(data_b64))
            chunk_data = data_b64[start:end]
            chunk_bytes = chunk_data.encode()
            chunk_hash = hashlib.sha256(chunk_bytes).hexdigest()
            chunk = BlobChunk(
                blob_id=blob_id,
                chunk_index=i,
                total_chunks=total_chunks,
                data_b64=chunk_data,
                size_bytes=len(chunk_bytes),
            )
            chunks.append(chunk)
            chunk_hashes.append(chunk_hash)

        manifest = BlobManifest(
            blob_id=blob_id,
            filename=filename,
            mime_type=mime_type,
            total_size=len(data),
            total_chunks=total_chunks,
            chunk_hashes=chunk_hashes,
            sender_id=sender_id,
            metadata=metadata or {},
        )
        return manifest, chunks

    @staticmethod
    def create_manifest_and_chunks(
        data: bytes,
        mime_type: str = "application/octet-stream",
    ) -> Tuple[BlobManifest, List["BlobChunk"]]:
        """Alias for create_manifest for backwards compatibility."""
        return BinaryChannel.create_manifest(data, "", mime_type)

    @staticmethod
    def assemble(chunks: List[BlobChunk]) -> bytes:
        """Reassemble chunks into original data."""
        ordered = sorted(chunks, key=lambda c: c.chunk_index)
        data_b64 = "".join(c.data_b64 for c in ordered)
        return base64.b64decode(data_b64)

    def store_manifest(self, manifest: BlobManifest) -> None:
        with self._lock:
            self._manifests[manifest.blob_id] = manifest
            self._chunks[manifest.blob_id] = {}

    def store_chunk(self, chunk: BlobChunk) -> bool:
        """Store a chunk. Returns True when all chunks are present."""
        with self._lock:
            if chunk.blob_id not in self._chunks:
                self._chunks[chunk.blob_id] = {}
            self._chunks[chunk.blob_id][chunk.chunk_index] = chunk

            manifest = self._manifests.get(chunk.blob_id)
            if manifest and len(self._chunks[chunk.blob_id]) >= manifest.total_chunks:
                return True  # all chunks present
        return False

    def get_manifest(self, blob_id: str) -> Optional[BlobManifest]:
        with self._lock:
            return self._manifests.get(blob_id)

    def get_missing_chunks(self, blob_id: str) -> List[int]:
        with self._lock:
            manifest = self._manifests.get(blob_id)
            if not manifest:
                return []
            stored = set(self._chunks.get(blob_id, {}).keys())
            return [i for i in range(manifest.total_chunks) if i not in stored]

    def is_complete(self, blob_id: str) -> bool:
        with self._lock:
            manifest = self._manifests.get(blob_id)
            if not manifest:
                return False
            return len(self._chunks.get(blob_id, {})) >= manifest.total_chunks

    def assemble_stored(self, blob_id: str) -> Optional[bytes]:
        with self._lock:
            manifest = self._manifests.get(blob_id)
            if not manifest:
                return None
            if len(self._chunks.get(blob_id, {})) < manifest.total_chunks:
                return None
            chunks = list(self._chunks[blob_id].values())
        return self.assemble(chunks)

    def verify_integrity(self, blob_id: str) -> bool:
        """Verify that assembled data matches the blob_id."""
        data = self.assemble_stored(blob_id)
        if data is None:
            return False
        return hashlib.sha256(data).hexdigest() == blob_id


# ── Streaming Channel ─────────────────────────────────────────────────────────

class StreamFrame:
    """A single frame in a bidirectional stream."""
    def __init__(
        self,
        stream_id: str,
        frame_index: int,
        data_b64: str = "",
        is_end: bool = False,
        sender_id: str = "",
        data: bytes = None,
    ):
        self.stream_id = stream_id
        self.frame_index = frame_index
        self.data_b64 = data_b64 or (base64.b64encode(data).decode() if data else "")
        self.is_end = is_end
        self.sender_id = sender_id

    @property
    def data(self) -> bytes:
        return base64.b64decode(self.data_b64) if self.data_b64 else b""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "stream_id": self.stream_id,
            "frame_index": self.frame_index,
            "data_b64": self.data_b64,
            "is_end": self.is_end,
            "sender_id": self.sender_id,
        }

    @classmethod
    def from_dict(cls, d: Dict) -> "StreamFrame":
        return cls(
            stream_id=d["stream_id"],
            frame_index=d["frame_index"],
            data_b64=d["data_b64"],
            is_end=d.get("is_end", False),
            sender_id=d.get("sender_id", ""),
        )


class StreamingChannel:
    """
    Bidirectional streaming over the mesh.
    Each stream has a unique stream_id; frames are sent sequentially.
    """

    def __init__(self):
        self._streams: Dict[str, Dict[int, StreamFrame]] = {}
        self._end_markers: set = set()  # stream_ids that have ended
        self._handlers: Dict[str, Callable[[StreamFrame], None]] = {}
        self._lock = threading.RLock()
        self.logger = logging.getLogger("streaming.channel")

    def create_stream(self, stream_id: str = None, sender_id: str = "", topic: str = "") -> str:
        import uuid
        # Support both call styles:
        # 1. create_stream("myid")           → stream_id="myid"
        # 2. create_stream("myid", "sender") → stream_id="myid", sender="sender"
        # 3. create_stream("a","b","topic")  → 3-arg legacy call → generate UUID
        if stream_id is not None and sender_id == "" and topic == "":
            # Likely new-style: single ID being passed
            sid = stream_id
        else:
            # Legacy or 3+ args: generate fresh UUID
            sid = str(uuid.uuid4())[:32]
        with self._lock:
            self._streams[sid] = {}
            return sid

    def receive_frame(self, frame: StreamFrame) -> bool:
        """Store a frame. Returns True if this is the end-of-stream marker."""
        with self._lock:
            if frame.stream_id not in self._streams:
                self._streams[frame.stream_id] = {}
            self._streams[frame.stream_id][frame.frame_index] = frame
            if frame.is_end:
                self._end_markers.add(frame.stream_id)

        # Call handler if registered
        handler = self._handlers.get(frame.stream_id)
        if handler:
            try:
                handler(frame)
            except Exception as exc:
                self.logger.debug(f"Stream handler error: {exc}")
        return frame.is_end

    def get_stream_frames(self, stream_id: str) -> List[StreamFrame]:
        with self._lock:
            frames = self._streams.get(stream_id, {})
            return sorted(frames.values(), key=lambda f: f.frame_index)

    def is_complete(self, stream_id: str) -> bool:
        with self._lock:
            return stream_id in self._end_markers

    def get_next_index(self, stream_id: str) -> int:
        with self._lock:
            frames = self._streams.get(stream_id, {})
            return max([-1] + [f.frame_index for f in frames.values()]) + 1

    def register_handler(self, stream_id: str, handler: Callable[[StreamFrame], None]) -> None:
        with self._lock:
            self._handlers[stream_id] = handler

    def assemble_stream(self, stream_id: str) -> Optional[bytes]:
        """Assemble all frames in a stream into bytes."""
        frames = self.get_stream_frames(stream_id)
        if not frames or not self.is_complete(stream_id):
            return None
        data_b64 = "".join(f.data_b64 for f in sorted(frames, key=lambda f: f.frame_index))
        return base64.b64decode(data_b64)
