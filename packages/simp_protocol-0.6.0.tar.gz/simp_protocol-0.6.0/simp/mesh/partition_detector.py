"""
Mesh Partition Detection — L3-T5

Detects when an agent group becomes unreachable from the rest of the mesh
and triggers rerouting via alternate paths.

Design:
- Runs a connectivity probe every heartbeat_interval (default 10s)
- Builds a connectivity matrix from gossip heartbeats and direct probes
- Runs graph connectivity check (is the mesh still fully connected?)
- If partitions detected, marks affected agents and fires callbacks
- Integration with RoutingTable for automatic reroute
"""

import logging
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from typing import Callable, Dict, List, Optional, Set, Tuple

from .gossip import GossipProtocol
from .routing_table import RoutingTable, get_routing_table

logger = logging.getLogger(__name__)


@dataclass
class PartitionEvent:
    """Record of a detected partition."""
    partition_id: str
    timestamp: float = field(default_factory=time.time)
    partition_agents: List[str] = field(default_factory=list)
    partition_severity: str = "minor"  # "minor", "major", "critical"
    healing_initiated: bool = False
    healed_at: Optional[float] = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ConnectivityProbe:
    """Result of a connectivity probe between two agents."""
    src: str
    dst: str
    reachable: bool
    rtt_ms: float
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return asdict(self)


class PartitionDetector:
    """
    Detects mesh partitions by maintaining a connectivity matrix
    and running graph connectivity checks.

    The mesh is partitioned when there exist two sets of agents such
    that no member of set A can reach any member of set B.
    """

    def __init__(self, agent_id: str,
                 gossip: Optional[GossipProtocol] = None,
                 routing_table: Optional[RoutingTable] = None,
                 heartbeat_interval: float = 10.0,
                 partition_threshold: float = 30.0):
        self.agent_id = agent_id
        self._gossip = gossip
        self._routing_table = routing_table or get_routing_table()
        self._heartbeat_interval = heartbeat_interval
        self._partition_threshold = partition_threshold  # Seconds without heartbeat = partition risk

        # Connectivity matrix: agent_id -> {peer_id -> last_seen}
        self._connectivity: Dict[str, Dict[str, float]] = defaultdict(dict)
        self._lock = threading.RLock()

        # Partition history
        self._partition_history: List[PartitionEvent] = []
        self._current_partition: Optional[PartitionEvent] = None

        # Callbacks
        self._on_partition_detected: Optional[Callable[[List[str], str], None]] = None
        self._on_partition_healed: Optional[Callable[[], None]] = None

        # Threading
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._last_check: float = 0.0
        self._check_count: int = 0

        logger.info("PartitionDetector initialized for %s", agent_id)

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def set_partition_detected_callback(self, cb: Callable[[List[str], str], None]) -> None:
        """Called when partition detected: (partition_agents, severity)."""
        self._on_partition_detected = cb

    def set_partition_healed_callback(self, cb: Callable[[], None]) -> None:
        """Called when partition heals."""
        self._on_partition_healed = cb

    # ------------------------------------------------------------------
    # Connectivity recording
    # ------------------------------------------------------------------

    def record_reachable(self, src: str, dst: str, rtt_ms: float = 0.0) -> None:
        """Record that src can reach dst."""
        with self._lock:
            self._connectivity[src][dst] = time.time()
            self._connectivity[dst][src] = time.time()  # Assume symmetric

    def record_unreachable(self, src: str, dst: str) -> None:
        """Record that src cannot reach dst."""
        with self._lock:
            self._connectivity[src][dst] = 0  # 0 means unreachable
            self._connectivity[dst][src] = 0

    # ------------------------------------------------------------------
    # Graph analysis
    # ------------------------------------------------------------------

    def _build_adjacency(self, now: float) -> Dict[str, Set[str]]:
        """Build adjacency list from connectivity matrix."""
        adj: Dict[str, Set[str]] = defaultdict(set)
        threshold = now - 30.0  # Connections older than 30s are stale

        for src, peers in self._connectivity.items():
            for dst, last_seen in peers.items():
                if last_seen > threshold and last_seen > 0:  # recent AND reachable
                    adj[src].add(dst)
                    adj[dst].add(src)

        # Also add heartbeat info from gossip
        if self._gossip:
            for peer_id in self._gossip.get_peers():
                hb = self._gossip.get_heartbeat(peer_id)
                if hb and (now - hb) < self._partition_threshold:
                    adj[self.agent_id].add(peer_id)
                    adj[peer_id].add(self.agent_id)

        return adj

    def _find_connected_components(self, adj: Dict[str, Set[str]]) -> List[Set[str]]:
        """Find all connected components in the graph."""
        visited: Set[str] = set()
        components: List[Set[str]] = []

        for node in adj:
            if node in visited:
                continue
            # BFS from this node
            component: Set[str] = set()
            queue = [node]
            while queue:
                current = queue.pop(0)
                if current in visited:
                    continue
                visited.add(current)
                component.add(current)
                for neighbor in adj.get(current, set()):
                    if neighbor not in visited:
                        queue.append(neighbor)
            components.append(component)

        return components

    def _check_partition(self) -> Optional[List[str]]:
        """
        Check if the mesh is partitioned.
        Returns list of agents in the smaller partition, or None if not partitioned.
        """
        now = time.time()
        adj = self._build_adjacency(now)

        if len(adj) < 2:
            return None  # Not enough agents to form a partition

        components = self._find_connected_components(adj)

        if len(components) <= 1:
            return None  # Fully connected

        # Find all agents not in our component
        our_component = None
        for comp in components:
            if self.agent_id in comp:
                our_component = comp
                break

        if our_component is None:
            # We're completely isolated
            all_agents = set()
            for comp in components:
                all_agents.update(comp)
            return list(all_agents)

        # All agents not in our component are partitioned from us
        partitioned: Set[str] = set()
        for comp in components:
            if comp is not our_component:
                partitioned.update(comp)

        return list(partitioned) if partitioned else None

    def _determine_severity(self, partitioned_agents: List[str]) -> str:
        """Determine partition severity based on agent count and roles."""
        count = len(partitioned_agents)
        if count >= 5:
            return "critical"
        elif count >= 3:
            return "major"
        else:
            return "minor"

    # ------------------------------------------------------------------
    # Active probe
    # ------------------------------------------------------------------

    def probe_agent(self, agent_id: str) -> bool:
        """
        Actively probe an agent's availability.
        Returns True if reachable.
        Override this in subclasses for actual transport.
        """
        # Default: check gossip heartbeat
        if self._gossip:
            hb = self._gossip.get_heartbeat(agent_id)
            if hb and (time.time() - hb) < self._partition_threshold:
                self.record_reachable(self.agent_id, agent_id)
                return True
        self.record_unreachable(self.agent_id, agent_id)
        return False

    # ------------------------------------------------------------------
    # Check cycle
    # ------------------------------------------------------------------

    def check(self) -> Optional[List[str]]:
        """
        Run one partition detection check.
        Returns list of partitioned agents, or None if fully connected.
        """
        with self._lock:
            partitioned = self._check_partition()
            self._check_count += 1
            self._last_check = time.time()

            if partitioned:
                severity = self._determine_severity(partitioned)
                logger.warning("Mesh PARTITION DETECTED: %d agents unreachable (severity=%s)",
                               len(partitioned), severity)

                # Create partition event
                event = PartitionEvent(
                    partition_id=f"part_{int(time.time())}",
                    partition_agents=partitioned,
                    partition_severity=severity,
                )
                self._partition_history.append(event)
                self._current_partition = event

                # Fire callback
                if self._on_partition_detected:
                    self._on_partition_detected(partitioned, severity)

                # Auto-reroute: remove partitioned agents from routing table
                if self._routing_table:
                    for agent_id in partitioned:
                        removed = self._routing_table.remove_agent_routes(agent_id)
                        if removed > 0:
                            logger.info("Rerouted %d intent types away from partitioned agent %s",
                                        removed, agent_id)

                return partitioned
            else:
                # Check if we just healed
                if self._current_partition is not None:
                    self._current_partition.healed_at = time.time()
                    self._current_partition.healing_initiated = True
                    logger.info("Mesh partition HEALED after %.1fs",
                                self._current_partition.healed_at - self._current_partition.timestamp)
                    if self._on_partition_healed:
                        self._on_partition_healed()
                    self._current_partition = None

                return None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start periodic partition detection."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._detection_loop,
            daemon=True,
            name=f"PartitionDetect-{self.agent_id}",
        )
        self._thread.start()
        logger.info("PartitionDetector started for %s", self.agent_id)

    def stop(self) -> None:
        """Stop partition detection."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("PartitionDetector stopped for %s", self.agent_id)

    def _detection_loop(self) -> None:
        """Main detection loop."""
        while self._running:
            try:
                self.check()
            except Exception as e:
                logger.error("Partition check error: %s", e)
            time.sleep(self._heartbeat_interval)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_status(self) -> dict:
        """Get detector status."""
        with self._lock:
            return {
                "agent_id": self.agent_id,
                "running": self._running,
                "known_agents": len(self._connectivity),
                "partition_detected": self._current_partition is not None,
                "last_check": self._last_check,
                "check_count": self._check_count,
                "partition_history_count": len(self._partition_history),
                "current_partition": self._current_partition.to_dict() if self._current_partition else None,
            }

    def get_partition_history(self) -> List[dict]:
        with self._lock:
            return [e.to_dict() for e in self._partition_history[-50:]]  # Last 50 events
