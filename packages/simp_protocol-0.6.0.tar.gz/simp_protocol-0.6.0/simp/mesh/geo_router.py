"""
Geo-Aware Mesh Routing — L3-T3

GeoRouter wraps a MeshRoutingTable (or RoutingTable) to provide region-aware
routing. Agents are tagged with a region string (e.g. "us-east-1", "eu-west-2").
When routing an intent, the GeoRouter prefers agents in the same region as the
source, falling back to other regions according to a configurable proximity list.

Design:
- Wraps any routing table that provides find_routes(intent_type) -> list[agent_id]
- Agents tagged via tag_agent(agent_id, region)
- route_intent(intent_type, source_region) returns nearest capable agent
- Nearest = same region first, then by proximity list order, then any remaining
- Thread-safe reads/writes
- Fully stateless aside from region map (no background threads needed)
"""

import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol, Sequence

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Protocol so GeoRouter works with any routing table
# ---------------------------------------------------------------------------

class RoutingTableProtocol(Protocol):
    """Minimal interface expected by GeoRouter."""

    def find_routes(self, intent_type: str) -> List[str]:
        """Return agent IDs capable of handling intent_type."""
        ...

    def remove_agent_routes(self, agent_id: str) -> int:
        """Remove all routes for an agent. Returns count removed."""
        ...

    def add_manual_route(self, intent_type: str, agent_id: str,
                         endpoint: Optional[str] = None,
                         reputation: float = 0.5) -> None:
        """Manually add a route."""
        ...


# ---------------------------------------------------------------------------
# GeoRouter
# ---------------------------------------------------------------------------

@dataclass
class RegionProximity:
    """
    Describes region proximity for fallback routing.

    ``order`` is a list of region names. When routing, the GeoRouter
    checks regions in the order they appear in this list (after the
    source region itself).
    """
    name: str
    order: List[str]  # e.g. ["us-east-1", "us-west-2", "eu-west-1"]


class GeoRouter:
    """
    Geo-aware mesh router.

    Wraps a routing table and adds region awareness. Agents are tagged
    with a region via ``tag_agent()``. When routing an intent:

    1. Find all capable agents from the underlying routing table.
    2. Prefer agents in the same region as the source.
    3. If none available, fall back to regions in proximity order.
    4. If still none, return any capable agent from any region.

    Thread-safe via ``threading.RLock``.
    """

    def __init__(self, routing_table: RoutingTableProtocol,
                 default_proximity: Optional[List[str]] = None):
        """
        Args:
            routing_table: Any object implementing ``find_routes()``,
                ``remove_agent_routes()`` and ``add_manual_route()``.
            default_proximity: Global fallback region order used when a
                source region has no explicit ``RegionProximity``.
        """
        self._routing_table = routing_table
        self._lock = threading.RLock()

        # agent_id -> region
        self._agent_regions: Dict[str, str] = {}

        # region -> agent_ids (inverse index for fast lookups)
        self._region_agents: Dict[str, List[str]] = {}

        # region -> proximity order (optional per-region)
        self._proximity: Dict[str, RegionProximity] = {}

        self._default_proximity: List[str] = default_proximity or []
        logger.info("GeoRouter initialized with %d proximity entries",
                     len(self._proximity))

    # ------------------------------------------------------------------
    # Region tagging
    # ------------------------------------------------------------------

    def tag_agent(self, agent_id: str, region: str) -> None:
        """
        Tag an agent with a region.

        If the agent already has a region it is overwritten.
        """
        with self._lock:
            # Remove from old region index
            old_region = self._agent_regions.get(agent_id)
            if old_region is not None and old_region in self._region_agents:
                self._region_agents[old_region] = [
                    a for a in self._region_agents[old_region] if a != agent_id
                ]
                if not self._region_agents[old_region]:
                    del self._region_agents[old_region]

            # Add to new region
            self._agent_regions[agent_id] = region
            if region not in self._region_agents:
                self._region_agents[region] = []
            self._region_agents[region].append(agent_id)

            logger.debug("Tagged agent %s -> region %s", agent_id, region)

    def untag_agent(self, agent_id: str) -> Optional[str]:
        """
        Remove an agent's region tag.

        Returns the previous region, or None if the agent was not tagged.
        """
        with self._lock:
            region = self._agent_regions.pop(agent_id, None)
            if region is not None and region in self._region_agents:
                self._region_agents[region] = [
                    a for a in self._region_agents[region] if a != agent_id
                ]
                if not self._region_agents[region]:
                    del self._region_agents[region]
            return region

    def get_region(self, agent_id: str) -> Optional[str]:
        """Return the region an agent is tagged with, or None."""
        with self._lock:
            return self._agent_regions.get(agent_id)

    # ------------------------------------------------------------------
    # Region proximity configuration
    # ------------------------------------------------------------------

    def set_proximity(self, region: str, order: List[str]) -> None:
        """
        Set fallback proximity order for a specific source region.

        Example::

            router.set_proximity("us-east-1", ["us-east-1", "us-west-2", "eu-west-1"])

        The source region itself should normally be first so that same-region
        routing is preferred.
        """
        with self._lock:
            self._proximity[region] = RegionProximity(name=region, order=order)
            logger.debug("Set proximity for %s: %s", region, order)

    def get_proximity(self, region: str) -> List[str]:
        """Get the proximity order for a region (falling back to default)."""
        with self._lock:
            prox = self._proximity.get(region)
            if prox is not None:
                return list(prox.order)
            return list(self._default_proximity)

    # ------------------------------------------------------------------
    # Routing
    # ------------------------------------------------------------------

    def route_intent(self, intent_type: str,
                     source_region: str) -> Optional[str]:
        """
        Route an intent to the nearest capable agent based on region.

        Strategy:
        1. Find all capable agents via the routing table.
        2. If any are in ``source_region``, return one (round-robin
           across equal-priority agents would be done by the caller).
        3. Otherwise, walk the proximity list for ``source_region``.
        4. If nothing found, return any capable agent from any region.

        Returns an agent ID or None if no capable agent exists.
        """
        capable_agents = self._find_capable_agents(intent_type)
        if not capable_agents:
            return None

        return self._pick_nearest(capable_agents, source_region)

    def route_intents(self, intent_type: str,
                      source_region: str,
                      count: int = 1) -> List[str]:
        """
        Route an intent to the *count* nearest capable agents.

        Useful for multi-agent fan-out or quorum-based execution.
        """
        capable_agents = self._find_capable_agents(intent_type)
        if not capable_agents:
            return []

        ordered = self._order_by_proximity(capable_agents, source_region)
        return ordered[:count]

    def find_capable_in_region(self, intent_type: str,
                               region: str) -> List[str]:
        """Find all capable agents in a specific region."""
        capable = self._find_capable_agents(intent_type)
        with self._lock:
            return [a for a in capable if self._agent_regions.get(a) == region]

    def get_all_regions(self) -> Dict[str, List[str]]:
        """Return a mapping of region -> list of agent IDs."""
        with self._lock:
            return {r: list(agents) for r, agents in self._region_agents.items()}

    def get_stats(self) -> dict:
        """Return statistics about the geo router state."""
        with self._lock:
            return {
                "total_tagged_agents": len(self._agent_regions),
                "total_regions": len(self._region_agents),
                "regions": list(self._region_agents.keys()),
                "agents_per_region": {
                    r: len(agents) for r, agents in self._region_agents.items()
                },
                "proximity_configs": len(self._proximity),
            }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_capable_agents(self, intent_type: str) -> List[str]:
        """Query the underlying routing table for capable agents."""
        return self._routing_table.find_routes(intent_type)

    def _pick_nearest(self, agent_ids: List[str],
                      source_region: str) -> Optional[str]:
        """
        Pick the nearest agent from ``agent_ids`` relative to ``source_region``.

        "Nearest" defined by:
        1. Same region as source (first match returned).
        2. Fallback through proximity order.
        3. Any remaining agent if proximity list is exhausted.
        """
        ordered = self._order_by_proximity(agent_ids, source_region)
        return ordered[0] if ordered else None

    def _order_by_proximity(self, agent_ids: List[str],
                            source_region: str) -> List[str]:
        """
        Order agent IDs by geo-proximity to ``source_region``.

        Returns a list where agents in the same region come first,
        then agents in regions listed by proximity order, then any
        remaining agents in other regions.
        """
        with self._lock:
            # Build region -> [agents] mapping for the candidate set
            candidates_by_region: Dict[str, List[str]] = {}
            for agent_id in agent_ids:
                region = self._agent_regions.get(agent_id, "")
                if region not in candidates_by_region:
                    candidates_by_region[region] = []
                candidates_by_region[region].append(agent_id)

            # Build ordered list
            ordered: List[str] = []
            seen_regions: set = set()

            # 1. Same region
            if source_region in candidates_by_region:
                ordered.extend(candidates_by_region[source_region])
                seen_regions.add(source_region)

            # 2. Proximity fallback
            prox_order = self.get_proximity(source_region)
            for prox_region in prox_order:
                if prox_region in candidates_by_region and prox_region not in seen_regions:
                    ordered.extend(candidates_by_region[prox_region])
                    seen_regions.add(prox_region)

            # 3. Any remaining regions
            for region, agents in candidates_by_region.items():
                if region not in seen_regions:
                    ordered.extend(agents)
                    seen_regions.add(region)

            return ordered
