"""
Agent Capability Registry — L3-T1

Central registry where agents publish their capabilities and brokers
query by capability rather than agent ID. Built on top of existing
IntentMeshRouter capability advertisement infrastructure.

Design:
- In-memory registry with SQLite persistence for broker restart survival
- TTL-based expiration (default 300s, agents must re-publish)
- Query by capability returns sorted list of capable agents (by reputation)
- Supports capability subtyping: "risk_assessment.var" matches "risk_assessment.*"
- Thread-safe reads/writes
"""

import json
import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any

logger = logging.getLogger(__name__)


@dataclass
class CapabilityEntry:
    """A single capability registration from an agent."""
    agent_id: str
    capability: str           # e.g. "risk_assessment", "trade_execution.spot"
    endpoint: Optional[str] = None  # Where to route intents for this agent
    reputation: float = 0.5   # 0.0 - 1.0
    ttl_seconds: int = 300    # Time-to-live before expiration
    published_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    metadata: Dict = field(default_factory=dict)

    def is_expired(self) -> bool:
        return (time.time() - self.last_seen) > self.ttl_seconds

    def touch(self) -> None:
        self.last_seen = time.time()

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "capability": self.capability,
            "endpoint": self.endpoint,
            "reputation": self.reputation,
            "ttl_seconds": self.ttl_seconds,
            "published_at": datetime.fromtimestamp(self.published_at, tz=timezone.utc).isoformat(),
            "last_seen": datetime.fromtimestamp(self.last_seen, tz=timezone.utc).isoformat(),
            "metadata": self.metadata,
            "expired": self.is_expired(),
        }


class CapabilityRegistry:
    """
    Thread-safe capability registry with SQLite persistence.

    Agents call register() to publish their capabilities.
    Brokers call query() to find agents that can handle an intent.
    """

    _CREATE_TABLE = """
        CREATE TABLE IF NOT EXISTS capabilities (
            agent_id TEXT NOT NULL,
            capability TEXT NOT NULL,
            endpoint TEXT,
            reputation REAL NOT NULL DEFAULT 0.5,
            ttl_seconds INTEGER NOT NULL DEFAULT 300,
            published_at REAL NOT NULL,
            last_seen REAL NOT NULL,
            metadata TEXT DEFAULT '{}',
            PRIMARY KEY (agent_id, capability)
        );
    """
    _INSERT = """
        INSERT OR REPLACE INTO capabilities
            (agent_id, capability, endpoint, reputation, ttl_seconds,
             published_at, last_seen, metadata)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """
    _DELETE = "DELETE FROM capabilities WHERE agent_id = ? AND capability = ?"
    _DELETE_AGENT = "DELETE FROM capabilities WHERE agent_id = ?"
    _QUERY_CAP = "SELECT * FROM capabilities WHERE capability = ? OR capability LIKE ?"
    _QUERY_AGENT = "SELECT * FROM capabilities WHERE agent_id = ?"
    _ALL = "SELECT * FROM capabilities"
    _EXPIRED = "SELECT * FROM capabilities WHERE last_seen < ? - ttl_seconds"
    _PURGE_EXPIRED = "DELETE FROM capabilities WHERE last_seen < ? - ttl_seconds"

    def __init__(self, db_path: Optional[str] = None):
        self._db_path = db_path or str(Path.home() / ".simp" / "capability_registry.db")
        self._lock = threading.RLock()
        # Cache in-memory for fast lookups: capability -> list of entries
        self._cache: Dict[str, List[CapabilityEntry]] = {}
        self._agent_cache: Dict[str, List[CapabilityEntry]] = {}
        self._dirty = False
        # For :memory: databases, hold a persistent connection
        self._persistent_conn: Optional[sqlite3.Connection] = None
        self._init_db()
        logger.info("CapabilityRegistry initialized at %s", self._db_path)

    def _init_db(self) -> None:
        if self._db_path == ":memory:":
            # For in-memory DBs, hold a persistent connection so data survives
            self._persistent_conn = sqlite3.connect(":memory:", timeout=5.0)
            conn = self._persistent_conn
        else:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(self._db_path, timeout=5.0)
        try:
            conn.execute(self._CREATE_TABLE)
            conn.commit()
            # Load into cache
            cursor = conn.execute(self._ALL)
            for row in cursor.fetchall():
                entry = self._row_to_entry(row)
                self._add_to_cache(entry)
        finally:
            if self._db_path != ":memory:":
                conn.close()

    def _get_conn(self) -> sqlite3.Connection:
        """Get a database connection. For :memory:, returns the persistent one."""
        if self._persistent_conn is not None:
            return self._persistent_conn
        return sqlite3.connect(self._db_path, timeout=5.0)

    def _close_conn(self, conn: sqlite3.Connection) -> None:
        """Close a connection unless it's the persistent in-memory one."""
        if conn is not self._persistent_conn:
            conn.close()

    def register(self, agent_id: str, capability: str, endpoint: Optional[str] = None,
                 reputation: Optional[float] = None, ttl_seconds: Optional[int] = None,
                 metadata: Optional[dict] = None) -> None:
        """Register or refresh a capability for an agent."""
        with self._lock:
            now = time.time()
            entry = CapabilityEntry(
                agent_id=agent_id,
                capability=capability,
                endpoint=endpoint,
                reputation=reputation if reputation is not None else 0.5,
                ttl_seconds=ttl_seconds or 300,
                published_at=now,
                last_seen=now,
                metadata=metadata or {},
            )
            conn = self._get_conn()
            try:
                conn.execute(self._INSERT, (
                    entry.agent_id, entry.capability, entry.endpoint,
                    entry.reputation, entry.ttl_seconds,
                    entry.published_at, entry.last_seen,
                    json.dumps(entry.metadata),
                ))
                conn.commit()
            finally:
                self._close_conn(conn)
            self._add_to_cache(entry)
            self._dirty = True
            logger.debug("Registered %s -> %s (ttl=%ds)", agent_id, capability, entry.ttl_seconds)

    def register_many(self, agent_id: str, capabilities: List[str],
                      endpoint: Optional[str] = None, reputation: Optional[float] = None,
                      ttl_seconds: Optional[int] = None) -> None:
        """Register multiple capabilities for an agent."""
        for cap in capabilities:
            self.register(agent_id, cap, endpoint, reputation, ttl_seconds)

    def unregister(self, agent_id: str, capability: Optional[str] = None) -> None:
        """Remove a specific capability or all capabilities for an agent."""
        with self._lock:
            conn = self._get_conn()
            try:
                if capability:
                    conn.execute(self._DELETE, (agent_id, capability))
                    self._remove_from_cache(agent_id, capability)
                else:
                    conn.execute(self._DELETE_AGENT, (agent_id,))
                    self._remove_agent_from_cache(agent_id)
                conn.commit()
            finally:
                self._close_conn(conn)
            self._dirty = True

    def query(self, capability: str, min_reputation: float = 0.0,
              include_expired: bool = False) -> List[CapabilityEntry]:
        """
        Find agents that can handle a capability.

        Supports wildcard: "risk_assessment.*" matches "risk_assessment.var"
        """
        with self._lock:
            results: List[CapabilityEntry] = []
            # Check exact match
            if capability in self._cache:
                results.extend(self._cache[capability])
            # Check wildcard match
            if capability.endswith(".*"):
                prefix = capability[:-2]  # Remove ".*"
                for cap, entries in self._cache.items():
                    if cap.startswith(prefix) and cap != capability:
                        results.extend(entries)
            # Check glob: if query has no wildcard, also check for subtype matches
            if "*" not in capability:
                for cap, entries in self._cache.items():
                    if cap.startswith(capability + "."):
                        results.extend(entries)

            # Filter expired unless asked
            if not include_expired:
                results = [e for e in results if not e.is_expired()]

            # Filter by reputation
            results = [e for e in results if e.reputation >= min_reputation]

            # Sort by reputation descending
            results.sort(key=lambda e: e.reputation, reverse=True)

            return results

    def get_agent_capabilities(self, agent_id: str) -> List[CapabilityEntry]:
        """Get all capabilities for a specific agent."""
        with self._lock:
            return list(self._agent_cache.get(agent_id, []))

    def list_agents(self) -> List[str]:
        """List all agents that have at least one capability registered."""
        with self._lock:
            return list(self._agent_cache.keys())

    def list_capabilities(self) -> List[str]:
        """List all known capability types."""
        with self._lock:
            return list(self._cache.keys())

    def get_stats(self) -> dict:
        """Get registry statistics."""
        with self._lock:
            total = sum(len(entries) for entries in self._cache.values())
            expired = sum(
                1 for entries in self._cache.values()
                for e in entries if e.is_expired()
            )
            return {
                "total_registrations": total,
                "active_registrations": total - expired,
                "expired_registrations": expired,
                "unique_agents": len(self._agent_cache),
                "unique_capabilities": len(self._cache),
                "db_path": self._db_path,
            }

    def purge_expired(self) -> int:
        """Remove expired entries from DB and cache. Returns count removed."""
        with self._lock:
            conn = self._get_conn()
            try:
                cursor = conn.execute(self._EXPIRED, (time.time(),))
                expired = cursor.fetchall()
                conn.execute(self._PURGE_EXPIRED, (time.time(),))
                conn.commit()
            finally:
                self._close_conn(conn)

            for row in expired:
                entry = self._row_to_entry(row)
                self._remove_from_cache(entry.agent_id, entry.capability)

            if expired:
                logger.info("Purged %d expired capability registrations", len(expired))
            return len(expired)

    def _add_to_cache(self, entry: CapabilityEntry) -> None:
        """Add entry to in-memory caches."""
        # Capability index
        if entry.capability not in self._cache:
            self._cache[entry.capability] = []
        # Replace existing entry for same agent+capability
        existing = [e for e in self._cache[entry.capability] if e.agent_id != entry.agent_id]
        existing.append(entry)
        self._cache[entry.capability] = existing

        # Agent index
        if entry.agent_id not in self._agent_cache:
            self._agent_cache[entry.agent_id] = []
        existing_agent = [e for e in self._agent_cache[entry.agent_id] if e.capability != entry.capability]
        existing_agent.append(entry)
        self._agent_cache[entry.agent_id] = existing_agent

    def _remove_from_cache(self, agent_id: str, capability: str) -> None:
        """Remove a specific entry from cache."""
        if capability in self._cache:
            self._cache[capability] = [e for e in self._cache[capability] if e.agent_id != agent_id]
            if not self._cache[capability]:
                del self._cache[capability]

        if agent_id in self._agent_cache:
            self._agent_cache[agent_id] = [e for e in self._agent_cache[agent_id] if e.capability != capability]
            if not self._agent_cache[agent_id]:
                del self._agent_cache[agent_id]

    def _remove_agent_from_cache(self, agent_id: str) -> None:
        """Remove all entries for an agent from cache."""
        if agent_id in self._agent_cache:
            caps = [e.capability for e in self._agent_cache[agent_id]]
            for cap in caps:
                if cap in self._cache:
                    self._cache[cap] = [e for e in self._cache[cap] if e.agent_id != agent_id]
                    if not self._cache[cap]:
                        del self._cache[cap]
            del self._agent_cache[agent_id]

    @staticmethod
    def _row_to_entry(row: tuple) -> CapabilityEntry:
        return CapabilityEntry(
            agent_id=row[0],
            capability=row[1],
            endpoint=row[2],
            reputation=row[3],
            ttl_seconds=row[4],
            published_at=row[5],
            last_seen=row[6],
            metadata=json.loads(row[7]) if row[7] else {},
        )

    def to_dict(self) -> dict:
        """Full serializable dump of registry."""
        return {
            "agents": {
                aid: [e.to_dict() for e in entries]
                for aid, entries in self._agent_cache.items()
            },
            "capabilities": {
                cap: [e.to_dict() for e in entries]
                for cap, entries in self._cache.items()
            },
            "stats": self.get_stats(),
        }


# ── Model Observer ────────────────────────────────────────────────────────────

class ModelObserver:
    """
    Integrates ModelGateway health stats into the CapabilityRegistry.

    Registers each specialist model as a capability under the "model-gateway"
    agent so agents can discover available models via the registry.
    Runs a background thread that periodically pings models (every 60s) and
    refreshes TTLs — when a specialist model goes offline its registry entry
    expires after ttl_seconds without a refresh (default 90s).
    """

    def __init__(self, registry: CapabilityRegistry, gateway, poll_interval: int = 60):
        self._registry = registry
        self._gateway = gateway
        self._poll_interval = poll_interval
        self._lock = threading.RLock()
        self._health: Dict[str, Any] = {}
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def register_models(self) -> None:
        """Register all 6 models as capabilities under model-gateway agent."""
        health = self._gateway.health_check()
        self._health = health

        models = self._gateway.list_models()
        for key, cfg in models.items():
            model_health = health["models"].get(key, False)
            metadata = {
                "model_key": key,
                "model_name": cfg["model"],
                "available": model_health,
                "timeout": cfg.get("timeout", 90),
                "context_window": cfg.get("context_window", 2048),
                "intent_types": self._intent_types_for(key),
            }
            self._registry.register(
                agent_id="model-gateway",
                capability=f"model.{key}",
                endpoint=f"model://{key}",
                reputation=1.0,   # models start at max reputation; lowered on failure
                ttl_seconds=90,
                metadata=metadata,
            )
        logger.info("[ModelObserver] registered %d models", len(models))

    def start(self) -> None:
        """Start background health polling thread."""
        with self._lock:
            if self._running:
                return
            self._running = True
            self._thread = threading.Thread(target=self._poll_loop, daemon=True)
            self._thread.start()
            logger.info("[ModelObserver] polling started (interval=%ds)", self._poll_interval)

    def stop(self) -> None:
        """Stop background polling thread."""
        with self._lock:
            self._running = False
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
            logger.info("[ModelObserver] polling stopped")

    def get_model_health(self) -> Dict[str, Any]:
        """Return current model health status from last poll."""
        with self._lock:
            return self._health.copy() if self._health else self._gateway.health_check()

    def get_health_by_key(self, model_key: str) -> bool:
        """Return whether a specific model is available."""
        health = self.get_model_health()
        return health.get("models", {}).get(model_key, False)

    def _poll_loop(self) -> None:
        """Background loop: ping models and refresh registry entries."""
        while True:
            try:
                self._refresh()
            except Exception as exc:
                logger.warning("[ModelObserver] poll error: %s", exc)
            # Sleep in small increments so stop() is responsive
            for _ in range(self._poll_interval):
                if not self._running:
                    return
                time.sleep(1)

    def _refresh(self) -> None:
        """Ping all models and update registry entries with fresh TTL + metadata."""
        health = self._gateway.health_check()
        models = self._gateway.list_models()

        with self._lock:
            self._health = health

        for key, cfg in models.items():
            model_available = health["models"].get(key, False)
            metadata = {
                "model_key": key,
                "model_name": cfg["model"],
                "available": model_available,
                "timeout": cfg.get("timeout", 90),
                "context_window": cfg.get("context_window", 2048),
                "intent_types": self._intent_types_for(key),
            }
            # Re-register with fresh TTL; if model is down, entry still gets refreshed
            # but availability=false is visible in metadata so callers can check
            self._registry.register(
                agent_id="model-gateway",
                capability=f"model.{key}",
                endpoint=f"model://{key}",
                reputation=1.0,
                ttl_seconds=90,
                metadata=metadata,
            )

    @staticmethod
    def _intent_types_for(model_key: str) -> List[str]:
        """Map model key to the intent types it handles."""
        mapping = {
            "legal": ["legal", "contract", "sec", "law", "llc", "corp", "83b"],
            "threat": ["threat", "security", "attack", "vulnerability", "brp"],
            "trading": ["trade", "arb", "signal", "market", "portfolio"],
            "orchestration": ["orchestrat", "agent", "task", "coordinate", "projectx"],
            "coordination": ["coordinate", "multi-agent", "dispatch"],
            "general": ["general", "fallback"],
        }
        return mapping.get(model_key, [])


# Module-level singleton
_registry: Optional[CapabilityRegistry] = None
_registry_lock = threading.Lock()
_model_observer: Optional[ModelObserver] = None
_observer_lock = threading.Lock()


def get_capability_registry(db_path: Optional[str] = None) -> CapabilityRegistry:
    """Get or create the singleton CapabilityRegistry."""
    global _registry
    if _registry is None:
        with _registry_lock:
            if _registry is None:
                _registry = CapabilityRegistry(db_path)
    return _registry


def get_model_observer() -> Optional[ModelObserver]:
    """Return the active ModelObserver instance (if started)."""
    global _model_observer
    return _model_observer


def register_model_gateway(
    gateway,
    registry: Optional[CapabilityRegistry] = None,
    poll_interval: int = 60,
) -> ModelObserver:
    """
    Wire a ModelGateway into the CapabilityRegistry.

    Creates a ModelObserver, registers all 6 models as capabilities under
    "model-gateway", and starts background health polling.

    Args:
        gateway: ModelGateway instance (or get_model_gateway() result)
        registry: Optional CapabilityRegistry; uses singleton if not given
        poll_interval: Seconds between health polls (default 60)

    Returns:
        ModelObserver instance (also stored at module level)
    """
    reg = registry or get_capability_registry()
    observer = ModelObserver(reg, gateway, poll_interval=poll_interval)
    observer.register_models()
    observer.start()

    global _model_observer
    with _observer_lock:
        _model_observer = observer

    return observer
