"""
Intent Escalation Chain — Level 3 Mesh Protocol

When an agent fails an intent, it escalates to its supervisor agent.
The supervisor can retry, delegate further, or escalate to its own supervisor.

Escalation is bounded by ``MAX_DEPTH = 5`` to prevent infinite loops.

Tracks the full escalation path each intent takes through the agent hierarchy.

Thread-safe via RLock.
"""

import logging
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class EscalationChain:
    """Intent escalation chain for failed intents.

    Agents are organized in a supervisor hierarchy. When an agent cannot
    handle an intent, it escalates to its supervisor, which can then
    re-delegate, resolve, or escalate further up the chain.

    Escalation is bounded at ``MAX_DEPTH = 5`` — beyond this, the
    intent is marked as ``max_depth_exceeded`` and must be resolved
    out-of-band.

    Thread-safe: all mutable state guarded by ``_lock``.
    """

    MAX_DEPTH: int = 5

    def __init__(self) -> None:
        self._lock = threading.RLock()

        # agent_id -> supervisor_id
        self._supervisors: Dict[str, str] = {}

        # intent_id -> list of (agent_id, reason, timestamp) for escalation path
        self._escalation_paths: Dict[str, List[Dict[str, Any]]] = {}

        # intent_id -> resolution record (if resolved)
        self._resolutions: Dict[str, Dict[str, Any]] = {}

        logger.info("EscalationChain initialized (MAX_DEPTH=%d)", self.MAX_DEPTH)

    # ------------------------------------------------------------------
    # Agent registration
    # ------------------------------------------------------------------

    def register_agent(self, agent_id: str, supervisor_id: str) -> None:
        """Set the supervisor for an agent.

        Args:
            agent_id: The agent to register.
            supervisor_id: The agent's direct supervisor.
        """
        with self._lock:
            self._supervisors[agent_id] = supervisor_id
            logger.debug("Agent %s -> supervisor %s", agent_id, supervisor_id)

    # ------------------------------------------------------------------
    # Escalation
    # ------------------------------------------------------------------

    def escalate(self, intent_id: str, agent_id: str, reason: str) -> Optional[str]:
        """Escalate an intent from ``agent_id`` to its supervisor.

        Records the escalation step in the chain. Returns the supervisor
        ID that the intent was escalated to, or ``None`` if:
          - The agent has no registered supervisor.
          - The max escalation depth (5) has been reached.

        Args:
            intent_id: The intent being escalated.
            agent_id: The agent that is escalating.
            reason: Why the intent is being escalated.

        Returns:
            The supervisor ID, or ``None`` if escalation cannot proceed.
        """
        with self._lock:
            supervisor = self._supervisors.get(agent_id)
            if supervisor is None:
                logger.warning(
                    "Escalation blocked: %s has no supervisor (intent=%s)",
                    agent_id,
                    intent_id,
                )
                return None

            # Initialize path if new
            if intent_id not in self._escalation_paths:
                self._escalation_paths[intent_id] = []

            path = self._escalation_paths[intent_id]

            # Check max depth
            if len(path) >= self.MAX_DEPTH:
                logger.error(
                    "Escalation max depth (%d) reached for intent %s from %s",
                    self.MAX_DEPTH,
                    intent_id,
                    agent_id,
                )
                # Mark the resolution as max depth exceeded
                self._resolutions[intent_id] = {
                    "intent_id": intent_id,
                    "status": "max_depth_exceeded",
                    "supervisor": supervisor,
                    "depth": len(path) + 1,
                    "reason": reason,
                    "timestamp": time.time(),
                }
                return None

            # Record escalation step
            step = {
                "intent_id": intent_id,
                "from_agent": agent_id,
                "to_agent": supervisor,
                "reason": reason,
                "timestamp": time.time(),
            }
            path.append(step)
            logger.warning(
                "Escalation: %s -> %s (intent=%s, depth=%d, reason=%s)",
                agent_id,
                supervisor,
                intent_id,
                len(path),
                reason,
            )

            return supervisor

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_escalation_path(self, intent_id: str) -> List[Dict[str, Any]]:
        """Return the chain of escalations an intent has passed through.

        Returns a list of ``{intent_id, from_agent, to_agent, reason, timestamp}``
        dicts ordered from first escalation to most recent.
        """
        with self._lock:
            return list(self._escalation_paths.get(intent_id, []))

    def get_supervisor(self, agent_id: str) -> Optional[str]:
        """Return the supervisor for an agent.

        Returns ``None`` if the agent has no registered supervisor.
        """
        with self._lock:
            return self._supervisors.get(agent_id)

    def get_all_agents(self) -> Dict[str, str]:
        """Return a dict of {agent_id: supervisor_id} for all registered agents."""
        with self._lock:
            return dict(self._supervisors)

    # ------------------------------------------------------------------
    # Resolution
    # ------------------------------------------------------------------

    def resolve(self, intent_id: str, resolution: str) -> Optional[Dict[str, Any]]:
        """Mark an intent as resolved at the current escalation level.

        Args:
            intent_id: The intent being resolved.
            resolution: Resolution description (e.g., "retried_on_child", "approved_by_supervisor").

        Returns:
            The resolution record, or ``None`` if the intent was not
            in any escalation path.
        """
        with self._lock:
            if intent_id not in self._escalation_paths:
                logger.warning("resolve: unknown intent_id %s (no escalation path)", intent_id)
                return None

            path = self._escalation_paths[intent_id]
            last_step = path[-1] if path else None

            record = {
                "intent_id": intent_id,
                "status": "resolved",
                "resolution": resolution,
                "total_escalations": len(path),
                "last_supervisor": last_step["to_agent"] if last_step else None,
                "timestamp": time.time(),
            }
            self._resolutions[intent_id] = record
            del self._escalation_paths[intent_id]

            logger.info(
                "Intent %s resolved: %s (escalations: %d)",
                intent_id,
                resolution,
                len(path),
            )
            return record

    def get_resolution(self, intent_id: str) -> Optional[Dict[str, Any]]:
        """Return the resolution record for an intent, if resolved."""
        with self._lock:
            return self._resolutions.get(intent_id)

    # ------------------------------------------------------------------
    # Agent hierarchy queries
    # ------------------------------------------------------------------

    def get_leaf_agents(self) -> List[str]:
        """Return agents that are not supervisors for anyone else.

        Leaf agents are those who have no registered subordinates.
        """
        with self._lock:
            supervisors = set(self._supervisors.values())
            all_agents = set(self._supervisors.keys())
            return [a for a in all_agents if a not in supervisors]

    def get_top_level_agents(self) -> List[str]:
        """Return agents that have no supervisor (top of chain)."""
        with self._lock:
            all_agents = set(self._supervisors.keys())
            all_supervisors = set(self._supervisors.values())
            return [a for a in all_agents if a not in all_supervisors]

    def get_subordinates(self, supervisor_id: str) -> List[str]:
        """Return all agents that report to a given supervisor."""
        with self._lock:
            return [aid for aid, sid in self._supervisors.items() if sid == supervisor_id]

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_status(self) -> Dict[str, Any]:
        """Return status dict with operational metrics."""
        with self._lock:
            return {
                "registered_agents": len(self._supervisors),
                "active_escalations": len(self._escalation_paths),
                "resolved_intents": len(self._resolutions),
                "max_depth": self.MAX_DEPTH,
                "leaf_agents": self.get_leaf_agents(),
                "top_level_agents": self.get_top_level_agents(),
            }


# ---------------------------------------------------------------------------
# Verification block
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(message)s")

    chain = EscalationChain()

    # Register agent hierarchy
    chain.register_agent("agent-leaf-1", "agent-mid-1")
    chain.register_agent("agent-leaf-2", "agent-mid-1")
    chain.register_agent("agent-leaf-3", "agent-mid-2")
    chain.register_agent("agent-mid-1", "agent-root")
    chain.register_agent("agent-mid-2", "agent-root")

    assert chain.get_supervisor("agent-leaf-1") == "agent-mid-1"
    assert chain.get_supervisor("agent-mid-1") == "agent-root"
    assert chain.get_supervisor("agent-root") is None
    print("Supervisor hierarchy registered ✓")

    # Get leaf agents
    leaves = chain.get_leaf_agents()
    assert "agent-leaf-1" in leaves
    assert "agent-leaf-2" in leaves
    assert "agent-leaf-3" in leaves
    print(f"Leaf agents: {leaves} ✓")

    # Get top-level
    top = chain.get_top_level_agents()
    assert "agent-root" in top
    print(f"Top-level agents: {top} ✓")

    # Get subordinates
    assert set(chain.get_subordinates("agent-mid-1")) == {"agent-leaf-1", "agent-leaf-2"}
    print(f"Subordinates of agent-mid-1: {chain.get_subordinates('agent-mid-1')} ✓")

    # Escalate from leaf-1 to mid-1
    supervisor = chain.escalate("intent-001", "agent-leaf-1", "Insufficient funds")
    assert supervisor == "agent-mid-1"
    print(f"Escalated to: {supervisor} ✓")

    # Escalate from mid-1 to root
    supervisor2 = chain.escalate("intent-001", "agent-mid-1", "Requires admin approval")
    assert supervisor2 == "agent-root"
    print(f"Escalated to: {supervisor2} ✓")

    # Check escalation path
    path = chain.get_escalation_path("intent-001")
    assert len(path) == 2
    assert path[0]["from_agent"] == "agent-leaf-1"
    assert path[1]["from_agent"] == "agent-mid-1"
    print(f"Escalation path: {len(path)} steps ✓")

    # Resolve
    resolution = chain.resolve("intent-001", "approved_by_root")
    assert resolution is not None
    assert resolution["resolution"] == "approved_by_root"
    assert resolution["total_escalations"] == 2
    print(f"Resolved: {resolution['resolution']} ✓")

    # Verify resolution retrievable
    res = chain.get_resolution("intent-001")
    assert res is not None
    assert res["status"] == "resolved"
    print("Resolution retrieval ✓")

    # Test max depth
    chain2 = EscalationChain()
    chain2.MAX_DEPTH = 3  # Lower for test
    chain2.register_agent("a1", "a2")
    chain2.register_agent("a2", "a3")
    chain2.register_agent("a3", "a4")
    chain2.register_agent("a4", "a5")

    assert chain2.escalate("intent-deep", "a1", "reason1") == "a2"
    assert chain2.escalate("intent-deep", "a2", "reason2") == "a3"
    assert chain2.escalate("intent-deep", "a3", "reason3") == "a4"

    # At depth 3, next escalation should fail (MAX_DEPTH check at len(path) >= depth)
    # But a4 still has a5 as supervisor... let's see: after 3 escalations path len=3 >= MAX_DEPTH=3
    result = chain2.escalate("intent-deep", "a4", "reason4")
    assert result is None, f"Expected None (max depth), got {result}"
    print(f"Max depth protection: escalation blocked at depth 3 ✓")

    # Unknown agent has no supervisor
    result3 = chain2.escalate("intent-unknown", "unknown-agent", "reason")
    assert result3 is None
    print("Unknown agent escalation blocked ✓")

    print("\n=== EscalationChain Verification ===")
    print(f"Status: {chain.get_status()}")
    print("All assertions passed ✓")
