"""
Quantum Circuit Broadcaster — T52: Quantum Circuit Design Broadcasting

Publishes QuantumCircuitDesign objects from QuantumAlgorithmDesigner onto the
quantum_circuits mesh channel so other QuantumIntelligentAgent instances can
receive, interpret, and learn from circuit designs.

Pipeline:
    QuantumAlgorithmDesigner.design_circuit()
        → QuantumCircuitDesign (asdict-serializable dataclass)
        → broadcast_design() → EnhancedMeshBus
        → quantum_circuits channel
            → other agents receive
            → QuantumStateInterpreter.analyze_circuit()
            → QuantumSkillEvolver.learn_from_experience() [IMITATION]
"""

from __future__ import annotations

import logging
import threading
from dataclasses import asdict
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from simp.mesh.enhanced_bus import get_enhanced_mesh_bus
from simp.mesh.packet import MeshPacket, MessageType, Priority, create_event_packet

if TYPE_CHECKING:
    from simp.organs.quantum_intelligence.quantum_designer import QuantumCircuitDesign

logger = logging.getLogger(__name__)

CHANNEL = "quantum_circuits"


def design_to_mesh_dict(design: "QuantumCircuitDesign") -> Dict[str, Any]:
    """Serialize a QuantumCircuitDesign to a mesh-safe dict via asdict."""
    return asdict(design)


def mesh_dict_to_design(d: Dict[str, Any]) -> "QuantumCircuitDesign":
    """Restore a QuantumCircuitDesign from a mesh dict."""
    from simp.organs.quantum_intelligence.quantum_designer import QuantumCircuitDesign
    return QuantumCircuitDesign(**d)


def broadcast_design(design: "QuantumCircuitDesign", sender_id: str) -> Optional[str]:
    """
    Broadcast a QuantumCircuitDesign to all subscribers of the quantum_circuits channel.

    Returns the message_id of the MeshPacket, or None on failure.
    """
    try:
        bus = get_enhanced_mesh_bus()
        bus.register_agent(sender_id)
        mesh_dict = design_to_mesh_dict(design)
        pkt = create_event_packet(
            sender_id=sender_id,
            recipient_id="*",
            channel=CHANNEL,
            payload=mesh_dict,
        )
        success = bus.send(pkt)
        if success:
            logger.info(
                f"Broadcast circuit {design.circuit_id} from {sender_id} "
                f"({len(design.gates)} gates, {design.qubits} qubits)"
            )
            return pkt.message_id
        return None
    except Exception as exc:
        logger.error(f"Failed to broadcast circuit: {exc}")
        return None


class QuantumCircuitBroadcaster:
    """
    Subscribes to the quantum_circuits channel and processes incoming circuit designs.

    For each received design:
        1. Deserialize the QuantumCircuitDesign
        2. Feed to QuantumStateInterpreter for analysis → QuantumAlgorithmInsight
        3. Log a LearningExperience with strategy=IMTATION on the evolver
    """

    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        self.logger = logging.getLogger(f"qcb.{agent_id}")
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._received: List[str] = []  # circuit_ids received
        self._bus = get_enhanced_mesh_bus()

    # ── lifecycle ────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Subscribe to quantum_circuits and start the receive loop."""
        if self._running:
            return
        self._bus.register_agent(self.agent_id)
        self._bus.subscribe(self.agent_id, CHANNEL)
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                       name=f"qcb-{self.agent_id}")
        self._thread.start()
        self.logger.info(f"QuantumCircuitBroadcaster started — listening on {CHANNEL}")

    def stop(self) -> None:
        self._running = False

    # ── receive loop ────────────────────────────────────────────────────────

    def _loop(self) -> None:
        while self._running:
            try:
                pkt = self._bus.receive(self.agent_id, timeout=1.0)
                if pkt is not None and pkt.get("channel") == CHANNEL:
                    self._handle(pkt)
            except Exception as exc:
                self.logger.debug(f"Receive loop: {exc}")

    def _handle(self, pkt: MeshPacket) -> None:
        """Process an incoming circuit design packet."""
        try:
            design = mesh_dict_to_design(pkt.payload)
            self._received.append(design.circuit_id)

            # 1. Interpret the circuit
            insight = self._interpret_circuit(design)

            # 2. Feed IMITATION experience to evolver
            self._feed_evolver(design, insight)

            self.logger.info(
                f"Processed circuit {design.circuit_id} from {pkt.sender_id} "
                f"(insight confidence={insight.confidence:.2f})"
            )
        except Exception as exc:
            self.logger.warning(f"Failed to handle circuit packet: {exc}")

    def _interpret_circuit(self, design: "QuantumCircuitDesign"):
        """Run QuantumStateInterpreter on the received circuit design."""
        try:
            from simp.organs.quantum_intelligence.quantum_interpreter import (
                QuantumStateInterpreter,
            )
            from simp.organs.quantum_intelligence import QuantumProblemType

            interpreter = QuantumStateInterpreter(self.agent_id)
            return interpreter.analyze_circuit(design, QuantumProblemType.OPTIMIZATION)
        except Exception as exc:
            self.logger.debug(f"QuantumStateInterpreter not available: {exc}")
            # Return a minimal stub insight so the evolver still gets called
            class StubInsight:
                confidence = 0.0
                gates_used = []
                estimated_depth = 0
            return StubInsight()

    def _feed_evolver(self, design: "QuantumCircuitDesign", insight) -> None:
        """Log an IMITATION learning experience for the received circuit."""
        try:
            from simp.organs.quantum_intelligence.quantum_evolver import (
                QuantumSkillEvolver,
                LearningExperience,
                LearningStrategy,
            )
            from simp.organs.quantum_intelligence import QuantumProblemType
            import uuid

            evolver = QuantumSkillEvolver(self.agent_id)
            exp = LearningExperience(
                experience_id=str(uuid.uuid4()),
                skill_id=f"circuit_{design.circuit_id[:8]}",
                problem_type=QuantumProblemType.OPTIMIZATION,
                outcome="success",
                performance_score=insight.confidence if hasattr(insight, 'confidence') else 0.5,
                quantum_advantage=0.5,
                insights_gained=[
                    f"Received circuit {design.circuit_id} via IMITATION",
                    f"Depth: {insight.estimated_depth if hasattr(insight, 'estimated_depth') else '?'}",
                    f"Gates: {[g.get('gate_type') if isinstance(g, dict) else getattr(g, 'gate_type', '?') for g in design.gates]}",
                ],
                metadata={
                    "strategy": LearningStrategy.IMITATION.value,
                    "source": "quantum_circuits_channel",
                    "circuit_id": design.circuit_id,
                },
            )
            evolver.learn_from_experience(exp)
            self.logger.debug(f"IMITATION: logged experience for {design.circuit_id}")
        except Exception as exc:
            self.logger.debug(f"QuantumSkillEvolver not available: {exc}")

    # ── stats ────────────────────────────────────────────────────────────────

    def get_stats(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "received_count": len(self._received),
            "received_circuits": self._received[-10:],  # last 10
        }
