"""
Raft-like Broker Health Consensus — Level 3 Mesh Protocol

Brokers vote on each other's health. A broker is considered healthy
if it has quorum (67% of active brokers) reporting it as healthy.

Quorum size is computed as ``round(0.67 * total_known_brokers)``
with a minimum of 2.

Supports dynamic add/remove of brokers from the peer set.

Thread-safe via RLock.
"""

import logging
import threading
import time
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class HealthConsensus:
    """Raft-like broker health consensus mechanism.

    Each broker reports health votes for other brokers. A target broker
    is considered healthy when more than half of the votes cast for it
    are healthy AND the number of votes reaches quorum.

    Quorum = 67% of known active brokers, minimum 2.

    Thread-safe: all mutable state guarded by ``_lock``.
    """

    QUORUM_FRACTION: float = 0.67
    MIN_QUORUM: int = 2

    def __init__(self) -> None:
        self._lock = threading.RLock()

        # Known active brokers
        self._brokers: Set[str] = set()

        # subject_broker_id -> {voter_broker_id: healthy_bool}
        self._votes: Dict[str, Dict[str, bool]] = {}

        # Cached health results
        self._health_cache: Dict[str, bool] = {}

        logger.info("HealthConsensus initialized")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def report_health(self, broker_id: str, healthy: bool) -> None:
        """Vote on a broker's health.

        If the voter (identified by ``broker_id``) is not in the known
        broker set, it is automatically added.

        Args:
            broker_id: The voter / observer broker ID.
            healthy: ``True`` if the voter considers the target healthy.
        """
        with self._lock:
            self._brokers.add(broker_id)

    def _record_vote(self, subject_id: str, voter_id: str, healthy: bool) -> None:
        """Internal: record a vote for a specific subject."""
        if subject_id not in self._votes:
            self._votes[subject_id] = {}
        self._votes[subject_id][voter_id] = healthy

    def is_healthy(self, broker_id: str) -> bool:
        """Return ``True`` if ``broker_id`` has quorum reporting it healthy.

        Threshold:
          - At least ``quorum_size`` brokers must have voted.
          - Of those votes, > 50% must be ``healthy=True``.

        If no votes exist for a broker, defaults to ``True`` (optimistic).
        """
        with self._lock:
            # If broker not known but we're asked anyway, default healthy
            if broker_id not in self._brokers:
                return True

            votes = self._votes.get(broker_id, {})
            quorum = self.get_quorum_size()

            if len(votes) < quorum:
                # Not enough votes yet — use cached result if available
                return self._health_cache.get(broker_id, True)

            healthy_votes = sum(1 for v in votes.values() if v)
            result = healthy_votes > len(votes) / 2

            self._health_cache[broker_id] = result
            return result

    def get_quorum_size(self) -> int:
        """Return the quorum size: 67% of known brokers, minimum 2."""
        with self._lock:
            total = len(self._brokers)
            return max(self.MIN_QUORUM, round(self.QUORUM_FRACTION * total))

    # ------------------------------------------------------------------
    # Broker set management
    # ------------------------------------------------------------------

    def add_broker(self, broker_id: str) -> None:
        """Add a broker to the active peer set."""
        with self._lock:
            self._brokers.add(broker_id)
            logger.debug("Broker added to health consensus: %s (total: %d)", broker_id, len(self._brokers))

    def remove_broker(self, broker_id: str) -> None:
        """Remove a broker from the active peer set and purge its votes."""
        with self._lock:
            self._brokers.discard(broker_id)
            # Remove votes BY this broker
            for subject in list(self._votes.keys()):
                self._votes[subject].pop(broker_id, None)
                if not self._votes[subject]:
                    del self._votes[subject]
            # Remove votes FOR this broker
            self._votes.pop(broker_id, None)
            self._health_cache.pop(broker_id, None)
            logger.debug("Broker removed from health consensus: %s (total: %d)", broker_id, len(self._brokers))

    def get_known_brokers(self) -> List[str]:
        """Return list of all known active brokers."""
        with self._lock:
            return list(self._brokers)

    # ------------------------------------------------------------------
    # Vote management
    # ------------------------------------------------------------------

    def cast_vote(self, subject_id: str, voter_id: str, healthy: bool) -> None:
        """Cast a specific vote from one broker about another.

        Both brokers are automatically added to the known set if not
        already present.

        Args:
            subject_id: The broker being voted on.
            voter_id: The broker casting the vote.
            healthy: ``True`` if the voter considers the subject healthy.
        """
        with self._lock:
            self._brokers.add(voter_id)
            self._brokers.add(subject_id)

            if subject_id not in self._votes:
                self._votes[subject_id] = {}
            self._votes[subject_id][voter_id] = healthy

            # Invalidate cache for this subject
            self._health_cache.pop(subject_id, None)

    def get_vote_summary(self, broker_id: str) -> Dict[str, Any]:
        """Return a summary of votes for a specific broker.

        Returns:
            {
                "broker_id": str,
                "total_votes": int,
                "healthy_votes": int,
                "unhealthy_votes": int,
                "is_healthy": bool,
                "quorum_size": int,
                "quorum_reached": bool,
            }
        """
        with self._lock:
            votes = self._votes.get(broker_id, {})
            quorum = self.get_quorum_size()
            healthy_votes = sum(1 for v in votes.values() if v)

            return {
                "broker_id": broker_id,
                "total_votes": len(votes),
                "healthy_votes": healthy_votes,
                "unhealthy_votes": len(votes) - healthy_votes,
                "is_healthy": self.is_healthy(broker_id),
                "quorum_size": quorum,
                "quorum_reached": len(votes) >= quorum,
            }

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_status(self) -> Dict[str, Any]:
        """Return status dict with operational metrics."""
        with self._lock:
            healthy = [b for b in self._brokers if self.is_healthy(b)]
            degraded = [b for b in self._brokers if not self.is_healthy(b)]
            return {
                "known_brokers": len(self._brokers),
                "healthy_brokers": healthy,
                "degraded_brokers": degraded,
                "quorum_size": self.get_quorum_size(),
                "quorum_fraction": self.QUORUM_FRACTION,
                "total_votes_cast": sum(len(v) for v in self._votes.values()),
            }


# ---------------------------------------------------------------------------
# Verification block
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(message)s")

    hc = HealthConsensus()

    # Add brokers
    hc.add_broker("broker-alpha")
    hc.add_broker("broker-beta")
    hc.add_broker("broker-gamma")
    hc.add_broker("broker-delta")

    assert len(hc.get_known_brokers()) == 4
    print(f"Known brokers: {hc.get_known_brokers()} ✓")

    # Quorum: 67% of 4 = round(2.68) = 3, min 2
    quorum = hc.get_quorum_size()
    assert quorum == 3, f"Expected quorum=3, got {quorum}"
    print(f"Quorum size with 4 brokers: {quorum} ✓")

    # Cast votes: 3 out of 4 say broker-alpha is healthy
    hc.cast_vote("broker-alpha", "broker-beta", True)
    hc.cast_vote("broker-alpha", "broker-gamma", True)
    hc.cast_vote("broker-alpha", "broker-delta", True)

    assert hc.is_healthy("broker-alpha") is True
    print("broker-alpha healthy with 3/3 healthy votes ✓")

    # Cast votes: 3 out of 4 say broker-beta is unhealthy
    hc.cast_vote("broker-beta", "broker-alpha", False)
    hc.cast_vote("broker-beta", "broker-gamma", False)
    hc.cast_vote("broker-beta", "broker-delta", False)

    assert hc.is_healthy("broker-beta") is False
    print("broker-beta unhealthy with 0/3 healthy votes ✓")

    # Remove a broker and check quorum recalculated
    hc.remove_broker("broker-delta")
    print(f"After removing broker-delta, known: {hc.get_known_brokers()}")

    # Quorum with 3 brokers: 67% of 3 = round(2.01) = 2
    quorum3 = hc.get_quorum_size()
    assert quorum3 == 2, f"Expected quorum=2, got {quorum3}"
    print(f"Quorum size with 3 brokers: {quorum3} ✓")

    # Vote summary
    summary = hc.get_vote_summary("broker-alpha")
    print(f"Vote summary for broker-alpha: {summary}")

    # Default healthy when no votes
    hc2 = HealthConsensus()
    hc2.add_broker("new-broker")
    assert hc2.is_healthy("new-broker") is True
    print("Unknown broker defaults to healthy ✓")

    print("\n=== HealthConsensus Verification ===")
    print(f"Status: {hc.get_status()}")
    print("All assertions passed ✓")
