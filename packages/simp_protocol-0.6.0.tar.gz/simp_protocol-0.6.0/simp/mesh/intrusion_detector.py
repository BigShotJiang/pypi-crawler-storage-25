"""
Mesh Intrusion Detector — Traffic Analysis & Anomaly Detection (Level 3)
========================================================================

Monitors broker-to-broker traffic in the SIMP mesh for suspicious
activity including:
  - Unregistered brokers sending messages
  - Replay attacks (nonce duplication)
  - Unexpected message types
  - Traffic volume anomalies (>100 msgs in 60s from a single broker)

Severity levels: low, medium, high, critical.
Thread-safe via threading.Lock.
Pure Python (stdlib only).
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Traffic anomaly threshold
TRAFFIC_THRESHOLD_COUNT = 100
TRAFFIC_THRESHOLD_WINDOW = 60.0  # seconds

# Valid message types in the SIMP mesh
VALID_MESSAGE_TYPES = {
    "intent_create",
    "intent_forward",
    "intent_resolve",
    "intent_cancel",
    "intent_status",
    "broker_hello",
    "broker_ack",
    "broker_sync",
    "broker_discover",
    "heartbeat",
    "gossip",
    "consensus_vote",
    "consensus_commit",
    "reputation_update",
    "swarm_command",
    "swarm_result",
    "trading_signal",
}

ANOMALY_TYPES = {
    "unregistered_broker": "Broker not found in registry",
    "replay_attack": "Duplicate nonce detected",
    "unexpected_message_type": "Message type not in valid set",
    "traffic_burst": "Message rate exceeds threshold",
    "unknown": "Unclassified anomaly",
}


@dataclass
class AnomalyRecord:
    """A recorded security anomaly."""

    anomaly_type: str
    source: str
    severity: str  # low, medium, high, critical
    detail: str
    timestamp: float = field(default_factory=time.time)
    alert_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])

    def to_dict(self) -> Dict[str, Any]:
        return {
            "alert_id": self.alert_id,
            "timestamp": self.timestamp,
            "anomaly_type": self.anomaly_type,
            "source": self.source,
            "severity": self.severity,
            "detail": self.detail,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnomalyRecord":
        return cls(
            anomaly_type=data["anomaly_type"],
            source=data["source"],
            severity=data["severity"],
            detail=data["detail"],
            timestamp=data.get("timestamp", time.time()),
            alert_id=data.get("alert_id", uuid.uuid4().hex[:12]),
        )


SEVERITY_ORDER = {"low": 0, "medium": 1, "high": 2, "critical": 3}


def _severity_ge(level_a: str, level_b: str) -> bool:
    """True if severity level_a >= level_b."""
    return SEVERITY_ORDER.get(level_a, 0) >= SEVERITY_ORDER.get(level_b, 0)


class MeshIntrusionDetector:
    """
    Detects and records mesh-level anomalies and intrusion attempts.

    Maintains a registry of known brokers, tracks nonces for replay
    detection, and monitors per-broker traffic rates.

    Args:
        max_nonce_history: Max nonces to retain per broker (prevents unbounded memory).
        traffic_threshold: Message count threshold for traffic burst detection.
        traffic_window: Time window (seconds) for traffic rate calculation.
    """

    def __init__(
        self,
        max_nonce_history: int = 10_000,
        traffic_threshold: int = TRAFFIC_THRESHOLD_COUNT,
        traffic_window: float = TRAFFIC_THRESHOLD_WINDOW,
    ) -> None:
        self._lock = threading.Lock()

        # Broker registry: broker_id -> address
        self._known_brokers: Dict[str, str] = {}

        # Nonce tracking: broker_id -> set of seen nonces (string)
        self._seen_nonces: Dict[str, set] = defaultdict(set)

        # Traffic tracking: broker_id -> list of (timestamp, msg_type) tuples
        self._traffic_log: Dict[str, List[Tuple[float, str]]] = defaultdict(list)

        # Anomaly store
        self._anomalies: List[AnomalyRecord] = []

        # Configuration
        self._max_nonce_history = max_nonce_history
        self._traffic_threshold = traffic_threshold
        self._traffic_window = traffic_window

    # ── Broker Registration ───────────────────────────────────────────

    def register_broker(self, broker_id: str, address: str) -> None:
        """
        Register a known broker in the detector's registry.

        Args:
            broker_id: Unique identifier for the broker.
            address: Network address of the broker (e.g. "tcp://10.0.0.1:9000").
        """
        with self._lock:
            self._known_brokers[broker_id] = address
        logger.info("Registered known broker: %s @ %s", broker_id, address)

    # ── Core Analysis ─────────────────────────────────────────────────

    def analyze_message(
        self,
        msg: Dict[str, Any],
        source_broker: str,
    ) -> List[Dict[str, Any]]:
        """
        Analyze an incoming mesh message for signs of intrusion.

        Checks performed:
          1. Unregistered broker — source_broker not in known_brokers
          2. Replay attack — nonce already seen from this broker
          3. Unexpected message type — msg_type not in VALID_MESSAGE_TYPES

        Args:
            msg: The parsed message dict (must contain at least a 'type' field).
            source_broker: The broker_id of the sender.

        Returns:
            List of anomaly dicts (empty if no issues detected).
        """
        anomalies: List[AnomalyRecord] = []
        msg_type = msg.get("type", "unknown")
        nonce = msg.get("nonce")

        with self._lock:
            # 1. Check broker registration
            if source_broker not in self._known_brokers:
                anomalies.append(self._make_anomaly(
                    "unregistered_broker", source_broker, "critical",
                    f"Message from unregistered broker '{source_broker}' (type={msg_type})",
                ))

            # 2. Check nonce for replay
            if nonce is not None:
                # Clean up old nonces if over limit
                if len(self._seen_nonces[source_broker]) > self._max_nonce_history:
                    self._seen_nonces[source_broker].clear()

                if nonce in self._seen_nonces[source_broker]:
                    anomalies.append(self._make_anomaly(
                        "replay_attack", source_broker, "critical",
                        f"Duplicate nonce '{nonce}' from broker '{source_broker}'",
                    ))
                else:
                    self._seen_nonces[source_broker].add(nonce)

            # 3. Check message type
            if msg_type not in VALID_MESSAGE_TYPES:
                anomalies.append(self._make_anomaly(
                    "unexpected_message_type", source_broker, "high",
                    f"Unexpected message type '{msg_type}' from broker '{source_broker}'",
                ))

            # 4. Log traffic (for rate analysis)
            self._traffic_log[source_broker].append((time.time(), msg_type))

            # Record any anomalies
            for a in anomalies:
                self._anomalies.append(a)

        # Log anomaly alerts
        for a in anomalies:
            logger.warning(
                "ANOMALY [%s] %s: %s (severity=%s)",
                a.alert_id, a.anomaly_type, a.detail, a.severity,
            )

        return [a.to_dict() for a in anomalies]

    def analyze_traffic(self, source_broker: str) -> List[Dict[str, Any]]:
        """
        Analyze traffic volume from a single broker.

        Flags an anomaly if more than ``traffic_threshold`` messages
        have been received in the last ``traffic_window`` seconds.

        Args:
            source_broker: The broker_id to check.

        Returns:
            List of anomaly dicts (empty if traffic is normal).
        """
        anomalies: List[AnomalyRecord] = []
        now = time.time()
        cutoff = now - self._traffic_window

        with self._lock:
            # Prune old entries
            log = self._traffic_log.get(source_broker, [])
            recent = [(ts, mt) for ts, mt in log if ts >= cutoff]
            self._traffic_log[source_broker] = recent

            count = len(recent)
            if count > self._traffic_threshold:
                anomaly = self._make_anomaly(
                    "traffic_burst", source_broker, "medium",
                    f"Traffic burst: {count} messages in {self._traffic_window:.0f}s "
                    f"(threshold={self._traffic_threshold})",
                )
                self._anomalies.append(anomaly)
                anomalies.append(anomaly)
                logger.warning(
                    "TRAFFIC ANOMALY [%s]: %s — %d msgs in %.0fs",
                    anomaly.alert_id, source_broker, count, self._traffic_window,
                )

        return [a.to_dict() for a in anomalies]

    # ── Anomaly Reporting ─────────────────────────────────────────────

    def report_anomaly(
        self,
        anomaly_type: str,
        source: str,
        severity: str = "medium",
        detail: str = "",
    ) -> Dict[str, Any]:
        """
        Manually report an anomaly / intrusion event.

        Args:
            anomaly_type: One of the keys in ANOMALY_TYPES (or custom).
            source: Source identifier (broker_id, agent_id, IP, etc.).
            severity: One of 'low', 'medium', 'high', 'critical'.
            detail: Human-readable description.

        Returns:
            The anomaly dict.
        """
        with self._lock:
            record = self._make_anomaly(anomaly_type, source, severity, detail)
            self._anomalies.append(record)
        logger.warning(
            "MANUAL ANOMALY [%s] %s: %s (severity=%s)",
            record.alert_id, anomaly_type, detail, severity,
        )
        return record.to_dict()

    # ── Queries ───────────────────────────────────────────────────────

    def get_anomalies(self, min_severity: str = "low") -> List[Dict[str, Any]]:
        """
        Return all anomalies at or above the given severity level.

        Args:
            min_severity: Minimum severity threshold ('low', 'medium', 'high', 'critical').

        Returns:
            List of anomaly dicts sorted by timestamp (newest first).
        """
        with self._lock:
            results = [
                a.to_dict()
                for a in self._anomalies
                if _severity_ge(a.severity, min_severity)
            ]
        results.sort(key=lambda x: x["timestamp"], reverse=True)
        return results

    def get_recent_alerts(self, count: int = 10) -> List[Dict[str, Any]]:
        """
        Return the N most recent anomaly alerts.

        Args:
            count: Maximum number of alerts to return.

        Returns:
            List of anomaly dicts (newest first, up to ``count``).
        """
        with self._lock:
            all_alerts = [a.to_dict() for a in self._anomalies]
        all_alerts.sort(key=lambda x: x["timestamp"], reverse=True)
        return all_alerts[:count]

    # ── Internal Helpers ──────────────────────────────────────────────

    def _make_anomaly(
        self,
        anomaly_type: str,
        source: str,
        severity: str,
        detail: str,
    ) -> AnomalyRecord:
        """Factory method for AnomalyRecord."""
        return AnomalyRecord(
            anomaly_type=anomaly_type,
            source=source,
            severity=severity,
            detail=detail,
        )


# ── Verification Block ────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("MeshIntrusionDetector Verification")
    print("=" * 60)

    detector = MeshIntrusionDetector(traffic_threshold=3, traffic_window=60.0)

    # 1. Register some brokers
    detector.register_broker("broker_a", "tcp://10.0.0.1:9001")
    detector.register_broker("broker_b", "tcp://10.0.0.2:9001")
    detector.register_broker("broker_c", "tcp://10.0.0.3:9001")
    print("[✓] 3 brokers registered")

    # 2. Normal message — no anomalies
    msg_ok = {"type": "heartbeat", "nonce": "nonce_001", "from": "broker_a"}
    result_ok = detector.analyze_message(msg_ok, "broker_a")
    assert len(result_ok) == 0, f"Expected 0 anomalies, got {len(result_ok)}"
    print("[✓] Normal message passes cleanly")

    # 3. Unregistered broker
    msg_bad = {"type": "heartbeat", "nonce": "nonce_002"}
    result_unreg = detector.analyze_message(msg_bad, "evil_broker")
    assert len(result_unreg) >= 1
    assert result_unreg[0]["anomaly_type"] == "unregistered_broker"
    print(f"[✓] Unregistered broker detected: {result_unreg[0]['detail']}")

    # 4. Replay attack (same nonce)
    msg_replay = {"type": "heartbeat", "nonce": "nonce_001"}
    result_replay = detector.analyze_message(msg_replay, "broker_b")
    # broker_b is known, nonce_001 is new for broker_b — should be clean
    assert len(result_replay) == 0
    # Now send the same nonce again from broker_b
    result_replay2 = detector.analyze_message(msg_replay, "broker_b")
    assert len(result_replay2) >= 1
    assert result_replay2[0]["anomaly_type"] == "replay_attack"
    print(f"[✓] Replay attack detected: {result_replay2[0]['detail']}")

    # 5. Unexpected message type
    msg_unknown_type = {"type": "alien_protocol", "nonce": "nonce_003"}
    result_badtype = detector.analyze_message(msg_unknown_type, "broker_a")
    assert len(result_badtype) >= 1
    assert result_badtype[0]["anomaly_type"] == "unexpected_message_type"
    print(f"[✓] Unexpected message type detected: {result_badtype[0]['detail']}")

    # 6. Traffic burst
    for i in range(5):
        detector.analyze_message({"type": "heartbeat", "nonce": f"traffic_{i}"}, "broker_c")
    result_burst = detector.analyze_traffic("broker_c")
    assert len(result_burst) >= 1
    assert result_burst[0]["anomaly_type"] == "traffic_burst"
    print(f"[✓] Traffic burst detected: {result_burst[0]['detail']}")

    # 7. Manual anomaly report
    manual = detector.report_anomaly("unknown", "10.0.0.99", "critical", "Manual test alert")
    assert manual["severity"] == "critical"
    print(f"[✓] Manual anomaly reported: {manual['detail']}")

    # 8. get_anomalies with severity filter
    all_anomalies = detector.get_anomalies(min_severity="low")
    assert len(all_anomalies) >= 4
    critical_anomalies = detector.get_anomalies(min_severity="critical")
    assert len(critical_anomalies) >= 1
    print(f"[✓] get_anomalies(low) → {len(all_anomalies)}, get_anomalies(critical) → {len(critical_anomalies)}")

    # 9. get_recent_alerts
    recent = detector.get_recent_alerts(count=3)
    assert len(recent) == 3
    print(f"[✓] get_recent_alerts(3) → {len(recent)} alerts (newest first)")

    # 10. Thread safety
    import concurrent.futures

    def threaded_analysis(d: MeshIntrusionDetector, broker: str, idx: int) -> None:
        d.analyze_message({"type": "heartbeat", "nonce": f"thread_{idx}"}, broker)

    det2 = MeshIntrusionDetector()
    det2.register_broker("load_broker", "tcp://10.0.0.100:9001")
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(threaded_analysis, det2, "load_broker", i) for i in range(100)]
        concurrent.futures.wait(futures)
    assert det2.get_anomalies(min_severity="low") == []  # Should all pass
    print(f"[✓] Thread safety: 100 concurrent analyses completed cleanly")

    print()
    print("All MeshIntrusionDetector tests PASSED ✓")
