"""
Intent Receipt Chain — L3 mesh module

Tracks multi-hop intent routing across the SIMP mesh. Each intent's
journey through brokers is recorded as a chain of hops, enabling
verification of route continuity and full audit trail.

Design:
- start_chain() creates the first hop at the origin broker
- add_hop() appends each subsequent broker the intent passes through
- finalize() marks the chain complete with the final result
- verify_chain() checks for chronological continuity (no gaps)
- Each hop stores broker_id, timestamp, and unique receipt_id
"""

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ChainHop:
    """A single hop in an intent's multi-broker journey.

    Each hop represents the intent passing through one broker.
    """
    broker_id: str
    timestamp: float
    receipt_id: str
    action: str = "forwarded"  # forwarded, processed, completed
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "broker_id": self.broker_id,
            "timestamp": self.timestamp,
            "timestamp_iso": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.timestamp)
            ),
            "receipt_id": self.receipt_id,
            "action": self.action,
        }


class ReceiptChainError(Exception):
    """Exception raised for receipt chain errors."""
    pass


class ReceiptChain:
    """Tracks an intent's journey through multiple brokers.

    An intent starts at an origin broker, gets forwarded through zero or
    more intermediary brokers, and eventually reaches a broker that produces
    a final result. Each hop is recorded with a receipt_id so the full
    path can be traced and verified.

    Thread-safe via RLock for concurrent access.
    """

    def __init__(self):
        self._lock = threading.RLock()

        # Chains: intent_id -> list of ChainHop
        self._chains: Dict[str, List[ChainHop]] = {}

        # Final results: intent_id -> result dict
        self._results: Dict[str, Dict[str, Any]] = {}

        # Chain metadata: intent_id -> metadata dict
        self._metadata: Dict[str, Dict[str, Any]] = {}

        # Stats
        self._stats = {
            "chains_started": 0,
            "hops_added": 0,
            "chains_finalized": 0,
            "verifications_performed": 0,
            "verification_failures": 0,
        }

        logger.info("ReceiptChain initialized")

    # ------------------------------------------------------------------ #
    # Chain Lifecycle
    # ------------------------------------------------------------------ #

    def start_chain(self, intent_id: str, origin_broker: str,
                    metadata: Optional[Dict[str, Any]] = None) -> str:
        """Start a new receipt chain for an intent.

        Creates the first hop at the origin broker with a unique receipt_id.

        Args:
            intent_id: Unique intent identifier.
            origin_broker: ID of the broker where this intent originates.
            metadata: Optional metadata for the entire chain.

        Returns:
            The receipt_id of the first hop.

        Raises:
            ReceiptChainError: If a chain already exists for this intent_id.
        """
        if metadata is None:
            metadata = {}

        receipt_id = str(uuid.uuid4())

        with self._lock:
            if intent_id in self._chains:
                raise ReceiptChainError(
                    f"Chain already exists for intent {intent_id}"
                )

            hop = ChainHop(
                broker_id=origin_broker,
                timestamp=time.time(),
                receipt_id=receipt_id,
                action="origin",
            )

            self._chains[intent_id] = [hop]
            self._metadata[intent_id] = metadata
            self._stats["chains_started"] += 1

        logger.info("Started receipt chain for intent %s at broker %s "
                     "(receipt=%s)", intent_id, origin_broker, receipt_id)
        return receipt_id

    def add_hop(self, intent_id: str, broker_id: str,
                action: str = "forwarded",
                metadata: Optional[Dict[str, Any]] = None) -> str:
        """Append a new hop to the chain.

        Records that the intent has been forwarded to another broker.

        Args:
            intent_id: Intent identifier.
            broker_id: ID of the broker receiving the intent.
            action: Action taken ('forwarded', 'processed', etc.).
            metadata: Optional per-hop metadata.

        Returns:
            The receipt_id of this hop.

        Raises:
            ReceiptChainError: If no chain exists for this intent_id.
        """
        if metadata is None:
            metadata = {}

        receipt_id = str(uuid.uuid4())

        with self._lock:
            if intent_id not in self._chains:
                raise ReceiptChainError(
                    f"No chain found for intent {intent_id}"
                )

            hop = ChainHop(
                broker_id=broker_id,
                timestamp=time.time(),
                receipt_id=receipt_id,
                action=action,
                metadata=metadata,
            )

            self._chains[intent_id].append(hop)
            self._stats["hops_added"] += 1

        logger.debug("Added hop %s -> broker %s for intent %s",
                     receipt_id, broker_id, intent_id)
        return receipt_id

    def finalize(self, intent_id: str,
                 result: Dict[str, Any]) -> bool:
        """Mark the chain as complete with a final result.

        Adds a final hop with 'completed' action and stores the result.

        Args:
            intent_id: Intent identifier.
            result: Result payload from the final broker.

        Returns:
            True if finalized successfully, False if chain doesn't exist.

        Raises:
            ReceiptChainError: If chain is already finalized.
        """
        with self._lock:
            if intent_id not in self._chains:
                logger.warning("Cannot finalize unknown intent %s", intent_id)
                return False

            if intent_id in self._results:
                raise ReceiptChainError(
                    f"Chain already finalized for intent {intent_id}"
                )

            # Add final hop
            final_hop = ChainHop(
                broker_id=self._chains[intent_id][-1].broker_id,
                timestamp=time.time(),
                receipt_id=str(uuid.uuid4()),
                action="completed",
            )
            self._chains[intent_id].append(final_hop)

            # Store result
            self._results[intent_id] = result
            self._stats["chains_finalized"] += 1

        logger.info("Finalized receipt chain for intent %s", intent_id)
        return True

    # ------------------------------------------------------------------ #
    # Chain Queries
    # ------------------------------------------------------------------ #

    def get_chain(self, intent_id: str) -> Optional[List[Dict[str, Any]]]:
        """Get the list of hops for an intent's journey.

        Args:
            intent_id: Intent identifier.

        Returns:
            List of dicts with 'broker', 'timestamp', 'receipt_id' keys,
            or None if no chain exists.
        """
        with self._lock:
            chain = self._chains.get(intent_id)
            if chain is None:
                return None
            return [hop.to_dict() for hop in chain]

    def get_final_receipt(self, intent_id: str) -> Optional[Dict[str, Any]]:
        """Get the complete chain as a dict with full details.

        Args:
            intent_id: Intent identifier.

        Returns:
            Dict with chain overview, full hop list, and final result,
            or None if no chain exists.
        """
        with self._lock:
            chain = self._chains.get(intent_id)
            if chain is None:
                return None

            hops = [hop.to_dict() for hop in chain]

            receipt = {
                "intent_id": intent_id,
                "hop_count": len(hops),
                "origin_broker": hops[0]["broker_id"] if hops else None,
                "final_broker": hops[-1]["broker_id"] if hops else None,
                "started_at": hops[0]["timestamp"] if hops else None,
                "completed_at": hops[-1]["timestamp"] if hops else None,
                "hops": hops,
                "result": self._results.get(intent_id),
                "metadata": self._metadata.get(intent_id, {}),
            }

            # Calculate duration
            if len(hops) >= 2:
                receipt["duration_seconds"] = round(
                    hops[-1]["timestamp"] - hops[0]["timestamp"], 3
                )

            return receipt

    def verify_chain(self, intent_id: str) -> bool:
        """Verify chain continuity — no gaps in the broker sequence.

        Checks that:
        1. The chain exists.
        2. All timestamps are monotonically increasing (no time gaps).
        3. Each hop has a valid broker_id and receipt_id.

        Args:
            intent_id: Intent identifier.

        Returns:
            True if chain is valid and continuous, False otherwise.
        """
        with self._lock:
            self._stats["verifications_performed"] += 1
            chain = self._chains.get(intent_id)

            if chain is None:
                self._stats["verification_failures"] += 1
                return False

            if len(chain) == 0:
                self._stats["verification_failures"] += 1
                return False

            # Check hop integrity
            for i, hop in enumerate(chain):
                # Every hop must have required fields
                if not hop.broker_id or not hop.receipt_id:
                    logger.warning("Chain %s hop %d missing broker_id or receipt_id",
                                   intent_id, i)
                    self._stats["verification_failures"] += 1
                    return False

                # Timestamps must be monotonically increasing (with small tolerance)
                if i > 0 and hop.timestamp < chain[i - 1].timestamp - 0.001:
                    logger.warning("Chain %s has timestamp regression at hop %d: "
                                   "%f < %f",
                                   intent_id, i, hop.timestamp,
                                   chain[i - 1].timestamp)
                    self._stats["verification_failures"] += 1
                    return False

            # Check that origin is first
            if chain[0].action != "origin":
                logger.warning("Chain %s first hop is not 'origin'", intent_id)
                self._stats["verification_failures"] += 1
                return False

            return True

    # ------------------------------------------------------------------ #
    # Convenience Methods
    # ------------------------------------------------------------------ #

    def add_route_from_router(self, intent_id: str, source_broker: str,
                              target_broker: str) -> Optional[str]:
        """Convenience: start a chain + add a hop in one call.

        If no chain exists, starts one at source_broker then adds
        a hop to target_broker. If chain exists, just adds the hop.

        Args:
            intent_id: Intent identifier.
            source_broker: Source broker ID.
            target_broker: Target broker ID.

        Returns:
            Final receipt_id from the target hop, or None on error.
        """
        with self._lock:
            if intent_id not in self._chains:
                # Start chain at source
                src_receipt = str(uuid.uuid4())
                hop = ChainHop(
                    broker_id=source_broker,
                    timestamp=time.time(),
                    receipt_id=src_receipt,
                    action="origin",
                )
                self._chains[intent_id] = [hop]
                self._stats["chains_started"] += 1

            # Add hop to target
            tgt_receipt = str(uuid.uuid4())
            hop = ChainHop(
                broker_id=target_broker,
                timestamp=time.time(),
                receipt_id=tgt_receipt,
                action="forwarded",
            )
            self._chains[intent_id].append(hop)
            self._stats["hops_added"] += 1

            return tgt_receipt

    def get_origin_broker(self, intent_id: str) -> Optional[str]:
        """Get the broker where this intent's chain started."""
        with self._lock:
            chain = self._chains.get(intent_id)
            if chain is None or len(chain) == 0:
                return None
            return chain[0].broker_id

    def get_last_broker(self, intent_id: str) -> Optional[str]:
        """Get the last broker in the chain."""
        with self._lock:
            chain = self._chains.get(intent_id)
            if chain is None or len(chain) == 0:
                return None
            return chain[-1].broker_id

    def get_chain_length(self, intent_id: str) -> Optional[int]:
        """Get the number of hops in the chain."""
        with self._lock:
            chain = self._chains.get(intent_id)
            if chain is None:
                return None
            return len(chain)

    def is_finalized(self, intent_id: str) -> bool:
        """Check if a chain has been finalized with a result."""
        with self._lock:
            return intent_id in self._results

    def get_result(self, intent_id: str) -> Optional[Dict[str, Any]]:
        """Get the final result for a completed chain."""
        with self._lock:
            return self._results.get(intent_id)

    # ------------------------------------------------------------------ #
    # Stats & Cleanup
    # ------------------------------------------------------------------ #

    def get_stats(self) -> Dict[str, Any]:
        """Return receipt chain statistics."""
        with self._lock:
            return {
                **dict(self._stats),
                "active_chains": sum(
                    1 for iid in self._chains if iid not in self._results
                ),
                "finalized_chains": len(self._results),
                "total_chains": len(self._chains),
            }

    def list_chains(self) -> List[Dict[str, Any]]:
        """Return summary of all tracked chains."""
        with self._lock:
            result = []
            for intent_id in self._chains:
                chain = self._chains[intent_id]
                result.append({
                    "intent_id": intent_id,
                    "hop_count": len(chain),
                    "origin": chain[0].broker_id if chain else None,
                    "last_broker": chain[-1].broker_id if chain else None,
                    "finalized": intent_id in self._results,
                })
            return result

    def remove_chain(self, intent_id: str) -> bool:
        """Remove a chain and its result."""
        with self._lock:
            found = intent_id in self._chains
            self._chains.pop(intent_id, None)
            self._results.pop(intent_id, None)
            self._metadata.pop(intent_id, None)
            return found


# ===================================================================== #
# Verification Block
# ===================================================================== #
if __name__ == "__main__":
    logging.basicConfig(level=logging.WARNING,
                        format="%(levelname)s: %(message)s")

    print("=== ReceiptChain Verification ===\n")

    rc = ReceiptChain()

    # Start a chain
    r1 = rc.start_chain("intent-001", "broker-alpha",
                         metadata={"type": "ml_inference"})
    assert r1 is not None, "start_chain should return a receipt_id"
    print(f"✓ Started chain for intent-001 at broker-alpha (receipt={r1[:8]}...)")

    # Add hops
    r2 = rc.add_hop("intent-001", "broker-beta", action="forwarded")
    print(f"✓ Added hop broker-beta (receipt={r2[:8]}...)")

    r3 = rc.add_hop("intent-001", "broker-gamma", action="forwarded")
    print(f"✓ Added hop broker-gamma (receipt={r3[:8]}...)")

    # Get chain
    chain = rc.get_chain("intent-001")
    assert chain is not None, "get_chain should return a list"
    assert len(chain) == 3, f"Expected 3 hops, got {len(chain)}"
    print(f"✓ Chain has {len(chain)} hops")

    # Verify chain integrity
    assert rc.verify_chain("intent-001"), "Chain should be valid"
    print("✓ Chain verified: no gaps, valid timestamps")

    # Finalize
    result = {"output": "inference_complete", "confidence": 0.95}
    finalized = rc.finalize("intent-001", result)
    assert finalized, "finalize should succeed"
    print(f"✓ Chain finalized with result")

    # Get final receipt
    final = rc.get_final_receipt("intent-001")
    assert final is not None, "get_final_receipt should return a dict"
    assert final["hop_count"] == 4, f"Expected 4 hops (incl. completed), got {final['hop_count']}"
    assert final["origin_broker"] == "broker-alpha"
    assert final["final_broker"] == "broker-gamma"
    assert final["result"]["output"] == "inference_complete"
    print(f"✓ Final receipt: {final['hop_count']} hops, "
          f"{final['origin_broker']} -> ... -> {final['final_broker']}")
    if "duration_seconds" in final:
        print(f"  Duration: {final['duration_seconds']}s")

    # Verify still passes after finalize
    assert rc.verify_chain("intent-001"), "Chain should still be valid"
    print("✓ Chain still valid after finalization")

    # Test chain with single hop (no forwarding)
    r_single = rc.start_chain("intent-002", "broker-alpha")
    rc.finalize("intent-002", {"result": "ok"})
    single_chain = rc.get_chain("intent-002")
    assert len(single_chain) == 2, f"Expected 2 hops (origin + completed), got {len(single_chain)}"
    assert rc.verify_chain("intent-002"), "Single-hop chain should be valid"
    print(f"✓ Single-hop chain for intent-002: {len(single_chain)} hops")

    # Test verification failure cases
    assert not rc.verify_chain("non-existent"), "Non-existent chain should fail verification"
    print("✓ Non-existent chain verification correctly returns False")

    # Test get_origin / get_last
    assert rc.get_origin_broker("intent-001") == "broker-alpha"
    assert rc.get_last_broker("intent-001") == "broker-gamma"
    assert rc.get_chain_length("intent-001") == 4
    assert rc.is_finalized("intent-001") is True
    print(f"✓ Chain queries: origin={rc.get_origin_broker('intent-001')}, "
          f"last={rc.get_last_broker('intent-001')}, "
          f"length={rc.get_chain_length('intent-001')}")

    # Test add_route_from_router convenience
    r4 = rc.add_route_from_router("intent-003", "broker-alpha", "broker-beta")
    assert r4 is not None
    chain3 = rc.get_chain("intent-003")
    assert len(chain3) == 2, f"Expected 2 hops, got {len(chain3)}"
    print(f"✓ add_route_from_router created 2-hop chain for intent-003")

    # Test duplicate chain rejection
    try:
        rc.start_chain("intent-001", "broker-delta")
        assert False, "Should have raised ReceiptChainError"
    except ReceiptChainError:
        print("✓ Duplicate chain correctly raises ReceiptChainError")

    # Test double finalize rejection
    try:
        rc.finalize("intent-001", {"extra": "data"})
        assert False, "Should have raised ReceiptChainError"
    except ReceiptChainError:
        print("✓ Double finalize correctly raises ReceiptChainError")

    # Test list_chains
    chains = rc.list_chains()
    print(f"✓ Total chains tracked: {len(chains)}")

    # Stats
    stats = rc.get_stats()
    print(f"✓ Stats: {stats}")

    # Remove chain
    removed = rc.remove_chain("intent-002")
    assert removed, "remove_chain should succeed"
    assert rc.get_chain("intent-002") is None, "Chain should be gone"
    print(f"✓ Chain intent-002 removed")

    print("\n=== All ReceiptChain tests passed! ===\n")
