"""
SIMP Adaptive Batching — T30-8

Dynamically adjusts batching parameters based on broker load:
  - Load < 30%: batch_size=25, max_latency=2ms (more batching)
  - Load 30-70%: batch_size=50, max_latency=1ms (balanced)
  - Load > 70%: batch_size=10, max_latency=0.1ms (minimal batching)

Load = CPU + queue depth + active agent count.

Files: simp/mesh/adaptive_batcher.py, simp/broker/load_monitor.py
"""

from __future__ import annotations

import json
import logging
import psutil
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Callable

logger = logging.getLogger("SIMP.AdaptiveBatcher")


# ---------------------------------------------------------------------------
# Load Tier
# ---------------------------------------------------------------------------


class LoadTier(str, Enum):
    """Broker load tiers for adaptive batching."""
    LOW = "low"      # < 30%: batch_size=25, max_latency=2ms
    MEDIUM = "medium"  # 30-70%: batch_size=50, max_latency=1ms
    HIGH = "high"    # > 70%: batch_size=10, max_latency=0.1ms


# ---------------------------------------------------------------------------
# Batch Config per Tier
# ---------------------------------------------------------------------------


@dataclass
class AdaptiveBatchConfig:
    """
    Adaptive batching configuration per load tier.

    Attributes:
        batch_size: Maximum intents per batch
        max_latency_ms: Maximum time to wait before flushing
        tier: The load tier this config applies to
    """
    batch_size: int
    max_latency_ms: float
    tier: LoadTier


# Default configs per tier
TIER_CONFIGS = {
    LoadTier.LOW: AdaptiveBatchConfig(batch_size=25, max_latency_ms=2.0, tier=LoadTier.LOW),
    LoadTier.MEDIUM: AdaptiveBatchConfig(batch_size=50, max_latency_ms=1.0, tier=LoadTier.MEDIUM),
    LoadTier.HIGH: AdaptiveBatchConfig(batch_size=10, max_latency_ms=0.1, tier=LoadTier.HIGH),
}

# Thresholds
LOW_THRESHOLD = 0.30
HIGH_THRESHOLD = 0.70


# ---------------------------------------------------------------------------
# Load Monitor
# ---------------------------------------------------------------------------


@dataclass
class BrokerLoad:
    """
    Snapshot of broker load metrics.

    Attributes:
        cpu_percent: Current CPU usage (0.0–1.0)
        queue_depth: Number of pending intents in queue
        active_agents: Number of connected agents
        load_score: Combined load metric (0.0–1.0)
        tier: Computed LoadTier
        measured_at: ISO timestamp
    """
    cpu_percent: float
    queue_depth: int
    active_agents: int
    load_score: float
    tier: LoadTier
    measured_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%dT%H:%M:%SZ"))


class LoadMonitor:
    """
    Monitors broker load metrics for adaptive batching decisions.

    Collects:
      - CPU usage via psutil
      - Queue depth from the priority message queue
      - Active agent count from the agent registry

    Computes a composite load score and determines the current LoadTier.
    """

    def __init__(
        self,
        priority_queue=None,
        agent_registry=None,
        process: Optional[Any] = None,
    ):
        """
        Initialize LoadMonitor.

        Args:
            priority_queue: PriorityMessageQueue instance
            agent_registry: AgentRegistry instance
            process: psutil.Process instance (defaults to current process)
        """
        self._priority_queue = priority_queue
        self._agent_registry = agent_registry
        self._process = process or psutil.Process()

        self._lock = threading.RLock()
        self._current_load: Optional[BrokerLoad] = None
        self._load_history: List[BrokerLoad] = []
        self._max_history = 1000  # Keep last 1000 samples

        # Configuration
        self._cpu_weight = 0.4
        self._queue_weight = 0.4
        self._agent_weight = 0.2

        # CPU baseline (100% = 1.0)
        self._cpu_baseline = psutil.cpu_count() or 1

        logger.info("LoadMonitor initialized")

    def set_priority_queue(self, queue) -> None:
        """Set the priority queue reference."""
        self._priority_queue = queue

    def set_agent_registry(self, registry) -> None:
        """Set the agent registry reference."""
        self._agent_registry = registry

    def measure(self) -> BrokerLoad:
        """
        Measure current broker load.

        Returns:
            BrokerLoad snapshot with current metrics
        """
        # CPU usage
        try:
            cpu_percent = self._process.cpu_percent(interval=0.001) / 100.0
        except Exception:
            cpu_percent = 0.0

        # Queue depth
        queue_depth = 0
        if self._priority_queue:
            try:
                queue_depth = self._priority_queue.size()
            except Exception:
                pass

        # Active agents
        active_agents = 0
        if self._agent_registry:
            try:
                active_agents = len(self._agent_registry.list_agents())
            except Exception:
                pass

        # Compute load score (composite)
        # CPU: 0-100% maps to 0-1
        cpu_score = min(cpu_percent, 1.0)

        # Queue: log scale, 1000+ intents = max
        queue_score = min(queue_depth / 1000.0, 1.0)

        # Agents: 50+ agents = max
        agent_score = min(active_agents / 50.0, 1.0)

        load_score = (
            self._cpu_weight * cpu_score +
            self._queue_weight * queue_score +
            self._agent_weight * agent_score
        )

        # Determine tier
        if load_score < LOW_THRESHOLD:
            tier = LoadTier.LOW
        elif load_score < HIGH_THRESHOLD:
            tier = LoadTier.MEDIUM
        else:
            tier = LoadTier.HIGH

        load = BrokerLoad(
            cpu_percent=cpu_percent,
            queue_depth=queue_depth,
            active_agents=active_agents,
            load_score=load_score,
            tier=tier,
        )

        with self._lock:
            self._current_load = load
            self._load_history.append(load)
            if len(self._load_history) > self._max_history:
                self._load_history = self._load_history[-self._max_history:]

        return load

    def get_current_load(self) -> Optional[BrokerLoad]:
        """Get the most recent load measurement."""
        with self._lock:
            return self._current_load

    def get_load_tier(self) -> LoadTier:
        """Get current load tier (measures if needed)."""
        if self._current_load is None:
            self.measure()
        return self._current_load.tier if self._current_load else LoadTier.MEDIUM

    def get_config(self) -> AdaptiveBatchConfig:
        """Get the batch config for the current load tier."""
        tier = self.get_load_tier()
        return TIER_CONFIGS[tier]

    def get_statistics(self) -> Dict[str, Any]:
        """Get load monitor statistics."""
        with self._lock:
            history = self._load_history[-100:]  # Last 100 samples

            avg_cpu = sum(h.cpu_percent for h in history) / max(len(history), 1)
            avg_queue = sum(h.queue_depth for h in history) / max(len(history), 1)
            avg_load = sum(h.load_score for h in history) / max(len(history), 1)

            tier_counts = {tier.value: 0 for tier in LoadTier}
            for h in history:
                tier_counts[h.tier.value] += 1

            return {
                "current_load_score": self._current_load.load_score if self._current_load else None,
                "current_tier": self._current_load.tier.value if self._current_load else None,
                "avg_cpu_percent": round(avg_cpu, 4),
                "avg_queue_depth": round(avg_queue, 1),
                "avg_load_score": round(avg_load, 4),
                "sample_count": len(self._load_history),
                "tier_distribution": tier_counts,
                "weights": {
                    "cpu": self._cpu_weight,
                    "queue": self._queue_weight,
                    "agent": self._agent_weight,
                },
            }


# ---------------------------------------------------------------------------
# Adaptive Batcher
# ---------------------------------------------------------------------------


class AdaptiveBatcher:
    """
    Adaptive batching that adjusts based on broker load.

    Wraps OutboundBatcher (from batcher.py) and dynamically updates
    its batch_size and max_latency based on current LoadTier.

    Usage:
      adaptive_batcher = AdaptiveBatcher(agent_id="agent-1", load_monitor=monitor)
      adaptive_batcher.start()

      # Add intents — batching adapts automatically
      adaptive_batcher.add(intent)

      # Batcher flushes with optimal params for current load
    """

    def __init__(
        self,
        agent_id: str,
        send_func: Callable[[bytes], None],
        load_monitor: Optional[LoadMonitor] = None,
    ):
        """
        Initialize AdaptiveBatcher.

        Args:
            agent_id: This agent's ID
            send_func: Called when batch is flushed
            load_monitor: LoadMonitor instance (creates one if None)
        """
        self.agent_id = agent_id
        self.send_func = send_func
        self.load_monitor = load_monitor or LoadMonitor()

        self._lock = threading.RLock()
        self._shutdown = False

        # Current config (starts with MEDIUM)
        self._current_config = TIER_CONFIGS[LoadTier.MEDIUM]

        # Create initial batcher
        from simp.mesh.batcher import OutboundBatcher, BatchConfig

        self._batcher = OutboundBatcher(
            agent_id=agent_id,
            send_func=send_func,
            config=BatchConfig(
                batch_max_latency_ms=self._current_config.max_latency_ms,
                batch_max_size=self._current_config.batch_size,
            ),
        )

        # Statistics
        self._stats = {
            "tier_changes": 0,
            "last_tier": LoadTier.MEDIUM.value,
            "config_updates": 0,
        }

        # Background thread for adaptive updates
        self._adapt_thread: Optional[threading.Thread] = None
        self._adapt_event = threading.Event()

        logger.info(f"AdaptiveBatcher[{agent_id}] initialized (tier={LoadTier.MEDIUM.value})")

    # -------------------------------------------------------------------------
    # Public API (delegates to underlying batcher)
    # -------------------------------------------------------------------------

    def add(self, intent: Dict[str, Any]) -> None:
        """Add an intent to the current batch."""
        self._batcher.add(intent)

    def add_batch(self, intents: List[Dict[str, Any]]) -> None:
        """Add multiple intents."""
        self._batcher.add_batch(intents)

    def flush(self) -> int:
        """Force flush current batch."""
        return self._batcher.flush()

    def size(self) -> int:
        """Current batch size."""
        return self._batcher.size()

    def get_statistics(self) -> Dict[str, Any]:
        """Get combined statistics."""
        with self._lock:
            batcher_stats = self._batcher.get_statistics()
            monitor_stats = self.load_monitor.get_statistics()
            return {
                **batcher_stats,
                **self._stats,
                "current_tier": self._current_config.tier.value,
                "current_batch_size": self._current_config.batch_size,
                "current_max_latency_ms": self._current_config.max_latency_ms,
                "load_monitor": monitor_stats,
            }

    # -------------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------------

    def start(self) -> None:
        """Start adaptive monitoring thread."""
        with self._lock:
            if self._adapt_thread and self._adapt_thread.is_alive():
                return
            self._adapt_event.clear()
            self._adapt_thread = threading.Thread(
                target=self._adapt_loop,
                name=f"AdaptiveBatcher-{self.agent_id}",
                daemon=True,
            )
            self._adapt_thread.start()
            logger.info(f"AdaptiveBatcher[{self.agent_id}] started")

    def stop(self) -> None:
        """Stop adaptive monitoring."""
        self._shutdown = True
        self._adapt_event.set()
        if self._adapt_thread:
            self._adapt_thread.join(timeout=3.0)

    def shutdown(self) -> None:
        """Full shutdown."""
        self.stop()
        self._batcher.shutdown()

    # -------------------------------------------------------------------------
    # Internal
    # -------------------------------------------------------------------------

    def _adapt_loop(self) -> None:
        """Background thread: periodically re-measure and adapt."""
        while not self._shutdown:
            try:
                self._adapt()
            except Exception:
                logger.exception(f"AdaptiveBatcher[{self.agent_id}] adapt error")

            self._adapt_event.wait(timeout=1.0)  # Check every second

    def _adapt(self) -> None:
        """Measure load and update batcher config if tier changed."""
        # Measure current load
        load = self.load_monitor.measure()
        new_tier = load.tier
        new_config = TIER_CONFIGS[new_tier]

        if new_tier != self._current_config.tier:
            # Tier changed — update batcher config
            old_tier = self._current_config.tier

            with self._lock:
                self._stats["tier_changes"] += 1
                self._stats["last_tier"] = new_tier.value

            # Update underlying batcher
            from simp.mesh.batcher import BatchConfig
            self._batcher = OutboundBatcher(
                agent_id=self.agent_id,
                send_func=self.send_func,
                config=BatchConfig(
                    batch_max_latency_ms=new_config.max_latency_ms,
                    batch_max_size=new_config.batch_size,
                ),
            )

            self._current_config = new_config
            self._stats["config_updates"] += 1

            logger.info(
                f"AdaptiveBatcher[{self.agent_id}] tier change: {old_tier.value} -> {new_tier.value} "
                f"(batch_size={new_config.batch_size}, latency={new_config.max_latency_ms}ms, "
                f"load_score={load.load_score:.3f})"
            )


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------


def get_adaptive_config_for_load(
    cpu_percent: float,
    queue_depth: int,
    active_agents: int,
) -> AdaptiveBatchConfig:
    """
    Compute adaptive batch config from raw metrics.

    Standalone function for when you have metrics but no LoadMonitor.
    """
    cpu_score = min(cpu_percent, 1.0)
    queue_score = min(queue_depth / 1000.0, 1.0)
    agent_score = min(active_agents / 50.0, 1.0)

    load_score = 0.4 * cpu_score + 0.4 * queue_score + 0.2 * agent_score

    if load_score < LOW_THRESHOLD:
        return TIER_CONFIGS[LoadTier.LOW]
    elif load_score < HIGH_THRESHOLD:
        return TIER_CONFIGS[LoadTier.MEDIUM]
    else:
        return TIER_CONFIGS[LoadTier.HIGH]
