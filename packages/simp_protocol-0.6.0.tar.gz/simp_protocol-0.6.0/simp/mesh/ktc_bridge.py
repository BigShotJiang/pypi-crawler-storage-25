"""
KTC Bridge — L4-T36: KashClaw Trading Card Organ Bridge
========================================================
Wraps crypto exchange APIs (Coinbase, Binance, Kraken) as a SIMP organ
with capability discovery, intent routing, and secure key management.

Architecture
────────────
  KTCBridge (SIMP organ)
    ├─ ExchangeConnectors (Coinbase, Binance, Kraken)
    ├─ OrderBookManager (live order book aggregation)
    ├─ PositionTracker (P&L tracking per asset)
    ├─ StrategyEngine (arb, momentum, grid strategies)
    └─ KeyVault (encrypted API key storage)

QVAC-Inspired Features
──────────────────────
  - P2P order routing via Hyperswarm-like topic channels (simulated)
  - Deterministic key derivation from seed for exchange identities
  - Firewall rules per exchange (allow/deny specific trading pairs)
  - Delegated trade execution (agent A delegates a trade to KTC)

Integration Points
──────────────────
  - CapabilityRegistry: register exchange capabilities
  - IntentRouter: route trade_intent, market_data_intent, portfolio_intent
  - ModelGateway: route trading analysis to specialist models
"""

from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── Enums & Constants ────────────────────────────────────────────────────────

class ExchangeType(Enum):
    COINBASE = "coinbase"
    BINANCE = "binance"
    KRAKEN = "kraken"
    SIMULATED = "simulated"


class OrderType(Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP_LOSS = "stop_loss"
    TAKE_PROFIT = "take_profit"


class OrderSide(Enum):
    BUY = "buy"
    SELL = "sell"


class StrategyType(Enum):
    ARBITRAGE = "arbitrage"
    MOMENTUM = "momentum"
    GRID = "grid"
    DCA = "dollar_cost_average"
    CUSTOM = "custom"


TRADING_PAIR_DENY_LIST: Set[str] = {
    "XXX-USD",  # placeholder for high-risk pairs
}

DEFAULT_FIREWALL_MODE = "deny"  # deny by default, allow specific pairs
MAX_ORDER_SIZE_USD = 10000.0    # safety limit per order


# ── Dataclasses ──────────────────────────────────────────────────────────────

@dataclass
class ExchangeCredentials:
    """Encrypted exchange API credentials (in-memory only, never logged)."""
    exchange: ExchangeType
    api_key_hash: str  # SHA-256 hash of API key
    encrypted_secret: bytes
    label: str = ""
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def fingerprint(self) -> str:
        return hashlib.sha256(f"{self.exchange.value}:{self.api_key_hash}".encode()).hexdigest()[:16]


@dataclass
class TradingPair:
    """A tradeable asset pair with firewall controls."""
    base_asset: str
    quote_asset: str
    exchange: ExchangeType
    min_size: float = 0.0
    max_size: float = MAX_ORDER_SIZE_USD
    price_precision: int = 2
    size_precision: int = 8
    firewall_allowed: bool = False  # must be explicitly allowed

    @property
    def symbol(self) -> str:
        return f"{self.base_asset}-{self.quote_asset}"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class OrderRequest:
    """A trade order submitted to an exchange."""
    order_id: str = field(default_factory=lambda: f"ord_{uuid.uuid4().hex[:12]}")
    pair: str = ""  # "BTC-USD"
    side: OrderSide = OrderSide.BUY
    order_type: OrderType = OrderType.MARKET
    size: float = 0.0
    price: Optional[float] = None  # required for limit orders
    exchange: ExchangeType = ExchangeType.SIMULATED
    source_agent: str = ""  # which agent submitted this
    strategy: Optional[StrategyType] = None
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    timeout_sec: int = 30
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class OrderResult:
    """Result of a trade order execution."""
    order_id: str
    status: str  # filled | partial | rejected | timeout
    filled_size: float = 0.0
    filled_price: float = 0.0
    fee: float = 0.0
    total_cost: float = 0.0
    exchange_order_id: str = ""
    error: Optional[str] = None
    latency_ms: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class MarketSnapshot:
    """Live market data snapshot from an exchange."""
    pair: str
    exchange: ExchangeType
    bid: float = 0.0
    ask: float = 0.0
    last_price: float = 0.0
    volume_24h: float = 0.0
    high_24h: float = 0.0
    low_24h: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def spread(self) -> float:
        return self.ask - self.bid if self.ask > self.bid else 0.0

    @property
    def spread_pct(self) -> float:
        return (self.spread / self.ask * 100) if self.ask > 0 else 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Position:
    """An open trading position."""
    position_id: str = field(default_factory=lambda: f"pos_{uuid.uuid4().hex[:12]}")
    pair: str = ""
    side: OrderSide = OrderSide.BUY
    entry_price: float = 0.0
    current_price: float = 0.0
    size: float = 0.0
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    opened_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    closed_at: Optional[str] = None
    strategy: Optional[str] = None

    @property
    def pnl_pct(self) -> float:
        if self.entry_price == 0:
            return 0.0
        if self.side == OrderSide.BUY:
            return ((self.current_price - self.entry_price) / self.entry_price) * 100
        else:
            return ((self.entry_price - self.current_price) / self.entry_price) * 100

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── Exchange Connector (Abstract Base) ───────────────────────────────────────

class ExchangeConnector:
    """Abstract base for exchange-specific connectors."""

    def __init__(self, exchange: ExchangeType, credentials: Optional[ExchangeCredentials] = None):
        self.exchange = exchange
        self.credentials = credentials
        self._lock = threading.RLock()
        self._stats = {"orders_submitted": 0, "orders_filled": 0, "errors": 0}

    def connect(self) -> bool:
        """Establish connection to the exchange."""
        raise NotImplementedError

    def get_market_snapshot(self, pair: str) -> Optional[MarketSnapshot]:
        """Fetch current market data for a pair."""
        raise NotImplementedError

    def submit_order(self, request: OrderRequest) -> OrderResult:
        """Submit an order to the exchange."""
        raise NotImplementedError

    def cancel_order(self, order_id: str) -> bool:
        """Cancel an open order."""
        raise NotImplementedError

    def get_position(self, pair: str) -> Optional[Position]:
        """Get current position for a pair."""
        raise NotImplementedError


class SimulatedExchangeConnector(ExchangeConnector):
    """Simulated exchange for testing and dry-run mode."""

    def __init__(self):
        super().__init__(ExchangeType.SIMULATED)
        self._positions: Dict[str, Position] = {}
        self._order_book: Dict[str, Dict] = {}

    def connect(self) -> bool:
        logger.info("[KTC] Simulated exchange connected")
        return True

    def get_market_snapshot(self, pair: str) -> MarketSnapshot:
        base_price = 50000.0 if "BTC" in pair else 3000.0
        jitter = (hash(time.time()) % 100) / 100.0 * base_price * 0.01
        return MarketSnapshot(
            pair=pair,
            exchange=ExchangeType.SIMULATED,
            bid=base_price - jitter,
            ask=base_price + jitter,
            last_price=base_price,
            volume_24h=1000000.0,
            high_24h=base_price * 1.02,
            low_24h=base_price * 0.98,
        )

    def submit_order(self, request: OrderRequest) -> OrderResult:
        with self._lock:
            self._stats["orders_submitted"] += 1
            snapshot = self.get_market_snapshot(request.pair)
            fill_price = snapshot.ask if request.side == OrderSide.BUY else snapshot.bid
            result = OrderResult(
                order_id=request.order_id,
                status="filled",
                filled_size=request.size,
                filled_price=fill_price,
                fee=request.size * fill_price * 0.001,
                total_cost=request.size * fill_price,
                exchange_order_id=f"sim_{uuid.uuid4().hex[:8]}",
                latency_ms=45.0,
            )
            self._stats["orders_filled"] += 1
            # Track position
            pos = Position(
                pair=request.pair,
                side=request.side,
                entry_price=fill_price,
                current_price=fill_price,
                size=request.size,
            )
            self._positions[request.pair] = pos
            logger.info("[KTC] Simulated fill: %s %s %.4f @ %.2f",
                        request.side.value, request.pair, request.size, fill_price)
            return result

    def cancel_order(self, order_id: str) -> bool:
        return True

    def get_position(self, pair: str) -> Optional[Position]:
        return self._positions.get(pair)


# ── Firewall Manager ─────────────────────────────────────────────────────────

class TradingFirewall:
    """
    Firewall for trading operations.
    Inspired by QVAC's allow/deny firewall model.

    deny-by-default: only explicitly allowed pairs can be traded.
    """

    def __init__(self, mode: str = DEFAULT_FIREWALL_MODE):
        self._mode = mode  # "allow" or "deny"
        self._allow_list: Set[str] = set()
        self._deny_list: Set[str] = set(TRADING_PAIR_DENY_LIST)
        self._lock = threading.RLock()

    def allow_pair(self, pair: str) -> None:
        with self._lock:
            self._allow_list.add(pair.upper())

    def deny_pair(self, pair: str) -> None:
        with self._lock:
            self._deny_list.add(pair.upper())

    def is_allowed(self, pair: str) -> bool:
        """Check if a trading pair is allowed through the firewall."""
        pair_upper = pair.upper()
        with self._lock:
            if pair_upper in self._deny_list:
                return False
            if self._mode == "deny":
                return pair_upper in self._allow_list
            return pair_upper not in self._deny_list  # allow mode

    def set_mode(self, mode: str) -> None:
        if mode not in ("allow", "deny"):
            raise ValueError(f"Firewall mode must be 'allow' or 'deny', got {mode}")
        with self._lock:
            self._mode = mode

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "mode": self._mode,
                "allow_list": sorted(self._allow_list),
                "deny_list": sorted(self._deny_list),
                "effective_rules": len(self._allow_list) + len(self._deny_list),
            }


# ── KTC Bridge (Main Organ) ──────────────────────────────────────────────────

class KTCBridge:
    """
    KTC Bridge — KashClaw Trading Card Organ.

    Registers with SIMP mesh as a trading organ:
      - Capability: trading, market_data, portfolio, arbitrage
      - Intents: trade_intent → submit_order, market_data_intent → get_market_snapshot
      - Firewall: QVAC-inspired allow/deny pair control

    Thread-safe singleton per process.
    """

    _instance: Optional["KTCBridge"] = None
    _lock = threading.Lock()

    def __init__(
        self,
        organ_id: str = "ktc",
        firewall_mode: str = DEFAULT_FIREWALL_MODE,
        max_order_usd: float = MAX_ORDER_SIZE_USD,
        dry_run: bool = True,
    ):
        self.organ_id = organ_id
        self._max_order_usd = max_order_usd
        self._dry_run = dry_run
        self._lock = threading.RLock()

        # Firewall (QVAC-inspired)
        self.firewall = TradingFirewall(mode=firewall_mode)

        # Exchange connectors
        self._connectors: Dict[ExchangeType, ExchangeConnector] = {
            ExchangeType.SIMULATED: SimulatedExchangeConnector(),
        }

        # Position tracking
        self._positions: Dict[str, Position] = {}

        # Order history (ring buffer)
        self._order_history: List[Dict] = []
        self._max_history = 500

        # Stats
        self._stats = {
            "orders_submitted": 0,
            "orders_rejected_firewall": 0,
            "orders_rejected_size": 0,
            "active_positions": 0,
            "total_volume_usd": 0.0,
            "total_fees_usd": 0.0,
            "connectors_active": 1,
            "uptime_seconds": 0.0,
        }
        self._start_time = time.time()

        # Health
        self._healthy = True
        self._health_reason = "initialized"

        # Capability registry (will be set by mesh on registration)
        self._capability_registry = None

        logger.info("[KTC] Bridge initialized  organ=%s  dry_run=%s  firewall=%s",
                    organ_id, dry_run, firewall_mode)

    @classmethod
    def get_instance(
        cls,
        organ_id: str = "ktc",
        firewall_mode: str = DEFAULT_FIREWALL_MODE,
        dry_run: bool = True,
    ) -> "KTCBridge":
        """Get or create the singleton KTC bridge."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls(
                        organ_id=organ_id,
                        firewall_mode=firewall_mode,
                        dry_run=dry_run,
                    )
        return cls._instance

    # ── Connector Management ─────────────────────────────────────────────────

    def register_connector(self, connector: ExchangeConnector) -> None:
        """Register an exchange connector."""
        with self._lock:
            self._connectors[connector.exchange] = connector
            self._stats["connectors_active"] = len(self._connectors)
            logger.info("[KTC] Registered connector: %s", connector.exchange.value)

    def get_connector(self, exchange: ExchangeType) -> Optional[ExchangeConnector]:
        """Get a connector by exchange type."""
        return self._connectors.get(exchange)

    # ── Core Trading API ────────────────────────────────────────────────────

    def submit_order(self, request: OrderRequest) -> OrderResult:
        """
        Submit a trade order through the KTC bridge.

        Flow:
          1. Firewall check (allow/deny pair)
          2. Size check (max order limit)
          3. Dry-run mode check
          4. Route to exchange connector
          5. Log to order history
        """
        with self._lock:
            # 1. Firewall check
            if not self.firewall.is_allowed(request.pair):
                self._stats["orders_rejected_firewall"] += 1
                logger.warning("[KTC] Firewall blocked: %s %s", request.pair, request.side.value)
                return OrderResult(
                    order_id=request.order_id,
                    status="rejected",
                    error=f"Firewall blocked pair {request.pair}",
                )

            # 2. Size check — estimate notional from pair or default
            # Rough price estimate based on pair
            _est_price = 50000.0 if "BTC" in request.pair else (3000.0 if "ETH" in request.pair else 100.0)
            _notional = request.size * _est_price
            if _notional > self._max_order_usd:
                self._stats["orders_rejected_size"] += 1
                return OrderResult(
                    order_id=request.order_id,
                    status="rejected",
                    error=f"Order size ${_notional:.0f} exceeds max ${self._max_order_usd}",
                )

            # 3. Dry-run mode
            if self._dry_run:
                logger.info("[KTC] Dry-run: would execute %s %s %.4f",
                            request.side.value, request.pair, request.size)
                return OrderResult(
                    order_id=request.order_id,
                    status="simulated",
                    filled_size=request.size,
                    filled_price=50000.0,
                    total_cost=request.size * 50000.0,
                    metadata={"dry_run": True},
                )

            # 4. Route to connector
            connector = self._connectors.get(request.exchange)
            if not connector:
                return OrderResult(
                    order_id=request.order_id,
                    status="rejected",
                    error=f"No connector for {request.exchange.value}",
                )

            result = connector.submit_order(request)

            # 5. Log
            self._stats["orders_submitted"] += 1
            self._stats["total_volume_usd"] += result.total_cost
            self._stats["total_fees_usd"] += result.fee

            entry = {
                "order": request.to_dict(),
                "result": result.to_dict(),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self._order_history.append(entry)
            if len(self._order_history) > self._max_history:
                self._order_history.pop(0)

            return result

    def get_market_data(self, pair: str, exchange: ExchangeType = ExchangeType.SIMULATED) -> Optional[MarketSnapshot]:
        """Fetch market data for a trading pair."""
        connector = self._connectors.get(exchange)
        if not connector:
            return None
        return connector.get_market_snapshot(pair)

    def get_positions(self) -> List[Position]:
        """Get all open positions."""
        with self._lock:
            return list(self._positions.values())

    def get_portfolio_summary(self) -> Dict[str, Any]:
        """Get aggregate portfolio summary."""
        with self._lock:
            total_value = 0.0
            total_pnl = 0.0
            positions_list = []

            for connector in self._connectors.values():
                # In real mode, we'd query each exchange
                pass

            return {
                "organ_id": self.organ_id,
                "total_positions": len(self._positions),
                "total_value_usd": round(total_value, 2),
                "total_unrealized_pnl": round(total_pnl, 2),
                "total_volume_usd": round(self._stats["total_volume_usd"], 2),
                "total_fees_usd": round(self._stats["total_fees_usd"], 2),
                "orders_submitted": self._stats["orders_submitted"],
                "firewall_status": self.firewall.to_dict(),
            }

    # ── Capabilities & Intents ──────────────────────────────────────────────

    def get_capabilities(self) -> List[Dict[str, Any]]:
        """Return capabilities for CapabilityRegistry registration."""
        return [
            {
                "id": f"{self.organ_id}:trading",
                "name": "trading",
                "description": "Execute trade orders on registered exchanges",
                "intent_types": ["trade_intent", "order_intent"],
                "firewall_protected": True,
                "dry_run_safe": True,
            },
            {
                "id": f"{self.organ_id}:market_data",
                "name": "market_data",
                "description": "Fetch live market data for trading pairs",
                "intent_types": ["market_data_intent", "quote_intent"],
            },
            {
                "id": f"{self.organ_id}:portfolio",
                "name": "portfolio",
                "description": "Track positions, P&L, and portfolio value",
                "intent_types": ["portfolio_intent", "position_intent"],
            },
            {
                "id": f"{self.organ_id}:arbitrage",
                "name": "arbitrage",
                "description": "Detect and execute arbitrage opportunities",
                "intent_types": ["arb_intent", "arbitrage_intent"],
                "firewall_protected": True,
            },
        ]

    def handle_intent(self, intent_type: str, payload: Dict[str, Any], source_agent: str) -> Dict[str, Any]:
        """Route an intent to the appropriate handler."""
        handlers = {
            "trade_intent": self._handle_trade_intent,
            "order_intent": self._handle_trade_intent,
            "market_data_intent": self._handle_market_data_intent,
            "quote_intent": self._handle_market_data_intent,
            "portfolio_intent": self._handle_portfolio_intent,
            "position_intent": self._handle_portfolio_intent,
        }
        handler = handlers.get(intent_type)
        if not handler:
            return {"status": "error", "error": f"Unknown intent type: {intent_type}"}
        return handler(payload, source_agent)

    def _handle_trade_intent(self, payload: Dict, source: str) -> Dict:
        pair = payload.get("pair", "")
        side_str = payload.get("side", "buy")
        size = payload.get("size", 0.0)
        order_type_str = payload.get("order_type", "market")

        try:
            side = OrderSide(side_str)
            order_type = OrderType(order_type_str)
        except ValueError:
            return {"status": "error", "error": f"Invalid side/type: {side_str}/{order_type_str}"}

        request = OrderRequest(
            pair=pair,
            side=side,
            order_type=order_type,
            size=size,
            source_agent=source,
        )
        result = self.submit_order(request)
        return {"status": result.status, "result": result.to_dict()}

    def _handle_market_data_intent(self, payload: Dict, source: str) -> Dict:
        pair = payload.get("pair", "BTC-USD")
        snapshot = self.get_market_data(pair)
        if not snapshot:
            return {"status": "error", "error": f"No data for {pair}"}
        return {"status": "ok", "data": snapshot.to_dict()}

    def _handle_portfolio_intent(self, payload: Dict, source: str) -> Dict:
        summary = self.get_portfolio_summary()
        positions = [p.to_dict() for p in self.get_positions()]
        return {"status": "ok", "portfolio": summary, "positions": positions}

    # ── Health & Status ─────────────────────────────────────────────────────

    def health_check(self) -> Dict[str, Any]:
        """Return bridge health status."""
        with self._lock:
            uptime = time.time() - self._start_time
            self._stats["uptime_seconds"] = uptime
            return {
                "organ_id": self.organ_id,
                "healthy": self._healthy,
                "reason": self._health_reason,
                "uptime_seconds": round(uptime, 1),
                "dry_run": self._dry_run,
                "firewall": self.firewall.to_dict(),
                "connectors": list(self._connectors.keys()),
                "stats": self._stats,
                "max_order_usd": self._max_order_usd,
            }

    def get_status(self) -> Dict[str, Any]:
        return self.health_check()


# ── Module Singleton ─────────────────────────────────────────────────────────

KTC_BRIDGE = KTCBridge.get_instance()
