"""
Intent Deadline Enforcement — L3 mesh module

Manages intent deadlines across the SIMP mesh. Expired intents are
detected by a background thread running every 5 seconds, which fires
registered callbacks for each expired intent.

Design:
- Thread-safe via RLock for concurrent registration and deadline checking
- Background daemon thread wakes every 5s to cancel expired intents
- Callback: on_expired(callback_fn) receives intent_id when expired
- Status tracking: active -> expired/cancelled/completed
"""

import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class IntentStatus(Enum):
    """Lifecycle status of a tracked intent."""
    ACTIVE = "active"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    COMPLETED = "completed"


@dataclass
class TrackedIntent:
    """An intent tracked by the DeadlineEnforcer."""
    intent_id: str
    deadline_timestamp: float
    status: IntentStatus = IntentStatus.ACTIVE
    created_at: float = field(default_factory=time.time)
    expired_at: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def remaining_time(self) -> float:
        """Seconds until deadline. Negative if past deadline."""
        return self.deadline_timestamp - time.time()

    def is_expired(self) -> bool:
        """Check if this intent has passed its deadline."""
        if self.status != IntentStatus.ACTIVE:
            return False
        return time.time() > self.deadline_timestamp

    def to_dict(self) -> Dict[str, Any]:
        return {
            "intent_id": self.intent_id,
            "deadline_timestamp": self.deadline_timestamp,
            "deadline_iso": time.strftime(
                "%Y-%m-%dT%H:%M:%SZ", time.gmtime(self.deadline_timestamp)
            ),
            "status": self.status.value,
            "created_at": self.created_at,
            "expired_at": self.expired_at,
            "remaining_seconds": round(self.remaining_time(), 2),
            "is_expired": self.is_expired(),
        }


class DeadlineEnforcer:
    """Enforces intent deadlines by checking every 5 seconds.

    Intents are registered with a deadline_timestamp (Unix epoch seconds).
    The enforcer runs a background daemon thread that periodically checks
    all tracked intents and fires the on_expired callback for any that
    have passed their deadline.

    Lifecycle:
        submit_intent() -> ACTIVE
        cancel_expired() fires callback -> EXPIRED
        cancel_intent() -> CANCELLED
        complete_intent() -> COMPLETED
    """

    def __init__(self, check_interval: float = 5.0):
        self._check_interval = check_interval
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)

        # Tracked intents: intent_id -> TrackedIntent
        self._intents: Dict[str, TrackedIntent] = {}

        # Expired callback: Callable[[str], None]
        self._on_expired_callback: Optional[Callable[[str], None]] = None

        # Background thread control
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Stats
        self._stats = {
            "total_submitted": 0,
            "total_expired": 0,
            "total_cancelled": 0,
            "total_completed": 0,
            "checks_performed": 0,
        }

        # Start the background thread
        self._start()

        logger.info("DeadlineEnforcer initialized (check_interval=%ss)",
                    check_interval)

    def _start(self) -> None:
        """Start the background deadline checker thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._check_loop,
            daemon=True,
            name="DeadlineEnforcer",
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop the background deadline checker thread."""
        with self._condition:
            self._running = False
            self._condition.notify_all()
        if self._thread:
            self._thread.join(timeout=5.0)
            self._thread = None
        logger.info("DeadlineEnforcer stopped")

    # ------------------------------------------------------------------ #
    # Background Check Loop (runs every check_interval seconds)
    # ------------------------------------------------------------------ #

    def _check_loop(self) -> None:
        """Background loop that periodically checks for expired intents."""
        while self._running:
            try:
                expired_count = self.cancel_expired()
                if expired_count > 0:
                    logger.info("Deadline enforcer expired %d intents",
                                expired_count)
            except Exception as e:
                logger.error("Deadline check error: %s", e)

            # Sleep for check_interval (check for stop signal with condition wait)
            with self._condition:
                if not self._running:
                    break
                self._condition.wait(timeout=self._check_interval)

    # ------------------------------------------------------------------ #
    # Intent Management
    # ------------------------------------------------------------------ #

    def submit_intent(self, intent_id: str,
                      deadline_timestamp: float,
                      metadata: Optional[Dict[str, Any]] = None) -> bool:
        """Register an intent with a deadline for enforcement.

        Args:
            intent_id: Unique intent identifier.
            deadline_timestamp: Unix epoch seconds deadline.
            metadata: Optional metadata attached to this intent.

        Returns:
            True if registered, False if intent_id already exists.
        """
        if metadata is None:
            metadata = {}

        with self._lock:
            if intent_id in self._intents:
                logger.warning("Intent %s already tracked", intent_id)
                return False

            self._intents[intent_id] = TrackedIntent(
                intent_id=intent_id,
                deadline_timestamp=deadline_timestamp,
                status=IntentStatus.ACTIVE,
                metadata=metadata,
            )
            self._stats["total_submitted"] += 1
            logger.debug("Registered intent %s (deadline=%s)",
                         intent_id, deadline_timestamp)
            return True

    def cancel_expired(self) -> int:
        """Check all intents and cancel any that have expired.

        For each expired intent:
        - Status changes to EXPIRED
        - expired_at is recorded
        - on_expired callback (if registered) is called with intent_id

        Returns:
            Number of intents that were expired in this check.
        """
        expired: List[str] = []

        with self._lock:
            self._stats["checks_performed"] += 1
            now = time.time()

            for intent_id, tracked in self._intents.items():
                if (tracked.status == IntentStatus.ACTIVE
                        and now > tracked.deadline_timestamp):
                    tracked.status = IntentStatus.EXPIRED
                    tracked.expired_at = now
                    expired.append(intent_id)
                    self._stats["total_expired"] += 1
                    logger.info("Intent %s expired", intent_id)

        # Fire callbacks outside the lock to prevent deadlock
        if expired and self._on_expired_callback:
            for intent_id in expired:
                try:
                    self._on_expired_callback(intent_id)
                except Exception as e:
                    logger.error("on_expired callback error for %s: %s",
                                 intent_id, e)

        return len(expired)

    def is_expired(self, intent_id: str) -> bool:
        """Check if an intent has expired.

        Args:
            intent_id: Intent to check.

        Returns:
            True if intent is past its deadline (or was already expired).
        """
        with self._lock:
            tracked = self._intents.get(intent_id)
            if tracked is None:
                return False
            return tracked.is_expired() or tracked.status == IntentStatus.EXPIRED

    def get_remaining_time(self, intent_id: str) -> Optional[float]:
        """Get seconds until an intent's deadline.

        Args:
            intent_id: Intent to check.

        Returns:
            Seconds remaining (positive = still active, negative = past deadline)
            or None if intent_id is not tracked.
        """
        with self._lock:
            tracked = self._intents.get(intent_id)
            if tracked is None:
                return None
            return tracked.remaining_time()

    def cancel_intent(self, intent_id: str) -> bool:
        """Manually cancel a tracked intent before its deadline.

        Args:
            intent_id: Intent to cancel.

        Returns:
            True if intent was found and cancelled.
        """
        with self._lock:
            tracked = self._intents.get(intent_id)
            if tracked is None:
                logger.warning("Cannot cancel unknown intent %s", intent_id)
                return False
            if tracked.status != IntentStatus.ACTIVE:
                logger.warning("Cannot cancel %s (status=%s)",
                               intent_id, tracked.status.value)
                return False

            tracked.status = IntentStatus.CANCELLED
            self._stats["total_cancelled"] += 1
            logger.info("Cancelled intent %s", intent_id)
            return True

    def complete_intent(self, intent_id: str) -> bool:
        """Mark a tracked intent as completed.

        Args:
            intent_id: Intent to mark completed.

        Returns:
            True if intent was found and marked completed.
        """
        with self._lock:
            tracked = self._intents.get(intent_id)
            if tracked is None:
                return False
            if tracked.status != IntentStatus.ACTIVE:
                return False
            tracked.status = IntentStatus.COMPLETED
            self._stats["total_completed"] += 1
            logger.debug("Completed intent %s", intent_id)
            return True

    # ------------------------------------------------------------------ #
    # Callbacks
    # ------------------------------------------------------------------ #

    def on_expired(self, callback: Callable[[str], None]) -> None:
        """Register a callback fired when an intent expires.

        The callback receives the intent_id of the expired intent.

        Args:
            callback: Function taking (intent_id: str) -> None.
        """
        self._on_expired_callback = callback
        logger.debug("Registered on_expired callback")

    # ------------------------------------------------------------------ #
    # Queries
    # ------------------------------------------------------------------ #

    def get_all_intents(self) -> List[Dict[str, Any]]:
        """Return all tracked intents with their status.

        Returns:
            List of intent dicts sorted by deadline (earliest first).
        """
        with self._lock:
            intents = [t.to_dict() for t in self._intents.values()]
            intents.sort(key=lambda d: d["deadline_timestamp"])
            return intents

    def get_active_intents(self) -> List[Dict[str, Any]]:
        """Return only ACTIVE intents."""
        with self._lock:
            return [
                t.to_dict()
                for t in self._intents.values()
                if t.status == IntentStatus.ACTIVE
            ]

    def get_expired_intents(self) -> List[Dict[str, Any]]:
        """Return only EXPIRED intents."""
        with self._lock:
            return [
                t.to_dict()
                for t in self._intents.values()
                if t.status == IntentStatus.EXPIRED
            ]

    def get_intent(self, intent_id: str) -> Optional[Dict[str, Any]]:
        """Get details for a specific tracked intent."""
        with self._lock:
            tracked = self._intents.get(intent_id)
            if tracked is None:
                return None
            return tracked.to_dict()

    def get_stats(self) -> Dict[str, Any]:
        """Return enforcer statistics."""
        with self._lock:
            active = sum(
                1 for t in self._intents.values()
                if t.status == IntentStatus.ACTIVE
            )
            return {
                **dict(self._stats),
                "currently_active": active,
                "currently_expired": sum(
                    1 for t in self._intents.values()
                    if t.status == IntentStatus.EXPIRED
                ),
                "check_interval": self._check_interval,
                "running": self._running,
                "thread_alive": (
                    self._thread is not None and self._thread.is_alive()
                ),
            }


# ===================================================================== #
# Verification Block
# ===================================================================== #
if __name__ == "__main__":
    logging.basicConfig(level=logging.WARNING,
                        format="%(levelname)s: %(message)s")

    print("=== DeadlineEnforcer Verification ===\n")

    enforcer = DeadlineEnforcer(check_interval=0.5)

    # Track some intents
    now = time.time()
    expired_callbacks = []

    def on_expired(intent_id):
        expired_callbacks.append(intent_id)
        print(f"  ⏰ Callback fired for: {intent_id}")

    enforcer.on_expired(on_expired)

    # Register intents with varying deadlines
    enforcer.submit_intent("intent-future", now + 60.0,
                           {"desc": "will not expire"})
    enforcer.submit_intent("intent-past", now - 5.0,
                           {"desc": "already expired"})
    enforcer.submit_intent("intent-soon", now + 1.0,
                           {"desc": "expires in 1s"})
    enforcer.submit_intent("intent-cancelled", now + 120.0,
                           {"desc": "will be cancelled"})

    print(f"✓ Submitted 4 intents")

    # Check stats
    stats = enforcer.get_stats()
    assert stats["total_submitted"] == 4
    print(f"✓ Total submitted: {stats['total_submitted']}")

    # Check is_expired for the past-due intent
    assert enforcer.is_expired("intent-past"), "intent-past should be expired"
    assert not enforcer.is_expired("intent-future"), "intent-future should not be expired"
    print("✓ is_expired checks correct")

    # Check remaining_time
    remaining = enforcer.get_remaining_time("intent-future")
    assert remaining is not None and remaining > 50.0, \
        f"Expected >50s remaining, got {remaining}"
    past_remaining = enforcer.get_remaining_time("intent-past")
    assert past_remaining is not None and past_remaining < 0, \
        f"Expected negative remaining for past intent, got {past_remaining}"
    print(f"✓ Remaining time: future={remaining:.1f}s, past={past_remaining:.1f}s")

    # Cancel an intent
    cancelled = enforcer.cancel_intent("intent-cancelled")
    assert cancelled, "cancel_intent should succeed"
    intent_c = enforcer.get_intent("intent-cancelled")
    assert intent_c["status"] == "cancelled"
    print(f"✓ Cancelled intent-cancelled: status={intent_c['status']}")

    # Complete an intent
    completed = enforcer.complete_intent("intent-future")
    assert completed, "complete_intent should succeed"
    intent_f = enforcer.get_intent("intent-future")
    assert intent_f["status"] == "completed"
    print(f"✓ Completed intent-future: status={intent_f['status']}")

    # Run cancel_expired manually — should fire callback for past and soon
    import time as _time

    # First check: should catch the past-due one
    expired_count = enforcer.cancel_expired()
    print(f"✓ Manual check #1: {expired_count} expired (intent-past)")
    assert "intent-past" in expired_callbacks, \
        "intent-past should have fired callback"

    # Wait for intent-soon to expire
    print("  Waiting for intent-soon to expire...")
    _time.sleep(1.5)

    # Second check: should catch intent-soon
    expired_count = enforcer.cancel_expired()
    print(f"✓ Manual check #2: {expired_count} expired (intent-soon)")
    assert "intent-soon" in expired_callbacks, \
        "intent-soon should have fired callback"

    # Check all intents
    all_intents = enforcer.get_all_intents()
    print(f"\nAll intents ({len(all_intents)}):")
    for intent in all_intents:
        print(f"  {intent['intent_id']}: {intent['status']} "
              f"(remaining: {intent['remaining_seconds']}s)")

    # Verify statuses
    status_map = {i["intent_id"]: i["status"] for i in all_intents}
    assert status_map["intent-past"] == "expired"
    assert status_map["intent-soon"] == "expired"
    assert status_map["intent-future"] == "completed"
    assert status_map["intent-cancelled"] == "cancelled"
    print("✓ All statuses correct")

    # Check final stats
    stats = enforcer.get_stats()
    print(f"\nFinal stats: {stats}")

    # Test duplicate submission
    dup = enforcer.submit_intent("intent-future", now + 10.0)
    assert not dup, "Duplicate submission should return False"
    print("✓ Duplicate submission correctly rejected")

    # Test unknown intent
    unknown = enforcer.get_remaining_time("non-existent")
    assert unknown is None
    print("✓ Unknown intent returns None")

    enforcer.stop()
    print("\n=== All DeadlineEnforcer tests passed! ===\n")
