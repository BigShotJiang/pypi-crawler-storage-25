"""
SIMP Message Compression — T30-7

Zstandard compression for large intents:
  - If intent size > 1024 bytes, compress with zstandard
  - Header: {compression: zstd, original_size: N, compressed_size: M}
  - Broker decompresses before schema validation
  - Fallback: route uncompressed if decompress fails

Files: simp/mesh/compression.py
"""

from __future__ import annotations

import io
import json
import logging
import threading
import zstandard
from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger("SIMP.Compression")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Minimum size to trigger compression (bytes)
COMPRESSION_THRESHOLD_BYTES = 1024

# Compression level (1-22, default 3 is a good balance of speed/ratio)
ZSTD_COMPRESSION_LEVEL = 3

# Maximum decompressed size to prevent zip bombs (10MB)
MAX_DECOMPRESSED_SIZE = 10 * 1024 * 1024


# ---------------------------------------------------------------------------
# Compression Metadata
# ---------------------------------------------------------------------------


@dataclass
class CompressionMetadata:
    """
    Metadata header for compressed messages.

    Attributes:
        original_size: Size of the original uncompressed data in bytes
        compressed_size: Size of the compressed data in bytes
        compression_algorithm: Algorithm used ("zstd" for now)
        compression_ratio: Computed ratio for monitoring
    """
    original_size: int
    compressed_size: int
    compression_algorithm: str = "zstd"

    @property
    def compression_ratio(self) -> float:
        if self.original_size == 0:
            return 0.0
        return round(self.compressed_size / self.original_size, 4)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "compression": self.compression_algorithm,
            "original_size": self.original_size,
            "compressed_size": self.compressed_size,
            "compression_ratio": self.compression_ratio,
        }


# ---------------------------------------------------------------------------
# Zstandard Compressor/Decompressor
# ---------------------------------------------------------------------------


class ZstdCompressor:
    """
    Zstandard compression wrapper.

    Uses the python-zstandard library for high-performance compression.
    Falls back to passthrough (no compression) if zstandard is unavailable.
    """

    _available: Optional[bool] = None
    _ctx: Optional[zstandard.ZstdCompressor] = None
    _dctx: Optional[zstandard.ZstdDecompressor] = None

    def __init__(self, level: int = ZSTD_COMPRESSION_LEVEL):
        self._lock = threading.Lock()
        self._level = level
        self._init_ctx()

    def _init_ctx(self) -> None:
        """Initialize compression/decompression contexts."""
        if ZstdCompressor._available is None:
            try:
                ZstdCompressor._ctx = zstandard.ZstdCompressor(level=self._level)
                ZstdCompressor._dctx = zstandard.ZstdDecompressor()
                ZstdCompressor._available = True
                logger.info(f"ZstdCompressor initialized (level={self._level})")
            except ImportError:
                ZstdCompressor._available = False
                logger.warning("zstandard not available, compression disabled")

    @property
    def is_available(self) -> bool:
        return ZstdCompressor._available

    def compress(self, data: bytes) -> Tuple[bytes, CompressionMetadata]:
        """
        Compress data using zstandard.

        Args:
            data: Raw bytes to compress

        Returns:
            Tuple of (compressed_bytes, CompressionMetadata)
        """
        if not self.is_available:
            return data, CompressionMetadata(
                original_size=len(data),
                compressed_size=len(data),
                compression_algorithm="none",
            )

        with self._lock:
            if ZstdCompressor._ctx is None:
                self._init_ctx()

            cctx = ZstdCompressor._ctx
            if cctx is None:
                return data, CompressionMetadata(
                    original_size=len(data),
                    compressed_size=len(data),
                    compression_algorithm="none",
                )

            compressed = cctx.compress(data)
            metadata = CompressionMetadata(
                original_size=len(data),
                compressed_size=len(compressed),
            )
            return compressed, metadata

    def decompress(self, data: bytes, metadata: CompressionMetadata) -> bytes:
        """
        Decompress data using zstandard.

        Args:
            data: Compressed bytes
            metadata: CompressionMetadata from compression

        Returns:
            Original uncompressed bytes

        Raises:
            DecompressionError: If decompression fails
        """
        if metadata.compression_algorithm == "none":
            return data

        if not self.is_available:
            raise DecompressionError(
                f"Cannot decompress {metadata.compression_algorithm}: "
                "zstandard library not available"
            )

        if metadata.compression_algorithm != "zstd":
            raise DecompressionError(f"Unknown compression algorithm: {metadata.compression_algorithm}")

        # Sanity check
        if metadata.original_size > MAX_DECOMPRESSED_SIZE:
            raise DecompressionError(
                f"Refusing to decompress {metadata.original_size} bytes "
                f"(max allowed: {MAX_DECOMPRESSED_SIZE})"
            )

        try:
            with self._lock:
                dctx = ZstdCompressor._dctx
                if dctx is None:
                    raise DecompressionError("Decompression context not initialized")

            # Decompress with size limit
            decompressed = dctx.decompress(data, max_output_size=MAX_DECOMPRESSED_SIZE)
            return decompressed

        except Exception as e:
            raise DecompressionError(f"Decompression failed: {e}") from e


class DecompressionError(Exception):
    """Raised when decompression fails."""
    pass


# ---------------------------------------------------------------------------
# Intent Compression
# ---------------------------------------------------------------------------


class IntentCompressor:
    """
    Handles compression/decompression of intent payloads.

    Can compress:
      - Individual intent payloads
      - Batches of intents (compress the whole batch)

    Compression is applied only when the serialized size exceeds
    COMPRESSION_THRESHOLD_BYTES (default 1024).
    """

    def __init__(self, level: int = ZSTD_COMPRESSION_LEVEL):
        self._compressor = ZstdCompressor(level=level)
        self._stats_lock = threading.Lock()
        self._stats = {
            "intents_compressed": 0,
            "intents_decompressed": 0,
            "bytes_saved": 0,
            "compression_ratio_avg": 0.0,
            "skipped_small": 0,
            "decompression_errors": 0,
        }

    @property
    def is_available(self) -> bool:
        return self._compressor.is_available

    def compress_intent(
        self,
        intent: Dict[str, Any],
    ) -> Tuple[Dict[str, Any], CompressionMetadata]:
        """
        Compress an intent if it exceeds the size threshold.

        Args:
            intent: Intent dict

        Returns:
            Tuple of (modified_intent, metadata)
            The modified_intent has payload replaced with compressed bytes
            and a _compression meta field added
        """
        serialized = json.dumps(intent, separators=(",", ":")).encode("utf-8")
        original_size = len(serialized)

        if original_size < COMPRESSION_THRESHOLD_BYTES:
            self._stats_lock.acquire()
            try:
                self._stats["skipped_small"] += 1
            finally:
                self._stats_lock.release()
            return intent, CompressionMetadata(
                original_size=original_size,
                compressed_size=original_size,
                compression_algorithm="none",
            )

        compressed, metadata = self._compressor.compress(serialized)

        # Add compression metadata to intent
        modified = dict(intent)
        if "meta" not in modified:
            modified["meta"] = {}
        modified["meta"]["_compression"] = metadata.to_dict()
        modified["_compressed_payload"] = compressed.hex()  # Store as hex string
        modified["payload"] = None  # Clear original payload

        with self._stats_lock:
            self._stats["intents_compressed"] += 1
            self._stats["bytes_saved"] += original_size - metadata.compressed_size

            # Running average
            n = self._stats["intents_compressed"]
            old_avg = self._stats["compression_ratio_avg"]
            self._stats["compression_ratio_avg"] = (
                (old_avg * (n - 1) + metadata.compression_ratio) / n
            )

        logger.debug(
            f"IntentCompressor compressed {original_size} -> {metadata.compressed_size} bytes "
            f"(ratio={metadata.compression_ratio})"
        )

        return modified, metadata

    def decompress_intent(
        self,
        intent: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Decompress an intent if it has compression metadata.

        Args:
            intent: Intent dict with _compression metadata

        Returns:
            Original uncompressed intent dict

        Raises:
            DecompressionError: If decompression fails
        """
        meta = intent.get("meta", {}).get("_compression")
        if not meta:
            return intent

        compressed_hex = intent.get("_compressed_payload")
        if not compressed_hex:
            return intent

        try:
            compressed = bytes.fromhex(compressed_hex)
            metadata = CompressionMetadata(
                original_size=meta["original_size"],
                compressed_size=meta["compressed_size"],
                compression_algorithm=meta["compression"],
            )

            decompressed_bytes = self._compressor.decompress(compressed, metadata)
            decompressed = json.loads(decompressed_bytes.decode("utf-8"))

            with self._stats_lock:
                self._stats["intents_decompressed"] += 1

            logger.debug(
                f"IntentCompressor decompressed {metadata.compressed_size} -> "
                f"{metadata.original_size} bytes"
            )

            return decompressed

        except Exception as e:
            with self._stats_lock:
                self._stats["decompression_errors"] += 1
            # Fallback: return as-is if decompression fails
            logger.warning(f"IntentCompressor decompression failed, returning as-is: {e}")
            return intent

    def compress_batch(
        self,
        intents: list[Dict[str, Any]],
    ) -> Tuple[list[Dict[str, Any]], CompressionMetadata]:
        """
        Compress a batch of intents together.

        More efficient than compressing individually when batching.

        Args:
            intents: List of intent dicts

        Returns:
            Tuple of (modified_intents, metadata)
        """
        # Serialize all intents as JSON array
        serialized = json.dumps(intents, separators=(",", ":")).encode("utf-8")
        original_size = len(serialized)

        if original_size < COMPRESSION_THRESHOLD_BYTES:
            return intents, CompressionMetadata(
                original_size=original_size,
                compressed_size=original_size,
                compression_algorithm="none",
            )

        compressed, metadata = self._compressor.compress(serialized)

        # Return single compressed representation
        return [{
            **intents[0],
            "meta": {**(intents[0].get("meta", {})), "_batch_compression": metadata.to_dict()},
            "_compressed_batch": compressed.hex(),
            "_intent_count": len(intents),
            "payload": None,
        }], metadata

    def decompress_batch(
        self,
        compressed_intents: list[Dict[str, Any]],
    ) -> list[Dict[str, Any]]:
        """
        Decompress a batch of intents.

        Args:
            compressed_intents: List with at least one item containing _batch_compression

        Returns:
            Original list of intent dicts
        """
        if not compressed_intents:
            return []

        first = compressed_intents[0]
        batch_meta = first.get("meta", {}).get("_batch_compression")

        if not batch_meta:
            return compressed_intents

        compressed_hex = first.get("_compressed_batch")
        if not compressed_hex:
            return compressed_intents

        try:
            compressed = bytes.fromhex(compressed_hex)
            metadata = CompressionMetadata(
                original_size=batch_meta["original_size"],
                compressed_size=batch_meta["compressed_size"],
                compression_algorithm=batch_meta["compression"],
            )

            decompressed_bytes = self._compressor.decompress(compressed, metadata)
            return json.loads(decompressed_bytes.decode("utf-8"))

        except Exception:
            logger.warning("IntentCompressor batch decompression failed")
            return compressed_intents

    def get_statistics(self) -> Dict[str, Any]:
        with self._stats_lock:
            return dict(self._stats)


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_intent_compressor: Optional[IntentCompressor] = None
_compressor_lock = threading.Lock()


def get_intent_compressor(level: int = ZSTD_COMPRESSION_LEVEL) -> IntentCompressor:
    """Get the singleton IntentCompressor."""
    global _intent_compressor
    with _compressor_lock:
        if _intent_compressor is None:
            _intent_compressor = IntentCompressor(level=level)
        return _intent_compressor


def should_compress(intent: Dict[str, Any]) -> bool:
    """Check if an intent exceeds the compression size threshold."""
    serialized = json.dumps(intent, separators=(",", ":"))
    return len(serialized.encode("utf-8")) >= COMPRESSION_THRESHOLD_BYTES
