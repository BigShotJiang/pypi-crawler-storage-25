"""
Mesh Health Dashboard — Brokered Health & Alerting (Level 3)
=============================================================

Aggregates broker health metrics, alerting, and latency heatmap for the
SIMP mesh. Provides a central view of mesh-wide health status.

Features:
  - Per-broker health updates (online/offline, latency, throughput)
  - Alert recording with severity levels
  - Latency heatmap: broker-to-broker latency matrix
  - Metric history tracking (last N values)
  - Thread-safe via threading.Lock
  - Pure Python (stdlib only)
"""

from __future__ import annotations

import logging
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

SEVERITY_ORDER = {"low": 0, "medium": 1, "high": 2, "critical": 3}


def _severity_ge(a: str, b: str) -> bool:
    return SEVERITY_ORDER.get(a, 0) >= SEVERITY_ORDER.get(b, 0)


@dataclass
class BrokerHealth:
    """Health snapshot for a single broker."""

    broker_id: str
    healthy: bool = True
    latency_ms: float = 0.0
    intent_throughput: float = 0.0  # intents per second
    last_seen: float = field(default_factory=time.time)
    uptime_start: float = field(default_factory=time.time)
    total_intents_processed: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "broker_id": self.broker_id,
            "healthy": self.healthy,
            "latency_ms": self.latency_ms,
            "intent_throughput": self.intent_throughput,
            "last_seen": self.last_seen,
            "uptime_start": self.uptime_start,
            "uptime_seconds": time.time() - self.uptime_start,
            "total_intents_processed": self.total_intents_processed,
        }


@dataclass
class DashboardAlert:
    """A health alert entry."""

    alert_type: str
    message: str
    severity: str  # low, medium, high, critical
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "alert_type": self.alert_type,
            "message": self.message,
            "severity": self.severity,
            "timestamp": self.timestamp,
        }


class MetricHistory:
    """Ring buffer for a time-series metric."""

    def __init__(self, maxlen: int = 100) -> None:
        self._values: Deque[Tuple[float, float]] = deque(maxlen=maxlen)  # (timestamp, value)

    def record(self, value: float, timestamp: Optional[float] = None) -> None:
        self._values.append((timestamp or time.time(), value))

    def get_last(self, count: int) -> List[Dict[str, float]]:
        items = list(self._values)[-count:]
        return [{"timestamp": ts, "value": val} for ts, val in items]

    def __len__(self) -> int:
        return len(self._values)


class MeshHealthDashboard:
    """
    Central health dashboard for the SIMP mesh.

    Tracks per-broker health, records alerts, maintains a latency
    heatmap between brokers, and keeps metric history.

    Args:
        max_metric_history: Maximum values to retain per metric.
    """

    def __init__(self, max_metric_history: int = 100) -> None:
        self._lock = threading.Lock()
        self._broker_health: Dict[str, BrokerHealth] = {}
        self._alerts: List[DashboardAlert] = []

        # Latency heatmap: broker_a -> broker_b -> latency_ms
        self._latency_matrix: Dict[str, Dict[str, float]] = defaultdict(dict)

        # Metric history: metric_name -> MetricHistory
        self._metric_history: Dict[str, MetricHistory] = defaultdict(
            lambda: MetricHistory(maxlen=max_metric_history)
        )

        self._max_metric_history = max_metric_history

    # ── Health Updates ────────────────────────────────────────────────

    def update_broker_health(
        self,
        broker_id: str,
        healthy: bool,
        latency_ms: float,
        intent_throughput: float,
    ) -> Dict[str, Any]:
        """
        Update health metrics for a broker.

        If the broker is new, it is registered automatically.

        Args:
            broker_id: The broker to update.
            healthy: Whether the broker is considered healthy.
            latency_ms: Current latency in milliseconds.
            intent_throughput: Current intent throughput (intents/sec).

        Returns:
            The broker health dict.
        """
        with self._lock:
            if broker_id in self._broker_health:
                bh = self._broker_health[broker_id]
                bh.healthy = healthy
                bh.latency_ms = latency_ms
                bh.intent_throughput = intent_throughput
                bh.last_seen = time.time()
                if healthy:
                    bh.total_intents_processed += int(intent_throughput)
            else:
                bh = BrokerHealth(
                    broker_id=broker_id,
                    healthy=healthy,
                    latency_ms=latency_ms,
                    intent_throughput=intent_throughput,
                )
                self._broker_health[broker_id] = bh

            # Record metric history
            self._metric_history[f"latency_ms.{broker_id}"].record(latency_ms)
            self._metric_history[f"throughput.{broker_id}"].record(intent_throughput)
            self._metric_history["total_brokers"].record(len(self._broker_health))

            return bh.to_dict()

    # ── Alerting ──────────────────────────────────────────────────────

    def record_alert(
        self,
        alert_type: str,
        message: str,
        severity: str = "medium",
    ) -> Dict[str, Any]:
        """
        Record a health alert.

        Args:
            alert_type: Category of the alert (e.g. 'broker_down', 'high_latency').
            message: Human-readable alert description.
            severity: One of 'low', 'medium', 'high', 'critical'.

        Returns:
            The alert dict.
        """
        alert = DashboardAlert(
            alert_type=alert_type,
            message=message,
            severity=severity,
        )
        with self._lock:
            self._alerts.append(alert)
            self._metric_history[f"alerts.{severity}"].record(1.0)
            self._metric_history["total_alerts"].record(len(self._alerts))
        logger.warning("ALERT [%s] %s: %s", severity, alert_type, message)
        return alert.to_dict()

    # ── Queries ───────────────────────────────────────────────────────

    def get_health_summary(self) -> Dict[str, Any]:
        """
        Return a high-level health summary across all brokers.

        Returns:
            {
                "brokers_online": int,
                "brokers_total": int,
                "avg_latency_ms": float,
                "total_throughput": float,
                "alert_count": int
            }
        """
        with self._lock:
            total = len(self._broker_health)
            online = sum(1 for b in self._broker_health.values() if b.healthy)
            if total > 0:
                avg_latency = sum(b.latency_ms for b in self._broker_health.values()) / total
                total_throughput = sum(b.intent_throughput for b in self._broker_health.values())
            else:
                avg_latency = 0.0
                total_throughput = 0.0

            return {
                "brokers_online": online,
                "brokers_total": total,
                "avg_latency_ms": round(avg_latency, 2),
                "total_throughput": round(total_throughput, 2),
                "alert_count": len(self._alerts),
            }

    def get_broker_health(self, broker_id: str) -> Optional[Dict[str, Any]]:
        """
        Return health details for a single broker.

        Args:
            broker_id: The broker to query.

        Returns:
            Health dict, or None if the broker is unknown.
        """
        with self._lock:
            bh = self._broker_health.get(broker_id)
            return bh.to_dict() if bh else None

    def get_latency_heatmap(self) -> Dict[str, Dict[str, float]]:
        """
        Return the broker-to-broker latency matrix.

        Returns:
            {broker_a: {broker_b: latency_ms, ...}, ...}
        """
        with self._lock:
            return {k: dict(v) for k, v in self._latency_matrix.items()}

    def set_latency(self, broker_a: str, broker_b: str, latency_ms: float) -> None:
        """
        Record latency between two brokers (updates heatmap).

        Args:
            broker_a: Source broker.
            broker_b: Target broker.
            latency_ms: Measured latency in milliseconds.
        """
        with self._lock:
            self._latency_matrix[broker_a][broker_b] = latency_ms
            self._latency_matrix[broker_b][broker_a] = latency_ms
            self._metric_history[f"latency_heatmap.{broker_a}.{broker_b}"].record(latency_ms)
            # Also update per-broker latency
            if broker_a in self._broker_health:
                self._broker_health[broker_a].latency_ms = latency_ms

    def get_alerts(self, min_severity: str = "low") -> List[Dict[str, Any]]:
        """
        Return alerts at or above the given severity level.

        Args:
            min_severity: Minimum severity threshold.

        Returns:
            List of alert dicts (newest first).
        """
        with self._lock:
            results = [
                a.to_dict()
                for a in self._alerts
                if _severity_ge(a.severity, min_severity)
            ]
        results.sort(key=lambda x: x["timestamp"], reverse=True)
        return results

    def get_metric_history(
        self,
        metric_name: str,
        count: int = 100,
    ) -> List[Dict[str, float]]:
        """
        Return the last N values for a named metric.

        Metric names follow the convention:
          - ``latency_ms.<broker_id>``
          - ``throughput.<broker_id>``
          - ``alerts.<severity>``
          - ``total_brokers``
          - ``total_alerts``
          - ``latency_heatmap.<a>.<b>``

        Args:
            metric_name: The metric identifier.
            count: Maximum number of data points to return.

        Returns:
            List of {timestamp, value} dicts, oldest first.
        """
        with self._lock:
            history = self._metric_history.get(metric_name)
            if history is None:
                return []
            return history.get_last(count)


# ── Verification Block ────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("MeshHealthDashboard Verification")
    print("=" * 60)

    dash = MeshHealthDashboard(max_metric_history=50)

    # 1. Initial summary (no brokers)
    summary = dash.get_health_summary()
    assert summary["brokers_total"] == 0
    assert summary["brokers_online"] == 0
    print(f"[✓] Empty dashboard summary: {summary}")

    # 2. Update broker health
    h1 = dash.update_broker_health("broker_a", healthy=True, latency_ms=12.5, intent_throughput=45.0)
    h2 = dash.update_broker_health("broker_b", healthy=True, latency_ms=8.3, intent_throughput=120.0)
    h3 = dash.update_broker_health("broker_c", healthy=False, latency_ms=999.0, intent_throughput=0.0)
    assert h1["healthy"] is True
    assert h3["healthy"] is False
    print(f"[✓] 3 brokers updated: {h1['broker_id']}(ok), {h2['broker_id']}(ok), {h3['broker_id']}(down)")

    # 3. Health summary with data
    summary = dash.get_health_summary()
    assert summary["brokers_total"] == 3
    assert summary["brokers_online"] == 2
    assert summary["avg_latency_ms"] > 0
    assert summary["total_throughput"] > 0
    print(f"[✓] Health summary: {summary}")

    # 4. Get broker health (single)
    bh = dash.get_broker_health("broker_a")
    assert bh is not None
    assert bh["latency_ms"] == 12.5
    print(f"[✓] get_broker_health('broker_a'): latency={bh['latency_ms']}ms")

    # 5. Unknown broker returns None
    assert dash.get_broker_health("ghost_broker") is None
    print("[✓] Unknown broker returns None")

    # 6. Record alerts
    a1 = dash.record_alert("broker_down", "broker_c went offline", severity="high")
    a2 = dash.record_alert("high_latency", "broker_c latency at 999ms", severity="medium")
    a3 = dash.record_alert("info", "System check passed", severity="low")
    assert a1["severity"] == "high"
    print(f"[✓] 3 alerts recorded: {a1['alert_type']}, {a2['alert_type']}, {a3['alert_type']}")

    # 7. Get alerts with severity filter
    all_alerts = dash.get_alerts(min_severity="low")
    high_alerts = dash.get_alerts(min_severity="high")
    assert len(all_alerts) == 3
    assert len(high_alerts) == 1
    assert high_alerts[0]["alert_type"] == "broker_down"
    print(f"[✓] get_alerts(low)={len(all_alerts)}, get_alerts(high)={len(high_alerts)}")

    # 8. Latency heatmap
    dash.set_latency("broker_a", "broker_b", 5.0)
    dash.set_latency("broker_b", "broker_c", 15.0)
    heatmap = dash.get_latency_heatmap()
    assert "broker_a" in heatmap
    assert heatmap["broker_a"]["broker_b"] == 5.0
    assert heatmap["broker_b"]["broker_a"] == 5.0  # Bidirectional
    print(f"[✓] Latency heatmap: broker_a->broker_b = {heatmap['broker_a']['broker_b']}ms")

    # 9. Metric history
    hist = dash.get_metric_history("latency_ms.broker_a", count=10)
    assert len(hist) >= 1
    assert hist[0]["value"] == 12.5
    print(f"[✓] Metric history for 'latency_ms.broker_a': {len(hist)} points")

    # 10. Update broker (history accumulates)
    dash.update_broker_health("broker_a", healthy=True, latency_ms=14.0, intent_throughput=50.0)
    hist2 = dash.get_metric_history("latency_ms.broker_a", count=10)
    assert len(hist2) >= 2
    assert hist2[-1]["value"] == 14.0
    print(f"[✓] Metric history grows: {len(hist2)} points after second update")

    # 11. Unknown metric returns empty
    empty_hist = dash.get_metric_history("nonexistent_metric")
    assert empty_hist == []
    print(f"[✓] Unknown metric returns empty list")

    # 12. Thread safety
    import concurrent.futures

    def threaded_health(d: MeshHealthDashboard, idx: int) -> None:
        d.update_broker_health(f"t_broker_{idx}", healthy=True, latency_ms=float(idx), intent_throughput=float(idx * 10))

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(threaded_health, dash, i) for i in range(40)]
        concurrent.futures.wait(futures)
    summary = dash.get_health_summary()
    assert summary["brokers_total"] >= 40
    print(f"[✓] Thread safety: 40 concurrent health updates → {summary['brokers_total']} total brokers")

    print()
    print("All MeshHealthDashboard tests PASSED ✓")
