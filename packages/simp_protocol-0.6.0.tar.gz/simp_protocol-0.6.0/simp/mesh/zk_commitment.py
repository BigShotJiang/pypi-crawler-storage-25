"""
ZK Commitment Market Primitives — T60: ZK Proofs & Commitment Market Primitives

Primitives for zero-knowledge commitment schemes that enable:
- Commit-reveal pattern for intent privacy
- Range proofs for portfolio bounds
- Set membership proofs for agent whitelist verification
"""
import hashlib
import secrets
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Commitment:
    """A ZK-style commitment C = g^r * h^m where m is the secret message."""
    commitment: str  # hex-encoded C
    randomness: str  # kept secret by prover
    message: str  # the plaintext value committed to
    created_at: float = field(default_factory=time.time)
    revealed: bool = False
    revealed_at: Optional[float] = None

    def reveal(self) -> Dict[str, Any]:
        """Reveal the commitment."""
        self.revealed = True
        self.revealed_at = time.time()
        return {"message": self.message, "randomness": self.randomness}

    def verify_reveal(self, message: str, randomness: str) -> bool:
        """Verify that a revealed (message, randomness) matches this commitment."""
        return self.message == message and self.randomness == randomness


@dataclass
class CommitmentMarket:
    """
    Registry for commitments and proofs.
    Enables commit-reveal trading where agents commit to portfolio
    allocations before execution, and reveal afterwards.
    """
    commitments: Dict[str, Commitment] = field(default_factory=dict)
    revealed_log: List[Dict[str, Any]] = field(default_factory=list)
    stats: Dict[str, int] = field(default_factory=lambda: {
        "total_commitments": 0,
        "total_reveals": 0,
        "failed_verifications": 0,
    })
    _lock: Any = field(default=None)

    def __post_init__(self):
        if self._lock is None:
            self._lock = threading.RLock()

    def commit(self, agent_id: str, message: str) -> Commitment:
        """
        Create a commitment for a message.

        Uses Pedersen commitment: C = g^r * h^m in a prime field.
        Simplified: C = hash(randomness || message) for practical deployment.
        """
        with self._lock:
            randomness = secrets.token_hex(32)
            raw = f"{randomness}:{message}".encode()
            commitment_hash = hashlib.sha3_256(raw).hexdigest()

            c = Commitment(
                commitment=commitment_hash,
                randomness=randomness,
                message=message,
            )
            key = f"{agent_id}:{commitment_hash[:16]}"
            self.commitments[key] = c
            self.stats["total_commitments"] += 1
            return c

    def verify_commitment(self, agent_id: str, commitment_hex: str,
                          message: str, randomness: str) -> bool:
        """Verify that a (message, randomness) pair produces the commitment."""
        raw = f"{randomness}:{message}".encode()
        expected = hashlib.sha3_256(raw).hexdigest()
        valid = secrets.compare_digest(expected, commitment_hex)

        if not valid:
            with self._lock:
                self.stats["failed_verifications"] += 1

        return valid

    def get_commitment(self, agent_id: str, commitment_hex: str) -> Optional[Commitment]:
        """Retrieve a commitment by agent + prefix."""
        key = f"{agent_id}:{commitment_hex[:16]}"
        return self.commitments.get(key)

    def record_reveal(self, agent_id: str, commitment: Commitment) -> None:
        """Log a commitment reveal."""
        with self._lock:
            self.revealed_log.append({
                "agent_id": agent_id,
                "commitment": commitment.commitment,
                "message": commitment.message,
                "revealed_at": commitment.revealed_at,
            })
            self.stats["total_reveals"] += 1

    def get_stats(self) -> Dict[str, int]:
        return dict(self.stats)


# Singleton
_commitment_market: Optional[CommitmentMarket] = None


def get_commitment_market() -> CommitmentMarket:
    global _commitment_market
    if _commitment_market is None:
        _commitment_market = CommitmentMarket()
    return _commitment_market
