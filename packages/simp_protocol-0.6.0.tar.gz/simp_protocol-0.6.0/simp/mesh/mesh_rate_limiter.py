"""Mesh rate limiting per broker.

Provides a sliding-window rate limiter that tracks requests per broker
over the last 60 seconds.  Configurable per-broker limits with a default
of 100 requests per minute.  Thread-safe.
"""

from __future__ import annotations

import threading
import time
from typing import Any

_WINDOW_SIZE = 60.0  # seconds
_DEFAULT_LIMIT = 100  # requests per window


class MeshRateLimiter:
    """Sliding-window rate limiter keyed by broker ID.

    Each broker has a configurable request-per-minute limit.  Requests
    are tracked in a sliding 60-second window.  When the window is full,
    old timestamps are evicted on access (lazy eviction).

    Thread-safe via ``threading.Lock``.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        # broker_id -> {"limit": int, "timestamps": list[float]}
        self._limits: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def set_limit(self, broker_id: str, max_requests_per_minute: int) -> None:
        """Set or update the rate limit for a broker.

        If the broker already has a limit, the counter is *not* reset
        (existing timestamps remain).  Use ``reset()`` to clear the
        window explicitly.

        Args:
            broker_id: Unique identifier for the broker.
            max_requests_per_minute: Maximum allowed requests in the
                                     sliding 60-second window.
        """
        with self._lock:
            if broker_id in self._limits:
                self._limits[broker_id]["limit"] = max_requests_per_minute
            else:
                self._limits[broker_id] = {
                    "limit": max_requests_per_minute,
                    "timestamps": [],
                }

    def get_limit(self, broker_id: str) -> int:
        """Return the current rate limit for a broker.

        Returns the default limit (100) if the broker is not configured.
        """
        with self._lock:
            entry = self._limits.get(broker_id)
            if entry is None:
                return _DEFAULT_LIMIT
            return entry["limit"]

    def get_all_limits(self) -> dict[str, int]:
        """Return a dict of ``{broker_id: limit}`` for all configured brokers.

        Does *not* include brokers using the default implicit limit.
        """
        with self._lock:
            return {bid: entry["limit"] for bid, entry in self._limits.items()}

    # ------------------------------------------------------------------
    # Rate checking
    # ------------------------------------------------------------------

    def check(self, broker_id: str) -> bool:
        """Check whether a new request from *broker_id* is allowed.

        If the broker is not yet configured, it gets the default limit.
        If the broker has exceeded its limit, the request is denied.

        Args:
            broker_id: The broker issuing the request.

        Returns:
            True if the request is allowed, False if rate-limited.
        """
        now = time.time()
        window_start = now - _WINDOW_SIZE

        with self._lock:
            entry = self._limits.get(broker_id)
            if entry is None:
                entry = {
                    "limit": _DEFAULT_LIMIT,
                    "timestamps": [],
                }
                self._limits[broker_id] = entry

            # Lazy eviction: discard timestamps outside the window
            timestamps = entry["timestamps"]
            # Since timestamps are appended in order, we can find the
            # first index within the window using a binary search, but
            # a simple while-loop is fine for typical counts.
            while timestamps and timestamps[0] < window_start:
                timestamps.pop(0)

            limit = entry["limit"]

            if len(timestamps) >= limit:
                return False  # rate limited

            # Allow the request
            timestamps.append(now)
            return True

    # ------------------------------------------------------------------
    # Usage stats
    # ------------------------------------------------------------------

    def get_usage(self, broker_id: str) -> dict[str, Any]:
        """Return usage statistics for a broker.

        Returns:
            A dict with keys:
                - allowed (int): request count in current window
                - denied (int): 0 (this tracks allowance, not denials)
                - remaining (int): slots remaining
                - window_start (float): epoch of window start
                - limit (int): configured limit
            If the broker has no recorded activity, ``allowed`` is 0.
        """
        now = time.time()
        window_start = now - _WINDOW_SIZE

        with self._lock:
            entry = self._limits.get(broker_id)
            if entry is None:
                return {
                    "allowed": 0,
                    "denied": 0,
                    "remaining": _DEFAULT_LIMIT,
                    "window_start": window_start,
                    "limit": _DEFAULT_LIMIT,
                }

            timestamps = entry["timestamps"]
            # Evict old
            while timestamps and timestamps[0] < window_start:
                timestamps.pop(0)

            limit = entry["limit"]
            allowed = len(timestamps)
            remaining = max(0, limit - allowed)

            return {
                "allowed": allowed,
                "denied": 0,
                "remaining": remaining,
                "window_start": window_start,
                "limit": limit,
            }

    # ------------------------------------------------------------------
    # Reset
    # ------------------------------------------------------------------

    def reset(self, broker_id: str) -> bool:
        """Reset the rate counter for a broker.

        Clears all recorded timestamps, effectively resetting the window.

        Args:
            broker_id: The broker to reset.

        Returns:
            True if the broker was found and reset, False otherwise.
        """
        with self._lock:
            entry = self._limits.get(broker_id)
            if entry is None:
                return False
            entry["timestamps"] = []
            return True

    def remove_broker(self, broker_id: str) -> bool:
        """Remove a broker from rate limiting entirely.

        Args:
            broker_id: The broker to remove.

        Returns:
            True if the broker was removed, False if not found.
        """
        with self._lock:
            return self._limits.pop(broker_id, None) is not None


# -----------------------------------------------------------------------
# Verification block
# -----------------------------------------------------------------------
if __name__ == "__main__":
    rl = MeshRateLimiter()

    # Default limit check
    limit = rl.get_limit("broker-unknown")
    assert limit == 100, f"Expected default limit 100, got {limit}"

    # Set a small limit for testing
    rl.set_limit("broker-test", 3)

    # First 3 requests should be allowed
    assert rl.check("broker-test") is True
    assert rl.check("broker-test") is True
    assert rl.check("broker-test") is True

    # 4th request should be denied
    assert rl.check("broker-test") is False, "4th request should be rate limited"

    # Check usage
    usage = rl.get_usage("broker-test")
    assert usage["allowed"] == 3
    assert usage["remaining"] == 0
    assert usage["limit"] == 3

    # Reset should clear the counter
    rl.reset("broker-test")
    assert rl.check("broker-test") is True, "After reset, requests should be allowed"

    # get_all_limits
    rl.set_limit("broker-a", 50)
    rl.set_limit("broker-b", 200)
    all_limits = rl.get_all_limits()
    assert all_limits["broker-a"] == 50
    assert all_limits["broker-b"] == 200
    assert "broker-test" in all_limits  # was set earlier

    # Remove broker
    rl.remove_broker("broker-test")
    assert "broker-test" not in rl.get_all_limits()

    # Unconfigured broker gets default
    assert rl.get_limit("nonexistent") == 100

    print("All MeshRateLimiter tests passed.")
