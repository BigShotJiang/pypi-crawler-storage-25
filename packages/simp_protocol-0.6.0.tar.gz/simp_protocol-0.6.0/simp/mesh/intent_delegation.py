"""
Hierarchical Intent Delegation — Level 3 Mesh Protocol

Brokers can delegate intents to sub-brokers in a hierarchical fashion.
Sub-brokers report completion, failure, or escalate intents they cannot handle.

Delegation tracking:
    {intent_id: {from, to, sub_broker, status, timestamp}}

Thread-safe via RLock.
"""

import logging
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class IntentDelegator:
    """Hierarchical intent delegation manager.

    Allows a broker to delegate an intent to a sub-broker, track its
    lifecycle (completion, failure, escalation), and query active
    and historical delegations.

    Thread-safe: all mutable state guarded by ``_lock``.
    """

    def __init__(self, local_broker_id: str) -> None:
        self.local_broker_id = local_broker_id
        self._lock = threading.RLock()

        # intent_id -> delegation record
        self._delegations: Dict[str, Dict[str, Any]] = {}

        # Completed/failed delegations (bounded history)
        self._history: List[Dict[str, Any]] = []
        self._max_history: int = 500

        logger.info("IntentDelegator initialized for %s", local_broker_id)

    # ------------------------------------------------------------------
    # Delegation lifecycle
    # ------------------------------------------------------------------

    def delegate(
        self,
        intent: str,
        from_broker: str,
        to_broker: str,
        sub_broker: str,
    ) -> str:
        """Delegate an intent from ``from_broker`` to ``sub_broker``.

        ``to_broker`` is the intermediate broker that facilitates the
        delegation.  ``sub_broker`` is the actual target broker that
        will execute the intent.

        Args:
            intent: Intent identifier (free-form string).
            from_broker: The broker requesting the delegation.
            to_broker: The broker facilitating the delegation.
            sub_broker: The target broker that will execute.

        Returns:
            A generated ``intent_id`` for tracking.
        """
        import uuid
        intent_id = f"del_{uuid.uuid4().hex[:12]}"

        with self._lock:
            self._delegations[intent_id] = {
                "intent_id": intent_id,
                "intent": intent,
                "from": from_broker,
                "to": to_broker,
                "sub_broker": sub_broker,
                "status": "delegated",
                "timestamp": time.time(),
                "result": None,
                "error": None,
            }
            logger.info(
                "Delegated intent %s (%s): %s -> %s -> %s",
                intent_id,
                intent,
                from_broker,
                to_broker,
                sub_broker,
            )

        return intent_id

    def report_completion(self, intent_id: str, result: Any) -> Optional[Dict[str, Any]]:
        """Mark a delegated intent as completed with ``result``.

        Args:
            intent_id: The delegation ID returned by :meth:`delegate`.
            result: The result payload from the sub-broker.

        Returns:
            The delegation record, or ``None`` if ``intent_id`` not found.
        """
        with self._lock:
            record = self._delegations.get(intent_id)
            if record is None:
                logger.warning("report_completion: unknown intent_id %s", intent_id)
                return None

            record["status"] = "completed"
            record["result"] = result
            record["completed_at"] = time.time()

            # Move to history
            self._archive(record)
            logger.info("Intent %s completed by %s", intent_id, record["sub_broker"])
            return dict(record)

    def report_failure(self, intent_id: str, error: str) -> Optional[Dict[str, Any]]:
        """Mark a delegated intent as failed with ``error`` description.

        Args:
            intent_id: The delegation ID.
            error: Error message from the sub-broker.

        Returns:
            The delegation record, or ``None`` if not found.
        """
        with self._lock:
            record = self._delegations.get(intent_id)
            if record is None:
                logger.warning("report_failure: unknown intent_id %s", intent_id)
                return None

            record["status"] = "failed"
            record["error"] = error
            record["completed_at"] = time.time()

            self._archive(record)
            logger.warning("Intent %s failed: %s", intent_id, error)
            return dict(record)

    def report_escalation(self, intent_id: str, reason: str) -> Optional[Dict[str, Any]]:
        """Mark a delegated intent as escalated.

        Escalation means the sub-broker could not handle the intent and
        is passing it up the chain.

        Args:
            intent_id: The delegation ID.
            reason: Why the intent is being escalated.

        Returns:
            The delegation record, or ``None`` if not found.
        """
        with self._lock:
            record = self._delegations.get(intent_id)
            if record is None:
                logger.warning("report_escalation: unknown intent_id %s", intent_id)
                return None

            record["status"] = "escalated"
            record["escalation_reason"] = reason
            record["completed_at"] = time.time()

            self._archive(record)
            logger.warning("Intent %s escalated: %s", intent_id, reason)
            return dict(record)

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    def get_delegations(self) -> List[Dict[str, Any]]:
        """Return all active (non-terminal) delegations.

        Returns list of delegation record dicts.
        """
        with self._lock:
            return [
                dict(v)
                for v in self._delegations.values()
                if v["status"] not in ("completed", "failed", "escalated")
            ]

    def get_delegation(self, intent_id: str) -> Optional[Dict[str, Any]]:
        """Return the delegation status for a specific intent.

        Checks active delegations first, then historical ones.

        Returns:
            Delegation record dict, or ``None`` if not found.
        """
        with self._lock:
            record = self._delegations.get(intent_id)
            if record is not None:
                return dict(record)

            # Check history
            for h in reversed(self._history):
                if h["intent_id"] == intent_id:
                    return dict(h)
            return None

    def get_history(self) -> List[Dict[str, Any]]:
        """Return historical (completed/failed/escalated) delegations."""
        with self._lock:
            return [dict(h) for h in self._history]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _archive(self, record: Dict[str, Any]) -> None:
        """Move a record from active delegations to history."""
        intent_id = record["intent_id"]
        self._history.append(dict(self._delegations.pop(intent_id, record)))
        # Trim history
        if len(self._history) > self._max_history:
            self._history = self._history[-self._max_history:]

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_status(self) -> Dict[str, Any]:
        """Return status dict with operational metrics."""
        with self._lock:
            active = [d for d in self._delegations.values()]
            statuses: Dict[str, int] = {}
            for d in active:
                s = d["status"]
                statuses[s] = statuses.get(s, 0) + 1
            return {
                "local_broker": self.local_broker_id,
                "active_delegations": len(active),
                "status_breakdown": statuses,
                "history_count": len(self._history),
                "max_history": self._max_history,
            }


# ---------------------------------------------------------------------------
# Verification block
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s %(message)s")

    delegator = IntentDelegator(local_broker_id="broker-alpha")

    # Delegate an intent
    intent_id = delegator.delegate(
        intent="process_trade_001",
        from_broker="broker-alpha",
        to_broker="broker-alpha",
        sub_broker="broker-beta",
    )
    print(f"Delegated intent: {intent_id}")

    # Check active delegations
    active = delegator.get_delegations()
    assert len(active) == 1
    assert active[0]["sub_broker"] == "broker-beta"
    assert active[0]["status"] == "delegated"
    print(f"Active delegations: {len(active)} ✓")

    # Query by ID
    d = delegator.get_delegation(intent_id)
    assert d is not None
    assert d["intent"] == "process_trade_001"
    print(f"Delegation lookup: {d['intent']} ✓")

    # Report completion
    result = delegator.report_completion(intent_id, {"status": "ok", "tx_id": "tx_123"})
    assert result is not None
    assert result["status"] == "completed"
    assert result["result"]["tx_id"] == "tx_123"
    print(f"Completion reported ✓")

    # No active delegations
    assert len(delegator.get_delegations()) == 0
    print("No active delegations after completion ✓")

    # Test failure
    intent_id2 = delegator.delegate(
        intent="risky_task_002",
        from_broker="broker-alpha",
        to_broker="broker-alpha",
        sub_broker="broker-gamma",
    )
    failure = delegator.report_failure(intent_id2, "Insufficient permissions")
    assert failure is not None
    assert failure["status"] == "failed"
    assert "Insufficient permissions" in failure["error"]
    print(f"Failure reported ✓")

    # Test escalation
    intent_id3 = delegator.delegate(
        intent="complex_task_003",
        from_broker="broker-alpha",
        to_broker="broker-alpha",
        sub_broker="broker-delta",
    )
    escalation = delegator.report_escalation(intent_id3, "Requires human review")
    assert escalation is not None
    assert escalation["status"] == "escalated"
    assert escalation["escalation_reason"] == "Requires human review"
    print(f"Escalation reported ✓")

    # Test history
    history = delegator.get_history()
    assert len(history) == 3
    print(f"History entries: {len(history)} ✓")

    # Unknown intent
    assert delegator.get_delegation("nonexistent") is None
    assert delegator.report_completion("nonexistent", {}) is None
    print("Unknown intent handling ✓")

    print("\n=== IntentDelegator Verification ===")
    print(f"Status: {delegator.get_status()}")
    print("All assertions passed ✓")
