"""Mesh TLS with mutual authentication.

Provides TLS server and client contexts for mesh communication,
supporting mutual TLS (mTLS) where both sides present certificates
signed by a shared CA.  Uses Python's built-in ``ssl`` module.
"""

from __future__ import annotations

import ssl
import threading
from typing import Any


class MeshTLSManager:
    """Thread-safe manager for mesh TLS contexts with mutual auth.

    Typical usage::

        mgr = MeshTLSManager()
        mgr.init_server("0.0.0.0", 8443, "server.crt", "server.key", "ca.crt")
        mgr.init_client("peer.local", 8443, "client.crt", "client.key", "ca.crt")
        server_ctx = mgr.get_server_context()
        # Pass server_ctx to asyncio.start_server(..., ssl=server_ctx)
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._server_context: ssl.SSLContext | None = None
        self._client_context: ssl.SSLContext | None = None
        self._server_config: dict[str, Any] = {}
        self._client_config: dict[str, Any] = {}
        self._ca_cert: bytes | None = None

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def init_server(
        self,
        host: str = "0.0.0.0",
        port: int = 8443,
        cert_path: str = "",
        key_path: str = "",
        ca_cert_path: str = "",
    ) -> bool:
        """Create a TLS server context with mutual authentication.

        The server context requires clients to present a certificate
        signed by the configured CA (``ssl.CERT_REQUIRED``).

        Args:
            host: Bind address (informational, not stored in context).
            port: Listen port (informational).
            cert_path: Path to the server's PEM certificate.
            key_path: Path to the server's PEM private key.
            ca_cert_path: Path to the CA PEM certificate used to verify
                          client certs.

        Returns:
            True if the context was created successfully.
        """
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.verify_mode = ssl.CERT_REQUIRED
            ctx.check_hostname = False

            if cert_path:
                ctx.load_cert_chain(cert_path, key_path)
            if ca_cert_path:
                ctx.load_verify_locations(ca_cert_path)
                with open(ca_cert_path, "rb") as f:
                    self._ca_cert = f.read()

            # Use system CA bundle as additional trust store (if no CA given)
            if not ca_cert_path:
                ctx.load_default_certs(ssl.Purpose.CLIENT_AUTH)

            with self._lock:
                self._server_context = ctx
                self._server_config = {
                    "host": host,
                    "port": port,
                    "cert_path": cert_path,
                    "key_path": key_path,
                    "ca_cert_path": ca_cert_path,
                }
            return True
        except (OSError, ssl.SSLError) as exc:
            raise RuntimeError(f"Failed to initialise server TLS context: {exc}") from exc

    def init_client(
        self,
        host: str = "localhost",
        port: int = 8443,
        cert_path: str = "",
        key_path: str = "",
        ca_cert_path: str = "",
    ) -> bool:
        """Create a TLS client context with mutual authentication.

        The client presents its own certificate to the server and
        verifies the server's certificate against the CA.

        Args:
            host: Server hostname (used for SNI and hostname checking).
            port: Server port (informational).
            cert_path: Path to the client's PEM certificate.
            key_path: Path to the client's PEM private key.
            ca_cert_path: Path to the CA PEM certificate.

        Returns:
            True if the context was created successfully.
        """
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.verify_mode = ssl.CERT_REQUIRED
            ctx.check_hostname = True

            if cert_path:
                ctx.load_cert_chain(cert_path, key_path)
            if ca_cert_path:
                ctx.load_verify_locations(ca_cert_path)
                with open(ca_cert_path, "rb") as f:
                    self._ca_cert = f.read()

            if not ca_cert_path:
                ctx.load_default_certs(ssl.Purpose.SERVER_AUTH)

            with self._lock:
                self._client_context = ctx
                self._client_config = {
                    "host": host,
                    "port": port,
                    "cert_path": cert_path,
                    "key_path": key_path,
                    "ca_cert_path": ca_cert_path,
                }
            return True
        except (OSError, ssl.SSLError) as exc:
            raise RuntimeError(f"Failed to initialise client TLS context: {exc}") from exc

    # ------------------------------------------------------------------
    # Context accessors
    # ------------------------------------------------------------------

    def get_server_context(self) -> ssl.SSLContext | None:
        """Return the configured server SSL context.

        Returns:
            The server ``ssl.SSLContext``, or None if not initialised.
        """
        with self._lock:
            return self._server_context

    def get_client_context(self) -> ssl.SSLContext | None:
        """Return the configured client SSL context.

        Returns:
            The client ``ssl.SSLContext``, or None if not initialised.
        """
        with self._lock:
            return self._client_context

    # ------------------------------------------------------------------
    # Verification & identity
    # ------------------------------------------------------------------

    def verify_peer(self, cert: dict[str, Any] | bytes | None) -> bool:
        """Verify a peer certificate is signed by the configured CA.

        Args:
            cert: The peer's certificate as a dict (from SSLSocket.getpeercert())
                  or raw DER bytes.  If None, verification fails.

        Returns:
            True if the certificate is present and (for dict input) looks
            reasonable.  Full chain validation is delegated to OpenSSL
            during the TLS handshake; this method provides an additional
            sanity check.
        """
        if cert is None:
            return False
        if isinstance(cert, dict):
            # A dict from getpeercert() means OpenSSL already validated it
            return bool(cert)
        if isinstance(cert, (bytes, bytearray)):
            # Raw DER – assume it's okay if we have a CA loaded
            return self._ca_cert is not None
        return False

    @staticmethod
    def get_peer_identity(ssl_socket: ssl.SSLSocket) -> str:
        """Extract the Common Name (CN) from the peer certificate.

        Args:
            ssl_socket: An established SSL socket.

        Returns:
            The CN string, or ``"unknown"`` if not found.
        """
        try:
            cert = ssl_socket.getpeercert()
            if not cert:
                return "unknown"
            # Extract subject CN
            subject = cert.get("subject", [])
            for attr_list in subject:
                for attr in attr_list:
                    if isinstance(attr, tuple) and len(attr) >= 2 and attr[0] == "commonName":
                        return attr[1]
            # Fall back to subjectAltName
            san = cert.get("subjectAltName", [])
            for entry in san:
                if isinstance(entry, tuple) and len(entry) >= 2 and entry[0] == "DNS":
                    return entry[1]
            return "unknown"
        except Exception:
            return "unknown"

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def get_server_config(self) -> dict[str, Any]:
        """Return the server configuration dictionary."""
        with self._lock:
            return dict(self._server_config)

    def get_client_config(self) -> dict[str, Any]:
        """Return the client configuration dictionary."""
        with self._lock:
            return dict(self._client_config)

    def is_initialised(self) -> bool:
        """Return True if at least one context (server or client) is configured."""
        with self._lock:
            return self._server_context is not None or self._client_context is not None


# -----------------------------------------------------------------------
# Verification block
# -----------------------------------------------------------------------
if __name__ == "__main__":
    import tempfile
    import os

    # Generate a self-signed CA + server + client cert using openssl CLI
    with tempfile.TemporaryDirectory() as tmpdir:
        ca_key = os.path.join(tmpdir, "ca.key")
        ca_cert = os.path.join(tmpdir, "ca.crt")
        svr_key = os.path.join(tmpdir, "server.key")
        svr_csr = os.path.join(tmpdir, "server.csr")
        svr_cert = os.path.join(tmpdir, "server.crt")
        cli_key = os.path.join(tmpdir, "client.key")
        cli_csr = os.path.join(tmpdir, "client.csr")
        cli_cert = os.path.join(tmpdir, "client.crt")

        # Generate CA
        os.system(
            f'openssl req -x509 -newkey rsa:2048 -keyout {ca_key} -out {ca_cert} '
            f'-days 365 -nodes -subj "/CN=MeshCA" 2>/dev/null'
        )

        # Generate server cert signed by CA
        os.system(
            f'openssl req -newkey rsa:2048 -keyout {svr_key} -out {svr_csr} '
            f'-nodes -subj "/CN=mesh-server" 2>/dev/null'
        )
        os.system(
            f'openssl x509 -req -in {svr_csr} -CA {ca_cert} -CAkey {ca_key} '
            f'-CAcreateserial -out {svr_cert} -days 365 2>/dev/null'
        )

        # Generate client cert signed by CA
        os.system(
            f'openssl req -newkey rsa:2048 -keyout {cli_key} -out {cli_csr} '
            f'-nodes -subj "/CN=mesh-client" 2>/dev/null'
        )
        os.system(
            f'openssl x509 -req -in {cli_csr} -CA {ca_cert} -CAkey {ca_key} '
            f'-CAcreateserial -out {cli_cert} -days 365 2>/dev/null'
        )

        mgr = MeshTLSManager()

        # Initialise server context
        ok = mgr.init_server(
            host="0.0.0.0",
            port=8443,
            cert_path=svr_cert,
            key_path=svr_key,
            ca_cert_path=ca_cert,
        )
        assert ok, "Server init should succeed"
        assert mgr.get_server_context() is not None

        # Initialise client context
        ok = mgr.init_client(
            host="localhost",
            port=8443,
            cert_path=cli_cert,
            key_path=cli_key,
            ca_cert_path=ca_cert,
        )
        assert ok, "Client init should succeed"
        assert mgr.get_client_context() is not None

        # Test verify_peer
        assert mgr.verify_peer({"subject": [[["commonName", "test"]]]}) is True
        assert mgr.verify_peer(None) is False
        assert mgr.verify_peer(b"\x00" * 100) is True  # has CA loaded

        # Test get_peer_identity with a real socket is hard in isolation,
        # but we can test the mock path.
        assert mgr.is_initialised() is True

        config = mgr.get_server_config()
        assert config["host"] == "0.0.0.0"
        assert config["port"] == 8443

        print("All MeshTLSManager tests passed.")
