"""
Ising Decoder Integration — SIMP Agent Integration for Quantum Error Correction

Provides agent-level services built on top of the IsingDecoderBridge:
  - DecodingAgent: SIMP agent that offers syndrome decoding as a service
  - DecoderMarket: Allows agents to discover and pay for decoders
  - LERMonitor: Tracks logical error rates across runs
  - CapabilityPublisher: Auto-registers decoders in SIMP capability registry

This integration connects the NVIDIA QEC pre-decoder infrastructure to SIMP's
mesh protocol, enabling:
  1. Agents to request syndrome decoding via intents
  2. Agents to offer decoder capabilities with $SIMP pricing
  3. Training runs managed through SIMP's lifecycle
  4. Integration with HF Space bridge for model distribution

License: Apache 2.0 — See vendor/ising_decoder/LICENSE
"""

from __future__ import annotations

import logging
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Callable

from simp.bridges.ising_decoder_bridge import (
    IsingDecoderBridge,
    DecodeRequest,
    DecodeResult,
    TrainingJob,
    DecoderCapability,
    get_ising_decoder_bridge,
    INTENT_HANDLERS,
)

logger = logging.getLogger(__name__)


# ── Agent-Level Integration ──────────────────────────────────────────────────

@dataclass
class AgentDecoderProfile:
    """
    A decoder profile that a specific agent offers on the mesh.
    Wraps a DecoderCapability with runtime stats and pricing.
    """
    agent_id: str
    capability: DecoderCapability
    is_active: bool = True
    total_decodes: int = 0
    total_errors_decoded: int = 0
    avg_latency_ms: float = 0.0
    uptime_seconds: float = 0.0
    started_at: float = field(default_factory=time.time)

    def record_decode(self, result: DecodeResult) -> None:
        self.total_decodes += 1
        self.total_errors_decoded += result.num_logical_errors
        # Exponential moving average latency
        alpha = 0.1
        self.avg_latency_ms = (1 - alpha) * self.avg_latency_ms + alpha * result.timing_ms

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["capability"] = self.capability.to_dict()
        d["uptime_seconds"] = time.time() - self.started_at
        return d


class DecodingAgent:
    """
    A SIMP agent that wraps the IsingDecoderBridge and offers
    syndrome decoding as a mesh service.

    Usage:
        agent = DecodingAgent("my_decoder_agent", model_id=1)
        agent.start()

        # Register on mesh
        agent.publish_capability()

        # Handle incoming decode requests
        agent.process_pending_requests(timeout=5.0)
    """

    def __init__(
        self,
        agent_id: str,
        model_id: int = 1,
        bridge: Optional[IsingDecoderBridge] = None,
        auto_register: bool = True,
    ):
        self.agent_id = agent_id
        self.model_id = model_id
        self._bridge = bridge or get_ising_decoder_bridge()
        self._profile = AgentDecoderProfile(
            agent_id=agent_id,
            capability=self._bridge.get_capability(agent_id, model_id),
        )
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._pending_requests: List[DecodeRequest] = []
        self._completed: List[DecodeResult] = []
        self._lock = threading.RLock()
        self._handler_registry: Dict[str, Callable] = {}
        self._logger = logging.getLogger(f"decoding_agent.{agent_id}")

        # Register default handlers
        for action, handler in INTENT_HANDLERS.items():
            self.register_handler(action, handler)

    def register_handler(self, action: str, handler: Callable) -> None:
        with self._lock:
            self._handler_registry[action] = handler

    def handle_intent(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Route an incoming SIMP intent to the appropriate handler.
        Matches the SIMP intent routing protocol.
        """
        action = payload.get("action", "")
        with self._lock:
            handler = self._handler_registry.get(action)
        if handler is None:
            return {"error": f"Unknown action: {action}", "status": "error"}
        return handler(payload)

    def publish_capability(self) -> Dict[str, Any]:
        """Generate and return the capability descriptor for mesh registration."""
        return self._profile.capability.to_dict()

    def decode(self, request: DecodeRequest) -> DecodeResult:
        """
        Decode syndromes and update profile stats.
        Thread-safe.
        """
        result = self._bridge.decode_syndromes(request)
        with self._lock:
            self._profile.record_decode(result)
            self._completed.append(result)
        self._logger.info(
            f"Decoded {request.num_shots} shots @ d={request.distance}, "
            f"LER={result.logical_error_rate:.6f}, "
            f"reduction={result.ler_reduction_factor:.1f}x"
        )
        return result

    def estimate(
        self,
        distance: int,
        error_rate: float,
        basis: str = "X",
    ) -> Dict[str, float]:
        """Fast LER estimation."""
        return self._bridge.estimate_ler(distance, error_rate, basis, self.model_id)

    def train(
        self,
        experiment_name: str,
        distance: int,
        error_rate: float,
        num_epochs: int = 100,
        gpus: int = 1,
    ) -> TrainingJob:
        """Spawn a training job."""
        job = TrainingJob(
            job_id=uuid.uuid4().hex,
            experiment_name=experiment_name,
            model_id=self.model_id,
            distance=distance,
            physical_error_rate=error_rate,
            num_epochs=num_epochs,
            gpus=gpus,
            agent_id=self.agent_id,
        )
        return self._bridge.spawn_training(job)

    def export(self, checkpoint_path: str, fmt: str = "safetensors") -> str:
        """Export a trained model."""
        return self._bridge.export_model(checkpoint_path, self.model_id, fmt)

    def get_profile(self) -> Dict[str, Any]:
        with self._lock:
            return self._profile.to_dict()

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "agent_id": self.agent_id,
                "model_id": self.model_id,
                "total_decodes": self._profile.total_decodes,
                "avg_latency_ms": round(self._profile.avg_latency_ms, 2),
                "total_errors_handled": self._profile.total_errors_decoded,
                "completed_results": len(self._completed),
            }

    # ── Polling / event loop ──────────────────────────────────────────

    def start(self) -> None:
        """Start the background polling loop."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name=f"da-{self.agent_id[:8]}")
        self._thread.start()
        self._logger.info(f"DecodingAgent {self.agent_id} started")

    def stop(self) -> None:
        self._running = False

    def _loop(self) -> None:
        while self._running:
            try:
                self.process_pending_requests(timeout=1.0)
            except Exception as exc:
                self._logger.debug(f"Loop: {exc}")

    def process_pending_requests(self, timeout: float = 1.0) -> List[DecodeResult]:
        """
        Process any pending decode requests.
        In production, this would poll the mesh for incoming intents.
        """
        with self._lock:
            requests = list(self._pending_requests)
            self._pending_requests.clear()

        results = []
        for req in requests:
            result = self.decode(req)
            results.append(result)
        return results

    def enqueue_request(self, request: DecodeRequest) -> None:
        with self._lock:
            self._pending_requests.append(request)


# ── Decoder Marketplace ──────────────────────────────────────────────────────

@dataclass
class DecoderOffer:
    """A decoder service offered by an agent on the mesh."""
    agent_id: str
    decoder_id: str
    model_variant: str
    receptive_field: int
    price_per_shot: float  # in $SIMP
    avg_latency_us: float
    total_decodes: int
    last_seen: float = field(default_factory=time.time)
    reliability_score: float = 1.0  # 0.0 - 1.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class DecoderMarketplace:
    """
    A mesh-wide marketplace where agents discover and select decoders.

    Agents can:
      - List their decoder as an offer
      - Discover decoders by distance, error rate, or price
      - Get recommendations based on quality/price
    """

    def __init__(self):
        self._offers: Dict[str, DecoderOffer] = {}  # decoder_id → offer
        self._lock = threading.RLock()
        self._logger = logging.getLogger("decoder_market")

    def register(self, profile: AgentDecoderProfile) -> DecoderOffer:
        cap = profile.capability
        offer = DecoderOffer(
            agent_id=profile.agent_id,
            decoder_id=cap.decoder_id,
            model_variant=cap.model_variant,
            receptive_field=cap.receptive_field,
            price_per_shot=cap.pricing.get("per_shot", 0.0001),
            avg_latency_us=cap.avg_inference_us,
            total_decodes=profile.total_decodes,
        )
        with self._lock:
            self._offers[cap.decoder_id] = offer
        self._logger.info(f"Registered decoder {cap.decoder_id} from {profile.agent_id}")
        return offer

    def unregister(self, decoder_id: str) -> None:
        with self._lock:
            self._offers.pop(decoder_id, None)

    def find_best(
        self,
        distance: int,
        max_price: float = 0.01,
        min_reliability: float = 0.5,
    ) -> Optional[DecoderOffer]:
        """Find the best decoder for a given distance."""
        with self._lock:
            candidates = [
                o for o in self._offers.values()
                if o.price_per_shot <= max_price
                and o.reliability_score >= min_reliability
            ]
        if not candidates:
            return None
        # Sort by composite score: low price * high reliability / latency
        candidates.sort(
            key=lambda o: (o.price_per_shot * (2 - o.reliability_score)) / max(o.avg_latency_us, 1)
        )
        return candidates[0]

    def list_offers(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [o.to_dict() for o in self._offers.values()]

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            offers = [o for o in self._offers.values() if isinstance(o, DecoderOffer)]
            if not offers:
                return {"total_decoders": 0, "avg_price": 0.0, "variants": []}
            return {
                "total_decoders": len(offers),
                "avg_price": sum(o.price_per_shot for o in offers) / len(offers),
                "variants": list(set(o.model_variant for o in offers)),
            }


# ── LER Monitor ─────────────────────────────────────────────────────────────

@dataclass
class LERObservation:
    """A single logical error rate measurement."""
    distance: int
    physical_error_rate: float
    logical_error_rate: float
    baseline_ler: float
    ler_reduction: float
    model_variant: str
    num_shots: int
    timestamp: float = field(default_factory=time.time)
    agent_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class LERMonitor:
    """
    Tracks logical error rate observations over time.

    Useful for:
      - Validating decoder performance
      - Detecting noise model drift
      - Building empirical scaling curves
      - Reporting to SIMP mesh telemetry
    """

    def __init__(self, max_history: int = 10000):
        self._observations: List[LERObservation] = []
        self._max_history = max_history
        self._lock = threading.RLock()

    def record(self, result: DecodeResult) -> LERObservation:
        obs = LERObservation(
            distance=result.distance,
            physical_error_rate=result.baseline_logical_error_rate,  # approximate
            logical_error_rate=result.logical_error_rate,
            baseline_ler=result.baseline_logical_error_rate,
            ler_reduction=result.ler_reduction_factor,
            model_variant=result.model_variant,
            num_shots=result.num_shots,
            agent_id=result.agent_id,
        )
        with self._lock:
            self._observations.append(obs)
            if len(self._observations) > self._max_history:
                self._observations = self._observations[-self._max_history:]
        return obs

    def get_recent(self, n: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            return [o.to_dict() for o in self._observations[-n:]]

    def get_summary(self) -> Dict[str, Any]:
        with self._lock:
            if not self._observations:
                return {"observations": 0}
            lers = [o.logical_error_rate for o in self._observations if o.logical_error_rate > 0]
            reductions = [o.ler_reduction for o in self._observations]
            return {
                "observations": len(self._observations),
                "avg_ler": sum(lers) / len(lers) if lers else 0,
                "min_ler": min(lers) if lers else 0,
                "max_ler": max(lers) if lers else 0,
                "avg_reduction": sum(reductions) / len(reductions) if reductions else 1.0,
                "models_seen": list(set(o.model_variant for o in self._observations)),
                "distances_seen": list(set(o.distance for o in self._observations)),
            }

    def get_scaling_data(self) -> Dict[str, Any]:
        """
        Return empirical scaling data for curve fitting.
        Groups by (distance, model_variant) → (p, LER) pairs.
        """
        with self._lock:
            groups: Dict[str, List[Dict]] = {}
            for obs in self._observations:
                key = f"d{obs.distance}_{obs.model_variant}"
                if key not in groups:
                    groups[key] = []
                groups[key].append({
                    "p": obs.physical_error_rate,
                    "ler": obs.logical_error_rate,
                    "baseline_ler": obs.baseline_ler,
                    "reduction": obs.ler_reduction,
                })
            return groups


# ── SIMP Integration Helper ──────────────────────────────────────────────────

def register_decoder_with_mesh(
    agent_id: str,
    model_id: int = 1,
    bridge: Optional[IsingDecoderBridge] = None,
    marketplace: Optional[DecoderMarketplace] = None,
) -> Dict[str, Any]:
    """
    One-shot helper: creates a DecodingAgent, gets its capability,
    and registers it in the marketplace.

    Returns the full capability + marketplace registration info.
    """
    bridge = bridge or get_ising_decoder_bridge()
    agent = DecodingAgent(agent_id, model_id, bridge)
    capability = agent.publish_capability()

    market = marketplace or DecoderMarketplace()
    profile = agent.get_profile()
    # Convert dict back to AgentDecoderProfile
    from dataclasses import field
    cap = DecoderCapability(**profile["capability"])
    agent_profile = AgentDecoderProfile(
        agent_id=profile["agent_id"],
        capability=cap,
        total_decodes=profile["total_decodes"],
        avg_latency_ms=profile["avg_latency_ms"],
    )
    offer = market.register(agent_profile)

    return {
        "agent_id": agent_id,
        "model_id": model_id,
        "capability": capability,
        "market_offer": offer.to_dict(),
        "marketplace_stats": market.get_stats(),
    }


# ── Mesh Intent Handling ────────────────────────────────────────────────────

# This function can be wired into SIMP's intent routing system
# to handle quantum_decode intents directly.
def quantum_decode_intent_handler(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Handle a quantum_decode intent received from the SIMP mesh.

    Expected intent format:
    ```json
    {
        "type": "quantum_decode",
        "payload": {
            "action": "decode",
            "distance": 11,
            "n_rounds": 11,
            "basis": "X",
            "model_id": 1,
            "physical_error_rate": 0.001,
            "num_shots": 10000,
            "agent_id": "requester_agent"
        }
    }
    ```

    Returns DecodeResult as dict.
    """
    inner = payload if "payload" not in payload else payload["payload"]
    action = inner.get("action", "decode")
    handler = INTENT_HANDLERS.get(action)
    if handler is None:
        return {"error": f"Unknown quantum_decode action: {action}", "status": "error"}
    return handler(inner)


# List of all intent types this integration handles
QUANTUM_DECODE_INTENT_TYPES = ["quantum_decode", "qec_decode", "ising_decode"]
