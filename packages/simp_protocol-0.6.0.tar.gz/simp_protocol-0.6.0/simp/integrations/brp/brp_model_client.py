"""
BRP Model Client — Ollama-backed threat evaluation using the fine-tuned BRP model.

Integrates the trained `hf.co/automationkasey/brp-merged-q8` model into the SIMP
threat detection pipeline. Provides both synchronous and async evaluation.

Usage:
    client = BrpModelClient()
    result = client.evaluate_threat(action="fund_transfer", threat_score=0.85)
    result = client.evaluate_intent(intent_data)
"""

import json
import logging
import os
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum

# Try httpx first (faster, newer), fall back to urllib
try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "hf.co/automationkasey/brp-merged-q8"
DEFAULT_OLLAMA_ENDPOINT = "http://localhost:11434"
DEFAULT_TIMEOUT = 120.0  # Cold-start model load can take 60s+
CACHE_TTL = 60.0  # Cache identical queries for 60 seconds

# ---------------------------------------------------------------------------
# BRP-specific response schema
# ---------------------------------------------------------------------------

class BrpDecision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    SHADOW_ALLOW = "SHADOW_ALLOW"
    SHADOW_DENY = "SHADOW_DENY"
    ESCALATE = "ESCALATE"
    LOG_ONLY = "LOG_ONLY"

class BrpSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class BrpEvaluation:
    """Result of a BRP model evaluation."""
    action: str
    threat_score: float
    severity: BrpSeverity
    decision: BrpDecision
    is_restricted: bool
    reason: str
    confidence: float = 0.0
    mode: str = "enforced"  # enforced, shadow, advisory
    model: str = DEFAULT_MODEL
    latency_ms: float = 0.0
    from_cache: bool = False
    raw_response: str = ""

    def to_dict(self) -> Dict:
        return asdict(self)

    def to_short_string(self) -> str:
        """Compact string for logging."""
        return (
            f"[BRP] {self.action} | score={self.threat_score:.2f} "
            f"severity={self.severity.value} | {self.decision.value} "
            f"(restricted={self.is_restricted}) | {self.latency_ms:.0f}ms"
        )

# ---------------------------------------------------------------------------
# BRP Model Client
# ---------------------------------------------------------------------------

class BrpModelClient:
    """Client for the BRP Ollama model, providing threat evaluation.

    Supports both httpx (preferred) and urllib (stdlib fallback).
    """

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        ollama_endpoint: str = DEFAULT_OLLAMA_ENDPOINT,
        timeout: float = DEFAULT_TIMEOUT,
        cache_ttl: float = CACHE_TTL,
        mode: str = "enforced",
    ):
        self.model = model
        self.ollama_endpoint = ollama_endpoint.rstrip("/")
        self.timeout = timeout
        self.mode = mode
        self._use_httpx = HAS_HTTPX
        if HAS_HTTPX:
            self._client = httpx.Client(timeout=timeout)
        else:
            self._client = None
        self._cache: Dict[str, Tuple[float, BrpEvaluation]] = {}
        self._cache_ttl = cache_ttl

        # Metrics
        self.evaluations = 0
        self.cache_hits = 0
        self.errors = 0
        self.total_latency_ms = 0.0

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def evaluate_threat(
        self,
        action: str,
        threat_score: float,
        severity: str = "medium",
        context: Optional[Dict] = None,
    ) -> BrpEvaluation:
        """Evaluate a threat using the BRP model.

        Args:
            action: The action being evaluated (e.g., "fund_transfer", "withdrawal")
            threat_score: Numeric threat score 0.0–1.0
            severity: Severity label ("low", "medium", "high", "critical")
            context: Optional additional context dict

        Returns:
            BrpEvaluation with decision, reason, etc.
        """
        start = time.time()

        # Build a query key for caching
        query_key = f"{action}:{threat_score:.2f}:{severity}:{self.mode}"

        # Check cache
        cached = self._cache.get(query_key)
        if cached and (time.time() - cached[0]) < self._cache_ttl:
            self.cache_hits += 1
            self.evaluations += 1
            ev = cached[1]
            ev.latency_ms = (time.time() - start) * 1000
            ev.from_cache = True
            return ev

        # Build prompt using training-format
        prompt = self._build_threat_prompt(action, threat_score, severity, context)

        # Call model
        raw_response = self._call_ollama(prompt)

        # Parse response
        evaluation = self._parse_response(raw_response, action, threat_score, severity)
        evaluation.latency_ms = (time.time() - start) * 1000
        evaluation.from_cache = False

        # Update metrics
        self.evaluations += 1
        self.total_latency_ms += evaluation.latency_ms

        # Cache
        self._cache[query_key] = (time.time(), evaluation)

        return evaluation

    def evaluate_intent(self, intent_data: Dict) -> BrpEvaluation:
        """Evaluate a SIMP intent for BRP policy compliance."""
        action = intent_data.get("intent_type", intent_data.get("action", "unknown"))
        threat_score = float(intent_data.get("threat_score", intent_data.get("confidence", 0.5)))
        severity = intent_data.get("severity", "medium")
        context = intent_data.get("payload", intent_data.get("params", {}))

        return self.evaluate_threat(action, threat_score, severity, context)

    def health(self) -> Dict:
        """Check model availability and return health."""
        try:
            if self._use_httpx:
                with httpx.Client(timeout=2.0) as hc:
                    resp = hc.get(f"{self.ollama_endpoint}/api/tags")
                models = resp.json().get("models", [])
            else:
                req = urllib.request.Request(f"{self.ollama_endpoint}/api/tags")
                with urllib.request.urlopen(req, timeout=2) as resp:
                    data = json.loads(resp.read().decode())
                models = data.get("models", [])
            model_loaded = any(
                m.get("name", "").strip() in (self.model, self.model + ":latest")
                for m in models
            )
            return {
                "status": "ok" if model_loaded else "degraded",
                "model": self.model,
                "model_loaded": model_loaded,
                "endpoint_reachable": True,
                "evaluations": self.evaluations,
                "cache_hits": self.cache_hits,
                "errors": self.errors,
                "avg_latency_ms": (
                    self.total_latency_ms / self.evaluations if self.evaluations else 0
                ),
            }
        except Exception as exc:
            return {
                "status": "error",
                "model": self.model,
                "model_loaded": False,
                "endpoint_reachable": False,
                "error": str(exc),
            }

    def close(self):
        """Close the HTTP client."""
        if self._use_httpx and self._client:
            self._client.close()

    def flush_cache(self):
        """Clear the evaluation cache."""
        self._cache.clear()
        log.info("BRP model cache flushed")

    # -----------------------------------------------------------------------
    # Internal: Prompt building
    # -----------------------------------------------------------------------

    def _build_threat_prompt(
        self,
        action: str,
        threat_score: float,
        severity: str,
        context: Optional[Dict] = None,
    ) -> str:
        """Build a prompt matching the BRP training data format."""
        mode_str = f" Mode: {self.mode}." if hasattr(self, 'mode') else ""

        return (
            f"<|im_start|>user\n"
            f"[Q-{hash(action + str(threat_score)) % 1000000:06x}] "
            f"BRP: action={action}, threat_score={threat_score}, "
            f"severity={severity}.{mode_str} "
            f"Is this action restricted? What decision? "
            f"Explain your reasoning.\n"
            f"<|im_end|>\n"
            f"<|im_start|>assistant\n"
        )

    # -----------------------------------------------------------------------
    # Internal: Ollama API call
    # -----------------------------------------------------------------------

    def _call_ollama(self, prompt: str) -> str:
        """Call the Ollama generate API."""
        url = f"{self.ollama_endpoint}/api/generate"
        payload_dict = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.1,
                "num_predict": 300,
            },
            "keep_alive": "5m",
        }
        payload = json.dumps(payload_dict).encode()

        if self._use_httpx:
            try:
                resp = self._client.post(url, content=payload, headers={"Content-Type": "application/json"})
                resp.raise_for_status()
                return resp.json().get("response", "")
            except httpx.HTTPStatusError as e:
                self.errors += 1
                log.error(f"BRP model HTTP error: {e.response.status_code} - {e.response.text[:200]}")
                raise
            except httpx.RequestError as e:
                self.errors += 1
                log.error(f"BRP model request failed: {e}")
                raise
        else:
            try:
                req = urllib.request.Request(
                    url,
                    data=payload,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    data = json.loads(resp.read().decode())
                    return data.get("response", "")
            except urllib.error.HTTPError as e:
                self.errors += 1
                log.error(f"BRP model HTTP error: {e.code} - {e.read()[:200]}")
                raise
            except urllib.error.URLError as e:
                self.errors += 1
                log.error(f"BRP model request failed: {e.reason}")
                raise
            except Exception as e:
                self.errors += 1
                log.error(f"BRP model unexpected error: {e}")
                raise

    # -----------------------------------------------------------------------
    # Internal: Response parsing
    # -----------------------------------------------------------------------

    def _parse_response(
        self,
        raw: str,
        action: str,
        threat_score: float,
        severity: str,
    ) -> BrpEvaluation:
        """Parse the model's raw response into a structured evaluation."""
        raw_upper = raw.upper()

        # Extract decision keywords
        is_restricted = any(kw in raw_upper for kw in [
            "RESTRICTED: YES", "RESTRICTED_ACTIONS", "RESTRICTED",
            "DENY", "SHADOW_DENY", "SHADOW_ALLOW", "ESCALATE"
        ])

        # Decision mapping
        if "DECISION: DENY" in raw_upper or "DECISION: DENY." in raw_upper:
            decision = BrpDecision.DENY
        elif "DECISION: SHADOW_ALLOW" in raw_upper or "SHADOW_ALLOW" in raw_upper:
            decision = BrpDecision.SHADOW_ALLOW
        elif "DECISION: SHADOW_DENY" in raw_upper or "SHADOW_DENY" in raw_upper:
            decision = BrpDecision.SHADOW_DENY
        elif "DECISION: ALLOW" in raw_upper or "DECISION: ALLOW." in raw_upper:
            decision = BrpDecision.ALLOW
        elif "DECISION: ESCALATE" in raw_upper or "ESCALATE" in raw_upper:
            decision = BrpDecision.ESCALATE
        else:
            # Heuristic fallback based on threat score
            if threat_score >= 0.7:
                decision = BrpDecision.DENY
                is_restricted = True
            elif threat_score >= 0.4:
                decision = BrpDecision.SHADOW_ALLOW
                is_restricted = True
            else:
                decision = BrpDecision.ALLOW

        # Check for restricted actions
        restricted_actions = [
            "fund_transfer", "withdrawal", "high_value_trade",
            "account_closure", "password_reset", "sensitive_access",
        ]
        action_name = action.lower().replace(" ", "_")
        is_restricted = is_restricted or action_name in restricted_actions

        # Confidence: extracted or derived
        confidence = 0.0
        for line in raw.split("\n"):
            line_lower = line.lower()
            if "confiden" in line_lower:
                import re
                matches = re.findall(r"(\d+\.\d+)", line)
                if matches:
                    confidence = float(matches[0])
                    break

        if confidence == 0.0:
            confidence = 0.85 if is_restricted else 0.75

        # Determine severity from score
        if threat_score >= 0.7:
            sev = BrpSeverity.CRITICAL if threat_score >= 0.85 else BrpSeverity.HIGH
        elif threat_score >= 0.4:
            sev = BrpSeverity.MEDIUM
        else:
            sev = BrpSeverity.LOW

        # Reason: extract first meaningful sentence
        reason = self._extract_reason(raw, decision, action)
        if not reason:
            reason = (
                f"Action '{action}' assessed at threat_score={threat_score:.2f} "
                f"({severity}). Decision: {decision.value}."
                f"{' Action is restricted.' if is_restricted else ''}"
            )

        return BrpEvaluation(
            action=action,
            threat_score=threat_score,
            severity=sev,
            decision=decision,
            is_restricted=is_restricted,
            reason=reason[:500],
            confidence=min(confidence, 1.0),
            mode=self.mode,
            model=self.model,
            raw_response=raw[:1000],
        )

    def _extract_reason(self, raw: str, decision: BrpDecision, action: str) -> str:
        """Extract the reasoning from the model response."""
        lines = [l.strip() for l in raw.split("\n") if l.strip()]
        # Skip decision/title lines, find actual reason
        skip_prefixes = [
            "action:", "decision:", "restricted:", "score:",
            "[q-", "q:", "a:", "action", "decision"
        ]
        for line in lines:
            if any(line.lower().startswith(p) for p in skip_prefixes):
                continue
            if len(line) > 30 and not line.startswith("```"):
                return line[:300]
        return ""


# ---------------------------------------------------------------------------
# Convenience factory
# ---------------------------------------------------------------------------

def create_brp_client(
    model: str = DEFAULT_MODEL,
    endpoint: str = DEFAULT_OLLAMA_ENDPOINT,
    mode: str = "enforced",
) -> BrpModelClient:
    """Create a BRP model client, checking availability first."""
    client = BrpModelClient(model=model, ollama_endpoint=endpoint, mode=mode)
    health = client.health()
    if health.get("status") != "ok":
        if not health.get("endpoint_reachable"):
            log.warning(
                f"Ollama not reachable at {endpoint}. "
                f"BRP model will not be available for evaluations."
            )
        elif not health.get("model_loaded"):
            log.warning(
                f"BRP model '{model}' not loaded in Ollama. "
                f"Run: ollama pull {model}"
            )
    else:
        log.info(f"BRP model client ready: {model} @ {endpoint} ({health['status']})")
    return client


# ---------------------------------------------------------------------------
# Quick self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    client = create_brp_client()
    print(f"Health: {json.dumps(client.health(), indent=2)}")

    # Test threat evaluations
    test_cases = [
        ("withdrawal", 0.15, "low"),
        ("fund_transfer", 0.85, "critical"),
        ("login_attempt", 0.30, "low"),
        ("high_value_trade", 0.72, "high"),
        ("account_closure", 0.50, "medium"),
    ]

    for action, score, severity in test_cases:
        try:
            result = client.evaluate_threat(action, score, severity)
            print(result.to_short_string())
        except Exception as e:
            print(f"  ✗ {action}: {e}")

    client.close()
