"""Quantum Broker — The Brain of the Trading Body.

Receives OpportunitySignals from the Mesh, scores them with OQS + RAS
algorithms, and publishes BrokerDecision results back to the Mesh.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict

from simp.mesh.trading_signal_bus import TradingSignalBus
from simp.organs.trading_body.models import BrokerDecision, OpportunitySignal

log = logging.getLogger(__name__)


def _utcnow() -> str:
    """Return ISO-8601 UTC timestamp string."""
    return datetime.now(timezone.utc).isoformat()


# Phase 1 hardcoded weights (no learning in Phase 1)
_OQS_WEIGHTS = {
    "profit": 0.25,
    "venue": 0.20,
    "liquidity": 0.20,
    "confidence": 0.20,
    "regime": 0.15,
}

_RAS_WEIGHTS = {
    "volatility": 0.25,
    "size_risk": 0.20,
    "reliability": 0.20,
    "slippage": 0.20,
    "conversion_risk": 0.15,
}

_DEFAULT_THRESHOLDS = {
    "net_score_threshold": 0.3,
    "risk_multiplier": 1.0,
    "min_spread_bps": 5.0,
}


class QuantumBroker:
    """The brain — evaluates OpportunitySignals using OQS and RAS scoring."""

    def __init__(
        self,
        signal_bus: TradingSignalBus,
        policy_path: str = "memory/active_system_policies.json",
    ):
        self.signal_bus = signal_bus
        self.policy_path = policy_path
        self.thresholds = self._load_thresholds()
        self.weights = self._load_weights()
        self.signal_bus.subscribe(
            TradingSignalBus.ARB_OPPORTUNITY,
            self._on_opportunity,
        )

    def _load_thresholds(self) -> Dict[str, float]:
        """Load thresholds from policy file, falling back to defaults."""
        try:
            path = Path(self.policy_path)
            if path.exists():
                with open(path) as f:
                    data = json.load(f)
                stored = data.get("thresholds", {})
                result = {**_DEFAULT_THRESHOLDS, **stored}
                log.info("Loaded thresholds from %s: %s", self.policy_path, result)
                return result
        except Exception as e:
            log.warning("Could not load thresholds from %s: %s", self.policy_path, e)
        return {**_DEFAULT_THRESHOLDS}

    def _load_weights(self) -> Dict[str, Dict[str, float]]:
        """Load OQS/RAS weights from policy file, falling back to Phase 1 defaults."""
        try:
            path = Path(self.policy_path)
            if path.exists():
                with open(path) as f:
                    data = json.load(f)
                oqs = data.get("oqs_weights", _OQS_WEIGHTS)
                ras = data.get("ras_weights", _RAS_WEIGHTS)
                log.info("Loaded weights from %s", self.policy_path)
                return {"oqs": oqs, "ras": ras}
        except Exception as e:
            log.warning("Could not load weights from %s: %s", self.policy_path, e)
        return {"oqs": dict(_OQS_WEIGHTS), "ras": dict(_RAS_WEIGHTS)}

    def _compute_oqs(self, opp: OpportunitySignal) -> float:
        """Opportunity Quantum Score (0–1 scale).

        OQS = w_profit × normalized_profit
            + w_venue × venue_score
            + w_liquidity × liquidity_score
            + w_confidence × confidence
            + w_regime × regime_fit

        normalized_profit_bps = net_profit_bps / 100.0  (scales to ~0–1 range)
        regime_fit = 0.5 by default (no regime detection in Phase 1)
        """
        w = self.weights["oqs"]
        normalized_profit = opp.net_profit_bps / 100.0
        regime_fit = 0.5  # Phase 1: no regime detection

        score = (
            w["profit"] * normalized_profit
            + w["venue"] * opp.venue_score
            + w["liquidity"] * opp.liquidity_score
            + w["confidence"] * opp.confidence
            + w["regime"] * regime_fit
        )
        return max(0.0, min(1.0, score))

    def _compute_ras(self, opp: OpportunitySignal) -> float:
        """Risk Adversary Score (0–1 scale, higher = riskier).

        RAS = r_volatility × market_volatility
            + r_size_risk × position_size_risk
            + r_reliability × exchange_reliability_factor
            + r_slippage × slippage_forecast
            + r_conversion × conversion_risk

        market_volatility: from metadata, default 0.3
        position_size_risk: capital_amount / 10000 (scaled, ~0–1)
        exchange_reliability_factor: 1 - venue_score (inverted)
        slippage_forecast: from metadata, default 0.2
        conversion_risk: conversion_cost_bps / 100.0
        """
        r = self.weights["ras"]

        market_vol = float(opp.metadata.get("market_volatility", 0.3))
        position_size_risk = min(1.0, opp.capital_amount / 10000.0)
        reliability_factor = 1.0 - opp.venue_score
        slippage_forecast = float(opp.metadata.get("slippage_forecast", 0.2))
        conversion_risk = opp.conversion_cost_bps / 100.0

        score = (
            r["volatility"] * market_vol
            + r["size_risk"] * position_size_risk
            + r["reliability"] * reliability_factor
            + r["slippage"] * slippage_forecast
            + r["conversion_risk"] * conversion_risk
        )
        return max(0.0, min(1.0, score))

    def _make_reason(self, decision: str, opp: OpportunitySignal, net_score: float) -> str:
        """Build human-readable reason string."""
        if decision == "APPROVE":
            return (
                f"APPROVE: OQS-RAS net_score={net_score:.3f} > threshold={self.thresholds['net_score_threshold']:.3f} "
                f"(spread={opp.net_profit_bps:.1f}bps, confidence={opp.confidence:.2f}, "
                f"venue={opp.venue_score:.2f}, liq={opp.liquidity_score:.2f})"
            )
        else:
            return (
                f"REJECT: OQS-RAS net_score={net_score:.3f} <= threshold={self.thresholds['net_score_threshold']:.3f} "
                f"(spread={opp.net_profit_bps:.1f}bps, confidence={opp.confidence:.2f}, "
                f"venue={opp.venue_score:.2f}, liq={opp.liquidity_score:.2f})"
            )

    def _on_opportunity(self, payload: Dict[str, Any]) -> None:
        """Internal callback when an ARB_OPPORTUNITY signal arrives."""
        try:
            opp = OpportunitySignal.from_dict(payload["opportunity"])
            decision = self.evaluate(opp)
            self.signal_bus.publish(
                TradingSignalBus.BROKER_DECISION,
                {"decision": decision.to_dict()},
            )
            log.info(
                "Broker decision: %s opportunity %s (net_score=%.3f)",
                decision.decision,
                opp.opportunity_id,
                decision.net_score,
            )
        except Exception as e:
            log.error("Failed to evaluate opportunity: %s", e, exc_info=True)

    def evaluate(self, opp: OpportunitySignal) -> BrokerDecision:
        """Main evaluation entry point.

        Returns a BrokerDecision with OQS, RAS, net_score, and APPROVE/REJECT.
        """
        oqs = self._compute_oqs(opp)
        ras = self._compute_ras(opp)
        risk_mult = self.thresholds["risk_multiplier"]
        net_score = oqs - ras * risk_mult
        threshold = self.thresholds["net_score_threshold"]
        decision: Literal["APPROVE", "REJECT"] = "APPROVE" if net_score > threshold else "REJECT"

        return BrokerDecision(
            opportunity_id=opp.opportunity_id,
            decision=decision,
            net_score=net_score,
            oqs=oqs,
            ras=ras,
            reason=self._make_reason(decision, opp, net_score),
            threshold_used=threshold,
            timestamp=_utcnow(),
        )