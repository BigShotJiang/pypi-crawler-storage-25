"""TriArbFusionScanner — The Heart of the Trading Body.

Phase 1 Step 5: Polls all venues every 2-5 seconds, detects triangular and
cross-exchange arb, constructs conversion paths for capital mobilization, and
publishes OpportunitySignal to the Mesh signal bus.

Polling cadence:
  - CEX REST prices: every poll (2s by default)
  - Cross-exchange spread detection: every scan cycle
  - Conversion path recalculation: cached for 30 seconds
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from simp.mesh.trading_signal_bus import TradingSignalBus, get_signal_bus
from simp.organs.trading_body.models import ArbLeg, OpportunitySignal
from simp.organs.trading_body.wallet_tracker import WalletTracker
from simp.organs.trading_body.conversion_path import ConversionPathEngine
from simp.organs.quantumarb.exchange_connector import (
    ExchangeConnector,
    Ticker,
    OrderSide,
)

log = logging.getLogger("TriArbFusionScanner")

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

# Supported triangular base assets on each exchange
_TRI_BASE_ASSETS: Dict[str, List[str]] = {
    "coinbase": ["BTC", "ETH", "SOL", "XRP", "LTC"],
    "alpaca": ["BTC", "ETH"],
    "kraken": ["BTC", "ETH"],
}

# Quote assets used to construct triangular paths
_QUOTE_ASSETS: List[str] = ["USD", "USDC"]

# Minimum profit threshold in bps after fees to report an opportunity
_MIN_PROFIT_BPS: float = 1.0

# Cross-exchange spread threshold in bps
_MIN_CROSS_SPREAD_BPS: float = 5.0

# Conversion path cache TTL in seconds
_CONVERSION_CACHE_TTL: float = 30.0

# Default fee estimate per leg in bps (when exchange connector unavailable)
_DEFAULT_FEE_BPS: float = 10.0

# Typical fee rates per exchange (decimal → multiply by 10000 for bps)
_FEE_RATES: Dict[str, float] = {
    "coinbase": 0.006 * 10000,  # 60 bps maker/taker
    "alpaca": 0.0,  # zero for US equities in Phase 1
    "kraken": 0.0026 * 10000,  # 26 bps
    "stub": 10.0,  # 10 bps
}


def _utcnow() -> str:
    """Return ISO-8601 UTC timestamp string."""
    return datetime.now(timezone.utc).isoformat()


def _bps(decimal: float) -> float:
    """Convert decimal fraction to basis points."""
    return decimal * 10000


def _generate_id() -> str:
    """Generate a unique opportunity ID."""
    return f"OPP-{uuid.uuid4().hex[:12].upper()}"


# ---------------------------------------------------------------------------
# TriArbFusionScanner
# ---------------------------------------------------------------------------

class TriArbFusionScanner:
    """Scans all registered exchanges for triangular and cross-exchange arb.

    The heart of the trading body. Publishes detected opportunities as
    ``arb_opportunity`` signals to the Mesh signal bus.

    Attributes:
        signal_bus: TradingSignalBus instance for publishing signals.
        wallet_tracker: WalletTracker for capital availability checks.
        conversion_engine: ConversionPathEngine for capital mobilization.
        poll_interval: Seconds between scan cycles (default 2.0).
    """

    def __init__(
        self,
        signal_bus: TradingSignalBus,
        wallet_tracker: WalletTracker,
        conversion_engine: ConversionPathEngine,
        poll_interval: float = 2.0,
    ) -> None:
        self.signal_bus = signal_bus
        self.wallet_tracker = wallet_tracker
        self.conversion_engine = conversion_engine
        self.poll_interval = poll_interval
        self.exchanges: Dict[str, ExchangeConnector] = {}
        self.running = False

        # Conversion path cache: (source_asset, target_asset) -> (path, cost_bps, expiry_ts)
        self._conversion_cache: Dict[Tuple[str, str], Tuple[List[str], float, float]] = {}
        self._conversion_cache_ttl = _CONVERSION_CACHE_TTL

        log.info(
            "TriArbFusionScanner initialized (poll_interval=%.1fs)", poll_interval
        )

    # ------------------------------------------------------------------
    # Exchange registration
    # ------------------------------------------------------------------

    def register_exchange(self, name: str, connector: ExchangeConnector) -> None:
        """Register an exchange connector.

        Args:
            name: Exchange name (e.g. "coinbase", "alpaca").
            connector: ExchangeConnector instance.
        """
        self.exchanges[name] = connector
        # Wire the connector into the conversion engine for live pricing
        self.conversion_engine.wire_exchange_connector(name, connector)
        log.info("Registered exchange: %s", name)

    # ------------------------------------------------------------------
    # Main scan loop
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """Main scan loop — runs until stop() is called."""
        self.running = True
        log.info("TriArbFusionScanner running")
        while self.running:
            try:
                opportunities = self.scan()
                for opp in opportunities:
                    self.signal_bus.publish(
                        TradingSignalBus.ARB_OPPORTUNITY,
                        {"opportunity": opp.to_dict()},
                    )
                    log.debug(
                        "Published opportunity %s: %s %.2f bps",
                        opp.opportunity_id,
                        opp.signal_type,
                        opp.net_profit_bps,
                    )
            except Exception as e:
                log.error("Scan error: %s", e, exc_info=True)
            await asyncio.sleep(self.poll_interval)
        log.info("TriArbFusionScanner stopped")

    def stop(self) -> None:
        """Stop the scan loop."""
        self.running = False

    def scan(self) -> List[OpportunitySignal]:
        """Run one complete scan cycle across all exchanges.

        Returns:
            List of detected OpportunitySignal objects.
        """
        opportunities: List[OpportunitySignal] = []

        # --- Triangular arb on each exchange ---
        for exchange_name, connector in self.exchanges.items():
            try:
                opps = self._scan_triangular(exchange_name, connector)
                opportunities.extend(opps)
            except Exception as e:
                log.warning("Triangular scan failed for %s: %s", exchange_name, e)

        # --- Cross-exchange arb between all exchange pairs ---
        exchange_names = list(self.exchanges.keys())
        for i, ex_a in enumerate(exchange_names):
            for ex_b in exchange_names[i + 1:]:
                try:
                    opps = self._scan_cross_exchange(ex_a, ex_b)
                    opportunities.extend(opps)
                except Exception as e:
                    log.warning(
                        "Cross-exchange scan failed for %s vs %s: %s",
                        ex_a, ex_b, e,
                    )

        return opportunities

    # ------------------------------------------------------------------
    # Triangular arb detection
    # ------------------------------------------------------------------

    def _scan_triangular(
        self, exchange_name: str, connector: ExchangeConnector
    ) -> List[OpportunitySignal]:
        """Scan a single exchange for triangular arbitrage.

        Examines all combinations of base asset → quote1 → quote2 → base asset
        paths. E.g., BTC→ETH→USD→BTC on Coinbase.

        Args:
            exchange_name: Name of the exchange.
            connector: ExchangeConnector for this exchange.

        Returns:
            List of detected triangular opportunities.
        """
        opportunities: List[OpportunitySignal] = []
        bases = _TRI_BASE_ASSETS.get(exchange_name, ["BTC", "ETH", "SOL"])
        quotes = _QUOTE_ASSETS

        for base in bases:
            for q1 in quotes:
                for q2 in quotes:
                    if q1 == q2:
                        continue
                    try:
                        opp = self._check_triangular_path(
                            exchange_name, connector, base, q1, q2
                        )
                        if opp is not None:
                            opportunities.append(opp)
                    except Exception as e:
                        log.debug(
                            "Triangular path %s/%s/%s/%s failed: %s",
                            base, q1, q2, base, e,
                        )

        return opportunities

    def _check_triangular_path(
        self,
        exchange_name: str,
        connector: ExchangeConnector,
        base: str,
        quote1: str,
        quote2: str,
    ) -> Optional[OpportunitySignal]:
        """Check a single triangular path: base → quote1 → quote2 → base.

        Args:
            exchange_name: Exchange name.
            connector: ExchangeConnector.
            base: Base asset symbol (e.g. "BTC").
            quote1: First quote asset (e.g. "ETH").
            quote2: Second quote asset (e.g. "USD").

        Returns:
            OpportunitySignal if profitable, None otherwise.
        """
        # Build the three leg symbols
        sym_a = f"{base}-{quote1}"   # e.g. BTC-ETH
        sym_b = f"{quote1}-{quote2}" # e.g. ETH-USD
        sym_c = f"{base}-{quote2}"   # e.g. BTC-USD

        # Fetch all three tickers
        try:
            ticker_a = connector.get_ticker(sym_a)
            ticker_b = connector.get_ticker(sym_b)
            ticker_c = connector.get_ticker(sym_c)
        except Exception:
            return None  # Symbol may not exist on this exchange

        # Use mid-prices for calculation
        price_a_to_q1 = (ticker_a.bid + ticker_a.ask) / 2   # how much quote1 per base
        price_b_to_q2 = (ticker_b.bid + ticker_b.ask) / 2   # how much quote2 per quote1
        price_c_from_q2 = (ticker_c.bid + ticker_c.ask) / 2 # how much base per quote2

        if price_a_to_q1 <= 0 or price_b_to_q2 <= 0 or price_c_from_q2 <= 0:
            return None

        # Imbalance ratio:
        #   We buy base with quote2 → sell base for quote1 → buy quote2 with quote1
        #   ideal ratio = 1.0 (no arb)
        #   imbalance > 1 means we get more quote2 back than we started with
        imbalance = (price_a_to_q1 * price_b_to_q2) / price_c_from_q2

        # Fees (one round trip = 3 legs)
        fee_bps = self._exchange_fee_bps(exchange_name) * 3
        profitable_threshold = 1.0 + (fee_bps / 10000)

        if imbalance <= profitable_threshold:
            return None

        # Gross profit in bps
        raw_profit_bps = (imbalance - 1.0) * 10000

        # Net profit after fees
        net_profit_bps = raw_profit_bps - fee_bps
        if net_profit_bps < _MIN_PROFIT_BPS:
            return None

        # Construct the execution sequence (clockwise cycle)
        # Leg 1: Buy base with quote2  (e.g. buy BTC with USD)
        leg1 = ArbLeg(
            exchange=exchange_name,
            symbol=sym_c,
            side="buy",
            expected_price=price_c_from_q2,
            quantity=1.0,
            fees_bps=fee_bps / 3,
        )
        # Leg 2: Sell base for quote1  (e.g. sell BTC for ETH)
        leg2 = ArbLeg(
            exchange=exchange_name,
            symbol=sym_a,
            side="sell",
            expected_price=price_a_to_q1,
            quantity=1.0,
            fees_bps=fee_bps / 3,
        )
        # Leg 3: Buy quote2 with quote1 (e.g. buy USD with ETH)
        leg3 = ArbLeg(
            exchange=exchange_name,
            symbol=sym_b,
            side="buy",
            expected_price=price_b_to_q2,
            quantity=price_a_to_q1,  # amount of quote1 received from leg2
            fees_bps=fee_bps / 3,
        )

        execution_sequence = [leg1, leg2, leg3]

        # Capital mobilization: do we hold the needed capital?
        capital_source = f"{base}-{quote2}"
        capital_needed_usd = 1.0  # normalised to $1 for scoring

        # Get venue and liquidity scores
        venue_score = self._venue_score(exchange_name)
        liquidity_score = self._liquidity_score(ticker_c)

        return OpportunitySignal(
            opportunity_id=_generate_id(),
            signal_type="triangular",
            profitable_leg=leg2,  # The spread-capture leg
            capital_source=capital_source,
            capital_amount=capital_needed_usd,
            conversion_path=[capital_source],
            execution_sequence=execution_sequence,
            raw_profit_bps=round(raw_profit_bps, 3),
            conversion_cost_bps=0.0,  # no conversion needed for triangular
            net_profit_bps=round(net_profit_bps, 3),
            venue_score=venue_score,
            liquidity_score=liquidity_score,
            confidence=0.75,
            timestamp=_utcnow(),
            metadata={
                "exchange": exchange_name,
                "base": base,
                "quote1": quote1,
                "quote2": quote2,
                "imbalance": round(imbalance, 6),
                "path": f"{base}→{quote1}→{quote2}→{base}",
            },
        )

    # ------------------------------------------------------------------
    # Cross-exchange arb detection
    # ------------------------------------------------------------------

    def _scan_cross_exchange(
        self, ex_a: str, ex_b: str
    ) -> List[OpportunitySignal]:
        """Scan between two exchanges for cross-exchange arb.

        For each traded symbol, compares bid/ask between the two exchanges.
        If max_bid on ex_a > min_ask on ex_b (after fees), an opportunity exists.

        Args:
            ex_a: First exchange name.
            ex_b: Second exchange name.

        Returns:
            List of cross-exchange opportunities.
        """
        opportunities: List[OpportunitySignal] = []
        connector_a = self.exchanges[ex_a]
        connector_b = self.exchanges[ex_b]

        # Symbols to check
        symbols = ["BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD"]

        for symbol in symbols:
            try:
                opp = self._check_cross_exchange_pair(
                    ex_a, connector_a, ex_b, connector_b, symbol
                )
                if opp is not None:
                    opportunities.append(opp)
            except Exception as e:
                log.debug("Cross-exchange check failed for %s %s: %s", symbol, ex_a, e)

        return opportunities

    def _check_cross_exchange_pair(
        self,
        ex_a: str,
        connector_a: ExchangeConnector,
        ex_b: str,
        connector_b: ExchangeConnector,
        symbol: str,
    ) -> Optional[OpportunitySignal]:
        """Check one symbol for cross-exchange arb between two exchanges.

        Strategy:
          - Buy on the exchange with the lower ask (cheapest purchase)
          - Sell on the exchange with the higher bid (best sale)
          - Net profit = (bid_A - ask_B) / ask_B  minus fees

        Args:
            ex_a: First exchange name.
            connector_a: ExchangeConnector for ex_a.
            ex_b: Second exchange name.
            connector_b: ExchangeConnector for ex_b.
            symbol: Trading symbol (e.g. "BTC-USD").

        Returns:
            OpportunitySignal if profitable, None otherwise.
        """
        try:
            ticker_a = connector_a.get_ticker(symbol)
            ticker_b = connector_b.get_ticker(symbol)
        except Exception:
            return None

        # best sell: highest bid across exchanges
        best_bid_exchange, best_bid = self._best_bid(
            [(ex_a, ticker_a.bid), (ex_b, ticker_b.bid)]
        )
        # best buy: lowest ask across exchanges
        best_ask_exchange, best_ask = self._best_ask(
            [(ex_a, ticker_a.ask), (ex_b, ticker_b.ask)]
        )

        if best_bid <= best_ask:
            return None  # No spread

        spread_bps = (best_bid - best_ask) / best_ask * 10000

        # Fee costs: 2 legs (buy + sell)
        fee_bps = (
            self._exchange_fee_bps(best_bid_exchange)
            + self._exchange_fee_bps(best_ask_exchange)
        )

        net_spread_bps = spread_bps - fee_bps
        if net_spread_bps < _MIN_CROSS_SPREAD_BPS:
            return None

        # Determine which exchange to buy on and which to sell on
        if best_bid_exchange == best_ask_exchange:
            # Same exchange — no cross-exchange arb possible
            return None

        buy_exchange = best_ask_exchange
        sell_exchange = best_bid_exchange
        buy_ticker = ticker_b if buy_exchange == ex_b else ticker_a
        sell_ticker = ticker_a if sell_exchange == ex_a else ticker_b

        # Construct legs
        quantity = 1.0  # normalised

        leg_buy = ArbLeg(
            exchange=buy_exchange,
            symbol=symbol,
            side="buy",
            expected_price=buy_ticker.ask,
            quantity=quantity,
            fees_bps=self._exchange_fee_bps(buy_exchange),
        )
        leg_sell = ArbLeg(
            exchange=sell_exchange,
            symbol=symbol,
            side="sell",
            expected_price=sell_ticker.bid,
            quantity=quantity,
            fees_bps=self._exchange_fee_bps(sell_exchange),
        )

        execution_sequence = [leg_buy, leg_sell]

        # Capital mobilization: do we hold the needed capital on the buy exchange?
        base_asset = symbol.split("-")[0]  # e.g. "BTC" from "BTC-USD"
        needed_amount_usd = buy_ticker.ask * quantity
        held_usd = self.wallet_tracker.get_balance_usd(base_asset)

        conversion_path: List[str] = []
        conversion_cost_bps = 0.0
        capital_amount = needed_amount_usd

        if held_usd < needed_amount_usd:
            # Need to mobilize capital via conversion
            path_result = self._get_cached_conversion_path(
                "USD", base_asset, needed_amount_usd
            )
            if path_result:
                conversion_path = path_result[0]
                conversion_cost_bps = path_result[1]
                capital_amount = needed_amount_usd
            else:
                # Cannot mobilize capital — skip
                return None

        # Determine profitable leg (the sell leg captures the spread)
        profitable_leg = leg_sell

        # Scores
        venue_score = (self._venue_score(buy_exchange) + self._venue_score(sell_exchange)) / 2
        liquidity_score = self._liquidity_score(buy_ticker)

        return OpportunitySignal(
            opportunity_id=_generate_id(),
            signal_type="cross_exchange",
            profitable_leg=profitable_leg,
            capital_source="USD" if conversion_path else base_asset,
            capital_amount=round(capital_amount, 2),
            conversion_path=conversion_path,
            execution_sequence=execution_sequence,
            raw_profit_bps=round(spread_bps, 3),
            conversion_cost_bps=round(conversion_cost_bps, 3),
            net_profit_bps=round(net_spread_bps - conversion_cost_bps, 3),
            venue_score=venue_score,
            liquidity_score=liquidity_score,
            confidence=0.70,
            timestamp=_utcnow(),
            metadata={
                "buy_exchange": buy_exchange,
                "sell_exchange": sell_exchange,
                "symbol": symbol,
                "buy_ask": buy_ticker.ask,
                "sell_bid": sell_ticker.bid,
                "spread_bps": round(spread_bps, 3),
            },
        )

    # ------------------------------------------------------------------
    # Capital mobilization
    # ------------------------------------------------------------------

    def _get_cached_conversion_path(
        self, source_asset: str, target_asset: str, amount_usd: float
    ) -> Optional[Tuple[List[str], float]]:
        """Get conversion path from cache or compute and cache it.

        Caches for _CONVERSION_CACHE_TTL seconds to avoid recalculating
        every scan cycle.

        Args:
            source_asset: Asset we hold (e.g. "BTC").
            target_asset: Asset we need (e.g. "SOL").
            amount_usd: USD amount for cost estimation.

        Returns:
            Tuple of (path, cost_bps) or None if no path exists.
        """
        now = time.monotonic()
        cache_key = (source_asset, target_asset)

        # Check cache
        cached = self._conversion_cache.get(cache_key)
        if cached is not None:
            path, cost, expiry = cached
            if now < expiry:
                return (path, cost)

        # Compute new path
        path = self.conversion_engine.find_cheapest_path(
            source_asset, target_asset, amount_usd
        )
        if not path:
            return None

        cost_bps = self.conversion_engine.estimate_conversion_cost_bps(
            path, amount_usd
        )

        # Cache it
        self._conversion_cache[cache_key] = (path, cost_bps, now + self._conversion_cache_ttl)

        return (path, cost_bps)

    # ------------------------------------------------------------------
    # Helper methods
    # ------------------------------------------------------------------

    def _exchange_fee_bps(self, exchange_name: str) -> float:
        """Return fee rate in bps for an exchange."""
        return _FEE_RATES.get(exchange_name, _DEFAULT_FEE_BPS)

    def _venue_score(self, exchange_name: str) -> float:
        """Return a normalised venue reliability score (0.0–1.0).

        Phase 1: static scores based on known reliability.
        Phase 2+: learned from execution results via signal bus.
        """
        scores: Dict[str, float] = {
            "coinbase": 0.90,
            "alpaca": 0.85,
            "kraken": 0.80,
            "stub": 0.50,
        }
        return scores.get(exchange_name, 0.50)

    def _liquidity_score(self, ticker: Ticker) -> float:
        """Return a normalised liquidity score (0.0–1.0) from a ticker."""
        if ticker.volume <= 0:
            return 0.0
        # Normalise: assume 1M daily volume = score 1.0
        score = min(ticker.volume / 1_000_000, 1.0)
        return round(score, 3)

    def _best_bid(
        self, bids: List[Tuple[str, float]]
    ) -> Tuple[str, float]:
        """Return (exchange, bid) with the highest bid."""
        best_ex, best_price = "", 0.0
        for ex, price in bids:
            if price > best_price:
                best_ex, best_price = ex, price
        return best_ex, best_price

    def _best_ask(
        self, asks: List[Tuple[str, float]]
    ) -> Tuple[str, float]:
        """Return (exchange, ask) with the lowest ask."""
        best_ex, best_price = "", float("inf")
        for ex, price in asks:
            if price < best_price:
                best_ex, best_price = ex, price
        return best_ex, best_price