"""Shared data models for the SIMP Trading Body.

Phase 1: ArbLeg, OpportunitySignal, BrokerDecision, ExecutionReport.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional


@dataclass
class ArbLeg:
    """A single leg of an arbitrage trade.

    Attributes:
        exchange: Exchange venue name (e.g. "coinbase", "alpaca").
        symbol: Trading pair symbol (e.g. "BTC-USD").
        side: "buy" or "sell".
        expected_price: Expected fill price in quote currency.
        quantity: Amount of base asset to trade.
        fees_bps: Fees in basis points (default 0.0).
    """

    exchange: str
    symbol: str
    side: Literal["buy", "sell"]
    expected_price: float
    quantity: float
    fees_bps: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "exchange": self.exchange,
            "symbol": self.symbol,
            "side": self.side,
            "expected_price": self.expected_price,
            "quantity": self.quantity,
            "fees_bps": self.fees_bps,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ArbLeg:
        return cls(
            exchange=data["exchange"],
            symbol=data["symbol"],
            side=data["side"],
            expected_price=float(data["expected_price"]),
            quantity=float(data["quantity"]),
            fees_bps=float(data.get("fees_bps", 0.0)),
        )


@dataclass
class OpportunitySignal:
    """A detected arbitrage opportunity signal.

    Attributes:
        opportunity_id: Unique identifier for this opportunity.
        signal_type: One of "triangular", "cross_exchange", "multi_venue", "conversion".
        profitable_leg: The ArbLeg that captures the spread.
        capital_source: Asset we are starting from (e.g. "BTC-USD").
        capital_amount: USD value of capital to deploy.
        conversion_path: Ordered list of symbols for capital mobilisation
            (e.g. ["ETH-USD", "USD", "SOL-USD"]).
        execution_sequence: Ordered list of ArbLegs to execute.
        raw_profit_bps: Gross profit in basis points before conversion costs.
        conversion_cost_bps: Cost of converting capital to needed asset in bps.
        net_profit_bps: Net profit after all costs in basis points.
        venue_score: Normalised score for venue reliability (0.0–1.0).
        liquidity_score: Normalised score for market liquidity (0.0–1.0).
        confidence: Model confidence that the opportunity is real (0.0–1.0).
        timestamp: ISO-8601 timestamp of detection.
        metadata: Arbitrary additional data.
    """

    opportunity_id: str
    signal_type: Literal["triangular", "cross_exchange", "multi_venue", "conversion"]
    profitable_leg: ArbLeg
    capital_source: str
    capital_amount: float
    conversion_path: List[str]
    execution_sequence: List[ArbLeg]
    raw_profit_bps: float
    conversion_cost_bps: float
    net_profit_bps: float
    venue_score: float
    liquidity_score: float
    confidence: float
    timestamp: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "opportunity_id": self.opportunity_id,
            "signal_type": self.signal_type,
            "profitable_leg": self.profitable_leg.to_dict(),
            "capital_source": self.capital_source,
            "capital_amount": self.capital_amount,
            "conversion_path": self.conversion_path,
            "execution_sequence": [leg.to_dict() for leg in self.execution_sequence],
            "raw_profit_bps": self.raw_profit_bps,
            "conversion_cost_bps": self.conversion_cost_bps,
            "net_profit_bps": self.net_profit_bps,
            "venue_score": self.venue_score,
            "liquidity_score": self.liquidity_score,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> OpportunitySignal:
        return cls(
            opportunity_id=data["opportunity_id"],
            signal_type=data["signal_type"],
            profitable_leg=ArbLeg.from_dict(data["profitable_leg"]),
            capital_source=data["capital_source"],
            capital_amount=float(data["capital_amount"]),
            conversion_path=list(data["conversion_path"]),
            execution_sequence=[ArbLeg.from_dict(leg) for leg in data["execution_sequence"]],
            raw_profit_bps=float(data["raw_profit_bps"]),
            conversion_cost_bps=float(data["conversion_cost_bps"]),
            net_profit_bps=float(data["net_profit_bps"]),
            venue_score=float(data["venue_score"]),
            liquidity_score=float(data["liquidity_score"]),
            confidence=float(data["confidence"]),
            timestamp=data["timestamp"],
            metadata=dict(data.get("metadata", {})),
        )


@dataclass
class BrokerDecision:
    """Quantum broker's evaluation decision for an opportunity.

    Attributes:
        opportunity_id: Reference to the evaluated OpportunitySignal.
        decision: "APPROVE" or "REJECT".
        net_score: OQS - RAS × risk_multiplier.
        oqs: Opportunity Quantum Score (0.0–1.0).
        ras: Risk Adversary Score (0.0–1.0).
        reason: Human-readable explanation of the decision.
        threshold_used: net_score threshold used for this decision.
        timestamp: ISO-8601 timestamp of decision.
    """

    opportunity_id: str
    decision: Literal["APPROVE", "REJECT"]
    net_score: float
    oqs: float
    ras: float
    reason: str
    threshold_used: float
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "opportunity_id": self.opportunity_id,
            "decision": self.decision,
            "net_score": self.net_score,
            "oqs": self.oqs,
            "ras": self.ras,
            "reason": self.reason,
            "threshold_used": self.threshold_used,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> BrokerDecision:
        return cls(
            opportunity_id=data["opportunity_id"],
            decision=data["decision"],
            net_score=float(data["net_score"]),
            oqs=float(data["oqs"]),
            ras=float(data["ras"]),
            reason=data["reason"],
            threshold_used=float(data["threshold_used"]),
            timestamp=data["timestamp"],
        )


@dataclass
class ExecutionReport:
    """Outcome report after execution attempt.

    Attributes:
        opportunity_id: Reference to the opportunity.
        decision: The BrokerDecision that led to execution.
        execution_status: "executed", "rejected", or "failed".
        execution_result: Exchange response or error details.
        pnl_usd: Realised P&L in USD.
        fees_usd: Total fees paid in USD.
        slippage_bps: Actual slippage vs expected price in bps.
        timestamp: ISO-8601 timestamp of report.
    """

    opportunity_id: str
    decision: BrokerDecision
    execution_status: Literal["executed", "rejected", "failed"]
    execution_result: Optional[Dict[str, Any]]
    pnl_usd: float
    fees_usd: float
    slippage_bps: float
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "opportunity_id": self.opportunity_id,
            "decision": self.decision.to_dict(),
            "execution_status": self.execution_status,
            "execution_result": self.execution_result,
            "pnl_usd": self.pnl_usd,
            "fees_usd": self.fees_usd,
            "slippage_bps": self.slippage_bps,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ExecutionReport:
        return cls(
            opportunity_id=data["opportunity_id"],
            decision=BrokerDecision.from_dict(data["decision"]),
            execution_status=data["execution_status"],
            execution_result=data.get("execution_result"),
            pnl_usd=float(data["pnl_usd"]),
            fees_usd=float(data["fees_usd"]),
            slippage_bps=float(data["slippage_bps"]),
            timestamp=data["timestamp"],
        )
