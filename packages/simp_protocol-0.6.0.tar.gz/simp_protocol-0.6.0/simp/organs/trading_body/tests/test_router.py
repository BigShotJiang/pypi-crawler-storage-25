"""
Tests for OrganRouter — Step 7 of the trading body plan.
"""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
from unittest import mock

import pytest

from simp.mesh.trading_signal_bus import TradingSignalBus
from simp.organs.trading_body.models import ArbLeg, BrokerDecision, OpportunitySignal
from simp.organs.trading_body.router import OrganRouter


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_opportunity(
    opportunity_id: str = "OPP-TEST-001",
    signal_type: str = "triangular",
    net_profit_bps: float = 50.0,
    capital_amount: float = 0.50,
    venue_score: float = 0.85,
    metadata: Dict[str, Any] | None = None,
) -> OpportunitySignal:
    """Factory to build OpportunitySignal for router tests."""
    return OpportunitySignal(
        opportunity_id=opportunity_id,
        signal_type=signal_type,
        profitable_leg=ArbLeg(
            exchange="coinbase",
            symbol="BTC-USD",
            side="sell",
            expected_price=65000.0,
            quantity=1.0,
            fees_bps=10.0,
        ),
        capital_source="BTC-USD",
        capital_amount=capital_amount,
        conversion_path=[],
        execution_sequence=[
            ArbLeg(exchange="coinbase", symbol="BTC-USD", side="buy",
                   expected_price=65000.0, quantity=1.0, fees_bps=10.0),
            ArbLeg(exchange="coinbase", symbol="ETH-BTC", side="sell",
                   expected_price=0.054, quantity=1.0, fees_bps=10.0),
            ArbLeg(exchange="coinbase", symbol="ETH-USD", side="buy",
                   expected_price=3500.0, quantity=1.0, fees_bps=10.0),
        ],
        raw_profit_bps=net_profit_bps + 10.0,
        conversion_cost_bps=0.0,
        net_profit_bps=net_profit_bps,
        venue_score=venue_score,
        liquidity_score=0.70,
        confidence=0.75,
        timestamp=datetime.now(timezone.utc).isoformat(),
        metadata=metadata or {},
    )


def make_decision(
    opportunity_id: str = "OPP-TEST-001",
    decision: str = "APPROVE",
    net_score: float = 0.5,
) -> BrokerDecision:
    """Factory to build BrokerDecision for router tests."""
    return BrokerDecision(
        opportunity_id=opportunity_id,
        decision=decision,
        net_score=net_score,
        oqs=0.6,
        ras=0.1,
        reason="test",
        threshold_used=0.3,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def signal_bus():
    return TradingSignalBus(max_history=100)


@pytest.fixture
def tmp_inbox(tmp_path):
    return tmp_path / "inbox"


@pytest.fixture
def router(signal_bus, tmp_inbox):
    return OrganRouter(
        signal_bus=signal_bus,
        inbox_dir=str(tmp_inbox),
    )


# ---------------------------------------------------------------------------
# Tier routing tests
# ---------------------------------------------------------------------------

class TestTierRouting:
    """Tests for Tier A / Tier B routing based on capital_amount."""

    def test_tier_a_for_small_amounts(self, router, tmp_inbox, signal_bus):
        """capital_amount < $1.00 → writes intent JSON to inbox."""
        opp = make_opportunity(capital_amount=0.50, net_profit_bps=50.0)
        decision = make_decision(opp.opportunity_id)

        router.route(opp, decision)

        inbox_files = list(tmp_inbox.glob("OPP-TEST-001.json"))
        assert len(inbox_files) == 1
        intent = json.loads(inbox_files[0].read_text())
        assert intent["intent_type"] == "arbitrage_signal"
        assert intent["intent_id"] == opp.opportunity_id

    def test_tier_b_for_large_amounts(self, router, signal_bus):
        """capital_amount >= $1.00 → calls executor directly."""
        opp = make_opportunity(capital_amount=2.00, net_profit_bps=50.0)
        decision = make_decision(opp.opportunity_id)

        # Wire a mock executor
        mock_exec = mock.MagicMock()
        mock_exec.execute_arbitrage.return_value = mock.MagicMock(
            success=True, total_pnl_usd=0.10
        )
        router.wire_executor(mock_exec)

        router.route(opp, decision)

        mock_exec.execute_arbitrage.assert_called_once()
        call_args = mock_exec.execute_arbitrage.call_args
        assert call_args[1]["opportunity"] == opp

    def test_unwired_executor_logs_error(self, router, signal_bus, caplog):
        """Tier B without executor wired logs an error, does not crash."""
        opp = make_opportunity(capital_amount=2.00, net_profit_bps=50.0)
        decision = make_decision(opp.opportunity_id)

        # No executor wired — should not raise
        router.route(opp, decision)

        # Error should be logged
        assert any("No executor wired" in r.message for r in caplog.records)


# ---------------------------------------------------------------------------
# Signal type routing tests
# ---------------------------------------------------------------------------

class TestSignalTypeRouting:
    """Tests for routing based on signal_type."""

    def test_cross_exchange_also_respects_tier_threshold(self, router, tmp_inbox):
        """cross_exchange with capital_amount < $1 goes to Tier A inbox."""
        opp = make_opportunity(signal_type="cross_exchange", capital_amount=0.50)
        decision = make_decision(opp.opportunity_id)

        router.route(opp, decision)

        inbox_files = list(tmp_inbox.glob("OPP-TEST-001.json"))
        assert len(inbox_files) == 1

    def test_equity_signal_routes_to_equities_organ(self, router, signal_bus):
        """equity_signal publishes external_signal and falls back to inbox."""
        opp = make_opportunity(signal_type="equity_signal", capital_amount=2.00)
        decision = make_decision(opp.opportunity_id)

        # Capture published signals
        published = []
        with mock.patch.object(signal_bus, "publish", side_effect=lambda t, p: published.append((t, p))):
            router.route(opp, decision)

        # external_signal published for equities_organ
        ext_signals = [(t, p) for t, p in published if t == TradingSignalBus.EXTERNAL_SIGNAL]
        assert len(ext_signals) >= 1
        assert ext_signals[0][1]["target_organ"] == "equities_organ"

        # Still falls back to inbox
        assert router.get_inbox_count() >= 1

    def test_unknown_signal_type_defaults_to_tier_a(self, router, tmp_inbox):
        """Unknown signal_type is handled safely via Tier A inbox."""
        opp = make_opportunity(signal_type="unknown_type", capital_amount=0.50)
        decision = make_decision(opp.opportunity_id)

        router.route(opp, decision)

        inbox_files = list(tmp_inbox.glob("OPP-TEST-001.json"))
        assert len(inbox_files) == 1

    def test_negative_net_profit_skipped(self, router, tmp_inbox):
        """Opportunity with net_profit_bps <= 0 is skipped."""
        opp = make_opportunity(net_profit_bps=-10.0)
        decision = make_decision(opp.opportunity_id)

        router.route(opp, decision)

        assert router.get_inbox_count() == 0


# ---------------------------------------------------------------------------
# Rejected decisions are not routed
# ---------------------------------------------------------------------------

class TestRejectedDecisions:
    """REJECT decisions should not be routed."""

    def test_rejected_decision_not_routed(self, router, tmp_inbox):
        """REJECT decision — _on_decision skips routing entirely."""
        opp = make_opportunity(capital_amount=0.50)
        decision = make_decision(opp.opportunity_id, decision="REJECT")

        # Publish the opportunity to the bus first so _get_opportunity finds it
        router.signal_bus.publish(
            TradingSignalBus.ARB_OPPORTUNITY,
            {"opportunity": opp.to_dict()},
        )

        # Feed the REJECT decision through the actual signal handler
        router._on_decision({"decision": decision.to_dict()})

        # REJECT → no inbox write, no executor call
        assert router.get_inbox_count() == 0


# ---------------------------------------------------------------------------
# Inbox management tests
# ---------------------------------------------------------------------------

class TestInboxManagement:
    """Tests for inbox file management."""

    def test_flush_inbox_deletes_all(self, router, tmp_inbox):
        """flush_inbox() removes all intent files and returns count."""
        # Write some files
        (tmp_inbox / "OPP-1.json").write_text('{"a":1}')
        (tmp_inbox / "OPP-2.json").write_text('{"a":2}')

        assert router.get_inbox_count() == 2
        flushed = router.flush_inbox()
        assert flushed == 2
        assert router.get_inbox_count() == 0

    def test_get_inbox_count_returns_correct_number(self, router, tmp_inbox):
        """get_inbox_count() reflects actual file count."""
        assert router.get_inbox_count() == 0
        (tmp_inbox / "OPP-1.json").write_text('{"a":1}')
        assert router.get_inbox_count() == 1
        (tmp_inbox / "OPP-2.json").write_text('{"a":2}')
        assert router.get_inbox_count() == 2


# ---------------------------------------------------------------------------
# Opportunity retrieval tests
# ---------------------------------------------------------------------------

class TestOpportunityRetrieval:
    """Tests for _get_opportunity via signal bus history."""

    def test_get_opportunity_from_signal_history(self, router, signal_bus):
        """_get_opportunity finds the original signal from bus history."""
        opp = make_opportunity()
        # Publish the opportunity to the bus
        signal_bus.publish(
            TradingSignalBus.ARB_OPPORTUNITY,
            {"opportunity": opp.to_dict()},
        )

        retrieved = router._get_opportunity(opp.opportunity_id)

        assert retrieved is not None
        assert retrieved.opportunity_id == opp.opportunity_id

    def test_get_opportunity_not_found_returns_none(self, router, signal_bus):
        """Unknown opportunity_id returns None."""
        retrieved = router._get_opportunity("NONEXISTENT-999")
        assert retrieved is None
