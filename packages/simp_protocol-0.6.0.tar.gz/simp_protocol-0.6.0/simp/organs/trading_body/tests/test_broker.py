"""
Tests for QuantumBroker — Step 6 of the trading body plan.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Literal
from unittest import mock

import pytest

from simp.mesh.trading_signal_bus import TradingSignalBus
from simp.organs.trading_body.models import ArbLeg, BrokerDecision, OpportunitySignal
from simp.organs.trading_body.broker import QuantumBroker


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_opportunity(
    net_profit_bps: float = 50.0,
    capital_amount: float = 0.50,
    venue_score: float = 0.85,
    liquidity_score: float = 0.70,
    confidence: float = 0.75,
    conversion_cost_bps: float = 0.0,
    metadata: Dict[str, Any] | None = None,
) -> OpportunitySignal:
    """Factory to build OpportunitySignal for broker tests."""
    return OpportunitySignal(
        opportunity_id="OPP-TEST-001",
        signal_type="triangular",
        profitable_leg=ArbLeg(
            exchange="coinbase",
            symbol="BTC-USD",
            side="sell",
            expected_price=65000.0,
            quantity=1.0,
            fees_bps=10.0,
        ),
        capital_source="BTC-USD",
        capital_amount=capital_amount,
        conversion_path=[],
        execution_sequence=[],
        raw_profit_bps=net_profit_bps + 10.0,
        conversion_cost_bps=conversion_cost_bps,
        net_profit_bps=net_profit_bps,
        venue_score=venue_score,
        liquidity_score=liquidity_score,
        confidence=confidence,
        timestamp=datetime.now(timezone.utc).isoformat(),
        metadata=metadata or {},
    )


def make_broker(signal_bus: TradingSignalBus | None = None) -> QuantumBroker:
    """Factory to build QuantumBroker with a real or mock signal bus."""
    bus = signal_bus or TradingSignalBus(max_history=100)
    return QuantumBroker(signal_bus=bus)


# ---------------------------------------------------------------------------
# Broker evaluation tests
# ---------------------------------------------------------------------------

class TestBrokerEvaluate:
    """Tests for the main broker evaluate() entry point."""

    def test_approve_above_threshold(self):
        """OQS - RAS * risk_mult > threshold → APPROVE."""
        broker = make_broker()
        opp = make_opportunity(net_profit_bps=50.0, venue_score=0.9, liquidity_score=0.8, confidence=0.8)

        decision = broker.evaluate(opp)

        assert decision.decision == "APPROVE"
        assert decision.opportunity_id == opp.opportunity_id
        assert decision.net_score > broker.thresholds["net_score_threshold"]
        assert decision.oqs > 0
        assert decision.ras >= 0
        assert "APPROVE" in decision.reason

    def test_reject_below_threshold(self):
        """OQS - RAS * risk_mult <= threshold → REJECT."""
        broker = make_broker()
        # Low profit + low scores = low OQS, high RAS → negative net_score
        opp = make_opportunity(net_profit_bps=1.0, venue_score=0.3, liquidity_score=0.2, confidence=0.2)

        decision = broker.evaluate(opp)

        assert decision.decision == "REJECT"
        assert "REJECT" in decision.reason

    def test_net_score_is_oqs_minus_ras(self):
        """net_score = oqs - ras * risk_multiplier."""
        broker = make_broker()
        opp = make_opportunity(net_profit_bps=30.0)

        decision = broker.evaluate(opp)

        expected_net = decision.oqs - decision.ras * broker.thresholds["risk_multiplier"]
        assert abs(decision.net_score - expected_net) < 1e-6

    def test_timestamps_and_ids_present(self):
        """Decision has required fields filled."""
        broker = make_broker()
        opp = make_opportunity()

        decision = broker.evaluate(opp)

        assert decision.timestamp != ""
        assert decision.opportunity_id == "OPP-TEST-001"
        assert decision.threshold_used > 0

    def test_round_trip_to_dict_and_back(self):
        """BrokerDecision survives to_dict → from_dict round-trip."""
        broker = make_broker()
        opp = make_opportunity(net_profit_bps=25.0)

        decision = broker.evaluate(opp)
        restored = BrokerDecision.from_dict(decision.to_dict())

        assert restored.opportunity_id == decision.opportunity_id
        assert restored.decision == decision.decision
        assert abs(restored.net_score - decision.net_score) < 1e-6
        assert abs(restored.oqs - decision.oqs) < 1e-6
        assert abs(restored.ras - decision.ras) < 1e-6


# ---------------------------------------------------------------------------
# OQS scoring tests
# ---------------------------------------------------------------------------

class TestOQS:
    """Tests for Opportunity Quantum Score computation."""

    def test_oqs_normalizes_profit(self):
        """Higher net_profit_bps → higher OQS contribution from profit weight."""
        broker = make_broker()
        opp_low = make_opportunity(net_profit_bps=5.0, venue_score=0.5, liquidity_score=0.5, confidence=0.5)
        opp_high = make_opportunity(net_profit_bps=100.0, venue_score=0.5, liquidity_score=0.5, confidence=0.5)

        oqs_low = broker._compute_oqs(opp_low)
        oqs_high = broker._compute_oqs(opp_high)

        # Same non-profit scores; profit difference should dominate
        assert oqs_high > oqs_low

    def test_oqs_all_weights_sum_to_one(self):
        """OQS weights sum to 1.0."""
        broker = make_broker()
        w = broker.weights["oqs"]
        total = sum(w.values())
        assert abs(total - 1.0) < 1e-6

    def test_oqs_bounded_0_to_1(self):
        """OQS is clamped to [0.0, 1.0] even with extreme inputs."""
        broker = make_broker()
        opp_max = make_opportunity(
            net_profit_bps=1000.0,
            venue_score=1.0,
            liquidity_score=1.0,
            confidence=1.0,
        )
        opp_min = make_opportunity(
            net_profit_bps=0.0,
            venue_score=0.0,
            liquidity_score=0.0,
            confidence=0.0,
        )

        oqs_max = broker._compute_oqs(opp_max)
        oqs_min = broker._compute_oqs(opp_min)

        assert 0.0 <= oqs_max <= 1.0
        assert 0.0 <= oqs_min <= 1.0


# ---------------------------------------------------------------------------
# RAS scoring tests
# ---------------------------------------------------------------------------

class TestRAS:
    """Tests for Risk Adversary Score computation."""

    def test_ras_increases_with_volatility(self):
        """Higher market_volatility → higher RAS."""
        broker = make_broker()
        opp_calm = make_opportunity(metadata={"market_volatility": 0.1})
        opp_volatile = make_opportunity(metadata={"market_volatility": 0.9})

        ras_calm = broker._compute_ras(opp_calm)
        ras_volatile = broker._compute_ras(opp_volatile)

        assert ras_volatile > ras_calm

    def test_ras_increases_with_slippage(self):
        """Higher slippage_forecast → higher RAS."""
        broker = make_broker()
        opp_tight = make_opportunity(metadata={"slippage_forecast": 0.05})
        opp_wide = make_opportunity(metadata={"slippage_forecast": 0.50})

        ras_tight = broker._compute_ras(opp_tight)
        ras_wide = broker._compute_ras(opp_wide)

        assert ras_wide > ras_tight

    def test_ras_increases_with_conversion_cost(self):
        """Higher conversion_cost_bps → higher RAS."""
        broker = make_broker()
        opp_free = make_opportunity(conversion_cost_bps=0.0)
        opp_costly = make_opportunity(conversion_cost_bps=50.0)

        ras_free = broker._compute_ras(opp_free)
        ras_costly = broker._compute_ras(opp_costly)

        assert ras_costly > ras_free

    def test_ras_inversely_related_to_venue_score(self):
        """Lower venue_score → higher RAS (unreliable exchange)."""
        broker = make_broker()
        opp_reliable = make_opportunity(venue_score=0.95)
        opp_unreliable = make_opportunity(venue_score=0.30)

        ras_reliable = broker._compute_ras(opp_reliable)
        ras_unreliable = broker._compute_ras(opp_unreliable)

        assert ras_unreliable > ras_reliable

    def test_ras_all_weights_sum_to_one(self):
        """RAS weights sum to 1.0."""
        broker = make_broker()
        w = broker.weights["ras"]
        total = sum(w.values())
        assert abs(total - 1.0) < 1e-6

    def test_ras_bounded_0_to_1(self):
        """RAS is clamped to [0.0, 1.0] even with extreme inputs."""
        broker = make_broker()
        opp_max_risk = make_opportunity(
            venue_score=0.0,
            conversion_cost_bps=100.0,
            metadata={"market_volatility": 1.0, "slippage_forecast": 1.0},
        )
        opp_min_risk = make_opportunity(
            venue_score=1.0,
            conversion_cost_bps=0.0,
            metadata={"market_volatility": 0.0, "slippage_forecast": 0.0},
        )

        ras_max = broker._compute_ras(opp_max_risk)
        ras_min = broker._compute_ras(opp_min_risk)

        assert 0.0 <= ras_max <= 1.0
        assert 0.0 <= ras_min <= 1.0


# ---------------------------------------------------------------------------
# Threshold and weight loading tests
# ---------------------------------------------------------------------------

class TestConfigLoading:
    """Tests for threshold and weight loading from policy file."""

    def test_loads_default_thresholds(self):
        """Without a policy file, defaults are used."""
        broker = make_broker()

        assert broker.thresholds["net_score_threshold"] == 0.3
        assert broker.thresholds["risk_multiplier"] == 1.0
        assert broker.thresholds["min_spread_bps"] == 5.0

    def test_loads_default_weights(self):
        """Without a policy file, Phase 1 defaults are used."""
        broker = make_broker()

        assert broker.weights["oqs"]["profit"] == 0.25
        assert broker.weights["oqs"]["venue"] == 0.20
        assert broker.weights["ras"]["volatility"] == 0.25
