"""Tests for the SIMP Trading Body."""
