"""Wallet Tracker — reads balances from .env wallets and exchange APIs.

Phase 1, Step 2 of the trading body implementation plan.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional

import httpx

from ..quantumarb.coinbase_connector import CoinbaseConnector

log = logging.getLogger("WalletTracker")

# ---------------------------------------------------------------------------
# XRP price via CoinGecko (free, no key required)
# ---------------------------------------------------------------------------
_XRP_PRICE_CACHE: Dict[str, float] = {}
_XRP_PRICE_CACHE_TTL: float = 60.0  # seconds


def _fetch_xrp_price_usd() -> float:
    """Fetch current XRP/USD price from CoinGecko."""
    import time

    now = time.monotonic()
    cached = _XRP_PRICE_CACHE.get("XRP")
    if cached is not None and (now - _XRP_PRICE_CACHE.get("_ts", 0)) < _XRP_PRICE_CACHE_TTL:
        return cached

    try:
        resp = httpx.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={"ids": "ripple", "vs_currencies": "usd"},
            timeout=10.0,
        )
        resp.raise_for_status()
        data = resp.json()
        price = float(data["ripple"]["usd"])
        _XRP_PRICE_CACHE["XRP"] = price
        _XRP_PRICE_CACHE["_ts"] = now
        return price
    except Exception as e:
        log.warning("Failed to fetch XRP price from CoinGecko: %s", e)
        # Fallback stub price
        return _XRP_PRICE_CACHE.get("XRP", 2.35)


# ---------------------------------------------------------------------------
# Solana price via CoinGecko (free, no key required)
# ---------------------------------------------------------------------------
_SOL_PRICE_CACHE: Dict[str, float] = {}
_SOL_PRICE_CACHE_TTL: float = 60.0


def _fetch_sol_price_usd() -> float:
    """Fetch current SOL/USD price from CoinGecko."""
    import time

    now = time.monotonic()
    cached = _SOL_PRICE_CACHE.get("SOL")
    if cached is not None and (now - _SOL_PRICE_CACHE.get("_ts", 0)) < _SOL_PRICE_CACHE_TTL:
        return cached

    try:
        resp = httpx.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={"ids": "solana", "vs_currencies": "usd"},
            timeout=10.0,
        )
        resp.raise_for_status()
        data = resp.json()
        price = float(data["solana"]["usd"])
        _SOL_PRICE_CACHE["SOL"] = price
        _SOL_PRICE_CACHE["_ts"] = now
        return price
    except Exception as e:
        log.warning("Failed to fetch SOL price from CoinGecko: %s", e)
        return _SOL_PRICE_CACHE.get("SOL", 180.0)


# ---------------------------------------------------------------------------
# WalletTracker
# ---------------------------------------------------------------------------

class WalletTracker:
    """Tracks wallet balances from .env wallets and exchange APIs.

    Attributes:
        balances: Dict mapping asset symbol to USD value.

    .env variables read:
        SOLANA_WALLET_ADDRESS     — Solana wallet address
        SOLANA_WALLET_PUBLIC_KEY  — Solana wallet public key
        XRP_WALLET_ADDRESS        — XRP ledger wallet address
        COINBASE_API_KEY_NAME     — Coinbase Advanced Trade API key name
        COINBASE_API_PRIVATE_KEY  — Coinbase Advanced Trade API private key (EC)
        ALCHEMY_SOLANA_ENDPOINT   — Alchemy Solana RPC endpoint
    """

    def __init__(self, env_path: str = ".env"):
        self.balances: Dict[str, float] = {}  # asset -> USD value
        self._raw_balances: Dict[str, float] = {}  # asset -> native amount

        # Solana
        self._sol_wallet_address: Optional[str] = None
        self._sol_rpc_url: Optional[str] = None

        # XRP
        self._xrp_wallet_address: Optional[str] = None

        # Coinbase
        self._coinbase_connector: Optional[CoinbaseConnector] = None

        self._load_from_env(env_path)
        self.refresh()

    # ------------------------------------------------------------------
    # Environment loading
    # ------------------------------------------------------------------

    def _load_from_env(self, env_path: str) -> None:
        """Parse .env file and initialise connectors."""
        env_vars = self._parse_env(env_path)

        # Solana
        self._sol_wallet_address = env_vars.get("SOLANA_WALLET_ADDRESS")
        self._sol_rpc_url = env_vars.get("ALCHEMY_SOLANA_ENDPOINT")

        # XRP
        self._xrp_wallet_address = env_vars.get("XRP_WALLET_ADDRESS")

        # Coinbase
        cb_key = env_vars.get("COINBASE_API_KEY_NAME", "")
        cb_secret = env_vars.get("COINBASE_API_PRIVATE_KEY", "")

        if cb_key and cb_secret:
            try:
                self._coinbase_connector = CoinbaseConnector(
                    api_key=cb_key,
                    api_secret=cb_secret,
                    passphrase="",  # Advanced Trade uses no passphrase
                    sandbox=False,  # live trading
                )
                log.info("Coinbase connector initialised (live mode)")
            except Exception as e:
                log.warning("Failed to initialise Coinbase connector: %s", e)
                self._coinbase_connector = None
        else:
            log.info("No Coinbase credentials found — Coinbase balance will be skipped")

    def _parse_env(self, env_path: str) -> Dict[str, str]:
        """Parse a .env-style file and return key-value pairs."""
        vars_: Dict[str, str] = {}
        path = Path(env_path)

        # Search upward from cwd if path is relative and not found
        if not path.is_absolute() and not path.exists():
            search = Path.cwd()
            for parent in [search] + list(search.parents):
                candidate = parent / env_path
                if candidate.exists():
                    path = candidate
                    break

        if not path.exists():
            log.warning(".env file not found at %s", env_path)
            return vars_

        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, _, value = line.partition("=")
                vars_[key.strip()] = value.strip().strip('"').strip("'")

        return vars_

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_balance_usd(self, asset: str) -> float:
        """Return USD value of held asset.

        Args:
            asset: Asset symbol (e.g. "SOL", "XRP", "BTC", "ETH", "USD").

        Returns:
            USD value of the asset balance, or 0.0 if not found.
        """
        return self.balances.get(asset.upper(), 0.0)

    def get_all_balances(self) -> Dict[str, float]:
        """Return all balances as {asset: usd_value}."""
        return dict(self.balances)

    def get_raw_balance(self, asset: str) -> float:
        """Return native amount of held asset (before USD conversion).

        Args:
            asset: Asset symbol (e.g. "SOL", "XRP").

        Returns:
            Raw balance in native units, or 0.0 if not tracked.
        """
        return self._raw_balances.get(asset.upper(), 0.0)

    def refresh(self) -> None:
        """Refresh all balances from exchanges and blockchain RPC."""
        self._raw_balances.clear()
        self.balances.clear()

        self._refresh_solana()
        self._refresh_xrp()
        self._refresh_coinbase()

        log.debug("Wallet balances refreshed: %s", self.balances)

    # ------------------------------------------------------------------
    # Solana
    # ------------------------------------------------------------------

    def _refresh_solana(self) -> None:
        """Poll Solana RPC for SOL balance and convert to USD."""
        if not self._sol_wallet_address or not self._sol_rpc_url:
            log.info("Solana wallet or RPC URL not configured — skipping")
            return

        try:
            from solana.rpc.api import Client as SolanaClient

            client = SolanaClient(self._sol_rpc_url)
            response = client.get_balance(self._sol_wallet_address)

            # Balance is in lamports (1 SOL = 1e9 lamports)
            lamports = int(response.value)
            sol_balance = lamports / 1e9
            self._raw_balances["SOL"] = sol_balance

            # Fetch SOL price and compute USD value
            sol_price = _fetch_sol_price_usd()
            self.balances["SOL"] = sol_balance * sol_price

            log.info(
                "Solana balance: %.4f SOL (~$%.2f at $%.2f/SOL)",
                sol_balance,
                self.balances["SOL"],
                sol_price,
            )

        except ImportError:
            log.warning("'solana' package not installed — Solana balance unavailable")
        except Exception as e:
            log.error("Failed to fetch Solana balance: %s", e)

    # ------------------------------------------------------------------
    # XRP Ledger
    # ------------------------------------------------------------------

    def _refresh_xrp(self) -> None:
        """Poll XRP ledger for XRP balance via public JSON-RPC."""
        if not self._xrp_wallet_address:
            log.info("XRP wallet address not configured — skipping")
            return

        try:
            # XRPL public JSON-RPC endpoint
            payload = {
                "method": "account_info",
                "params": [
                    {
                        "account": self._xrp_wallet_address,
                        "strict": True,
                        "ledger_index": "validated",
                    }
                ],
            }

            with httpx.post(
                "https://xrplcluster.com",
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10.0,
            ) as resp:
                resp.raise_for_status()
                data = resp.json()

            result = data.get("result", {})
            balance_drops = int(result.get("account_data", {}).get("Balance", "0"))
            xrp_balance = balance_drops / 1e6  # 1 XRP = 1e6 drops
            self._raw_balances["XRP"] = xrp_balance

            xrp_price = _fetch_xrp_price_usd()
            self.balances["XRP"] = xrp_balance * xrp_price

            log.info(
                "XRP balance: %.4f XRP (~$%.2f at $%.4f/XRP)",
                xrp_balance,
                self.balances["XRP"],
                xrp_price,
            )

        except ImportError:
            log.warning("httpx not available — XRP balance unavailable")
        except Exception as e:
            log.error("Failed to fetch XRP balance: %s", e)

    # ------------------------------------------------------------------
    # Coinbase
    # ------------------------------------------------------------------

    def _refresh_coinbase(self) -> None:
        """Poll Coinbase for account balances via Advanced Trade API."""
        if self._coinbase_connector is None:
            log.info("Coinbase connector not configured — skipping")
            return

        try:
            # Coinbase connector's get_balance returns Balance(currency, available, total, held)
            # We track: BTC, ETH, SOL, XRP, USD (as available USD)
            for currency in ("BTC", "ETH", "SOL", "XRP", "USD"):
                try:
                    bal = self._coinbase_connector.get_balance(currency)

                    if currency == "USD":
                        usd_val = bal.available  # already in USD
                        self._raw_balances["USD"] = bal.available
                        self.balances["USD"] = usd_val
                    else:
                        # Fetch price of this currency in USD
                        symbol = f"{currency}-USD"
                        try:
                            ticker = self._coinbase_connector.get_ticker(symbol)
                            price = ticker.last
                        except Exception:
                            log.warning("No ticker for %s, using 0", symbol)
                            price = 0.0

                        usd_val = bal.available * price
                        self._raw_balances[currency] = bal.available
                        self.balances[currency] = usd_val

                        log.info(
                            "Coinbase %s balance: %.4f (~$%.2f at $%.2f)",
                            currency,
                            bal.available,
                            usd_val,
                            price,
                        )

                except Exception as e:
                    log.warning("Failed to get Coinbase balance for %s: %s", currency, e)

        except Exception as e:
            log.error("Failed to refresh Coinbase balances: %s", e)

    # ------------------------------------------------------------------
    # Debug / repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"WalletTracker(balances={self.balances}, "
            f"sol_wallet={self._sol_wallet_address}, "
            f"xrp_wallet={self._xrp_wallet_address}, "
            f"coinbase_configured={self._coinbase_connector is not None})"
        )
