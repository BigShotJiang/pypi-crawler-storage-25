"""Conversion Path Engine for capital mobilization.

Phase 1 Step 3: Finds cheapest conversion path from any held asset to any needed asset.
Used by the scanner to construct capital mobilization plans.
"""

from __future__ import annotations

import heapq
import logging
from collections import defaultdict
from typing import TYPE_CHECKING, Dict, List, Optional, Set, Tuple

if TYPE_CHECKING:
    from simp.organs.trading_body.wallet_tracker import WalletTracker

log = logging.getLogger("ConversionPathEngine")

# Default spread assumption in bps when no live data available
_DEFAULT_SPREAD_BPS = 10.0  # 0.10%


class ConversionPathEngine:
    """Finds cheapest conversion path between assets across registered exchanges.

    Uses a graph of conversion pairs where nodes are assets and edges are
    trading symbols. Dijkstra/BFS finds the cheapest path by cumulative cost.

    Attributes:
        wallet_tracker: WalletTracker instance for balance context.
        conversion_pairs: Dict mapping exchange name -> list of supported symbols.
        _exchange_connectors: Optional dict of exchange connectors for live pricing.
    """

    def __init__(
        self,
        wallet_tracker: "WalletTracker",
        conversion_pairs: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        """Initialize ConversionPathEngine.

        Args:
            wallet_tracker: WalletTracker instance for balance context.
            conversion_pairs: Optional override for default conversion pairs.
                              Defaults to built-in pairs for coinbase and alpaca.
        """
        self.wallet_tracker = wallet_tracker
        self.conversion_pairs: Dict[str, List[str]] = conversion_pairs or {
            "coinbase": ["BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD", "LTC-USD"],
            "alpaca": ["SPY", "QQQ", "BTC-USD", "ETH-USD"],
        }
        # Exchange connectors set by scanner via wire_exchange_connector()
        self._exchange_connectors: Dict[str, object] = {}

    def wire_exchange_connector(self, exchange: str, connector: object) -> None:
        """Wire an exchange connector for live price feeds.

        Args:
            exchange: Exchange name (e.g. "coinbase").
            connector: ExchangeConnector instance.
        """
        self._exchange_connectors[exchange] = connector

    def find_cheapest_path(
        self,
        source_asset: str,
        target_asset: str,
        amount_usd: float,
    ) -> List[str]:
        """Return cheapest conversion path as list of symbols.

        Performs weighted BFS on the conversion graph. Edge weights are
        estimated conversion costs in bps. Returns empty list if no path
        exists or source == target.

        Args:
            source_asset: Starting asset name (e.g. "BTC", "ETH").
            target_asset: Target asset name (e.g. "SOL", "USD").
            amount_usd: USD amount for cost estimation (unused in path search,
                        used for tiebreaking in phase 2).

        Returns:
            List of trading symbols representing the conversion path.
            e.g. ["ETH-USD", "SOL-USD"] means sell ETH for USD, buy SOL with USD.
            Returns [] if source == target or no path found.
        """
        if source_asset == target_asset:
            return []

        # Build adjacency graph: asset -> set of (connected_asset, symbol, exchange)
        graph = self._build_conversion_graph()
        if source_asset not in graph or target_asset not in graph:
            return []

        # Weighted BFS using cost as priority
        #pq: (cost, steps, current_asset, path)
        pq: List[Tuple[float, int, str, List[str]]] = [(0.0, 0, source_asset, [])]
        visited: Set[str] = set()
        best_cost: Dict[str, float] = {source_asset: 0.0}

        while pq:
            cost, steps, current, path = heapq.heappop(pq)

            if current in visited:
                continue
            visited.add(current)

            if current == target_asset:
                return path

            for neighbor, symbol, exchange in graph.get(current, []):
                if neighbor in visited:
                    continue

                # Cost of this edge in bps
                edge_cost = self._estimate_edge_cost(symbol, exchange, amount_usd)
                new_cost = cost + edge_cost

                if new_cost < best_cost.get(neighbor, float("inf")):
                    best_cost[neighbor] = new_cost
                    new_path = path + [symbol]
                    heapq.heappush(pq, (new_cost, steps + 1, neighbor, new_path))

        return []  # No path found

    def estimate_conversion_cost_bps(
        self,
        path: List[str],
        amount_usd: float,
    ) -> float:
        """Return estimated cost in basis points for a conversion path.

        Sums the per-leg costs (fees + spread) across all symbols in path.

        Args:
            path: List of trading symbols (e.g. ["ETH-USD", "SOL-USD"]).
            amount_usd: USD amount for size-dependent cost estimation.

        Returns:
            Total estimated cost in basis points. Returns 0.0 for empty path.
        """
        if not path:
            return 0.0

        total_bps = 0.0
        for symbol in path:
            exchange = self._find_exchange_for_symbol(symbol)
            cost_bps = self._estimate_edge_cost(symbol, exchange, amount_usd)
            total_bps += cost_bps

        return total_bps

    def _build_conversion_graph(
        self,
    ) -> Dict[str, List[Tuple[str, str, str]]]:
        """Build adjacency list graph from conversion pairs.

        Nodes are assets. Edges are trading symbols with exchange metadata.

        Returns:
            Dict mapping asset -> list of (connected_asset, symbol, exchange).
        """
        graph: Dict[str, List[Tuple[str, str, str]]] = defaultdict(list)

        for exchange, symbols in self.conversion_pairs.items():
            for symbol in symbols:
                if "-" not in symbol:
                    continue
                base, quote = symbol.split("-", 1)
                # Undirected edge: base <-> quote via symbol on exchange
                graph[base].append((quote, symbol, exchange))
                graph[quote].append((base, symbol, exchange))

        return dict(graph)

    def _find_exchange_for_symbol(self, symbol: str) -> Optional[str]:
        """Find which exchange supports a given symbol."""
        for exchange, symbols in self.conversion_pairs.items():
            if symbol in symbols:
                return exchange
        return None

    def _estimate_edge_cost(
        self,
        symbol: str,
        exchange: Optional[str],
        amount_usd: float,
    ) -> float:
        """Estimate conversion cost for a single edge in bps.

        Uses live fee rate from exchange connector if available,
        otherwise falls back to default fee + spread estimate.

        Args:
            symbol: Trading symbol (e.g. "BTC-USD").
            exchange: Exchange name or None.
            amount_usd: USD amount (for future size-dependent modeling).

        Returns:
            Estimated cost in basis points.
        """
        cost_bps = 0.0

        # Fee component from exchange connector
        if exchange and exchange in self._exchange_connectors:
            conn = self._exchange_connectors[exchange]
            try:
                fee_rate = conn.get_fees()  # decimal, e.g. 0.001
                cost_bps += fee_rate * 100  # convert to bps
            except Exception as e:
                log.debug(f"Failed to get fees for {exchange}: {e}")
                cost_bps += 10.0  # fallback: 10 bps
        else:
            # Default fee assumption: 10 bps (0.10%)
            cost_bps += 10.0

        # Spread component from ticker
        if exchange and exchange in self._exchange_connectors:
            conn = self._exchange_connectors[exchange]
            try:
                ticker = conn.get_ticker(symbol)
                spread_bps = abs(ticker.ask - ticker.bid) / ticker.last * 10000
                cost_bps += spread_bps
            except Exception as e:
                log.debug(f"Failed to get ticker for {symbol}: {e}")
                cost_bps += _DEFAULT_SPREAD_BPS
        else:
            cost_bps += _DEFAULT_SPREAD_BPS

        return cost_bps

    def get_available_assets(self) -> Set[str]:
        """Return set of all assets reachable through configured conversion pairs."""
        graph = self._build_conversion_graph()
        return set(graph.keys())