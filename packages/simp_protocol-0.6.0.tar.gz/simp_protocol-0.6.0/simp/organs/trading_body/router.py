"""
Organ Router — the nervous system of the SIMP Trading Body.

Routes approved opportunities to the correct execution organ based on
signal_type and capital_amount:

  - Tier A (< $1.00): Write intent JSON to inbox for QuantumArbAgentPhase4
    to process with full safety gates.
  - Tier B (>= $1.00): Direct execution via TradeExecutor with inline risk checks.

All routing decisions are published to the Mesh signal bus.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

from simp.mesh.trading_signal_bus import TradingSignalBus, get_signal_bus
from simp.organs.trading_body.models import BrokerDecision, OpportunitySignal

log = logging.getLogger(__name__)


class OrganRouter:
    """Routes approved opportunities to the correct execution organ.

    Tier A (inbox): capital_amount < $1.00 → QuantumArbAgentPhase4 processes
                    with full safety gates and polling.
    Tier B (direct): capital_amount >= $1.00 → TradeExecutor executes immediately
                    with all risk checks inline.
    """

    def __init__(
        self,
        signal_bus: Optional[TradingSignalBus] = None,
        inbox_dir: str = "data/quantumarb_phase4/inbox",
    ) -> None:
        self.signal_bus = signal_bus or get_signal_bus()
        self.inbox_dir = Path(inbox_dir)
        self.inbox_dir.mkdir(parents=True, exist_ok=True)
        self.executor: Optional["TradeExecutor"] = None  # wired later

        # Subscribe to broker decisions
        self.signal_bus.subscribe(
            TradingSignalBus.BROKER_DECISION,
            self._on_decision,
        )

    def wire_executor(self, executor: "TradeExecutor") -> None:
        """Wire in a TradeExecutor for Tier B direct execution."""
        self.executor = executor

    # -------------------------------------------------------------------------
    # Signal handlers
    # -------------------------------------------------------------------------

    def _on_decision(self, payload: Dict[str, Any]) -> None:
        """Handle incoming BrokerDecision signals."""
        decision = BrokerDecision.from_dict(payload["decision"])
        if decision.decision != "APPROVE":
            return

        opp = self._get_opportunity(decision.opportunity_id)
        if opp is None:
            log.warning(
                "Opportunity %s not found in signal history — cannot route",
                decision.opportunity_id,
            )
            return

        self.route(opp, decision)

    # -------------------------------------------------------------------------
    # Routing logic
    # -------------------------------------------------------------------------

    def route(self, opp: OpportunitySignal, decision: BrokerDecision) -> None:
        """Route opportunity to the correct organ based on signal_type and amount.

        Decision tree:
          triangular / cross_exchange  + capital_amount < $1.00  → Tier A (inbox)
          triangular / cross_exchange  + capital_amount >= $1.00 → Tier B (direct)
          equity_signal                                          → equities organ
          kalshi_prediction                                      → Kalshi organ
          unknown / other                                        → Tier A (safe default)
        """
        if opp.net_profit_bps <= 0:
            log.debug(
                "Opportunity %s has non-positive net profit (%.2f bps) — skipping",
                opp.opportunity_id,
                opp.net_profit_bps,
            )
            return

        if opp.signal_type in ("triangular", "cross_exchange"):
            if opp.capital_amount < 1.0:
                self._route_to_inbox(opp)
            else:
                self._route_direct(opp, decision)
        elif opp.signal_type == "equity_signal":
            self._route_to_equities_organ(opp)
        elif opp.signal_type == "kalshi_prediction":
            self._route_to_kalshi(opp)
        else:
            # Safe default — use Tier A inbox for unknown signal types
            self._route_to_inbox(opp)

    def _route_to_inbox(self, opp: OpportunitySignal) -> None:
        """Write opportunity to inbox for QuantumArbAgentPhase4 to process.

        QuantumArbAgentPhase4 polls ``inbox_dir`` and processes each intent
        through its full safety gate pipeline (emergency stop, slippage checks,
        position size limits, etc.). This is the safest path for small capital.
        """
        intent = {
            "intent_type": "arbitrage_signal",
            "intent_id": opp.opportunity_id,
            "source_agent": "trading_body_organ_router",
            "payload": opp.to_dict(),
            "timestamp": opp.timestamp,
        }
        path = self.inbox_dir / f"{opp.opportunity_id}.json"
        try:
            with open(path, "w") as f:
                json.dump(intent, f)
            log.info(
                "Tier A routing: opportunity %s written to inbox (%s)",
                opp.opportunity_id,
                path,
            )
        except OSError as exc:
            log.error(
                "Failed to write inbox intent for %s: %s",
                opp.opportunity_id,
                exc,
            )

    def _route_direct(self, opp: OpportunitySignal, decision: BrokerDecision) -> None:
        """Direct execution via wired TradeExecutor with inline risk checks.

        Used for capital_amount >= $1.00 where the executor's own risk controls
        (max_position_size_usd, max_slippage_bps, emergency_stop) are sufficient.
        Results are published back to the Mesh as EXECUTION_RESULT signals.
        """
        if self.executor is None:
            log.error(
                "No executor wired — cannot route opportunity %s directly",
                opp.opportunity_id,
            )
            return

        result = self.executor.execute_arbitrage(
            opportunity=opp,
            execution_plan={
                "steps": [leg.to_dict() for leg in opp.execution_sequence],
            },
        )

        log.info(
            "Tier B direct execution: opportunity %s → success=%s pnl=%.4f",
            opp.opportunity_id,
            result.success,
            result.total_pnl_usd,
        )

        self.signal_bus.publish(
            TradingSignalBus.EXECUTION_RESULT,
            {
                "opportunity_id": opp.opportunity_id,
                "result": result.to_dict(),
                "broker_decision": decision.to_dict(),
            },
        )

    def _route_to_equities_organ(self, opp: OpportunitySignal) -> None:
        """Route equity signals to the equities execution organ.

        Placeholder: publishes an external_signal that the equities organ
        will consume once it is implemented (Phase 2).
        """
        log.info(
            "Routing equity_signal opportunity %s to equities organ (not yet implemented)",
            opp.opportunity_id,
        )
        self.signal_bus.publish(
            TradingSignalBus.EXTERNAL_SIGNAL,
            {
                "opportunity": opp.to_dict(),
                "target_organ": "equities_organ",
                "note": "equities_organ not yet implemented — Tier A inbox fallback",
            },
        )
        # Fallback: route through Tier A inbox until equities organ exists
        self._route_to_inbox(opp)

    def _route_to_kalshi(self, opp: OpportunitySignal) -> None:
        """Route Kalshi prediction signals to the Kalshi execution organ.

        Placeholder: similar to equities organ — publishes external_signal and
        falls back to Tier A inbox.
        """
        log.info(
            "Routing kalshi_prediction opportunity %s to Kalshi organ (not yet implemented)",
            opp.opportunity_id,
        )
        self.signal_bus.publish(
            TradingSignalBus.EXTERNAL_SIGNAL,
            {
                "opportunity": opp.to_dict(),
                "target_organ": "kalshi_organ",
                "note": "kalshi_organ not yet implemented — Tier A inbox fallback",
            },
        )
        # Fallback: route through Tier A inbox until Kalshi organ exists
        self._route_to_inbox(opp)

    # -------------------------------------------------------------------------
    # Opportunity retrieval
    # -------------------------------------------------------------------------

    def _get_opportunity(self, opportunity_id: str) -> Optional[OpportunitySignal]:
        """Retrieve the original OpportunitySignal from signal bus history.

        Looks up the most recent ARB_OPPORTUNITY signal with the matching
        opportunity_id. Returns None if not found.
        """
        recent = self.signal_bus.get_recent_signals(
            TradingSignalBus.ARB_OPPORTUNITY,
            n=100,
        )
        for record in reversed(recent):
            payload = record.get("payload", {})
            if "opportunity" in payload:
                opp_data = payload["opportunity"]
                if isinstance(opp_data, dict) and opp_data.get("opportunity_id") == opportunity_id:
                    return OpportunitySignal.from_dict(opp_data)
        return None

    # -------------------------------------------------------------------------
    # Introspection
    # -------------------------------------------------------------------------

    def get_inbox_count(self) -> int:
        """Return the number of pending intents in the inbox."""
        try:
            return len(list(self.inbox_dir.glob("*.json")))
        except OSError:
            return 0

    def flush_inbox(self) -> int:
        """Delete all files in the inbox. Returns count of deleted files."""
        count = 0
        try:
            for path in self.inbox_dir.glob("*.json"):
                path.unlink()
                count += 1
        except OSError as exc:
            log.warning("Error flushing inbox: %s", exc)
        return count