"""
Voiceover Engine for SIMP Commercials.

Generates voiceovers using free/affordable TTS providers:
- Bark (Suno) - open source, local
- Coqui XTTS - voice cloning, local
- ElevenLabs - free tier
- MMS Fairseq - Meta, 1000+ languages
"""
import asyncio
import base64
import logging
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger("media.simp_promo.voiceover")


class VoiceStyle(Enum):
    """Voice styles for different commercial types."""
    PROFESSIONAL = "professional"  # Corporate, trustworthy
    CASUAL = "casual"  # Friendly, approachable
    EXCITED = "excited"  # Energetic, enthusiastic
    DEEP = "deep"  # Authoritative, deep tone
    SOFT = "soft"  # Calm, soothing
    YOUNG = "young"  # Youthful, Gen-Z
    BRITISH = "british"  # British accent
    AMERICAN = "american"  # American accent


class TTSBackend(Enum):
    """Available TTS backends."""
    BARK = "bark"  # Suno open source
    COQUI = "coqui"  # Coqui XTTS
    ELEVENLABS = "elevenlabs"  # ElevenLabs free
    MMS = "mms"  # Meta MMS
    GTTS = "gtts"  # Google TTS (free, no voice cloning)
    EDGE_TTS = "edge_tts"  # Microsoft Edge TTS (free, good quality)


@dataclass
class VoiceConfig:
    """Configuration for voice generation."""
    backend: TTSBackend = TTSBackend.BARK
    
    # Voice identity
    voice_style: VoiceStyle = VoiceStyle.PROFESSIONAL
    voice_id: Optional[str] = None
    
    # Generation settings
    speed: float = 1.0  # 0.5 - 2.0
    pitch: float = 1.0  # 0.5 - 2.0
    energy: float = 1.0  # 0.5 - 2.0
    
    # Output
    output_format: str = "wav"  # wav, mp3, ogg
    sample_rate: int = 24000
    
    # API keys
    elevenlabs_key: Optional[str] = None
    
    # Local model path
    local_model_path: Optional[str] = None


@dataclass
class VoiceoverResult:
    """Result of voiceover generation."""
    success: bool
    
    # Output
    audio_path: Optional[str] = None
    audio_url: Optional[str] = None
    
    # Metadata
    duration_seconds: float = 0.0
    transcript: str = ""
    backend: str = ""
    
    # Error
    error: Optional[str] = None


@dataclass
class SIMPVoiceoverPresets:
    """Presets for SIMP commercial voiceovers."""
    # Brand voice profiles
    BRAND_VOICES = {
        "simp_founder": {
            "style": VoiceStyle.PROFESSIONAL,
            "description": "Confident, visionary founder voice",
            "personality": "Leading the autonomous revolution"
        },
        "simp_explainer": {
            "style": VoiceStyle.CASUAL,
            "description": "Friendly explainer voice",
            "personality": "Makes complex simple"
        },
        "simp_hype": {
            "style": VoiceStyle.EXCITED,
            "description": "High energy hype voice",
            "personality": "Can't contain the excitement"
        },
        "simp_pro": {
            "style": VoiceStyle.DEEP,
            "description": "Deep authoritative voice",
            "personality": "Trust and expertise"
        },
    }


class VoiceoverEngine:
    """
    Multi-backend voiceover engine for SIMP commercials.
    
    Supports multiple TTS backends with automatic fallback.
    """
    
    def __init__(
        self,
        config: Optional[VoiceConfig] = None,
        data_dir: str = "data/media/simp_promo/voiceovers"
    ):
        self.config = config or VoiceConfig()
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("media.simp_promo.voiceover_engine")
        
        # Check available backends
        self._available_backends = self._detect_backends()
        
        # Generate audio cache
        self._audio_cache: Dict[str, str] = {}
    
    def _detect_backends(self) -> List[TTSBackend]:
        """Detect which TTS backends are available."""
        available = []
        
        # Check gtts (always available)
        try:
            import gtts
            available.append(TTSBackend.GTTS)
        except ImportError:
            pass
        
        # Check edge-tts
        try:
            import edge_tts
            available.append(TTSBackend.EDGE_TTS)
        except ImportError:
            pass
        
        # Check bark
        try:
            from bark import generate_audio
            available.append(TTSBackend.BARK)
        except ImportError:
            pass
        
        # Check elevenlabs
        if os.environ.get("ELEVENLABS_API_KEY"):
            available.append(TTSBackend.ELEVENLABS)
        
        # Check coqui
        try:
            from TTS.api import TTS
            available.append(TTSBackend.COQUI)
        except ImportError:
            pass
        
        self.logger.info(f"Available TTS backends: {[b.value for b in available]}")
        return available
    
    async def generate_voiceover(
        self,
        script: str,
        voice_style: Optional[VoiceStyle] = None,
        output_path: Optional[str] = None,
    ) -> VoiceoverResult:
        """
        Generate voiceover from script.
        
        Args:
            script: Text to speak
            voice_style: Voice style preset
            output_path: Optional output file path
            
        Returns:
            VoiceoverResult with audio path and metadata
        """
        voice_style = voice_style or self.config.voice_style
        
        # Generate output path if not provided
        if not output_path:
            output_path = str(self.data_dir / f"vo_{uuid.uuid4().hex[:8]}.{self.config.output_format}")
        
        self.logger.info(f"Generating voiceover: {len(script)} chars with {voice_style.value}")
        
        # Try each backend in order of preference
        backends_to_try = [
            self.config.backend,
            TTSBackend.EDGE_TTS,
            TTSBackend.GTTS,
        ]
        
        last_error = None
        for backend in backends_to_try:
            if backend in self._available_backends:
                try:
                    result = await self._generate_with_backend(
                        backend,
                        script,
                        voice_style,
                        output_path
                    )
                    if result.success:
                        return result
                    last_error = result.error
                except Exception as e:
                    last_error = str(e)
                    self.logger.debug(f"Backend {backend.value} failed: {e}")
        
        # All backends failed
        return VoiceoverResult(
            success=False,
            error=f"All backends failed. Last error: {last_error}"
        )
    
    async def _generate_with_backend(
        self,
        backend: TTSBackend,
        script: str,
        voice_style: VoiceStyle,
        output_path: str
    ) -> VoiceoverResult:
        """Generate voiceover with specific backend."""
        
        if backend == TTSBackend.EDGE_TTS:
            return await self._generate_edge_tts(script, voice_style, output_path)
        
        elif backend == TTSBackend.GTTS:
            return await self._generate_gtts(script, output_path)
        
        elif backend == TTSBackend.BARK:
            return await self._generate_bark(script, voice_style, output_path)
        
        elif backend == TTSBackend.ELEVENLABS:
            return await self._generate_elevenlabs(script, output_path)
        
        elif backend == TTSBackend.COQUI:
            return await self._generate_coqui(script, output_path)
        
        else:
            return VoiceoverResult(success=False, error=f"Backend {backend.value} not implemented")
    
    async def _generate_edge_tts(
        self,
        script: str,
        voice_style: VoiceStyle,
        output_path: str
    ) -> VoiceoverResult:
        """Generate using Microsoft Edge TTS (free, high quality)."""
        try:
            import edge_tts
            
            # Map voice style to Edge TTS voice
            voice_map = {
                VoiceStyle.PROFESSIONAL: "en-US-GuyNeural",
                VoiceStyle.CASUAL: "en-US-AriaNeural",
                VoiceStyle.EXCITED: "en-US-JennyNeural",
                VoiceStyle.DEEP: "en-US-DavisNeural",
                VoiceStyle.SOFT: "en-US-SaraNeural",
                VoiceStyle.YOUNG: "en-US-JennyNeural",
                VoiceStyle.BRITISH: "en-GB-RyanNeural",
                VoiceStyle.AMERICAN: "en-US-ChristopherNeural",
            }
            
            voice = voice_map.get(voice_style, "en-US-GuyNeural")
            
            # Edge TTS parameters
            rate = f"+{int((self.config.speed - 1) * 100)}%" if self.config.speed > 1 else f"{int((self.config.speed - 1) * 100)}%"
            pitch = f"+{int((self.config.pitch - 1) * 10)}Hz" if self.config.pitch > 1 else f"{int((self.config.pitch - 1) * 10)}Hz"
            
            communicate = edge_tts.Communicate(script, voice)
            await communicate.save(output_path)
            
            # Get duration
            import wave
            with wave.open(output_path, 'rb') as w:
                frames = w.getnframes()
                rate = w.getframerate()
                duration = frames / float(rate)
            
            return VoiceoverResult(
                success=True,
                audio_path=output_path,
                duration_seconds=duration,
                transcript=script,
                backend="edge_tts"
            )
            
        except ImportError:
            return VoiceoverResult(success=False, error="edge-tts not installed")
        except Exception as e:
            return VoiceoverResult(success=False, error=str(e))
    
    async def _generate_gtts(
        self,
        script: str,
        output_path: str
    ) -> VoiceoverResult:
        """Generate using Google TTS (free, no voice options)."""
        try:
            from gtts import gTTS
            
            tts = gTTS(text=script, lang='en', slow=(self.config.speed < 0.8))
            tts.save(output_path)
            
            return VoiceoverResult(
                success=True,
                audio_path=output_path,
                duration_seconds=len(script) / 150,  # Estimate
                transcript=script,
                backend="gtts"
            )
            
        except ImportError:
            return VoiceoverResult(success=False, error="gtts not installed")
        except Exception as e:
            return VoiceoverResult(success=False, error=str(e))
    
    async def _generate_bark(
        self,
        script: str,
        voice_style: VoiceStyle,
        output_path: str
    ) -> VoiceoverResult:
        """Generate using Bark (Suno open source)."""
        try:
            from bark import generate_audio, SAMPLE_RATE
            import scipy.io.wavfile as wavfile
            
            # Bark voice presets
            voice_preset = "v2/en_speaker_6"  # Default male voice
            
            if voice_style == VoiceStyle.CASUAL:
                voice_preset = "v2/en_speaker_9"
            elif voice_style == VoiceStyle.EXCITED:
                voice_preset = "v2/en_speaker_1"
            elif voice_style == VoiceStyle.SOFT:
                voice_preset = "v2/en_speaker_5"
            
            # Generate
            audio_array = generate_audio(
                script,
                history_prompt=voice_preset,
                text_temp=0.7,
                waveform_temp=0.7
            )
            
            # Save
            wavfile.write(output_path, SAMPLE_RATE, audio_array)
            
            duration = len(audio_array) / SAMPLE_RATE
            
            return VoiceoverResult(
                success=True,
                audio_path=output_path,
                duration_seconds=duration,
                transcript=script,
                backend="bark"
            )
            
        except ImportError:
            return VoiceoverResult(success=False, error="bark not installed")
        except Exception as e:
            return VoiceoverResult(success=False, error=str(e))
    
    async def _generate_elevenlabs(
        self,
        script: str,
        output_path: str
    ) -> VoiceoverResult:
        """Generate using ElevenLabs (free tier)."""
        try:
            import httpx
            
            api_key = self.config.elevenlabs_key or os.environ.get("ELEVENLABS_API_KEY")
            if not api_key:
                return VoiceoverResult(success=False, error="No ElevenLabs API key")
            
            # Get voice ID
            voice_id = self.config.voice_id or "21m00Tcm4TlvDq8ikWAM"  # Rachel
            
            # Generate
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
                    headers={
                        "xi-api-key": api_key,
                        "Content-Type": "application/json"
                    },
                    json={
                        "text": script,
                        "voice_settings": {
                            "stability": 0.5,
                            "similarity_boost": 0.75,
                            "style": 0.5,
                            "use_speaker_boost": True
                        }
                    },
                    timeout=30.0
                )
                
                if response.status_code == 200:
                    # Save audio
                    with open(output_path, "wb") as f:
                        f.write(response.content)
                    
                    return VoiceoverResult(
                        success=True,
                        audio_path=output_path,
                        duration_seconds=len(script) / 150,
                        transcript=script,
                        backend="elevenlabs"
                    )
                else:
                    return VoiceoverResult(
                        success=False,
                        error=f"ElevenLabs error: {response.status_code}"
                    )
                    
        except Exception as e:
            return VoiceoverResult(success=False, error=str(e))
    
    async def _generate_coqui(
        self,
        script: str,
        output_path: str
    ) -> VoiceoverResult:
        """Generate using Coqui XTTS (open source voice cloning)."""
        try:
            from TTS.api import TTS
            
            # Initialize with XTTS model
            tts = TTS(model_name="xtts", progress_bar=False)
            
            # Generate (requires GPU for best results)
            tts.tts(
                text=script,
                file_path=output_path,
                speaker_wav=None,  # Could use reference audio for cloning
                language="en"
            )
            
            return VoiceoverResult(
                success=True,
                audio_path=output_path,
                duration_seconds=len(script) / 150,
                transcript=script,
                backend="coqui_xtts"
            )
            
        except ImportError:
            return VoiceoverResult(success=False, error="Coqui TTS not installed")
        except Exception as e:
            return VoiceoverResult(success=False, error=str(e))
    
    async def generate_simp_voiceover(
        self,
        script: str,
        preset: str = "simp_founder"
    ) -> VoiceoverResult:
        """
        Generate SIMP-branded voiceover with preset voice.
        
        Args:
            script: Voiceover script
            preset: Voice preset from SIMPVoiceoverPresets
            
        Returns:
            VoiceoverResult with generated audio
        """
        preset_config = SIMPVoiceoverPresets.BRAND_VOICES.get(preset)
        
        if not preset_config:
            preset_config = SIMPVoiceoverPresets.BRAND_VOICES["simp_founder"]
        
        voice_style = preset_config["style"]
        
        self.logger.info(f"Generating SIMP voiceover with preset: {preset}")
        
        return await self.generate_voiceover(script, voice_style)
    
    def get_available_backends(self) -> List[str]:
        """Get list of available TTS backends."""
        return [b.value for b in self._available_backends]
    
    def get_voice_styles(self) -> List[str]:
        """Get list of available voice styles."""
        return [v.value for v in VoiceStyle]


async def generate_voiceover(
    script: str,
    style: VoiceStyle = VoiceStyle.PROFESSIONAL,
    backend: TTSBackend = TTSBackend.EDGE_TTS
) -> VoiceoverResult:
    """Convenience function to generate a voiceover."""
    engine = VoiceoverEngine(VoiceConfig(backend=backend, voice_style=style))
    return await engine.generate_voiceover(script, style)
