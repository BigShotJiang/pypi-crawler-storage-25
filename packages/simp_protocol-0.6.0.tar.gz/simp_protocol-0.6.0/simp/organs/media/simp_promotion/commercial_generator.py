"""
SIMP Commercial Generator.

Generates compelling commercials and promotional scripts for SIMP platform.
"""
import asyncio
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable

import logging

logger = logging.getLogger("media.simp_promo.commercial")


class CommercialType(Enum):
    """Types of SIMP commercials."""
    INTRO = "intro"  # What is SIMP
    FEATURE_SPOTLIGHT = "feature_spotlight"  # Specific feature
    TESTIMONIAL = "testimonial"  # User success story
    COMPARISON = "comparison"  # SIMP vs alternatives
    TUTORIAL = "tutorial"  # How to use
    PRODUCT_TOUR = "product_tour"  # Full platform walkthrough
    SOCIAL_PROOF = "social_proof"  # Stats and metrics
    EMOTIONAL = "emotional"  # Aspirational/outro


class CommercialStyle(Enum):
    """Visual and audio style for commercials."""
    CINEMATIC = "cinematic"  # High-end film quality
    FAST_PACED = "fast_paced"  # Quick cuts, energetic
    MINIMALIST = "minimalist"  # Clean, simple
    ANIMATED = "animated"  # Motion graphics/2D
    LIVE_ACTION = "live_action"  # Real footage
    MIXED = "mixed"  # Combination of styles


class Tone(Enum):
    """Tone of the commercial."""
    PROFESSIONAL = "professional"
    CASUAL = "casual"
    EXCITED = "excited"
    MYSTERIOUS = "mysterious"
    INSPIRATIONAL = "inspirational"
    TECHNICAL = "technical"


@dataclass
class CommercialScene:
    """A single scene in a commercial."""
    scene_id: str
    duration_seconds: float
    
    # Visual
    visual_description: str
    text_overlay: str = ""
    
    # Audio
    voiceover_script: str = ""
    music_mood: str = "upbeat"
    sfx: List[str] = field(default_factory=list)
    
    # Transition
    transition: str = "cut"  # cut, fade, dissolve, wipe


@dataclass
class CommercialScript:
    """Complete commercial script."""
    script_id: str
    title: str
    commercial_type: CommercialType
    
    # Meta
    target_duration_seconds: float = 30.0
    target_audience: str = "developers, builders, operators"
    platform: str = "twitter"  # twitter, youtube, tiktok, website
    
    # Scenes
    scenes: List[CommercialScene] = field(default_factory=list)
    
    # Hook
    hook: str = ""
    
    # Key message
    key_message: str = ""
    
    # Call to action
    cta: str = ""
    cta_url: str = "https://github.com/your-org/simp"
    
    # Technical notes
    music_cue: str = ""
    style_notes: str = ""
    
    # Metadata
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    version: int = 1


@dataclass
class SIMPFeature:
    """A SIMP feature to highlight."""
    name: str
    tagline: str
    description: str
    benefit: str  # Why user cares
    icon: str = ""


# SIMP Feature Library
SIMP_FEATURES = [
    SIMPFeature(
        name="Autonomous Agents",
        tagline="AI agents that work while you sleep",
        description="Deploy AI agents that handle complex workflows autonomously",
        benefit="10x productivity without the overhead"
    ),
    SIMPFeature(
        name="SIMP Broker",
        tagline="The nervous system of your operations",
        description="Intelligent routing and orchestration of tasks and intents",
        benefit="Everything works together seamlessly"
    ),
    SIMPFeature(
        name="Media Empire",
        tagline="Build your content empire on autopilot",
        description="Autonomous video creation, social posting, and monetization",
        benefit="Scale content without scaling effort"
    ),
    SIMPFeature(
        name="Quantum Arb",
        tagline="DeFi trading on autopilot",
        description="Intelligent arbitrage across exchanges with risk management",
        benefit="Make money while you sleep"
    ),
    SIMPFeature(
        name="Brain Intents",
        tagline="Think it, the agents handle it",
        description="Natural language interface to control all your agents",
        benefit="Complex tasks, simple commands"
    ),
    SIMPFeature(
        name="Watchtower",
        tagline="Your 24/7 digital guardian",
        description="Real-time monitoring and automated incident response",
        benefit="Sleep peacefully knowing your systems are watched"
    ),
]


@dataclass
class CommercialConfig:
    """Configuration for commercial generation."""
    commercial_type: CommercialType = CommercialType.INTRO
    style: CommercialStyle = CommercialStyle.CINEMATIC
    tone: Tone = Tone.EXCITED
    
    target_duration_seconds: float = 30.0
    target_audience: str = "developers, builders"
    
    # Which features to highlight (None = all)
    features: Optional[List[str]] = None
    
    # Script generation parameters
    llm_provider: str = "ollama"
    llm_model: str = "llama3.2:3b"
    
    # Output
    output_format: str = "json"  # json, markdown, video_script


class SIMPCommercialGenerator:
    """
    Generates compelling commercials for SIMP platform.
    """
    
    def __init__(
        self,
        config: Optional[CommercialConfig] = None,
        data_dir: str = "data/media/simp_promo"
    ):
        self.config = config or CommercialConfig()
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("media.simp_promo.commercial_generator")
        
        # LLM client
        self._llm_client = None
        self._init_llm()
        
        # Templates
        self._scene_templates = self._load_scene_templates()
        self._hooks = self._load_hooks()
        self._ctas = self._load_ctas()
    
    def _init_llm(self):
        """Initialize LLM client for script generation."""
        try:
            import httpx
            # Will use Ollama by default
            self._llm_client = httpx.AsyncClient(
                base_url="http://localhost:11434",
                timeout=60.0
            )
        except Exception as e:
            self.logger.warning(f"LLM not available: {e}. Will use templates.")
    
    def _load_scene_templates(self) -> Dict[str, List[Dict]]:
        """Load scene structure templates."""
        return {
            "intro": [
                {"type": "hook", "duration": 3, "visual": "logo animation"},
                {"type": "problem", "duration": 5, "visual": "person struggling"},
                {"type": "solution", "duration": 7, "visual": "SIMP interface"},
                {"type": "features", "duration": 10, "visual": "feature showcase"},
                {"type": "cta", "duration": 5, "visual": "call to action"}
            ],
            "feature_spotlight": [
                {"type": "hook", "duration": 2, "visual": "feature name"},
                {"type": "demo", "duration": 15, "visual": "feature in action"},
                {"type": "benefit", "duration": 5, "visual": "user success"},
                {"type": "cta", "duration": 3, "visual": "try it now"}
            ],
            "comparison": [
                {"type": "problem_old", "duration": 8, "visual": "old way"},
                {"type": "transition", "duration": 2, "visual": "vs"},
                {"type": "solution_new", "duration": 15, "visual": "SIMP way"},
                {"type": "cta", "duration": 5, "visual": "switch now"}
            ],
            "social_proof": [
                {"type": "stats", "duration": 10, "visual": "metrics"},
                {"type": "testimonials", "duration": 12, "visual": "users"},
                {"type": "cta", "duration": 5, "visual": "join them"}
            ]
        }
    
    def _load_hooks(self) -> List[str]:
        """Load hook templates."""
        return [
            "What if your software could work while you sleep?",
            "Stop managing tools. Start building empires.",
            "This is what autonomous productivity looks like.",
            "Your competitors are using AI agents. Are you?",
            "The future of development isn't coding. It's commanding.",
            "Imagine: ideas to production in minutes, not months.",
            "This single platform replaced my entire tool stack.",
            "While you were reading this, agents were getting things done.",
        ]
    
    def _load_ctas(self) -> List[str]:
        """Load CTA templates."""
        return [
            "Try SIMP today at {url}",
            "Get started free at {url}",
            "Join thousands of builders at {url}",
            "Deploy your first agent at {url}",
            "See what SIMP can do at {url}",
        ]
    
    async def generate_commercial(
        self,
        commercial_type: Optional[CommercialType] = None,
        style: Optional[CommercialStyle] = None,
        target_duration: Optional[float] = None,
    ) -> CommercialScript:
        """
        Generate a complete commercial script.
        
        Args:
            commercial_type: Type of commercial to generate
            style: Visual/audio style
            target_duration: Target duration in seconds
            
        Returns:
            Complete commercial script with scenes
        """
        commercial_type = commercial_type or self.config.commercial_type
        style = style or self.config.style
        target_duration = target_duration or self.config.target_duration_seconds
        
        script_id = f"simp_commercial_{uuid.uuid4().hex[:8]}"
        
        self.logger.info(f"Generating {style.value} {commercial_type.value} commercial...")
        
        # Generate hook
        hook = await self._generate_hook(commercial_type)
        
        # Generate scenes
        scenes = await self._generate_scenes(
            commercial_type,
            style,
            target_duration,
            hook
        )
        
        # Generate CTA
        cta = await self._generate_cta()
        
        # Generate key message
        key_message = await self._generate_key_message(commercial_type)
        
        # Create script
        script = CommercialScript(
            script_id=script_id,
            title=f"SIMP {commercial_type.value.replace('_', ' ').title()} - {style.value}",
            commercial_type=commercial_type,
            target_duration_seconds=target_duration,
            hook=hook,
            scenes=scenes,
            key_message=key_message,
            cta=cta,
            style_notes=f"Style: {style.value}. Tone: {self.config.tone.value}."
        )
        
        # Save script
        self._save_script(script)
        
        self.logger.info(f"Generated commercial: {script_id}")
        return script
    
    async def _generate_hook(self, commercial_type: CommercialType) -> str:
        """Generate compelling opening hook."""
        if self._llm_client:
            try:
                prompt = f"""Generate a compelling opening hook for a SIMP platform commercial.
Type: {commercial_type.value}
Tone: {self.config.tone.value}
Duration: 3-5 seconds of voiceover

Requirements:
- Grabs attention immediately
- Creates curiosity or emotion
- Relevant to {self.config.target_audience}

Return only the hook line, nothing else. Under 15 words."""
                
                response = await self._llm_client.post(
                    "/api/generate",
                    json={
                        "model": self.config.llm_model,
                        "prompt": prompt,
                        "stream": False
                    }
                )
                
                if response.status_code == 200:
                    return response.json().get("response", "").strip()
            except Exception as e:
                self.logger.debug(f"LLM hook generation failed: {e}")
        
        # Fallback to templates
        import random
        return random.choice(self._hooks)
    
    async def _generate_cta(self) -> str:
        """Generate call to action."""
        import random
        cta_template = random.choice(self._ctas)
        return cta_template.format(url=self.config.output_format)
    
    async def _generate_key_message(self, commercial_type: CommercialType) -> str:
        """Generate the key message."""
        messages = {
            CommercialType.INTRO: "SIMP: Autonomous agents that work for you.",
            CommercialType.FEATURE_SPOTLIGHT: "One feature, infinite possibilities.",
            CommercialType.TESTIMONIAL: "Join thousands who've already transformed.",
            CommercialType.COMPARISON: "There's a better way. SIMP.",
            CommercialType.TUTORIAL: "Getting started takes minutes.",
            CommercialType.PRODUCT_TOUR: "See the full power of SIMP.",
            CommercialType.SOCIAL_PROOF: "The numbers don't lie.",
            CommercialType.EMOTIONAL: "This is what freedom looks like.",
        }
        return messages.get(commercial_type, "SIMP: Work smarter, not harder.")
    
    async def _generate_scenes(
        self,
        commercial_type: CommercialType,
        style: CommercialStyle,
        target_duration: float,
        hook: str
    ) -> List[CommercialScene]:
        """Generate scene breakdown."""
        scenes = []
        
        # Calculate scene durations based on template
        scene_templates = self._scene_templates.get(
            commercial_type.value.replace("_", ""),
            self._scene_templates["intro"]
        )
        
        # Scale to fit target duration
        total_template_duration = sum(s.get("duration", 5) for s in scene_templates)
        scale_factor = target_duration / total_template_duration
        
        scene_id = 1
        for template in scene_templates:
            duration = template["duration"] * scale_factor
            scene = CommercialScene(
                scene_id=f"scene_{scene_id}",
                duration_seconds=duration,
                visual_description=self._generate_visual(
                    template["type"],
                    style
                ),
                voiceover_script=await self._generate_voiceover_for_scene(
                    template["type"],
                    duration
                ),
                music_mood=self._get_music_mood(template["type"]),
                transition=self._get_transition(style)
            )
            scenes.append(scene)
            scene_id += 1
        
        return scenes
    
    def _generate_visual(self, scene_type: str, style: CommercialStyle) -> str:
        """Generate visual description for scene."""
        visuals = {
            "hook": f"Motion graphics logo reveal, {style.value} aesthetic",
            "problem": "Person at desk, multiple screens, overwhelmed expression",
            "solution": "SIMP dashboard, agents working, smooth animations",
            "features": "Feature icons animating in, brief UI shots",
            "cta": "SIMP logo with URL, calm confident energy",
            "demo": "Screen recording with UI highlights, clean cuts",
            "benefit": "User success moment, achievement visualization",
            "stats": "Animated graphs, growing numbers, social proof",
            "testimonials": "User photos with quotes, authentic feel",
        }
        
        base = visuals.get(scene_type, "Clean professional visuals")
        
        style_notes = {
            CommercialStyle.CINEMATIC: "Add film grain, anamorphic flares",
            CommercialStyle.FAST_PACED: "Quick cuts, dynamic camera movement",
            CommercialStyle.MINIMALIST: "White space, single focal point",
            CommercialStyle.ANIMATED: "2D motion graphics, clean vectors",
            CommercialStyle.LIVE_ACTION: "Real people, natural lighting",
            CommercialStyle.MIXED: "Blend of styles, seamless transitions",
        }
        
        return f"{base}. {style_notes.get(style, '')}"
    
    async def _generate_voiceover_for_scene(
        self,
        scene_type: str,
        duration_seconds: float
    ) -> str:
        """Generate voiceover script for a scene."""
        word_count = int(duration_seconds * 2.5)  # ~150 words/min speaking rate
        
        prompts = {
            "hook": f"Opening hook: {word_count} words. Confident, intriguing tone.",
            "problem": f"Describe the pain point: {word_count} words. Relatable struggle.",
            "solution": f"Introduce SIMP: {word_count} words. Clear, enthusiastic.",
            "features": f"Feature highlights: {word_count} words. Benefits-focused.",
            "cta": f"Call to action: {word_count} words. Clear next step.",
            "demo": f"Feature demonstration narration: {word_count} words. Professional.",
            "benefit": f"User benefit: {word_count} words. Aspirational.",
            "stats": f"Statistics and social proof: {word_count} words. Credible.",
            "testimonials": f"Testimonial voiceover: {word_count} words. Authentic.",
        }
        
        if self._llm_client:
            try:
                response = await self._llm_client.post(
                    "/api/generate",
                    json={
                        "model": self.config.llm_model,
                        "prompt": prompts.get(scene_type, prompts["solution"]),
                        "stream": False
                    }
                )
                if response.status_code == 200:
                    return response.json().get("response", "").strip()
            except Exception:
                pass
        
        # Fallback
        fallbacks = {
            "hook": "Stop managing tools. Start building empires.",
            "problem": "You're juggling too many tools. It's overwhelming.",
            "solution": "SIMP brings it all together with AI agents.",
            "features": "Autonomous agents, smart routing, 24/7 operation.",
            "cta": "Try SIMP today. Link in description.",
            "demo": "Watch how easily SIMP handles complex tasks.",
            "benefit": "Imagine what you could build with 10x the power.",
            "stats": "Thousands of builders trust SIMP every day.",
            "testimonials": "SIMP changed how I work. Total game changer.",
        }
        return fallbacks.get(scene_type, "SIMP makes it happen.")
    
    def _get_music_mood(self, scene_type: str) -> str:
        """Get music mood for scene."""
        moods = {
            "hook": "upbeat_energetic",
            "problem": "tense_building",
            "solution": "uplifting_reveal",
            "features": "confident_showcase",
            "cta": "warm_confident",
            "demo": "professional_ambient",
            "benefit": "inspirational",
            "stats": "triumphant_confident",
            "testimonials": "warm_authentic",
        }
        return moods.get(scene_type, "upbeat")
    
    def _get_transition(self, style: CommercialStyle) -> str:
        """Get transition style."""
        transitions = {
            CommercialStyle.CINEMATIC: "dissolve",
            CommercialStyle.FAST_PACED: "cut",
            CommercialStyle.MINIMALIST: "fade",
            CommercialStyle.ANIMATED: "wipe",
            CommercialStyle.LIVE_ACTION: "cut",
            CommercialStyle.MIXED: "dissolve",
        }
        return transitions.get(style, "cut")
    
    def _save_script(self, script: CommercialScript):
        """Save script to file."""
        output_file = self.data_dir / f"{script.script_id}.json"
        
        with open(output_file, "w") as f:
            json.dump({
                "script_id": script.script_id,
                "title": script.title,
                "commercial_type": script.commercial_type.value,
                "hook": script.hook,
                "key_message": script.key_message,
                "cta": script.cta,
                "target_duration_seconds": script.target_duration_seconds,
                "style_notes": script.style_notes,
                "scenes": [
                    {
                        "scene_id": s.scene_id,
                        "duration_seconds": s.duration_seconds,
                        "visual_description": s.visual_description,
                        "voiceover_script": s.voiceover_script,
                        "music_mood": s.music_mood,
                        "transition": s.transition,
                    }
                    for s in script.scenes
                ],
                "created_at": script.created_at,
            }, f, indent=2)
        
        self.logger.info(f"Saved script to {output_file}")


async def generate_simp_commercial(
    commercial_type: CommercialType = CommercialType.INTRO,
    style: CommercialStyle = CommercialStyle.CINEMATIC,
    duration: float = 30.0
) -> CommercialScript:
    """Convenience function to generate a SIMP commercial."""
    generator = SIMPCommercialGenerator(
        CommercialConfig(
            commercial_type=commercial_type,
            style=style,
            target_duration_seconds=duration
        )
    )
    return await generator.generate_commercial()
