"""
Promotional Templates for SIMP.

Ready-to-use templates for SIMP commercials, social posts, and ads.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional
from enum import Enum


class Platform(Enum):
    """Target platforms for promotional content."""
    TWITTER = "twitter"
    YOUTUBE = "youtube"
    TIKTOK = "tiktok"
    LINKEDIN = "linkedin"
    WEBSITE = "website"
    NEWSLETTER = "newsletter"


@dataclass
class PromoTemplate:
    """A promotional content template."""
    template_id: str
    name: str
    platform: Platform
    content_type: str  # tweet, short_video, ad, etc.
    
    # Template content with placeholders
    template: str
    
    # Platform-specific
    char_limit: Optional[int] = None
    hashtag_suggestions: List[str] = None
    media_type: str = "video"  # video, image, text
    
    # Performance hints
    best_for: List[str] = None
    engagement_tips: str = ""


class PromoTemplates:
    """Collection of SIMP promotional templates."""
    
    # Twitter/X Templates
    TWITTER_TEMPLATES = [
        PromoTemplate(
            template_id="tweet_intro_1",
            name="What is SIMP - Hook",
            platform=Platform.TWITTER,
            content_type="tweet",
            template="""What if your software could work while you sleep?

@{handle} built autonomous agents that handle the boring stuff so you can focus on building.

🤖 AI agents that actually work
⚡ Deploy in minutes  
💰 Save hours every day

{url}""",
            char_limit=280,
            hashtag_suggestions=["#AI", "#Agents", "#Automation", "#DevTools", "#NoCode"],
            best_for=["awareness", "link_clicks"],
            engagement_tips="Ask a question to boost engagement"
        ),
        
        PromoTemplate(
            template_id="tweet_feature_agents",
            name="Feature Spotlight - Agents",
            platform=Platform.TWITTER,
            content_type="tweet",
            template="""Introducing SIMP Agents 🧠

Deploy AI agents that:
• Handle complex workflows
• Work 24/7
• Learn and improve
• Connect to any API

The future of automation is here.

{url}

RT if you want to work less.""",
            char_limit=280,
            hashtag_suggestions=["#AIAgents", "#Automation", "#Productivity", "#AIAgents"],
            best_for=["product_launch", "engagement"],
            engagement_tips="Use numbered lists for higher engagement"
        ),
        
        PromoTemplate(
            template_id="tweet_comparison",
            name="The Reality Check",
            platform=Platform.TWITTER,
            content_type="tweet",
            template="""Building with AI in 2024:

❌ 50 tools, zero integration
❌ Hours of manual work
❌ Context switching hell

SIMP stack:

✅ One platform, all agents
✅ Everything connected
✅ Autonomous operation

Stop managing tools. Start building empires.

{url}""",
            char_limit=280,
            hashtag_suggestions=["#BuildInPublic", "#StartupLife", "#AI", "#Tooling"],
            best_for=["comparison", "switches"],
            engagement_tips="Contrast creates engagement"
        ),
        
        PromoTemplate(
            template_id="tweet_stats",
            name="Social Proof - Stats",
            platform=Platform.TWITTER,
            content_type="tweet",
            template="""SIMP by the numbers 📊

🏗️ {active_users}+ builders
⚡ {deployments}+ deployments
🤖 {agents}+ autonomous agents
⏱️ {hours_saved}+ hours saved

Built by builders, for builders.

{url}""",
            char_limit=280,
            hashtag_suggestions=["#BuildInPublic", "#Startup", "#DevTools"],
            best_for=["social_proof", "trust"],
            engagement_tips="Use specific numbers for credibility"
        ),
        
        PromoTemplate(
            template_id="tweet_cta_soft",
            name="Soft CTA",
            platform=Platform.TWITTER,
            content_type="tweet",
            template="""Curious what autonomous agents could do for your projects?

We've been building in stealth for 6 months.

Today we're ready to share.

{url}

First 1000 builders get free tier forever.""",
            char_limit=280,
            hashtag_suggestions=["#AI", "#Launch", "#Startup"],
            best_for=["launch", "acquisition"],
            engagement_tips="Create urgency with limited offer"
        ),
    ]
    
    # YouTube Templates
    YOUTUBE_TEMPLATES = [
        PromoTemplate(
            template_id="yt_short_intro",
            name="What is SIMP (60s)",
            platform=Platform.YOUTUBE,
            content_type="short",
            template="""HOOK (0-5s):
Stop managing tools. Start building empires.

CONTEXT (5-15s):
Every developer I know is juggling 50+ tools. It's chaos.

SOLUTION (15-50s):
SIMP is the operating system for AI agents.
- Deploy agents in minutes
- They handle the boring stuff  
- You focus on what matters

CTA (50-60s):
Link in bio to get started. First 1000 free.""",
            char_limit=None,
            hashtag_suggestions=["#SIMP", "#AIAgents", "#DevTools", "#Automation"],
            media_type="video",
            best_for=["awareness", "education"],
            engagement_tips="Hook in first 3 seconds for Shorts"
        ),
        
        PromoTemplate(
            template_id="yt_tutorial",
            name="How to Deploy Your First Agent (10min)",
            platform=Platform.YOUTUBE,
            content_type="long_form",
            template="""VIDEO STRUCTURE:

0:00 - What we'll build
0:30 - Why SIMP changes everything
2:00 - Account setup
3:00 - Deploying your first agent
5:00 - Connecting to your tools
7:00 - Watching it work
8:00 - What you can automate next
9:00 - Resources and next steps
9:30 - Subscribe for more""",
            char_limit=None,
            hashtag_suggestions=["#Tutorial", "#SIMP", "#AIAgents", "#HowTo", "#DevOps"],
            media_type="video",
            best_for=["education", "onboarding", "seo"],
            engagement_tips="Timestamps improve watch time and SEO"
        ),
        
        PromoTemplate(
            template_id="yt_demo",
            name="SIMP in Action (Demo)",
            platform=Platform.YOUTUBE,
            content_type="demo",
            template="""DEMO SCRIPT:

OPENING:
"Watch this agent handle a week's worth of work in 3 minutes."

DEMONSTRATION:
- Show agent receiving task
- Show agent researching
- Show agent executing
- Show results delivered

CLOSING:
"That's not the future. That's SIMP. Available today."

CTA: Subscribe and link in bio.""",
            char_limit=None,
            hashtag_suggestions=["#Demo", "#SIMP", "#AI", "#Automation"],
            media_type="video",
            best_for=["demo", "conversion"],
            engagement_tips="Let the product speak for itself"
        ),
    ]
    
    # TikTok Templates
    TIKTOK_TEMPLATES = [
        PromoTemplate(
            template_id="tiktok_hook",
            name="POV: Using SIMP",
            platform=Platform.TIKTOK,
            content_type="short_video",
            template="""POV: You deployed an agent before lunch 🍕

*shows simple dashboard*
*agent working*
*results coming in*

"This exists RIGHT NOW and it's free"

#SIMP #AIAgents #Tech #Automation #BuildInPublic #Coding""",
            char_limit=150,
            hashtag_suggestions=["#SIMP", "#AIAgents", "#TechTok", "#Automation", "#AI"],
            media_type="video",
            best_for=["viral", "awareness"],
            engagement_tips="POV format works great on TikTok"
        ),
        
        PromoTemplate(
            template_id="tiktok_comparison",
            name="Day in the Life",
            platform=Platform.TIKTOK,
            content_type="day_in_life",
            template="""BEFORE (screen recording struggling):
- 47 browser tabs
- Copy paste all day
- Context switching
- Nothing gets done

AFTER (SIMP dashboard):
- Agents working
- Tasks automated
- Building actual stuff
- Leaving on time 🕔

#SIMP #Productivity #TechLife #AI #Automation""",
            char_limit=150,
            hashtag_suggestions=["#SIMP", "#ProductivityHacks", "#AIAgents", "#Tech"],
            media_type="video",
            best_for=["comparison", "relatability"],
            engagement_tips="Show the contrast dramatically"
        ),
        
        PromoTemplate(
            template_id="tiktok_tutorial",
            name="Deploy in 60 Seconds",
            platform=Platform.TIKTOK,
            content_type="quick_tutorial",
            template="""HOW TO DEPLOY AN AGENT IN 60 SECONDS ⏱️

1️⃣ Go to [URL]
2️⃣ Click "New Agent"  
3️⃣ Pick what you want automated
4️⃣ Connect your tools
5️⃣ Hit deploy

That's it. Your agent is working.

SAVE this for later!

#Tutorial #SIMP #AIAgents #TechTips #Coding""",
            char_limit=150,
            hashtag_suggestions=["#Tutorial", "#TechTips", "#SIMP", "#HowTo"],
            media_type="video",
            best_for=["education", "onboarding"],
            engagement_tips="Numbered steps perform well"
        ),
    ]
    
    # LinkedIn Templates
    LINKEDIN_TEMPLATES = [
        PromoTemplate(
            template_id="linkedin_thought_leadership",
            name="Thought Leadership",
            platform=Platform.LINKEDIN,
            content_type="article",
            template="""The biggest mistake I see developers making in 2024?

Trying to do everything themselves.

Here's the truth:
- You can't outwork AI agents
- You can't out-remember automation
- You can't out-focus a system that never gets tired

The developers winning aren't the ones coding 16 hours a day.

They're the ones who figured out how to delegate to autonomous agents.

SIMP is the platform I've been building to make this possible for everyone.

Link in comments if you want early access.""",
            char_limit=3000,
            hashtag_suggestions=["#AI", "#Leadership", "#Developers", "#Automation", "#Tech"],
            media_type="text",
            best_for=["thought_leadership", "brand"],
            engagement_tips="Share a perspective, not just features"
        ),
        
        PromoTemplate(
            template_id="linkedin_launch",
            name="Product Launch",
            platform=Platform.LINKEDIN,
            content_type="announcement",
            template="""🚀 We're LIVE!

Today we're launching SIMP - the operating system for autonomous AI agents.

What if every repetitive task in your workflow could be handled by an agent that:
• Works 24/7
• Never forgets
• Scales instantly
• Gets smarter over time

We've been building this in stealth for 6 months with a small team of developers.

Today, we open it up.

First 1000 builders get free tier forever.

Link in comments 👇

#Launch #AI #Startup #Developers #Innovation""",
            char_limit=3000,
            hashtag_suggestions=["#Startup", "#AI", "#Launch", "#Innovation", "#Developers"],
            media_type="text",
            best_for=["launch", "awareness"],
            engagement_tips="Share the journey, not just the product"
        ),
    ]


def get_promo_templates(
    platform: Optional[Platform] = None,
    content_type: Optional[str] = None
) -> List[PromoTemplate]:
    """
    Get promotional templates by platform and content type.
    
    Args:
        platform: Filter by platform (twitter, youtube, tiktok, linkedin)
        content_type: Filter by content type (tweet, short, article, etc.)
        
    Returns:
        List of matching templates
    """
    all_templates = []
    
    all_templates.extend(PromoTemplates.TWITTER_TEMPLATES)
    all_templates.extend(PromoTemplates.YOUTUBE_TEMPLATES)
    all_templates.extend(PromoTemplates.TIKTOK_TEMPLATES)
    all_templates.extend(PromoTemplates.LINKEDIN_TEMPLATES)
    
    if platform:
        all_templates = [t for t in all_templates if t.platform == platform]
    
    if content_type:
        all_templates = [t for t in all_templates if t.content_type == content_type]
    
    return all_templates


def get_template_by_id(template_id: str) -> Optional[PromoTemplate]:
    """Get a specific template by ID."""
    all_templates = get_promo_templates()
    for template in all_templates:
        if template.template_id == template_id:
            return template
    return None


def render_template(template: PromoTemplate, **kwargs) -> str:
    """
    Render a template with provided values.
    
    Args:
        template: PromoTemplate to render
        **kwargs: Values to fill in (url, handle, stats, etc.)
        
    Returns:
        Rendered template string
    """
    result = template.template
    
    # Common placeholders
    replacements = {
        "{url}": kwargs.get("url", "https://github.com/your-org/simp"),
        "{handle}": kwargs.get("handle", "@your_handle"),
        "{active_users}": kwargs.get("active_users", "10,000"),
        "{deployments}": kwargs.get("deployments", "50,000"),
        "{agents}": kwargs.get("agents", "100,000"),
        "{hours_saved}": kwargs.get("hours_saved", "1,000,000"),
    }
    
    for placeholder, value in replacements.items():
        result = result.replace(placeholder, value)
    
    return result
