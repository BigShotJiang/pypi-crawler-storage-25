"""
SIMP Self-Promotion Engine.

Generates SIMP commercials, promotional content, and voiceover scripts
to spread awareness of the SIMP platform and grow the ecosystem.
"""
from .commercial_generator import (
    SIMPCommercialGenerator,
    CommercialStyle,
    CommercialType,
    generate_simp_commercial,
)
from .voiceover_engine import (
    VoiceoverEngine,
    VoiceStyle,
    generate_voiceover,
)
from .promo_templates import (
    PromoTemplate,
    get_promo_templates,
)

__all__ = [
    "SIMPCommercialGenerator",
    "CommercialStyle",
    "CommercialType", 
    "generate_simp_commercial",
    "VoiceoverEngine",
    "VoiceStyle",
    "generate_voiceover",
    "PromoTemplate",
    "get_promo_templates",
]
