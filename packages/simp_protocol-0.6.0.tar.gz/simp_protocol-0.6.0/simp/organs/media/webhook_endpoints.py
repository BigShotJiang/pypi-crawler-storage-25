"""
Webhook endpoints for workflow triggers.

Provides HTTP endpoints for triggering workflows via webhooks,
simulating the n8n integration with SIMP broker.
"""
from typing import Dict, Any, Optional
from enum import Enum


class WorkflowTriggerType(Enum):
    """Workflow trigger types available via webhook."""
    NEW_CHANNEL_LAUNCH = "new_channel_launch"
    DAILY_CONTENT_PRODUCTION = "daily_content_production"
    TREND_INGESTION = "trend_ingestion"
    ANALYTICS_FEEDBACK = "analytics_feedback"
    CHANNEL_CLONING = "channel_cloning"
    COMPLIANCE_CHECK = "compliance_check"


class WorkflowWebhookHandler:
    """
    Handler for workflow webhook triggers.
    
    Simulates n8n webhook integration with SIMP broker.
    """
    
    def __init__(self, orchestrator=None, workflow_engine=None):
        self.orchestrator = orchestrator
        self.workflow_engine = workflow_engine
    
    async def handle_webhook(
        self,
        trigger_type: WorkflowTriggerType,
        payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Handle incoming webhook for workflow trigger.
        
        Args:
            trigger_type: Type of workflow to trigger
            payload: Webhook payload data
            
        Returns:
            Response with workflow execution details
        """
        if not self.orchestrator:
            return {"status": "error", "message": "Orchestrator not initialized"}
        
        workflow_id = None
        
        try:
            if trigger_type == WorkflowTriggerType.NEW_CHANNEL_LAUNCH:
                workflow_id = await self.orchestrator.execute_new_channel_launch_workflow(
                    niche=payload.get("niche", ""),
                    brand_options=payload.get("brand_options")
                )
                
            elif trigger_type == WorkflowTriggerType.DAILY_CONTENT_PRODUCTION:
                result = await self.orchestrator.execute_daily_content_production_workflow(
                    channel_ids=payload.get("channel_ids")
                )
                workflow_id = result.get("workflow_id")
                
            elif trigger_type == WorkflowTriggerType.TREND_INGESTION:
                result = await self.orchestrator.execute_trend_ingestion_workflow(
                    platforms=payload.get("platforms"),
                    score_threshold=payload.get("score_threshold", 0.7)
                )
                workflow_id = result.get("workflow_id")
                
            elif trigger_type == WorkflowTriggerType.ANALYTICS_FEEDBACK:
                result = await self.orchestrator.execute_analytics_feedback_workflow(
                    period=payload.get("period", "24h"),
                    weekly=payload.get("weekly", False)
                )
                workflow_id = result.get("workflow_id")
                
            elif trigger_type == WorkflowTriggerType.CHANNEL_CLONING:
                result = await self.orchestrator.execute_channel_cloning_workflow(
                    source_channel_id=payload.get("source_channel_id"),
                    target_type=payload.get("target_type"),
                    target_value=payload.get("target_value")
                )
                workflow_id = result.get("workflow_id")
                
            elif trigger_type == WorkflowTriggerType.COMPLIANCE_CHECK:
                result = await self.orchestrator.execute_compliance_monitor_workflow(
                    content=payload.get("content"),
                    pre_publish=payload.get("pre_publish", True)
                )
                workflow_id = result.get("workflow_id")
            
            return {
                "status": "triggered",
                "workflow_id": workflow_id,
                "trigger_type": trigger_type.value,
                "payload_received": payload
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "trigger_type": trigger_type.value
            }
    
    def get_webhook_routes(self) -> Dict[str, Dict[str, Any]]:
        """Get all available webhook routes."""
        return {
            "/webhooks/launch-channel": {
                "method": "POST",
                "trigger": WorkflowTriggerType.NEW_CHANNEL_LAUNCH,
                "description": "Trigger new channel launch workflow",
                "required_fields": ["niche"]
            },
            "/webhooks/daily-content": {
                "method": "POST",
                "trigger": WorkflowTriggerType.DAILY_CONTENT_PRODUCTION,
                "description": "Trigger daily content production",
                "required_fields": []
            },
            "/webhooks/trend-ingestion": {
                "method": "POST",
                "trigger": WorkflowTriggerType.TREND_INGESTION,
                "description": "Trigger trend monitoring and reactivity",
                "required_fields": []
            },
            "/webhooks/analytics-feedback": {
                "method": "POST",
                "trigger": WorkflowTriggerType.ANALYTICS_FEEDBACK,
                "description": "Trigger analytics feedback loop",
                "required_fields": []
            },
            "/webhooks/clone-channel": {
                "method": "POST",
                "trigger": WorkflowTriggerType.CHANNEL_CLONING,
                "description": "Trigger channel cloning workflow",
                "required_fields": ["source_channel_id", "target_type", "target_value"]
            },
            "/webhooks/pre-publish-compliance": {
                "method": "POST",
                "trigger": WorkflowTriggerType.COMPLIANCE_CHECK,
                "description": "Pre-publish compliance check",
                "required_fields": ["content"]
            }
        }


# Convenience function to create webhook handler
def create_webhook_handler(
    orchestrator=None,
    workflow_engine=None
) -> WorkflowWebhookHandler:
    """Create a webhook handler instance."""
    return WorkflowWebhookHandler(orchestrator, workflow_engine)
