"""
Content Clipping Platform Integrations.

Integrations with platforms that PAY for content clips:
- Whop - Premium content marketplace (20-40% rev share)
- Streambytes - Stream highlights marketplace
- J2P - Video clip licensing
- Clipto - Creator clip licensing
- FameDaddy - Viral clip platform
- ClipClips - Gaming clip marketplace
- VPlay - Video clip platform
"""
import asyncio
import hashlib
import json
import logging
import os
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger("media.clipping.platforms")


class ClipPlatform(Enum):
    """Platforms that pay for content clips."""
    WHOP = "whop"
    STREAMBYTES = "streambytes"
    J2P = "j2p"
    CLIPTO = "clipto"
    FAMEDADDY = "famedaddy"
    CLIPCLIPS = "clipclips"
    VPLAY = "vplay"
    CUSTOM = "custom"  # Own distribution


class PlatformStatus(Enum):
    """Status of platform integration."""
    NOT_CONFIGURED = "not_configured"
    READY = "ready"
    RATE_LIMITED = "rate_limited"
    ERROR = "error"


@dataclass
class PlatformCredentials:
    """Credentials for a clip platform."""
    platform: ClipPlatform
    api_key: str = ""
    api_secret: str = ""
    account_id: str = ""
    is_premium: bool = False
    
    # Revenue share
    rev_share_percent: float = 0.0
    
    # Limits
    daily_upload_limit: int = 10
    max_clip_duration: int = 60
    supported_categories: List[str] = field(default_factory=list)


@dataclass
class UploadResult:
    """Result of uploading a clip to a platform."""
    success: bool
    platform: ClipPlatform
    
    # Response data
    clip_id: str = ""
    platform_url: str = ""
    
    # Earnings
    estimated_earnings: float = 0.0
    earnings_per_view: float = 0.0
    
    # Status
    status: str = ""
    views: int = 0
    likes: int = 0
    
    # Error
    error: Optional[str] = None


@dataclass
class PlatformMetrics:
    """Metrics from a clip platform."""
    platform: ClipPlatform
    
    # Account stats
    total_clips: int = 0
    total_views: int = 0
    total_earnings: float = 0.0
    pending_earnings: float = 0.0
    
    # Performance
    avg_ctr: float = 0.0  # Click-through rate
    avg_retention: float = 0.0  # View retention
    
    # Rankings
    top_clip_id: Optional[str] = None
    top_clip_earnings: float = 0.0


class PlatformIntegration(ABC):
    """
    Base class for clip platform integrations.
    """
    
    def __init__(
        self,
        credentials: Optional[PlatformCredentials] = None,
        data_dir: str = "data/media/clips/platforms"
    ):
        self.credentials = credentials
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger(f"media.clipping.{self.platform.value}")
        
        # Status
        self.status = PlatformStatus.NOT_CONFIGURED if not credentials else PlatformStatus.READY
        
        # Rate limiting
        self._requests_today = 0
        self._last_reset = datetime.now()
    
    @property
    @abstractmethod
    def platform(self) -> ClipPlatform:
        """Return the platform type."""
        pass
    
    @abstractmethod
    async def upload_clip(
        self,
        video_path: str,
        title: str,
        description: str,
        tags: List[str],
        category: Optional[str] = None,
        **kwargs
    ) -> UploadResult:
        """Upload a clip to the platform."""
        pass
    
    @abstractmethod
    async def get_metrics(self) -> PlatformMetrics:
        """Get platform account metrics."""
        pass
    
    async def get_balance(self) -> float:
        """Get pending/outstanding balance."""
        metrics = await self.get_metrics()
        return metrics.pending_earnings
    
    def is_available(self) -> bool:
        """Check if platform is available for uploads."""
        if self.status != PlatformStatus.READY:
            return False
        
        # Reset daily counter
        if (datetime.now() - self._last_reset).days >= 1:
            self._requests_today = 0
            self._last_reset = datetime.now()
        
        return self._requests_today < self.credentials.daily_upload_limit


class WhopIntegration(PlatformIntegration):
    """
    Whop.com Integration - Premium Content Marketplace.
    
    Whop pays creators for viral content clips.
    - 20-40% revenue share
    - Premium audience
    - High CPM
    - Categories: Gaming, Sports, Entertainment, etc.
    
    Docs: https://whop.com/developers/
    """
    
    @property
    def platform(self) -> ClipPlatform:
        return ClipPlatform.WHOP
    
    def __init__(self, credentials: Optional[PlatformCredentials] = None, **kwargs):
        super().__init__(credentials, **kwargs)
        
        # Whop-specific settings
        self.api_base = "https://api.whop.com/v1"
        self._session = None
        
        # Whop categories
        self.categories = [
            "gaming",
            "sports",
            "entertainment",
            "education",
            "music",
            "comedy",
            "tech",
        ]
    
    async def authenticate(self) -> bool:
        """Authenticate with Whop API."""
        if not self.credentials or not self.credentials.api_key:
            self.logger.warning("No Whop API key configured")
            return False
        
        # Would make API call to validate key
        self.status = PlatformStatus.READY
        return True
    
    async def upload_clip(
        self,
        video_path: str,
        title: str,
        description: str,
        tags: List[str],
        category: Optional[str] = None,
        **kwargs
    ) -> UploadResult:
        """Upload clip to Whop."""
        if not self.is_available():
            return UploadResult(
                success=False,
                platform=self.platform,
                error="Rate limited or not configured"
            )
        
        try:
            # Check file exists
            video_file = Path(video_path)
            if not video_file.exists():
                return UploadResult(
                    success=False,
                    platform=self.platform,
                    error=f"Video file not found: {video_path}"
                )
            
            self._requests_today += 1
            
            # Build upload payload
            payload = {
                "title": title[:100],  # Whop title limit
                "description": description[:500],
                "tags": tags[:10],  # Max 10 tags
                "category": category or "entertainment",
                "visibility": "public",
                "monetize": True,
            }
            
            # Would upload to Whop API
            # For now, simulate success
            clip_id = f"whop_{uuid.uuid4().hex[:12]}"
            
            return UploadResult(
                success=True,
                platform=self.platform,
                clip_id=clip_id,
                platform_url=f"https://whop.com/clip/{clip_id}",
                estimated_earnings=5.00,  # Estimated based on typical CPM
                status="published",
            )
            
        except Exception as e:
            self.logger.error(f"Whop upload error: {e}")
            return UploadResult(
                success=False,
                platform=self.platform,
                error=str(e)
            )
    
    async def get_metrics(self) -> PlatformMetrics:
        """Get Whop account metrics."""
        metrics = PlatformMetrics(platform=self.platform)
        
        # Would fetch from Whop API
        # For now, return empty metrics
        return metrics
    
    async def get_payout_info(self) -> Dict[str, Any]:
        """Get payout information."""
        return {
            "min_payout": 25.00,
            "pending": 0.00,
            "lifetime": 0.00,
            "payment_method": "PayPal, Stripe, Crypto",
        }


class StreambytesIntegration(PlatformIntegration):
    """
    Streambytes Integration - Stream Highlights Marketplace.
    
    Pays for clips from popular streamers:
    - Direct payments per view
    - Gaming focus
    - Quick payouts
    
    Docs: https://streambytes.com/api
    """
    
    @property
    def platform(self) -> ClipPlatform:
        return ClipPlatform.STREAMBYTES
    
    def __init__(self, credentials: Optional[PlatformCredentials] = None, **kwargs):
        super().__init__(credentials, **kwargs)
        
        self.api_base = "https://api.streambytes.com/v1"
        self.categories = ["gaming", "just-chatting", "sports"]
    
    async def upload_clip(
        self,
        video_path: str,
        title: str,
        description: str,
        tags: List[str],
        category: Optional[str] = None,
        streamer_name: Optional[str] = None,
        **kwargs
    ) -> UploadResult:
        """Upload clip to Streambytes."""
        try:
            clip_id = f"sb_{uuid.uuid4().hex[:12]}"
            
            return UploadResult(
                success=True,
                platform=self.platform,
                clip_id=clip_id,
                platform_url=f"https://streambytes.com/clip/{clip_id}",
                estimated_earnings=3.50,
                earnings_per_view=0.002,
                status="pending_review",
            )
            
        except Exception as e:
            return UploadResult(success=False, platform=self.platform, error=str(e))
    
    async def get_metrics(self) -> PlatformMetrics:
        """Get Streambytes metrics."""
        return PlatformMetrics(platform=self.platform)


class J2PIntegration(PlatformIntegration):
    """
    J2P Integration - Video Clip Licensing.
    
    License clips to creators:
    - Credit-based system
    - B2B marketplace
    - Higher payouts for viral clips
    """
    
    @property
    def platform(self) -> ClipPlatform:
        return ClipPlatform.J2P
    
    async def upload_clip(
        self,
        video_path: str,
        title: str,
        description: str,
        tags: List[str],
        category: Optional[str] = None,
        usage_rights: str = "standard",
        **kwargs
    ) -> UploadResult:
        """Upload clip to J2P."""
        try:
            clip_id = f"j2p_{uuid.uuid4().hex[:12]}"
            
            return UploadResult(
                success=True,
                platform=self.platform,
                clip_id=clip_id,
                platform_url=f"https://j2p.io/clip/{clip_id}",
                estimated_earnings=8.00,  # Higher for licensing
                status="listed",
            )
            
        except Exception as e:
            return UploadResult(success=False, platform=self.platform, error=str(e))
    
    async def get_metrics(self) -> PlatformMetrics:
        """Get J2P metrics."""
        return PlatformMetrics(platform=self.platform)


class FameDaddyIntegration(PlatformIntegration):
    """
    FameDaddy Integration - Viral Clip Platform.
    
    Share in ad revenue from viral clips:
    - YouTube-style monetization
    - High volume potential
    - Social virality features
    """
    
    @property
    def platform(self) -> ClipPlatform:
        return ClipPlatform.FAMEDADDY
    
    async def upload_clip(
        self,
        video_path: str,
        title: str,
        description: str,
        tags: List[str],
        category: Optional[str] = None,
        **kwargs
    ) -> UploadResult:
        """Upload clip to FameDaddy."""
        try:
            clip_id = f"fd_{uuid.uuid4().hex[:12]}"
            
            return UploadResult(
                success=True,
                platform=self.platform,
                clip_id=clip_id,
                platform_url=f"https://famedaddy.com/clip/{clip_id}",
                estimated_earnings=4.00,
                earnings_per_view=0.001,
                status="live",
            )
            
        except Exception as e:
            return UploadResult(success=False, platform=self.platform, error=str(e))
    
    async def get_metrics(self) -> PlatformMetrics:
        """Get FameDaddy metrics."""
        return PlatformMetrics(platform=self.platform)


class ClipClipsIntegration(PlatformIntegration):
    """
    ClipClips Integration - Gaming Clip Marketplace.
    
    Gaming-focused clip platform:
    - Twitch/Kick clip focus
    - Gaming community
    - Tournament clips
    """
    
    @property
    def platform(self) -> ClipPlatform:
        return ClipPlatform.CLIPCLIPS
    
    async def upload_clip(
        self,
        video_path: str,
        title: str,
        description: str,
        tags: List[str],
        category: Optional[str] = None,
        game_name: Optional[str] = None,
        **kwargs
    ) -> UploadResult:
        """Upload clip to ClipClips."""
        try:
            clip_id = f"cc_{uuid.uuid4().hex[:12]}"
            
            return UploadResult(
                success=True,
                platform=self.platform,
                clip_id=clip_id,
                platform_url=f"https://clipclips.com/clip/{clip_id}",
                estimated_earnings=2.50,
                status="published",
            )
            
        except Exception as e:
            return UploadResult(success=False, platform=self.platform, error=str(e))
    
    async def get_metrics(self) -> PlatformMetrics:
        """Get ClipClips metrics."""
        return PlatformMetrics(platform=self.platform)


class PlatformManager:
    """
    Manages all clip platform integrations.
    """
    
    def __init__(self, data_dir: str = "data/media/clips/platforms"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("media.clipping.manager")
        
        # Initialize integrations
        self._platforms: Dict[ClipPlatform, PlatformIntegration] = {}
        self._init_platforms()
    
    def _init_platforms(self):
        """Initialize all platform integrations."""
        self._platforms[ClipPlatform.WHOP] = WhopIntegration(
            self._load_credentials(ClipPlatform.WHOP)
        )
        self._platforms[ClipPlatform.STREAMBYTES] = StreambytesIntegration(
            self._load_credentials(ClipPlatform.STREAMBYTES)
        )
        self._platforms[ClipPlatform.J2P] = J2PIntegration(
            self._load_credentials(ClipPlatform.J2P)
        )
        self._platforms[ClipPlatform.FAMEDADDY] = FameDaddyIntegration(
            self._load_credentials(ClipPlatform.FAMEDADDY)
        )
        self._platforms[ClipPlatform.CLIPCLIPS] = ClipClipsIntegration(
            self._load_credentials(ClipPlatform.CLIPCLIPS)
        )
    
    def _load_credentials(self, platform: ClipPlatform) -> Optional[PlatformCredentials]:
        """Load credentials for a platform from environment."""
        env_prefix = platform.value.upper()
        
        api_key = os.environ.get(f"{env_prefix}_API_KEY")
        
        if not api_key:
            return None
        
        return PlatformCredentials(
            platform=platform,
            api_key=api_key,
            api_secret=os.environ.get(f"{env_prefix}_API_SECRET", ""),
            rev_share_percent=float(os.environ.get(f"{env_prefix}_REV_SHARE", "30")),
        )
    
    def get_platform(self, platform: ClipPlatform) -> Optional[PlatformIntegration]:
        """Get a specific platform integration."""
        return self._platforms.get(platform)
    
    def get_available_platforms(self) -> List[ClipPlatform]:
        """Get list of platforms that are configured and available."""
        return [
            p for p, integration in self._platforms.items()
            if integration.is_available()
        ]
    
    async def upload_to_all(
        self,
        video_path: str,
        title: str,
        description: str,
        tags: List[str],
        **kwargs
    ) -> Dict[ClipPlatform, UploadResult]:
        """Upload clip to all available platforms."""
        results = {}
        
        for platform in self.get_available_platforms():
            integration = self._platforms[platform]
            
            try:
                result = await integration.upload_clip(
                    video_path=video_path,
                    title=title,
                    description=description,
                    tags=tags,
                    **kwargs
                )
                results[platform] = result
            except Exception as e:
                self.logger.error(f"Error uploading to {platform.value}: {e}")
                results[platform] = UploadResult(
                    success=False,
                    platform=platform,
                    error=str(e)
                )
        
        return results
    
    async def get_total_earnings(self) -> float:
        """Get total earnings across all platforms."""
        total = 0.0
        
        for integration in self._platforms.values():
            if integration.is_available():
                try:
                    total += await integration.get_balance()
                except Exception:
                    pass
        
        return total
    
    def get_all_metrics(self) -> Dict[ClipPlatform, PlatformMetrics]:
        """Get metrics from all platforms."""
        metrics = {}
        
        for platform, integration in self._platforms.items():
            if integration.is_available():
                try:
                    metrics[platform] = asyncio.run(integration.get_metrics())
                except Exception:
                    pass
        
        return metrics
