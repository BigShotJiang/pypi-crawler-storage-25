"""
Content Clipping Engine for Media Empire.

Automated discovery, clipping, and distribution of trending content.
Earn revenue by clipping popular creators and distributing via paying platforms.

Key Features:
- Multi-platform trending content discovery
- AI-powered clip extraction (highlights, virals)
- Platform integrations (Whop, Streambytes, etc.)
- Automated publishing pipeline
- Revenue tracking

Platforms That PAY for Clips:
- Whop - Premium content marketplace
- Streambytes - Stream highlights marketplace  
- J2P - Video clip marketplace
- Clipto - Creator clip licensing
- FameDaddy - Viral clip platform
- Fiverr - Custom clip services
"""
from .clipping_engine import (
    ContentClippingEngine,
    ClipResult,
    ContentSource,
    ClipType,
    create_clipping_engine,
)
from .platform_integrations import (
    ClipPlatform,
    PlatformIntegration,
    WhopIntegration,
    StreambytesIntegration,
)
from .trending_discovery import (
    TrendingDiscovery,
    TrendingContent,
    TrendReport,
    create_trending_discovery,
)

__all__ = [
    "ContentClippingEngine",
    "ClipResult",
    "ContentSource",
    "ClipType",
    "create_clipping_engine",
    "ClipPlatform",
    "PlatformIntegration",
    "WhopIntegration",
    "StreambytesIntegration",
    "TrendingDiscovery",
    "TrendingContent",
    "TrendReport",
    "create_trending_discovery",
]
