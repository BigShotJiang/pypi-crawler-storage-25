"""
Autonomous Agent Wiring for Media Grid.

Wires together:
- Computer use tools (Playwright browser automation)
- OAuth manager (social account creation)
- Workflow engine (orchestrated flows)
- SIMP broker (agent communication)

Enables fully autonomous media empire operation.
"""
import asyncio
import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

from simp.organs.media.workflow_engine import WorkflowEngine, WorkflowTrigger, WorkflowStatus, create_workflow_engine
from simp.organs.media.computer_use_tools import ComputerUseToolkit, create_computer_use_toolkit
from simp.organs.media.platform_oauth_manager import PlatformOAuthManager, Platform, create_oauth_manager


class AgentMode(Enum):
    """Operating mode for autonomous agents."""
    AUTONOMOUS = "autonomous"  # Fully self-directed
    ASSISTED = "assisted"  # Human-in-the-loop for key decisions
    SUPERVISED = "supervised"  # Human approval required for actions
    PAUSED = "paused"  # No autonomous actions


@dataclass
class AgentCapability:
    """An agent's capabilities and current status."""
    capability_id: str
    name: str
    enabled: bool = True
    rate_limit_per_hour: int = 100
    cost_per_call: float = 0.0
    last_called: Optional[float] = None
    call_count: int = 0
    success_count: int = 0


@dataclass
class AutonomousAgent:
    """Autonomous agent configuration and state."""
    agent_id: str
    name: str
    mode: AgentMode = AgentMode.AUTONOMOUS
    
    # Capabilities
    capabilities: List[AgentCapability] = field(default_factory=list)
    
    # State
    is_active: bool = False
    last_activity: Optional[str] = None
    actions_today: int = 0
    
    # Constraints
    max_actions_per_day: int = 1000
    max_cost_per_day: float = 100.0
    budget_spent_today: float = 0.0
    
    # Approval requirements
    require_human_approval_for: List[str] = field(default_factory=list)


class AutonomousAgentController:
    """
    Controller for autonomous agent operations.
    
    Manages:
    - Agent modes and capabilities
    - Budget and rate limiting
    - Human-in-the-loop approvals
    - Tool execution and orchestration
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/autonomous",
        workflow_engine: Optional[WorkflowEngine] = None,
        computer_use: Optional[ComputerUseToolkit] = None,
        oauth_manager: Optional[PlatformOAuthManager] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("media.autonomous_controller")
        
        # Core components
        self.workflow_engine = workflow_engine or create_workflow_engine(str(self.data_dir))
        self.computer_use = computer_use or create_computer_use_toolkit(str(self.data_dir))
        self.oauth_manager = oauth_manager or create_oauth_manager(str(self.data_dir))
        
        # Agents
        self._agents: Dict[str, AutonomousAgent] = {}
        self._load_agents()
        
        # Tool registry
        self._tool_handlers: Dict[str, Callable] = {}
        self._register_default_tools()
        
        # Human approval queue
        self._approval_queue: List[Dict] = []
        
        # Metrics
        self._metrics = {
            "total_actions": 0,
            "successful_actions": 0,
            "failed_actions": 0,
            "approvals_requested": 0,
            "approvals_granted": 0
        }
    
    def _load_agents(self) -> None:
        """Load agent configurations."""
        agents_file = self.data_dir / "agents.json"
        if agents_file.exists():
            try:
                with open(agents_file, 'r') as f:
                    agents_data = json.load(f)
                    for agent_data in agents_data.get("agents", []):
                        agent = AutonomousAgent(**agent_data)
                        self._agents[agent.agent_id] = agent
                self.logger.info(f"Loaded {len(self._agents)} agent configurations")
            except Exception as e:
                self.logger.error(f"Failed to load agents: {e}")
    
    def _save_agents(self) -> None:
        """Save agent configurations."""
        agents_file = self.data_dir / "agents.json"
        try:
            agents_data = {"agents": [vars(a) for a in self._agents.values()]}
            with open(agents_file, 'w') as f:
                json.dump(agents_data, f, indent=2, default=str)
        except Exception as e:
            self.logger.error(f"Failed to save agents: {e}")
    
    def _register_default_tools(self) -> None:
        """Register default tool handlers."""
        self._tool_handlers = {
            "browser.open": self._handle_browser_open,
            "browser.click": self._handle_browser_click,
            "browser.type": self._handle_browser_type,
            "browser.screenshot": self._handle_browser_screenshot,
            "browser.snapshot": self._handle_browser_snapshot,
            "oauth.authorize": self._handle_oauth_authorize,
            "account.create": self._handle_account_create,
            "workflow.trigger": self._handle_workflow_trigger,
            "shell.execute": self._handle_shell_execute,
        }
    
    # =========================================================================
    # Agent Management
    # =========================================================================
    
    def register_agent(self, agent: AutonomousAgent) -> bool:
        """Register an autonomous agent."""
        self._agents[agent.agent_id] = agent
        self._save_agents()
        self.logger.info(f"Registered agent: {agent.name} ({agent.agent_id})")
        return True
    
    def get_agent(self, agent_id: str) -> Optional[AutonomousAgent]:
        """Get agent by ID."""
        return self._agents.get(agent_id)
    
    def set_agent_mode(self, agent_id: str, mode: AgentMode) -> bool:
        """Set agent operating mode."""
        agent = self._agents.get(agent_id)
        if agent:
            agent.mode = mode
            self._save_agents()
            self.logger.info(f"Agent {agent_id} mode set to {mode.value}")
            return True
        return False
    
    def check_agent_budget(self, agent_id: str) -> Dict[str, Any]:
        """Check if agent has budget remaining."""
        agent = self._agents.get(agent_id)
        if not agent:
            return {"allowed": False, "reason": "Agent not found"}
        
        if agent.mode == AgentMode.PAUSED:
            return {"allowed": False, "reason": "Agent paused"}
        
        if agent.mode == AgentMode.SUPERVISED:
            return {"allowed": False, "reason": "Agent requires supervision"}
        
        if agent.actions_today >= agent.max_actions_per_day:
            return {"allowed": False, "reason": "Daily action limit reached"}
        
        if agent.budget_spent_today >= agent.max_cost_per_day:
            return {"allowed": False, "reason": "Daily budget exhausted"}
        
        return {"allowed": True, "budget_remaining": agent.max_cost_per_day - agent.budget_spent_today}
    
    # =========================================================================
    # Tool Execution
    # =========================================================================
    
    async def execute_tool(
        self,
        agent_id: str,
        tool_name: str,
        params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Execute a tool on behalf of an agent.
        
        Args:
            agent_id: ID of the agent requesting the tool
            tool_name: Name of the tool to execute
            params: Tool parameters
            
        Returns:
            Tool execution result
        """
        # Check agent budget
        budget_check = self.check_agent_budget(agent_id)
        if not budget_check["allowed"]:
            return {"success": False, "error": budget_check["reason"]}
        
        # Check if tool requires approval
        tool_handler = self._tool_handlers.get(tool_name)
        if not tool_handler:
            return {"success": False, "error": f"Unknown tool: {tool_name}"}
        
        # Check for human approval requirement
        agent = self._agents.get(agent_id)
        if agent and tool_name in agent.require_human_approval_for:
            return await self._request_approval(agent_id, tool_name, params)
        
        # Execute tool
        self.logger.info(f"Agent {agent_id} executing tool: {tool_name}")
        
        try:
            result = await tool_handler(params)
            
            # Update metrics
            self._metrics["total_actions"] += 1
            if result.get("success"):
                self._metrics["successful_actions"] += 1
                if agent:
                    agent.success_count += 1
            else:
                self._metrics["failed_actions"] += 1
            
            if agent:
                agent.actions_today += 1
                agent.last_activity = datetime.utcnow().isoformat()
            
            return result
            
        except Exception as e:
            self.logger.error(f"Tool execution failed: {e}")
            return {"success": False, "error": str(e)}
    
    async def _handle_browser_open(self, params: Dict) -> Dict[str, Any]:
        """Handle browser.open tool."""
        url = params.get("url", "")
        session_id = params.get("session_id")
        
        result = await self.computer_use._browser_open(url, session_id)
        
        return {
            "success": result.success,
            "session_id": result.output.get("session_id") if result.output else None,
            "elements": len(result.elements) if result.elements else 0
        }
    
    async def _handle_browser_click(self, params: Dict) -> Dict[str, Any]:
        """Handle browser.click tool."""
        element_ref = params.get("element_ref", "")
        session_id = params.get("session_id", "")
        
        result = await self.computer_use._browser_click(element_ref, session_id)
        
        return {
            "success": result.success,
            "clicked": element_ref
        }
    
    async def _handle_browser_type(self, params: Dict) -> Dict[str, Any]:
        """Handle browser.type tool."""
        element_ref = params.get("element_ref", "")
        text = params.get("text", "")
        session_id = params.get("session_id", "")
        
        result = await self.computer_use._browser_type(element_ref, text, session_id)
        
        return {
            "success": result.success,
            "typed": text
        }
    
    async def _handle_browser_screenshot(self, params: Dict) -> Dict[str, Any]:
        """Handle browser.screenshot tool."""
        session_id = params.get("session_id", "")
        full_page = params.get("full_page", False)
        
        result = await self.computer_use._browser_screenshot(session_id, full_page)
        
        return {
            "success": result.success,
            "screenshot": result.screenshot[:100] + "..." if result.screenshot else None
        }
    
    async def _handle_browser_snapshot(self, params: Dict) -> Dict[str, Any]:
        """Handle browser.snapshot tool."""
        session_id = params.get("session_id", "")
        
        result = await self.computer_use._browser_snapshot(session_id)
        
        return {
            "success": result.success,
            "elements": result.elements
        }
    
    async def _handle_oauth_authorize(self, params: Dict) -> Dict[str, Any]:
        """Handle oauth.authorize tool."""
        platform_str = params.get("platform", "tiktok")
        platform = Platform(platform_str.lower())
        
        auth_url = self.oauth_manager.get_authorization_url(platform)
        
        return {
            "success": bool(auth_url),
            "authorization_url": auth_url,
            "platform": platform.value
        }
    
    async def _handle_account_create(self, params: Dict) -> Dict[str, Any]:
        """Handle account.create tool."""
        platform_str = params.get("platform", "tiktok")
        brand_name = params.get("brand_name", "")
        
        platform = Platform(platform_str.lower())
        
        result = await self.oauth_manager.create_account(
            platform=platform,
            brand_name=brand_name,
            use_browser_automation=params.get("use_browser_automation", True)
        )
        
        return {
            "success": result.success,
            "account_id": result.account_id,
            "username": result.username,
            "platform": platform.value
        }
    
    async def _handle_workflow_trigger(self, params: Dict) -> Dict[str, Any]:
        """Handle workflow.trigger tool."""
        workflow_type = params.get("workflow_type", "")
        trigger_str = params.get("trigger", "intent")
        
        trigger = WorkflowTrigger(trigger_str.lower())
        
        workflow_id = await self.workflow_engine.trigger_workflow(
            workflow_type=workflow_type,
            trigger=trigger,
            params=params
        )
        
        return {
            "success": bool(workflow_id),
            "workflow_id": workflow_id
        }
    
    async def _handle_shell_execute(self, params: Dict) -> Dict[str, Any]:
        """Handle shell.execute tool."""
        command = params.get("command", "")
        
        result = await self.computer_use._shell_command(command)
        
        return {
            "success": result.success,
            "output": result.output
        }
    
    # =========================================================================
    # Human-in-the-Loop
    # =========================================================================
    
    async def _request_approval(
        self,
        agent_id: str,
        tool_name: str,
        params: Dict
    ) -> Dict[str, Any]:
        """Request human approval for an action."""
        approval_request = {
            "request_id": f"apr_{int(time.time())}_{agent_id}",
            "agent_id": agent_id,
            "tool": tool_name,
            "params": params,
            "timestamp": datetime.utcnow().isoformat(),
            "status": "pending"
        }
        
        self._approval_queue.append(approval_request)
        self._metrics["approvals_requested"] += 1
        
        self.logger.info(f"Approval requested: {agent_id} -> {tool_name}")
        
        return {
            "success": False,
            "error": "Approval required",
            "approval_request_id": approval_request["request_id"],
            "status": "pending_approval"
        }
    
    async def approve_action(self, request_id: str) -> Dict[str, Any]:
        """Approve a pending action."""
        request = next((r for r in self._approval_queue if r["request_id"] == request_id), None)
        
        if not request:
            return {"success": False, "error": "Request not found"}
        
        request["status"] = "approved"
        request["approved_at"] = datetime.utcnow().isoformat()
        
        self._metrics["approvals_granted"] += 1
        
        # Execute the approved action
        tool_name = request["tool"]
        params = request["params"]
        agent_id = request["agent_id"]
        
        self.logger.info(f"Action approved: {request_id}")
        
        return await self.execute_tool(agent_id, tool_name, params)
    
    def get_pending_approvals(self) -> List[Dict]:
        """Get all pending approval requests."""
        return [r for r in self._approval_queue if r["status"] == "pending"]
    
    # =========================================================================
    # Full Channel Launch
    # =========================================================================
    
    async def launch_channel_autonomous(
        self,
        brand_name: str,
        platforms: List[str],
        auto_approve: bool = True
    ) -> Dict[str, Any]:
        """
        Launch a new channel across multiple platforms autonomously.
        
        Args:
            brand_name: Brand name for the channel
            platforms: List of platforms (tiktok, youtube, instagram, x)
            auto_approve: Automatically approve account creation
            
        Returns:
            Channel launch results
        """
        self.logger.info(f"Autonomous channel launch: {brand_name} on {platforms}")
        
        results = {
            "brand_name": brand_name,
            "platforms": {},
            "workflow_id": None,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Create accounts
        for platform_str in platforms:
            try:
                platform = Platform(platform_str.lower())
                
                # Execute account creation
                create_result = await self.oauth_manager.create_account(
                    platform=platform,
                    brand_name=brand_name,
                    use_browser_automation=True
                )
                
                results["platforms"][platform_str] = {
                    "success": create_result.success,
                    "account_id": create_result.account_id,
                    "username": create_result.username,
                    "session_id": create_result.session_id
                }
                
                # Continue with OAuth if needed
                if create_result.success:
                    auth_url = self.oauth_manager.get_authorization_url(platform)
                    results["platforms"][platform_str]["oauth_url"] = auth_url
                    
            except Exception as e:
                results["platforms"][platform_str] = {"success": False, "error": str(e)}
        
        # Trigger content workflow
        workflow_id = await self.workflow_engine.trigger_workflow(
            workflow_type="channel_launch",
            trigger=WorkflowTrigger.INTENT,
            params={"brand_name": brand_name, "accounts": results["platforms"]}
        )
        results["workflow_id"] = workflow_id
        
        return results
    
    # =========================================================================
    # Metrics and Health
    # =========================================================================
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get controller metrics."""
        return {
            **self._metrics,
            "active_agents": len([a for a in self._agents.values() if a.is_active]),
            "total_agents": len(self._agents),
            "pending_approvals": len(self.get_pending_approvals()),
            "approval_rate": self._metrics["approvals_granted"] / max(1, self._metrics["approvals_requested"]),
            "success_rate": self._metrics["successful_actions"] / max(1, self._metrics["total_actions"])
        }
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get system health status."""
        return {
            "status": "healthy",
            "components": {
                "workflow_engine": len(self.workflow_engine._workflow_definitions) > 0,
                "computer_use": self.computer_use._playwright is not None,
                "oauth_manager": len(self.oauth_manager._accounts) >= 0
            },
            "metrics": self.get_metrics()
        }


# Convenience function
def create_autonomous_controller(
    data_dir: str = "data/media/autonomous"
) -> AutonomousAgentController:
    """Create autonomous agent controller instance."""
    return AutonomousAgentController(data_dir=data_dir)
