"""
Cost Optimizer - ROI tracking and cost optimization for media empire.

Features:
- Per-channel ROI analysis
- Cost allocation
- Resource optimization recommendations
- Budget management
"""
import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging


class CostCategory(Enum):
    """Categories of costs."""
    CONTENT_GENERATION = "content_generation"
    API_CALLS = "api_calls"
    STORAGE = "storage"
    BANDWIDTH = "bandwidth"
    AD_SPEND = "ad_spend"
    HUMAN_TIME = "human_time"


@dataclass
class CostAllocation:
    """Cost allocation for a resource."""
    allocation_id: str
    category: CostCategory
    
    channel_id: Optional[str] = None
    campaign_id: Optional[str] = None
    
    amount: float = 0.0
    currency: str = "USD"
    
    description: str = ""
    
    date: datetime = field(default_factory=datetime.now)


@dataclass
class ROIAnalysis:
    """ROI analysis for a channel or campaign."""
    entity_id: str
    entity_type: str  # "channel" or "campaign"
    
    # Revenue
    revenue: float = 0.0
    
    # Costs
    total_cost: float = 0.0
    cost_by_category: Dict[str, float] = field(default_factory=dict)
    
    # Metrics
    roi: float = 0.0
    cpa: float = 0.0  # Cost per acquisition
    ltv: float = 0.0  # Lifetime value
    payback_period_days: float = 0.0
    
    # Period
    period_start: datetime = field(default_factory=datetime.now)
    period_end: datetime = field(default_factory=datetime.now)
    
    # Recommendations
    recommendations: List[str] = field(default_factory=list)


@dataclass
class Budget:
    """Budget allocation and tracking."""
    budget_id: str
    name: str
    
    # Allocation
    total_amount: float
    currency: str = "USD"
    
    # Spent
    spent: float = 0.0
    remaining: float = 0.0
    
    # Period
    period_start: datetime = field(default_factory=datetime.now)
    period_end: datetime = field(default_factory=datetime.now)
    
    # Allocations
    allocations: List[CostAllocation] = field(default_factory=list)
    
    # Alerts
    alert_threshold: float = 0.8  # Alert when 80% spent


class CostOptimizer:
    """
    Cost optimization for media empire.
    
    Tracks:
    - Per-channel costs and ROI
    - Resource allocation efficiency
    - Budget compliance
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/cost"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.cost_optimizer")
        
        # Cost tracking
        self._costs: List[CostAllocation] = []
        self._revenue: Dict[str, float] = {}  # channel_id -> revenue
        
        # Budgets
        self._budgets: Dict[str, Budget] = {}
        
        # Cost rates
        self._rates: Dict[CostCategory, float] = {
            CostCategory.CONTENT_GENERATION: 0.05,  # Per content piece
            CostCategory.API_CALLS: 0.001,           # Per API call
            CostCategory.STORAGE: 0.023,            # Per GB/month
            CostCategory.BANDWIDTH: 0.01,           # Per GB
        }
        
        self._load_state()
    
    def _load_state(self) -> None:
        """Load cost data from disk."""
        costs_file = self.data_dir / "costs.json"
        budgets_file = self.data_dir / "budgets.json"
        
        if costs_file.exists():
            with open(costs_file) as f:
                data = json.load(f)
                self._costs = [CostAllocation(**c) for c in data]
        
        if budgets_file.exists():
            with open(budgets_file) as f:
                data = json.load(f)
                self._budgets = {k: Budget(**v) for k, v in data.items()}
    
    def _save_state(self) -> None:
        """Save cost data to disk."""
        costs_file = self.data_dir / "costs.json"
        with open(costs_file, "w") as f:
            json.dump([vars(c) for c in self._costs], f, indent=2, default=str)
        
        budgets_file = self.data_dir / "budgets.json"
        with open(budgets_file, "w") as f:
            json.dump({k: vars(v) for k, v in self._budgets.items()}, f, indent=2, default=str)
    
    # =========================================================================
    # Cost Tracking
    # =========================================================================
    
    def track_cost(
        self,
        category: CostCategory,
        amount: float,
        description: str = "",
        channel_id: Optional[str] = None,
        campaign_id: Optional[str] = None
    ) -> CostAllocation:
        """Track a cost."""
        allocation = CostAllocation(
            allocation_id=f"cost_{len(self._costs)}",
            category=category,
            channel_id=channel_id,
            campaign_id=campaign_id,
            amount=amount,
            description=description
        )
        
        self._costs.append(allocation)
        self._save_state()
        
        return allocation
    
    def track_revenue(
        self,
        channel_id: str,
        amount: float
    ) -> None:
        """Track revenue for a channel."""
        self._revenue[channel_id] = self._revenue.get(channel_id, 0) + amount
        self._save_state()
    
    # =========================================================================
    # ROI Analysis
    # =========================================================================
    
    def analyze_channel_roi(
        self,
        channel_id: str,
        period_days: int = 30
    ) -> ROIAnalysis:
        """Analyze ROI for a channel."""
        period_end = datetime.now()
        period_start = period_end - timedelta(days=period_days)
        
        # Get costs for this channel
        costs = [
            c for c in self._costs
            if c.channel_id == channel_id
            and period_start <= c.date <= period_end
        ]
        
        total_cost = sum(c.amount for c in costs)
        
        # Group by category
        cost_by_category = {}
        for c in costs:
            cat = c.category.value
            cost_by_category[cat] = cost_by_category.get(cat, 0) + c.amount
        
        # Get revenue
        revenue = self._revenue.get(channel_id, 0)
        
        # Calculate ROI
        roi = (revenue - total_cost) / total_cost if total_cost > 0 else 0
        
        # Generate recommendations
        recommendations = []
        if roi < 0:
            recommendations.append("Channel is operating at a loss - review strategy")
        if roi < 0.5:
            recommendations.append("ROI below target - consider reducing costs")
        if total_cost > revenue * 2:
            recommendations.append("Costs significantly exceed revenue - urgent review needed")
        
        return ROIAnalysis(
            entity_id=channel_id,
            entity_type="channel",
            revenue=revenue,
            total_cost=total_cost,
            cost_by_category=cost_by_category,
            roi=roi,
            period_start=period_start,
            period_end=period_end,
            recommendations=recommendations
        )
    
    def analyze_campaign_roi(
        self,
        campaign_id: str,
        period_days: int = 30
    ) -> ROIAnalysis:
        """Analyze ROI for a campaign."""
        period_end = datetime.now()
        period_start = period_end - timedelta(days=period_days)
        
        costs = [
            c for c in self._costs
            if c.campaign_id == campaign_id
            and period_start <= c.date <= period_end
        ]
        
        total_cost = sum(c.amount for c in costs)
        revenue = 0  # Would aggregate from channels
        
        cost_by_category = {c.category.value: c.amount for c in costs}
        roi = (revenue - total_cost) / total_cost if total_cost > 0 else 0
        
        return ROIAnalysis(
            entity_id=campaign_id,
            entity_type="campaign",
            revenue=revenue,
            total_cost=total_cost,
            cost_by_category=cost_by_category,
            roi=roi,
            period_start=period_start,
            period_end=period_end
        )
    
    def get_empire_roi(self, period_days: int = 30) -> Dict[str, Any]:
        """Get overall empire ROI."""
        period_end = datetime.now()
        period_start = period_end - timedelta(days=period_days)
        
        costs = [
            c for c in self._costs
            if period_start <= c.date <= period_end
        ]
        
        total_cost = sum(c.amount for c in costs)
        total_revenue = sum(self._revenue.values())
        
        roi = (total_revenue - total_cost) / total_cost if total_cost > 0 else 0
        
        return {
            "total_revenue": total_revenue,
            "total_cost": total_cost,
            "roi": roi,
            "cost_by_category": {
                c.value: sum(x.amount for x in costs if x.category == c)
                for c in CostCategory
            },
            "channel_count": len(self._revenue),
            "avg_channel_roi": roi / max(len(self._revenue), 1)
        }
    
    # =========================================================================
    # Budget Management
    # =========================================================================
    
    def create_budget(
        self,
        name: str,
        total_amount: float,
        period_start: datetime,
        period_end: datetime
    ) -> Budget:
        """Create a new budget."""
        budget_id = f"budget_{len(self._budgets)}"
        
        budget = Budget(
            budget_id=budget_id,
            name=name,
            total_amount=total_amount,
            remaining=total_amount,
            period_start=period_start,
            period_end=period_end
        )
        
        self._budgets[budget_id] = budget
        self._save_state()
        
        return budget
    
    def allocate_to_budget(
        self,
        budget_id: str,
        amount: float,
        description: str = ""
    ) -> bool:
        """Allocate funds from a budget."""
        budget = self._budgets.get(budget_id)
        if not budget:
            return False
        
        if amount > budget.remaining:
            self.logger.warning(f"Insufficient budget: {amount} > {budget.remaining}")
            return False
        
        allocation = CostAllocation(
            allocation_id=f"alloc_{len(self._costs)}",
            category=CostCategory.HUMAN_TIME,
            amount=amount,
            description=description,
            date=datetime.now()
        )
        
        budget.allocations.append(allocation)
        budget.spent += amount
        budget.remaining -= amount
        
        self._costs.append(allocation)
        self._save_state()
        
        return True
    
    def check_budget_alerts(self) -> List[Dict[str, Any]]:
        """Check for budget alerts."""
        alerts = []
        
        for budget in self._budgets.values():
            if budget.remaining <= 0:
                alerts.append({
                    "budget_id": budget.budget_id,
                    "name": budget.name,
                    "alert_type": "exceeded",
                    "message": f"Budget '{budget.name}' has been exceeded"
                })
            elif budget.spent / budget.total_amount >= budget.alert_threshold:
                alerts.append({
                    "budget_id": budget.budget_id,
                    "name": budget.name,
                    "alert_type": "threshold",
                    "message": f"Budget '{budget.name}' at {budget.spent/budget.total_amount:.0%}"
                })
        
        return alerts
    
    # =========================================================================
    # Optimization
    # =========================================================================
    
    def get_optimization_recommendations(self) -> List[str]:
        """Get cost optimization recommendations."""
        recommendations = []
        
        # Analyze cost distribution
        total_cost = sum(c.amount for c in self._costs)
        if total_cost == 0:
            return recommendations
        
        # Content generation costs
        cg_cost = sum(c.amount for c in self._costs if c.category == CostCategory.CONTENT_GENERATION)
        cg_pct = cg_cost / total_cost
        if cg_pct > 0.5:
            recommendations.append("Content generation costs are high - consider optimizing generation pipeline")
        
        # API call costs
        api_cost = sum(c.amount for c in self._costs if c.category == CostCategory.API_CALLS)
        api_pct = api_cost / total_cost
        if api_pct > 0.3:
            recommendations.append("API costs are high - implement more aggressive caching")
        
        return recommendations


def create_cost_optimizer(data_dir: str = "data/media/cost") -> CostOptimizer:
    """Factory function."""
    return CostOptimizer(data_dir=data_dir)
