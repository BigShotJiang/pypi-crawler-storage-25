"""
Channel Pool - Manages 1000+ channels with dynamic allocation.

Features:
- Resource pooling and allocation
- Priority-based scheduling
- Cross-channel optimization
- Failover and recovery
"""
import asyncio
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging

from simp.organs.media.platform_oauth_manager import Platform


class ChannelPriority(Enum):
    """Channel priority levels."""
    CRITICAL = 1  # Revenue-generating, high-performing
    HIGH = 2
    MEDIUM = 3
    LOW = 4
    IDLE = 5  # Paused or underperforming


class ResourceType(Enum):
    """Types of resources."""
    CONTENT_GENERATION = "content_generation"
    PUBLISHING = "publishing"
    API_CALL = "api_call"
    STORAGE = "storage"


@dataclass
class PooledChannel:
    """A channel in the pool with resource usage."""
    channel_id: str
    name: str
    
    # Resources
    priority: ChannelPriority = ChannelPriority.MEDIUM
    allocated_resources: Dict[str, float] = field(default_factory=dict)  # resource -> amount
    
    # Quotas
    daily_api_quota: int = 100
    daily_api_used: int = 0
    content_generation_quota: int = 10
    content_generation_used: int = 0
    
    # State
    is_active: bool = True
    is_paused: bool = False
    last_used: datetime = field(default_factory=datetime.now)
    
    # Performance
    rpm: float = 0.0
    ctr: float = 0.0
    roi: float = 0.0
    
    # Tags for grouping
    tags: List[str] = field(default_factory=list)


@dataclass
class ChannelAllocation:
    """Resource allocation for a channel."""
    allocation_id: str
    channel_id: str
    
    resources: Dict[str, float] = field(default_factory=dict)
    
    allocated_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    
    # Priority
    priority: ChannelPriority = ChannelPriority.MEDIUM
    queue_position: int = 0


class ChannelPool:
    """
    Manages a pool of channels with dynamic resource allocation.
    
    Handles:
    - Channel registration and lifecycle
    - Resource allocation and quotas
    - Priority scheduling
    - Cross-channel optimization
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/channel_pool"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.channel_pool")
        
        # Channel registry
        self._channels: Dict[str, PooledChannel] = {}
        
        # Resource pools
        self._resource_pools: Dict[ResourceType, float] = {
            ResourceType.CONTENT_GENERATION: 50.0,  # Concurrent generations
            ResourceType.PUBLISHING: 100.0,         # Concurrent publishes
            ResourceType.API_CALL: 1000.0,           # API calls per minute
            ResourceType.STORAGE: 10000.0,           # Storage units
        }
        
        # Allocations
        self._allocations: Dict[str, ChannelAllocation] = {}
        
        # Load state
        self._load_state()
    
    def _load_state(self) -> None:
        """Load channel pool state."""
        state_file = self.data_dir / "pool_state.json"
        if state_file.exists():
            with open(state_file) as f:
                data = json.load(f)
                for ch_data in data.get("channels", []):
                    self._channels[ch_data["channel_id"]] = PooledChannel(**ch_data)
    
    def _save_state(self) -> None:
        """Save channel pool state."""
        state_file = self.data_dir / "pool_state.json"
        data = {
            "channels": [vars(ch) for ch in self._channels.values()]
        }
        with open(state_file, "w") as f:
            json.dump(data, f, indent=2, default=str)
    
    # =========================================================================
    # Channel Management
    # =========================================================================
    
    def register_channel(
        self,
        channel_id: str,
        name: str,
        priority: ChannelPriority = ChannelPriority.MEDIUM,
        tags: Optional[List[str]] = None
    ) -> PooledChannel:
        """Register a new channel in the pool."""
        channel = PooledChannel(
            channel_id=channel_id,
            name=name,
            priority=priority,
            tags=tags or []
        )
        
        self._channels[channel_id] = channel
        self._save_state()
        
        self.logger.info(f"Registered channel: {channel_id} ({name})")
        return channel
    
    def get_channel(self, channel_id: str) -> Optional[PooledChannel]:
        """Get a channel from the pool."""
        return self._channels.get(channel_id)
    
    def remove_channel(self, channel_id: str) -> bool:
        """Remove a channel from the pool."""
        if channel_id in self._channels:
            del self._channels[channel_id]
            self._save_state()
            return True
        return False
    
    def list_channels(
        self,
        priority: Optional[ChannelPriority] = None,
        is_active: Optional[bool] = None,
        tags: Optional[List[str]] = None
    ) -> List[PooledChannel]:
        """List channels with optional filters."""
        channels = list(self._channels.values())
        
        if priority:
            channels = [c for c in channels if c.priority == priority]
        if is_active is not None:
            channels = [c for c in channels if c.is_active == is_active]
        if tags:
            channels = [c for c in channels if any(t in c.tags for t in tags)]
        
        return sorted(channels, key=lambda c: c.priority.value)
    
    # =========================================================================
    # Resource Allocation
    # =========================================================================
    
    def allocate_resources(
        self,
        channel_id: str,
        resources: Dict[ResourceType, float],
        duration_seconds: Optional[int] = None
    ) -> Optional[ChannelAllocation]:
        """Allocate resources to a channel."""
        channel = self._channels.get(channel_id)
        if not channel:
            return None
        
        # Check resource availability
        for res_type, amount in resources.items():
            available = self._resource_pools.get(res_type, 0)
            if amount > available:
                self.logger.warning(f"Insufficient resources: {res_type.value}")
                return None
        
        # Create allocation
        allocation_id = f"alloc_{uuid.uuid4().hex[:8]}"
        allocation = ChannelAllocation(
            allocation_id=allocation_id,
            channel_id=channel_id,
            resources={r.value: amt for r, amt in resources.items()},
            expires_at=datetime.now() + timedelta(seconds=duration_seconds) if duration_seconds else None,
            priority=channel.priority
        )
        
        # Reserve resources
        for res_type, amount in resources.items():
            self._resource_pools[res_type] -= amount
        
        self._allocations[allocation_id] = allocation
        self._save_state()
        
        return allocation
    
    def release_allocation(self, allocation_id: str) -> bool:
        """Release an allocation and return resources to pool."""
        allocation = self._allocations.get(allocation_id)
        if not allocation:
            return False
        
        # Return resources
        for res_name, amount in allocation.resources.items():
            try:
                res_type = ResourceType(res_name)
                self._resource_pools[res_type] += amount
            except ValueError:
                pass
        
        del self._allocations[allocation_id]
        self._save_state()
        
        return True
    
    def get_available_resources(self) -> Dict[str, float]:
        """Get available resources per type."""
        return {r.value: amt for r, amt in self._resource_pools.items()}
    
    # =========================================================================
    # Quota Management
    # =========================================================================
    
    def check_quota(
        self,
        channel_id: str,
        quota_type: str
    ) -> bool:
        """Check if channel has quota remaining."""
        channel = self._channels.get(channel_id)
        if not channel:
            return False
        
        if quota_type == "api":
            return channel.daily_api_used < channel.daily_api_quota
        elif quota_type == "content":
            return channel.content_generation_used < channel.content_generation_quota
        
        return True
    
    def consume_quota(
        self,
        channel_id: str,
        quota_type: str,
        amount: int = 1
    ) -> bool:
        """Consume quota for a channel."""
        channel = self._channels.get(channel_id)
        if not channel:
            return False
        
        if not self.check_quota(channel_id, quota_type):
            return False
        
        if quota_type == "api":
            channel.daily_api_used += amount
        elif quota_type == "content":
            channel.content_generation_used += amount
        
        channel.last_used = datetime.now()
        self._save_state()
        
        return True
    
    def reset_daily_quotas(self) -> None:
        """Reset daily quotas for all channels."""
        for channel in self._channels.values():
            channel.daily_api_used = 0
            channel.content_generation_used = 0
        
        self._save_state()
        self.logger.info("Reset daily quotas for all channels")
    
    # =========================================================================
    # Priority & Scheduling
    # =========================================================================
    
    def update_priority(
        self,
        channel_id: str,
        priority: ChannelPriority
    ) -> bool:
        """Update channel priority."""
        channel = self._channels.get(channel_id)
        if not channel:
            return False
        
        channel.priority = priority
        self._save_state()
        
        return True
    
    def get_next_channel(
        self,
        resource_type: Optional[ResourceType] = None
    ) -> Optional[PooledChannel]:
        """Get next channel based on priority and resource availability."""
        channels = self.list_channels(is_active=True, is_paused=False)
        
        for channel in channels:
            # Check quota
            if resource_type == ResourceType.API_CALL:
                if not self.check_quota(channel.channel_id, "api"):
                    continue
            elif resource_type == ResourceType.CONTENT_GENERATION:
                if not self.check_quota(channel.channel_id, "content"):
                    continue
            
            return channel
        
        return None
    
    # =========================================================================
    # Optimization
    # =========================================================================
    
    def rebalance_resources(self) -> None:
        """Rebalance resources across channels based on ROI."""
        # Sort by ROI
        sorted_channels = sorted(
            self._channels.values(),
            key=lambda c: c.roi,
            reverse=True
        )
        
        # Allocate more to high-ROI channels
        total_resources = sum(self._resource_pools.values())
        
        # In production, would implement actual rebalancing logic
        self.logger.info(f"Rebalanced resources across {len(sorted_channels)} channels")
    
    def identify_idle_channels(self) -> List[PooledChannel]:
        """Identify channels that haven't been used recently."""
        cutoff = datetime.now() - timedelta(days=7)
        
        return [
            c for c in self._channels.values()
            if c.last_used < cutoff and c.is_active
        ]
    
    def get_pool_stats(self) -> Dict[str, Any]:
        """Get overall pool statistics."""
        total_channels = len(self._channels)
        active_channels = sum(1 for c in self._channels.values() if c.is_active)
        total_roi = sum(c.roi for c in self._channels.values())
        avg_roi = total_roi / max(total_channels, 1)
        
        return {
            "total_channels": total_channels,
            "active_channels": active_channels,
            "idle_channels": total_channels - active_channels,
            "total_allocations": len(self._allocations),
            "available_resources": self.get_available_resources(),
            "avg_roi": avg_roi,
            "by_priority": {
                p.name: sum(1 for c in self._channels.values() if c.priority == p)
                for p in ChannelPriority
            }
        }


def create_channel_pool(data_dir: str = "data/media/channel_pool") -> ChannelPool:
    """Factory function."""
    return ChannelPool(data_dir=data_dir)
