"""
Scale Infrastructure for Enterprise Media Empire.

Enables operation of 1000+ channels with:
- Dynamic resource allocation
- Distributed worker queues
- Real-time metrics pipelines
- Cost optimization
"""
from simp.organs.media.scale.channel_pool import (
    ChannelPool,
    PooledChannel,
    ChannelAllocation,
    create_channel_pool
)
from simp.organs.media.scale.worker_queue import (
    WorkerQueue,
    Job,
    JobStatus,
    Worker,
    create_worker_queue
)
from simp.organs.media.scale.metrics_pipeline import (
    MetricsPipeline,
    MetricPoint,
    AggregationWindow,
    create_metrics_pipeline
)
from simp.organs.media.scale.cost_optimizer import (
    CostOptimizer,
    CostAllocation,
    ROIAnalysis,
    create_cost_optimizer
)

__version__ = "0.1.0"
__all__ = [
    "ChannelPool",
    "PooledChannel",
    "ChannelAllocation",
    "create_channel_pool",
    "WorkerQueue",
    "Job",
    "JobStatus",
    "Worker",
    "create_worker_queue",
    "MetricsPipeline",
    "MetricPoint",
    "AggregationWindow",
    "create_metrics_pipeline",
    "CostOptimizer",
    "CostAllocation",
    "ROIAnalysis",
    "create_cost_optimizer"
]
