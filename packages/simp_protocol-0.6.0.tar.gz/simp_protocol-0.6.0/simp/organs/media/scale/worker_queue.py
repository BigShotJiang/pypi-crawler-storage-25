"""
Worker Queue - Distributed job processing for scale.

Features:
- Priority queues
- Worker management
- Job retries
- Dead letter queue
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging


class JobStatus(Enum):
    """Status of a job."""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    DEAD_LETTER = "dead_letter"


class JobPriority(Enum):
    """Job priority levels."""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    URGENT = 3


@dataclass
class Job:
    """A job in the queue."""
    job_id: str
    job_type: str  # "content_generation", "publishing", "analytics"
    
    # Payload
    payload: Dict[str, Any] = field(default_factory=dict)
    
    # Priority & scheduling
    priority: JobPriority = JobPriority.NORMAL
    scheduled_at: Optional[datetime] = None
    
    # Status
    status: JobStatus = JobStatus.PENDING
    
    # Worker info
    worker_id: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    # Retry
    retry_count: int = 0
    max_retries: int = 3
    last_error: Optional[str] = None
    
    # Result
    result: Optional[Dict[str, Any]] = None
    
    # Metadata
    channel_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    
    # Tracing
    parent_job_id: Optional[str] = None
    trace_id: Optional[str] = None


@dataclass
class Worker:
    """A worker that processes jobs."""
    worker_id: str
    name: str
    
    # Status
    is_active: bool = False
    is_busy: bool = False
    
    # Current job
    current_job_id: Optional[str] = None
    started_job_at: Optional[datetime] = None
    
    # Stats
    jobs_processed: int = 0
    jobs_failed: int = 0
    avg_process_time: float = 0.0
    
    # Capabilities
    capabilities: List[str] = field(default_factory=list)
    
    # Heartbeat
    last_heartbeat: datetime = field(default_factory=datetime.now)


class WorkerQueue:
    """
    Distributed worker queue for job processing.
    
    Features:
    - Priority-based job scheduling
    - Worker pool management
    - Automatic retry
    - Dead letter queue
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/worker_queue"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.worker_queue")
        
        # Queues (by priority)
        self._queues: Dict[JobPriority, List[Job]] = {
            JobPriority.LOW: [],
            JobPriority.NORMAL: [],
            JobPriority.HIGH: [],
            JobPriority.URGENT: []
        }
        
        # Workers
        self._workers: Dict[str, Worker] = {}
        
        # Job storage
        self._jobs: Dict[str, Job] = {}
        
        # Dead letter queue
        self._dead_letter: List[Job] = []
        
        # Processing state
        self._running: bool = False
        self._process_task: Optional[asyncio.Task] = None
        
        # Stats
        self.metrics = {
            "total_jobs": 0,
            "completed_jobs": 0,
            "failed_jobs": 0,
            "avg_queue_time": 0.0
        }
        
        self._load_state()
    
    def _load_state(self) -> None:
        """Load queue state from disk."""
        state_file = self.data_dir / "queue_state.json"
        if state_file.exists():
            with open(state_file) as f:
                data = json.load(f)
                self._jobs = {
                    jid: Job(**j) for jid, j in data.get("jobs", {}).items()
                }
    
    def _save_state(self) -> None:
        """Save queue state to disk."""
        state_file = self.data_dir / "queue_state.json"
        data = {
            "jobs": {
                jid: {
                    **vars(j),
                    "created_at": j.created_at.isoformat(),
                    "started_at": j.started_at.isoformat() if j.started_at else None,
                    "completed_at": j.completed_at.isoformat() if j.completed_at else None,
                    "scheduled_at": j.scheduled_at.isoformat() if j.scheduled_at else None
                }
                for jid, j in self._jobs.items()
            }
        }
        with open(state_file, "w") as f:
            json.dump(data, f, indent=2, default=str)
    
    # =========================================================================
    # Job Management
    # =========================================================================
    
    def enqueue(
        self,
        job_type: str,
        payload: Dict[str, Any],
        priority: JobPriority = JobPriority.NORMAL,
        scheduled_at: Optional[datetime] = None,
        channel_id: Optional[str] = None,
        max_retries: int = 3
    ) -> str:
        """Add a job to the queue."""
        job_id = f"job_{uuid.uuid4().hex[:12]}"
        
        job = Job(
            job_id=job_id,
            job_type=job_type,
            payload=payload,
            priority=priority,
            scheduled_at=scheduled_at,
            status=JobStatus.PENDING,
            channel_id=channel_id,
            max_retries=max_retries
        )
        
        self._jobs[job_id] = job
        self.metrics["total_jobs"] += 1
        
        if not scheduled_at or scheduled_at <= datetime.now():
            self._queues[priority].append(job)
            job.status = JobStatus.QUEUED
        
        self._save_state()
        self.logger.info(f"Enqueued job: {job_id} ({job_type}) priority={priority.name}")
        
        return job_id
    
    def dequeue(self, worker_id: str) -> Optional[Job]:
        """Get next job for a worker."""
        worker = self._workers.get(worker_id)
        if not worker or worker.is_busy:
            return None
        
        # Check queues by priority
        for priority in [JobPriority.URGENT, JobPriority.HIGH, JobPriority.NORMAL, JobPriority.LOW]:
            queue = self._queues[priority]
            
            for i, job in enumerate(queue):
                if self._can_process_job(job, worker):
                    queue.pop(i)
                    job.status = JobStatus.RUNNING
                    job.worker_id = worker_id
                    job.started_at = datetime.now()
                    
                    worker.is_busy = True
                    worker.current_job_id = job.job_id
                    worker.started_job_at = datetime.now()
                    
                    self._save_state()
                    return job
        
        return None
    
    def _can_process_job(self, job: Job, worker: Worker) -> bool:
        """Check if worker can process this job."""
        if not worker.is_active:
            return False
        
        # Check capabilities
        if worker.capabilities and job.job_type not in worker.capabilities:
            return False
        
        # Check if scheduled
        if job.scheduled_at and job.scheduled_at > datetime.now():
            return False
        
        return True
    
    def complete(self, job_id: str, result: Optional[Dict[str, Any]] = None) -> bool:
        """Mark a job as completed."""
        job = self._jobs.get(job_id)
        if not job:
            return False
        
        job.status = JobStatus.COMPLETED
        job.completed_at = datetime.now()
        job.result = result
        
        # Free the worker
        if job.worker_id:
            worker = self._workers.get(job.worker_id)
            if worker:
                worker.is_busy = False
                worker.current_job_id = None
                worker.jobs_processed += 1
        
        self.metrics["completed_jobs"] += 1
        self._save_state()
        
        self.logger.info(f"Completed job: {job_id}")
        return True
    
    def fail(self, job_id: str, error: str) -> bool:
        """Mark a job as failed."""
        job = self._jobs.get(job_id)
        if not job:
            return False
        
        job.last_error = error
        job.retry_count += 1
        
        # Free the worker
        if job.worker_id:
            worker = self._workers.get(job.worker_id)
            if worker:
                worker.is_busy = False
                worker.current_job_id = None
                worker.jobs_failed += 1
        
        # Retry or dead letter
        if job.retry_count < job.max_retries:
            # Re-queue with same priority
            self._queues[job.priority].append(job)
            job.status = JobStatus.QUEUED
            self.logger.warning(f"Retrying job: {job_id} (attempt {job.retry_count})")
        else:
            # Move to dead letter
            job.status = JobStatus.DEAD_LETTER
            self._dead_letter.append(job)
            self.metrics["failed_jobs"] += 1
            self.logger.error(f"Job dead-lettered: {job_id} - {error}")
        
        self._save_state()
        return True
    
    def cancel(self, job_id: str) -> bool:
        """Cancel a job."""
        job = self._jobs.get(job_id)
        if not job or job.status in [JobStatus.COMPLETED, JobStatus.FAILED]:
            return False
        
        job.status = JobStatus.CANCELLED
        job.completed_at = datetime.now()
        
        self._save_state()
        return True
    
    # =========================================================================
    # Worker Management
    # =========================================================================
    
    def register_worker(
        self,
        name: str,
        capabilities: Optional[List[str]] = None
    ) -> str:
        """Register a new worker."""
        worker_id = f"worker_{uuid.uuid4().hex[:8]}"
        
        worker = Worker(
            worker_id=worker_id,
            name=name,
            is_active=True,
            capabilities=capabilities or []
        )
        
        self._workers[worker_id] = worker
        self.logger.info(f"Registered worker: {worker_id} ({name})")
        
        return worker_id
    
    def unregister_worker(self, worker_id: str) -> bool:
        """Unregister a worker."""
        if worker_id in self._workers:
            del self._workers[worker_id]
            return True
        return False
    
    def get_idle_worker(self) -> Optional[Worker]:
        """Get an idle worker."""
        for worker in self._workers.values():
            if worker.is_active and not worker.is_busy:
                return worker
        return None
    
    def heartbeat(self, worker_id: str) -> bool:
        """Update worker heartbeat."""
        worker = self._workers.get(worker_id)
        if worker:
            worker.last_heartbeat = datetime.now()
            return True
        return False
    
    # =========================================================================
    # Queue Status
    # =========================================================================
    
    def get_queue_depth(self) -> Dict[str, int]:
        """Get number of jobs per queue."""
        return {
            priority.name: len(queue)
            for priority, queue in self._queues.items()
        }
    
    def get_job_status(self, job_id: str) -> Optional[JobStatus]:
        """Get status of a job."""
        job = self._jobs.get(job_id)
        return job.status if job else None
    
    def get_dead_letter_jobs(self) -> List[Job]:
        """Get all dead letter jobs."""
        return self._dead_letter
    
    def retry_dead_letter(self, job_id: str) -> bool:
        """Retry a dead letter job."""
        for i, job in enumerate(self._dead_letter):
            if job.job_id == job_id:
                self._dead_letter.pop(i)
                job.status = JobStatus.QUEUED
                job.retry_count = 0
                self._queues[job.priority].append(job)
                self._save_state()
                return True
        return False
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get queue metrics."""
        return {
            **self.metrics,
            "total_workers": len(self._workers),
            "active_workers": sum(1 for w in self._workers.values() if w.is_active),
            "busy_workers": sum(1 for w in self._workers.values() if w.is_busy),
            "queue_depth": self.get_queue_depth(),
            "dead_letter_count": len(self._dead_letter)
        }


def create_worker_queue(data_dir: str = "data/media/worker_queue") -> WorkerQueue:
    """Factory function."""
    return WorkerQueue(data_dir=data_dir)
