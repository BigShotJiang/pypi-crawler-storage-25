"""
Metrics Pipeline - Real-time metrics collection and aggregation.

Features:
- Real-time streaming (simulated)
- Historical aggregation
- Anomaly detection
- ML feature store
"""
import asyncio
import json
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging


class AggregationWindow(Enum):
    """Time windows for aggregation."""
    SECOND = "1s"
    MINUTE = "1m"
    HOUR = "1h"
    DAY = "1d"


@dataclass
class MetricPoint:
    """A single metric data point."""
    metric_name: str
    value: float
    timestamp: datetime
    labels: Dict[str, str] = field(default_factory=dict)


@dataclass
class AggregatedMetric:
    """Aggregated metric over a time window."""
    # Required fields first (no defaults)
    metric_name: str
    window: AggregationWindow
    count: int
    sum_val: float
    min_val: float
    max_val: float
    avg: float
    p50: float
    p95: float
    p99: float
    window_start: datetime
    window_end: datetime
    # Fields with defaults last
    labels: Dict[str, str] = field(default_factory=dict)


class MetricsPipeline:
    """Real-time metrics pipeline for media empire."""
    
    def __init__(self, data_dir: str = "data/media/metrics"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.metrics_pipeline")
        self._buffer: deque = deque(maxlen=10000)
        self._aggregates: Dict[str, List[AggregatedMetric]] = {}
        self._handlers: Dict[str, List[Callable]] = {}
        self.retention_days: int = 30
        self._collecting: bool = False
        self._collect_task: Optional[asyncio.Task] = None
    
    def record(self, metric_name: str, value: float, labels: Optional[Dict[str, str]] = None) -> None:
        """Record a metric point."""
        point = MetricPoint(metric_name=metric_name, value=value, timestamp=datetime.now(), labels=labels or {})
        self._buffer.append(point)
        if metric_name in self._handlers:
            for handler in self._handlers[metric_name]:
                try:
                    handler(point)
                except Exception as e:
                    self.logger.error(f"Handler failed for {metric_name}: {e}")
    
    def register_handler(self, metric_name: str, handler: Callable) -> None:
        """Register a handler for a metric."""
        if metric_name not in self._handlers:
            self._handlers[metric_name] = []
        self._handlers[metric_name].append(handler)
    
    def aggregate(self, metric_name: str, window: AggregationWindow, labels: Optional[Dict[str, str]] = None, period_start: Optional[datetime] = None, period_end: Optional[datetime] = None) -> AggregatedMetric:
        """Aggregate metrics over a time window."""
        period_end = period_end or datetime.now()
        period_start = period_start or (period_end - timedelta(hours=1))
        points = [p for p in self._buffer if p.metric_name == metric_name and period_start <= p.timestamp <= period_end and (not labels or all(p.labels.get(k) == v for k, v in labels.items()))]
        if not points:
            return AggregatedMetric(metric_name=metric_name, window=window, count=0, sum_val=0, min_val=0, max_val=0, avg=0, p50=0, p95=0, p99=0, window_start=period_start, window_end=period_end, labels=labels or {})
        values = sorted([p.value for p in points])
        return AggregatedMetric(metric_name=metric_name, window=window, count=len(values), sum_val=sum(values), min_val=min(values), max_val=max(values), avg=sum(values)/len(values), p50=self._percentile(values, 0.5), p95=self._percentile(values, 0.95), p99=self._percentile(values, 0.99), window_start=period_start, window_end=period_end, labels=labels or {})
    
    def _percentile(self, sorted_values: List[float], p: float) -> float:
        if not sorted_values: return 0.0
        idx = int(len(sorted_values) * p)
        idx = min(idx, len(sorted_values) - 1)
        return sorted_values[idx]
    
    def record_content_generated(self, channel_id: str, platform: str, duration_ms: float) -> None:
        self.record("content.generation.duration_ms", duration_ms, {"channel_id": channel_id, "platform": platform})
    
    def record_published(self, channel_id: str, platform: str, engagement_1h: int) -> None:
        self.record("content.published.engagement_1h", float(engagement_1h), {"channel_id": channel_id, "platform": platform})
    
    def record_revenue(self, channel_id: str, platform: str, amount: float) -> None:
        self.record("revenue.amount", amount, {"channel_id": channel_id, "platform": platform})
    
    def record_api_call(self, platform: str, latency_ms: float, success: bool) -> None:
        self.record("api.call.latency_ms", latency_ms, {"platform": platform, "success": str(success)})
    
    def query(self, metric_name: str, window: AggregationWindow, period_days: int = 7, labels: Optional[Dict[str, str]] = None) -> List[AggregatedMetric]:
        key = f"{metric_name}:{window.value}"
        if key not in self._aggregates:
            return []
        cutoff = datetime.now() - timedelta(days=period_days)
        results = [a for a in self._aggregates[key] if a.window_end >= cutoff]
        if labels:
            results = [a for a in results if all(a.labels.get(k) == v for k, v in labels.items())]
        return sorted(results, key=lambda a: a.window_start)
    
    def get_latest(self, metric_name: str, labels: Optional[Dict[str, str]] = None) -> Optional[float]:
        points = [p for p in self._buffer if p.metric_name == metric_name and (not labels or all(p.labels.get(k) == v for k, v in labels.items()))]
        return points[-1].value if points else None
    
    def detect_anomaly(self, metric_name: str, threshold_std: float = 2.0, window: AggregationWindow = AggregationWindow.HOUR) -> List[Dict[str, Any]]:
        recent = self.query(metric_name, window, period_days=1)
        if len(recent) < 10:
            return []
        values = [a.avg for a in recent]
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / len(values)
        std = variance ** 0.5
        anomalies = []
        for a in recent:
            if abs(a.avg - mean) > threshold_std * std:
                anomalies.append({"metric_name": metric_name, "window_start": a.window_start.isoformat(), "value": a.avg, "expected_range": (mean - threshold_std * std, mean + threshold_std * std), "deviation": abs(a.avg - mean) / std})
        return anomalies


def create_metrics_pipeline(data_dir: str = "data/media/metrics") -> MetricsPipeline:
    return MetricsPipeline(data_dir=data_dir)
