"""
Circuit Breaker - Prevents cascading failures.

Opens circuit when failures exceed threshold, preventing further requests.
"""
import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, Optional, Any, Callable
import logging


class CircuitState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"     # Normal operation
    OPEN = "open"         # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if service recovered


@dataclass
class CircuitMetrics:
    """Circuit breaker metrics."""
    total_calls: int = 0
    successful_calls: int = 0
    failed_calls: int = 0
    
    last_failure_at: Optional[datetime] = None
    last_success_at: Optional[datetime] = None
    
    consecutive_failures: int = 0
    consecutive_successes: int = 0
    
    # State transitions
    opened_at: Optional[datetime] = None
    closed_at: Optional[datetime] = None
    last_transition_at: Optional[datetime] = None


class CircuitBreaker:
    """
    Circuit breaker to prevent cascading failures.
    
    States:
    - CLOSED: Normal operation, requests pass through
    - OPEN: Too many failures, requests are rejected
    - HALF_OPEN: Testing recovery, limited requests pass through
    
    Transitions:
    - CLOSED -> OPEN: When failures exceed threshold
    - OPEN -> HALF_OPEN: After timeout period
    - HALF_OPEN -> CLOSED: If test requests succeed
    - HALF_OPEN -> OPEN: If test requests fail
    """
    
    def __init__(
        self,
        name: str,
        
        # Failure thresholds
        failure_threshold: int = 5,
        success_threshold: int = 3,
        
        # Timing
        timeout_seconds: float = 30.0,
        half_open_max_calls: int = 3,
        
        # Callbacks
        on_open: Optional[Callable] = None,
        on_close: Optional[Callable] = None
    ):
        self.name = name
        self.logger = logging.getLogger(f"circuit_breaker.{name}")
        
        # Configuration
        self.failure_threshold = failure_threshold
        self.success_threshold = success_threshold
        self.timeout_seconds = timeout_seconds
        self.half_open_max_calls = half_open_max_calls
        
        # Callbacks
        self.on_open = on_open
        self.on_close = on_close
        
        # State
        self._state = CircuitState.CLOSED
        self._metrics = CircuitMetrics()
        self._half_open_calls = 0
        self._lock = asyncio.Lock()
    
    @property
    def state(self) -> CircuitState:
        """Get current state, checking for timeout transition."""
        if self._state == CircuitState.OPEN:
            if self._should_attempt_reset():
                asyncio.create_task(self._transition_to_half_open())
        return self._state
    
    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset."""
        if not self._metrics.opened_at:
            return True
        elapsed = (datetime.now() - self._metrics.opened_at).total_seconds()
        return elapsed >= self.timeout_seconds
    
    async def _transition_to_half_open(self) -> None:
        """Transition from OPEN to HALF_OPEN."""
        async with self._lock:
            if self._state != CircuitState.OPEN:
                return
            
            self._state = CircuitState.HALF_OPEN
            self._half_open_calls = 0
            self._metrics.last_transition_at = datetime.now()
            self.logger.info(f"Circuit {self.name}: OPEN -> HALF_OPEN")
    
    async def _transition_to_closed(self) -> None:
        """Transition to CLOSED state."""
        async with self._lock:
            self._state = CircuitState.CLOSED
            self._metrics.consecutive_failures = 0
            self._metrics.closed_at = datetime.now()
            self._metrics.last_transition_at = datetime.now()
            self.logger.info(f"Circuit {self.name}: HALF_OPEN -> CLOSED")
            
            if self.on_close:
                await self.on_close(self.name)
    
    async def _transition_to_open(self) -> None:
        """Transition to OPEN state."""
        async with self._lock:
            self._state = CircuitState.OPEN
            self._metrics.opened_at = datetime.now()
            self._metrics.last_transition_at = datetime.now()
            self.logger.warning(f"Circuit {self.name}: CLOSED -> OPEN (failures={self._metrics.consecutive_failures})")
            
            if self.on_open:
                await self.on_open(self.name)
    
    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function through the circuit breaker.
        
        Raises CircuitBreakerOpen if circuit is open.
        """
        if self.state == CircuitState.OPEN:
            raise CircuitBreakerOpen(f"Circuit {self.name} is OPEN")
        
        if self.state == CircuitState.HALF_OPEN:
            async with self._lock:
                if self._half_open_calls >= self.half_open_max_calls:
                    raise CircuitBreakerOpen(f"Circuit {self.name} is HALF_OPEN, max calls reached")
                self._half_open_calls += 1
        
        self._metrics.total_calls += 1
        
        try:
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            await self._record_success()
            return result
            
        except Exception as e:
            await self._record_failure()
            raise
    
    async def _record_success(self) -> None:
        """Record a successful call."""
        self._metrics.successful_calls += 1
        self._metrics.consecutive_successes += 1
        self._metrics.consecutive_failures = 0
        self._metrics.last_success_at = datetime.now()
        
        # Transition from HALF_OPEN to CLOSED after success threshold
        if self._state == CircuitState.HALF_OPEN:
            if self._metrics.consecutive_successes >= self.success_threshold:
                await self._transition_to_closed()
    
    async def _record_failure(self) -> None:
        """Record a failed call."""
        self._metrics.failed_calls += 1
        self._metrics.consecutive_failures += 1
        self._metrics.consecutive_successes = 0
        self._metrics.last_failure_at = datetime.now()
        
        # Transition to OPEN if failure threshold reached
        if self._state == CircuitState.CLOSED:
            if self._metrics.consecutive_failures >= self.failure_threshold:
                await self._transition_to_open()
        
        # Transition back to OPEN from HALF_OPEN on failure
        elif self._state == CircuitState.HALF_OPEN:
            await self._transition_to_open()
    
    def is_closed(self) -> bool:
        """Check if circuit is closed."""
        return self.state == CircuitState.CLOSED
    
    def is_open(self) -> bool:
        """Check if circuit is open."""
        return self.state == CircuitState.OPEN
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get circuit metrics."""
        return {
            "name": self.name,
            "state": self.state.value,
            "total_calls": self._metrics.total_calls,
            "success_rate": self._metrics.successful_calls / max(self._metrics.total_calls, 1),
            "consecutive_failures": self._metrics.consecutive_failures,
            "failure_threshold": self.failure_threshold,
            "timeout_seconds": self.timeout_seconds,
            "opened_at": self._metrics.opened_at.isoformat() if self._metrics.opened_at else None,
            "last_failure_at": self._metrics.last_failure_at.isoformat() if self._metrics.last_failure_at else None
        }
    
    async def reset(self) -> None:
        """Manually reset the circuit breaker."""
        async with self._lock:
            self._state = CircuitState.CLOSED
            self._metrics = CircuitMetrics()
            self._half_open_calls = 0
            self.logger.info(f"Circuit {self.name}: manually reset")


class CircuitBreakerOpen(Exception):
    """Exception raised when circuit breaker is open."""
    pass


class CircuitBreakerManager:
    """Manages multiple circuit breakers."""
    
    def __init__(self):
        self._breakers: Dict[str, CircuitBreaker] = {}
        self.logger = logging.getLogger("circuit_breaker.manager")
    
    def get_or_create(
        self,
        name: str,
        **kwargs
    ) -> CircuitBreaker:
        """Get existing or create new circuit breaker."""
        if name not in self._breakers:
            self._breakers[name] = CircuitBreaker(name, **kwargs)
        return self._breakers[name]
    
    def get_all_metrics(self) -> Dict[str, Any]:
        """Get metrics for all circuit breakers."""
        return {
            name: breaker.get_metrics()
            for name, breaker in self._breakers.items()
        }
    
    def open_circuit(self, name: str) -> None:
        """Manually open a circuit."""
        if name in self._breakers:
            asyncio.create_task(self._breakers[name]._transition_to_open())
    
    def close_circuit(self, name: str) -> None:
        """Manually close a circuit."""
        if name in self._breakers:
            asyncio.create_task(self._breakers[name]._transition_to_closed())


# Global circuit breaker manager
_circuit_manager: Optional[CircuitBreakerManager] = None


def get_circuit_breaker(name: str, **kwargs) -> CircuitBreaker:
    """Get a circuit breaker from the global manager."""
    global _circuit_manager
    if _circuit_manager is None:
        _circuit_manager = CircuitBreakerManager()
    return _circuit_manager.get_or_create(name, **kwargs)


def create_circuit_breaker(
    name: str,
    **kwargs
) -> CircuitBreaker:
    """Create a new circuit breaker."""
    return CircuitBreaker(name, **kwargs)
