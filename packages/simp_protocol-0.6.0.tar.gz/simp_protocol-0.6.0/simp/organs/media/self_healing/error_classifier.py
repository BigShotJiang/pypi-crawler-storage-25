"""
Error Classifier - Categorizes errors by type, severity, and recoverability.

Enables appropriate recovery strategies based on error characteristics.
"""
import asyncio
import json
import re
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable, Type
import logging


class ErrorType(Enum):
    """Categories of errors."""
    # Network/Connectivity
    NETWORK_ERROR = "network_error"
    TIMEOUT = "timeout"
    CONNECTION_REFUSED = "connection_refused"
    DNS_FAILURE = "dns_failure"
    
    # API/Platform
    RATE_LIMIT = "rate_limit"
    AUTHENTICATION_FAILED = "auth_failed"
    AUTHORIZATION_DENIED = "auth_denied"
    TOKEN_EXPIRED = "token_expired"
    API_ERROR = "api_error"
    API_DEPRECATED = "api_deprecated"
    
    # Content
    CONTENT_POLICY_VIOLATION = "content_policy"
    COPYRIGHT_CLAIM = "copyright"
    TRADEMARK_VIOLATION = "trademark"
    NSFW_DETECTED = "nsfw"
    
    # Account
    ACCOUNT_SUSPENDED = "account_suspended"
    ACCOUNT_BANNED = "account_banned"
    QUOTA_EXCEEDED = "quota_exceeded"
    
    # Resource
    FILE_NOT_FOUND = "file_not_found"
    STORAGE_FULL = "storage_full"
    MEMORY_ERROR = "memory_error"
    
    # Validation
    INVALID_INPUT = "invalid_input"
    MISSING_PARAMETER = "missing_param"
    SCHEMA_VIOLATION = "schema_violation"
    
    # System
    UNKNOWN_ERROR = "unknown"
    INTERNAL_ERROR = "internal_error"
    SERVICE_UNAVAILABLE = "service_unavailable"


class ErrorSeverity(Enum):
    """Severity levels for errors."""
    CRITICAL = "critical"  # Immediate halt, human required
    HIGH = "high"         # Retry with backoff, escalate if persistent
    MEDIUM = "medium"     # Auto-retry, log for monitoring
    LOW = "low"           # Log only, continue operation


class Recoverability(Enum):
    """Whether an error is recoverable."""
    AUTO_RETRY = "auto_retry"       # Can retry immediately
    RETRY_WITH_BACKOFF = "retry_backoff"  # Retry with exponential backoff
    MANUAL_RETRY = "manual_retry"   # Retry after fix
    UNRECOVERABLE = "unrecoverable"  # Cannot retry


@dataclass
class ErrorPattern:
    """Pattern for matching error messages."""
    pattern: str
    error_type: ErrorType
    severity: ErrorSeverity
    recoverability: Recoverability
    
    # Match criteria
    http_status_codes: List[int] = field(default_factory=list)
    platform_codes: List[str] = field(default_factory=list)
    
    # Metadata
    description: str = ""
    resolution_hint: str = ""


@dataclass
class ClassifiedError:
    """A classified error with recovery info."""
    error_id: str
    original_error: str
    
    # Classification
    error_type: ErrorType
    severity: ErrorSeverity
    recoverability: Recoverability
    
    # Context
    platform: Optional[str] = None
    operation: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    
    # Recovery
    retry_after_seconds: int = 0
    resolution_hint: str = ""
    
    # History
    occurred_at: datetime = field(default_factory=datetime.now)
    occurrence_count: int = 1
    last_occurrence: datetime = field(default_factory=datetime.now)


class ErrorClassifier:
    """
    Classifies errors and determines recovery strategies.
    
    Maintains error history, detects patterns, and suggests recovery actions.
    """
    
    # Default error patterns
    DEFAULT_PATTERNS: List[ErrorPattern] = [
        # Network errors
        ErrorPattern(
            pattern=r"Connection.*timeout|timed out",
            error_type=ErrorType.TIMEOUT,
            severity=ErrorSeverity.MEDIUM,
            recoverability=Recoverability.RETRY_WITH_BACKOFF,
            resolution_hint="Increase timeout or retry with backoff"
        ),
        ErrorPattern(
            pattern=r"Connection refused|ECONNREFUSED",
            error_type=ErrorType.CONNECTION_REFUSED,
            severity=ErrorSeverity.HIGH,
            recoverability=Recoverability.RETRY_WITH_BACKOFF,
            resolution_hint="Service may be down, retry after delay"
        ),
        ErrorPattern(
            pattern=r"DNS|Could not resolve",
            error_type=ErrorType.DNS_FAILURE,
            severity=ErrorSeverity.HIGH,
            recoverability=Recoverability.RETRY_WITH_BACKOFF,
            resolution_hint="Check DNS configuration"
        ),
        
        # Rate limiting
        ErrorPattern(
            pattern=r"429|Rate limit|Too many requests",
            error_type=ErrorType.RATE_LIMIT,
            severity=ErrorSeverity.MEDIUM,
            recoverability=Recoverability.RETRY_WITH_BACKOFF,
            resolution_hint="Wait before retrying"
        ),
        
        # Authentication
        ErrorPattern(
            pattern=r"401|Unauthorized|Authentication failed",
            error_type=ErrorType.AUTHENTICATION_FAILED,
            severity=ErrorSeverity.HIGH,
            recoverability=Recoverability.UNRECOVERABLE,
            resolution_hint="Invalid credentials, refresh OAuth token"
        ),
        ErrorPattern(
            pattern=r"403|Forbidden|Access denied",
            error_type=ErrorType.AUTHORIZATION_DENIED,
            severity=ErrorSeverity.HIGH,
            recoverability=Recoverability.UNRECOVERABLE,
            resolution_hint="Insufficient permissions, check scopes"
        ),
        ErrorPattern(
            pattern=r"token.*expired|Token has expired",
            error_type=ErrorType.TOKEN_EXPIRED,
            severity=ErrorSeverity.MEDIUM,
            recoverability=Recoverability.MANUAL_RETRY,
            resolution_hint="Refresh OAuth token"
        ),
        
        # Content violations
        ErrorPattern(
            pattern=r"content.*policy|Community guidelines",
            error_type=ErrorType.CONTENT_POLICY_VIOLATION,
            severity=ErrorSeverity.CRITICAL,
            recoverability=Recoverability.UNRECOVERABLE,
            resolution_hint="Remove/modify violating content"
        ),
        ErrorPattern(
            pattern=r"copyright|Content ID|match",
            error_type=ErrorType.COPYRIGHT_CLAIM,
            severity=ErrorSeverity.HIGH,
            recoverability=Recoverability.UNRECOVERABLE,
            resolution_hint="Dispute claim or use different content"
        ),
        
        # Account issues
        ErrorPattern(
            pattern=r"Account.*suspended|suspended",
            error_type=ErrorType.ACCOUNT_SUSPENDED,
            severity=ErrorSeverity.CRITICAL,
            recoverability=Recoverability.UNRECOVERABLE,
            resolution_hint="Contact platform support"
        ),
        ErrorPattern(
            pattern=r"Account.*banned|permanently.*ban",
            error_type=ErrorType.ACCOUNT_BANNED,
            severity=ErrorSeverity.CRITICAL,
            recoverability=Recoverability.UNRECOVERABLE,
            resolution_hint="Create new account, pivot strategy"
        ),
        
        # Platform API errors
        ErrorPattern(
            pattern=r"500|Internal server error",
            error_type=ErrorType.API_ERROR,
            severity=ErrorSeverity.MEDIUM,
            recoverability=Recoverability.RETRY_WITH_BACKOFF,
            resolution_hint="Platform issue, retry shortly"
        ),
        ErrorPattern(
            pattern=r"503|Service unavailable",
            error_type=ErrorType.SERVICE_UNAVAILABLE,
            severity=ErrorSeverity.HIGH,
            recoverability=Recoverability.RETRY_WITH_BACKOFF,
            resolution_hint="Service down, retry with backoff"
        ),
        ErrorPattern(
            pattern=r"deprecated|End of life",
            error_type=ErrorType.API_DEPRECATED,
            severity=ErrorSeverity.CRITICAL,
            recoverability=Recoverability.UNRECOVERABLE,
            resolution_hint="Migrate to new API version"
        ),
    ]
    
    def __init__(
        self,
        data_dir: str = "data/media/errors",
        custom_patterns: Optional[List[ErrorPattern]] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.error_classifier")
        
        # Patterns
        self._patterns = self.DEFAULT_PATTERNS.copy()
        if custom_patterns:
            self._patterns.extend(custom_patterns)
        
        # Error history
        self._error_history: Dict[str, List[ClassifiedError]] = {}
        self._error_counts: Dict[ErrorType, int] = {}
        
        # Compiled regex patterns
        self._compiled_patterns: List[tuple] = []
        for p in self._patterns:
            try:
                compiled = re.compile(p.pattern, re.IGNORECASE)
                self._compiled_patterns.append((compiled, p))
            except re.error as e:
                self.logger.warning(f"Invalid pattern: {p.pattern} - {e}")
        
        self._load_history()
    
    def _load_history(self) -> None:
        """Load error history from disk."""
        history_file = self.data_dir / "error_history.json"
        if history_file.exists():
            with open(history_file) as f:
                data = json.load(f)
                for error_id, errors in data.items():
                    self._error_history[error_id] = [
                        ClassifiedError(**e) for e in errors
                    ]
    
    def _save_history(self) -> None:
        """Save error history to disk."""
        history_file = self.data_dir / "error_history.json"
        data = {}
        for error_id, errors in self._error_history.items():
            data[error_id] = [vars(e) for e in errors]
        
        with open(history_file, "w") as f:
            json.dump(data, f, indent=2)
    
    # =========================================================================
    # Classification
    # =========================================================================
    
    def classify(
        self,
        error: Exception or str,
        context: Optional[Dict[str, Any]] = None,
        http_status: Optional[int] = None,
        platform_code: Optional[str] = None
    ) -> ClassifiedError:
        """
        Classify an error.
        
        Args:
            error: The error to classify (Exception or string message)
            context: Additional context about where the error occurred
            http_status: HTTP status code if applicable
            platform_code: Platform-specific error code
            
        Returns:
            ClassifiedError with recovery info
        """
        # Extract error message
        if isinstance(error, Exception):
            error_message = str(error)
            error_type_name = type(error).__name__
        else:
            error_message = str(error)
            error_type_name = "Unknown"
        
        # Generate error ID
        error_hash = str(hash(error_message))[:16]
        error_id = f"err_{error_hash}_{int(time.time())}"
        
        # Try to match patterns
        for compiled, pattern in self._compiled_patterns:
            if compiled.search(error_message):
                classified = ClassifiedError(
                    error_id=error_id,
                    original_error=error_message,
                    error_type=pattern.error_type,
                    severity=pattern.severity,
                    recoverability=pattern.recoverability,
                    platform=context.get("platform") if context else None,
                    operation=context.get("operation", "") if context else "",
                    context=context or {},
                    resolution_hint=pattern.resolution_hint
                )
                
                # Update history
                self._record_error(classified)
                
                return classified
        
        # Check HTTP status
        if http_status:
            for compiled, pattern in self._compiled_patterns:
                if http_status in pattern.http_status_codes:
                    classified = ClassifiedError(
                        error_id=error_id,
                        original_error=error_message,
                        error_type=pattern.error_type,
                        severity=pattern.severity,
                        recoverability=pattern.recoverability,
                        context=context or {},
                        resolution_hint=pattern.resolution_hint
                    )
                    self._record_error(classified)
                    return classified
        
        # Default: unknown error
        classified = ClassifiedError(
            error_id=error_id,
            original_error=error_message,
            error_type=ErrorType.UNKNOWN_ERROR,
            severity=ErrorSeverity.MEDIUM,
            recoverability=Recoverability.RETRY_WITH_BACKOFF,
            context=context or {},
            resolution_hint="Review error and implement fix"
        )
        
        self._record_error(classified)
        return classified
    
    def _record_error(self, error: ClassifiedError) -> None:
        """Record error in history."""
        # Update counts
        self._error_counts[error.error_type] = self._error_counts.get(error.error_type, 0) + 1
        
        # Update history
        if error.error_type.value not in self._error_history:
            self._error_history[error.error_type.value] = []
        
        self._error_history[error.error_type.value].append(error)
        
        # Keep only recent errors (last 100 per type)
        if len(self._error_history[error.error_type.value]) > 100:
            self._error_history[error.error_type.value] = self._error_history[error.error_type.value][-100:]
        
        self._save_history()
    
    # =========================================================================
    # Error Analysis
    # =========================================================================
    
    def get_error_stats(
        self,
        since: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """Get error statistics."""
        since = since or (datetime.now() - timedelta(hours=24))
        
        recent_errors = []
        for errors in self._error_history.values():
            recent_errors.extend([e for e in errors if e.occurred_at >= since])
        
        by_type = {}
        by_severity = {}
        
        for error in recent_errors:
            by_type[error.error_type.value] = by_type.get(error.error_type.value, 0) + 1
            by_severity[error.severity.value] = by_severity.get(error.severity.value, 0) + 1
        
        return {
            "total_errors": len(recent_errors),
            "by_type": by_type,
            "by_severity": by_severity,
            "critical_count": by_severity.get("critical", 0),
            "unrecoverable_count": sum(
                1 for e in recent_errors if e.recoverability == Recoverability.UNRECOVERABLE
            )
        }
    
    def is_recurring(self, error_type: ErrorType, threshold: int = 3) -> bool:
        """Check if an error type is recurring."""
        recent = [
            e for e in self._error_history.get(error_type.value, [])
            if e.occurred_at >= datetime.now() - timedelta(minutes=30)
        ]
        return len(recent) >= threshold
    
    def get_recommended_action(self, error: ClassifiedError) -> str:
        """Get recommended action for a classified error."""
        if error.recoverability == Recoverability.AUTO_RETRY:
            return "retry"
        elif error.recoverability == Recoverability.RETRY_WITH_BACKOFF:
            base = 5  # seconds
            return f"retry_backoff_{base}"
        elif error.recoverability == Recoverability.MANUAL_RETRY:
            return "await_manual_fix"
        else:
            return "escalate_human"


def create_error_classifier(
    data_dir: str = "data/media/errors"
) -> ErrorClassifier:
    """Factory function."""
    return ErrorClassifier(data_dir=data_dir)
