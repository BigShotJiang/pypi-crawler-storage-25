"""
Health Monitor - System health checks and alerting.

Monitors:
- Account health scores
- API connectivity
- Content quality metrics
- Resource usage
"""
import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging


class HealthStatus(Enum):
    """Health status levels."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    CRITICAL = "critical"


class CheckType(Enum):
    """Types of health checks."""
    ACCOUNT_STATUS = "account_status"
    API_CONNECTIVITY = "api_connectivity"
    CONTENT_QUALITY = "content_quality"
    REVENUE_TREND = "revenue_trend"
    ENGAGEMENT_RATE = "engagement_rate"
    FOLLOWER_GROWTH = "follower_growth"
    POST_SUCCESS_RATE = "post_success_rate"


@dataclass
class HealthCheck:
    """A single health check."""
    check_id: str
    check_type: CheckType
    
    # Status
    status: HealthStatus = HealthStatus.HEALTHY
    
    # Details
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    
    # Thresholds
    warning_threshold: float = 0.8
    critical_threshold: float = 0.5
    
    # Timing
    last_checked: datetime = field(default_factory=datetime.now)
    check_duration_ms: float = 0.0
    
    # History
    failure_count: int = 0
    last_failure_at: Optional[datetime] = None


@dataclass
class ChannelHealth:
    """Overall health of a channel."""
    channel_id: str
    channel_name: str
    
    # Overall status
    status: HealthStatus = HealthStatus.HEALTHY
    health_score: float = 1.0  # 0.0 - 1.0
    
    # Individual checks
    checks: Dict[str, HealthCheck] = field(default_factory=dict)
    
    # Trends
    trend: str = "stable"  # improving, stable, declining
    trend_days: int = 7
    
    # Recommendations
    issues: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    # Timing
    last_full_check: datetime = field(default_factory=datetime.now)
    last_alert_at: Optional[datetime] = None


class HealthMonitor:
    """
    Health monitoring for media empire.
    
    Runs periodic health checks and alerts on issues.
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/health"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.health_monitor")
        
        # Channel health
        self._channel_health: Dict[str, ChannelHealth] = {}
        
        # Check functions
        self._check_functions: Dict[CheckType, Callable] = {}
        self._register_default_checks()
        
        # Monitoring
        self._monitoring: bool = False
        self._monitor_task: Optional[asyncio.Task] = None
        
        # Alert callbacks
        self._alert_callbacks: List[Callable] = []
        
        # Config
        self.check_interval_seconds: int = 300  # 5 minutes
        
        self._load_state()
    
    def _load_state(self) -> None:
        """Load health state from disk."""
        state_file = self.data_dir / "health_state.json"
        if state_file.exists():
            with open(state_file) as f:
                data = json.load(f)
                for cid, health_data in data.items():
                    health_data["last_full_check"] = datetime.fromisoformat(health_data["last_full_check"])
                    if health_data.get("last_alert_at"):
                        health_data["last_alert_at"] = datetime.fromisoformat(health_data["last_alert_at"])
                    self._channel_health[cid] = ChannelHealth(**health_data)
    
    def _save_state(self) -> None:
        """Save health state to disk."""
        state_file = self.data_dir / "health_state.json"
        data = {}
        for cid, health in self._channel_health.items():
            data[cid] = {
                **vars(health),
                "last_full_check": health.last_full_check.isoformat(),
                "last_alert_at": health.last_alert_at.isoformat() if health.last_alert_at else None
            }
        
        with open(state_file, "w") as f:
            json.dump(data, f, indent=2)
    
    def _register_default_checks(self) -> None:
        """Register default health check functions."""
        self._check_functions[CheckType.ACCOUNT_STATUS] = self._check_account_status
        self._check_functions[CheckType.API_CONNECTIVITY] = self._check_api_connectivity
        self._check_functions[CheckType.POST_SUCCESS_RATE] = self._check_post_success_rate
        self._check_functions[CheckType.ENGAGEMENT_RATE] = self._check_engagement_rate
        self._check_functions[CheckType.REVENUE_TREND] = self._check_revenue_trend
    
    # =========================================================================
    # Health Checks
    # =========================================================================
    
    async def check_channel(self, channel_id: str) -> ChannelHealth:
        """Run all health checks for a channel."""
        health = self._channel_health.get(channel_id, ChannelHealth(
            channel_id=channel_id,
            channel_name=channel_id
        ))
        
        total_score = 0.0
        check_count = 0
        
        for check_type, check_func in self._check_functions.items():
            check = await self._run_check(check_type, channel_id, check_func)
            health.checks[check_type.value] = check
            total_score += self._score_from_status(check.status)
            check_count += 1
        
        health.health_score = total_score / max(check_count, 1)
        health.status = self._status_from_score(health.health_score)
        health.last_full_check = datetime.now()
        
        # Generate recommendations
        health.issues = self._generate_issues(health)
        health.recommendations = self._generate_recommendations(health)
        
        # Check trend
        health.trend = self._calculate_trend(channel_id)
        
        self._channel_health[channel_id] = health
        self._save_state()
        
        # Alert if needed
        if health.status in [HealthStatus.UNHEALTHY, HealthStatus.CRITICAL]:
            await self._send_alert(health)
        
        return health
    
    async def _run_check(
        self,
        check_type: CheckType,
        channel_id: str,
        check_func: Callable
    ) -> HealthCheck:
        """Run a single health check."""
        check = HealthCheck(
            check_id=f"{check_type.value}_{channel_id}",
            check_type=check_type
        )
        
        start = datetime.now()
        
        try:
            result = await check_func(channel_id)
            check.status = result.get("status", HealthStatus.HEALTHY)
            check.message = result.get("message", "")
            check.details = result.get("details", {})
        except Exception as e:
            check.status = HealthStatus.UNHEALTHY
            check.message = str(e)
            check.failure_count += 1
            check.last_failure_at = datetime.now()
        
        check.last_checked = datetime.now()
        check.check_duration_ms = (datetime.now() - start).total_seconds() * 1000
        
        return check
    
    def _score_from_status(self, status: HealthStatus) -> float:
        """Convert status to score."""
        scores = {
            HealthStatus.HEALTHY: 1.0,
            HealthStatus.DEGRADED: 0.6,
            HealthStatus.UNHEALTHY: 0.3,
            HealthStatus.CRITICAL: 0.0
        }
        return scores.get(status, 0.5)
    
    def _status_from_score(self, score: float) -> HealthStatus:
        """Convert score to status."""
        if score >= 0.8:
            return HealthStatus.HEALTHY
        elif score >= 0.6:
            return HealthStatus.DEGRADED
        elif score >= 0.3:
            return HealthStatus.UNHEALTHY
        else:
            return HealthStatus.CRITICAL
    
    # =========================================================================
    # Individual Check Functions
    # =========================================================================
    
    async def _check_account_status(self, channel_id: str) -> Dict[str, Any]:
        """Check if account is in good standing."""
        # In production, would check actual account status
        return {
            "status": HealthStatus.HEALTHY,
            "message": "Account in good standing",
            "details": {"verified": True, "standing": "good"}
        }
    
    async def _check_api_connectivity(self, channel_id: str) -> Dict[str, Any]:
        """Check API connectivity to platforms."""
        # In production, would ping actual APIs
        return {
            "status": HealthStatus.HEALTHY,
            "message": "All APIs accessible",
            "details": {"latency_ms": 150}
        }
    
    async def _check_post_success_rate(self, channel_id: str) -> Dict[str, Any]:
        """Check posting success rate."""
        # In production, would analyze actual post data
        return {
            "status": HealthStatus.HEALTHY,
            "message": "Success rate: 95%",
            "details": {"success_rate": 0.95, "failed_posts_24h": 1}
        }
    
    async def _check_engagement_rate(self, channel_id: str) -> Dict[str, Any]:
        """Check engagement rate."""
        # In production, would compare to benchmarks
        return {
            "status": HealthStatus.DEGRADED,
            "message": "Engagement below average",
            "details": {"current_rate": 0.03, "benchmark_rate": 0.05}
        }
    
    async def _check_revenue_trend(self, channel_id: str) -> Dict[str, Any]:
        """Check revenue trend."""
        return {
            "status": HealthStatus.HEALTHY,
            "message": "Revenue growing",
            "details": {"trend": "up", "growth_percent": 15}
        }
    
    # =========================================================================
    # Analysis
    # =========================================================================
    
    def _generate_issues(self, health: ChannelHealth) -> List[str]:
        """Generate list of issues from health checks."""
        issues = []
        
        for check in health.checks.values():
            if check.status in [HealthStatus.UNHEALTHY, HealthStatus.CRITICAL]:
                issues.append(f"{check.check_type.value}: {check.message}")
        
        return issues
    
    def _generate_recommendations(self, health: ChannelHealth) -> List[str]:
        """Generate recommendations based on health status."""
        recommendations = []
        
        for check_type, check in health.checks.items():
            if check.status == HealthStatus.DEGRADED:
                if check_type == CheckType.ENGAGEMENT_RATE.value:
                    recommendations.append("Test new content formats to boost engagement")
                elif check_type == CheckType.REVENUE_TREND.value:
                    recommendations.append("Review monetization strategy")
            elif check.status in [HealthStatus.UNHEALTHY, HealthStatus.CRITICAL]:
                recommendations.append(f"URGENT: Address {check.message}")
        
        return recommendations
    
    def _calculate_trend(self, channel_id: str) -> str:
        """Calculate health trend over time."""
        # In production, would compare historical scores
        return "stable"
    
    # =========================================================================
    # Alerting
    # =========================================================================
    
    def register_alert_callback(self, callback: Callable) -> None:
        """Register a callback for health alerts."""
        self._alert_callbacks.append(callback)
    
    async def _send_alert(self, health: ChannelHealth) -> None:
        """Send alert for unhealthy channel."""
        # Rate limit alerts
        if health.last_alert_at:
            if (datetime.now() - health.last_alert_at).total_seconds() < 3600:
                return  # Already alerted recently
        
        health.last_alert_at = datetime.now()
        
        for callback in self._alert_callbacks:
            try:
                await callback(health)
            except Exception as e:
                self.logger.error(f"Alert callback failed: {e}")
    
    # =========================================================================
    # Monitoring Loop
    # =========================================================================
    
    async def start_monitoring(self, channel_ids: List[str]) -> None:
        """Start continuous monitoring for channels."""
        self._monitoring = True
        
        while self._monitoring:
            for channel_id in channel_ids:
                await self.check_channel(channel_id)
            
            await asyncio.sleep(self.check_interval_seconds)
    
    async def stop_monitoring(self) -> None:
        """Stop monitoring."""
        self._monitoring = False
    
    # =========================================================================
    # Accessors
    # =========================================================================
    
    def get_channel_health(self, channel_id: str) -> Optional[ChannelHealth]:
        """Get health for a channel."""
        return self._channel_health.get(channel_id)
    
    def get_all_health(self) -> Dict[str, ChannelHealth]:
        """Get health for all channels."""
        return self._channel_health
    
    def get_unhealthy_channels(self) -> List[ChannelHealth]:
        """Get all unhealthy channels."""
        return [
            h for h in self._channel_health.values()
            if h.status in [HealthStatus.UNHEALTHY, HealthStatus.CRITICAL]
        ]


def create_health_monitor(data_dir: str = "data/media/health") -> HealthMonitor:
    """Factory function."""
    return HealthMonitor(data_dir=data_dir)
