"""
Recovery Policies - Automated error recovery strategies.

Defines and executes recovery actions based on error classification.
"""
import asyncio
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable, Awaitable
import logging


class RecoveryAction(Enum):
    """Types of recovery actions."""
    # Retry actions
    RETRY_IMMEDIATE = "retry_immediate"
    RETRY_WITH_BACKOFF = "retry_with_backoff"
    RETRY_WITH_JITTER = "retry_with_jitter"
    
    # Token management
    REFRESH_TOKEN = "refresh_token"
    REAUTHENTICATE = "reauthenticate"
    
    # Content recovery
    MODIFY_CONTENT = "modify_content"
    REMOVE_CONTENT = "remove_content"
    REDUCE_CONTENT_LENGTH = "reduce_content_length"
    
    # Platform recovery
    SWITCH_API_ENDPOINT = "switch_api_endpoint"
    USE_FALLBACK_PLATFORM = "use_fallback_platform"
    REDUCE_POSTING_FREQUENCY = "reduce_posting_frequency"
    
    # Account recovery
    APPEAL_SUSPENSION = "appeal_suspension"
    CREATE_BACKUP_ACCOUNT = "create_backup_account"
    
    # Escalation
    ESCALATE_HUMAN = "escalate_human"
    NOTIFY_TEAM = "notify_team"
    CREATE_TICKET = "create_ticket"
    
    # System recovery
    RESTART_COMPONENT = "restart_component"
    CLEAR_CACHE = "clear_cache"
    INCREASE_RESOURCES = "increase_resources"


@dataclass
class RecoveryPolicy:
    """A recovery policy for a specific error type or condition."""
    policy_id: str
    name: str
    description: str
    
    # Trigger conditions
    error_types: List[str] = field(default_factory=list)  # ErrorType values
    conditions: Dict[str, Any] = field(default_factory=dict)  # Additional conditions
    
    # Actions to take (in order)
    actions: List[RecoveryAction] = field(default_factory=list)
    
    # Retry config
    max_retries: int = 3
    base_delay_seconds: float = 1.0
    max_delay_seconds: float = 300.0
    backoff_multiplier: float = 2.0
    jitter: bool = True
    
    # After recovery
    on_success: str = "resume"  # resume, continue_next, stop
    on_failure: str = "escalate"  # escalate, stop, fallback
    
    # Validation
    validate_after_recovery: bool = True
    validation_timeout_seconds: float = 30.0


@dataclass
class RecoveryResult:
    """Result of a recovery attempt."""
    success: bool
    policy_id: str
    error_id: str
    
    # Actions taken
    actions_attempted: List[RecoveryAction] = field(default_factory=list)
    actions_succeeded: List[RecoveryAction] = field(default_factory=list)
    actions_failed: List[RecoveryAction] = field(default_factory=list)
    
    # Timing
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    total_duration_seconds: float = 0.0
    
    # Outcome
    error_message: Optional[str] = None
    recovery_data: Dict[str, Any] = field(default_factory=dict)
    
    # Next steps
    should_retry: bool = False
    should_escalate: bool = False
    next_retry_at: Optional[datetime] = None


class RecoveryPolicyRegistry:
    """
    Registry of recovery policies and execution engine.
    """
    
    # Default policies
    DEFAULT_POLICIES: List[RecoveryPolicy] = [
        RecoveryPolicy(
            policy_id="transient_error",
            name="Transient Error Recovery",
            description="Retry transient errors with exponential backoff",
            error_types=["timeout", "network_error", "api_error", "service_unavailable"],
            actions=[RecoveryAction.RETRY_WITH_BACKOFF],
            max_retries=5,
            base_delay_seconds=2.0,
            max_delay_seconds=120.0
        ),
        RecoveryPolicy(
            policy_id="rate_limit",
            name="Rate Limit Recovery",
            description="Handle rate limiting with backoff",
            error_types=["rate_limit"],
            actions=[RecoveryAction.REDUCE_POSTING_FREQUENCY, RecoveryAction.RETRY_WITH_BACKOFF],
            max_retries=3,
            base_delay_seconds=60.0,
            max_delay_seconds=3600.0
        ),
        RecoveryPolicy(
            policy_id="auth_error",
            name="Authentication Error Recovery",
            description="Refresh tokens or reauthenticate",
            error_types=["token_expired", "authentication_failed"],
            actions=[RecoveryAction.REFRESH_TOKEN],
            max_retries=2,
            on_failure="escalate"
        ),
        RecoveryPolicy(
            policy_id="content_violation",
            name="Content Violation Recovery",
            description="Handle content policy violations",
            error_types=["content_policy_violation", "copyright_claim", "nsfw_detected"],
            actions=[RecoveryAction.MODIFY_CONTENT, RecoveryAction.ESCALATE_HUMAN],
            max_retries=1,
            on_failure="escalate"
        ),
        RecoveryPolicy(
            policy_id="account_suspended",
            name="Account Suspension Recovery",
            description="Handle account suspension",
            error_types=["account_suspended"],
            actions=[RecoveryAction.APPEAL_SUSPENSION, RecoveryAction.CREATE_BACKUP_ACCOUNT],
            max_retries=1,
            on_failure="escalate"
        ),
        RecoveryPolicy(
            policy_id="quota_exceeded",
            name="Quota Exceeded Recovery",
            description="Handle quota/limit exceeded",
            error_types=["quota_exceeded"],
            actions=[RecoveryAction.REDUCE_POSTING_FREQUENCY, RecoveryAction.RETRY_WITH_BACKOFF],
            max_retries=5,
            base_delay_seconds=300.0,
            max_delay_seconds=86400.0
        ),
        RecoveryPolicy(
            policy_id="critical_failure",
            name="Critical Failure Escalation",
            description="Escalate critical failures immediately",
            error_types=["account_banned", "api_deprecated"],
            actions=[RecoveryAction.ESCALATE_HUMAN, RecoveryAction.NOTIFY_TEAM],
            max_retries=0,
            on_failure="stop"
        ),
    ]
    
    def __init__(
        self,
        data_dir: str = "data/media/recovery"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.recovery_policies")
        
        # Policies
        self._policies: Dict[str, RecoveryPolicy] = {}
        for policy in self.DEFAULT_POLICIES:
            self._policies[policy.policy_id] = policy
        
        # Recovery handlers
        self._handlers: Dict[RecoveryAction, Callable] = {}
        self._register_default_handlers()
        
        # Stats
        self._recovery_stats: Dict[str, int] = {}
    
    def _register_default_handlers(self) -> None:
        """Register default recovery action handlers."""
        self._handlers[RecoveryAction.RETRY_IMMEDIATE] = self._handle_retry_immediate
        self._handlers[RecoveryAction.RETRY_WITH_BACKOFF] = self._handle_retry_backoff
        self._handlers[RecoveryAction.REFRESH_TOKEN] = self._handle_refresh_token
        self._handlers[RecoveryAction.REDUCE_POSTING_FREQUENCY] = self._handle_reduce_frequency
        self._handlers[RecoveryAction.ESCALATE_HUMAN] = self._handle_escalate_human
        self._handlers[RecoveryAction.NOTIFY_TEAM] = self._handle_notify_team
    
    # =========================================================================
    # Policy Management
    # =========================================================================
    
    def get_policy(self, policy_id: str) -> Optional[RecoveryPolicy]:
        """Get a policy by ID."""
        return self._policies.get(policy_id)
    
    def add_policy(self, policy: RecoveryPolicy) -> None:
        """Add a custom policy."""
        self._policies[policy.policy_id] = policy
    
    def find_policy(self, error_type: str) -> Optional[RecoveryPolicy]:
        """Find a policy for an error type."""
        for policy in self._policies.values():
            if error_type in policy.error_types:
                return policy
        return self._policies.get("transient_error")
    
    # =========================================================================
    # Recovery Execution
    # =========================================================================
    
    async def execute_recovery(
        self,
        policy_id: str,
        error_id: str,
        context: Dict[str, Any]
    ) -> RecoveryResult:
        """
        Execute recovery for an error.
        
        Args:
            policy_id: ID of the recovery policy to use
            error_id: ID of the classified error
            context: Context including the operation to retry
            
        Returns:
            RecoveryResult with outcome
        """
        policy = self._policies.get(policy_id)
        if not policy:
            return RecoveryResult(
                success=False,
                policy_id=policy_id,
                error_id=error_id,
                error_message=f"Policy not found: {policy_id}"
            )
        
        result = RecoveryResult(
            policy_id=policy_id,
            error_id=error_id
        )
        
        self.logger.info(f"Executing recovery: {policy.name} for {error_id}")
        
        for action in policy.actions:
            result.actions_attempted.append(action)
            
            handler = self._handlers.get(action)
            if not handler:
                self.logger.warning(f"No handler for action: {action}")
                result.actions_failed.append(action)
                continue
            
            try:
                action_result = await handler(context, policy)
                
                if action_result.get("success"):
                    result.actions_succeeded.append(action)
                    result.recovery_data.update(action_result)
                else:
                    result.actions_failed.append(action)
                    result.error_message = action_result.get("error", "Action failed")
                    
                    if policy.on_failure == "escalate":
                        result.should_escalate = True
                        break
                    elif policy.on_failure == "stop":
                        break
                        
            except Exception as e:
                self.logger.error(f"Recovery action failed: {action} - {e}")
                result.actions_failed.append(action)
                result.error_message = str(e)
        
        # Calculate retry if needed
        if not result.success and result.actions_succeeded:
            result.should_retry = True
            retry_delay = self._calculate_backoff(policy, len(result.actions_succeeded))
            result.next_retry_at = datetime.now() + timedelta(seconds=retry_delay)
        
        result.completed_at = datetime.now()
        result.total_duration_seconds = (result.completed_at - result.started_at).total_seconds()
        
        # Update stats
        self._recovery_stats[policy_id] = self._recovery_stats.get(policy_id, 0) + 1
        
        return result
    
    def _calculate_backoff(
        self,
        policy: RecoveryPolicy,
        retry_count: int
    ) -> float:
        """Calculate backoff delay."""
        delay = policy.base_delay_seconds * (policy.backoff_multiplier ** retry_count)
        delay = min(delay, policy.max_delay_seconds)
        
        if policy.jitter:
            import random
            delay = delay * (0.5 + random.random() * 0.5)
        
        return delay
    
    # =========================================================================
    # Default Handlers
    # =========================================================================
    
    async def _handle_retry_immediate(
        self,
        context: Dict[str, Any],
        policy: RecoveryPolicy
    ) -> Dict[str, Any]:
        """Handle immediate retry."""
        operation = context.get("operation")
        if not operation:
            return {"success": False, "error": "No operation to retry"}
        
        try:
            # Execute the operation
            if asyncio.iscoroutinefunction(operation):
                result = await operation()
            else:
                result = operation()
            
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _handle_retry_backoff(
        self,
        context: Dict[str, Any],
        policy: RecoveryPolicy
    ) -> Dict[str, Any]:
        """Handle retry with backoff."""
        retry_count = context.get("retry_count", 0)
        delay = self._calculate_backoff(policy, retry_count)
        
        self.logger.info(f"Retrying after {delay:.1f}s (attempt {retry_count + 1})")
        
        await asyncio.sleep(delay)
        
        context["retry_count"] = retry_count + 1
        return await self._handle_retry_immediate(context, policy)
    
    async def _handle_refresh_token(
        self,
        context: Dict[str, Any],
        policy: RecoveryPolicy
    ) -> Dict[str, Any]:
        """Handle token refresh."""
        oauth_manager = context.get("oauth_manager")
        platform = context.get("platform")
        
        if not oauth_manager or not platform:
            return {"success": False, "error": "Missing oauth_manager or platform"}
        
        try:
            # Refresh the token
            result = await oauth_manager.refresh_token(platform)
            return {"success": result, "refreshed": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _handle_reduce_frequency(
        self,
        context: Dict[str, Any],
        policy: RecoveryPolicy
    ) -> Dict[str, Any]:
        """Handle reducing posting frequency."""
        channel_id = context.get("channel_id")
        current_frequency = context.get("posts_per_day", 2)
        
        # Reduce by 50%
        new_frequency = max(1, current_frequency // 2)
        
        self.logger.info(f"Reducing posting frequency: {current_frequency} -> {new_frequency}")
        
        return {
            "success": True,
            "reduced_frequency": True,
            "new_posts_per_day": new_frequency
        }
    
    async def _handle_escalate_human(
        self,
        context: Dict[str, Any],
        policy: RecoveryPolicy
    ) -> Dict[str, Any]:
        """Handle human escalation."""
        from simp.organs.media.approval_gates import ApprovalGate, GateType, ApprovalPriority
        
        gate = ApprovalGate()
        
        gate.create_request(
            gate_type=GateType.LEGAL_REVIEW,
            channel_id=context.get("channel_id", ""),
            channel_name=context.get("channel_name", ""),
            action="error_recovery",
            title=f"Critical Error: {context.get('error_type', 'Unknown')}",
            description=context.get("error_message", ""),
            payload=context,
            priority=ApprovalPriority.URGENT
        )
        
        return {"success": True, "escalated": True}
    
    async def _handle_notify_team(
        self,
        context: Dict[str, Any],
        policy: RecoveryPolicy
    ) -> Dict[str, Any]:
        """Handle team notification."""
        # In production, would send Slack/email notification
        self.logger.warning(f"Team notification: {context.get('error_message', 'Error occurred')}")
        return {"success": True, "notified": True}


# Convenience function
async def execute_recovery(
    policy_id: str,
    error_id: str,
    context: Dict[str, Any]
) -> RecoveryResult:
    """Execute a recovery policy."""
    registry = RecoveryPolicyRegistry()
    return await registry.execute_recovery(policy_id, error_id, context)
