"""
Self-Healing System for Autonomous Media Empire.

Provides autonomous error recovery and system resilience.
"""
from simp.organs.media.self_healing.error_classifier import (
    ErrorClassifier,
    ErrorType,
    ErrorSeverity,
    ClassifiedError,
    create_error_classifier
)
from simp.organs.media.self_healing.recovery_policies import (
    RecoveryPolicy,
    RecoveryPolicyRegistry,
    RecoveryResult,
    RecoveryAction,
    execute_recovery
)
from simp.organs.media.self_healing.circuit_breaker import (
    CircuitBreaker,
    CircuitState,
    create_circuit_breaker
)
from simp.organs.media.self_healing.health_monitor import (
    HealthMonitor,
    HealthStatus,
    HealthCheck,
    create_health_monitor
)

__version__ = "0.1.0"
__all__ = [
    "ErrorClassifier",
    "ErrorType",
    "ErrorSeverity",
    "ClassifiedError",
    "create_error_classifier",
    "RecoveryPolicy",
    "RecoveryPolicyRegistry",
    "RecoveryResult",
    "RecoveryAction",
    "execute_recovery",
    "CircuitBreaker",
    "CircuitState",
    "create_circuit_breaker",
    "HealthMonitor",
    "HealthStatus",
    "HealthCheck",
    "create_health_monitor"
]
