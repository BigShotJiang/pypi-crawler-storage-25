"""
Affiliate Link Tracker for Media Empire.

Manages:
- Affiliate link generation and tracking
- Click/conversion attribution
- Commission aggregation
- Link-in-bio automation (Linktree API)
"""
import asyncio
import json
import time
import uuid
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging
import httpx

from simp.organs.media.account_creation.account_creator import PlatformCredentials
from simp.organs.media.platform_oauth_manager import Platform


class AffiliateNetwork(Enum):
    """Supported affiliate networks."""
    AMAZON_ASSOCIATES = "amazon"
    IMPACT = "impact"
    SHAREASALE = "shareasale"
    CJ_AFFILIATE = "cj"
    CUSTOM = "custom"


class LinkStatus(Enum):
    """Status of affiliate link."""
    ACTIVE = "active"
    PAUSED = "paused"
    EXPIRED = "expired"
    FLAGGED = "flagged"


@dataclass
class AffiliateLink:
    """An affiliate link."""
    link_id: str
    network: AffiliateNetwork
    offer_id: str
    
    # Link info
    original_url: str
    affiliate_url: str
    short_code: str  # For tracking
    
    # Product info
    product_name: str
    product_category: str
    price: Optional[float] = None
    
    # Commission
    commission_rate: float = 0.0
    commission_amount: float = 0.0
    currency: str = "USD"
    
    # Tracking
    clicks: int = 0
    conversions: int = 0
    revenue: float = 0.0
    
    # Status
    status: LinkStatus = LinkStatus.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None


@dataclass
class ConversionEvent:
    """A conversion event from affiliate link."""
    event_id: str
    link_id: str
    platform: Platform
    
    # Attribution
    click_id: str
    utm_source: str = ""
    utm_medium: str = ""
    utm_campaign: str = ""
    
    # Conversion
    order_id: str = ""
    order_value: float = 0.0
    commission: float = 0.0
    
    # Timing
    clicked_at: Optional[datetime] = None
    converted_at: datetime = field(default_factory=datetime.now)


@dataclass
class AffiliateReport:
    """Affiliate performance report."""
    network: AffiliateNetwork
    period_start: datetime
    period_end: datetime
    
    # Aggregates
    total_links: int = 0
    total_clicks: int = 0
    total_conversions: int = 0
    total_revenue: float = 0.0
    total_commission: float = 0.0
    
    # Calculated
    conversion_rate: float = 0.0
    ctr: float = 0.0  # Click-through rate
    rpc: float = 0.0  # Revenue per click
    
    # Top performers
    top_links: List[Dict[str, Any]] = field(default_factory=list)
    top_platform: Optional[Platform] = None


class AffiliateTracker:
    """
    Affiliate link management and tracking.
    
    Handles:
    - Link generation via network APIs
    - Click tracking with UTM parameters
    - Conversion attribution
    - Commission aggregation
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/affiliate",
        linktree_token: Optional[str] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.affiliate")
        
        self.linktree_token = linktree_token
        self._client: Optional[httpx.AsyncClient] = None
        
        # Storage
        self._links: Dict[str, AffiliateLink] = {}
        self._conversions: Dict[str, ConversionEvent] = {}
        self._load_data()
    
    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=30.0)
        return self._client
    
    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
    
    def _load_data(self) -> None:
        """Load affiliate data from disk."""
        links_file = self.data_dir / "links.json"
        conversions_file = self.data_dir / "conversions.jsonl"
        
        if links_file.exists():
            with open(links_file) as f:
                data = json.load(f)
                for link_data in data.values():
                    link_data["created_at"] = datetime.fromisoformat(link_data["created_at"])
                    if link_data.get("expires_at"):
                        link_data["expires_at"] = datetime.fromisoformat(link_data["expires_at"])
                    self._links[link_data["link_id"]] = AffiliateLink(**link_data)
        
        if conversions_file.exists():
            with open(conversions_file) as f:
                for line in f:
                    event_data = json.loads(line)
                    event_data["converted_at"] = datetime.fromisoformat(event_data["converted_at"])
                    if event_data.get("clicked_at"):
                        event_data["clicked_at"] = datetime.fromisoformat(event_data["clicked_at"])
                    event = ConversionEvent(**event_data)
                    self._conversions[event.event_id] = event
    
    def _save_data(self) -> None:
        """Save affiliate data to disk."""
        links_data = {
            lid: {
                **vars(link),
                "created_at": link.created_at.isoformat(),
                "expires_at": link.expires_at.isoformat() if link.expires_at else None
            }
            for lid, link in self._links.items()
        }
        
        with open(self.data_dir / "links.json", "w") as f:
            json.dump(links_data, f, indent=2)
        
        with open(self.data_dir / "conversions.jsonl", "w") as f:
            for event in self._conversions.values():
                event_dict = {
                    **vars(event),
                    "converted_at": event.converted_at.isoformat(),
                    "clicked_at": event.clicked_at.isoformat() if event.clicked_at else None
                }
                f.write(json.dumps(event_dict) + "\n")
    
    # =========================================================================
    # Link Management
    # =========================================================================
    
    def generate_tracking_code(self, link_id: str, platform: Platform) -> str:
        """Generate unique tracking code for link."""
        raw = f"{link_id}:{platform.value}:{time.time()}"
        return hashlib.md5(raw.encode()).hexdigest()[:8]
    
    async def create_affiliate_link(
        self,
        network: AffiliateNetwork,
        original_url: str,
        offer_id: str,
        product_name: str,
        product_category: str,
        commission_rate: float = 0.0,
        price: Optional[float] = None,
        platform: Optional[Platform] = None
    ) -> AffiliateLink:
        """Create a new affiliate link."""
        link_id = f"aff_{uuid.uuid4().hex[:8]}"
        short_code = self.generate_tracking_code(link_id, platform or Platform.X)
        
        # Build affiliate URL (simplified - real impl would call network API)
        affiliate_url = self._build_affiliate_url(network, offer_id, original_url)
        
        link = AffiliateLink(
            link_id=link_id,
            network=network,
            offer_id=offer_id,
            original_url=original_url,
            affiliate_url=affiliate_url,
            short_code=short_code,
            product_name=product_name,
            product_category=product_category,
            price=price,
            commission_rate=commission_rate
        )
        
        self._links[link_id] = link
        self._save_data()
        
        self.logger.info(f"Created affiliate link: {link_id} ({network.value})")
        return link
    
    def _build_affiliate_url(
        self,
        network: AffiliateNetwork,
        offer_id: str,
        original_url: str
    ) -> str:
        """Build affiliate URL based on network."""
        builders = {
            AffiliateNetwork.AMAZON_ASSOCIATES: lambda: f"https://www.amazon.com/dp/product?tag=YOUR_TAG&linkCode=ll2",
            AffiliateNetwork.IMPACT: lambda: f"https://{offer_id}.impact.com/click",
            AffiliateNetwork.CUSTOM: lambda: f"{original_url}?ref={offer_id}"
        }
        return builders.get(network, builders[AffiliateNetwork.CUSTOM])()
    
    async def get_link(self, link_id: str) -> Optional[AffiliateLink]:
        """Get affiliate link by ID."""
        return self._links.get(link_id)
    
    async def get_links_by_category(self, category: str) -> List[AffiliateLink]:
        """Get all links in a category."""
        return [l for l in self._links.values() if l.product_category == category]
    
    async def pause_link(self, link_id: str) -> bool:
        """Pause an affiliate link."""
        link = self._links.get(link_id)
        if link:
            link.status = LinkStatus.PAUSED
            self._save_data()
            return True
        return False
    
    # =========================================================================
    # Tracking & Attribution
    # =========================================================================
    
    def generate_tracked_url(
        self,
        link_id: str,
        platform: Platform,
        utm_source: str = "",
        utm_medium: str = "",
        utm_campaign: str = ""
    ) -> str:
        """Generate a tracked URL with UTM parameters."""
        link = self._links.get(link_id)
        if not link:
            return ""
        
        base_url = link.affiliate_url
        params = [
            f"utm_source={utm_source or platform.value}",
            f"utm_medium=affiliate",
            f"utm_campaign={utm_campaign or link.product_category}",
            f"ref={link.short_code}"
        ]
        
        separator = "&" if "?" in base_url else "?"
        return f"{base_url}{separator}{'&'.join(params)}"
    
    async def record_click(
        self,
        link_id: str,
        platform: Platform,
        utm_params: Optional[Dict[str, str]] = None
    ) -> str:
        """Record a click on affiliate link."""
        link = self._links.get(link_id)
        if not link:
            return ""
        
        click_id = f"clk_{uuid.uuid4().hex[:8]}"
        
        # Increment click count
        link.clicks += 1
        
        self.logger.info(f"Click recorded: {click_id} -> {link_id} ({platform.value})")
        self._save_data()
        
        return click_id
    
    async def record_conversion(
        self,
        link_id: str,
        click_id: str,
        platform: Platform,
        order_id: str,
        order_value: float
    ) -> ConversionEvent:
        """Record a conversion event."""
        link = self._links.get(link_id)
        if not link:
            raise ValueError(f"Link not found: {link_id}")
        
        event_id = f"conv_{uuid.uuid4().hex[:8]}"
        
        # Calculate commission
        commission = order_value * link.commission_rate
        
        event = ConversionEvent(
            event_id=event_id,
            link_id=link_id,
            platform=platform,
            click_id=click_id,
            order_id=order_id,
            order_value=order_value,
            commission=commission,
            converted_at=datetime.now()
        )
        
        # Update link stats
        link.conversions += 1
        link.revenue += order_value
        link.commission_amount += commission
        
        self._conversions[event_id] = event
        self._save_data()
        
        self.logger.info(f"Conversion recorded: {event_id} - ${commission:.2f}")
        return event
    
    # =========================================================================
    # Reporting
    # =========================================================================
    
    async def get_report(
        self,
        network: Optional[AffiliateNetwork] = None,
        period_days: int = 30
    ) -> AffiliateReport:
        """Generate affiliate performance report."""
        period_start = datetime.now() - timedelta(days=period_days)
        period_end = datetime.now()
        
        # Filter links by network
        links = list(self._links.values())
        if network:
            links = [l for l in links if l.network == network]
        
        # Get conversions in period
        conversions = [
            c for c in self._conversions.values()
            if c.converted_at >= period_start
        ]
        
        total_clicks = sum(l.clicks for l in links)
        total_conversions = sum(l.conversions for l in links)
        total_revenue = sum(l.revenue for l in links)
        total_commission = sum(l.commission_amount for l in links)
        
        # Find top links
        sorted_links = sorted(links, key=lambda l: l.commission_amount, reverse=True)
        top_links = [
            {
                "link_id": l.link_id,
                "product_name": l.product_name,
                "clicks": l.clicks,
                "conversions": l.conversions,
                "commission": l.commission_amount
            }
            for l in sorted_links[:5]
        ]
        
        report = AffiliateReport(
            network=network or AffiliateNetwork.CUSTOM,
            period_start=period_start,
            period_end=period_end,
            total_links=len(links),
            total_clicks=total_clicks,
            total_conversions=total_conversions,
            total_revenue=total_revenue,
            total_commission=total_commission,
            conversion_rate=total_conversions / total_clicks if total_clicks > 0 else 0.0,
            ctr=total_clicks / total_conversions if total_conversions > 0 else 0.0,
            rpc=total_revenue / total_clicks if total_clicks > 0 else 0.0,
            top_links=top_links
        )
        
        return report
    
    # =========================================================================
    # Link-in-Bio Integration
    # =========================================================================
    
    async def update_linktree(
        self,
        channel_id: str,
        platform: Platform
    ) -> bool:
        """Update Linktree with current affiliate links."""
        if not self.linktree_token:
            self.logger.warning("Linktree token not configured")
            return False
        
        try:
            # Get active links
            active_links = [l for l in self._links.values() if l.status == LinkStatus.ACTIVE]
            
            # Build Linktree items
            items = [
                {
                    "url": link.affiliate_url,
                    "title": link.product_name,
                    "key": link.short_code
                }
                for link in active_links[:15]  # Linktree limit
            ]
            
            # Update Linktree (simplified API call)
            response = await self.client.post(
                "https://api.linktree.com/v1/links",
                headers={
                    "Authorization": f"Bearer {self.linktree_token}",
                    "Content-Type": "application/json"
                },
                json={"links": items}
            )
            
            if response.status_code == 200:
                self.logger.info(f"Updated Linktree for {channel_id}")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Failed to update Linktree: {e}")
            return False
