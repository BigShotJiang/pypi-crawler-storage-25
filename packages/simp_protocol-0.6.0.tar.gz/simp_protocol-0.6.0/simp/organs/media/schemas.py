"""
Schema enforcement for SIMP Media Grid agents.

Defines validated dataclasses for all agent factory inputs, intent payloads,
and agent outputs. Ensures type safety at system boundaries.
"""

import re
from dataclasses import dataclass, field, fields, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple, Union

# ── Validation utilities ──────────────────────────────────────────────────────


class SchemaValidationError(ValueError):
    """Raised when input validation fails against a schema."""
    pass


def _validate_non_empty_str(value: Any, field_name: str) -> str:
    if not isinstance(value, str):
        raise SchemaValidationError(f"{field_name} must be a string, got {type(value).__name__}")
    stripped = value.strip()
    if not stripped:
        raise SchemaValidationError(f"{field_name} must not be empty")
    return stripped


def _validate_positive_int(value: Any, field_name: str, allow_zero: bool = False) -> int:
    if not isinstance(value, int):
        raise SchemaValidationError(f"{field_name} must be an integer, got {type(value).__name__}")
    if allow_zero:
        if value < 0:
            raise SchemaValidationError(f"{field_name} must be >= 0, got {value}")
    else:
        if value < 1:
            raise SchemaValidationError(f"{field_name} must be >= 1, got {value}")
    return value


def _validate_positive_float(value: Any, field_name: str, allow_zero: bool = False) -> float:
    if not isinstance(value, (int, float)):
        raise SchemaValidationError(f"{field_name} must be a number, got {type(value).__name__}")
    val = float(value)
    if allow_zero:
        if val < 0:
            raise SchemaValidationError(f"{field_name} must be >= 0, got {val}")
    else:
        if val <= 0:
            raise SchemaValidationError(f"{field_name} must be > 0, got {val}")
    return val


def _validate_enum(value: Any, enum_cls, field_name: str):
    """Validate value is a member of enum_cls (or a valid string key/value)."""
    if isinstance(value, enum_cls):
        return value
    if isinstance(value, str):
        try:
            return enum_cls(value)
        except ValueError:
            pass
        # Try matching by name
        try:
            return enum_cls[value.upper().strip()]
        except (KeyError, AttributeError):
            pass
    valid = [f"{m.name}={m.value}" for m in enum_cls]
    raise SchemaValidationError(
        f"{field_name} must be one of {valid}, got {value!r}"
    )


def _validate_optional_str(value: Any, field_name: str) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        raise SchemaValidationError(f"{field_name} must be a string or None, got {type(value).__name__}")
    return value


def _validate_log_level(value: Any, field_name: str = "log_level") -> str:
    valid = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
    if isinstance(value, str):
        upper = value.strip().upper()
        if upper in valid:
            return upper
    raise SchemaValidationError(
        f"{field_name} must be one of {valid}, got {value!r}"
    )


def _validate_dict(value: Any, field_name: str) -> Dict[str, Any]:
    if not isinstance(value, dict):
        raise SchemaValidationError(f"{field_name} must be a dict, got {type(value).__name__}")
    return value


def _validate_platform_name(value: str, field_name: str = "platform") -> str:
    """Validate a platform name against known platforms."""
    valid = {
        "tiktok", "youtube_shorts", "instagram_reels", "youtube",
        "instagram", "twitter", "x", "facebook", "linkedin", "tiktok_shorts",
        "snapchat", "pinterest", "website", "blog", "email",
    }
    name = value.strip().lower()
    if name not in valid:
        raise SchemaValidationError(
            f"{field_name} must be one of {sorted(valid)}, got {value!r}"
        )
    return name


def _validate_content_type(value: str, field_name: str = "content_type") -> str:
    """Validate a content type."""
    valid = {
        "short_video", "long_video", "image", "carousel", "story",
        "reel", "shorts", "tweet", "post", "article", "blog",
        "newsletter", "podcast", "live_stream", "shoppable_video",
    }
    name = value.strip().lower()
    if name not in valid:
        raise SchemaValidationError(
            f"{field_name} must be one of {sorted(valid)}, got {value!r}"
        )
    return name


# ── Base schema with validation hook ──────────────────────────────────────────


def _validate_schema(instance):
    """Run validation for all fields with type hints."""
    cls = type(instance)
    for f in fields(cls):
        value = getattr(instance, f.name)
        expected = f.type

        # For Optional[X], allow None
        origin = getattr(expected, "__origin__", None)
        args = getattr(expected, "__args__", ())

        if origin is Union and type(None) in args:
            if value is None:
                continue

        # Call special validator if it exists
        validator_name = f"_validate_{f.name}"
        if hasattr(instance, validator_name):
            validated = getattr(instance, validator_name)(value)
            setattr(instance, f.name, validated)


class ValidatedSchema:
    """Base class for all validated schemas. Validates in __post_init__."""

    def __post_init__(self):
        _validate_schema(self)


# ── Agent Configuration Schemas ───────────────────────────────────────────────

@dataclass
class TrendHarvesterConfig(ValidatedSchema):
    """Schema for trend harvester agent factory inputs."""
    agent_id: str = "trend_harvester"
    data_dir: Optional[str] = None
    research_interval_minutes: int = 60

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_research_interval_minutes(self, value):
        return _validate_positive_int(value, "research_interval_minutes")


@dataclass
class ScriptAgentConfig(ValidatedSchema):
    """Schema for script agent factory inputs."""
    agent_id: str = "script_agent"
    data_dir: Optional[str] = None
    generation_tool: Any = None  # GenerationTool enum

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def __post_init__(self):
        # Validate generation_tool if present
        if self.generation_tool is not None:
            try:
                from simp.organs.media.models import GenerationTool
                self.generation_tool = _validate_enum(
                    self.generation_tool, GenerationTool, "generation_tool"
                )
            except ImportError:
                pass  # skip if models not available
        super().__post_init__()


@dataclass
class AssetAgentConfig(ValidatedSchema):
    """Schema for asset agent factory inputs."""
    agent_id: str = "asset_agent"
    data_dir: Optional[str] = None
    default_tool: Any = None  # GenerationTool enum
    budget_per_job: float = 10.0
    budget_tracker: Any = None  # Optional[DailyBudgetTracker]
    rate_limiter: Any = None  # Optional[RateLimiter]

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_budget_per_job(self, value):
        return _validate_positive_float(value, "budget_per_job", allow_zero=True)

    def __post_init__(self):
        if self.default_tool is not None:
            try:
                from simp.organs.media.models import GenerationTool
                self.default_tool = _validate_enum(
                    self.default_tool, GenerationTool, "default_tool"
                )
            except ImportError:
                pass
        super().__post_init__()


@dataclass
class EditPackagingConfig(ValidatedSchema):
    """Schema for edit/packaging agent factory inputs."""
    agent_id: str = "edit_packaging_agent"
    data_dir: Optional[str] = None

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")


@dataclass
class PublisherConfig(ValidatedSchema):
    """Schema for publisher agent factory inputs."""
    agent_id: str = "publisher_agent"
    data_dir: Optional[str] = None
    max_retries: int = 3
    retry_delay: int = 60

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_max_retries(self, value):
        return _validate_positive_int(value, "max_retries", allow_zero=True)

    def _validate_retry_delay(self, value):
        return _validate_positive_int(value, "retry_delay", allow_zero=True)


@dataclass
class AnalyticsConfig(ValidatedSchema):
    """Schema for analytics agent factory inputs."""
    agent_id: str = "analytics_agent"
    data_dir: Optional[str] = None
    analysis_interval_minutes: int = 60

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_analysis_interval_minutes(self, value):
        return _validate_positive_int(value, "analysis_interval_minutes")


@dataclass
class LandingPageConfig(ValidatedSchema):
    """Schema for landing page agent factory inputs."""
    agent_id: str = "landing_page_agent"
    data_dir: Optional[str] = None
    log_level: str = "INFO"
    template_dir: Optional[str] = None

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_log_level(self, value):
        return _validate_log_level(value)


@dataclass
class OfferIntelligenceConfig(ValidatedSchema):
    """Schema for offer intelligence agent factory inputs."""
    agent_id: str = "offer_intelligence"
    data_dir: Optional[str] = None
    log_level: str = "INFO"
    scoring_interval_minutes: int = 30

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_log_level(self, value):
        return _validate_log_level(value)

    def _validate_scoring_interval_minutes(self, value):
        return _validate_positive_int(value, "scoring_interval_minutes")


@dataclass
class SimpNewsConfig(ValidatedSchema):
    """Schema for SIMP news agent factory inputs."""
    agent_id: str = "simp_news"
    data_dir: Optional[str] = None
    log_level: str = "INFO"
    news_interval_minutes: int = 120

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_log_level(self, value):
        return _validate_log_level(value)

    def _validate_news_interval_minutes(self, value):
        return _validate_positive_int(value, "news_interval_minutes")


@dataclass
class BrandDealsConfig(ValidatedSchema):
    """Schema for brand deals agent factory inputs."""
    agent_id: str = "brand_deals"
    data_dir: str = "data/media"
    log_level: str = "INFO"
    min_deal_value: float = 100.0

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_log_level(self, value):
        return _validate_log_level(value)

    def _validate_min_deal_value(self, value):
        return _validate_positive_float(value, "min_deal_value", allow_zero=True)


@dataclass
class YoutubeEmpireConfig(ValidatedSchema):
    """Schema for YouTube Empire agent factory inputs."""
    agent_id: str = "youtube_empire"
    data_dir: Optional[str] = None
    log_level: str = "INFO"
    channel_id: str = ""
    upload_playlist_id: str = ""

    def _validate_agent_id(self, value):
        return _validate_non_empty_str(value, "agent_id")

    def _validate_log_level(self, value):
        return _validate_log_level(value)


# ── Intent Payload Schemas ────────────────────────────────────────────────────


@dataclass
class TrendResearchPayload(ValidatedSchema):
    """Schema for media.trend_research intent payloads."""
    topic: str = ""
    max_results: int = 5
    platforms: Optional[List[str]] = None
    include_content_fit: bool = True
    include_competition: bool = False

    def _validate_topic(self, value):
        return _validate_non_empty_str(value, "topic")

    def _validate_max_results(self, value):
        return _validate_positive_int(value, "max_results")


@dataclass
class OfferScoringPayload(ValidatedSchema):
    """Schema for media.offer_scoring intent payloads."""
    offers: List[Dict[str, Any]] = field(default_factory=list)
    budget: float = 0.0
    preferred_categories: Optional[List[str]] = None
    min_score: float = 0.0

    def _validate_budget(self, value):
        return _validate_positive_float(value, "budget", allow_zero=True)


@dataclass
class ScriptGenerationPayload(ValidatedSchema):
    """Schema for media.script_generation intent payloads."""
    brief_id: str = ""
    content_type: str = "short_video"
    platform: str = "youtube_shorts"
    tone: str = "professional"
    target_duration_seconds: int = 60
    include_cta: bool = True
    hooks_count: int = 3

    def _validate_brief_id(self, value):
        return _validate_non_empty_str(value, "brief_id")

    def _validate_content_type(self, value):
        return _validate_content_type(value)

    def _validate_platform(self, value):
        return _validate_platform_name(value)

    def _validate_target_duration_seconds(self, value):
        return _validate_positive_int(value, "target_duration_seconds")

    def _validate_hooks_count(self, value):
        return _validate_positive_int(value, "hooks_count")


@dataclass
class AssetGenerationPayload(ValidatedSchema):
    """Schema for media.asset_generation intent payloads."""
    script_id: str = ""
    platform: str = "youtube_shorts"
    asset_type: str = "short_video"
    style_reference: Optional[str] = None
    budget: float = 5.0

    def _validate_script_id(self, value):
        return _validate_non_empty_str(value, "script_id")

    def _validate_platform(self, value):
        return _validate_platform_name(value)

    def _validate_budget(self, value):
        return _validate_positive_float(value, "budget", allow_zero=True)


@dataclass
class ContentPublishPayload(ValidatedSchema):
    """Schema for media.content_publishing intent payloads."""
    package_id: str = ""
    schedule_at: Optional[str] = None
    platforms: List[str] = field(default_factory=list)
    monetize: bool = True

    def _validate_package_id(self, value):
        return _validate_non_empty_str(value, "package_id")

    def _validate_platforms(self, value):
        if not isinstance(value, list):
            raise SchemaValidationError("platforms must be a list")
        for p in value:
            _validate_platform_name(p, f"platform in platforms")
        return value


@dataclass
class PerformanceTrackingPayload(ValidatedSchema):
    """Schema for media.performance_tracking intent payloads."""
    post_id: str = ""
    platform: str = "youtube_shorts"
    views: int = 0
    likes: int = 0
    comments: int = 0
    shares: int = 0
    clicks: int = 0
    conversions: int = 0
    revenue: float = 0.0
    cost: float = 0.0

    def _validate_post_id(self, value):
        return _validate_non_empty_str(value, "post_id")

    def _validate_platform(self, value):
        return _validate_platform_name(value)


# ── Factory validation helper ─────────────────────────────────────────────────


def validate_factory_config(config: ValidatedSchema) -> Dict[str, Any]:
    """Validate a config against its schema and return as dict.

    Args:
        config: A ValidatedSchema instance

    Returns:
        Dict of validated config fields

    Raises:
        SchemaValidationError: If validation fails
    """
    validated = {}
    for f in fields(config):
        value = getattr(config, f.name)
        # Skip None optionals
        origin = getattr(f.type, "__origin__", None)
        args = getattr(f.type, "__args__", ())
        if origin is Union and type(None) in args and value is None:
            validated[f.name] = None
            continue
        validated[f.name] = value
    return validated


def factory_from_dict(schema_cls, data: Dict[str, Any]) -> ValidatedSchema:
    """Create a validated schema from a dict.

    Args:
        schema_cls: A ValidatedSchema subclass
        data: Dict of field values

    Returns:
        Validated schema instance
    """
    # Filter to only valid fields
    valid_field_names = {f.name for f in fields(schema_cls)}
    filtered = {k: v for k, v in data.items() if k in valid_field_names}
    return schema_cls(**filtered)


# ── Registration metadata ─────────────────────────────────────────────────────


def make_registration_metadata(agent_id: str, agent_class: str) -> Dict[str, Any]:
    """Generate standardized SIMP broker registration metadata.

    Args:
        agent_id: Agent identifier
        agent_class: Class name for tracking

    Returns:
        Metadata dict suitable for broker registration
    """
    return {
        "agent_name": agent_id.replace("_", " ").title().replace("Agent", "").strip() + " Agent",
        "agent_class": agent_class,
        "endpoint_type": "file-based",
        "simp_versions": ["1.0"],
        "registered_at": datetime.utcnow().isoformat(),
    }
