"""
Human-in-the-Loop Approval Gates.

Defines approval gates that pause autonomous flow for human review:
- Brand Identity Gate (channel launch naming)
- Content Quality Gate (risky content)
- Spend Authorization Gate (ad spend > $500)
- Kill/Scale Gate (channel decisions)
- Viral Response Gate (high-engagement posts)
"""
import asyncio
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging


class GateType(Enum):
    """Types of approval gates."""
    BRAND_IDENTITY = "brand_identity"  # Channel launch naming
    CONTENT_QUALITY = "content_quality"  # Risky/flagged content
    SPEND_AUTHORIZATION = "spend_auth"  # Ad spend approval
    KILL_CHANNEL = "kill_channel"  # Stop a channel
    SCALE_CHANNEL = "scale_channel"  # Expand a channel
    VIRAL_RESPONSE = "viral_response"  # Amplify viral content
    LEGAL_REVIEW = "legal_review"  # Legal/compliance review


class ApprovalStatus(Enum):
    """Status of an approval request."""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


class ApprovalPriority(Enum):
    """Priority levels for approvals."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


@dataclass
class ApprovalRequest:
    """An approval request awaiting human review."""
    request_id: str
    gate_type: GateType
    priority: ApprovalPriority
    
    # Context
    channel_id: str
    channel_name: str
    action: str  # What action needs approval
    
    # Details
    title: str
    description: str
    options: List[Dict[str, Any]] = field(default_factory=list)
    
    # Data
    payload: Dict[str, Any] = field(default_factory=dict)
    
    # Status
    status: ApprovalStatus = ApprovalStatus.PENDING
    requested_at: datetime = field(default_factory=datetime.now)
    responded_at: Optional[datetime] = None
    responded_by: Optional[str] = None
    response_note: Optional[str] = None
    
    # Expiration
    expires_at: Optional[datetime] = None
    
    # Routing
    approver_role: str = "operations"  # Which team handles this
    slack_channel: str = "#approvals"
    notification_sent: bool = False


@dataclass
class GateConfig:
    """Configuration for an approval gate."""
    gate_type: GateType
    
    # Trigger conditions
    auto_trigger: bool = True
    conditions: Dict[str, Any] = field(default_factory=dict)
    
    # Behavior
    require_approval: bool = True
    timeout_minutes: int = 60
    escalation_minutes: int = 30
    
    # Routing
    approver_role: str = "operations"
    approvers: List[str] = field(default_factory=list)
    slack_channel: str = "#approvals"
    
    # On timeout
    on_timeout: str = "reject"  # reject, approve, escalate
    on_reject: str = "pause"  # pause, abort, continue
    
    # Priority mapping
    priority_conditions: Dict[str, ApprovalPriority] = field(default_factory=dict)


class ApprovalGate:
    """
    Approval gate that pauses workflow for human review.
    
    Integrates with:
    - Slack for notifications
    - Simple web portal for responses
    - Workflow engine for pause/resume
    """
    
    # Default gate configurations
    DEFAULT_CONFIGS: Dict[GateType, GateConfig] = {
        GateType.BRAND_IDENTITY: GateConfig(
            gate_type=GateType.BRAND_IDENTITY,
            approver_role="brand",
            slack_channel="#brand-approvals",
            timeout_minutes=120,  # 2 hours for branding
            priority_conditions={"high_value": ApprovalPriority.HIGH}
        ),
        GateType.CONTENT_QUALITY: GateConfig(
            gate_type=GateType.CONTENT_QUALITY,
            approver_role="compliance",
            slack_channel="#content-review",
            timeout_minutes=30,
            on_timeout="reject",
            priority_conditions={
                "niche_finance": ApprovalPriority.HIGH,
                "niche_health": ApprovalPriority.HIGH,
                "risk_score_high": ApprovalPriority.URGENT
            }
        ),
        GateType.SPEND_AUTHORIZATION: GateConfig(
            gate_type=GateType.SPEND_AUTHORIZATION,
            approver_role="finance",
            slack_channel="#finance-approvals",
            timeout_minutes=60,
            priority_conditions={
                "amount_500_1000": ApprovalPriority.MEDIUM,
                "amount_1000_plus": ApprovalPriority.HIGH
            }
        ),
        GateType.KILL_CHANNEL: GateConfig(
            gate_type=GateType.KILL_CHANNEL,
            approver_role="operations",
            slack_channel="#ops-approvals",
            timeout_minutes=1440,  # 24 hours
            priority_conditions={"established_channel": ApprovalPriority.HIGH}
        ),
        GateType.SCALE_CHANNEL: GateConfig(
            gate_type=GateType.SCALE_CHANNEL,
            approver_role="operations",
            slack_channel="#growth-approvals",
            timeout_minutes=480,  # 8 hours
            priority_conditions={"high_roi": ApprovalPriority.HIGH}
        ),
        GateType.VIRAL_RESPONSE: GateConfig(
            gate_type=GateType.VIRAL_RESPONSE,
            approver_role="growth",
            slack_channel="#growth-hacking",
            timeout_minutes=15,
            on_timeout="continue",
            priority_conditions={"engagement_10x": ApprovalPriority.URGENT}
        ),
        GateType.LEGAL_REVIEW: GateConfig(
            gate_type=GateType.LEGAL_REVIEW,
            approver_role="legal",
            slack_channel="#legal",
            timeout_minutes=2880,  # 48 hours
            priority_conditions={"dmca_takedown": ApprovalPriority.URGENT}
        ),
    }
    
    def __init__(
        self,
        data_dir: str = "data/media/approvals",
        slack_webhook: Optional[str] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.approval_gates")
        
        self.slack_webhook = slack_webhook
        self._requests: Dict[str, ApprovalRequest] = {}
        self._configs: Dict[GateType, GateConfig] = {}
        
        # Load defaults
        for gate_type, config in self.DEFAULT_CONFIGS.items():
            self._configs[gate_type] = config
        
        self._load_requests()
    
    def _load_requests(self) -> None:
        """Load pending requests from disk."""
        requests_file = self.data_dir / "pending_requests.json"
        if requests_file.exists():
            with open(requests_file) as f:
                data = json.load(f)
                for req_data in data.values():
                    req_data["requested_at"] = datetime.fromisoformat(req_data["requested_at"])
                    if req_data.get("responded_at"):
                        req_data["responded_at"] = datetime.fromisoformat(req_data["responded_at"])
                    if req_data.get("expires_at"):
                        req_data["expires_at"] = datetime.fromisoformat(req_data["expires_at"])
                    self._requests[req_data["request_id"]] = ApprovalRequest(**req_data)
    
    def _save_requests(self) -> None:
        """Save requests to disk."""
        requests_data = {}
        for rid, req in self._requests.items():
            if req.status == ApprovalStatus.PENDING:
                requests_data[rid] = {
                    **vars(req),
                    "requested_at": req.requested_at.isoformat(),
                    "responded_at": req.responded_at.isoformat() if req.responded_at else None,
                    "expires_at": req.expires_at.isoformat() if req.expires_at else None
                }
        
        with open(self.data_dir / "pending_requests.json", "w") as f:
            json.dump(requests_data, f, indent=2)
    
    # =========================================================================
    # Gate Management
    # =========================================================================
    
    def get_config(self, gate_type: GateType) -> GateConfig:
        """Get configuration for a gate type."""
        return self._configs.get(gate_type, GateConfig(gate_type=gate_type))
    
    def update_config(self, gate_type: GateType, config: GateConfig) -> None:
        """Update gate configuration."""
        self._configs[gate_type] = config
    
    # =========================================================================
    # Approval Requests
    # =========================================================================
    
    def create_request(
        self,
        gate_type: GateType,
        channel_id: str,
        channel_name: str,
        action: str,
        title: str,
        description: str,
        payload: Optional[Dict[str, Any]] = None,
        options: Optional[List[Dict[str, Any]]] = None,
        priority: Optional[ApprovalPriority] = None
    ) -> ApprovalRequest:
        """Create a new approval request."""
        config = self.get_config(gate_type)
        
        # Determine priority
        if priority is None:
            priority = self._determine_priority(config, payload or {})
        
        # Calculate expiration
        expires_at = datetime.now() + timedelta(minutes=config.timeout_minutes)
        
        request = ApprovalRequest(
            request_id=f"apr_{uuid.uuid4().hex[:8]}",
            gate_type=gate_type,
            priority=priority,
            channel_id=channel_id,
            channel_name=channel_name,
            action=action,
            title=title,
            description=description,
            options=options or [],
            payload=payload or {},
            expires_at=expires_at,
            approver_role=config.approver_role,
            slack_channel=config.slack_channel
        )
        
        self._requests[request.request_id] = request
        self._save_requests()
        
        # Send notification
        self._send_notification(request)
        
        self.logger.info(f"Created approval request: {request.request_id} ({gate_type.value})")
        return request
    
    def _determine_priority(
        self,
        config: GateConfig,
        payload: Dict[str, Any]
    ) -> ApprovalPriority:
        """Determine priority based on payload and conditions."""
        for condition, priority in config.priority_conditions.items():
            if self._check_condition(condition, payload):
                return priority
        return ApprovalPriority.MEDIUM
    
    def _check_condition(self, condition: str, payload: Dict[str, Any]) -> bool:
        """Check if a condition is met in the payload."""
        checks = {
            "niche_finance": lambda p: p.get("niche") == "finance",
            "niche_health": lambda p: p.get("niche") == "health",
            "risk_score_high": lambda p: p.get("risk_score", 0) > 0.7,
            "amount_500_1000": lambda p: 500 <= p.get("amount", 0) < 1000,
            "amount_1000_plus": lambda p: p.get("amount", 0) >= 1000,
            "established_channel": lambda p: p.get("days_active", 0) > 90,
            "high_roi": lambda p: p.get("roi", 0) > 2.0,
            "engagement_10x": lambda p: p.get("engagement_multiplier", 0) > 10,
            "high_value": lambda p: p.get("value_estimate", 0) > 10000,
            "dmca_takedown": lambda p: p.get("type") == "dmca"
        }
        
        check = checks.get(condition)
        return check(payload) if check else False
    
    # =========================================================================
    # Approval Responses
    # =========================================================================
    
    async def approve(
        self,
        request_id: str,
        approver: str,
        note: Optional[str] = None
    ) -> bool:
        """Approve an approval request."""
        request = self._requests.get(request_id)
        if not request:
            return False
        
        request.status = ApprovalStatus.APPROVED
        request.responded_at = datetime.now()
        request.responded_by = approver
        request.response_note = note
        
        self._save_requests()
        self.logger.info(f"Approved request: {request_id} by {approver}")
        
        # Trigger callback if registered
        await self._trigger_callback(request, approved=True)
        
        return True
    
    async def reject(
        self,
        request_id: str,
        approver: str,
        reason: str
    ) -> bool:
        """Reject an approval request."""
        request = self._requests.get(request_id)
        if not request:
            return False
        
        request.status = ApprovalStatus.REJECTED
        request.responded_at = datetime.now()
        request.responded_by = approver
        request.response_note = reason
        
        self._save_requests()
        self.logger.info(f"Rejected request: {request_id} by {approver} - {reason}")
        
        # Trigger callback if registered
        await self._trigger_callback(request, approved=False)
        
        return True
    
    async def select_option(
        self,
        request_id: str,
        option_index: int,
        approver: str,
        note: Optional[str] = None
    ) -> bool:
        """Select an option from the approval request."""
        request = self._requests.get(request_id)
        if not request or not request.options:
            return False
        
        if option_index >= len(request.options):
            return False
        
        selected = request.options[option_index]
        request.payload["selected_option"] = selected
        
        return await self.approve(request_id, approver, note)
    
    # =========================================================================
    # Request Status
    # =========================================================================
    
    def get_request(self, request_id: str) -> Optional[ApprovalRequest]:
        """Get an approval request by ID."""
        return self._requests.get(request_id)
    
    def get_pending_requests(
        self,
        gate_type: Optional[GateType] = None,
        channel_id: Optional[str] = None,
        priority: Optional[ApprovalPriority] = None
    ) -> List[ApprovalRequest]:
        """Get pending approval requests."""
        requests = [
            r for r in self._requests.values()
            if r.status == ApprovalStatus.PENDING
        ]
        
        if gate_type:
            requests = [r for r in requests if r.gate_type == gate_type]
        if channel_id:
            requests = [r for r in requests if r.channel_id == channel_id]
        if priority:
            requests = [r for r in requests if r.priority == priority]
        
        return sorted(requests, key=lambda r: (r.priority.value, r.requested_at))
    
    async def check_expired(self) -> List[ApprovalRequest]:
        """Check for expired requests and apply timeout policy."""
        expired = []
        now = datetime.now()
        
        for request in self._requests.values():
            if request.status == ApprovalStatus.PENDING:
                if request.expires_at and request.expires_at < now:
                    expired.append(request)
                    config = self.get_config(request.gate_type)
                    
                    if config.on_timeout == "reject":
                        await self.reject(
                            request.request_id,
                            approver="system",
                            reason=f"Expired after {config.timeout_minutes} minutes"
                        )
                    elif config.on_timeout == "continue":
                        await self.approve(
                            request.request_id,
                            approver="system",
                            note="Auto-approved on timeout"
                        )
        
        return expired
    
    # =========================================================================
    # Callbacks
    # =========================================================================
    
    _callbacks: Dict[str, Callable] = {}
    
    def register_callback(
        self,
        gate_type: GateType,
        callback: Callable[[ApprovalRequest, bool], Any]
    ) -> None:
        """Register a callback for approval completion."""
        self._callbacks[gate_type.value] = callback
    
    async def _trigger_callback(
        self,
        request: ApprovalRequest,
        approved: bool
    ) -> None:
        """Trigger registered callback."""
        callback_key = request.gate_type.value
        if callback_key in self._callbacks:
            try:
                await self._callbacks[callback_key](request, approved)
            except Exception as e:
                self.logger.error(f"Callback failed: {e}")
    
    # =========================================================================
    # Notifications
    # =========================================================================
    
    async def _send_notification(self, request: ApprovalRequest) -> None:
        """Send Slack notification for approval request."""
        if not self.slack_webhook:
            return
        
        import httpx
        
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    self.slack_webhook,
                    json={
                        "channel": request.slack_channel,
                        "text": f"📋 *Approval Required*: {request.title}",
                        "blocks": [
                            {
                                "type": "header",
                                "text": {"type": "plain_text", "text": f"Approval: {request.title}"}
                            },
                            {
                                "type": "section",
                                "fields": [
                                    {"type": "mrkdwn", "text": f"*Channel:*\n{request.channel_name}"},
                                    {"type": "mrkdwn", "text": f"*Priority:*\n{request.priority.value}"},
                                    {"type": "mrkdwn", "text": f"*Gate:*\n{request.gate_type.value}"},
                                    {"type": "mrkdwn", "text": f"*Requested:*\n{request.requested_at.strftime('%H:%M')}"}
                                ]
                            },
                            {"type": "section", "text": {"type": "mrkdwn", "text": request.description}},
                            {
                                "type": "actions",
                                "elements": [
                                    {
                                        "type": "button",
                                        "text": {"type": "plain_text", "text": "✅ Approve"},
                                        "style": "primary",
                                        "action_id": f"approve_{request.request_id}"
                                    },
                                    {
                                        "type": "button",
                                        "text": {"type": "plain_text", "text": "❌ Reject"},
                                        "style": "danger",
                                        "action_id": f"reject_{request.request_id}"
                                    }
                                ]
                            }
                        ]
                    }
                )
            
            request.notification_sent = True
            self._save_requests()
            
        except Exception as e:
            self.logger.error(f"Failed to send Slack notification: {e}")
    
    # =========================================================================
    # Workflow Integration
    # =========================================================================
    
    async def wait_for_approval(
        self,
        request_id: str,
        timeout_seconds: Optional[int] = None
    ) -> ApprovalStatus:
        """Wait for an approval request to be resolved."""
        request = self._requests.get(request_id)
        if not request:
            return ApprovalStatus.EXPIRED
        
        timeout = timeout_seconds or (request.expires_at - datetime.now()).total_seconds()
        start = datetime.now()
        
        while (datetime.now() - start).total_seconds() < timeout:
            if request.status != ApprovalStatus.PENDING:
                return request.status
            await asyncio.sleep(5)
        
        return ApprovalStatus.EXPIRED
