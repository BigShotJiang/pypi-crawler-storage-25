"""
Scheduler & Publisher Agent - Autonomous Content Scheduling & Publishing.

Manages:
- Content calendar generation
- Multi-platform scheduling
- Publishing orchestration
- Engagement monitoring

Integrates with:
- ContentFactory (content generation)
- PlatformConnectors (posting)
- AnalyticsAgent (performance tracking)
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

from simp.organs.media.account_creation.platform_connectors import (
    Platform, PostContent, PostResult, PostStatus, create_connector
)



class SchedulerStatus(Enum):
    """Status of scheduled content."""
    PENDING = "pending"
    QUEUED = "queued"
    PUBLISHED = "published"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ScheduledPost:
    """A scheduled post entry."""
    post_id: str
    channel_id: str
    platform: Platform
    content: PostContent
    scheduled_time: datetime
    status: SchedulerStatus = SchedulerStatus.PENDING
    
    # Generation status
    script_generated: bool = False
    assets_generated: bool = False
    quality_approved: bool = False
    
    # Publishing
    published_result: Optional[PostResult] = None
    published_at: Optional[datetime] = None
    
    # Metrics
    engagement_1hr: int = 0
    engagement_24hr: int = 0
    is_viral: bool = False
    
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class ContentCalendar:
    """Content calendar for a channel."""
    channel_id: str
    start_date: datetime
    end_date: datetime
    posts: List[ScheduledPost] = field(default_factory=list)
    platform_schedule: Dict[str, List[str]] = field(default_factory=dict)  # platform -> times
    
    # Statistics
    total_posts_planned: int = 0
    total_posts_published: int = 0
    avg_engagement: float = 0.0


@dataclass
class PublishingQueue:
    """Queue of posts ready for publishing."""
    queue_id: str
    posts: List[ScheduledPost] = field(default_factory=list)
    current_index: int = 0
    platform: Optional[Platform] = None  # Filter by platform
    
    # Rate limiting
    posts_per_hour: int = 4
    min_interval_minutes: int = 15
    
    created_at: datetime = field(default_factory=datetime.now)


class SchedulerPublisherAgent:
    """
    Autonomous scheduler and publisher agent.
    
    Handles:
    - Generating content calendars
    - Scheduling posts across platforms
    - Executing publishing pipeline
    - Monitoring engagement and viral detection
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/scheduler",
        connectors: Optional[Dict[Platform, Any]] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.scheduler_publisher")
        
        # Platform connectors
        self.connectors: Dict[Platform, Any] = connectors or {}
        
        # State
        self._calendars: Dict[str, ContentCalendar] = {}
        self._scheduled_posts: Dict[str, ScheduledPost] = {}
        self._queues: Dict[str, PublishingQueue] = {}
        
        # Load state
        self._load_state()
        
        # Publishers per channel
        self._channel_publishers: Dict[str, asyncio.Task] = {}
    
    def _load_state(self) -> None:
        """Load state from disk."""
        calendars_file = self.data_dir / "calendars.json"
        posts_file = self.data_dir / "scheduled_posts.json"
        
        if calendars_file.exists():
            with open(calendars_file) as f:
                data = json.load(f)
                for cal_data in data.values():
                    cal_data["start_date"] = datetime.fromisoformat(cal_data["start_date"])
                    cal_data["end_date"] = datetime.fromisoformat(cal_data["end_date"])
                    for post in cal_data["posts"]:
                        post["scheduled_time"] = datetime.fromisoformat(post["scheduled_time"])
                        if post.get("published_at"):
                            post["published_at"] = datetime.fromisoformat(post["published_at"])
                self._calendars = data
        
        if posts_file.exists():
            with open(posts_file) as f:
                data = json.load(f)
                for post_data in data.values():
                    post_data["scheduled_time"] = datetime.fromisoformat(post_data["scheduled_time"])
                    if post_data.get("published_at"):
                        post_data["published_at"] = datetime.fromisoformat(post_data["published_at"])
                self._scheduled_posts = data
    
    def _save_state(self) -> None:
        """Save state to disk."""
        # Serialize datetime objects
        calendars_data = {}
        for cid, cal in self._calendars.items():
            cal_dict = {
                "channel_id": cal.channel_id,
                "start_date": cal.start_date.isoformat(),
                "end_date": cal.end_date.isoformat(),
                "posts": [
                    {
                        **vars(post),
                        "scheduled_time": post.scheduled_time.isoformat(),
                        "published_at": post.published_at.isoformat() if post.published_at else None,
                        "content": {
                            **vars(post.content),
                            "scheduled_time": post.content.scheduled_time.isoformat() if post.content.scheduled_time else None
                        }
                    }
                    for post in cal.posts
                ],
                "platform_schedule": cal.platform_schedule,
                "total_posts_planned": cal.total_posts_planned,
                "total_posts_published": cal.total_posts_published,
                "avg_engagement": cal.avg_engagement
            }
            calendars_data[cid] = cal_dict
        
        with open(self.data_dir / "calendars.json", "w") as f:
            json.dump(calendars_data, f, indent=2)
        
        posts_data = {}
        for pid, post in self._scheduled_posts.items():
            posts_data[pid] = {
                **vars(post),
                "scheduled_time": post.scheduled_time.isoformat(),
                "published_at": post.published_at.isoformat() if post.published_at else None,
                "content": vars(post.content)
            }
        
        with open(self.data_dir / "scheduled_posts.json", "w") as f:
            json.dump(posts_data, f, indent=2)
    
    def add_connector(self, platform: Platform, connector: Any) -> None:
        """Add a platform connector."""
        self.connectors[platform] = connector
    
    async def generate_calendar(
        self,
        channel_id: str,
        days: int = 30,
        posts_per_day: int = 2,
        platforms: Optional[List[Platform]] = None
    ) -> ContentCalendar:
        """
        Generate a content calendar for a channel.
        
        Args:
            channel_id: The channel to generate calendar for
            days: Number of days to schedule
            posts_per_day: Posts per day per platform
            platforms: Platforms to schedule for
        """
        if platforms is None:
            platforms = [Platform.TIKTOK, Platform.YOUTUBE, Platform.INSTAGRAM, Platform.X]
        
        start_date = datetime.now().replace(hour=6, minute=0, second=0, microsecond=0)
        end_date = start_date + timedelta(days=days)
        
        calendar = ContentCalendar(
            channel_id=channel_id,
            start_date=start_date,
            end_date=end_date,
            platform_schedule={
                Platform.TIKTOK.value: ["06:00", "12:00", "18:00", "21:00"],
                Platform.YOUTUBE.value: ["09:00", "15:00"],
                Platform.INSTAGRAM.value: ["07:00", "13:00", "19:00"],
                Platform.X.value: ["08:00", "11:00", "14:00", "17:00", "20:00"],
            }
        )
        
        # Generate posts
        current_date = start_date
        post_count = 0
        
        while current_date < end_date:
            for platform in platforms:
                times = calendar.platform_schedule.get(platform.value, [])
                for time_str in times[:posts_per_day]:
                    hour, minute = map(int, time_str.split(":"))
                    scheduled_time = current_date.replace(hour=hour, minute=minute)
                    
                    post = ScheduledPost(
                        post_id=f"post_{uuid.uuid4().hex[:8]}",
                        channel_id=channel_id,
                        platform=platform,
                        content=PostContent(
                            title=f"Content {post_count + 1}",
                            description="",
                            caption=f"Check out this amazing content! #viral #trending",
                            hashtags=["tech", "ai", "content"]
                        ),
                        scheduled_time=scheduled_time
                    )
                    
                    calendar.posts.append(post)
                    self._scheduled_posts[post.post_id] = post
                    post_count += 1
            
            current_date += timedelta(days=1)
        
        calendar.total_posts_planned = len(calendar.posts)
        self._calendars[channel_id] = calendar
        self._save_state()
        
        self.logger.info(f"Generated calendar with {len(calendar.posts)} posts for {channel_id}")
        return calendar
    
    async def get_todays_posts(
        self,
        channel_id: str,
        platform: Optional[Platform] = None
    ) -> List[ScheduledPost]:
        """Get today's scheduled posts for a channel."""
        today = datetime.now().date()
        posts = []
        
        for post in self._scheduled_posts.values():
            if post.channel_id == channel_id:
                post_date = post.scheduled_time.date()
                if post_date == today:
                    if platform is None or post.platform == platform:
                        posts.append(post)
        
        return sorted(posts, key=lambda p: p.scheduled_time)
    
    async def queue_for_scheduling(self, post: ScheduledPost) -> bool:
        """Add a post to the publishing queue."""
        queue_id = f"queue_{post.platform.value}_{datetime.now().strftime('%Y%m%d')}"
        
        if queue_id not in self._queues:
            self._queues[queue_id] = PublishingQueue(
                queue_id=queue_id,
                platform=post.platform
            )
        
        queue = self._queues[queue_id]
        queue.posts.append(post)
        post.status = SchedulerStatus.QUEUED
        
        self.logger.info(f"Queued post {post.post_id} for {post.platform.value}")
        return True
    
    async def start_publishing_loop(self, channel_id: str) -> None:
        """Start the publishing loop for a channel."""
        if channel_id in self._channel_publishers:
            self.logger.warning(f"Publisher already running for {channel_id}")
            return
        
        task = asyncio.create_task(self._publishing_loop(channel_id))
        self._channel_publishers[channel_id] = task
        self.logger.info(f"Started publishing loop for {channel_id}")
    
    async def stop_publishing_loop(self, channel_id: str) -> None:
        """Stop the publishing loop for a channel."""
        if channel_id in self._channel_publishers:
            self._channel_publishers[channel_id].cancel()
            del self._channel_publishers[channel_id]
            self.logger.info(f"Stopped publishing loop for {channel_id}")
    
    async def _publishing_loop(self, channel_id: str) -> None:
        """Main publishing loop - checks for due posts and publishes them."""
        while True:
            try:
                now = datetime.now()
                posts = self._scheduled_posts.values()
                
                for post in posts:
                    if post.channel_id == channel_id and post.status == SchedulerStatus.QUEUED:
                        # Check if it's time to publish
                        if post.scheduled_time <= now:
                            await self._publish_post(post)
                
                await asyncio.sleep(60)  # Check every minute
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Publishing loop error: {e}")
                await asyncio.sleep(60)
    
    async def _publish_post(self, post: ScheduledPost) -> PostResult:
        """Publish a single post to its platform."""
        connector = self.connectors.get(post.platform)
        
        if not connector:
            post.status = SchedulerStatus.FAILED
            return PostResult(
                success=False,
                status=PostStatus.FAILED,
                platform=post.platform,
                error=f"No connector for {post.platform.value}"
            )
        
        result = await connector.post(post.content)
        
        if result.success:
            post.status = SchedulerStatus.PUBLISHED
            post.published_result = result
            post.published_at = datetime.now()
            self.logger.info(f"Published {post.post_id} to {post.platform.value}")
        else:
            post.status = SchedulerStatus.FAILED
            self.logger.error(f"Failed to publish {post.post_id}: {result.error}")
        
        self._save_state()
        return result
    
    async def check_viral_detection(self, post_id: str) -> bool:
        """
        Check if a post is going viral.
        
        Returns True if engagement is >3x baseline in 2 hours.
        """
        post = self._scheduled_posts.get(post_id)
        if not post or not post.published_at:
            return False
        
        # Check if it's within viral detection window (2 hours)
        time_since_publish = datetime.now() - post.published_at
        if time_since_publish.total_seconds() > 7200:  # 2 hours
            return False
        
        # Simplified viral check - in production would query real metrics
        is_viral = post.engagement_1hr > 10000  # Example threshold
        
        if is_viral:
            post.is_viral = True
            self.logger.info(f"🔥 VIRAL: Post {post_id} is going viral!")
        
        return is_viral
    
    async def get_upcoming_posts(
        self,
        channel_id: str,
        hours: int = 24
    ) -> List[ScheduledPost]:
        """Get posts scheduled in the next N hours."""
        now = datetime.now()
        cutoff = now + timedelta(hours=hours)
        
        upcoming = []
        for post in self._scheduled_posts.values():
            if post.channel_id == channel_id:
                if now <= post.scheduled_time <= cutoff:
                    if post.status == SchedulerStatus.PENDING:
                        upcoming.append(post)
        
        return sorted(upcoming, key=lambda p: p.scheduled_time)
    
    def get_queue_status(self) -> Dict[str, Any]:
        """Get status of all publishing queues."""
        return {
            queue_id: {
                "platform": queue.platform.value,
                "posts_queued": len(queue.posts),
                "current_index": queue.current_index
            }
            for queue_id, queue in self._queues.items()
        }
