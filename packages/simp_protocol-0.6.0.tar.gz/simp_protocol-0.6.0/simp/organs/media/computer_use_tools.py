"""
Computer Use Tools for Autonomous Agent Actions.

Provides browser automation and computer control capabilities for:
- Social media account creation
- OAuth authentication flows
- Platform API interactions
- Web scraping and data extraction

Based on anthropic/computer-use patterns and Claude Code/Claude Cowork integration.
"""
import asyncio
import base64
import json
import os
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable, Tuple
import logging

# Optional: Playwright for browser automation
try:
    from playwright.async_api import async_playwright, Page, Browser, BrowserContext
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    print("Playwright not installed. Install with: pip install playwright && playwright install chromium")


class ToolCapability(Enum):
    """Capabilities available via computer use tools."""
    BROWSER_OPEN = "browser_open"
    BROWSER_SNAPSHOT = "browser_snapshot"
    BROWSER_CLICK = "browser_click"
    BROWSER_TYPE = "browser_type"
    BROWSER_SCREENSHOT = "browser_screenshot"
    BROWSER_NAVIGATE = "browser_navigate"
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    FILE_EXECUTE = "file_execute"
    SHELL_COMMAND = "shell_command"


@dataclass
class ComputerToolResult:
    """Result from a computer tool execution."""
    tool: str
    success: bool
    output: Any = None
    error: Optional[str] = None
    screenshot: Optional[str] = None  # Base64 encoded screenshot
    elements: Optional[List[Dict]] = None  # UI elements for next action
    execution_time_ms: float = 0.0


@dataclass
class BrowserSession:
    """Browser session for autonomous actions."""
    session_id: str
    browser: Optional[Any] = None
    context: Optional[Any] = None
    page: Optional[Any] = None
    cookies: List[Dict] = field(default_factory=list)
    local_storage: Dict[str, str] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: str(time.time()))
    last_activity: str = field(default_factory=lambda: str(time.time()))


class ComputerUseToolkit:
    """
    Autonomous computer use toolkit for agent actions.
    
    Enables agents to:
    - Open browsers and navigate to URLs
    - Authenticate via OAuth flows (social account creation)
    - Fill forms and interact with UI elements
    - Execute shell commands
    - Read/write files
    """
    
    def __init__(self, data_dir: str = "data/media/computer_use"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.computer_use")
        
        # Browser sessions
        self._sessions: Dict[str, BrowserSession] = {}
        self._playwright = None
        
        # Tool registry
        self._tools: Dict[ToolCapability, Callable] = {
            ToolCapability.BROWSER_OPEN: self._browser_open,
            ToolCapability.BROWSER_SNAPSHOT: self._browser_snapshot,
            ToolCapability.BROWSER_CLICK: self._browser_click,
            ToolCapability.BROWSER_TYPE: self._browser_type,
            ToolCapability.BROWSER_SCREENSHOT: self._browser_screenshot,
            ToolCapability.BROWSER_NAVIGATE: self._browser_navigate,
            ToolCapability.FILE_READ: self._file_read,
            ToolCapability.FILE_WRITE: self._file_write,
            ToolCapability.SHELL_COMMAND: self._shell_command,
        }
    
    async def initialize(self) -> bool:
        """Initialize the computer use toolkit."""
        if not PLAYWRIGHT_AVAILABLE:
            self.logger.warning("Playwright not available. Browser automation disabled.")
            return False
        
        try:
            self._playwright = await async_playwright().start()
            self.logger.info("Computer use toolkit initialized with Playwright")
            return True
        except Exception as e:
            self.logger.error(f"Failed to initialize Playwright: {e}")
            return False
    
    async def cleanup(self) -> None:
        """Cleanup all browser sessions."""
        for session in self._sessions.values():
            if session.page:
                await session.page.close()
            if session.context:
                await session.context.close()
            if session.browser:
                await session.browser.close()
        
        if self._playwright:
            await self._playwright.stop()
        
        self._sessions.clear()
        self.logger.info("Computer use toolkit cleaned up")
    
    # =========================================================================
    # Browser Automation
    # =========================================================================
    
    async def create_browser_session(
        self,
        headless: bool = True,
        viewport: Optional[Dict] = None
    ) -> str:
        """Create a new browser session using Chrome on macOS."""
        if not self._playwright:
            await self.initialize()
        
        session_id = f"session_{uuid.uuid4().hex[:8]}"
        
        viewport = viewport or {"width": 1280, "height": 720}
        
        try:
            # Use Chrome on macOS with specific executable path
            chrome_path = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
            context = await self._playwright.chromium.launch_persistent_context(
                user_data_dir=f"/tmp/playwright_{session_id}",
                headless=headless,
                viewport=viewport,
                executable_path=chrome_path,
                args=[
                    '--no-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-gpu',
                    '--disable-software-rasterizer',
                    '--disable-extensions'
                ]
            )
            
            page = context.pages[0] if context.pages else None
            
            session = BrowserSession(
                session_id=session_id,
                context=context,
                page=page
            )
            
            self._sessions[session_id] = session
            self.logger.info(f"Created browser session: {session_id}")
            
            return session_id
            
        except Exception as e:
            self.logger.error(f"Failed to create browser session: {e}")
            raise
    
    async def get_session(self, session_id: str) -> Optional[BrowserSession]:
        """Get a browser session by ID."""
        return self._sessions.get(session_id)
    
    async def _browser_open(
        self,
        url: str,
        session_id: Optional[str] = None,
        headless: bool = True
    ) -> ComputerToolResult:
        """Open a URL in browser."""
        start = time.time()
        
        try:
            if not session_id or session_id not in self._sessions:
                session_id = await self.create_browser_session(headless=headless)
            
            session = self._sessions[session_id]
            await session.page.goto(url, wait_until="networkidle")
            
            # Update last activity
            session.last_activity = str(time.time())
            
            # Get elements for interaction
            elements = await self._extract_elements(session.page)
            
            return ComputerToolResult(
                tool="browser_open",
                success=True,
                output={"url": url, "session_id": session_id},
                elements=elements,
                execution_time_ms=(time.time() - start) * 1000
            )
            
        except Exception as e:
            return ComputerToolResult(
                tool="browser_open",
                success=False,
                error=str(e),
                execution_time_ms=(time.time() - start) * 1000
            )
    
    async def _browser_navigate(
        self,
        url: str,
        session_id: str
    ) -> ComputerToolResult:
        """Navigate to a URL."""
        return await self._browser_open(url, session_id)
    
    async def _browser_snapshot(self, session_id: str) -> ComputerToolResult:
        """Get current state of the page (elements and positions)."""
        start = time.time()
        
        try:
            session = self._sessions.get(session_id)
            if not session:
                return ComputerToolResult(
                    tool="browser_snapshot",
                    success=False,
                    error="Session not found"
                )
            
            elements = await self._extract_elements(session.page)
            
            session.last_activity = str(time.time())
            
            return ComputerToolResult(
                tool="browser_snapshot",
                success=True,
                output={"element_count": len(elements)},
                elements=elements,
                execution_time_ms=(time.time() - start) * 1000
            )
            
        except Exception as e:
            return ComputerToolResult(
                tool="browser_snapshot",
                success=False,
                error=str(e),
                execution_time_ms=(time.time() - start) * 1000
            )
    
    async def _extract_elements(self, page: Any) -> List[Dict]:
        """Extract interactive elements from page."""
        elements = []
        
        try:
            # Get all interactive elements
            await page.wait_for_selector("body", timeout=5000)
            
            # Extract buttons, inputs, links
            selectors = [
                ("button", "button"),
                ("input", "input"),
                ("a", "link"),
                ("textarea", "textarea"),
                ("select", "select"),
            ]
            
            element_id = 0
            for css_sel, elem_type in selectors:
                try:
                    elems = await page.query_selector_all(css_sel)
                    for elem in elems:
                        info = await elem.evaluate("""
// Extract element info
(el) => {
    const rect = el.getBoundingClientRect();
    const is_visible = rect.width > 0 && rect.height > 0;
    return {
        tag: el.tagName.toLowerCase(),
        type: el.type || null,
        id: el.id || null,
        class: el.className || null,
        text: el.innerText?.substring(0, 100) || null,
        href: el.href || null,
        placeholder: el.placeholder || null,
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        width: Math.round(rect.width),
        height: Math.round(rect.height),
        disabled: el.disabled || false,
        required: el.required || false
    };
}
                        """)
                        
                        if info and info.get("is_visible", True):
                            elements.append({
                                "ref": f"e{element_id}",
                                "type": elem_type,
                                "tag": info.get("tag"),
                                "id": info.get("id"),
                                "class": info.get("class"),
                                "text": info.get("text"),
                                "href": info.get("href"),
                                "placeholder": info.get("placeholder"),
                                "position": {"x": info.get("x"), "y": info.get("y")},
                                "size": {"width": info.get("width"), "height": info.get("height")},
                                "disabled": info.get("disabled"),
                            })
                            element_id += 1
                            
                except Exception:
                    continue
                    
        except Exception as e:
            self.logger.debug(f"Element extraction error: {e}")
        
        return elements
    
    async def _browser_click(
        self,
        element_ref: str,
        session_id: str
    ) -> ComputerToolResult:
        """Click an element by reference."""
        start = time.time()
        
        try:
            session = self._sessions.get(session_id)
            if not session:
                return ComputerToolResult(
                    tool="browser_click",
                    success=False,
                    error="Session not found"
                )
            
            # Find element by ref
            # Element refs are in format "e12" meaning index 12
            ref_index = int(element_ref.replace("e", ""))
            elements = await self._extract_elements(session.page)
            
            if ref_index >= len(elements):
                return ComputerToolResult(
                    tool="browser_click",
                    success=False,
                    error=f"Element {element_ref} not found"
                )
            
            # Click the element
            elem = elements[ref_index]
            x = elem["position"]["x"] + elem["size"]["width"] // 2
            y = elem["position"]["y"] + elem["size"]["height"] // 2
            
            await session.page.mouse.click(x, y)
            
            # Wait for navigation or UI update
            await asyncio.sleep(0.5)
            
            # Get updated elements
            new_elements = await self._extract_elements(session.page)
            session.last_activity = str(time.time())
            
            return ComputerToolResult(
                tool="browser_click",
                success=True,
                output={"clicked": element_ref, "new_elements": len(new_elements)},
                elements=new_elements,
                execution_time_ms=(time.time() - start) * 1000
            )
            
        except Exception as e:
            return ComputerToolResult(
                tool="browser_click",
                success=False,
                error=str(e),
                execution_time_ms=(time.time() - start) * 1000
            )
    
    async def _browser_type(
        self,
        element_ref: str,
        text: str,
        session_id: str,
        press_enter: bool = False
    ) -> ComputerToolResult:
        """Type text into an element."""
        start = time.time()
        
        try:
            session = self._sessions.get(session_id)
            if not session:
                return ComputerToolResult(
                    tool="browser_type",
                    success=False,
                    error="Session not found"
                )
            
            elements = await self._extract_elements(session.page)
            ref_index = int(element_ref.replace("e", ""))
            
            if ref_index >= len(elements):
                return ComputerToolResult(
                    tool="browser_type",
                    success=False,
                    error=f"Element {element_ref} not found"
                )
            
            elem = elements[ref_index]
            x = elem["position"]["x"] + elem["size"]["width"] // 2
            y = elem["position"]["y"] + elem["size"]["height"] // 2
            
            # Click to focus, then type
            await session.page.mouse.click(x, y)
            await asyncio.sleep(0.2)
            await session.page.keyboard.type(text, delay=50)
            
            if press_enter:
                await session.page.keyboard.press("Enter")
            
            new_elements = await self._extract_elements(session.page)
            session.last_activity = str(time.time())
            
            return ComputerToolResult(
                tool="browser_type",
                success=True,
                output={"typed": text, "element": element_ref},
                elements=new_elements,
                execution_time_ms=(time.time() - start) * 1000
            )
            
        except Exception as e:
            return ComputerToolResult(
                tool="browser_type",
                success=False,
                error=str(e),
                execution_time_ms=(time.time() - start) * 1000
            )
    
    async def _browser_screenshot(
        self,
        session_id: str,
        full_page: bool = False
    ) -> ComputerToolResult:
        """Take a screenshot of the current page."""
        start = time.time()
        
        try:
            session = self._sessions.get(session_id)
            if not session:
                return ComputerToolResult(
                    tool="browser_screenshot",
                    success=False,
                    error="Session not found"
                )
            
            screenshot_bytes = await session.page.screenshot(
                full_page=full_page,
                type="png"
            )
            
            screenshot_b64 = base64.b64encode(screenshot_bytes).decode()
            
            session.last_activity = str(time.time())
            
            return ComputerToolResult(
                tool="browser_screenshot",
                success=True,
                output={"size_bytes": len(screenshot_bytes)},
                screenshot=screenshot_b64,
                execution_time_ms=(time.time() - start) * 1000
            )
            
        except Exception as e:
            return ComputerToolResult(
                tool="browser_screenshot",
                success=False,
                error=str(e),
                execution_time_ms=(time.time() - start) * 1000
            )
    
    # =========================================================================
    # File Operations
    # =========================================================================
    
    async def _file_read(self, path: str) -> ComputerToolResult:
        """Read a file."""
        start = time.time()
        
        try:
            file_path = Path(path)
            if not file_path.exists():
                return ComputerToolResult(
                    tool="file_read",
                    success=False,
                    error=f"File not found: {path}"
                )
            
            content = file_path.read_text()
            
            return ComputerToolResult(
                tool="file_read",
                success=True,
                output={"path": path, "size": len(content), "content": content[:10000]},
                execution_time_ms=(time.time() - start) * 1000
            )
            
        except Exception as e:
            return ComputerToolResult(
                tool="file_read",
                success=False,
                error=str(e),
                execution_time_ms=(time.time() - start) * 1000
            )
    
    async def _file_write(self, path: str, content: str) -> ComputerToolResult:
        """Write content to a file."""
        start = time.time()
        
        try:
            file_path = Path(path)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(content)
            
            return ComputerToolResult(
                tool="file_write",
                success=True,
                output={"path": path, "size": len(content)},
                execution_time_ms=(time.time() - start) * 1000
            )
            
        except Exception as e:
            return ComputerToolResult(
                tool="file_write",
                success=False,
                error=str(e),
                execution_time_ms=(time.time() - start) * 1000
            )
    
    # =========================================================================
    # Shell Commands
    # =========================================================================
    
    async def _shell_command(self, command: str) -> ComputerToolResult:
        """Execute a shell command."""
        start = time.time()
        
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=60
            )
            
            return ComputerToolResult(
                tool="shell_command",
                success=result.returncode == 0,
                output={
                    "stdout": result.stdout[:5000],
                    "stderr": result.stderr[:5000],
                    "returncode": result.returncode
                },
                execution_time_ms=(time.time() - start) * 1000
            )
            
        except Exception as e:
            return ComputerToolResult(
                tool="shell_command",
                success=False,
                error=str(e),
                execution_time_ms=(time.time() - start) * 1000
            )
    
    # =========================================================================
    # High-Level Workflows
    # =========================================================================
    
    async def execute_oauth_flow(
        self,
        platform: str,
        client_id: str,
        redirect_uri: str,
        scopes: List[str]
    ) -> Dict[str, Any]:
        """
        Execute OAuth authentication flow for a platform.
        
        Args:
            platform: Platform name (tiktok, youtube, instagram, x)
            client_id: OAuth client ID
            redirect_uri: Callback URL
            scopes: Required OAuth scopes
            
        Returns:
            OAuth tokens and session info
        """
        auth_url = self._build_oauth_url(platform, client_id, redirect_uri, scopes)
        
        # Create browser session for auth
        session_id = await self.create_browser_session(headless=False)
        
        try:
            # Open auth page
            result = await self._browser_open(auth_url, session_id)
            if not result.success:
                return {"success": False, "error": result.error}
            
            # Wait for user to complete auth (in autonomous mode, we'd need to handle this)
            # For now, return the auth URL for manual completion
            # In production, this would integrate with a callback server
            
            return {
                "success": True,
                "session_id": session_id,
                "auth_url": auth_url,
                "requires_manual_interaction": True
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _build_oauth_url(
        self,
        platform: str,
        client_id: str,
        redirect_uri: str,
        scopes: List[str]
    ) -> str:
        """Build OAuth authorization URL for platform."""
        
        oauth_urls = {
            "tiktok": f"https://www.tiktok.com/auth/authorize/?client_id={client_id}&redirect_uri={redirect_uri}&response_type=code&scope={'+'.join(scopes)}",
            "youtube": f"https://accounts.google.com/o/oauth2/v2/auth?client_id={client_id}&redirect_uri={redirect_uri}&response_type=code&scope={'+'.join(scopes)}",
            "instagram": f"https://api.instagram.com/oauth/authorize?client_id={client_id}&redirect_uri={redirect_uri}&scope={'+'.join(scopes)}&response_type=code",
            "x": f"https://twitter.com/i/oauth2/authorize?client_id={client_id}&redirect_uri={redirect_uri}&scope={'+'.join(scopes)}&response_type=code",
            "linkedin": f"https://www.linkedin.com/oauth/v2/authorization?client_id={client_id}&redirect_uri={redirect_uri}&scope={'+'.join(scopes)}&response_type=code",
        }
        
        return oauth_urls.get(platform.lower(), "")
    
    async def create_social_account(
        self,
        platform: str,
        credentials: Dict[str, str],
        browser_session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a social media account using browser automation.
        
        Args:
            platform: Target platform
            credentials: Account credentials (email, password, etc.)
            browser_session_id: Optional existing browser session
            
        Returns:
            Created account info
        """
        session_id = browser_session_id or await self.create_browser_session(headless=False)
        
        signup_flows = {
            "tiktok": self._tiktok_signup_flow,
            "youtube": self._youtube_signup_flow,
            "instagram": self._instagram_signup_flow,
            "x": self._twitter_signup_flow,
        }
        
        flow = signup_flows.get(platform.lower())
        if not flow:
            return {"success": False, "error": f"Unknown platform: {platform}"}
        
        try:
            result = await flow(session_id, credentials)
            return result
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def _tiktok_signup_flow(
        self,
        session_id: str,
        credentials: Dict
    ) -> Dict[str, Any]:
        """Execute TikTok signup flow."""
        signup_url = "https://www.tiktok.com/signup"
        
        await self._browser_open(signup_url, session_id)
        await asyncio.sleep(2)
        
        # Get elements
        snapshot = await self._browser_snapshot(session_id)
        
        # Find signup options and proceed
        return {
            "success": True,
            "platform": "tiktok",
            "session_id": session_id,
            "elements_found": len(snapshot.elements or []),
            "next_step": "email_verification"
        }
    
    async def _youtube_signup_flow(
        self,
        session_id: str,
        credentials: Dict
    ) -> Dict[str, Any]:
        """Execute YouTube channel signup flow."""
        channel_url = "https://www.youtube.com/channel_create"
        
        await self._browser_open(channel_url, session_id)
        await asyncio.sleep(2)
        
        return {
            "success": True,
            "platform": "youtube",
            "session_id": session_id,
            "next_step": "google_account_link"
        }
    
    async def _instagram_signup_flow(
        self,
        session_id: str,
        credentials: Dict
    ) -> Dict[str, Any]:
        """Execute Instagram signup flow."""
        signup_url = "https://www.instagram.com/accounts/emailsignup/"
        
        await self._browser_open(signup_url, session_id)
        await asyncio.sleep(2)
        
        return {
            "success": True,
            "platform": "instagram",
            "session_id": session_id,
            "next_step": "phone_verification"
        }
    
    async def _twitter_signup_flow(
        self,
        session_id: str,
        credentials: Dict
    ) -> Dict[str, Any]:
        """Execute X/Twitter signup flow."""
        signup_url = "https://twitter.com/i/flow/signup"
        
        await self._browser_open(signup_url, session_id)
        await asyncio.sleep(2)
        
        return {
            "success": True,
            "platform": "x",
            "session_id": session_id,
            "next_step": "email_verification"
        }
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get toolkit metrics."""
        return {
            "active_sessions": len(self._sessions),
            "session_ids": list(self._sessions.keys()),
            "playwright_available": PLAYWRIGHT_AVAILABLE
        }


# Convenience function
def create_computer_use_toolkit(data_dir: str = "data/media/computer_use") -> ComputerUseToolkit:
    """Create a computer use toolkit instance."""
    return ComputerUseToolkit(data_dir=data_dir)
