"""
Monetization Engine for KashClaw Media Grid.

Revenue aggregation and content calendar module that:
- Aggregates all revenue streams (affiliate, brand deals, AdSense, sponsorships)
- Tracks revenue per platform, per content type, per time period
- Generates revenue reports (daily, weekly, monthly)
- Forecasts future revenue based on trends
- Manages the content calendar (scheduled posts across all platforms)
- Coordinates cross-platform content timing
- Tracks viral content amplification
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from pathlib import Path
import json
import uuid


@dataclass
class RevenueStream:
    """Represents a single revenue transaction."""
    stream_id: str
    source: str  # "affiliate", "brand_deal", "adsense", "sponsorship", "tips"
    platform: str
    amount: float
    currency: str = "USD"
    earned_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    content_id: Optional[str] = None
    affiliate_offer_id: Optional[str] = None
    deal_id: Optional[str] = None
    status: str = "earned"  # "earned", "pending", "paid", "clawed_back"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RevenueStream":
        return cls(**data)


@dataclass
class ContentCalendarEntry:
    """Represents a scheduled piece of content across platforms."""
    entry_id: str
    content_brief_id: str
    script_id: Optional[str]
    asset_id: Optional[str]
    platforms: List[str]  # ["youtube_shorts", "tiktok", "instagram_reels"]
    scheduled_time: str
    status: str = "draft"  # "draft", "ready", "scheduled", "published", "failed"
    posted_at: Optional[str] = None
    post_ids: Dict[str, str] = field(default_factory=dict)  # platform -> post_id
    content_type: str = "short"
    topic: str = ""
    expected_revenue: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ContentCalendarEntry":
        return cls(**data)


class MonetizationEngine:
    """
    Revenue aggregation and content calendar module.
    
    Aggregates all revenue streams and manages the content calendar
    for cross-platform content distribution.
    """

    # Platform engagement benchmarks for viral detection (engagement_rate thresholds)
    PLATFORM_BENCHMARKS = {
        "youtube_shorts": 0.05,      # 5% engagement rate is average
        "youtube_long": 0.03,        # 3% for long-form
        "tiktok": 0.08,              # 8% for TikTok
        "instagram_reels": 0.04,     # 4% for Instagram Reels
        "instagram_post": 0.02,      # 2% for static posts
        "instagram_story": 0.03,     # 3% for stories
        "twitter": 0.02,             # 2% for Twitter
        "facebook": 0.01,            # 1% for Facebook
        "threads": 0.03,             # 3% for Threads
        "pinterest": 0.02,           # 2% for Pinterest
    }

    def __init__(self, data_dir: str = "data/media"):
        self.data_dir = Path(data_dir)
        self.revenue_dir = self.data_dir / "monetization"
        self.revenue_dir.mkdir(parents=True, exist_ok=True)
        self.calendar_dir = self.data_dir / "calendar"
        self.calendar_dir.mkdir(parents=True, exist_ok=True)
        
        self.revenue_ledger_path = self.revenue_dir / "revenue_streams.jsonl"
        self.calendar_ledger_path = self.calendar_dir / "scheduled_content.jsonl"
        self.performance_metrics_path = self.data_dir / "performance_metrics.jsonl"
        
        self._revenue_streams: List[RevenueStream] = []
        self._calendar_entries: Dict[str, ContentCalendarEntry] = {}
        self._performance_cache: List[Dict[str, Any]] = []
        self._load_data()
    
    # ── Revenue Recording ─────────────────────────────────────────────────

    def record_revenue(self, stream: RevenueStream) -> str:
        """
        Record a revenue stream and persist to ledger.
        
        Args:
            stream: RevenueStream object with transaction details
            
        Returns:
            The stream_id of the recorded revenue
        """
        if not stream.stream_id:
            stream.stream_id = str(uuid.uuid4())
        
        self._revenue_streams.append(stream)
        self._save_revenue_stream(stream)
        return stream.stream_id

    def record_affiliate_revenue(
        self,
        offer_id: str,
        platform: str,
        amount: float,
        content_id: Optional[str] = None
    ) -> str:
        """
        Record affiliate commission earned.
        
        Args:
            offer_id: The affiliate offer identifier
            platform: Platform where the content was posted
            amount: Commission amount earned
            content_id: Optional ID of the content that drove the sale
            
        Returns:
            The stream_id of the recorded revenue
        """
        stream = RevenueStream(
            stream_id=str(uuid.uuid4()),
            source="affiliate",
            platform=platform,
            amount=amount,
            affiliate_offer_id=offer_id,
            content_id=content_id,
            status="earned",
            metadata={"offer_id": offer_id}
        )
        self._revenue_streams.append(stream)
        self._save_revenue_stream(stream)
        return stream.stream_id

    def record_brand_deal_revenue(
        self,
        deal_id: str,
        brand_name: str,
        amount: float,
        status: str = "earned"
    ) -> str:
        """
        Record brand deal payment.
        
        Args:
            deal_id: Unique identifier for the brand deal
            brand_name: Name of the brand
            amount: Payment amount
            status: Payment status (earned, pending, paid, clawed_back)
            
        Returns:
            The stream_id of the recorded revenue
        """
        stream = RevenueStream(
            stream_id=str(uuid.uuid4()),
            source="brand_deal",
            platform="direct",
            amount=amount,
            deal_id=deal_id,
            status=status,
            metadata={"brand_name": brand_name, "deal_id": deal_id}
        )
        self._revenue_streams.append(stream)
        self._save_revenue_stream(stream)
        return stream.stream_id

    def record_adsense_revenue(
        self,
        video_id: str,
        platform: str,
        amount: float,
        month: str
    ) -> str:
        """
        Record YouTube AdSense revenue.
        
        Args:
            video_id: YouTube video identifier
            platform: Platform (e.g., "youtube_shorts", "youtube_long")
            amount: Revenue amount earned
            month: Month in YYYY-MM format
            
        Returns:
            The stream_id of the recorded revenue
        """
        stream = RevenueStream(
            stream_id=str(uuid.uuid4()),
            source="adsense",
            platform=platform,
            amount=amount,
            content_id=video_id,
            status="earned",
            metadata={"video_id": video_id, "month": month}
        )
        self._revenue_streams.append(stream)
        self._save_revenue_stream(stream)
        return stream.stream_id

    def record_sponsorship_revenue(
        self,
        sponsor_name: str,
        platform: str,
        amount: float,
        contract_id: Optional[str] = None,
        content_id: Optional[str] = None
    ) -> str:
        """
        Record sponsorship revenue.
        
        Args:
            sponsor_name: Name of the sponsor
            platform: Platform for the sponsorship
            amount: Sponsorship payment amount
            contract_id: Optional contract identifier
            content_id: Optional content associated with the sponsorship
            
        Returns:
            The stream_id of the recorded revenue
        """
        stream = RevenueStream(
            stream_id=str(uuid.uuid4()),
            source="sponsorship",
            platform=platform,
            amount=amount,
            content_id=content_id,
            status="earned",
            metadata={"sponsor_name": sponsor_name, "contract_id": contract_id}
        )
        self._revenue_streams.append(stream)
        self._save_revenue_stream(stream)
        return stream.stream_id

    def record_tips_revenue(
        self,
        platform: str,
        amount: float,
        content_id: Optional[str] = None,
        sender_name: Optional[str] = None
    ) -> str:
        """
        Record tips/payments from fans.
        
        Args:
            platform: Platform where the tip was received
            amount: Tip amount
            content_id: Optional associated content
            sender_name: Optional name of the sender
            
        Returns:
            The stream_id of the recorded revenue
        """
        stream = RevenueStream(
            stream_id=str(uuid.uuid4()),
            source="tips",
            platform=platform,
            amount=amount,
            content_id=content_id,
            status="earned",
            metadata={"sender_name": sender_name} if sender_name else {}
        )
        self._revenue_streams.append(stream)
        self._save_revenue_stream(stream)
        return stream.stream_id

    def update_revenue_status(self, stream_id: str, new_status: str) -> bool:
        """
        Update the status of a revenue stream.
        
        Args:
            stream_id: ID of the revenue stream to update
            new_status: New status ("earned", "pending", "paid", "clawed_back")
            
        Returns:
            True if updated, False if not found
        """
        valid_statuses = {"earned", "pending", "paid", "clawed_back"}
        if new_status not in valid_statuses:
            return False
        
        for stream in self._revenue_streams:
            if stream.stream_id == stream_id:
                stream.status = new_status
                self._rewrite_revenue_ledger()
                return True
        return False

    # ── Revenue Queries ────────────────────────────────────────────────────

    def get_daily_revenue(self, date: Optional[str] = None) -> float:
        """
        Total revenue for a specific day (ISO date string).
        
        Args:
            date: ISO date string (YYYY-MM-DD), defaults to today
            
        Returns:
            Total revenue for that day
        """
        if date is None:
            date = datetime.utcnow().strftime("%Y-%m-%d")
        
        total = 0.0
        for stream in self._revenue_streams:
            if stream.status in ("earned", "paid"):
                stream_date = stream.earned_at[:10]  # Extract YYYY-MM-DD
                if stream_date == date:
                    total += stream.amount
        return total

    def get_weekly_revenue(self, week_start: Optional[str] = None) -> float:
        """
        Total revenue for a week starting on given date.
        
        Args:
            week_start: ISO date string for the start of the week (Monday),
                       defaults to current week's Monday
            
        Returns:
            Total revenue for the week
        """
        if week_start is None:
            today = datetime.utcnow()
            week_start = (today - timedelta(days=today.weekday())).strftime("%Y-%m-%d")
        
        try:
            start_date = datetime.strptime(week_start, "%Y-%m-%d")
        except ValueError:
            return 0.0
        
        end_date = start_date + timedelta(days=7)
        
        total = 0.0
        for stream in self._revenue_streams:
            if stream.status in ("earned", "paid"):
                try:
                    stream_date = datetime.fromisoformat(stream.earned_at)
                    if start_date <= stream_date < end_date:
                        total += stream.amount
                except ValueError:
                    continue
        return total

    def get_monthly_revenue(self, month: Optional[str] = None) -> float:
        """
        Total revenue for a month (format: 'YYYY-MM').
        
        Args:
            month: Month string, defaults to current month
            
        Returns:
            Total revenue for that month
        """
        if month is None:
            month = datetime.utcnow().strftime("%Y-%m")
        
        total = 0.0
        for stream in self._revenue_streams:
            if stream.status in ("earned", "paid"):
                stream_month = stream.earned_at[:7]  # Extract YYYY-MM
                if stream_month == month:
                    total += stream.amount
        return total

    def get_revenue_by_platform(self, period_days: int = 30) -> Dict[str, float]:
        """
        Revenue breakdown by platform.
        
        Args:
            period_days: Number of days to look back
            
        Returns:
            Dict mapping platform names to revenue totals
        """
        cutoff = datetime.utcnow() - timedelta(days=period_days)
        revenue_by_platform: Dict[str, float] = {}
        
        for stream in self._revenue_streams:
            if stream.status not in ("earned", "paid"):
                continue
            try:
                stream_date = datetime.fromisoformat(stream.earned_at)
                if stream_date >= cutoff:
                    platform = stream.platform
                    revenue_by_platform[platform] = revenue_by_platform.get(platform, 0.0) + stream.amount
            except ValueError:
                continue
        
        return revenue_by_platform

    def get_revenue_by_source(self, period_days: int = 30) -> Dict[str, float]:
        """
        Revenue breakdown by source (affiliate, brand_deal, adsense, etc).
        
        Args:
            period_days: Number of days to look back
            
        Returns:
            Dict mapping source names to revenue totals
        """
        cutoff = datetime.utcnow() - timedelta(days=period_days)
        revenue_by_source: Dict[str, float] = {}
        
        for stream in self._revenue_streams:
            if stream.status not in ("earned", "paid"):
                continue
            try:
                stream_date = datetime.fromisoformat(stream.earned_at)
                if stream_date >= cutoff:
                    source = stream.source
                    revenue_by_source[source] = revenue_by_source.get(source, 0.0) + stream.amount
            except ValueError:
                continue
        
        return revenue_by_source

    def get_revenue_forecast(self, months: int = 3) -> Dict:
        """
        Forecast revenue for next N months using weighted moving average.
        
        Uses last 3 months data with weights:
        - Most recent month: 0.5
        - Middle month: 0.3
        - Oldest month: 0.2
        
        Applies growth rate from trend.
        
        Args:
            months: Number of months to forecast
            
        Returns:
            Dict with monthly forecasts and confidence level
        """
        forecasts = []
        monthly_totals = []
        
        # Get last 3 months of data
        for i in range(3):
            month_date = datetime.utcnow() - timedelta(days=30 * i)
            month_str = month_date.strftime("%Y-%m")
            monthly_totals.append(self.get_monthly_revenue(month_str))
        
        # Ensure we have at least some data
        if all(t == 0 for t in monthly_totals):
            return {
                "forecasts": [{"month": "", "predicted_revenue": 0.0} for _ in range(months)],
                "confidence": "low",
                "methodology": "weighted_moving_average",
                "weights": {"month_1": 0.5, "month_2": 0.3, "month_3": 0.2}
            }
        
        # Calculate weighted average
        month_1, month_2, month_3 = monthly_totals[0], monthly_totals[1], monthly_totals[2]
        weighted_avg = 0.5 * month_1 + 0.3 * month_2 + 0.2 * month_3
        
        # Calculate growth rate from trend
        growth = 0.0
        if month_2 > 0:
            growth = (month_1 - month_2) / month_2
        
        # Generate forecasts for each month
        base_month = datetime.utcnow()
        for i in range(1, months + 1):
            forecast_date = base_month + timedelta(days=30 * i)
            # Apply growth with dampening factor
            growth_factor = 1 + (growth * 0.5 * i)
            predicted = weighted_avg * growth_factor
            
            forecasts.append({
                "month": forecast_date.strftime("%Y-%m"),
                "predicted_revenue": round(predicted, 2),
                "growth_applied": round(growth_factor - 1, 4) if growth_factor != 1 else 0
            })
        
        # Calculate confidence based on data consistency
        if all(t > 0 for t in monthly_totals):
            variance = sum((t - sum(monthly_totals) / 3) ** 2 for t in monthly_totals) / 3
            avg = sum(monthly_totals) / 3
            if avg > 0:
                cv = (variance ** 0.5) / avg  # Coefficient of variation
                if cv < 0.2:
                    confidence = "high"
                elif cv < 0.5:
                    confidence = "medium"
                else:
                    confidence = "low"
            else:
                confidence = "low"
        else:
            confidence = "low"
        
        return {
            "forecasts": forecasts,
            "confidence": confidence,
            "methodology": "weighted_moving_average",
            "weights": {"month_1": 0.5, "month_2": 0.3, "month_3": 0.2},
            "historical_months": [
                {"month": (datetime.utcnow() - timedelta(days=30 * i)).strftime("%Y-%m"),
                 "actual_revenue": monthly_totals[i]}
                for i in range(3)
            ],
            "growth_rate": round(growth, 4)
        }

    def get_pending_payouts(self) -> float:
        """
        Total revenue earned but not yet received (status=earned, not paid).
        
        Returns:
            Total pending payout amount
        """
        total = 0.0
        for stream in self._revenue_streams:
            if stream.status == "earned":
                total += stream.amount
        return total

    def get_total_lifetime_revenue(self) -> float:
        """
        Sum of all revenue streams with status in (earned, paid).
        
        Returns:
            Total lifetime revenue
        """
        total = 0.0
        for stream in self._revenue_streams:
            if stream.status in ("earned", "paid"):
                total += stream.amount
        return total

    def get_revenue_timeline(self, period_days: int = 30) -> List[Dict[str, Any]]:
        """
        Get daily revenue totals for the specified period.
        
        Args:
            period_days: Number of days to include
            
        Returns:
            List of dicts with date and revenue totals
        """
        timeline = []
        today = datetime.utcnow()
        
        for i in range(period_days):
            date = today - timedelta(days=i)
            date_str = date.strftime("%Y-%m-%d")
            daily_revenue = self.get_daily_revenue(date_str)
            timeline.append({
                "date": date_str,
                "revenue": daily_revenue
            })
        
        return list(reversed(timeline))

    # ── Content Calendar ─────────────────────────────────────────────────

    def schedule_content(self, entry: ContentCalendarEntry) -> str:
        """
        Add content to the calendar.
        
        Args:
            entry: ContentCalendarEntry to schedule
            
        Returns:
            The entry_id of the scheduled content
        """
        if not entry.entry_id:
            entry.entry_id = str(uuid.uuid4())
        
        self._calendar_entries[entry.entry_id] = entry
        self._save_calendar_entry(entry)
        return entry.entry_id

    def get_calendar(
        self,
        start_date: str,
        end_date: str
    ) -> List[ContentCalendarEntry]:
        """
        Get all calendar entries in a date range.
        
        Args:
            start_date: ISO date string for range start
            end_date: ISO date string for range end
            
        Returns:
            List of ContentCalendarEntry objects in range
        """
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
        except ValueError:
            return []
        
        entries = []
        for entry in self._calendar_entries.values():
            try:
                entry_date = datetime.fromisoformat(entry.scheduled_time)
                if start <= entry_date <= end:
                    entries.append(entry)
            except ValueError:
                continue
        
        return sorted(entries, key=lambda e: e.scheduled_time)

    def get_upcoming_posts(self, hours: int = 24) -> List[ContentCalendarEntry]:
        """
        Get posts scheduled in next N hours.
        
        Args:
            hours: Number of hours to look ahead
            
        Returns:
            List of upcoming ContentCalendarEntry objects
        """
        now = datetime.utcnow()
        cutoff = now + timedelta(hours=hours)
        
        upcoming = []
        for entry in self._calendar_entries.values():
            if entry.status not in ("published", "cancelled"):
                try:
                    entry_time = datetime.fromisoformat(entry.scheduled_time)
                    if now <= entry_time <= cutoff:
                        upcoming.append(entry)
                except ValueError:
                    continue
        
        return sorted(upcoming, key=lambda e: e.scheduled_time)

    def mark_published(
        self,
        entry_id: str,
        post_ids: Dict[str, str]
    ) -> bool:
        """
        Mark calendar entry as published with post IDs.
        
        Args:
            entry_id: ID of the calendar entry
            post_ids: Dict mapping platform names to their post IDs
            
        Returns:
            True if marked successfully, False if not found
        """
        if entry_id not in self._calendar_entries:
            return False
        
        entry = self._calendar_entries[entry_id]
        entry.status = "published"
        entry.posted_at = datetime.utcnow().isoformat()
        entry.post_ids = post_ids
        
        self._rewrite_calendar_ledger()
        return True

    def get_overdue_posts(self) -> List[ContentCalendarEntry]:
        """
        Get posts past scheduled_time that haven't been published.
        
        Returns:
            List of overdue ContentCalendarEntry objects
        """
        now = datetime.utcnow()
        overdue = []
        
        for entry in self._calendar_entries.values():
            if entry.status in ("scheduled", "ready", "draft"):
                try:
                    entry_time = datetime.fromisoformat(entry.scheduled_time)
                    if entry_time < now:
                        overdue.append(entry)
                except ValueError:
                    continue
        
        return sorted(overdue, key=lambda e: e.scheduled_time)

    def cancel_scheduled(self, entry_id: str, reason: str = "") -> bool:
        """
        Cancel a scheduled post.
        
        Args:
            entry_id: ID of the calendar entry to cancel
            reason: Optional cancellation reason
            
        Returns:
            True if cancelled, False if not found
        """
        if entry_id not in self._calendar_entries:
            return False
        
        entry = self._calendar_entries[entry_id]
        entry.status = "cancelled"
        entry.metadata["cancellation_reason"] = reason
        entry.metadata["cancelled_at"] = datetime.utcnow().isoformat()
        
        self._rewrite_calendar_ledger()
        return True

    def update_entry_status(self, entry_id: str, new_status: str) -> bool:
        """
        Update the status of a calendar entry.
        
        Args:
            entry_id: ID of the entry to update
            new_status: New status (draft, ready, scheduled, published, failed, cancelled)
            
        Returns:
            True if updated, False if not found or invalid status
        """
        valid_statuses = {"draft", "ready", "scheduled", "published", "failed", "cancelled"}
        if new_status not in valid_statuses:
            return False
        
        if entry_id not in self._calendar_entries:
            return False
        
        self._calendar_entries[entry_id].status = new_status
        self._rewrite_calendar_ledger()
        return True

    # ── Viral Detection & Amplification ──────────────────────────────────

    def detect_viral_content(self) -> List[Dict]:
        """
        Find content with engagement rate > 3x platform average within first 2 hours.
        
        Returns:
            List of viral content dicts with amplification recommendations
        """
        self._load_performance_metrics()
        
        viral_content = []
        cutoff_time = datetime.utcnow() - timedelta(hours=2)
        
        for metric in self._performance_cache:
            try:
                # Parse metrics
                content_id = metric.get("content_id", "")
                platform = metric.get("platform", "")
                posted_at = metric.get("posted_at", "")
                
                if not posted_at or not content_id:
                    continue
                
                posted_time = datetime.fromisoformat(posted_at)
                
                # Only consider content posted in the last 2 hours
                if posted_time < cutoff_time:
                    continue
                
                # Get engagement metrics
                views = metric.get("views", 0)
                likes = metric.get("likes", 0)
                comments = metric.get("comments", 0)
                shares = metric.get("shares", 0)
                
                if views == 0:
                    continue
                
                # Calculate engagement rate
                # engagement_rate = (likes + comments + shares * 2) / views
                engagement_rate = (likes + comments + shares * 2) / views
                
                # Get platform benchmark
                benchmark = self.PLATFORM_BENCHMARKS.get(platform, 0.03)
                viral_threshold = benchmark * 3
                
                if engagement_rate >= viral_threshold:
                    # This is viral content
                    days_since_post = (datetime.utcnow() - posted_time).total_seconds() / 3600
                    
                    viral_content.append({
                        "content_id": content_id,
                        "platform": platform,
                        "engagement_rate": round(engagement_rate, 4),
                        "benchmark": benchmark,
                        "viral_multiplier": round(engagement_rate / benchmark, 2) if benchmark > 0 else 0,
                        "hours_since_post": round(days_since_post, 1),
                        "views": views,
                        "likes": likes,
                        "comments": comments,
                        "shares": shares,
                        "amplification_needed": True,
                        "recommendations": self._generate_amplification_recommendations(
                            platform, engagement_rate, views
                        )
                    })
            except (ValueError, KeyError):
                continue
        
        # Sort by engagement rate
        viral_content.sort(key=lambda x: x["engagement_rate"], reverse=True)
        return viral_content

    def _generate_amplification_recommendations(
        self,
        platform: str,
        engagement_rate: float,
        views: int
    ) -> List[str]:
        """Generate amplification recommendations for viral content."""
        recommendations = []
        
        # Cross-posting recommendations
        if platform == "tiktok":
            recommendations.append("Cross-post to Instagram Reels with platform-specific hashtags")
            recommendations.append("Create YouTube Shorts version with extended hook")
        elif platform == "youtube_shorts":
            recommendations.append("Create full-length YouTube video on the same topic")
            recommendations.append("Clip the best moments for TikTok")
        elif platform == "instagram_reels":
            recommendations.append("Create carousel post with key takeaways")
            recommendations.append("Cross-post to TikTok and YouTube Shorts")
        
        # Engagement boosting
        if engagement_rate > 0.2:
            recommendations.append("Pin top 3 comments to boost engagement signal")
            recommendations.append("Reply to comments in first 30 minutes to boost algorithm")
        
        # Promotion
        if views < 10000:
            recommendations.append("Consider boosting with $10-20 ad spend")
        elif views < 50000:
            recommendations.append("High potential - boost with $25-50 ad spend")
        
        # Follow-up content
        recommendations.append("Create follow-up content on the same trending topic")
        recommendations.append("Series potential - plan part 2 content")
        
        return recommendations

    def amplify_content(self, content_id: str) -> Dict:
        """
        Create amplification campaign for viral content.
        
        Args:
            content_id: ID of the content to amplify
            
        Returns:
            Dict with amplification plan
        """
        self._load_performance_metrics()
        
        # Find the content
        metric = None
        for m in self._performance_cache:
            if m.get("content_id") == content_id:
                metric = m
                break
        
        if not metric:
            return {
                "content_id": content_id,
                "amplification_plan": None,
                "error": "Content not found in performance metrics"
            }
        
        platform = metric.get("platform", "")
        views = metric.get("views", 0)
        engagement_rate = self._calculate_engagement_rate(metric)
        
        # Generate amplification plan
        plan = {
            "content_id": content_id,
            "platform": platform,
            "current_metrics": {
                "views": views,
                "engagement_rate": round(engagement_rate, 4)
            },
            "cross_post_targets": self._get_cross_post_targets(platform),
            "engagement_actions": self._get_engagement_actions(views, engagement_rate),
            "promotion_budget_suggestion": self._suggest_promotion_budget(views),
            "follow_up_content": self._generate_follow_up_topics(metric),
            "timeline": {
                "immediate": "Reply to comments, pin top comments",
                "1_hour": "Post on second platform if applicable",
                "3_hours": "Review metrics, adjust strategy",
                "24_hours": "Create follow-up content"
            }
        }
        
        return plan

    def _calculate_engagement_rate(self, metric: Dict[str, Any]) -> float:
        """Calculate engagement rate from metric dict."""
        views = metric.get("views", 0)
        if views == 0:
            return 0.0
        likes = metric.get("likes", 0)
        comments = metric.get("comments", 0)
        shares = metric.get("shares", 0)
        return (likes + comments + shares * 2) / views

    def _get_cross_post_targets(self, platform: str) -> List[Dict[str, str]]:
        """Get platforms to cross-post to."""
        cross_post_map = {
            "tiktok": ["instagram_reels", "youtube_shorts"],
            "youtube_shorts": ["tiktok", "instagram_reels"],
            "instagram_reels": ["tiktok", "youtube_shorts"],
        }
        targets = cross_post_map.get(platform, [])
        return [{"platform": p, "action": "cross_post"} for p in targets]

    def _get_engagement_actions(
        self,
        views: int,
        engagement_rate: float
    ) -> List[Dict[str, Any]]:
        """Get recommended engagement actions."""
        actions = []
        
        actions.append({
            "action": "reply_to_comments",
            "priority": "high",
            "target": "top_10_comments",
            "reason": "Boost algorithm signals"
        })
        
        if engagement_rate > 0.1:
            actions.append({
                "action": "pin_comments",
                "priority": "high",
                "count": 3,
                "reason": "Highlight best engagement"
            })
        
        if views < 5000:
            actions.append({
                "action": "share_to_stories",
                "priority": "medium",
                "reason": "Drive initial traction"
            })
        
        return actions

    def _suggest_promotion_budget(self, views: int) -> Dict[str, Any]:
        """Suggest promotion budget based on current views."""
        if views < 1000:
            return {"suggested_budget": 10, "platform": "native_boost", "duration": "1_day"}
        elif views < 10000:
            return {"suggested_budget": 25, "platform": "native_boost", "duration": "2_days"}
        elif views < 50000:
            return {"suggested_budget": 50, "platform": "native_boost", "duration": "3_days"}
        else:
            return {"suggested_budget": 100, "platform": "native_boost", "duration": "5_days"}

    def _generate_follow_up_topics(self, metric: Dict[str, Any]) -> List[str]:
        """Generate follow-up content topic ideas."""
        topic = metric.get("topic", "")
        content_type = metric.get("content_type", "short")
        
        topics = []
        
        if topic:
            topics.append(f"Part 2: {topic} - Expanded Version")
            topics.append(f"Response: {topic} - Community Questions")
        
        topics.append("Behind the scenes of this viral moment")
        topics.append("My honest reaction - 24 hours later")
        
        return topics

    # ── ROI Analysis ─────────────────────────────────────────────────────

    def get_content_roi(self, content_id: str) -> float:
        """
        ROI for specific content: (revenue - costs) / costs * 100.
        
        Args:
            content_id: ID of the content to analyze
            
        Returns:
            ROI percentage
        """
        # Get revenue for this content
        content_revenue = 0.0
        for stream in self._revenue_streams:
            if stream.content_id == content_id and stream.status in ("earned", "paid"):
                content_revenue += stream.amount
        
        # Get costs (would come from content production metrics)
        # For now, estimate based on content type
        costs = self._estimate_content_cost(content_id)
        
        if costs == 0:
            return 0.0
        
        return round((content_revenue - costs) / costs * 100, 2)

    def _estimate_content_cost(self, content_id: str) -> float:
        """Estimate production cost for content."""
        # This would normally look up actual costs from a production tracker
        # For now, return a default estimate
        return 50.0  # Default estimated cost

    def get_platform_roi(self, platform: str, period_days: int = 30) -> float:
        """
        ROI for a platform over a period.
        
        Args:
            platform: Platform name
            period_days: Number of days to analyze
            
        Returns:
            ROI percentage
        """
        cutoff = datetime.utcnow() - timedelta(days=period_days)
        
        # Get revenue for this platform
        platform_revenue = 0.0
        for stream in self._revenue_streams:
            if stream.platform == platform and stream.status in ("earned", "paid"):
                try:
                    stream_date = datetime.fromisoformat(stream.earned_at)
                    if stream_date >= cutoff:
                        platform_revenue += stream.amount
                except ValueError:
                    continue
        
        # Estimate platform costs (content production, promotion, time)
        # This would normally come from actual cost tracking
        estimated_costs = platform_revenue * 0.3  # Assume 30% cost ratio
        
        if estimated_costs == 0:
            return 0.0
        
        return round((platform_revenue - estimated_costs) / estimated_costs * 100, 2)

    def get_top_performers(self, limit: int = 10) -> List[Dict]:
        """
        Top content by revenue generated.
        
        Args:
            limit: Maximum number of results
            
        Returns:
            List of top performing content dicts
        """
        # Aggregate revenue by content
        content_revenue: Dict[str, float] = {}
        content_details: Dict[str, Dict[str, Any]] = {}
        
        for stream in self._revenue_streams:
            if stream.content_id and stream.status in ("earned", "paid"):
                content_id = stream.content_id
                content_revenue[content_id] = content_revenue.get(content_id, 0.0) + stream.amount
                content_details[content_id] = {
                    "content_id": content_id,
                    "platform": stream.platform,
                    "source": stream.source,
                    "stream_count": content_details.get(content_id, {}).get("stream_count", 0) + 1
                }
        
        # Sort by revenue
        sorted_content = sorted(
            content_revenue.items(),
            key=lambda x: x[1],
            reverse=True
        )[:limit]
        
        result = []
        for content_id, revenue in sorted_content:
            details = content_details.get(content_id, {})
            result.append({
                "content_id": content_id,
                "total_revenue": round(revenue, 2),
                "platform": details.get("platform", "unknown"),
                "primary_source": details.get("source", "unknown"),
                "revenue_streams": details.get("stream_count", 1),
                "roi": self.get_content_roi(content_id)
            })
        
        return result

    def get_content_cost_analysis(self) -> Dict:
        """
        Cost breakdown: asset generation, editing, promotion, time cost.
        
        Returns:
            Dict with cost breakdown by category
        """
        # This would normally integrate with actual cost tracking
        # For now, return estimated breakdown based on revenue patterns
        
        total_revenue = self.get_total_lifetime_revenue()
        
        # Estimate costs as percentage of revenue
        return {
            "total_estimated_costs": {
                "asset_generation": total_revenue * 0.08,
                "editing": total_revenue * 0.06,
                "promotion": total_revenue * 0.05,
                "time_cost": total_revenue * 0.10,
                "tools_and_subscriptions": total_revenue * 0.02
            },
            "total_revenue": total_revenue,
            "estimated_profit_margin": round(
                (total_revenue - total_revenue * 0.31) / total_revenue * 100, 2
            ) if total_revenue > 0 else 0,
            "note": "Cost estimates based on industry averages. Integrate with actual cost tracking for accuracy."
        }

    # ── Reports ───────────────────────────────────────────────────────────

    def generate_revenue_report(self, period: str = "month") -> Dict:
        """
        Full revenue report: total, by platform, by source, trends, forecasts.
        
        Args:
            period: Time period (day, week, month)
            
        Returns:
            Comprehensive revenue report dict
        """
        now = datetime.utcnow()
        
        if period == "day":
            period_revenue = self.get_daily_revenue()
            period_start = now.strftime("%Y-%m-%d")
            period_end = period_start
            prev_revenue = self.get_daily_revenue(
                (now - timedelta(days=1)).strftime("%Y-%m-%d")
            )
        elif period == "week":
            week_start = (now - timedelta(days=now.weekday())).strftime("%Y-%m-%d")
            period_revenue = self.get_weekly_revenue(week_start)
            period_start = week_start
            period_end = (datetime.strptime(week_start, "%Y-%m-%d") + timedelta(days=6)).strftime("%Y-%m-%d")
            prev_revenue = self.get_weekly_revenue(
                (datetime.strptime(week_start, "%Y-%m-%d") - timedelta(days=7)).strftime("%Y-%m-%d")
            )
        else:  # month
            month = now.strftime("%Y-%m")
            period_revenue = self.get_monthly_revenue(month)
            period_start = f"{month}-01"
            period_end = (datetime.strptime(month, "%Y-%m") + timedelta(days=32)).strftime("%Y-%m")[:7] + "-31"
            prev_revenue = self.get_monthly_revenue(
                (now - timedelta(days=30)).strftime("%Y-%m")
            )
        
        # Calculate period-over-period change
        if prev_revenue > 0:
            pop_change = ((period_revenue - prev_revenue) / prev_revenue) * 100
        else:
            pop_change = 0.0
        
        forecast = self.get_revenue_forecast(3)
        
        return {
            "period": period,
            "period_start": period_start,
            "period_end": period_end,
            "total_revenue": round(period_revenue, 2),
            "previous_period_revenue": round(prev_revenue, 2),
            "period_over_period_change": round(pop_change, 2),
            "by_platform": {k: round(v, 2) for k, v in self.get_revenue_by_platform(30).items()},
            "by_source": {k: round(v, 2) for k, v in self.get_revenue_by_source(30).items()},
            "pending_payouts": round(self.get_pending_payouts(), 2),
            "lifetime_revenue": round(self.get_total_lifetime_revenue(), 2),
            "forecast": forecast,
            "top_performers": self.get_top_performers(5),
            "generated_at": datetime.utcnow().isoformat()
        }

    def generate_content_report(self, period: str = "week") -> Dict:
        """
        Content performance report: posts published, views, engagement, revenue.
        
        Args:
            period: Time period (day, week, month)
            
        Returns:
            Comprehensive content report dict
        """
        self._load_performance_metrics()
        
        now = datetime.utcnow()
        
        if period == "day":
            cutoff = now - timedelta(days=1)
        elif period == "week":
            cutoff = now - timedelta(days=7)
        else:  # month
            cutoff = now - timedelta(days=30)
        
        # Filter metrics for the period
        period_metrics = []
        for m in self._performance_cache:
            try:
                posted_at = m.get("posted_at", "")
                if posted_at:
                    posted_time = datetime.fromisoformat(posted_at)
                    if posted_time >= cutoff:
                        period_metrics.append(m)
            except ValueError:
                continue
        
        # Calculate aggregates
        total_views = sum(m.get("views", 0) for m in period_metrics)
        total_likes = sum(m.get("likes", 0) for m in period_metrics)
        total_comments = sum(m.get("comments", 0) for m in period_metrics)
        total_shares = sum(m.get("shares", 0) for m in period_metrics)
        
        # Get calendar entries for the period
        calendar_entries = []
        for entry in self._calendar_entries.values():
            try:
                entry_time = datetime.fromisoformat(entry.scheduled_time)
                if entry_time >= cutoff:
                    calendar_entries.append(entry)
            except ValueError:
                continue
        
        published_count = sum(1 for e in calendar_entries if e.status == "published")
        scheduled_count = sum(1 for e in calendar_entries if e.status in ("scheduled", "ready"))
        draft_count = sum(1 for e in calendar_entries if e.status == "draft")
        
        # Revenue generated in period
        period_revenue = 0.0
        if period == "day":
            period_revenue = self.get_daily_revenue()
        elif period == "week":
            period_revenue = self.get_weekly_revenue()
        else:
            period_revenue = self.get_monthly_revenue()
        
        # Calculate engagement rate
        engagement_rate = 0.0
        if total_views > 0:
            engagement_rate = (total_likes + total_comments + total_shares * 2) / total_views
        
        # Platform breakdown
        platform_stats: Dict[str, Dict[str, Any]] = {}
        for m in period_metrics:
            platform = m.get("platform", "unknown")
            if platform not in platform_stats:
                platform_stats[platform] = {
                    "posts": 0,
                    "views": 0,
                    "likes": 0,
                    "comments": 0,
                    "shares": 0
                }
            platform_stats[platform]["posts"] += 1
            platform_stats[platform]["views"] += m.get("views", 0)
            platform_stats[platform]["likes"] += m.get("likes", 0)
            platform_stats[platform]["comments"] += m.get("comments", 0)
            platform_stats[platform]["shares"] += m.get("shares", 0)
        
        return {
            "period": period,
            "generated_at": datetime.utcnow().isoformat(),
            "content_summary": {
                "posts_published": published_count,
                "posts_scheduled": scheduled_count,
                "posts_draft": draft_count,
                "total_posts_in_period": len(calendar_entries)
            },
            "performance_summary": {
                "total_views": total_views,
                "total_likes": total_likes,
                "total_comments": total_comments,
                "total_shares": total_shares,
                "overall_engagement_rate": round(engagement_rate, 4),
                "avg_views_per_post": round(total_views / len(period_metrics), 2) if period_metrics else 0,
                "avg_engagement_rate": round(
                    sum(
                        (m.get("likes", 0) + m.get("comments", 0) + m.get("shares", 0) * 2) / max(m.get("views", 1), 1)
                        for m in period_metrics
                    ) / len(period_metrics), 4
                ) if period_metrics else 0
            },
            "revenue": {
                "total_revenue": round(period_revenue, 2),
                "revenue_per_post": round(period_revenue / published_count, 2) if published_count > 0 else 0,
                "revenue_per_1000_views": round(period_revenue / max(total_views / 1000, 1), 4)
            },
            "by_platform": platform_stats,
            "viral_content": self.detect_viral_content()
        }

    # ── Data Persistence ─────────────────────────────────────────────────

    def _load_data(self) -> None:
        """Load existing revenue streams and calendar entries from ledgers."""
        # Load revenue streams
        if self.revenue_ledger_path.exists():
            with open(self.revenue_ledger_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            data = json.loads(line)
                            self._revenue_streams.append(RevenueStream.from_dict(data))
                        except (json.JSONDecodeError, TypeError):
                            continue
        
        # Load calendar entries
        if self.calendar_ledger_path.exists():
            with open(self.calendar_ledger_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            data = json.loads(line)
                            entry = ContentCalendarEntry.from_dict(data)
                            self._calendar_entries[entry.entry_id] = entry
                        except (json.JSONDecodeError, TypeError):
                            continue

    def _save_revenue_stream(self, stream: RevenueStream) -> None:
        """Append revenue stream to ledger."""
        with open(self.revenue_ledger_path, "a") as f:
            f.write(json.dumps(stream.to_dict()) + "\n")

    def _save_calendar_entry(self, entry: ContentCalendarEntry) -> None:
        """Append calendar entry to ledger."""
        with open(self.calendar_ledger_path, "a") as f:
            f.write(json.dumps(entry.to_dict()) + "\n")

    def _rewrite_revenue_ledger(self) -> None:
        """Rewrite the entire revenue ledger with current data."""
        with open(self.revenue_ledger_path, "w") as f:
            for stream in self._revenue_streams:
                f.write(json.dumps(stream.to_dict()) + "\n")

    def _rewrite_calendar_ledger(self) -> None:
        """Rewrite the entire calendar ledger with current data."""
        with open(self.calendar_ledger_path, "w") as f:
            for entry in self._calendar_entries.values():
                f.write(json.dumps(entry.to_dict()) + "\n")

    def _load_performance_metrics(self) -> None:
        """Load performance metrics for viral detection."""
        if not self._performance_cache and self.performance_metrics_path.exists():
            with open(self.performance_metrics_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            self._performance_cache.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue

    # ── Utility Methods ─────────────────────────────────────────────────

    def get_revenue_for_content(self, content_id: str) -> float:
        """Get total revenue generated by specific content."""
        total = 0.0
        for stream in self._revenue_streams:
            if stream.content_id == content_id and stream.status in ("earned", "paid"):
                total += stream.amount
        return total

    def get_content_count_by_status(self) -> Dict[str, int]:
        """Get count of content by status."""
        counts: Dict[str, int] = {}
        for entry in self._calendar_entries.values():
            status = entry.status
            counts[status] = counts.get(status, 0) + 1
        return counts

    def get_revenue_count_by_status(self) -> Dict[str, float]:
        """Get revenue totals by status."""
        totals: Dict[str, float] = {}
        for stream in self._revenue_streams:
            totals[stream.status] = totals.get(stream.status, 0.0) + stream.amount
        return totals
