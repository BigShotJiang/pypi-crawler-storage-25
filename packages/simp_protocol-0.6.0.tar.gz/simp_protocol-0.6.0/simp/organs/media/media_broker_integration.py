"""
Media Empire Broker Integration.

Wires the AutonomousMediaEmpire into SIMP broker for:
- Agent registration and discovery
- Intent routing (launch_channel, clone_channel, etc.)
- Inter-agent communication
- Mesh bus integration
"""
import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

from simp.agentic_https import AgenticIntentRequest, AgenticIntentResponse
from simp.models.canonical_intent import CanonicalIntent


class MediaIntentType:
    """Media empire intent types for SIMP broker."""
    
    # Channel intents
    LAUNCH_CHANNEL = "launch_channel"
    CLONE_CHANNEL = "clone_channel"
    PAUSE_CHANNEL = "pause_channel"
    RESUME_CHANNEL = "resume_channel"
    KILL_CHANNEL = "kill_channel"
    
    # Content intents
    GENERATE_CONTENT = "generate_content"
    PUBLISH_CONTENT = "publish_content"
    SCHEDULE_CONTENT = "schedule_content"
    
    # Analytics intents
    REFRESH_METRICS = "refresh_metrics"
    ANALYZE_PERFORMANCE = "analyze_performance"
    CHECK_CHANNEL_HEALTH = "check_channel_health"
    
    # Revenue intents
    FETCH_REVENUE = "fetch_revenue"
    CHECK_KILL_SCALE = "check_kill_scale"
    
    # Operations intents
    APPROVE_REQUEST = "approve_request"
    RECOVER_FROM_ERROR = "recover_from_error"
    HEALTH_CHECK = "health_check"


@dataclass
class MediaAgentContext:
    """Context passed to media agents."""
    empire_id: str
    channel_id: Optional[str] = None
    campaign_id: Optional[str] = None
    
    # Request tracking
    intent_id: Optional[str] = None
    trace_id: Optional[str] = None
    
    # User context
    user_id: Optional[str] = None
    team_id: Optional[str] = None


class MediaEmpireBrokerIntegration:
    """
    Integrates AutonomousMediaEmpire with SIMP broker.
    
    Exposes media empire operations as agentic intents that can be:
    - Received via HTTP webhook
    - Sent via broker message bus
    - Routed through orchestration loops
    """
    
    def __init__(
        self,
        empire,  # AutonomousMediaEmpire
        agent_id: str = "media_empire_agent",
        data_dir: str = "data/media/broker"
    ):
        self.empire = empire
        self.agent_id = agent_id
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.broker_integration")
        
        # Intent handlers
        self._handlers: Dict[str, Callable] = {}
        self._register_handlers()
        
        # State
        self._is_registered = False
        self._pending_intents: Dict[str, Dict] = {}
    
    def _register_handlers(self) -> None:
        """Register intent handlers."""
        self._handlers = {
            MediaIntentType.LAUNCH_CHANNEL: self._handle_launch_channel,
            MediaIntentType.CLONE_CHANNEL: self._handle_clone_channel,
            MediaIntentType.GENERATE_CONTENT: self._handle_generate_content,
            MediaIntentType.PUBLISH_CONTENT: self._handle_publish_content,
            MediaIntentType.REFRESH_METRICS: self._handle_refresh_metrics,
            MediaIntentType.CHECK_CHANNEL_HEALTH: self._handle_check_health,
            MediaIntentType.FETCH_REVENUE: self._handle_fetch_revenue,
            MediaIntentType.HEALTH_CHECK: self._handle_health_check,
            MediaIntentType.APPROVE_REQUEST: self._handle_approval,
            MediaIntentType.RECOVER_FROM_ERROR: self._handle_recovery,
        }
    
    # =========================================================================
    # Broker Registration
    # =========================================================================
    
    def get_agent_manifest(self) -> Dict[str, Any]:
        """
        Get agent manifest for SIMP broker registration.
        
        Returns the capabilities and intents this agent handles.
        """
        return {
            "agent_id": self.agent_id,
            "agent_name": "Media Empire Agent",
            "description": "Autonomous multi-channel content empire manager",
            "capabilities": [
                "channel_management",
                "content_generation",
                "multi_platform_publishing",
                "analytics_and_optimization",
                "revenue_tracking",
                "approval_workflow",
                "error_recovery"
            ],
            "intents_handled": list(self._handlers.keys()),
            "metadata": {
                "version": "1.0.0",
                "channels_supported": ["tiktok", "youtube", "instagram", "x"],
                "content_types": ["short_video", "long_video", "post", "story"],
                "autonomous": True
            }
        }
    
    def register_with_broker(self, broker) -> bool:
        """
        Register this agent with a SIMP broker instance.
        
        Args:
            broker: SimpBroker instance
            
        Returns:
            True if registration successful
        """
        try:
            manifest = self.get_agent_manifest()
            
            # Register with broker's agent registry
            if hasattr(broker, 'agent_registry'):
                broker.agent_registry.register_agent(
                    agent_id=self.agent_id,
                    capabilities=manifest["capabilities"],
                    intents_handled=manifest["intents_handled"]
                )
            
            self._is_registered = True
            self.logger.info(f"Registered with broker as {self.agent_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Broker registration failed: {e}")
            return False
    
    # =========================================================================
    # Intent Handling
    # =========================================================================
    
    async def handle_intent(
        self,
        intent: AgenticIntentRequest
    ) -> AgenticIntentResponse:
        """
        Handle an incoming intent from the SIMP broker.
        
        Args:
            intent: The intent request
            
        Returns:
            AgenticIntentResponse with result
        """
        intent_type = intent.intent_type
        handler = self._handlers.get(intent_type)
        
        if not handler:
            return AgenticIntentResponse(
                success=False,
                intent_id=intent.intent_id,
                error=f"No handler for intent type: {intent_type}"
            )
        
        # Track pending intent
        self._pending_intents[intent.intent_id] = {
            "intent_type": intent_type,
            "started_at": datetime.now().isoformat(),
            "status": "processing"
        }
        
        try:
            # Execute handler
            context = MediaAgentContext(
                empire_id=self.agent_id,
                intent_id=intent.intent_id,
                trace_id=intent.metadata.get("trace_id") if intent.metadata else None
            )
            
            result = await handler(intent.payload, context)
            
            # Update tracking
            self._pending_intents[intent.intent_id]["status"] = "completed"
            
            return AgenticIntentResponse(
                success=True,
                intent_id=intent.intent_id,
                result=result
            )
            
        except Exception as e:
            self.logger.error(f"Intent handling failed: {e}")
            self._pending_intents[intent.intent_id]["status"] = "failed"
            self._pending_intents[intent.intent_id]["error"] = str(e)
            
            return AgenticIntentResponse(
                success=False,
                intent_id=intent.intent_id,
                error=str(e)
            )
    
    # =========================================================================
    # Intent Handlers
    # =========================================================================
    
    async def _handle_launch_channel(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle launch_channel intent."""
        channel = await self.empire.launch_channel(
            niche=payload["niche"],
            brand_name=payload["brand_name"],
            brand_handle=payload["brand_handle"],
            email=payload["email"],
            platforms=payload.get("platforms", ["tiktok", "youtube", "x"]),
            phone=payload.get("phone")
        )
        
        return {
            "channel_id": channel.channel_id,
            "name": channel.name,
            "status": "launched",
            "platforms": [p.value for p in channel.platforms]
        }
    
    async def _handle_clone_channel(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle clone_channel intent."""
        new_channel = await self.empire.clone_channel(
            source_channel_id=payload["source_channel_id"],
            new_niche=payload.get("new_niche"),
            new_platform=payload.get("new_platform"),
            new_language=payload.get("new_language")
        )
        
        return {
            "channel_id": new_channel.channel_id,
            "name": new_channel.name,
            "status": "cloned"
        }
    
    async def _handle_generate_content(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle generate_content intent."""
        package = await self.empire.generate_content(
            channel_id=payload["channel_id"],
            idea=payload["idea"],
            content_type=payload.get("content_type", "short_video"),
            duration_seconds=payload.get("duration_seconds", 60)
        )
        
        return {
            "content_id": package.content_id,
            "status": "generated",
            "script": package.script.title if package.script else None,
            "has_video": package.video_asset is not None
        }
    
    async def _handle_publish_content(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle publish_content intent."""
        success = await self.empire.publish_post(
            channel_id=payload["channel_id"],
            post_id=payload["post_id"]
        )
        
        return {
            "success": success,
            "post_id": payload["post_id"]
        }
    
    async def _handle_refresh_metrics(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle refresh_metrics intent."""
        metrics = await self.empire.refresh_metrics()
        return metrics
    
    async def _handle_check_health(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle check_channel_health intent."""
        actions = await self.empire.check_channel_health()
        return {"actions": actions}
    
    async def _handle_fetch_revenue(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle fetch_revenue intent."""
        revenue = await self.empire.refresh_revenue_metrics()
        return revenue
    
    async def _handle_health_check(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle health_check intent."""
        return self.empire.get_status()
    
    async def _handle_approval(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle approval intent."""
        from simp.organs.media.approval_gates import ApprovalGate
        
        gate = ApprovalGate()
        request_id = payload["request_id"]
        action = payload["action"]  # "approve" or "reject"
        
        if action == "approve":
            await gate.approve(request_id, approver=payload.get("approver", "system"))
        else:
            await gate.reject(request_id, approver=payload.get("approver", "system"), reason=payload.get("reason", ""))
        
        return {"request_id": request_id, "action": action, "status": "processed"}
    
    async def _handle_recovery(
        self,
        payload: Dict[str, Any],
        context: MediaAgentContext
    ) -> Dict[str, Any]:
        """Handle recover_from_error intent."""
        from simp.organs.media.self_healing import execute_recovery
        
        result = await execute_recovery(
            policy_id=payload["policy_id"],
            error_id=payload["error_id"],
            context=payload.get("context", {})
        )
        
        return {
            "success": result.success,
            "actions_taken": [a.value for a in result.actions_attempted],
            "should_retry": result.should_retry
        }
    
    # =========================================================================
    # Outbound Communication
    # =========================================================================
    
    async def send_intent(
        self,
        broker,
        target_agent: str,
        intent_type: str,
        payload: Dict[str, Any],
        metadata: Optional[Dict] = None
    ) -> str:
        """
        Send an intent to another agent via the broker.
        
        Args:
            broker: SimpBroker instance
            target_agent: Agent ID to send to
            intent_type: Type of intent
            payload: Intent payload
            metadata: Optional metadata
            
        Returns:
            Intent ID
        """
        intent = AgenticIntentRequest(
            intent_type=intent_type,
            payload=payload,
            metadata=metadata or {}
        )
        
        # Route through broker
        response = await broker.route_intent(
            source_agent=self.agent_id,
            target_agent=target_agent,
            intent=intent
        )
        
        return response.intent_id if response else None
    
    # =========================================================================
    # Mesh Bus Integration
    # =========================================================================
    
    async def publish_to_mesh(
        self,
        topic: str,
        message: Dict[str, Any]
    ) -> None:
        """
        Publish a message to the mesh bus.
        
        Args:
            topic: Mesh topic
            message: Message to publish
        """
        from simp.mesh import get_mesh_bus
        
        bus = get_mesh_bus()
        await bus.publish(topic, message)
    
    async def subscribe_to_mesh(
        self,
        topic: str,
        handler: Callable
    ) -> None:
        """
        Subscribe to mesh bus topic.
        
        Args:
            topic: Mesh topic
            handler: Message handler callback
        """
        from simp.mesh import get_mesh_bus
        
        bus = get_mesh_bus()
        await bus.subscribe(topic, handler)
    
    # =========================================================================
    # Status & Monitoring
    # =========================================================================
    
    def get_pending_intents(self) -> List[Dict[str, Any]]:
        """Get list of pending intents."""
        return list(self._pending_intents.values())
    
    def get_stats(self) -> Dict[str, Any]:
        """Get agent statistics."""
        return {
            "agent_id": self.agent_id,
            "is_registered": self._is_registered,
            "handlers_count": len(self._handlers),
            "pending_intents": len(self._pending_intents),
            "empire_status": self.empire.get_status()
        }
