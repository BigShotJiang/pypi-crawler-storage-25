"""
Ad Revenue Connectors for Media Empire.

Provides API wrappers for:
- TikTok Creator Fund
- YouTube Partner Program
- Instagram Reels Bonuses
"""
from simp.organs.media.ad_connectors.ad_revenue import (
    AdRevenueConnector,
    AdRevenueResult,
    AdRevenueMetrics,
    TikTokCreatorFundConnector,
    YouTubePartnerConnector,
    InstagramReelsConnector,
    create_ad_connector
)

__version__ = "0.1.0"
__all__ = [
    "AdRevenueConnector",
    "AdRevenueResult",
    "AdRevenueMetrics",
    "TikTokCreatorFundConnector",
    "YouTubePartnerConnector",
    "InstagramReelsConnector",
    "create_ad_connector"
]
