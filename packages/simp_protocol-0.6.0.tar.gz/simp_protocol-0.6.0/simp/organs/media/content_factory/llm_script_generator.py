"""
LLM Script Generator for AI-Powered Content Creation.

Supports multiple LLM providers:
- Anthropic Claude
- OpenAI GPT-4
- Google Gemini
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

# LLM Provider support
try:
    from anthropic import AsyncAnthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    import google.generativeai as genai
    GOOGLE_AVAILABLE = True
except ImportError:
    GOOGLE_AVAILABLE = False


class LLMProvider(Enum):
    """Supported LLM providers."""
    CLAUDE = "claude"
    GPT4 = "gpt4"
    GEMINI = "gemini"
    LOCAL = "local"  # For local models like LLaMA


@dataclass
class ScriptGenerationConfig:
    """Configuration for script generation."""
    provider: LLMProvider = LLMProvider.CLAUDE
    
    # Model selection
    model: str = "claude-3-5-sonnet-20241022"
    
    # Generation parameters
    temperature: float = 0.8
    max_tokens: int = 4096
    top_p: float = 0.9
    
    # Content parameters
    script_style: str = "engaging"  # engaging, professional, casual, educational
    hook_style: str = "curiosity"  # curiosity, controversy, story, question, stat
    cta_style: str = "subscribe"  # subscribe, share, comment, visit_link
    
    # Platform-specific adjustments
    platform: str = "tiktok"
    
    # API keys (can be set via environment or init)
    api_key: Optional[str] = None
    
    # Callbacks
    on_progress: Optional[Callable] = None
    on_complete: Optional[Callable] = None


@dataclass
class ScriptResult:
    """Result from script generation."""
    success: bool
    script_id: str
    
    # Generated content
    hooks: List[str] = field(default_factory=list)
    main_script: str = ""
    alternative_scripts: List[str] = field(default_factory=list)
    ctas: List[str] = field(default_factory=list)
    
    # Metadata
    provider: str = ""
    model: str = ""
    tokens_used: int = 0
    generation_time_ms: float = 0.0
    
    # Quality metrics
    engagement_score: float = 0.0
    authenticity_score: float = 0.0
    
    # Raw response for debugging
    raw_response: Optional[Dict] = None
    error: Optional[str] = None


@dataclass
class ContentBrief:
    """Content brief for generation."""
    topic: str
    angle: str = ""  # comparison, review, tutorial, story, news
    target_audience: str = ""
    key_message: str = ""
    duration_seconds: int = 60
    platform: str = "tiktok"
    
    # References
    reference_content: Optional[str] = None
    competitor_analysis: Optional[str] = None
    
    # Requirements
    include_stats: bool = False
    include_story: bool = False
    tone: str = "informative"  # informative, entertaining, urgent, professional


class LLMScriptGenerator:
    """
    LLM-powered script generator.
    
    Generates optimized scripts for multiple platforms using AI.
    """
    
    def __init__(
        self,
        config: Optional[ScriptGenerationConfig] = None,
        data_dir: str = "data/media/llm_generated"
    ):
        self.config = config or ScriptGenerationConfig()
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("media.llm_generator")
        
        # LLM clients
        self._claude_client: Optional[AsyncAnthropic] = None
        self._openai_client = None
        self._gemini_model = None
        
        # Initialize clients
        self._init_clients()
        
        # Prompt templates
        self._prompt_templates = self._load_prompt_templates()
    
    def _init_clients(self) -> None:
        """Initialize LLM clients."""
        # Claude
        if ANTHROPIC_AVAILABLE and self.config.provider == LLMProvider.CLAUDE:
            api_key = self.config.api_key or self._get_env("ANTHROPIC_API_KEY")
            if api_key:
                self._claude_client = AsyncAnthropic(api_key=api_key)
                self.logger.info("Claude client initialized")
        
        # OpenAI
        if OPENAI_AVAILABLE and self.config.provider == LLMProvider.GPT4:
            api_key = self.config.api_key or self._get_env("OPENAI_API_KEY")
            if api_key:
                openai.api_key = api_key
                self._openai_client = openai
                self.logger.info("OpenAI client initialized")
        
        # Gemini
        if GOOGLE_AVAILABLE and self.config.provider == LLMProvider.GEMINI:
            api_key = self.config.api_key or self._get_env("GOOGLE_API_KEY")
            if api_key:
                genai.configure(api_key=api_key)
                self._gemini_model = genai.GenerativeModel(self.config.model)
                self.logger.info("Gemini client initialized")
    
    def _get_env(self, key: str) -> Optional[str]:
        """Get environment variable."""
        import os
        return os.environ.get(key)
    
    def _load_prompt_templates(self) -> Dict[str, str]:
        """Load prompt templates for different platforms and styles."""
        return {
            "tiktok_engaging": """Generate a TikTok video script.

Topic: {topic}
Angle: {angle}
Target Audience: {target_audience}
Duration: {duration} seconds

Requirements:
- Strong hook in the first 3 seconds (use '{hook_style}' style)
- Keep it conversational and authentic
- Include a clear call-to-action
- Make it scannable and punchy

Generate:
1. 5 hook options (15 chars max each)
2. Main script structure (with timing notes)
3. 3 alternative versions
4. 3 CTA options

Format as JSON.""",

            "youtube_educational": """Generate a YouTube educational script.

Topic: {topic}
Angle: {angle}
Target Audience: {target_audience}
Duration: {duration} seconds

Requirements:
- Hook in first 30 seconds
- Clear structure with sections
- Include timestamps
- Strong outro with CTA

Generate:
1. Compelling title
2. 5 hook options
3. Full script with section markers
4. Timestamps for chapters
5. End screen elements

Format as JSON.""",

            "generic": """Generate a social media script.

Topic: {topic}
Platform: {platform}
Style: {style}
Duration: {duration} seconds

Generate engaging content with:
- Strong opening hook
- Main body (conclusion first, then details)
- Call to action

Output as JSON with:
- hooks (list of 5)
- main_script
- alternative_scripts (list of 3)
- ctas (list of 3)
- engagement_score (0-1)
- authenticity_score (0-1)
"""
        }
    
    # =========================================================================
    # Script Generation
    # =========================================================================
    
    async def generate_script(self, brief: ContentBrief) -> ScriptResult:
        """
        Generate a script from a content brief.
        
        Args:
            brief: Content brief with topic, angle, etc.
            
        Returns:
            ScriptResult with generated content
        """
        script_id = f"script_{uuid.uuid4().hex[:8]}"
        start_time = time.time()
        
        try:
            # Build prompt
            prompt = self._build_prompt(brief)
            
            # Generate based on provider
            if self.config.provider == LLMProvider.CLAUDE:
                result = await self._generate_with_claude(prompt, brief)
            elif self.config.provider == LLMProvider.GPT4:
                result = await self._generate_with_gpt4(prompt, brief)
            elif self.config.provider == LLMProvider.GEMINI:
                result = await self._generate_with_gemini(prompt, brief)
            else:
                result = await self._generate_mock_script(brief)
            
            result.script_id = script_id
            result.provider = self.config.provider.value
            result.model = self.config.model
            result.generation_time_ms = (time.time() - start_time) * 1000
            
            # Save to disk
            self._save_script(result, brief)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Script generation failed: {e}")
            return ScriptResult(
                success=False,
                script_id=script_id,
                error=str(e)
            )
    
    async def generate_scripts_batch(
        self,
        briefs: List[ContentBrief],
        max_concurrent: int = 3
    ) -> List[ScriptResult]:
        """Generate scripts for multiple briefs concurrently."""
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def generate_with_limit(brief):
            async with semaphore:
                return await self.generate_script(brief)
        
        tasks = [generate_with_limit(brief) for brief in briefs]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Convert exceptions to failed results
        return [
            r if isinstance(r, ScriptResult) else ScriptResult(
                success=False,
                script_id="error",
                error=str(r)
            )
            for r in results
        ]
    
    def _build_prompt(self, brief: ContentBrief) -> str:
        """Build generation prompt from brief."""
        # Select template
        if brief.platform == "tiktok":
            if self.config.script_style == "engaging":
                template = self._prompt_templates["tiktok_engaging"]
            else:
                template = self._prompt_templates["generic"]
        elif brief.platform == "youtube":
            template = self._prompt_templates["youtube_educational"]
        else:
            template = self._prompt_templates["generic"]
        
        return template.format(
            topic=brief.topic,
            angle=brief.angle,
            target_audience=brief.target_audience,
            duration=brief.duration_seconds,
            platform=brief.platform,
            style=self.config.script_style,
            hook_style=self.config.hook_style,
            cta_style=self.config.cta_style
        )
    
    async def _generate_with_claude(self, prompt: str, brief: ContentBrief) -> ScriptResult:
        """Generate script using Claude."""
        if not self._claude_client:
            return await self._generate_mock_script(brief)
        
        response = await self._claude_client.messages.create(
            model=self.config.model,
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            messages=[{"role": "user", "content": prompt}]
        )
        
        content = response.content[0].text
        
        # Parse JSON response
        try:
            parsed = json.loads(content)
            return ScriptResult(
                success=True,
                script_id="",
                hooks=parsed.get("hooks", []),
                main_script=parsed.get("main_script", parsed.get("script", "")),
                alternative_scripts=parsed.get("alternative_scripts", []),
                ctas=parsed.get("ctas", []),
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                raw_response=parsed
            )
        except json.JSONDecodeError:
            # Return as raw text
            return ScriptResult(
                success=True,
                script_id="",
                main_script=content,
                raw_response={"raw_text": content}
            )
    
    async def _generate_with_gpt4(self, prompt: str, brief: ContentBrief) -> ScriptResult:
        """Generate script using GPT-4."""
        if not self._openai_client:
            return await self._generate_mock_script(brief)
        
        response = await self._openai_client.ChatCompletion.acreate(
            model=self.config.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens
        )
        
        content = response.choices[0].message.content
        
        try:
            parsed = json.loads(content)
            return ScriptResult(
                success=True,
                script_id="",
                hooks=parsed.get("hooks", []),
                main_script=parsed.get("main_script", parsed.get("script", "")),
                alternative_scripts=parsed.get("alternative_scripts", []),
                ctas=parsed.get("ctas", []),
                tokens_used=response.usage.total_tokens,
                raw_response=parsed
            )
        except json.JSONDecodeError:
            return ScriptResult(
                success=True,
                script_id="",
                main_script=content
            )
    
    async def _generate_with_gemini(self, prompt: str, brief: ContentBrief) -> ScriptResult:
        """Generate script using Gemini."""
        if not self._gemini_model:
            return await self._generate_mock_script(brief)
        
        response = await self._gemini_model.generate_content(prompt)
        
        content = response.text
        
        try:
            parsed = json.loads(content)
            return ScriptResult(
                success=True,
                script_id="",
                hooks=parsed.get("hooks", []),
                main_script=parsed.get("main_script", parsed.get("script", "")),
                alternative_scripts=parsed.get("alternative_scripts", []),
                ctas=parsed.get("ctas", []),
                raw_response=parsed
            )
        except json.JSONDecodeError:
            return ScriptResult(
                success=True,
                script_id="",
                main_script=content
            )
    
    async def _generate_mock_script(self, brief: ContentBrief) -> ScriptResult:
        """Generate a mock script when no API is available."""
        # Create mock but realistic content
        hooks = [
            f"Here's what nobody tells you about {brief.topic}",
            f"I tested {brief.topic} for 30 days - here's what happened",
            f"This changed everything about {brief.topic}",
            f"The truth about {brief.topic} nobody talks about",
            f"Why {brief.topic} is about to be huge"
        ]
        
        scripts = [
            f"""Hook: Start with impact (0-3s)

Main content:
- Why {brief.topic} matters right now
- The key insight that changes everything
- Step-by-step how to apply this
- Real examples and proof

CTA: Follow for more insights like this""",
            
            f"""Opening: Ask a compelling question

Body:
- Share a surprising statistic or fact about {brief.topic}
- Explain why this matters to {brief.target_audience}
- Give 3 actionable tips

Close: Call to action"""
        ]
        
        ctas = [
            "Follow for more content like this",
            "Comment your thoughts below",
            "Share this with someone who needs it"
        ]
        
        return ScriptResult(
            success=True,
            script_id="",
            hooks=hooks,
            main_script=scripts[0],
            alternative_scripts=scripts,
            ctas=ctas,
            engagement_score=0.75,
            authenticity_score=0.80
        )
    
    def _save_script(self, result: ScriptResult, brief: ContentBrief) -> None:
        """Save generated script to disk."""
        script_file = self.data_dir / f"{result.script_id}.json"
        
        with open(script_file, 'w') as f:
            json.dump({
                "script_id": result.script_id,
                "brief": vars(brief),
                "hooks": result.hooks,
                "main_script": result.main_script,
                "alternative_scripts": result.alternative_scripts,
                "ctas": result.ctas,
                "provider": result.provider,
                "model": result.model,
                "generated_at": datetime.utcnow().isoformat(),
                "tokens_used": result.tokens_used,
                "generation_time_ms": result.generation_time_ms
            }, f, indent=2)
    
    # =========================================================================
    # Configuration
    # =========================================================================
    
    def set_api_key(self, provider: LLMProvider, api_key: str) -> None:
        """Set API key for a provider."""
        if provider == LLMProvider.CLAUDE:
            self._claude_client = AsyncAnthropic(api_key=api_key)
        elif provider == LLMProvider.GPT4:
            openai.api_key = api_key
        elif provider == LLMProvider.GEMINI:
            genai.configure(api_key=api_key)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get generator metrics."""
        return {
            "provider": self.config.provider.value,
            "model": self.config.model,
            "claude_connected": self._claude_client is not None,
            "openai_connected": self._openai_client is not None,
            "gemini_connected": self._gemini_model is not None
        }


# =============================================================================
# Convenience Functions
# =============================================================================

async def generate_script_with_llm(
    brief: ContentBrief,
    provider: LLMProvider = LLMProvider.CLAUDE,
    model: str = "claude-3-5-sonnet-20241022",
    api_key: Optional[str] = None
) -> ScriptResult:
    """Convenience function to generate a script."""
    config = ScriptGenerationConfig(
        provider=provider,
        model=model,
        api_key=api_key
    )
    
    generator = LLMScriptGenerator(config)
    return await generator.generate_script(brief)


def create_generator(
    provider: LLMProvider = LLMProvider.CLAUDE,
    model: str = "claude-3-5-sonnet-20241022",
    api_key: Optional[str] = None
) -> LLMScriptGenerator:
    """Create a script generator instance."""
    config = ScriptGenerationConfig(provider=provider, model=model, api_key=api_key)
    return LLMScriptGenerator(config)
