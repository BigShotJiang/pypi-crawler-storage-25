"""
Content Generation Factory for Media Grid.

AI-powered content creation pipeline:
- LLM script generation (Claude, GPT-4, Gemini)
- AI video generation (Runway, Pika, Kling)
- Auto-editing pipeline
- Asset optimization
"""
from simp.organs.media.content_factory.llm_script_generator import (
    LLMScriptGenerator,
    LLMProvider,
    ScriptGenerationConfig,
    ScriptResult,
    ContentBrief,
    generate_script_with_llm
)
from simp.organs.media.content_factory.ai_video_generator import (
    AIVideoGenerator,
    VideoProvider,
    VideoGenerationConfig,
    VideoGenerationResult,
    generate_video
)
from simp.organs.media.content_factory.editing_pipeline import (
    EditingPipeline,
    EditConfig,
    process_edit
)
from simp.organs.media.content_factory.content_factory import (
    ContentFactory,
    ContentPackage,
    create_content_factory
)

__version__ = "0.1.0"
__all__ = [
    "LLMScriptGenerator",
    "LLMProvider",
    "ScriptGenerationConfig",
    "ScriptResult",
    "ContentBrief",
    "generate_script_with_llm",
    "AIVideoGenerator",
    "VideoProvider",
    "VideoGenerationConfig",
    "VideoGenerationResult",
    "generate_video",
    "EditingPipeline",
    "EditConfig",
    "process_edit",
    "ContentFactory",
    "ContentPackage",
    "create_content_factory"
]
