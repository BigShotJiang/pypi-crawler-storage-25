"""
Content Factory - Main Coordinator.

Orchestrates the entire content generation pipeline:
LLM Script Generation → AI Video Generation → Auto-Editing → Output
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging

from simp.organs.media.content_factory.llm_script_generator import (
    LLMScriptGenerator,
    ScriptGenerationConfig,
    ContentBrief,
    ScriptResult,
    LLMProvider
)
from simp.organs.media.content_factory.ai_video_generator import (
    AIVideoGenerator,
    VideoGenerationConfig,
    VideoProvider,
    VideoGenerationResult
)
from simp.organs.media.content_factory.editing_pipeline import (
    EditingPipeline,
    EditConfig,
    EditOperation,
    EditType,
    EditResult
)


class ContentStatus(Enum):
    """Status of content generation."""
    PENDING = "pending"
    SCRIPT_GENERATING = "script_generating"
    SCRIPT_COMPLETE = "script_complete"
    VIDEO_GENERATING = "video_generating"
    VIDEO_COMPLETE = "video_complete"
    EDITING = "editing"
    EDITING_COMPLETE = "editing_complete"
    FAILED = "failed"
    COMPLETED = "completed"


@dataclass
class ContentPackage:
    """
    Complete content package ready for publishing.
    
    Contains all assets needed for a single piece of content.
    """
    package_id: str
    
    # Basic info
    topic: str
    platform: str
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    # Script
    script_id: Optional[str] = None
    hooks: List[str] = field(default_factory=list)
    main_script: str = ""
    alternative_scripts: List[str] = field(default_factory=list)
    ctas: List[str] = field(default_factory=list)
    
    # Video
    video_path: Optional[str] = None
    video_url: Optional[str] = None
    video_duration: float = 0.0
    
    # Thumbnails
    thumbnail_path: Optional[str] = None
    alt_thumbnails: List[str] = field(default_factory=list)
    
    # Captions
    captions: List[Dict] = field(default_factory=list)
    
    # Metadata
    status: ContentStatus = ContentStatus.PENDING
    generation_time_seconds: float = 0.0
    cost_estimate: float = 0.0
    quality_score: float = 0.0
    
    # Platform-specific data
    platform_metadata: Dict[str, Any] = field(default_factory=dict)
    
    # For publishing
    scheduled_time: Optional[str] = None
    published: bool = False
    publish_url: Optional[str] = None


class ContentFactory:
    """
    Content Factory - Main orchestrator for AI-powered content generation.
    
    Coordinates:
    - LLM script generation
    - AI video generation
    - Auto-editing
    - Quality control
    """
    
    def __init__(
        self,
        script_config: Optional[ScriptGenerationConfig] = None,
        video_config: Optional[VideoGenerationConfig] = None,
        edit_config: Optional[EditConfig] = None,
        data_dir: str = "data/media/factory"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("media.content_factory")
        
        # Initialize components
        self.script_generator = LLMScriptGenerator(script_config)
        self.video_generator = AIVideoGenerator(video_config)
        self.editing_pipeline = EditingPipeline(edit_config)
        
        # Configs
        self.script_config = script_config or ScriptGenerationConfig()
        self.video_config = video_config or VideoGenerationConfig()
        self.edit_config = edit_config or EditConfig()
        
        # Packages in progress
        self._active_packages: Dict[str, ContentPackage] = {}
        self._completed_packages: List[ContentPackage] = []
        
        # Stats
        self.total_packages = 0
        self.total_cost = 0.0
        
        # Quality thresholds
        self.min_script_score = 0.7
        self.min_video_quality = 0.6
        self.min_final_quality = 0.65
    
    # =========================================================================
    # Full Pipeline
    # =========================================================================
    
    async def create_content(
        self,
        topic: str,
        platform: str,
        angle: str = "",
        duration: int = 60,
        generate_video: bool = True,
        auto_edit: bool = True
    ) -> ContentPackage:
        """
        Create a complete content package.
        
        Args:
            topic: Content topic
            platform: Target platform (tiktok, youtube, instagram, x, linkedin)
            angle: Content angle (comparison, review, tutorial, etc.)
            duration: Target duration in seconds
            generate_video: Whether to generate AI video
            auto_edit: Whether to auto-edit the video
            
        Returns:
            ContentPackage with all assets
        """
        package_id = f"pkg_{uuid.uuid4().hex[:8]}"
        start_time = time.time()
        
        package = ContentPackage(
            package_id=package_id,
            topic=topic,
            platform=platform
        )
        
        self._active_packages[package_id] = package
        self.total_packages += 1
        
        try:
            # Step 1: Generate script
            package.status = ContentStatus.SCRIPT_GENERATING
            script_result = await self._generate_script(topic, platform, angle, duration)
            
            if script_result.success:
                package.script_id = script_result.script_id
                package.hooks = script_result.hooks
                package.main_script = script_result.main_script
                package.alternative_scripts = script_result.alternative_scripts
                package.ctas = script_result.ctas
                package.status = ContentStatus.SCRIPT_COMPLETE
            
            # Step 2: Generate video (if requested)
            if generate_video:
                package.status = ContentStatus.VIDEO_GENERATING
                video_result = await self._generate_video(package)
                
                if video_result.success:
                    package.video_path = video_result.video_path
                    package.video_url = video_result.video_url
                    package.video_duration = video_result.duration_seconds
                    package.cost_estimate += video_result.cost_estimate
                    package.status = ContentStatus.VIDEO_COMPLETE
            
            # Step 3: Auto-edit (if video exists)
            if auto_edit and package.video_path:
                package.status = ContentStatus.EDITING
                edit_result = await self._auto_edit(package)
                
                if edit_result.success:
                    package.thumbnail_path = edit_result.thumbnail_path
                    package.captions = edit_result.captions
                    package.video_path = edit_result.output_path
                    package.status = ContentStatus.EDITING_COMPLETE
            
            # Calculate final quality
            package.quality_score = self._calculate_quality_score(package)
            package.generation_time_seconds = time.time() - start_time
            
            # Check if meets threshold
            if package.quality_score >= self.min_final_quality:
                package.status = ContentStatus.COMPLETED
            else:
                package.status = ContentStatus.FAILED
                self.logger.warning(
                    f"Content quality {package.quality_score:.2f} below threshold {self.min_final_quality}"
                )
            
            # Update stats
            self.total_cost += package.cost_estimate
            
            # Move to completed
            self._active_packages.pop(package_id, None)
            self._completed_packages.append(package)
            
            # Save package
            self._save_package(package)
            
            return package
            
        except Exception as e:
            self.logger.error(f"Content creation failed: {e}")
            package.status = ContentStatus.FAILED
            return package
    
    async def create_batch(
        self,
        topics: List[Dict],
        max_concurrent: int = 3
    ) -> List[ContentPackage]:
        """Create multiple content packages concurrently."""
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def create_one(topic_data):
            async with semaphore:
                return await self.create_content(**topic_data)
        
        tasks = [create_one(t) for t in topics]
        return await asyncio.gather(*tasks, return_exceptions=True)
    
    # =========================================================================
    # Individual Steps
    # =========================================================================
    
    async def _generate_script(
        self,
        topic: str,
        platform: str,
        angle: str,
        duration: int
    ) -> ScriptResult:
        """Generate script using LLM."""
        brief = ContentBrief(
            topic=topic,
            angle=angle,
            target_audience="tech professionals",
            duration_seconds=duration,
            platform=platform
        )
        
        return await self.script_generator.generate_script(brief)
    
    async def _generate_video(self, package: ContentPackage) -> VideoGenerationResult:
        """Generate AI video from script."""
        prompt = self._script_to_video_prompt(package)
        
        result = await self.video_generator.generate_video(
            prompt=prompt,
            duration=min(package.video_duration if package.video_duration else 60, self.video_config.duration_seconds)
        )
        
        return result
    
    async def _auto_edit(self, package: ContentPackage) -> EditResult:
        """Auto-edit the generated video."""
        operations = []
        
        # Trim if too long
        if package.video_duration > 60:
            operations.append(EditOperation(
                operation_id=f"op_{uuid.uuid4().hex[:8]}",
                edit_type=EditType.TRIM,
                params={"start": 0, "end": 60}
            ))
        
        # Add captions
        if package.main_script:
            operations.append(EditOperation(
                operation_id=f"op_{uuid.uuid4().hex[:8]}",
                edit_type=EditType.CAPTION,
                script=package.main_script
            ))
        
        # Generate thumbnail
        operations.append(EditOperation(
            operation_id=f"op_{uuid.uuid4().hex[:8]}",
            edit_type=EditType.THUMBNAIL
        ))
        
        return await self.editing_pipeline.process_video(
            package.video_path,
            operations
        )
    
    def _script_to_video_prompt(self, package: ContentPackage) -> str:
        """Convert script to video generation prompt."""
        # Extract key elements
        hook = package.hooks[0] if package.hooks else ""
        main_point = package.main_script[:200] if package.main_script else ""
        
        # Build prompt
        prompts = {
            "tiktok": f"{hook}. {main_point[:100]}",
            "youtube": f"Educational video about {package.topic}: {main_point[:150]}",
            "instagram": f"Visual story about {package.topic}",
            "x": f"Quick insight about {package.topic}",
            "linkedin": f"Professional content about {package.topic}"
        }
        
        return prompts.get(package.platform, main_point[:200])
    
    def _calculate_quality_score(self, package: ContentPackage) -> float:
        """Calculate overall quality score for package."""
        scores = []
        
        # Script quality (if generated)
        if package.main_script:
            # Higher for longer scripts, presence of hooks/CTAs
            script_score = 0.5
            if len(package.main_script) > 100:
                script_score += 0.2
            if package.hooks:
                script_score += 0.15
            if package.ctas:
                script_score += 0.15
            scores.append(script_score)
        
        # Video quality (if generated)
        if package.video_path:
            scores.append(0.8)  # Placeholder - would use video generator score
        
        # Edit quality
        if package.thumbnail_path:
            scores.append(0.75)
        if package.captions:
            scores.append(0.80)
        
        return sum(scores) / len(scores) if scores else 0.5
    
    def _save_package(self, package: ContentPackage) -> None:
        """Save package to disk."""
        package_file = self.data_dir / f"{package.package_id}.json"
        
        # Convert enum to string for JSON
        package_data = {
            "package_id": package.package_id,
            "topic": package.topic,
            "platform": package.platform,
            "status": package.status.value,
            "hooks": package.hooks,
            "main_script": package.main_script,
            "alternative_scripts": package.alternative_scripts,
            "ctas": package.ctas,
            "video_path": package.video_path,
            "video_duration": package.video_duration,
            "thumbnail_path": package.thumbnail_path,
            "captions": package.captions,
            "quality_score": package.quality_score,
            "cost_estimate": package.cost_estimate,
            "generation_time_seconds": package.generation_time_seconds,
            "created_at": package.created_at
        }
        
        with open(package_file, 'w') as f:
            json.dump(package_data, f, indent=2)
    
    # =========================================================================
    # Script-Only Mode
    # =========================================================================
    
    async def generate_scripts_only(
        self,
        briefs: List[Dict]
    ) -> List[ScriptResult]:
        """Generate scripts only (no video generation)."""
        content_briefs = [
            ContentBrief(**brief) for brief in briefs
        ]
        
        return await self.script_generator.generate_scripts_batch(content_briefs)
    
    # =========================================================================
    # Metrics & Status
    # =========================================================================
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get factory metrics."""
        completed = [p for p in self._completed_packages if p.status == ContentStatus.COMPLETED]
        failed = [p for p in self._completed_packages if p.status == ContentStatus.FAILED]
        
        return {
            "total_packages": self.total_packages,
            "active": len(self._active_packages),
            "completed": len(completed),
            "failed": len(failed),
            "total_cost": self.total_cost,
            "success_rate": len(completed) / max(1, self.total_packages),
            "avg_quality": sum(p.quality_score for p in completed) / max(1, len(completed)),
            "script_generator": self.script_generator.get_metrics(),
            "video_generator": self.video_generator.get_metrics(),
            "editing_pipeline": self.editing_pipeline.get_metrics()
        }
    
    def get_packages(
        self,
        status: Optional[ContentStatus] = None,
        limit: int = 50
    ) -> List[ContentPackage]:
        """Get packages, optionally filtered by status."""
        packages = self._completed_packages
        
        if status:
            packages = [p for p in packages if p.status == status]
        
        return packages[-limit:]
    
    def get_package(self, package_id: str) -> Optional[ContentPackage]:
        """Get a specific package."""
        for package in self._completed_packages:
            if package.package_id == package_id:
                return package
        
        return self._active_packages.get(package_id)


# =============================================================================
# Factory Function
# =============================================================================

def create_content_factory(
    script_provider: LLMProvider = LLMProvider.CLAUDE,
    video_provider: VideoProvider = VideoProvider.RUNWAY,
    llm_api_key: Optional[str] = None,
    video_api_key: Optional[str] = None
) -> ContentFactory:
    """Create a content factory instance."""
    script_config = ScriptGenerationConfig(
        provider=script_provider,
        api_key=llm_api_key
    )
    
    video_config = VideoGenerationConfig(
        provider=video_provider,
        api_key=video_api_key
    )
    
    return ContentFactory(script_config, video_config)
