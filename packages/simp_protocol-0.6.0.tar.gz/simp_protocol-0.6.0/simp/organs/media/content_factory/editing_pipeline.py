"""
AI-Powered Editing Pipeline.

Automated video editing with AI:
- Smart trimming and pacing
- Auto-captioning
- Thumbnail generation
- Transitions and effects
- Color grading
"""
import asyncio
import base64
import json
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
import logging

# Optional: FFmpeg availability check
try:
    result = subprocess.run(
        ["which", "ffmpeg"],
        capture_output=True,
        text=True,
        timeout=5
    )
    FFMPEG_AVAILABLE = result.returncode == 0
except Exception:
    FFMPEG_AVAILABLE = False


class EditType(Enum):
    """Types of editing operations."""
    TRIM = "trim"
    CAPTION = "caption"
    THUMBNAIL = "thumbnail"
    TRANSITION = "transition"
    COLOR_GRADE = "color_grade"
    AUDIO_ENHANCE = "audio_enhance"
    STABILIZE = "stabilize"
    CROP = "crop"
    SCALE = "scale"
    ROTATE = "rotate"


@dataclass
class EditConfig:
    """Configuration for editing operations."""
    # Output settings
    output_format: str = "mp4"
    output_codec: str = "h264"
    output_quality: str = "high"  # low, medium, high, lossless
    
    # Video settings
    resolution: str = "1080x1920"  # Portrait
    fps: int = 30
    bitrate: str = "8M"
    
    # Caption settings
    caption_style: str = "default"
    caption_font: str = "Arial"
    caption_size: int = 32
    caption_color: str = "white"
    caption_background: str = "black"
    
    # Thumbnail settings
    thumbnail_timestamp: float = 0
    thumbnail_format: str = "jpg"
    
    # Processing
    use_gpu: bool = True
    parallel_processing: bool = True
    max_workers: int = 4


@dataclass
class EditOperation:
    """A single editing operation."""
    operation_id: str
    edit_type: EditType
    params: Dict[str, Any] = field(default_factory=dict)
    
    # For captions
    script: Optional[str] = None
    timestamps: Optional[List[Dict]] = None
    
    # For effects
    effect_name: Optional[str] = None
    effect_params: Optional[Dict] = None


@dataclass
class EditResult:
    """Result from editing operation."""
    success: bool
    output_path: Optional[str] = None
    duration_seconds: float = 0.0
    file_size_bytes: int = 0
    
    # Before/after metrics
    original_duration: float = 0.0
    original_size: int = 0
    
    # Captions generated
    captions: List[Dict] = field(default_factory=list)
    
    # Thumbnail generated
    thumbnail_path: Optional[str] = None
    
    # Error
    error: Optional[str] = None


class EditingPipeline:
    """
    AI-powered video editing pipeline.
    
    Provides automated editing with:
    - Smart trimming
    - Auto-captioning
    - Thumbnail generation
    - Transitions and effects
    - Color grading
    """
    
    def __init__(
        self,
        config: Optional[EditConfig] = None,
        data_dir: str = "data/media/edited"
    ):
        self.config = config or EditConfig()
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("media.editing_pipeline")
        
        # FFmpeg path (if available)
        self.ffmpeg_path = "ffmpeg" if FFMPEG_AVAILABLE else None
        
        # Operation history
        self._history: List[EditResult] = []
        
        # Stats
        self.total_edited = 0
        self.total_time_saved = 0.0
    
    # =========================================================================
    # Main Editing Operations
    # =========================================================================
    
    async def process_video(
        self,
        input_path: str,
        operations: List[EditOperation]
    ) -> EditResult:
        """
        Process a video with a series of edit operations.
        
        Args:
            input_path: Path to input video
            operations: List of EditOperation to apply
            
        Returns:
            EditResult with output info
        """
        start_time = time.time()
        
        try:
            input_path = Path(input_path)
            
            # Get input metadata
            original_duration = await self._get_duration(input_path)
            original_size = input_path.stat().st_size
            
            # Apply operations in order
            current_path = str(input_path)
            
            for op in operations:
                current_path = await self._apply_operation(current_path, op)
            
            # Generate thumbnail if requested
            thumbnail_path = None
            if any(op.edit_type == EditType.THUMBNAIL for op in operations):
                thumbnail_path = await self.create_thumbnail(
                    current_path,
                    self.config.thumbnail_timestamp
                )
            
            # Get output metadata
            output_path = Path(current_path)
            output_size = output_path.stat().st_size if output_path.exists() else 0
            
            result = EditResult(
                success=True,
                output_path=current_path,
                duration_seconds=time.time() - start_time,
                file_size_bytes=output_size,
                original_duration=original_duration,
                original_size=original_size,
                thumbnail_path=thumbnail_path
            )
            
            self._history.append(result)
            self.total_edited += 1
            self.total_time_saved += original_duration - (output_path.stat().st_size if output_path.exists() else 0)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Video processing failed: {e}")
            return EditResult(success=False, error=str(e))
    
    async def _apply_operation(self, video_path: str, operation: EditOperation) -> str:
        """Apply a single edit operation."""
        if operation.edit_type == EditType.TRIM:
            return await self._trim_video(
                video_path,
                operation.params.get("start", 0),
                operation.params.get("end", None)
            )
        elif operation.edit_type == EditType.CAPTION:
            return await self._add_captions(
                video_path,
                operation.script,
                operation.timestamps
            )
        elif operation.edit_type == EditType.CROP:
            return await self._crop_video(
                video_path,
                operation.params
            )
        elif operation.edit_type == EditType.COLOR_GRADE:
            return await self._color_grade(
                video_path,
                operation.params
            )
        else:
            return video_path  # Pass through if not implemented
    
    # =========================================================================
    # Specific Operations
    # =========================================================================
    
    async def auto_trim(
        self,
        input_path: str,
        target_duration: float,
        style: str = "engaging"
    ) -> str:
        """
        Auto-trim video to target duration.
        
        Args:
            input_path: Input video path
            target_duration: Target duration in seconds
            style: "engaging" (keeps high-motion moments) or "smooth" (consistent pacing)
            
        Returns:
            Path to trimmed video
        """
        # In production, would analyze video for engagement peaks
        # For now, just trim from start
        
        output_path = Path(self.data_dir) / f"trimmed_{uuid.uuid4().hex[:8]}.mp4"
        
        if self.ffmpeg_path:
            # Use FFmpeg to trim
            cmd = [
                self.ffmpeg_path, "-y",
                "-i", input_path,
                "-t", str(target_duration),
                "-c", "copy",
                str(output_path)
            ]
            subprocess.run(cmd, capture_output=True)
        else:
            # Mock - just copy file
            import shutil
            shutil.copy(input_path, output_path)
        
        return str(output_path)
    
    async def generate_captions(
        self,
        video_path: str,
        script: str,
        style: Optional[Dict] = None
    ) -> List[Dict]:
        """
        Generate captions from script.
        
        Args:
            video_path: Video to add captions to
            script: Script/transcript text
            style: Caption styling options
            
        Returns:
            List of caption segments with timestamps
        """
        style = style or {
            "font": self.config.caption_font,
            "size": self.config.caption_size,
            "color": self.config.caption_color,
            "background": self.config.caption_background
        }
        
        # Simple word-level caption generation
        # In production, would use AI for proper sync
        
        words = script.split()
        duration = await self._get_duration(video_path)
        time_per_word = duration / len(words) if words else 1
        
        captions = []
        for i, word in enumerate(words):
            captions.append({
                "text": word,
                "start": i * time_per_word,
                "end": (i + 1) * time_per_word,
                "x": 0.1,
                "y": 0.85
            })
        
        return captions
    
    async def add_captions(
        self,
        video_path: str,
        script: str,
        timestamps: Optional[List[Dict]] = None
    ) -> str:
        """Add captions to video."""
        if not timestamps:
            timestamps = await self.generate_captions(video_path, script)
        
        output_path = Path(self.data_dir) / f"captioned_{uuid.uuid4().hex[:8]}.mp4"
        
        # In production, would burn captions into video
        # Using FFmpeg with subtitles or drawtext filter
        
        return str(output_path)
    
    async def create_thumbnail(
        self,
        video_path: str,
        timestamp: float = 0
    ) -> str:
        """Create thumbnail from video."""
        output_path = Path(self.data_dir) / f"thumb_{uuid.uuid4().hex[:8]}.jpg"
        
        if self.ffmpeg_path:
            cmd = [
                self.ffmpeg_path, "-y",
                "-ss", str(timestamp),
                "-i", video_path,
                "-frames:v", "1",
                "-q:v", "2",
                str(output_path)
            ]
            subprocess.run(cmd, capture_output=True)
        else:
            # Mock thumbnail
            output_path.touch()
        
        return str(output_path)
    
    async def _trim_video(
        self,
        video_path: str,
        start: float,
        end: Optional[float]
    ) -> str:
        """Trim video to specified time range."""
        output_path = Path(self.data_dir) / f"trim_{uuid.uuid4().hex[:8]}.mp4"
        
        if self.ffmpeg_path:
            cmd = [
                self.ffmpeg_path, "-y",
                "-ss", str(start),
                "-i", video_path
            ]
            if end:
                cmd.extend(["-t", str(end - start)])
            cmd.extend(["-c", "copy", str(output_path)])
            subprocess.run(cmd, capture_output=True)
        
        return str(output_path)
    
    async def _crop_video(self, video_path: str, params: Dict) -> str:
        """Crop video."""
        output_path = Path(self.data_dir) / f"crop_{uuid.uuid4().hex[:8]}.mp4"
        
        if self.ffmpeg_path:
            x = params.get("x", 0)
            y = params.get("y", 0)
            w = params.get("width", 1080)
            h = params.get("height", 1920)
            
            cmd = [
                self.ffmpeg_path, "-y",
                "-i", video_path,
                "-vf", f"crop={w}:{h}:{x}:{y}",
                str(output_path)
            ]
            subprocess.run(cmd, capture_output=True)
        
        return str(output_path)
    
    async def _color_grade(self, video_path: str, params: Dict) -> str:
        """Apply color grading."""
        output_path = Path(self.data_dir) / f"graded_{uuid.uuid4().hex[:8]}.mp4"
        
        if self.ffmpeg_path:
            # Simple color adjustment
            brightness = params.get("brightness", 1.0)
            contrast = params.get("contrast", 1.0)
            saturation = params.get("saturation", 1.0)
            
            cmd = [
                self.ffmpeg_path, "-y",
                "-i", video_path,
                "-vf", f"eq=brightness={brightness-1}:contrast={contrast}:saturation={saturation}",
                str(output_path)
            ]
            subprocess.run(cmd, capture_output=True)
        
        return str(output_path)
    
    async def _get_duration(self, video_path: str) -> float:
        """Get video duration in seconds."""
        if self.ffmpeg_path:
            cmd = [
                self.ffmpeg_path, "-i", video_path
            ]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True
            )
            
            # Parse duration from output
            import re
            match = re.search(r"Duration: (\d+):(\d+):(\d+)", result.stderr)
            if match:
                h, m, s = match.groups()
                return int(h) * 3600 + int(m) * 60 + int(s)
        
        return 60.0  # Default fallback
    
    # =========================================================================
    # Preset Pipelines
    # =========================================================================
    
    async def process_tiktok_video(
        self,
        input_path: str,
        script: str,
        add_captions: bool = True
    ) -> EditResult:
        """Process video for TikTok with all optimizations."""
        operations = [
            EditOperation(
                operation_id=f"op_{uuid.uuid4().hex[:8]}",
                edit_type=EditType.TRIM,
                params={"start": 0, "end": 60}  # Max 60s for TikTok
            )
        ]
        
        if add_captions:
            operations.append(EditOperation(
                operation_id=f"op_{uuid.uuid4().hex[:8]}",
                edit_type=EditType.CAPTION,
                script=script
            ))
        
        operations.append(EditOperation(
            operation_id=f"op_{uuid.uuid4().hex[:8]}",
            edit_type=EditType.THUMBNAIL
        ))
        
        return await self.process_video(input_path, operations)
    
    async def process_youtube_short(
        self,
        input_path: str,
        script: str
    ) -> EditResult:
        """Process video for YouTube Shorts."""
        operations = [
            EditOperation(
                operation_id=f"op_{uuid.uuid4().hex[:8]}",
                edit_type=EditType.TRIM,
                params={"start": 0, "end": 60}
            ),
            EditOperation(
                operation_id=f"op_{uuid.uuid4().hex[:8]}",
                edit_type=EditType.CAPTION,
                script=script
            ),
            EditOperation(
                operation_id=f"op_{uuid.uuid4().hex[:8]}",
                edit_type=EditType.COLOR_GRADE,
                params={"brightness": 1.05, "contrast": 1.1, "saturation": 1.1}
            ),
            EditOperation(
                operation_id=f"op_{uuid.uuid4().hex[:8]}",
                edit_type=EditType.THUMBNAIL
            )
        ]
        
        return await self.process_video(input_path, operations)
    
    # =========================================================================
    # Metrics
    # =========================================================================
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get editing pipeline metrics."""
        successful = [r for r in self._history if r.success]
        
        return {
            "total_edited": self.total_edited,
            "successful": len(successful),
            "failed": len(self._history) - len(successful),
            "total_time_saved_seconds": self.total_time_saved,
            "ffmpeg_available": self.ffmpeg_path is not None
        }
    
    def get_history(self, limit: int = 50) -> List[Dict]:
        """Get editing history."""
        return [
            {
                "output_path": r.output_path,
                "success": r.success,
                "duration": r.duration_seconds,
                "original_duration": r.original_duration,
                "thumbnail": r.thumbnail_path
            }
            for r in self._history[-limit:]
        ]


# =============================================================================
# Convenience Functions
# =============================================================================

async def process_edit(
    input_path: str,
    edit_type: EditType,
    params: Dict
) -> str:
    """Convenience function for a single edit operation."""
    pipeline = EditingPipeline()
    operation = EditOperation(
        operation_id=f"edit_{uuid.uuid4().hex[:8]}",
        edit_type=edit_type,
        params=params
    )
    result = await pipeline.process_video(input_path, [operation])
    return result.output_path or input_path


def create_pipeline(config: Optional[EditConfig] = None) -> EditingPipeline:
    """Create an editing pipeline instance."""
    return EditingPipeline(config)
