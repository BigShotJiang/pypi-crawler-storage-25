"""
Workflow Engine for KashClaw Media Grid.

Provides workflow execution engine with state machine, event triggers,
and handlers for all 6 n8n-styled workflows.
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

from simp.organs.media.config import get_config
from simp.organs.media.models import ContentPlatform


class WorkflowStatus(Enum):
    """Workflow execution status."""
    PENDING = "pending"
    RUNNING = "running"
    WAITING = "waiting"  # Human review, webhook callback
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class WorkflowStepStatus(Enum):
    """Individual step status within a workflow."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    WAITING = "waiting"


class WorkflowTrigger(Enum):
    """Workflow trigger types."""
    MANUAL = "manual"
    CRON = "cron"
    WEBHOOK = "webhook"
    INTENT = "intent"  # Brain intent
    EVENT = "event"   # Event-based (viral detection, etc.)


@dataclass
class WorkflowStep:
    """A single step within a workflow."""
    step_id: str
    name: str
    action: str  # Agent/intent to call
    params: Dict[str, Any] = field(default_factory=dict)
    depends_on: List[str] = field(default_factory=list)
    timeout_seconds: int = 300
    retry_count: int = 0
    max_retries: int = 3
    status: WorkflowStepStatus = WorkflowStepStatus.PENDING
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


@dataclass
class Workflow:
    """Workflow definition with steps."""
    workflow_id: str
    name: str
    workflow_type: str
    trigger: WorkflowTrigger
    steps: List[WorkflowStep] = field(default_factory=list)
    params: Dict[str, Any] = field(default_factory=dict)
    status: WorkflowStatus = WorkflowStatus.PENDING
    context: Dict[str, Any] = field(default_factory=dict)  # Shared state
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    error: Optional[str] = None


@dataclass
class WorkflowMetrics:
    """Workflow execution metrics."""
    total_runs: int = 0
    completed: int = 0
    failed: int = 0
    avg_duration_seconds: float = 0
    by_type: Dict[str, Dict[str, int]] = field(default_factory=dict)


class WorkflowEngine:
    """
    Workflow execution engine with state machine.
    
    Handles the 6 core workflows:
    1. new_channel_launch - Launch new content channel
    2. daily_content_production - Daily content generation & publishing
    3. trend_ingestion - Trend monitoring and reactive content
    4. analytics_feedback - Performance analysis and optimization
    5. channel_cloning - Clone winning channel to new targets
    6. compliance_monitor - Pre-publish and daily compliance checks
    """
    
    def __init__(self, data_dir: str = "data/media", config=None):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config = config or get_config()
        self.logger = logging.getLogger("media.workflow_engine")
        
        # Workflow definitions
        self._workflow_definitions: Dict[str, Dict] = {}
        self._load_workflow_definitions()
        
        # Active workflows
        self.active_workflows: Dict[str, Workflow] = {}
        self.workflow_history: List[Workflow] = []
        
        # Event handlers
        self._event_handlers: Dict[str, List[Callable]] = {}
        
        # Metrics
        self.metrics = WorkflowMetrics()
        
        # Agent registry
        self._agents: Dict[str, Any] = {}
    
    def _load_workflow_definitions(self) -> None:
        """Load workflow definitions from JSON templates."""
        workflow_dir = Path(__file__).parent / "workflows"
        
        for json_file in workflow_dir.glob("*.json"):
            if json_file.stem in ["workflow_schema"]:
                continue
            try:
                with open(json_file, 'r') as f:
                    template = json.load(f)
                self._workflow_definitions[json_file.stem] = template
                self.logger.debug(f"Loaded workflow: {json_file.stem}")
            except Exception as e:
                self.logger.error(f"Failed to load {json_file}: {e}")
    
    def register_agent(self, agent_name: str, agent: Any) -> None:
        """Register an agent for workflow execution."""
        self._agents[agent_name] = agent
    
    def register_event_handler(self, event: str, handler: Callable) -> None:
        """Register an event handler."""
        if event not in self._event_handlers:
            self._event_handlers[event] = []
        self._event_handlers[event].append(handler)
    
    async def trigger_workflow(
        self,
        workflow_type: str,
        trigger: WorkflowTrigger = WorkflowTrigger.MANUAL,
        params: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """
        Trigger a workflow by type.
        
        Args:
            workflow_type: One of the 6 workflow types
            trigger: How the workflow was triggered
            params: Workflow parameters
            
        Returns:
            workflow_id if successful, None otherwise
        """
        if workflow_type not in self._workflow_definitions:
            self.logger.error(f"Unknown workflow type: {workflow_type}")
            return None
        
        workflow_id = f"wf_{workflow_type}_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        
        # Create workflow from definition
        workflow = self._create_workflow(workflow_id, workflow_type, trigger, params or {})
        
        # Store and execute
        self.active_workflows[workflow_id] = workflow
        self.metrics.total_runs += 1
        
        # Update type-specific metrics
        if workflow_type not in self.metrics.by_type:
            self.metrics.by_type[workflow_type] = {"completed": 0, "failed": 0}
        
        # Execute asynchronously
        asyncio.create_task(self._execute_workflow(workflow))
        
        return workflow_id
    
    def _create_workflow(
        self,
        workflow_id: str,
        workflow_type: str,
        trigger: WorkflowTrigger,
        params: Dict[str, Any]
    ) -> Workflow:
        """Create workflow from definition."""
        template = self._workflow_definitions.get(workflow_type, {})
        
        # Convert JSON nodes to WorkflowStep objects
        steps = []
        for node in template.get("nodes", []):
            step = WorkflowStep(
                step_id=f"{workflow_id}_step_{len(steps)}",
                name=node.get("name", ""),
                action=self._extract_action(node),
                params=self._extract_params(node),
                timeout_seconds=node.get("timeout", 300)
            )
            steps.append(step)
        
        return Workflow(
            workflow_id=workflow_id,
            name=template.get("name", workflow_type),
            workflow_type=workflow_type,
            trigger=trigger,
            steps=steps,
            params=params,
            context={"nodes": {s.name: s for s in steps}}
        )
    
    def _extract_action(self, node: Dict) -> str:
        """Extract action/agent call from node."""
        node_type = node.get("type", "")
        
        if "httpRequest" in node_type:
            return "http_call"
        elif "code" in node_type:
            return "code_execution"
        elif "scheduleTrigger" in node_type:
            return "schedule_trigger"
        elif "webhook" in node_type:
            return "webhook_trigger"
        elif "switch" in node_type:
            return "branch_decision"
        elif "splitInBatches" in node_type:
            return "loop_batch"
        elif "waitNode" in node_type:
            return "human_wait"
        elif "slack" in node_type:
            return "slack_notify"
        else:
            return "generic"
    
    def _extract_params(self, node: Dict) -> Dict[str, Any]:
        """Extract parameters from node."""
        return node.get("parameters", {})
    
    async def _execute_workflow(self, workflow: Workflow) -> None:
        """Execute workflow steps."""
        workflow.status = WorkflowStatus.RUNNING
        workflow.started_at = datetime.utcnow().isoformat()
        
        self.logger.info(f"Starting workflow: {workflow.workflow_id}")
        
        try:
            for step in workflow.steps:
                # Check dependencies
                if not self._check_dependencies(step, workflow.context):
                    step.status = WorkflowStepStatus.SKIPPED
                    continue
                
                # Execute step
                result = await self._execute_step(step, workflow)
                workflow.context[step.name] = result
                
                # Check for branching decisions
                if step.action == "branch_decision":
                    self._handle_branch(step, workflow)
            
            workflow.status = WorkflowStatus.COMPLETED
            self.metrics.completed += 1
            self.metrics.by_type[workflow.workflow_type]["completed"] += 1
            
        except Exception as e:
            workflow.status = WorkflowStatus.FAILED
            workflow.error = str(e)
            self.metrics.failed += 1
            self.metrics.by_type[workflow.workflow_type]["failed"] += 1
            self.logger.error(f"Workflow {workflow.workflow_id} failed: {e}")
        
        workflow.completed_at = datetime.utcnow().isoformat()
        
        # Move to history
        self.active_workflows.pop(workflow.workflow_id, None)
        self.workflow_history.append(workflow)
        
        # Trigger completion event
        await self._trigger_event("workflow_completed", workflow)
    
    def _check_dependencies(self, step: WorkflowStep, context: Dict) -> bool:
        """Check if all dependencies are met."""
        for dep_name in step.depends_on:
            dep_result = context.get(dep_name)
            if dep_result is None:
                return False
        return True
    
    async def _execute_step(self, step: WorkflowStep, workflow: Workflow) -> Dict[str, Any]:
        """Execute a single workflow step."""
        step.status = WorkflowStepStatus.RUNNING
        step.started_at = datetime.utcnow().isoformat()
        
        self.logger.debug(f"Executing step: {step.name}")
        
        try:
            result = await self._dispatch_step(step, workflow)
            step.status = WorkflowStepStatus.COMPLETED
            step.result = result
            step.completed_at = datetime.utcnow().isoformat()
            return result
            
        except Exception as e:
            step.status = WorkflowStepStatus.FAILED
            step.error = str(e)
            step.completed_at = datetime.utcnow().isoformat()
            
            # Retry logic
            if step.retry_count < step.max_retries:
                step.retry_count += 1
                self.logger.warning(f"Retrying step {step.name} ({step.retry_count}/{step.max_retries})")
                return await self._execute_step(step, workflow)
            
            raise
    
    async def _dispatch_step(self, step: WorkflowStep, workflow: Workflow) -> Dict[str, Any]:
        """Dispatch step execution based on action type."""
        params = step.params
        
        if step.action == "http_call":
            return await self._execute_http_call(step, workflow)
        elif step.action == "code_execution":
            return self._execute_code_step(params)
        elif step.action == "branch_decision":
            return self._evaluate_branch(params, workflow.context)
        elif step.action == "slack_notify":
            return await self._send_slack_notification(step, workflow)
        elif step.action == "human_wait":
            workflow.status = WorkflowStatus.WAITING
            return await self._wait_for_human_review(step, workflow)
        else:
            return {"status": "ok", "step": step.name}
    
    async def _execute_http_call(self, step: WorkflowStep, workflow: Workflow) -> Dict[str, Any]:
        """Execute HTTP request step (calls SIMP broker)."""
        params = step.params
        
        # This would make actual HTTP calls to SIMP broker
        # For now, simulate the call
        url = params.get("url", "")
        method = params.get("method", "POST")
        body_params = params.get("bodyParameters", {}).get("parameters", [])
        
        # Extract intent routing
        intent_type = None
        target_agent = None
        payload = {}
        
        for p in body_params:
            name = p.get("name", "")
            value = p.get("value", "")
            if name == "intent_type":
                intent_type = value.replace("{{", "").replace("}}", "").strip()
            elif name == "target_agent":
                target_agent = value.replace("{{", "").replace("}}", "").strip()
            elif name == "payload":
                payload = {"action": "parse_payload", "raw": value}
        
        return {
            "status": "called",
            "url": url,
            "intent_type": intent_type,
            "target_agent": target_agent,
            "payload": payload
        }
    
    def _execute_code_step(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute JavaScript/Code node (simulated for Python)."""
        code = params.get("jsCode", "")
        
        # Simple simulation - would need JS execution in production
        return {
            "status": "code_executed",
            "output": f"Code node executed: {len(code)} chars"
        }
    
    def _evaluate_branch(self, params: Dict, context: Dict) -> Dict[str, Any]:
        """Evaluate branch/switch node."""
        rules = params.get("rules", {}).get("values", [{}])
        
        if not rules:
            return {"branch": "default"}
        
        rule = rules[0]
        operation = rule.get("operation", "")
        value1 = rule.get("value1", "")
        value2 = rule.get("value2", "")
        
        # Resolve template variables
        if "json" in str(value1):
            value1 = context.get(value1.replace("={{$json.", "").replace("}}", ""), value1)
        
        result = False
        if operation == "greater":
            result = float(value1) > float(value2)
        elif operation == "less":
            result = float(value1) < float(value2)
        elif operation == "isEqual":
            result = value1 == value2
        
        return {"branch": "main" if result else "default", "condition_result": result}
    
    def _handle_branch(self, step: WorkflowStep, workflow: Workflow) -> None:
        """Handle branching in workflow."""
        result = step.result or {}
        branch = result.get("branch", "default")
        
        self.logger.debug(f"Branch decision: {branch}")
    
    async def _send_slack_notification(self, step: WorkflowStep, workflow: Workflow) -> Dict[str, Any]:
        """Send Slack notification."""
        params = step.params
        channel = params.get("channel", "#general")
        text = params.get("text", "")
        
        # Resolve template variables
        text = self._resolve_template(text, workflow.context)
        
        return {
            "status": "notification_sent",
            "channel": channel,
            "message": text
        }
    
    async def _wait_for_human_review(self, step: WorkflowStep, workflow: Workflow) -> Dict[str, Any]:
        """Wait for human review callback."""
        webhook_id = step.params.get("webhookId", "")
        
        # In production, this would wait for webhook callback
        # For now, simulate with timeout
        try:
            await asyncio.sleep(5)  # Simulated wait
            return {"status": "review_completed", "webhook_id": webhook_id}
        except Exception:
            return {"status": "review_timeout"}
    
    def _resolve_template(self, template: str, context: Dict) -> str:
        """Resolve template variables in strings."""
        import re
        
        def replace_var(match):
            path = match.group(1)
            value = context
            for key in path.split("."):
                value = value.get(key, match.group(0))
            return str(value)
        
        return re.sub(r"\{\{\$json\.(\w+)\}\}", replace_var, template)
    
    async def _trigger_event(self, event: str, data: Any) -> None:
        """Trigger event handlers."""
        if event in self._event_handlers:
            for handler in self._event_handlers[event]:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        await handler(data)
                    else:
                        handler(data)
                except Exception as e:
                    self.logger.error(f"Event handler error: {e}")
    
    def get_workflow_status(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        """Get workflow status."""
        workflow = self.active_workflows.get(workflow_id) or \
                   next((w for w in self.workflow_history if w.workflow_id == workflow_id), None)
        
        if not workflow:
            return None
        
        return {
            "workflow_id": workflow.workflow_id,
            "name": workflow.name,
            "type": workflow.workflow_type,
            "status": workflow.status.value,
            "progress": self._calculate_progress(workflow),
            "started_at": workflow.started_at,
            "completed_at": workflow.completed_at,
            "error": workflow.error
        }
    
    def _calculate_progress(self, workflow: Workflow) -> float:
        """Calculate workflow progress percentage."""
        if not workflow.steps:
            return 0.0
        
        completed = sum(1 for s in workflow.steps 
                      if s.status in [WorkflowStepStatus.COMPLETED, WorkflowStepStatus.SKIPPED])
        return (completed / len(workflow.steps)) * 100
    
    def list_active_workflows(self) -> List[Dict[str, Any]]:
        """List all active workflows."""
        return [self.get_workflow_status(wf.workflow_id) 
                for wf in self.active_workflows.values()]
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get workflow engine metrics."""
        return {
            "total_runs": self.metrics.total_runs,
            "completed": self.metrics.completed,
            "failed": self.metrics.failed,
            "success_rate": self.metrics.completed / max(1, self.metrics.total_runs),
            "by_type": self.metrics.by_type,
            "active_count": len(self.active_workflows),
            "history_count": len(self.workflow_history)
        }


# Convenience function
def create_workflow_engine(data_dir: str = "data/media") -> WorkflowEngine:
    """Create a workflow engine instance."""
    return WorkflowEngine(data_dir=data_dir)
