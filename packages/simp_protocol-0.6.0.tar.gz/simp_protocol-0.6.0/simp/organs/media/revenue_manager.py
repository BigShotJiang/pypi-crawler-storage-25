"""
Revenue Manager - Central Revenue Aggregation for Media Empire.

Integrates:
- Ad Revenue (TikTok Creator Fund, YouTube Partner, Instagram Reels)
- Affiliate Revenue (commission tracking)
- Sponsorships (brand deals)
- Native Revenue (tips, memberships)

Provides unified revenue ledger and attribution.
"""
import asyncio
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging

from simp.organs.media.platform_oauth_manager import Platform
from simp.organs.media.ad_connectors import (
    AdRevenueConnector, AdRevenueMetrics, create_ad_connector
)
from simp.organs.media.affiliate_tracker import AffiliateTracker, AffiliateReport
from simp.organs.media.monetization_engine import MonetizationEngine


class RevenueType(Enum):
    """Types of revenue."""
    AD_REVENUE = "ad"
    AFFILIATE = "affiliate"
    SPONSORSHIP = "sponsorship"
    MEMBERSHIP = "membership"
    TIPS = "tips"


@dataclass
class RevenueEntry:
    """A single revenue entry."""
    entry_id: str
    channel_id: str
    platform: Platform
    revenue_type: RevenueType
    
    amount: float
    currency: str = "USD"
    
    # Attribution
    content_id: Optional[str] = None
    offer_id: Optional[str] = None
    deal_id: Optional[str] = None
    
    # Context
    views: int = 0
    engagement: int = 0
    
    # Timing
    earned_at: datetime = field(default_factory=datetime.now)
    status: str = "earned"  # earned, pending, paid, clawed_back


@dataclass
class ChannelRevenue:
    """Revenue summary for a channel."""
    channel_id: str
    
    # Totals
    total_revenue: float = 0.0
    pending_revenue: float = 0.0
    lifetime_revenue: float = 0.0
    
    # By type
    ad_revenue: float = 0.0
    affiliate_revenue: float = 0.0
    sponsorship_revenue: float = 0.0
    membership_revenue: float = 0.0
    
    # By platform
    platform_revenue: Dict[str, float] = field(default_factory=dict)
    
    # Metrics
    rpm: float = 0.0  # Revenue per 1000 views
    rpb: float = 0.0  # Revenue per post
    total_views: int = 0
    total_posts: int = 0
    
    # Period
    period_start: datetime = field(default_factory=datetime.now)
    period_end: datetime = field(default_factory=datetime.now)


class RevenueManager:
    """
    Central revenue management and aggregation.
    
    Integrates all revenue sources and provides:
    - Unified revenue ledger
    - Channel revenue summaries
    - Attribution tracking
    - Payout management
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/revenue",
        monetization_engine: Optional[MonetizationEngine] = None,
        affiliate_tracker: Optional[AffiliateTracker] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.revenue")
        
        # Dependencies
        self.monetization = monetization_engine or MonetizationEngine(str(self.data_dir.parent))
        self.affiliate = affiliate_tracker or AffiliateTracker(str(self.data_dir / "affiliate"))
        
        # Ad connectors (created per channel)
        self._ad_connectors: Dict[Platform, AdRevenueConnector] = {}
        
        # Revenue entries
        self._entries: Dict[str, RevenueEntry] = {}
        self._channel_revenue: Dict[str, ChannelRevenue] = {}
        
        self._load_data()
    
    def _load_data(self) -> None:
        """Load revenue data from disk."""
        entries_file = self.data_dir / "revenue_entries.jsonl"
        
        if entries_file.exists():
            with open(entries_file) as f:
                for line in f:
                    data = json.loads(line)
                    data["earned_at"] = datetime.fromisoformat(data["earned_at"])
                    entry = RevenueEntry(**data)
                    self._entries[entry.entry_id] = entry
    
    def _save_entries(self) -> None:
        """Save revenue entries to disk."""
        with open(self.data_dir / "revenue_entries.jsonl", "w") as f:
            for entry in self._entries.values():
                entry_dict = {
                    **vars(entry),
                    "earned_at": entry.earned_at.isoformat()
                }
                f.write(json.dumps(entry_dict) + "\n")
    
    # =========================================================================
    # Ad Revenue Integration
    # =========================================================================
    
    def add_ad_connector(self, platform: Platform, connector: AdRevenueConnector) -> None:
        """Add an ad revenue connector for a platform."""
        self._ad_connectors[platform] = connector
    
    async def fetch_ad_revenue(
        self,
        channel_id: str,
        platforms: List[Platform],
        period_days: int = 30
    ) -> Dict[str, AdRevenueMetrics]:
        """Fetch ad revenue from all platforms for a channel."""
        results = {}
        
        for platform in platforms:
            connector = self._ad_connectors.get(platform)
            if not connector:
                # Create connector with placeholder credentials
                from simp.organs.media.account_creation.account_creator import PlatformCredentials
                creds = PlatformCredentials(platform=platform, access_token="placeholder")
                connector = create_ad_connector(platform, creds)
                self._ad_connectors[platform] = connector
            
            result = await connector.get_revenue_metrics(channel_id, period_days)
            
            if result.success and result.metrics:
                results[platform.value] = result.metrics
                
                # Add to revenue entries
                entry = RevenueEntry(
                    entry_id=f"rev_{platform.value}_{channel_id}_{int(datetime.now().timestamp())}",
                    channel_id=channel_id,
                    platform=platform,
                    revenue_type=RevenueType.AD_REVENUE,
                    amount=result.metrics.estimated_revenue,
                    views=result.metrics.total_views
                )
                self._entries[entry.entry_id] = entry
        
        self._save_entries()
        return results
    
    # =========================================================================
    # Affiliate Revenue Integration
    # =========================================================================
    
    async def fetch_affiliate_revenue(
        self,
        channel_id: str,
        period_days: int = 30
    ) -> AffiliateReport:
        """Fetch affiliate revenue for a channel."""
        report = await self.affiliate.get_report(period_days=period_days)
        
        # Add to revenue entries
        entry = RevenueEntry(
            entry_id=f"rev_aff_{channel_id}_{int(datetime.now().timestamp())}",
            channel_id=channel_id,
            platform=Platform.X,  # Generic
            revenue_type=RevenueType.AFFILIATE,
            amount=report.total_commission
        )
        self._entries[entry.entry_id] = entry
        
        self._save_entries()
        return report
    
    # =========================================================================
    # Revenue Aggregation
    # =========================================================================
    
    def get_channel_revenue(
        self,
        channel_id: str,
        period_days: int = 30
    ) -> ChannelRevenue:
        """Get revenue summary for a channel."""
        period_start = datetime.now() - timedelta(days=period_days)
        
        # Filter entries by channel and period
        channel_entries = [
            e for e in self._entries.values()
            if e.channel_id == channel_id
            and e.earned_at >= period_start
        ]
        
        total_revenue = sum(e.amount for e in channel_entries)
        total_views = sum(e.views for e in channel_entries)
        total_posts = len(channel_entries)
        
        # Aggregate by type
        ad_rev = sum(e.amount for e in channel_entries if e.revenue_type == RevenueType.AD_REVENUE)
        aff_rev = sum(e.amount for e in channel_entries if e.revenue_type == RevenueType.AFFILIATE)
        spon_rev = sum(e.amount for e in channel_entries if e.revenue_type == RevenueType.SPONSORSHIP)
        memb_rev = sum(e.amount for e in channel_entries if e.revenue_type == RevenueType.MEMBERSHIP)
        
        # Aggregate by platform
        platform_revenue: Dict[str, float] = {}
        for entry in channel_entries:
            p = entry.platform.value
            platform_revenue[p] = platform_revenue.get(p, 0) + entry.amount
        
        return ChannelRevenue(
            channel_id=channel_id,
            total_revenue=total_revenue,
            ad_revenue=ad_rev,
            affiliate_revenue=aff_rev,
            sponsorship_revenue=spon_rev,
            membership_revenue=memb_rev,
            platform_revenue=platform_revenue,
            rpm=(total_revenue / total_views * 1000) if total_views > 0 else 0.0,
            rpb=total_revenue / total_posts if total_posts > 0 else 0.0,
            total_views=total_views,
            total_posts=total_posts,
            period_start=period_start,
            period_end=datetime.now()
        )
    
    def get_empire_revenue(
        self,
        channel_ids: List[str],
        period_days: int = 30
    ) -> Dict[str, Any]:
        """Get consolidated revenue for all channels."""
        total_revenue = 0.0
        total_views = 0
        channel_summaries = {}
        
        for channel_id in channel_ids:
            revenue = self.get_channel_revenue(channel_id, period_days)
            channel_summaries[channel_id] = {
                "total_revenue": revenue.total_revenue,
                "rpm": revenue.rpm,
                "platform_breakdown": revenue.platform_revenue
            }
            total_revenue += revenue.total_revenue
            total_views += revenue.total_views
        
        return {
            "total_revenue": total_revenue,
            "total_views": total_views,
            "empire_rpm": (total_revenue / total_views * 1000) if total_views > 0 else 0.0,
            "channel_count": len(channel_ids),
            "channels": channel_summaries,
            "period_days": period_days
        }
    
    # =========================================================================
    # Kill/Scale Decisions
    # =========================================================================
    
    def should_kill_channel(
        self,
        channel_id: str,
        min_rpm: float = 0.50,
        min_days: int = 60
    ) -> bool:
        """Determine if a channel should be killed based on RPM."""
        # Check revenue for last N days
        cutoff = datetime.now() - timedelta(days=min_days)
        
        channel_entries = [
            e for e in self._entries.values()
            if e.channel_id == channel_id
            and e.earned_at >= cutoff
        ]
        
        if not channel_entries:
            return False  # No data yet
        
        total_revenue = sum(e.amount for e in channel_entries)
        total_views = sum(e.views for e in channel_entries)
        
        if total_views == 0:
            return False
        
        rpm = (total_revenue / total_views) * 1000
        
        return rpm < min_rpm
    
    def should_scale_channel(
        self,
        channel_id: str,
        min_ctr: float = 0.05,
        min_growth: float = 0.10
    ) -> bool:
        """Determine if a channel should be scaled/cloned."""
        # This would integrate with analytics to check:
        # - CTR > min_ctr
        # - Growth rate > min_growth
        # For now, simplified check
        
        revenue = self.get_channel_revenue(channel_id, period_days=7)
        
        # Scale if RPM is healthy and channel is growing
        return revenue.rpm > 1.0 and revenue.total_revenue > 100.0
