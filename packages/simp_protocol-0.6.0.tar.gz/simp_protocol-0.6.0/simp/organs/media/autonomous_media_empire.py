"""
Autonomous Media Empire - End-to-End Orchestration.

Wires together all components for fully autonomous media empire operation:

1. Account Creation (via ComputerUse + OAuth)
2. Content Generation (via ContentFactory)
3. Scheduling & Publishing (via SchedulerPublisherAgent)
4. Analytics & Optimization (via AnalyticsAgent)
5. Workflow Templates (from n8n/workflow_templates/)

This is the main entry point for the autonomous operation.
"""
import asyncio
import json
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

# Core modules
from simp.organs.media.account_creation import (
    AccountCreator, AccountCreationRequest, PlatformCredentials,
    PlatformConnector, create_connector
)
from simp.organs.media.content_factory import (
    ContentFactory, ContentPackage, LLMProvider, VideoProvider
)
from simp.organs.media.scheduler_publisher import (
    SchedulerPublisherAgent, ScheduledPost, SchedulerStatus
)
from simp.organs.media.platform_oauth_manager import (
    Platform, PlatformOAuthManager
)
from simp.organs.media.workflow_engine import (
    WorkflowEngine, WorkflowTrigger, WorkflowStatus
)
from simp.organs.media.computer_use_tools import (
    ComputerUseToolkit, create_computer_use_toolkit
)


class EmpireStatus(Enum):
    """Overall empire status."""
    INITIALIZING = "initializing"
    OPERATIONAL = "operational"
    SCALING = "scaling"
    PAUSED = "paused"
    ERROR = "error"


@dataclass
class Channel:
    """A media channel in the empire."""
    channel_id: str
    name: str
    niche: str
    brand_handle: str
    platforms: List[Platform] = field(default_factory=list)
    
    # Credentials
    credentials: Dict[str, PlatformCredentials] = field(default_factory=dict)
    
    # State
    is_active: bool = False
    followers_total: int = 0
    revenue_total: float = 0.0
    
    # Brand identity
    brand_name: str = ""
    brand_voice: str = ""
    visual_direction: str = ""
    
    created_at: datetime = field(default_factory=datetime.now)
    last_published: Optional[datetime] = None


@dataclass
class Campaign:
    """A content campaign across multiple channels."""
    campaign_id: str
    name: str
    channels: List[str] = field(default_factory=list)  # channel_ids
    goal: str = ""
    
    # Content
    ideas: List[str] = field(default_factory=list)
    scheduled_posts: List[str] = field(default_factory=list)
    
    # Metrics
    total_reach: int = 0
    total_engagement: int = 0
    total_revenue: float = 0.0
    
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class AutonomousMediaEmpire:
    """
    Main orchestration class for the autonomous media empire.
    
    Coordinates:
    - Account creation across platforms
    - Content generation pipeline
    - Multi-channel publishing
    - Analytics and optimization
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/empire",
        config: Optional[Dict] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.empire")
        self.config = config or {}
        
        # Status
        self.status = EmpireStatus.INITIALIZING
        self.started_at: Optional[datetime] = None
        
        # Core components
        self._account_creator: Optional[AccountCreator] = None
        self._content_factory: Optional[ContentFactory] = None
        self._scheduler: Optional[SchedulerPublisherAgent] = None
        self._workflow_engine: Optional[WorkflowEngine] = None
        self._oauth_manager: Optional[PlatformOAuthManager] = None
        
        # State
        self.channels: Dict[str, Channel] = {}
        self.campaigns: Dict[str, Campaign] = {}
        
        # Load state
        self._state_file = self.data_dir / "empire_state.json"
        self._load_state()
    
    async def initialize(self) -> bool:
        """Initialize all components."""
        self.logger.info("Initializing Autonomous Media Empire...")
        
        try:
            # Initialize computer use toolkit
            computer_use = create_computer_use_toolkit(str(self.data_dir / "computer_use"))
            await computer_use.initialize()
            
            # Initialize account creator
            self._account_creator = AccountCreator(
                data_dir=str(self.data_dir / "accounts"),
                computer_use=computer_use
            )
            await self._account_creator.initialize()
            
            # Initialize content factory
            self._content_factory = ContentFactory()
            
            # Initialize scheduler
            self._scheduler = SchedulerPublisherAgent(
                data_dir=str(self.data_dir / "scheduler")
            )
            
            # Initialize OAuth manager
            self._oauth_manager = PlatformOAuthManager(
                data_dir=str(self.data_dir / "oauth")
            )
            
            # Initialize workflow engine
            self._workflow_engine = WorkflowEngine(
                data_dir=str(self.data_dir / "workflows")
            )
            
            # Load workflow templates
            await self._load_workflow_templates()
            
            self.status = EmpireStatus.OPERATIONAL
            self.started_at = datetime.now()
            self._save_state()
            
            self.logger.info("✓ Autonomous Media Empire initialized")
            return True
            
        except Exception as e:
            self.logger.error(f"Initialization failed: {e}")
            self.status = EmpireStatus.ERROR
            return False
    
    async def _load_workflow_templates(self) -> None:
        """Load n8n workflow templates."""
        template_dir = Path("n8n/workflow_templates")
        if not template_dir.exists():
            self.logger.warning(f"Template directory not found: {template_dir}")
            return
        
        for template_file in template_dir.glob("*.json"):
            try:
                with open(template_file) as f:
                    template = json.load(f)
                    self.logger.info(f"Loaded workflow template: {template.get('name', template_file.name)}")
            except Exception as e:
                self.logger.error(f"Failed to load {template_file}: {e}")
    
    # =========================================================================
    # Channel Management
    # =========================================================================
    
    async def launch_channel(
        self,
        niche: str,
        brand_name: str,
        brand_handle: str,
        email: str,
        platforms: List[Platform],
        phone: Optional[str] = None
    ) -> Channel:
        """
        Launch a new channel across specified platforms.
        
        Flow:
        1. Create accounts on each platform (via ComputerUse + OAuth)
        2. Set up brand identity
        3. Generate initial content batch
        4. Start publishing schedule
        """
        channel_id = f"channel_{uuid.uuid4().hex[:8]}"
        
        self.logger.info(f"🚀 Launching channel: {brand_name} ({niche})")
        
        channel = Channel(
            channel_id=channel_id,
            name=brand_name,
            niche=niche,
            brand_handle=brand_handle,
            platforms=platforms,
            brand_name=brand_name
        )
        
        # Step 1: Create accounts on each platform
        for platform in platforms:
            self.logger.info(f"Creating {platform.value} account...")
            
            request = AccountCreationRequest(
                platform=platform,
                brand_name=brand_name,
                brand_handle=brand_handle,
                email=email,
                phone=phone,
                category=niche
            )
            
            result = await self._account_creator.create_account(request)
            
            if result.success and result.credentials:
                channel.credentials[platform.value] = result.credentials
                
                # Add connector to scheduler
                connector = create_connector(platform, result.credentials)
                self._scheduler.add_connector(platform, connector)
                
                self.logger.info(f"✓ {platform.value} account created")
            else:
                self.logger.error(f"✗ {platform.value} account creation failed: {result.error}")
        
        # Step 2: Generate initial content (30 days)
        self.logger.info("Generating initial content batch...")
        calendar = await self._scheduler.generate_calendar(
            channel_id=channel_id,
            days=30,
            posts_per_day=2,
            platforms=platforms
        )
        
        # Step 3: Queue posts for generation
        for post in calendar.posts[:10]:  # Start with first 10
            await self._scheduler.queue_for_scheduling(post)
        
        # Step 4: Start publishing loop
        await self._scheduler.start_publishing_loop(channel_id)
        
        channel.is_active = True
        self.channels[channel_id] = channel
        self._save_state()
        
        self.logger.info(f"✓ Channel {brand_name} launched successfully!")
        return channel
    
    async def clone_channel(
        self,
        source_channel_id: str,
        new_niche: Optional[str] = None,
        new_platform: Optional[Platform] = None,
        new_language: Optional[str] = None
    ) -> Channel:
        """
        Clone an existing channel with modifications.
        
        Used for:
        - Expanding to new niches
        - Adding new platforms
        - Localizing to new languages/demographics
        """
        source = self.channels.get(source_channel_id)
        if not source:
            raise ValueError(f"Source channel not found: {source_channel_id}")
        
        # Create new channel with cloned settings
        new_niche = new_niche or source.niche
        new_channel_id = f"channel_{uuid.uuid4().hex[:8]}"
        
        channel = Channel(
            channel_id=new_channel_id,
            name=f"{source.name} (Clone)",
            niche=new_niche,
            brand_handle=f"{source.brand_handle}_clone",
            platforms=[new_platform] if new_platform else source.platforms,
            brand_name=source.brand_name,
            brand_voice=source.brand_voice,
            visual_direction=source.visual_direction
        )
        
        # If adding new platform, create account
        if new_platform and new_platform not in source.platforms:
            request = AccountCreationRequest(
                platform=new_platform,
                brand_name=channel.brand_name,
                brand_handle=channel.brand_handle,
                email="clone@example.com"  # Would be a real email
            )
            result = await self._account_creator.create_account(request)
            if result.success:
                channel.credentials[new_platform.value] = result.credentials
        
        # Generate content for new configuration
        calendar = await self._scheduler.generate_calendar(
            channel_id=new_channel_id,
            days=30,
            platforms=channel.platforms
        )
        
        channel.is_active = True
        self.channels[new_channel_id] = channel
        self._save_state()
        
        return channel
    
    # =========================================================================
    # Content Generation Pipeline
    # =========================================================================
    
    async def generate_content(
        self,
        channel_id: str,
        idea: str,
        content_type: str = "short_video",
        duration_seconds: int = 60
    ) -> ContentPackage:
        """
        Generate content for a channel.
        
        Pipeline:
        1. Generate script (via LLM)
        2. Generate video assets (via AI video)
        3. Process and edit
        """
        channel = self.channels.get(channel_id)
        if not channel:
            raise ValueError(f"Channel not found: {channel_id}")
        
        # Get primary platform
        platform = channel.platforms[0] if channel.platforms else Platform.TIKTOK
        
        # Generate via content factory
        package = await self._content_factory.create_content(
            niche=channel.niche,
            platform=platform.value,
            content_type=content_type,
            duration=duration_seconds,
            brand_voice=channel.brand_voice,
            script_override=idea
        )
        
        return package
    
    async def batch_generate_content(
        self,
        channel_id: str,
        ideas: List[str],
        max_concurrent: int = 3
    ) -> List[ContentPackage]:
        """Generate multiple content pieces in parallel."""
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def generate_one(idea: str) -> ContentPackage:
            async with semaphore:
                return await self.generate_content(channel_id, idea)
        
        tasks = [generate_one(idea) for idea in ideas]
        return await asyncio.gather(*tasks)
    
    # =========================================================================
    # Publishing Pipeline
    # =========================================================================
    
    async def publish_post(
        self,
        channel_id: str,
        post_id: str,
        content_package: Optional[ContentPackage] = None
    ) -> bool:
        """
        Publish a scheduled post.
        
        If content_package provided, generate content first.
        Otherwise use pre-generated content.
        """
        post = self._scheduler._scheduled_posts.get(post_id)
        if not post:
            raise ValueError(f"Post not found: {post_id}")
        
        # Generate content if needed
        if content_package:
            post.content.title = content_package.script.title
            post.content.caption = content_package.script.caption
            
            if content_package.video_asset:
                from simp.organs.media.account_creation.platform_connectors import MediaAsset
                post.content.media.append(MediaAsset(
                    media_type="video",
                    file_path=content_package.video_asset.get("path")
                ))
        
        # Publish
        result = await self._scheduler._publish_post(post)
        
        # Update channel
        channel = self.channels.get(channel_id)
        if channel and result.success:
            channel.last_published = datetime.now()
            self._save_state()
        
        return result.success
    
    # =========================================================================
    # Analytics & Optimization
    # =========================================================================
    
    async def refresh_metrics(self) -> Dict[str, Any]:
        """Refresh metrics for all channels."""
        metrics = {}
        
        for channel_id, channel in self.channels.items():
            channel_metrics = {
                "channel_id": channel_id,
                "name": channel.name,
                "followers_total": channel.followers_total,
                "revenue_total": channel.revenue_total,
                "platforms": {}
            }
            
            # Get metrics from each connector
            for platform_value, credentials in channel.credentials.items():
                platform = Platform(platform_value)
                connector = create_connector(platform, credentials)
                platform_metrics = await connector.get_metrics()
                
                channel_metrics["platforms"][platform_value] = {
                    "followers": platform_metrics.followers,
                    "views": platform_metrics.total_views,
                    "engagement": platform_metrics.total_engagement
                }
                
                channel.followers_total += platform_metrics.followers
            
            metrics[channel_id] = channel_metrics
        
        self._save_state()
        return metrics
    
    async def analyze_performance(self) -> Dict[str, Any]:
        """Analyze channel performance and suggest optimizations."""
        # Get recent posts
        recent_posts = []
        for post in self._scheduler._scheduled_posts.values():
            if post.published_at and (datetime.now() - post.published_at).days <= 7:
                recent_posts.append(post)
        
        # Calculate top/bottom performers
        sorted_posts = sorted(recent_posts, key=lambda p: p.engagement_24hr, reverse=True)
        top_posts = sorted_posts[:5]
        bottom_posts = sorted_posts[-5:]
        
        return {
            "total_posts_analyzed": len(recent_posts),
            "avg_engagement": sum(p.engagement_24hr for p in recent_posts) / len(recent_posts) if recent_posts else 0,
            "top_performers": [p.post_id for p in top_posts],
            "bottom_performers": [p.post_id for p in bottom_posts],
            "suggestions": [
                "Increase posting frequency during peak engagement hours",
                "Test shorter hooks in first 3 seconds",
                "A/B test thumbnail styles"
            ]
        }
    
    # =========================================================================
    # State Management
    # =========================================================================
    
    def _load_state(self) -> None:
        """Load empire state from disk."""
        if self._state_file.exists():
            with open(self._state_file) as f:
                data = json.load(f)
                
                # Load channels
                for channel_data in data.get("channels", []):
                    channel_data["created_at"] = datetime.fromisoformat(channel_data["created_at"])
                    if channel_data.get("last_published"):
                        channel_data["last_published"] = datetime.fromisoformat(channel_data["last_published"])
                    channel = Channel(**channel_data)
                    self.channels[channel.channel_id] = channel
                
                # Load campaigns
                for campaign_data in data.get("campaigns", []):
                    campaign_data["created_at"] = datetime.fromisoformat(campaign_data["created_at"])
                    campaign = Campaign(**campaign_data)
                    self.campaigns[campaign.campaign_id] = campaign
    
    def _save_state(self) -> None:
        """Save empire state to disk."""
        data = {
            "status": self.status.value,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "channels": [
                {
                    **vars(channel),
                    "credentials": {
                        k: {
                            **vars(v),
                            "expires_at": v.expires_at
                        }
                        for k, v in channel.credentials.items()
                    }
                }
                for channel in self.channels.values()
            ],
            "campaigns": [
                {**vars(campaign)}
                for campaign in self.campaigns.values()
            ]
        }
        
        with open(self._state_file, "w") as f:
            json.dump(data, f, indent=2, default=str)
    
    def get_status(self) -> Dict[str, Any]:
        """Get overall empire status."""
        return {
            "status": self.status.value,
            "uptime_seconds": (datetime.now() - self.started_at).total_seconds() if self.started_at else 0,
            "channels_total": len(self.channels),
            "channels_active": sum(1 for c in self.channels.values() if c.is_active),
            "campaigns_total": len(self.campaigns),
            "queue_status": self._scheduler.get_queue_status() if self._scheduler else {}
        }


# =============================================================================
# CLI Integration
# =============================================================================

async def create_empire() -> AutonomousMediaEmpire:
    """Factory function to create and initialize empire."""
    empire = AutonomousMediaEmpire()
    await empire.initialize()
    return empire


if __name__ == "__main__":
    # Example usage
    async def main():
        empire = await create_empire()
        
        # Launch a test channel
        channel = await empire.launch_channel(
            niche="AI Tools",
            brand_name="AI Insider",
            brand_handle="aiinsider",
            email="launch@aiinsider.com",
            platforms=[Platform.TIKTOK, Platform.YOUTUBE, Platform.X]
        )
        
        print(f"✓ Launched channel: {channel.name}")
        print(f"  Status: {empire.get_status()}")
    
    asyncio.run(main())


# =============================================================================
# Revenue Integration (Tranche 6)
# =============================================================================

    async def refresh_revenue_metrics(self) -> Dict[str, Any]:
        """Refresh revenue metrics for all channels."""
        from simp.organs.media.revenue_manager import RevenueManager
        from simp.organs.media.ad_connectors import create_ad_connector
        
        revenue_manager = RevenueManager(
            data_dir=str(self.data_dir / "revenue")
        )
        
        # Add connectors for each channel
        for channel_id, channel in self.channels.items():
            for platform_value, credentials in channel.credentials.items():
                from simp.organs.media.platform_oauth_manager import Platform
                platform = Platform(platform_value)
                connector = create_ad_connector(platform, credentials)
                revenue_manager.add_ad_connector(platform, connector)
        
        # Fetch revenue for all channels
        empire_revenue = revenue_manager.get_empire_revenue(
            channel_ids=list(self.channels.keys()),
            period_days=30
        )
        
        self.logger.info(f"Empire revenue: ${empire_revenue['total_revenue']:.2f}")
        return empire_revenue
    
    async def check_channel_health(self) -> List[Dict[str, Any]]:
        """Check health of all channels and recommend actions."""
        from simp.organs.media.revenue_manager import RevenueManager
        
        revenue_manager = RevenueManager(
            data_dir=str(self.data_dir / "revenue")
        )
        
        actions = []
        for channel_id, channel in self.channels.items():
            # Check kill condition
            if revenue_manager.should_kill_channel(channel_id):
                actions.append({
                    "channel_id": channel_id,
                    "action": "KILL",
                    "reason": "RPM below threshold for 60+ days",
                    "requires_approval": True
                })
            
            # Check scale condition
            if revenue_manager.should_scale_channel(channel_id):
                actions.append({
                    "channel_id": channel_id,
                    "action": "SCALE",
                    "reason": "Healthy RPM and growth rate",
                    "recommendation": "clone_channel"
                })
        
        return actions
