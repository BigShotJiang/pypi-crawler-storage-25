"""
n8n Workflow Templates for Anil-matcha's AI Tools.

Generates n8n workflow JSON for automating:
- Video generation (Seedance, Veo, HappyHorse, Hailuo)
- Image generation (Midjourney, Flux, Stable Diffusion)
- Multi-step content pipelines
"""
import json
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any


@dataclass
class WorkflowTemplate:
    """n8n workflow template."""
    name: str
    description: str
    nodes: List[Dict] = field(default_factory=list)
    connections: Dict = field(default_factory=dict)


def create_seedance_workflow(
    api_key: str = "{{env.SEEDANCE_API_KEY}}",
    api_url: str = "https://api.muapi.ai/v1/seedance"
) -> Dict:
    """Create Seedance 2.0 video generation workflow."""
    workflow_id = str(uuid.uuid4())
    
    nodes = [
        {
            "id": "trigger-1",
            "name": "Webhook Trigger",
            "type": "n8n-nodes-base.webhook",
            "parameters": {
                "httpMethod": "POST",
                "path": "generate-video",
                "responseMode": "lastNode",
            },
            "position": [100, 300],
        },
        {
            "id": "parse-1",
            "name": "Parse Prompt",
            "type": "n8n-nodes-base.set",
            "parameters": {
                "mode": "manual",
                "duplicateItem": False,
                "assignments": {
                    "assignments": [
                        {"name": "prompt", "value": "={{ $json.body.prompt }}"},
                        {"name": "model", "value": "={{ $json.body.model || 'seedance-2.0-standard' }}"},
                        {"name": "duration", "value": "={{ $json.body.duration || 5 }}"},
                        {"name": "aspect_ratio", "value": "={{ $json.body.aspect_ratio || '16:9' }}"},
                    ]
                },
                "options": {},
            },
            "position": [300, 300],
        },
        {
            "id": "api-1",
            "name": "Seedance API",
            "type": "n8n-nodes-base.httpRequest",
            "parameters": {
                "url": f"{api_url}/generate",
                "method": "POST",
                "authentication": "genericCredentialType",
                "genericAuthType": "httpHeaderAuth",
                "sendHeaders": True,
                "headerParameters": {
                    "parameters": [
                        {"name": "Authorization", "value": f"Bearer {api_key}"},
                        {"name": "Content-Type", "value": "application/json"},
                    ]
                },
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "prompt", "value": "={{ $json.prompt }}"},
                        {"name": "model", "value": "={{ $json.model }}"},
                        {"name": "duration", "value": "={{ $json.duration }}"},
                        {"name": "aspect_ratio", "value": "={{ $json.aspect_ratio }}"},
                    ]
                },
                "options": {"timeout": 120000},
            },
            "position": [500, 300],
        },
        {
            "id": "respond-1",
            "name": "Return Video URL",
            "type": "n8n-nodes-base.respondToWebhook",
            "parameters": {
                "respondWith": "json",
                "responseBody": {
                    "video_url": "={{ $json.data.video_url }}",
                    "job_id": "={{ $json.data.job_id }}",
                    "status": "={{ $json.status }}",
                },
            },
            "position": [700, 300],
        },
    ]
    
    connections = {
        "trigger-1": {"main": [[{"node": "parse-1", "type": "main", "index": 0}]]},
        "parse-1": {"main": [[{"node": "api-1", "type": "main", "index": 0}]]},
        "api-1": {"main": [[{"node": "respond-1", "type": "main", "index": 0}]]},
    }
    
    return {
        "name": "Seedance 2.0 Video Generation",
        "nodes": nodes,
        "connections": connections,
        "settings": {
            "executionOrder": "v1",
        },
        "staticData": None,
        "tags": ["video", "ai", "seedance", "media-empire"],
    }


def create_veo4_workflow(
    api_key: str = "{{env.VEO_API_KEY}}",
    api_url: str = "https://api.muapi.ai/v1/veo4"
) -> Dict:
    """Create Veo 4 (4K) video generation workflow."""
    nodes = [
        {
            "id": "trigger-1",
            "name": "Webhook Trigger",
            "type": "n8n-nodes-base.webhook",
            "parameters": {
                "httpMethod": "POST",
                "path": "generate-veo4",
                "responseMode": "lastNode",
            },
            "position": [100, 300],
        },
        {
            "id": "parse-1",
            "name": "Parse Request",
            "type": "n8n-nodes-base.set",
            "parameters": {
                "assignments": {
                    "assignments": [
                        {"name": "prompt", "value": "={{ $json.body.prompt }}"},
                        {"name": "resolution", "value": "4k"},
                        {"name": "fps", "value": 30},
                    ]
                },
            },
            "position": [300, 300],
        },
        {
            "id": "api-1",
            "name": "Veo 4 API",
            "type": "n8n-nodes-base.httpRequest",
            "parameters": {
                "url": f"{api_url}/generate",
                "method": "POST",
                "sendHeaders": True,
                "headerParameters": {
                    "parameters": [
                        {"name": "Authorization", "value": f"Bearer {api_key}"},
                    ]
                },
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "prompt", "value": "={{ $json.prompt }}"},
                        {"name": "resolution", "value": "={{ $json.resolution }}"},
                        {"name": "fps", "value": "={{ $json.fps }}"},
                    ]
                },
                "options": {"timeout": 300000},  # 5 min for 4K
            },
            "position": [500, 300],
        },
        {
            "id": "respond-1",
            "name": "Return Response",
            "type": "n8n-nodes-base.respondToWebhook",
            "parameters": {
                "respondWith": "json",
                "responseBody": {
                    "video_url": "={{ $json.data.video_url }}",
                    "resolution": "4K",
                    "job_id": "={{ $json.data.job_id }}",
                },
            },
            "position": [700, 300],
        },
    ]
    
    connections = {
        "trigger-1": {"main": [[{"node": "parse-1", "type": "main", "index": 0}]]},
        "parse-1": {"main": [[{"node": "api-1", "type": "main", "index": 0}]]},
        "api-1": {"main": [[{"node": "respond-1", "type": "main", "index": 0}]]},
    }
    
    return {
        "name": "Veo 4 4K Video Generation",
        "nodes": nodes,
        "connections": connections,
        "tags": ["video", "ai", "veo", "4k", "media-empire"],
    }


def create_happyhorse_workflow(
    api_key: str = "{{env.HAPPYHORSE_API_KEY}}",
    api_url: str = "https://api.muapi.ai/v1/happyhorse"
) -> Dict:
    """Create HappyHorse 1.0 video generation workflow."""
    nodes = [
        {
            "id": "trigger-1",
            "name": "Webhook Trigger",
            "type": "n8n-nodes-base.webhook",
            "parameters": {
                "httpMethod": "POST",
                "path": "generate-happyhorse",
            },
            "position": [100, 300],
        },
        {
            "id": "api-1",
            "name": "HappyHorse API",
            "type": "n8n-nodes-base.httpRequest",
            "parameters": {
                "url": f"{api_url}/generate",
                "method": "POST",
                "sendHeaders": True,
                "headerParameters": {
                    "parameters": [
                        {"name": "Authorization", "value": f"Bearer {api_key}"},
                    ]
                },
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "prompt", "value": "={{ $json.body.prompt }}"},
                        {"name": "model", "value": "={{ $json.body.model || 'happyhorse-1.0-pro' }}"},
                    ]
                },
            },
            "position": [300, 300],
        },
        {
            "id": "respond-1",
            "name": "Return Response",
            "type": "n8n-nodes-base.respondToWebhook",
            "parameters": {
                "respondWith": "json",
                "responseBody": {
                    "video_url": "={{ $json.data.video_url }}",
                    "model": "HappyHorse 1.0",
                },
            },
            "position": [500, 300],
        },
    ]
    
    connections = {
        "trigger-1": {"main": [[{"node": "api-1", "type": "main", "index": 0}]]},
        "api-1": {"main": [[{"node": "respond-1", "type": "main", "index": 0}]]},
    }
    
    return {
        "name": "HappyHorse 1.0 Video Generation",
        "nodes": nodes,
        "connections": connections,
        "tags": ["video", "ai", "happyhorse", "alibaba", "media-empire"],
    }


def create_image_generation_workflow(
    tool: str = "midjourney",
    api_key: str = "{{env.MIDJOURNEY_API_KEY}}",
    api_url: str = "https://api.muapi.ai/v1/midjourney"
) -> Dict:
    """Create image generation workflow for Midjourney/Flux/Stable Diffusion."""
    nodes = [
        {
            "id": "trigger-1",
            "name": "Webhook Trigger",
            "type": "n8n-nodes-base.webhook",
            "parameters": {
                "httpMethod": "POST",
                "path": f"generate-{tool}",
            },
            "position": [100, 300],
        },
        {
            "id": "api-1",
            "name": f"{tool.title()} API",
            "type": "n8n-nodes-base.httpRequest",
            "parameters": {
                "url": f"{api_url}/generate",
                "method": "POST",
                "sendHeaders": True,
                "headerParameters": {
                    "parameters": [
                        {"name": "Authorization", "value": f"Bearer {api_key}"},
                    ]
                },
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "prompt", "value": "={{ $json.body.prompt }}"},
                        {"name": "aspect_ratio", "value": "={{ $json.body.aspect_ratio || '1:1' }}"},
                        {"name": "style", "value": "={{ $json.body.style || 'vivid' }}"},
                    ]
                },
            },
            "position": [300, 300],
        },
        {
            "id": "respond-1",
            "name": "Return Response",
            "type": "n8n-nodes-base.respondToWebhook",
            "parameters": {
                "respondWith": "json",
                "responseBody": {
                    "image_urls": "={{ $json.data.image_urls }}",
                    "tool": tool,
                },
            },
            "position": [500, 300],
        },
    ]
    
    return {
        "name": f"{tool.title()} Image Generation",
        "nodes": nodes,
        "connections": {
            "trigger-1": {"main": [[{"node": "api-1", "type": "main", "index": 0}]]},
            "api-1": {"main": [[{"node": "respond-1", "type": "main", "index": 0}]]},
        },
        "tags": ["image", "ai", tool, "media-empire"],
    }


def create_content_pipeline_workflow(
    video_tool: str = "seedance",
    image_tool: str = "midjourney"
) -> Dict:
    """Create multi-step content pipeline: thumbnail → video → publish."""
    nodes = [
        {
            "id": "trigger-1",
            "name": "Content Request",
            "type": "n8n-nodes-base.webhook",
            "parameters": {"httpMethod": "POST", "path": "create-content"},
            "position": [100, 300],
        },
        {
            "id": "thumbnail-1",
            "name": "Generate Thumbnail",
            "type": "n8n-nodes-base.httpRequest",
            "parameters": {
                "url": f"https://api.muapi.ai/v1/{image_tool}/generate",
                "method": "POST",
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "prompt", "value": "={{ $json.body.prompt }}+ cinematic thumbnail, high quality"},
                    ]
                },
            },
            "position": [300, 200],
        },
        {
            "id": "video-1",
            "name": "Generate Video",
            "type": "n8n-nodes-base.httpRequest",
            "parameters": {
                "url": f"https://api.muapi.ai/v1/{video_tool}/generate",
                "method": "POST",
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "prompt", "value": "={{ $json.body.prompt }}"},
                        {"name": "duration", "value": "={{ $json.body.duration || 10 }}"},
                    ]
                },
            },
            "position": [500, 300],
        },
        {
            "id": "notify-1",
            "name": "Notify Complete",
            "type": "n8n-nodes-base.slack",
            "parameters": {
                "channel": "#content-pipeline",
                "text": "={{ $json.body.channel_name }}: Content generated! Video: {{ $json.video_url }}",
            },
            "position": [700, 300],
        },
    ]
    
    return {
        "name": f"Content Pipeline ({video_tool} + {image_tool})",
        "nodes": nodes,
        "connections": {
            "trigger-1": {"main": [[{"node": "thumbnail-1", "type": "main", "index": 0}]]},
            "thumbnail-1": {"main": [[{"node": "video-1", "type": "main", "index": 0}]]},
            "video-1": {"main": [[{"node": "notify-1", "type": "main", "index": 0}]]},
        },
        "tags": ["pipeline", "video", "thumbnail", "media-empire"],
    }


def save_workflow_templates(output_dir: str = "n8n/workflow_templates") -> None:
    """Save all workflow templates to n8n directory."""
    import os
    os.makedirs(output_dir, exist_ok=True)
    
    workflows = [
        ("seedance_workflow.json", create_seedance_workflow()),
        ("veo4_workflow.json", create_veo4_workflow()),
        ("happyhorse_workflow.json", create_happyhorse_workflow()),
        ("midjourney_workflow.json", create_image_generation_workflow("midjourney")),
        ("flux_workflow.json", create_image_generation_workflow("flux")),
        ("content_pipeline.json", create_content_pipeline_workflow()),
    ]
    
    for filename, workflow in workflows:
        path = os.path.join(output_dir, filename)
        with open(path, "w") as f:
            json.dump(workflow, f, indent=2)
        print(f"✓ Saved {path}")
