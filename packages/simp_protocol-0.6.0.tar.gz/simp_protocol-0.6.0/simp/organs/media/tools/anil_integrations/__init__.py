"""
Anil-matcha's Tool Integrations for Media Empire.

Source: https://github.com/Anil-matcha

Key Tools Integrated:
- Video Generation: Seedance 2.0, Veo 4, Veo 3.1, HappyHorse 1.0, Hailuo 3.0
- Image Generation: Open-Generative-AI (Flux, Midjourney, Kling, Sora, Stable Diffusion)
- ComfyUI Nodes: All major AI video models via ComfyUI
- LLM Aggregation: Open-Poe-AI style interfaces
"""
import os
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path

logger = logging.getLogger("media.tools.anil")

# Feature flags - set via environment
SEEDANCE_ENABLED = os.environ.get("SEEDANCE_ENABLED", "false").lower() == "true"
VEO_ENABLED = os.environ.get("VEO_ENABLED", "false").lower() == "true"
HAPPYHORSE_ENABLED = os.environ.get("HAPPYHORSE_ENABLED", "false").lower() == "true"
MIDJOURNEY_ENABLED = os.environ.get("MIDJOURNEY_ENABLED", "false").lower() == "true"
OPEN_GENERATIVE_AI_ENABLED = os.environ.get("OPEN_GENERATIVE_AI_ENABLED", "false").lower() == "true"
HAILUO_ENABLED = os.environ.get("HAILUO_ENABLED", "false").lower() == "true"


class VideoModel(Enum):
    """Available AI video generation models."""
    SEEDANCE_2 = "seedance_2"
    VEO_4 = "veo_4"
    VEO_3_1 = "veo_3_1"
    HAPPYHORSE_1 = "happyhorse_1"
    HAILUO_3 = "hailuo_3"
    KLING = "kling"
    SORA = "sora"
    GEN3 = "gen3"  # Generic fallback


class ImageModel(Enum):
    """Available AI image generation models."""
    FLUX_1 = "flux_1"
    FLUX_PRO = "flux_pro"
    MIDJOURNEY = "midjourney"
    DALL_E_3 = "dall_e_3"
    GPT_IMAGE_2 = "gpt_image_2"
    STABLE_DIFFUSION = "stable_diffusion"
    KLING_IMAGE = "kling_image"
    IMAGEN_3 = "imagen_3"


@dataclass
class ToolConfig:
    """Configuration for an AI tool."""
    name: str
    api_endpoint: str
    api_key_env: str
    enabled: bool = False
    rate_limit_rpm: int = 10
    cost_per_call: float = 0.0
    models: List[str] = field(default_factory=list)
    capabilities: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GenerationResult:
    """Result of content generation."""
    success: bool
    tool: str
    model: str
    output_url: Optional[str] = None
    output_path: Optional[str] = None
    duration: Optional[float] = None
    resolution: Optional[str] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class AnilToolRegistry:
    """
    Registry of Anil-matcha's AI tools integrated for Media Empire.
    
    Provides unified interface to:
    - AI video generation (Seedance, Veo, HappyHorse, Hailuo)
    - AI image generation (Flux, Midjourney, Stable Diffusion)
    - ComfyUI node wrappers
    - LLM aggregation
    """
    
    def __init__(self, data_dir: str = "data/media/tools"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.tools.anil.registry")
        
        # Initialize tool configurations
        self._tools: Dict[str, ToolConfig] = {}
        self._init_tools()
        
        # Usage tracking
        self._usage: Dict[str, int] = {}
        self._costs: Dict[str, float] = {}
    
    def _init_tools(self) -> None:
        """Initialize all tool configurations from Anil-matcha's repos."""
        
        # Seedance 2.0 API - ByteDance's video model
        self._tools["seedance"] = ToolConfig(
            name="Seedance 2.0 API",
            api_endpoint=os.environ.get("SEEDANCE_API_URL", "https://api.muapi.ai/v1/seedance"),
            api_key_env="SEEDANCE_API_KEY",
            enabled=SEEDANCE_ENABLED,
            rate_limit_rpm=5,
            cost_per_call=0.05,
            models=["seedance-2.0-standard", "seedance-2.0-pro"],
            capabilities=["text-to-video", "image-to-video", "video-extend", "video-edit"],
            metadata={
                "source": "https://github.com/Anil-matcha/Seedance-2.0-API",
                "provider": "ByteDance",
                "resolution": "1080p",
                "max_duration": 10,
            }
        )
        
        # Veo 4 API - Google DeepMind
        self._tools["veo4"] = ToolConfig(
            name="Veo 4 API",
            api_endpoint=os.environ.get("VEO_API_URL", "https://api.muapi.ai/v1/veo4"),
            api_key_env="VEO_API_KEY",
            enabled=VEO_ENABLED,
            rate_limit_rpm=3,
            cost_per_call=0.10,
            models=["veo-4.0-generate-001"],
            capabilities=["text-to-video", "image-to-video", "character-consistency", "camera-control", "4k"],
            metadata={
                "source": "https://github.com/Anil-matcha/Veo-4-API",
                "provider": "Google DeepMind",
                "resolution": "4K",
                "max_duration": 60,
            }
        )
        
        # Veo 3.1 via ComfyUI
        self._tools["veo31"] = ToolConfig(
            name="Veo 3.1 (ComfyUI)",
            api_endpoint=os.environ.get("VEO31_API_URL", "https://api.muapi.ai/v1/veo31"),
            api_key_env="VEO31_API_KEY",
            enabled=False,  # ComfyUI mode
            rate_limit_rpm=5,
            cost_per_call=0.03,
            models=["veo-3.1"],
            capabilities=["text-to-video", "image-to-video", "reference-to-video", "extend", "4k-upscale"],
            metadata={
                "source": "https://github.com/Anil-matcha/veo3.1-comfyui",
                "provider": "Google DeepMind",
                "resolution": "4K",
                "interface": "ComfyUI",
            }
        )
        
        # HappyHorse 1.0 - Alibaba's #1 ranked video model
        self._tools["happyhorse"] = ToolConfig(
            name="HappyHorse 1.0 API",
            api_endpoint=os.environ.get("HAPPYHORSE_API_URL", "https://api.muapi.ai/v1/happyhorse"),
            api_key_env="HAPPYHORSE_API_KEY",
            enabled=HAPPYHORSE_ENABLED,
            rate_limit_rpm=5,
            cost_per_call=0.02,
            models=["happyhorse-1.0-standard", "happyhorse-1.0-pro"],
            capabilities=["text-to-video", "image-to-video", "video-edit", "audio-integrated"],
            metadata={
                "source": "https://github.com/Anil-matcha/happyhorse-comfyui",
                "provider": "Alibaba",
                "resolution": "1080p",
                "max_duration": 10,
                "note": "#1 ranked AI video model on benchmarks",
            }
        )
        
        # Hailuo 3.0 - MiniMax
        self._tools["hailuo"] = ToolConfig(
            name="Hailuo 3.0 API",
            api_endpoint=os.environ.get("HAILUO_API_URL", "https://api.muapi.ai/v1/hailuo3"),
            api_key_env="HAILUO_API_KEY",
            enabled=HAILUO_ENABLED,
            rate_limit_rpm=5,
            cost_per_call=0.03,
            models=["hailuo-3.0-standard", "hailuo-3.0-plus"],
            capabilities=["text-to-video", "character-consistency", "lip-sync", "4k"],
            metadata={
                "source": "https://github.com/Anil-matcha/hailuo-3.0-api",
                "provider": "MiniMax",
                "resolution": "4K",
                "max_duration": 30,
            }
        )
        
        # Midjourney via muapi.ai
        self._tools["midjourney"] = ToolConfig(
            name="Midjourney (muapi.ai)",
            api_endpoint=os.environ.get("MIDJOURNEY_API_URL", "https://api.muapi.ai/v1/midjourney"),
            api_key_env="MIDJOURNEY_API_KEY",
            enabled=MIDJOURNEY_ENABLED,
            rate_limit_rpm=10,
            cost_per_call=0.02,
            models=["midjourney-v7", "midjourney-niji-v6"],
            capabilities=["image-generation", "image-to-image", "variations", "upscale"],
            metadata={
                "source": "https://github.com/Anil-matcha/midjourney-comfyui",
                "interface": "ComfyUI",
                "images_per_run": 4,
            }
        )
        
        # Open-Generative-AI - Self-hosted alternative
        self._tools["opengenerative"] = ToolConfig(
            name="Open Generative AI",
            api_endpoint=os.environ.get("OPEN_GENERATIVE_API_URL", "http://localhost:3000"),
            api_key_env="OPEN_GENERATIVE_API_KEY",
            enabled=OPEN_GENERATIVE_AI_ENABLED,
            rate_limit_rpm=20,
            cost_per_call=0.0,  # Self-hosted
            models=[
                "flux-pro", "flux-dev", "flux-schnell",
                "midjourney", "dall-e-3",
                "kling-pro", "kling-standard",
                "sora-1", "veo-2",
                "stable-diffusion-xl",
            ],
            capabilities=[
                "text-to-image", "image-to-image", "text-to-video",
                "image-to-video", "inpainting", "outpainting",
            ],
            metadata={
                "source": "https://github.com/Anil-matcha/Open-Generative-AI",
                "license": "MIT",
                "self_hosted": True,
                "models_count": 200,
                "note": "Uncensored, no content filters",
            }
        )
        
        self.logger.info(f"Initialized {len(self._tools)} tools from Anil-matcha's repos")
    
    def get_tool(self, name: str) -> Optional[ToolConfig]:
        """Get tool configuration by name."""
        return self._tools.get(name.lower())
    
    def list_tools(self, enabled_only: bool = False) -> List[ToolConfig]:
        """List all available tools."""
        tools = list(self._tools.values())
        if enabled_only:
            tools = [t for t in tools if t.enabled]
        return tools
    
    def is_enabled(self, name: str) -> bool:
        """Check if a tool is enabled and configured."""
        tool = self._tools.get(name.lower())
        if not tool:
            return False
        api_key = os.environ.get(tool.api_key_env)
        return tool.enabled and bool(api_key)
    
    def get_capabilities(self, name: str) -> List[str]:
        """Get capabilities for a tool."""
        tool = self._tools.get(name.lower())
        return tool.capabilities if tool else []
    
    def track_usage(self, tool: str, cost: float = 0.0) -> None:
        """Track tool usage."""
        self._usage[tool] = self._usage.get(tool, 0) + 1
        self._costs[tool] = self._costs.get(tool, 0.0) + cost
    
    def get_stats(self) -> Dict[str, Any]:
        """Get usage statistics."""
        return {
            "tools": {name: {"uses": self._usage.get(name, 0), "cost": self._costs.get(name, 0)}
                     for name in self._tools},
            "total_uses": sum(self._usage.values()),
            "total_cost": sum(self._costs.values()),
        }


# Global registry instance
_registry: Optional[AnilToolRegistry] = None


def get_anil_registry() -> AnilToolRegistry:
    """Get global Anil tool registry instance."""
    global _registry
    if _registry is None:
        _registry = AnilToolRegistry()
    return _registry
