"""
FREE AI Tools Registry for Media Empire.

Curated list of free/affordable AI tools for content creation:
- Text-to-Speech / Voice Cloning
- Video Generation (free tiers)
- Image Generation (free tiers)
- Script Generation (free LLMs)
- Music/Sound Effects
"""
import os
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path

logger = logging.getLogger("media.tools.free")

# =============================================================================
# TTS / VOICE CLONING
# =============================================================================

class TTSProvider(Enum):
    """Free/affordable TTS providers."""
    COQUI = "coqui"  # Open source voice cloning
    BARK = "bark"  # Suno's open-source TTS
    tortoise = "tortoise"  # High-quality open source
    VOICEBOOK = "voicebook"  # ElevenLabs free tier
    PIX2SPEECH = "pix2speech"  # Free TTS
    MMS = "mms"  # Facebook's Massively Multilingual Speech


class VoiceCloningProvider(Enum):
    """Voice cloning options."""
    COQUI_XTTS = "coqui_xtts"  # Open source, local
    Tortoise_TTS = "tortoise"  # High quality, slow
    SV2TTS = "sv2tts"  # Resemble.ai free tier
    ElevenLabs_VoiceLab = "elevenlabs_voice_lab"  # 10k chars free/month


@dataclass
class VoiceProfile:
    """Voice profile for TTS."""
    voice_id: str
    name: str
    provider: str
    language: str = "en"
    gender: str = "neutral"  # male, female, neutral
    quality: str = "high"  # low, medium, high
    is_clone: bool = False
    sample_url: Optional[str] = None


@dataclass
class TTSConfig:
    """Configuration for TTS generation."""
    provider: TTSProvider = TTSProvider.BARK
    voice: Optional[VoiceProfile] = None
    voice_id: Optional[str] = None
    
    # Generation settings
    speed: float = 1.0
    pitch: float = 1.0
    
    # Output
    output_format: str = "wav"  # wav, mp3, ogg
    sample_rate: int = 24000


@dataclass
class TTSResult:
    """Result of TTS generation."""
    success: bool
    audio_url: Optional[str] = None
    audio_path: Optional[str] = None
    duration_seconds: float = 0.0
    transcript: str = ""
    error: Optional[str] = None


# =============================================================================
# FREE LLM PROVIDERS
# =============================================================================

class FreeLLMProvider(Enum):
    """Free LLM providers for script generation."""
    OLLAMA = "ollama"  # Local LLaMA/Mistral/etc
    LM_STUDIO = "lm_studio"  # Local
    GROQ = "groq"  # Free tier: 30 rpm
    PERPLEXITY = "perplexity"  # Free API limited
    GITHUB_MODELS = "github_models"  # Free tier
    MISTRAL = "mistral"  # Free tier
    HUGGINGFACE = "huggingface"  # Inference API free
    LEPTON = "lepton"  # Free LLM search


@dataclass
class LLMConfig:
    """Configuration for LLM calls."""
    provider: FreeLLMProvider = FreeLLMProvider.OLLAMA
    
    # Model selection
    model: str = "llama3.2:3b"  # Default for Ollama
    
    # Generation parameters
    temperature: float = 0.7
    max_tokens: int = 2048
    top_p: float = 0.9
    
    # API endpoint (for custom endpoints)
    api_url: Optional[str] = None
    api_key: Optional[str] = None


# =============================================================================
# FREE IMAGE GENERATION
# =============================================================================

class FreeImageProvider(Enum):
    """Free image generation providers."""
    STABILITY_AI = "stability_ai"  # Free tier: 100 credits
    HUGGINGFACE_DIFFUSERS = "huggingface_diffusers"  # Local Stable Diffusion
    PIXART = "pixart"  # Open source
    PLAYGROUND = "playground"  # Free tier: 500 images/month
    FAL_DREAMSHAPER = "fal_dreamshaper"  # Free tier
    CANDID = "candid"  # Free tier
    SHAKKER = "shakker"  # Free tier


# =============================================================================
# FREE VIDEO GENERATION
# =============================================================================

class FreeVideoProvider(Enum):
    """Free video generation providers."""
    MODEL_SCOPE = "model_scope"  # Qianwen/ Alibaba free tier
    CogVideoX = "cogvideox"  # THUDM open source
    Zeroscope = "zeroscope"  # Open source 30fps
    LaVie = "lavie"  # ByteDance open source
    LVD = "lvd"  # LiveVideoDiffusion


# =============================================================================
# FREE TOOL REGISTRY
# =============================================================================

@dataclass
class FreeTool:
    """A free/affordable tool entry."""
    name: str
    category: str  # tts, image, video, llm, music
    provider: str
    description: str
    
    # Access info
    is_local: bool = False
    requires_api_key: bool = False
    free_tier_limit: Optional[str] = None
    
    # Capabilities
    capabilities: List[str] = field(default_factory=list)
    
    # Setup info
    setup_url: Optional[str] = None
    install_command: Optional[str] = None
    
    # Quality/speed tradeoff
    quality: str = "medium"
    speed: str = "medium"
    cost: float = 0.0


class FreeToolRegistry:
    """
    Registry of free/affordable AI tools for Media Empire.
    
    Organized by category with setup instructions.
    """
    
    def __init__(self):
        self.logger = logging.getLogger("media.tools.free.registry")
        self._tools: Dict[str, FreeTool] = {}
        self._init_tools()
    
    def _init_tools(self):
        """Initialize free tool registry."""
        
        # === TTS / VOICE ===
        self._tools["coqui_xtts"] = FreeTool(
            name="Coqui XTTS",
            category="tts",
            provider="Coqui",
            description="Open-source voice cloning with 30+ languages",
            is_local=True,
            capabilities=["tts", "voice_cloning", "multi_language"],
            setup_url="https://docs.coqui.ai/",
            install_command="pip install TTS",
            quality="high",
            speed="medium",
        )
        
        self._tools["bark"] = FreeTool(
            name="Bark",
            category="tts",
            provider="Suno",
            description="Open-source text-to-audio with music generation",
            is_local=True,
            capabilities=["tts", "voice_cloning", "music_generation"],
            setup_url="https://github.com/suno-ai/bark",
            install_command="pip install bark",
            quality="medium",
            speed="medium",
        )
        
        self._tools["elevenlabs_free"] = FreeTool(
            name="ElevenLabs Free",
            category="tts",
            provider="ElevenLabs",
            description="10,000 characters free/month, 30+ voices",
            requires_api_key=True,
            free_tier_limit="10k chars/month",
            capabilities=["tts", "voice_cloning", "voice_styles"],
            setup_url="https://elevenlabs.io/",
            quality="high",
            speed="fast",
        )
        
        self._tools["mms_fairseq"] = FreeTool(
            name="MMS Fairseq",
            category="tts",
            provider="Meta/Facebook",
            description="Meta's Massively Multilingual Speech. 1000+ languages.",
            is_local=True,
            capabilities=["tts", "speech_recognition", "language_translation"],
            setup_url="https://github.com/facebookresearch/fairseq/tree/main/examples/mms",
            install_command="pip install fairseq",
            quality="medium",
            speed="slow",
        )
        
        # === FREE LLMs ===
        self._tools["ollama_llama"] = FreeTool(
            name="Ollama + LLaMA 3.2",
            category="llm",
            provider="Ollama",
            description="Local LLaMA 3.2 3B/8B/70B - runs entirely offline",
            is_local=True,
            capabilities=["script_generation", "summarization", "translation", "qa"],
            setup_url="https://ollama.ai/",
            install_command="brew install ollama && ollama pull llama3.2:3b",
            quality="high",
            speed="medium",
        )
        
        self._tools["ollama_mistral"] = FreeTool(
            name="Ollama + Mistral 7B",
            category="llm",
            provider="Ollama",
            description="Fast, efficient local LLM. Great for scripting.",
            is_local=True,
            capabilities=["script_generation", "reasoning", "coding"],
            setup_url="https://ollama.ai/",
            install_command="ollama pull mistral:7b",
            quality="high",
            speed="fast",
        )
        
        self._tools["groq_llama"] = FreeTool(
            name="Groq Free Tier",
            category="llm",
            provider="Groq",
            description="Fastest inference. 30 requests/min free. LLaMA 3.1 70B",
            requires_api_key=True,
            free_tier_limit="30 rpm",
            capabilities=["script_generation", "reasoning", "fast_inference"],
            setup_url="https://console.groq.com/",
            quality="high",
            speed="very_fast",
        )
        
        self._tools["github_models"] = FreeTool(
            name="GitHub Models",
            category="llm",
            provider="Microsoft/GitHub",
            description="Free tier: GPT-4o, Claude 3.5, LLaMA 3.1. 50 requests/day",
            requires_api_key=True,
            free_tier_limit="50 req/day",
            capabilities=["script_generation", "image_analysis", "reasoning"],
            setup_url="https://github.com/marketplace/models",
            quality="high",
            speed="fast",
        )
        
        self._tools["huggingface_inference"] = FreeTool(
            name="HuggingFace Inference API",
            category="llm",
            provider="HuggingFace",
            description="Free tier: 1000 inference hours/month. Many models.",
            requires_api_key=True,
            free_tier_limit="1000 hrs/month",
            capabilities=["script_generation", "text_to_speech", "image_gen"],
            setup_url="https://huggingface.co/inference-api",
            quality="medium",
            speed="medium",
        )
        
        # === FREE IMAGE ===
        self._tools["huggingface_diffusers"] = FreeTool(
            name="Diffusers (Local SDXL)",
            category="image",
            provider="HuggingFace",
            description="Run Stable Diffusion XL locally. Best quality free.",
            is_local=True,
            capabilities=["text_to_image", "image_to_image", "inpainting"],
            setup_url="https://huggingface.co/docs/diffusers/",
            install_command="pip install diffusers transformers accelerate",
            quality="high",
            speed="slow",
        )
        
        self._tools["playground_ai"] = FreeTool(
            name="Playground AI",
            category="image",
            provider="Playground",
            description="500 images/month free. SDXL, DALL-E 3 quality.",
            requires_api_key=True,
            free_tier_limit="500 images/month",
            capabilities=["text_to_image", "image_editing"],
            setup_url="https://playground.com/",
            quality="high",
            speed="fast",
        )
        
        self._tools["stability_free"] = FreeTool(
            name="Stability AI Free",
            category="image",
            provider="Stability AI",
            description="100 credits free. SDXL, video, 3D generation.",
            requires_api_key=True,
            free_tier_limit="100 credits",
            capabilities=["text_to_image", "video_generation", "3d_generation"],
            setup_url="https://stability.ai/",
            quality="high",
            speed="medium",
        )
        
        # === FREE VIDEO ===
        self._tools["cogvideox"] = FreeTool(
            name="CogVideoX",
            category="video",
            provider="THUDM",
            description="Open source video generation. 5-10 seconds. Requires GPU.",
            is_local=True,
            capabilities=["text_to_video", "image_to_video"],
            setup_url="https://github.com/THUDM/CogVideoX",
            install_command="pip install cogvideo-x",
            quality="medium",
            speed="slow",
        )
        
        self._tools["zeroscope"] = FreeTool(
            name="Zeroscope v2",
            category="video",
            provider="ByteDance/MagicAnimate",
            description="Open source 30fps video. 576x320 resolution.",
            is_local=True,
            capabilities=["text_to_video", "image_to_video", "30fps"],
            setup_url="https://huggingface.co/cerspense/zeroscope_v2_576w",
            install_command="pip install diffusers transformers",
            quality="medium",
            speed="medium",
        )
        
        self._tools["model_scope"] = FreeTool(
            name="ModelScope",
            category="video",
            provider="Alibaba/Damo",
            description="Free tier video generation. I2V, text-to-video.",
            requires_api_key=True,
            free_tier_limit="50 videos/month",
            capabilities=["text_to_video", "image_to_video"],
            setup_url="https://modelscope.cn/",
            quality="medium",
            speed="medium",
        )
        
        # === FREE MUSIC / SFX ===
        self._tools["suno_music"] = FreeTool(
            name="Suno (Free Tier)",
            category="music",
            provider="Suno",
            description="AI music generation. 50 credits free. Generate songs with lyrics.",
            requires_api_key=True,
            free_tier_limit="50 credits",
            capabilities=["music_generation", "song_generation", "voice_music"],
            setup_url="https://suno.ai/",
            quality="high",
            speed="medium",
        )
        
        self._tools["pixabay_music"] = FreeTool(
            name="Pixabay Music",
            category="music",
            provider="Pixabay",
            description="Royalty-free music and sound effects. 100% free.",
            is_local=False,
            free_tier_limit="Unlimited",
            capabilities=["background_music", "sound_effects"],
            setup_url="https://pixabay.com/music/",
            quality="high",
            speed="instant",
        )
        
        self._tools["freesound"] = FreeTool(
            name="Freesound",
            category="music",
            provider="Freesound.org",
            description="User-uploaded sound effects. 400k+ sounds. CC license.",
            is_local=False,
            free_tier_limit="Unlimited",
            capabilities=["sound_effects", "foley", "ambient"],
            setup_url="https://freesound.org/",
            quality="medium",
            speed="instant",
        )
        
        self.logger.info(f"Initialized {len(self._tools)} free/affordable tools")
    
    def get_tools_by_category(self, category: str) -> List[FreeTool]:
        """Get all tools in a category."""
        return [t for t in self._tools.values() if t.category == category]
    
    def get_best_tool(self, category: str, preference: str = "quality") -> Optional[FreeTool]:
        """Get the best tool for a category based on preference."""
        tools = self.get_tools_by_category(category)
        if not tools:
            return None
        
        if preference == "quality":
            return max(tools, key=lambda t: {"high": 3, "medium": 2, "low": 1}.get(t.quality, 1))
        elif preference == "speed":
            return max(tools, key=lambda t: {"very_fast": 4, "fast": 3, "medium": 2, "slow": 1}.get(t.speed, 1))
        elif preference == "cost":
            return min(tools, key=lambda t: t.cost)
        
        return tools[0]
    
    def list_all(self) -> List[FreeTool]:
        """List all tools."""
        return list(self._tools.values())
    
    def get_setup_guide(self, tool_name: str) -> Dict[str, Any]:
        """Get detailed setup guide for a tool."""
        tool = self._tools.get(tool_name)
        if not tool:
            return {"error": f"Tool {tool_name} not found"}
        
        return {
            "name": tool.name,
            "description": tool.description,
            "is_local": tool.is_local,
            "requires_api_key": tool.requires_api_key,
            "free_tier_limit": tool.free_tier_limit,
            "capabilities": tool.capabilities,
            "setup_url": tool.setup_url,
            "install_command": tool.install_command,
            "environment_variables": self._get_env_vars(tool_name),
        }
    
    def _get_env_vars(self, tool_name: str) -> List[str]:
        """Get required environment variables for a tool."""
        env_map = {
            "ollama_llama": ["OLLAMA_HOST=http://localhost:11434"],
            "ollama_mistral": ["OLLAMA_HOST=http://localhost:11434"],
            "groq_llama": ["GROQ_API_KEY=your_key"],
            "github_models": ["GITHUB_TOKEN=your_token"],
            "huggingface_inference": ["HF_TOKEN=your_token"],
            "elevenlabs_free": ["ELEVENLABS_API_KEY=your_key"],
            "playground_ai": ["PLAYGROUND_API_KEY=your_key"],
            "stability_free": ["STABILITY_API_KEY=your_key"],
            "model_scope": ["MODELSCOPE_TOKEN=your_token"],
            "suno_music": ["SUNO_API_KEY=your_key"],
        }
        return env_map.get(tool_name, [])


# Global registry
_free_registry: Optional[FreeToolRegistry] = None


def get_free_registry() -> FreeToolRegistry:
    """Get global free tool registry."""
    global _free_registry
    if _free_registry is None:
        _free_registry = FreeToolRegistry()
    return _free_registry
