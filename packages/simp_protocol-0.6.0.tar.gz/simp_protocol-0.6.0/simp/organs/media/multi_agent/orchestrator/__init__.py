"""
Multi-Agent Orchestrator for Media Empire.

Coordinates HiveMind with workflow engine and autonomous empire operations.
"""
from simp.organs.media.multi_agent.orchestrator.content_orchestrator import (
    ContentOrchestrator,
    TaskRequest,
    TaskResult,
    TaskStatus,
    create_content_orchestrator
)
from simp.organs.media.multi_agent.orchestrator.agent_supervisor import (
    AgentSupervisor,
    SupervisorConfig,
    create_supervisor
)

__version__ = "0.1.0"
__all__ = [
    "ContentOrchestrator",
    "TaskRequest",
    "TaskResult",
    "TaskStatus",
    "create_content_orchestrator",
    "AgentSupervisor",
    "SupervisorConfig",
    "create_supervisor"
]
