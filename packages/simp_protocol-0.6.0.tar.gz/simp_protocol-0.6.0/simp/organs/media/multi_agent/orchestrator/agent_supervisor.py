"""
Agent Supervisor - Monitors and manages specialist agents.

Ensures agents are healthy, balanced, and following strategies.
"""
import asyncio
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging

from simp.organs.media.multi_agent.hive_mind import HiveMind, HiveState
from simp.organs.media.multi_agent.base_specialist import AgentState


class HealthStatus(Enum):
    """Health status of an agent."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    OFFLINE = "offline"


class ScalingAction(Enum):
    """Actions for load balancing."""
    SCALE_UP = "scale_up"
    SCALE_DOWN = "scale_down"
    REDISTRIBUTE = "redistribute"
    NONE = "none"


@dataclass
class AgentHealth:
    """Health metrics for an agent."""
    agent_id: str
    agent_name: str
    
    # Health indicators
    status: HealthStatus = HealthStatus.HEALTHY
    
    # Performance
    tasks_completed: int = 0
    tasks_failed: int = 0
    avg_task_duration: float = 0.0
    success_rate: float = 1.0
    
    # Load
    queue_depth: int = 0
    active_tasks: int = 0
    
    # Timing
    last_heartbeat: datetime = field(default_factory=datetime.now)
    last_task_at: Optional[datetime] = None
    
    # Issues
    error_count_24h: int = 0
    recent_errors: List[str] = field(default_factory=list)


@dataclass
class SupervisorConfig:
    """Configuration for agent supervision."""
    # Health thresholds
    max_queue_depth: int = 50
    min_success_rate: float = 0.8
    
    # Heartbeat
    heartbeat_interval_seconds: int = 30
    heartbeat_timeout_seconds: int = 120
    
    # Scaling
    auto_scale: bool = True
    target_tasks_per_agent: int = 10
    scale_up_threshold: float = 0.8
    scale_down_threshold: float = 0.3
    
    # Recovery
    auto_restart: bool = True
    max_restart_attempts: int = 3
    restart_cooldown_seconds: int = 300


class AgentSupervisor:
    """Agent Supervisor - Monitors and manages the HiveMind agents."""
    
    def __init__(
        self,
        hive_mind: Optional[HiveMind] = None,
        config: Optional[SupervisorConfig] = None,
        data_dir: str = "data/media/supervisor"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.agent_supervisor")
        
        self.hive_mind = hive_mind
        self.config = config or SupervisorConfig()
        
        self._agent_health: Dict[str, AgentHealth] = {}
        self._monitoring: bool = False
        self._monitor_task: Optional[asyncio.Task] = None
        
        self.metrics = {
            "total_restarts": 0,
            "total_scale_actions": 0,
            "total_failovers": 0,
        }
    
    async def start(self) -> bool:
        """Start the supervisor."""
        if self._monitoring:
            return True
        
        self.logger.info("Starting Agent Supervisor...")
        
        if self.hive_mind:
            for agent_id, agent in self.hive_mind.agents.items():
                self._agent_health[agent_id] = AgentHealth(
                    agent_id=agent_id,
                    agent_name=agent.agent_name
                )
        
        self._monitoring = True
        self._monitor_task = asyncio.create_task(self._monitoring_loop())
        
        self.logger.info("Agent Supervisor started")
        return True
    
    async def stop(self) -> bool:
        """Stop the supervisor."""
        self._monitoring = False
        if self._monitor_task:
            self._monitor_task.cancel()
        self.logger.info("Agent Supervisor stopped")
        return True
    
    async def check_agent_health(self, agent_id: str) -> AgentHealth:
        """Check health of a specific agent."""
        health = self._agent_health.get(agent_id, AgentHealth(
            agent_id=agent_id,
            agent_name=agent_id
        ))
        
        if not self.hive_mind or agent_id not in self.hive_mind.agents:
            health.status = HealthStatus.OFFLINE
            return health
        
        agent = self.hive_mind.agents[agent_id]
        
        if agent.state == AgentState.ERROR:
            health.status = HealthStatus.UNHEALTHY
        elif agent.state == AgentState.IDLE:
            health.status = HealthStatus.HEALTHY
        
        # Check heartbeat timeout
        time_since_heartbeat = (datetime.now() - health.last_heartbeat).total_seconds()
        if time_since_heartbeat > self.config.heartbeat_timeout_seconds:
            health.status = HealthStatus.UNHEALTHY
        
        # Calculate success rate
        total = health.tasks_completed + health.tasks_failed
        if total > 0:
            health.success_rate = health.tasks_completed / total
        
        return health
    
    async def _monitoring_loop(self) -> None:
        """Main monitoring loop."""
        while self._monitoring:
            try:
                await self.check_all_agents()
                
                for agent_id, health in self._agent_health.items():
                    if health.status != HealthStatus.HEALTHY:
                        self.logger.warning(
                            f"Agent {agent_id} is {health.status.value}: "
                            f"success_rate={health.success_rate:.2f}"
                        )
                
                if self.config.auto_scale:
                    await self._check_scaling()
                
            except Exception as e:
                self.logger.error(f"Monitoring loop error: {e}")
            
            await asyncio.sleep(self.config.heartbeat_interval_seconds)
    
    async def check_all_agents(self) -> Dict[str, AgentHealth]:
        """Check health of all agents."""
        if not self.hive_mind:
            return {}
        
        for agent_id in self.hive_mind.agents:
            await self.check_agent_health(agent_id)
        
        return self._agent_health
    
    async def _check_scaling(self) -> None:
        """Check if scaling actions are needed."""
        if not self.hive_mind:
            return
        
        total_queue = sum(h.queue_depth for h in self._agent_health.values())
        avg_load = total_queue / max(len(self._agent_health), 1)
        
        target = self.config.target_tasks_per_agent
        
        if avg_load > target * self.config.scale_up_threshold:
            self.logger.info(f"Scale up triggered: avg_load={avg_load:.1f}")
            self.metrics["total_scale_actions"] += 1
        
        elif avg_load < target * self.config.scale_down_threshold:
            self.logger.info(f"Scale down triggered: avg_load={avg_load:.1f}")
            self.metrics["total_scale_actions"] += 1
    
    def get_load_balance_report(self) -> Dict[str, Any]:
        """Get load balance report across agents."""
        if not self.hive_mind:
            return {}
        
        return {
            "total_agents": len(self.hive_mind.agents),
            "healthy_agents": sum(1 for h in self._agent_health.values() if h.status == HealthStatus.HEALTHY),
            "agents": {
                agent_id: {
                    "status": health.status.value,
                    "queue_depth": health.queue_depth,
                    "success_rate": health.success_rate,
                }
                for agent_id, health in self._agent_health.items()
            }
        }
    
    def get_health_report(self) -> Dict[str, Any]:
        """Get overall health report."""
        total = len(self._agent_health)
        healthy = sum(1 for h in self._agent_health.values() if h.status == HealthStatus.HEALTHY)
        
        return {
            "total_agents": total,
            "healthy": healthy,
            "health_score": healthy / max(total, 1),
            "metrics": self.metrics
        }


def create_supervisor(
    hive_mind: Optional[HiveMind] = None,
    config: Optional[SupervisorConfig] = None,
    data_dir: str = "data/media/supervisor"
) -> AgentSupervisor:
    """Factory function to create agent supervisor."""
    return AgentSupervisor(hive_mind=hive_mind, config=config, data_dir=data_dir)
