"""
Content Orchestrator - Coordinates HiveMind for Content Generation.

Manages the flow of content generation tasks through specialist agents:
- Interprets Brain intents
- Assigns tasks to appropriate agents
- Coordinates multi-agent content creation
- Handles failures and retries
- Monitors quality
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

from simp.organs.media.multi_agent.hive_mind import HiveMind, HiveState
from simp.organs.media.multi_agent.base_specialist import AgentState


class TaskStatus(Enum):
    """Status of a content task."""
    PENDING = "pending"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(Enum):
    """Priority levels for tasks."""
    LOW = 0
    NORMAL = 1
    HIGH = 2
    URGENT = 3


@dataclass
class TaskRequest:
    """A content generation task request."""
    task_id: str
    task_type: str  # "script", "idea", "asset", "full_content"
    
    # Content details
    niche: str
    topic: str
    content_type: str  # "short_video", "long_video", "post", etc.
    duration_seconds: int = 60
    platforms: List[str] = field(default_factory=list)
    
    # Brand context
    brand_voice: str = ""
    brand_guidelines: Dict[str, Any] = field(default_factory=dict)
    
    # Constraints
    constraints: Dict[str, Any] = field(default_factory=dict)  # ToS, style, etc.
    
    # Priority & deadline
    priority: TaskPriority = TaskPriority.NORMAL
    deadline: Optional[datetime] = None
    
    # Metadata
    channel_id: str = ""
    campaign_id: str = ""
    source: str = "manual"  # "manual", "scheduled", "trend", "brain"
    
    created_at: datetime = field(default_factory=datetime.now)
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent: Optional[str] = None


@dataclass
class TaskResult:
    """Result of a completed task."""
    task_id: str
    status: TaskStatus
    
    # Generated content
    content: Dict[str, Any] = field(default_factory=dict)
    quality_score: float = 0.0
    
    # Agent info
    agent_id: Optional[str] = None
    agent_name: Optional[str] = None
    
    # Timing
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_seconds: float = 0.0
    
    # Error info
    error: Optional[str] = None
    retry_count: int = 0
    
    # Follow-up tasks
    sub_tasks: List[str] = field(default_factory=list)


@dataclass
class ContentPipeline:
    """A content generation pipeline (multi-step)."""
    pipeline_id: str
    name: str
    
    # Steps
    steps: List[str] = field(default_factory=list)  # Task IDs
    
    # Current state
    current_step: int = 0
    completed_steps: List[str] = field(default_factory=list)
    failed_steps: List[str] = field(default_factory=list)
    
    # Results
    results: Dict[str, TaskResult] = field(default_factory=dict)
    
    status: TaskStatus = TaskStatus.PENDING


class ContentOrchestrator:
    """
    Orchestrates content generation through HiveMind.
    
    Coordinates:
    - Task assignment to specialist agents
    - Pipeline execution (multi-step content creation)
    - Quality monitoring
    - Failure recovery
    - Progress tracking
    """
    
    def __init__(
        self,
        hive_mind: Optional[HiveMind] = None,
        data_dir: str = "data/media/orchestrator"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.content_orchestrator")
        
        # HiveMind integration
        self.hive_mind = hive_mind
        
        # Task management
        self._tasks: Dict[str, TaskRequest] = {}
        self._results: Dict[str, TaskResult] = {}
        self._pipelines: Dict[str, ContentPipeline] = {}
        
        # Agent routing
        self._agent_routing: Dict[str, str] = {
            "tiktok": "tiktok_agent",
            "youtube": "youtube_agent",
            "instagram": "instagram_agent",
            "x": "x_agent",
            "linkedin": "linkedin_agent"
        }
        
        # Callbacks
        self._on_task_complete: Optional[Callable] = None
        self._on_pipeline_complete: Optional[Callable] = None
        
        # Stats
        self.metrics = {
            "tasks_submitted": 0,
            "tasks_completed": 0,
            "tasks_failed": 0,
            "pipelines_completed": 0,
            "avg_quality_score": 0.0
        }
        
        self._load_state()
    
    def _load_state(self) -> None:
        """Load pending tasks from disk."""
        tasks_file = self.data_dir / "pending_tasks.json"
        if tasks_file.exists():
            with open(tasks_file) as f:
                data = json.load(f)
                for task_data in data.values():
                    task_data["created_at"] = datetime.fromisoformat(task_data["created_at"])
                    if task_data.get("deadline"):
                        task_data["deadline"] = datetime.fromisoformat(task_data["deadline"])
                    self._tasks[task_data["task_id"]] = TaskRequest(**task_data)
    
    def _save_state(self) -> None:
        """Save pending tasks to disk."""
        tasks_data = {
            tid: {
                **vars(task),
                "created_at": task.created_at.isoformat(),
                "deadline": task.deadline.isoformat() if task.deadline else None
            }
            for tid, task in self._tasks.items()
            if task.status == TaskStatus.PENDING
        }
        
        with open(self.data_dir / "pending_tasks.json", "w") as f:
            json.dump(tasks_data, f, indent=2)
    
    # =========================================================================
    # HiveMind Integration
    # =========================================================================
    
    async def set_hive_mind(self, hive_mind: HiveMind) -> None:
        """Set or update the HiveMind instance."""
        self.hive_mind = hive_mind
    
    async def start(self) -> bool:
        """Start the orchestrator."""
        if self.hive_mind and not self.hive_mind.is_running:
            await self.hive_mind.start()
        
        self.logger.info("Content orchestrator started")
        return True
    
    async def stop(self) -> bool:
        """Stop the orchestrator."""
        self._save_state()
        self.logger.info("Content orchestrator stopped")
        return True
    
    # =========================================================================
    # Task Submission
    # =========================================================================
    
    async def submit_task(
        self,
        task_type: str,
        niche: str,
        topic: str,
        content_type: str,
        platforms: List[str],
        **kwargs
    ) -> str:
        """Submit a new content generation task."""
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        
        task = TaskRequest(
            task_id=task_id,
            task_type=task_type,
            niche=niche,
            topic=topic,
            content_type=content_type,
            platforms=platforms,
            **kwargs
        )
        
        self._tasks[task_id] = task
        self._tasks[task_id] = task
        self.metrics["tasks_submitted"] += 1
        
        self.logger.info(f"Submitted task: {task_id} ({task_type})")
        
        # Process immediately if high priority
        if task.priority == TaskPriority.URGENT:
            asyncio.create_task(self.process_task(task_id))
        
        return task_id
    
    async def submit_pipeline(
        self,
        name: str,
        steps: List[Dict[str, Any]]
    ) -> str:
        """
        Submit a multi-step content pipeline.
        
        Example steps:
        [
            {"type": "idea_generation", "params": {...}},
            {"type": "script_writing", "params": {...}},
            {"type": "asset_generation", "params": {...}},
            {"type": "editing", "params": {...}}
        ]
        """
        pipeline_id = f"pipeline_{uuid.uuid4().hex[:8]}"
        
        # Create tasks for each step
        step_ids = []
        for i, step in enumerate(steps):
            task_id = await self.submit_task(
                task_type=step["type"],
                niche=step.get("niche", ""),
                topic=step.get("topic", ""),
                content_type=step.get("content_type", ""),
                platforms=step.get("platforms", []),
                priority=TaskPriority.HIGH if i == 0 else TaskPriority.NORMAL
            )
            step_ids.append(task_id)
        
        pipeline = ContentPipeline(
            pipeline_id=pipeline_id,
            name=name,
            steps=step_ids
        )
        
        self._pipelines[pipeline_id] = pipeline
        self.logger.info(f"Submitted pipeline: {pipeline_id} with {len(steps)} steps")
        
        return pipeline_id
    
    # =========================================================================
    # Task Processing
    # =========================================================================
    
    async def process_task(self, task_id: str) -> TaskResult:
        """Process a content generation task."""
        task = self._tasks.get(task_id)
        if not task:
            return TaskResult(task_id=task_id, status=TaskStatus.FAILED, error="Task not found")
        
        if task.status != TaskStatus.PENDING:
            return TaskResult(task_id=task_id, status=task.status)
        
        # Assign to agent
        task.status = TaskStatus.ASSIGNED
        
        # Find appropriate agent
        agent_id = self._route_to_agent(task)
        task.assigned_agent = agent_id
        
        if not self.hive_mind or not self.hive_mind.agents.get(agent_id):
            # Fallback: process without HiveMind
            return await self._process_without_hive_mind(task)
        
        agent = self.hive_mind.agents[agent_id]
        task.status = TaskStatus.IN_PROGRESS
        
        result = TaskResult(
            task_id=task_id,
            status=TaskStatus.IN_PROGRESS,
            started_at=datetime.now(),
            agent_id=agent_id,
            agent_name=agent.agent_name
        )
        
        try:
            # Process through agent
            content = await agent.generate_content(
                brief=task.__dict__,
                task_type=task.task_type
            )
            
            result.content = content
            result.status = TaskStatus.COMPLETED
            result.completed_at = datetime.now()
            result.quality_score = content.get("quality_score", 0.8)
            
            self.metrics["tasks_completed"] += 1
            self.logger.info(f"Task completed: {task_id} by {agent_id}")
            
        except Exception as e:
            result.status = TaskStatus.FAILED
            result.error = str(e)
            result.completed_at = datetime.now()
            self.metrics["tasks_failed"] += 1
            self.logger.error(f"Task failed: {task_id} - {e}")
        
        finally:
            result.duration_seconds = (result.completed_at - result.started_at).total_seconds()
            self._results[task_id] = result
            task.status = result.status
        
        # Trigger callback
        if self._on_task_complete:
            await self._on_task_complete(task, result)
        
        return result
    
    def _route_to_agent(self, task: TaskRequest) -> str:
        """Route task to appropriate agent based on platform/content type."""
        # Primary platform routing
        if task.platforms:
            primary = task.platforms[0]
            if primary in self._agent_routing:
                return self._agent_routing[primary]
        
        # Content type routing
        if task.task_type == "idea":
            return "content_ideation_agent"
        elif task.task_type == "script":
            return "script_writer_agent"
        elif task.task_type == "asset":
            return "asset_generator_agent"
        
        return "general_agent"
    
    async def _process_without_hive_mind(self, task: TaskRequest) -> TaskResult:
        """Process task without HiveMind (fallback mode)."""
        self.logger.warning(f"Processing task without HiveMind: {task.task_id}")
        
        result = TaskResult(
            task_id=task.task_id,
            status=TaskStatus.IN_PROGRESS,
            started_at=datetime.now()
        )
        
        # Generate placeholder content
        result.content = {
            "title": f"Generated: {task.topic}",
            "description": f"Content for {task.niche}",
            "caption": f"Check out this {task.content_type}!",
            "quality_score": 0.7,
            "platform": task.platforms[0] if task.platforms else "generic"
        }
        
        result.status = TaskStatus.COMPLETED
        result.completed_at = datetime.now()
        result.duration_seconds = 0.1
        
        self.metrics["tasks_completed"] += 1
        return result
    
    # =========================================================================
    # Pipeline Processing
    # =========================================================================
    
    async def process_pipeline(self, pipeline_id: str) -> Dict[str, TaskResult]:
        """Process a multi-step content pipeline."""
        pipeline = self._pipelines.get(pipeline_id)
        if not pipeline:
            return {}
        
        self.logger.info(f"Processing pipeline: {pipeline_id}")
        
        for i, step_id in enumerate(pipeline.steps):
            pipeline.current_step = i
            
            result = await self.process_task(step_id)
            pipeline.results[step_id] = result
            
            if result.status == TaskStatus.COMPLETED:
                pipeline.completed_steps.append(step_id)
            else:
                pipeline.failed_steps.append(step_id)
                
                # Stop on failure
                if pipeline.completed_steps:
                    pipeline.status = TaskStatus.FAILED
                    break
            
            # Pass output to next step
            if result.status == TaskStatus.COMPLETED and i < len(pipeline.steps) - 1:
                next_task_id = pipeline.steps[i + 1]
                next_task = self._tasks.get(next_task_id)
                if next_task and result.content:
                    # Inject previous output as context
                    next_task.constraints["previous_output"] = result.content
        
        if not pipeline.failed_steps:
            pipeline.status = TaskStatus.COMPLETED
            self.metrics["pipelines_completed"] += 1
        
        # Trigger callback
        if self._on_pipeline_complete:
            await self._on_pipeline_complete(pipeline)
        
        return pipeline.results
    
    # =========================================================================
    # Status & Monitoring
    # =========================================================================
    
    def get_task_status(self, task_id: str) -> Optional[TaskResult]:
        """Get status of a task."""
        return self._results.get(task_id)
    
    def get_pending_tasks(
        self,
        priority: Optional[TaskPriority] = None,
        platform: Optional[str] = None
    ) -> List[TaskRequest]:
        """Get pending tasks."""
        tasks = [t for t in self._tasks.values() if t.status == TaskStatus.PENDING]
        
        if priority:
            tasks = [t for t in tasks if t.priority == priority]
        if platform:
            tasks = [t for t in tasks if platform in t.platforms]
        
        return sorted(tasks, key=lambda t: (t.priority.value, t.created_at))
    
    def get_pipeline_status(self, pipeline_id: str) -> Optional[ContentPipeline]:
        """Get status of a pipeline."""
        return self._pipelines.get(pipeline_id)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get orchestrator metrics."""
        return {
            **self.metrics,
            "pending_tasks": len([t for t in self._tasks.values() if t.status == TaskStatus.PENDING]),
            "active_tasks": len([t for t in self._tasks.values() if t.status == TaskStatus.IN_PROGRESS]),
            "active_pipelines": len([p for p in self._pipelines.values() if p.status == TaskStatus.IN_PROGRESS]),
            "hive_mind_status": self.hive_mind.state.value if self.hive_mind else "not_connected"
        }
    
    # =========================================================================
    # Callbacks
    # =========================================================================
    
    def on_task_complete(self, callback: Callable) -> None:
        """Register callback for task completion."""
        self._on_task_complete = callback
    
    def on_pipeline_complete(self, callback: Callable) -> None:
        """Register callback for pipeline completion."""
        self._on_pipeline_complete = callback


def create_content_orchestrator(
    hive_mind: Optional[HiveMind] = None,
    data_dir: str = "data/media/orchestrator"
) -> ContentOrchestrator:
    """Factory function to create content orchestrator."""
    return ContentOrchestrator(hive_mind=hive_mind, data_dir=data_dir)
