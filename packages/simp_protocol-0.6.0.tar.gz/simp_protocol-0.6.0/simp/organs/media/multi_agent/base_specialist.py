"""
Base Specialist Agent for Multi-Agent Hive Mind.

Each platform has a specialized agent that learns platform-specific optimizations.
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging


class AgentState(Enum):
    """Agent operational state."""
    IDLE = "idle"
    WORKING = "working"
    LEARNING = "learning"
    WAITING = "waiting"
    ERROR = "error"


class LearningType(Enum):
    """Types of learnings an agent can share."""
    HOOK_PATTERN = "hook_pattern"
    POSTING_TIME = "posting_time"
    CONTENT_FORMAT = "content_format"
    HASHTAG_STRATEGY = "hashtag_strategy"
    ENGAGEMENT_TECHNIQUE = "engagement_technique"
    TREND_RESPONSE = "trend_response"
    AUDIENCE_INSIGHT = "audience_insight"


@dataclass
class Learning:
    """A learning instance from an agent."""
    learning_id: str
    agent_id: str
    learning_type: LearningType
    content: Dict[str, Any]
    confidence: float  # 0-1
    evidence: List[Dict] = field(default_factory=list)  # Supporting data points
    success_count: int = 0
    failure_count: int = 0
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    last_verified: Optional[str] = None
    expires_at: Optional[str] = None


@dataclass
class AgentInsight:
    """An insight or recommendation from an agent."""
    insight_id: str
    agent_id: str
    insight_type: str
    recommendation: str
    reasoning: str
    supporting_learnings: List[str] = field(default_factory=list)
    confidence: float = 0.0
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class StrategyUpdate:
    """A strategy update from the hive mind."""
    update_id: str
    source_agents: List[str]
    strategy_type: str
    changes: Dict[str, Any]
    priority: int = 0
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class BaseSpecialistAgent:
    """
    Base class for platform-specific specialist agents.
    
    Each specialist:
    - Masters its platform's algorithm and best practices
    - Generates content optimized for its platform
    - Shares learnings with the hive mind
    - Receives strategy updates from other agents
    - Tracks performance and iteratively improves
    """
    
    def __init__(
        self,
        agent_id: str,
        platform: str,
        data_dir: str = "data/media/agents"
    ):
        self.agent_id = agent_id
        self.platform = platform
        
        self.data_dir = Path(data_dir) / platform
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger(f"media.agent.{platform}.{agent_id}")
        
        # State
        self.state = AgentState.IDLE
        self.is_active = False
        
        # Learnings cache
        self._learnings: List[Learning] = []
        self._load_learnings()
        
        # Insights
        self._insights: List[AgentInsight] = []
        
        # Performance metrics
        self.metrics = {
            "posts_generated": 0,
            "posts_published": 0,
            "total_views": 0,
            "total_engagement": 0,
            "learnings_shared": 0,
            "insights_generated": 0,
            "strategy_updates_received": 0
        }
        
        # Message queue for inter-agent communication
        self._inbox: asyncio.Queue = asyncio.Queue()
        self._outbox: Dict[str, asyncio.Queue] = {}
        
        # Callbacks for hive mind integration
        self._on_learning_ready: Optional[Callable] = None
        self._on_insight_ready: Optional[Callable] = None
        self._on_strategy_update: Optional[Callable] = None
        
        # Platform-specific configuration
        self.platform_config = self._get_platform_config()
    
    def _get_platform_config(self) -> Dict:
        """Get platform-specific configuration."""
        configs = {
            "tiktok": {
                "max_duration": 180,
                "aspect_ratio": "9:16",
                "ideal_length": 15,
                "best_posting_hours": [6, 9, 12, 17, 20, 21],
                "algorithm_factors": ["completion_rate", "shares", "comments", "likes"],
                "hook_window_seconds": 3,
                "trending_audio_importance": 0.9
            },
            "youtube": {
                "max_duration": 600,
                "aspect_ratio": "16:9",
                "ideal_length": 480,
                "best_posting_hours": [14, 15, 16, 17],
                "algorithm_factors": ["watch_time", "ctr", "likes", "comments", "subscribes"],
                "hook_window_seconds": 30,
                "thumbnail_importance": 0.95
            },
            "instagram": {
                "max_duration": 90,
                "aspect_ratio": "1:1",
                "ideal_length": 30,
                "best_posting_hours": [9, 11, 14, 17, 20],
                "algorithm_factors": ["likes", "comments", "saves", "shares", "follows"],
                "hook_window_seconds": 5,
                "reels_priority": True
            },
            "x": {
                "max_duration": 280,
                "aspect_ratio": "16:9",
                "ideal_length": 100,
                "best_posting_hours": [8, 9, 12, 17, 20],
                "algorithm_factors": ["engagement_rate", "impressions", "link_clicks", "replies"],
                "hook_window_seconds": 2,
                "thread_importance": 0.8
            },
            "linkedin": {
                "max_duration": 600,
                "aspect_ratio": "1.91:1",
                "ideal_length": 300,
                "best_posting_hours": [7, 8, 12, 17],
                "algorithm_factors": ["comments", "shares", "connections", "profile_visits"],
                "hook_window_seconds": 10,
                "professional_tone_priority": 0.95
            }
        }
        return configs.get(self.platform, configs["x"])
    
    # =========================================================================
    # Lifecycle
    # =========================================================================
    
    async def start(self) -> bool:
        """Start the agent."""
        if self.is_active:
            return True
        
        self.is_active = True
        self.state = AgentState.IDLE
        self.logger.info(f"Agent {self.agent_id} started for {self.platform}")
        
        # Start message processing loop
        asyncio.create_task(self._process_messages())
        
        return True
    
    async def stop(self) -> bool:
        """Stop the agent."""
        self.is_active = False
        self.state = AgentState.IDLE
        self.logger.info(f"Agent {self.agent_id} stopped")
        return True
    
    # =========================================================================
    # Core Operations
    # =========================================================================
    
    async def generate_content(self, brief: Dict) -> Dict[str, Any]:
        """
        Generate content optimized for this platform.
        
        Args:
            brief: Content brief with title, angle, target audience, etc.
            
        Returns:
            Generated content package
        """
        self.state = AgentState.WORKING
        start_time = time.time()
        
        try:
            content = {
                "content_id": f"content_{self.platform}_{uuid.uuid4().hex[:8]}",
                "platform": self.platform,
                "agent_id": self.agent_id,
                "brief": brief,
                
                # Platform-optimized elements
                "hook": self._generate_hook(brief),
                "script": self._generate_script(brief),
                "caption": self._generate_caption(brief),
                "hashtags": self._generate_hashtags(brief),
                "posting_time": self._get_optimal_posting_time(),
                
                # Metadata
                "generated_at": datetime.utcnow().isoformat(),
                "platform_config": self.platform_config,
                "strategy_tags": self._get_applied_strategies()
            }
            
            self.metrics["posts_generated"] += 1
            
            self.state = AgentState.IDLE
            return content
            
        except Exception as e:
            self.state = AgentState.ERROR
            self.logger.error(f"Content generation failed: {e}")
            raise
    
    def _generate_hook(self, brief: Dict) -> str:
        """Generate platform-optimized hook."""
        hooks = [
            f"Here's what nobody tells you about {brief.get('topic', 'success')}",
            f"This changed everything about {brief.get('topic', 'productivity')}",
            f"The truth about {brief.get('topic', 'AI tools')} nobody talks about",
            f"I tested this {brief.get('topic', 'strategy')} for 30 days - here's what happened",
            f"Why {brief.get('topic', 'business')} is about to shift dramatically"
        ]
        return hooks[int(time.time()) % len(hooks)]
    
    def _generate_script(self, brief: Dict) -> str:
        """Generate platform-optimized script."""
        topic = brief.get("topic", "this topic")
        
        # Platform-specific structure
        if self.platform == "tiktok":
            return f"""Hook: (0-3s) {brief.get('hook', 'Start with impact')}
Story: (3-60s) Share the insight
Payoff: (60-90s) Call to action

Script: Today I'm going to show you the one thing about {topic} that changed everything for me. Most people get this completely wrong, but once you understand it, everything starts to make sense.

Key points:
1. Start with why it matters
2. Give the counter-intuitive insight  
3. Show proof/personal experience
4. End with actionable takeaway

CTA: Follow for more insights like this."""
        
        elif self.platform == "youtube":
            return f"""Intro: {brief.get('hook', 'Compelling hook')} (30s)
Body: Deep dive into {topic} (5-10 min)
Conclusion: Summary + CTA (30s)

Script structure:
- Problem statement (1-2 min)
- The insight (3-5 min)
- Implementation steps (2-3 min)
- Results expectation (1 min)
- Call to subscribe"""

        else:
            return f"""Topic: {topic}

Key message: {brief.get('main_takeaway', 'Share your unique perspective')}
Supporting points: {brief.get('sub_points', ['Point 1', 'Point 2', 'Point 3'])}
Call to action: {brief.get('cta', 'Share your thoughts below')}

Format: Keep it engaging and platform-native"""

    def _generate_caption(self, brief: Dict) -> str:
        """Generate social media caption."""
        topic = brief.get("topic", "insights")
        
        if self.platform == "tiktok":
            return f"I've been studying {topic} for years and here's what I found...\n\nSwipe to see what most people miss.\n\n#fyp #viral #{topic.replace(' ', '')}"
        
        elif self.platform == "youtube":
            return f"{brief.get('title', 'Deep dive on ' + topic)}\n\nIn this video, we cover:\n• Key insight about {topic}\n• Implementation steps\n• Expected results\n\nLinks in description."
        
        elif self.platform == "x":
            return f"Hot take on {topic}: {'/'.join(brief.get('hot_takes', ['Most people get this wrong']))}\n\nThin thread 🧵"
        
        elif self.platform == "linkedin":
            return f"I recently discovered something interesting about {topic} that I think the industry needs to pay more attention to.\n\nAfter analyzing the data, here's what I found:\n\n[Key insight]\n\nI'd love to hear your thoughts. Have you experienced something similar?"
        
        else:
            return f"{brief.get('summary', 'Check out this insight about ' + topic)}"

    def _generate_hashtags(self, brief: Dict) -> List[str]:
        """Generate platform-optimized hashtags."""
        base_hashtags = {
            "tiktok": ["#fyp", "#foryoupage", "#viral", "#trending", "#ai"],
            "youtube": ["#shorts", "#tech", "#education", "#tips"],
            "instagram": ["#reels", "#explore", "#viral", "#trending"],
            "x": ["#AI", "#Tech", "#Innovation"],
            "linkedin": ["#AI", "#Leadership", "#Innovation"]
        }
        
        topic = brief.get("topic", "").replace(" ", "")
        
        return base_hashtags.get(self.platform, []) + [f"#{topic}"] if topic else base_hashtags.get(self.platform, [])
    
    def _get_optimal_posting_time(self) -> Dict:
        """Get optimal posting time based on learnings."""
        # Use accumulated learnings or fallback to config
        best_hours = self.platform_config.get("best_posting_hours", [12])
        
        return {
            "hour_utc": best_hours[int(time.time()) % len(best_hours)],
            "confidence": 0.7,
            "based_on": "platform_config"
        }
    
    def _get_applied_strategies(self) -> List[str]:
        """Get list of strategies applied to this content."""
        strategies = []
        
        # Check recent learnings
        for learning in self._learnings[-5:]:
            if learning.learning_type == LearningType.HOOK_PATTERN:
                strategies.append(f"hook_{learning.confidence:.0%}")
            elif learning.learning_type == LearningType.POSTING_TIME:
                strategies.append(f"timing_{learning.confidence:.0%}")
        
        return strategies if strategies else ["default_strategy"]
    
    # =========================================================================
    # Learning System
    # =========================================================================
    
    async def learn_from_result(self, content_id: str, result: Dict) -> None:
        """
        Learn from content performance results.
        
        Args:
            content_id: ID of the content
            result: Performance metrics (views, engagement, conversions)
        """
        self.state = AgentState.LEARNING
        
        try:
            views = result.get("views", 0)
            engagement = result.get("engagement", 0)
            conversions = result.get("conversions", 0)
            
            # Calculate success score
            success_score = self._calculate_success_score(result)
            
            # Generate learnings from this result
            if success_score > 0.7:
                await self._record_positive_learning(content_id, result, success_score)
            elif success_score < 0.3:
                await self._record_negative_learning(content_id, result, success_score)
            
            # Generate insight if significant
            if success_score > 0.9:
                await self._generate_insight_from_result(content_id, result, success_score)
            
            self.state = AgentState.IDLE
            
        except Exception as e:
            self.logger.error(f"Learning from result failed: {e}")
            self.state = AgentState.ERROR
    
    def _calculate_success_score(self, result: Dict) -> float:
        """Calculate content success score."""
        # Platform-specific metrics
        weights = {
            "tiktok": {"views": 0.3, "completion_rate": 0.4, "shares": 0.2, "comments": 0.1},
            "youtube": {"views": 0.2, "watch_time": 0.3, "ctr": 0.3, "subscribes": 0.2},
            "instagram": {"views": 0.2, "likes": 0.3, "saves": 0.3, "comments": 0.2},
            "x": {"views": 0.2, "engagement_rate": 0.4, "link_clicks": 0.2, "replies": 0.2},
            "linkedin": {"views": 0.2, "comments": 0.4, "shares": 0.3, "profile_visits": 0.1}
        }
        
        platform_weights = weights.get(self.platform, weights["x"])
        
        score = 0
        total_weight = 0
        for metric, weight in platform_weights.items():
            value = result.get(metric, 0)
            score += min(value / 1000, 1.0) * weight  # Normalize to 0-1
            total_weight += weight
        
        return score / total_weight if total_weight > 0 else 0.5
    
    async def _record_positive_learning(
        self,
        content_id: str,
        result: Dict,
        score: float
    ) -> None:
        """Record a positive learning."""
        learning = Learning(
            learning_id=f"learning_{uuid.uuid4().hex[:8]}",
            agent_id=self.agent_id,
            learning_type=self._infer_learning_type(result),
            content={
                "content_id": content_id,
                "metrics": result,
                "score": score
            },
            confidence=min(score, 1.0),
            evidence=[result],
            success_count=1,
            failure_count=0
        )
        
        self._learnings.append(learning)
        self._save_learning(learning)
        
        # Share with hive mind
        if self._on_learning_ready:
            await self._on_learning_ready(learning)
        
        self.metrics["learnings_shared"] += 1
    
    async def _record_negative_learning(
        self,
        content_id: str,
        result: Dict,
        score: float
    ) -> None:
        """Record a negative learning (what NOT to do)."""
        learning = Learning(
            learning_id=f"learning_{uuid.uuid4().hex[:8]}",
            agent_id=self.agent_id,
            learning_type=self._infer_learning_type(result),
            content={
                "content_id": content_id,
                "metrics": result,
                "score": score,
                "is_negative": True
            },
            confidence=1.0 - score,
            evidence=[result],
            success_count=0,
            failure_count=1
        )
        
        self._learnings.append(learning)
        self._save_learning(learning)
        
        self.logger.info(f"Recorded negative learning from {content_id}: score={score:.2f}")
    
    def _infer_learning_type(self, result: Dict) -> LearningType:
        """Infer what type of learning this is."""
        # Analyze result to determine learning type
        if result.get("hook_views", 0) > result.get("avg_views", 0) * 1.5:
            return LearningType.HOOK_PATTERN
        elif result.get("morning_views", 0) > result.get("evening_views", 0):
            return LearningType.POSTING_TIME
        elif result.get("short_duration", 0) > result.get("long_duration", 0):
            return LearningType.CONTENT_FORMAT
        elif result.get("hashtag_views", 0) > 0.3:
            return LearningType.HASHTAG_STRATEGY
        else:
            return LearningType.AUDIENCE_INSIGHT
    
    async def _generate_insight_from_result(
        self,
        content_id: str,
        result: Dict,
        score: float
    ) -> None:
        """Generate an insight from high-performing content."""
        insight = AgentInsight(
            insight_id=f"insight_{uuid.uuid4().hex[:8]}",
            agent_id=self.agent_id,
            insight_type=self._infer_learning_type(result).value,
            recommendation=f"Content {content_id} performed at {score:.0%} - apply pattern widely",
            reasoning=f"Based on {result.get('views', 0):,} views and {result.get('engagement', 0):,} engagement",
            confidence=score,
            supporting_learnings=[l.learning_id for l in self._learnings[-3:]]
        )
        
        self._insights.append(insight)
        
        if self._on_insight_ready:
            await self._on_insight_ready(insight)
        
        self.metrics["insights_generated"] += 1
    
    # =========================================================================
    # Strategy Updates
    # =========================================================================
    
    async def receive_strategy_update(self, update: StrategyUpdate) -> None:
        """Receive and apply a strategy update from hive mind."""
        self.logger.info(f"Received strategy update: {update.update_id}")
        
        self.metrics["strategy_updates_received"] += 1
        
        # Apply strategy changes
        for key, value in update.strategy_changes.items():
            if hasattr(self.platform_config, key):
                setattr(self.platform_config, key, value)
        
        # Record the update
        strategy_log = self.data_dir / "strategy_updates.jsonl"
        with open(strategy_log, 'a') as f:
            f.write(json.dumps({
                "update_id": update.update_id,
                "source_agents": update.source_agents,
                "received_at": datetime.utcnow().isoformat()
            }) + "\n")
    
    # =========================================================================
    # Inter-Agent Communication
    # =========================================================================
    
    async def send_message(self, target_agent: str, message: Dict) -> bool:
        """Send a message to another agent."""
        if target_agent not in self._outbox:
            self.logger.warning(f"No outbox for agent: {target_agent}")
            return False
        
        try:
            await self._outbox[target_agent].put(message)
            return True
        except Exception as e:
            self.logger.error(f"Failed to send message: {e}")
            return False
    
    async def broadcast_to_hive(self, message: Dict) -> None:
        """Broadcast a message to all agents in the hive."""
        for agent_id, outbox in self._outbox.items():
            try:
                await outbox.put(message)
            except Exception:
                pass
    
    def register_outbox(self, agent_id: str, outbox: asyncio.Queue) -> None:
        """Register an outbox for another agent."""
        self._outbox[agent_id] = outbox
    
    async def _process_messages(self) -> None:
        """Process incoming messages."""
        while self.is_active:
            try:
                message = await asyncio.wait_for(self._inbox.get(), timeout=1.0)
                await self._handle_message(message)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.logger.error(f"Message processing error: {e}")
    
    async def _handle_message(self, message: Dict) -> None:
        """Handle an incoming message."""
        msg_type = message.get("type")
        
        if msg_type == "strategy_update":
            await self.receive_strategy_update(
                StrategyUpdate(**message.get("payload", {}))
            )
        elif msg_type == "learning":
            # Store and potentially use shared learning
            learning = Learning(**message.get("payload", {}))
            self._learnings.append(learning)
        elif msg_type == "request_insight":
            # Respond with insights
            response = {
                "type": "insights_response",
                "payload": {
                    "insights": [
                        {"insight_id": i.insight_id, "recommendation": i.recommendation}
                        for i in self._insights[-3:]
                    ]
                }
            }
            await self.send_message(message.get("source"), response)
    
    # =========================================================================
    # Persistence
    # =========================================================================
    
    def _load_learnings(self) -> None:
        """Load learnings from disk."""
        learnings_file = self.data_dir / "learnings.jsonl"
        if learnings_file.exists():
            with open(learnings_file, 'r') as f:
                for line in f:
                    try:
                        data = json.loads(line)
                        self._learnings.append(Learning(**data))
                    except Exception:
                        pass
    
    def _save_learning(self, learning: Learning) -> None:
        """Save a learning to disk."""
        learnings_file = self.data_dir / "learnings.jsonl"
        with open(learnings_file, 'a') as f:
            f.write(json.dumps({
                "learning_id": learning.learning_id,
                "agent_id": learning.agent_id,
                "learning_type": learning.learning_type.value,
                "content": learning.content,
                "confidence": learning.confidence,
                "success_count": learning.success_count,
                "failure_count": learning.failure_count,
                "created_at": learning.created_at
            }) + "\n")
    
    # =========================================================================
    # Metrics & Status
    # =========================================================================
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get agent metrics."""
        return {
            **self.metrics,
            "state": self.state.value,
            "is_active": self.is_active,
            "learnings_count": len(self._learnings),
            "insights_count": len(self._insights),
            "platform": self.platform
        }
    
    def get_top_learnings(self, limit: int = 5) -> List[Learning]:
        """Get top-performing learnings."""
        sorted_learnings = sorted(
            self._learnings,
            key=lambda l: l.success_count - l.failure_count,
            reverse=True
        )
        return sorted_learnings[:limit]
    
    def get_status(self) -> Dict[str, Any]:
        """Get agent status."""
        return {
            "agent_id": self.agent_id,
            "platform": self.platform,
            "state": self.state.value,
            "is_active": self.is_active,
            "metrics": self.get_metrics(),
            "top_learnings": [
                {"type": l.learning_type.value, "confidence": l.confidence}
                for l in self.get_top_learnings(3)
            ]
        }
