"""
Shared Learning Brain for Hive Mind.

Collects, analyzes, and distributes learnings across all agents.
"""
import asyncio
import json
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path
import logging

from simp.organs.media.multi_agent.base_specialist import (
    BaseSpecialistAgent,
    Learning,
    LearningType,
    AgentInsight
)


@dataclass
class StrategyChange:
    """A change to be applied across agents."""
    change_id: str
    strategy_type: str
    change: Dict[str, Any]
    confidence: float
    source_learnings: List[str]
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    applied: bool = False
    applied_agents: List[str] = field(default_factory=list)


@dataclass
class CrossPlatformInsight:
    """An insight that applies across multiple platforms."""
    insight_id: str
    insight: str
    platforms: List[str]
    confidence: float
    evidence: List[Dict]
    generated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class SharedLearningBrain:
    """
    Central intelligence hub for the hive mind.
    
    Collects learnings from all agents, identifies patterns,
    generates cross-platform insights, and distributes strategy updates.
    """
    
    def __init__(self, data_dir: str = "data/media/learning"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("media.learning_brain")
        
        # All learnings from all agents
        self._learnings: List[Learning] = []
        self._insights: List[AgentInsight] = []
        self._strategy_changes: List[StrategyChange] = []
        
        # Agent registry
        self._agents: Dict[str, BaseSpecialistAgent] = {}
        self._agent_outboxes: Dict[str, asyncio.Queue] = {}
        
        # Learning analysis
        self._learning_patterns: Dict[str, List[Learning]] = defaultdict(list)
        self._cross_platform_insights: List[CrossPlatformInsight] = []
        
        # Configuration
        self.min_confidence_threshold = 0.7
        self.learning_consolidation_interval = 300  # 5 minutes
        self.max_learnings_per_agent = 100
        
        # Stats
        self.metrics = {
            "total_learnings": 0,
            "cross_platform_insights": 0,
            "strategy_changes": 0,
            "insights_distributed": 0
        }
        
        self._load_persistent_learnings()
    
    # =========================================================================
    # Agent Registration
    # =========================================================================
    
    def register_agent(self, agent: BaseSpecialistAgent) -> None:
        """Register an agent with the learning brain."""
        self._agents[agent.agent_id] = agent
        
        # Create outbox for this agent
        outbox = asyncio.Queue()
        self._agent_outboxes[agent.agent_id] = outbox
        
        # Register with agent
        agent.register_outbox("hive_mind", outbox)
        
        # Set up callbacks
        agent._on_learning_ready = self.receive_learning
        agent._on_insight_ready = self.receive_insight
        
        self.logger.info(f"Registered agent: {agent.agent_id} ({agent.platform})")
    
    def unregister_agent(self, agent_id: str) -> None:
        """Unregister an agent."""
        if agent_id in self._agents:
            del self._agents[agent_id]
        if agent_id in self._agent_outboxes:
            del self._agent_outboxes[agent_id]
    
    # =========================================================================
    # Learning Collection
    # =========================================================================
    
    async def receive_learning(self, learning: Learning) -> None:
        """Receive a learning from an agent."""
        self.logger.debug(f"Received learning from {learning.agent_id}: {learning.learning_type.value}")
        
        # Store learning
        self._learnings.append(learning)
        self._learning_patterns[learning.learning_type.value].append(learning)
        
        # Update metrics
        self.metrics["total_learnings"] += 1
        
        # Check if this warrants a strategy change
        await self._analyze_learning(learning)
        
        # Consolidate learnings periodically
        await self._maybe_consolidate_learnings()
    
    async def receive_insight(self, insight: AgentInsight) -> None:
        """Receive an insight from an agent."""
        self.logger.info(f"Received insight from {insight.agent_id}: {insight.recommendation[:50]}...")
        
        self._insights.append(insight)
        
        # Check for cross-platform relevance
        await self._analyze_cross_platform_potential(insight)
    
    async def _analyze_learning(self, learning: Learning) -> None:
        """Analyze if a learning warrants action."""
        if learning.confidence >= self.min_confidence_threshold:
            # Check for pattern across learnings
            pattern = self._detect_pattern(learning)
            
            if pattern:
                # Generate strategy change
                await self._generate_strategy_change(learning, pattern)
    
    def _detect_pattern(self, learning: Learning) -> Optional[Dict]:
        """Detect patterns in learnings."""
        # Get recent learnings of same type
        recent = [
            l for l in self._learning_patterns.get(learning.learning_type.value, [])
            if l.agent_id == learning.agent_id
        ][-10:]  # Last 10 from same agent
        
        if len(recent) >= 3:
            # Check for consistent success
            avg_confidence = sum(l.confidence for l in recent) / len(recent)
            if avg_confidence > 0.75:
                return {
                    "type": learning.learning_type.value,
                    "avg_confidence": avg_confidence,
                    "sample_size": len(recent),
                    "agent_id": learning.agent_id
                }
        
        return None
    
    async def _generate_strategy_change(self, learning: Learning, pattern: Dict) -> None:
        """Generate and distribute a strategy change."""
        change = StrategyChange(
            change_id=f"change_{uuid.uuid4().hex[:8]}",
            strategy_type=pattern["type"],
            change={
                "confidence_boost": min(pattern["avg_confidence"], 1.0),
                "pattern_source": learning.agent_id
            },
            confidence=pattern["avg_confidence"],
            source_learnings=[l.learning_id for l in self._learnings[-5:]]
        )
        
        self._strategy_changes.append(change)
        self.metrics["strategy_changes"] += 1
        
        # Distribute to relevant agents
        await self._distribute_strategy_change(change)
    
    async def _distribute_strategy_change(self, change: StrategyChange) -> None:
        """Distribute strategy change to appropriate agents."""
        from simp.organs.media.multi_agent.base_specialist import StrategyUpdate
        
        update = StrategyUpdate(
            update_id=change.change_id,
            source_agents=[l.agent_id for l in self._learnings[-5:]],
            strategy_type=change.strategy_type,
            changes=change.change,
            priority=int(change.confidence * 10)
        )
        
        # Send to all agents
        for agent_id, outbox in self._agent_outboxes.items():
            try:
                await outbox.put({
                    "type": "strategy_update",
                    "payload": {
                        "update_id": update.update_id,
                        "source_agents": update.source_agents,
                        "strategy_type": update.strategy_type,
                        "changes": update.changes,
                        "priority": update.priority,
                        "created_at": update.created_at
                    }
                })
                change.applied_agents.append(agent_id)
                change.applied = True
                
            except Exception as e:
                self.logger.error(f"Failed to send update to {agent_id}: {e}")
        
        self.metrics["insights_distributed"] += len(change.applied_agents)
    
    async def _maybe_consolidate_learnings(self) -> None:
        """Periodically consolidate and prune learnings."""
        if self.metrics["total_learnings"] % 20 == 0:
            await self._consolidate_learnings()
    
    async def _consolidate_learnings(self) -> None:
        """Consolidate similar learnings and prune old ones."""
        # Group by type and agent
        grouped = defaultdict(list)
        for learning in self._learnings:
            key = f"{learning.agent_id}_{learning.learning_type.value}"
            grouped[key].append(learning)
        
        # Keep only best learnings per group
        for key, learnings in grouped.items():
            if len(learnings) > self.max_learnings_per_agent:
                # Sort by confidence and success rate
                sorted_learnings = sorted(
                    learnings,
                    key=lambda l: (l.confidence, l.success_count - l.failure_count),
                    reverse=True
                )
                # Prune bottom half
                self._learnings = [
                    l for l in self._learnings
                    if not (l in learnings[len(sorted_learnings)//2:])
                ]
        
        self._save_learnings()
    
    # =========================================================================
    # Cross-Platform Analysis
    # =========================================================================
    
    async def _analyze_cross_platform_potential(self, insight: AgentInsight) -> None:
        """Analyze if insight applies across platforms."""
        # Look for similar insights from other platforms
        similar_insights = [
            i for i in self._insights
            if i.insight_type == insight.insight_type
            and i.agent_id != insight.agent_id
            and i.confidence > 0.7
        ]
        
        if len(similar_insights) >= 2:
            # Cross-platform insight detected
            cross_platform = CrossPlatformInsight(
                insight_id=f"xplatform_{uuid.uuid4().hex[:8]}",
                insight=insight.recommendation,
                platforms=list(set([i.agent_id for i in [insight] + similar_insights])),
                confidence=sum(i.confidence for i in similar_insights + [insight]) / (len(similar_insights) + 1),
                evidence=[{"insight_id": i.insight_id, "agent": i.agent_id} for i in similar_insights]
            )
            
            self._cross_platform_insights.append(cross_platform)
            self.metrics["cross_platform_insights"] += 1
            
            self.logger.info(
                f"Cross-platform insight: {insight.insight_type} "
                f"across {len(cross_platform.platforms)} platforms"
            )
    
    # =========================================================================
    # Query Interface
    # =========================================================================
    
    def get_best_learnings(self, learning_type: Optional[LearningType] = None, limit: int = 10) -> List[Learning]:
        """Get best-performing learnings."""
        learnings = self._learnings
        
        if learning_type:
            learnings = [l for l in learnings if l.learning_type == learning_type]
        
        return sorted(
            learnings,
            key=lambda l: (l.confidence, l.success_count - l.failure_count),
            reverse=True
        )[:limit]
    
    def get_platform_recommendations(self, platform: str) -> List[Dict]:
        """Get recommendations for a specific platform."""
        recommendations = []
        
        for change in self._strategy_changes[-10:]:
            if not change.applied or platform in change.applied_agents:
                recommendations.append({
                    "type": change.strategy_type,
                    "change": change.change,
                    "confidence": change.confidence
                })
        
        return recommendations
    
    def get_cross_platform_insights(self) -> List[CrossPlatformInsight]:
        """Get all cross-platform insights."""
        return self._cross_platform_insights
    
    # =========================================================================
    # Persistence
    # =========================================================================
    
    def _load_persistent_learnings(self) -> None:
        """Load learnings from disk."""
        learnings_file = self.data_dir / "learnings.jsonl"
        if learnings_file.exists():
            with open(learnings_file, 'r') as f:
                for line in f:
                    try:
                        data = json.loads(line)
                        self._learnings.append(Learning(**data))
                    except Exception:
                        pass
    
    def _save_learnings(self) -> None:
        """Save learnings to disk."""
        learnings_file = self.data_dir / "learnings.jsonl"
        
        with open(learnings_file, 'w') as f:
            for learning in self._learnings[-1000:]:  # Keep last 1000
                f.write(json.dumps({
                    "learning_id": learning.learning_id,
                    "agent_id": learning.agent_id,
                    "learning_type": learning.learning_type.value,
                    "content": learning.content,
                    "confidence": learning.confidence,
                    "success_count": learning.success_count,
                    "failure_count": learning.failure_count,
                    "created_at": learning.created_at
                }) + "\n")
    
    # =========================================================================
    # Metrics
    # =========================================================================
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get learning brain metrics."""
        return {
            **self.metrics,
            "registered_agents": len(self._agents),
            "total_learnings": len(self._learnings),
            "insights_count": len(self._insights),
            "strategy_changes": len(self._strategy_changes),
            "cross_platform_insights": len(self._cross_platform_insights),
            "patterns_tracked": len(self._learning_patterns)
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Get overall status."""
        return {
            "agents": {
                agent_id: {
                    "platform": agent.platform,
                    "learnings_shared": len([l for l in self._learnings if l.agent_id == agent_id]),
                    "insights_generated": len([i for i in self._insights if i.agent_id == agent_id])
                }
                for agent_id, agent in self._agents.items()
            },
            "top_learnings": [
                {
                    "type": l.learning_type.value,
                    "confidence": l.confidence,
                    "agent": l.agent_id
                }
                for l in self.get_best_learnings(limit=5)
            ],
            "metrics": self.get_metrics()
        }
