"""
Hive Mind Multi-Agent Architecture for Media Grid.

Specialized sub-agents per platform that share learning and coordinate strategy.
"""
from simp.organs.media.multi_agent.base_specialist import BaseSpecialistAgent
from simp.organs.media.multi_agent.platform_agents import (
    TikTokAgent,
    YouTubeAgent,
    InstagramAgent,
    XAgent,
    LinkedInAgent
)
from simp.organs.media.multi_agent.hive_mind import HiveMind, create_hive_mind
from simp.organs.media.multi_agent.learning_brain import SharedLearningBrain

__version__ = "0.1.0"
__all__ = [
    "BaseSpecialistAgent",
    "TikTokAgent",
    "YouTubeAgent", 
    "InstagramAgent",
    "XAgent",
    "LinkedInAgent",
    "HiveMind",
    "SharedLearningBrain",
    "create_hive_mind"
]
