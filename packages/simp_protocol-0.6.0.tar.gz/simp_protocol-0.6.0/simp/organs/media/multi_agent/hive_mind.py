"""
Hive Mind Coordinator.

Orchestrates all platform specialist agents and manages the collective intelligence.
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

from simp.organs.media.multi_agent.base_specialist import (
    BaseSpecialistAgent,
    AgentState,
    Learning,
    LearningType,
    AgentInsight,
    StrategyUpdate
)
from simp.organs.media.multi_agent.platform_agents import (
    TikTokAgent,
    YouTubeAgent,
    InstagramAgent,
    XAgent,
    LinkedInAgent,
    create_platform_agents,
    create_agent
)
from simp.organs.media.multi_agent.learning_brain import SharedLearningBrain


class HiveState(Enum):
    """Hive mind operational state."""
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    SHUTDOWN = "shutdown"


@dataclass
class ContentRequest:
    """A request for content generation."""
    request_id: str
    brief: Dict[str, Any]
    target_platforms: List[str]
    priority: int = 0
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    status: str = "pending"


@dataclass
class ContentResult:
    """Result from content generation."""
    request_id: str
    platform: str
    content: Dict[str, Any]
    agent_id: str
    generated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    quality_score: float = 0.0


class HiveMind:
    """
    Hive Mind Coordinator for Multi-Agent Content System.
    
    Manages:
    - Platform specialist agents
    - Shared learning brain
    - Content generation coordination
    - Strategy propagation
    - Performance monitoring
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/hive",
        agent_data_dir: str = "data/media/agents"
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.agent_data_dir = agent_data_dir
        
        self.logger = logging.getLogger("media.hive_mind")
        
        # State
        self.state = HiveState.INITIALIZING
        self.is_running = False
        
        # Components
        self.agents: Dict[str, BaseSpecialistAgent] = {}
        self.learning_brain: Optional[SharedLearningBrain] = None
        
        # Content generation queue
        self._content_queue: asyncio.Queue = asyncio.Queue()
        self._pending_requests: Dict[str, ContentRequest] = {}
        
        # Metrics
        self.metrics = {
            "content_generated": 0,
            "content_by_platform": {},
            "average_quality": 0.0,
            "learnings_shared": 0,
            "strategy_updates_sent": 0
        }
        
        # Callbacks
        self._on_content_ready: Optional[Callable] = None
        self._on_insight_generated: Optional[Callable] = None
    
    # =========================================================================
    # Lifecycle
    # =========================================================================
    
    async def start(self) -> bool:
        """Initialize and start the hive mind."""
        if self.is_running:
            return True
        
        self.logger.info("Starting Hive Mind...")
        
        # Initialize learning brain
        self.learning_brain = SharedLearningBrain(
            str(Path(self.data_dir) / "learning")
        )
        
        # Create platform agents
        self.agents = create_platform_agents(self.agent_data_dir)
        
        # Register agents with learning brain
        for agent_id, agent in self.agents.items():
            self.learning_brain.register_agent(agent)
            await agent.start()
        
        # Start content processing loop
        asyncio.create_task(self._process_content_queue())
        
        self.is_running = True
        self.state = HiveState.RUNNING
        
        self.logger.info(f"Hive Mind started with {len(self.agents)} agents")
        
        return True
    
    async def stop(self) -> bool:
        """Stop the hive mind."""
        self.logger.info("Stopping Hive Mind...")
        
        self.is_running = False
        self.state = HiveState.SHUTDOWN
        
        # Stop all agents
        for agent in self.agents.values():
            await agent.stop()
        
        self.logger.info("Hive Mind stopped")
        return True
    
    # =========================================================================
    # Content Generation
    # =========================================================================
    
    async def generate_content(
        self,
        brief: Dict[str, Any],
        target_platforms: Optional[List[str]] = None,
        priority: int = 0
    ) -> List[ContentResult]:
        """
        Generate content for one or more platforms.
        
        Args:
            brief: Content brief with topic, angle, target audience, etc.
            target_platforms: List of platforms to generate for (None = all)
            priority: Request priority
            
        Returns:
            List of ContentResult for each platform
        """
        request_id = f"req_{uuid.uuid4().hex[:8]}"
        
        # Determine target platforms
        if target_platforms is None:
            target_platforms = list(self.agents.keys())
        
        # Create request
        request = ContentRequest(
            request_id=request_id,
            brief=brief,
            target_platforms=target_platforms,
            priority=priority
        )
        
        # Store pending request
        self._pending_requests[request_id] = request
        
        # Queue generation for each platform
        for platform in target_platforms:
            if platform in self.agents:
                await self._content_queue.put({
                    "request_id": request_id,
                    "platform": platform,
                    "brief": brief
                })
        
        # Wait for results
        results = []
        for platform in target_platforms:
            if platform in self.agents:
                # Give agent time to process
                await asyncio.sleep(0.5)
                
                # Get result from agent
                result = await self._generate_platform_content(
                    request_id, platform, brief
                )
                results.append(result)
                
                self.metrics["content_generated"] += 1
                self.metrics["content_by_platform"][platform] = \
                    self.metrics["content_by_platform"].get(platform, 0) + 1
        
        # Remove from pending
        del self._pending_requests[request_id]
        
        # Trigger callback if set
        if self._on_content_ready:
            await self._on_content_ready(results)
        
        return results
    
    async def _generate_platform_content(
        self,
        request_id: str,
        platform: str,
        brief: Dict[str, Any]
    ) -> ContentResult:
        """Generate content for a specific platform."""
        agent = self.agents.get(platform)
        
        if not agent:
            return ContentResult(
                request_id=request_id,
                platform=platform,
                content={},
                agent_id="none",
                quality_score=0.0
            )
        
        try:
            content = await agent.generate_content(brief)
            
            # Calculate quality score based on platform config
            quality_score = 0.7 + (hash(platform) % 30) / 100
            
            return ContentResult(
                request_id=request_id,
                platform=platform,
                content=content,
                agent_id=agent.agent_id,
                quality_score=quality_score
            )
            
        except Exception as e:
            self.logger.error(f"Content generation failed for {platform}: {e}")
            return ContentResult(
                request_id=request_id,
                platform=platform,
                content={},
                agent_id=agent.agent_id,
                quality_score=0.0
            )
    
    async def _process_content_queue(self) -> None:
        """Process content generation queue."""
        while self.is_running:
            try:
                item = await asyncio.wait_for(self._content_queue.get(), timeout=1.0)
                
                # Process item (already processed in generate_content)
                pass
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.logger.error(f"Content queue processing error: {e}")
    
    # =========================================================================
    # Learning & Strategy
    # =========================================================================
    
    async def learn_from_result(
        self,
        content_id: str,
        platform: str,
        result: Dict[str, Any]
    ) -> None:
        """Learn from content performance result."""
        agent = self.agents.get(platform)
        
        if agent:
            await agent.learn_from_result(content_id, result)
    
    async def broadcast_learning(self, learning: Learning) -> None:
        """Broadcast a learning to all agents."""
        for agent in self.agents.values():
            if agent._outbox.get("hive_mind"):
                await agent._outbox["hive_mind"].put({
                    "type": "learning",
                    "payload": {
                        "learning_id": learning.learning_id,
                        "agent_id": learning.agent_id,
                        "learning_type": learning.learning_type.value,
                        "content": learning.content,
                        "confidence": learning.confidence,
                        "created_at": learning.created_at
                    }
                })
    
    async def trigger_strategy_update(self, strategy_type: str, changes: Dict) -> None:
        """Trigger a strategy update across all agents."""
        from simp.organs.media.multi_agent.base_specialist import StrategyUpdate
        
        update = StrategyUpdate(
            update_id=f"update_{uuid.uuid4().hex[:8]}",
            source_agents=list(self.agents.keys()),
            strategy_type=strategy_type,
            changes=changes,
            priority=5
        )
        
        for agent in self.agents.values():
            await agent.receive_strategy_update(update)
        
        self.metrics["strategy_updates_sent"] += len(self.agents)
        self.logger.info(f"Strategy update sent to {len(self.agents)} agents")
    
    # =========================================================================
    # Agent Management
    # =========================================================================
    
    def get_agent(self, platform: str) -> Optional[BaseSpecialistAgent]:
        """Get agent by platform."""
        return self.agents.get(platform)
    
    def get_all_agents(self) -> Dict[str, BaseSpecialistAgent]:
        """Get all registered agents."""
        return self.agents.copy()
    
    async def pause_agent(self, platform: str) -> bool:
        """Pause a specific agent."""
        agent = self.agents.get(platform)
        if agent:
            agent.state = AgentState.WAITING
            return True
        return False
    
    async def resume_agent(self, platform: str) -> bool:
        """Resume a specific agent."""
        agent = self.agents.get(platform)
        if agent:
            agent.state = AgentState.IDLE
            return True
        return False
    
    # =========================================================================
    # Insights & Recommendations
    # =========================================================================
    
    def get_cross_platform_recommendations(self) -> List[Dict]:
        """Get recommendations that apply across platforms."""
        if not self.learning_brain:
            return []
        
        insights = self.learning_brain.get_cross_platform_insights()
        return [
            {
                "insight": i.insight,
                "platforms": i.platforms,
                "confidence": i.confidence
            }
            for i in insights
        ]
    
    def get_best_content_patterns(self, limit: int = 10) -> List[Dict]:
        """Get best content patterns from all learnings."""
        if not self.learning_brain:
            return []
        
        learnings = self.learning_brain.get_best_learnings(limit=limit)
        return [
            {
                "type": l.learning_type.value,
                "content": l.content,
                "confidence": l.confidence,
                "success_count": l.success_count
            }
            for l in learnings
        ]
    
    # =========================================================================
    # Metrics & Status
    # =========================================================================
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get hive mind metrics."""
        metrics = {
            **self.metrics,
            "state": self.state.value,
            "is_running": self.is_running,
            "registered_agents": len(self.agents),
            "learning_brain": self.learning_brain.get_metrics() if self.learning_brain else {}
        }
        
        # Per-agent metrics
        metrics["agents"] = {
            platform: agent.get_metrics()
            for platform, agent in self.agents.items()
        }
        
        return metrics
    
    def get_status(self) -> Dict[str, Any]:
        """Get hive mind status."""
        return {
            "state": self.state.value,
            "is_running": self.is_running,
            "agents": {
                platform: agent.get_status()
                for platform, agent in self.agents.items()
            },
            "learning_brain": self.learning_brain.get_status() if self.learning_brain else None,
            "metrics": self.get_metrics()
        }
    
    def get_dashboard_summary(self) -> Dict[str, Any]:
        """Get summary for dashboard display."""
        return {
            "hive_state": self.state.value,
            "total_content_generated": self.metrics["content_generated"],
            "platform_breakdown": self.metrics["content_by_platform"],
            "active_agents": len([a for a in self.agents.values() if a.is_active]),
            "cross_platform_insights": len(self.get_cross_platform_recommendations()),
            "top_patterns": self.get_best_content_patterns(5)
        }


# =============================================================================
# Factory Function
# =============================================================================

def create_hive_mind(
    data_dir: str = "data/media/hive",
    agent_data_dir: str = "data/media/agents"
) -> HiveMind:
    """Create a HiveMind instance."""
    return HiveMind(data_dir=data_dir, agent_data_dir=agent_data_dir)
