"""
SIMP Broker Integration for Media Grid Agents.

Wires autonomous agent system into SIMP broker for:
- Agent-to-agent communication
- Intent routing
- Task distribution
- Health monitoring
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

import httpx

from simp.organs.media.workflow_engine import WorkflowTrigger, WorkflowStatus
from simp.organs.media.autonomous_agent_wiring import (
    AutonomousAgentController, AgentMode
)


class IntentType(Enum):
    """Media grid intent types for SIMP broker."""
    # Workflow triggers
    LAUNCH_CHANNEL = "media.launch_channel"
    DAILY_CONTENT = "media.daily_content"
    TREND_ANALYSIS = "media.trend_analysis"
    ANALYTICS_FEEDBACK = "media.analytics_feedback"
    CLONE_CHANNEL = "media.clone_channel"
    COMPLIANCE_CHECK = "media.compliance_check"
    
    # Agent actions
    CREATE_ACCOUNT = "media.create_account"
    GENERATE_CONTENT = "media.generate_content"
    PUBLISH_CONTENT = "media.publish_content"
    ANALYZE_PERFORMANCE = "media.analyze_performance"
    
    # System
    HEALTH_CHECK = "system.health_check"
    GET_STATUS = "system.get_status"


@dataclass
class Intent:
    """Intent message for SIMP broker."""
    intent_id: str
    intent_type: IntentType
    source_agent: str
    target_agent: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)
    priority: int = 0
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    status: str = "pending"


@dataclass
class IntentResult:
    """Result from intent processing."""
    success: bool
    intent_id: str
    result: Optional[Dict] = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0


class SIMPBrokerIntegration:
    """
    Integration layer between autonomous agents and SIMP broker.
    
    Provides:
    - Intent sending/receiving
    - Agent registration
    - Health monitoring
    - Task distribution
    """
    
    def __init__(
        self,
        broker_url: str = "http://127.0.0.1:5555",
        api_key: str = "",
        autonomous_controller: Optional[AutonomousAgentController] = None,
        agent_id: str = "media_grid_orchestrator"
    ):
        self.broker_url = broker_url.rstrip("/")
        self.api_key = api_key
        self.agent_id = agent_id
        
        self.logger = logging.getLogger("media.simp_broker")
        
        # HTTP client
        self._client: Optional[httpx.AsyncClient] = None
        
        # Autonomous controller
        self.autonomous_controller = autonomous_controller
        
        # Intent handlers
        self._intent_handlers: Dict[IntentType, Callable] = {}
        self._register_default_handlers()
        
        # Metrics
        self._metrics = {
            "intents_sent": 0,
            "intents_received": 0,
            "intents_processed": 0,
            "errors": 0
        }
        
        # Registered agents
        self._registered_agents: Dict[str, Dict] = {}
    
    def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if not self._client:
            self._client = httpx.AsyncClient(
                base_url=self.broker_url,
                timeout=30.0,
                headers={"X-API-Key": self.api_key} if self.api_key else {}
            )
        return self._client
    
    def _register_default_handlers(self) -> None:
        """Register default intent handlers."""
        self._intent_handlers = {
            IntentType.LAUNCH_CHANNEL: self._handle_launch_channel,
            IntentType.DAILY_CONTENT: self._handle_daily_content,
            IntentType.TREND_ANALYSIS: self._handle_trend_analysis,
            IntentType.ANALYTICS_FEEDBACK: self._handle_analytics_feedback,
            IntentType.CLONE_CHANNEL: self._handle_clone_channel,
            IntentType.COMPLIANCE_CHECK: self._handle_compliance_check,
            IntentType.CREATE_ACCOUNT: self._handle_create_account,
            IntentType.HEALTH_CHECK: self._handle_health_check,
            IntentType.GET_STATUS: self._handle_get_status,
        }
    
    # =========================================================================
    # Broker Communication
    # =========================================================================
    
    async def register_with_broker(self) -> bool:
        """Register this agent with SIMP broker."""
        client = self._get_client()
        
        try:
            response = await client.post("/agents/register", json={
                "agent_id": self.agent_id,
                "agent_type": "media_grid_orchestrator",
                "capabilities": [
                    "workflow_execution",
                    "account_creation",
                    "content_generation",
                    "compliance_checking"
                ],
                "intent_types": [it.value for it in IntentType],
                "heartbeat_interval": 60
            })
            
            if response.status_code == 200:
                self.logger.info(f"Registered with broker: {self.agent_id}")
                return True
            
            self.logger.error(f"Registration failed: {response.status_code}")
            return False
            
        except Exception as e:
            self.logger.error(f"Failed to register with broker: {e}")
            return False
    
    async def send_intent(
        self,
        intent_type: IntentType,
        target_agent: Optional[str] = None,
        payload: Optional[Dict] = None,
        priority: int = 0
    ) -> Optional[Intent]:
        """Send an intent to the broker."""
        client = self._get_client()
        
        intent = Intent(
            intent_id=f"intent_{uuid.uuid4().hex[:12]}",
            intent_type=intent_type,
            source_agent=self.agent_id,
            target_agent=target_agent,
            payload=payload or {},
            priority=priority
        )
        
        try:
            response = await client.post("/intents/route", json={
                "intent_id": intent.intent_id,
                "intent_type": intent.intent_type.value,
                "source_agent": intent.source_agent,
                "target_agent": intent.target_agent,
                "payload": intent.payload,
                "priority": intent.priority,
                "timestamp": intent.timestamp
            })
            
            if response.status_code == 200:
                self._metrics["intents_sent"] += 1
                self.logger.debug(f"Sent intent: {intent.intent_id} ({intent_type.value})")
                return intent
            
        except Exception as e:
            self.logger.error(f"Failed to send intent: {e}")
            self._metrics["errors"] += 1
        
        return None
    
    async def receive_intent(self, intent_data: Dict) -> IntentResult:
        """Receive and process an intent."""
        self._metrics["intents_received"] += 1
        
        try:
            intent_type_str = intent_data.get("intent_type", "")
            intent_id = intent_data.get("intent_id", f"intent_{uuid.uuid4().hex[:12]}")
            
            # Parse intent type
            intent_type = None
            for it in IntentType:
                if it.value == intent_type_str:
                    intent_type = it
                    break
            
            if not intent_type:
                return IntentResult(
                    success=False,
                    intent_id=intent_id,
                    error=f"Unknown intent type: {intent_type_str}"
                )
            
            # Get handler
            handler = self._intent_handlers.get(intent_type)
            if not handler:
                return IntentResult(
                    success=False,
                    intent_id=intent_id,
                    error=f"No handler for {intent_type.value}"
                )
            
            # Process intent
            start = time.time()
            result = await handler(intent_data)
            execution_time = (time.time() - start) * 1000
            
            self._metrics["intents_processed"] += 1
            
            return IntentResult(
                success=True,
                intent_id=intent_id,
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            self.logger.error(f"Intent processing failed: {e}")
            self._metrics["errors"] += 1
            return IntentResult(
                success=False,
                intent_id=intent_data.get("intent_id", "unknown"),
                error=str(e)
            )
    
    async def send_heartbeat(self) -> bool:
        """Send heartbeat to broker."""
        client = self._get_client()
        
        try:
            health = self.autonomous_controller.get_health_status() if self.autonomous_controller else {}
            
            response = await client.post(f"/agents/{self.agent_id}/heartbeat", json={
                "timestamp": datetime.utcnow().isoformat(),
                "status": "healthy",
                "metrics": self._metrics,
                "health": health
            })
            
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"Heartbeat failed: {e}")
            return False
    
    # =========================================================================
    # Intent Handlers
    # =========================================================================
    
    async def _handle_launch_channel(self, intent_data: Dict) -> Dict:
        """Handle launch_channel intent."""
        if not self.autonomous_controller:
            return {"success": False, "error": "Autonomous controller not initialized"}
        
        brand_name = intent_data.get("payload", {}).get("brand_name", "")
        platforms = intent_data.get("payload", {}).get("platforms", ["tiktok", "youtube", "instagram", "x"])
        
        result = await self.autonomous_controller.launch_channel_autonomous(
            brand_name=brand_name,
            platforms=platforms
        )
        
        return result
    
    async def _handle_daily_content(self, intent_data: Dict) -> Dict:
        """Handle daily_content intent."""
        # Trigger daily content workflow
        if self.autonomous_controller and self.autonomous_controller.workflow_engine:
            workflow_id = await self.autonomous_controller.workflow_engine.trigger_workflow(
                workflow_type="daily_content_production",
                trigger=WorkflowTrigger.CRON,
                params=intent_data.get("payload", {})
            )
            return {"success": True, "workflow_id": workflow_id}
        
        return {"success": False, "error": "Workflow engine not available"}
    
    async def _handle_trend_analysis(self, intent_data: Dict) -> Dict:
        """Handle trend_analysis intent."""
        if self.autonomous_controller and self.autonomous_controller.workflow_engine:
            workflow_id = await self.autonomous_controller.workflow_engine.trigger_workflow(
                workflow_type="trend_ingestion",
                trigger=WorkflowTrigger.CRON,
                params=intent_data.get("payload", {})
            )
            return {"success": True, "workflow_id": workflow_id}
        
        return {"success": False, "error": "Workflow engine not available"}
    
    async def _handle_analytics_feedback(self, intent_data: Dict) -> Dict:
        """Handle analytics_feedback intent."""
        if self.autonomous_controller and self.autonomous_controller.workflow_engine:
            workflow_id = await self.autonomous_controller.workflow_engine.trigger_workflow(
                workflow_type="analytics_feedback",
                trigger=WorkflowTrigger.CRON,
                params=intent_data.get("payload", {})
            )
            return {"success": True, "workflow_id": workflow_id}
        
        return {"success": False, "error": "Workflow engine not available"}
    
    async def _handle_clone_channel(self, intent_data: Dict) -> Dict:
        """Handle clone_channel intent."""
        if not self.autonomous_controller:
            return {"success": False, "error": "Autonomous controller not initialized"}
        
        payload = intent_data.get("payload", {})
        result = await self.autonomous_controller.launch_channel_autonomous(
            brand_name=payload.get("brand_name", "cloned"),
            platforms=payload.get("platforms", ["tiktok"])
        )
        
        return result
    
    async def _handle_compliance_check(self, intent_data: Dict) -> Dict:
        """Handle compliance_check intent."""
        if self.autonomous_controller and self.autonomous_controller.workflow_engine:
            workflow_id = await self.autonomous_controller.workflow_engine.trigger_workflow(
                workflow_type="compliance_monitor",
                trigger=WorkflowTrigger.WEBHOOK,
                params=intent_data.get("payload", {})
            )
            return {"success": True, "workflow_id": workflow_id}
        
        return {"success": False, "error": "Workflow engine not available"}
    
    async def _handle_create_account(self, intent_data: Dict) -> Dict:
        """Handle create_account intent."""
        if not self.autonomous_controller:
            return {"success": False, "error": "Autonomous controller not initialized"}
        
        from simp.organs.media.platform_oauth_manager import Platform
        
        payload = intent_data.get("payload", {})
        platform = Platform(payload.get("platform", "tiktok"))
        brand_name = payload.get("brand_name", "new_account")
        
        result = await self.autonomous_controller.oauth_manager.create_account(
            platform=platform,
            brand_name=brand_name,
            use_browser_automation=payload.get("use_browser", True)
        )
        
        return {
            "success": result.success,
            "account_id": result.account_id,
            "username": result.username
        }
    
    async def _handle_health_check(self, intent_data: Dict) -> Dict:
        """Handle health_check intent."""
        return {
            "agent_id": self.agent_id,
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "metrics": self._metrics
        }
    
    async def _handle_get_status(self, intent_data: Dict) -> Dict:
        """Handle get_status intent."""
        status = {
            "agent_id": self.agent_id,
            "registered_agents": len(self._registered_agents),
            "metrics": self._metrics
        }
        
        if self.autonomous_controller:
            status["autonomous_health"] = self.autonomous_controller.get_health_status()
        
        return status
    
    # =========================================================================
    # Workflow Integration
    # =========================================================================
    
    async def trigger_workflow_from_intent(
        self,
        intent_type: IntentType,
        payload: Dict
    ) -> Optional[str]:
        """Trigger a workflow based on intent."""
        if not self.autonomous_controller:
            return None
        
        # Map intent types to workflows
        workflow_map = {
            IntentType.LAUNCH_CHANNEL: "channel_launch",
            IntentType.DAILY_CONTENT: "daily_content_production",
            IntentType.TREND_ANALYSIS: "trend_ingestion",
            IntentType.ANALYTICS_FEEDBACK: "analytics_feedback",
            IntentType.CLONE_CHANNEL: "channel_cloning",
            IntentType.COMPLIANCE_CHECK: "compliance_monitor",
        }
        
        workflow_type = workflow_map.get(intent_type)
        if not workflow_type:
            return None
        
        return await self.autonomous_controller.workflow_engine.trigger_workflow(
            workflow_type=workflow_type,
            trigger=WorkflowTrigger.INTENT,
            params=payload
        )
    
    # =========================================================================
    # Metrics
    # =========================================================================
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get integration metrics."""
        return {
            **self._metrics,
            "registered_agents": len(self._registered_agents),
            "intent_types_handled": len(self._intent_handlers)
        }


# Convenience function
def create_simp_broker_integration(
    broker_url: str = "http://127.0.0.1:5555",
    autonomous_controller: Optional[AutonomousAgentController] = None
) -> SIMPBrokerIntegration:
    """Create SIMP broker integration."""
    return SIMPBrokerIntegration(
        broker_url=broker_url,
        autonomous_controller=autonomous_controller
    )
