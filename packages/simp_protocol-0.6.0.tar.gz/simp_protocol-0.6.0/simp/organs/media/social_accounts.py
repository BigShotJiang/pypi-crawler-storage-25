"""
Social Account Registry and OAuth Flow System for KashClaw Media Grid.

Handles platform OAuth credentials, account registration, and token management
for YouTube, TikTok, Instagram, and X (Twitter).
"""
import base64
import json
import os
import secrets
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import httpx

from .models import ContentPlatform


@dataclass
class PlatformAccount:
    """Represents a connected social media account with OAuth tokens."""
    platform: ContentPlatform
    account_id: str
    account_name: str
    access_token: str
    refresh_token: Optional[str] = None
    token_expires_at: Optional[str] = None  # ISO8601
    scopes: List[str] = field(default_factory=list)
    connected_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    last_used: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    status: str = "active"  # "active", "expired", "revoked", "pending"
    channel_id: str = ""
    subscriber_count: int = 0
    daily_upload_limit: int = 0
    uploads_today: int = 0
    
    # Encrypted storage fields
    _encrypted_access_token: Optional[str] = None
    _encrypted_refresh_token: Optional[str] = None
    
    def is_token_expired(self) -> bool:
        """Check if the access token is expired or will expire within 5 minutes."""
        if not self.token_expires_at:
            return False
        try:
            expires_at = datetime.fromisoformat(self.token_expires_at.replace("Z", "+00:00"))
            # Check if token expires within 5 minutes
            threshold = datetime.utcnow() + timedelta(minutes=5)
            return expires_at.replace(tzinfo=None) < threshold.replace(tzinfo=None)
        except (ValueError, TypeError):
            return False
    
    def needs_refresh(self) -> bool:
        """Check if token should be refreshed (within 5 min of expiry)."""
        return self.is_token_expired()


class SocialAccountRegistry:
    """
    Registry for managing social media account connections and OAuth flows.
    
    Handles:
    - Platform OAuth credentials storage and refresh
    - Account registry with status tracking
    - OAuth flow initiation and callback handling
    - Account health monitoring
    """
    
    # OAuth configuration for each platform
    OAUTH_CONFIGS = {
        ContentPlatform.YOUTUBE_SHORTS: {
            "auth_url": "https://accounts.google.com/o/oauth2/v2/auth",
            "token_url": "https://oauth2.googleapis.com/token",
            "scopes": [
                "https://www.googleapis.com/auth/youtube.upload",
                "https://www.googleapis.com/auth/youtube.readonly",
            ],
            "client_id_env": "MEDIA_YOUTUBE_CLIENT_ID",
            "client_secret_env": "MEDIA_YOUTUBE_CLIENT_SECRET",
            "default_upload_limit": 100,
        },
        ContentPlatform.TIKTOK: {
            "auth_url": "https://www.tiktok.com/v2/auth/authorize/",
            "token_url": "https://open.tiktokapis.com/v2/oauth/token/",
            "scopes": [
                "user.info.basic",
                "video.upload",
                "video.publish",
            ],
            "client_id_env": "MEDIA_TIKTOK_CLIENT_KEY",
            "client_secret_env": "MEDIA_TIKTOK_CLIENT_SECRET",
            "default_upload_limit": 50,
        },
        ContentPlatform.INSTAGRAM_REELS: {
            "auth_url": "https://api.instagram.com/oauth/authorize",
            "token_url": "https://api.instagram.com/oauth/access_token",
            "scopes": ["user_profile", "user_media"],
            "client_id_env": "MEDIA_INSTAGRAM_CLIENT_ID",
            "client_secret_env": "MEDIA_INSTAGRAM_CLIENT_SECRET",
            "default_upload_limit": 50,
        },
        ContentPlatform.INSTAGRAM_FEED: {
            "auth_url": "https://api.instagram.com/oauth/authorize",
            "token_url": "https://api.instagram.com/oauth/access_token",
            "scopes": ["user_profile", "user_media"],
            "client_id_env": "MEDIA_INSTAGRAM_CLIENT_ID",
            "client_secret_env": "MEDIA_INSTAGRAM_CLIENT_SECRET",
            "default_upload_limit": 50,
        },
        ContentPlatform.X: {
            "auth_url": "https://twitter.com/i/oauth2/authorize",
            "token_url": "https://api.twitter.com/2/oauth2/token",
            "scopes": ["tweet.write", "users.read", "offline.access"],
            "client_id_env": "MEDIA_X_CLIENT_ID",
            "client_secret_env": "MEDIA_X_CLIENT_SECRET",
            "default_upload_limit": 500,
        },
    }
    
    def __init__(self, data_dir: str = "data/media/social_accounts"):
        """
        Initialize the social account registry.
        
        Args:
            data_dir: Directory for storing account data files.
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Track state for OAuth flows
        self._state_store: Dict[str, Dict[str, Any]] = {}
        
        # HTTP client for OAuth requests
        self._client: Optional[httpx.AsyncClient] = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=30.0)
        return self._client
    
    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
    
    def _get_storage_file(self, platform: ContentPlatform) -> Path:
        """Get the storage file path for a platform."""
        return self.data_dir / f"{platform.value}_accounts.json"
    
    def _encrypt_token(self, token: str) -> str:
        """
        Basic token obfuscation using base64 encoding.
        
        Note: This is obfuscation, not encryption. For production,
        use proper encryption (e.g., Fernet, AWS KMS).
        """
        if not token:
            return ""
        encoded = base64.b64encode(token.encode()).decode()
        return encoded
    
    def _decrypt_token(self, encrypted: str) -> str:
        """
        Decode a base64 obfuscated token.
        """
        if not encrypted:
            return ""
        try:
            decoded = base64.b64decode(encrypted.encode()).decode()
            return decoded
        except Exception:
            return ""
    
    def _get_client_credentials(self, platform: ContentPlatform) -> Tuple[str, str]:
        """
        Get OAuth client credentials from environment variables.
        
        Returns:
            Tuple of (client_id, client_secret)
            
        Raises:
            ValueError: If credentials are not configured for the platform.
        """
        config = self.OAUTH_CONFIGS.get(platform)
        if not config:
            raise ValueError(f"No OAuth configuration for platform: {platform}")
        
        client_id = os.environ.get(config["client_id_env"], "")
        client_secret = os.environ.get(config["client_secret_env"], "")
        
        if not client_id or not client_secret:
            raise ValueError(
                f"Missing OAuth credentials for {platform.value}. "
                f"Set {config['client_id_env']} and {config['client_secret_env']}."
            )
        
        return client_id, client_secret
    
    def _generate_state(self) -> str:
        """Generate a cryptographically secure state parameter for OAuth."""
        return secrets.token_urlsafe(32)
    
    def _build_auth_params(
        self,
        platform: ContentPlatform,
        redirect_uri: str,
        state: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Build platform-specific OAuth authorization parameters.
        
        Args:
            platform: The social platform.
            redirect_uri: OAuth callback URI.
            state: Optional state parameter for CSRF protection.
            
        Returns:
            Dictionary of auth URL parameters.
        """
        config = self.OAUTH_CONFIGS.get(platform)
        if not config:
            raise ValueError(f"Unsupported platform: {platform}")
        
        client_id, _ = self._get_client_credentials(platform)
        
        params: Dict[str, Any] = {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "scope": " ".join(config["scopes"]),
            "response_type": "code",
        }
        
        if state:
            params["state"] = state
        
        # Platform-specific parameters
        if platform == ContentPlatform.YOUTUBE_SHORTS:
            params["access_type"] = "offline"
            params["prompt"] = "consent"
            params["include_granted_scopes"] = "true"
        elif platform == ContentPlatform.TIKTOK:
            params["client_key"] = client_id
            params["scope"] = ",".join(config["scopes"])
            params["redirect_uri"] = redirect_uri
        elif platform in (ContentPlatform.INSTAGRAM_REELS, ContentPlatform.INSTAGRAM_FEED):
            params["redirect_uri"] = redirect_uri
        elif platform == ContentPlatform.X:
            params["code_challenge"] = secrets.token_urlsafe(32)
            params["code_challenge_method"] = "S256"
        
        return params
    
    async def get_oauth_url(
        self,
        platform: ContentPlatform,
        redirect_uri: str,
        store_state: bool = True,
    ) -> str:
        """
        Generate an OAuth authorization URL for the platform.
        
        Args:
            platform: The social platform to authorize.
            redirect_uri: OAuth callback URI.
            store_state: Whether to store the state for validation.
            
        Returns:
            The OAuth authorization URL to redirect the user to.
        """
        config = self.OAUTH_CONFIGS.get(platform)
        if not config:
            raise ValueError(f"Unsupported platform: {platform}")
        
        state = self._generate_state()
        
        if store_state:
            self._state_store[state] = {
                "platform": platform.value,
                "redirect_uri": redirect_uri,
                "created_at": datetime.utcnow().isoformat(),
            }
        
        params = self._build_auth_params(platform, redirect_uri, state)
        
        # Build the URL
        auth_url = config["auth_url"]
        if platform == ContentPlatform.YOUTUBE_SHORTS:
            # Google OAuth uses query parameters
            query = "&".join(f"{k}={v}" for k, v in params.items())
            return f"{auth_url}?{query}"
        elif platform == ContentPlatform.TIKTOK:
            # TikTok uses query parameters
            query = "&".join(f"{k}={v}" for k, v in params.items())
            return f"{auth_url}?{query}"
        else:
            # Standard OAuth URL building
            query = "&".join(f"{k}={v}" for k, v in params.items())
            return f"{auth_url}?{query}"
    
    def _parse_token_response(
        self,
        platform: ContentPlatform,
        response_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Parse platform-specific token response into standardized format.
        
        Args:
            platform: The social platform.
            response_data: Raw response from token endpoint.
            
        Returns:
            Dictionary with standardized keys: access_token, refresh_token, expires_in, scopes.
        """
        result: Dict[str, Any] = {}
        
        if platform == ContentPlatform.YOUTUBE_SHORTS:
            # Google OAuth response
            result["access_token"] = response_data.get("access_token", "")
            result["refresh_token"] = response_data.get("refresh_token")
            result["expires_in"] = response_data.get("expires_in", 3600)
            result["scopes"] = response_data.get("scope", "").split()
        elif platform == ContentPlatform.TIKTOK:
            # TikTok OAuth response
            result["access_token"] = response_data.get("access_token", "")
            result["refresh_token"] = response_data.get("refresh_token")
            result["expires_in"] = response_data.get("expires_in", 3600)
            result["scopes"] = response_data.get("scope", "").split(",")
            result["open_id"] = response_data.get("open_id", "")
        elif platform in (ContentPlatform.INSTAGRAM_REELS, ContentPlatform.INSTAGRAM_FEED):
            # Instagram OAuth response
            result["access_token"] = response_data.get("access_token", "")
            result["refresh_token"] = None
            result["expires_in"] = response_data.get("expires_in", 3600)
            result["scopes"] = response_data.get("scope", "").split(",")
            result["user_id"] = response_data.get("user_id", "")
        elif platform == ContentPlatform.X:
            # Twitter OAuth 2.0 response
            result["access_token"] = response_data.get("access_token", "")
            result["refresh_token"] = response_data.get("refresh_token")
            result["expires_in"] = response_data.get("expires_in", 7200)
            result["scopes"] = response_data.get("scope", "").split()
            result["token_type"] = response_data.get("token_type", "bearer")
        
        return result
    
    async def exchange_code(
        self,
        platform: ContentPlatform,
        code: str,
        redirect_uri: str,
        state: Optional[str] = None,
    ) -> Optional[PlatformAccount]:
        """
        Exchange an authorization code for access tokens.
        
        Args:
            platform: The social platform.
            code: Authorization code from OAuth callback.
            redirect_uri: OAuth callback URI (must match the original).
            state: Optional state parameter for validation.
            
        Returns:
            PlatformAccount if exchange successful, None otherwise.
        """
        config = self.OAUTH_CONFIGS.get(platform)
        if not config:
            raise ValueError(f"Unsupported platform: {platform}")
        
        # Validate state if provided
        if state and state in self._state_store:
            stored = self._state_store.pop(state)
            if stored["platform"] != platform.value:
                raise ValueError("State platform mismatch")
        
        client_id, client_secret = self._get_client_credentials(platform)
        
        # Build token request based on platform
        if platform == ContentPlatform.YOUTUBE_SHORTS:
            data = {
                "code": code,
                "client_id": client_id,
                "client_secret": client_secret,
                "redirect_uri": redirect_uri,
                "grant_type": "authorization_code",
            }
        elif platform == ContentPlatform.TIKTOK:
            data = {
                "code": code,
                "client_key": client_id,
                "client_secret": client_secret,
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
            }
        elif platform in (ContentPlatform.INSTAGRAM_REELS, ContentPlatform.INSTAGRAM_FEED):
            data = {
                "client_id": client_id,
                "client_secret": client_secret,
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
                "code": code,
            }
        elif platform == ContentPlatform.X:
            data = {
                "code": code,
                "grant_type": "authorization_code",
                "client_id": client_id,
                "client_secret": client_secret,
                "redirect_uri": redirect_uri,
            }
        else:
            raise ValueError(f"Unsupported platform: {platform}")
        
        try:
            client = await self._get_client()
            response = await client.post(config["token_url"], data=data)
            response.raise_for_status()
            token_data = response.json()
        except httpx.HTTPError as e:
            print(f"Token exchange failed for {platform.value}: {e}")
            return None
        
        # Parse token response
        parsed = self._parse_token_response(platform, token_data)
        
        # Calculate expiration time
        expires_in = parsed.get("expires_in", 3600)
        expires_at = datetime.utcnow() + timedelta(seconds=expires_in)
        
        # Fetch account info
        account_info = await self._fetch_account_info(platform, parsed["access_token"])
        
        # Create account
        account = PlatformAccount(
            platform=platform,
            account_id=account_info.get("account_id", f"{platform.value}_{int(time.time())}"),
            account_name=account_info.get("account_name", "Unknown Account"),
            access_token=parsed["access_token"],
            refresh_token=parsed.get("refresh_token"),
            token_expires_at=expires_at.isoformat(),
            scopes=parsed.get("scopes", []),
            status="active",
            channel_id=account_info.get("channel_id", ""),
            subscriber_count=account_info.get("subscriber_count", 0),
            daily_upload_limit=config.get("default_upload_limit", 100),
            uploads_today=0,
        )
        
        # Save the account
        self.save_account(account)
        
        return account
    
    async def _fetch_account_info(
        self,
        platform: ContentPlatform,
        access_token: str,
    ) -> Dict[str, Any]:
        """
        Fetch account information from the platform API.
        
        Args:
            platform: The social platform.
            access_token: Valid access token.
            
        Returns:
            Dictionary with account_id, account_name, channel_id, subscriber_count.
        """
        client = await self._get_client()
        headers = {"Authorization": f"Bearer {access_token}"}
        info: Dict[str, Any] = {}
        
        try:
            if platform == ContentPlatform.YOUTUBE_SHORTS:
                response = await client.get(
                    "https://www.googleapis.com/youtube/v3/channels",
                    params={"part": "snippet,statistics", "mine": "true"},
                    headers=headers,
                )
                if response.status_code == 200:
                    data = response.json()
                    if data.get("items"):
                        channel = data["items"][0]
                        info["account_id"] = channel["id"]
                        info["account_name"] = channel["snippet"]["title"]
                        info["channel_id"] = channel["id"]
                        info["subscriber_count"] = int(
                            channel["statistics"].get("subscriberCount", 0)
                        )
                        
            elif platform == ContentPlatform.TIKTOK:
                response = await client.get(
                    "https://open.tiktokapis.com/v2/user/info/",
                    headers={**headers, "Content-Type": "application/json"},
                )
                if response.status_code == 200:
                    data = response.json()
                    user = data.get("data", {}).get("user", {})
                    info["account_id"] = user.get("open_id", "")
                    info["account_name"] = user.get("display_name", "")
                    info["channel_id"] = user.get("open_id", "")
                    
            elif platform in (ContentPlatform.INSTAGRAM_REELS, ContentPlatform.INSTAGRAM_FEED):
                # Instagram requires Graph API call
                # First get the IG User ID from the access token
                ig_response = await client.get(
                    "https://graph.instagram.com/me",
                    params={
                        "fields": "id,username,followers_count,account_type",
                        "access_token": access_token,
                    },
                )
                if ig_response.status_code == 200:
                    data = ig_response.json()
                    info["account_id"] = data.get("id", "")
                    info["account_name"] = data.get("username", "")
                    info["channel_id"] = data.get("id", "")
                    info["subscriber_count"] = data.get("followers_count", 0)
                    
            elif platform == ContentPlatform.X:
                response = await client.get(
                    "https://api.twitter.com/2/users/me",
                    params={"user.fields": "public_metrics,name,username"},
                    headers=headers,
                )
                if response.status_code == 200:
                    data = response.json()
                    user = data.get("data", {})
                    info["account_id"] = user.get("id", "")
                    info["account_name"] = user.get("username", "")
                    info["channel_id"] = user.get("id", "")
                    info["subscriber_count"] = user.get("public_metrics", {}).get(
                        "followers_count", 0
                    )
                    
        except httpx.HTTPError as e:
            print(f"Failed to fetch account info for {platform.value}: {e}")
        
        # Return defaults if fetch failed
        if not info:
            info = {
                "account_id": f"{platform.value}_unknown",
                "account_name": "Unknown",
                "channel_id": "",
                "subscriber_count": 0,
            }
        
        return info
    
    def _save_tokens(self, account: PlatformAccount) -> None:
        """
        Save updated tokens to the account (with obfuscation).
        
        Args:
            account: Account with updated token information.
        """
        # Update last used timestamp
        account.last_used = datetime.utcnow().isoformat()
        self.save_account(account)
    
    async def refresh_if_needed(self, account: PlatformAccount) -> bool:
        """
        Refresh the access token if it's expired or about to expire.
        
        Args:
            account: The platform account to refresh.
            
        Returns:
            True if the token is still valid (refreshed or not needed),
            False if refresh failed.
        """
        # Check if refresh is needed
        if not account.needs_refresh():
            return True
        
        if not account.refresh_token:
            print(f"No refresh token available for {account.platform.value}:{account.account_id}")
            account.status = "expired"
            self.save_account(account)
            return False
        
        config = self.OAUTH_CONFIGS.get(account.platform)
        if not config:
            return False
        
        client_id, client_secret = self._get_client_credentials(account.platform)
        
        # Build refresh request based on platform
        if account.platform == ContentPlatform.YOUTUBE_SHORTS:
            data = {
                "grant_type": "refresh_token",
                "refresh_token": account.refresh_token,
                "client_id": client_id,
                "client_secret": client_secret,
            }
        elif account.platform == ContentPlatform.TIKTOK:
            data = {
                "grant_type": "refresh_token",
                "refresh_token": account.refresh_token,
                "client_key": client_id,
                "client_secret": client_secret,
            }
        elif account.platform in (ContentPlatform.INSTAGRAM_REELS, ContentPlatform.INSTAGRAM_FEED):
            # Instagram doesn't support token refresh via API
            print(f"Instagram does not support token refresh")
            return False
        elif account.platform == ContentPlatform.X:
            data = {
                "grant_type": "refresh_token",
                "refresh_token": account.refresh_token,
                "client_id": client_id,
                "client_secret": client_secret,
            }
        else:
            return False
        
        try:
            client = await self._get_client()
            response = await client.post(config["token_url"], data=data)
            response.raise_for_status()
            token_data = response.json()
        except httpx.HTTPError as e:
            print(f"Token refresh failed for {account.platform.value}: {e}")
            account.status = "expired"
            self.save_account(account)
            return False
        
        # Parse updated tokens
        parsed = self._parse_token_response(account.platform, token_data)
        
        # Update account with new tokens
        account.access_token = parsed.get("access_token", account.access_token)
        if parsed.get("refresh_token"):
            account.refresh_token = parsed["refresh_token"]
        
        expires_in = parsed.get("expires_in", 3600)
        account.token_expires_at = (
            datetime.utcnow() + timedelta(seconds=expires_in)
        ).isoformat()
        
        if parsed.get("scopes"):
            account.scopes = parsed["scopes"]
        
        account.status = "active"
        
        # Persist the updated tokens
        self._save_tokens(account)
        
        return True
    
    def get_account(
        self,
        platform: ContentPlatform,
        account_id: str,
    ) -> Optional[PlatformAccount]:
        """
        Retrieve an account by platform and account ID.
        
        Args:
            platform: The social platform.
            account_id: The account identifier.
            
        Returns:
            PlatformAccount if found, None otherwise.
        """
        storage_file = self._get_storage_file(platform)
        
        if not storage_file.exists():
            return None
        
        try:
            with open(storage_file, "r") as f:
                accounts_data = json.load(f)
        except (json.JSONDecodeError, IOError):
            return None
        
        for acc_data in accounts_data.get("accounts", []):
            if acc_data.get("account_id") == account_id:
                return self._deserialize_account(acc_data)
        
        return None
    
    def save_account(self, account: PlatformAccount) -> None:
        """
        Save or update an account in storage.
        
        Args:
            account: The platform account to save.
        """
        storage_file = self._get_storage_file(account.platform)
        
        # Load existing accounts
        accounts_data = {"accounts": []}
        if storage_file.exists():
            try:
                with open(storage_file, "r") as f:
                    accounts_data = json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        
        # Update or append
        serialized = self._serialize_account(account)
        found = False
        for i, acc_data in enumerate(accounts_data["accounts"]):
            if acc_data.get("account_id") == account.account_id:
                accounts_data["accounts"][i] = serialized
                found = True
                break
        
        if not found:
            accounts_data["accounts"].append(serialized)
        
        # Save
        with open(storage_file, "w") as f:
            json.dump(accounts_data, f, indent=2)
    
    def _serialize_account(self, account: PlatformAccount) -> Dict[str, Any]:
        """
        Serialize account for JSON storage with token obfuscation.
        
        Args:
            account: The account to serialize.
            
        Returns:
            Dictionary suitable for JSON storage.
        """
        data = asdict(account)
        
        # Encrypt tokens before storage
        data["access_token"] = self._encrypt_token(account.access_token)
        if account.refresh_token:
            data["refresh_token"] = self._encrypt_token(account.refresh_token)
        
        # Remove internal fields
        data.pop("_encrypted_access_token", None)
        data.pop("_encrypted_refresh_token", None)
        
        # Convert enum to string
        data["platform"] = account.platform.value
        
        return data
    
    def _deserialize_account(self, data: Dict[str, Any]) -> PlatformAccount:
        """
        Deserialize account from JSON storage with token decryption.
        
        Args:
            data: Dictionary from JSON storage.
            
        Returns:
            PlatformAccount instance.
        """
        # Decrypt tokens
        data["access_token"] = self._decrypt_token(data.get("access_token", ""))
        data["refresh_token"] = self._decrypt_token(data.get("refresh_token", ""))
        
        # Convert platform string to enum
        if isinstance(data.get("platform"), str):
            data["platform"] = ContentPlatform(data["platform"])
        
        return PlatformAccount(**data)
    
    def revoke_account(self, platform: ContentPlatform, account_id: str) -> None:
        """
        Revoke an account and mark it as revoked.
        
        Args:
            platform: The social platform.
            account_id: The account identifier.
        """
        account = self.get_account(platform, account_id)
        
        if account:
            account.status = "revoked"
            # Optionally make API call to revoke tokens on the platform
            self.save_account(account)
    
    def list_accounts(
        self,
        platform: Optional[ContentPlatform] = None,
    ) -> List[PlatformAccount]:
        """
        List all accounts, optionally filtered by platform.
        
        Args:
            platform: Optional platform filter.
            
        Returns:
            List of PlatformAccount objects.
        """
        accounts: List[PlatformAccount] = []
        
        platforms = [platform] if platform else list(self.OAUTH_CONFIGS.keys())
        
        for p in platforms:
            storage_file = self._get_storage_file(p)
            
            if not storage_file.exists():
                continue
            
            try:
                with open(storage_file, "r") as f:
                    accounts_data = json.load(f)
                
                for acc_data in accounts_data.get("accounts", []):
                    accounts.append(self._deserialize_account(acc_data))
                    
            except (json.JSONDecodeError, IOError):
                continue
        
        return accounts
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Perform a health check on all connected accounts.
        
        Returns:
            Dictionary with:
            - total_accounts: Total number of accounts
            - by_platform: Per-platform breakdown
            - expired_tokens: List of accounts with expired tokens
            - needs_refresh: List of accounts that need token refresh
            - healthy: Overall health status
        """
        accounts = self.list_accounts()
        
        result: Dict[str, Any] = {
            "checked_at": datetime.utcnow().isoformat(),
            "total_accounts": len(accounts),
            "by_platform": {},
            "expired_tokens": [],
            "needs_refresh": [],
            "healthy": True,
        }
        
        for platform in self.OAUTH_CONFIGS.keys():
            platform_accounts = [a for a in accounts if a.platform == platform]
            result["by_platform"][platform.value] = {
                "count": len(platform_accounts),
                "active": len([a for a in platform_accounts if a.status == "active"]),
                "expired": len([a for a in platform_accounts if a.status == "expired"]),
                "revoked": len([a for a in platform_accounts if a.status == "revoked"]),
            }
        
        for account in accounts:
            if account.status == "expired":
                result["expired_tokens"].append({
                    "platform": account.platform.value,
                    "account_id": account.account_id,
                    "account_name": account.account_name,
                })
                result["healthy"] = False
            elif account.needs_refresh() and account.refresh_token:
                result["needs_refresh"].append({
                    "platform": account.account_id,
                    "account_id": account.account_id,
                    "account_name": account.account_name,
                    "expires_at": account.token_expires_at,
                })
        
        # Attempt to refresh accounts that need it
        for account in accounts:
            if account.status == "active" and account.needs_refresh() and account.refresh_token:
                refresh_success = await self.refresh_if_needed(account)
                if not refresh_success and account.status != "active":
                    result["expired_tokens"].append({
                        "platform": account.platform.value,
                        "account_id": account.account_id,
                        "account_name": account.account_name,
                        "refresh_failed": True,
                    })
                    result["healthy"] = False
        
        return result
    
    async def validate_token(self, account: PlatformAccount) -> bool:
        """
        Validate that an account's access token is still valid.
        
        Args:
            account: The account to validate.
            
        Returns:
            True if token is valid, False otherwise.
        """
        client = await self._get_client()
        headers = {"Authorization": f"Bearer {account.access_token}"}
        
        try:
            if account.platform == ContentPlatform.YOUTUBE_SHORTS:
                response = await client.get(
                    "https://www.googleapis.com/youtube/v3/channels",
                    params={"part": "id", "mine": "true"},
                    headers=headers,
                )
            elif account.platform == ContentPlatform.TIKTOK:
                response = await client.get(
                    "https://open.tiktokapis.com/v2/user/info/",
                    headers={**headers, "Content-Type": "application/json"},
                )
            elif account.platform in (ContentPlatform.INSTAGRAM_REELS, ContentPlatform.INSTAGRAM_FEED):
                response = await client.get(
                    "https://graph.instagram.com/me",
                    params={"fields": "id", "access_token": account.access_token},
                )
            elif account.platform == ContentPlatform.X:
                response = await client.get(
                    "https://api.twitter.com/2/users/me",
                    headers=headers,
                )
            else:
                return False
            
            if response.status_code == 200:
                return True
            elif response.status_code == 401:
                # Token expired
                account.status = "expired"
                self.save_account(account)
                return False
            else:
                return False
                
        except httpx.HTTPError:
            return False
    
    def get_accounts_by_status(
        self,
        status: str,
    ) -> List[PlatformAccount]:
        """
        Get all accounts with a specific status.
        
        Args:
            status: Account status to filter by.
            
        Returns:
            List of accounts with the specified status.
        """
        return [a for a in self.list_accounts() if a.status == status]
    
    def get_active_accounts(self) -> List[PlatformAccount]:
        """Get all accounts with 'active' status."""
        return self.get_accounts_by_status("active")
    
    async def refresh_all_expired(self) -> Dict[str, Any]:
        """
        Refresh all accounts that need token refresh.
        
        Returns:
            Dictionary with refresh results per account.
        """
        accounts = self.list_accounts()
        results: Dict[str, Any] = {
            "attempted": 0,
            "succeeded": 0,
            "failed": [],
        }
        
        for account in accounts:
            if account.status == "active" and account.needs_refresh():
                results["attempted"] += 1
                success = await self.refresh_if_needed(account)
                if success:
                    results["succeeded"] += 1
                else:
                    results["failed"].append({
                        "platform": account.platform.value,
                        "account_id": account.account_id,
                    })
        
        return results
    
    def delete_account(self, platform: ContentPlatform, account_id: str) -> bool:
        """
        Delete an account from the registry.
        
        Args:
            platform: The social platform.
            account_id: The account identifier.
            
        Returns:
            True if account was deleted, False if not found.
        """
        storage_file = self._get_storage_file(platform)
        
        if not storage_file.exists():
            return False
        
        try:
            with open(storage_file, "r") as f:
                accounts_data = json.load(f)
        except (json.JSONDecodeError, IOError):
            return False
        
        original_count = len(accounts_data.get("accounts", []))
        accounts_data["accounts"] = [
            a for a in accounts_data.get("accounts", [])
            if a.get("account_id") != account_id
        ]
        
        if len(accounts_data["accounts"]) < original_count:
            with open(storage_file, "w") as f:
                json.dump(accounts_data, f, indent=2)
            return True
        
        return False
    
    def get_platform_stats(self) -> Dict[str, Any]:
        """
        Get statistics about connected accounts per platform.
        
        Returns:
            Dictionary with per-platform statistics.
        """
        accounts = self.list_accounts()
        stats: Dict[str, Any] = {}
        
        for platform in self.OAUTH_CONFIGS.keys():
            platform_accounts = [a for a in accounts if a.platform == platform]
            
            if platform_accounts:
                total_subscribers = sum(a.subscriber_count for a in platform_accounts)
                total_uploads_today = sum(a.uploads_today for a in platform_accounts)
                total_daily_limit = sum(a.daily_upload_limit for a in platform_accounts)
                
                stats[platform.value] = {
                    "connected_accounts": len(platform_accounts),
                    "total_subscribers": total_subscribers,
                    "uploads_today": total_uploads_today,
                    "daily_limit": total_daily_limit,
                    "capacity_remaining": total_daily_limit - total_uploads_today,
                }
        
        return stats


# Convenience function for synchronous usage
def create_registry(data_dir: str = "data/media/social_accounts") -> SocialAccountRegistry:
    """
    Create a new SocialAccountRegistry instance.
    
    Args:
        data_dir: Directory for storing account data.
        
    Returns:
        SocialAccountRegistry instance.
    """
    return SocialAccountRegistry(data_dir=data_dir)
