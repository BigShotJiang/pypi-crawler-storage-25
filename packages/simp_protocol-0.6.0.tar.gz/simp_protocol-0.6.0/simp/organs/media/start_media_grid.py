#!/usr/bin/env python3
"""
Media Grid Integration with SIMP Broker.

Wires the autonomous media grid system into the SIMP broker for:
- Agent registration
- Intent routing
- Health heartbeats
- Task distribution
"""
import asyncio
import signal
import sys
import time
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from simp.organs.media import (
    create_autonomous_controller,
    create_simp_broker_integration,
    IntentType,
    AgentMode,
    Platform
)


class MediaGridIntegration:
    """
    Main integration controller for Media Grid + SIMP Broker.
    
    Handles:
    - Startup/shutdown
    - Broker connection
    - Workflow triggering
    - Health monitoring
    """
    
    def __init__(
        self,
        broker_url: str = "http://127.0.0.1:5555",
        api_key: str = "",
        agent_id: str = "media_grid_orchestrator"
    ):
        self.broker_url = broker_url
        self.api_key = api_key
        self.agent_id = agent_id
        
        # Components
        self.autonomous_controller = None
        self.broker_integration = None
        
        # State
        self.is_running = False
        self.heartbeat_task = None
        self.workflow_scheduler_task = None
        
        print(f"Media Grid Integration initialized")
        print(f"  - Broker: {broker_url}")
        print(f"  - Agent ID: {agent_id}")
    
    async def start(self) -> bool:
        """Start the media grid integration."""
        print("\n" + "="*60)
        print("Starting Media Grid Integration")
        print("="*60)
        
        # Initialize autonomous controller
        print("\n[1/4] Initializing autonomous controller...")
        self.autonomous_controller = create_autonomous_controller(
            data_dir="data/media/autonomous"
        )
        
        # Create SIMP broker integration
        print("[2/4] Creating SIMP broker integration...")
        self.broker_integration = create_simp_broker_integration(
            broker_url=self.broker_url,
            api_key=self.api_key,
            autonomous_controller=self.autonomous_controller
        )
        
        # Register with broker
        print("[3/4] Registering with SIMP broker...")
        registered = await self.broker_integration.register_with_broker()
        
        if registered:
            print("  ✓ Registered with broker")
        else:
            print("  ⚠️ Could not register (broker may not be running)")
            print("     Continuing in standalone mode...")
        
        # Start heartbeat loop
        print("[4/4] Starting heartbeat loop...")
        self.heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        
        # Start workflow scheduler
        self.workflow_scheduler_task = asyncio.create_task(self._workflow_scheduler())
        
        self.is_running = True
        
        print("\n" + "="*60)
        print("✅ Media Grid Integration Running")
        print("="*60)
        
        # Print status
        health = self.autonomous_controller.get_health_status()
        print(f"\nHealth Status: {health['status']}")
        print(f"Components:")
        for comp, status in health['components'].items():
            print(f"  - {comp}: {'✅' if status else '❌'}")
        
        return True
    
    async def stop(self) -> bool:
        """Stop the media grid integration."""
        print("\n" + "="*60)
        print("Stopping Media Grid Integration")
        print("="*60)
        
        self.is_running = False
        
        # Cancel tasks
        if self.heartbeat_task:
            self.heartbeat_task.cancel()
        if self.workflow_scheduler_task:
            self.workflow_scheduler_task.cancel()
        
        # Send final heartbeat
        if self.broker_integration:
            await self.broker_integration.send_heartbeat()
        
        print("✅ Integration stopped")
        return True
    
    async def _heartbeat_loop(self) -> None:
        """Send periodic heartbeats to broker."""
        while self.is_running:
            try:
                await asyncio.sleep(60)  # Every 60 seconds
                
                if self.broker_integration:
                    success = await self.broker_integration.send_heartbeat()
                    if success:
                        print(".", end="", flush=True)
                    else:
                        print("⚠️", end="", flush=True)
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"\nHeartbeat error: {e}")
    
    async def _workflow_scheduler(self) -> None:
        """Schedule periodic workflow triggers."""
        while self.is_running:
            try:
                # Check for scheduled workflows every 5 minutes
                await asyncio.sleep(300)
                
                if self.autonomous_controller and self.autonomous_controller.workflow_engine:
                    # Trigger trend ingestion check
                    await self.autonomous_controller.workflow_engine.trigger_workflow(
                        workflow_type="trend_ingestion",
                        trigger=IntentType.TREND_ANALYSIS.value,
                        params={"scheduled": True}
                    )
                    print("\n📊 Scheduled workflow: trend_ingestion")
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"\nWorkflow scheduler error: {e}")
    
    # =========================================================================
    # Intent Handlers (triggered by broker)
    # =========================================================================
    
    async def handle_launch_channel(self, payload: Dict) -> Dict:
        """Handle launch_channel intent."""
        return await self.autonomous_controller.launch_channel_autonomous(
            brand_name=payload.get("brand_name"),
            platforms=payload.get("platforms", ["tiktok", "youtube", "instagram", "x"])
        )
    
    async def handle_create_account(self, payload: Dict) -> Dict:
        """Handle create_account intent."""
        from simp.organs.media.platform_oauth_manager import Platform
        
        platform = Platform(payload.get("platform", "tiktok"))
        
        result = await self.autonomous_controller.oauth_manager.create_account(
            platform=platform,
            brand_name=payload.get("brand_name", "new_account"),
            use_browser_automation=payload.get("use_browser", True)
        )
        
        return {
            "success": result.success,
            "account_id": result.account_id,
            "username": result.username
        }
    
    async def handle_compliance_check(self, payload: Dict) -> Dict:
        """Handle compliance_check intent."""
        from simp.organs.media.orchestration import MediaGridOrchestrator
        
        orchestrator = MediaGridOrchestrator()
        await orchestrator.initialize()
        
        result = await orchestrator.execute_compliance_monitor_workflow(
            content=payload.get("content"),
            pre_publish=payload.get("pre_publish", True)
        )
        
        return result
    
    # =========================================================================
    # Manual Triggers
    # =========================================================================
    
    async def launch_channel(self, brand_name: str, platforms: List[str]) -> Dict:
        """Manually launch a new channel."""
        return await self.autonomous_controller.launch_channel_autonomous(
            brand_name=brand_name,
            platforms=platforms
        )
    
    async def get_status(self) -> Dict:
        """Get current system status."""
        return {
            "is_running": self.is_running,
            "autonomous": self.autonomous_controller.get_health_status() if self.autonomous_controller else None,
            "broker_metrics": self.broker_integration.get_metrics() if self.broker_integration else None
        }
    
    async def get_accounts(self) -> List[Dict]:
        """Get all registered accounts."""
        if self.autonomous_controller:
            return self.autonomous_controller.oauth_manager.get_all_accounts()
        return []


# =============================================================================
# CLI Interface
# =============================================================================

async def run_integration():
    """Run the media grid integration."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Media Grid Integration with SIMP Broker")
    parser.add_argument("--broker-url", default="http://127.0.0.1:5555", help="SIMP broker URL")
    parser.add_argument("--api-key", default="", help="API key for broker")
    parser.add_argument("--agent-id", default="media_grid_orchestrator", help="Agent ID")
    parser.add_argument("--launch", help="Launch a channel with brand name")
    parser.add_argument("--platforms", nargs="+", default=["tiktok", "youtube", "instagram", "x"],
                        help="Platforms for channel launch")
    parser.add_argument("--status", action="store_true", help="Show current status")
    parser.add_argument("--accounts", action="store_true", help="List all accounts")
    
    args = parser.parse_args()
    
    # Create integration
    integration = MediaGridIntegration(
        broker_url=args.broker_url,
        api_key=args.api_key,
        agent_id=args.agent_id
    )
    
    # Handle CLI commands
    if args.launch:
        print(f"\n🚀 Launching channel: {args.launch}")
        print(f"   Platforms: {args.platforms}")
        
        # Initialize autonomous controller
        integration.autonomous_controller = create_autonomous_controller("data/media")
        
        result = await integration.launch_channel(args.launch, args.platforms)
        
        print(f"\nResult:")
        print(f"  Brand: {result['brand_name']}")
        print(f"  Workflow ID: {result['workflow_id']}")
        print(f"  Accounts:")
        for platform, data in result['platforms'].items():
            status = "✅" if data.get('success') else "❌"
            acc_id = data.get('account_id', 'N/A')
            print(f"    {status} {platform}: {acc_id}")
        
    elif args.status:
        status = await integration.get_status()
        print(f"\nStatus:")
        print(f"  Running: {status['is_running']}")
        if status['autonomous']:
            print(f"  Autonomous health: {status['autonomous']['status']}")
    
    elif args.accounts:
        integration.autonomous_controller = create_autonomous_controller("data/media")
        accounts = await integration.get_accounts()
        print(f"\nAccounts ({len(accounts)}):")
        for acc in accounts:
            print(f"  - {acc.get('platform')}: {acc.get('username')} ({acc.get('account_id')})")
    
    else:
        # Start in server mode
        await integration.start()
        
        print("\n" + "="*60)
        print("Press Ctrl+C to stop")
        print("="*60)
        
        # Wait for interrupt
        try:
            while integration.is_running:
                await asyncio.sleep(1)
        except KeyboardInterrupt:
            pass
        
        await integration.stop()


def main():
    """Main entry point."""
    asyncio.run(run_integration())


if __name__ == "__main__":
    main()
