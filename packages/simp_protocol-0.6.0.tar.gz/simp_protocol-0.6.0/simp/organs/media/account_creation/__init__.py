"""
Account Creation Pipeline for Autonomous Media Empire.

Wires together:
- ComputerUseToolkit (browser automation for account creation flows)
- PlatformOAuthManager (OAuth token management)
- PlatformConnectors (API-based posting after account creation)

Supports: TikTok, YouTube, Instagram, X (Twitter)
"""
from simp.organs.media.account_creation.account_creator import (
    AccountCreator,
    AccountCreationRequest,
    AccountCreationResult,
    AccountProfile,
    PlatformCredentials,
    create_account_creator
)
from simp.organs.media.account_creation.platform_connectors import (
    PlatformConnector,
    TikTokConnector,
    YouTubeConnector,
    InstagramConnector,
    XConnector,
    create_connector
)

__version__ = "0.1.0"
__all__ = [
    "AccountCreator",
    "AccountCreationRequest",
    "AccountCreationResult",
    "AccountProfile",
    "PlatformCredentials",
    "create_account_creator",
    "PlatformConnector",
    "TikTokConnector",
    "YouTubeConnector",
    "InstagramConnector",
    "XConnector",
    "create_connector"
]
