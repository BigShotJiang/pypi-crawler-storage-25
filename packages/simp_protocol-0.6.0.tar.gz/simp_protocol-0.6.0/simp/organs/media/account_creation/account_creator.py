"""
Account Creator - Autonomous Social Account Instantiation.

Wires ComputerUseToolkit + OAuthManager + PlatformConnectors to:
1. Create accounts via browser automation (first account on platform)
2. Complete OAuth flows for API access
3. Return credentials for subsequent API-based operations
"""
import asyncio
import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
import logging

from simp.organs.media.computer_use_tools import (
    ComputerUseToolkit, create_computer_use_toolkit, ComputerToolResult
)
from simp.organs.media.platform_oauth_manager import (
    PlatformOAuthManager, Platform, create_oauth_manager, OAuthState
)


class AccountCreationMethod(Enum):
    """Method used to create account."""
    BROWSER_AUTOMATION = "browser_automation"  # Use computer use to fill forms
    API_CREATION = "api_creation"  # Platform API directly
    OAUTH_FLOW = "oauth_flow"  # OAuth sign-up flow


class CreationStatus(Enum):
    """Status of account creation."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    AWAITING_VERIFICATION = "awaiting_verification"  # Email/phone verification needed
    COMPLETED = "completed"
    FAILED = "failed"
    NEEDS_HUMAN_REVIEW = "needs_human_review"


@dataclass
class AccountCreationRequest:
    """Request to create a new social account."""
    platform: Platform
    brand_name: str
    brand_handle: str
    email: str
    phone: Optional[str] = None
    bio: str = ""
    profile_image_path: Optional[str] = None
    category: str = "tech"  # Content category
    business_type: str = "personal"  # personal, business, creator
    
    # OAuth config
    redirect_uri: str = "http://localhost:8765/oauth/callback"
    
    # Creation method preference
    preferred_method: AccountCreationMethod = AccountCreationMethod.BROWSER_AUTOMATION


@dataclass
class AccountProfile:
    """Created account profile data."""
    platform: Platform
    account_id: str  # Platform's internal ID
    username: str
    handle: str
    display_name: str
    bio: str
    profile_image_url: Optional[str] = None
    followers_count: int = 0
    verified: bool = False
    business_account: bool = False
    created_at: Optional[str] = None


@dataclass
class PlatformCredentials:
    """OAuth/API credentials for account access."""
    platform: Platform
    access_token: str
    refresh_token: Optional[str] = None
    token_type: str = "Bearer"
    expires_at: Optional[float] = None
    scope: List[str] = field(default_factory=list)
    
    # API credentials (for platforms that use API keys)
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    
    # Account metadata
    user_id: Optional[str] = None
    account_id: Optional[str] = None


@dataclass
class AccountCreationResult:
    """Result of account creation attempt."""
    success: bool
    status: CreationStatus
    profile: Optional[AccountProfile] = None
    credentials: Optional[PlatformCredentials] = None
    session_id: Optional[str] = None
    error: Optional[str] = None
    verification_url: Optional[str] = None
    steps_completed: List[str] = field(default_factory=list)
    execution_time_seconds: float = 0.0


class AccountCreator:
    """
    Autonomous account creation pipeline.
    
    Orchestrates browser automation + OAuth to create social accounts.
    """
    
    def __init__(
        self,
        data_dir: str = "data/media/accounts",
        computer_use: Optional[ComputerUseToolkit] = None,
        oauth_manager: Optional[PlatformOAuthManager] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("media.account_creator")
        
        # Core components
        self.computer_use = computer_use or create_computer_use_toolkit(str(self.data_dir))
        self.oauth_manager = oauth_manager or create_oauth_manager(str(self.data_dir))
        
        # Account state storage
        self._accounts_file = self.data_dir / "accounts.json"
        self._accounts: Dict[str, Dict] = {}
        self._load_accounts()
    
    def _load_accounts(self) -> None:
        """Load existing accounts from disk."""
        if self._accounts_file.exists():
            with open(self._accounts_file) as f:
                self._accounts = json.load(f)
    
    def _save_accounts(self) -> None:
        """Save accounts to disk."""
        with open(self._accounts_file, "w") as f:
            json.dump(self._accounts, f, indent=2)
    
    async def initialize(self) -> bool:
        """Initialize browser and OAuth components."""
        await self.computer_use.initialize()
        return True
    
    async def create_account(
        self,
        request: AccountCreationRequest
    ) -> AccountCreationResult:
        """
        Create a new social account.
        
        Flow:
        1. Start browser session
        2. Navigate to signup page
        3. Fill form with brand details
        4. Complete OAuth for API access
        5. Store credentials
        """
        start_time = time.time()
        session_id = await self.computer_use.create_browser_session(headless=False)
        
        result = AccountCreationResult(
            success=False,
            status=CreationStatus.IN_PROGRESS,
            session_id=session_id
        )
        
        try:
            # Step 1: Navigate to signup
            signup_url = self._get_signup_url(request.platform)
            step_result = await self.computer_use.browse_url(session_id, signup_url)
            result.steps_completed.append("navigate_to_signup")
            
            if not step_result.success:
                result.status = CreationStatus.FAILED
                result.error = f"Failed to navigate to signup: {step_result.error}"
                return result
            
            # Step 2: Fill signup form
            if request.preferred_method == AccountCreationMethod.BROWSER_AUTOMATION:
                fill_result = await self._fill_signup_form(session_id, request)
                result.steps_completed.append("fill_signup_form")
                
                if not fill_result.success:
                    if "verification" in str(fill_result.error).lower():
                        result.status = CreationStatus.AWAITING_VERIFICATION
                        result.verification_url = fill_result.output
                    else:
                        result.status = CreationStatus.NEEDS_HUMAN_REVIEW
                        result.error = fill_result.error
                    return result
            
            # Step 3: Complete OAuth flow
            oauth_result = await self._complete_oauth_flow(session_id, request)
            result.steps_completed.append("oauth_flow")
            
            if oauth_result.success:
                result.credentials = oauth_result.credentials
                result.profile = oauth_result.profile
            
            # Step 4: Extract profile info
            profile_result = await self._extract_profile(session_id, request.platform)
            if profile_result.success:
                result.profile = profile_result.profile
            
            result.status = CreationStatus.COMPLETED
            result.success = True
            
            # Save account data
            self._save_account(request, result)
            
        except Exception as e:
            self.logger.error(f"Account creation failed: {e}")
            result.status = CreationStatus.FAILED
            result.error = str(e)
        finally:
            result.execution_time_seconds = time.time() - start_time
            await self.computer_use.close_session(session_id)
        
        return result
    
    def _get_signup_url(self, platform: Platform) -> str:
        """Get signup URL for platform."""
        urls = {
            Platform.TIKTOK: "https://www.tiktok.com/signup",
            Platform.YOUTUBE: "https://accounts.google.com/signup",
            Platform.INSTAGRAM: "https://www.instagram.com/accounts/emailsignup/",
            Platform.X: "https://x.com/i/flow/signup",
        }
        return urls.get(platform, "")
    
    async def _fill_signup_form(
        self,
        session_id: str,
        request: AccountCreationRequest
    ) -> ComputerToolResult:
        """Fill the signup form for the platform."""
        # Platform-specific form filling
        platform_methods = {
            Platform.TIKTOK: self._fill_tiktok_signup,
            Platform.YOUTUBE: self._fill_youtube_signup,
            Platform.INSTAGRAM: self._fill_instagram_signup,
            Platform.X: self._fill_x_signup,
        }
        
        fill_method = platform_methods.get(request.platform)
        if fill_method:
            return await fill_method(session_id, request)
        
        return ComputerToolResult(
            tool="fill_signup_form",
            success=False,
            error=f"No fill method for platform {request.platform}"
        )
    
    async def _fill_tiktok_signup(
        self,
        session_id: str,
        request: AccountCreationRequest
    ) -> ComputerToolResult:
        """Fill TikTok signup form."""
        # Type email
        await self.computer_use.type_text(session_id, '[data-testid="email-input"]', request.email)
        await asyncio.sleep(0.5)
        
        # Click continue
        await self.computer_use.click_element(session_id, '[data-testid="submit-button"]')
        await asyncio.sleep(2)
        
        # Type date of birth if prompted
        # (simplified - real implementation would handle date picker)
        
        return ComputerToolResult(
            tool="fill_tiktok_signup",
            success=True,
            output={"form_filled": True}
        )
    
    async def _fill_youtube_signup(
        self,
        session_id: str,
        request: AccountCreationRequest
    ) -> ComputerToolResult:
        """Fill YouTube/Google signup form."""
        await self.computer_use.type_text(session_id, '#username', request.brand_handle)
        await asyncio.sleep(0.3)
        
        return ComputerToolResult(
            tool="fill_youtube_signup",
            success=True,
            output={"form_filled": True}
        )
    
    async def _fill_instagram_signup(
        self,
        session_id: str,
        request: AccountCreationRequest
    ) -> ComputerToolResult:
        """Fill Instagram signup form."""
        await self.computer_use.type_text(session_id, 'input[name="emailOrPhone"]', request.email)
        await asyncio.sleep(0.3)
        await self.computer_use.type_text(session_id, 'input[name="fullName"]', request.brand_name)
        await asyncio.sleep(0.3)
        await self.computer_use.type_text(session_id, 'input[name="username"]', request.brand_handle)
        await asyncio.sleep(0.3)
        
        return ComputerToolResult(
            tool="fill_instagram_signup",
            success=True,
            output={"form_filled": True}
        )
    
    async def _fill_x_signup(
        self,
        session_id: str,
        request: AccountCreationRequest
    ) -> ComputerToolResult:
        """Fill X (Twitter) signup form."""
        await self.computer_use.type_text(session_id, 'input[name="name"]', request.brand_name)
        await asyncio.sleep(0.3)
        await self.computer_use.type_text(session_id, 'input[name="email"]', request.email)
        await asyncio.sleep(0.3)
        
        return ComputerToolResult(
            tool="fill_x_signup",
            success=True,
            output={"form_filled": True}
        )
    
    async def _complete_oauth_flow(
        self,
        session_id: str,
        request: AccountCreationRequest
    ) -> AccountCreationResult:
        """Complete OAuth flow to get API credentials."""
        oauth_state = OAuthState(
            state=str(uuid.uuid4()),
            platform=request.platform,
            redirect_uri=request.redirect_uri,
            scope=self._get_oauth_scope(request.platform)
        )
        
        # Start OAuth flow
        auth_url = self.oauth_manager.get_authorization_url(request.platform, oauth_state)
        await self.computer_use.browse_url(session_id, auth_url)
        
        # OAuth will redirect to callback - capture the code
        current_url = await self.computer_use.get_current_url(session_id)
        
        # Exchange code for tokens (simplified)
        # Real implementation would parse the callback URL
        result = AccountCreationResult(
            success=True,
            status=CreationStatus.COMPLETED,
            credentials=PlatformCredentials(
                platform=request.platform,
                access_token="placeholder_token",
                scope=oauth_state.scope
            )
        )
        
        return result
    
    def _get_oauth_scope(self, platform: Platform) -> List[str]:
        """Get OAuth scope for platform."""
        scopes = {
            Platform.TIKTOK: ["user.info.basic", "video.upload", "video.publish"],
            Platform.YOUTUBE: ["youtube.upload", "youtube.read_channel", "yt-analytics.readonly"],
            Platform.INSTAGRAM: ["user_profile", "user_media"],
            Platform.X: ["tweet.read", "tweet.write", "users.read", "offline.access"],
        }
        return scopes.get(platform, [])
    
    async def _extract_profile(
        self,
        session_id: str,
        platform: Platform
    ) -> ComputerToolResult:
        """Extract profile info from the created account."""
        # Get page content and parse profile
        snapshot = await self.computer_use.get_page_snapshot(session_id)
        
        profile = AccountProfile(
            platform=platform,
            account_id=str(uuid.uuid4()),
            username="extracted_username",
            handle="extracted_handle",
            display_name="Extracted Name",
            bio=""
        )
        
        return ComputerToolResult(
            tool="extract_profile",
            success=True,
            output={"profile": profile.__dict__}
        )
    
    def _save_account(
        self,
        request: AccountCreationRequest,
        result: AccountCreationResult
    ) -> None:
        """Save account data to disk."""
        account_id = str(uuid.uuid4())
        
        account_data = {
            "account_id": account_id,
            "platform": request.platform.value,
            "brand_name": request.brand_name,
            "brand_handle": request.brand_handle,
            "email": request.email,
            "profile": result.profile.__dict__ if result.profile else None,
            "credentials": {
                "access_token": result.credentials.access_token if result.credentials else None,
                "token_type": result.credentials.token_type if result.credentials else None,
                "expires_at": result.credentials.expires_at if result.credentials else None,
                "scope": result.credentials.scope if result.credentials else [],
            },
            "status": result.status.value,
            "created_at": datetime.now().isoformat(),
        }
        
        self._accounts[account_id] = account_data
        self._save_accounts()
    
    async def get_account(
        self,
        platform: Platform,
        brand_handle: str
    ) -> Optional[Dict]:
        """Get existing account by platform and handle."""
        for account in self._accounts.values():
            if account["platform"] == platform.value and account["brand_handle"] == brand_handle:
                return account
        return None
    
    async def list_accounts(
        self,
        platform: Optional[Platform] = None
    ) -> List[Dict]:
        """List all accounts, optionally filtered by platform."""
        accounts = list(self._accounts.values())
        if platform:
            accounts = [a for a in accounts if a["platform"] == platform.value]
        return accounts


def create_account_creator(
    data_dir: str = "data/media/accounts"
) -> AccountCreator:
    """Factory function to create AccountCreator."""
    return AccountCreator(data_dir=data_dir)
