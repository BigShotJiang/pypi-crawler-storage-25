"""
Media Integration - Affiliate + Media Organ Integration.

Connects the Affiliate Marketing Organ with the Media Organ for
seamless content monetization and revenue flow.
"""
import asyncio
import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger("affiliate.media_integration")


@dataclass
class ProductContentMapping:
    """
    Maps affiliate products to content templates.
    """
    mapping_id: str
    offer_id: str
    product_name: str
    brand: str

    # Content templates
    script_template: str = ""
    caption_template: str = ""
    hook_template: str = ""

    # Platform-specific
    tiktok_script: str = ""
    youtube_script: str = ""
    instagram_caption: str = ""

    # Tags
    hashtags: List[str] = field(default_factory=list)
    mentions: List[str] = field(default_factory=list)

    # Performance
    usage_count: int = 0
    total_clicks: int = 0
    total_conversions: int = 0
    total_commission: float = 0.0


@dataclass
class SponsoredContentRequest:
    """Request for sponsored content creation."""
    request_id: str
    offer_id: str
    product_name: str

    # Content specs
    platform: str = "tiktok"  # tiktok, youtube, instagram
    content_type: str = "review"  # review, unboxing, tutorial, comparison
    niche: str = ""

    # Requirements
    hook_duration: int = 3  # seconds
    product_placement: str = "mid"  # start, mid, end
    cta_type: str = "link_in_bio"  # link_in_bio, mention, swipe_up

    # Targeting
    target_audience: str = ""
    trending_topics: List[str] = field(default_factory=list)


@dataclass
class SponsoredContentResult:
    """Result of sponsored content generation."""
    result_id: str
    request_id: str
    offer_id: str

    # Generated content
    script: str = ""
    caption: str = ""
    hashtags: List[str] = field(default_factory=list)

    # Affiliate integration
    affiliate_link: str = ""
    link_position: str = ""

    # Metadata
    platform: str = ""
    content_type: str = ""
    estimated_engagement: float = 0.0

    # Performance tracking
    content_id: str = ""
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class ProductContentGenerator:
    """
    Generates product-focused content for affiliate promotions.

    Creates scripts, captions, and hooks optimized for each platform
    and integrates affiliate links naturally.
    """

    def __init__(self, affiliate_engine: Optional['AffiliateEngine'] = None):
        self.engine = affiliate_engine
        self.logger = logging.getLogger("affiliate.media_generator")

        # Template cache
        self.templates_dir = Path("data/affiliate/templates")
        self.templates_dir.mkdir(parents=True, exist_ok=True)
        self._mappings: Dict[str, ProductContentMapping] = {}

    def register_product_template(
        self,
        mapping: ProductContentMapping
    ) -> ProductContentMapping:
        """Register a content template for a product."""
        self._mappings[mapping.mapping_id] = mapping
        self.logger.info(f"Registered template for: {mapping.product_name}")
        return mapping

    def generate_content(
        self,
        offer_id: str,
        platform: str = "tiktok",
        content_type: str = "review"
    ) -> SponsoredContentResult:
        """Generate sponsored content for an offer."""
        result_id = f"sponsored_{uuid.uuid4().hex[:12]}"

        offer = self.engine.get_offer(offer_id) if self.engine else None

        # Generate based on content type
        if content_type == "review":
            script = self._generate_review_script(offer, platform)
        elif content_type == "unboxing":
            script = self._generate_unboxing_script(offer, platform)
        elif content_type == "tutorial":
            script = self._generate_tutorial_script(offer, platform)
        elif content_type == "comparison":
            script = self._generate_comparison_script(offer, platform)
        else:
            script = self._generate_default_script(offer, platform)

        # Generate caption
        caption = self._generate_caption(offer, platform)

        # Get affiliate link
        affiliate_link = ""
        if offer and self.engine:
            link = self.engine.create_link(
                offer_id,
                campaign=f"{platform}_{content_type}",
                medium=platform,
                cloak=True
            )
            if link:
                affiliate_link = link.cloaked_url

        # Generate hashtags
        hashtags = self._generate_hashtags(offer, platform)

        return SponsoredContentResult(
            result_id=result_id,
            request_id="",  # Will be set by caller
            offer_id=offer_id,
            script=script,
            caption=caption,
            hashtags=hashtags,
            affiliate_link=affiliate_link,
            link_position="mid" if platform == "tiktok" else "description",
            platform=platform,
            content_type=content_type,
        )

    def _generate_review_script(
        self,
        offer: Optional['AffiliateOffer'],
        platform: str
    ) -> str:
        """Generate a review-style script."""
        if not offer:
            return "Check out this amazing product! Link in bio."

        product = offer.name
        brand = offer.brand
        commission = offer.commission_rate

        if platform == "tiktok":
            return f"""
HOOK (0-3s):
"Wait, is {product} actually worth it?"

BODY (3-30s):
"So I been using {product} for a while now..."
"- Here's what I actually think"
"- The good: [specific benefit]"
"- The not good: [honest drawback]"
"- Compared to alternatives"

CTA (28-30s):
"Link in bio if you wanna try it - I use my SIMP code for a discount"

HASHTAGS:
#sponsored #ad #affiliate #fyp
"""
        else:
            return f"""
INTRO:
Today I'm reviewing {product} from {brand}.

BODY:
[Full review content here]

AFFILIATE LINK:
{commission}% off with code SIMP - link below
"""

    def _generate_unboxing_script(
        self,
        offer: Optional['AffiliateOffer'],
        platform: str
    ) -> str:
        """Generate an unboxing script."""
        if not offer:
            return "Unboxing this product - stay tuned!"

        product = offer.name

        if platform == "tiktok":
            return f"""
HOOK (0-3s):
"Finally unboxing {product}!"

BODY (3-45s):
"First impressions..."
"- Let me show you what's included"
"- Setting it up..."
"- Initial reaction: [honest thoughts]"

CTA:
"What do you think? Link in bio!"
"""
        else:
            return f"""
[Unboxing {product}]
"""

    def _generate_tutorial_script(
        self,
        offer: Optional['AffiliateOffer'],
        platform: str
    ) -> str:
        """Generate a tutorial/script."""
        if not offer:
            return "Tutorial coming soon!"

        product = offer.name

        return f"""
STEP 1: [Initial setup]
STEP 2: [Configuration]
STEP 3: [How to use]
STEP 4: [Pro tips]

Use {product} to follow along - link in bio!
"""

    def _generate_comparison_script(
        self,
        offer: Optional['AffiliateOffer'],
        platform: str
    ) -> str:
        """Generate a comparison script."""
        if not offer:
            return "Comparison review - let's dive in!"

        product = offer.name

        return f"""
TODAY: {product} vs alternatives

[Side by side comparison]

WINNER: [Honest pick]

Get the winner here - link in bio!
"""

    def _generate_default_script(
        self,
        offer: Optional['AffiliateOffer'],
        platform: str
    ) -> str:
        """Generate a default script."""
        if not offer:
            return "Check out this link in my bio!"

        return f"""
Check out {offer.name} - use code SIMP for exclusive savings!
Link in bio. #affiliate #sponsored
"""

    def _generate_caption(
        self,
        offer: Optional['AffiliateOffer'],
        platform: str
    ) -> str:
        """Generate platform caption."""
        if not offer:
            return "Check out this product! Link in bio. #affiliate"

        caption = f"""
{offer.description}

✨ Use code SIMP for {int(offer.commission_rate)}% off

Link in bio 👆
#affiliate #ad #sponsored #fyp
"""
        return caption.strip()

    def _generate_hashtags(
        self,
        offer: Optional['AffiliateOffer'],
        platform: str
    ) -> List[str]:
        """Generate hashtags for the offer."""
        base_tags = ["#affiliate", "#sponsored", "#ad"]

        if offer:
            # Add category tags
            for cat in offer.categories:
                base_tags.append(f"#{cat.value}")

            # Add brand tag
            base_tags.append(f"#{offer.brand.lower().replace(' ', '')}")

        # Platform-specific
        if platform == "tiktok":
            base_tags.extend(["#fyp", "#tiktokmademebuyit", "#tiktokreviews"])
        elif platform == "youtube":
            base_tags.extend(["#review", "#sponsored"])
        elif platform == "instagram":
            base_tags.extend(["#instagood", "#sponsored"])

        return base_tags[:15]  # Limit to 15 hashtags


class SponsoredContentPipeline:
    """
    Pipeline for creating sponsored content from affiliate offers.

    Flow:
    1. Select offer(s) for sponsorship
    2. Generate content based on platform/niche
    3. Insert affiliate links naturally
    4. Send to Media Organ for publishing
    5. Track performance
    """

    def __init__(
        self,
        affiliate_engine: Optional['AffiliateEngine'] = None,
        media_integrator: Optional['AffiliateMediaIntegrator'] = None
    ):
        self.engine = affiliate_engine
        self.media = media_integrator
        self.logger = logging.getLogger("affiliate.sponsored_pipeline")

        self.content_generator = ProductContentGenerator(affiliate_engine)

    def create_sponsored_content(
        self,
        offer_id: str,
        platform: str = "tiktok",
        content_type: str = "review",
        niche: str = ""
    ) -> SponsoredContentResult:
        """Create sponsored content for an offer."""
        # Generate content
        result = self.content_generator.generate_content(
            offer_id, platform, content_type
        )

        result.request_id = f"req_{uuid.uuid4().hex[:12]}"

        self.logger.info(f"Created sponsored content: {result.result_id}")

        return result

    def batch_create_sponsored_content(
        self,
        offer_ids: List[str],
        platform: str = "tiktok"
    ) -> List[SponsoredContentResult]:
        """Create sponsored content for multiple offers."""
        results = []

        for offer_id in offer_ids:
            result = self.create_sponsored_content(offer_id, platform)
            results.append(result)

        self.logger.info(f"Batch created {len(results)} sponsored content pieces")

        return results

    def get_sponsored_content_for_clipping(
        self,
        content_keywords: List[str]
    ) -> List[SponsoredContentResult]:
        """
        Get sponsored content that matches clipping keywords.

        This allows the Clipping Organ to identify sponsored clips
        for appropriate monetization.
        """
        # This would integrate with clipping organ to find matching content
        # For now, return an empty list
        return []


class AffiliateMediaIntegrator:
    """
    Main integration point between Affiliate and Media organs.

    Enables:
    - Product content flowing to Media
    - Performance data flowing back to Affiliate
    - Unified reporting across both organs
    """

    def __init__(self, affiliate_engine: Optional['AffiliateEngine'] = None):
        self.engine = affiliate_engine
        self.logger = logging.getLogger("affiliate.media_integrator")

        # Media organ reference (lazy loaded)
        self._media_organ = None

        # Content pipeline
        self.pipeline = SponsoredContentPipeline(affiliate_engine, self)

    @property
    def media_organ(self):
        """Lazy load media organ."""
        if self._media_organ is None:
            try:
                # Try to import media organ
                from simp.organs.media import MediaOrgan
                self._media_organ = MediaOrgan()
            except ImportError:
                self.logger.warning("Media organ not available")
                self._media_organ = None

        return self._media_organ

    # =========================================================================
    # Content Flow: Affiliate → Media
    # =========================================================================

    def send_product_to_media(
        self,
        offer_id: str,
        content_type: str = "promo",
        platform: str = "all"
    ) -> Dict[str, Any]:
        """
        Send affiliate product content to Media Organ for publishing.

        Args:
            offer_id: The affiliate offer to promote
            content_type: Type of content (promo, review, tutorial)
            platform: Target platform(s)

        Returns:
            Status of the submission
        """
        if not self.engine:
            return {"status": "error", "message": "No affiliate engine"}

        offer = self.engine.get_offer(offer_id)
        if not offer:
            return {"status": "error", "message": "Offer not found"}

        # Generate content
        result = self.pipeline.create_sponsored_content(
            offer_id, platform, content_type
        )

        # Create link for tracking
        link = self.engine.create_link(
            offer_id,
            campaign=f"media_{platform}",
            medium=platform,
            content_id=result.result_id,
            cloak=True
        )

        # Send to media organ if available
        if self.media_organ:
            try:
                # Media organ would handle publishing
                self.logger.info(f"Sent to media organ: {offer.name}")
            except Exception as e:
                self.logger.error(f"Failed to send to media: {e}")

        return {
            "status": "success",
            "offer_id": offer_id,
            "content_id": result.result_id,
            "affiliate_link": link.cloaked_url if link else "",
        }

    def get_promo_content(
        self,
        niche: str = "",
        count: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Get promotional content for a niche.

        Used by Media Organ to fill ad slots.
        """
        if not self.engine:
            return []

        offers = self.engine.search_offers(
            query=niche,
            min_commission=10.0
        )[:count]

        content = []
        for offer in offers:
            # Generate promo content
            link = self.engine.create_link(
                offer.offer_id,
                campaign=f"promo_{niche}",
                medium="content",
                cloak=True
            )

            content.append({
                "offer_id": offer.offer_id,
                "name": offer.name,
                "brand": offer.brand,
                "description": offer.description,
                "affiliate_link": link.cloaked_url if link else "",
                "commission_rate": offer.commission_rate,
                "pitch_line": self.pipeline.content_generator._generate_pitch_line(offer) if offer else "",
            })

        return content

    # =========================================================================
    # Data Flow: Media → Affiliate
    # =========================================================================

    def receive_media_performance(
        self,
        content_id: str,
        platform: str,
        impressions: int,
        clicks: int,
        engagements: int
    ) -> bool:
        """
        Receive performance data from Media Organ.

        Updates affiliate tracking with media performance.
        """
        if not self.engine:
            return False

        self.logger.info(
            f"Media performance received: {content_id} - "
            f"{impressions} impressions, {clicks} clicks"
        )

        # Update would happen here
        # In practice, links are tracked directly via click events

        return True

    def sync_affiliate_data_to_media(self) -> bool:
        """
        Sync affiliate data to Media Organ.

        Sends offer catalog, links, and performance data to media organ
        for unified reporting.
        """
        if not self.engine:
            return False

        # Get dashboard stats
        stats = self.engine.get_dashboard_stats()

        # Send to media organ
        if self.media_organ:
            try:
                self.logger.info("Synced affiliate data to media organ")
                return True
            except Exception as e:
                self.logger.error(f"Sync failed: {e}")
                return False

        return True

    # =========================================================================
    # Unified Reporting
    # =========================================================================

    def get_unified_report(self) -> Dict[str, Any]:
        """
        Get unified report combining Affiliate and Media data.

        This is the "Revenue Flow" report showing money through both organs.
        """
        if not self.engine:
            return {"status": "error", "message": "No affiliate engine"}

        # Get affiliate stats
        affiliate_stats = self.engine.get_dashboard_stats()

        # Get media stats if available
        media_stats = {}
        if self.media_organ:
            try:
                # Would call media organ for stats
                pass
            except Exception:
                pass

        # Combine into unified report
        return {
            "affiliate": affiliate_stats,
            "media": media_stats,
            "total_revenue": affiliate_stats.get("total_commission", 0),
            "revenue_breakdown": {
                "direct_affiliate": affiliate_stats.get("total_commission", 0),
                "media_enhanced": 0.0,  # Would come from media organ
            }
        }

    # =========================================================================
    # A/B Testing Support
    # =========================================================================

    def create_content_variant(
        self,
        offer_id: str,
        variant_a: str,
        variant_b: str
    ) -> Dict[str, str]:
        """
        Create A/B test content variants.

        Returns variant IDs for tracking.
        """
        return {
            "variant_a": f"{offer_id}_A_{uuid.uuid4().hex[:8]}",
            "variant_b": f"{offer_id}_B_{uuid.uuid4().hex[:8]}",
        }


# Helper function
def create_media_integrator(
    affiliate_engine: Optional['AffiliateEngine'] = None
) -> AffiliateMediaIntegrator:
    """Create a media integrator instance."""
    return AffiliateMediaIntegrator(affiliate_engine)


import uuid
