"""
Commission Tracker - Revenue Analytics and Payment Tracking.

Tracks commissions across all affiliate networks, calculates earnings,
and provides revenue reports for the Affiliate Marketing Organ.
"""
import json
import logging
import os
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger("affiliate.commission_tracker")


@dataclass
class CommissionRecord:
    """
    A single commission record.
    """
    record_id: str
    network: str
    offer_id: str
    offer_name: str
    brand: str

    # Commission details
    event_type: str = "sale"  # sale, lead, install, click
    amount: float = 0.0
    commission: float = 0.0
    currency: str = "USD"

    # Status
    status: str = "pending"  # pending, approved, rejected, paid
    approved_at: Optional[str] = None
    paid_at: Optional[str] = None

    # Attribution
    link_id: str = ""
    campaign: str = ""
    medium: str = ""
    source: str = ""
    content_id: str = ""

    # Metadata
    occurred_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    notes: str = ""


@dataclass
class RevenueReport:
    """
    Revenue report for a time period.
    """
    report_id: str
    period_start: str
    period_end: str
    period_type: str = "daily"  # daily, weekly, monthly

    # Totals
    total_revenue: float = 0.0
    total_commission: float = 0.0
    pending_commission: float = 0.0
    approved_commission: float = 0.0
    paid_commission: float = 0.0

    # Counts
    total_sales: int = 0
    total_leads: int = 0
    total_installs: int = 0
    total_clicks: int = 0

    # Averages
    avg_order_value: float = 0.0
    avg_commission_rate: float = 0.0
    conversion_rate: float = 0.0

    # Breakdown
    by_network: Dict[str, Dict] = field(default_factory=dict)
    by_offer: Dict[str, Dict] = field(default_factory=dict)
    by_campaign: Dict[str, Dict] = field(default_factory=dict)
    by_medium: Dict[str, Dict] = field(default_factory=dict)

    # Daily breakdown
    daily_revenue: List[Dict] = field(default_factory=list)


@dataclass
class PaymentSummary:
    """
    Summary of payments due or received.
    """
    summary_id: str
    period: str

    # Amounts
    total_due: float = 0.0
    total_paid: float = 0.0
    pending_payment: float = 0.0

    # By network
    by_network: Dict[str, float] = field(default_factory=dict)

    # Payment details
    payment_method: str = ""
    minimum_threshold: float = 0.0
    next_payment_date: Optional[str] = None

    # Records
    records: List[CommissionRecord] = field(default_factory=list)


class CommissionTracker:
    """
    Tracks commissions across all affiliate networks.

    Features:
    - Real-time commission tracking
    - Multi-network aggregation
    - Revenue reporting by period, campaign, network
    - Payment tracking and summaries
    - Trend analysis
    """

    def __init__(
        self,
        data_dir: str = "data/affiliate/commissions",
        affiliate_engine: Optional['AffiliateEngine'] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.engine = affiliate_engine
        self.logger = logging.getLogger("affiliate.commission_tracker")

        # Subdirectories
        self.records_dir = self.data_dir / "records"
        self.reports_dir = self.data_dir / "reports"
        self.records_dir.mkdir(exist_ok=True)
        self.reports_dir.mkdir(exist_ok=True)

        # In-memory records
        self._records: Dict[str, CommissionRecord] = {}
        self._load_records()

    def _load_records(self):
        """Load commission records from disk."""
        records_file = self.records_dir / "commissions.json"

        if records_file.exists():
            with open(records_file) as f:
                data = json.load(f)
                for record_id, record_data in data.items():
                    try:
                        record = CommissionRecord(**record_data)
                        self._records[record_id] = record
                    except Exception:
                        pass

    def _save_records(self):
        """Save commission records to disk."""
        records_file = self.records_dir / "commissions.json"
        data = {k: v.__dict__ for k, v in self._records.items()}

        with open(records_file, "w") as f:
            json.dump(data, f, indent=2)

    # =========================================================================
    # Commission Recording
    # =========================================================================

    def record_commission(
        self,
        network: str,
        offer_id: str,
        offer_name: str,
        brand: str,
        event_type: str = "sale",
        amount: float = 0.0,
        commission: float = 0.0,
        status: str = "pending",
        link_id: str = "",
        campaign: str = "",
        medium: str = "",
        source: str = "",
        content_id: str = "",
        occurred_at: Optional[str] = None,
        notes: str = ""
    ) -> CommissionRecord:
        """Record a new commission."""
        record_id = f"rec_{uuid.uuid4().hex[:12]}"

        record = CommissionRecord(
            record_id=record_id,
            network=network,
            offer_id=offer_id,
            offer_name=offer_name,
            brand=brand,
            event_type=event_type,
            amount=amount,
            commission=commission,
            status=status,
            link_id=link_id,
            campaign=campaign,
            medium=medium,
            source=source,
            content_id=content_id,
            occurred_at=occurred_at or datetime.utcnow().isoformat(),
            notes=notes,
        )

        self._records[record_id] = record
        self._save_records()

        self.logger.info(f"Recorded commission: {record_id} - ${commission}")

        return record

    def get_record(self, record_id: str) -> Optional[CommissionRecord]:
        """Get a commission record by ID."""
        return self._records.get(record_id)

    def update_record_status(
        self,
        record_id: str,
        status: str,
        notes: str = ""
    ) -> bool:
        """Update the status of a commission record."""
        record = self._records.get(record_id)
        if not record:
            return False

        record.status = status

        if status == "approved":
            record.approved_at = datetime.utcnow().isoformat()
        elif status == "paid":
            record.paid_at = datetime.utcnow().isoformat()

        if notes:
            record.notes = notes

        self._save_records()

        self.logger.info(f"Updated commission status: {record_id} -> {status}")

        return True

    # =========================================================================
    # Reporting
    # =========================================================================

    def generate_report(
        self,
        period_start: str,
        period_end: str,
        period_type: str = "daily"
    ) -> RevenueReport:
        """
        Generate a revenue report for a period.

        Args:
            period_start: Start date (ISO format)
            period_end: End date (ISO format)
            period_type: daily, weekly, monthly

        Returns:
            RevenueReport with all metrics
        """
        report_id = f"rpt_{uuid.uuid4().hex[:12]}"

        # Filter records in period
        records = [
            r for r in self._records.values()
            if period_start <= r.occurred_at <= period_end
        ]

        # Calculate totals
        total_amount = sum(r.amount for r in records)
        total_commission = sum(r.commission for r in records)
        pending = sum(r.commission for r in records if r.status == "pending")
        approved = sum(r.commission for r in records if r.status == "approved")
        paid = sum(r.commission for r in records if r.status == "paid")

        # Count by event type
        sales = sum(1 for r in records if r.event_type == "sale")
        leads = sum(1 for r in records if r.event_type == "lead")
        installs = sum(1 for r in records if r.event_type == "install")
        clicks = sum(1 for r in records if r.event_type == "click")

        # Averages
        avg_order_value = total_amount / sales if sales > 0 else 0.0
        avg_commission_rate = (total_commission / total_amount * 100) if total_amount > 0 else 0.0
        conversion_rate = (sales / clicks * 100) if clicks > 0 else 0.0

        # By network breakdown
        by_network: Dict[str, Dict] = defaultdict(lambda: {"amount": 0, "commission": 0, "count": 0})
        for r in records:
            by_network[r.network]["amount"] += r.amount
            by_network[r.network]["commission"] += r.commission
            by_network[r.network]["count"] += 1

        # By offer breakdown
        by_offer: Dict[str, Dict] = defaultdict(lambda: {"amount": 0, "commission": 0, "count": 0})
        for r in records:
            by_offer[r.offer_name]["amount"] += r.amount
            by_offer[r.offer_name]["commission"] += r.commission
            by_offer[r.offer_name]["count"] += 1

        # By campaign breakdown
        by_campaign: Dict[str, Dict] = defaultdict(lambda: {"amount": 0, "commission": 0, "count": 0})
        for r in records:
            if r.campaign:
                by_campaign[r.campaign]["amount"] += r.amount
                by_campaign[r.campaign]["commission"] += r.commission
                by_campaign[r.campaign]["count"] += 1

        # By medium breakdown
        by_medium: Dict[str, Dict] = defaultdict(lambda: {"amount": 0, "commission": 0, "count": 0})
        for r in records:
            if r.medium:
                by_medium[r.medium]["amount"] += r.amount
                by_medium[r.medium]["commission"] += r.commission
                by_medium[r.medium]["count"] += 1

        # Daily breakdown
        daily_revenue = self._calculate_daily_breakdown(
            records, period_start, period_end
        )

        report = RevenueReport(
            report_id=report_id,
            period_start=period_start,
            period_end=period_end,
            period_type=period_type,
            total_revenue=total_amount,
            total_commission=total_commission,
            pending_commission=pending,
            approved_commission=approved,
            paid_commission=paid,
            total_sales=sales,
            total_leads=leads,
            total_installs=installs,
            total_clicks=clicks,
            avg_order_value=avg_order_value,
            avg_commission_rate=avg_commission_rate,
            conversion_rate=conversion_rate,
            by_network=dict(by_network),
            by_offer=dict(by_offer),
            by_campaign=dict(by_campaign),
            by_medium=dict(by_medium),
            daily_revenue=daily_revenue,
        )

        self.logger.info(f"Generated report: {report_id}")

        return report

    def _calculate_daily_breakdown(
        self,
        records: List[CommissionRecord],
        start_date: str,
        end_date: str
    ) -> List[Dict]:
        """Calculate daily revenue breakdown."""
        # Parse dates
        start = datetime.fromisoformat(start_date)
        end = datetime.fromisoformat(end_date)

        # Build daily buckets
        daily = []
        current = start

        while current <= end:
            date_str = current.date().isoformat()
            day_records = [
                r for r in records
                if r.occurred_at.startswith(date_str)
            ]

            daily.append({
                "date": date_str,
                "revenue": sum(r.amount for r in day_records),
                "commission": sum(r.commission for r in day_records),
                "sales": sum(1 for r in day_records if r.event_type == "sale"),
            })

            current += timedelta(days=1)

        return daily

    def get_payment_summary(
        self,
        networks: Optional[List[str]] = None,
        threshold: float = 0.0
    ) -> PaymentSummary:
        """
        Get payment summary for networks.

        Shows how much is due and pending for payment.
        """
        summary_id = f"pay_{uuid.uuid4().hex[:12]}"

        # Filter records pending or approved
        records = [
            r for r in self._records.values()
            if r.status in ["approved", "pending"]
        ]

        if networks:
            records = [r for r in records if r.network in networks]

        # Calculate totals
        total_due = sum(r.commission for r in records if r.status == "pending")
        total_paid = sum(r.commission for r in records if r.status == "approved")
        pending_payment = total_paid  # Approved but not yet paid

        # By network
        by_network: Dict[str, float] = defaultdict(float)
        for r in records:
            by_network[r.network] += r.commission

        # Network-specific thresholds
        network_thresholds = {
            "clickbank": 50.0,
            "shareasale": 50.0,
            "awin": 50.0,
            "cj_affiliate": 50.0,
        }

        # Calculate next payment date (simplified - monthly)
        today = datetime.utcnow()
        if today.day >= 25:
            next_payment_date = (today.replace(day=1) + timedelta(days=32)).replace(day=1).isoformat()
        else:
            next_payment_date = today.replace(day=1).isoformat()

        summary = PaymentSummary(
            summary_id=summary_id,
            period="monthly",
            total_due=total_due,
            total_paid=total_paid,
            pending_payment=pending_payment,
            by_network=dict(by_network),
            minimum_threshold=threshold or 50.0,
            next_payment_date=next_payment_date,
            records=records[:50],  # Limit for display
        )

        return summary

    # =========================================================================
    # Analytics
    # =========================================================================

    def get_top_performers(
        self,
        period_start: Optional[str] = None,
        period_end: Optional[str] = None,
        limit: int = 10,
        by: str = "commission"  # commission, sales, clicks
    ) -> List[Dict]:
        """
        Get top performing offers/campaigns/media.

        Args:
            period_start: Optional period filter
            period_end: Optional period filter
            limit: Number to return
            by: Metric to sort by

        Returns:
            List of top performers
        """
        records = list(self._records.values())

        if period_start and period_end:
            records = [
                r for r in records
                if period_start <= r.occurred_at <= period_end
            ]

        # Group by offer
        by_offer = defaultdict(lambda: {"commission": 0, "sales": 0, "clicks": 0})
        for r in records:
            key = r.offer_name
            by_offer[key]["commission"] += r.commission
            if r.event_type == "sale":
                by_offer[key]["sales"] += 1

        # Sort and return top N
        sorted_offers = sorted(
            by_offer.items(),
            key=lambda x: x[1][by],
            reverse=True
        )

        return [
            {
                "offer_name": name,
                "network": next((r.network for r in records if r.offer_name == name), "unknown"),
                "total_commission": data["commission"],
                "total_sales": data["sales"],
            }
            for name, data in sorted_offers[:limit]
        ]

    def get_trend_analysis(
        self,
        periods: int = 6,
        period_type: str = "weekly"
    ) -> Dict[str, Any]:
        """
        Get trend analysis over multiple periods.

        Args:
            periods: Number of periods to analyze
            period_type: daily, weekly, monthly

        Returns:
            Trend analysis data
        """
        end_date = datetime.utcnow()

        if period_type == "daily":
            period_delta = timedelta(days=1)
            date_format = "%Y-%m-%d"
        elif period_type == "weekly":
            period_delta = timedelta(weeks=1)
            date_format = "%Y-W%W"
        else:
            period_delta = timedelta(days=30)
            date_format = "%Y-%m"

        trend_data = []
        current_start = end_date - (period_delta * periods)

        for i in range(periods):
            period_end = current_start + period_delta
            period_start_str = current_start.isoformat()
            period_end_str = period_end.isoformat()

            report = self.generate_report(
                period_start_str,
                period_end_str,
                period_type
            )

            trend_data.append({
                "period": current_start.strftime(date_format),
                "commission": report.total_commission,
                "sales": report.total_sales,
                "conversion_rate": report.conversion_rate,
            })

            current_start = period_end

        # Calculate trends
        if len(trend_data) >= 2:
            first = trend_data[0]["commission"]
            last = trend_data[-1]["commission"]
            change_pct = ((last - first) / first * 100) if first > 0 else 0

            trend_direction = "up" if change_pct > 5 else ("down" if change_pct < -5 else "stable")
        else:
            change_pct = 0
            trend_direction = "stable"

        return {
            "trend_data": trend_data,
            "trend_direction": trend_direction,
            "change_percentage": change_pct,
            "analysis_periods": periods,
            "period_type": period_type,
        }

    # =========================================================================
    # Export
    # =========================================================================

    def export_report(
        self,
        report: RevenueReport,
        format: str = "json",
        filepath: Optional[str] = None
    ) -> str:
        """
        Export a report to file.

        Args:
            report: The report to export
            format: json or csv
            filepath: Output path (generated if not provided)

        Returns:
            Path to exported file
        """
        if not filepath:
            filepath = str(self.reports_dir / f"{report.report_id}.{format}")

        if format == "json":
            with open(filepath, "w") as f:
                json.dump(report.__dict__, f, indent=2, default=str)
        else:
            import csv
            with open(filepath, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "Date", "Offer", "Network", "Event Type",
                    "Amount", "Commission", "Status"
                ])

                for day in report.daily_revenue:
                    writer.writerow([
                        day["date"], "", "", "",
                        day["revenue"], day["commission"], ""
                    ])

        self.logger.info(f"Exported report to {filepath}")

        return filepath

    # =========================================================================
    # Integration with Affiliate Engine
    # =========================================================================

    def sync_with_engine(self) -> int:
        """
        Sync commission records with Affiliate Engine.

        Pulls any commission events recorded by the engine that aren't
        in our records.

        Returns:
            Number of records synced
        """
        if not self.engine:
            return 0

        synced = 0

        # Get engine commissions
        engine_commissions = self.engine.get_commissions()

        # Get our record IDs
        our_ids = set(self._records.keys())

        # Find engine commissions not in our records
        for comm in engine_commissions:
            record_id = f"rec_{uuid.uuid4().hex[:12]}"

            # Check if this link already has a record
            link_records = [
                r for r in self._records.values()
                if r.link_id == comm.link_id
            ]

            if not link_records:
                # New commission
                offer = self.engine.get_offer(comm.offer_id)

                self.record_commission(
                    network=comm.network.value,
                    offer_id=comm.offer_id,
                    offer_name=offer.name if offer else "Unknown",
                    brand=offer.brand if offer else "",
                    event_type=comm.event_type,
                    amount=comm.amount,
                    commission=comm.commission,
                    status=comm.status,
                    link_id=comm.link_id,
                    occurred_at=comm.occurred_at,
                )

                synced += 1

        return synced


# Helper function
def track_commission(
    network: str,
    offer_id: str,
    commission: float,
    **kwargs
) -> Optional[CommissionRecord]:
    """Track a commission event (convenience function)."""
    tracker = CommissionTracker()
    return tracker.record_commission(
        network=network,
        offer_id=offer_id,
        offer_name=kwargs.get("offer_name", "Unknown"),
        brand=kwargs.get("brand", ""),
        commission=commission,
        **kwargs
    )


import uuid
from collections import defaultdict
