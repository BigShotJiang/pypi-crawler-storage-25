"""
KashClaw Affiliate Marketing Organ.

Revenue-generating affiliate marketing system that integrates with
Media Empire and Content Clipping for automated monetization.

Key Features:
- Multi-network affiliate management (ClickBank, ShareASale, etc.)
- Luxury brand partnerships (Louis Vuitton, etc.)
- Link cloaking and tracking
- AI-powered product recommendations
- Content integration for Media/Clipping
- Revenue analytics and optimization
- Deep mesh integration for system-wide communication

Revenue Flow:
    Affiliate Organ → Media Organ (product content)
    Affiliate Organ → Clipping Organ (sponsored clips)
    Clipping Organ → Media Organ (viral content + revenue)
    Media Organ → Affiliate Organ (impressions + clicks)

Mesh Channels:
- affiliate.offers      → Offer updates, new offers
- affiliate.clicks     → Click tracking events
- affiliate.commissions → Commission events
- affiliate.links      → Link creation/cloaking
- affiliate.media      → Media organ communication
- affiliate.clipping  → Clipping organ communication
- affiliate.revenue   → Revenue reports

Author: KashClaw Ecosystem
"""
from .affiliate_engine import (
    AffiliateEngine,
    AffiliateOffer,
    AffiliateNetwork,
    AffiliateLink,
    CommissionEvent,
    OfferCategory,
    CommissionType,
    OfferStatus,
    create_affiliate_engine,
)
from .clickbank_integration import (
    ClickBankAPI,
    ClickBankOffer,
    ClickBankHopLink,
    ClickBankHopLinkBuilder,
    fetch_clickbank_offers,
)
from .luxury_brands import (
    LuxuryBrandAffiliate,
    LuxuryBrandRegistry,
    LuxuryBrand,
    get_luxury_brands,
    ADDITIONAL_LUXURY_PROGRAMS,
)
from .link_manager import (
    LinkManager,
    CloakedLink,
    LinkAnalytics,
    create_link_manager,
)
from .media_integration import (
    AffiliateMediaIntegrator,
    ProductContentGenerator,
    ProductContentMapping,
    SponsoredContentRequest,
    SponsoredContentResult,
    SponsoredContentPipeline,
    create_media_integrator,
)
from .clipping_integration import (
    AffiliateClippingIntegrator,
    SponsoredClipOpportunity,
    SponsoredClipResult,
    SponsoredClipPipeline,
    AffiliateClippingIntegrator,
    create_clipping_integrator,
)
from .commission_tracker import (
    CommissionTracker,
    CommissionRecord,
    RevenueReport,
    PaymentSummary,
    track_commission,
)
from .mesh_integration import (
    AffiliateMeshGateway,
    MediaMeshGateway,
    ClippingMeshGateway,
    OrganMeshManager,
    OrganChannel,
    AffiliatePacketType,
    AffiliateMeshMessage,
)
from .organ_init import (
    initialize_affiliate_organ,
    initialize_media_organ,
    initialize_clipping_organ,
    wire_organs_together,
    connect_to_mesh,
    initialize_revenue_organs,
    get_revenue_dashboard,
    quick_start_affiliate,
    setup_mesh_message_handlers,
)

__all__ = [
    # Core engine
    "AffiliateEngine",
    "AffiliateOffer",
    "AffiliateNetwork",
    "AffiliateLink",
    "CommissionEvent",
    "OfferCategory",
    "CommissionType",
    "OfferStatus",
    "create_affiliate_engine",
    # ClickBank
    "ClickBankAPI",
    "ClickBankOffer",
    "ClickBankHopLink",
    "ClickBankHopLinkBuilder",
    "fetch_clickbank_offers",
    # Luxury brands
    "LuxuryBrandAffiliate",
    "LuxuryBrandRegistry",
    "LuxuryBrand",
    "get_luxury_brands",
    "ADDITIONAL_LUXURY_PROGRAMS",
    # Link management
    "LinkManager",
    "CloakedLink",
    "LinkAnalytics",
    "create_link_manager",
    # Media integration
    "AffiliateMediaIntegrator",
    "ProductContentGenerator",
    "ProductContentMapping",
    "SponsoredContentRequest",
    "SponsoredContentResult",
    "SponsoredContentPipeline",
    "create_media_integrator",
    # Clipping integration
    "AffiliateClippingIntegrator",
    "SponsoredClipOpportunity",
    "SponsoredClipResult",
    "SponsoredClipPipeline",
    "create_clipping_integrator",
    # Commission tracking
    "CommissionTracker",
    "CommissionRecord",
    "RevenueReport",
    "PaymentSummary",
    "track_commission",
    # Mesh integration
    "AffiliateMeshGateway",
    "MediaMeshGateway",
    "ClippingMeshGateway",
    "OrganMeshManager",
    "OrganChannel",
    "AffiliatePacketType",
    "AffiliateMeshMessage",
    # Organ initialization
    "initialize_affiliate_organ",
    "initialize_media_organ",
    "initialize_clipping_organ",
    "wire_organs_together",
    "connect_to_mesh",
    "initialize_revenue_organs",
    "get_revenue_dashboard",
    "quick_start_affiliate",
    "setup_mesh_message_handlers",
]
