"""
Affiliate Organ Mesh Integration.

Wires the Affiliate Marketing Organ deeply into the SIMP mesh for
communication with Media Organ, Clipping Organ, and the rest of the system.

Channels:
- affiliate.offers      → Offer updates, new offers
- affiliate.clicks      → Click tracking events
- affiliate.commissions → Commission events
- affiliate.links       → Link creation/cloaking
- affiliate.media       → Media organ communication
- affiliate.clipping   → Clipping organ communication
- affiliate.revenue    → Revenue reports

Author: KashClaw Ecosystem
"""
import asyncio
import hashlib
import hmac
import json
import logging
import sqlite3
import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

logger = logging.getLogger("affiliate.mesh")


# ─────────────────────────────────────────────────────────────────────────────
# Organ Channels Registry
# ─────────────────────────────────────────────────────────────────────────────

class OrganChannel(str, Enum):
    """Affiliate organ mesh channels."""
    OFFERS = "affiliate.offers"
    CLICKS = "affiliate.clicks"
    COMMISSIONS = "affiliate.commissions"
    LINKS = "affiliate.links"
    MEDIA = "affiliate.media"
    CLIPPING = "affiliate.clipping"
    REVENUE = "affiliate.revenue"
    SYSTEM = "affiliate.system"


# ─────────────────────────────────────────────────────────────────────────────
# Mesh Packet Types for Affiliate Organ
# ─────────────────────────────────────────────────────────────────────────────

class AffiliatePacketType(str, Enum):
    """Packet types for affiliate mesh messages."""
    # Offer operations
    OFFER_ADDED = "affiliate.offer.added"
    OFFER_UPDATED = "affiliate.offer.updated"
    OFFER_REMOVED = "affiliate.offer.removed"
    OFFER_SEARCH = "affiliate.offer.search"
    OFFER_MATCH = "affiliate.offer.match"

    # Link operations
    LINK_CREATED = "affiliate.link.created"
    LINK_CLICKED = "affiliate.link.clicked"
    LINK_CONVERTED = "affiliate.link.converted"

    # Commission operations
    COMMISSION_RECORDED = "affiliate.commission.recorded"
    COMMISSION_APPROVED = "affiliate.commission.approved"
    COMMISSION_PAID = "affiliate.commission.paid"

    # Media organ communication
    MEDIA_CONTENT_REQUEST = "affiliate.media.content_request"
    MEDIA_CONTENT_READY = "affiliate.media.content_ready"
    MEDIA_PERFORMANCE = "affiliate.media.performance"

    # Clipping organ communication
    CLIPPING_OPPORTUNITY = "affiliate.clipping.opportunity"
    CLIPPING_SPONSORED_CLIP = "affiliate.clipping.sponsored_clip"
    CLIPPING_PERFORMANCE = "affiliate.clipping.performance"

    # Revenue
    REVENUE_REPORT = "affiliate.revenue.report"
    REVENUE_ALERT = "affiliate.revenue.alert"


# ─────────────────────────────────────────────────────────────────────────────
# Mesh-Enveloped Affiliate Messages
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class AffiliateMeshMessage:
    """
    Wraps affiliate organ payloads in mesh-compatible format.
    """
    organ: str = "affiliate"
    packet_type: str = ""
    sender_id: str = ""
    target_channel: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    correlation_id: Optional[str] = None
    trace_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(',', ':'))

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AffiliateMeshMessage":
        return cls(**data)

    @classmethod
    def from_json(cls, json_str: str) -> "AffiliateMeshMessage":
        return cls.from_dict(json.loads(json_str))


# ─────────────────────────────────────────────────────────────────────────────
# Affiliate Mesh Gateway - Connects Organ to Mesh Bus
# ─────────────────────────────────────────────────────────────────────────────

class AffiliateMeshGateway:
    """
    Gateway that wires the Affiliate Organ into the SIMP mesh.

    Handles:
    - Registering organ channels with the mesh
    - Converting organ events to mesh packets
    - Routing affiliate messages to media/clipping organs
    - Receiving and processing mesh messages from other organs
    """

    def __init__(
        self,
        affiliate_engine: 'AffiliateEngine',
        mesh_bus: Optional[Any] = None,
        organ_id: str = "affiliate_organ"
    ):
        self.engine = affiliate_engine
        self.mesh = mesh_bus
        self.organ_id = organ_id

        self.logger = logging.getLogger("affiliate.mesh.gateway")

        # Registered handlers
        self._handlers: Dict[str, List[Callable]] = {}
        self._subscribers: Dict[str, Set[str]] = {}

        # Connection state
        self._connected = False
        self._last_sync: Optional[str] = None

        # Channels this organ publishes to
        self._published_channels: Set[str] = {
            OrganChannel.OFFERS.value,
            OrganChannel.CLICKS.value,
            OrganChannel.COMMISSIONS.value,
            OrganChannel.LINKS.value,
            OrganChannel.REVENUE.value,
        }

        # Channels this organ subscribes to
        self._subscribed_channels: Set[str] = {
            OrganChannel.MEDIA.value,
            OrganChannel.CLIPPING.value,
        }

    # =========================================================================
    # Mesh Connection
    # =========================================================================

    def connect_to_mesh(self, mesh_bus: Any) -> bool:
        """
        Connect the affiliate organ gateway to the mesh bus.

        Args:
            mesh_bus: The EnhancedMeshBus instance

        Returns:
            True if connection successful
        """
        self.mesh = mesh_bus
        self._connected = True

        self.logger.info(f"Affiliate organ connected to mesh as {self.organ_id}")

        # Register channels
        self._register_channels()

        # Subscribe to required channels
        self._subscribe_channels()

        return True

    def _register_channels(self) -> None:
        """Register this organ's channels with the mesh."""
        if not self.mesh:
            return

        for channel in self._published_channels | self._subscribed_channels:
            try:
                # Subscribe to channel
                self.mesh.subscribe(channel, self.organ_id)
                self.logger.debug(f"Registered channel: {channel}")
            except Exception as e:
                self.logger.warning(f"Could not register channel {channel}: {e}")

    def _subscribe_channels(self) -> None:
        """Subscribe to channels from other organs."""
        if not self.mesh:
            return

        for channel in self._subscribed_channels:
            try:
                self.mesh.subscribe(channel, self.organ_id)
            except Exception as e:
                self.logger.warning(f"Could not subscribe to {channel}: {e}")

    def disconnect_from_mesh(self) -> None:
        """Disconnect from mesh and cleanup."""
        self._connected = False
        self.mesh = None
        self.logger.info("Affiliate organ disconnected from mesh")

    # =========================================================================
    # Publishing to Mesh
    # =========================================================================

    def publish(
        self,
        channel: str,
        packet_type: str,
        payload: Dict[str, Any],
        priority: str = "normal"
    ) -> bool:
        """
        Publish a message to the mesh.

        Args:
            channel: Target channel
            packet_type: Type of message
            payload: Message payload
            priority: Message priority

        Returns:
            True if published successfully
        """
        if not self._connected or not self.mesh:
            self.logger.warning("Cannot publish: not connected to mesh")
            return False

        try:
            # Create mesh message
            message = AffiliateMeshMessage(
                organ="affiliate",
                packet_type=packet_type,
                sender_id=self.organ_id,
                target_channel=channel,
                payload=payload,
            )

            # Convert to mesh packet
            from simp.mesh.packet import MeshPacket, MessageType, Priority

            mesh_packet = MeshPacket(
                msg_type=MessageType.EVENT,
                sender_id=self.organ_id,
                recipient_id="*",  # Broadcast to channel subscribers
                channel=channel,
                payload=message.to_dict(),
                priority=getattr(Priority, priority.upper(), Priority.NORMAL),
            )

            # Send via mesh - channel broadcast
            self.mesh.send(mesh_packet)

            self.logger.debug(f"Published to {channel}: {packet_type}")
            return True

        except Exception as e:
            self.logger.error(f"Failed to publish to {channel}: {e}")
            return False

    def publish_offer_added(self, offer: 'AffiliateOffer') -> bool:
        """Publish a new offer to the mesh."""
        return self.publish(
            channel=OrganChannel.OFFERS.value,
            packet_type=AffiliatePacketType.OFFER_ADDED.value,
            payload={
                "offer_id": offer.offer_id,
                "name": offer.name,
                "brand": offer.brand,
                "network": offer.network.value,
                "commission_rate": offer.commission_rate,
                "categories": [c.value for c in offer.categories],
                "tags": offer.tags,
            }
        )

    def publish_link_clicked(self, link_id: str, link_data: Dict[str, Any]) -> bool:
        """Publish a link click event to the mesh."""
        return self.publish(
            channel=OrganChannel.CLICKS.value,
            packet_type=AffiliatePacketType.LINK_CLICKED.value,
            payload={
                "link_id": link_id,
                "offer_id": link_data.get("offer_id", ""),
                "network": link_data.get("network", ""),
                "campaign": link_data.get("campaign", ""),
                "medium": link_data.get("medium", ""),
                "source": link_data.get("source", ""),
            }
        )

    def publish_commission_recorded(
        self,
        event_data: Dict[str, Any]
    ) -> bool:
        """Publish a commission event to the mesh."""
        return self.publish(
            channel=OrganChannel.COMMISSIONS.value,
            packet_type=AffiliatePacketType.COMMISSION_RECORDED.value,
            payload=event_data,
            priority="high"
        )

    def publish_revenue_report(self, stats: Dict[str, Any]) -> bool:
        """Publish a revenue report to the mesh."""
        return self.publish(
            channel=OrganChannel.REVENUE.value,
            packet_type=AffiliatePacketType.REVENUE_REPORT.value,
            payload=stats,
            priority="normal"
        )

    def publish_media_content_request(
        self,
        request_id: str,
        niche: str,
        platform: str,
        count: int = 5
    ) -> bool:
        """Request content from media organ."""
        return self.publish(
            channel=OrganChannel.MEDIA.value,
            packet_type=AffiliatePacketType.MEDIA_CONTENT_REQUEST.value,
            payload={
                "request_id": request_id,
                "niche": niche,
                "platform": platform,
                "count": count,
                "source": "affiliate",
            },
            priority="high"
        )

    def publish_clipping_opportunity(
        self,
        opportunity: 'SponsoredClipOpportunity'
    ) -> bool:
        """Publish a clip opportunity to the clipping organ."""
        return self.publish(
            channel=OrganChannel.CLIPPING.value,
            packet_type=AffiliatePacketType.CLIPPING_OPPORTUNITY.value,
            payload={
                "opportunity_id": opportunity.opportunity_id,
                "source_platform": opportunity.source_platform,
                "source_url": opportunity.source_url,
                "title": opportunity.title,
                "creator": opportunity.creator,
                "niche": opportunity.niche,
                "virality_score": opportunity.virality_score,
                "affiliate_offer_id": opportunity.affiliate_offer_id,
                "estimated_revenue": opportunity.estimated_revenue_per_clip,
            }
        )

    # =========================================================================
    # Receiving from Mesh
    # =========================================================================

    def handle_mesh_message(self, message: Dict[str, Any]) -> bool:
        """
        Handle an incoming message from the mesh.

        Args:
            message: The mesh message dict

        Returns:
            True if message was handled
        """
        try:
            sender = message.get("sender_id", "")
            packet_type = message.get("packet_type", "")
            payload = message.get("payload", {})

            # Route based on packet type
            handlers = self._handlers.get(packet_type, [])

            if handlers:
                for handler in handlers:
                    try:
                        handler(payload, sender)
                    except Exception as e:
                        self.logger.error(f"Handler error for {packet_type}: {e}")

                return True

            # Default routing based on channel
            if "media" in str(message.get("channel", "")):
                return self._handle_media_message(packet_type, payload)
            elif "clipping" in str(message.get("channel", "")):
                return self._handle_clipping_message(packet_type, payload)

            return False

        except Exception as e:
            self.logger.error(f"Error handling mesh message: {e}")
            return False

    def _handle_media_message(self, packet_type: str, payload: Dict[str, Any]) -> bool:
        """Handle messages from media organ."""
        handlers = {
            AffiliatePacketType.MEDIA_PERFORMANCE.value: self._on_media_performance,
            AffiliatePacketType.MEDIA_CONTENT_READY.value: self._on_media_content_ready,
        }

        handler = handlers.get(packet_type)
        if handler:
            try:
                handler(payload)
                return True
            except Exception as e:
                self.logger.error(f"Media message handler error: {e}")

        return False

    def _handle_clipping_message(self, packet_type: str, payload: Dict[str, Any]) -> bool:
        """Handle messages from clipping organ."""
        handlers = {
            AffiliatePacketType.CLIPPING_PERFORMANCE.value: self._on_clipping_performance,
            AffiliatePacketType.CLIPPING_SPONSORED_CLIP.value: self._on_sponsored_clip,
        }

        handler = handlers.get(packet_type)
        if handler:
            try:
                handler(payload)
                return True
            except Exception as e:
                self.logger.error(f"Clipping message handler error: {e}")

        return False

    def _on_media_performance(self, payload: Dict[str, Any]) -> None:
        """Handle performance data from media organ."""
        self.logger.info(f"Media performance received: {payload}")
        # Update affiliate tracking with media data
        content_id = payload.get("content_id", "")
        impressions = payload.get("impressions", 0)
        clicks = payload.get("clicks", 0)
        engagements = payload.get("engagements", 0)

        # Would update link tracking here
        if content_id and self.engine:
            self.logger.debug(f"Updated affiliate stats with media performance for {content_id}")

    def _on_media_content_ready(self, payload: Dict[str, Any]) -> None:
        """Handle content ready notification from media organ."""
        self.logger.info(f"Media content ready: {payload}")
        content_id = payload.get("content_id", "")
        platform = payload.get("platform", "")

    def _on_clipping_performance(self, payload: Dict[str, Any]) -> None:
        """Handle performance data from clipping organ."""
        self.logger.info(f"Clipping performance received: {payload}")
        clip_id = payload.get("clip_id", "")
        views = payload.get("views", 0)
        clicks = payload.get("clicks", 0)
        conversions = payload.get("conversions", 0)
        commission = payload.get("commission", 0.0)

    def _on_sponsored_clip(self, payload: Dict[str, Any]) -> None:
        """Handle sponsored clip notification from clipping organ."""
        self.logger.info(f"Sponsored clip created: {payload}")

    # =========================================================================
    # Handlers Registration
    # =========================================================================

    def register_handler(
        self,
        packet_type: str,
        handler: Callable[[Dict[str, Any], str], None]
    ) -> None:
        """Register a handler for a packet type."""
        if packet_type not in self._handlers:
            self._handlers[packet_type] = []
        self._handlers[packet_type].append(handler)

    def unregister_handler(self, packet_type: str, handler: Callable) -> None:
        """Unregister a handler."""
        if packet_type in self._handlers:
            self._handlers[packet_type] = [
                h for h in self._handlers[packet_type] if h != handler
            ]

    # =========================================================================
    # Offer Broadcasting
    # =========================================================================

    def broadcast_offer_update(self, offer: 'AffiliateOffer', action: str = "updated") -> bool:
        """
        Broadcast an offer change to all subscribers.

        Args:
            offer: The offer that changed
            action: updated, added, removed
        """
        packet_type = f"affiliate.offer.{action}"

        return self.publish(
            channel=OrganChannel.OFFERS.value,
            packet_type=packet_type,
            payload={
                "offer_id": offer.offer_id,
                "name": offer.name,
                "brand": offer.brand,
                "network": offer.network.value,
                "commission_rate": offer.commission_rate,
                "commission_type": offer.commission_type.value,
                "categories": [c.value for c in offer.categories],
                "tags": offer.tags,
                "status": offer.status.value,
                "epc": offer.epc,
                "conversion_rate": offer.conversion_rate,
            },
            priority="normal"
        )

    # =========================================================================
    # Inter-Organ Communication
    # =========================================================================

    def request_offers_from_network(
        self,
        network: str,
        category: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Request offers from a specific network via mesh.

        Args:
            network: Network name (clickbank, shareasale, etc)
            category: Optional category filter

        Returns:
            List of offer dicts
        """
        request_id = f"req_{uuid.uuid4().hex[:12]}"

        # Publish request
        self.publish(
            channel=OrganChannel.OFFERS.value,
            packet_type=AffiliatePacketType.OFFER_SEARCH.value,
            payload={
                "request_id": request_id,
                "network": network,
                "category": category,
                "source": self.organ_id,
            },
            priority="high"
        )

        # For now, return empty - would await response via mesh
        return []

    def find_matching_offers(
        self,
        niche: str,
        content_type: str = "video",
        platform: str = "tiktok"
    ) -> List['AffiliateOffer']:
        """
        Find offers matching content criteria.

        Uses the engine's matching logic and broadcasts to mesh.
        """
        offer = self.engine.get_offer_for_content(niche, content_type, platform)

        if offer:
            # Broadcast match to mesh
            self.publish(
                channel=OrganChannel.OFFERS.value,
                packet_type=AffiliatePacketType.OFFER_MATCH.value,
                payload={
                    "niche": niche,
                    "content_type": content_type,
                    "platform": platform,
                    "matched_offer": {
                        "offer_id": offer.offer_id,
                        "name": offer.name,
                        "brand": offer.brand,
                        "commission_rate": offer.commission_rate,
                    }
                }
            )

            return [offer]

        return []

    # =========================================================================
    # Sync with Mesh State
    # =========================================================================

    def sync_state(self) -> bool:
        """
        Sync affiliate organ state with mesh.

        Publishes current state to mesh for other organs.
        """
        if not self._connected:
            return False

        try:
            # Get current stats
            stats = self.engine.get_dashboard_stats()

            # Publish full state
            self.publish_revenue_report(stats)

            # Publish active offers
            active_offers = self.engine.get_active_offers()
            for offer in active_offers[:10]:  # Top 10
                self.publish_offer_added(offer)

            self._last_sync = datetime.now(timezone.utc).isoformat()
            self.logger.info(f"Affiliate state synced to mesh at {self._last_sync}")

            return True

        except Exception as e:
            self.logger.error(f"State sync failed: {e}")
            return False

    # =========================================================================
    # Integration with Affiliate Engine
    # =========================================================================

    def wire_to_engine(self) -> None:
        """
        Wire the mesh gateway to the affiliate engine.

        This hooks mesh publishing into engine events.
        """
        # Note: In a full implementation, we would override engine methods
        # to automatically publish events to mesh. For now, we provide
        # the methods for manual publishing.

        self.logger.info("Mesh gateway wired to affiliate engine")


# ─────────────────────────────────────────────────────────────────────────────
# Media Organ Mesh Integration
# ─────────────────────────────────────────────────────────────────────────────

class MediaMeshGateway:
    """
    Gateway that wires the Media Organ into the SIMP mesh.

    Handles communication with Affiliate Organ for:
    - Product content requests
    - Performance data sharing
    - Unified revenue reporting
    """

    def __init__(
        self,
        media_organ: Any = None,
        mesh_bus: Optional[Any] = None,
        organ_id: str = "media_organ"
    ):
        self.organ = media_organ
        self.mesh = mesh_bus
        self.organ_id = organ_id
        self.logger = logging.getLogger("media.mesh.gateway")

        self._handlers: Dict[str, List[Callable]] = {}

    def connect_to_mesh(self, mesh_bus: Any) -> bool:
        """Connect media organ to mesh."""
        self.mesh = mesh_bus
        self.logger.info(f"Media organ connected to mesh as {self.organ_id}")
        return True

    def publish(
        self,
        channel: str,
        packet_type: str,
        payload: Dict[str, Any],
        priority: str = "normal"
    ) -> bool:
        """Publish to mesh."""
        if not self.mesh:
            return False

        try:
            from simp.mesh.packet import MeshPacket, MessageType, Priority

            message = AffiliateMeshMessage(
                organ="media",
                packet_type=packet_type,
                sender_id=self.organ_id,
                target_channel=channel,
                payload=payload,
            )

            mesh_packet = MeshPacket(
                msg_type=MessageType.EVENT,
                sender_id=self.organ_id,
                recipient_id="*",
                channel=channel,
                payload=message.to_dict(),
                priority=getattr(Priority, priority.upper(), Priority.NORMAL),
            )

            self.mesh.send(mesh_packet)
            return True

        except Exception as e:
            self.logger.error(f"Publish failed: {e}")
            return False

    def publish_content_ready(
        self,
        content_id: str,
        platform: str,
        affiliate_offer_id: Optional[str] = None
    ) -> bool:
        """Notify affiliate organ that content is ready."""
        return self.publish(
            channel=OrganChannel.MEDIA.value,
            packet_type=AffiliatePacketType.MEDIA_CONTENT_READY.value,
            payload={
                "content_id": content_id,
                "platform": platform,
                "affiliate_offer_id": affiliate_offer_id,
            }
        )

    def publish_performance(
        self,
        content_id: str,
        platform: str,
        impressions: int,
        clicks: int,
        engagements: int
    ) -> bool:
        """Share performance data with affiliate organ."""
        return self.publish(
            channel=OrganChannel.MEDIA.value,
            packet_type=AffiliatePacketType.MEDIA_PERFORMANCE.value,
            payload={
                "content_id": content_id,
                "platform": platform,
                "impressions": impressions,
                "clicks": clicks,
                "engagements": engagements,
            },
            priority="high"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Clipping Organ Mesh Integration
# ─────────────────────────────────────────────────────────────────────────────

class ClippingMeshGateway:
    """
    Gateway that wires the Content Clipping Organ into the SIMP mesh.

    Handles communication with Affiliate Organ for:
    - Sponsored clip opportunities
    - Performance tracking
    - Revenue attribution
    """

    def __init__(
        self,
        clipping_engine: Any = None,
        mesh_bus: Optional[Any] = None,
        organ_id: str = "clipping_organ"
    ):
        self.engine = clipping_engine
        self.mesh = mesh_bus
        self.organ_id = organ_id
        self.logger = logging.getLogger("clipping.mesh.gateway")

        self._handlers: Dict[str, List[Callable]] = {}

    def connect_to_mesh(self, mesh_bus: Any) -> bool:
        """Connect clipping organ to mesh."""
        self.mesh = mesh_bus
        self.logger.info(f"Clipping organ connected to mesh as {self.organ_id}")
        return True

    def publish(
        self,
        channel: str,
        packet_type: str,
        payload: Dict[str, Any],
        priority: str = "normal"
    ) -> bool:
        """Publish to mesh."""
        if not self.mesh:
            return False

        try:
            from simp.mesh.packet import MeshPacket, MessageType, Priority

            message = AffiliateMeshMessage(
                organ="clipping",
                packet_type=packet_type,
                sender_id=self.organ_id,
                target_channel=channel,
                payload=payload,
            )

            mesh_packet = MeshPacket(
                msg_type=MessageType.EVENT,
                sender_id=self.organ_id,
                recipient_id="*",
                channel=channel,
                payload=message.to_dict(),
                priority=getattr(Priority, priority.upper(), Priority.NORMAL),
            )

            self.mesh.send(mesh_packet)
            return True

        except Exception as e:
            self.logger.error(f"Publish failed: {e}")
            return False

    def publish_trending_opportunity(
        self,
        platform: str,
        content_id: str,
        title: str,
        creator: str,
        niche: str,
        virality_score: float,
        affiliate_offer_id: Optional[str] = None
    ) -> bool:
        """Publish a trending content opportunity to affiliate organ."""
        return self.publish(
            channel=OrganChannel.CLIPPING.value,
            packet_type=AffiliatePacketType.CLIPPING_OPPORTUNITY.value,
            payload={
                "platform": platform,
                "content_id": content_id,
                "title": title,
                "creator": creator,
                "niche": niche,
                "virality_score": virality_score,
                "affiliate_offer_id": affiliate_offer_id,
            },
            priority="high"
        )

    def publish_clip_performance(
        self,
        clip_id: str,
        views: int,
        clicks: int,
        conversions: int,
        commission: float
    ) -> bool:
        """Share clip performance with affiliate organ."""
        return self.publish(
            channel=OrganChannel.CLIPPING.value,
            packet_type=AffiliatePacketType.CLIPPING_PERFORMANCE.value,
            payload={
                "clip_id": clip_id,
                "views": views,
                "clicks": clicks,
                "conversions": conversions,
                "commission": commission,
            },
            priority="high"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Unified Organ Mesh Manager
# ─────────────────────────────────────────────────────────────────────────────

class OrganMeshManager:
    """
    Manages mesh integration for all three revenue organs.

    Creates and manages:
    - AffiliateMeshGateway
    - MediaMeshGateway
    - ClippingMeshGateway

    Provides unified access to all organ gateways.
    """

    def __init__(
        self,
        affiliate_engine: Optional['AffiliateEngine'] = None,
        media_organ: Any = None,
        clipping_engine: Any = None,
        mesh_bus: Optional[Any] = None
    ):
        self.mesh = mesh_bus

        # Initialize gateways
        self.affiliate = AffiliateMeshGateway(affiliate_engine) if affiliate_engine else None
        self.media = MediaMeshGateway(media_organ)
        self.clipping = ClippingMeshGateway(clipping_engine)

        self.logger = logging.getLogger("organ.mesh.manager")

    def connect_all(self, mesh_bus: Any) -> bool:
        """
        Connect all organ gateways to the mesh.

        Args:
            mesh_bus: The EnhancedMeshBus instance

        Returns:
            True if all connected successfully
        """
        self.mesh = mesh_bus

        success = True

        if self.affiliate:
            try:
                self.affiliate.connect_to_mesh(mesh_bus)
            except Exception as e:
                self.logger.error(f"Affiliate mesh connect failed: {e}")
                success = False

        try:
            self.media.connect_to_mesh(mesh_bus)
        except Exception as e:
            self.logger.error(f"Media mesh connect failed: {e}")
            success = False

        try:
            self.clipping.connect_to_mesh(mesh_bus)
        except Exception as e:
            self.logger.error(f"Clipping mesh connect failed: {e}")
            success = False

        if success:
            self.logger.info("All organ gateways connected to mesh")

        return success

    def disconnect_all(self) -> None:
        """Disconnect all gateways from mesh."""
        if self.affiliate:
            self.affiliate.disconnect_from_mesh()
        self.mesh = None
        self.logger.info("All organ gateways disconnected from mesh")

    def sync_all_state(self) -> bool:
        """
        Sync state of all organs to mesh.

        Returns:
            True if all synced successfully
        """
        success = True

        if self.affiliate:
            try:
                self.affiliate.sync_state()
            except Exception as e:
                self.logger.error(f"Affiliate state sync failed: {e}")
                success = False

        return success

    def get_mesh_status(self) -> Dict[str, Any]:
        """Get status of all mesh connections."""
        return {
            "mesh_connected": self.mesh is not None,
            "affiliate_connected": self.affiliate._connected if self.affiliate else False,
            "media_connected": True,  # Always connected if manager exists
            "clipping_connected": True,
            "channels": {
                "affiliate": list(self.affiliate._published_channels) if self.affiliate else [],
                "media": ["affiliate.media"],
                "clipping": ["affiliate.clipping"],
            }
        }


# ─────────────────────────────────────────────────────────────────────────────
# Type Hints
# ─────────────────────────────────────────────────────────────────────────────

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from simp.organs.affiliate.affiliate_engine import AffiliateEngine
    from simp.organs.affiliate.clipping_integration import SponsoredClipOpportunity
    from simp.organs.affiliate.affiliate_engine import AffiliateOffer
