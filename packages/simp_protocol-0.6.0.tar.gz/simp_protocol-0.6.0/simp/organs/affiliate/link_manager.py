"""
Link Manager - Link Cloaking and Tracking.

Provides link cloaking, shortening, and analytics for affiliate links.
Integrates with Media and Clipping organs for revenue tracking.
"""
import hashlib
import json
import logging
import os
import re
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger("affiliate.link_manager")


@dataclass
class CloakedLink:
    """
    A cloaked affiliate link with full analytics.
    """
    link_id: str
    cloaked_url: str

    # Source
    original_url: str = ""
    network: str = "unknown"
    offer_id: str = ""

    # Tracking
    campaign: str = ""
    medium: str = ""
    source: str = ""
    content_id: str = ""

    # Analytics
    clicks: int = 0
    unique_clicks: int = 0
    conversions: int = 0
    commission: float = 0.0
    revenue: float = 0.0

    # Performance
    epc: float = 0.0  # Earnings per click
    conversion_rate: float = 0.0

    # Timestamps
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    last_clicked_at: Optional[str] = None

    # Status
    is_active: bool = True
    is_paused: bool = False


@dataclass
class LinkAnalytics:
    """
    Analytics for a set of links.
    """
    total_links: int = 0
    active_links: int = 0

    # Clicks
    total_clicks: int = 0
    unique_clicks: int = 0
    avg_ctr: float = 0.0  # Click-through rate

    # Conversions
    total_conversions: int = 0
    conversion_rate: float = 0.0

    # Revenue
    total_commission: float = 0.0
    total_revenue: float = 0.0
    avg_order_value: float = 0.0

    # Performance by medium
    by_medium: Dict[str, Dict] = field(default_factory=dict)

    # Performance by campaign
    by_campaign: Dict[str, Dict] = field(default_factory=dict)


class LinkManager:
    """
    Manages link cloaking, tracking, and analytics.

    Features:
    - URL shortening with custom slugs
    - Click tracking and attribution
    - Conversion attribution
    - A/B testing support
    - Multi-platform tracking
    - Real-time analytics
    """

    def __init__(
        self,
        data_dir: str = "data/affiliate/links",
        base_domain: str = "kp.link"  # KashPay link domain
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.base_domain = base_domain
        self.logger = logging.getLogger("affiliate.link_manager")

        # Database for link analytics
        self.db_path = self.data_dir / "links.db"
        self._init_db()

        # In-memory cache
        self._links: Dict[str, CloakedLink] = {}
        self._load_links()

    def _init_db(self):
        """Initialize SQLite database for link tracking."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        # Links table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS links (
                link_id TEXT PRIMARY KEY,
                cloaked_url TEXT UNIQUE,
                original_url TEXT,
                network TEXT,
                offer_id TEXT,
                campaign TEXT,
                medium TEXT,
                source TEXT,
                content_id TEXT,
                clicks INTEGER DEFAULT 0,
                unique_clicks INTEGER DEFAULT 0,
                conversions INTEGER DEFAULT 0,
                commission REAL DEFAULT 0.0,
                revenue REAL DEFAULT 0.0,
                created_at TEXT,
                last_clicked_at TEXT,
                is_active INTEGER DEFAULT 1,
                is_paused INTEGER DEFAULT 0
            )
        """)

        # Click events table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clicks (
                click_id TEXT PRIMARY KEY,
                link_id TEXT,
                timestamp TEXT,
                ip_hash TEXT,
                user_agent TEXT,
                referrer TEXT,
                country TEXT,
                device_type TEXT,
                FOREIGN KEY (link_id) REFERENCES links(link_id)
            )
        """)

        # Create index on cloaked_url
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_cloaked_url ON links(cloaked_url)
        """)

        conn.commit()
        conn.close()

    def _load_links(self):
        """Load links from database into memory."""
        if not self.db_path.exists():
            return

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM links")
        for row in cursor.fetchall():
            link = CloakedLink(
                link_id=row[0],
                cloaked_url=row[1],
                original_url=row[2],
                network=row[3],
                offer_id=row[4],
                campaign=row[5],
                medium=row[6],
                source=row[7],
                content_id=row[8],
                clicks=row[9],
                unique_clicks=row[10],
                conversions=row[11],
                commission=row[12],
                revenue=row[13],
                created_at=row[14],
                last_clicked_at=row[15],
                is_active=bool(row[16]),
                is_paused=bool(row[17]),
            )
            self._links[link.link_id] = link

        conn.close()

    def _save_link(self, link: CloakedLink):
        """Save link to database."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute("""
            INSERT OR REPLACE INTO links VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            link.link_id,
            link.cloaked_url,
            link.original_url,
            link.network,
            link.offer_id,
            link.campaign,
            link.medium,
            link.source,
            link.content_id,
            link.clicks,
            link.unique_clicks,
            link.conversions,
            link.commission,
            link.revenue,
            link.created_at,
            link.last_clicked_at,
            int(link.is_active),
            int(link.is_paused),
        ))

        conn.commit()
        conn.close()

    def _record_click_event(self, link_id: str, ip_hash: str = "", user_agent: str = "", referrer: str = ""):
        """Record a click event."""
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        click_id = f"clk_{uuid.uuid4().hex[:16]}"
        timestamp = datetime.utcnow().isoformat()

        cursor.execute("""
            INSERT INTO clicks (click_id, link_id, timestamp, ip_hash, user_agent, referrer)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (click_id, link_id, timestamp, ip_hash, user_agent, referrer))

        conn.commit()
        conn.close()

    # =========================================================================
    # Link Creation
    # =========================================================================

    def cloak_link(
        self,
        original_url: str,
        link_id: Optional[str] = None,
        network: str = "unknown",
        offer_id: str = "",
        campaign: str = "",
        medium: str = "",
        source: str = "",
        content_id: str = "",
        slug: Optional[str] = None
    ) -> str:
        """
        Create a cloaked version of a URL.

        Args:
            original_url: The original affiliate URL
            link_id: Optional internal ID (generated if not provided)
            network: Affiliate network name
            offer_id: Associated offer ID
            campaign: Campaign name
            medium: Traffic medium (tiktok, youtube, etc)
            source: Traffic source
            content_id: Content piece ID
            slug: Custom URL slug (generated from URL if not provided)

        Returns:
            The cloaked URL
        """
        link_id = link_id or f"lnk_{uuid.uuid4().hex[:12]}"

        # Generate slug if not provided
        if not slug:
            slug = self._generate_slug(original_url)

        # Build cloaked URL
        cloaked_url = f"https://{self.base_domain}/{slug}"

        # Create link object
        link = CloakedLink(
            link_id=link_id,
            cloaked_url=cloaked_url,
            original_url=original_url,
            network=network,
            offer_id=offer_id,
            campaign=campaign,
            medium=medium,
            source=source,
            content_id=content_id,
        )

        # Save to memory and DB
        self._links[link_id] = link
        self._save_link(link)

        self.logger.info(f"Cloaked link created: {link_id} -> {cloaked_url}")

        return cloaked_url

    def _generate_slug(self, url: str) -> str:
        """Generate a URL slug from URL hash."""
        # Create a deterministic slug based on URL hash
        url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
        return f"a{url_hash}"

    def get_link_by_cloaked(self, cloaked_url: str) -> Optional[CloakedLink]:
        """Get link by cloaked URL."""
        for link in self._links.values():
            if link.cloaked_url == cloaked_url:
                return link
        return None

    def get_link(self, link_id: str) -> Optional[CloakedLink]:
        """Get link by ID."""
        return self._links.get(link_id)

    # =========================================================================
    # Click Tracking
    # =========================================================================

    def record_click(
        self,
        link_id: str,
        ip_hash: str = "",
        user_agent: str = "",
        referrer: str = "",
        update_link: bool = True
    ) -> bool:
        """
        Record a click on a cloaked link.

        Returns True if click was recorded, False if link not found.
        """
        link = self._links.get(link_id)
        if not link:
            return False

        if link.is_paused:
            # Don't record clicks for paused links
            return False

        # Record click event
        self._record_click_event(link_id, ip_hash, user_agent, referrer)

        if update_link:
            # Update link stats
            link.clicks += 1
            link.unique_clicks += 1
            link.last_clicked_at = datetime.utcnow().isoformat()
            self._save_link(link)

        self.logger.debug(f"Click recorded for link: {link_id}")

        return True

    def get_cloaked_url_for_redirect(self, link_id: str) -> Optional[str]:
        """Get the original URL for a cloaked link (for redirect)."""
        link = self._links.get(link_id)
        if link and link.is_active and not link.is_paused:
            return link.original_url
        return None

    # =========================================================================
    # Conversion Tracking
    # =========================================================================

    def record_conversion(
        self,
        link_id: str,
        commission: float = 0.0,
        revenue: float = 0.0,
        event_data: Optional[Dict] = None
    ) -> bool:
        """Record a conversion (sale) for a link."""
        link = self._links.get(link_id)
        if not link:
            self.logger.error(f"Link not found for conversion: {link_id}")
            return False

        # Update link stats
        link.conversions += 1
        link.commission += commission
        link.revenue += revenue

        # Update derived metrics
        if link.unique_clicks > 0:
            link.conversion_rate = (link.conversions / link.unique_clicks) * 100
        if link.unique_clicks > 0:
            link.epc = link.commission / link.unique_clicks

        self._save_link(link)

        self.logger.info(f"Conversion recorded: {link_id} - ${commission}")

        return True

    # =========================================================================
    # Analytics
    # =========================================================================

    def get_analytics(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        medium: Optional[str] = None,
        campaign: Optional[str] = None
    ) -> LinkAnalytics:
        """Get comprehensive link analytics."""
        links = list(self._links.values())

        # Apply filters
        if medium:
            links = [l for l in links if l.medium == medium]
        if campaign:
            links = [l for l in links if l.campaign == campaign]

        # Calculate analytics
        analytics = LinkAnalytics(
            total_links=len(links),
            active_links=len([l for l in links if l.is_active]),
            total_clicks=sum(l.clicks for l in links),
            unique_clicks=sum(l.unique_clicks for l in links),
            total_conversions=sum(l.conversions for l in links),
            total_commission=sum(l.commission for l in links),
            total_revenue=sum(l.revenue for l in links),
        )

        # Calculate rates
        if analytics.unique_clicks > 0:
            analytics.conversion_rate = (analytics.total_conversions / analytics.unique_clicks) * 100
        if analytics.unique_clicks > 0:
            analytics.avg_ctr = (analytics.unique_clicks / analytics.total_clicks * 100) if analytics.total_clicks > 0 else 0
        if analytics.total_conversions > 0:
            analytics.avg_order_value = analytics.total_revenue / analytics.total_conversions

        # By medium breakdown
        by_medium: Dict[str, Dict] = {}
        for link in links:
            if link.medium:
                if link.medium not in by_medium:
                    by_medium[link.medium] = {"clicks": 0, "conversions": 0, "commission": 0.0}
                by_medium[link.medium]["clicks"] += link.unique_clicks
                by_medium[link.medium]["conversions"] += link.conversions
                by_medium[link.medium]["commission"] += link.commission

        analytics.by_medium = by_medium

        # By campaign breakdown
        by_campaign: Dict[str, Dict] = {}
        for link in links:
            if link.campaign:
                if link.campaign not in by_campaign:
                    by_campaign[link.campaign] = {"clicks": 0, "conversions": 0, "commission": 0.0}
                by_campaign[link.campaign]["clicks"] += link.unique_clicks
                by_campaign[link.campaign]["conversions"] += link.conversions
                by_campaign[link.campaign]["commission"] += link.commission

        analytics.by_campaign = by_campaign

        return analytics

    def get_top_performing_links(self, limit: int = 10) -> List[CloakedLink]:
        """Get top performing links by commission."""
        links = list(self._links.values())
        links.sort(key=lambda x: x.commission, reverse=True)
        return links[:limit]

    def get_links_by_medium(self, medium: str) -> List[CloakedLink]:
        """Get all links for a specific medium."""
        return [l for l in self._links.values() if l.medium == medium]

    # =========================================================================
    # Link Management
    # =========================================================================

    def pause_link(self, link_id: str) -> bool:
        """Pause a link (stop recording clicks)."""
        link = self._links.get(link_id)
        if link:
            link.is_paused = True
            self._save_link(link)
            return True
        return False

    def resume_link(self, link_id: str) -> bool:
        """Resume a paused link."""
        link = self._links.get(link_id)
        if link:
            link.is_paused = False
            self._save_link(link)
            return True
        return False

    def deactivate_link(self, link_id: str) -> bool:
        """Deactivate a link permanently."""
        link = self._links.get(link_id)
        if link:
            link.is_active = False
            self._save_link(link)
            return True
        return False

    # =========================================================================
    # Media Organ Integration
    # =========================================================================

    def get_links_for_content(
        self,
        content_id: str,
        medium: str = ""
    ) -> List[CloakedLink]:
        """Get all affiliate links associated with content."""
        links = [l for l in self._links.values() if l.content_id == content_id]

        if medium:
            links = [l for l in links if l.medium == medium]

        return links

    def get_media_performance_report(self) -> Dict[str, Any]:
        """Get performance report for media organ integration."""
        platforms = ["tiktok", "youtube", "instagram", "twitter"]

        report = {}
        for platform in platforms:
            links = self.get_links_by_medium(platform)
            total_clicks = sum(l.unique_clicks for l in links)
            total_conversions = sum(l.conversions for l in links)
            total_commission = sum(l.commission for l in links)

            report[platform] = {
                "links": len(links),
                "clicks": total_clicks,
                "conversions": total_conversions,
                "commission": total_commission,
                "conversion_rate": (total_conversions / total_clicks * 100) if total_clicks > 0 else 0,
                "epc": (total_commission / total_clicks) if total_clicks > 0 else 0,
            }

        return report

    # =========================================================================
    # Export
    # =========================================================================

    def export_links_csv(self, filepath: str):
        """Export links to CSV."""
        import csv

        with open(filepath, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "link_id", "cloaked_url", "original_url", "network",
                "campaign", "medium", "source", "clicks", "unique_clicks",
                "conversions", "commission", "created_at"
            ])

            for link in self._links.values():
                writer.writerow([
                    link.link_id, link.cloaked_url, link.original_url, link.network,
                    link.campaign, link.medium, link.source, link.clicks, link.unique_clicks,
                    link.conversions, link.commission, link.created_at
                ])

        self.logger.info(f"Exported {len(self._links)} links to {filepath}")


def create_link_manager(config: Optional[Dict] = None) -> LinkManager:
    """Create a link manager instance."""
    config = config or {}
    return LinkManager(
        data_dir=config.get("data_dir", "data/affiliate/links"),
        base_domain=config.get("base_domain", "kp.link")
    )
