"""
ClickBank Integration.

Manages ClickBank affiliate offers, HopLinks, and API integration.
ClickBank is one of the largest affiliate networks with thousands of products.
"""
import asyncio
import hashlib
import hmac
import json
import logging
import os
import time
import urllib.parse
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger("affiliate.clickbank")


class ClickBankAPI:
    """
    ClickBank API integration.
    
    ClickBank offers:
    - Physical and digital products
    - High commission rates (30-70% common)
    - Recurring commissions for subscriptions
    - Quick approval for most offers
    
    Docs: https://developers.clickbank.com/
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        dev_key: Optional[str] = None,
        data_dir: str = "data/affiliate/clickbank"
    ):
        self.api_key = api_key or os.environ.get("CLICKBANK_API_KEY", "")
        self.api_secret = api_secret or os.environ.get("CLICKBANK_API_SECRET", "")
        self.dev_key = dev_key or os.environ.get("CLICKBANK_DEV_KEY", "")
        
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger("affiliate.clickbank.api")
        
        # API endpoints
        self.api_base = "https://api.clickbank.com/rest/1.3"
        self.sandbox_base = "https://sandbox.clickbank.com/rest/1.3"
        
        # Determine if using sandbox
        self.sandbox = os.environ.get("CLICKBANK_SANDBOX", "true").lower() == "true"
        self.base_url = self.sandbox_base if self.sandbox else self.api_base
        
        # Auth header
        self._auth_header = self._generate_auth() if self.api_key else ""
    
    def _generate_auth(self) -> str:
        """Generate ClickBank API authorization header."""
        import base64
        credentials = f"{self.api_key}:{self.api_secret}"
        return f"Basic {base64.b64encode(credentials.encode()).decode()}"
    
    async def get_vendor_list(self, category: Optional[str] = None) -> List[Dict]:
        """
        Get list of available vendors (sellers).
        
        Returns vendors with their offers.
        """
        # In production, would call ClickBank API
        # For now, return sample data structure
        
        vendors = [
            {
                "vendor_id": "vendor_001",
                "vendor_name": "TechPro Solutions",
                "nickname": "techpro",
                "categories": ["technology", "software"],
                "avg_commission": 45.0,
                "total_offers": 5,
            },
            {
                "vendor_id": "vendor_002",
                "vendor_name": "HealthMaster",
                "nickname": "healthmaster",
                "categories": ["health", "fitness"],
                "avg_commission": 50.0,
                "total_offers": 8,
            },
        ]
        
        if category:
            vendors = [v for v in vendors if category.lower() in str(v["categories"]).lower()]
        
        return vendors
    
    async def get_affiliate_offers(
        self,
        category: Optional[str] = None,
        min_commission: float = 30.0,
        limit: int = 50
    ) -> List['ClickBankOffer']:
        """
        Get affiliate offers from ClickBank.
        
        Args:
            category: Filter by category
            min_commission: Minimum commission rate
            limit: Maximum results
        """
        # In production, would call ClickBank API
        # For demo, return structured sample offers
        
        sample_offers = [
            ClickBankOffer(
                offer_id="cb_affiliate_001",
                vendor_id="vendor_tech",
                vendor_name="AI Tools Pro",
                name="AI Content Generator Pro",
                description="Create AI-powered content in seconds. Used by 10,000+ creators.",
                category="software",
                commission_rate=50.0,
                commission_type="cps",
                avg_sale_value=97.0,
                gravity=45.0,
                popular=False,
                recurring=True,
                cookie_days=60,
            ),
            ClickBankOffer(
                offer_id="cb_affiliate_002",
                vendor_id="vendor_health",
                vendor_name="Fitness Revolution",
                name="Home Workout App",
                description="Complete home fitness solution with AI trainer. 30-day money-back guarantee.",
                category="fitness",
                commission_rate=60.0,
                commission_type="cps",
                avg_sale_value=197.0,
                gravity=78.0,
                popular=True,
                recurring=True,
                cookie_days=60,
            ),
            ClickBankOffer(
                offer_id="cb_affiliate_003",
                vendor_id="vendor_biz",
                vendor_name="Business Tools Inc",
                name="Business Automation Suite",
                description="Automate your business workflows. Save 20+ hours per week.",
                category="business",
                commission_rate=40.0,
                commission_type="cps",
                avg_sale_value=297.0,
                gravity=32.0,
                popular=False,
                recurring=True,
                cookie_days=60,
            ),
            ClickBankOffer(
                offer_id="cb_affiliate_004",
                vendor_id="vendor_edu",
                vendor_name="LearnFast",
                name="Advanced Trading Course",
                description="Master day trading with our proven system. 90% success rate.",
                category="education",
                commission_rate=40.0,
                commission_type="cps",
                avg_sale_value=1997.0,
                gravity=25.0,
                popular=False,
                recurring=False,
                cookie_days=60,
            ),
        ]
        
        # Filter
        filtered = [o for o in sample_offers if o.commission_rate >= min_commission]
        
        if category:
            filtered = [o for o in filtered if o.category.lower() == category.lower()]
        
        return filtered[:limit]
    
    def generate_hoplink(
        self,
        nickname: str,
        tracking_id: str = "",
        campaign: str = ""
    ) -> str:
        """
        Generate a ClickBank HopLink.
        
        Format: https://nickname.hop.clickbank.net/?tid=tracking
        """
        base = f"https://{nickname}.hop.clickbank.net"
        
        params = []
        if tracking_id:
            params.append(f"tid={urllib.parse.quote(tracking_id)}")
        if campaign:
            params.append(f"campaign={urllib.parse.quote(campaign)}")
        
        if params:
            return f"{base}/?{'&'.join(params)}"
        
        return base


@dataclass
class ClickBankOffer:
    """A ClickBank affiliate offer."""
    offer_id: str
    vendor_id: str
    vendor_name: str
    name: str
    description: str
    category: str
    
    # Commission
    commission_rate: float
    commission_type: str = "cps"
    avg_sale_value: float = 0.0
    
    # Metrics
    gravity: float = 0.0  # ClickBank popularity metric
    popular: bool = False
    
    # Features
    recurring: bool = False
    cookie_days: int = 60
    
    # HopLink
    hoplink: str = ""
    
    # Status
    active: bool = True
    
    def get_hoplink(self, tracking_id: str = "") -> str:
        """Generate HopLink for this offer."""
        # Convert vendor name to ClickBank nickname format
        nickname = self.vendor_name.lower().replace(" ", "").replace("_", "")[:15]
        cb = ClickBankAPI()
        return cb.generate_hoplink(nickname, tracking_id)


@dataclass
class ClickBankHopLink:
    """A ClickBank HopLink with tracking."""
    hoplink_id: str
    vendor_nickname: str
    full_url: str
    
    # Tracking
    tracking_id: str = ""
    campaign: str = ""
    
    # Analytics
    clicks: int = 0
    conversions: int = 0
    commission: float = 0.0
    
    def __post_init__(self):
        # Build full URL
        base = f"https://{self.vendor_nickname}.hop.clickbank.net"
        params = []
        if self.tracking_id:
            params.append(f"tid={self.tracking_id}")
        if self.campaign:
            params.append(f"campaign={self.campaign}")
        
        if params:
            self.full_url = f"{base}/?{'&'.join(params)}"
        else:
            self.full_url = base


class ClickBankHopLinkBuilder:
    """
    Builder for ClickBank HopLinks with tracking.
    """
    
    def __init__(self, engine: Optional['AffiliateEngine'] = None):
        self.engine = engine
        self.logger = logging.getLogger("affiliate.clickbank.hoplinks")
    
    def build(
        self,
        vendor_nickname: str,
        tracking_id: str = "",
        campaign: str = "",
        medium: str = "",
        source: str = ""
    ) -> ClickBankHopLink:
        """Build a tracked HopLink."""
        hoplink_id = f"cb_hop_{uuid.uuid4().hex[:12]}"
        
        cb = ClickBankAPI()
        full_url = cb.generate_hoplink(vendor_nickname, tracking_id, campaign)
        
        hoplink = ClickBankHopLink(
            hoplink_id=hoplink_id,
            vendor_nickname=vendor_nickname,
            full_url=full_url,
            tracking_id=tracking_id,
            campaign=campaign,
        )
        
        # Save to engine if available
        if self.engine:
            self.engine.record_click(hoplink_id)
        
        return hoplink


# Sample ClickBank offers for demo
CLICKBANK_SAMPLE_CATEGORIES = [
    "software",
    "fitness",
    "health",
    "business",
    "education",
    "gaming",
    "travel",
    "food",
    "self_help",
    "arts",
]


# Helper to get ClickBank offers
async def fetch_clickbank_offers(
    category: Optional[str] = None,
    min_commission: float = 30.0
) -> List[ClickBankOffer]:
    """Fetch offers from ClickBank (mock for now)."""
    api = ClickBankAPI()
    return await api.get_affiliate_offers(category, min_commission)


import uuid
