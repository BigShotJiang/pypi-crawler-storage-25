"""
Revenue Organs - Organ Initialization and Mesh Wiring.

Initializes the three revenue organs (Affiliate, Media, Clipping) and
wires them together and to the SIMP mesh for system-wide communication.

Usage:
    from simp.organs.affiliate import initialize_revenue_organs
    organs = initialize_revenue_organs(mesh_bus)

Author: KashClaw Ecosystem
"""
import asyncio
import logging
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("organ.revenue_init")


def initialize_affiliate_organ(
    data_dir: str = "data/affiliate",
    config: Optional[Dict] = None
) -> Tuple['AffiliateEngine', 'LinkManager']:
    """
    Initialize the Affiliate Marketing organ.

    Args:
        data_dir: Directory for affiliate data
        config: Optional configuration

    Returns:
        Tuple of (AffiliateEngine, LinkManager)
    """
    from simp.organs.affiliate import AffiliateEngine, LinkManager, create_link_manager

    # Create engine
    engine = AffiliateEngine(data_dir=data_dir, config=config)

    # Create and attach link manager
    link_manager = create_link_manager({"data_dir": f"{data_dir}/links"})
    engine.link_manager = link_manager

    logger.info("Affiliate organ initialized")

    return engine, link_manager


def initialize_media_organ(
    data_dir: str = "data/media",
    config: Optional[Dict] = None
) -> Any:
    """
    Initialize the Media organ.

    Args:
        data_dir: Directory for media data
        config: Optional configuration

    Returns:
        Media organ instance
    """
    try:
        from simp.organs.media import MediaOrgan

        organ = MediaOrgan(data_dir=data_dir, config=config)
        logger.info("Media organ initialized")
        return organ

    except ImportError as e:
        logger.warning(f"Media organ not available: {e}")
        return None


def initialize_clipping_organ(
    data_dir: str = "data/clipping",
    config: Optional[Dict] = None
) -> Any:
    """
    Initialize the Content Clipping organ.

    Args:
        data_dir: Directory for clipping data
        config: Optional configuration

    Returns:
        ContentClippingEngine instance
    """
    try:
        from simp.organs.media.content_clipping import ContentClippingEngine

        engine = ContentClippingEngine(data_dir=data_dir)
        logger.info("Clipping organ initialized")
        return engine

    except ImportError as e:
        logger.warning(f"Clipping organ not available: {e}")
        return None


def wire_organs_together(
    affiliate_engine: 'AffiliateEngine',
    media_organ: Any,
    clipping_engine: Any
) -> Dict[str, Any]:
    """
    Wire the three organs together for direct communication.

    Args:
        affiliate_engine: The affiliate engine
        media_organ: The media organ
        clipping_engine: The clipping engine

    Returns:
        Dict of wired integrations
    """
    from simp.organs.affiliate import (
        AffiliateMediaIntegrator,
        AffiliateClippingIntegrator,
    )

    integrations = {}

    # Wire Affiliate -> Media
    if media_organ:
        try:
            media_integrator = AffiliateMediaIntegrator(affiliate_engine)
            integrations["media"] = media_integrator
            logger.info("Affiliate -> Media integration wired")
        except Exception as e:
            logger.error(f"Failed to wire Affiliate -> Media: {e}")

    # Wire Affiliate -> Clipping
    if clipping_engine:
        try:
            clipping_integrator = AffiliateClippingIntegrator(
                affiliate_engine, clipping_engine
            )
            integrations["clipping"] = clipping_integrator
            logger.info("Affiliate -> Clipping integration wired")
        except Exception as e:
            logger.error(f"Failed to wire Affiliate -> Clipping: {e}")

    return integrations


def connect_to_mesh(
    affiliate_engine: 'AffiliateEngine',
    media_organ: Any,
    clipping_engine: Any,
    mesh_bus: Any
) -> 'OrganMeshManager':
    """
    Connect all revenue organs to the SIMP mesh.

    Args:
        affiliate_engine: The affiliate engine
        media_organ: The media organ
        clipping_engine: The clipping engine
        mesh_bus: The EnhancedMeshBus instance

    Returns:
        OrganMeshManager with all gateways connected
    """
    from simp.organs.affiliate.mesh_integration import (
        AffiliateMeshGateway,
        MediaMeshGateway,
        ClippingMeshGateway,
        OrganMeshManager,
    )

    # Register agents with mesh first
    if hasattr(mesh_bus, 'register_agent'):
        mesh_bus.register_agent("affiliate_organ")
        mesh_bus.register_agent("media_organ")
        mesh_bus.register_agent("clipping_organ")

    # Subscribe to channels
    if hasattr(mesh_bus, 'subscribe'):
        # Affiliate subscribes to media and clipping channels
        mesh_bus.subscribe("affiliate_organ", "affiliate.media")
        mesh_bus.subscribe("affiliate_organ", "affiliate.clipping")
        # Media subscribes to affiliate offers
        mesh_bus.subscribe("media_organ", "affiliate.offers")
        mesh_bus.subscribe("media_organ", "affiliate.clicks")
        # Clipping subscribes to affiliate offers
        mesh_bus.subscribe("clipping_organ", "affiliate.offers")
        mesh_bus.subscribe("clipping_organ", "affiliate.commissions")

    # Create and connect gateways
    manager = OrganMeshManager(
        affiliate_engine=affiliate_engine,
        media_organ=media_organ,
        clipping_engine=clipping_engine,
        mesh_bus=mesh_bus
    )

    manager.connect_all(mesh_bus)

    logger.info("All revenue organs connected to mesh")

    return manager


def initialize_revenue_organs(
    mesh_bus: Any,
    data_dir: str = "data/revenue"
) -> Dict[str, Any]:
    """
    Initialize all revenue organs and wire them together and to mesh.

    This is the main entry point for bringing up the revenue system.

    Args:
        mesh_bus: The EnhancedMeshBus instance
        data_dir: Base directory for revenue organ data

    Returns:
        Dict containing:
            - affiliate_engine
            - affiliate_link_manager
            - media_organ
            - clipping_engine
            - mesh_manager
            - integrations
    """
    logger.info("Initializing revenue organs...")

    # Initialize organs
    affiliate_engine, link_manager = initialize_affiliate_organ(
        data_dir=f"{data_dir}/affiliate"
    )

    media_organ = initialize_media_organ(data_dir=f"{data_dir}/media")

    clipping_engine = initialize_clipping_organ(data_dir=f"{data_dir}/clipping")

    # Wire organs together
    integrations = wire_organs_together(
        affiliate_engine, media_organ, clipping_engine
    )

    # Connect to mesh
    mesh_manager = connect_to_mesh(
        affiliate_engine, media_organ, clipping_engine, mesh_bus
    )

    # Sync initial state
    mesh_manager.sync_all_state()

    result = {
        "affiliate_engine": affiliate_engine,
        "affiliate_link_manager": link_manager,
        "media_organ": media_organ,
        "clipping_engine": clipping_engine,
        "mesh_manager": mesh_manager,
        "integrations": integrations,
    }

    logger.info("Revenue organs initialization complete")

    return result


def get_revenue_dashboard() -> Dict[str, Any]:
    """
    Get unified revenue dashboard across all organs.

    Returns:
        Dict with revenue stats from all organs
    """
    # This would get stats from all three organs
    return {
        "status": "operational",
        "organs": {
            "affiliate": "active",
            "media": "active",
            "clipping": "active"
        }
    }


# ─────────────────────────────────────────────────────────────────────────────
# Quick Start Functions
# ─────────────────────────────────────────────────────────────────────────────

def quick_start_affiliate(mesh_bus: Optional[Any] = None) -> Dict[str, Any]:
    """
    Quick start for affiliate organ only.

    Args:
        mesh_bus: Optional mesh bus to connect to

    Returns:
        Dict with affiliate components
    """
    engine, link_manager = initialize_affiliate_organ()

    if mesh_bus:
        gateway = AffiliateMeshGateway(engine)
        gateway.connect_to_mesh(mesh_bus)

        return {
            "engine": engine,
            "link_manager": link_manager,
            "mesh_gateway": gateway,
        }

    return {
        "engine": engine,
        "link_manager": link_manager,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Mesh Message Handlers Setup
# ─────────────────────────────────────────────────────────────────────────────

def setup_mesh_message_handlers(
    mesh_bus: Any,
    affiliate_engine: 'AffiliateEngine',
    affiliate_gateway: 'AffiliateMeshGateway'
) -> None:
    """
    Set up handlers for mesh messages from other organs.

    Args:
        mesh_bus: The mesh bus
        affiliate_engine: The affiliate engine
        affiliate_gateway: The affiliate mesh gateway
    """
    # Media organ message handler
    def handle_media_message(packet: Any) -> None:
        try:
            payload = packet.get("payload", {})
            packet_type = payload.get("packet_type", "")

            if packet_type == "affiliate.media.performance":
                # Handle media performance data
                content_id = payload.get("content_id", "")
                clicks = payload.get("clicks", 0)
                logger.info(f"Media performance: {content_id} - {clicks} clicks")

            elif packet_type == "affiliate.media.content_ready":
                # Handle content ready notification
                content_id = payload.get("content_id", "")
                logger.info(f"Media content ready: {content_id}")

        except Exception as e:
            logger.error(f"Error handling media message: {e}")

    # Clipping organ message handler
    def handle_clipping_message(packet: Any) -> None:
        try:
            payload = packet.get("payload", {})
            packet_type = payload.get("packet_type", "")

            if packet_type == "affiliate.clipping.performance":
                # Handle clipping performance data
                clip_id = payload.get("clip_id", "")
                commission = payload.get("commission", 0.0)
                logger.info(f"Clipping performance: {clip_id} - ${commission}")

            elif packet_type == "affiliate.clipping.sponsored_clip":
                # Handle sponsored clip notification
                clip_id = payload.get("clip_id", "")
                logger.info(f"Sponsored clip created: {clip_id}")

        except Exception as e:
            logger.error(f"Error handling clipping message: {e}")

    # Register handlers
    if hasattr(mesh_bus, 'add_message_handler'):
        mesh_bus.add_message_handler("affiliate.media", handle_media_message)
        mesh_bus.add_message_handler("affiliate.clipping", handle_clipping_message)

    logger.info("Mesh message handlers set up")


# ─────────────────────────────────────────────────────────────────────────────
# Type Hints
# ─────────────────────────────────────────────────────────────────────────────

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from simp.organs.affiliate.affiliate_engine import AffiliateEngine
    from simp.organs.affiliate.mesh_integration import OrganMeshManager, AffiliateMeshGateway
