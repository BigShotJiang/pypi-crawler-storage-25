"""
Clipping Integration - Affiliate + Clipping Organ Integration.

Connects the Affiliate Marketing Organ with the Content Clipping organ
for sponsored clip monetization and revenue flow.
"""
import asyncio
import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

logger = logging.getLogger("affiliate.clipping_integration")


@dataclass
class SponsoredClipOpportunity:
    """
    A clip opportunity with affiliate potential.
    """
    opportunity_id: str
    source_platform: str  # twitch, youtube, tiktok, kick, rumble
    source_content_id: str
    source_url: str

    # Content details
    title: str = ""
    creator: str = ""
    category: str = ""
    niche: str = ""
    duration_seconds: int = 0

    # Virality potential
    virality_score: float = 0.0  # 0-100
    trending_score: float = 0.0

    # Affiliate fit
    affiliate_offer_id: str = ""
    affiliate_fit_score: float = 0.0  # How well this clip fits an affiliate offer
    recommended_products: List[str] = field(default_factory=list)

    # Revenue potential
    estimated_views: int = 0
    estimated_ctr: float = 0.0  # Click-through rate
    estimated_conversion_rate: float = 0.0
    estimated_revenue_per_clip: float = 0.0

    # Status
    status: str = "pending"  # pending, approved, clip_created, published, monetized
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())


@dataclass
class SponsoredClipResult:
    """
    Result of creating a sponsored clip.
    """
    result_id: str
    opportunity_id: str
    clip_id: str

    # Content
    clip_title: str = ""
    clip_description: str = ""
    clip_tags: List[str] = field(default_factory=list)

    # Affiliate integration
    affiliate_link: str = ""
    affiliate_offers_used: List[str] = field(default_factory=list)
    product_mentions: List[str] = field(default_factory=list)

    # Platform
    target_platforms: List[str] = field(default_factory=list)

    # Performance
    estimated_reach: int = 0
    projected_clicks: int = 0
    projected_conversions: int = 0
    projected_revenue: float = 0.0

    # Metadata
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    status: str = "created"


@dataclass
class ClipAffiliateMapping:
    """
    Maps a clip to affiliate offers for monetization.
    """
    mapping_id: str
    clip_id: str
    opportunity_id: str

    # Products to mention
    primary_offer_id: str = ""
    secondary_offer_ids: List[str] = field(default_factory=list)

    # Placement
    in_clip_mention: bool = True  # Mention during clip
    link_in_description: bool = True
    cta_during_clip: str = ""

    # Revenue
    estimated_revenue: float = 0.0
    actual_revenue: float = 0.0


class AffiliateClippingIntegrator:
    """
    Integrates Affiliate Marketing with Content Clipping.

    Enables:
    - Identifying sponsored clip opportunities
    - Matching clips to affiliate offers
    - Generating affiliate-ready clip content
    - Tracking clip revenue
    - Optimizing clip-to-conversion flow
    """

    def __init__(
        self,
        affiliate_engine: Optional['AffiliateEngine'] = None,
        clipping_engine: Optional['ContentClippingEngine'] = None
    ):
        self.engine = affiliate_engine
        self.clipping = clipping_engine
        self.logger = logging.getLogger("affiliate.clipping_integrator")

        # Data directory
        self.data_dir = Path("data/affiliate/clipping")
        self.data_dir.mkdir(parents=True, exist_ok=True)

        # In-memory storage for opportunities
        self._opportunities: Dict[str, SponsoredClipOpportunity] = {}
        self._load_opportunities()

        # Sponsored clip pipeline
        self.pipeline = SponsoredClipPipeline(affiliate_engine, self)

    def _load_opportunities(self):
        """Load opportunities from disk."""
        opp_file = self.data_dir / "opportunities.json"
        if opp_file.exists():
            with open(opp_file) as f:
                data = json.load(f)
                for opp_data in data.values():
                    try:
                        opp = SponsoredClipOpportunity(**opp_data)
                        self._opportunities[opp.opportunity_id] = opp
                    except Exception:
                        pass

    def _save_opportunities(self):
        """Save opportunities to disk."""
        opp_file = self.data_dir / "opportunities.json"
        data = {k: v.__dict__ for k, v in self._opportunities.items()}
        with open(opp_file, "w") as f:
            json.dump(data, f, indent=2)

    # =========================================================================
    # Opportunity Discovery
    # =========================================================================

    def discover_sponsored_opportunities(
        self,
        platforms: List[str] = None,
        niches: List[str] = None,
        min_virality: float = 50.0
    ) -> List[SponsoredClipOpportunity]:
        """
        Discover clip opportunities with affiliate potential.

        Args:
            platforms: Platforms to monitor (twitch, youtube, etc)
            niches: Content niches to focus on
            min_virality: Minimum virality score

        Returns:
            List of opportunities with affiliate fit
        """
        platforms = platforms or ["twitch", "youtube", "tiktok", "kick"]
        niches = niches or ["tech", "fitness", "business", "gaming", "lifestyle"]

        opportunities = []

        # Would integrate with clipping organ here
        # For now, generate sample opportunities
        for platform in platforms:
            for niche in niches:
                opp = SponsoredClipOpportunity(
                    opportunity_id=f"opp_{uuid.uuid4().hex[:12]}",
                    source_platform=platform,
                    source_content_id=f"{platform}_{uuid.uuid4().hex[:8]}",
                    source_url=f"https://{platform}.com/video/example",
                    title=f"Trending {niche} content on {platform}",
                    creator="Example Creator",
                    category=niche,
                    niche=niche,
                    duration_seconds=180,
                    virality_score=70.0,
                    trending_score=65.0,
                )

                # Find matching affiliate offers
                matching_offers = self._find_offers_for_niche(niche)
                if matching_offers:
                    opp.affiliate_offer_id = matching_offers[0].offer_id
                    opp.affiliate_fit_score = self._calculate_affiliate_fit(
                        opp, matching_offers[0]
                    )
                    opp.recommended_products = [o.name for o in matching_offers[:3]]

                    # Calculate revenue potential
                    opp.estimated_revenue_per_clip = self._estimate_revenue(
                        opp, matching_offers[0]
                    )

                if opp.virality_score >= min_virality:
                    opportunities.append(opp)
                    self._opportunities[opp.opportunity_id] = opp

        self._save_opportunities()

        self.logger.info(f"Discovered {len(opportunities)} sponsored opportunities")

        return opportunities

    def _find_offers_for_niche(
        self,
        niche: str
    ) -> List['AffiliateOffer']:
        """Find affiliate offers matching a niche."""
        if not self.engine:
            return []

        offers = self.engine.search_offers(
            query=niche,
            min_commission=10.0
        )

        return offers[:5]  # Top 5 matches

    def _calculate_affiliate_fit(
        self,
        opportunity: SponsoredClipOpportunity,
        offer: 'AffiliateOffer'
    ) -> float:
        """Calculate how well an opportunity fits an offer."""
        score = 0.0

        # Niche match
        if opportunity.niche.lower() in offer.tags:
            score += 0.4

        # Content type fit
        if opportunity.source_platform in offer.platforms:
            score += 0.2

        # Commission fit
        if offer.commission_rate >= 30:
            score += 0.2

        # Virality bonus
        if opportunity.virality_score >= 70:
            score += 0.2

        return min(score, 1.0)

    def _estimate_revenue(
        self,
        opportunity: SponsoredClipOpportunity,
        offer: 'AffiliateOffer'
    ) -> float:
        """Estimate revenue potential for a clip."""
        # Base views estimate
        base_views = 1000

        # Adjust for virality
        virality_multiplier = opportunity.virality_score / 50

        estimated_views = int(base_views * virality_multiplier)

        # Click through
        ctr = 0.02  # 2% typical CTR
        clicks = int(estimated_views * ctr)

        # Conversion
        conversion_rate = offer.conversion_rate / 100
        conversions = int(clicks * conversion_rate)

        # Revenue per conversion
        revenue_per_sale = offer.calculate_earnings(1)

        return conversions * revenue_per_sale

    # =========================================================================
    # Sponsored Clip Creation
    # =========================================================================

    def create_sponsored_clip(
        self,
        opportunity_id: str,
        clip_title: str = "",
        add_affiliate_mentions: bool = True,
        mention_position: str = "mid"
    ) -> Optional[SponsoredClipResult]:
        """
        Create a sponsored clip from an opportunity.

        Args:
            opportunity_id: The opportunity to create from
            clip_title: Custom title for the clip
            add_affiliate_mentions: Whether to add product mentions
            mention_position: Where to place mentions (start, mid, end)

        Returns:
            Result with clip details and affiliate links
        """
        opportunity = self._opportunities.get(opportunity_id)
        if not opportunity:
            self.logger.error(f"Opportunity not found: {opportunity_id}")
            return None

        result_id = f"scr_{uuid.uuid4().hex[:12]}"
        clip_id = f"clip_{uuid.uuid4().hex[:12]}"

        # Get affiliate offers
        offers = []
        if opportunity.affiliate_offer_id and self.engine:
            offer = self.engine.get_offer(opportunity.affiliate_offer_id)
            if offer:
                offers.append(offer)

        # Create affiliate links
        affiliate_offers_used = []
        product_mentions = []
        affiliate_link = ""

        if add_affiliate_mentions and offers:
            primary_offer = offers[0]
            affiliate_offers_used.append(primary_offer.offer_id)
            product_mentions.append(primary_offer.name)

            # Create tracking link
            link = self.engine.create_link(
                primary_offer.offer_id,
                campaign=f"clip_{opportunity.source_platform}",
                medium=opportunity.source_platform,
                source=opportunity.creator,
                content_id=clip_id,
                cloak=True
            )

            if link:
                affiliate_link = link.cloaked_url

        # Build clip description
        clip_description = self._build_clip_description(opportunity, offers)

        # Build tags
        clip_tags = self._build_clip_tags(opportunity)

        result = SponsoredClipResult(
            result_id=result_id,
            opportunity_id=opportunity_id,
            clip_id=clip_id,
            clip_title=clip_title or f"{opportunity.title} - Sponsored",
            clip_description=clip_description,
            clip_tags=clip_tags,
            affiliate_link=affiliate_link,
            affiliate_offers_used=affiliate_offers_used,
            product_mentions=product_mentions,
            target_platforms=self._get_target_platforms(opportunity),
            estimated_reach=opportunity.estimated_views or 1000,
            projected_clicks=int((opportunity.estimated_views or 1000) * 0.02),
            projected_conversions=int((opportunity.estimated_views or 1000) * 0.02 * 0.05),
            projected_revenue=opportunity.estimated_revenue_per_clip or 5.0,
        )

        # Update opportunity status
        opportunity.status = "clip_created"
        self._save_opportunities()

        self.logger.info(f"Created sponsored clip: {clip_id}")

        return result

    def _build_clip_description(
        self,
        opportunity: SponsoredClipOpportunity,
        offers: List['AffiliateOffer']
    ) -> str:
        """Build clip description with affiliate links."""
        desc = f"""
{opportunity.title}

Original content by: {opportunity.creator}
Platform: {opportunity.source_platform}

💰 Related Products:
"""

        for offer in offers:
            desc += f"- {offer.name}: {offer.description[:100]}...\n"

        desc += """
🔗 Links in bio

#sponsored #affiliate #clip #viral
"""
        return desc.strip()

    def _build_clip_tags(self, opportunity: SponsoredClipOpportunity) -> List[str]:
        """Build tags for a clip."""
        tags = [
            "sponsored",
            "affiliate",
            "clip",
            opportunity.niche,
            opportunity.source_platform,
        ]

        # Add niche-specific tags
        if opportunity.niche == "tech":
            tags.extend(["#tech", "#gadgets", "#review"])
        elif opportunity.niche == "fitness":
            tags.extend(["#fitness", "#workout", "#health"])

        return tags[:10]

    def _get_target_platforms(
        self,
        opportunity: SponsoredClipOpportunity
    ) -> List[str]:
        """Get target platforms for reposting."""
        # Viral clips go everywhere
        if opportunity.virality_score >= 80:
            return ["tiktok", "youtube_shorts", "instagram_reels"]
        elif opportunity.virality_score >= 60:
            return ["tiktok", "youtube_shorts"]
        else:
            return ["tiktok"]

    # =========================================================================
    # Batch Operations
    # =========================================================================

    def batch_create_sponsored_clips(
        self,
        opportunity_ids: List[str],
        add_affiliate_mentions: bool = True
    ) -> List[SponsoredClipResult]:
        """Create multiple sponsored clips."""
        results = []

        for opp_id in opportunity_ids:
            result = self.create_sponsored_clip(opp_id, add_affiliate_mentions=add_affiliate_mentions)
            if result:
                results.append(result)

        self.logger.info(f"Batch created {len(results)} sponsored clips")

        return results

    # =========================================================================
    # Performance Tracking
    # =========================================================================

    def record_clip_performance(
        self,
        clip_id: str,
        views: int = 0,
        clicks: int = 0,
        conversions: int = 0,
        commission: float = 0.0
    ) -> bool:
        """
        Record performance for a sponsored clip.

        This is called by the Clipping Organ when performance data is available.
        """
        self.logger.info(
            f"Clip performance: {clip_id} - "
            f"{views} views, {clicks} clicks, {conversions} conversions, ${commission}"
        )

        # Update opportunity
        for opp in self._opportunities.values():
            if opp.status == "clip_created":
                opp.status = "monetized"

        self._save_opportunities()

        return True

    def get_clipping_affiliate_report(self) -> Dict[str, Any]:
        """
        Get report on clipping-to-affiliate performance.

        Shows revenue generated through the clipping organ.
        """
        total_opportunities = len(self._opportunities)
        monetized = sum(
            1 for o in self._opportunities.values()
            if o.status in ["published", "monetized"]
        )

        total_projected_revenue = sum(
            o.estimated_revenue_per_clip for o in self._opportunities.values()
        )

        # By platform
        by_platform = {}
        for opp in self._opportunities.values():
            platform = opp.source_platform
            if platform not in by_platform:
                by_platform[platform] = {"count": 0, "revenue": 0.0}
            by_platform[platform]["count"] += 1
            by_platform[platform]["revenue"] += opp.estimated_revenue_per_clip

        # By niche
        by_niche = {}
        for opp in self._opportunities.values():
            niche = opp.niche
            if niche not in by_niche:
                by_niche[niche] = {"count": 0, "revenue": 0.0}
            by_niche[niche]["count"] += 1
            by_niche[niche]["revenue"] += opp.estimated_revenue_per_clip

        return {
            "total_opportunities": total_opportunities,
            "monetized_opportunities": monetized,
            "monetization_rate": (monetized / total_opportunities * 100) if total_opportunities > 0 else 0,
            "total_projected_revenue": total_projected_revenue,
            "by_platform": by_platform,
            "by_niche": by_niche,
            "top_opportunities": self._get_top_opportunities(5),
        }

    def _get_top_opportunities(
        self,
        limit: int
    ) -> List[Dict]:
        """Get top opportunities by revenue potential."""
        opportunities = list(self._opportunities.values())
        opportunities.sort(
            key=lambda x: x.estimated_revenue_per_clip,
            reverse=True
        )

        return [
            {
                "opportunity_id": o.opportunity_id,
                "title": o.title,
                "platform": o.source_platform,
                "niche": o.niche,
                "virality_score": o.virality_score,
                "projected_revenue": o.estimated_revenue_per_clip,
                "status": o.status,
            }
            for o in opportunities[:limit]
        ]

    # =========================================================================
    # Integration with Clipping Organ
    # =========================================================================

    def get_affiliate_offers_for_clip(
        self,
        niche: str,
        count: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Get affiliate offers suitable for a clip in a niche.

        Called by Clipping Organ to get offers for a clip.
        """
        if not self.engine:
            return []

        offers = self.engine.search_offers(
            query=niche,
            min_commission=15.0
        )[:count]

        return [
            {
                "offer_id": o.offer_id,
                "name": o.name,
                "brand": o.brand,
                "commission_rate": o.commission_rate,
                "pitch_line": f"{int(o.commission_rate)}% commission on {o.name}",
                "affiliate_link": "",  # Created when clip is made
            }
            for o in offers
        ]

    def process_trending_content_for_affiliate(
        self,
        content_data: Dict[str, Any]
    ) -> Optional[SponsoredClipOpportunity]:
        """
        Process trending content from Clipping Organ and find affiliate match.

        Called when Clipping Organ finds trending content.
        """
        opportunity_id = f"opp_{uuid.uuid4().hex[:12]}"

        niche = content_data.get("niche", "")
        platform = content_data.get("platform", "unknown")

        opportunity = SponsoredClipOpportunity(
            opportunity_id=opportunity_id,
            source_platform=platform,
            source_content_id=content_data.get("content_id", ""),
            source_url=content_data.get("url", ""),
            title=content_data.get("title", "Trending Content"),
            creator=content_data.get("creator", "Unknown"),
            category=niche,
            niche=niche,
            duration_seconds=content_data.get("duration", 180),
            virality_score=content_data.get("virality_score", 60),
            trending_score=content_data.get("trending_score", 50),
        )

        # Find matching offers
        matching_offers = self._find_offers_for_niche(niche)
        if matching_offers:
            opportunity.affiliate_offer_id = matching_offers[0].offer_id
            opportunity.affiliate_fit_score = self._calculate_affiliate_fit(
                opportunity, matching_offers[0]
            )
            opportunity.recommended_products = [o.name for o in matching_offers[:3]]
            opportunity.estimated_revenue_per_clip = self._estimate_revenue(
                opportunity, matching_offers[0]
            )

        self._opportunities[opportunity_id] = opportunity
        self._save_opportunities()

        return opportunity


# ContentClippingEngine type hint
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from simp.organs.media.content_clipping import ContentClippingEngine


class SponsoredClipPipeline:
    """
    Pipeline for creating sponsored clips.

    Flow:
    1. Detect trending content opportunity
    2. Match with affiliate offers
    3. Generate clip with affiliate mentions
    4. Add tracking links
    5. Track performance
    """

    def __init__(
        self,
        affiliate_engine: Optional['AffiliateEngine'] = None,
        integrator: Optional[AffiliateClippingIntegrator] = None
    ):
        self.engine = affiliate_engine
        self.integrator = integrator
        self.logger = logging.getLogger("affiliate.clip_pipeline")

    def create_opportunity_from_trending(
        self,
        platform: str,
        content_id: str,
        title: str,
        creator: str,
        niche: str,
        virality_score: float
    ) -> SponsoredClipOpportunity:
        """Create an opportunity from trending content."""
        opportunity_id = f"opp_{uuid.uuid4().hex[:12]}"

        opportunity = SponsoredClipOpportunity(
            opportunity_id=opportunity_id,
            source_platform=platform,
            source_content_id=content_id,
            source_url=f"https://{platform}.com/video/{content_id}",
            title=title,
            creator=creator,
            niche=niche,
            virality_score=virality_score,
        )

        # Find offers
        if self.integrator and niche:
            matching = self.integrator._find_offers_for_niche(niche)
            if matching:
                opportunity.affiliate_offer_id = matching[0].offer_id
                opportunity.affiliate_fit_score = self.integrator._calculate_affiliate_fit(
                    opportunity, matching[0]
                )
                opportunity.estimated_revenue_per_clip = self.integrator._estimate_revenue(
                    opportunity, matching[0]
                )

        return opportunity


# Helper function
def create_clipping_integrator(
    affiliate_engine: Optional['AffiliateEngine'] = None
) -> AffiliateClippingIntegrator:
    """Create a clipping integrator instance."""
    return AffiliateClippingIntegrator(affiliate_engine)


import uuid
