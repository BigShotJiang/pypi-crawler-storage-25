"""
Luxury Brand Affiliate Programs.

Researched affiliate programs for luxury brands.
Note: Most luxury brands have selective/high-bar affiliate programs.
Many require applications and approval.
"""
import os
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any

logger = logging.getLogger("affiliate.luxury")


class LuxuryBrand(Enum):
    """Luxury brands with affiliate programs."""
    LOUIS_VUITTON = "louis_vuitton"
    GUCCI = "gucci"
    PRADA = "prada"
    HERMES = "hermes"
    CHANEL = "chanel"
    DIOR = "dior"
    BURBERRY = "burberry"
    VERSACE = "versace"
    FENDI = "fendi"
    BALENCIAGA = "balenciaga"
    ROLEX = "rolex"
    OMEGA = "omega"
    CARTIER = "cartier"
    TIFFANY = "tiffany"
    SNEADERS = "sneaders"


@dataclass
class LuxuryBrandAffiliate:
    """
    A luxury brand's affiliate program details.
    """
    brand: LuxuryBrand
    brand_name: str
    
    # Program details
    has_affiliate_program: bool = False
    affiliate_url: str = ""
    application_url: str = ""
    
    # Commission (luxury brands typically have lower rates but higher AOV)
    commission_rate: float = 0.0  # Percentage
    cookie_duration: int = 7  # Days (luxury brands often have shorter cookies)
    
    # Program specifics
    requires_approval: bool = True
    minimum_followers: int = 0
    niche_requirements: str = ""
    
    # Commission details
    commission_type: str = "standard"  # standard, rev_share, cpi
    payment_threshold: float = 50.0
    payment_methods: List[str] = field(default_factory=list)
    
    # Status
    program_active: bool = False
    notes: str = ""


class LuxuryBrandRegistry:
    """
    Registry of luxury brand affiliate programs.
    
    Research shows:
    - Louis Vuitton: NO affiliate program (brand protection policy)
    - Gucci: Partnerize network (5-10%, 15 day cookie)
    - Prada: Selective, application required
    - Hermes: NO affiliate program
    - Chanel: NO affiliate program (extremely selective)
    - Dior: Partnerize network (selective)
    - Rolex: NO affiliate program
    - Cartier: Partnerize network
    """
    
    def __init__(self):
        self.logger = logging.getLogger("affiliate.luxury.registry")
        self._brands: Dict[LuxuryBrand, LuxuryBrandAffiliate] = {}
        self._init_brands()
    
    def _init_brands(self):
        """Initialize luxury brand affiliate programs."""
        
        # Louis Vuitton - NO direct affiliate program
        self._brands[LuxuryBrand.LOUIS_VUITTON] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.LOUIS_VUITTON,
            brand_name="Louis Vuitton",
            has_affiliate_program=False,
            notes="Louis Vuitton does NOT offer affiliate programs. Brand protection is strict."
        )
        
        # Gucci - Partnerize
        self._brands[LuxuryBrand.GUCCI] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.GUCCI,
            brand_name="Gucci",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/gucci",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=7.0,
            cookie_duration=15,
            requires_approval=True,
            minimum_followers=10000,
            niche_requirements="Fashion, lifestyle, luxury content",
            commission_type="standard",
            payment_threshold=50.0,
            payment_methods=["PayPal", "Wire Transfer"],
            program_active=True,
            notes="Available through Partnerize network. High AOV = good earnings despite lower %."
        )
        
        # Prada - Selective
        self._brands[LuxuryBrand.PRADA] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.PRADA,
            brand_name="Prada",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/prada",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=5.0,
            cookie_duration=14,
            requires_approval=True,
            minimum_followers=50000,
            niche_requirements="Luxury fashion, high-end lifestyle",
            commission_type="standard",
            payment_threshold=100.0,
            payment_methods=["Wire Transfer"],
            program_active=True,
            notes="Selective approval. Premium aesthetic required."
        )
        
        # Hermes - NO affiliate
        self._brands[LuxuryBrand.HERMES] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.HERMES,
            brand_name="Hermès",
            has_affiliate_program=False,
            notes="Hermès does NOT offer affiliate programs."
        )
        
        # Chanel - NO affiliate
        self._brands[LuxuryBrand.CHANEL] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.CHANEL,
            brand_name="Chanel",
            has_affiliate_program=False,
            notes="Chanel does NOT offer affiliate programs. Extremely selective brand partnerships only."
        )
        
        # Dior - Partnerize
        self._brands[LuxuryBrand.DIOR] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.DIOR,
            brand_name="Dior",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/dior",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=5.0,
            cookie_duration=14,
            requires_approval=True,
            minimum_followers=25000,
            niche_requirements="Luxury fashion, beauty, lifestyle",
            commission_type="standard",
            payment_threshold=50.0,
            payment_methods=["PayPal", "Wire Transfer"],
            program_active=True,
            notes="Available through Partnerize. High brand recognition."
        )
        
        # Burberry
        self._brands[LuxuryBrand.BURBERRY] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.BURBERRY,
            brand_name="Burberry",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/burberry",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=6.0,
            cookie_duration=21,
            requires_approval=True,
            minimum_followers=10000,
            niche_requirements="British luxury, fashion",
            commission_type="standard",
            payment_threshold=50.0,
            payment_methods=["PayPal", "Wire Transfer"],
            program_active=True,
        )
        
        # Versace
        self._brands[LuxuryBrand.VERSACE] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.VERSACE,
            brand_name="Versace",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/versace",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=8.0,
            cookie_duration=30,
            requires_approval=True,
            minimum_followers=5000,
            niche_requirements="Fashion, bold luxury",
            commission_type="standard",
            payment_threshold=50.0,
            payment_methods=["PayPal", "Wire Transfer"],
            program_active=True,
        )
        
        # Rolex - NO affiliate
        self._brands[LuxuryBrand.ROLEX] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.ROLEX,
            brand_name="Rolex",
            has_affiliate_program=False,
            notes="Rolex does NOT offer affiliate programs. Authorized dealer network only."
        )
        
        # Cartier - Partnerize
        self._brands[LuxuryBrand.CARTIER] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.CARTIER,
            brand_name="Cartier",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/cartier",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=5.0,
            cookie_duration=14,
            requires_approval=True,
            minimum_followers=15000,
            niche_requirements="Jewelry, luxury watches, high-end lifestyle",
            commission_type="standard",
            payment_threshold=50.0,
            payment_methods=["Wire Transfer"],
            program_active=True,
        )
        
        # Tiffany - Partnerize
        self._brands[LuxuryBrand.TIFFANY] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.TIFFANY,
            brand_name="Tiffany & Co.",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/tiffany",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=5.0,
            cookie_duration=14,
            requires_approval=True,
            minimum_followers=10000,
            niche_requirements="Jewelry, luxury gifts",
            commission_type="standard",
            payment_threshold=50.0,
            payment_methods=["PayPal", "Wire Transfer"],
            program_active=True,
        )
        
        # Balenciaga
        self._brands[LuxuryBrand.BALENCIAGA] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.BALENCIAGA,
            brand_name="Balenciaga",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/balenciaga",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=7.0,
            cookie_duration=14,
            requires_approval=True,
            minimum_followers=10000,
            niche_requirements="Avant-garde fashion, streetwear-meets-luxury",
            commission_type="standard",
            payment_threshold=50.0,
            payment_methods=["PayPal", "Wire Transfer"],
            program_active=True,
        )
        
        # Fendi
        self._brands[LuxuryBrand.FENDI] = LuxuryBrandAffiliate(
            brand=LuxuryBrand.FENDI,
            brand_name="Fendi",
            has_affiliate_program=True,
            affiliate_url="https://partnerize.com/brand/fendi",
            application_url="https://partnerize.com/publishers/apply",
            commission_rate=6.0,
            cookie_duration=14,
            requires_approval=True,
            minimum_followers=10000,
            niche_requirements="Italian luxury, fashion",
            commission_type="standard",
            payment_threshold=50.0,
            payment_methods=["PayPal", "Wire Transfer"],
            program_active=True,
        )
        
        self.logger.info(f"Initialized {len(self._brands)} luxury brand entries")
    
    def get_brand(self, brand: LuxuryBrand) -> Optional[LuxuryBrandAffiliate]:
        """Get a luxury brand's affiliate details."""
        return self._brands.get(brand)
    
    def get_affiliate_brands(self) -> List[LuxuryBrandAffiliate]:
        """Get all brands that have affiliate programs."""
        return [
            b for b in self._brands.values()
            if b.has_affiliate_program and b.program_active
        ]
    
    def get_no_affiliate_brands(self) -> List[LuxuryBrandAffiliate]:
        """Get brands without affiliate programs."""
        return [
            b for b in self._brands.values()
            if not b.has_affiliate_program
        ]
    
    def search_brands(self, query: str) -> List[LuxuryBrandAffiliate]:
        """Search for brands by name."""
        q = query.lower()
        return [
            b for b in self._brands.values()
            if q in b.brand_name.lower()
        ]


# Singleton instance
_registry: Optional[LuxuryBrandRegistry] = None


def get_luxury_brands() -> LuxuryBrandRegistry:
    """Get luxury brand registry."""
    global _registry
    if _registry is None:
        _registry = LuxuryBrandRegistry()
    return _registry


# Additional luxury affiliate programs worth noting
ADDITIONAL_LUXURY_PROGRAMS = [
    {
        "brand": "Net-A-Porter",
        "commission": "8-12%",
        "cookie": "30 days",
        "network": "Partnerize",
        "notes": "Multi-brand luxury fashion"
    },
    {
        "brand": "Mr Porter",
        "commission": "8-12%",
        "cookie": "30 days",
        "network": "Partnerize",
        "notes": "Men's luxury fashion"
    },
    {
        "brand": "Farfetch",
        "commission": "5-12%",
        "cookie": "30 days",
        "network": "Own program",
        "notes": "Multi-brand luxury marketplace"
    },
    {
        "brand": "SSENSE",
        "commission": "8-10%",
        "cookie": "7 days",
        "network": "Direct",
        "notes": "Avant-garde luxury"
    },
    {
        "brand": "Matches Fashion",
        "commission": "10%",
        "cookie": "30 days",
        "network": "Partnerize",
        "notes": "UK luxury fashion"
    },
    {
        "brand": "Neiman Marcus",
        "commission": "5-12%",
        "cookie": "14 days",
        "network": "Own program",
        "notes": "US luxury department store"
    },
    {
        "brand": "Bergdorf Goodman",
        "commission": "5-10%",
        "cookie": "14 days",
        "network": "Own program",
        "notes": "NYC luxury department store"
    },
    {
        "brand": "Macy's Luxury",
        "commission": "8-12%",
        "cookie": "14 days",
        "network": "Own program",
        "notes": "Including Bloomingdales brands"
    },
]
