"""
Affiliate Marketing Engine - Core System.

Manages affiliate offers, links, commissions, and integrations
with Media Empire and Content Clipping organs.
"""
import asyncio
import hashlib
import json
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable

logger = logging.getLogger("affiliate.engine")


class AffiliateNetwork(Enum):
    """Supported affiliate networks."""
    CLICKBANK = "clickbank"
    SHAREASALE = "shareasale"
    AWIN = "awin"
    CJ_AFFILIATE = "cj_affiliate"
    REFERRAL = "referral"  # Direct referral programs
    SELF = "self"  # Own products
    # Luxury brands
    LOUIS_VUITTON = "louis_vuitton"
    GUCCI = "gucci"
    PRADA = "prada"
    HERMES = "hermes"
    CHANEL = "chanel"
    DIOR = "dior"
    # Tech brands
    APPLE = "apple"
    SAMSUNG = "samsung"
    SONY = "sony"
    # SaaS
    SHOPIFY = "shopify"
    SAMECART = "samecart"
    STRIPE = "stripe"


class OfferCategory(Enum):
    """Categories for affiliate offers."""
    TECH = "tech"
    SOFTWARE = "software"
    EDUCATION = "education"
    FASHION = "fashion"
    LUXURY = "luxury"
    HEALTH = "health"
    FITNESS = "fitness"
    BUSINESS = "business"
    CRYPTO = "crypto"
    GAMING = "gaming"
    LIFESTYLE = "lifestyle"
    SERVICES = "services"


class CommissionType(Enum):
    """Commission structure types."""
    CPS = "cps"  # Cost Per Sale
    CPL = "cpl"  # Cost Per Lead
    CPI = "cpi"  # Cost Per Install
    CPC = "cpc"  # Cost Per Click
    REV_SHARE = "rev_share"  # Revenue Share


class OfferStatus(Enum):
    """Status of an affiliate offer."""
    ACTIVE = "active"
    PAUSED = "paused"
    ARCHIVED = "archived"
    PENDING_APPROVAL = "pending_approval"


@dataclass
class AffiliateOffer:
    """
    An affiliate offer from a network or brand.
    """
    offer_id: str
    network: AffiliateNetwork
    
    # Identity
    name: str
    description: str
    brand: str
    
    # URLs
    offer_url: str = ""
    affiliate_link: str = ""
    hoplink: str = ""  # ClickBank-style
    
    # Commission
    commission_type: CommissionType = CommissionType.CPS
    commission_rate: float = 0.0  # Percentage or fixed amount
    commission_amount: float = 0.0  # Fixed amount if applicable
    cookie_duration: int = 30  # Days
    avg_sale_value: float = 0.0
    
    # Metrics
    epc: float = 0.0  # Earnings Per Click
    conversion_rate: float = 0.0
    total_sales: int = 0
    total_commission: float = 0.0
    
    # Categories and tags
    categories: List[OfferCategory] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    
    # Status
    status: OfferStatus = OfferStatus.ACTIVE
    
    # Media fit
    content_types: List[str] = field(default_factory=list)  # video, social, blog
    platforms: List[str] = field(default_factory=list)  # tiktok, youtube, etc
    niche_fit_score: float = 0.0  # 0-1 how well it fits our media
    
    # Approval
    is_approved: bool = False
    approval_notes: str = ""
    
    # Metadata
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    
    # Performance
    clicks_30d: int = 0
    conversions_30d: int = 0
    commission_30d: float = 0.0
    
    def calculate_earnings(self, units: int = 1) -> float:
        """Calculate potential earnings."""
        if self.commission_type == CommissionType.CPS:
            return units * self.commission_rate * self.avg_sale_value / 100
        elif self.commission_type == CommissionType.CPL:
            return units * self.commission_amount
        elif self.commission_type == CommissionType.CPC:
            return units * self.commission_amount
        return 0.0
    
    def get_monthly_potential(self, monthly_clicks: int = 1000) -> float:
        """Estimate monthly earnings potential."""
        expected_sales = monthly_clicks * self.conversion_rate / 100
        return self.calculate_earnings(int(expected_sales))


@dataclass
class AffiliateLink:
    """
    A tracked affiliate link with analytics.
    """
    link_id: str
    offer_id: str
    network: AffiliateNetwork
    
    # Link info
    original_url: str = ""
    cloaked_url: str = ""  # Our shortened/tracked URL
    final_url: str = ""  # Where user actually goes
    
    # Tracking
    campaign: str = ""
    medium: str = ""  # tiktok, youtube, twitter
    source: str = ""  # specific creator, channel
    content_id: str = ""  # specific content piece
    
    # Analytics
    clicks: int = 0
    unique_clicks: int = 0
    conversions: int = 0
    commission: float = 0.0
    
    # Timestamps
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    last_clicked_at: Optional[str] = None


@dataclass
class CommissionEvent:
    """A commission event (sale, lead, etc)."""
    event_id: str
    link_id: str
    offer_id: str
    network: AffiliateNetwork
    
    # Event data
    event_type: str = "sale"  # sale, lead, install, click
    amount: float = 0.0
    commission: float = 0.0
    currency: str = "USD"
    
    # Status
    status: str = "pending"  # pending, approved, rejected, paid
    paid_at: Optional[str] = None
    
    # Attribution
    click_id: str = ""
    sub_ids: Dict[str, str] = field(default_factory=dict)
    
    # Timestamps
    occurred_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class AffiliateEngine:
    """
    Core affiliate marketing engine.
    
    Manages:
    - Offer discovery and management
    - Link generation and cloaking
    - Commission tracking
    - Media organ integration
    - Clipping organ integration
    """
    
    def __init__(
        self,
        data_dir: str = "data/affiliate",
        config: Optional[Dict] = None
    ):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Subdirectories
        self.offers_dir = self.data_dir / "offers"
        self.links_dir = self.data_dir / "links"
        self.commissions_dir = self.data_dir / "commissions"
        self.offers_dir.mkdir(exist_ok=True)
        self.links_dir.mkdir(exist_ok=True)
        self.commissions_dir.mkdir(exist_ok=True)
        
        self.logger = logging.getLogger("affiliate.engine")
        self.config = config or {}
        
        # State
        self._offers: Dict[str, AffiliateOffer] = {}
        self._links: Dict[str, AffiliateLink] = {}
        self._commissions: List[CommissionEvent] = []
        
        # Load existing data
        self._load_offers()
        self._load_links()
        self._load_commissions()
        
        # Link manager
        self.link_manager: Optional['LinkManager'] = None
    
    def _load_offers(self):
        """Load offers from disk."""
        offers_file = self.offers_dir / "offers.json"
        if offers_file.exists():
            with open(offers_file) as f:
                data = json.load(f)
                for offer_data in data.values():
                    try:
                        offer = AffiliateOffer(**offer_data)
                        self._offers[offer.offer_id] = offer
                    except Exception:
                        pass
    
    def _save_offers(self):
        """Save offers to disk."""
        offers_file = self.offers_dir / "offers.json"
        # Convert enums to values for JSON serialization
        def enum_to_str(obj):
            if isinstance(obj, dict):
                return {k: enum_to_str(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [enum_to_str(i) for i in obj]
            elif isinstance(obj, Enum):
                return obj.value
            return obj
        data = {k: enum_to_str(v.__dict__) for k, v in self._offers.items()}
        with open(offers_file, "w") as f:
            json.dump(data, f, indent=2)
    
    def _load_links(self):
        """Load links from disk."""
        links_file = self.links_dir / "links.json"
        if links_file.exists():
            with open(links_file) as f:
                data = json.load(f)
                for link_data in data.values():
                    try:
                        link = AffiliateLink(**link_data)
                        self._links[link.link_id] = link
                    except Exception:
                        pass
    
    def _save_links(self):
        """Save links to disk."""
        links_file = self.links_dir / "links.json"
        # Convert enums to values for JSON serialization
        def enum_to_str(obj):
            if isinstance(obj, dict):
                return {k: enum_to_str(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [enum_to_str(i) for i in obj]
            elif isinstance(obj, Enum):
                return obj.value
            return obj
        data = {k: enum_to_str(v.__dict__) for k, v in self._links.items()}
        with open(links_file, "w") as f:
            json.dump(data, f, indent=2)
    
    def _load_commissions(self):
        """Load commissions from disk."""
        comm_file = self.commissions_dir / "commissions.jsonl"
        if comm_file.exists():
            with open(comm_file) as f:
                for line in f:
                    try:
                        data = json.loads(line)
                        self._commissions.append(CommissionEvent(**data))
                    except Exception:
                        pass
    
    def _save_commission(self, commission: CommissionEvent):
        """Save commission to disk."""
        comm_file = self.commissions_dir / "commissions.jsonl"
        def enum_to_str(obj):
            if isinstance(obj, dict):
                return {k: enum_to_str(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [enum_to_str(i) for i in obj]
            elif isinstance(obj, Enum):
                return obj.value
            return obj
        with open(comm_file, "a") as f:
            f.write(json.dumps(enum_to_str(commission.__dict__)) + "\n")
    
    # =========================================================================
    # Offer Management
    # =========================================================================
    
    def add_offer(self, offer: AffiliateOffer) -> AffiliateOffer:
        """Add an offer to the engine."""
        self._offers[offer.offer_id] = offer
        self._save_offers()
        self.logger.info(f"Added offer: {offer.name} ({offer.network.value})")
        return offer
    
    def get_offer(self, offer_id: str) -> Optional[AffiliateOffer]:
        """Get an offer by ID."""
        return self._offers.get(offer_id)
    
    def get_offers_by_network(self, network: AffiliateNetwork) -> List[AffiliateOffer]:
        """Get all offers from a network."""
        return [o for o in self._offers.values() if o.network == network]
    
    def get_offers_by_category(self, category: OfferCategory) -> List[AffiliateOffer]:
        """Get all offers in a category."""
        return [o for o in self._offers.values() if category in o.categories]
    
    def get_active_offers(self) -> List[AffiliateOffer]:
        """Get all active offers."""
        return [o for o in self._offers.values() if o.status == OfferStatus.ACTIVE]
    
    def search_offers(
        self,
        query: str = "",
        category: Optional[OfferCategory] = None,
        min_commission: float = 0,
        networks: Optional[List[AffiliateNetwork]] = None
    ) -> List[AffiliateOffer]:
        """Search offers by various criteria."""
        results = self._offers.values()
        
        # Filter by search query
        if query:
            q = query.lower()
            results = [
                o for o in results
                if q in o.name.lower() or q in o.description.lower() or q in o.brand.lower()
            ]
        
        # Filter by category
        if category:
            results = [o for o in results if category in o.categories]
        
        # Filter by commission
        if min_commission > 0:
            results = [o for o in results if o.commission_rate >= min_commission]
        
        # Filter by network
        if networks:
            results = [o for o in results if o.network in networks]
        
        # Filter active only
        results = [o for o in results if o.status == OfferStatus.ACTIVE]
        
        # Sort by niche fit score
        results.sort(key=lambda x: x.niche_fit_score, reverse=True)
        
        return results
    
    def get_offer_for_content(
        self,
        content_niche: str,
        content_type: str = "video",
        platform: str = "tiktok"
    ) -> Optional[AffiliateOffer]:
        """Find the best offer for specific content."""
        offers = self.search_offers(query=content_niche)
        
        if not offers:
            # Fall back to tech/lifestyle offers
            offers = self.search_offers(query="tech")
        
        # Score offers for this specific content
        for offer in offers:
            score = 0.0
            
            # Niche match
            if content_niche.lower() in offer.tags:
                score += 0.4
            
            # Content type fit
            if content_type in offer.content_types:
                score += 0.3
            
            # Platform fit
            if platform in offer.platforms:
                score += 0.2
            
            # Commission
            score += min(offer.commission_rate / 50, 0.1)  # Cap at 10%
            
            offer.niche_fit_score = score
        
        if offers:
            # Return highest scoring
            offers.sort(key=lambda x: x.niche_fit_score, reverse=True)
            return offers[0]
        
        return None
    
    # =========================================================================
    # Link Generation
    # =========================================================================
    
    def create_link(
        self,
        offer_id: str,
        campaign: str = "",
        medium: str = "",
        source: str = "",
        content_id: str = "",
        cloak: bool = True
    ) -> Optional[AffiliateLink]:
        """Create a tracked affiliate link."""
        offer = self.get_offer(offer_id)
        if not offer:
            self.logger.error(f"Offer not found: {offer_id}")
            return None
        
        link_id = f"link_{uuid.uuid4().hex[:12]}"
        
        # Build the affiliate link
        if offer.affiliate_link:
            original_url = offer.affiliate_link
        elif offer.hoplink:
            original_url = offer.hoplink
        else:
            original_url = offer.offer_url
        
        # Create cloaked version if enabled
        if cloak and self.link_manager:
            cloaked_url = self.link_manager.cloak_link(original_url, link_id)
        else:
            cloaked_url = original_url
        
        link = AffiliateLink(
            link_id=link_id,
            offer_id=offer_id,
            network=offer.network,
            original_url=original_url,
            cloaked_url=cloaked_url,
            final_url=original_url,
            campaign=campaign,
            medium=medium,
            source=source,
            content_id=content_id,
        )
        
        self._links[link_id] = link
        self._save_links()
        
        self.logger.info(f"Created link: {link_id} for offer: {offer_id}")
        
        return link
    
    def get_link(self, link_id: str) -> Optional[AffiliateLink]:
        """Get a link by ID."""
        return self._links.get(link_id)
    
    def get_link_by_cloaked(self, cloaked_url: str) -> Optional[AffiliateLink]:
        """Get link by cloaked URL."""
        for link in self._links.values():
            if link.cloaked_url == cloaked_url:
                return link
        return None
    
    def record_click(self, link_id: str) -> bool:
        """Record a click on a link."""
        link = self._links.get(link_id)
        if not link:
            return False
        
        link.clicks += 1
        link.unique_clicks += 1
        link.last_clicked_at = datetime.utcnow().isoformat()
        
        self._save_links()
        
        # Also update offer
        offer = self._offers.get(link.offer_id)
        if offer:
            offer.clicks_30d += 1
        
        return True
    
    # =========================================================================
    # Commission Tracking
    # =========================================================================
    
    def record_commission(
        self,
        link_id: str,
        event_type: str = "sale",
        amount: float = 0.0,
        commission: float = 0.0,
        status: str = "pending",
        **kwargs
    ) -> Optional[CommissionEvent]:
        """Record a commission event."""
        link = self._links.get(link_id)
        if not link:
            self.logger.error(f"Link not found: {link_id}")
            return None
        
        offer = self._offers.get(link.offer_id)
        
        event = CommissionEvent(
            event_id=f"evt_{uuid.uuid4().hex[:12]}",
            link_id=link_id,
            offer_id=link.offer_id,
            network=link.network,
            event_type=event_type,
            amount=amount,
            commission=commission,
            status=status,
            sub_ids=kwargs,
        )
        
        self._commissions.append(event)
        self._save_commission(event)
        
        # Update link stats
        link.conversions += 1
        link.commission += commission
        self._save_links()
        
        # Update offer stats
        if offer:
            offer.conversions_30d += 1
            offer.commission_30d += commission
            offer.total_sales += 1
            offer.total_commission += commission
        
        self.logger.info(f"Recorded commission: {event.event_id} - ${event.commission}")
        
        return event
    
    def get_commissions(
        self,
        status: Optional[str] = None,
        network: Optional[AffiliateNetwork] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[CommissionEvent]:
        """Get commissions with filters."""
        results = self._commissions
        
        if status:
            results = [c for c in results if c.status == status]
        
        if network:
            results = [c for c in results if c.network == network]
        
        if start_date:
            results = [c for c in results if c.occurred_at >= start_date]
        
        if end_date:
            results = [c for c in results if c.occurred_at <= end_date]
        
        return results
    
    # =========================================================================
    # Analytics
    # =========================================================================
    
    def get_dashboard_stats(self) -> Dict[str, Any]:
        """Get dashboard statistics."""
        total_commission = sum(c.commission for c in self._commissions)
        pending_commission = sum(
            c.commission for c in self._commissions if c.status == "pending"
        )
        approved_commission = sum(
            c.commission for c in self._commissions if c.status == "approved"
        )
        paid_commission = sum(
            c.commission for c in self._commissions if c.status == "paid"
        )
        
        total_clicks = sum(l.clicks for l in self._links.values())
        total_conversions = sum(l.conversions for l in self._links.values())
        
        # By network
        by_network = {}
        for commission in self._commissions:
            network = commission.network.value
            if network not in by_network:
                by_network[network] = {"clicks": 0, "conversions": 0, "commission": 0.0}
            by_network[network]["commission"] += commission.commission
        
        return {
            "total_offers": len(self._offers),
            "active_offers": len(self.get_active_offers()),
            "total_links": len(self._links),
            "total_clicks": total_clicks,
            "total_conversions": total_conversions,
            "conversion_rate": (total_conversions / total_clicks * 100) if total_clicks > 0 else 0,
            "total_commission": total_commission,
            "pending_commission": pending_commission,
            "approved_commission": approved_commission,
            "paid_commission": paid_commission,
            "commissions_by_network": by_network,
            "top_offers": self._get_top_offers(5),
        }
    
    def _get_top_offers(self, limit: int) -> List[Dict]:
        """Get top performing offers."""
        offers = list(self._offers.values())
        offers.sort(key=lambda x: x.total_commission, reverse=True)
        
        return [
            {
                "offer_id": o.offer_id,
                "name": o.name,
                "network": o.network.value,
                "total_commission": o.total_commission,
                "total_sales": o.total_sales,
                "conversion_rate": o.conversion_rate,
            }
            for o in offers[:limit]
        ]
    
    # =========================================================================
    # Content Generation Integration
    # =========================================================================
    
    def get_offers_for_script_integration(self, niche: str, count: int = 3) -> List[Dict]:
        """
        Get offers formatted for script integration.
        
        Returns data ready to be embedded in video scripts.
        """
        offers = self.search_offers(query=niche)[:count]
        
        return [
            {
                "offer_id": o.offer_id,
                "name": o.name,
                "brand": o.brand,
                "commission": f"{o.commission_rate}%",
                "pitch_line": self._generate_pitch_line(o),
                "affiliate_url": self.create_link(
                    o.offer_id,
                    campaign=f"script_{niche}",
                    medium="content",
                    cloak=True
                ).cloaked_url if o else None,
            }
            for o in offers
        ]
    
    def _generate_pitch_line(self, offer: AffiliateOffer) -> str:
        """Generate a pitch line for an offer."""
        if offer.commission_type == CommissionType.CPS:
            return f"Use code SIMP for {int(offer.commission_rate)}% off {offer.brand}"
        elif offer.commission_type == CommissionType.REV_SHARE:
            return f"Get {offer.commission_rate}% cash back with {offer.brand}"
        return f"Check out {offer.brand} - link in bio"


def create_affiliate_engine(config: Optional[Dict] = None) -> AffiliateEngine:
    """Create an affiliate engine instance."""
    return AffiliateEngine(config=config)
