"""
T42 — Vault Secrets: Multi-backend secret storage with rotation, audit, and revocation.

Provides a VaultClient abstraction that supports:
  - HashiCorp Vault (production)
  - File-based fallback (dev/test)
  - Encrypted local cache
  - Auto rotation with configurable TTL
  - Audit trail for every secret access
  - Emergency revocation endpoint
"""

import json
import os
import time
import hashlib
import base64
import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Callable

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# Data Classes
# ──────────────────────────────────────────────


@dataclass
class SecretMetadata:
    """Metadata about a stored secret (never the secret value itself)."""
    key_name: str
    version: int
    created_at: str          # ISO8601 UTC
    expires_at: Optional[str]  # ISO8601 UTC, None = no expiry
    rotation_days: int       # 0 = never rotate
    backend: str             # "vault" | "file" | "encrypted_file"
    tags: List[str]          # e.g. ["exchange", "coinbase", "production"]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key_name": self.key_name,
            "version": self.version,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "rotation_days": self.rotation_days,
            "backend": self.backend,
            "tags": self.tags,
        }


@dataclass
class SecretAccessRecord:
    """Audit record for every secret access."""
    key_name: str
    accessed_at: str          # ISO8601 UTC
    caller_id: str            # e.g. process name, thread name
    action: str               # "read" | "write" | "rotate" | "revoke"
    success: bool
    source_ip: Optional[str] = None
    trace_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key_name": self.key_name,
            "accessed_at": self.accessed_at,
            "caller_id": self.caller_id,
            "action": self.action,
            "success": self.success,
            "source_ip": self.source_ip,
            "trace_id": self.trace_id,
        }


@dataclass
class RotationPolicy:
    """Defines rotation schedule for a secret key."""
    key_name: str
    rotation_days: int          # 0 = never
    auto_rotate: bool           # rotate automatically when expired
    notify_before_days: int     # send alert N days before expiry
    max_versions: int           # keep this many historical versions
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key_name": self.key_name,
            "rotation_days": self.rotation_days,
            "auto_rotate": self.auto_rotate,
            "notify_before_days": self.notify_before_days,
            "max_versions": self.max_versions,
            "tags": self.tags,
        }


# ──────────────────────────────────────────────
# Backend ABC
# ──────────────────────────────────────────────


class SecretBackend:
    """Abstract base for secret storage backends."""

    def get(self, key_name: str) -> Optional[str]:
        """Retrieve a secret value. Returns None if not found."""
        raise NotImplementedError

    def set(self, key_name: str, value: str, tags: Optional[List[str]] = None) -> None:
        """Store a secret value."""
        raise NotImplementedError

    def delete(self, key_name: str) -> bool:
        """Delete a secret. Returns True if existed."""
        raise NotImplementedError

    def list_keys(self) -> List[str]:
        """List all secret key names."""
        raise NotImplementedError

    def get_metadata(self, key_name: str) -> Optional[SecretMetadata]:
        """Get metadata for a secret key."""
        raise NotImplementedError

    @property
    def name(self) -> str:
        return "abstract"


class FileBackend(SecretBackend):
    """File-based secret storage for development/testing.
    
    Stores secrets in a JSON file with restricted permissions.
    NOT recommended for production.
    """

    def __init__(self, secrets_path: Optional[Path] = None):
        self._lock = threading.Lock()
        self._secrets_path = secrets_path or Path("data/vault_secrets.json")
        self._metadata_path = self._secrets_path.with_suffix(".meta.json")
        self._data: Dict[str, str] = {}
        self._meta: Dict[str, dict] = {}
        self._load()

    @property
    def name(self) -> str:
        return "file"

    def _load(self) -> None:
        with self._lock:
            if self._secrets_path.exists():
                try:
                    self._data = json.loads(self._secrets_path.read_text())
                except (json.JSONDecodeError, OSError):
                    self._data = {}
            if self._metadata_path.exists():
                try:
                    self._meta = json.loads(self._metadata_path.read_text())
                except (json.JSONDecodeError, OSError):
                    self._meta = {}

    def _save(self) -> None:
        self._secrets_path.parent.mkdir(parents=True, exist_ok=True)
        self._secrets_path.write_text(json.dumps(self._data, indent=2))
        # Try to set restrictive permissions
        try:
            self._secrets_path.chmod(0o600)
        except OSError:
            pass
        self._metadata_path.write_text(json.dumps(self._meta, indent=2))

    def get(self, key_name: str) -> Optional[str]:
        with self._lock:
            return self._data.get(key_name)

    def set(self, key_name: str, value: str, tags: Optional[List[str]] = None) -> None:
        with self._lock:
            existing_version = self._meta.get(key_name, {}).get("version", 0)
            self._data[key_name] = value
            self._meta[key_name] = {
                "version": existing_version + 1,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "expires_at": None,
                "rotation_days": 0,
                "backend": "file",
                "tags": tags or [],
            }
            self._save()

    def delete(self, key_name: str) -> bool:
        with self._lock:
            existed = key_name in self._data
            self._data.pop(key_name, None)
            self._meta.pop(key_name, None)
            self._save()
            return existed

    def list_keys(self) -> List[str]:
        with self._lock:
            return list(self._data.keys())

    def get_metadata(self, key_name: str) -> Optional[SecretMetadata]:
        with self._lock:
            meta = self._meta.get(key_name)
            if meta is None:
                return None
            return SecretMetadata(
                key_name=key_name,
                version=meta.get("version", 1),
                created_at=meta.get("created_at", ""),
                expires_at=meta.get("expires_at"),
                rotation_days=meta.get("rotation_days", 0),
                backend=meta.get("backend", "file"),
                tags=meta.get("tags", []),
            )


class EncryptedFileBackend(SecretBackend):
    """File-based storage with XOR + base64 obfuscation at rest.
    
    Provides mild protection against casual file reads.
    Master key is derived from an environment variable.
    For real security, use HashiCorp Vault.
    """

    def __init__(self, secrets_path: Optional[Path] = None,
                 master_key_env: str = "SIMP_VAULT_MASTER_KEY"):
        self._lock = threading.Lock()
        self._secrets_path = secrets_path or Path("data/vault_secrets.enc")
        self._metadata_path = self._secrets_path.with_suffix(".meta.json")
        self._master_key = os.environ.get(master_key_env, "dev-master-key")
        self._data: Dict[str, str] = {}
        self._meta: Dict[str, dict] = {}
        self._load()

    @property
    def name(self) -> str:
        return "encrypted_file"

    def _obfuscate(self, value: str) -> str:
        key = self._master_key
        result = []
        for i, c in enumerate(value.encode("utf-8")):
            result.append(c ^ ord(key[i % len(key)]))
        return base64.b64encode(bytes(result)).decode("ascii")

    def _deobfuscate(self, encoded: str) -> str:
        key = self._master_key
        raw = base64.b64decode(encoded.encode("ascii"))
        result = bytes(b ^ ord(key[i % len(key)]) for i, b in enumerate(raw))
        return result.decode("utf-8")

    def _load(self) -> None:
        with self._lock:
            if self._secrets_path.exists():
                try:
                    raw_data = json.loads(self._secrets_path.read_text())
                    self._data = {k: self._deobfuscate(v)
                                  for k, v in raw_data.items()}
                except Exception:
                    self._data = {}
            if self._metadata_path.exists():
                try:
                    self._meta = json.loads(self._metadata_path.read_text())
                except Exception:
                    self._meta = {}

    def _save(self) -> None:
        self._secrets_path.parent.mkdir(parents=True, exist_ok=True)
        obfuscated = {k: self._obfuscate(v) for k, v in self._data.items()}
        self._secrets_path.write_text(json.dumps(obfuscated))
        try:
            self._secrets_path.chmod(0o600)
        except OSError:
            pass
        self._metadata_path.write_text(json.dumps(self._meta, indent=2))

    def get(self, key_name: str) -> Optional[str]:
        with self._lock:
            return self._data.get(key_name)

    def set(self, key_name: str, value: str, tags: Optional[List[str]] = None) -> None:
        with self._lock:
            existing_version = self._meta.get(key_name, {}).get("version", 0)
            self._data[key_name] = value
            self._meta[key_name] = {
                "version": existing_version + 1,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "expires_at": None,
                "rotation_days": 0,
                "backend": "encrypted_file",
                "tags": tags or [],
            }
            self._save()

    def delete(self, key_name: str) -> bool:
        with self._lock:
            existed = key_name in self._data
            self._data.pop(key_name, None)
            self._meta.pop(key_name, None)
            self._save()
            return existed

    def list_keys(self) -> List[str]:
        with self._lock:
            return list(self._data.keys())

    def get_metadata(self, key_name: str) -> Optional[SecretMetadata]:
        with self._lock:
            meta = self._meta.get(key_name)
            if meta is None:
                return None
            return SecretMetadata(
                key_name=key_name,
                version=meta.get("version", 1),
                created_at=meta.get("created_at", ""),
                expires_at=meta.get("expires_at"),
                rotation_days=meta.get("rotation_days", 0),
                backend=meta.get("backend", "encrypted_file"),
                tags=meta.get("tags", []),
            )


class VaultBackend(SecretBackend):
    """HashiCorp Vault backend (KV v2 engine).
    
    Connects via VAULT_ADDR / VAULT_TOKEN environment variables.
    Uses stdlib urllib only for minimal dependency footprint.
    """

    def __init__(self, vault_addr: Optional[str] = None,
                 vault_token: Optional[str] = None,
                 mount_path: str = "secret",
                 verify_ssl: bool = True):
        self._lock = threading.Lock()
        self._vault_addr = (vault_addr or
                            os.environ.get("VAULT_ADDR", "http://127.0.0.1:8200"))
        self._vault_token = (vault_token or
                             os.environ.get("VAULT_TOKEN", ""))
        self._mount_path = mount_path.strip("/")
        self._verify_ssl = verify_ssl
        self._cache: Dict[str, Tuple[str, float]] = {}  # key -> (value, expiry_ts)
        self._meta_cache: Dict[str, Tuple[SecretMetadata, float]] = {}
        self._cache_ttl = 30.0  # seconds

    @property
    def name(self) -> str:
        return "vault"

    def _api_url(self, path: str) -> str:
        return (f"{self._vault_addr}/v1/{self._mount_path}/data/{path}")

    def _metadata_url(self, path: str) -> str:
        return (f"{self._vault_addr}/v1/{self._mount_path}/metadata/{path}")

    def _headers(self) -> Dict[str, str]:
        return {
            "X-Vault-Token": self._vault_token,
            "Content-Type": "application/json",
        }

    def _request(self, method: str, url: str, body: Optional[bytes] = None
                 ) -> Optional[Dict[str, Any]]:
        """Make an HTTP request using stdlib urllib."""
        import urllib.request
        import urllib.error

        req = urllib.request.Request(url, data=body, headers=self._headers(),
                                     method=method)
        if not self._verify_ssl and url.startswith("https"):
            import ssl
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        else:
            ctx = None

        try:
            with urllib.request.urlopen(req, timeout=10, context=ctx) as resp:
                raw = resp.read().decode("utf-8")
                return json.loads(raw)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            logger.warning("Vault HTTP %d: %s", e.code, url)
            return None
        except Exception as e:
            logger.warning("Vault request failed: %s %s", e.__class__.__name__, e)
            return None

    def get(self, key_name: str) -> Optional[str]:
        with self._lock:
            # Check cache
            cached = self._cache.get(key_name)
            if cached and cached[1] > time.time():
                return cached[0]

            resp = self._request("GET", self._api_url(key_name))
            if resp is None:
                return None

            try:
                data = resp.get("data", {}).get("data", {})
                secret_value = data.get("secret", data.get("value", data.get("key", "")))
                if not secret_value and data:
                    # Try to get any value from data
                    for v in data.values():
                        if isinstance(v, str):
                            secret_value = v
                            break
                # Cache it
                self._cache[key_name] = (str(secret_value) if secret_value else "",
                                         time.time() + self._cache_ttl)
                return str(secret_value) if secret_value else None
            except Exception as e:
                logger.warning("Vault get parse error: %s", e)
                return None

    def set(self, key_name: str, value: str, tags: Optional[List[str]] = None) -> None:
        with self._lock:
            body = json.dumps({
                "data": {
                    "secret": value,
                    "tags": tags or [],
                }
            }).encode("utf-8")
            self._request("POST", self._api_url(key_name), body=body)
            # Invalidate cache
            self._cache.pop(key_name, None)

    def delete(self, key_name: str) -> bool:
        with self._lock:
            existed = self.get(key_name) is not None
            self._request("DELETE", self._api_url(key_name))
            self._cache.pop(key_name, None)
            return existed

    def list_keys(self) -> List[str]:
        with self._lock:
            list_url = f"{self._vault_addr}/v1/{self._mount_path}/metadata"
            resp = self._request("LIST", list_url)
            if resp is None:
                return []
            try:
                keys = resp.get("data", {}).get("keys", [])
                return [k.rstrip("/") for k in keys]
            except Exception:
                return []

    def get_metadata(self, key_name: str) -> Optional[SecretMetadata]:
        with self._lock:
            cached = self._meta_cache.get(key_name)
            if cached and cached[1] > time.time():
                return cached[0]

            resp = self._request("GET", self._metadata_url(key_name))
            if resp is None:
                return None
            try:
                meta = resp.get("data", {})
                created = meta.get("created_time", datetime.now(timezone.utc).isoformat())
                version = meta.get("version", 1)
                md = SecretMetadata(
                    key_name=key_name,
                    version=version,
                    created_at=created,
                    expires_at=None,
                    rotation_days=0,
                    backend="vault",
                    tags=[],
                )
                self._meta_cache[key_name] = (md, time.time() + self._cache_ttl)
                return md
            except Exception as e:
                logger.warning("Vault metadata parse error: %s", e)
                return None


# ──────────────────────────────────────────────
# VaultClient — Unified Secret Manager
# ──────────────────────────────────────────────


class VaultClient:
    """Unified secret management with multi-backend support.

    Resolves secrets from the configured backend, tracks all access
    in an audit trail, and supports automatic rotation.
    """

    def __init__(self,
                 backend: Optional[SecretBackend] = None,
                 audit_path: Optional[Path] = None,
                 rotation_policies: Optional[Dict[str, RotationPolicy]] = None):
        self._lock = threading.Lock()
        self._backend = backend or self._auto_detect_backend()
        self._audit_path = audit_path or Path("data/vault_audit.jsonl")
        self._audit_path.parent.mkdir(parents=True, exist_ok=True)
        self._policies: Dict[str, RotationPolicy] = rotation_policies or {}
        self._rotation_timer: Optional[threading.Thread] = None
        self._running = False
        self._caller_id = f"vault_client:{os.getpid()}"

    def _auto_detect_backend(self) -> SecretBackend:
        """Auto-detect backend: Vault if VAULT_ADDR set, else encrypted file."""
        if os.environ.get("VAULT_ADDR"):
            return VaultBackend()
        master_key = os.environ.get("SIMP_VAULT_MASTER_KEY")
        if master_key:
            return EncryptedFileBackend()
        return FileBackend()

    # ── Core API ──

    def get(self, key_name: str, trace_id: Optional[str] = None) -> Optional[str]:
        """Retrieve a secret value with audit logging."""
        try:
            value = self._backend.get(key_name)
            self._audit(SecretAccessRecord(
                key_name=key_name,
                accessed_at=datetime.now(timezone.utc).isoformat(),
                caller_id=self._caller_id,
                action="read",
                success=value is not None,
                trace_id=trace_id,
            ))
            return value
        except Exception as e:
            logger.error("Secret read failed for '%s': %s", key_name, e)
            self._audit(SecretAccessRecord(
                key_name=key_name,
                accessed_at=datetime.now(timezone.utc).isoformat(),
                caller_id=self._caller_id,
                action="read",
                success=False,
                trace_id=trace_id,
            ))
            return None

    def set(self, key_name: str, value: str, tags: Optional[List[str]] = None,
            trace_id: Optional[str] = None) -> None:
        """Store a secret value."""
        try:
            self._backend.set(key_name, value, tags=tags)
            self._audit(SecretAccessRecord(
                key_name=key_name,
                accessed_at=datetime.now(timezone.utc).isoformat(),
                caller_id=self._caller_id,
                action="write",
                success=True,
                trace_id=trace_id,
            ))
        except Exception as e:
            logger.error("Secret write failed for '%s': %s", key_name, e)
            self._audit(SecretAccessRecord(
                key_name=key_name,
                accessed_at=datetime.now(timezone.utc).isoformat(),
                caller_id=self._caller_id,
                action="write",
                success=False,
                trace_id=trace_id,
            ))
            raise

    def delete(self, key_name: str, trace_id: Optional[str] = None) -> bool:
        """Delete a secret."""
        result = self._backend.delete(key_name)
        self._audit(SecretAccessRecord(
            key_name=key_name,
            accessed_at=datetime.now(timezone.utc).isoformat(),
            caller_id=self._caller_id,
            action="revoke",
            success=result,
            trace_id=trace_id,
        ))
        return result

    def list_keys(self) -> List[str]:
        """List all secret key names."""
        return self._backend.list_keys()

    def get_metadata(self, key_name: str) -> Optional[SecretMetadata]:
        """Get secret metadata (not the value)."""
        return self._backend.get_metadata(key_name)

    # ── Rotation ──

    def set_rotation_policy(self, policy: RotationPolicy) -> None:
        """Set or update a rotation policy for a key."""
        with self._lock:
            self._policies[policy.key_name] = policy

    def check_expiry(self, key_name: str) -> Optional[int]:
        """Check if a secret is expiring soon.
        
        Returns days until expiry, or None if no policy or already expired.
        """
        policy = self._policies.get(key_name)
        if policy is None or policy.rotation_days <= 0:
            return None

        meta = self._backend.get_metadata(key_name)
        if meta is None:
            return None

        created = datetime.fromisoformat(meta.created_at)
        age_days = (datetime.now(timezone.utc) - created.replace(tzinfo=timezone.utc)).days
        remaining = policy.rotation_days - age_days
        return max(remaining, 0)

    def rotate(self, key_name: str, new_value: str,
               trace_id: Optional[str] = None) -> bool:
        """Manually rotate a secret to a new value."""
        policy = self._policies.get(key_name)
        if policy and policy.max_versions > 0:
            # Here we'd archive old versions in production
            pass

        self.set(key_name, new_value, trace_id=trace_id)
        self._audit(SecretAccessRecord(
            key_name=key_name,
            accessed_at=datetime.now(timezone.utc).isoformat(),
            caller_id=self._caller_id,
            action="rotate",
            success=True,
            trace_id=trace_id,
        ))
        return True

    def start_auto_rotation(self, interval_seconds: int = 3600) -> None:
        """Start background thread for automatic secret rotation."""
        if self._running:
            logger.warning("Auto-rotation already running")
            return

        self._running = True
        self._rotation_timer = threading.Thread(
            target=self._rotation_loop,
            args=(interval_seconds,),
            daemon=True,
            name="vault-rotator",
        )
        self._rotation_timer.start()
        logger.info("Auto-rotation started (interval=%ds)", interval_seconds)

    def stop_auto_rotation(self) -> None:
        """Stop the background rotation thread."""
        self._running = False
        logger.info("Auto-rotation stopped")

    def _rotation_loop(self, interval: int) -> None:
        """Background loop that checks and rotates expired secrets."""
        while self._running:
            try:
                for key_name, policy in list(self._policies.items()):
                    if not policy.auto_rotate or policy.rotation_days <= 0:
                        continue
                    remaining = self.check_expiry(key_name)
                    if remaining is not None and remaining <= 0:
                        logger.warning("Secret '%s' expired, requires rotation", key_name)
            except Exception as e:
                logger.error("Rotation check error: %s", e)
            time.sleep(interval)

    # ── Emergency Revocation ──

    def emergency_revoke(self, key_names: List[str],
                         trace_id: Optional[str] = None) -> Dict[str, bool]:
        """Emergency revoke one or more secrets.
        
        Returns {key_name: success} mapping.
        """
        results = {}
        for key_name in key_names:
            try:
                results[key_name] = self.delete(key_name, trace_id=trace_id)
                if results[key_name]:
                    logger.warning("EMERGENCY REVOKE: '%s'", key_name)
            except Exception as e:
                logger.error("Emergency revoke failed for '%s': %s", key_name, e)
                results[key_name] = False
        return results

    # ── Audit ──

    def _audit(self, record: SecretAccessRecord) -> None:
        """Write an audit record to the JSONL audit log."""
        try:
            with self._lock:
                with open(self._audit_path, "a") as f:
                    f.write(json.dumps(record.to_dict()) + "\n")
        except Exception as e:
            logger.error("Failed to write audit record: %s", e)

    def get_audit_log(self, key_name: Optional[str] = None,
                      limit: int = 100) -> List[SecretAccessRecord]:
        """Retrieve audit records, optionally filtered by key name."""
        records = []
        try:
            if not self._audit_path.exists():
                return []
            with open(self._audit_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        records.append(SecretAccessRecord(**data))
                    except Exception:
                        continue
        except Exception as e:
            logger.error("Failed to read audit log: %s", e)

        if key_name:
            records = [r for r in records if r.key_name == key_name]

        return records[-limit:]

    def get_audit_summary(self) -> Dict[str, Any]:
        """Get summary statistics from the audit log."""
        records = self.get_audit_log(limit=10000)
        total = len(records)
        by_action: Dict[str, int] = {}
        by_key: Dict[str, int] = {}
        failures = 0

        for r in records:
            by_action[r.action] = by_action.get(r.action, 0) + 1
            by_key[r.key_name] = by_key.get(r.key_name, 0) + 1
            if not r.success:
                failures += 1

        return {
            "total_accesses": total,
            "by_action": by_action,
            "by_key": by_key,
            "failures": failures,
            "most_accessed": sorted(by_key.items(), key=lambda x: -x[1])[:5],
        }

    # ── Utility ──

    def get_backend_name(self) -> str:
        """Get the name of the active backend."""
        return self._backend.name

    def health_check(self) -> Dict[str, Any]:
        """Check vault health and backend status."""
        try:
            key_count = len(self.list_keys())
            # Test read/write capability
            test_key = "_vault_health_test"
            self.set(test_key, "ok")
            readback = self.get(test_key)
            self.delete(test_key)
            writable = readback == "ok"
        except Exception as e:
            return {
                "healthy": False,
                "backend": self._backend.name,
                "error": str(e),
            }

        return {
            "healthy": True,
            "backend": self._backend.name,
            "key_count": key_count,
            "writable": writable,
        }

    def build_queue_item(self, key_name: str,
                         current_value: str,
                         rotation_policy: Optional[RotationPolicy] = None
                         ) -> Dict[str, Any]:
        """Generate a manifest entry for the build queue to vault a key."""
        return {
            "type": "vault_secret",
            "key_name": key_name,
            "backend": self._backend.name,
            "has_value": bool(current_value),
            "rotation_policy": rotation_policy.to_dict() if rotation_policy else None,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


# ──────────────────────────────────────────────
# Module-level singleton
# ──────────────────────────────────────────────

_VAULT_CLIENT: Optional[VaultClient] = None
_vault_lock = threading.Lock()


def get_vault_client(backend: Optional[SecretBackend] = None) -> VaultClient:
    """Get or create the module-level VaultClient singleton."""
    global _VAULT_CLIENT
    if _VAULT_CLIENT is None:
        with _vault_lock:
            if _VAULT_CLIENT is None:
                _VAULT_CLIENT = VaultClient(backend=backend)
    return _VAULT_CLIENT


# ──────────────────────────────────────────────
# Quick test
# ──────────────────────────────────────────────

def test_vault_client() -> None:
    """Run a self-test of the vault client with file backend."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        audit_path = Path(tmpdir) / "audit.jsonl"
        secrets_path = Path(tmpdir) / "secrets.json"
        backend = FileBackend(secrets_path)

        client = VaultClient(backend=backend, audit_path=audit_path)

        # Test set/get
        client.set("coinbase_api_key", "sk_test_abc123")
        assert client.get("coinbase_api_key") == "sk_test_abc123"

        # Test overwrite
        client.set("coinbase_api_key", "sk_test_def456")
        assert client.get("coinbase_api_key") == "sk_test_def456"

        # Test nonexistent key
        assert client.get("nonexistent") is None

        # Test list
        client.set("kraken_secret", "kraken_val_xyz")
        keys = client.list_keys()
        assert "coinbase_api_key" in keys
        assert "kraken_secret" in keys

        # Test metadata
        meta = client.get_metadata("coinbase_api_key")
        assert meta is not None
        assert meta.key_name == "coinbase_api_key"
        assert meta.version == 2  # Overwritten once
        assert meta.backend == "file"

        # Test rotation policy
        policy = RotationPolicy(
            key_name="coinbase_api_key",
            rotation_days=90,
            auto_rotate=False,
            notify_before_days=7,
            max_versions=5,
        )
        client.set_rotation_policy(policy)
        assert client.check_expiry("coinbase_api_key") is not None

        # Test audit trail
        records = client.get_audit_log()
        assert len(records) >= 3  # 2 writes + 1 read
        write_records = [r for r in records if r.action == "write"]
        assert len(write_records) >= 2

        # Test audit summary
        summary = client.get_audit_summary()
        assert summary["total_accesses"] >= 3

        # Test delete
        assert client.delete("kraken_secret")
        assert client.get("kraken_secret") is None
        assert "kraken_secret" not in client.list_keys()

        # Test emergency revoke
        client.set("emergency_test", "value123")
        result = client.emergency_revoke(["emergency_test"])
        assert result.get("emergency_test") is True

        # Test health check
        health = client.health_check()
        assert health["healthy"] is True
        assert health["backend"] == "file"

        # Test build queue item
        item = client.build_queue_item("coinbase_api_key", "sk_test_abc123")
        assert item["type"] == "vault_secret"
        assert item["key_name"] == "coinbase_api_key"

        print("✅ T42 test_vault_client: ALL PASSED")


if __name__ == "__main__":
    test_vault_client()
