"""
T41 — Multi-Sig Approval: Multi-signer approval flow for large trades.

Provides:
  - MultiSigPolicy: threshold-based signing rules
  - MultiSigProposal: lifecycle (draft → pending → approved/rejected)
  - Approval queue with timeouts
  - Integration with VaultClient for key access audit
  - Emergency override with full audit trail
"""

import json
import time
import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable, Set

logger = logging.getLogger(__name__)

# ── Constants ──

DEFAULT_TIMEOUT_HOURS = 24
EMERGENCY_OVERRIDE_LABEL = "__EMERGENCY_OVERRIDE__"

# ── Data Classes ──


@dataclass
class SignerInfo:
    """Information about an authorized signer."""
    signer_id: str
    name: str
    role: str                    # "trader" | "risk_manager" | "compliance" | "admin"
    weight: int = 1              # For weighted voting
    is_emergency_authorized: bool = False
    public_key_fingerprint: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signer_id": self.signer_id,
            "name": self.name,
            "role": self.role,
            "weight": self.weight,
            "is_emergency_authorized": self.is_emergency_authorized,
            "public_key_fingerprint": self.public_key_fingerprint,
        }


@dataclass
class MultiSigPolicy:
    """Defines signing rules for a category of operations."""
    policy_id: str
    description: str
    threshold: int               # Total weight required to approve
    min_signers: int = 1         # Minimum number of unique signers
    allowed_roles: List[str] = field(default_factory=lambda: ["trader", "risk_manager"])
    timeout_hours: int = DEFAULT_TIMEOUT_HOURS
    emergency_override_enabled: bool = True
    emergency_override_roles: List[str] = field(default_factory=lambda: ["admin"])
    max_value_usd: Optional[float] = None  # Max value this policy applies to
    min_value_usd: Optional[float] = None  # Min value to trigger this policy

    def to_dict(self) -> Dict[str, Any]:
        return {
            "policy_id": self.policy_id,
            "description": self.description,
            "threshold": self.threshold,
            "min_signers": self.min_signers,
            "allowed_roles": self.allowed_roles,
            "timeout_hours": self.timeout_hours,
            "emergency_override_enabled": self.emergency_override_enabled,
            "emergency_override_roles": self.emergency_override_roles,
            "max_value_usd": self.max_value_usd,
            "min_value_usd": self.min_value_usd,
        }


@dataclass
class Signature:
    """A single signature on a proposal."""
    signer_id: str
    signed_at: str               # ISO8601 UTC
    approved: bool               # True = approve, False = reject
    comment: Optional[str] = None
    signature_hash: Optional[str] = None  # Cryptographic signature if available

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signer_id": self.signer_id,
            "signed_at": self.signed_at,
            "approved": self.approved,
            "comment": self.comment,
            "signature_hash": self.signature_hash,
        }


@dataclass
class MultiSigProposal:
    """A proposal requiring multiple signatures to execute."""
    proposal_id: str
    policy_id: str
    intent_type: str             # e.g. "trade", "transfer", "withdraw", "deploy"
    payload: Dict[str, Any]      # The operation to execute
    value_usd: float             # Estimated value in USD
    submitted_by: str            # Creator signer_id
    status: str                  # "draft" | "pending" | "approved" | "rejected" | "expired" | "executed" | "overridden"
    signatures: List[Signature] = field(default_factory=list)
    approved_weight: int = 0
    rejected_weight: int = 0
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    expires_at: Optional[str] = None
    executed_at: Optional[str] = None
    execution_tx_id: Optional[str] = None
    overridden_by: Optional[str] = None
    override_reason: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "policy_id": self.policy_id,
            "intent_type": self.intent_type,
            "payload": self.payload,
            "value_usd": self.value_usd,
            "submitted_by": self.submitted_by,
            "status": self.status,
            "signatures": [s.to_dict() for s in self.signatures],
            "approved_weight": self.approved_weight,
            "rejected_weight": self.rejected_weight,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "executed_at": self.executed_at,
            "execution_tx_id": self.execution_tx_id,
            "overridden_by": self.overridden_by,
            "override_reason": self.override_reason,
            "tags": self.tags,
            "description": self.description,
        }

    @property
    def is_approved(self) -> bool:
        return self.status == "approved"

    @property
    def is_rejected(self) -> bool:
        return self.status in ("rejected", "expired")

    @property
    def is_pending(self) -> bool:
        return self.status == "pending"

    @property
    def has_expired(self) -> bool:
        if self.expires_at is None:
            return False
        try:
            expiry = datetime.fromisoformat(self.expires_at)
            return datetime.now(timezone.utc) > expiry.replace(tzinfo=timezone.utc)
        except (ValueError, TypeError):
            return False


class SignerRegistry:
    """Manages the set of authorized signers."""

    def __init__(self):
        self._lock = threading.Lock()
        self._signers: Dict[str, SignerInfo] = {}

    def register(self, signer: SignerInfo) -> None:
        with self._lock:
            self._signers[signer.signer_id] = signer

    def unregister(self, signer_id: str) -> bool:
        with self._lock:
            return self._signers.pop(signer_id, None) is not None

    def get(self, signer_id: str) -> Optional[SignerInfo]:
        with self._lock:
            return self._signers.get(signer_id)

    def list_signers(self) -> List[SignerInfo]:
        with self._lock:
            return list(self._signers.values())

    def list_by_role(self, role: str) -> List[SignerInfo]:
        with self._lock:
            return [s for s in self._signers.values() if s.role == role]

    def is_authorized(self, signer_id: str, role: Optional[str] = None) -> bool:
        with self._lock:
            signer = self._signers.get(signer_id)
            if signer is None:
                return False
            if role and signer.role != role:
                return False
            return True

    def get_total_weight(self) -> int:
        with self._lock:
            return sum(s.weight for s in self._signers.values())


class MultiSigApproval:
    """Multi-signature approval workflow engine.

    Manages the full lifecycle of multi-sig proposals including
    submission, signing, threshold enforcement, expiry, and execution.
    """

    def __init__(self,
                 policies: Optional[Dict[str, MultiSigPolicy]] = None,
                 signer_registry: Optional[SignerRegistry] = None,
                 ledger_path: Optional[Path] = None,
                 on_execute: Optional[Callable[[MultiSigProposal], Any]] = None):
        self._lock = threading.Lock()
        self._policies: Dict[str, MultiSigPolicy] = policies or {}
        self._signers = signer_registry or SignerRegistry()
        self._ledger_path = ledger_path or Path("data/multi_sig_ledger.jsonl")
        self._ledger_path.parent.mkdir(parents=True, exist_ok=True)
        self._on_execute: Optional[Callable[[MultiSigProposal], Any]] = on_execute
        self._proposals: Dict[str, MultiSigProposal] = {}
        self._seq = 0
        self._load_proposals()

    # ── Policy Management ──

    def add_policy(self, policy: MultiSigPolicy) -> None:
        with self._lock:
            self._policies[policy.policy_id] = policy

    def remove_policy(self, policy_id: str) -> bool:
        with self._lock:
            return self._policies.pop(policy_id, None) is not None

    def get_policy(self, policy_id: str) -> Optional[MultiSigPolicy]:
        return self._policies.get(policy_id)

    def list_policies(self) -> List[MultiSigPolicy]:
        return list(self._policies.values())

    def find_matching_policy(self, intent_type: str, value_usd: float
                             ) -> Optional[MultiSigPolicy]:
        """Find the most specific policy matching intent type and value."""
        candidates = []
        for policy in self._policies.values():
            if policy.min_value_usd is not None and value_usd < policy.min_value_usd:
                continue
            if policy.max_value_usd is not None and value_usd > policy.max_value_usd:
                continue
            candidates.append(policy)

        if not candidates:
            return None

        # Return the most specific (highest min threshold)
        candidates.sort(key=lambda p: -(p.min_value_usd or 0))
        return candidates[0]

    # ── Signer Management ──

    def register_signer(self, signer: SignerInfo) -> None:
        self._signers.register(signer)

    def unregister_signer(self, signer_id: str) -> bool:
        return self._signers.unregister(signer_id)

    def get_signer(self, signer_id: str) -> Optional[SignerInfo]:
        return self._signers.get(signer_id)

    def list_signers(self) -> List[SignerInfo]:
        return self._signers.list_signers()

    # ── Proposal Lifecycle ──

    def submit(self,
               intent_type: str,
               payload: Dict[str, Any],
               value_usd: float = 0.0,
               submitted_by: str = "",
               policy_id: Optional[str] = None,
               description: str = "",
               tags: Optional[List[str]] = None) -> MultiSigProposal:
        """Submit a new proposal for multi-sig approval.

        If no policy_id is given, auto-select from matching policies.
        """
        with self._lock:
            self._seq += 1
            proposal_id = f"ms-{int(time.time())}-{self._seq}"

            # Find policy
            if policy_id is None:
                policy = self.find_matching_policy(intent_type, value_usd)
                if policy is None:
                    raise ValueError(
                        f"No policy matches intent_type={intent_type} "
                        f"value_usd={value_usd}"
                    )
                policy_id = policy.policy_id
            else:
                policy = self._policies.get(policy_id)
                if policy is None:
                    raise ValueError(f"Policy not found: {policy_id}")

            expires_at = datetime.now(timezone.utc).isoformat()
            # Calculate expiry
            try:
                expiry_dt = datetime.now(timezone.utc).replace(tzinfo=None)
                from datetime import timedelta
                expiry_dt += timedelta(hours=policy.timeout_hours)
                expires_at = expiry_dt.isoformat()
            except Exception:
                expires_at = ""

            proposal = MultiSigProposal(
                proposal_id=proposal_id,
                policy_id=policy_id,
                intent_type=intent_type,
                payload=payload,
                value_usd=value_usd,
                submitted_by=submitted_by,
                status="pending",
                expires_at=expires_at,
                description=description,
                tags=tags or [],
            )
            self._proposals[proposal_id] = proposal
            self._persist(proposal)
            logger.info("Proposal %s submitted (policy=%s, value=$%.2f)",
                        proposal_id, policy_id, value_usd)
            return proposal

    def sign(self, proposal_id: str, signer_id: str, approved: bool,
             comment: Optional[str] = None,
             signature_hash: Optional[str] = None) -> MultiSigProposal:
        """Sign (approve or reject) a proposal.

        Returns the updated proposal. May auto-execute if threshold reached.
        """
        with self._lock:
            proposal = self._proposals.get(proposal_id)
            if proposal is None:
                raise ValueError(f"Proposal not found: {proposal_id}")

            if proposal.status != "pending":
                raise ValueError(
                    f"Proposal {proposal_id} is {proposal.status}, not pending"
                )

            if proposal.has_expired:
                proposal.status = "expired"
                self._persist(proposal)
                raise ValueError(f"Proposal {proposal_id} has expired")

            # Check signer eligibility
            signer = self._signers.get(signer_id)
            if signer is None:
                raise ValueError(f"Signer not registered: {signer_id}")

            policy = self._policies.get(proposal.policy_id)
            if policy and signer.role not in policy.allowed_roles:
                raise ValueError(
                    f"Signer {signer_id} role '{signer.role}' not in "
                    f"allowed roles: {policy.allowed_roles}"
                )

            # Check if already signed
            existing = [s for s in proposal.signatures if s.signer_id == signer_id]
            if existing:
                raise ValueError(f"Signer {signer_id} already signed")

            signature = Signature(
                signer_id=signer_id,
                signed_at=datetime.now(timezone.utc).isoformat(),
                approved=approved,
                comment=comment,
                signature_hash=signature_hash,
            )
            proposal.signatures.append(signature)

            if approved:
                proposal.approved_weight += signer.weight
            else:
                proposal.rejected_weight += signer.weight

            # Check thresholds
            if policy:
                # Check if approved
                if (proposal.approved_weight >= policy.threshold
                        and len(proposal.signatures) >= policy.min_signers):
                    proposal.status = "approved"
                    logger.info("Proposal %s APPROVED (weight=%d >= threshold=%d)",
                                proposal_id, proposal.approved_weight, policy.threshold)
                # Check if rejected majority
                elif proposal.rejected_weight >= policy.threshold:
                    proposal.status = "rejected"
                    logger.info("Proposal %s REJECTED (weight=%d >= threshold=%d)",
                                proposal_id, proposal.rejected_weight, policy.threshold)

            self._persist(proposal)

            # Auto-execute if approved and callback is configured
            if proposal.status == "approved" and self._on_execute:
                try:
                    result = self._on_execute(proposal)
                    proposal.status = "executed"
                    proposal.executed_at = datetime.now(timezone.utc).isoformat()
                    if result and isinstance(result, dict):
                        proposal.execution_tx_id = result.get("tx_id",
                                                              result.get("id"))
                    self._persist(proposal)
                except Exception as e:
                    logger.error("Auto-execute failed for %s: %s", proposal_id, e)

            return proposal

    def emergency_override(self, proposal_id: str, admin_id: str,
                           reason: str) -> MultiSigProposal:
        """Emergency override: bypass multi-sig for critical operations.

        Only available if the policy allows it and the admin is authorized.
        """
        with self._lock:
            proposal = self._proposals.get(proposal_id)
            if proposal is None:
                raise ValueError(f"Proposal not found: {proposal_id}")

            policy = self._policies.get(proposal.policy_id)
            if policy and not policy.emergency_override_enabled:
                raise ValueError(f"Emergency override disabled for policy {proposal.policy_id}")

            admin = self._signers.get(admin_id)
            if admin is None:
                raise ValueError(f"Admin not found: {admin_id}")

            if policy and admin.role not in policy.emergency_override_roles:
                raise ValueError(
                    f"Admin {admin_id} role '{admin.role}' not authorized "
                    f"for emergency override"
                )

            proposal.status = "overridden"
            proposal.overridden_by = admin_id
            proposal.override_reason = reason
            self._persist(proposal)

            # Log override as a signature
            proposal.signatures.append(Signature(
                signer_id=EMERGENCY_OVERRIDE_LABEL + ":" + admin_id,
                signed_at=datetime.now(timezone.utc).isoformat(),
                approved=True,
                comment=f"EMERGENCY OVERRIDE by {admin_id}: {reason}",
            ))

            logger.warning("EMERGENCY OVERRIDE: %s by %s (%s)",
                           proposal_id, admin_id, reason)

            # Auto-execute if callback
            if self._on_execute:
                try:
                    result = self._on_execute(proposal)
                    proposal.status = "executed"
                    proposal.executed_at = datetime.now(timezone.utc).isoformat()
                    if result and isinstance(result, dict):
                        proposal.execution_tx_id = result.get("tx_id",
                                                              result.get("id"))
                    self._persist(proposal)
                except Exception as e:
                    logger.error("Override auto-execute failed: %s", e)

            return proposal

    def cancel(self, proposal_id: str, signer_id: str) -> MultiSigProposal:
        """Cancel a pending proposal (submitter only)."""
        with self._lock:
            proposal = self._proposals.get(proposal_id)
            if proposal is None:
                raise ValueError(f"Proposal not found: {proposal_id}")

            if proposal.submitted_by != signer_id:
                raise ValueError(
                    f"Only the submitter ({proposal.submitted_by}) can cancel"
                )

            if proposal.status != "pending":
                raise ValueError(f"Proposal {proposal_id} is {proposal.status}, not pending")

            proposal.status = "rejected"
            proposal.signatures.append(Signature(
                signer_id=signer_id,
                signed_at=datetime.now(timezone.utc).isoformat(),
                approved=False,
                comment="Cancelled by submitter",
            ))
            self._persist(proposal)
            return proposal

    # ── Query ──

    def get_proposal(self, proposal_id: str) -> Optional[MultiSigProposal]:
        return self._proposals.get(proposal_id)

    def list_proposals(self, status: Optional[str] = None,
                       policy_id: Optional[str] = None,
                       limit: int = 50) -> List[MultiSigProposal]:
        """List proposals with optional filters."""
        # Check for expired proposals
        self._check_expired()

        proposals = list(self._proposals.values())
        if status:
            proposals = [p for p in proposals if p.status == status]
        if policy_id:
            proposals = [p for p in proposals if p.policy_id == policy_id]

        # Sort by created_at descending
        proposals.sort(key=lambda p: p.created_at, reverse=True)
        return proposals[:limit]

    def get_pending_proposals(self) -> List[MultiSigProposal]:
        """Get all proposals awaiting signatures."""
        self._check_expired()
        return [p for p in self._proposals.values() if p.status == "pending"]

    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics."""
        self._check_expired()
        proposals = list(self._proposals.values())
        return {
            "total": len(proposals),
            "pending": len([p for p in proposals if p.status == "pending"]),
            "approved": len([p for p in proposals if p.status == "approved"]),
            "rejected": len([p for p in proposals if p.status == "rejected"]),
            "executed": len([p for p in proposals if p.status == "executed"]),
            "expired": len([p for p in proposals if p.status == "expired"]),
            "overridden": len([p for p in proposals if p.status == "overridden"]),
            "total_value_usd": sum(p.value_usd for p in proposals
                                   if p.status in ("approved", "executed")),
            "signers": len(self._signers.list_signers()),
            "policies": len(self._policies),
        }

    def _check_expired(self) -> None:
        """Mark expired proposals."""
        for proposal in self._proposals.values():
            if proposal.status == "pending" and proposal.has_expired:
                proposal.status = "expired"
                self._persist(proposal)

    # ── Persistence ──

    def _persist(self, proposal: MultiSigProposal) -> None:
        """Append proposal state to JSONL ledger."""
        try:
            with self._lock:
                with open(self._ledger_path, "a") as f:
                    f.write(json.dumps(proposal.to_dict()) + "\n")
        except Exception as e:
            logger.error("Failed to persist proposal %s: %s",
                         proposal.proposal_id, e)

    def _load_proposals(self) -> None:
        """Load proposals from JSONL ledger on startup."""
        try:
            if not self._ledger_path.exists():
                return
            with open(self._ledger_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        # Reconstruct proposal from latest state
                        signatures = [
                            Signature(**s) for s in data.pop("signatures", [])
                        ]
                        proposal = MultiSigProposal(
                            **{k: v for k, v in data.items()
                               if k != "signatures"}
                        )
                        proposal.signatures = signatures
                        self._proposals[proposal.proposal_id] = proposal
                    except Exception:
                        continue
        except Exception as e:
            logger.error("Failed to load proposals: %s", e)

    # ── Cleanup ──

    def cleanup_expired(self) -> int:
        """Remove expired proposals older than 30 days from memory.
        
        Returns count removed.
        """
        self._check_expired()
        # Keep expired proposals in ledger, remove from memory to save space
        # In production you'd archive to cold storage
        cutoff = time.time() - (30 * 24 * 3600)
        to_remove = []
        for pid, proposal in self._proposals.items():
            if proposal.status == "expired":
                try:
                    created = datetime.fromisoformat(proposal.created_at)
                    if created.timestamp() < cutoff:
                        to_remove.append(pid)
                except (ValueError, AttributeError):
                    continue

        for pid in to_remove:
            self._proposals.pop(pid, None)

        return len(to_remove)


# ── Module Level Singleton ──

_MSA: Optional[MultiSigApproval] = None
_msa_lock = threading.Lock()


def get_multi_sig(ledger_path: Optional[Path] = None) -> MultiSigApproval:
    """Get or create the module-level MultiSigApproval singleton."""
    global _MSA
    if _MSA is None:
        with _msa_lock:
            if _MSA is None:
                _MSA = MultiSigApproval(ledger_path=ledger_path)
    return _MSA


# ── Default Policies ──

def create_default_policies() -> Dict[str, MultiSigPolicy]:
    """Create a set of sensible default multi-sig policies."""
    return {
        "small_trade": MultiSigPolicy(
            policy_id="small_trade",
            description="Small trades under $1k require 1 trader",
            threshold=1,
            min_signers=1,
            allowed_roles=["trader"],
            timeout_hours=4,
            max_value_usd=1000.0,
            min_value_usd=0.0,
        ),
        "medium_trade": MultiSigPolicy(
            policy_id="medium_trade",
            description="Medium trades $1k-$10k require 2 signers",
            threshold=2,
            min_signers=2,
            allowed_roles=["trader", "risk_manager"],
            timeout_hours=8,
            max_value_usd=10000.0,
            min_value_usd=1000.0,
        ),
        "large_trade": MultiSigPolicy(
            policy_id="large_trade",
            description="Large trades $10k-$100k require 3 signers",
            threshold=3,
            min_signers=2,
            allowed_roles=["trader", "risk_manager", "compliance"],
            timeout_hours=24,
            max_value_usd=100000.0,
            min_value_usd=10000.0,
        ),
        "whale_trade": MultiSigPolicy(
            policy_id="whale_trade",
            description="Whale trades >$100k require 4 signers including admin",
            threshold=4,
            min_signers=3,
            allowed_roles=["trader", "risk_manager", "compliance", "admin"],
            timeout_hours=48,
            min_value_usd=100000.0,
        ),
        "withdraw": MultiSigPolicy(
            policy_id="withdraw",
            description="Any withdrawal requires 2 signers including risk manager",
            threshold=2,
            min_signers=2,
            allowed_roles=["risk_manager", "admin"],
            timeout_hours=24,
            min_value_usd=0.0,
        ),
        "deploy": MultiSigPolicy(
            policy_id="deploy",
            description="Code deployment requires admin approval",
            threshold=1,
            min_signers=1,
            allowed_roles=["admin"],
            timeout_hours=72,
            min_value_usd=0.0,
        ),
    }


# ── Self-test ──

def test_multi_sig() -> None:
    """Run a self-test of the multi-sig system."""
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        ledger = Path(tmpdir) / "ledger.jsonl"
        policies = create_default_policies()

        msa = MultiSigApproval(policies=policies, ledger_path=ledger)

        # Register signers
        msa.register_signer(SignerInfo("trader1", "Alice", "trader", weight=1))
        msa.register_signer(SignerInfo("trader2", "Bob", "trader", weight=1))
        msa.register_signer(SignerInfo("risk1", "Carol", "risk_manager", weight=2))
        msa.register_signer(SignerInfo("admin1", "Dave", "admin", weight=3,
                                        is_emergency_authorized=True))
        msa.register_signer(SignerInfo("comp1", "Eve", "compliance", weight=1))

        # Test 1: Small trade (1 signer)
        small = msa.submit(
            intent_type="trade",
            payload={"pair": "BTC/USD", "side": "buy", "quantity": 0.1},
            value_usd=500.0,
            submitted_by="trader1",
            description="Test small trade",
        )
        assert small.status == "pending"
        assert small.proposal_id.startswith("ms-")

        # Sign it (1 trader → threshold 1)
        small = msa.sign(small.proposal_id, "trader1", approved=True)
        assert small.status == "approved", f"Expected approved, got {small.status}"
        print(f"  ✅ Small trade: approved with {len(small.signatures)} signature(s)")

        # Test 2: Medium trade (2 signers needed)
        med = msa.submit(
            intent_type="trade",
            payload={"pair": "ETH/USD", "side": "sell", "quantity": 5.0},
            value_usd=5000.0,
            submitted_by="trader1",
            description="Test medium trade",
        )
        assert med.status == "pending"

        med = msa.sign(med.proposal_id, "trader1", approved=True)
        assert med.status == "pending", "Should still be pending (need 2 signers)"
        med = msa.sign(med.proposal_id, "risk1", approved=True)
        assert med.status == "approved", f"Expected approved, got {med.status}"
        print(f"  ✅ Medium trade: approved with {len(med.signatures)} signature(s)")

        # Test 3: Rejection
        rej = msa.submit(
            intent_type="trade",
            payload={"pair": "SOL/USD", "side": "buy", "quantity": 100},
            value_usd=3000.0,
            submitted_by="trader2",
            description="Test rejection",
        )
        rej = msa.sign(rej.proposal_id, "trader2", approved=True)
        rej = msa.sign(rej.proposal_id, "risk1", approved=False,
                       comment="Insufficient liquidity")
        assert rej.status == "rejected", f"Expected rejected, got {rej.status}"
        print(f"  ✅ Rejection: rejected with comment")

        # Test 4: Emergency override
        override = msa.submit(
            intent_type="trade",
            payload={"pair": "BTC/USD", "side": "buy", "quantity": 10},
            value_usd=50000.0,
            submitted_by="trader1",
            description="Test emergency override",
        )
        override = msa.emergency_override(
            override.proposal_id, "admin1",
            "Market opportunity expiring, need immediate execution"
        )
        assert override.status in ("overridden", "executed")
        print(f"  ✅ Emergency override: {override.status}")

        # Test 5: Summary
        summary = msa.get_summary()
        assert summary["total"] == 4
        assert summary["pending"] >= 0
        print(f"  ✅ Summary: {summary['total']} proposals, "
              f"{summary['approved']} approved, "
              f"{summary['rejected']} rejected")

        # Test 6: Find matching policy
        policy = msa.find_matching_policy("trade", 50.0)
        assert policy is not None
        assert policy.policy_id == "small_trade"
        policy = msa.find_matching_policy("trade", 50000.0)
        assert policy is not None
        assert policy.policy_id == "large_trade"
        policy = msa.find_matching_policy("withdraw", 100.0)
        assert policy is not None
        assert policy.policy_id == "withdraw"
        print(f"  ✅ Policy matching works")

        # Test 7: Duplicate signer rejected
        dupe = msa.submit(
            intent_type="trade",
            payload={"pair": "ETH/USD", "side": "buy", "quantity": 1},
            value_usd=500.0,
            submitted_by="trader1",
        )
        msa.sign(dupe.proposal_id, "trader1", approved=True)
        try:
            msa.sign(dupe.proposal_id, "trader1", approved=True)
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "already signed" in str(e)
        print(f"  ✅ Duplicate signer prevention works")

        # Test 8: Persistence (reload from ledger)
        msa2 = MultiSigApproval(policies=policies, ledger_path=ledger)
        assert len(msa2.list_proposals()) >= 4
        reloaded = msa2.get_proposal(small.proposal_id)
        assert reloaded is not None
        assert reloaded.status == "approved"
        print(f"  ✅ Persistence: reloaded {len(msa2.list_proposals())} proposals")

        # Test 9: Cancel
        cancel_me = msa.submit(
            intent_type="trade",
            payload={"pair": "SOL/USD", "side": "sell", "quantity": 50},
            value_usd=2500.0,
            submitted_by="trader1",
        )
        cancel_me = msa.cancel(cancel_me.proposal_id, "trader1")
        assert cancel_me.status == "rejected"
        print(f"  ✅ Cancel works")

        print(f"\n✅ T41 test_multi_sig: ALL PASSED")


if __name__ == "__main__":
    test_multi_sig()
