"""
TradingQuant Analyzer — TradingQuant Model Integration for Quantum Organ
=========================================================================
Wires the fine-tuned tradingquant:latest (Ollama) into the quantumarb organ
as an enhanced market analysis layer.

Architecture:
  quantum_decision_agent.py
       │
       ├── RegimeDetector (technical indicators — ADX/RSI/BB) ← existing
       │
       └── TradingQuantAnalyzer (LLM-based structured analysis) ← NEW
                │
                ├── Ollama: tradingquant:latest (local, 4.7GB)
                ├── Market regime classification + reasoning
                ├── Signal quality scoring (0-100)
                ├── Confidence calibration override
                └── Trade recommendation with justification

Integration Points:
  - quantum_decision_agent.py calls get_analysis() during evaluation
  - Returns structured dict matching the DecisionRecord format
  - Falls back to RegimeDetector if Ollama unavailable
"""

import json
import logging
import time
import re
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any
from pathlib import Path

from simp.mesh.model_gateway import get_model_gateway

log = logging.getLogger("tradingquant_analyzer")

OLLAMA_MODEL = "tradingquant:latest"
OLLAMA_API = "http://localhost:11434/api/generate"
OLLAMA_TIMEOUT = 90
CACHE_FILE = Path("state/tradingquant_analysis_cache.jsonl")
MAX_CACHE_ENTRIES = 100


@dataclass
class AnalysisResult:
    """Structured output from tradingquant model."""
    regime: str
    regime_confidence: float
    volatility: float
    sentiment: float
    flow: float
    signal_score: int
    recommendation: str
    reasoning: str
    indicators_used: List[str]
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    model: str = OLLAMA_MODEL
    inference_time_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class TradingQuantAnalyzer:
    """
    Wraps the tradingquant:latest Ollama model for market analysis.

    Provides structured regime/sentiment/recommendation output
    that can be consumed by quantum_decision_agent and other
    SIMP organs.
    """

    def __init__(self, model: str = OLLAMA_MODEL, timeout: int = OLLAMA_TIMEOUT):
        self.model = model
        self.timeout = timeout
        self._cache: Dict[str, AnalysisResult] = {}
        self._availability: Optional[bool] = None  # None = not checked yet

    def check_available(self) -> bool:
        """Check if tradingquant model is loaded and responsive via ModelGateway."""
        if self._availability is not None:
            return self._availability
        try:
            gateway = get_model_gateway()
            health = gateway.health_check()
            self._availability = health.get("models", {}).get("trading", False)
            return self._availability
        except Exception:
            self._availability = False
            return False

    def get_analysis(
        self,
        symbol: str,
        price: float,
        prices_24h: Optional[List[float]] = None,
        volume_24h: Optional[float] = None,
        market_data: Optional[Dict[str, Any]] = None,
        use_cache: bool = True,
    ) -> AnalysisResult:
        """
        Get structured market analysis from tradingquant via Ollama.

        Args:
            symbol: Trading pair (e.g., "BTC-USD")
            price: Current price
            prices_24h: Recent price history (optional)
            volume_24h: 24h volume (optional)
            market_data: Any additional market context
            use_cache: If True, returns cached result for same symbol within 60s

        Returns:
            AnalysisResult with regime, signal score, recommendation
        """
        cache_key = f"{symbol}:{price:.0f}:{int(time.time() / 60)}"  # symbol:price:minute

        if use_cache and cache_key in self._cache:
            return self._cache[cache_key]

        if not self.check_available():
            log.warning(f"Model {self.model} not available, returning unknown analysis")
            return AnalysisResult(
                regime="unknown",
                regime_confidence=0.0,
                volatility=0.0,
                sentiment=0.5,
                flow=0.5,
                signal_score=0,
                recommendation="HOLD",
                reasoning="Model unavailable — market data only",
                indicators_used=["none"],
            )

        # Build structured analysis prompt
        prompt = self._build_prompt(symbol, price, prices_24h, volume_24h, market_data)
        raw_output = self._query_ollama(prompt)
        result = self._parse_response(raw_output, symbol)
        
        # === Momentum Override ===
        # The model has a bullish bias from training data.
        # Apply price-trend correction when 24h data shows clear direction.
        if prices_24h and len(prices_24h) >= 2:
            price_open = prices_24h[0]
            price_close = prices_24h[-1]
            change_pct = (price - price_open) / price_open * 100
            intraday_range_pct = (max(prices_24h) - min(prices_24h)) / price_open * 100
            
            # Price declining >1.5% → cap signal_score, force SELL/HOLD
            if change_pct < -1.5 and result.recommendation == "BUY":
                if result.signal_score > 50:
                    result.signal_score = int(result.signal_score * 0.5)
                result.recommendation = "HOLD"
                result.regime = "trending_down" if abs(change_pct) > 3 else "ranging"
                log.info(f"Momentum override: {symbol} down {change_pct:.1f}% → HOLD")
            
            # Price surging >2% and model says HOLD → upgrade
            elif change_pct > 2.0 and result.recommendation in ("HOLD", "SELL"):
                result.signal_score = min(100, result.signal_score + 20)
                result.recommendation = "BUY"
                result.regime = "trending_up"
                log.info(f"Momentum override: {symbol} up {change_pct:.1f}% → BUY")
            
            # High volatility (>5% range) → reduce signal confidence
            if intraday_range_pct > 5.0:
                result.signal_score = int(result.signal_score * 0.85)
                # Downgrade regime if it was trending_up but stable
                if result.regime == "trending_up" and change_pct < 1:
                    result.regime = "high_vol"
                log.info(f"Volatility override: {symbol} range {intraday_range_pct:.1f}% → signal {result.signal_score}")
        
        # Cache and log
        self._cache[cache_key] = result
        self._log_analysis(result)
        
        return result

    def _build_prompt(
        self,
        symbol: str,
        price: float,
        prices_24h: Optional[List[float]] = None,
        volume_24h: Optional[float] = None,
        market_data: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Build structured analysis prompt for the tradingquant model."""
        
        # Price context
        high_24h = max(prices_24h) if prices_24h else price
        low_24h = min(prices_24h) if prices_24h else price
        price_range = (high_24h - low_24h) / (low_24h or 1) * 100 if prices_24h else 0.0

        prompt = f"""### Market Analysis Request

Asset: {symbol}
Price: ${price:.2f}
24h High: ${high_24h:.2f}
24h Low: ${low_24h:.2f}
24h Range: {price_range:.1f}%
"""
        if volume_24h:
            prompt += f"Volume: ${volume_24h:,.0f}\n"

        if market_data:
            prompt += f"Context: {json.dumps(market_data)}\n"

        prompt += """
### Analysis
"""
        return prompt

    def _query_ollama(self, prompt: str) -> str:
        """Query tradingquant model via ModelGateway (unified Ollama routing)."""
        try:
            gateway = get_model_gateway()
            response = gateway.route(
                intent_type="trading",
                prompt=prompt,
                timeout=self.timeout,
            )
            if response.error:
                log.error(f"ModelGateway error: {response.error}")
                return ""
            elapsed = int(response.inference_time_ms)
            log.info(f"ModelGateway trading route: {elapsed}ms via {response.model}")
            return response.response_text.strip()
        except Exception as e:
            log.error(f"ModelGateway routing failed: {e}")
            return ""

    def _parse_response(self, raw: str, symbol: str) -> AnalysisResult:
        """Parse JSON response from model, with fallback for malformed output."""
        inference_time = 0  # Will be set if we track it properly

        if not raw:
            return AnalysisResult(
                regime="unknown",
                regime_confidence=0.0,
                volatility=0.0,
                sentiment=0.5,
                flow=0.5,
                signal_score=0,
                recommendation="HOLD",
                reasoning="No response from model",
                indicators_used=["none"],
            )

        # Try to extract JSON from response (model may wrap in markdown, or trail off)
        try:
            # Find JSON block
            start_idx = raw.find("{")
            end_idx = raw.rfind("}")
            if start_idx >= 0 and end_idx > start_idx:
                json_str = raw[start_idx : end_idx + 1]
                # Fix common truncation — model sometimes leaves trailing "
                # by attempting sequential key removal   
                data = self._safe_parse(json_str)
            else:
                data = self._safe_parse(raw)
        except Exception:
            log.warning(f"Failed to parse model response as JSON: {raw[:200]}")
            return AnalysisResult(
                regime="unknown",
                regime_confidence=0.0,
                volatility=0.0,
                sentiment=0.5,
                flow=0.5,
                signal_score=0,
                recommendation="HOLD",
                reasoning=f"Parse error: {raw[:100]}",
                indicators_used=["none"],
            )

        # Validate and sanitize fields
        regime = str(data.get("regime", "unknown"))
        valid_regimes = {"trending_up", "trending_down", "ranging", "high_vol", "unknown"}
        if regime not in valid_regimes:
            regime = "unknown"

        return AnalysisResult(
            regime=regime,
            regime_confidence=min(1.0, max(0.0, float(data.get("regime_confidence", 0.0)))),
            volatility=min(1.0, max(0.0, float(data.get("volatility", 0.0)))),
            sentiment=min(1.0, max(0.0, float(data.get("sentiment", 0.5)))),
            flow=min(1.0, max(0.0, float(data.get("flow", 0.5)))),
            signal_score=max(0, min(100, int(data.get("signal_score", 50)))),
            recommendation=str(data.get("recommendation", "HOLD")).upper(),
            reasoning=str(data.get("reasoning", "No reasoning provided"))[:500],
            indicators_used=[str(i) for i in data.get("indicators_used", [])],
            model=self.model,
        )

    @staticmethod
    def _safe_parse(raw: str) -> dict:
        """
        Parse tradingquant model output into structured dict.
        The model outputs natural language analysis — we extract
        regime, sentiment, and recommendation via regex patterns.
        """
        text = raw.lower()

        # Extract regime
        regime = "unknown"
        for kw in [("trending_up", "trending up|uptrend|bullish|uptrending"),
                   ("trending_down", "trending down|downtrend|bearish|downtrending"),
                   ("ranging", "ranging|consolidat|sideways|neutral|choppy"),
                   ("high_vol", "high vol|volatile|high volatility|turbulent")]:
            label, pattern = kw
            if re.search(pattern, text):
                regime = label
                break

        # Extract sentiment (0.0-1.0)
        sentiment = 0.5
        if re.search(r"bullish|positive|strong|uptrend|buy signal|oversold", text):
            sentiment = 0.7 + (0.3 if re.search(r"very bullish|strong buy|extremely positive", text) else 0.0)
        elif re.search(r"bearish|negative|weak|downtrend|sell signal|overbought", text):
            sentiment = 0.3 - (0.2 if re.search(r"very bearish|strong sell|extremely negative", text) else 0.0)

        # Extract recommendation
        rec = "HOLD"
        if re.search(r"\bbuy\b|long entry|accumulat", text):
            rec = "BUY"
        elif re.search(r"\bsell\b|short|exit|take profit", text):
            rec = "SELL"

        # Extract signal score (infer from text)
        signal_score = 50
        if rec == "BUY" and sentiment > 0.6:
            signal_score = 65 + int((sentiment - 0.6) * 80)
        elif rec == "SELL" and sentiment < 0.4:
            signal_score = 65 + int((0.4 - sentiment) * 80)
        elif rec == "HOLD":
            signal_score = 40 + int((sentiment - 0.3) * 50)

        # Extract volatility keywords
        vol = 0.5
        if re.search(r"high vol|volatile|turbulent|high volatility|wide range", text):
            vol = 0.7 + (0.3 if re.search(r"extreme|very high", text) else 0.0)
        elif re.search(r"low vol|stable|calm|tight|narrow range", text):
            vol = 0.3 - (0.2 if re.search(r"very low|extremely stable", text) else 0.0)

        # Extract flow
        flow = 0.5
        if re.search(r"high volume|strong flow|inflow|positive flow|accumulation|buying pressure", text):
            flow = 0.65
        elif re.search(r"low volume|outflow|negative flow|distribution|selling pressure", text):
            flow = 0.35

        # Extract indicators referenced
        indicators = []
        indicator_patterns = [
            "rsi", "macd", "bollinger", "moving average|ma|ema|sma",
            "adx", "atr", "stochastic", "volume|obv", "fibonacci",
            "support|resistance", "trendline", "ichimoku"
        ]
        for pattern in indicator_patterns:
            if re.search(pattern, text):
                indicators.append(pattern.split("|")[0])

        return {
            "regime": regime,
            "regime_confidence": min(1.0, sentiment + 0.15),
            "volatility": vol,
            "sentiment": round(sentiment, 2),
            "flow": round(flow, 2),
            "signal_score": min(100, signal_score),
            "recommendation": rec,
            "reasoning": raw[:300],
            "indicators_used": list(set(indicators)),
        }

    def _log_analysis(self, result: AnalysisResult) -> None:
        """Log analysis to cache file for auditing."""
        try:
            CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            entries = []
            if CACHE_FILE.exists():
                with open(CACHE_FILE) as f:
                    entries = [json.loads(line) for line in f if line.strip()]
            
            entries.append(result.to_dict())
            
            # Keep only recent entries
            if len(entries) > MAX_CACHE_ENTRIES:
                entries = entries[-MAX_CACHE_ENTRIES:]
            
            with open(CACHE_FILE, "w") as f:
                for entry in entries:
                    f.write(json.dumps(entry) + "\n")
        except Exception as e:
            log.warning(f"Failed to log analysis: {e}")

    def get_cached_analysis(self, symbol: str, max_age_seconds: int = 60) -> Optional[AnalysisResult]:
        """Retrieve cached analysis for a symbol within the age window."""
        cache_key = f"{symbol}:{int(time.time() / (max_age_seconds // 60 or 1))}"
        return self._cache.get(cache_key)

    def clear_cache(self) -> None:
        """Clear in-memory analysis cache."""
        self._cache.clear()

    def status(self) -> Dict[str, Any]:
        """Return status dict for health monitoring."""
        return {
            "model": self.model,
            "available": self.check_available(),
            "cache_size": len(self._cache),
            "cache_file": str(CACHE_FILE),
        }


# ── Quick test ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    analyzer = TradingQuantAnalyzer()
    
    print(f"Model available: {analyzer.check_available()}")
    
    if analyzer.check_available():
        result = analyzer.get_analysis(
            symbol="BTC-USD",
            price=82450.00,
            prices_24h=[81000, 81500, 82000, 81800, 82200, 82500, 82450],
            volume_24h=28_500_000_000,
            market_data={"fear_greed_index": 65, "open_interest_change_pct": 2.3},
        )
        print("\n=== Analysis Result ===")
        print(json.dumps(result.to_dict(), indent=2))
    else:
        print(f"Model '{OLLAMA_MODEL}' not found in Ollama. Run:")
        print(f"  ollama pull {OLLAMA_MODEL}")
