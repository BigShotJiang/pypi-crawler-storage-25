"""
SIMP Evolutionary Adapter — Automatically Absorb Any Agent Protocol.

This is the core of SIMP's "evolving adapter" strategy:

  1. SCAN — Watch for new agent protocols/tools across GitHub, HF, npm, PyPI
  2. LEARN — Auto-discover their API surface (endpoints, tools, capabilities)
  3. GENERATE — Create a SIMP bridge adapter on the fly
  4. ABSORB — Register as native SIMP capabilities
  5. OPTIMIZE — Track usage, improve routing, update adapters

The adapter never stops watching. Every agent protocol that emerges
gets absorbed before it can become a competitive threat.

Usage:
    from simp.adapter import EvolutionaryAdapter
    
    adapter = EvolutionaryAdapter()
    await adapter.start()  # Begin continuous scanning + absorption
    
    # Adapters are auto-discovered and applied:
    intent = Intent(intent_type="any_agent_tool_call")
    response = await adapter.handle(intent)
"""

import logging
import os
import json
import hashlib
import asyncio
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any, Set
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Adapter Signature — What defines a protocol's bridge
# ---------------------------------------------------------------------------

@dataclass
class AdapterSignature:
    """
    A protocol's fingerprint — used to detect new versions and
    generate adapters automatically.
    
    Fields capture every dimension of an external protocol:
      - Transport: REST, WebSocket, gRPC, stdio, protobuf, etc.
      - Auth: API key, OAuth, JWT, mTLS, none
      - Capabilities: what tools/endpoints does it expose
      - Schema: request/response format
      - Identity: how agents identify themselves
      - Settlement: does it have payment? what token?
    """
    # Protocol metadata
    name: str
    version: str
    source: str  # github, hf, npm, pypi, docker
    
    # Transport
    transport_type: str  # rest | ws | grpc | stdio | queue
    base_url: Optional[str] = None
    protocol_format: str = "json"  # json | protobuf | msgpack | custom
    
    # Auth
    auth_type: str = "none"  # none | apikey | oauth | jwt | mtls
    auth_location: str = ""  # header | query | body | cookie
    
    # Capabilities
    capability_discovery: str = ""  # how to discover tools (e.g., "get /tools", "tools/list")
    capabilities: List[str] = field(default_factory=list)
    
    # Schema
    request_schema: dict = field(default_factory=dict)
    response_schema: dict = field(default_factory=dict)
    
    # Identity
    identity_type: str = "string"  # string | uuid | key | did
    
    # Settlement
    supports_payment: bool = False
    payment_token: Optional[str] = None
    
    # Learned metadata
    first_seen: str = ""
    last_seen: str = ""
    usage_count: int = 0
    reliability: float = 1.0  # 0.0 — 1.0
    
    def fingerprint(self) -> str:
        """Unique hash for this protocol version."""
        key = f"{self.name}:{self.version}:{self.transport_type}:{self.auth_type}"
        return hashlib.sha256(key.encode()).hexdigest()[:16]
    
    def is_compatible_with(self, other: 'AdapterSignature') -> bool:
        """Check if two protocol versions are compatible (minor changes only)."""
        base = self.name == other.name
        major = self.version.split('.')[0] == other.version.split('.')[0]
        transport = self.transport_type == other.transport_type
        return base and major and transport


# ---------------------------------------------------------------------------
# Adapter Generator — Create bridges from signatures
# ---------------------------------------------------------------------------

class AdapterGenerator:
    """
    Generates bridge adapters from protocol signatures.
    
    The generator is recursive — it can learn from its own generated
    adapters and improve them over time.
    """

    # Template mappings — known protocol patterns
    TRANSPORT_TEMPLATES = {
        "rest": """
async def call_{name}(params: dict, auth: dict) -> dict:
    \"\"\"Auto-generated adapter for {name} v{version}\"\"\"
    import aiohttp
    
    headers = {{"Content-Type": "application/json"}}
    {auth_header}
    
    async with aiohttp.ClientSession(headers=headers) as session:
        {capability_routing}
        async with session.{method}(
            url, json=request_body, timeout=30
        ) as resp:
            result = await resp.json()
            return {response_transform}
""",
        "ws": """
async def call_{name}(params: dict, auth: dict) -> dict:
    \"\"\"Auto-generated WebSocket adapter for {name} v{version}\"\"\"
    import asyncio
    import json
    
    {auth_setup}
    
    async with websockets.connect("{base_url}") as ws:
        {capability_routing}
        await ws.send(json.dumps(request_body))
        result = json.loads(await ws.recv())
        return {response_transform}
""",
        "stdio": """
async def call_{name}(params: dict, auth: dict) -> dict:
    \"\"\"Auto-generated stdio adapter for {name} v{version}\"\"\"
    import asyncio
    import json
    
    {auth_setup}
    
    proc = await asyncio.create_subprocess_exec(
        {command_args},
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
    )
    
    request = {request_body}
    stdout, _ = await proc.communicate(json.dumps(request).encode())
    result = json.loads(stdout.decode())
    return {response_transform}
""",
    }

    def generate_adapter(self, sig: AdapterSignature) -> str:
        """Generate a bridge adapter from a protocol signature."""
        template = self.TRANSPORT_TEMPLATES.get(sig.transport_type)
        if not template:
            raise ValueError(f"Unknown transport: {sig.transport_type}")
        
        # Determine HTTP method for REST
        method = "post"
        if sig.capability_discovery.startswith("GET "):
            method = "get"
        
        # Build auth header template
        auth_header = ""
        if sig.auth_type == "apikey" and sig.auth_location == "header":
            auth_header = f'headers["Authorization"] = f"Bearer {{auth.get(\'api_key\', \'\')}}"'
        elif sig.auth_type == "jwt":
            auth_header = f'headers["Authorization"] = f"Bearer {{auth.get(\'token\', \'\')}}"'
        
        # Build capability routing
        if sig.capabilities:
            capability_routing = f"""
        tool = params.get("tool", "{sig.capabilities[0]}")
        url = f"{{base_url}}/{{tool}}"
        request_body = params.get("params", params)
"""
        else:
            capability_routing = f"""
        url = "{sig.base_url or 'http://localhost'}"
        request_body = params
"""
        
        # Build response transform
        response_transform = """{"status": "success", "data": result}"""
        
        # Build command args for stdio
        command_args = ""
        if sig.transport_type == "stdio":
            parts = (sig.base_url or "").split()
            command_args = ", ".join(f'"{p}"' for p in parts)
        
        return template.format(
            name=sig.name.replace("-", "_").replace(".", "_"),
            version=sig.version,
            base_url=sig.base_url or "ws://localhost",
            method=method,
            auth_header=auth_header,
            auth_setup=auth_header,
            capability_routing=capability_routing,
            request_body="params",
            response_transform=response_transform,
            command_args=command_args,
        )


# ---------------------------------------------------------------------------
# Protocol Scanner — Watch for new protocols across ecosystems
# ---------------------------------------------------------------------------

class ProtocolScanner:
    """
    Continuously scans for new agent protocols across:
      - GitHub (new repos, trending in agent space)
      - Hugging Face (new Spaces with agent patterns)
      - PyPI / npm (new packages with "agent", "mcp", "a2a" keywords)
      - Hacker News / Reddit (mentions of new protocols)
      - Pre-registered well-known sources
    """

    SCAN_SOURCES = {
        "github_trending": "https://api.github.com/search/repositories?q=agent+protocol+OR+agent+tool+OR+mcp+server&sort=stars&per_page=20",
        "github_mcp": "https://api.github.com/search/repositories?q=mcp+server+tool&sort=updated&per_page=20",
        "github_a2a": "https://api.github.com/search/repositories?q=agent-to-agent+protocol&sort=updated&per_page=10",
        "github_intent": "https://api.github.com/search/repositories?q=agent+intent+routing&sort=updated&per_page=10",
        "pypi": "https://pypi.org/search/?q=agent+protocol&o=-created",
        "npm": "https://registry.npmjs.org/-/v1/search?text=agent+protocol+tool&size=20",
    }

    def __init__(self):
        self._known_signatures: Dict[str, AdapterSignature] = {}
        self._seen_repos: Set[str] = set()

    async def scan_all(self) -> List[AdapterSignature]:
        """Scan all sources for new protocols."""
        discovered = []
        
        for source_name, url in self.SCAN_SOURCES.items():
            try:
                results = await self._scan_source(source_name, url)
                discovered.extend(results)
            except Exception as e:
                logger.debug(f"Scan {source_name} failed: {e}")
        
        # Filter to truly new protocols
        new_protocols = []
        for sig in discovered:
            fp = sig.fingerprint()
            if fp not in self._known_signatures:
                self._known_signatures[fp] = sig
                new_protocols.append(sig)
        
        if new_protocols:
            logger.info(f"Discovered {len(new_protocols)} new protocols: "
                       f"{[p.name for p in new_protocols]}")
        
        return new_protocols

    async def _scan_source(self, source_name: str, url: str) -> List[AdapterSignature]:
        """Scan a single source for protocol definitions."""
        import aiohttp
        
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"User-Agent": "simp-adapter/1.0"}
                
                if "github.com" in url:
                    # GitHub token from env
                    gh_token = os.environ.get("GITHUB_TOKEN")
                    if gh_token:
                        headers["Authorization"] = f"Bearer {gh_token}"
                
                async with session.get(url, headers=headers, timeout=15) as resp:
                    if resp.status != 200:
                        return []
                    data = await resp.json()
        except Exception as e:
            logger.debug(f"HTTP scan failed for {source_name}: {e}")
            return []

        # Parse results based on source type
        if "github.com" in url:
            return self._parse_github_results(data, source_name)
        elif "pypi.org" in url:
            return self._parse_pypi_results(data)
        elif "npmjs.org" in url:
            return self._parse_npm_results(data)
        
        return []

    def _parse_github_results(self, data: dict, source: str) -> List[AdapterSignature]:
        """Extract protocol signatures from GitHub search results."""
        signatures = []
        
        repos = data.get("items", [])
        for repo in repos[:10]:  # Top 10 per scan
            name = repo.get("full_name", "")
            if name in self._seen_repos:
                continue
            self._seen_repos.add(name)
            
            description = repo.get("description", "") or ""
            topics = repo.get("topics", [])
            
            # Detect protocol characteristics from repo metadata
            sig = self._detect_from_metadata(
                name=name,
                description=description,
                topics=topics,
                source=f"github:{name}",
            )
            if sig:
                signatures.append(sig)
        
        return signatures

    def _parse_pypi_results(self, data: dict) -> List[AdapterSignature]:
        """Parse PyPI search results."""
        # PyPI HTML search — requires parsing. Simplified here.
        return []

    def _parse_npm_results(self, data: dict) -> List[AdapterSignature]:
        """Parse npm search results."""
        signatures = []
        packages = data.get("objects", [])
        for pkg in packages[:10]:
            pkg_data = pkg.get("package", {})
            name = pkg_data.get("name", "")
            description = pkg_data.get("description", "") or ""
            keywords = pkg_data.get("keywords", [])
            
            sig = self._detect_from_metadata(
                name=name,
                description=description,
                topics=keywords,
                source=f"npm:{name}",
            )
            if sig:
                signatures.append(sig)
        
        return signatures

    def _detect_from_metadata(
        self,
        name: str,
        description: str,
        topics: List[str],
        source: str,
    ) -> Optional[AdapterSignature]:
        """Detect protocol characteristics from repo/package metadata."""
        desc_lower = description.lower()
        topics_lower = [t.lower() for t in topics]
        all_text = desc_lower + " " + " ".join(topics_lower)
        
        # Detect transport
        transport = "rest"
        if any(t in all_text for t in ["websocket", "ws://", "wss://"]):
            transport = "ws"
        if any(t in all_text for t in ["stdio", "subprocess", "stdin"]):
            transport = "stdio"
        if any(t in all_text for t in ["grpc", "protobuf"]):
            transport = "grpc"
        
        # Detect auth
        auth = "none"
        if any(t in all_text for t in ["oauth", "oauth2"]):
            auth = "oauth"
        elif any(t in all_text for t in ["jwt", "bearer"]):
            auth = "jwt"
        elif any(t in all_text for t in ["apikey", "api_key", "api key"]):
            auth = "apikey"
        
        # Detect capability model
        capabilities = []
        if "mcp" in topics_lower or "model-context-protocol" in all_text:
            capabilities.append("mcp_tools/list")
            capabilities.append("mcp_tools/call")
        if "a2a" in topics_lower or "agent-to-agent" in all_text:
            capabilities.append("a2a_send_message")
        if "tool" in topics_lower:
            capabilities.append("tool_execute")
        if "function" in topics_lower or "function_calling" in all_text:
            capabilities.append("function_call")
        
        # Detect payment
        supports_payment = any(t in all_text for t in [
            "payment", "settlement", "token", "crypto", "micropayment"
        ])
        
        return AdapterSignature(
            name=name.split("/")[-1] if "/" in name else name,
            version="1.0",  # Will be refined on deeper scan
            source=source,
            transport_type=transport,
            auth_type=auth,
            capabilities=capabilities,
            supports_payment=supports_payment,
            first_seen=datetime.now(timezone.utc).isoformat(),
        )


# ---------------------------------------------------------------------------
# Deep Protocol Analyzer — Probe a live protocol endpoint
# ---------------------------------------------------------------------------

class ProtocolAnalyzer:
    """
    Probes a live protocol endpoint to learn its capabilities.
    
    Uses techniques from:
      - OpenAPI spec discovery (GET /openapi.json, GET /swagger.json)
      - GraphQL introspection (POST /graphql with introspection query)
      - MCP discovery (JSON-RPC tools/list)
      - Generic endpoint probing (common paths)
    """

    DISCOVERY_PATHS = [
        "/openapi.json",
        "/swagger.json",
        "/api/openapi.json",
        "/api/spec",
        "/.well-known/simp",
        "/.well-known/agent",
        "/.well-known/mcp",
        "/health",
        "/api/health",
        "/tools",
        "/api/tools",
        "/capabilities",
    ]

    MCP_METHODS = [
        "tools/list",
        "resources/list",
        "prompts/list",
    ]

    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    async def analyze(self) -> AdapterSignature:
        """Deep-analyze a protocol endpoint and return its signature."""
        sig = AdapterSignature(
            name=self.base_url.split("://")[-1].split(".")[0],
            version="1.0",
            source=f"probe:{self.base_url}",
            first_seen=datetime.now(timezone.utc).isoformat(),
        )
        
        # Try each discovery path
        discovered_capabilities = []
        
        for path in self.DISCOVERY_PATHS:
            try:
                result = await self._probe_path(path)
                if result:
                    caps = self._parse_discovery_result(path, result)
                    discovered_capabilities.extend(caps)
                    
                    # Update transport from response
                    if "websocket" in result.get("protocol", "") or \
                       "ws" in result.get("transports", []):
                        sig.transport_type = "ws"
                    
                    # Update auth
                    if "auth" in result:
                        sig.auth_type = result["auth"].get("type", sig.auth_type)
            except Exception:
                continue
        
        # Try MCP protocol probe
        if not discovered_capabilities:
            for method in self.MCP_METHODS:
                result = await self._mcp_probe(method)
                if result:
                    sig.capability_discovery = method
                    sig.transport_type = "stdio"  # MCP often uses stdio
                    
                    if method == "tools/list":
                        tools = result.get("result", {}).get("tools", [])
                        for t in tools:
                            discovered_capabilities.append(f"mcp.{t['name']}")
        
        sig.capabilities = discovered_capabilities or ["generic_handle"]
        sig.last_seen = datetime.now(timezone.utc).isoformat()
        
        return sig

    async def _probe_path(self, path: str) -> Optional[dict]:
        """Probe a single discovery path."""
        import aiohttp
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{self.base_url}{path}",
                    timeout=5,
                    headers={"User-Agent": "simp-adapter/1.0"},
                ) as resp:
                    if resp.status == 200:
                        return await resp.json()
        except Exception:
            return None

    async def _mcp_probe(self, method: str) -> Optional[dict]:
        """Probe using MCP JSON-RPC protocol."""
        import aiohttp
        
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": {},
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.base_url}/mcp",
                    json=payload,
                    timeout=5,
                ) as resp:
                    if resp.status == 200:
                        return await resp.json()
        except Exception:
            return None

    def _parse_discovery_result(self, path: str, result: dict) -> List[str]:
        """Extract capability names from a discovery endpoint response."""
        capabilities = []
        
        # OpenAPI / Swagger
        if "paths" in result:
            for path_name, methods in result["paths"].items():
                for method, details in methods.items():
                    if isinstance(details, dict):
                        summary = details.get("summary", details.get("operationId", path_name))
                        capabilities.append(f"openapi.{method}.{path_name}")
        
        # MCP-style discovery
        if "tools" in result:
            for t in result["tools"]:
                capabilities.append(f"mcp.{t.get('name', t)}")
        
        # Simple capability listing
        if isinstance(result, list):
            for item in result:
                if isinstance(item, str):
                    capabilities.append(f"capability.{item}")
                elif isinstance(item, dict):
                    capabilities.append(f"capability.{item.get('name', item.get('id', 'unknown'))}")
        
        # Well-known SIMP
        if "capabilities" in result:
            for cap in result["capabilities"]:
                if isinstance(cap, str):
                    capabilities.append(cap)
                elif isinstance(cap, dict):
                    capabilities.append(cap.get("type", cap.get("name", "unknown")))
        
        return capabilities


# ---------------------------------------------------------------------------
# Adapter Registry — Manage all active adapters
# ---------------------------------------------------------------------------

@dataclass
class AdapterInstance:
    """A live adapter instance wrapping an external protocol."""
    signature: AdapterSignature
    code: str  # Generated Python code for the adapter
    is_active: bool = True
    created_at: str = ""
    last_called: str = ""
    call_count: int = 0
    error_count: int = 0


class AdapterRegistry:
    """Registry of all adopted protocols and their adapters."""

    def __init__(self):
        self._adapters: Dict[str, AdapterInstance] = {}
        self._capability_index: Dict[str, str] = {}  # cap → adapter fingerprint

    def register(self, sig: AdapterSignature, code: str) -> str:
        """Register a new adapter."""
        fp = sig.fingerprint()
        instance = AdapterInstance(
            signature=sig,
            code=code,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._adapters[fp] = instance
        
        # Index capabilities
        for cap in sig.capabilities:
            self._capability_index[cap] = fp
        
        logger.info(f"Registered adapter: {sig.name} v{sig.version} "
                   f"({sig.transport_type}, {len(sig.capabilities)} capabilities)")
        return fp

    def get_adapter(self, capability: str) -> Optional[AdapterInstance]:
        """Find an adapter that can handle a capability."""
        # Direct match
        fp = self._capability_index.get(capability)
        if fp:
            return self._adapters.get(fp)
        
        # Prefix match
        for cap_type, adapter_fp in self._capability_index.items():
            if capability.startswith(cap_type) or cap_type.startswith(capability):
                return self._adapters.get(adapter_fp)
        
        return None

    def list_adapters(self) -> Dict[str, dict]:
        """List all registered adapters."""
        return {
            fp: {
                "name": inst.signature.name,
                "version": inst.signature.version,
                "transport": inst.signature.transport_type,
                "capabilities": inst.signature.capabilities,
                "source": inst.signature.source,
                "calls": inst.call_count,
                "errors": inst.error_count,
                "active": inst.is_active,
            }
            for fp, inst in self._adapters.items()
        }

    def record_call(self, fingerprint: str, success: bool):
        """Record an adapter call for reliability tracking."""
        inst = self._adapters.get(fingerprint)
        if inst:
            inst.call_count += 1
            inst.last_called = datetime.now(timezone.utc).isoformat()
            if not success:
                inst.error_count += 1
                inst.signature.reliability = max(
                    0.0,
                    inst.signature.reliability - (1.0 / (inst.call_count + 1))
                )
            else:
                inst.signature.reliability = min(
                    1.0,
                    inst.signature.reliability + (0.1 / (inst.call_count + 1))
                )


# ---------------------------------------------------------------------------
# The Evolutionary Adapter — Main orchestration
# ---------------------------------------------------------------------------

class EvolutionaryAdapter:
    """
    The core engine that:
      1. Continuously scans for new agent protocols
      2. Deep-analyzes each one (probe endpoints, discover capabilities)
      3. Generates a SIMP bridge adapter automatically
      4. Tests the adapter against live endpoints
      5. Deploys it into the registry
      6. Monitors usage and adapts over time
    
    This runs as a background service alongside the SIMP broker.
    """

    def __init__(
        self,
        scan_interval: int = 3600,        # Full scan every hour
        probe_enabled: bool = True,        # Probe live endpoints
        auto_deploy: bool = True,          # Auto-deploy generated adapters
        state_path: str = "./simp_adapter_state.json",
    ):
        self.scanner = ProtocolScanner()
        self.generator = AdapterGenerator()
        self.registry = AdapterRegistry()
        self.state_path = state_path
        
        self._scan_interval = scan_interval
        self._probe_enabled = probe_enabled
        self._auto_deploy = auto_deploy
        self._running = False
        
        # Pre-seeded well-known protocols
        self._well_known: List[dict] = [
            {"name": "mcp", "source": "https://github.com/modelcontextprotocol/spec"},
            {"name": "a2a", "source": "https://github.com/google/a2a"},
            {"name": "openai-tools", "source": "https://platform.openai.com/docs/guides/function-calling"},
            {"name": "anthropic-tools", "source": "https://docs.anthropic.com/claude/docs/tool-use"},
            {"name": "hf-inference-api", "source": "https://huggingface.co/docs/api-inference"},
            {"name": "openclaw", "source": "https://github.com/openclaw/openclaw"},
            {"name": "nanoclaw", "source": "https://github.com/qwibitai/nanoclaw"},
            {"name": "elizaos", "source": "https://github.com/elizaOS/eliza"},
            {"name": "vercel-ai-sdk", "source": "https://github.com/vercel/ai"},
            {"name": "langchain-tools", "source": "https://github.com/langchain-ai/langchain"},
            {"name": "crewai-tools", "source": "https://github.com/crewAIInc/crewAI"},
            {"name": "autogen-tools", "source": "https://github.com/microsoft/autogen"},
        ]
        
        # Load existing state
        self._load_state()

    async def start(self):
        """Start the evolutionary adapter — continuous scanning + adaptation."""
        self._running = True
        
        logger.info("Evolutionary Adapter started — scanning for protocols...")
        
        # Seed well-known protocols immediately
        await self._seed_well_known()
        
        # Main adaptation loop
        while self._running:
            try:
                await self._adaptation_cycle()
            except Exception as e:
                logger.error(f"Adaptation cycle failed: {e}")
            
            await asyncio.sleep(self._scan_interval)
    
    async def stop(self):
        """Stop the adapter."""
        self._running = False
        self._save_state()

    async def handle(self, intent: Any) -> dict:
        """Route an intent to the best available adapter.
        
        This is the unified entry point — any intent to any protocol
        gets routed through whatever adapter is registered.
        """
        intent_type = intent.intent_type if hasattr(intent, 'intent_type') else ""
        params = intent.params if hasattr(intent, 'params') else {}
        
        # Find an adapter that can handle this capability
        adapter = self.registry.get_adapter(intent_type)
        if not adapter:
            return {
                "status": "error",
                "error_code": "NO_ADAPTER",
                "error_message": f"No adapter found for '{intent_type}'. "
                               f"Try /adapt to teach SIMP this protocol.",
            }
        
        # Execute the generated adapter code
        try:
            # The generated code is a string — we exec it
            # (in production, use a sandboxed runner)
            namespace = {
                "params": params,
                "auth": {},
                "base_url": adapter.signature.base_url or "",
            }
            exec(adapter.code, namespace)
            result = await namespace[f"call_{adapter.signature.name.replace('-', '_')}"](
                params, {}
            )
            
            self.registry.record_call(sig.fingerprint(), True)
            return result
        except Exception as e:
            self.registry.record_call(sig.fingerprint(), False)
            return {
                "status": "error",
                "error_code": "ADAPTER_FAILED",
                "error_message": str(e),
            }

    async def adapt_protocol(self, name: str, source: str) -> Optional[str]:
        """Manually trigger adaptation of a protocol.
        
        Returns: adapter fingerprint if successful.
        """
        logger.info(f"Manually adapting protocol: {name} ({source})")
        
        # Probe the endpoint
        sig = AdapterSignature(
            name=name,
            version="1.0",
            source=source,
            first_seen=datetime.now(timezone.utc).isoformat(),
        )
        
        if self._probe_enabled and source.startswith("http"):
            analyzer = ProtocolAnalyzer(source)
            sig = await analyzer.analyze()
        
        # Generate adapter code
        try:
            code = self.generator.generate_adapter(sig)
        except Exception as e:
            logger.error(f"Failed to generate adapter for {name}: {e}")
            return None
        
        # Register
        fp = self.registry.register(sig, code)
        logger.info(f"Successfully adapted {name} → adapter {fp}")
        return fp

    async def _seed_well_known(self):
        """Seed adapters for well-known protocols."""
        for proto in self._well_known:
            try:
                # Quick scan — just register as known
                sig = AdapterSignature(
                    name=proto["name"],
                    version="1.0",
                    source=proto["source"],
                    first_seen=datetime.now(timezone.utc).isoformat(),
                )
                code = self.generator.generate_adapter(sig)
                self.registry.register(sig, code)
            except Exception as e:
                logger.debug(f"Failed to seed {proto['name']}: {e}")

    async def _adaptation_cycle(self):
        """One full cycle: scan → analyze → generate → register."""
        # Step 1: Scan for new protocols
        new_protocols = await self.scanner.scan_all()
        
        if not new_protocols:
            logger.debug("No new protocols found in this cycle")
            return
        
        logger.info(f"Found {len(new_protocols)} new protocols to analyze")
        
        # Step 2: Deep-analyze each new protocol
        for sig in new_protocols:
            if self._probe_enabled:
                try:
                    analyzer = ProtocolAnalyzer(sig.source)
                    sig = await analyzer.analyze()
                except Exception as e:
                    logger.debug(f"Deep analysis failed for {sig.name}: {e}")
            
            # Step 3: Generate adapter
            try:
                code = self.generator.generate_adapter(sig)
            except Exception as e:
                logger.warning(f"Failed to generate adapter for {sig.name}: {e}")
                continue
            
            # Step 4: Register
            if self._auto_deploy:
                fp = self.registry.register(sig, code)
                logger.info(f"Auto-adapted: {sig.name} v{sig.version} "
                          f"(transport={sig.transport_type}, "
                          f"capabilities={len(sig.capabilities)})")
        
        # Save state after each cycle
        self._save_state()

    def _save_state(self):
        """Save adapter state to disk."""
        try:
            state = {
                "adapters": self.registry.list_adapters(),
                "last_scan": datetime.now(timezone.utc).isoformat(),
            }
            os.makedirs(os.path.dirname(self.state_path) or ".", exist_ok=True)
            with open(self.state_path, "w") as f:
                json.dump(state, f, indent=2)
        except Exception as e:
            logger.debug(f"Failed to save state: {e}")

    def _load_state(self):
        """Load adapter state from disk."""
        try:
            if os.path.exists(self.state_path):
                with open(self.state_path) as f:
                    state = json.load(f)
                # Restore known protocols from previously discovered
                for fp, info in state.get("adapters", {}).items():
                    logger.debug(f"Restored adapter: {info.get('name', fp)}")
        except Exception as e:
            logger.debug(f"Failed to load state: {e}")

    @property
    def status(self) -> dict:
        """Current status of the evolutionary adapter."""
        return {
            "running": self._running,
            "adapters_registered": len(self.registry._adapters),
            "capabilities_indexed": len(self.registry._capability_index),
            "scan_interval_seconds": self._scan_interval,
            "probe_enabled": self._probe_enabled,
            "auto_deploy": self._auto_deploy,
        }
