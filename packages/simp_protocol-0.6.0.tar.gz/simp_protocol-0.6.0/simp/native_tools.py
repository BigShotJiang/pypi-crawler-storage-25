"""
Native Tools registry — SIMP's built-in tool definitions and the @native_tool decorator.
"""
from __future__ import annotations

import inspect
import logging
import threading
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, ClassVar, Dict, List, Optional, Set

logger = logging.getLogger("simp.native_tools")

NATIVE_TOOL_REGISTRIES: ClassVar[Dict[str, "NativeToolRegistry"]] = {}

_REGISTRY_LOCK = threading.RLock()


@dataclass
class ToolParameter:
    name: str
    type: str
    description: str = ""
    required: bool = True
    default: Any = None

    def to_json_schema_property(self) -> Dict[str, Any]:
        prop = {"type": self.type}
        if self.description:
            prop["description"] = self.description
        if self.default is not None:
            prop["default"] = self.default
        return prop


@dataclass
class ToolExample:
    input_args: Dict[str, Any] = field(default_factory=dict)
    output: Any = None


@dataclass
class SimpTool:
    name: str
    description: str
    input_schema: Dict[str, Any] = field(default_factory=dict)
    handler: Optional[Callable[..., Any]] = None
    parameters: List[ToolParameter] = field(default_factory=list)
    examples: List[ToolExample] = field(default_factory=list)
    intent_type: str = ""
    routing_hint: str = "auto"
    brp_sensitivity: str = "normal"
    cost_per_call: float = 0.0
    timeout_seconds: int = 30
    security_level: str = "signed"
    mesh_preferred: bool = False
    cache_ttl: int = 0

    @classmethod
    def from_function(
        cls,
        func: Callable[..., Any],
        name: str = "",
        description: str = "",
        intent_type: str = "",
    ) -> "SimpTool":
        sig = inspect.signature(func)
        params = []
        for pname, p in sig.parameters.items():
            ann = p.annotation.__name__ if hasattr(p.annotation, "__name__") else "Any"
            params.append(ToolParameter(
                name=pname,
                type=ann,
                required=(p.default is inspect.Parameter.empty),
                default=(p.default if p.default is not inspect.Parameter.empty else None),
            ))
        schema = {
            "type": "object",
            "properties": {p.name: p.to_json_schema_property() for p in params},
            "required": [p.name for p in params if p.required],
        }
        if not description:
            description = func.__doc__ or f"{name or func.__name__} tool"
        return cls(
            name=name or func.__name__,
            description=description,
            input_schema=schema,
            handler=func,
            parameters=params,
            intent_type=intent_type,
        )

    def simp_intent_type(self) -> str:
        return self.intent_type or f"native.{self.name}"

    def simp_routing_hint(self) -> str:
        return self.routing_hint

    def simp_brp_sensitivity(self) -> str:
        return self.brp_sensitivity

    def simp_cost_per_call(self) -> float:
        return self.cost_per_call

    def simp_timeout_seconds(self) -> int:
        return self.timeout_seconds

    def simp_security_level(self) -> str:
        return self.security_level

    def simp_mesh_preferred(self) -> bool:
        return self.mesh_preferred

    def simp_cache_ttl(self) -> int:
        return self.cache_ttl

    def to_native_descriptor(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
        }

    def to_mcp_list_item(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }

    def to_simp_metadata(self) -> Dict[str, Any]:
        return {
            "intent_type": self.simp_intent_type(),
            "routing_hint": self.simp_routing_hint(),
            "brp_sensitivity": self.simp_brp_sensitivity(),
            "cost_per_call_usd": self.simp_cost_per_call(),
            "timeout_seconds": self.simp_timeout_seconds(),
            "security_level": self.simp_security_level(),
            "mesh_preferred": self.simp_mesh_preferred(),
            "cache_ttl_seconds": self.simp_cache_ttl(),
        }

    def to_full_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["simp_metadata"] = self.to_simp_metadata()
        return d

    def __hash__(self) -> int:
        return hash(self.name)


class NativeToolRegistry:
    def __init__(self, agent_id: str):
        self._agent_id = agent_id
        self._tools: Dict[str, SimpTool] = {}
        self._execution_class = "native"

    def register(self, tool: SimpTool) -> None:
        self._tools[tool.name] = tool

    def register_many(self, tools: List[SimpTool]) -> None:
        for t in tools:
            self.register(t)

    def unregister(self, name: str) -> bool:
        return self._tools.pop(name, None) is not None

    def get_tool(self, name: str) -> Optional[SimpTool]:
        return self._tools.get(name)

    def list_tools(self) -> List[SimpTool]:
        return list(self._tools.values())

    def list_native_items(self) -> List[Dict[str, Any]]:
        return [t.to_native_descriptor() for t in self._tools.values()]

    def list_mcp_items(self) -> List[Dict[str, Any]]:
        return [t.to_mcp_list_item() for t in self._tools.values()]

    def tool_names(self) -> List[str]:
        return list(self._tools.keys())

    def invoke(self, name: str, **kwargs) -> Any:
        tool = self.get_tool(name)
        if not tool or not tool.handler:
            raise ValueError(f"No tool registered: {name}")
        return tool.handler(**kwargs)

    def call_tool(self, name: str, args: Dict[str, Any]) -> Any:
        return self.invoke(name, **args)

    @classmethod
    def get_registry(cls, agent_id: str) -> "NativeToolRegistry":
        with _REGISTRY_LOCK:
            if agent_id not in cls._registry_map:
                cls._registry_map[agent_id] = cls(agent_id)
            return cls._registry_map[agent_id]

    @classmethod
    def all_registries(cls) -> Dict[str, "NativeToolRegistry"]:
        with _REGISTRY_LOCK:
            return dict(cls._registry_map)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self._agent_id,
            "tool_count": len(self._tools),
            "execution_class": self._execution_class,
            "tools": {name: tool.to_full_dict() for name, tool in self._tools.items()},
        }


# Module-level singleton
native_tool_registry = NativeToolRegistry("global")


def native_tool(
    func: Callable[..., Any] | None = None,
    *,
    name: str = "",
    description: str = "",
    intent_type: str = "",
) -> Callable[..., Any]:
    """Decorator to register a function as a native SIMP tool."""
    def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
        tool = SimpTool.from_function(
            f,
            name=name or f.__name__,
            description=description or (f.__doc__ or ""),
            intent_type=intent_type,
        )
        native_tool_registry.register(tool)
        return f

    if func is None:
        return decorator
    return decorator(func)


def get_registry(agent_id: str) -> NativeToolRegistry:
    return NativeToolRegistry.get_registry(agent_id)


NATIVE_TOOL_REGISTRIES = {"global": native_tool_registry}
