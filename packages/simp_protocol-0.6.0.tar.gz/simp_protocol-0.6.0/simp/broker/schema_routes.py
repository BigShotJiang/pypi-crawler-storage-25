"""Schema routes shim — provides the schema_bp blueprint."""

from flask import Blueprint, jsonify

schema_bp = Blueprint("schema", __name__)


@schema_bp.route("/schema", methods=["GET"])
def get_schema():
    """Return the broker schema."""
    return jsonify({"schema_version": "1.0", "status": "ok"})


@schema_bp.route("/schema/health", methods=["GET"])
def schema_health():
    """Health check for schema service."""
    return jsonify({"status": "healthy"})


__all__ = ["schema_bp"]
