"""
IntentLogger — JSONL writer for broker intent routing outcomes.

Writes to ``~/.simp/logs/broker_intents.jsonl`` with fields:
    timestamp, intent_id, intent_type, target_agent, routed_to, latency_ms, success

Designed to be called by the broker on each routing decision so the
reflection pipeline can ingest routing outcomes for learning.
"""

from __future__ import annotations

import json
import logging
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger("SIMP.Broker.IntentLogger")


class IntentLogger:
    """
    Thread-safe JSONL appender for broker intent routing records.

    Usage::

        logger = IntentLogger()
        logger.log_intent(
            intent_id="abc-123",
            intent_type="trade_signal",
            target_agent="quantum-goose",
            routed_to="quantum-goose",
            latency_ms=4.2,
            success=True,
        )
    """

    def __init__(self, log_path: Optional[str] = None) -> None:
        """
        Args:
            log_path: Full path to the intents log file.
                      Defaults to ``~/.simp/logs/broker_intents.jsonl``.
        """
        if log_path is None:
            log_path = str(Path.home() / ".simp" / "logs" / "broker_intents.jsonl")
        self._log_path = Path(log_path)
        self._log_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def log_intent(
        self,
        intent_id: Optional[str] = None,
        intent_type: str = "",
        target_agent: str = "",
        routed_to: str = "",
        latency_ms: float = 0.0,
        success: bool = True,
        timestamp: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Append a routing outcome record to the intent log.

        Args:
            intent_id:   Unique intent identifier. Auto-generated if omitted.
            intent_type:  Type of intent (e.g. "trade_signal", "mesh_message").
            target_agent: Agent the intent was addressed to.
            routed_to:    Agent that actually received the intent.
            latency_ms:   Routing latency in milliseconds.
            success:      Whether routing succeeded.
            timestamp:    ISO-8600 timestamp string. Defaults to now (UTC).
            extra:        Additional fields to attach to the record.
        """
        if timestamp is None:
            timestamp = datetime.now(timezone.utc).isoformat()
        if intent_id is None:
            intent_id = str(uuid.uuid4())

        record: Dict[str, Any] = {
            "timestamp": timestamp,
            "intent_id": intent_id,
            "intent_type": intent_type,
            "target_agent": target_agent,
            "routed_to": routed_to,
            "latency_ms": latency_ms,
            "success": success,
        }
        if extra:
            record.update(extra)

        with self._lock:
            try:
                with open(self._log_path, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps(record, default=str) + "\n")
            except OSError as exc:
                logger.warning("IntentLogger: failed to write — %s", exc)