"""Per-agent rate limiter.

Thin wrapper over the token-bucket RateLimiter from simp.server.rate_limit.
Maps agent IDs to separate bucketed limits with global ceiling.
"""

import threading
import os
from typing import Optional

from simp.server.rate_limit import RateLimiter, TokenBucket


class PerAgentRateLimiter:
    """Rate limiter keyed by agent ID with global aggregate ceiling.

    Each agent has its own token bucket (per-minute limit).
    A global ceiling limits total broker-wide intent throughput.
    """

    def __init__(
        self,
        agent_limit: int = 60,
        global_limit: int = 10000,
        intent_limits: Optional[dict[str, int]] = None,
    ):
        self._per_agent_rate = float(
            os.environ.get("SIMP_PER_AGENT_RATE", str(agent_limit))
        )
        self._global_ceiling = int(
            os.environ.get("SIMP_GLOBAL_CEILING", str(global_limit))
        )
        self._intent_limits = intent_limits or {}

        self._lock = threading.Lock()
        self._agent_buckets: dict[str, TokenBucket] = {}
        self._global_bucket = TokenBucket(
            rate=self._global_ceiling / 60.0,
            capacity=self._global_ceiling,
        )

    def _bucket_for(self, agent_id: str) -> TokenBucket:
        if agent_id not in self._agent_buckets:
            self._agent_buckets[agent_id] = TokenBucket(
                rate=self._per_agent_rate / 60.0,
                capacity=self._per_agent_rate,
            )
        return self._agent_buckets[agent_id]

    def check(self, agent_id: str, tokens: int = 1) -> bool:
        """Check if agent is allowed. Returns True if within limits."""
        # Global ceiling first
        if not self._global_bucket.consume(tokens):
            return False
        # Per-agent limit
        with self._lock:
            bucket = self._bucket_for(agent_id)
        return bucket.consume(tokens)

    def limit_for_intent(self, agent_id: str) -> bool:
        """Check if agent can send an intent-type message."""
        return self.check(agent_id, tokens=1)

    def __repr__(self) -> str:
        return (
            f"<PerAgentRateLimiter "
            f"per_agent={self._per_agent_rate}/min "
            f"global_ceiling={self._global_ceiling}/min>"
        )


__all__ = ["PerAgentRateLimiter"]
