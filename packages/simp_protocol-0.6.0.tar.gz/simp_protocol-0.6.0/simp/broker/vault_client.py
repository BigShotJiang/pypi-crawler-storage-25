"""
T5 — HashiCorp Vault client re-export.

Provides a VaultClient for secrets management, delegating to the
security organ's implementation at simp/organs/security/vault_client.py.
"""

from simp.organs.security.vault_client import VaultClient  # noqa: F401

__all__ = ["VaultClient"]
