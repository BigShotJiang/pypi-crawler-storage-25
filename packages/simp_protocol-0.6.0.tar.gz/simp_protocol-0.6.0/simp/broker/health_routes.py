"""
SIMP Health Endpoints — T10-10 / T39

GET /health             — liveness: is the broker process alive?
GET /health?full=true   — full dependency health check (DB, disk, memory, gRPC, WS)
GET /ready              — readiness: can the broker route? (DB + TLS + mesh OK)
GET /live               — Kubernetes liveness probe (same as /health)

Response includes:
  uptime_seconds, active_agents, intent_throughput_1m, tls_version,
  schema_count, circuit_breaker_states, timestamp
"""

import os
import shutil
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from flask import Blueprint, jsonify, request

health_bp = Blueprint("health", __name__, url_prefix="/health")

# Module-level broker ref registry (avoids Blueprint method issue)
_broker_ref: object = None
_start_time = datetime.now(timezone.utc)


def set_harness_ref(harness):
    """Set the harness reference for health checks.

    Called during broker startup to wire in the RecursiveHarness instance.
    """
    global _recursive_harness_ref
    _recursive_harness_ref = harness


_recursive_harness_ref: object = None


def set_broker_ref(broker):
    global _broker_ref
    global _start_time
    _broker_ref = broker
    _start_time = datetime.now(timezone.utc)


def uptime_seconds() -> float:
    delta = datetime.now(timezone.utc) - _start_time
    return delta.total_seconds()


def get_active_agents() -> int:
    if _broker_ref and hasattr(_broker_ref, "agent_registry"):
        try:
            return len(_broker_ref.agent_registry.list_agents())
        except Exception:
            pass
    return 0


def get_intent_throughput() -> float:
    """Intents per second over the last minute (placeholder — hook into structured logging)."""
    return 0.0


# ---------------------------------------------------------------------------
# T39 — HealthChecker
# ---------------------------------------------------------------------------

class HealthChecker:
    """Performs dependency checks for the broker's /health?full=true endpoint.

    Checks performed:
        1. Database connection  — if ``SIMP_DB_URL`` is set
        2. Disk space           — warns if < 10 % free
        3. Memory usage         — warns if > 90 % used
        4. gRPC server          — if the broker has a gRPC server running
        5. WS bridge            — if the broker has a WebSocket bridge running
    """

    def __init__(self, broker_ref: Optional[object] = None):
        self._broker = broker_ref

    def check_all(self) -> Dict[str, Any]:
        """Run all checks and return a dict of results."""
        return {
            "database": self._check_database(),
            "disk": self._check_disk(),
            "memory": self._check_memory(),
            "grpc": self._check_grpc(),
            "ws_bridge": self._check_ws_bridge(),
        }

    def _check_database(self) -> Dict[str, Any]:
        """Check database connectivity — Postgres, SQLite, or YAML config."""
        db_url = os.environ.get("SIMP_DB_URL", "").strip()
        db_config_path = os.environ.get("SIMP_DB_CONFIG", os.path.expanduser("~/.simp/config/database.yaml")).strip()

        # Try Postgres via config file
        if os.path.exists(db_config_path):
            try:
                import yaml
                with open(db_config_path) as f:
                    cfg = yaml.safe_load(f) or {}
                if cfg.get("backend") == "postgres":
                    import psycopg2
                    password = os.environ.get("SIMP_DB_PASSWORD", "")
                    if cfg.get("password", "").startswith("${") and cfg["password"].endswith("}"):
                        env_var = cfg["password"][2:-1]
                        password = os.environ.get(env_var, "")
                    conn = psycopg2.connect(
                        host=cfg.get("host", "localhost"),
                        port=cfg.get("port", 5432),
                        user=cfg.get("user", "simp"),
                        password=password,
                        dbname=cfg.get("database", "simp"),
                        connect_timeout=3,
                    )
                    cur = conn.cursor()
                    cur.execute("SELECT 1")
                    cur.fetchone()
                    conn.close()
                    return {"status": "ok", "detail": f"PostgreSQL {cfg.get('database')} connection successful"}
            except Exception as e:
                return {"status": "error", "detail": f"Postgres: {e}"}

        # Fallback to SIMP_DB_URL
        if db_url:
            try:
                import sqlite3
                if db_url.startswith("sqlite:///"):
                    path = db_url[len("sqlite:///"):]
                    conn = sqlite3.connect(path, timeout=2.0)
                    cursor = conn.cursor()
                    cursor.execute("SELECT 1")
                    cursor.fetchone()
                    conn.close()
                    return {"status": "ok", "detail": "sqlite connection successful"}
                return {"status": "warn", "detail": f"Unsupported scheme: {db_url.split(':')[0]}"}
            except Exception as e:
                return {"status": "error", "detail": str(e)}

        return {"status": "skipped", "detail": "No database configured"}

    def _check_disk(self) -> Dict[str, Any]:
        """Check disk space availability. Warns if < 10 % free."""
        try:
            usage = shutil.disk_usage("/")
            free_pct = usage.free / usage.total * 100
            used_pct = usage.used / usage.total * 100
            status = "ok" if free_pct >= 10 else "warn"
            return {
                "status": status,
                "free_pct": round(free_pct, 1),
                "used_pct": round(used_pct, 1),
                "total_gb": round(usage.total / (1024 ** 3), 1),
                "free_gb": round(usage.free / (1024 ** 3), 1),
            }
        except Exception as e:
            return {"status": "error", "detail": str(e)}

    def _check_memory(self) -> Dict[str, Any]:
        """Check system memory usage. Warns if > 90 % used."""
        try:
            import psutil
            mem = psutil.virtual_memory()
            used_pct = mem.percent
            status = "ok" if used_pct <= 90 else "warn"
            return {
                "status": status,
                "used_pct": used_pct,
                "total_gb": round(mem.total / (1024 ** 3), 1),
                "available_gb": round(mem.available / (1024 ** 3), 1),
            }
        except ImportError:
            # Fallback: read from /proc/meminfo on Linux
            try:
                with open("/proc/meminfo") as f:
                    data = f.read()
                lines = data.strip().splitlines()
                mem_total = None
                mem_available = None
                for line in lines:
                    if line.startswith("MemTotal:"):
                        mem_total = int(line.split()[1])
                    elif line.startswith("MemAvailable:"):
                        mem_available = int(line.split()[1])
                if mem_total and mem_available:
                    used_pct = (mem_total - mem_available) / mem_total * 100
                    status = "ok" if used_pct <= 90 else "warn"
                    return {
                        "status": status,
                        "used_pct": round(used_pct, 1),
                        "total_gb": round(mem_total * 1024 / (1024 ** 3), 1),
                        "available_gb": round(mem_available * 1024 / (1024 ** 3), 1),
                    }
                return {"status": "warn", "detail": "meminfo fields incomplete"}
            except Exception as e:
                return {"status": "warn", "detail": f"Memory check unavailable: {e}"}
        except Exception as e:
            return {"status": "error", "detail": str(e)}

    def _check_grpc(self) -> Dict[str, Any]:
        """Check if gRPC server is running (via broker attribute)."""
        if self._broker is None:
            return {"status": "skipped", "detail": "no broker reference"}
        grpc_server = getattr(self._broker, "_grpc_server", None)
        if grpc_server is None:
            return {"status": "not_running", "detail": "gRPC server not initialized"}
        try:
            is_active = grpc_server.is_active() if hasattr(grpc_server, "is_active") else True
            return {
                "status": "ok" if is_active else "not_running",
                "detail": "gRPC server is running" if is_active else "gRPC server is not active",
            }
        except Exception as e:
            return {"status": "error", "detail": str(e)}

    def _check_ws_bridge(self) -> Dict[str, Any]:
        """Check if WebSocket bridge is running (via broker attribute)."""
        if self._broker is None:
            return {"status": "skipped", "detail": "no broker reference"}
        ws_bridge = getattr(self._broker, "ws_bridge", None)
        if ws_bridge is None:
            return {"status": "not_running", "detail": "WS bridge not initialized"}
        try:
            is_alive = ws_bridge.is_alive() if hasattr(ws_bridge, "is_alive") else True
            return {
                "status": "ok" if is_alive else "not_running",
                "detail": "WS bridge is running" if is_alive else "WS bridge thread is not alive",
            }
        except Exception as e:
            return {"status": "error", "detail": str(e)}


# Singleton health checker lazily created once broker_ref is set
_health_checker: Optional[HealthChecker] = None


def get_health_checker() -> HealthChecker:
    global _health_checker
    if _health_checker is None:
        _health_checker = HealthChecker(broker_ref=_broker_ref)
    return _health_checker


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@health_bp.route("/health", methods=["GET"])
def health():
    """Liveness probe — is the process alive? Use ?full=true for dependency checks."""
    result = {
        "status": "alive",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "uptime_seconds": round(uptime_seconds(), 2),
    }

    # T39 — Full dependency checks when ?full=true
    if request.args.get("full", "").lower() in ("true", "1", "yes"):
        checker = get_health_checker()
        result["checks"] = checker.check_all()

    return jsonify(result)


@health_bp.route("/live", methods=["GET"])
def live():
    """Kubernetes liveness probe."""
    return health()


@health_bp.route("/ready", methods=["GET"])
def ready():
    """Readiness probe — can the broker route?"""
    checks = {}
    overall = "ready"

    # TLS check: can we build an SSL context?
    try:
        from simp.crypto.tls_manager import get_tls_manager
        mgr = get_tls_manager()
        cert = mgr.get_current()
        checks["tls"] = {
            "status": "ok",
            "cert_serial": cert.serial,
            "not_after": cert.not_after,
        }
    except Exception as e:
        checks["tls"] = {"status": "error", "detail": str(e)}
        overall = "not_ready"

    # Schema registry check
    try:
        from simp.broker.schema_registry import get_schema_registry
        registry = get_schema_registry()
        schema_count = len(registry.list_types())
        checks["schemas"] = {"status": "ok", "count": schema_count}
    except Exception as e:
        checks["schemas"] = {"status": "error", "detail": str(e)}

    # Circuit breakers
    try:
        from simp.server.circuit_breaker import CircuitBreakerRegistry
        # This is a global registry
        checks["circuit_breakers"] = {"status": "ok", "note": "use GET /circuit-breakers for details"}
    except Exception as e:
        checks["circuit_breakers"] = {"status": "error", "detail": str(e)}

    # Agent count
    checks["agents"] = {
        "status": "ok",
        "active": get_active_agents(),
    }

    # T39 — Include health dependency checks in readiness probe
    checker = get_health_checker()
    dep_checks = checker.check_all()
    checks["dependencies"] = dep_checks

    # Check if any dependency is in error state
    for dep_name, dep_result in dep_checks.items():
        if dep_result.get("status") == "error":
            overall = "not_ready"
            break

    return jsonify({
        "status": overall,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "uptime_seconds": round(uptime_seconds(), 2),
        "active_agents": get_active_agents(),
        "intent_throughput_1m": get_intent_throughput(),
        "schema_count": checks.get("schemas", {}).get("count", 0),
        "tls_version": "TLS 1.3",
        "checks": checks,
    }), 200 if overall == "ready" else 503


@health_bp.route("/circuit-breakers", methods=["GET"])
def circuit_breaker_status():
    """Get status of all circuit breakers."""
    try:
        from simp.server.circuit_breaker import CircuitBreakerRegistry
        # Try to get from broker if available
        registry = getattr(_broker_ref, "_circuit_breakers", None) if _broker_ref else None
        if registry is None:
            return jsonify({
                "status": "no_circuit_breakers",
                "message": "CircuitBreakerRegistry not yet initialized on broker",
            })
        snapshots = registry.get_all_snapshots()
        return jsonify({
            "circuit_breakers": {
                aid: {
                    "state": s.state.value,
                    "total_requests": s.total_requests,
                    "error_count": s.error_count,
                    "error_rate": round(s.error_rate, 3),
                    "last_error": s.last_error,
                    "opened_at": s.opened_at,
                }
                for aid, s in snapshots.items()
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
