"""Telemetry manager — lightweight in-process observability hub."""

import logging
import threading
import time
from typing import Any

logger = logging.getLogger("simp.telemetry")


class TelemetryManager:
    """Collects and exposes broker telemetry.

    Wires into the /metrics endpoint to provide structured telemetry data.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._counters: dict[str, int] = {}
        self._started_at = time.time()

    def increment(self, metric: str, value: int = 1) -> None:
        with self._lock:
            self._counters[metric] = self._counters.get(metric, 0) + value

    def set(self, metric: str, value: Any) -> None:
        with self._lock:
            self._counters[metric] = value

    def get(self, metric: str, default: Any = 0) -> Any:
        with self._lock:
            return self._counters.get(metric, default)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._counters)

    def metrics_text(self) -> str:
        """Return telemetry as Prometheus-style text."""
        lines = [
            "# HELP simp_telemetry Broker telemetry counters",
            "# TYPE simp_telemetry untyped",
        ]
        for key, val in sorted(self.snapshot().items()):
            lines.append(f'simp_telemetry{{metric="{key}"}} {val}')
        lines.append(f"simp_uptime_seconds {time.time() - self._started_at:.0f}")
        return "\n".join(lines) + "\n"

    def __repr__(self) -> str:
        return f"<TelemetryManager counters={len(self._counters)}>"


__all__ = ["TelemetryManager"]
