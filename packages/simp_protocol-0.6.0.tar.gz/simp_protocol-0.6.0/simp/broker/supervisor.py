"""
SIMP Broker Supervisor — Self-Supervision Without External Dependencies

This module implements what PM2 would do, but as a native Python component
of the SIMP broker. The supervisor runs as a daemon thread within the broker
process and provides:

  1. Process health monitoring — periodic self-checks against /health
  2. Automatic restart on hard crash — via a watchdog parent process
  3. Graceful code reload — hot-reload routes without dropping connections
  4. Resource monitoring — memory, CPU, file descriptor tracking
  5. Metrics export — Prometheus-format, no separate metrics server needed
  6. Upgrade orchestration — staged rollout of new broker versions

Architecture:
    ┌─────────────────────────────────────────┐
    │  Watchdog (parent process)              │
    │  - Launches broker as subprocess        │
    │  - Restarts if broker exits abnormally  │
    │  - Can hot-swap broker binary on restart │
    └────────────┬────────────────────────────┘
                 │ subprocess.Popen
    ┌────────────▼────────────────────────────┐
    │  Broker (child process)                 │
    │  ┌──────────────────────────────────┐   │
    │  │ Supervisor (daemon thread)       │   │
    │  │ - /health polling every 15s      │   │
    │  │ - Memory/CPU tracking            │   │
    │  │ - Metrics endpoint feed          │   │
    │  │ - Signals on resource thresholds │   │
    │  └──────────────────────────────────┘   │
    │  ┌──────────────────────────────────┐   │
    │  │ Hot-Reload Manager               │   │
    │  │ - Reload route blueprints        │   │
    │  │ - Reload crypto keys             │   │
    │  │ - Reload config without restart  │   │
    │  └──────────────────────────────────┘   │
    └─────────────────────────────────────────┘

Usage:
    # Start with integrated watchdog:
    python -m simp start --watchdog

    # Start broker alone (for PM2, systemd, or container orchestration):
    python -m simp start

    # Reload config without restart:
    curl -X POST http://localhost:5555/admin/reload
"""

import os
import sys
import time
import json
import signal
import threading
import subprocess
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Optional, Callable

logger = logging.getLogger("simp.supervisor")

# ─── Configuration ──────────────────────────────────────────────────────────

@dataclass
class SupervisorConfig:
    """Configuration for the SIMP supervisor subsystem.

    All values sourced from environment variables with sensible defaults.
    """
    # Health check polling
    health_interval_s: float = float(os.environ.get("SIMP_SUPERVISOR_HEALTH_INTERVAL", "5.0"))
    health_endpoint: str = os.environ.get("SIMP_SUPERVISOR_HEALTH_URL", "http://127.0.0.1:5555/health")

    # Resource thresholds
    max_memory_mb: int = int(os.environ.get("SIMP_SUPERVISOR_MAX_MEMORY_MB", "512"))
    max_cpu_percent: float = float(os.environ.get("SIMP_SUPERVISOR_MAX_CPU_PERCENT", "80.0"))
    max_fd_count: int = int(os.environ.get("SIMP_SUPERVISOR_MAX_FD_COUNT", "1024"))

    # Auto-healing
    max_consecutive_failures: int = int(os.environ.get("SIMP_SUPERVISOR_MAX_FAILURES", "3"))
    restart_delay_s: float = float(os.environ.get("SIMP_SUPERVISOR_RESTART_DELAY", "2.0"))

    # Watchdog (parent process)
    enable_watchdog: bool = os.environ.get("SIMP_SUPERVISOR_WATCHDOG", "false").lower() in ("1", "true")
    watchdog_max_restarts: int = int(os.environ.get("SIMP_SUPERVISOR_MAX_RESTARTS", "5"))
    watchdog_restart_window_s: float = float(os.environ.get("SIMP_SUPERVISOR_RESTART_WINDOW", "60.0"))

    # Upgrade
    upgrade_binary_path: str = os.environ.get("SIMP_SUPERVISOR_UPGRADE_PATH", "")

    # Heartbeat file (for external monitoring like systemd)
    heartbeat_file: str = os.environ.get("SIMP_SUPERVISOR_HEARTBEAT", "/tmp/simp_heartbeat")


# ─── Watchdog Parent Process ────────────────────────────────────────────────

def run_watchdog(config: Optional[SupervisorConfig] = None) -> None:
    """Run as a watchdog parent process that launches and supervises the broker.

    The watchdog:
    - Launches the broker as a child subprocess
    - Monitors its exit code
    - Restarts on abnormal exit (up to max_restarts in the window)
    - Can hot-swap the binary on restart for zero-downtime upgrades

    This is the entry point for `simp start --watchdog`.
    """
    if config is None:
        config = SupervisorConfig()

    broker_args = sys.argv[1:] if "--watchdog" in sys.argv else []
    # Strip watchdog flag to avoid recursive watchdog launch
    broker_args = [a for a in broker_args if a != "--watchdog" and a != "--watchdog=true"]

    restarts = []
    restart_count = 0

    logger.info("🐍 SIMP Watchdog starting — supervising broker process")
    logger.info("  Max restarts: %d in %.0fs window",
                config.watchdog_max_restarts, config.watchdog_restart_window_s)

    while True:
        now = time.time()
        # Prune old restarts from the window
        restarts = [t for t in restarts if now - t < config.watchdog_restart_window_s]

        if len(restarts) >= config.watchdog_max_restarts:
            logger.critical(
                "Watchdog: %d restarts in %.0fs exceeds limit (%d). Giving up.",
                len(restarts), config.watchdog_restart_window_s,
                config.watchdog_max_restarts
            )
            sys.exit(1)

        # If there's an upgrade binary, swap it in
        broker_cmd = [sys.executable, "-m", "simp"] + broker_args
        if config.upgrade_binary_path:
            upgrade_path = Path(config.upgrade_binary_path)
            if upgrade_path.exists():
                logger.info("📦 Upgrading broker binary: %s", upgrade_path)
                broker_cmd = [str(upgrade_path)] + broker_args
                config.upgrade_binary_path = ""  # one-shot upgrade
            else:
                logger.warning("Upgrade binary not found: %s", upgrade_path)

        logger.info("Watchdog: launching broker: %s", " ".join(broker_cmd))

        try:
            proc = subprocess.Popen(
                broker_cmd,
                stdout=sys.stdout,
                stderr=sys.stderr,
                env=os.environ,
            )
            exit_code = proc.wait()
        except FileNotFoundError as e:
            logger.critical("Watchdog: broker binary not found: %s", e)
            sys.exit(1)
        except KeyboardInterrupt:
            logger.info("Watchdog: received SIGINT, shutting down broker...")
            if proc:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
            sys.exit(0)

        if exit_code == 0:
            logger.info("✅ Broker exited cleanly (code 0). Watchdog shutting down.")
            sys.exit(0)
        elif exit_code == 78:
            # EX_CONFIG — signal to watchdog to upgrade and restart
            logger.info("🔄 Broker requested upgrade. Restarting with new binary...")
            restarts.append(time.time())
            restart_count += 1
            time.sleep(config.restart_delay_s)
            continue
        else:
            logger.warning(
                "⚠️ Broker exited with code %d. Restarting in %.1fs... (restart #%d)",
                exit_code, config.restart_delay_s, restart_count + 1
            )
            restarts.append(time.time())
            restart_count += 1
            time.sleep(config.restart_delay_s)


# ─── Supervisor Daemon Thread ───────────────────────────────────────────────

class SupervisorDaemon:
    # L2-T5: Crash circuit-break constants
    MAX_CRASHES = 5
    CRASH_WINDOW = 60  # seconds
    CIRCUIT_BREAK_WAIT = 300  # 5 min before attempting restart again

    """In-process supervisor daemon that monitors broker health and resources.

    Runs as a daemon thread inside the broker process. It:
    - Polls the /health endpoint
    - Tracks memory, CPU, and file descriptor usage
    - Fires callbacks when thresholds are breached
    - Writes a heartbeat file for external process managers (systemd, Docker)
    - Exposes metrics in Prometheus format
    - L2-T4: Runs the harness alive-check loop to detect dead agents and stuck items

    The alive-check loop is the critical path for Level 2 resilience — it
    periodically calls `harness.run_alive_check()` with an agent-check function
    that verifies each assigned agent is still responsive. Items whose agents
    fail 3 consecutive checks are escalated to STUCK status.
    """

    def __init__(
        self,
        config: Optional[SupervisorConfig] = None,
        health_check_fn: Optional[Callable[[], dict]] = None,
        on_degraded: Optional[Callable[[str], None]] = None,
        on_critical: Optional[Callable[[str], None]] = None,
        harness: Optional[Any] = None,
        agent_check_fn: Optional[Callable[[str], bool]] = None,
    ):
        self.config = config or SupervisorConfig()
        self._health_check_fn = health_check_fn
        self._on_degraded = on_degraded
        self._on_critical = on_critical

        # L2-T4: Harness alive-check wiring
        self._harness = harness
        self._agent_check_fn = agent_check_fn

        # State tracking
        self._consecutive_failures = 0
        self._last_heartbeat = 0.0
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        # L2-T5: Crash circuit-break — track crash timestamps
        self._crash_timestamps: list[float] = []
        self._circuit_broken = False
        self._circuit_break_until = 0.0

        # L2-T9: Deadlock timer thread (separate from health loop)
        self._deadlock_thread: Optional[threading.Thread] = None
        self._deadlock_interval = 30.0  # check every 30s

        # Metrics (expanded for L2-T4 alive-check tracking)
        self._metrics: dict = {
            "supervisor_health_checks_total": 0,
            "supervisor_health_failures_total": 0,
            "supervisor_restarts_total": 0,
            "supervisor_memory_mb": 0.0,
            "supervisor_cpu_percent": 0.0,
            "supervisor_fd_count": 0,
            "supervisor_uptime_seconds": 0.0,
            "supervisor_degraded_events": 0,
            "supervisor_critical_events": 0,
            # L2-T4 alive-check metrics
            "supervisor_alive_checks_total": 0,
            "supervisor_alive_checks_passed": 0,
            "supervisor_alive_checks_failed": 0,
            "supervisor_alive_escalated_total": 0,
            "supervisor_alive_check_level": 0,
            "supervisor_stuck_items_total": 0,
        }
        self._start_time = 0.0

    # ── Resource introspection ───────────────────────────────────────────

    @staticmethod
    def _get_memory_mb() -> float:
        """Get current RSS memory usage in MB (cross-platform)."""
        try:
            import resource
            usage = resource.getrusage(resource.RUSAGE_SELF)
            # On macOS, ru_maxrss is in bytes; on Linux, in KB
            if sys.platform == "darwin":
                return usage.ru_maxrss / (1024 * 1024)
            return usage.ru_maxrss / 1024
        except (ImportError, AttributeError):
            return 0.0

    @staticmethod
    def _get_fd_count() -> int:
        """Count open file descriptors (Unix only)."""
        try:
            proc_fd = Path(f"/proc/{os.getpid()}/fd")
            if proc_fd.exists():
                return len(list(proc_fd.iterdir()))
            # macOS fallback: count from lsof (expensive, cache)
            return 0
        except (OSError, PermissionError):
            return 0

    @staticmethod
    def _get_cpu_percent() -> float:
        """Get approximate CPU usage since last call (Unix)."""
        try:
            import resource
            usage = resource.getrusage(resource.RUSAGE_SELF)
            # Sum user + system time, convert to percentage of wall time
            cpu_time = usage.ru_utime + usage.ru_stime
            # Rough estimate — real CPU % requires wall-clock delta
            return cpu_time * 100  # simplified
        except (ImportError, AttributeError):
            return 0.0

    # ── Heartbeat ────────────────────────────────────────────────────────

    def _write_heartbeat(self) -> None:
        """Write a heartbeat file with current broker status."""
        try:
            data = {
                "pid": os.getpid(),
                "timestamp": time.time(),
                "status": "healthy" if self._consecutive_failures == 0 else "degraded",
                "memory_mb": round(self._metrics["supervisor_memory_mb"], 1),
                "uptime_seconds": round(time.time() - self._start_time),
            }
            Path(self.config.heartbeat_file).write_text(json.dumps(data) + "\n")
            self._last_heartbeat = time.time()
        except (OSError, PermissionError) as e:
            logger.debug("Failed to write heartbeat: %s", e)

    # ── Health check ─────────────────────────────────────────────────────

    def _run_health_check(self) -> dict:
        """Run a health check and return a status dict.

        Uses the injected health_check_fn if available (in-process),
        otherwise falls back to HTTP polling of the health endpoint.
        """
        if self._health_check_fn:
            return self._health_check_fn()
        return {"status": "unknown", "reason": "no health_check_fn configured"}

    # ── Metrics ──────────────────────────────────────────────────────────

    def get_prometheus_text(self) -> str:
        """Return supervisor metrics in Prometheus exposition format."""
        lines = [
            "# HELP supervisor_health_checks_total Total health checks performed",
            "# TYPE supervisor_health_checks_total counter",
            f"supervisor_health_checks_total {self._metrics['supervisor_health_checks_total']}",
            "# HELP supervisor_health_failures_total Total health check failures",
            "# TYPE supervisor_health_failures_total counter",
            f"supervisor_health_failures_total {self._metrics['supervisor_health_failures_total']}",
            "# HELP supervisor_memory_mb Current RSS memory in MB",
            "# TYPE supervisor_memory_mb gauge",
            f"supervisor_memory_mb {self._metrics['supervisor_memory_mb']:.1f}",
            "# HELP supervisor_cpu_percent Current CPU usage (approx)",
            "# TYPE supervisor_cpu_percent gauge",
            f"supervisor_cpu_percent {self._metrics.get('cpu_percent', 0.0):.1f}",
            "# HELP supervisor_fd_count Current open file descriptors",
            "# TYPE supervisor_fd_count gauge",
            f"supervisor_fd_count {self._metrics['supervisor_fd_count']}",
            "# HELP supervisor_uptime_seconds Seconds since supervisor started",
            "# TYPE supervisor_uptime_seconds gauge",
            f"supervisor_uptime_seconds {self._metrics['supervisor_uptime_seconds']:.0f}",
            "# HELP supervisor_degraded_events Total degraded health events",
            "# TYPE supervisor_degraded_events counter",
            f"supervisor_degraded_events {self._metrics['supervisor_degraded_events']}",
            "# HELP supervisor_critical_events Total critical health events",
            "# TYPE supervisor_critical_events counter",
            f"supervisor_critical_events {self._metrics['supervisor_critical_events']}",
            # L2-T4 alive-check metrics
            "# HELP supervisor_alive_checks_total Total harness alive-checks performed",
            "# TYPE supervisor_alive_checks_total counter",
            f"supervisor_alive_checks_total {self._metrics['supervisor_alive_checks_total']}",
            "# HELP supervisor_alive_checks_passed Alive-checks where no items escalated",
            "# TYPE supervisor_alive_checks_passed counter",
            f"supervisor_alive_checks_passed {self._metrics['supervisor_alive_checks_passed']}",
            "# HELP supervisor_alive_checks_failed Alive-checks where items escalated",
            "# TYPE supervisor_alive_checks_failed counter",
            f"supervisor_alive_checks_failed {self._metrics['supervisor_alive_checks_failed']}",
            "# HELP supervisor_alive_escalated_total Total items escalated to STUCK",
            "# TYPE supervisor_alive_escalated_total counter",
            f"supervisor_alive_escalated_total {self._metrics['supervisor_alive_escalated_total']}",
            "# HELP supervisor_alive_check_level Current level being alive-checked",
            "# TYPE supervisor_alive_check_level gauge",
            f"supervisor_alive_check_level {self._metrics['supervisor_alive_check_level']}",
            "# HELP supervisor_stuck_items_total Current stuck item count",
            "# TYPE supervisor_stuck_items_total gauge",
            f"supervisor_stuck_items_total {self._metrics['supervisor_stuck_items_total']}",
            # L2-T5 crash circuit-break metrics
            "# HELP supervisor_crash_count Total broker crashes in current window",
            "# TYPE supervisor_crash_count gauge",
            f"supervisor_crash_count {len(self._crash_timestamps)}",
            "# HELP supervisor_circuit_broken Whether circuit-break is active (1=yes, 0=no)",
            "# TYPE supervisor_circuit_broken gauge",
            f"supervisor_circuit_broken {1 if self._circuit_broken else 0}",
        ]
        return "\n".join(lines) + "\n"

    # ── Alive-check (L2-T4) ──────────────────────────────────────────────

    def _run_alive_check(self) -> list[dict]:
        """Run the harness alive-check loop.

        Calls `harness.run_alive_check()` with the configured agent_check_fn
        for the current active level. Items whose agents fail 3 consecutive
        alive-checks are escalated to STUCK status.

        Returns a list of escalated item dicts (empty if none escalated).
        """
        if not self._harness or not self._agent_check_fn:
            return []

        level = self._harness.current_level
        if not level:
            return []

        try:
            self._metrics["supervisor_alive_checks_total"] += 1
            self._metrics["supervisor_alive_check_level"] = level.number
            self._metrics["supervisor_stuck_items_total"] = len(self._harness.deadlocked_items())

            escalated = self._harness.run_alive_check(
                level_num=level.number,
                agent_check=self._agent_check_fn,
            )

            if escalated:
                self._metrics["supervisor_alive_escalated_total"] += len(escalated)
                self._metrics["supervisor_alive_checks_failed"] += len(escalated)
                for item in escalated:
                    logger.warning(
                        "🔴 L2-T4 alive-check: item %s (%s) escalated to STUCK "
                        "(agent %s unresponsive after 3 checks)",
                        item.id, item.title, item.assigned_to,
                    )
            else:
                self._metrics["supervisor_alive_checks_passed"] += 1

            return [item.to_dict() for item in escalated]

        except Exception as e:
            logger.exception("L2-T4 alive-check loop error: %s", e)
            self._metrics["supervisor_alive_checks_failed"] += 1
            return []

    # ── Main loop ────────────────────────────────────────────────────────

    def _loop(self) -> None:
        """Main supervisor monitoring loop."""
        self._start_time = time.time()
        logger.info(
            "Supervisor daemon started (interval=%.1fs, max_mem=%dMB, max_cpu=%.0f%%)",
            self.config.health_interval_s,
            self.config.max_memory_mb,
            self.config.max_cpu_percent,
        )

        while self._running:
            try:
                # 1. Run health check
                self._metrics["supervisor_health_checks_total"] += 1
                health = self._run_health_check()

                if health.get("status") == "healthy":
                    self._consecutive_failures = 0
                else:
                    self._metrics["supervisor_health_failures_total"] += 1
                    self._consecutive_failures += 1

                    if self._consecutive_failures >= self.config.max_consecutive_failures:
                        self._metrics["supervisor_critical_events"] += 1
                        msg = (
                            f"Supervisor: {self._consecutive_failures} consecutive "
                            f"health failures. Triggering critical callback."
                        )
                        logger.warning(msg)
                        if self._on_critical:
                            self._on_critical(msg)

                # 2. Sample resources
                self._metrics["supervisor_memory_mb"] = self._get_memory_mb()
                self._metrics["supervisor_fd_count"] = self._get_fd_count()
                self._metrics["supervisor_uptime_seconds"] = time.time() - self._start_time

                # 3. Check resource thresholds
                mem = self._metrics["supervisor_memory_mb"]
                if mem > self.config.max_memory_mb:
                    self._metrics["supervisor_degraded_events"] += 1
                    msg = f"Supervisor: memory {mem:.0f}MB exceeds threshold {self.config.max_memory_mb}MB"
                    logger.warning(msg)
                    if self._on_degraded:
                        self._on_degraded(msg)

                # 4. L2-T4: Run harness alive-check loop
                # This is the critical path — it detects dead agents and
                # escalates stuck items. Runs every cycle alongside health checks.
                self._run_alive_check()

                # 5. Write heartbeat
                self._write_heartbeat()

            except Exception as e:
                logger.exception("Supervisor loop error: %s", e)
                self._consecutive_failures += 1

            # Sleep until next cycle
            time.sleep(self.config.health_interval_s)

    # ── Lifecycle ────────────────────────────────────────────────────────

    def start(self) -> None:
        """Start the supervisor daemon thread."""
        if self._thread and self._thread.is_alive():
            logger.warning("Supervisor already running")
            return

        self._running = True
        self._thread = threading.Thread(
            target=self._loop,
            daemon=True,
            name="simp-supervisor",
        )
        self._thread.start()
        # L2-T9: Start the deadlock monitor alongside the health-loop
        self.start_deadlock_monitor()
        logger.info("Supervisor daemon thread started")

    def stop(self) -> None:
        """Signal the supervisor to stop."""
        self._running = False
        logger.info("Supervisor daemon stopping")

    # ── L2-T5: Crash circuit-break ──────────────────────────────────────

    def record_crash(self) -> None:
        """Record a broker crash for circuit-break detection.

        If >MAX_CRASHES crashes occur within CRASH_WINDOW seconds,
        the circuit breaks and no restart attempts are made for
        CIRCUIT_BREAK_WAIT seconds.
        """
        now = time.time()
        self._crash_timestamps.append(now)
        # Prune timestamps outside the window
        self._crash_timestamps = [t for t in self._crash_timestamps if now - t <= self.CRASH_WINDOW]

        crash_count = len(self._crash_timestamps)
        logger.warning(
            "💥 Broker crash #%d in last %ds (threshold: %d in %ds)",
            crash_count, int(now - self._crash_timestamps[0]) if self._crash_timestamps else 0,
            self.MAX_CRASHES, self.CRASH_WINDOW,
        )

        if crash_count >= self.MAX_CRASHES:
            self._circuit_broken = True
            self._circuit_break_until = now + self.CIRCUIT_BREAK_WAIT
            logger.critical(
                "🔴 CIRCUIT BREAK: Broker crashed %d times in %ds. "
                "No restart attempts until %.1f (%ds from now).",
                crash_count, self.CRASH_WINDOW,
                self._circuit_break_until, self.CIRCUIT_BREAK_WAIT,
            )

    def can_attempt_restart(self) -> bool:
        """Check if a restart is allowed (circuit-break check).

        Returns:
            True if restart is allowed, False if circuit is broken.
        """
        if not self._circuit_broken:
            return True
        if time.time() >= self._circuit_break_until:
            self._circuit_broken = False
            self._crash_timestamps = []
            logger.info("🔵 Circuit reset — restart attempts allowed again.")
            return True
        remaining = int(self._circuit_break_until - time.time())
        logger.warning("⏳ Circuit still broken — wait %ds before restart.", remaining)
        return False

    # ── L2-T9: Deadlocked item auto-escalation timer ────────────────────

    # L2-T10: Webhook callback for stuck-item notifications.
    # Set this to a callable (e.g. lambda items: requests.post(url, json=items))
    # and the deadlock monitor will fire it whenever items go STUCK.
    on_stuck_items: Optional[Callable[[list], None]] = None

    def _deadlock_loop(self) -> None:
        """Background thread that runs alive-checks on a fixed timer.

        This is separate from the main health-check loop so that
        deadlock detection runs at a consistent 30s interval regardless
        of health-check timing.
        """
        logger.info(
            "Deadlock monitor started (interval=%.1fs)",
            self._deadlock_interval,
        )
        while self._running:
            try:
                if self._harness and self._agent_check_fn:
                    deadlocked = self._run_alive_check()
                    if deadlocked:
                        logger.warning(
                            "🔴 L2-T9 deadlock monitor: %d items escalated",
                            len(deadlocked),
                        )
                        # L2-T10: Fire stuck-item webhook callback
                        if self.on_stuck_items is not None:
                            try:
                                self.on_stuck_items(deadlocked)
                            except Exception as hook_err:
                                logger.warning(
                                    "L2-T10 stuck-item webhook callback failed: %s",
                                    hook_err,
                                )
            except Exception as e:
                logger.exception("Deadlock monitor error: %s", e)
            time.sleep(self._deadlock_interval)

    def start_deadlock_monitor(self) -> None:
        """Start the background deadlock detection thread."""
        if self._deadlock_thread and self._deadlock_thread.is_alive():
            return
        self._deadlock_thread = threading.Thread(
            target=self._deadlock_loop,
            daemon=True,
            name="simp-deadlock-monitor",
        )
        self._deadlock_thread.start()
        logger.info("Deadlock monitor thread started")

    def stop_deadlock_monitor(self) -> None:
        """Stop the deadlock monitor (called during shutdown)."""
        # Thread is daemon, will exit when process exits.
        # This is just a clean signaling point.
        logger.info("Deadlock monitor stopping (daemon will exit with process)")

    @property
    def healthy(self) -> bool:
        """Returns True if the supervisor considers the broker healthy."""
        return self._consecutive_failures < self.config.max_consecutive_failures

    @property
    def metrics(self) -> dict:
        """Return a copy of current metrics."""
        with self._lock:
            return dict(self._metrics)


# ─── Hot-Reload Manager ─────────────────────────────────────────────────────

class ReloadManager:
    """Manages hot-reload of broker configuration and routes without process restart.

    This is the runtime equivalent of PM2's `pm2 reload` — it reloads:
    - Route blueprints (add/remove routes without restart)
    - Crypto keys (rotate signing keys in-place)
    - Broker configuration (rate limits, timeouts, pool sizes)
    - CORS and TLS settings
    """

    def __init__(self, app, broker):
        self.app = app
        self.broker = broker
        self._reload_lock = threading.Lock()
        self._reload_count = 0

    def reload_all(self) -> dict:
        """Perform a full configuration reload.

        Returns a dict describing what was reloaded and any errors.
        """
        with self._reload_lock:
            result = {"reload_count": self._reload_count + 1, "actions": [], "errors": []}

            # 1. Reload broker configuration
            try:
                self.broker.load_config()
                result["actions"].append("broker_config")
            except Exception as e:
                result["errors"].append(f"broker_config: {e}")

            # 2. Reload crypto keys
            try:
                if hasattr(self.broker, "load_crypto_keys"):
                    self.broker.load_crypto_keys()
                    result["actions"].append("crypto_keys")
            except Exception as e:
                result["errors"].append(f"crypto_keys: {e}")

            # 3. Reload CORS config
            try:
                cors_origins = os.environ.get("SIMP_CORS_ORIGINS", "*")
                self.app.config["SIMP_CORS_ORIGINS"] = cors_origins
                result["actions"].append("cors_config")
            except Exception as e:
                result["errors"].append(f"cors_config: {e}")

            # 4. Reload TLS manager
            try:
                from simp.broker.tls_manager import init_tls
                init_tls(reload=True)
                result["actions"].append("tls_config")
            except Exception as e:
                result["errors"].append(f"tls_config: {e}")

            self._reload_count += 1
            result["success"] = len(result["errors"]) == 0
            return result


# ─── Upgrade Orchestrator ────────────────────────────────────────────────────

class UpgradeOrchestrator:
    """Coordinates staged rollout of new broker versions.

    Supports:
    - Canary deployments: run new version alongside current, monitor health
    - Blue/green: swap traffic after canary passes
    - Rollback: if new version fails, revert to previous
    - Binary swap: download new binary, verify signature, swap in

    This is the recursive evolution mechanism — the supervisor can upgrade
    itself by launching a new watchdog that manages a new broker.
    """

    def __init__(self, supervisor: SupervisorDaemon):
        self.supervisor = supervisor
        self._previous_version = None

    def upgrade_binary(self, new_binary_path: str) -> dict:
        """Stage a binary upgrade.

        Sets the upgrade binary path so the watchdog picks it up on restart,
        then signals the broker to exit with code 78 (EX_CONFIG) to trigger
        a watchdog-managed restart with the new binary.
        """
        path = Path(new_binary_path)
        if not path.exists():
            return {"success": False, "error": f"Binary not found: {new_binary_path}"}

        os.environ["SIMP_SUPERVISOR_UPGRADE_PATH"] = str(path.absolute())
        logger.info("Upgrade staged: %s", path.absolute())

        # Signal graceful shutdown with restart
        os.kill(os.getpid(), signal.SIGTERM)
        return {"success": True, "message": f"Upgrade to {new_binary_path} staged"}


# ─── CLI Entry Point ─────────────────────────────────────────────────────────

def start_broker():
    """Entry point for `simp start`.

    Starts the broker with optional watchdog supervision.
    """
    if "--watchdog" in sys.argv or os.environ.get("SIMP_SUPERVISOR_WATCHDOG", "").lower() in ("1", "true"):
        run_watchdog()
    else:
        # Start broker directly (for systemd, Docker, PM2, or container orchestration)
        from simp.server.http_server import main
        main()


if __name__ == "__main__":
    start_broker()
