"""Agent Heartbeat Protocol (L2-T1, L2-T2, L2-T3).

A signed heartbeat system that:
  - Tracks agent liveness via periodic heartbeats
  - Escalates stale agents through warn → drain → deregister
  - Exposes /internal/ping for supervisor alive-checks
  - Integrates with the RecursiveHarness deadlock detection

Design:
  - HeartbeatAgent: tracks a single agent's state
  - HeartbeatRegistry: manages all agents, stores to state.json
  - SelfPingEndpoint: /internal/ping for supervisor loop
"""

import json
import logging
import threading
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Agent heartbeat state
# ---------------------------------------------------------------------------

class HeartbeatStatus:
    ALIVE = "alive"           # Heartbeat received within window
    WARN = "warn"             # Missed 1 heartbeat window
    DRAINING = "draining"     # Missed 2 windows — being drained
    STALE = "stale"           # Missed 3+ windows — deregistered
    UNKNOWN = "unknown"       # Not yet seen

    TRANSITIONS = {
        "alive": ["warn"],
        "warn": ["alive", "draining"],
        "draining": ["alive", "stale"],
        "stale": [],
        "unknown": ["alive", "stale"],
    }


@dataclass
class HeartbeatRecord:
    """Tracks a single agent's heartbeat state."""
    agent_id: str
    last_seen: float = 0.0          # timestamp of last heartbeat
    miss_count: int = 0              # consecutive missed windows
    status: str = HeartbeatStatus.UNKNOWN
    warn_at: float = 0.0            # timestamp when warn was issued
    drain_at: Optional[float] = None  # timestamp when drain started
    deregister_at: Optional[float] = None  # timestamp when deregistered
    signing_key_id: Optional[str] = None   # Ed25519 key id for signature verification

    @property
    def is_active(self) -> bool:
        return self.status in (HeartbeatStatus.ALIVE, HeartbeatStatus.WARN, HeartbeatStatus.DRAINING)

    @property
    def is_dead(self) -> bool:
        return self.status == HeartbeatStatus.STALE

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "HeartbeatRecord":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# Heartbeat Registry — manages all agents
# ---------------------------------------------------------------------------

class HeartbeatRegistry:
    """Manages heartbeat tracking for all connected agents.

    Configurable:
      heartbeat_window_s: how long before an agent is considered missing (default 30s)
      warn_threshold: missed windows before warn (default 1)
      drain_threshold: missed windows before drain (default 2)
      stale_threshold: missed windows before deregister (default 3)
    """

    def __init__(
        self,
        heartbeat_window_s: float = 30.0,
        warn_threshold: int = 1,
        drain_threshold: int = 2,
        stale_threshold: int = 3,
        state_path: Optional[str] = None,
        on_agent_warn: Optional[Callable[[str], None]] = None,
        on_agent_drain: Optional[Callable[[str], None]] = None,
        on_agent_stale: Optional[Callable[[str], None]] = None,
    ):
        self._heartbeat_window_s = heartbeat_window_s
        self._warn_threshold = warn_threshold
        self._drain_threshold = drain_threshold
        self._stale_threshold = stale_threshold
        self._state_path = Path(state_path) if state_path else None
        self._on_agent_warn = on_agent_warn
        self._on_agent_drain = on_agent_drain
        self._on_agent_stale = on_agent_stale

        self._agents: dict[str, HeartbeatRecord] = {}
        self._lock = threading.Lock()
        self._running = False
        self._check_thread: Optional[threading.Thread] = None
        self._start_time = time.time()

        # Load persisted state
        if self._state_path and self._state_path.exists():
            self._load()

    # ── Agent Registration ───────────────────────────────────────────────

    def register(self, agent_id: str, signing_key_id: Optional[str] = None) -> HeartbeatRecord:
        """Register a new agent, or reset an existing one."""
        with self._lock:
            record = HeartbeatRecord(
                agent_id=agent_id,
                status=HeartbeatStatus.ALIVE,
                last_seen=time.time(),
                signing_key_id=signing_key_id,
            )
            self._agents[agent_id] = record
            self._save()
            return record

    def deregister(self, agent_id: str) -> Optional[HeartbeatRecord]:
        """Remove an agent from the registry entirely."""
        with self._lock:
            record = self._agents.pop(agent_id, None)
            self._save()
            return record

    def get_agent(self, agent_id: str) -> Optional[HeartbeatRecord]:
        with self._lock:
            return self._agents.get(agent_id)

    def list_agents(self, status: Optional[str] = None) -> list[HeartbeatRecord]:
        with self._lock:
            if status:
                return [a for a in self._agents.values() if a.status == status]
            return list(self._agents.values())

    # ── Heartbeat Reception ──────────────────────────────────────────────

    def receive_heartbeat(self, agent_id: str, signing_key_id: Optional[str] = None) -> HeartbeatRecord:
        """Process an incoming heartbeat from an agent.

        If the agent is unknown, registers it.
        If the agent was draining/stale, brings it back to alive.
        """
        with self._lock:
            record = self._agents.get(agent_id)
            if record is None:
                # Inline registration to avoid deadlock (lock already held)
                record = HeartbeatRecord(
                    agent_id=agent_id,
                    status=HeartbeatStatus.ALIVE,
                    last_seen=time.time(),
                    signing_key_id=signing_key_id,
                )
                self._agents[agent_id] = record
                self._save()
                return record

            # Reset miss count and status
            record.last_seen = time.time()
            record.miss_count = 0
            if record.status != HeartbeatStatus.ALIVE:
                logger.info("❤️‍🩹 Agent %s reconnected (was %s)", agent_id, record.status)
                record.status = HeartbeatStatus.ALIVE
            if signing_key_id:
                record.signing_key_id = signing_key_id
            self._save()
            return record

    # ── Heartbeat Checking Loop ──────────────────────────────────────────

    def start_checker(self, interval_s: float = 10.0) -> None:
        """Start background thread that checks for stale agents."""
        if self._running:
            return
        self._running = True
        self._check_thread = threading.Thread(
            target=self._check_loop,
            args=(interval_s,),
            daemon=True,
            name="heartbeat-checker",
        )
        self._check_thread.start()
        logger.info("❤️ Heartbeat checker started (interval=%ds, window=%ds)", interval_s, self._heartbeat_window_s)

    def stop_checker(self) -> None:
        self._running = False

    def _check_loop(self, interval_s: float) -> None:
        """Periodic loop that checks all agents for staleness."""
        while self._running:
            try:
                self.check_all()
            except Exception as e:
                logger.error("Heartbeat check error: %s", e)
            time.sleep(interval_s)

    def check_all(self) -> list[HeartbeatRecord]:
        """Check all agents and escalate stale ones.

        Returns list of agents whose status changed.
        """
        now = time.time()
        changed: list[HeartbeatRecord] = []

        with self._lock:
            for agent_id, record in list(self._agents.items()):
                if not record.is_active:
                    continue

                elapsed = now - record.last_seen
                missed_windows = int(elapsed / self._heartbeat_window_s)

                if missed_windows <= 0:
                    continue  # still within window

                old_status = record.status
                record.miss_count = missed_windows

                if missed_windows >= self._stale_threshold:
                    new_status = HeartbeatStatus.STALE
                elif missed_windows >= self._drain_threshold:
                    new_status = HeartbeatStatus.DRAINING
                elif missed_windows >= self._warn_threshold:
                    new_status = HeartbeatStatus.WARN
                else:
                    continue

                if new_status != old_status:
                    record.status = new_status
                    changed.append(record)
                    logger.log(
                        logging.WARNING if new_status in (HeartbeatStatus.WARN, HeartbeatStatus.DRAINING) else logging.ERROR,
                        "❤️ Agent %s heartbeat status: %s → %s (missed %d/%d windows, %.1fs elapsed)",
                        agent_id, old_status, new_status, missed_windows, self._stale_threshold, elapsed,
                    )
                    # Fire callbacks
                    if new_status == HeartbeatStatus.WARN and self._on_agent_warn:
                        self._on_agent_warn(agent_id)
                    elif new_status == HeartbeatStatus.DRAINING and self._on_agent_drain:
                        self._on_agent_drain(agent_id)
                    elif new_status == HeartbeatStatus.STALE and self._on_agent_stale:
                        self._on_agent_stale(agent_id)

            self._save()

        return changed

    # ── L2-T4: Agent liveness query ──────────────────────────────────────

    def is_alive(self, agent_id: str) -> bool:
        """Check if an agent is considered alive.

        Returns True if:
          - Agent is registered AND
          - Status is ALIVE or WARN (still active, not yet drained/stale)

        Returns True for unknown agents (conservative — don't false-positive
        escalate items assigned to agents that were never registered).

        Used by the supervisor alive-check loop to verify agent responsiveness.
        """
        with self._lock:
            record = self._agents.get(agent_id)
            if record is None:
                # Unknown agent — assume alive to avoid false escalation
                return True
            return record.status in (HeartbeatStatus.ALIVE, HeartbeatStatus.WARN)

    # ── Metrics ──────────────────────────────────────────────────────────

    @property
    def stats(self) -> dict:
        with self._lock:
            total = len(self._agents)
            alive = sum(1 for a in self._agents.values() if a.status == HeartbeatStatus.ALIVE)
            warn = sum(1 for a in self._agents.values() if a.status == HeartbeatStatus.WARN)
            draining = sum(1 for a in self._agents.values() if a.status == HeartbeatStatus.DRAINING)
            stale = sum(1 for a in self._agents.values() if a.status == HeartbeatStatus.STALE)
            return {
                "total": total,
                "alive": alive,
                "warn": warn,
                "draining": draining,
                "stale": stale,
                "uptime_s": round(time.time() - self._start_time),
            }

    # ── Persistence ──────────────────────────────────────────────────────

    def _save(self) -> None:
        if not self._state_path:
            return
        try:
            data = {
                "agents": {aid: rec.to_dict() for aid, rec in self._agents.items()},
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            self._state_path.write_text(json.dumps(data, indent=2))
        except (OSError, PermissionError) as e:
            logger.warning("Failed to save heartbeat state: %s", e)

    def _load(self) -> None:
        if not self._state_path or not self._state_path.exists():
            return
        try:
            data = json.loads(self._state_path.read_text())
            for aid, rec_data in data.get("agents", {}).items():
                self._agents[aid] = HeartbeatRecord.from_dict(rec_data)
            logger.info("❤️ Loaded %d heartbeat records from %s", len(self._agents), self._state_path)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load heartbeat state: %s", e)
