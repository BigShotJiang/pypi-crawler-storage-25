"""
SIMP MCP Blueprint

Exposes SIMP's native tools and memory as MCP-compatible endpoints.
GET  /mcp/tools         — list all available tools
POST /mcp/call_tool    — invoke a tool by name

Gated by SIMP_MCP_ENABLE=true env var (default: false).
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List

from flask import Blueprint, jsonify, request

logger = logging.getLogger("simp.mcp")


# ── Blueprint ────────────────────────────────────────────────────────────────

mcp_bp = Blueprint("mcp", __name__, url_prefix="/mcp")


# ── Tool registry helpers ────────────────────────────────────────────────────

def _get_tools() -> List[Dict[str, Any]]:
    """Harvest all registered native tools from NATIVE_TOOL_REGISTRIES."""
    from simp.native_tools import NATIVE_TOOL_REGISTRIES
    tools = []

    # Always include core memory and policy tools
    tools.extend([
        {
            "name": "knowledge_index.search_by_topic",
            "description": "Search SIMP knowledge index by topic",
            "input_schema": {
                "type": "object",
                "properties": {"topic": {"type": "string"}, "limit": {"type": "integer", "default": 10}},
                "required": ["topic"]
            },
            "registry": "memory"
        },
        {
            "name": "task_memory.get_task",
            "description": "Retrieve task memory by ID",
            "input_schema": {
                "type": "object",
                "properties": {"task_id": {"type": "string"}},
                "required": ["task_id"]
            },
            "registry": "memory"
        },
        {
            "name": "session_bootstrap.get_recent",
            "description": "Get recent session context pack",
            "input_schema": {
                "type": "object",
                "properties": {"pack_id": {"type": "string", "default": "default"}},
                "required": []
            },
            "registry": "memory"
        },
        {
            "name": "policy_state.get_current",
            "description": "Get current SIMP policy state",
            "input_schema": {"type": "object", "properties": {}},
            "registry": "policy"
        },
    ])

    # Pull tool definitions from the registries
    for registry_name, registry in NATIVE_TOOL_REGISTRIES.items():
        if hasattr(registry, "list_tools") and callable(getattr(registry, "list_tools")):
            try:
                for tool_def in registry.list_tools():
                    if isinstance(tool_def, dict):
                        tools.append(tool_def)
                    elif hasattr(tool_def, "name"):
                        tools.append({
                            "name": getattr(tool_def, "name", ""),
                            "description": getattr(tool_def, "description", ""),
                            "input_schema": getattr(tool_def, "input_schema", {}),
                            "registry": registry_name
                        })
            except Exception as e:
                logger.warning("Error listing tools from %s: %s", registry_name, e)

    return tools


def _call_tool(name: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Dispatch a tool call by name."""
    # Memory tools
    if name == "knowledge_index.search_by_topic":
        from simp.memory.knowledge_index import KnowledgeIndex
        ki = KnowledgeIndex()
        results = ki.search_topics(args.get("topic", ""))
        return {"success": True, "result": results}

    if name == "task_memory.get_task":
        from simp.memory.task_memory import TaskMemory
        tm = TaskMemory()
        task = tm.get_task(args.get("task_id", ""))
        return {"success": True, "result": task}

    if name == "session_bootstrap.get_recent":
        from simp.memory.session_bootstrap import SessionBootstrap
        sb = SessionBootstrap()
        # load_context_pack returns None if not found; return empty list if None
        pack = sb.load_context_pack(args.get("pack_id", "default"))
        return {"success": True, "result": pack or []}

    if name == "policy_state.get_current":
        from simp.memory.policy_state import load_active_system_policies
        state = load_active_system_policies()
        return {"success": True, "result": state}

    # Fallback: try native tool registry
    from simp.native_tools import NATIVE_TOOL_REGISTRIES
    for registry_name, registry in NATIVE_TOOL_REGISTRIES.items():
        if hasattr(registry, "get_tool") and callable(getattr(registry, "get_tool")):
            tool = registry.get_tool(name)
            if tool and hasattr(tool, "handler") and callable(tool.handler):
                try:
                    result = tool.handler(**args)
                    return {"success": True, "result": result}
                except Exception as e:
                    return {"success": False, "error": str(e)}

    return {"success": False, "error": f"Tool '{name}' not found or not callable"}


# ── Routes ───────────────────────────────────────────────────────────────────

@mcp_bp.route("/tools", methods=["GET"])
def list_tools():
    """List all available MCP tools."""
    if os.environ.get("SIMP_MCP_ENABLE", "").lower() not in ("1", "true", "yes"):
        return jsonify({"error": "MCP disabled — set SIMP_MCP_ENABLE=1 to enable"}), 503

    tools = _get_tools()
    return jsonify({
        "tools": tools,
        "count": len(tools),
        "mcp_version": "1.0"
    })


@mcp_bp.route("/call_tool", methods=["POST"])
def call_tool():
    """Invoke a tool by name with arguments."""
    if os.environ.get("SIMP_MCP_ENABLE", "").lower() not in ("1", "true", "yes"):
        return jsonify({"error": "MCP disabled"}), 503

    body = request.get_json(silent=True) or {}
    tool_name = body.get("tool") or body.get("name", "")
    args = body.get("args", body.get("arguments", {}))

    if not tool_name:
        return jsonify({"error": "Missing required field: tool"}), 400

    result = _call_tool(tool_name, args)
    status = 200 if result.get("success") else 404
    return jsonify(result), status