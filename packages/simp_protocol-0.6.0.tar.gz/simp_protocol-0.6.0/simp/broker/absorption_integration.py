"""
Absorption Integration — Wires the Absorption Automaton into the SIMP broker.

This is the bridge between the running broker and the ecosystem absorber.
On broker startup:
  1. Loads all auto-generated bridges from simp/bridges/auto/
  2. Starts the Absorption Automaton in the background
  3. Registers all absorbed capabilities as routable intents
  4. Re-runs scanning every N seconds

The automaton's status is exposed at /v1/absorption/status
"""

import asyncio
import logging
import os
import sys
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Lazy imports — the absorption modules are self-contained
_automaton = None
_adapter = None


def get_automaton() -> Any:
    """Get or create the Absorption Automaton singleton."""
    global _automaton
    if _automaton is None:
        from simp.orchestration.absorption_automaton import AbsorptionAutomaton
        state_path = os.environ.get(
            "SIMP_ABSORPTION_STATE",
            os.path.join(os.path.dirname(__file__), "..", "absorption_state.json"),
        )
        _automaton = AbsorptionAutomaton(
            scan_interval=int(os.environ.get("SIMP_ABSORPTION_INTERVAL", "3600")),
            auto_deploy=True,
            state_path=state_path,
        )
        logger.info("Absorption Automaton initialized")
    return _automaton


def get_adapter() -> Any:
    """Get the Evolutionary Adapter singleton."""
    global _adapter
    if _adapter is None:
        from simp.adapter import EvolutionaryAdapter
        state_path = os.environ.get(
            "SIMP_ADAPTER_STATE",
            os.path.join(os.path.dirname(__file__), "..", "adapter_state.json"),
        )
        _adapter = EvolutionaryAdapter(
            scan_interval=int(os.environ.get("SIMP_ABSORPTION_INTERVAL", "3600")),
            auto_deploy=True,
            state_path=state_path,
        )
        logger.info("Evolutionary Adapter initialized")
    return _adapter


async def start_absorption():
    """Start the absorption automaton in the background."""
    automaton = get_automaton()
    asyncio.create_task(automaton.start())
    logger.info("Absorption Automaton started — scanning every %s seconds",
                automaton.scan_interval)
    logger.info("Pre-seeded ecosystems: %d", automaton.scheduler.absorbed_count)


async def stop_absorption():
    """Stop the absorption automaton."""
    automaton = get_automaton()
    await automaton.stop()
    logger.info("Absorption Automaton stopped")


def get_absorption_status() -> dict:
    """Get current absorption status for the /v1/absorption/status endpoint."""
    adapter = get_adapter()
    automaton = get_automaton()
    
    return {
        "evolutionary_adapter": adapter.status,
        "absorption_automaton": automaton.status,
        "bridges_active": len(automaton._bridges),
        "ecosystems_absorbed": automaton.scheduler.absorbed_count,
        "pending_absorptions": automaton.scheduler.pending_count,
        "capabilities_available": [
            f"simp://absorbed/{name}"
            for name in sorted(automaton._bridges.keys())
        ],
    }


# HTTP handler for the absorption status endpoint
async def handle_absorption_request(request: Any) -> dict:
    """Handle /v1/absorption/* requests."""
    path = request.path if hasattr(request, 'path') else ''
    
    if path.endswith('/status'):
        return get_absorption_status()
    elif path.endswith('/absorb'):
        # Manual absorption trigger
        name = request.args.get('name', [''])[0]
        source = request.args.get('source', [''])[0]
        if name and source:
            automaton = get_automaton()
            fp = await automaton.absorb_now(name, source)
            return {
                "status": "absorbed",
                "name": name,
                "source": source,
                "bridge": fp,
            }
        return {"status": "error", "message": "name and source required"}
    elif path.endswith('/scan'):
        # Manual scan trigger
        automaton = get_automaton()
        new_fingerprints = await automaton.scanner.scan_all()
        return {
            "status": "scanned",
            "new_discoveries": len(new_fingerprints),
            "ecosystems": [f.name for f in new_fingerprints],
        }
    
    return {"status": "error", "message": f"Unknown path: {path}"}
