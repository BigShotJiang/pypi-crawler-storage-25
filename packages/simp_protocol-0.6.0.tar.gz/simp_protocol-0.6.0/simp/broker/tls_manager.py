"""
SIMP TLS Manager — CA, broker cert, mTLS, and auto-rotation.

Provides TLS 1.3 with optional mTLS, self-signed CA, and automatic
certificate rotation for agent certs in the SIMP mesh.

Thread-safe singleton pattern.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import logging
import os
import shutil
import ssl
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("simp.tls_manager")


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

def _simp_dir() -> Path:
    home = Path(os.environ.get("SIMP_HOME", Path.home()))
    d = home / ".simp"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ca_dir() -> Path:
    d = _simp_dir() / "ca"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _certs_dir() -> Path:
    d = _simp_dir() / "certs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _agents_dir() -> Path:
    d = _simp_dir() / "agents"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class TLSManagerConfig:
    """TLS configuration. Loaded from env + config file."""
    cert_rotation_days: int = 365
    cert_grace_period_hours: int = 48
    ca_common_name: str = "SIMP Broker CA"
    broker_common_name: str = "simp-broker"
    agent_validity_days: int = 365
    min_cipher_suite: str = "TLS_AES_256_GCM_SHA384"
    ocsp_stapling: bool = False

    @classmethod
    def from_env(cls) -> "TLSManagerConfig":
        """Load config from environment with defaults."""
        return cls(
            cert_rotation_days=int(os.environ.get("SIMP_TLS_ROTATION_DAYS", "365")),
            cert_grace_period_hours=int(os.environ.get("SIMP_TLS_GRACE_HOURS", "48")),
            ca_common_name=os.environ.get("SIMP_CA_CN", "SIMP Broker CA"),
            broker_common_name=os.environ.get("SIMP_BROKER_CN", "simp-broker"),
            agent_validity_days=int(os.environ.get("SIMP_AGENT_VALIDITY_DAYS", "365")),
            min_cipher_suite=os.environ.get("SIMP_TLS_CIPHER", "TLS_AES_256_GCM_SHA384"),
            ocsp_stapling=os.environ.get("SIMP_OCSP_STAPLING", "").lower() in ("1", "true"),
        )


# ---------------------------------------------------------------------------
# SSL context builders
# ---------------------------------------------------------------------------

def _build_ssl_context(
    cert_path: Path,
    key_path: Path,
    ca_cert_path: Optional[Path] = None,
    require_client_cert: bool = False,
) -> ssl.SSLContext:
    """Build an SSLContext for TLS 1.3 with optional mTLS."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    ctx.load_cert_chain(str(cert_path), str(key_path))
    ctx.set_ciphers("TLS_AES@STRENGTH")

    if ca_cert_path and ca_cert_path.exists():
        if require_client_cert:
            ctx.verify_mode = ssl.CERT_REQUIRED
        else:
            ctx.verify_mode = ssl.CERT_OPTIONAL
        ctx.load_verify_locations(str(ca_cert_path))
    else:
        ctx.verify_mode = ssl.CERT_NONE

    return ctx


def build_client_ssl_context(cert_path: Path, key_path: Path, ca_cert_path: Path) -> ssl.SSLContext:
    """Build an SSLContext for an agent connecting to the broker."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    ctx.load_cert_chain(str(cert_path), str(key_path))
    ctx.set_ciphers("TLS_AES@STRENGTH")
    ctx.load_verify_locations(str(ca_cert_path))
    ctx.verify_mode = ssl.CERT_REQUIRED
    ctx.check_hostname = False
    return ctx


# ---------------------------------------------------------------------------
# Data Types
# ---------------------------------------------------------------------------

@dataclass
class CertInfo:
    serial: str
    cn: str
    not_before: str
    not_after: str
    key_type: str = "RSA"
    issuer: str = ""
    fingerprint_sha256: str = ""


# ---------------------------------------------------------------------------
# Broker CA — self-signed root CA
# ---------------------------------------------------------------------------

class BrokerCA:
    """Self-signed root CA for the SIMP mesh."""

    CA_CERT_PATH: Path = property(lambda s: _ca_dir() / "ca.pem")
    CA_KEY_PATH: Path = property(lambda s: _ca_dir() / "ca-key.pem")
    CA_SERIAL_FILE: Path = property(lambda s: _ca_dir() / "ca.srl")

    def __init__(self, config: Optional[TLSManagerConfig] = None):
        self._config = config or TLSManagerConfig.from_env()
        self._ensure_dir()
        self._ensure_ca()

    def _ensure_dir(self) -> None:
        _ca_dir().mkdir(parents=True, exist_ok=True)

    def _ensure_ca(self) -> None:
        if not self.CA_CERT_PATH.exists() or not self.CA_KEY_PATH.exists():
            self._generate_ca()

    def _run_openssl(self, args: List[str], input_str: Optional[str] = None) -> str:
        result = subprocess.run(
            ["openssl"] + args,
            capture_output=True, text=True, input=input_str,
        )
        if result.returncode != 0:
            raise RuntimeError(f"OpenSSL failed: {result.stderr}")
        return result.stdout

    def _generate_ca(self) -> None:
        """Generate self-signed CA key + cert."""
        self._run_openssl([
            "req", "-x509", "-new", "-newkey", "rsa:4096",
            "-nodes", "-sha256",
            "-keyout", str(self.CA_KEY_PATH),
            "-out", str(self.CA_CERT_PATH),
            "-days", "7300",
            "-subj", f"/CN={self._config.ca_common_name}",
        ])
        # Init serial file
        with open(self.CA_SERIAL_FILE, "w") as f:
            f.write("01\n")
        logger.info("Self-signed CA generated at %s", self.CA_CERT_PATH)

    def _next_serial(self) -> str:
        with open(self.CA_SERIAL_FILE, "r+") as f:
            serial = int(f.read().strip(), 16)
            f.seek(0)
            f.write(f"{serial + 1:02x}\n")
            f.truncate()
        return f"{serial:02x}"

    def _fingerprint(self, cert_path: Path) -> str:
        out = self._run_openssl(["x509", "-in", str(cert_path), "-noout", "-fingerprint", "-sha256"])
        return out.strip().split("=")[-1]

    def _cert_info(self, cert_path: Path) -> CertInfo:
        subj = self._run_openssl(["x509", "-in", str(cert_path), "-noout", "-subject"])
        dates = self._run_openssl(["x509", "-in", str(cert_path), "-noout", "-dates"])
        serial = self._run_openssl(["x509", "-in", str(cert_path), "-noout", "-serial"])
        return CertInfo(
            serial=serial.strip().split("=")[-1],
            cn=subj.strip().split("CN=")[-1].split(",")[0],
            not_before=dates.split("notBefore=")[-1].split("\n")[0].strip(),
            not_after=dates.split("notAfter=")[-1].split("\n")[0].strip(),
            fingerprint_sha256=self._fingerprint(cert_path),
        )

    def get_info(self) -> CertInfo:
        return self._cert_info(self.CA_CERT_PATH)

    def issue_agent_cert(self, agent_id: str) -> Tuple[str, str]:
        """Issue a new agent certificate. Returns (cert_path, key_path)."""
        agent_dir = _agents_dir() / agent_id.replace("/", "_").replace(" ", "_")
        agent_dir.mkdir(parents=True, exist_ok=True)
        cert_path = agent_dir / "cert.pem"
        key_path = agent_dir / "key.pem"
        csr_path = agent_dir / "csr.pem"

        # Generate key + CSR
        self._run_openssl([
            "req", "-new", "-newkey", "rsa:2048", "-nodes",
            "-keyout", str(key_path),
            "-out", str(csr_path),
            "-subj", f"/CN={agent_id}",
        ])

        # Sign with CA
        serial = self._next_serial()
        self._run_openssl([
            "x509", "-req", "-sha256",
            "-in", str(csr_path),
            "-CA", str(self.CA_CERT_PATH),
            "-CAkey", str(self.CA_KEY_PATH),
            "-set_serial", f"0x{serial}",
            "-out", str(cert_path),
            "-days", "365",
        ])

        # Clean up CSR
        csr_path.unlink(missing_ok=True)
        logger.info("Issued cert for agent %s (serial %s)", agent_id, serial)
        return str(cert_path), str(key_path)

    def revoke_agent(self, agent_id: str) -> bool:
        agent_dir = _agents_dir() / agent_id.replace("/", "_").replace(" ", "_")
        if agent_dir.exists():
            shutil.rmtree(agent_dir)
            logger.info("Revoked cert for agent %s", agent_id)
            return True
        return False

    def is_cert_valid(self, agent_id: str) -> bool:
        agent_dir = _agents_dir() / agent_id.replace("/", "_").replace(" ", "_")
        cert_path = agent_dir / "cert.pem"
        if not cert_path.exists():
            return False
        try:
            self._run_openssl(["x509", "-in", str(cert_path), "-noout", "-subject"])
            return True
        except RuntimeError:
            return False

    def get_agent_info(self, agent_id: str) -> Optional[CertInfo]:
        agent_dir = _agents_dir() / agent_id.replace("/", "_").replace(" ", "_")
        cert_path = agent_dir / "cert.pem"
        if cert_path.exists():
            return self._cert_info(cert_path)
        return None

    def list_agents(self) -> List[str]:
        ad = _agents_dir()
        if not ad.exists():
            return []
        return sorted(d.name for d in ad.iterdir() if d.is_dir())


# ---------------------------------------------------------------------------
# Broker cert manager — auto-rotating broker TLS identity
# ---------------------------------------------------------------------------

@dataclass
class BrokerCert:
    cert_path: str
    key_path: str
    serial: str = ""
    not_before: str = ""
    not_after: str = ""
    is_rolling: bool = False


class BrokerCertManager:
    """Manages the broker's own TLS certificate with automatic rotation."""

    CERT_PATH: Path = property(lambda s: _certs_dir() / "broker.pem")
    KEY_PATH: Path = property(lambda s: _certs_dir() / "broker-key.pem")
    SERIAL_FILE: Path = property(lambda s: _certs_dir() / "broker.srl")
    ROLL_DIR: Path = property(lambda s: _certs_dir() / "rolling")

    def __init__(self, ca: BrokerCA, config: Optional[TLSManagerConfig] = None):
        self._ca = ca
        self._config = config or TLSManagerConfig.from_env()
        self._ssl_context: Optional[ssl.SSLContext] = None
        self._lock = threading.Lock()
        self._ensure_cert()

    def _ensure_cert(self) -> None:
        _certs_dir().mkdir(parents=True, exist_ok=True)
        if not self.CERT_PATH.exists() or not self.KEY_PATH.exists():
            self._generate_broker_cert()

    def _generate_broker_cert(self) -> None:
        """Generate a new broker certificate signed by the CA."""
        tmp_key = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
        tmp_csr = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
        tmp_cert = tempfile.NamedTemporaryFile(delete=False, suffix=".pem")
        try:
            # Generate key
            subprocess.run(
                ["openssl", "genrsa", "2048"],
                stdout=tmp_key, stderr=subprocess.PIPE,
                check=True,
            )
            tmp_key.close()

            # Generate CSR
            subprocess.run(
                ["openssl", "req", "-new", "-sha256",
                 "-key", tmp_key.name,
                 "-out", tmp_csr.name,
                 "-subj", f"/CN={self._config.broker_common_name}"],
                capture_output=True, check=True,
            )
            tmp_csr.close()

            # Sign with CA
            subprocess.run(
                ["openssl", "x509", "-req", "-sha256",
                 "-in", tmp_csr.name,
                 "-CA", str(self._ca.CA_CERT_PATH),
                 "-CAkey", str(self._ca.CA_KEY_PATH),
                 "-CAcreateserial",
                 "-out", tmp_cert.name,
                 "-days", str(self._config.cert_rotation_days)],
                capture_output=True, check=True,
            )
            tmp_cert.close()

            # Move into place
            shutil.move(tmp_key.name, self.KEY_PATH)
            shutil.move(tmp_cert.name, self.CERT_PATH)
            logger.info("Broker TLS cert generated at %s", self.CERT_PATH)
        finally:
            for p in [tmp_key.name, tmp_csr.name, tmp_cert.name]:
                Path(p).unlink(missing_ok=True)

    def _load_cert(self) -> BrokerCert:
        if not self.CERT_PATH.exists():
            self._generate_broker_cert()
        out = subprocess.run(
            ["openssl", "x509", "-in", str(self.CERT_PATH), "-noout", "-serial", "-dates"],
            capture_output=True, text=True,
        )
        lines = out.stdout.strip().split("\n")
        serial = lines[0].split("=")[-1] if len(lines) > 0 else ""
        not_before = lines[1].split("=")[-1] if len(lines) > 1 else ""
        not_after = lines[2].split("=")[-1] if len(lines) > 2 else ""
        return BrokerCert(
            cert_path=str(self.CERT_PATH),
            key_path=str(self.KEY_PATH),
            serial=serial, not_before=not_before, not_after=not_after,
        )

    def get_current(self) -> BrokerCert:
        return self._load_cert()

    def needs_rotation(self) -> bool:
        try:
            cert = self._load_cert()
            if not cert.not_after:
                return True
            expiry = datetime.strptime(cert.not_after, "%b %d %H:%M:%S %Y %Z")
            remaining = expiry - datetime.now(timezone.utc).replace(tzinfo=None)
            return remaining < timedelta(hours=self._config.cert_grace_period_hours)
        except Exception:
            return True

    def rotate(self) -> None:
        with self._lock:
            # Save current as rolling backup
            roll_dir = self.ROLL_DIR
            roll_dir.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            if self.CERT_PATH.exists():
                shutil.copy2(self.CERT_PATH, roll_dir / f"broker-{timestamp}.pem")
            if self.KEY_PATH.exists():
                shutil.copy2(self.KEY_PATH, roll_dir / f"broker-key-{timestamp}.pem")

            self._generate_broker_cert()
            self._ssl_context = None
            logger.info("Broker TLS cert rotated")

    def _start_rotation_watcher(self) -> None:
        """Start background thread to monitor cert expiry."""

        def _watcher():
            while True:
                if self.needs_rotation():
                    self.rotate()
                time.sleep(3600)  # Check hourly

        t = threading.Thread(target=_watcher, daemon=True)
        t.start()

    def get_ssl_context(self, require_client_cert: bool = False) -> ssl.SSLContext:
        if self._ssl_context is None:
            self._ssl_context = _build_ssl_context(
                self.CERT_PATH, self.KEY_PATH,
                self._ca.CA_CERT_PATH if self._ca.CA_CERT_PATH.exists() else None,
                require_client_cert,
            )
        return self._ssl_context


# ---------------------------------------------------------------------------
# Singleton / global state
# ---------------------------------------------------------------------------

_tls_manager: Optional[BrokerCertManager] = None
_ca: Optional[BrokerCA] = None
_config: Optional[TLSManagerConfig] = None
_init_lock = threading.Lock()


def init_tls() -> Tuple[BrokerCertManager, BrokerCA]:
    """Initialize TLS subsystem. Thread-safe, idempotent."""
    global _tls_manager, _ca, _config
    if _tls_manager is not None and _ca is not None:
        return _tls_manager, _ca
    with _init_lock:
        if _tls_manager is not None and _ca is not None:
            return _tls_manager, _ca
        _config = TLSManagerConfig.from_env()
        _ca = BrokerCA(_config)
        _tls_manager = BrokerCertManager(_ca, _config)
        logger.info("TLS subsystem initialized")
        return _tls_manager, _ca


def get_tls_manager() -> BrokerCertManager:
    """Get the singleton TLS manager. Initializes if needed."""
    if _tls_manager is None:
        init_tls()
    return _tls_manager


def get_ca() -> BrokerCA:
    """Get the singleton BrokerCA. Initializes if needed."""
    if _ca is None:
        init_tls()
    return _ca
