"""Certificate routes shim — re-exports from the broker-level cert routes."""

from flask import Blueprint, jsonify

tls_bp = Blueprint("tls", __name__)


jsonify_blueprint = tls_bp


__all__ = ["jsonify_blueprint", "tls_bp"]
