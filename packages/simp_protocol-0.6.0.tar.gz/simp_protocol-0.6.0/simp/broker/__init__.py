"""
SIMP Broker — routing, health, TLS, telemetry, schema, and certificate management.

Package `simp.broker.*` modules provide backing services for the SIMP HTTP server.
"""
