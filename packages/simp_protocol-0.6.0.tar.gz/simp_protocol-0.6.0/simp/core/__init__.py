"""SIMP Recursive Self-Awareness Core.

The harness lives here:
  - RecursiveHarness  → top-level state machine
  - SimpLevel         → one level of the spiral (50 items)
  - WorkItem          → one thing to do
  - build_level2()    → generates Level 2 items
  - build_level3()    → generates Level 3 items
  - build_level4()    → generates Level 4 items
  - build_level5()    → generates Level 5 items

Level 5 (Autonomous Financial Operations) is the active workstream.
"""

from simp.core.state_machine import RecursiveHarness, SimpLevel, WorkItem, LevelStatus, ItemStatus

__all__ = [
    "RecursiveHarness",
    "SimpLevel",
    "WorkItem",
    "LevelStatus",
    "ItemStatus",
]
