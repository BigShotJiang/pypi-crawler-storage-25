"""SIMP Self-Awareness Harness — recursive state machine.

This module gives SIMP the ability to know its exact state at all times,
track work levels, detect stuck items, and generate new work from completed work.

Design principles:
- Pure stdlib (no external deps)
- Stuck items get escalated, not retried (anti-infinite-loop)
- State persists to ~/.simp/state.json
- Generates next level when current level completes
"""

import json
import logging
import os
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional


logger = logging.getLogger(__name__)


def _now() -> str:
    """Return the current UTC time as ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Level definitions
# ---------------------------------------------------------------------------

class LevelStatus(Enum):
    LOCKED = "locked"         # Not yet started
    ACTIVE = "active"         # Work in progress
    COMPLETE = "complete"     # All items verified
    FAILED = "failed"         # An item escalated, needs human review


class ItemStatus(Enum):
    PENDING = "pending"       # Not started
    ASSIGNED = "assigned"     # Being worked on by an agent
    CHECKPOINT = "checkpoint"   # Partial progress, alive-check positive
    STUCK = "stuck"           # Alive-check failed, escalated
    DONE = "done"             # Verified complete
    SKIPPED = "skipped"       # Intentionally bypassed


@dataclass
class WorkItem:
    """A single work item within a level."""

    id: str                    # e.g. "L2-T12"
    title: str                 # Human-readable name
    description: str           # What needs to be done
    status: str = "pending"
    created_at: str = field(default_factory=_now)
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    assigned_to: Optional[str] = None   # agent name (e.g. "g3")
    tags: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)
    evidence: Optional[str] = None      # verification evidence (file, line, test)
    metadata: dict = field(default_factory=dict)  # L2-T12: zombie detection, etc.
    alive_checks: int = 0               # number of successful alive-checks
    alive_failures: int = 0             # consecutive failures before escalation

    def assign(self, agent: str) -> None:
        self.status = "assigned"
        self.assigned_to = agent
        self.started_at = _now()
        self.alive_checks = 0
        self.alive_failures = 0

    def checkpoint(self) -> None:
        self.status = "checkpoint"
        self.alive_checks += 1
        self.alive_failures = 0

    def fail_alive(self) -> None:
        self.alive_failures += 1
        if self.alive_failures >= 3:
            self.status = "stuck"

    def complete(self, evidence: str = "") -> None:
        self.status = "done"
        self.completed_at = _now()
        self.evidence = evidence

    def skip(self, reason: str = "") -> None:
        self.status = "skipped"
        self.completed_at = _now()
        self.evidence = reason

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "WorkItem":
        return cls(**d)


@dataclass
class SimpLevel:
    """A collection of work items representing one level of SIMP evolution."""

    number: int          # 1, 2, 3, ...
    name: str            # e.g. "Foundation — Security Hardening"
    status: str = "locked"
    items: list[WorkItem] = field(default_factory=list)
    created_at: str = field(default_factory=_now)

    @property
    def current_item(self) -> Optional[WorkItem]:
        """First non-done, non-skipped item."""
        for item in self.items:
            if item.status not in ("done", "skipped"):
                return item
        return None

    @property
    def pct(self) -> int:
        """Percent complete (0-100)."""
        if not self.items:
            return 0
        done = sum(1 for i in self.items if i.status in ("done", "skipped"))
        return int(done / len(self.items) * 100)

    @property
    def stuck_items(self) -> list[WorkItem]:
        return [i for i in self.items if i.status == "stuck"]

    @property
    def active_items(self) -> list[WorkItem]:
        return [i for i in self.items if i.status in ("assigned", "checkpoint")]

    def to_dict(self) -> dict:
        return {
            "number": self.number,
            "name": self.name,
            "status": self.status,
            "pct": self.pct,
            "item_count": len(self.items),
            "done": sum(1 for i in self.items if i.status == "done"),
            "stuck": len(self.stuck_items),
            "active": len(self.active_items),
            "current_item": self.current_item.id if self.current_item else None,
            "items": [i.to_dict() for i in self.items],
        }


class RecursiveHarness:
    """Top-level harness that manages levels and state persistence.

    The harness is a finite state machine:
      LOCKED → ACTIVE → COMPLETE → (generate next level) → ACTIVE → ...
    """

    def __init__(self, state_dir: str = "~/.simp", state_path: Optional[str] = None, auto_save: bool = False):
        if state_path:
            # Accept explicit state_path override
            state_dir = str(Path(state_path).parent)
        self._state_dir = Path(state_dir).expanduser()
        self._state_dir.mkdir(parents=True, exist_ok=True)
        self._state_path = self._state_dir / "state.json"
        self._levels: list[SimpLevel] = []

        # Load existing state or create fresh
        if self._state_path.exists():
            self._load()
            # L2-T12: Zombie detection — flag items that were in-progress at last save
            self._detect_zombies()
        else:
            # Seed Level 1 as done
            self._seed_level_1()

    # ------------------------------------------------------------------
    # Level management
    # ------------------------------------------------------------------

    def _seed_level_1(self) -> None:
        """Level 1 — Security Hardening (50/50 complete)."""
        items = []
        for i in range(1, 51):
            items.append(WorkItem(
                id=f"T{i}",
                title=f"Security tranche T{i}",
                description="",
                status="done",
                completed_at=_now(),
                evidence="verified in SECURITY_AUDIT.md",
            ))
        level = SimpLevel(
            number=1,
            name="Foundation — Security Hardening",
            status="complete",
            items=items,
        )
        self._levels.append(level)

    def seed_level(self, number: int, items: list[WorkItem], name: Optional[str] = None) -> SimpLevel:
        # If a SimpLevel was passed, extract its items
        if hasattr(items, 'items'):
            items = items.items
        """Add a new level (e.g. from build_level2())."""
        # Ensure we don't skip numbers
        existing = {l.number for l in self._levels}
        if number - 1 not in existing and number != 1:
            logger.warning("Seeding level %d without level %d", number, number - 1)

        level = SimpLevel(
            number=number,
            name=name or f"Level {number}",
            status="active",
            items=items,
        )
        self._levels.append(level)
        self._levels.sort(key=lambda l: l.number)
        self._persist()
        return level

    # ------------------------------------------------------------------
    # Item operations
    # ------------------------------------------------------------------

    def assign_item(self, level_num: int, item_id: str, agent: str) -> Optional[WorkItem]:
        """Mark an item as assigned to an agent."""
        item = self._find_item(level_num, item_id)
        if item:
            item.assign(agent)
            self._persist()
        return item

    def checkpoint_item(self, level_num: int, item_id: str) -> Optional[WorkItem]:
        """Record partial progress on an item (alive-check passed)."""
        item = self._find_item(level_num, item_id)
        if item:
            item.checkpoint()
            self._persist()
        return item

    def complete_item(self, level_num: int, item_id: str, evidence: str = "") -> Optional[WorkItem]:
        """Mark an item done."""
        item = self._find_item(level_num, item_id)
        if item:
            item.complete(evidence)
            self._maybe_advance_level()
            self._persist()
        return item

    def fail_item(self, level_num: int, item_id: str) -> Optional[WorkItem]:
        """Mark an item as stuck (escalated)."""
        item = self._find_item(level_num, item_id)
        if item:
            item.status = "stuck"
            self._persist()
        return item

    # ------------------------------------------------------------------
    # Alive check loop
    # ------------------------------------------------------------------

    def run_alive_check(self, level_num: int, agent_check: Callable[[str], bool]) -> list[WorkItem]:
        """Ping all assigned/checkpoint items. Escalate after 3 failures."""
        level = self._get_level(level_num)
        if not level:
            return []

        escalated: list[WorkItem] = []
        for item in level.active_items:
            if not item.assigned_to:
                continue
            if agent_check(item.assigned_to):
                item.checkpoint()
            else:
                item.fail_alive()
                if item.status == "stuck":
                    escalated.append(item)
        self._persist()
        return escalated

    def deadlocked_items(self) -> list[WorkItem]:
        """Return all stuck items across all levels."""
        result = []
        for level in self._levels:
            result.extend(level.stuck_items)
        return result

    # ------------------------------------------------------------------
    # Level completion → next generation
    # ------------------------------------------------------------------

    def _maybe_advance_level(self) -> None:
        """If current active level is done, mark it complete."""
        level = self.current_level
        if level and level.pct == 100 and level.status == "active":
            level.status = "complete"
            logger.info("Level %d COMPLETE! Ready to generate Level %d", level.number, level.number + 1)
            self._persist()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _persist(self) -> None:
        """Write state to disk.

        L2-T7: Creates a backup before overwriting on each level advance.
        Backups are written as state.json.bak.<timestamp> when the level
        status changes (e.g., active->complete).
        """
        data = self.to_dict()

        # L2-T7: Snapshot backup on level transition
        current = self.current_level
        if current and current.status == "active" and current.pct == 100:
            # About to advance — create a snapshot
            bak_path = self._state_path.with_suffix(
                f".json.bak.{int(time.time())}"
            )
            try:
                with open(bak_path, "w") as f:
                    json.dump(data, f, indent=2, default=str)
                logger.info("Level %d complete — state backed up to %s", current.number, bak_path)
            except (OSError, PermissionError) as e:
                logger.warning("Failed to create state backup: %s", e)

        with open(self._state_path, "w") as f:
            json.dump(data, f, indent=2, default=str)

    def _load(self) -> None:
        """Read state from disk."""
        with open(self._state_path) as f:
            data = json.load(f)
        for ld in data.get("levels", []):
            items = [WorkItem.from_dict(i) for i in ld.get("items", [])]
            level = SimpLevel(
                number=ld["number"],
                name=ld.get("name", f"Level {ld['number']}"),
                status=ld.get("status", "locked"),
                items=items,
                created_at=ld.get("created_at", _now()),
            )
            self._levels.append(level)

    # L2-T12: Zombie detection — run on harness load.
    # Flags any items with status "in_progress" or "assigned" as "zombie",
    # meaning the agent that was working on them may have died during
    # the last session. The supervisor's alive-check loop will then
    # re-check these items and either recover or escalate them.
    def _detect_zombies(self) -> int:
        """Scan all active-level items for zombie (stale in-progress) state.

        Returns the count of items flagged as zombie.
        """
        count = 0
        for level in self._levels:
            if level.status != "active":
                continue
            for item in level.items:
                if item.status in ("in_progress", "assigned"):
                    old_status = item.status
                    item.status = "zombie"
                    item.metadata["zombie_restored_from"] = old_status
                    item.metadata["zombie_detected_at"] = _now()
                    logger.warning(
                        "L2-T12 zombie: item %s restored from %s → zombie",
                        item.id, old_status,
                    )
                    count += 1
        if count:
            logger.warning("L2-T12: %d zombie item(s) detected on startup", count)
        return count

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    @property
    def current_level(self) -> Optional[SimpLevel]:
        """Find the highest-numbered active (not complete) level."""
        for level in reversed(self._levels):
            if level.status == "active":
                return level
        return None

    @property
    def levels(self) -> list[SimpLevel]:
        return self._levels

    def _get_level(self, num: int) -> Optional[SimpLevel]:
        for l in self._levels:
            if l.number == num:
                return l
        return None

    def _find_item(self, level_num: int, item_id: str) -> Optional[WorkItem]:
        level = self._get_level(level_num)
        if not level:
            return None
        for item in level.items:
            if item.id == item_id:
                return item
        return None

    def to_dict(self) -> dict:
        return {
            "levels": [l.to_dict() for l in self._levels],
            "current_level": self.current_level.number if self.current_level else None,
        }
