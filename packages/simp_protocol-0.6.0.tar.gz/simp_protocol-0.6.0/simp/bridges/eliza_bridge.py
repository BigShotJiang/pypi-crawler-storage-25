"""
ElizaOS Bridge — ElizaOS Agents → SIMP Participants.

Allows any ElizaOS agent to:
  1. Register its actions/plugins as SIMP capabilities
  2. Receive intents from the SIMP broker
  3. Route sub-intents to other agents via SIMP
  4. Settle payments for inter-agent work

This bridges the gap between ElizaOS's agent runtime (single-agent focus)
and SIMP's inter-agent network (multi-agent routing).

Usage:
    bridge = ElizaBridge()
    await bridge.connect("http://localhost:3000")
    
    # Register ElizaOS agent's actions as SIMP capabilities
    await bridge.sync_capabilities()
    
    # Now other agents can route intents to this ElizaOS agent
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin

logger = logging.getLogger(__name__)


@dataclass
class ElizaAction:
    """An action registered by an ElizaOS agent."""
    name: str
    description: str = ""
    similes: List[str] = field(default_factory=list)
    validate_fn: str = ""
    handler_fn: str = ""

    def to_simp_capability(self, agent_id: str) -> str:
        """Map ElizaOS action → SIMP capability type."""
        return f"eliza.{agent_id}.{self.name}"


@dataclass
class ElizaPlugin:
    """A plugin loaded by an ElizaOS agent."""
    name: str
    description: str = ""
    actions: List[ElizaAction] = field(default_factory=list)
    providers: List[str] = field(default_factory=list)
    evaluators: List[str] = field(default_factory=list)


class ElizaRestClient:
    """Minimal REST client for ElizaOS's API."""

    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    def get_plugins(self) -> List[str]:
        """Get list of loaded plugins."""
        import urllib.request
        try:
            url = urljoin(self.base_url, "/api/plugins")
            resp = urllib.request.urlopen(url, timeout=10)
            return json.loads(resp.read().decode())
        except Exception as e:
            logger.warning(f"ElizaOS plugins fetch failed: {e}")
            return []

    def send_message(self, agent_id: str, text: str, room_id: str = "simp") -> dict:
        """Send a message to an ElizaOS agent."""
        import urllib.request
        try:
            url = urljoin(self.base_url, f"/{agent_id}/message")
            payload = json.dumps({
                "text": text,
                "userId": "simp-bridge",
                "roomId": room_id,
            }).encode()
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            resp = urllib.request.urlopen(req, timeout=30)
            return json.loads(resp.read().decode())
        except Exception as e:
            logger.warning(f"ElizaOS message failed: {e}")
            return {"error": str(e)}


class ElizaBridge:
    """Bridge between ElizaOS and SIMP."""

    def __init__(self):
        self._client: Optional[ElizaRestClient] = None
        self._agent_id: str = ""
        self._plugins: List[ElizaPlugin] = []
        self._capabilities: Dict[str, str] = {}  # cap_type → action_name

    async def connect(self, base_url: str) -> bool:
        """Connect to an ElizaOS agent's REST API."""
        self._client = ElizaRestClient(base_url)
        
        # Verify connection with health check
        import urllib.request
        try:
            url = urljoin(base_url, "/api/health")
            resp = urllib.request.urlopen(url, timeout=10)
            health = json.loads(resp.read().decode())
            self._agent_id = health.get("agentId", health.get("id", "eliza-agent"))
            logger.info(f"Connected to ElizaOS agent: {self._agent_id}")
            return True
        except Exception as e:
            logger.warning(f"ElizaOS connection failed: {e}")
            return False

    def sync_capabilities(self) -> Dict[str, str]:
        """Fetch ElizaOS actions and register them as SIMP capabilities.
        
        Returns: {capability_type: action_name}
        """
        if not self._client:
            logger.warning("No ElizaOS connection — cannot sync")
            return {}

        plugin_names = self._client.get_plugins()
        
        # ElizaOS doesn't expose action details via REST directly,
        # so we register known action patterns.
        # In production, you'd read the agent's registered actions
        # from its runtime state or configuration.
        known_actions = {
            "eliza.continue": "Continue generating",
            "eliza.summarize": "Summarize conversation",
            "eliza.evaluate": "Evaluate context",
            "eliza.respond": "Generate response",
        }
        
        self._capabilities.clear()
        for action_name, description in known_actions.items():
            cap_type = f"eliza.{self._agent_id}.{action_name}"
            self._capabilities[cap_type] = action_name

        logger.info(
            f"Synced {len(self._capabilities)} ElizaOS capabilities "
            f"for agent {self._agent_id}"
        )
        return self._capabilities

    async def handle_intent(self, intent: Any) -> dict:
        """Route a SIMP intent to an ElizaOS agent."""
        if not self._client:
            return {
                "status": "error",
                "error_code": "NO_CONNECTION",
                "error_message": "No ElizaOS agent connected",
            }

        intent_type = intent.intent_type if hasattr(intent, 'intent_type') else ""
        params = intent.params if hasattr(intent, 'params') else {}
        
        # Extract text from params
        text = params.get("text", params.get("prompt", params.get("message", "")))
        if not text:
            text = intent_type  # Use intent type as prompt

        result = self._client.send_message(
            agent_id=self._agent_id,
            text=text,
            room_id=params.get("room_id", "simp"),
        )

        return {
            "status": "success",
            "data": result,
            "agent": self._agent_id,
        }
