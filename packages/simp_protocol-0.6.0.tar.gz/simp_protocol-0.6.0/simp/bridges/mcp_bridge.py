"""
MCP Bridge — Every MCP Server → SIMP Capability with Settlement.

MCP (Model Context Protocol) is the emerging standard for tool servers.
This bridge turns any MCP server into a SIMP-addressable, trust-weighted,
payment-settled capability.

Usage:
    bridge = McpBridge()
    
    # Connect to an MCP server (stdio or SSE)
    await bridge.connect("my-server", "/path/to/mcp-server")
    
    # Now all MCP tools are SIMP capabilities
    intent = Intent(intent_type="mcp_tool", params={"tool": "read_file", "path": "/tmp/test"})
    response = await bridge.handle_intent(intent)
    
    # Settlement happens automatically via SIMP pay
"""

import asyncio
import json
import logging
import os
import subprocess
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Set

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# MCP Tool Schema (mirrors the MCP spec types)
# ---------------------------------------------------------------------------

@dataclass
class McpToolSchema:
    """Schema for an MCP tool."""
    name: str
    description: str = ""
    input_schema: dict = field(default_factory=dict)

    def to_simp_capability(self, server_name: str) -> str:
        """Map MCP tool name → SIMP capability type.
        
        e.g., "read_file" on server "filesystem" → "mcp.filesystem.read_file"
        """
        return f"mcp.{server_name}.{self.name}"


@dataclass
class McpServerInfo:
    """Runtime info about a connected MCP server."""
    name: str
    transport: str  # "stdio" | "sse"
    tools: List[McpToolSchema] = field(default_factory=list)
    resources: List[str] = field(default_factory=list)
    healthy: bool = True
    error_count: int = 0


# ---------------------------------------------------------------------------
# MCP Client (JSON-RPC over stdio or SSE)
# ---------------------------------------------------------------------------

class McpClient:
    """Minimal MCP client that speaks JSON-RPC 2.0 over stdio."""

    def __init__(self, name: str):
        self.name = name
        self._process: Optional[subprocess.Popen] = None
        self._request_id = 0
        self._pending: Dict[int, asyncio.Future] = {}
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None

    async def connect_stdio(self, command: str, args: List[str]) -> None:
        """Connect to an MCP server via stdio."""
        self._process = subprocess.Popen(
            [command] + args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        
        # Create async reader/writer from pipes
        loop = asyncio.get_event_loop()
        self._reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(self._reader)
        await loop.connect_read_pipe(lambda: protocol, self._process.stdout)
        
        self._writer = asyncio.StreamWriter(
            self._process.stdin,
            loop=loop,
        )
        
        # Start background read loop
        asyncio.create_task(self._read_loop())

    async def send_request(self, method: str, params: dict = None) -> dict:
        """Send a JSON-RPC request and await response."""
        self._request_id += 1
        req_id = self._request_id
        
        payload = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
            "params": params or {},
        }
        
        future = asyncio.get_event_loop().create_future()
        self._pending[req_id] = future
        
        line = json.dumps(payload)
        self._writer.write((line + "\n").encode())
        await self._writer.drain()
        
        try:
            return await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            self._pending.pop(req_id, None)
            raise RuntimeError(f"MCP request {method} timed out")

    async def list_tools(self) -> List[McpToolSchema]:
        """Call tools/list and return tool schemas."""
        result = await self.send_request("tools/list")
        tools = result.get("tools", result.get("result", {}).get("tools", []))
        return [
            McpToolSchema(
                name=t["name"],
                description=t.get("description", ""),
                input_schema=t.get("inputSchema", {}),
            )
            for t in tools
        ]

    async def call_tool(self, name: str, arguments: dict) -> dict:
        """Call a tool on the MCP server."""
        result = await self.send_request("tools/call", {
            "name": name,
            "arguments": arguments,
        })
        return result

    async def close(self):
        """Close the MCP connection."""
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()

    async def _read_loop(self):
        """Background task: read JSON-RPC responses from the server."""
        try:
            while self._reader:
                line = await self._reader.readline()
                if not line:
                    break
                
                data = json.loads(line.decode().strip())
                req_id = data.get("id")
                
                if req_id in self._pending:
                    future = self._pending.pop(req_id)
                    if "error" in data:
                        future.set_exception(
                            RuntimeError(data["error"].get("message", "MCP error"))
                        )
                    else:
                        future.set_result(data)
        except Exception as e:
            logger.debug(f"MCP read loop ended for {self.name}: {e}")
            # Fail all pending requests
            for req_id, future in self._pending.items():
                if not future.done():
                    future.set_exception(
                        RuntimeError(f"MCP server disconnected: {e}")
                )


# ---------------------------------------------------------------------------
# MCP Bridge — Registry + Intent Handler
# ---------------------------------------------------------------------------

class McpBridge:
    """Bridge that connects MCP servers as SIMP capabilities.
    
    Features:
      - Auto-discovers tools from connected MCP servers
      - Registers each tool as a SIMP capability
      - Routes intents to the right MCP tool
      - Handles JSON-RPC translation
      - Tracks errors + health per server
      - Integrates with SIMP settlement ($SIMP per tool call)
    """

    def __init__(self, settlement_enabled: bool = True):
        self._servers: Dict[str, McpServerInfo] = {}
        self._clients: Dict[str, McpClient] = {}
        self._capability_index: Dict[str, str] = {}  # cap_type → server_name
        self.settlement_enabled = settlement_enabled
        self._settlement_rates: Dict[str, float] = {}  # cap_type → $SIMP per call

    async def connect(
        self,
        name: str,
        command: str,
        args: Optional[List[str]] = None,
    ) -> List[McpToolSchema]:
        """Connect to an MCP server and discover its tools.
        
        Args:
            name: Server name (used in capability type: mcp.{name}.{tool})
            command: Server executable path
            args: Command-line arguments
            
        Returns: List of discovered tool schemas
        """
        client = McpClient(name)
        await client.connect_stdio(command, args or [])
        
        tools = await client.list_tools()
        
        server_info = McpServerInfo(
            name=name,
            transport="stdio",
            tools=tools,
        )
        
        self._servers[name] = server_info
        self._clients[name] = client
        
        # Index each tool as a SIMP capability
        for tool in tools:
            cap_type = tool.to_simp_capability(name)
            self._capability_index[cap_type] = name
        
        logger.info(
            f"MCP bridge: connected '{name}' with {len(tools)} tools"
        )
        return tools

    def set_settlement_rate(self, cap_type: str, rate: float):
        """Set $SIMP per call for a capability."""
        self._settlement_rates[cap_type] = rate

    def set_server_settlement_rate(self, server_name: str, rate: float):
        """Set $SIMP per call for all tools on a server."""
        server = self._servers.get(server_name)
        if not server:
            raise ValueError(f"Unknown MCP server: {server_name}")
        for tool in server.tools:
            cap_type = tool.to_simp_capability(server_name)
            self._settlement_rates[cap_type] = rate

    async def handle_intent(self, intent: Any) -> dict:
        """Route a SIMP intent to the right MCP tool.
        
        Supports two addressing modes:
          1. Explicit: intent.intent_type == "mcp.server_name.tool_name"
          2. Dynamic: intent.params = {"tool": "tool_name", ...}  
                      + optional "server" field
        """
        intent_type = intent.intent_type if hasattr(intent, 'intent_type') else ""
        params = intent.params if hasattr(intent, 'params') else {}
        
        # Parse capability type to extract server + tool
        if intent_type.startswith("mcp."):
            parts = intent_type.split(".")
            if len(parts) >= 3:
                # mcp.server_name.tool_name
                _, server_name, *tool_parts = parts
                tool_name = ".".join(tool_parts)
            else:
                return {
                    "status": "error",
                    "error_code": "INVALID_CAPABILITY",
                    "error_message": f"Invalid MCP capability: {intent_type}",
                }
        else:
            # Extract from params
            tool_name = params.get("tool", "")
            server_name = params.get("server", "")
        
        if not server_name:
            # Find server by capability type
            server_name = self._capability_index.get(intent_type, "")
        
        if not server_name or server_name not in self._clients:
            return {
                "status": "error",
                "error_code": "SERVER_NOT_FOUND",
                "error_message": f"No MCP server found for '{server_name}'",
            }
        
        client = self._clients[server_name]
        
        # Extract tool arguments from params (everything except tool/server)
        tool_args = {
            k: v for k, v in params.items()
            if k not in ("tool", "server", "_settlement")
        }
        
        try:
            result = await client.call_tool(tool_name, tool_args)
            
            # Record settlement if enabled
            cap_type = f"mcp.{server_name}.{tool_name}"
            if self.settlement_enabled and cap_type in self._settlement_rates:
                await self._record_settlement(cap_type)
            
            # Extract content from MCP response
            content = result.get("result", {}).get("content", [])
            text_parts = [
                c.get("text", "") for c in content
                if c.get("type") == "text"
            ]
            
            return {
                "status": "success",
                "data": {
                    "content": content,
                    "text": "\n".join(text_parts),
                },
                "server": server_name,
                "tool": tool_name,
            }
            
        except Exception as e:
            logger.warning(f"MCP tool call failed: {server_name}/{tool_name}: {e}")
            self._servers[server_name].error_count += 1
            return {
                "status": "error",
                "error_code": "TOOL_CALL_FAILED",
                "error_message": str(e),
                "server": server_name,
                "tool": tool_name,
            }

    async def _record_settlement(self, cap_type: str):
        """Record a $SIMP settlement for a capability call.
        
        Integrates with simp.payments.simp_pay if available.
        """
        rate = self._settlement_rates.get(cap_type, 0.01)  # default 0.01 SIMP
        
        try:
            from simp.payments.simp_pay import get_simp_pay
            pay = get_simp_pay()
            await pay.record_micropayment(
                recipient=cap_type,
                amount=rate,
                reason=f"MCP tool call: {cap_type}",
            )
        except ImportError:
            logger.debug("SIMP pay not available — settlement skipped")
        except Exception as e:
            logger.debug(f"Settlement failed: {e}")

    def list_capabilities(self) -> Dict[str, dict]:
        """List all registered MCP capabilities."""
        caps = {}
        for name, server in self._servers.items():
            for tool in server.tools:
                cap_type = tool.to_simp_capability(name)
                caps[cap_type] = {
                    "server": name,
                    "tool": tool.name,
                    "description": tool.description,
                    "settlement_rate": self._settlement_rates.get(cap_type, 0),
                }
        return caps

    def server_status(self) -> Dict[str, dict]:
        """Status of all connected MCP servers."""
        return {
            name: {
                "tools": len(server.tools),
                "healthy": server.healthy,
                "errors": server.error_count,
                "transport": server.transport,
            }
            for name, server in self._servers.items()
        }

    async def disconnect_all(self):
        """Disconnect all MCP servers."""
        for name, client in self._clients.items():
            await client.close()
        self._servers.clear()
        self._clients.clear()
        self._capability_index.clear()
