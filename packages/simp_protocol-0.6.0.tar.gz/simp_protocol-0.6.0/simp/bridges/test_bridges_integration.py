"""
Integration Tests — All Bridges Working Together.

Tests that the HF Space bridge, MCP bridge, and plugin system
can be loaded, register capabilities, and route intents.

Run: python -m pytest tests/test_bridges_integration.py -v
"""

import json
import unittest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from dataclasses import dataclass, field
from typing import Dict, Any


# Mock SIMP types for testing
@dataclass
class MockIntent:
    intent_type: str
    params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MockResponse:
    status: str = "success"
    data: dict = field(default_factory=dict)
    error_code: str = ""
    error_message: str = ""


class TestHfSpaceBridge(unittest.TestCase):
    """Test HF Space Bridge — discovery + intent routing."""

    def setUp(self):
        # Don't import real bridge — use patched version
        self.hf_api_patcher = patch("urllib.request.urlopen")
        self.mock_urlopen = self.hf_api_patcher.start()

    def tearDown(self):
        self.hf_api_patcher.stop()

    def _mock_hf_response(self, data: list):
        """Create a mock HF API response."""
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(data).encode()
        mock_resp.__enter__.return_value = mock_resp
        self.mock_urlopen.return_value = mock_resp

    def test_discover_spaces_by_tag(self):
        """Test discovering HF Spaces by pipeline tag."""
        from simp.bridges.hf_space import HfHubClient, HfSpaceInfo

        self._mock_hf_response([
            {
                "id": "google/gemma-2-2b-it",
                "sdk": "gradio",
                "pipeline_tag": "text-generation",
                "cardData": {"tags": ["llm", "conversational"]},
                "likes": 1500,
                "private": False,
            },
            {
                "id": "black-forest-labs/FLUX.1-dev",
                "sdk": "gradio",
                "pipeline_tag": "text-to-image",
                "cardData": {"tags": ["image-generation"]},
                "likes": 5000,
                "private": False,
            },
        ])

        client = HfHubClient()
        spaces = client.search_spaces(tag="text-generation", limit=10)

        self.assertEqual(len(spaces), 1)
        self.assertEqual(spaces[0].id, "google/gemma-2-2b-it")
        self.assertEqual(spaces[0].simp_capability_type, "hf_text_generation")

    def test_capability_type_mapping(self):
        """Test HF pipeline tags → SIMP capability types."""
        from simp.bridges.hf_space import HfSpaceInfo

        test_cases = [
            ("text-generation", "hf_text_generation"),
            ("text-to-image", "hf_image_generation"),
            ("conversational", "hf_conversational"),
            ("summarization", "hf_summarization"),
            ("feature-extraction", "hf_embedding"),
            ("unknown-tag", "hf_gradio_app"),       # gradio SDK takes priority
        ]

        for pipeline_tag, expected_cap in test_cases:
            info = HfSpaceInfo(
                id="test/space",
                sdk="gradio",
                pipeline_tag=pipeline_tag,
            )
            self.assertEqual(info.simp_capability_type, expected_cap)

    def test_bridge_registers_spaces(self):
        """Test full bridge registration flow."""
        from simp.bridges.hf_space import HfSpaceBridge

        # Mock the Hub client within the bridge
        with patch.object(HfSpaceBridge, "_discover_popular", return_value=None):
            bridge = HfSpaceBridge(auto_discover=False)
            
            # Mock get_space
            bridge.hub.get_space = MagicMock(return_value={
                "id": "test/model",
                "sdk": "gradio", 
                "pipeline_tag": "text-generation",
                "cardData": {"tags": []},
                "likes": 100,
                "private": False,
            })
            
            # Manually wrap in HfSpaceInfo
            from simp.bridges.hf_space import HfSpaceInfo
            bridge.hub.get_space = MagicMock(return_value=HfSpaceInfo(
                id="test/model",
                sdk="gradio",
                pipeline_tag="text-generation",
                tags=[],
                likes=100,
                private=False,
            ))

            cap_type = bridge.register_space("test/model")
            self.assertEqual(cap_type, "hf_text_generation")
            self.assertEqual(bridge.registered_count, 1)

    def test_gradio_intent_routing(self):
        """Test routing an intent to a Gradio Space."""
        import asyncio
        from simp.bridges.hf_space import HfSpaceAdapter, HfSpaceInfo

        info = HfSpaceInfo(
            id="test/gradio-space",
            sdk="gradio",
            pipeline_tag="text-generation",
        )
        adapter = HfSpaceAdapter(info)

        # Mock the Gradio API call
        with patch("urllib.request.urlopen") as mock_call:
            mock_resp = MagicMock()
            mock_resp.read.return_value = json.dumps({
                "data": ["Hello! How can I help you?"]
            }).encode()
            mock_resp.__enter__.return_value = mock_resp
            mock_call.return_value = mock_resp

            intent = MockIntent(
                intent_type="hf_text_generation",
                params={"prompt": "Hi there!"},
            )
            result = asyncio.run(adapter.handle_intent(intent))

            self.assertEqual(result["status"], "success")
            self.assertEqual(result["space_id"], "test/gradio-space")


class TestMcpBridge(unittest.TestCase):
    """Test MCP Bridge — tool discovery + intent routing."""

    def test_mcp_tool_capability_mapping(self):
        """Test MCP tool names → SIMP capability types."""
        from simp.bridges.mcp_bridge import McpToolSchema

        tool = McpToolSchema(name="read_file", description="Read a file")
        cap_type = tool.to_simp_capability("filesystem")
        self.assertEqual(cap_type, "mcp.filesystem.read_file")

    def test_intent_routing_to_mcp_tool(self):
        """Test routing an intent to a specific MCP tool."""
        from simp.bridges.mcp_bridge import McpBridge, McpServerInfo, McpToolSchema

        bridge = McpBridge()

        # Simulate a connected server
        bridge._servers["filesystem"] = McpServerInfo(
            name="filesystem",
            transport="stdio",
            tools=[McpToolSchema(name="read_file", description="Read a file")],
        )
        bridge._capability_index["mcp.filesystem.read_file"] = "filesystem"

        # Mock client (async call_tool with call tracking)
        mock_client = MagicMock()
        mock_client.call_tool = AsyncMock(return_value={
            "result": {
                "content": [{"type": "text", "text": "file contents here"}]
            }
        })
        bridge._clients["filesystem"] = mock_client

        intent = MockIntent(
            intent_type="mcp.filesystem.read_file",
            params={"path": "/tmp/test.txt"},
        )
        
        import asyncio
        result = asyncio.run(bridge.handle_intent(intent))

        self.assertEqual(result["status"], "success")
        self.assertEqual(result["data"]["text"], "file contents here")
        mock_client.call_tool.assert_called_once_with(
            "read_file", {"path": "/tmp/test.txt"}
        )


class TestPluginSystem(unittest.TestCase):
    """Test the plugin system hooks."""

    def test_plugin_registration(self):
        """Test registering a plugin and verifying hooks."""
        from simp.plugins import PluginABC, plugin_registry

        class TestPlugin(PluginABC):
            name = "test-plugin"
            version = "1.0.0"
            
            def __init__(self):
                self.intents_seen = []
                
            async def on_intent(self, intent):
                self.intents_seen.append(intent)
                return intent

        # Reset registry
        plugin_registry._plugins.clear()
        plugin_registry._intent_hooks.clear()
        
        plugin = TestPlugin()
        plugin_registry.register(plugin)
        
        self.assertEqual(len(plugin_registry.plugins), 1)

    def test_intent_pipeline(self):
        """Test intent flowing through plugin hooks."""
        from simp.plugins import PluginABC, plugin_registry

        class LogPlugin(PluginABC):
            name = "log-plugin"
            
            def __init__(self):
                self.seen = []
                
            async def on_intent(self, intent):
                self.seen.append(intent.intent_type)
                return intent

        class BlockPlugin(PluginABC):
            name = "block-plugin"
            
            async def on_intent(self, intent):
                if intent.intent_type == "blocked":
                    return None  # Reject
                return intent

        # Reset
        plugin_registry._plugins.clear()
        plugin_registry._intent_hooks.clear()
        
        log_plugin = LogPlugin()
        block_plugin = BlockPlugin()
        plugin_registry.register(log_plugin)
        plugin_registry.register(block_plugin)

        import asyncio

        # Test allowed intent
        intent = MockIntent(intent_type="allowed", params={})
        result = asyncio.run(plugin_registry.process_intent(intent))
        self.assertIsNotNone(result)
        self.assertIn("allowed", log_plugin.seen)

        # Test blocked intent
        blocked = MockIntent(intent_type="blocked", params={})
        result = asyncio.run(plugin_registry.process_intent(blocked))
        self.assertIsNone(result)


class TestSessionManager(unittest.TestCase):
    """Test the two-DB session polling pattern."""

    def setUp(self):
        import tempfile
        self.temp_dir = tempfile.mkdtemp()

    def tearDown(self):
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_session_creation(self):
        """Test creating a session with inbound/outbound DBs."""
        from simp.agent.session import Session, SessionConfig

        config = SessionConfig(base_dir=self.temp_dir)
        session = Session(
            agent_group_id="test-agent",
            session_id="test-session-1",
            config=config,
        )
        session.open()

        # Verify DB files created
        import os
        self.assertTrue(os.path.exists(session.inbound._db_path))
        self.assertTrue(os.path.exists(session.outbound._db_path))

        session.close()

    def test_write_and_read_intent(self):
        """Test writing an intent to inbound DB and reading it."""
        from simp.agent.session import Session, SessionConfig
        import json

        config = SessionConfig(base_dir=self.temp_dir)
        session = Session(
            agent_group_id="test-agent",
            session_id="test-session-2",
            config=config,
        )
        session.open()

        # Simulate broker writing an intent to inbound DB
        session.inbound._conn.execute(
            """INSERT INTO messages_in (id, intent_id, capability, params_json, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            ("msg-1", "intent-1", "hf_text_generation",
             json.dumps({"prompt": "Hello"}), "2025-01-01T00:00:00"),
        )
        session.inbound._conn.commit()

        # Agent reads pending intents
        pending = session.inbound.get_pending()
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]["capability"], "hf_text_generation")

        # Agent processes and writes response
        response_id = session.outbound.write_response(
            intent_id="intent-1",
            result={"text": "Hello back!"},
        )
        self.assertIsNotNone(response_id)

        session.close()

    def test_heartbeat(self):
        """Test heartbeat file touch."""
        from simp.agent.session import Session, SessionConfig
        import os

        config = SessionConfig(base_dir=self.temp_dir)
        session = Session(
            agent_group_id="test-agent",
            session_id="test-session-3",
            config=config,
        )
        session.open()

        session.touch_heartbeat()
        self.assertTrue(os.path.exists(session.heartbeat_path))

        session.close()


if __name__ == "__main__":
    unittest.main()
