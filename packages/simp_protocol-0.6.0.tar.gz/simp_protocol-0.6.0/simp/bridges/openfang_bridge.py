"""
OpenFang Bridge — SIMP ↔ OpenFang Agent OS Connector.

OpenFang (17k⭐ on GitHub) is an open-source Agent Operating System built in Rust.
It compiles to a single ~32MB binary with 7 autonomous Hands, 40 channel adapters,
16 security systems, and 53 built-in tools.

This bridge makes any OpenFang instance a first-class SIMP participant:

    ┌─────────────┐     ┌──────────────┐     ┌─────────────┐
    │  SIMP       │────▶│  OpenFang    │────▶│  Hands      │
    │  Broker     │     │  Bridge      │     │  (Lead,     │
    │             │◀────│  (this)      │◀────│   Research…)│
    └─────────────┘     └──────────────┘     └─────────────┘

SIMP gains from OpenFang:
    • 16 security systems (WASM sandbox, taint tracking, Ed25519 manifests)
    • 40 channel adapters (Telegram, Discord, WhatsApp, etc.)
    • 7 autonomous Hands (Lead, Collector, Researcher, Predictor, etc.)
    • 53 built-in tools + MCP + A2A support
    • Merkle hash-chain audit trails
    • Agent sandbox with fuel metering

OpenFang gains from SIMP:
    • Global capability registry (discover agents across networks)
    • Trust-weighted routing (BRP scores)
    • Cryptographically verified Ed25519 identity
    • Native $SIMP payment settlement
    • Cross-ecosystem intent routing
"""

import json
import logging
import asyncio
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


@dataclass
class OpenFangHand:
    """An OpenFang Hand (autonomous capability package)."""
    name: str
    description: str
    simd_capabilities: List[str]  # mapped to SIMP intent types
    requires_approval: bool = False

    def to_capability(self) -> Dict[str, Any]:
        return {
            "name": f"openfang-hand-{self.name.lower()}",
            "description": self.description,
            "hand": self.name,
            "simd_capabilities": self.simd_capabilities,
            "requires_approval": self.requires_approval,
            "trust_level": "high" if not self.requires_approval else "medium",
        }


# The 7 bundled OpenFang Hands mapped to SIMP capability types
_BUNDLED_HANDS = {
    "clip": OpenFangHand(
        name="clip",
        description="YouTube video to vertical shorts pipeline with captions and thumbnails",
        simd_capabilities=["media_processing", "video_editing", "content_publishing"],
        requires_approval=True,
    ),
    "lead": OpenFangHand(
        name="lead",
        description="Daily lead generation with ICP matching, enrichment, scoring 0-100",
        simd_capabilities=["lead_generation", "data_enrichment", "scoring"],
        requires_approval=False,
    ),
    "collector": OpenFangHand(
        name="collector",
        description="OSINT-grade intelligence monitoring with change detection and knowledge graphs",
        simd_capabilities=["intelligence_gathering", "monitoring", "threat_detection"],
        requires_approval=False,
    ),
    "predictor": OpenFangHand(
        name="predictor",
        description="Superforecasting engine with Brier scores and contrarian mode",
        simd_capabilities=["forecasting", "prediction", "signal_analysis"],
        requires_approval=False,
    ),
    "researcher": OpenFangHand(
        name="researcher",
        description="Deep autonomous research with CRAAP credibility evaluation",
        simd_capabilities=["research", "analysis", "fact_checking"],
        requires_approval=False,
    ),
    "twitter": OpenFangHand(
        name="twitter",
        description="Autonomous Twitter/X account manager with 7 content formats",
        simd_capabilities=["social_media", "content_generation", "engagement"],
        requires_approval=True,
    ),
    "browser": OpenFangHand(
        name="browser",
        description="Web automation agent with Playwright bridge and purchase approval gate",
        simd_capabilities=["web_automation", "data_collection", "form_filling"],
        requires_approval=True,
    ),
}


class OpenFangBridge:
    """Bridge between SIMP broker and an OpenFang instance.
    
    Connects to OpenFang's REST API at localhost:4200 (default)
    and registers Hands as SIMP capabilities.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:4200",
        api_key: Optional[str] = None,
        openfang_id: str = "openfang-default",
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.openfang_id = openfang_id
        self._session: Optional[Any] = None
        self._hands: Dict[str, OpenFangHand] = dict(_BUNDLED_HANDS)
        self._registered_capabilities: List[Dict[str, Any]] = []

    def discover_capabilities(self) -> List[Dict[str, Any]]:
        """Discover all OpenFang capabilities as SIMP capability records (sync)."""
        capabilities = []

        for hand_name, hand in self._hands.items():
            cap = hand.to_capability()
            cap["agent_id"] = self.openfang_id
            cap["ecosystem"] = "openfang"
            cap["transport"] = "rest"
            cap["endpoint"] = f"{self.base_url}/v1/hands/{hand_name}/invoke"
            capabilities.append(cap)

        self._registered_capabilities = capabilities
        return capabilities

    async def route_intent(self, intent_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Route a SIMP intent to the matching OpenFang Hand.
        
        Args:
            intent_type: SIMP intent type (e.g., "research", "lead_generation")
            payload: Intent parameters
            
        Returns:
            OpenFang Hand response
        """
        # Find the best Hand for this intent type
        hand = self._find_best_hand(intent_type)
        if not hand:
            return {"error": f"No OpenFang Hand available for intent: {intent_type}"}

        try:
            response = await self._call_hand(hand.name, payload)
            return {
                "status": "success",
                "hand": hand.name,
                "data": response,
                "ecosystem": "openfang",
            }
        except Exception as e:
            logger.error(f"OpenFang hand '{hand.name}' failed: {e}")
            return {"error": str(e), "hand": hand.name}

    def _find_best_hand(self, intent_type: str) -> Optional[OpenFangHand]:
        """Find the best OpenFang Hand for an intent type."""
        # Direct match
        for hand in self._hands.values():
            if intent_type in hand.simd_capabilities:
                return hand

        # Partial match
        intent_parts = intent_type.lower().replace("-", "_").split("_")
        for hand in self._hands.values():
            for cap in hand.simd_capabilities:
                cap_parts = cap.lower().replace("-", "_").split("_")
                if any(p in cap_parts for p in intent_parts):
                    return hand

        return None

    async def _call_hand(self, hand_name: str, payload: Dict[str, Any]) -> Any:
        """Call an OpenFang Hand via its REST API.
        
        Falls back to OpenAI-compatible chat API if direct hand endpoint unavailable.
        """
        import aiohttp

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        hand_endpoint = f"{self.base_url}/v1/hands/{hand_name}/invoke"

        async with aiohttp.ClientSession(headers=headers) as session:
            try:
                async with session.post(hand_endpoint, json=payload, timeout=30) as resp:
                    if resp.status == 200:
                        return await resp.json()
                    else:
                        logger.warning(f"OpenFang hand endpoint returned {resp.status}, falling back")
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                logger.warning(f"OpenFang hand endpoint unreachable: {e}, falling back")

            # Fallback: try OpenAI-compatible chat API
            chat_endpoint = f"{self.base_url}/v1/chat/completions"
            chat_payload = {
                "model": hand_name,
                "messages": [{"role": "user", "content": json.dumps(payload)}],
                "stream": False,
            }
            async with session.post(chat_endpoint, json=chat_payload, timeout=60) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return {
                        "model": hand_name,
                        "response": data.get("choices", [{}])[0]
                            .get("message", {})
                            .get("content", ""),
                    }
                else:
                    error_text = await resp.text()
                    raise ConnectionError(
                        f"OpenFang API error: {resp.status} - {error_text}"
                    )

    async def health_check(self) -> Dict[str, Any]:
        """Check if the OpenFang instance is healthy."""
        import aiohttp

        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        async with aiohttp.ClientSession(headers=headers) as session:
            try:
                async with session.get(f"{self.base_url}/health", timeout=5) as resp:
                    return {
                        "connected": resp.status == 200,
                        "status_code": resp.status,
                        "openfang_id": self.openfang_id,
                        "hands_available": list(self._hands.keys()),
                    }
            except Exception as e:
                return {
                    "connected": False,
                    "error": str(e),
                    "openfang_id": self.openfang_id,
                }

    def get_absorbed_security_systems(self) -> List[Dict[str, Any]]:
        """Return OpenFang's 16 security systems as SIMP-absorbed capabilities.
        
        These are the defense mechanisms we can offer SIMP agents
        through the OpenFang bridge.
        """
        return [
            {"name": "wasm_dual_metered_sandbox", "description": "WASM sandbox with fuel metering + epoch interruption"},
            {"name": "merkle_hash_chain_audit", "description": "Cryptographically linked audit trail"},
            {"name": "information_flow_taint_tracking", "description": "Secret propagation tracking from source to sink"},
            {"name": "ed25519_signed_manifests", "description": "Cryptographically signed agent identity"},
            {"name": "ssrf_protection", "description": "Private IP and cloud metadata endpoint blocking"},
            {"name": "secret_zeroization", "description": "Auto-wipe API keys from memory on release"},
            {"name": "ofp_mutual_authentication", "description": "HMAC-SHA256 nonce-based P2P auth"},
            {"name": "capability_gates", "description": "Role-based access control for agent capabilities"},
            {"name": "security_headers", "description": "CSP, HSTS, XFO, X-Content-Type-Options"},
            {"name": "health_endpoint_redaction", "description": "Minimal public health checks"},
            {"name": "subprocess_sandbox", "description": "env_clear() + selective variable passthrough"},
            {"name": "prompt_injection_scanner", "description": "Override, exfil, and injection detection"},
            {"name": "loop_guard", "description": "SHA256-based tool call loop detection with circuit breaker"},
            {"name": "session_repair", "description": "7-phase message history validation and recovery"},
            {"name": "path_traversal_prevention", "description": "Canonicalization with symlink escape prevention"},
            {"name": "gcra_rate_limiter", "description": "Cost-aware token bucket with per-IP tracking"},
        ]

    def get_absorbed_channel_adapters(self) -> List[str]:
        """Return OpenFang's 40 channel adapters."""
        return [
            "Telegram", "Discord", "Slack", "WhatsApp", "Signal", "Matrix", "Email",
            "Microsoft Teams", "Mattermost", "Google Chat", "Webex", "Feishu/Lark", "Zulip",
            "LINE", "Viber", "Facebook Messenger", "Mastodon", "Bluesky", "Reddit",
            "LinkedIn", "Twitch", "IRC", "XMPP", "Guilded", "Revolt", "Keybase",
            "Discourse", "Gitter", "Threema", "Nostr", "Mumble", "Nextcloud Talk",
            "Rocket.Chat", "Ntfy", "Gotify", "Pumble", "Flock", "Twist", "DingTalk", "Zalo",
        ]


# ===========================================
# Integration with Absorption Automaton
# ===========================================
# The following function is registered with the automaton to
# ensure OpenFang is always absorbed when discovered.

def get_openfang_absorption_fingerprint() -> Dict[str, Any]:
    """Return the ecosystem fingerprint for the Absorption Automaton."""
    return {
        "name": "openfang",
        "source": "github",
        "source_url": "https://github.com/RightNow-AI/openfang",
        "capability_types": ["sandbox", "agent_spawn", "tool_execution",
                             "lead_generation", "research", "forecasting",
                             "media_processing", "web_automation",
                             "social_media", "intelligence_gathering"],
        "transport": "rest",
        "auth_type": "api_key",
        "stars": 17131,
        "adoption_signal": 0.85,
        "security_systems": 16,
        "channel_adapters": 40,
        "built_in_tools": 53,
        "bridge_complexity": "medium",  # Well-defined REST API
        "bridge_file": "simp/bridges/openfang_bridge.py",
    }
