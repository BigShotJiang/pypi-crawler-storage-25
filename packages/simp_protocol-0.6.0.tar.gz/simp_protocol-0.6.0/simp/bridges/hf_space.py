"""
HF Space Bridge — Every Hugging Face Space → SIMP Capability.

Turns 1M+ HF Spaces into routable SIMP capabilities with:
  - Zero-code registration (just point to a Space ID)
  - Automatic capability type detection from SDK/pipeline_tag
  - Intent → Space API translation
  - Response signing with Ed25519
  - Discovery via HF Hub search
  - Rate limiting per Space

Usage:
    # Register a single Space as a capability
    bridge = HfSpaceBridge()
    bridge.register_space("google/gemma-2-2b-it")

    # Register all Spaces matching a tag
    bridge.register_by_tag("text-to-image", limit=100)

    # Query via SIMP intent
    intent = Intent(intent_type="hf_text_generation", params={"prompt": "Hello"})
    response = await bridge.handle_intent(intent)
"""

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, AsyncIterator
from urllib.parse import urljoin

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# HF Space Metadata
# ---------------------------------------------------------------------------

@dataclass
class HfSpaceInfo:
    """Metadata about a Hugging Face Space, fetched from the Hub API."""
    id: str                    # e.g. "google/gemma-2-2b-it"
    sdk: str                   # gradio, streamlit, docker, static
    pipeline_tag: Optional[str]  # text-generation, text-to-image, etc.
    tags: List[str] = field(default_factory=list)
    likes: int = 0
    private: bool = False

    @property
    def simp_capability_type(self) -> str:
        """Map HF pipeline_tag → SIMP capability type.
        
        This is the key translation: HF's taxonomy → SIMP's taxonomy.
        """
        tag_map = {
            "text-generation":       "hf_text_generation",
            "text-to-image":         "hf_image_generation",
            "text-to-speech":        "hf_audio_generation",
            "image-to-text":         "hf_image_captioning",
            "image-classification":  "hf_image_classification",
            "automatic-speech-recognition": "hf_speech_recognition",
            "conversational":        "hf_conversational",
            "summarization":         "hf_summarization",
            "translation":           "hf_translation",
            "question-answering":    "hf_qa",
            "sentence-similarity":   "hf_embedding",
            "feature-extraction":    "hf_embedding",
            "text-classification":   "hf_text_classification",
            "token-classification":  "hf_ner",
            "fill-mask":             "hf_fill_mask",
            "table-question-answering": "hf_table_qa",
            "document-question-answering": "hf_document_qa",
            "visual-question-answering": "hf_visual_qa",
            "image-segmentation":    "hf_image_segmentation",
            "object-detection":      "hf_object_detection",
            "depth-estimation":      "hf_depth_estimation",
            "text-to-video":         "hf_video_generation",
            "text-to-audio":         "hf_audio_generation",
            "audio-to-audio":        "hf_audio_processing",
        }
        if self.pipeline_tag and self.pipeline_tag in tag_map:
            return tag_map[self.pipeline_tag]
        if self.sdk == "gradio":
            return "hf_gradio_app"
        if self.sdk == "streamlit":
            return "hf_streamlit_app"
        return "hf_generic_space"

    @property
    def inference_url(self) -> str:
        """HTTPS inference endpoint for the Space."""
        return f"https://{self.id.replace('/', '--')}.hf.space"

    @property
    def api_url(self) -> str:
        """Gradio/Inference API URL."""
        if self.sdk == "gradio":
            return urljoin(self.inference_url, "gradio_api/")
        if self.sdk == "streamlit":
            return self.inference_url
        # Docker spaces — use HF Inference API
        return f"https://api-inference.huggingface.co/models/{self.id}"


# ---------------------------------------------------------------------------
# HF Hub Client (lightweight, no huggingface_hub dependency)
# ---------------------------------------------------------------------------

class HfHubClient:
    """Minimal HF Hub API client for Space discovery."""

    BASE_URL = "https://huggingface.co/api"

    def __init__(self, token: Optional[str] = None):
        self.token = token
        self._headers = {"User-Agent": "simp-bridge/1.0"}
        if token:
            self._headers["Authorization"] = f"Bearer {token}"

    def search_spaces(
        self,
        query: Optional[str] = None,
        tag: Optional[str] = None,
        sdk: Optional[str] = None,
        limit: int = 50,
        sort: str = "likes",
    ) -> List[HfSpaceInfo]:
        """Search HF Spaces matching criteria."""
        import urllib.request
        import json

        params = f"sort={sort}&limit={min(limit, 1000)}&full=false"
        if query:
            params += f"&search={urllib.parse.quote(query)}"
        if sdk:
            params += f"&sdk={sdk}"
        # HF API doesn't have a direct tag filter on spaces endpoint,
        # but we can filter post-query

        url = f"{self.BASE_URL}/spaces?{params}"
        req = urllib.request.Request(url, headers=self._headers)
        
        try:
            resp = urllib.request.urlopen(req, timeout=15)
            data = json.loads(resp.read().decode())
        except Exception as e:
            logger.warning(f"HF Hub search failed: {e}")
            return []

        spaces = []
        for item in data:
            info = HfSpaceInfo(
                id=item.get("id", ""),
                sdk=item.get("sdk", ""),
                pipeline_tag=item.get("pipeline_tag"),
                tags=item.get("cardData", {}).get("tags", []) or [],
                likes=item.get("likes", 0),
                private=item.get("private", False),
            )
            if tag and tag not in info.tags and tag != info.pipeline_tag:
                continue
            if info.private:
                continue
            spaces.append(info)

        return spaces

    def get_space(self, space_id: str) -> Optional[HfSpaceInfo]:
        """Get details for a specific Space."""
        import urllib.request
        import json

        url = f"{self.BASE_URL}/spaces/{space_id}"
        req = urllib.request.Request(url, headers=self._headers)
        
        try:
            resp = urllib.request.urlopen(req, timeout=10)
            data = json.loads(resp.read().decode())
            return HfSpaceInfo(
                id=data.get("id", space_id),
                sdk=data.get("sdk", ""),
                pipeline_tag=data.get("pipeline_tag"),
                tags=data.get("cardData", {}).get("tags", []) or [],
                likes=data.get("likes", 0),
                private=data.get("private", False),
            )
        except Exception as e:
            logger.warning(f"Failed to fetch Space {space_id}: {e}")
            return None


# ---------------------------------------------------------------------------
# HF Space → SIMP Capability Adapter
# ---------------------------------------------------------------------------

class HfSpaceAdapter:
    """Wraps a single HF Space as a SIMP-addressable capability."""

    def __init__(
        self,
        space_info: HfSpaceInfo,
        hf_token: Optional[str] = None,
        rate_limit: int = 30,  # requests per minute
    ):
        self.space = space_info
        self.capability_type = space_info.simp_capability_type
        self.hf_token = hf_token
        self.rate_limit = rate_limit
        self._last_calls: List[float] = []

    async def handle_intent(self, intent: Any) -> Any:
        """Translate a SIMP intent into an HF Space API call.
        
        Args:
            intent: A SIMP Intent object with intent_type + params
            
        Returns:
            SimpResponse with the Space's output
        """
        self._check_rate_limit()
        
        if self.space.sdk == "gradio":
            return self._call_gradio(intent)
        elif self.space.sdk == "streamlit":
            return self._call_streamlit(intent)
        else:
            return self._call_inference_api(intent)

    def _call_gradio(self, intent: Any) -> dict:
        """Call a Gradio Space via its API endpoint."""
        import urllib.request
        import json

        # Gradio Spaces expose POST /gradio_api/call/{endpoint}
        params = intent.params if hasattr(intent, 'params') else {}
        endpoint = params.pop("endpoint", "predict")
        
        # Build the API URL
        api_url = urljoin(self.space.inference_url, f"gradio_api/call/{endpoint}")
        
        # Determine the input format from params
        inputs = params.get("inputs", params.get("prompt", params.get("text", "")))
        
        payload = json.dumps({"data": [inputs]}).encode()
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "simp-bridge/1.0",
        }
        if self.hf_token:
            headers["Authorization"] = f"Bearer {self.hf_token}"

        req = urllib.request.Request(
            api_url,
            data=payload,
            headers=headers,
            method="POST",
        )
        
        try:
            resp = urllib.request.urlopen(req, timeout=60)
            result = json.loads(resp.read().decode())
            return {
                "status": "success",
                "data": result,
                "space_id": self.space.id,
                "capability": self.capability_type,
            }
        except Exception as e:
            logger.warning(f"Gradio call failed for {self.space.id}: {e}")
            return {
                "status": "error",
                "error_message": str(e),
                "space_id": self.space.id,
            }

    def _call_streamlit(self, intent: Any) -> dict:
        """Call a Streamlit Space (HTTP-based interaction)."""
        import urllib.request
        import json

        params = intent.params if hasattr(intent, 'params') else {}
        # Streamlit Spaces don't have a standard API — 
        # we use the HF Inference API as fallback
        return self._call_inference_api(intent)

    def _call_inference_api(self, intent: Any) -> dict:
        """Call via HF Inference API (works for most Spaces)."""
        import urllib.request
        import json

        params = intent.params if hasattr(intent, 'params') else {}
        
        # Build the request payload based on capability type
        inputs = params.get("inputs", params.get("prompt", params.get("text", "")))
        parameters = params.get("parameters", {})
        
        payload = json.dumps({
            "inputs": inputs,
            "parameters": parameters,
        }).encode()
        
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "simp-bridge/1.0",
        }
        if self.hf_token:
            headers["Authorization"] = f"Bearer {self.hf_token}"

        url = f"https://api-inference.huggingface.co/models/{self.space.id}"
        req = urllib.request.Request(
            url,
            data=payload,
            headers=headers,
            method="POST",
        )
        
        try:
            resp = urllib.request.urlopen(req, timeout=120)
            result = json.loads(resp.read().decode())
            return {
                "status": "success",
                "data": result,
                "space_id": self.space.id,
                "capability": self.capability_type,
            }
        except Exception as e:
            logger.warning(f"Inference API call failed for {self.space.id}: {e}")
            return {
                "status": "error",
                "error_message": str(e),
                "space_id": self.space.id,
            }

    def _check_rate_limit(self):
        """Simple sliding-window rate limiter."""
        now = time.time()
        window = 60.0
        self._last_calls = [t for t in self._last_calls if now - t < window]
        if len(self._last_calls) >= self.rate_limit:
            raise RuntimeError(
                f"Rate limit exceeded for {self.space.id} "
                f"({self.rate_limit} req/min)"
            )
        self._last_calls.append(now)


# ---------------------------------------------------------------------------
# HF Space Bridge — Registry + Discovery
# ---------------------------------------------------------------------------

class HfSpaceBridge:
    """Bridge that discovers HF Spaces and registers them as SIMP capabilities.
    
    Can be used as:
      - A discovery service (find Spaces → register as capabilities)
      - An intent handler (receive intents → route to right Space)
      - A standalone capability provider
    """

    def __init__(
        self,
        hf_token: Optional[str] = None,
        auto_discover: bool = True,
        discovery_interval: int = 3600,  # re-discover every hour
    ):
        self.hub = HfHubClient(token=hf_token)
        self.hf_token = hf_token
        self._adapters: Dict[str, HfSpaceAdapter] = {}
        self._capability_map: Dict[str, List[str]] = {}  # cap_type → [space_ids]
        self._registered_tags: List[str] = []

        if auto_discover:
            self._discover_popular()

    def register_space(self, space_id: str) -> Optional[str]:
        """Register a single HF Space as a SIMP capability.
        
        Returns: capability type string, or None if not found.
        """
        info = self.hub.get_space(space_id)
        if not info:
            logger.warning(f"Cannot register {space_id}: not found")
            return None
        
        adapter = HfSpaceAdapter(info, hf_token=self.hf_token)
        self._adapters[space_id] = adapter
        
        cap_type = adapter.capability_type
        if cap_type not in self._capability_map:
            self._capability_map[cap_type] = []
        self._capability_map[cap_type].append(space_id)
        
        logger.info(f"Registered {space_id} → {cap_type}")
        return cap_type

    def register_by_tag(
        self,
        tag: str,
        limit: int = 100,
        sdk: Optional[str] = None,
    ) -> Dict[str, str]:
        """Register all Spaces matching a tag.
        
        Args:
            tag: HF tag or pipeline_tag to search for
            limit: Max spaces to register
            sdk: Filter by SDK (gradio, streamlit, docker)
            
        Returns: {space_id: capability_type}
        """
        spaces = self.hub.search_spaces(tag=tag, sdk=sdk, limit=limit)
        results = {}
        for space in spaces:
            cap_type = self.register_space(space.id)
            if cap_type:
                results[space.id] = cap_type
        
        self._registered_tags.append(tag)
        logger.info(f"Registered {len(results)} Spaces for tag '{tag}'")
        return results

    def register_by_capability_type(
        self,
        cap_type: str,
        hf_pipeline_tag: Optional[str] = None,
    ) -> Dict[str, str]:
        """Register Spaces for a specific SIMP capability type.
        
        Maps common SIMP capability types to HF tags.
        """
        cap_to_hf = {
            "hf_text_generation":    "text-generation",
            "hf_image_generation":   "text-to-image",
            "hf_audio_generation":   "text-to-speech",
            "hf_conversational":     "conversational",
            "hf_summarization":      "summarization",
            "hf_translation":        "translation",
            "hf_qa":                 "question-answering",
            "hf_embedding":          "feature-extraction",
            "hf_image_classification": "image-classification",
        }
        
        hf_tag = hf_pipeline_tag or cap_to_hf.get(cap_type)
        if not hf_tag:
            logger.warning(f"No HF tag mapping for {cap_type}")
            return {}
        
        return self.register_by_tag(hf_tag)

    def find_capability(self, intent_type: str) -> Optional[HfSpaceAdapter]:
        """Find the best Space to handle a given intent type.
        
        Uses capability map + load balancing (round-robin within type).
        """
        spaces = self._capability_map.get(intent_type, [])
        if not spaces:
            # Try prefix match for HF-specific types
            for cap_type, space_ids in self._capability_map.items():
                if cap_type in intent_type or intent_type in cap_type:
                    spaces.extend(space_ids)
        
        if not spaces:
            return None
        
        # Simple round-robin across adapters of this type
        space_id = spaces[0]  # TODO: add trust-weighted selection
        return self._adapters.get(space_id)

    async def handle_intent(self, intent: Any) -> Any:
        """Route a SIMP intent to the appropriate HF Space.
        
        This is the main entry point — integrates with the SIMP broker's
        intent dispatch pipeline.
        """
        import json
        from dataclasses import asdict
        
        intent_type = intent.intent_type if hasattr(intent, 'intent_type') else ""
        params = intent.params if hasattr(intent, 'params') else {}
        
        # If specific space targeted, use it
        target_space = params.get("_space_id")
        if target_space and target_space in self._adapters:
            adapter = self._adapters[target_space]
        else:
            # Auto-select best Space for this intent type
            adapter = self.find_capability(intent_type)
        
        if not adapter:
            return {
                "status": "error",
                "error_code": "NO_CAPABILITY",
                "error_message": f"No HF Space found for intent type '{intent_type}'",
            }
        
        return adapter.handle_intent(intent)

    @property
    def registered_count(self) -> int:
        return len(self._adapters)

    @property
    def capability_types(self) -> List[str]:
        return list(self._capability_map.keys())

    def _discover_popular(self, limit: int = 50):
        """Auto-discover popular Spaces by category."""
        categories = [
            "text-generation", "text-to-image", "conversational",
            "summarization", "translation", "question-answering",
        ]
        for cat in categories:
            try:
                self.register_by_tag(cat, limit=limit // len(categories))
            except Exception as e:
                logger.debug(f"Discovery for {cat} failed: {e}")

    def status(self) -> dict:
        """Report bridge status."""
        return {
            "registered_spaces": self.registered_count,
            "capability_types": self.capability_types,
            "registered_tags": self._registered_tags,
        }


# ---------------------------------------------------------------------------
# CLI: quick registration from command line
# ---------------------------------------------------------------------------

def register_from_cli():
    """CLI entry: python -m simp.bridges.hf_space <space_id|tag>"""
    import sys
    
    bridge = HfSpaceBridge(auto_discover=False)
    
    args = sys.argv[1:]
    if not args:
        print("Usage: python -m simp.bridges.hf_space <space_id|--tag <tag>>")
        print("Examples:")
        print("  python -m simp.bridges.hf_space google/gemma-2-2b-it")
        print("  python -m simp.bridges.hf_space --tag text-to-image --limit 10")
        return
    
    if args[0] == "--tag":
        tag = args[1] if len(args) > 1 else "text-generation"
        limit = int(args[3]) if len(args) > 3 and args[2] == "--limit" else 20
        results = bridge.register_by_tag(tag, limit=limit)
        print(f"Registered {len(results)} Spaces for tag '{tag}':")
        for space_id, cap_type in list(results.items())[:10]:
            print(f"  ✓ {space_id} → {cap_type}")
    else:
        space_id = args[0]
        cap_type = bridge.register_space(space_id)
        if cap_type:
            print(f"✓ Registered {space_id} → {cap_type}")
        else:
            print(f"✗ Failed to register {space_id}")


if __name__ == "__main__":
    register_from_cli()
