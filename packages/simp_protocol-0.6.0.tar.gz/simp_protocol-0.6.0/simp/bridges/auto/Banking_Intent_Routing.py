"""
Auto-generated SIMP Bridge: Banking-Intent-Routing
Source: https://github.com/krisz-T/Banking-Intent-Routing
Generated: 2026-05-04T03:53:10.910858+00:00

This bridge absorbs Banking-Intent-Routing into the SIMP network.
"""

import json
import logging
from typing import Dict, List, Optional, Any

logger = logging.getLogger(__name__)

ECOSYSTEM_NAME = "Banking-Intent-Routing"
ECOSYSTEM_SOURCE = "github"
CAPABILITY_TYPES = ["intent_routing"]
TRANSPORT = "rest"
AUTH_TYPE = "none"


class BankingIntentRoutingBridge:
    """Bridge that absorbs Banking-Intent-Routing capabilities into SIMP."""

    def __init__(self, base_url: str = '', api_key: str = ''):
        self.base_url = base_url
        self.api_key = api_key
        self._capabilities: List[str] = ["intent_routing"]

    async def handle_intent(self, intent: Any) -> dict:
        """Translate a SIMP intent into a Banking-Intent-Routing API call."""
        intent_type = getattr(intent, 'intent_type', '')
        params = getattr(intent, 'params', {})

        # Auto-detect the right endpoint based on capability
        if "intent_routing" in intent_type:
            endpoint = "intent_routing"
        else:
            endpoint = params.get("endpoint", "default")

        # Execute the API call
        import aiohttp
        headers = {"Content-Type": "application/json", "User-Agent": "simp-bridge/1.0"}

        async with aiohttp.ClientSession(headers=headers) as session:
            url = self._build_url(intent_type, params)
            payload = self._build_payload(intent_type, params)

            try:
                async with session.post(url, json=payload, timeout=30) as resp:
                    result = await resp.json()
                    return {"status": "success", "data": result, "ecosystem": "Banking-Intent-Routing"}
            except Exception as e:
                logger.warning(f"{fp.name} call failed: {e}")
                return {"status": "error", "error_code": "BRIDGE_FAILED", "error_message": str(e)}

    def _build_url(self, intent_type: str, params: dict) -> str:
        """Build the Banking-Intent-Routing API URL from intent parameters."""
        base = self.base_url or "https://github.com/krisz-T/Banking-Intent-Routing"
        endpoint = params.get("endpoint", "")
        if endpoint:
            return f"{base}/{endpoint}"
        return base

    def _build_payload(self, intent_type: str, params: dict) -> dict:
        """Build the request payload from intent parameters."""
        payload = {k: v for k, v in params.items() if k not in ("endpoint", "tool")}
        return payload

    @property
    def capabilities(self) -> List[str]:
        return self._capabilities



async def discover_capabilities(base_url: str = "") -> List[dict]:
    """Discover capabilities from a Banking-Intent-Routing instance."""
    # Attempt standard discovery endpoints
    discovery_paths = [
        "/capabilities", "/tools", "/api/tools",
        "/.well-known/agent", "/.well-known/mcp",
        "/health", "/api/health",
    ]

    import aiohttp
    async with aiohttp.ClientSession() as session:
        for path in discovery_paths:
            try:
                async with session.get(f"{base_url}{path}", timeout=5) as resp:
                    if resp.status == 200:
                        result = await resp.json()
                        return result if isinstance(result, list) else result.get("tools", result.get("capabilities", []))
            except Exception:
                continue

    return []



async def record_settlement(capability: str, amount: float = 0.001) -> dict:
    """Banking-Intent-Routing doesn't natively support payments. SIMP adds settlement layer."""
    # SIMP adds settlement even to ecosystems that don't have it
    return {"status": "added_settlement", "note": "SIMP added settlement layer to Banking-Intent-Routing"}
