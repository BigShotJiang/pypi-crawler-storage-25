"""Auto-generated ecosystem bridges."""
