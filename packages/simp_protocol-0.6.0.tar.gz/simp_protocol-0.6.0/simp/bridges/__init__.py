"""
SIMP Bridges — Absorb all capabilities into the SIMP network.

Every external ecosystem (Hugging Face, MCP, ElizaOS, NanoClaw, OpenClaw)
becomes a SIMP-addressable capability through these bridges.

Each bridge:
  1. Discovers capabilities from the external ecosystem
  2. Registers them as SIMP capabilities in the broker
  3. Translates SIMP intents → external API calls
  4. Returns signed SIMP responses
"""

from .hf_space import HfSpaceBridge, HfSpaceInfo
from .mcp_bridge import McpBridge
from .eliza_bridge import ElizaBridge
from .openfang_bridge import OpenFangBridge

__all__ = [
    "HfSpaceBridge",
    "HfSpaceInfo",
    "McpBridge",
    "ElizaBridge",
    "OpenFangBridge",
]
