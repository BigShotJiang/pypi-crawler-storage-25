"""SIMP Protocol — Standardized Intent Messaging Protocol."""

__version__ = "0.4.1"
