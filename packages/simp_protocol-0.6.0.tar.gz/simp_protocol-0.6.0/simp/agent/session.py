"""
Session Manager — Two-DB Polling Pattern (from NanoClaw v2).

Each agent session gets two SQLite databases:
  - inbound.db:  broker writes intents here, agent reads them
  - outbound.db: agent writes responses here, broker reads them

This eliminates IPC, keeps agents crash-recoverable, and enables
container-level isolation via simple volume mounts.

Key invariants (from NanoClaw):
  1. journal_mode=DELETE — WAL's shared memory doesn't survive mounts
  2. Host opens-writes-CLOSES per op — prevents page cache staleness
  3. One writer per file — no contention across mount boundaries
"""

import json
import logging
import os
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any, Callable

logger = logging.getLogger(__name__)


@dataclass
class SessionConfig:
    """Configuration for a session directory."""
    base_dir: str = "./simp_sessions"
    poll_interval_ms: int = 500
    active_poll_interval_ms: int = 200
    heartbeat_interval: int = 30  # poll cycles between heartbeat writes
    cleanup_hours: int = 72       # auto-close stale sessions


class InboundDb:
    """Read-only view of the inbound database (agent side)."""

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

    def open(self):
        self._conn = sqlite3.connect(self._db_path)
        self._conn.execute("PRAGMA journal_mode=DELETE")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._ensure_schema()

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    def _ensure_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS messages_in (
                id TEXT PRIMARY KEY,
                intent_id TEXT NOT NULL,
                capability TEXT NOT NULL,
                source_agent TEXT,
                params_json TEXT NOT NULL,
                settlement_json TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                trigger INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                claimed_at TEXT
            );
            CREATE TABLE IF NOT EXISTS processing_ack (
                message_id TEXT PRIMARY KEY,
                claimed_at TEXT NOT NULL
            );
        """)
        self._conn.commit()

    def get_pending(self) -> List[dict]:
        """Get all pending messages."""
        if not self._conn:
            return []
        cursor = self._conn.execute(
            "SELECT * FROM messages_in WHERE status = 'pending' ORDER BY created_at ASC"
        )
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]
        return [dict(zip(columns, row)) for row in rows]


class OutboundDb:
    """Write-only session database (agent side)."""

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

    def open(self):
        self._conn = sqlite3.connect(self._db_path)
        self._conn.execute("PRAGMA journal_mode=DELETE")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._ensure_schema()

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None

    def _ensure_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS messages_out (
                id TEXT PRIMARY KEY,
                intent_id TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                result_json TEXT,
                error_code TEXT,
                error_message TEXT,
                settlement_receipt TEXT,
                created_at TEXT NOT NULL,
                delivered INTEGER NOT NULL DEFAULT 0
            );
        """)
        self._conn.commit()

    def write_response(self, intent_id: str, result: dict, status: str = "success"):
        """Write a response for delivery back to the broker."""
        response_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()
        
        self._conn.execute(
            """INSERT OR REPLACE INTO messages_out 
               (id, intent_id, status, result_json, error_code, error_message, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                response_id,
                intent_id,
                status,
                json.dumps(result.get("data", result)),
                result.get("error_code", ""),
                result.get("error_message", ""),
                now,
            ),
        )
        self._conn.commit()
        return response_id


@dataclass
class Session:
    """A single agent session with inbound/outbound DBs."""

    agent_group_id: str
    session_id: str
    config: SessionConfig = field(default_factory=SessionConfig)

    def __post_init__(self):
        self._dir = os.path.join(self.config.base_dir, self.agent_group_id, self.session_id)
        os.makedirs(self._dir, exist_ok=True)
        self.inbound = InboundDb(os.path.join(self._dir, "inbound.db"))
        self.outbound = OutboundDb(os.path.join(self._dir, "outbound.db"))

    def open(self):
        self.inbound.open()
        self.outbound.open()

    def close(self):
        self.inbound.close()
        self.outbound.close()

    @property
    def heartbeat_path(self) -> str:
        return os.path.join(self._dir, ".heartbeat")

    def touch_heartbeat(self):
        """Write heartbeat timestamp."""
        with open(self.heartbeat_path, "w") as f:
            f.write(str(time.time()))

    def mark_processing(self, message_ids: List[str]):
        """Mark messages as being processed (claimed)."""
        if not self.inbound._conn:
            return
        now = datetime.now(timezone.utc).isoformat()
        for mid in message_ids:
            self.inbound._conn.execute(
                "UPDATE messages_in SET status = 'processing', claimed_at = ? WHERE id = ?",
                (now, mid),
            )
            self.inbound._conn.execute(
                "INSERT OR REPLACE INTO processing_ack (message_id, claimed_at) VALUES (?, ?)",
                (mid, now),
            )
        self.inbound._conn.commit()

    def mark_completed(self, message_ids: List[str]):
        """Mark messages as completed."""
        if not self.inbound._conn:
            return
        for mid in message_ids:
            self.inbound._conn.execute(
                "UPDATE messages_in SET status = 'completed' WHERE id = ?",
                (mid,),
            )
        self.inbound._conn.commit()
