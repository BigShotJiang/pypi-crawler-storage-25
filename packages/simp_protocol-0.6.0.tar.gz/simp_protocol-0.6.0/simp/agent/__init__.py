"""
SIMP Agent SDK — Build agents that can send and receive SIMP intents.

Based on patterns from NanoClaw v2 (two-DB polling, provider abstraction)
and ElizaOS (plugin system, memory management).

Usage:
    from simp.agent import SimpAgent, AgentConfig
    
    agent = SimpAgent(config=AgentConfig(
        agent_id="my-agent",
        private_key="...",
        broker_url="https://simp-broker.fly.dev",
    ))
    
    # Register capabilities
    agent.register_capability("hf_text_generation", my_handler)
    
    # Start the poll loop
    await agent.run()
"""
