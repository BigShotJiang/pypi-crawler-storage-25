"""
Provider Abstraction — Plug any model/agent backend into SIMP.

Based on NanoClaw v2's AgentProvider interface. Enables:
  - Claude (Anthropic SDK)
  - OpenAI Codex
  - Any OpenAI-compatible API (OpenRouter, Ollama, etc.)
  - Custom local models

Each provider handles:
  - Converting SIMP intents → model prompts
  - Streaming responses back
  - Session continuation (resume across container restarts)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import AsyncIterable, Optional, Dict, Any, List


@dataclass
class QueryInput:
    """Input to a provider query."""
    prompt: str
    continuation: Optional[str] = None
    cwd: str = "/workspace/agent"
    system_context: Optional[dict] = None
    additional_directories: Optional[List[str]] = None


@dataclass
class McpServerConfig:
    """MCP server configuration for providers that support it."""
    command: str
    args: List[str]
    env: Dict[str, str]


class ProviderEvent:
    """Events yielded during a provider query."""
    pass


@dataclass
class InitEvent(ProviderEvent):
    """Session initialized, continuation token provided."""
    continuation: str


@dataclass
class ResultEvent(ProviderEvent):
    """Final result from the query."""
    text: Optional[str]


@dataclass
class ErrorEvent(ProviderEvent):
    """Error during query processing."""
    message: str
    retryable: bool = False
    classification: Optional[str] = None


@dataclass
class ProgressEvent(ProviderEvent):
    """Progress update (token, thinking step, tool call)."""
    message: str


@dataclass
class ActivityEvent(ProviderEvent):
    """Liveness signal — provider is still working."""
    pass


class AgentQuery(ABC):
    """Handle for an active provider query."""

    @abstractmethod
    def push(self, message: str):
        """Push a follow-up message into the active query."""
        ...

    @abstractmethod
    def end(self):
        """Signal that no more input will be sent."""
        ...

    @abstractmethod
    def abort(self):
        """Force-stop the query."""
        ...

    @property
    @abstractmethod
    def events(self) -> AsyncIterable[ProviderEvent]:
        """Output event stream."""
        ...


class AgentProvider(ABC):
    """Abstract provider for agent backends."""

    @property
    @abstractmethod
    def supports_native_slash_commands(self) -> bool:
        """True if the SDK handles commands like /clear natively."""
        ...

    @abstractmethod
    def query(self, input: QueryInput) -> AgentQuery:
        """Start a new query. Returns a handle for streaming IO."""
        ...

    @abstractmethod
    def is_session_invalid(self, err: Exception) -> bool:
        """True if the error indicates stale continuation should be cleared."""
        ...
