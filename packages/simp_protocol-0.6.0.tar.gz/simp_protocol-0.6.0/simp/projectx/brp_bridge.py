"""
ProjectX → BRP Bridge — T20

Bidirectional bridge between ProjectX self-modification events and the BRP
security supervisor.

ProjectX self-modification events → BRP.evaluate_event()
BRP shadow decisions → ProjectXSafetyMonitor flag update

This closes the loop: BRP supervises ProjectX changes, and ProjectX
modifications inform BRP scoring.

Usage::

    from simp.projectx.brp_bridge import ProjectXBRPBridge, get_brp_bridge

    bridge = ProjectXBRPBridge()
    bridge.on_projectx_applied(proposal, result)  # fires BRP event
    bridge.on_brp_decision(brp_response)           # updates safety monitor
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from simp.security.brp_bridge import BRPBridge
from simp.security.brp_models import (
    BRPEvent,
    BRPEventType,
    BRPResponse,
)
from simp.projectx.safety_monitor import get_safety_monitor

logger = logging.getLogger("SIMP.ProjectX.BRPBridge")

# BRP event type for ProjectX self-modifications
PROJECTX_EVENT_TYPE = "projectx_modification"


class ProjectXBRPBridge:
    """
    Bridges ProjectX self-modification lifecycle events to BRP scoring.

    Usage::

        bridge = ProjectXBRPBridge()
        # When ProjectX applies a patch:
        bridge.on_projectx_applied(proposal, apply_result)
        # When BRP returns a decision on a projectx event:
        bridge.on_brp_decision(brp_response)
    """

    def __init__(
        self,
        brp_bridge: Optional[BRPBridge] = None,
        safety_monitor=None,
    ) -> None:
        self._brp = brp_bridge or BRPBridge()
        self._safety = safety_monitor or get_safety_monitor()
        self._paused = False

    def on_projectx_applied(
        self,
        proposal: Any,
        result: Dict[str, Any],
    ) -> None:
        """
        Called after SelfModifier.apply() succeeds.

        Emits a BRP event for the modification so BRP can score it,
        and pauses self-modification if BRP returns DENY.

        Args:
            proposal: The PatchProposal that was applied.
            result: Dict with apply result (file, patch_id, etc.)
        """
        event = BRPEvent(
            schema_version="brp.event.v1",
            source_agent="projectx_self_modifier",
            event_type=PROJECTX_EVENT_TYPE,
            action="projectx_apply",
            params={
                "proposal_id": getattr(proposal, "proposal_id", "unknown"),
                "target_file": getattr(proposal, "target_file", result.get("file", "")),
                "patch_id": result.get("patch_id", ""),
                "benchmark_delta": getattr(proposal, "benchmark_delta", None),
                "validation_score": getattr(proposal, "validation_score", None),
            },
            context={
                "proposal_rationale": getattr(proposal, "rationale", ""),
                "auto_generated": True,
            },
            tags=["projectx", "self_modification"],
            mode="shadow",
        )

        try:
            response = self._brp.evaluate_event(event)
            logger.info(
                "[PX-BRP] ProjectX apply event scored: decision=%s, threat=%.3f",
                response.decision, response.threat_score,
            )
            # If BRP denies, pause self-modification
            if response.decision == "DENY":
                self._safety.pause_self_modification(
                    reason=f"BRP DENY on projectx_apply: {response.summary}"
                )
                self._paused = True
                logger.warning(
                    "[PX-BRP] Self-modification PAUSED — BRP threat score %.3f > threshold",
                    response.threat_score,
                )
        except Exception as e:
            logger.error("[PX-BRP] Failed to evaluate projectx event: %s", e)

    def on_projectx_candidate(
        self,
        proposal: Any,
    ) -> Optional[BRPResponse]:
        """
        Called before a patch proposal is approved.

        Pre-flight check: score the proposed modification against BRP
        without persisting an event. If DENY, the governance layer
        should not approve.

        Args:
            proposal: The PatchProposal being considered.

        Returns:
            BRPResponse if scoring is possible, None on error.
        """
        event = BRPEvent(
            schema_version="brp.event.v1",
            source_agent="projectx_governance",
            event_type=PROJECTX_EVENT_TYPE,
            action="projectx_candidate",
            params={
                "proposal_id": getattr(proposal, "proposal_id", "unknown"),
                "target_file": getattr(proposal, "target_file", ""),
                "benchmark_delta": getattr(proposal, "benchmark_delta", None),
            },
            tags=["projectx", "pre_approval_check"],
            mode="shadow",
        )

        try:
            return self._brp.evaluate_event(event)
        except Exception as e:
            logger.error("[PX-BRP] Pre-approval check failed: %s", e)
            return None

    def on_brp_decision(self, response: BRPResponse) -> None:
        """
        Called when BRP returns a decision on any event.

        Updates the ProjectX safety monitor with BRP's assessment
        so future governance decisions are informed by security posture.

        Args:
            response: The BRPResponse from evaluate_event().
        """
        if response.threat_score > 0.7:
            self._safety.set_alert(
                f"BRP threat score elevated: {response.threat_score:.3f} "
                f"tags={response.threat_tags}"
            )
        elif self._paused and response.threat_score < 0.3:
            # Resume self-modification if BRP score drops back to safe
            self._safety.resume_self_modification()
            self._paused = False
            logger.info("[PX-BRP] Self-modification RESUMED — BRP threat score normalized")

    @property
    def is_self_modification_paused(self) -> bool:
        """Returns True if BRP has caused self-modification to be paused."""
        return self._paused


# Module-level singleton
_bridge: Optional[ProjectXBRPBridge] = None


def get_brp_bridge() -> ProjectXBRPBridge:
    global _bridge
    if _bridge is None:
        _bridge = ProjectXBRPBridge()
    return _bridge
