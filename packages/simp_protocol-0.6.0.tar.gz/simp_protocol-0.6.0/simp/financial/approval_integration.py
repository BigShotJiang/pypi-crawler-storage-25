"""
L5-T4 — Financial Ops Approval Queue Integration.

Wires the existing ApprovalQueue into the multi-currency payment flow:
1. Payments over $100 (or equivalent) require approval queue
2. Queue supports: submit → review → approve/reject
3. Audited trail per decision
4. Multi-currency threshold detection (convert to USD for comparison)
5. Integration with MultiCurrencyFlowManager

Builds on: simp/compat/approval_queue.py (existing queue)
"""

import json
import logging
import os
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple

from simp.compat.approval_queue import (
    ApprovalQueue,
    PaymentProposal,
    PaymentProposalStatus,
    PolicyChangeQueue,
)

from simp.financial.multi_currency import MultiCurrencyFlowManager, MULTI_CURRENCY_MANAGER

logger = logging.getLogger("SIMP.ApprovalIntegration")

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------

# Intent execution costs above this USD-equivalent require approval
AUTO_APPROVAL_THRESHOLD_USD = 100.00

# Higher threshold for trusted organs
TRUSTED_ORGAN_THRESHOLD_USD = 500.00

# Trusted organs (bypass high-amount flags for moderate amounts)
TRUSTED_ORGANS = {"financial_ops", "quantumarb"}  # These organs can self-approve up to threshold


# ---------------------------------------------------------------------------
# Approval Integration Manager
# ---------------------------------------------------------------------------

class ApprovalIntegrationManager:
    """
    Integrates the approval queue with financial operations.

    Provides:
    - Multi-currency threshold checking (converts to USD)
    - Automatic submission to approval queue when threshold exceeded
    - Approval/rejection with operator audit trail
    - Execution of approved payments
    - Status tracking for pending approvals
    """

    def __init__(self):
        self._approval_queue = ApprovalQueue()
        self._currency_manager = MultiCurrencyFlowManager()

    # ------------------------------------------------------------------
    # Threshold checking
    # ------------------------------------------------------------------

    def get_usd_equivalent(self, amount: float, currency: str) -> float:
        """Convert an amount to USD equivalent for threshold checking."""
        if currency == "USD":
            return amount
        rate, _ = self._currency_manager.get_rate(currency.upper())
        return round(amount * rate, 2)

    def requires_approval(self, amount: float, currency: str, organ_id: str = "") -> Tuple[bool, str]:
        """
        Check if a payment requires approval.

        Returns (requires_approval, reason).
        """
        usd_value = self.get_usd_equivalent(amount, currency)

        if organ_id in TRUSTED_ORGANS:
            threshold = TRUSTED_ORGAN_THRESHOLD_USD
        else:
            threshold = AUTO_APPROVAL_THRESHOLD_USD

        if usd_value > threshold:
            return (True, f"Amount ${usd_value:.2f} USD exceeds ${threshold:.2f} threshold")
        return (False, "")

    # ------------------------------------------------------------------
    # Proposal lifecycle
    # ------------------------------------------------------------------

    def submit_payment_for_approval(
        self,
        organ_id: str,
        amount: float,
        currency: str,
        vendor: str,
        description: str,
        category: str = "small_purchase",
        idempotency_key: str = "",
    ) -> Dict[str, Any]:
        """
        Submit a payment for approval.

        If amount is below threshold, auto-approves.
        If above threshold, submits to approval queue.

        Returns with status: "approved", "submitted", or "error".
        """
        currency = currency.upper()

        # Check if approval is needed
        needs_approval, reason = self.requires_approval(amount, currency, organ_id)

        if not needs_approval:
            # Auto-approve — below threshold
            return {
                "status": "approved",
                "message": f"Payment of {amount} {currency} is below threshold — auto-approved",
                "auto_approved": True,
                "amount": amount,
                "currency": currency,
                "usd_equivalent": self.get_usd_equivalent(amount, currency),
            }

        # Submit to approval queue
        usd_value = self.get_usd_equivalent(amount, currency)
        proposal = self._approval_queue.submit_proposal(
            op_type="payment",
            connector_name="multi_currency",
            amount=amount,
            vendor=vendor,
            category=category,
            description=f"[{currency}] {description} (${usd_value:.2f} USD)",
        )

        logger.info(
            "Payment submitted for approval: %s → %s: %.4f %s (${usd_value:.2f} USD)",
            organ_id, vendor, amount, currency,
        )

        return {
            "status": "submitted",
            "proposal_id": proposal.proposal_id,
            "amount": amount,
            "currency": currency,
            "usd_equivalent": usd_value,
            "threshold_reason": reason,
            "message": f"Payment exceeds ${AUTO_APPROVAL_THRESHOLD_USD:.2f} threshold — submitted for approval",
        }

    def approve_payment(
        self,
        proposal_id: str,
        operator_subject: str,
    ) -> Dict[str, Any]:
        """
        Approve a pending payment proposal.

        Returns the approved proposal.
        """
        try:
            proposal = self._approval_queue.approve_proposal(proposal_id, operator_subject)
            return {
                "status": "approved",
                "proposal_id": proposal.proposal_id,
                "amount": proposal.amount,
                "vendor": proposal.vendor,
                "approved_by": operator_subject,
                "message": "Payment approved",
            }
        except Exception as e:
            logger.error("Approval failed for %s: %s", proposal_id, e)
            return {"status": "error", "error": str(e)}

    def reject_payment(
        self,
        proposal_id: str,
        operator_subject: str,
        reason: str = "",
    ) -> Dict[str, Any]:
        """
        Reject a pending payment proposal.
        """
        try:
            proposal = self._approval_queue.reject_proposal(proposal_id, operator_subject, reason)
            return {
                "status": "rejected",
                "proposal_id": proposal.proposal_id,
                "rejected_by": operator_subject,
                "reason": reason,
                "message": "Payment rejected",
            }
        except Exception as e:
            logger.error("Rejection failed for %s: %s", proposal_id, e)
            return {"status": "error", "error": str(e)}

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_pending_approvals(self) -> List[Dict[str, Any]]:
        """Get all pending payment proposals."""
        proposals = self._approval_queue.get_pending_proposals()
        return [p.to_dict() for p in proposals]

    def get_approval_history(self) -> List[Dict[str, Any]]:
        """Get all proposals (including approved/rejected)."""
        proposals = self._approval_queue.get_all_proposals()
        return [p.to_dict() for p in proposals]

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of the approval queue."""
        all_proposals = self._approval_queue.get_all_proposals()
        pending = [p for p in all_proposals if p.status == PaymentProposalStatus.PENDING]
        approved = [p for p in all_proposals if p.status == PaymentProposalStatus.APPROVED]
        rejected = [p for p in all_proposals if p.status == PaymentProposalStatus.REJECTED]

        return {
            "total_proposals": len(all_proposals),
            "pending": len(pending),
            "approved": len(approved),
            "rejected": len(rejected),
            "threshold_usd": AUTO_APPROVAL_THRESHOLD_USD,
            "trusted_organs": TRUSTED_ORGANS,
            "vendor_summary": self._get_vendor_summary(approved),
        }

    def _get_vendor_summary(self, approved_proposals: List[PaymentProposal]) -> Dict[str, float]:
        """Get total approved spend per vendor."""
        vendor_totals: Dict[str, float] = {}
        for p in approved_proposals:
            vendor_totals[p.vendor] = vendor_totals.get(p.vendor, 0.0) + p.amount
        return {v: round(a, 2) for v, a in vendor_totals.items()}


# Module-level singleton
APPROVAL_INTEGRATION = ApprovalIntegrationManager()
