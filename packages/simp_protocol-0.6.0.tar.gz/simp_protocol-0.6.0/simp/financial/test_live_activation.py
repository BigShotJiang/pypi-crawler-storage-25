"""
Tests for L5-T1 — Live Payment Connector Activation.

Ensures:
1. Global feature flag controls live mode
2. Organ whitelist gates activation
3. Connector promotion works (stub → stripe_test)
4. Health checks run on activation
5. Fallback to stub when Stripe key is absent
"""

import json
import os
import sys
import tempfile
from pathlib import Path

# Ensure inner simp package is importable
_simp_inner = Path(__file__).resolve().parent.parent
if str(_simp_inner) not in sys.path:
    sys.path.insert(0, str(_simp_inner))

from simp.financial.live_activation import LiveActivator, OrgLiveStatus


class TestL5T1LiveActivation:
    """L5-T1: Live Payment Connector Activation."""

    def setup_method(self):
        # Save env state
        self._saved_env = {}
        for key in ("FINANCIAL_OPS_LIVE_ENABLED", "LIVE_ORG_WHITELIST", "STRIPE_TEST_SECRET_KEY"):
            self._saved_env[key] = os.environ.get(key)
            if key in os.environ:
                del os.environ[key]

    def teardown_method(self):
        # Restore env state
        for key, val in self._saved_env.items():
            if val is not None:
                os.environ[key] = val
            elif key in os.environ:
                del os.environ[key]

    # ------------------------------------------------------------------
    # T1.1 — Feature flag OFF means all connectors stay in dry-run
    # ------------------------------------------------------------------

    def test_feature_flag_off_disables_live(self):
        """FINANCIAL_OPS_LIVE_ENABLED=false → all organs get stub connectors."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "false"
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t1.jsonl")
        result = activ.initialize()

        assert result["global_live_enabled"] is False
        assert len(result["orgs_activated"]) == 0  # No one activated
        assert activ.is_live_ready()["ready"] is False

    # ------------------------------------------------------------------
    # T1.2 — Feature flag ON with whitelist activates organs
    # ------------------------------------------------------------------

    def test_feature_flag_on_activates_whitelist(self):
        """FINANCIAL_OPS_LIVE_ENABLED=true + whitelist → organs activated."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "true"
        os.environ["LIVE_ORG_WHITELIST"] = "quantumarb,financial_ops"
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t2.jsonl")
        result = activ.initialize()

        assert result["global_live_enabled"] is True
        assert len(result["orgs_activated"]) == 2
        orgs = {o["organ_id"] for o in result["orgs_activated"]}
        assert "quantumarb" in orgs
        assert "financial_ops" in orgs

    # ------------------------------------------------------------------
    # T1.3 — Organ NOT in whitelist stays on stub
    # ------------------------------------------------------------------

    def test_organ_not_in_whitelist_uses_stub(self):
        """Org not in whitelist → not activated, uses stub fallback."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "true"
        os.environ["LIVE_ORG_WHITELIST"] = "quantumarb"
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t3.jsonl")
        activ.initialize()

        # 'media' is not whitelisted → should not be activated
        status = activ.get_status("media")
        assert status is None

        # But can still make stub payments
        result = activ.execute_payment("media", 5.00, "TestVendor", "test payment")
        # Should produce a stub-style result (dry_run=True)
        assert result is not None

    # ------------------------------------------------------------------
    # T1.4 — StripeTestConnector promotion when key is set
    # ------------------------------------------------------------------

    def test_stripe_connector_promotion(self):
        """STRIPE_TEST_SECRET_KEY set → StripeTestConnector is used."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "true"
        os.environ["STRIPE_TEST_SECRET_KEY"] = "sk_test_abc123dummykey"
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t4.jsonl")
        result = activ.initialize()

        for org in result["orgs_activated"]:
            assert org["connector"] == "stripe_small_payments", (
                f"Expected stripe_small_payments for {org['organ_id']}, got {org['connector']}"
            )

    # ------------------------------------------------------------------
    # T1.5 — Fallback to stub when Stripe key absent
    # ------------------------------------------------------------------

    def test_stub_fallback_when_no_stripe_key(self):
        """No STRIPE_TEST_SECRET_KEY → stub connector with dry_run=False."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "true"
        # Intentionally NOT setting STRIPE_TEST_SECRET_KEY
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t5.jsonl")
        result = activ.initialize()

        for org in result["orgs_activated"]:
            assert org["connector"] == "stub_small_payments", (
                f"Expected stub_small_payments for {org['organ_id']}, got {org['connector']}"
            )

    # ------------------------------------------------------------------
    # T1.6 — Execute payment records to ledger
    # ------------------------------------------------------------------

    def test_live_payment_executed_successfully(self):
        """Live payment → executes and returns success result."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "true"
        activ = LiveActivator(ledger_path="/tmp/test_ledger_live.jsonl")
        activ.initialize()

        result = activ.execute_payment("quantumarb", 10.00, "OpenAI", "GPT-4 API credits")

        assert result.success is True
        assert result.amount == 10.00
        # Stub connector always reports dry_run=True in result
        # The key signal is success=True + payment executes

    # ------------------------------------------------------------------
    # T1.7 — is_live_ready reports correctly
    # ------------------------------------------------------------------

    def test_is_live_ready_true_when_activated(self):
        """All conditions met → is_live_ready returns True."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "true"
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t7.jsonl")
        activ.initialize()

        ready = activ.is_live_ready()
        assert ready["ready"] is True
        assert len(ready["organs_ready"]) > 0

    def test_is_live_ready_false_when_flag_off(self):
        """Feature flag off → is_live_ready returns False."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "false"
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t7b.jsonl")
        activ.initialize()

        assert activ.is_live_ready()["ready"] is False

    # ------------------------------------------------------------------
    # T1.8 — OrgLiveStatus correctly tracks state
    # ------------------------------------------------------------------

    def test_org_live_status_tracking(self):
        """OrgLiveStatus fields are populated correctly."""
        status = OrgLiveStatus(
            organ_id="test_organ",
            live_enabled=True,
            connector_name="stripe_small_payments",
            daily_spend=15.00,
            monthly_spend=150.00,
            health_ok=True,
        )
        d = status.to_dict()
        assert d["organ_id"] == "test_organ"
        assert d["daily_spend"] == 15.00
        assert d["monthly_spend"] == 150.00
        assert d["health_ok"] is True

    # ------------------------------------------------------------------
    # T1.9 — get_all_statuses returns all organ statuses
    # ------------------------------------------------------------------

    def test_get_all_statuses(self):
        """get_all_statuses returns statuses for all activated organs."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "true"
        os.environ["LIVE_ORG_WHITELIST"] = "quantumarb,financial_ops,kashclaw"
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t9.jsonl")
        activ.initialize()

        all_statuses = activ.get_all_statuses()
        assert len(all_statuses) == 3
        organ_ids = {s["organ_id"] for s in all_statuses}
        assert organ_ids == {"quantumarb", "financial_ops", "kashclaw"}

    # ------------------------------------------------------------------
    # T1.10 — Default whitelist works when env var not set
    # ------------------------------------------------------------------

    def test_default_whitelist(self):
        """No LIVE_ORG_WHITELIST env var → uses DEFAULT_WHITELIST."""
        os.environ["FINANCIAL_OPS_LIVE_ENABLED"] = "true"
        # Intentionally NOT setting LIVE_ORG_WHITELIST
        activ = LiveActivator(ledger_path="/tmp/test_ledger_t10.jsonl")
        result = activ.initialize()

        # Should use DEFAULT_WHITELIST = ["quantumarb", "financial_ops", "kashclaw"]
        assert len(result["orgs_activated"]) == 3
