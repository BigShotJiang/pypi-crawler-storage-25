"""
L5-T2 — Real Financial Operations Ledger.

Extends the existing LiveSpendLedger with:
1. Multi-currency support (USD, USDC, ETH, BTC)
2. Dual-party signed entries (both source and target sign)
3. Exchange rate resolution from Coinbase/Kraken feeds
4. Auto-reconciliation with external balances

Builds on: simp/compat/live_ledger.py (base append-only ledger)
Uses: simp/compat/reconciliation.py (existing reconciliation engine)
"""

import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple

from simp.compat.live_ledger import LiveSpendLedger, LivePaymentRecord
from simp.compat.reconciliation import run_reconciliation, ReconciliationResult

logger = logging.getLogger("SIMP.FinOpsLedger")

# ---------------------------------------------------------------------------
# Supported currencies
# ---------------------------------------------------------------------------

SUPPORTED_CURRENCIES = {"USD", "USDC", "ETH", "BTC"}

# Default exchange rates (updated on each fetch attempt)
DEFAULT_RATES: Dict[str, float] = {
    "USDC": 1.0,    # 1:1 with USD
    "ETH": 1875.00,  # Fallback if API unavailable
    "BTC": 63500.00,
}


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class FinOpsEntry:
    """A single financial operations ledger entry."""
    entry_id: str = ""
    source_organ: str = ""
    target_organ: str = ""
    intent_id: str = ""
    amount: float = 0.0
    currency: str = "USD"
    amount_usd: float = 0.0  # Normalized to USD for reconciliation
    source_signature: str = ""  # Ed25519 hex signature from source
    target_signature: str = ""  # Ed25519 hex signature from target
    exchange_rate_used: float = 1.0
    exchange_source: str = "default"  # "coinbase", "kraken", "default"
    status: str = "pending"  # pending, settled, disputed, reversed
    description: str = ""
    created_at: str = ""
    settled_at: Optional[str] = None

    def __post_init__(self):
        if not self.entry_id:
            self.entry_id = f"finops-{uuid.uuid4().hex[:16]}"
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BalanceSnapshot:
    """Organ balance snapshot at a point in time."""
    organ_id: str
    balances: Dict[str, float]  # currency → amount
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Exchange Rate Resolver
# ---------------------------------------------------------------------------

class ExchangeRateResolver:
    """
    Fetches real-time exchange rates from Coinbase/Kraken.
    Falls back to cached defaults if API unavailable.
    """

    def __init__(self):
        self._rates: Dict[str, float] = DEFAULT_RATES.copy()
        self._source: str = "default"
        self._last_fetch: float = 0.0
        self._cache_ttl: float = 10.0  # seconds

    def get_rate(self, currency: str) -> Tuple[float, str]:
        """
        Get the USD exchange rate for a currency.

        Returns (rate, source). Caches for 10 seconds.
        """
        now = time.time()
        if now - self._last_fetch > self._cache_ttl:
            self._fetch_rates()

        rate = self._rates.get(currency.upper(), 1.0)
        return rate, self._source

    def _fetch_rates(self) -> None:
        """Try Coinbase API first, then Kraken, then fallback."""
        self._last_fetch = time.time()

        # Try Coinbase
        try:
            import urllib.request
            import json as _json
            req = urllib.request.Request(
                "https://api.coinbase.com/v2/exchange-rates?currency=USD",
                headers={"User-Agent": "SIMP-FinOps/1.0"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = _json.loads(resp.read().decode("utf-8"))
                rates = data.get("data", {}).get("rates", {})
                for sym in ["ETH", "BTC", "USDC"]:
                    if sym in rates:
                        # Coinbase gives "amount of currency per USD"
                        # We want USD per 1 unit of currency
                        per_usd = float(rates[sym])
                        if per_usd > 0:
                            self._rates[sym] = round(1.0 / per_usd, 2)
                self._source = "coinbase"
                logger.info("Exchange rates fetched from Coinbase")
                return
        except Exception as e:
            logger.debug("Coinbase rate fetch failed: %s", e)

        # Fallback: Kraken
        try:
            import urllib.request
            import json as _json
            pairs = {"ETH": "XETHZUSD", "BTC": "XXBTZUSD", "USDC": "USDCUSD"}
            for sym, pair in pairs.items():
                url = f"https://api.kraken.com/0/public/Ticker?pair={pair}"
                req = urllib.request.Request(url, headers={"User-Agent": "SIMP-FinOps/1.0"})
                with urllib.request.urlopen(req, timeout=5) as resp:
                    data = _json.loads(resp.read().decode("utf-8"))
                    result = data.get("result", {})
                    ticker = result.get(list(result.keys())[0], {})
                    c = ticker.get("c", ["0"])
                    if c:
                        self._rates[sym] = round(float(c[0]), 2)
            self._source = "kraken"
            logger.info("Exchange rates fetched from Kraken")
            return
        except Exception as e:
            logger.debug("Kraken rate fetch failed: %s", e)

        # Keep defaults
        self._source = "default"
        logger.info("Using default exchange rates (API unavailable)")


# ---------------------------------------------------------------------------
# Real Financial Operations Ledger
# ---------------------------------------------------------------------------

class RealFinOpsLedger:
    """
    Real financial operations ledger with multi-currency support.

    Tracks both simulated and real transactions, with dual-party signatures,
    exchange rate resolution, and auto-reconciliation.

    Thread-safe via lock. Append-only via JSONL persistence.
    """

    def __init__(self, ledger_path: Optional[str] = None):
        self._lock = threading.Lock()
        self._ledger_path = ledger_path or "data/finops_ledger.jsonl"
        self._entries: Dict[str, FinOpsEntry] = {}
        self._rate_resolver = ExchangeRateResolver()
        self._live_ledger = LiveSpendLedger()
        self._load_existing()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load_existing(self) -> None:
        """Load existing entries from JSONL file."""
        path = os.path.expanduser(self._ledger_path)
        if not os.path.exists(path):
            os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
            return
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        data = json.loads(line)
                        entry = FinOpsEntry(**data)
                        self._entries[entry.entry_id] = entry
                    except (json.JSONDecodeError, TypeError) as e:
                        logger.warning("Skipping malformed ledger entry: %s", e)

    def _append_entry(self, entry: FinOpsEntry) -> None:
        """Append an entry to the JSONL file."""
        path = os.path.expanduser(self._ledger_path)
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "a") as f:
            f.write(json.dumps(entry.to_dict()) + "\n")

    # ------------------------------------------------------------------
    # Entry creation
    # ------------------------------------------------------------------

    def record_transaction(
        self,
        source_organ: str,
        target_organ: str,
        amount: float,
        currency: str = "USD",
        intent_id: str = "",
        description: str = "",
        source_signature: str = "",
    ) -> FinOpsEntry:
        """
        Record a financial transaction between two organs.

        Automatically resolves exchange rate and computes USD equivalent.
        The source organ signs the entry; target organ signs on settlement.
        """
        currency = currency.upper()
        if currency not in SUPPORTED_CURRENCIES:
            raise ValueError(f"Unsupported currency: {currency}. Must be one of: {SUPPORTED_CURRENCIES}")

        rate, exch_source = self._rate_resolver.get_rate(currency)
        amount_usd = round(amount * rate, 2)

        entry = FinOpsEntry(
            source_organ=source_organ,
            target_organ=target_organ,
            intent_id=intent_id,
            amount=amount,
            currency=currency,
            amount_usd=amount_usd,
            source_signature=source_signature,
            exchange_rate_used=rate,
            exchange_source=exch_source,
            description=description,
        )

        with self._lock:
            self._entries[entry.entry_id] = entry
            self._append_entry(entry)

        # Also record in base LiveSpendLedger
        try:
            self._live_ledger.record_attempt(
                proposal_id=entry.entry_id,
                idempotency_key=entry.entry_id,
                connector_name="finops_ledger",
                vendor=target_organ,
                category="cross_organ_settlement",
                amount=amount_usd,
            )
        except Exception as e:
            logger.warning("Failed to record in base ledger: %s", e)

        logger.info(
            "Transaction: %s → %s: %.4f %s ($%.2f USD) [%s]",
            source_organ, target_organ, amount, currency, amount_usd, exch_source,
        )
        return entry

    def settle_transaction(
        self,
        entry_id: str,
        target_signature: str = "",
    ) -> Optional[FinOpsEntry]:
        """
        Settle a pending transaction. The target organ signs to confirm.

        Returns None if entry not found or already settled.
        """
        with self._lock:
            entry = self._entries.get(entry_id)
            if not entry:
                logger.warning("Entry %s not found for settlement", entry_id)
                return None
            if entry.status != "pending":
                logger.warning("Entry %s already %s", entry_id, entry.status)
                return None

            entry.target_signature = target_signature
            entry.status = "settled"
            entry.settled_at = datetime.now(timezone.utc).isoformat()

            # Re-append updated entry (append-only pattern)
            self._append_entry(entry)

            # Record outcome in base ledger
            try:
                self._live_ledger.record_outcome(
                    record_id=entry_id,
                    status="completed",
                    provider_reference=entry_id,
                )
            except Exception as e:
                logger.debug("Outcome recording skipped: %s", e)

            logger.info("Transaction %s settled: %s", entry_id, entry.status)
            return entry

    def dispute_transaction(self, entry_id: str, reason: str = "") -> Optional[FinOpsEntry]:
        """Flag a transaction as disputed."""
        with self._lock:
            entry = self._entries.get(entry_id)
            if not entry:
                return None
            entry.status = "disputed"
            if reason:
                entry.description = f"{entry.description} | DISPUTED: {reason}"
            self._append_entry(entry)
            return entry

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_entry(self, entry_id: str) -> Optional[FinOpsEntry]:
        """Get a specific entry."""
        with self._lock:
            return self._entries.get(entry_id)

    def get_entries_for_organ(self, organ_id: str) -> List[FinOpsEntry]:
        """Get all entries involving a specific organ."""
        with self._lock:
            return [
                e for e in self._entries.values()
                if e.source_organ == organ_id or e.target_organ == organ_id
            ]

    def get_all_entries(self) -> List[FinOpsEntry]:
        """Get all entries."""
        with self._lock:
            return list(self._entries.values())

    def get_balance(self, organ_id: str) -> Dict[str, float]:
        """
        Calculate net balance for an organ across all currencies.

        Positive = organ is owed money (as source).
        Negative = organ owes money (as target).
        """
        balance: Dict[str, float] = {}
        with self._lock:
            for entry in self._entries.values():
                if entry.status != "settled":
                    continue
                if entry.source_organ == organ_id:
                    balance[entry.currency] = balance.get(entry.currency, 0.0) + entry.amount
                if entry.target_organ == organ_id:
                    balance[entry.currency] = balance.get(entry.currency, 0.0) - entry.amount
        # Round
        for cur in balance:
            balance[cur] = round(balance[cur], 4)
        return balance

    # ------------------------------------------------------------------
    # Reconciliation
    # ------------------------------------------------------------------

    def run_reconciliation(
        self,
        period_start: str,
        period_end: str,
        external_totals: Optional[Dict[str, float]] = None,
    ) -> Dict[str, Any]:
        """
        Run reconciliation across all currencies.

        external_totals: dict of currency → total amount from external system.
        Returns per-currency reconciliation results.
        """
        results: Dict[str, Any] = {}
        with self._lock:
            for currency in SUPPORTED_CURRENCIES:
                entries_in_currency = [
                    e for e in self._entries.values()
                    if e.currency == currency
                    and period_start <= e.created_at <= period_end
                    and e.status == "settled"
                ]
                ledger_total = round(sum(e.amount for e in entries_in_currency), 4)
                external = external_totals.get(currency) if external_totals else None

                if external is not None:
                    discrepancy = round(ledger_total - external, 4)
                    status = "matched" if abs(discrepancy) <= 0.01 else "discrepancy"
                else:
                    discrepancy = 0.0
                    status = "reference_unavailable"

                results[currency] = {
                    "ledger_total": ledger_total,
                    "external_total": external,
                    "discrepancy": discrepancy,
                    "status": status,
                    "entry_count": len(entries_in_currency),
                }

        return results

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of the ledger."""
        with self._lock:
            total_entries = len(self._entries)
            settled = sum(1 for e in self._entries.values() if e.status == "settled")
            pending = sum(1 for e in self._entries.values() if e.status == "pending")
            disputed = sum(1 for e in self._entries.values() if e.status == "disputed")
            total_usd = round(sum(e.amount_usd for e in self._entries.values() if e.status == "settled"), 2)
            organs = set()
            for e in self._entries.values():
                organs.add(e.source_organ)
                organs.add(e.target_organ)

            return {
                "total_entries": total_entries,
                "settled": settled,
                "pending": pending,
                "disputed": disputed,
                "total_settled_usd": total_usd,
                "organs": sorted(organs),
                "currencies_used": sorted(set(e.currency for e in self._entries.values())),
            }


# Module-level singleton
REAL_FIN_OPS_LEDGER = RealFinOpsLedger()
