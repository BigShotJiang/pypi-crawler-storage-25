"""
Tests for L5-T4 — Financial Ops Approval Queue Integration.

Tests:
1. Payments under $100 auto-approve
2. Payments over $100 require approval
3. Multi-currency threshold detection (ETH/USD conversion)
4. Submit → approve flow
5. Submit → reject flow
6. Approval/rejection audit trail
7. Trusted organs get higher threshold
8. Pending approvals listing
9. Approval history
10. Summary statistics
"""

import json
import os
import sys
from pathlib import Path

_simp_inner = Path(__file__).resolve().parent.parent
if str(_simp_inner) not in sys.path:
    sys.path.insert(0, str(_simp_inner))

from simp.financial.approval_integration import (
    ApprovalIntegrationManager,
    AUTO_APPROVAL_THRESHOLD_USD,
    TRUSTED_ORGANS,
)


class TestL5T4ApprovalIntegration:
    """L5-T4: Financial Ops Approval Queue."""

    def setup_method(self):
        # Clear any existing test state
        self.approval_file = "/tmp/test_approval_queue.jsonl"
        if os.path.exists(self.approval_file):
            os.remove(self.approval_file)

    # ------------------------------------------------------------------
    # T4.1 — Payment under $100 auto-approves
    # ------------------------------------------------------------------

    def test_payment_under_threshold_auto_approves(self):
        """Payment under $100 USD threshold auto-approves."""
        mgr = ApprovalIntegrationManager()
        result = mgr.submit_payment_for_approval(
            organ_id="kashclaw",
            amount=50.00,
            currency="USD",
            vendor="OpenAI",
            description="API credits",
        )

        assert result["status"] == "approved"
        assert result["auto_approved"] is True

    # ------------------------------------------------------------------
    # T4.2 — Payment over $100 requires approval
    # ------------------------------------------------------------------

    def test_payment_over_threshold_requires_approval(self):
        """Payment over $100 USD threshold requires approval."""
        mgr = ApprovalIntegrationManager()
        result = mgr.submit_payment_for_approval(
            organ_id="kashclaw",
            amount=150.00,
            currency="USD",
            vendor="AWS",
            description="Cloud compute",
        )

        assert result["status"] == "submitted"
        assert "proposal_id" in result
        assert "threshold" in result["threshold_reason"]

    # ------------------------------------------------------------------
    # T4.3 — Multi-currency threshold detection (ETH)
    # ------------------------------------------------------------------

    def test_eth_payment_over_threshold_requires_approval(self):
        """ETH payment equivalent to >$100 requires approval."""
        mgr = ApprovalIntegrationManager()
        # 0.1 ETH ≈ $187 USD at current rates
        result = mgr.submit_payment_for_approval(
            organ_id="kashclaw",
            amount=0.1,
            currency="ETH",
            vendor="Ethereum Gas",
            description="Smart contract execution",
        )

        assert result["status"] == "submitted"
        assert result["usd_equivalent"] > AUTO_APPROVAL_THRESHOLD_USD

    # ------------------------------------------------------------------
    # T4.4 — Small ETH payment auto-approves
    # ------------------------------------------------------------------

    def test_small_eth_payment_auto_approves(self):
        """Small ETH payment (under $100 equivalent) auto-approves."""
        mgr = ApprovalIntegrationManager()
        # 0.01 ETH ≈ $18.75 USD — well under $100
        result = mgr.submit_payment_for_approval(
            organ_id="kashclaw",
            amount=0.01,
            currency="ETH",
            vendor="Test Gas",
            description="Small tx",
        )

        assert result["status"] == "approved"
        assert result["auto_approved"] is True
        assert result["usd_equivalent"] < AUTO_APPROVAL_THRESHOLD_USD

    # ------------------------------------------------------------------
    # T4.5 — Submit → Approve flow
    # ------------------------------------------------------------------

    def test_submit_and_approve_flow(self):
        """Submit a payment, then approve it."""
        mgr = ApprovalIntegrationManager()
        submitted = mgr.submit_payment_for_approval(
            organ_id="kashclaw",
            amount=500.00,
            currency="USD",
            vendor="Vendor A",
            description="Large purchase",
        )

        assert submitted["status"] == "submitted"
        proposal_id = submitted["proposal_id"]

        # Approve
        approved = mgr.approve_payment(proposal_id, "operator@kashclaw")
        assert approved["status"] == "approved"
        assert approved["approved_by"] == "operator@kashclaw"
        assert approved["proposal_id"] == proposal_id

    # ------------------------------------------------------------------
    # T4.6 — Submit → Reject flow
    # ------------------------------------------------------------------

    def test_submit_and_reject_flow(self):
        """Submit a payment, then reject it."""
        mgr = ApprovalIntegrationManager()
        submitted = mgr.submit_payment_for_approval(
            organ_id="kashclaw",
            amount=999.99,
            currency="USD",
            vendor="Vendor B",
            description="Expensive item",
        )

        proposal_id = submitted["proposal_id"]

        # Reject
        rejected = mgr.reject_payment(proposal_id, "auditor@kashclaw", reason="Budget exceeded")
        assert rejected["status"] == "rejected"
        assert rejected["rejected_by"] == "auditor@kashclaw"
        assert "Budget exceeded" in rejected["reason"]

    # ------------------------------------------------------------------
    # T4.7 — Trusted organs have higher threshold
    # ------------------------------------------------------------------

    def test_trusted_organ_higher_threshold(self):
        """Trusted organs can auto-approve up to $500."""
        mgr = ApprovalIntegrationManager()

        # quantumarb is trusted — $200 should auto-approve
        result = mgr.submit_payment_for_approval(
            organ_id="quantumarb",
            amount=200.00,
            currency="USD",
            vendor="Exchange",
            description="Trading fee",
        )

        assert result["status"] == "approved"
        assert result["auto_approved"] is True

    # ------------------------------------------------------------------
    # T4.8 — Pending approvals listing
    # ------------------------------------------------------------------

    def test_approve_reduces_pending_count(self):
        """Approving a proposal reduces the pending count."""
        mgr = ApprovalIntegrationManager()

        before = len(mgr.get_pending_approvals())

        # Submit an over-threshold payment
        r = mgr.submit_payment_for_approval("kashclaw", 200.00, "USD", "V-Approve", "payment to approve")
        mgr.approve_payment(r["proposal_id"], "operator@kashclaw")

        after = len(mgr.get_pending_approvals())
        # Our approved proposal should no longer be pending
        # (Count may not drop by exactly 1 if other tests added proposals,
        #  but the approved proposal won't be in pending list)
        pending_ids = [p["proposal_id"] for p in mgr.get_pending_approvals()]
        assert r["proposal_id"] not in pending_ids

    # ------------------------------------------------------------------
    # T4.9 — Approval history
    # ------------------------------------------------------------------

    def test_approval_history(self):
        """get_approval_history returns all proposals."""
        mgr = ApprovalIntegrationManager()

        mgr.submit_payment_for_approval("kashclaw", 50.00, "USD", "V1", "small")
        mgr.submit_payment_for_approval("kashclaw", 200.00, "USD", "V2", "large")

        history = mgr.get_approval_history()
        assert len(history) >= 2

    # ------------------------------------------------------------------
    # T4.10 — Summary statistics
    # ------------------------------------------------------------------

    def test_summary_statistics(self):
        """get_summary returns correct statistics."""
        mgr = ApprovalIntegrationManager()

        # Auto-approved
        mgr.submit_payment_for_approval("kashclaw", 50.00, "USD", "VendorX", "small")

        # Submitted + approved
        r = mgr.submit_payment_for_approval("kashclaw", 200.00, "USD", "VendorY", "medium")
        mgr.approve_payment(r["proposal_id"], "op@kashclaw")

        # Submitted + rejected
        r2 = mgr.submit_payment_for_approval("kashclaw", 300.00, "USD", "VendorZ", "large")
        mgr.reject_payment(r2["proposal_id"], "auditor@kashclaw", reason="Not needed")

        summary = mgr.get_summary()
        assert summary["total_proposals"] >= 3
        assert summary["threshold_usd"] == 100.00
        assert "VendorY" in summary["vendor_summary"]
