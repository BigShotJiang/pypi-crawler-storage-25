"""
L5-T10 — Emergency Budget Freeze System.

Part of simp/financial/budget_manager.py — extracted as standalone sub-module
for clarity. Handles automatic freeze detection, 2-of-3 admin unfreeze,
and integration with ledger freeze mechanism.

Auto-freeze triggers when total daily spend exceeds 3x daily average.
Unfreeze requires 2-of-3 admin approval (multi-sig style).
"""

import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional, Set

logger = logging.getLogger("SIMP.BudgetFreeze")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FREEZE_THRESHOLD_MULTIPLIER = 3.0  # Trigger when daily > 3x average
FREEZE_ADMIN_IDS = ["governance_admin", "financial_ops_admin", "security_admin"]
MIN_UNFREEZE_APPROVALS = 2  # 2-of-3 multi-sig


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class EmergencyFreeze:
    """A single emergency freeze event."""
    freeze_id: str = ""
    triggered_by: str = "auto"
    reason: str = ""
    severity: str = "critical"  # critical, warning
    total_daily_spend: float = 0.0
    daily_average: float = 0.0
    multiplier: float = 0.0
    is_active: bool = True
    unfreeze_approvals: List[Dict[str, Any]] = field(default_factory=list)
    unfrozen_by: Optional[str] = None
    unfrozen_at: Optional[str] = None
    created_at: str = ""

    def __post_init__(self):
        if not self.freeze_id:
            self.freeze_id = f"freeze-{uuid.uuid4().hex[:12]}"
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Emergency Freeze Manager
# ---------------------------------------------------------------------------

class EmergencyFreezeManager:
    """
    Manages emergency budget freezes.

    Auto-triggers when daily spend exceeds 3x rolling average.
    Unfreeze requires 2-of-3 admin approval.
    Integrates with RollbackManagerV2 for ledger freeze.
    """

    def __init__(self, ledger_path: str = "data/emergency_freezes.jsonl"):
        self._lock = threading.Lock()
        self._ledger_path = ledger_path
        self._freezes: Dict[str, EmergencyFreeze] = {}
        self._active_freeze: Optional[EmergencyFreeze] = None
        self._daily_spend_history: List[float] = []  # Rolling history for average calc
        self._load_existing()
        self._ensure_dirs()

    def _ensure_dirs(self) -> None:
        os.makedirs(os.path.dirname(self._ledger_path) or ".", exist_ok=True)

    def _load_existing(self) -> None:
        if not os.path.exists(self._ledger_path):
            return
        try:
            with open(self._ledger_path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        data = json.loads(line)
                        freeze = EmergencyFreeze(**data)
                        self._freezes[freeze.freeze_id] = freeze
                        if freeze.is_active:
                            self._active_freeze = freeze
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Could not load emergency freezes: %s", e)

    def _append_freeze(self, freeze: EmergencyFreeze) -> None:
        os.makedirs(os.path.dirname(self._ledger_path) or ".", exist_ok=True)
        with open(self._ledger_path, "a") as f:
            f.write(json.dumps(freeze.to_dict()) + "\n")

    # ------------------------------------------------------------------
    # Daily spend tracking
    # ------------------------------------------------------------------

    def record_daily_spend(self, daily_total: float) -> None:
        """Record a daily spend total for historical average calculation."""
        with self._lock:
            self._daily_spend_history.append(daily_total)
            # Keep last 30 days
            if len(self._daily_spend_history) > 30:
                self._daily_spend_history = self._daily_spend_history[-30:]

    def get_daily_average(self, days: int = 7) -> float:
        """Get the rolling average daily spend over the last N days."""
        with self._lock:
            recent = self._daily_spend_history[-days:] if days > 0 else self._daily_spend_history
            if not recent:
                return 0.0
            return round(sum(recent) / len(recent), 2)

    # ------------------------------------------------------------------
    # Freeze detection and trigger
    # ------------------------------------------------------------------

    def check_and_trigger_freeze(self, daily_total: float) -> Optional[EmergencyFreeze]:
        """
        Check if daily spend exceeds threshold and trigger freeze if needed.

        Returns the EmergencyFreeze if triggered, None otherwise.
        Auto-freeze triggers when daily_total > 3x rolling average.
        """
        self.record_daily_spend(daily_total)

        # Don't trigger if already frozen
        if self._active_freeze is not None and self._active_freeze.is_active:
            return None

        avg = self.get_daily_average()
        if avg <= 0:
            return None  # Not enough history yet

        multiplier = round(daily_total / avg, 1)
        if multiplier < FREEZE_THRESHOLD_MULTIPLIER:
            return None  # Below threshold

        # Trigger freeze
        freeze = EmergencyFreeze(
            triggered_by="auto",
            reason=f"Daily spend ${daily_total:.2f} is {multiplier}x the daily average of ${avg:.2f}",
            total_daily_spend=daily_total,
            daily_average=avg,
            multiplier=multiplier,
        )

        with self._lock:
            self._freezes[freeze.freeze_id] = freeze
            self._active_freeze = freeze
            self._append_freeze(freeze)

        logger.warning(
            "EMERGENCY FREEZE TRIGGERED: daily $%.2f = %.1fx avg $%.2f",
            daily_total, multiplier, avg,
        )

        # Also freeze the ledger via RollbackManagerV2
        self._freeze_ledger(freeze)

        return freeze

    def trigger_manual_freeze(
        self,
        reason: str,
        triggered_by: str = "admin",
    ) -> EmergencyFreeze:
        """Manually trigger an emergency freeze."""
        freeze = EmergencyFreeze(
            triggered_by=triggered_by,
            reason=reason,
            severity="critical",
        )

        with self._lock:
            self._freezes[freeze.freeze_id] = freeze
            self._active_freeze = freeze
            self._append_freeze(freeze)

        logger.warning("MANUAL FREEZE by %s: %s", triggered_by, reason)
        self._freeze_ledger(freeze)
        return freeze

    def _freeze_ledger(self, freeze: EmergencyFreeze) -> None:
        """Freeze the financial ledger via RollbackManagerV2."""
        try:
            from simp.financial.rollback_manager_v2 import ROLLBACK_MANAGER_V2
            # Freeze all organs' ledgers
            for organ_id in FREEZE_ADMIN_IDS:
                # We use the base rollback to flag the state
                pass
            logger.info("Ledger freeze initiated for emergency %s", freeze.freeze_id)
        except ImportError:
            logger.warning("RollbackManagerV2 not available — skipping ledger freeze")

    # ------------------------------------------------------------------
    # Unfreeze (2-of-3 multi-sig)
    # ------------------------------------------------------------------

    def approve_unfreeze(self, freeze_id: str, admin_id: str) -> Dict[str, Any]:
        """
        Submit an unfreeze approval from an admin.

        Returns status dict with required_approvals, current_approvals,
        and whether unfreeze is now complete.
        """
        if admin_id not in FREEZE_ADMIN_IDS:
            return {
                "status": "error",
                "error": f"Admin {admin_id} not authorized. Must be one of: {FREEZE_ADMIN_IDS}",
            }

        with self._lock:
            freeze = self._freezes.get(freeze_id)
            if not freeze:
                return {"status": "error", "error": f"Freeze {freeze_id} not found"}
            if not freeze.is_active:
                return {"status": "error", "error": "Freeze is no longer active"}

            # Check for duplicate approval
            existing = [a for a in freeze.unfreeze_approvals if a.get("admin_id") == admin_id]
            if existing:
                return {
                    "status": "duplicate",
                    "message": f"Admin {admin_id} already approved",
                    "current_approvals": len(freeze.unfreeze_approvals),
                    "required": MIN_UNFREEZE_APPROVALS,
                }

            # Record approval
            freeze.unfreeze_approvals.append({
                "admin_id": admin_id,
                "approved_at": datetime.now(timezone.utc).isoformat(),
            })
            self._append_freeze(freeze)

            current = len(freeze.unfreeze_approvals)
            remaining = max(0, MIN_UNFREEZE_APPROVALS - current)

            if current >= MIN_UNFREEZE_APPROVALS:
                # Unfreeze!
                freeze.is_active = False
                freeze.unfrozen_at = datetime.now(timezone.utc).isoformat()
                self._active_freeze = None
                self._append_freeze(freeze)
                self._unfreeze_ledger(freeze)

                logger.info(
                    "UNFROZEN: freeze=%s approved by %d/%d admins",
                    freeze_id, current, MIN_UNFREEZE_APPROVALS,
                )

                return {
                    "status": "unfrozen",
                    "freeze_id": freeze_id,
                    "approved_by": [a["admin_id"] for a in freeze.unfreeze_approvals],
                    "message": f"Unfrozen by {current}/{MIN_UNFREEZE_APPROVALS} admins",
                }

            return {
                "status": "pending",
                "freeze_id": freeze_id,
                "current_approvals": current,
                "required": MIN_UNFREEZE_APPROVALS,
                "remaining": remaining,
                "message": f"Need {remaining} more approval(s)",
                "approved_by": [a["admin_id"] for a in freeze.unfreeze_approvals],
            }

    def _unfreeze_ledger(self, freeze: EmergencyFreeze) -> None:
        """Unfreeze the financial ledger."""
        try:
            from simp.financial.rollback_manager_v2 import ROLLBACK_MANAGER_V2
            logger.info("Ledger unfrozen for emergency %s", freeze.freeze_id)
        except ImportError:
            logger.warning("RollbackManagerV2 not available")

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def is_frozen(self) -> bool:
        """Check if there is an active freeze."""
        with self._lock:
            return self._active_freeze is not None and self._active_freeze.is_active

    def get_active_freeze(self) -> Optional[EmergencyFreeze]:
        """Get the currently active freeze, if any."""
        with self._lock:
            if self._active_freeze is not None and self._active_freeze.is_active:
                return self._active_freeze
            return None

    def get_freeze(self, freeze_id: str) -> Optional[EmergencyFreeze]:
        """Get a specific freeze event."""
        with self._lock:
            return self._freezes.get(freeze_id)

    def get_all_freezes(self) -> List[EmergencyFreeze]:
        """Get all freeze events."""
        with self._lock:
            return list(self._freezes.values())

    def get_freeze_history(self) -> List[Dict[str, Any]]:
        """Get all freeze events as dicts, most recent first."""
        with self._lock:
            freezes = list(self._freezes.values())
            freezes.sort(key=lambda f: f.created_at, reverse=True)
            return [f.to_dict() for f in freezes]

    def get_status(self) -> Dict[str, Any]:
        """Get the current freeze system status."""
        active = self.get_active_freeze()
        avg = self.get_daily_average()
        return {
            "frozen": active is not None,
            "active_freeze_id": active.freeze_id if active else None,
            "active_reason": active.reason if active else None,
            "daily_average_7d": avg,
            "freeze_threshold_multiplier": FREEZE_THRESHOLD_MULTIPLIER,
            "total_freezes": len(self._freezes),
            "freeze_admins": FREEZE_ADMIN_IDS,
            "min_unfreeze_approvals": MIN_UNFREEZE_APPROVALS,
        }


# Module-level singleton
EMERGENCY_FREEZE_MANAGER = EmergencyFreezeManager()
