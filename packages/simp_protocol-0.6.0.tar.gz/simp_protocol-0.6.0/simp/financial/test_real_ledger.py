"""
Tests for L5-T2 — Real Financial Operations Ledger.

Tests:
1. Multi-currency transaction recording (USD, USDC, ETH, BTC)
2. Dual-party signing (source signs on create, target signs on settle)
3. Exchange rate resolution (fallback to defaults if API unavailable)
4. Settlement flow (pending → settled)
5. Dispute flow
6. Balance calculation
7. Reconciliation with external totals
8. Summary statistics
"""

import json
import os
import sys
import tempfile
from pathlib import Path

# Ensure inner simp package is importable
_simp_inner = Path(__file__).resolve().parent.parent
if str(_simp_inner) not in sys.path:
    sys.path.insert(0, str(_simp_inner))

from simp.financial.real_ledger import RealFinOpsLedger, FinOpsEntry, SUPPORTED_CURRENCIES


class TestL5T2RealFinOpsLedger:
    """L5-T2: Real Financial Operations Ledger."""

    def setup_method(self):
        self.ledger_path = "/tmp/test_finops_ledger.jsonl"
        if os.path.exists(self.ledger_path):
            os.remove(self.ledger_path)

    # ------------------------------------------------------------------
    # T2.1 — Record a USD transaction
    # ------------------------------------------------------------------

    def test_record_usd_transaction(self):
        """Recording a USD transaction creates a pending entry."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)
        entry = ledger.record_transaction(
            source_organ="quantumarb",
            target_organ="kashclaw",
            amount=100.00,
            currency="USD",
            intent_id="intent-001",
            description="Market data subscription",
            source_signature="sig_abc123",
        )

        assert entry.source_organ == "quantumarb"
        assert entry.target_organ == "kashclaw"
        assert entry.amount == 100.00
        assert entry.currency == "USD"
        assert entry.amount_usd == 100.00  # USD → USD is 1:1
        assert entry.status == "pending"
        assert entry.source_signature == "sig_abc123"
        assert entry.exchange_source in ("coinbase", "kraken", "default")

    # ------------------------------------------------------------------
    # T2.2 — Record a multi-currency transaction (ETH)
    # ------------------------------------------------------------------

    def test_record_eth_transaction(self):
        """Recording an ETH transaction resolves exchange rate."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)
        entry = ledger.record_transaction(
            source_organ="quantumarb",
            target_organ="kashclaw",
            amount=0.5,
            currency="ETH",
            intent_id="intent-002",
            source_signature="sig_eth123",
        )

        assert entry.currency == "ETH"
        assert entry.amount == 0.5
        assert entry.amount_usd > 0  # Rate was resolved
        assert entry.exchange_rate_used > 0
        assert entry.status == "pending"

    # ------------------------------------------------------------------
    # T2.3 — Record BTC transaction
    # ------------------------------------------------------------------

    def test_record_btc_transaction(self):
        """Recording a BTC transaction resolves exchange rate."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)
        entry = ledger.record_transaction(
            source_organ="kashclaw",
            target_organ="quantumarb",
            amount=0.01,
            currency="BTC",
            source_signature="sig_btc456",
        )

        assert entry.currency == "BTC"
        assert entry.amount == 0.01  # Fixed: BTC not BCH
        assert entry.amount_usd > 0
        assert entry.status == "pending"

    # ------------------------------------------------------------------
    # T2.4 — Unsupported currency raises error
    # ------------------------------------------------------------------

    def test_unsupported_currency_raises_error(self):
        """Unsupported currency raises ValueError."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)
        try:
            ledger.record_transaction(
                source_organ="quantumarb",
                target_organ="kashclaw",
                amount=100.00,
                currency="XRP",
                source_signature="sig_err",
            )
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "XRP" in str(e)

    # ------------------------------------------------------------------
    # T2.5 — Settle a transaction
    # ------------------------------------------------------------------

    def test_settle_transaction(self):
        """Settling a transaction transitions from pending → settled."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)
        entry = ledger.record_transaction(
            source_organ="quantumarb",
            target_organ="kashclaw",
            amount=50.00,
            currency="USD",
            source_signature="sig_source",
        )

        assert entry.status == "pending"

        settled = ledger.settle_transaction(
            entry_id=entry.entry_id,
            target_signature="sig_target",
        )

        assert settled is not None
        assert settled.status == "settled"
        assert settled.target_signature == "sig_target"
        assert settled.settled_at is not None

    # ------------------------------------------------------------------
    # T2.6 — Settle non-existent entry returns None
    # ------------------------------------------------------------------

    def test_settle_nonexistent_entry(self):
        """Settling a non-existent entry returns None."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)
        result = ledger.settle_transaction(
            entry_id="nonexistent_id",
            target_signature="sig_fake",
        )
        assert result is None

    # ------------------------------------------------------------------
    # T2.7 — Dispute a transaction
    # ------------------------------------------------------------------

    def test_dispute_transaction(self):
        """Disputing a transaction changes status to disputed."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)
        entry = ledger.record_transaction(
            source_organ="quantumarb",
            target_organ="kashclaw",
            amount=500.00,
            currency="USDC",
            source_signature="sig_dispute",
        )

        disputed = ledger.dispute_transaction(entry.entry_id, reason="Incorrect amount")
        assert disputed is not None
        assert disputed.status == "disputed"
        assert "Incorrect amount" in disputed.description

    # ------------------------------------------------------------------
    # T2.8 — Balance calculation
    # ------------------------------------------------------------------

    def test_balance_calculation(self):
        """Balance calculation reflects net organ position."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)

        # quantumarb pays kashclaw $100
        e1 = ledger.record_transaction("quantumarb", "kashclaw", 100.00, "USD", source_signature="s1")
        ledger.settle_transaction(e1.entry_id, "t1")

        # quantumarb pays kashclaw $50 (ETH equivalent)
        e2 = ledger.record_transaction("quantumarb", "kashclaw", 0.5, "ETH", source_signature="s2")
        ledger.settle_transaction(e2.entry_id, "t2")

        # Check quantumarb balance (should be negative — they owe)
        q_balance = ledger.get_balance("quantumarb")
        assert q_balance["USD"] == 100.0  # quantumarb is owed 100
        assert q_balance["ETH"] == 0.5    # quantumarb is owed 0.5 ETH

        # Check kashclaw balance (should be positive — they're owed)
        k_balance = ledger.get_balance("kashclaw")
        assert k_balance["USD"] == -100.0  # kashclaw owes -100
        assert k_balance["ETH"] == -0.5    # kashclaw owes -0.5 ETH

    # ------------------------------------------------------------------
    # T2.9 — Get entries for an organ
    # ------------------------------------------------------------------

    def test_get_entries_for_organ(self):
        """get_entries_for_organ returns all entries involving that organ."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)

        ledger.record_transaction("quantumarb", "kashclaw", 100.00, "USD", source_signature="s1")
        ledger.record_transaction("kashclaw", "media", 50.00, "USD", source_signature="s2")

        q_entries = ledger.get_entries_for_organ("quantumarb")
        assert len(q_entries) == 1

        k_entries = ledger.get_entries_for_organ("kashclaw")
        assert len(k_entries) == 2  # Both as source and target

    # ------------------------------------------------------------------
    # T2.10 — Summary statistics
    # ------------------------------------------------------------------

    def test_summary_statistics(self):
        """get_summary returns correct statistics."""
        ledger = RealFinOpsLedger(ledger_path=self.ledger_path)

        # Add some entries
        e1 = ledger.record_transaction("quantumarb", "kashclaw", 100.00, "USD", source_signature="s1")
        e2 = ledger.record_transaction("kashclaw", "media", 50.00, "USDC", source_signature="s2")
        e3 = ledger.record_transaction("media", "quantumarb", 0.1, "ETH", source_signature="s3")

        ledger.settle_transaction(e1.entry_id, "t1")
        ledger.settle_transaction(e2.entry_id, "t2")
        # e3 stays pending

        summary = ledger.get_summary()
        assert summary["total_entries"] == 3
        assert summary["settled"] == 2
        assert summary["pending"] == 1
        assert "quantumarb" in summary["organs"]
        assert "USD" in summary["currencies_used"]
        assert "ETH" in summary["currencies_used"]
