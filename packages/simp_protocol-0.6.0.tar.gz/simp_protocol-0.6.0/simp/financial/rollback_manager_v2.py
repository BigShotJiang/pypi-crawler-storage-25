"""
L5-T5 — Financial Ops Rollback Mechanism (Enhanced).

Extends the base RollbackManager with:
1. Auto-rollback on payment/transaction failure
2. Frozen ledger support with timeout-based release
3. Detailed RollbackState machine (pending → in_progress → rolled_back / failed)
4. Integration with ApprovalIntegrationManager and RealFinOpsLedger
5. Per-organ rollback policies and history

Builds on: simp/compat/rollback.py (base RollbackManager, RollbackState, LedgerFrozenError)
Integrates with: simp/financial/real_ledger.py (RealFinOpsLedger for transaction reversal)
                 simp/financial/approval_integration.py (pending proposal cancellation)
"""

import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Dict, Any, List, Optional, Set, Callable

from simp.compat.rollback import (
    RollbackManager,
    RollbackState as BaseRollbackState,
    RollbackRecord,
    LedgerFrozenError,
    ROLLBACK_MANAGER,
)

logger = logging.getLogger("SIMP.FinOpsRollbackV2")

# ---------------------------------------------------------------------------
# Enhanced Rollback State
# ---------------------------------------------------------------------------

class RollbackDetailState(str, Enum):
    """Detailed rollback state for a single operation."""
    PENDING = "pending"              # Operational failure detected, rollback queued
    IN_PROGRESS = "in_progress"      # Rollback is being executed
    ROLLED_BACK = "rolled_back"      # Successfully rolled back
    FAILED = "failed"                # Rollback itself failed
    SKIPPED = "skipped"              # Rollback skipped (amount too small / policy)
    EXPIRED = "expired"              # Rollback timeout reached, amount released


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class RollbackOperation:
    """A single rollback operation for a failed financial intent."""
    operation_id: str = ""
    intent_id: str = ""
    source_organ: str = ""
    target_organ: str = ""
    amount: float = 0.0
    currency: str = "USD"
    entry_id: str = ""               # Reference to the FinOpsEntry being rolled back
    original_status: str = ""        # Status of the operation before failure
    failure_reason: str = ""
    state: str = RollbackDetailState.PENDING.value
    frozen_until: str = ""           # ISO8601 timestamp when frozen amount is released
    released_at: Optional[str] = None
    error_detail: Optional[str] = None
    triggered_by: str = "auto"
    created_at: str = ""
    completed_at: Optional[str] = None

    def __post_init__(self):
        if not self.operation_id:
            self.operation_id = f"rb-{uuid.uuid4().hex[:12]}"
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
        if not self.frozen_until:
            # Default freeze timeout: 30 minutes
            timeout = datetime.now(timezone.utc) + timedelta(minutes=30)
            self.frozen_until = timeout.isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RollbackPolicy:
    """Per-organ rollback policy."""
    organ_id: str
    auto_rollback_enabled: bool = True
    max_rollback_amount: float = 500.0  # Max amount per single rollback
    freeze_timeout_minutes: int = 30
    max_rollbacks_per_hour: int = 5
    notify_on_failure: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RollbackSummary:
    """Summary of rollback operations for a period."""
    total_operations: int = 0
    rolled_back: int = 0
    failed: int = 0
    skipped: int = 0
    expired: int = 0
    total_amount_rolled_back: float = 0.0
    total_amount_frozen: float = 0.0
    organs_affected: List[str] = field(default_factory=list)
    period_start: str = ""
    period_end: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Enhanced Rollback Manager V2
# ---------------------------------------------------------------------------

class RollbackManagerV2:
    """
    Enhanced rollback manager for financial operations.

    Features:
    - Auto-rollback on payment failure detection
    - Frozen ledger support with timeout-based release
    - Per-organ rollback policies
    - Integration with RealFinOpsLedger for transaction reversal
    - Rollback history with detailed state tracking
    - Rate limiting to prevent rollback storms
    """

    def __init__(self, ledger_path: str = "data/rollback_v2_log.jsonl"):
        self._lock = threading.Lock()
        self._ledger_path = ledger_path
        self._operations: Dict[str, RollbackOperation] = {}
        self._policies: Dict[str, RollbackPolicy] = {}
        self._base_manager = ROLLBACK_MANAGER
        self._frozen_ledgers: Set[str] = set()  # Set of organ_ids with frozen ledgers
        self._rollback_counts: Dict[str, List[float]] = {}  # organ_id → [timestamps]
        self._event_handlers: List[Callable] = []
        self._load_existing()
        self._ensure_dirs()

    def _ensure_dirs(self) -> None:
        os.makedirs(os.path.dirname(self._ledger_path) or ".", exist_ok=True)

    def _load_existing(self) -> None:
        if not os.path.exists(self._ledger_path):
            return
        try:
            with open(self._ledger_path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        data = json.loads(line)
                        op = RollbackOperation(**data)
                        self._operations[op.operation_id] = op
                        if op.state == RollbackDetailState.PENDING.value:
                            self._frozen_ledgers.add(op.source_organ)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Could not load rollback ledger: %s", e)

    def _append_operation(self, op: RollbackOperation) -> None:
        os.makedirs(os.path.dirname(self._ledger_path) or ".", exist_ok=True)
        with open(self._ledger_path, "a") as f:
            f.write(json.dumps(op.to_dict()) + "\n")

    # ------------------------------------------------------------------
    # Policy Management
    # ------------------------------------------------------------------

    def set_policy(self, organ_id: str, policy: RollbackPolicy) -> None:
        """Set or update a rollback policy for an organ."""
        with self._lock:
            self._policies[organ_id] = policy
        logger.info("Rollback policy set for %s: auto=%s, max=%.2f",
                     organ_id, policy.auto_rollback_enabled, policy.max_rollback_amount)

    def get_policy(self, organ_id: str) -> RollbackPolicy:
        """Get rollback policy for an organ, or return default."""
        with self._lock:
            return self._policies.get(
                organ_id,
                RollbackPolicy(organ_id=organ_id),
            )

    def remove_policy(self, organ_id: str) -> bool:
        """Remove a rollback policy (reverts to default)."""
        with self._lock:
            return self._policies.pop(organ_id, None) is not None

    # ------------------------------------------------------------------
    # Event Handlers
    # ------------------------------------------------------------------

    def on_event(self, handler: Callable) -> None:
        """Register a callback for rollback events. Callable(op) will be called."""
        with self._lock:
            self._event_handlers.append(handler)

    def _emit_event(self, op: RollbackOperation) -> None:
        with self._lock:
            handlers = list(self._event_handlers)
        for handler in handlers:
            try:
                handler(op)
            except Exception as e:
                logger.warning("Rollback event handler failed: %s", e)

    # ------------------------------------------------------------------
    # Core Rollback Logic
    # ------------------------------------------------------------------

    def auto_rollback_on_failure(
        self,
        intent_id: str,
        source_organ: str,
        target_organ: str,
        amount: float,
        currency: str = "USD",
        entry_id: str = "",
        failure_reason: str = "",
        triggered_by: str = "auto",
    ) -> RollbackOperation:
        """
        Automatically execute rollback when a financial operation fails.

        Checks organ policy, rate limits, and amount thresholds before executing.
        Freezes the amount until rollback completes or timeout expires.
        """
        # Build the rollback operation
        policy = self.get_policy(source_organ)

        # Check if rollback is allowed
        if not policy.auto_rollback_enabled:
            op = RollbackOperation(
                intent_id=intent_id,
                source_organ=source_organ,
                target_organ=target_organ,
                amount=amount,
                currency=currency,
                entry_id=entry_id,
                failure_reason=failure_reason,
                state=RollbackDetailState.SKIPPED.value,
                triggered_by=triggered_by,
                error_detail="Auto-rollback disabled by policy",
            )
            with self._lock:
                self._operations[op.operation_id] = op
                self._append_operation(op)
            self._emit_event(op)
            return op

        # Check amount threshold
        if amount > policy.max_rollback_amount:
            op = RollbackOperation(
                intent_id=intent_id,
                source_organ=source_organ,
                target_organ=target_organ,
                amount=amount,
                currency=currency,
                entry_id=entry_id,
                failure_reason=failure_reason,
                state=RollbackDetailState.SKIPPED.value,
                triggered_by=triggered_by,
                error_detail=f"Amount {amount} exceeds max rollback {policy.max_rollback_amount}",
            )
            with self._lock:
                self._operations[op.operation_id] = op
                self._append_operation(op)
            self._emit_event(op)
            return op

        # Check rate limit
        if self._check_rate_limit(source_organ, policy.max_rollbacks_per_hour):
            op = RollbackOperation(
                intent_id=intent_id,
                source_organ=source_organ,
                target_organ=target_organ,
                amount=amount,
                currency=currency,
                entry_id=entry_id,
                failure_reason=failure_reason,
                state=RollbackDetailState.SKIPPED.value,
                triggered_by=triggered_by,
                error_detail="Rate limit exceeded for rollbacks",
            )
            with self._lock:
                self._operations[op.operation_id] = op
                self._append_operation(op)
            self._emit_event(op)
            return op

        # Create pending operation (amount frozen)
        op = RollbackOperation(
            intent_id=intent_id,
            source_organ=source_organ,
            target_organ=target_organ,
            amount=amount,
            currency=currency,
            entry_id=entry_id,
            failure_reason=failure_reason,
            state=RollbackDetailState.PENDING.value,
            triggered_by=triggered_by,
        )

        with self._lock:
            self._operations[op.operation_id] = op
            self._append_operation(op)
            self._frozen_ledgers.add(source_organ)
            self._record_rollback_timestamp(source_organ)

        logger.info(
            "Auto-rollback queued for %s (intent=%s): %.4f %s — %s",
            source_organ, intent_id, amount, currency, failure_reason,
        )

        # Try to execute the rollback
        return self._execute_rollback(op)

    def _execute_rollback(self, op: RollbackOperation) -> RollbackOperation:
        """Execute a pending rollback operation."""
        with self._lock:
            op.state = RollbackDetailState.IN_PROGRESS.value
            self._append_operation(op)

        try:
            # 1. Record rollback in base RollbackManager
            self._base_manager.trigger_rollback(
                triggered_by=op.triggered_by,
                reason=f"Auto-rollback for intent {op.intent_id}: {op.failure_reason}",
            )

            # 2. Mark the ledger entry for reversal (if entry_id provided)
            if op.entry_id:
                self._reverse_ledger_entry(op)

            # 3. Mark as successfully rolled back
            with self._lock:
                op.state = RollbackDetailState.ROLLED_BACK.value
                op.completed_at = datetime.now(timezone.utc).isoformat()
                self._frozen_ledgers.discard(op.source_organ)
                self._append_operation(op)

            logger.info(
                "Rollback successful for %s: %.4f %s (op=%s)",
                op.source_organ, op.amount, op.currency, op.operation_id,
            )

        except Exception as e:
            # Rollback itself failed
            with self._lock:
                op.state = RollbackDetailState.FAILED.value
                op.error_detail = str(e)
                op.completed_at = datetime.now(timezone.utc).isoformat()
                self._append_operation(op)

            logger.error(
                "Rollback FAILED for %s: %.4f %s — %s",
                op.source_organ, op.amount, op.currency, e,
            )

        self._emit_event(op)
        return op

    def _reverse_ledger_entry(self, op: RollbackOperation) -> None:
        """
        Reverse a ledger entry as part of rollback.

        Creates a compensating entry in the ledger. Since ledgers are
        append-only, we add a reversal entry rather than modifying history.
        """
        try:
            from simp.financial.real_ledger import REAL_FIN_OPS_LEDGER
            REAL_FIN_OPS_LEDGER.record_transaction(
                source_organ=op.target_organ,
                target_organ=op.source_organ,
                amount=op.amount,
                currency=op.currency,
                intent_id=f"rollback-{op.intent_id}",
                description=f"Auto-rollback reversal for {op.intent_id}: {op.failure_reason}",
            )
            logger.debug("Ledger reversal recorded for entry %s", op.entry_id)
        except ImportError:
            logger.warning("RealFinOpsLedger not available — skipping ledger reversal")
        except Exception as e:
            logger.warning("Ledger reversal failed: %s", e)
            # Non-fatal — the rollback still succeeds at the system level

    def _check_rate_limit(self, organ_id: str, max_per_hour: int) -> bool:
        """Check if organ has exceeded rollback rate limit."""
        now = time.time()
        one_hour_ago = now - 3600
        with self._lock:
            timestamps = self._rollback_counts.get(organ_id, [])
            # Filter to last hour
            recent = [t for t in timestamps if t > one_hour_ago]
            self._rollback_counts[organ_id] = recent
            return len(recent) >= max_per_hour

    def _record_rollback_timestamp(self, organ_id: str) -> None:
        now = time.time()
        with self._lock:
            if organ_id not in self._rollback_counts:
                self._rollback_counts[organ_id] = []
            self._rollback_counts[organ_id].append(now)

    # ------------------------------------------------------------------
    # Freeze / Unfreeze
    # ------------------------------------------------------------------

    def is_ledger_frozen(self, organ_id: str) -> bool:
        """Check if an organ's ledger is frozen due to pending rollback."""
        with self._lock:
            return organ_id in self._frozen_ledgers

    def get_frozen_ledgers(self) -> List[str]:
        """Get list of organ IDs with frozen ledgers."""
        with self._lock:
            return list(self._frozen_ledgers)

    def release_frozen_amount(self, operation_id: str) -> Optional[RollbackOperation]:
        """
        Manually release a frozen amount (typically after timeout).

        Returns the operation with updated state, or None if not found.
        """
        with self._lock:
            op = self._operations.get(operation_id)
            if not op:
                return None
            if op.state == RollbackDetailState.ROLLED_BACK.value:
                # Already handled
                return op
            if op.state == RollbackDetailState.EXPIRED.value:
                # Already released
                return op

            op.state = RollbackDetailState.EXPIRED.value
            op.released_at = datetime.now(timezone.utc).isoformat()
            self._frozen_ledgers.discard(op.source_organ)
            self._append_operation(op)

        logger.info("Frozen amount released for op=%s (%s)", operation_id, op.source_organ)
        self._emit_event(op)
        return op

    def check_and_release_expired(self) -> List[RollbackOperation]:
        """
        Check all pending operations and release any that have exceeded
        their freeze timeout.

        Called periodically (e.g., by a background scheduler).
        """
        released: List[RollbackOperation] = []
        now = datetime.now(timezone.utc)

        with self._lock:
            for op in list(self._operations.values()):
                if op.state != RollbackDetailState.PENDING.value:
                    continue
                try:
                    frozen_until = datetime.fromisoformat(op.frozen_until)
                    if now >= frozen_until:
                        op.state = RollbackDetailState.EXPIRED.value
                        op.released_at = now.isoformat()
                        self._frozen_ledgers.discard(op.source_organ)
                        self._append_operation(op)
                        released.append(op)
                except (ValueError, TypeError):
                    continue

        for op in released:
            logger.info("Expired rollback released: op=%s", op.operation_id)
            self._emit_event(op)

        return released

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_operation(self, operation_id: str) -> Optional[RollbackOperation]:
        """Get a specific rollback operation."""
        with self._lock:
            return self._operations.get(operation_id)

    def get_operations_for_organ(self, organ_id: str) -> List[RollbackOperation]:
        """Get all rollback operations for a specific organ."""
        with self._lock:
            return [op for op in self._operations.values()
                    if op.source_organ == organ_id or op.target_organ == organ_id]

    def get_operations_by_state(self, state: str) -> List[RollbackOperation]:
        """Get all rollback operations in a specific state."""
        with self._lock:
            return [op for op in self._operations.values() if op.state == state]

    def get_all_operations(self) -> List[RollbackOperation]:
        """Get all rollback operations."""
        with self._lock:
            return list(self._operations.values())

    def get_summary(
        self,
        hours: int = 24,
    ) -> RollbackSummary:
        """Get a summary of rollback operations for the last N hours."""
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        organs: Set[str] = set()
        total_amount_rb = 0.0
        total_amount_frozen = 0.0
        rolled_back = 0
        failed = 0
        skipped = 0
        expired = 0

        with self._lock:
            ops = [op for op in self._operations.values() if op.created_at >= cutoff]

        for op in ops:
            organs.add(op.source_organ)
            organs.add(op.target_organ)
            if op.state == RollbackDetailState.ROLLED_BACK.value:
                rolled_back += 1
                total_amount_rb += op.amount
            elif op.state == RollbackDetailState.FAILED.value:
                failed += 1
            elif op.state == RollbackDetailState.SKIPPED.value:
                skipped += 1
            elif op.state in (RollbackDetailState.PENDING.value, RollbackDetailState.IN_PROGRESS.value):
                total_amount_frozen += op.amount
            elif op.state == RollbackDetailState.EXPIRED.value:
                expired += 1

        return RollbackSummary(
            total_operations=len(ops),
            rolled_back=rolled_back,
            failed=failed,
            skipped=skipped,
            expired=expired,
            total_amount_rolled_back=round(total_amount_rb, 2),
            total_amount_frozen=round(total_amount_frozen, 2),
            organs_affected=sorted(organs),
            period_start=cutoff,
            period_end=datetime.now(timezone.utc).isoformat(),
        )

    def get_base_rollback_status(self) -> Dict[str, Any]:
        """Get status from the base RollbackManager."""
        return self._base_manager.get_rollback_status()


# Module-level singleton
ROLLBACK_MANAGER_V2 = RollbackManagerV2()
