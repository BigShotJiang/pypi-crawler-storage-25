"""
Tests for L5-T3 — Multi-currency Financial Operations.

Tests:
1. Exchange rate fetching for all supported currencies (USD, USDC, ETH, BTC)
2. Currency conversion between any supported pair
3. Cross-currency settlement with audit trail
4. Same-currency settlement (direct)
5. Unsupported currency rejection
6. Payment execution in specific currency
7. Rate summary generation
"""

import json
import os
import sys
from pathlib import Path

_simp_inner = Path(__file__).resolve().parent.parent
if str(_simp_inner) not in sys.path:
    sys.path.insert(0, str(_simp_inner))

from simp.financial.multi_currency import MultiCurrencyFlowManager
from simp.financial.real_ledger import SUPPORTED_CURRENCIES


class TestL5T3MultiCurrency:
    """L5-T3: Multi-currency Financial Operations."""

    def setup_method(self):
        self.ledger_path = "/tmp/test_finops_t3.jsonl"
        if os.path.exists(self.ledger_path):
            os.remove(self.ledger_path)

    # ------------------------------------------------------------------
    # T3.1 — Exchange rate available for all supported currencies
    # ------------------------------------------------------------------

    def test_exchange_rates_available(self):
        """All supported currencies have exchange rates resolved."""
        mgr = MultiCurrencyFlowManager()
        for currency in SUPPORTED_CURRENCIES:
            if currency == "USD":
                continue  # USD → USD is always 1.0
            rate, source = mgr.get_rate(currency)
            assert rate > 0, f"Rate for {currency} should be positive"
            assert source in ("coinbase", "kraken", "default")

    # ------------------------------------------------------------------
    # T3.2 — USD conversion is 1:1
    # ------------------------------------------------------------------

    def test_usd_conversion_identity(self):
        """USD to USD conversion is identity."""
        mgr = MultiCurrencyFlowManager()
        conv = mgr.convert(100.00, "USD", "USD")
        assert conv.from_amount == 100.00
        assert conv.to_amount == 100.00
        assert conv.rate == 1.0
        assert conv.rate_source == "identity"

    # ------------------------------------------------------------------
    # T3.3 — Cross-currency conversion (USD → ETH)
    # ------------------------------------------------------------------

    def test_usd_to_eth_conversion(self):
        """USD to ETH conversion produces a positive amount."""
        mgr = MultiCurrencyFlowManager()
        # $100 → ETH
        conv = mgr.convert(100.00, "USD", "ETH")
        assert conv.from_currency == "USD"
        assert conv.to_currency == "ETH"
        assert conv.from_amount == 100.00
        assert conv.to_amount > 0  # Should be ~0.05 ETH
        assert conv.rate > 0
        assert conv.rate_source in ("coinbase", "kraken", "default")

    # ------------------------------------------------------------------
    # T3.4 — Cross-currency conversion (ETH → USDC)
    # ------------------------------------------------------------------

    def test_eth_to_usdc_conversion(self):
        """ETH to USDC conversion bridges through USD."""
        mgr = MultiCurrencyFlowManager()
        conv = mgr.convert(1.0, "ETH", "USDC")
        assert conv.from_currency == "ETH"
        assert conv.to_currency == "USDC"
        assert conv.from_amount == 1.0
        assert conv.to_amount > 0  # Should be ~$1,875 USDC
        assert conv.rate > 0

    # ------------------------------------------------------------------
    # T3.5 — BTC to USD conversion
    # ------------------------------------------------------------------

    def test_btc_to_usd_conversion(self):
        """BTC to USD produces correct amount."""
        mgr = MultiCurrencyFlowManager()
        conv = mgr.convert(0.01, "BTC", "USD")
        assert conv.from_currency == "BTC"
        assert conv.to_currency == "USD"
        assert conv.from_amount == 0.01
        assert conv.to_amount > 0  # Should be ~$635 USD

    # ------------------------------------------------------------------
    # T3.6 — Unsupported currency raises error
    # ------------------------------------------------------------------

    def test_unsupported_currency_raises_error(self):
        """Unsupported currency raises ValueError."""
        mgr = MultiCurrencyFlowManager()
        try:
            mgr.convert(100.00, "XRP", "USD")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "XRP" in str(e)

    # ------------------------------------------------------------------
    # T3.7 — Cross-currency settlement
    # ------------------------------------------------------------------

    def test_cross_currency_settlement(self):
        """Cross-currency settlement records converted amounts."""
        mgr = MultiCurrencyFlowManager()
        entry = mgr.settle_cross_currency(
            source_organ="quantumarb",
            target_organ="kashclaw",
            amount=0.5,
            from_currency="ETH",
            to_currency="USDC",
            intent_id="intent-ccy-001",
            source_signature="sig_ccy1",
        )

        assert entry.source_organ == "quantumarb"
        assert entry.target_organ == "kashclaw"
        assert entry.currency == "USDC"
        assert entry.amount > 0  # Should be ~$937.50 USDC
        assert "Cross-currency" in entry.description
        assert entry.status == "pending"

    # ------------------------------------------------------------------
    # T3.8 — Same-currency settlement
    # ------------------------------------------------------------------

    def test_same_currency_settlement(self):
        """Same-currency settlement records directly."""
        mgr = MultiCurrencyFlowManager()
        entry = mgr.settle_in_currency(
            source_organ="kashclaw",
            target_organ="media",
            amount=500.00,
            currency="USD",
            source_signature="sig_usd1",
        )

        assert entry.currency == "USD"
        assert entry.amount == 500.00
        assert entry.source_organ == "kashclaw"
        assert entry.status == "pending"

    # ------------------------------------------------------------------
    # T3.9 — Payment execution in currency
    # ------------------------------------------------------------------

    def test_execute_payment_in_currency(self):
        """Execute payment in specific currency."""
        mgr = MultiCurrencyFlowManager()
        result = mgr.execute_payment_in_currency(
            organ_id="quantumarb",
            amount=0.1,
            currency="ETH",
            vendor="OpenAI",
            description="GPT-4 API credits",
        )

        assert result["status"] == "pending"
        assert result["amount_original"] == 0.1
        assert result["currency_original"] == "ETH"
        assert result["rate_info"]["currency"] == "ETH"
        assert result["rate_info"]["rate"] > 0
        assert "entry_id" in result

    # ------------------------------------------------------------------
    # T3.10 — Rate summary
    # ------------------------------------------------------------------

    def test_rate_summary(self):
        """Rate summary returns all non-USD currencies."""
        mgr = MultiCurrencyFlowManager()
        summary = mgr.get_rate_summary()
        assert "ETH" in summary
        assert "BTC" in summary
        assert "USDC" in summary
        for cur, info in summary.items():
            assert info["rate_usd"] > 0
            assert info["source"] in ("coinbase", "kraken", "default")
