"""
Level 5, T1 — Live Payment Connector Activation.

Promotes StubPaymentConnector to live connectors for whitelisted organs.
Enforces FINANCIAL_OPS_LIVE_ENABLED feature flag with organ-level control.

Design:
- Feature flag FINANCIAL_OPS_LIVE_ENABLED controls global live mode
- LIVE_ORG_WHITELIST env var controls which organs can use live connectors
- Connectors are instantiated via build_connector() with dry_run=False
- Health tracking via HEALTH_TRACKER ensures connectors are working
- Every live payment is logged to the live spend ledger

Safety:
- Never stores credentials in source code
- StripeTestConnector enforces sk_test_ key prefix
- Health check runs before first live payment attempt
- Auto-fallback to StubPaymentConnector if Stripe key is missing
"""

import json
import logging
import os
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional

from simp.compat.payment_connector import (
    build_connector,
    PaymentConnector,
    PaymentConnectorConfig,
    PaymentResult,
    StubPaymentConnector,
    HEALTH_TRACKER,
)
from simp.compat.live_ledger import LiveSpendLedger
from simp.compat.stripe_connector import StripeTestConnector

logger = logging.getLogger("SIMP.LiveActivation")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_WHITELIST = ["quantumarb", "financial_ops", "kashclaw"]
MAX_STUB_LIMIT = 20.00  # Max amount via stub (simulated)
MAX_LIVE_LIMIT = 100.00  # Max amount via live connector

# ---------------------------------------------------------------------------
# Activation state
# ---------------------------------------------------------------------------

@dataclass
class OrgLiveStatus:
    """Live payment status for a single organ."""
    organ_id: str
    live_enabled: bool = False
    connector_name: str = "stub_small_payments"
    daily_spend: float = 0.0
    monthly_spend: float = 0.0
    last_payment_at: Optional[str] = None
    last_health_check: Optional[str] = None
    health_ok: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class LiveActivator:
    """
    Manages the transition from stub → live payment connectors per organ.

    Flow:
    1. Check FINANCIAL_OPS_LIVE_ENABLED env var
    2. Check organ whitelist (LIVE_ORG_WHITELIST env var)
    3. If both pass, instantiate live connector
    4. Run health check
    5. If healthy, mark organ as live_enabled=True
    """

    def __init__(self, ledger_path: str = "data/live_spend_ledger.jsonl"):
        self._ledger = LiveSpendLedger(ledger_path)
        self._org_statuses: Dict[str, OrgLiveStatus] = {}
        self._live_enabled_global: bool = False
        self._whitelist: List[str] = []
        self._initialized: bool = False

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    def initialize(self) -> Dict[str, Any]:
        """
        Initialize the LiveActivator.

        Returns a status report of what was activated.
        """
        self._live_enabled_global = os.environ.get("FINANCIAL_OPS_LIVE_ENABLED", "").lower() == "true"

        raw_whitelist = os.environ.get("LIVE_ORG_WHITELIST", "")
        if raw_whitelist:
            self._whitelist = [o.strip() for o in raw_whitelist.split(",")]
        else:
            self._whitelist = DEFAULT_WHITELIST.copy()

        result: Dict[str, Any] = {
            "global_live_enabled": self._live_enabled_global,
            "whitelist": self._whitelist,
            "orgs_activated": [],
            "errors": [],
        }

        if not self._live_enabled_global:
            logger.info("FINANCIAL_OPS_LIVE_ENABLED is false — all connectors stay in dry-run mode")
            return result

        # Attempt to activate each whitelisted organ
        for organ_id in self._whitelist:
            try:
                status = self._activate_organ(organ_id)
                self._org_statuses[organ_id] = status
                result["orgs_activated"].append({
                    "organ_id": organ_id,
                    "connector": status.connector_name,
                    "health_ok": status.health_ok,
                })
            except Exception as e:
                logger.error("Failed to activate organ %s: %s", organ_id, e)
                result["errors"].append({"organ_id": organ_id, "error": str(e)})
                self._org_statuses[organ_id] = OrgLiveStatus(
                    organ_id=organ_id,
                    live_enabled=False,
                    connector_name="stub_small_payments",
                    health_ok=False,
                )

        self._initialized = True
        return result

    def _activate_organ(self, organ_id: str) -> OrgLiveStatus:
        """
        Activate a single organ for live payments.

        1. Try StripeTestConnector first (if STRIPE_TEST_SECRET_KEY is set)
        2. Fall back to StubPaymentConnector with dry_run=False
        3. Run health check before marking live
        """
        stripe_key = os.environ.get("STRIPE_TEST_SECRET_KEY", "")

        if stripe_key and stripe_key.startswith("sk_test_"):
            # Promote to StripeTestConnector
            config = PaymentConnectorConfig(
                name="stripe_small_payments",
                connector_type="stripe_test",
                dry_run=False,
                max_amount=MAX_LIVE_LIMIT,
            )
            connector = StripeTestConnector(config=config, api_key=stripe_key)
            connector_name = "stripe_small_payments"
        else:
            # Promote stub to live mode (still simulated but tagged as live)
            config = PaymentConnectorConfig(
                name="stub_small_payments",
                connector_type="stub",
                dry_run=False,
                max_amount=MAX_STUB_LIMIT,
            )
            connector = StubPaymentConnector(config=config)
            connector_name = "stub_small_payments"

        # Run health check
        try:
            health = connector.health_check()
            health_ok = health.get("status") in ("healthy", "ok")
        except Exception as e:
            logger.warning("Health check failed for %s: %s", organ_id, e)
            health_ok = False

        status = OrgLiveStatus(
            organ_id=organ_id,
            live_enabled=health_ok,
            connector_name=connector_name,
            health_ok=health_ok,
            last_health_check=datetime.now(timezone.utc).isoformat(),
        )

        logger.info(
            "Organ %s activated: connector=%s live=%s health=%s",
            organ_id, connector_name, self._live_enabled_global, health_ok,
        )
        return status

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute_payment(
        self,
        organ_id: str,
        amount: float,
        vendor: str,
        description: str,
        category: str = "small_purchase",
    ) -> PaymentResult:
        """
        Execute a payment for a specific organ.

        If the organ is live-enabled and FINANCIAL_OPS_LIVE_ENABLED is true,
        this uses the live connector. Otherwise, falls back to stub.
        """
        if not self._initialized:
            self.initialize()

        status = self._org_statuses.get(organ_id)
        use_live = (
            self._live_enabled_global
            and status is not None
            and status.live_enabled
            and status.health_ok
        )

        if use_live:
            connector = self._build_connector_live(organ_id)
            result = connector.execute_small_payment(amount, vendor, description)
            self._log_live_payment(organ_id, amount, vendor, result)
        else:
            # Stub fallback
            config = PaymentConnectorConfig(
                name="stub_small_payments",
                connector_type="stub",
                dry_run=True,
                max_amount=MAX_STUB_LIMIT,
            )
            connector = StubPaymentConnector(config=config)
            result = connector.execute_small_payment(amount, vendor, description)

        return result

    def _build_connector_live(self, organ_id: str) -> PaymentConnector:
        """Build a live connector for the given organ."""
        stripe_key = os.environ.get("STRIPE_TEST_SECRET_KEY", "")
        if stripe_key and stripe_key.startswith("sk_test_"):
            config = PaymentConnectorConfig(
                name="stripe_small_payments",
                connector_type="stripe_test",
                dry_run=False,
                max_amount=MAX_LIVE_LIMIT,
            )
            return StripeTestConnector(config=config, api_key=stripe_key)
        else:
            config = PaymentConnectorConfig(
                name="stub_small_payments",
                connector_type="stub",
                dry_run=False,
            )
            return StubPaymentConnector(config=config)

    def _log_live_payment(
        self,
        organ_id: str,
        amount: float,
        vendor: str,
        result: PaymentResult,
    ) -> None:
        """Record a live payment in the ledger."""
        try:
            self._ledger.record_attempt(
                proposal_id=result.reference_id,
                idempotency_key=result.reference_id,
                connector_name=result.connector_name or "stub_small_payments",
                vendor=vendor,
                category="small_purchase",
                amount=amount,
            )
        except Exception as e:
            logger.warning("Failed to record ledger attempt: %s", e)
        try:
            if result.success:
                self._ledger.record_outcome(
                    record_id=result.reference_id,
                    status="completed",
                    provider_reference=result.reference_id,
                )
        except Exception as e:
            logger.warning("Failed to record ledger outcome: %s", e)

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_status(self, organ_id: str) -> Optional[OrgLiveStatus]:
        """Get the live status for a specific organ."""
        return self._org_statuses.get(organ_id)

    def get_all_statuses(self) -> List[Dict[str, Any]]:
        """Get live status for all organs."""
        return [s.to_dict() for s in self._org_statuses.values()]

    def is_live_ready(self) -> Dict[str, Any]:
        """
        Returns True if the system is ready for live payments.
        Checks: feature flag, at least one organ activated, connector health.
        """
        activated = [
            oid for oid, s in self._org_statuses.items()
            if s.live_enabled and s.health_ok
        ]
        return {
            "ready": self._live_enabled_global and len(activated) > 0,
            "organs_ready": activated,
            "global_live": self._live_enabled_global,
        }


# Module-level singleton
LIVE_ACTIVATOR = LiveActivator()
