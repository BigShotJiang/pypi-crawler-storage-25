"""
L5 T6-T10 — Budget & Spend Governance Module.

Provides per-organ budget management with:
  T6 — Per-organ budget caps (soft $1K, hard $5K), daily limits, budget checking
  T7 — Budget approval gates (Gate 1 dry-run, Gate 2 limited, Gate 3 full)
  T8 — Cross-organ budget delegation with dual tracking
  T9 — Budget rollover (50% roll, 50% to federation reserve)
  T10 — Emergency freeze (delegated to freeze_manager.py, integrated here)

Builds on: simp/compat/budget_monitor.py (BudgetMonitor for threshold alerts)
Integrates with: simp/financial/approval_integration.py (gate checks)
                 simp/financial/freeze_manager.py (emergency freeze)
"""

import json
import logging
import os
import threading
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, List, Optional, Set, Tuple

from simp.compat.budget_monitor import BudgetMonitor, BUDGET_MONITOR, AlertSeverity

logger = logging.getLogger("SIMP.BudgetManagerV2")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_SOFT_CAP = 1000.00    # $1,000/mo per organ
DEFAULT_HARD_CAP = 5000.00    # $5,000/mo per organ
DEFAULT_DAILY_LIMIT = 200.00  # $200/day per organ
FEDERATION_RESERVE_ID = "__federation_reserve__"


# ---------------------------------------------------------------------------
# T7: Budget Gate Levels
# ---------------------------------------------------------------------------

class BudgetGateLevel:
    DRY_RUN = 1      # Gate 1: 7-day dry-run. No real execution.
    LIVE_LIMITED = 2 # Gate 2: Live but limited ($100/day)
    FULL = 3         # Gate 3: Full limits (soft/hard caps)

GATE_NAMES = {
    1: "dry_run",
    2: "live_limited",
    3: "full",
}

GATE_DAILY_LIMITS = {
    1: 0.0,      # Dry-run: no live spend
    2: 100.00,   # Live limited: $100/day
    3: DEFAULT_DAILY_LIMIT,
}

GATE_DURATION_DAYS = {
    1: 7,        # 7 days dry-run
    2: 30,       # 30 days live limited
}


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class OrganBudget:
    """Budget configuration and current spend for a single organ."""
    organ_id: str
    soft_cap: float = DEFAULT_SOFT_CAP       # Warning threshold
    hard_cap: float = DEFAULT_HARD_CAP       # Block threshold
    daily_limit: float = DEFAULT_DAILY_LIMIT
    monthly_spend: float = 0.0
    daily_spend: float = 0.0
    delegated_in: float = 0.0                # Amount delegated FROM this organ
    delegated_out: float = 0.0               # Amount delegated TO other organs
    rollover_amount: float = 0.0             # Amount rolled over from prev month
    currency: str = "USD"
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
        if not self.updated_at:
            self.updated_at = self.created_at

    @property
    def effective_hard_cap(self) -> float:
        """Hard cap including rollover."""
        return self.hard_cap + self.rollover_amount

    @property
    def remaining_monthly(self) -> float:
        """Remaining monthly budget."""
        total_used = self.monthly_spend + self.delegated_in
        return max(0.0, round(self.effective_hard_cap - total_used, 2))

    @property
    def remaining_daily(self) -> float:
        """Remaining daily budget."""
        return max(0.0, round(self.daily_limit - self.daily_spend, 2))

    @property
    def usage_percentage(self) -> float:
        """Percentage of soft cap used."""
        if self.soft_cap <= 0:
            return 0.0
        return round((self.monthly_spend / self.soft_cap) * 100, 1)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BudgetGate:
    """An organ's current budget gate level and progression state."""
    organ_id: str
    gate_level: int = BudgetGateLevel.DRY_RUN
    entered_at: str = ""
    last_promotion_check: Optional[str] = None
    violations: int = 0                       # SLA / policy violations since entering
    clean_days_streak: int = 0                # Consecutive clean days
    eligible_for_promotion: bool = False
    promotion_block_reason: str = ""

    def __post_init__(self):
        if not self.entered_at:
            self.entered_at = datetime.now(timezone.utc).isoformat()

    @property
    def gate_name(self) -> str:
        return GATE_NAMES.get(self.gate_level, f"unknown({self.gate_level})")

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class BudgetDelegation:
    """A cross-organ budget delegation."""
    delegation_id: str = ""
    delegator_organ: str = ""
    delegate_organ: str = ""
    amount: float = 0.0
    remaining: float = 0.0
    capability_types: List[str] = field(default_factory=list)
    expires_at: str = ""
    is_active: bool = True
    created_at: str = ""

    def __post_init__(self):
        if not self.delegation_id:
            self.delegation_id = f"del-{uuid.uuid4().hex[:12]}"
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()
        if self.remaining == 0.0:
            self.remaining = self.amount
        if not self.expires_at:
            self.expires_at = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class FederationReserve:
    """Federation reserve fund tracking."""
    total_reserve: float = 0.0
    contributions: List[Dict[str, Any]] = field(default_factory=list)
    allocations: List[Dict[str, Any]] = field(default_factory=list)
    updated_at: str = ""

    def __post_init__(self):
        if not self.updated_at:
            self.updated_at = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Budget Manager V2
# ---------------------------------------------------------------------------

class BudgetManagerV2:
    """
    Per-organ budget management with gates, delegation, and rollover.

    Features:
    - Soft/hard caps per organ with warning/block thresholds
    - Three-tier gate progression (dry-run → limited → full)
    - Cross-organ budget delegation
    - Monthly rollover (50% unused → next month, 50% → reserve)
    - Integration with emergency freeze
    - Thread-safe, JSONL-persisted
    """

    def __init__(self, budget_path: str = "data/organ_budgets.jsonl"):
        self._lock = threading.Lock()
        self._budget_path = budget_path
        self._budgets: Dict[str, OrganBudget] = {}
        self._gates: Dict[str, BudgetGate] = {}
        self._delegations: Dict[str, BudgetDelegation] = {}
        self._reserve = FederationReserve()
        self._monitor = BudgetMonitor()
        self._load_existing()
        self._ensure_dirs()

    def _ensure_dirs(self) -> None:
        os.makedirs(os.path.dirname(self._budget_path) or ".", exist_ok=True)

    def _load_existing(self) -> None:
        if not os.path.exists(self._budget_path):
            return
        try:
            with open(self._budget_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    data = json.loads(line)
                    record_type = data.get("_type", "")
                    if record_type == "budget":
                        b = OrganBudget(**data.get("data", {}))
                        self._budgets[b.organ_id] = b
                    elif record_type == "gate":
                        g = BudgetGate(**data.get("data", {}))
                        self._gates[g.organ_id] = g
                    elif record_type == "delegation":
                        d = BudgetDelegation(**data.get("data", {}))
                        self._delegations[d.delegation_id] = d
                    elif record_type == "reserve":
                        self._reserve = FederationReserve(**data.get("data", {}))
        except (json.JSONDecodeError, OSError, TypeError) as e:
            logger.warning("Could not load budget data: %s", e)

    def _append_record(self, record_type: str, data: Dict[str, Any]) -> None:
        os.makedirs(os.path.dirname(self._budget_path) or ".", exist_ok=True)
        with open(self._budget_path, "a") as f:
            f.write(json.dumps({
                "_type": record_type,
                "data": data,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }) + "\n")

    # ==================================================================
    # T6 — Per-Organ Budget Management
    # ==================================================================

    def create_budget(
        self,
        organ_id: str,
        soft_cap: float = DEFAULT_SOFT_CAP,
        hard_cap: float = DEFAULT_HARD_CAP,
        daily_limit: float = DEFAULT_DAILY_LIMIT,
    ) -> OrganBudget:
        """Create a new budget for an organ."""
        budget = OrganBudget(
            organ_id=organ_id,
            soft_cap=soft_cap,
            hard_cap=hard_cap,
            daily_limit=daily_limit,
        )
        with self._lock:
            self._budgets[organ_id] = budget
            self._append_record("budget", budget.to_dict())
        logger.info("Budget created for %s: soft=$%.2f hard=$%.2f daily=$%.2f",
                     organ_id, soft_cap, hard_cap, daily_limit)
        return budget

    def get_budget(self, organ_id: str) -> Optional[OrganBudget]:
        """Get an organ's budget. Creates default if not exists."""
        with self._lock:
            if organ_id not in self._budgets:
                budget = self.create_budget(organ_id)
                return budget
            return self._budgets.get(organ_id)

    def update_budget(
        self,
        organ_id: str,
        soft_cap: Optional[float] = None,
        hard_cap: Optional[float] = None,
        daily_limit: Optional[float] = None,
    ) -> Optional[OrganBudget]:
        """Update an organ's budget limits."""
        with self._lock:
            budget = self._budgets.get(organ_id)
            if not budget:
                return None
            if soft_cap is not None:
                budget.soft_cap = soft_cap
            if hard_cap is not None:
                budget.hard_cap = hard_cap
            if daily_limit is not None:
                budget.daily_limit = daily_limit
            budget.updated_at = datetime.now(timezone.utc).isoformat()
            self._append_record("budget", budget.to_dict())
            return budget

    def check_budget(
        self,
        organ_id: str,
        amount: float,
        currency: str = "USD",
    ) -> Dict[str, Any]:
        """
        Check if an organ can spend a given amount.

        Returns:
            allowed (bool): Whether the spend is allowed
            reason (str): Why it was blocked or allowed
            alerts (list): Any budget alerts generated
        """
        budget = self.get_budget(organ_id)
        if not budget:
            return {"allowed": True, "reason": "No budget configured", "alerts": []}

        alerts: List[Dict[str, Any]] = []

        # 1. Check daily limit
        new_daily = budget.daily_spend + amount
        daily_alerts = self._monitor.check_daily_budget(new_daily)
        alerts.extend(a.to_dict() for a in daily_alerts)

        daily_blocked = any(
            a.severity == AlertSeverity.CRITICAL.value and a.category == "daily"
            for a in daily_alerts
        )
        if daily_blocked:
            return {
                "allowed": False,
                "reason": f"Daily limit exceeded: ${new_daily:.2f} > ${budget.daily_limit:.2f}",
                "alerts": alerts,
            }

        # 2. Check monthly hard cap
        new_monthly = budget.monthly_spend + amount
        if new_monthly > budget.effective_hard_cap:
            return {
                "allowed": False,
                "reason": f"Hard cap exceeded: ${new_monthly:.2f} > ${budget.effective_hard_cap:.2f}",
                "alerts": alerts,
            }

        # 3. Check soft cap (warning only)
        if new_monthly > budget.soft_cap:
            pct = (new_monthly / budget.soft_cap) * 100
            from simp.compat.budget_monitor import BudgetAlert
            alert = BudgetAlert(
                severity=AlertSeverity.WARNING.value,
                category="monthly",
                message=f"Soft cap exceeded: ${new_monthly:.2f} / ${budget.soft_cap:.2f} ({pct:.0f}%)",
                current_value=new_monthly,
                limit_value=budget.soft_cap,
                percentage=round(pct, 1),
            )
            alerts.append(alert.to_dict())

        return {
            "allowed": True,
            "reason": f"Within budget: ${new_monthly:.2f} / ${budget.effective_hard_cap:.2f}",
            "alerts": alerts,
        }

    def record_spend(self, organ_id: str, amount: float) -> Optional[OrganBudget]:
        """
        Record a spend against an organ's budget.

        Updates both daily and monthly counters.
        """
        with self._lock:
            budget = self._budgets.get(organ_id)
            if not budget:
                return None
            budget.daily_spend = round(budget.daily_spend + amount, 2)
            budget.monthly_spend = round(budget.monthly_spend + amount, 2)
            budget.updated_at = datetime.now(timezone.utc).isoformat()
            self._append_record("budget", budget.to_dict())
            return budget

    def reset_daily_spends(self) -> int:
        """Reset all daily spend counters (called daily at midnight)."""
        count = 0
        with self._lock:
            for budget in self._budgets.values():
                budget.daily_spend = 0.0
                budget.updated_at = datetime.now(timezone.utc).isoformat()
                count += 1
        logger.info("Daily spends reset for %d organs", count)
        return count

    def get_budget_summary(self, organ_id: str) -> Dict[str, Any]:
        """Get a detailed budget summary for an organ."""
        budget = self.get_budget(organ_id)
        if not budget:
            return {"error": f"No budget for {organ_id}"}

        gate = self.get_gate(organ_id)
        return {
            "organ_id": organ_id,
            "soft_cap": budget.soft_cap,
            "hard_cap": budget.hard_cap,
            "effective_hard_cap": budget.effective_hard_cap,
            "daily_limit": budget.daily_limit,
            "daily_spend": budget.daily_spend,
            "monthly_spend": budget.monthly_spend,
            "remaining_daily": budget.remaining_daily,
            "remaining_monthly": budget.remaining_monthly,
            "usage_pct": budget.usage_percentage,
            "rollover": budget.rollover_amount,
            "gate_level": gate.gate_level if gate else 1,
            "gate_name": gate.gate_name if gate else "dry_run",
            "delegated_in": budget.delegated_in,
            "delegated_out": budget.delegated_out,
        }

    # ==================================================================
    # T7 — Budget Approval Gates
    # ==================================================================

    def get_gate(self, organ_id: str) -> BudgetGate:
        """Get an organ's gate level. Creates default if not exists."""
        with self._lock:
            if organ_id not in self._gates:
                gate = BudgetGate(organ_id=organ_id)
                self._gates[organ_id] = gate
                self._append_record("gate", gate.to_dict())
                return gate
            return self._gates[organ_id]

    def check_promotion_eligibility(self, organ_id: str) -> Dict[str, Any]:
        """
        Check if an organ is eligible for gate promotion.

        Gate 1 → Gate 2: 7 days clean, no violations
        Gate 2 → Gate 3: 30 days clean, no violations
        """
        gate = self.get_gate(organ_id)
        duration_days = GATE_DURATION_DAYS.get(gate.gate_level, 0)

        if gate.gate_level >= BudgetGateLevel.FULL:
            return {"eligible": False, "reason": "Already at maximum gate level (3)"}

        now = datetime.now(timezone.utc)
        entered = datetime.fromisoformat(gate.entered_at)
        days_elapsed = (now - entered).days

        if days_elapsed < duration_days:
            remaining = duration_days - days_elapsed
            return {
                "eligible": False,
                "reason": f"Need {remaining} more days ({days_elapsed}/{duration_days})",
                "days_elapsed": days_elapsed,
                "days_required": duration_days,
                "violations": gate.violations,
            }

        if gate.violations > 0:
            return {
                "eligible": False,
                "reason": f"Has {gate.violations} violations — resolve before promotion",
                "days_elapsed": days_elapsed,
                "violations": gate.violations,
            }

        with self._lock:
            gate.eligible_for_promotion = True
            gate.promotion_block_reason = ""
            gate.last_promotion_check = now.isoformat()
            self._append_record("gate", gate.to_dict())

        return {
            "eligible": True,
            "reason": f"Eligible for promotion to gate {gate.gate_level + 1}",
            "days_elapsed": days_elapsed,
            "current_gate": gate.gate_level,
            "next_gate": gate.gate_level + 1,
        }

    def promote_organ(self, organ_id: str) -> Dict[str, Any]:
        """
        Promote an organ to the next gate level.

        Checks eligibility first, then promotes.
        """
        eligibility = self.check_promotion_eligibility(organ_id)
        if not eligibility.get("eligible"):
            return {"status": "error", "error": eligibility.get("reason", "Not eligible")}

        gate = self.get_gate(organ_id)
        new_level = gate.gate_level + 1

        with self._lock:
            gate.gate_level = new_level
            gate.entered_at = datetime.now(timezone.utc).isoformat()
            gate.eligible_for_promotion = False
            gate.violations = 0
            gate.last_promotion_check = datetime.now(timezone.utc).isoformat()
            self._append_record("gate", gate.to_dict())

        # Update the organ's daily limit to match gate
        daily_limit = GATE_DAILY_LIMITS.get(new_level, DEFAULT_DAILY_LIMIT)
        self.update_budget(organ_id, daily_limit=daily_limit)

        logger.info("Organ %s promoted to Gate %d (%s)", organ_id, new_level, GATE_NAMES[new_level])

        return {
            "status": "promoted",
            "organ_id": organ_id,
            "previous_gate": new_level - 1,
            "new_gate": new_level,
            "gate_name": GATE_NAMES[new_level],
            "daily_limit": daily_limit,
        }

    def demote_organ(self, organ_id: str, reason: str = "") -> Dict[str, Any]:
        """
        Demote an organ one gate level due to violations.
        """
        gate = self.get_gate(organ_id)
        if gate.gate_level <= BudgetGateLevel.DRY_RUN:
            return {"status": "error", "error": "Already at minimum gate level"}

        new_level = gate.gate_level - 1
        with self._lock:
            gate.gate_level = new_level
            gate.entered_at = datetime.now(timezone.utc).isoformat()
            gate.violations += 1
            gate.eligible_for_promotion = False
            self._append_record("gate", gate.to_dict())

        daily_limit = GATE_DAILY_LIMITS.get(new_level, 0.0)
        self.update_budget(organ_id, daily_limit=daily_limit)

        logger.warning("Organ %s DEMOTED to Gate %d: %s", organ_id, new_level, reason)
        return {
            "status": "demoted",
            "organ_id": organ_id,
            "new_gate": new_level,
            "gate_name": GATE_NAMES[new_level],
            "reason": reason,
        }

    def record_violation(self, organ_id: str) -> None:
        """Record a policy violation for an organ."""
        with self._lock:
            gate = self._gates.get(organ_id)
            if gate:
                gate.violations += 1
                gate.eligible_for_promotion = False
                self._append_record("gate", gate.to_dict())

    # ==================================================================
    # T8 — Cross-Organ Budget Delegation
    # ==================================================================

    def delegate_budget(
        self,
        from_organ: str,
        to_organ: str,
        amount: float,
        capability_types: Optional[List[str]] = None,
        expires_in_days: int = 30,
    ) -> Dict[str, Any]:
        """
        Delegate budget from one organ to another.

        The delegated amount counts against the delegator's total budget.
        The delegate can spend up to the delegated amount.
        """
        delegator_budget = self.get_budget(from_organ)
        if not delegator_budget:
            return {"status": "error", "error": f"No budget for delegator {from_organ}"}

        # Check delegator has enough remaining budget
        remaining = delegator_budget.effective_hard_cap - delegator_budget.monthly_spend
        new_delegated_total = delegator_budget.delegated_in + amount
        if new_delegated_total > remaining:
            return {
                "status": "error",
                "error": f"Delegator only has ${remaining:.2f} remaining, cannot delegate ${amount:.2f}",
            }

        delegation = BudgetDelegation(
            delegator_organ=from_organ,
            delegate_organ=to_organ,
            amount=amount,
            remaining=amount,
            capability_types=capability_types or [],
            expires_at=(datetime.now(timezone.utc) + timedelta(days=expires_in_days)).isoformat(),
        )

        with self._lock:
            self._delegations[delegation.delegation_id] = delegation
            delegator_budget.delegated_in = round(delegator_budget.delegated_in + amount, 2)
            self._append_record("delegation", delegation.to_dict())
            self._append_record("budget", delegator_budget.to_dict())

        logger.info(
            "Budget delegated: %s → %s: $%.2f for %s",
            from_organ, to_organ, amount, capability_types or "all",
        )

        return {
            "status": "created",
            "delegation_id": delegation.delegation_id,
            "from": from_organ,
            "to": to_organ,
            "amount": amount,
            "expires_at": delegation.expires_at,
        }

    def check_delegated_budget(self, organ_id: str, amount: float) -> Dict[str, Any]:
        """
        Check if an organ has enough delegated budget for a spend.

        Returns (available, total_delegated, remaining).
        """
        total_delegated = 0.0
        total_used = 0.0
        available = 0.0

        with self._lock:
            for delegation in self._delegations.values():
                if delegation.delegate_organ == organ_id and delegation.is_active:
                    if delegation.expires_at >= datetime.now(timezone.utc).isoformat():
                        total_delegated += delegation.amount
                        total_used += delegation.amount - delegation.remaining
                        available += delegation.remaining

        return {
            "available": round(available, 2),
            "total_delegated": round(total_delegated, 2),
            "total_used": round(total_used, 2),
            "sufficient": available >= amount,
        }

    def consume_delegated_budget(self, organ_id: str, amount: float) -> bool:
        """
        Consume from delegated budgets. Returns True if fully covered.

        Consumes from oldest delegation first.
        """
        with self._lock:
            active = sorted(
                [d for d in self._delegations.values()
                 if d.delegate_organ == organ_id and d.is_active
                 and d.expires_at >= datetime.now(timezone.utc).isoformat()],
                key=lambda d: d.created_at,
            )

            remaining = amount
            for delegation in active:
                if remaining <= 0:
                    break
                use = min(remaining, delegation.remaining)
                delegation.remaining = round(delegation.remaining - use, 2)
                remaining = round(remaining - use, 2)

                # Track on delegator's budget
                delegator_budget = self._budgets.get(delegation.delegator_organ)
                if delegator_budget:
                    delegator_budget.delegated_out = round(
                        delegator_budget.delegated_out + use, 2
                    )

            return remaining <= 0

    def get_delegations(
        self,
        organ_id: str,
        direction: str = "both",
    ) -> Dict[str, Any]:
        """
        Get all delegations involving an organ.

        direction: "incoming", "outgoing", or "both"
        """
        incoming = []
        outgoing = []

        with self._lock:
            for delegation in self._delegations.values():
                if direction in ("incoming", "both") and delegation.delegate_organ == organ_id:
                    incoming.append(delegation.to_dict())
                if direction in ("outgoing", "both") and delegation.delegator_organ == organ_id:
                    outgoing.append(delegation.to_dict())

        return {
            "incoming": incoming,
            "outgoing": outgoing,
            "total_incoming": round(sum(d["amount"] for d in incoming), 2),
            "total_outgoing": round(sum(d["amount"] for d in outgoing), 2),
        }

    def revoke_delegation(self, delegation_id: str) -> bool:
        """Revoke an active delegation."""
        with self._lock:
            delegation = self._delegations.get(delegation_id)
            if not delegation or not delegation.is_active:
                return False
            delegation.is_active = False
            self._append_record("delegation", delegation.to_dict())
            logger.info("Delegation %s revoked", delegation_id)
            return True

    # ==================================================================
    # T9 — Budget Rollover
    # ==================================================================

    def calculate_rollover(self, organ_id: str) -> Dict[str, Any]:
        """
        Calculate month-end rollover for an organ.

        50% of unused soft cap rolls over to next month.
        50% returned to federation reserve.
        """
        budget = self.get_budget(organ_id)
        if not budget:
            return {"error": f"No budget for {organ_id}"}

        unused = max(0.0, budget.soft_cap - budget.monthly_spend)
        rollover_amount = round(unused * 0.5, 2)
        reserve_amount = round(unused * 0.5, 2)

        return {
            "organ_id": organ_id,
            "soft_cap": budget.soft_cap,
            "monthly_spend": budget.monthly_spend,
            "unused": round(unused, 2),
            "rollover_amount": rollover_amount,
            "reserve_amount": reserve_amount,
        }

    def apply_rollover(self, organ_id: str) -> Dict[str, Any]:
        """
        Apply month-end rollover for an organ.

        50% of unused → organ's rollover balance.
        50% of unused → federation reserve.
        """
        calc = self.calculate_rollover(organ_id)
        if "error" in calc:
            return {"status": "error", "error": calc["error"]}

        with self._lock:
            budget = self._budgets.get(organ_id)
            if not budget:
                return {"status": "error", "error": "Budget not found"}

            # Apply rollover to organ
            budget.rollover_amount = round(budget.rollover_amount + calc["rollover_amount"], 2)

            # Reset monthly spend for new month
            budget.monthly_spend = 0.0
            budget.daily_spend = 0.0
            budget.updated_at = datetime.now(timezone.utc).isoformat()
            self._append_record("budget", budget.to_dict())

            # Add to federation reserve
            self._reserve.total_reserve = round(
                self._reserve.total_reserve + calc["reserve_amount"], 2
            )
            self._reserve.contributions.append({
                "organ_id": organ_id,
                "amount": calc["reserve_amount"],
                "applied_at": datetime.now(timezone.utc).isoformat(),
            })
            self._reserve.updated_at = datetime.now(timezone.utc).isoformat()
            self._append_record("reserve", self._reserve.to_dict())

        logger.info(
            "Rollover applied for %s: $%.2f rolled, $%.2f to reserve",
            organ_id, calc["rollover_amount"], calc["reserve_amount"],
        )

        return {
            "status": "applied",
            "organ_id": organ_id,
            "rollover_amount": calc["rollover_amount"],
            "reserve_contribution": calc["reserve_amount"],
            "total_reserve": self._reserve.total_reserve,
            "new_effective_cap": budget.effective_hard_cap if budget else 0.0,
        }

    def get_reserve(self) -> FederationReserve:
        """Get the federation reserve status."""
        with self._lock:
            return self._reserve

    # ==================================================================
    # T10 — Emergency Freeze Integration
    # ==================================================================

    def check_emergency_freeze(self, daily_total: float) -> Optional[Dict[str, Any]]:
        """
        Check if emergency freeze should trigger.

        Delegates to EmergencyFreezeManager.
        Returns freeze info if triggered, None otherwise.
        """
        try:
            from simp.financial.freeze_manager import EMERGENCY_FREEZE_MANAGER
            freeze = EMERGENCY_FREEZE_MANAGER.check_and_trigger_freeze(daily_total)
            if freeze:
                return freeze.to_dict()
        except ImportError:
            logger.debug("EmergencyFreezeManager not available")
        return None

    def is_frozen(self) -> bool:
        """Check if there's an active emergency freeze."""
        try:
            from simp.financial.freeze_manager import EMERGENCY_FREEZE_MANAGER
            return EMERGENCY_FREEZE_MANAGER.is_frozen()
        except ImportError:
            return False

    def approve_unfreeze(self, freeze_id: str, admin_id: str) -> Dict[str, Any]:
        """Approve unfreeze (2-of-3 multi-sig)."""
        try:
            from simp.financial.freeze_manager import EMERGENCY_FREEZE_MANAGER
            return EMERGENCY_FREEZE_MANAGER.approve_unfreeze(freeze_id, admin_id)
        except ImportError:
            return {"status": "error", "error": "Freeze manager not available"}

    # ==================================================================
    # Summary & Maintenance
    # ==================================================================

    def get_all_budgets(self) -> List[Dict[str, Any]]:
        """Get all organ budgets as dicts."""
        with self._lock:
            return [b.to_dict() for b in self._budgets.values()]

    def get_all_gates(self) -> List[Dict[str, Any]]:
        """Get all gate states as dicts."""
        with self._lock:
            return [g.to_dict() for g in self._gates.values()]

    def get_system_summary(self) -> Dict[str, Any]:
        """Get full system summary."""
        with self._lock:
            total_budget = sum(b.soft_cap for b in self._budgets.values())
            total_spent = sum(b.monthly_spend for b in self._budgets.values())
            total_delegated = sum(b.delegated_in for b in self._budgets.values())
            organ_count = len(self._budgets)

            gate_counts = {1: 0, 2: 0, 3: 0}
            for g in self._gates.values():
                gate_counts[g.gate_level] = gate_counts.get(g.gate_level, 0) + 1

            frozen = self.is_frozen()

        return {
            "total_organs": organ_count,
            "total_budget_soft_cap": round(total_budget, 2),
            "total_monthly_spend": round(total_spent, 2),
            "total_delegated": round(total_delegated, 2),
            "reserve": self._reserve.total_reserve,
            "gates": {
                "dry_run": gate_counts.get(1, 0),
                "live_limited": gate_counts.get(2, 0),
                "full": gate_counts.get(3, 0),
            },
            "frozen": frozen,
            "active_delegations": sum(
                1 for d in self._delegations.values() if d.is_active
            ),
        }


# Module-level singleton
BUDGET_MANAGER_V2 = BudgetManagerV2()
