"""
L5-T3 — Multi-currency Financial Operations.

Adds multi-currency settlement to the payment execution flow:
1. Exchange rates fetched from Coinbase/Kraken with 10s cache
2. Amount conversion between any supported currency pair
3. Cross-currency settlement with exchange rate recorded in audit trail
4. Supports: USD, USDC, ETH, BTC

Builds on: ExchangeRateResolver from real_ledger.py
Integrates with: execute_approved_payment from financial_ops.py
"""

import json
import logging
import os
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple

from simp.financial.real_ledger import (
    ExchangeRateResolver,
    SUPPORTED_CURRENCIES,
    RealFinOpsLedger,
    FinOpsEntry,
)

logger = logging.getLogger("SIMP.MultiCurrencyFlow")

# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class CurrencyConversion:
    """Result of a currency conversion."""
    from_currency: str
    to_currency: str
    from_amount: float
    to_amount: float
    rate: float
    rate_source: str
    timestamp: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# Multi-Currency Flow Manager
# ---------------------------------------------------------------------------


class MultiCurrencyFlowManager:
    """
    Manages multi-currency financial operations.

    Provides:
    - Exchange rate resolution with caching
    - Currency conversion between any supported pair
    - Cross-currency settlement with audit trail
    - Integration with existing payment execution flow
    """

    def __init__(self):
        self._rate_resolver = ExchangeRateResolver()
        self._ledger = RealFinOpsLedger()

    # ------------------------------------------------------------------
    # Exchange Rates
    # ------------------------------------------------------------------

    def get_rate(self, currency: str) -> Tuple[float, str]:
        """
        Get the USD exchange rate for a currency.

        Returns (rate, source). Supports: USD, USDC, ETH, BTC.
        """
        return self._rate_resolver.get_rate(currency)

    def convert(
        self,
        amount: float,
        from_currency: str,
        to_currency: str = "USD",
    ) -> CurrencyConversion:
        """
        Convert an amount between currencies.

        Uses USD as the bridge currency for cross pairs (e.g., ETH → USDC).
        """
        from_currency = from_currency.upper()
        to_currency = to_currency.upper()

        if from_currency not in SUPPORTED_CURRENCIES:
            raise ValueError(f"Unsupported source currency: {from_currency}")
        if to_currency not in SUPPORTED_CURRENCIES:
            raise ValueError(f"Unsupported target currency: {to_currency}")

        if from_currency == to_currency:
            return CurrencyConversion(
                from_currency=from_currency,
                to_currency=to_currency,
                from_amount=amount,
                to_amount=amount,
                rate=1.0,
                rate_source="identity",
            )

        # Convert via USD as bridge
        from_rate, source = self._rate_resolver.get_rate(from_currency)
        to_rate, _ = self._rate_resolver.get_rate(to_currency)

        # amount(from) → USD → amount(to)
        amount_usd = amount * from_rate
        result_amount = round(amount_usd / to_rate, 6)
        cross_rate = round(from_rate / to_rate, 6)

        conversion = CurrencyConversion(
            from_currency=from_currency,
            to_currency=to_currency,
            from_amount=amount,
            to_amount=result_amount,
            rate=cross_rate,
            rate_source=source,
        )

        logger.info(
            "Convert: %.6f %s → %.6f %s (rate=%.6f, source=%s)",
            amount, from_currency, result_amount, to_currency, cross_rate, source,
        )
        return conversion

    # ------------------------------------------------------------------
    # Multi-currency settlement
    # ------------------------------------------------------------------

    def settle_cross_currency(
        self,
        source_organ: str,
        target_organ: str,
        amount: float,
        from_currency: str,
        to_currency: str,
        intent_id: str = "",
        source_signature: str = "",
    ) -> FinOpsEntry:
        """
        Settle a cross-currency payment.

        Converts from_currency → to_currency, records both amounts and rate.
        """
        conversion = self.convert(amount, from_currency, to_currency)

        description = (
            f"Cross-currency settlement: {amount} {from_currency} → "
            f"{conversion.to_amount} {to_currency} "
            f"(rate={conversion.rate}, source={conversion.rate_source})"
        )

        entry = self._ledger.record_transaction(
            source_organ=source_organ,
            target_organ=target_organ,
            amount=conversion.to_amount,
            currency=to_currency,
            intent_id=intent_id,
            description=description,
            source_signature=source_signature,
        )

        # Record the original amount in from_currency as metadata
        # This is embedded in the description for audit trail
        logger.info(
            "Cross-currency settlement: %s → %s: %.6f %s → %.6f %s",
            source_organ, target_organ,
            amount, from_currency,
            conversion.to_amount, to_currency,
        )
        return entry

    def settle_in_currency(
        self,
        source_organ: str,
        target_organ: str,
        amount: float,
        currency: str = "USD",
        intent_id: str = "",
        source_signature: str = "",
    ) -> FinOpsEntry:
        """
        Settle a same-currency payment.

        Directly records the payment without conversion.
        """
        return self._ledger.record_transaction(
            source_organ=source_organ,
            target_organ=target_organ,
            amount=amount,
            currency=currency,
            intent_id=intent_id,
            description=f"Settlement in {currency}",
            source_signature=source_signature,
        )

    # ------------------------------------------------------------------
    # Payment execution with currency conversion
    # ------------------------------------------------------------------

    def execute_payment_in_currency(
        self,
        organ_id: str,
        amount: float,
        currency: str,
        vendor: str,
        description: str,
        settle_in: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Execute a payment in a specific currency.

        If settle_in is set, converts to that currency for settlement.
        Otherwise, uses the transaction currency.

        Integrates with the existing execute_approved_payment flow
        via the approval queue (L5-T4 coverage).
        """
        currency = currency.upper()
        if currency not in SUPPORTED_CURRENCIES:
            return {"status": "error", "error": f"Unsupported currency: {currency}"}

        target_currency = (settle_in or currency).upper()
        if target_currency not in SUPPORTED_CURRENCIES:
            return {"status": "error", "error": f"Unsupported settlement currency: {target_currency}"}

        try:
            # Get rate info for the payment
            rate, rate_source = self._rate_resolver.get_rate(currency)
            rate_info = {"rate": rate, "source": rate_source, "currency": currency}

            if currency != target_currency:
                conversion = self.convert(amount, currency, target_currency)
                settlement_amount = conversion.to_amount
                rate_info["conversion_rate"] = conversion.rate
                rate_info["settlement_currency"] = target_currency
            else:
                settlement_amount = amount

            # Record in ledger
            entry = self._ledger.record_transaction(
                source_organ=organ_id,
                target_organ=vendor,
                amount=settlement_amount,
                currency=target_currency,
                description=description,
            )

            return {
                "status": "pending",
                "entry_id": entry.entry_id,
                "amount_original": amount,
                "currency_original": currency,
                "amount_settled": settlement_amount,
                "currency_settled": target_currency,
                "rate_info": rate_info,
                "message": f"Payment of {amount} {currency} recorded as {settlement_amount} {target_currency}",
            }

        except Exception as e:
            logger.error("Payment execution failed: %s", e)
            return {"status": "error", "error": str(e)}

    # ------------------------------------------------------------------
    # Status & Info
    # ------------------------------------------------------------------

    def get_supported_currencies(self) -> List[str]:
        """Get list of supported currencies."""
        return sorted(SUPPORTED_CURRENCIES)

    def get_rate_summary(self) -> Dict[str, Any]:
        """Get a summary of current exchange rates."""
        rates = {}
        for cur in SUPPORTED_CURRENCIES:
            if cur == "USD":
                continue
            rate, source = self._rate_resolver.get_rate(cur)
            rates[cur] = {"rate_usd": rate, "source": source}
        return rates


# Module-level singleton
MULTI_CURRENCY_MANAGER = MultiCurrencyFlowManager()
