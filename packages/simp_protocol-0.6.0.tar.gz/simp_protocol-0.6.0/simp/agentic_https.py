"""
SIMP Agentic HTTPS

Canonical request/response wrappers for native SIMP agent invocation.
This keeps the core contract typed and local while remaining easy to expose
over broker HTTP, mesh, or direct in-process execution.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from simp.models.canonical_intent import CanonicalIntent


@dataclass
class AgentIdentity:
    """Identity payload for agent registration and trust verification."""
    agent_id: str
    public_key: str
    endpoint: str
    trust_state: str = "unverified"
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        if self.metadata:
            d["metadata"] = self.metadata
        return d


@dataclass
class AgenticIntentRequest:
    """Canonical intent envelope for native agent invocation over HTTPS."""
    intent: CanonicalIntent
    identity: AgentIdentity
    transport: str = "https"
    invocation_mode: str = "native"
    expect_stream: bool = False
    ttl_seconds: int = 300
    trace_id: Optional[str] = None
    correlation_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    def to_broker_payload(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgenticIntentRequest":
        identity_data = data.get("identity", {})
        intent_data = data.get("intent", {})
        return cls(
            intent=CanonicalIntent.from_dict(intent_data) if intent_data else CanonicalIntent(
                intent_type=data.get("intent_type", "unknown"),
                task_id=data.get("task_id", ""),
                actor=data.get("identity", {}).get("agent_id", "unknown"),
            ),
            identity=AgentIdentity(
                agent_id=identity_data.get("agent_id", ""),
                public_key=identity_data.get("public_key", ""),
                endpoint=identity_data.get("endpoint", ""),
                trust_state=identity_data.get("trust_state", "unverified"),
            ),
            transport=data.get("transport", "https"),
            invocation_mode=data.get("invocation_mode", "native"),
            expect_stream=data.get("expect_stream", False),
            ttl_seconds=data.get("ttl_seconds", 300),
            trace_id=data.get("trace_id"),
            correlation_id=data.get("correlation_id"),
            metadata=data.get("metadata"),
        )


@dataclass
class AgenticIntentResponse:
    """Canonical response from agent invocation."""
    status: str
    success: bool
    intent_id: Optional[str] = None
    target_agent: Optional[str] = None
    task_id: Optional[str] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    delivery_status: Optional[str] = None
    delivery_method: Optional[str] = None
    invocation_mode: Optional[str] = None
    trace_id: Optional[str] = None
    correlation_id: Optional[str] = None
    stream_endpoint: Optional[str] = None
    payload: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        result = {}
        r = asdict(self)
        for key in ["status", "success", "intent_id", "target_agent", "task_id",
                    "error_code", "error_message", "delivery_status", "delivery_method",
                    "invocation_mode", "trace_id", "correlation_id", "stream_endpoint", "payload"]:
            v = r.get(key)
            if v is not None:
                result[key] = v
        return result

    @classmethod
    def from_route_result(cls, result: Dict[str, Any]) -> "AgenticIntentResponse":
        return cls(
            status=str(result.get("status", "unknown")),
            success=bool(result.get("success", False)),
            intent_id=str(result.get("intent_id")) if result.get("intent_id") else None,
            target_agent=str(result.get("target_agent")) if result.get("target_agent") else None,
            task_id=str(result.get("task_id")) if result.get("task_id") else None,
            error_code=str(result.get("error_code")) if result.get("error_code") else None,
            error_message=str(result.get("error_message")) if result.get("error_message") else str(result.get("error", "")),
            delivery_status=str(result.get("delivery_status")) if result.get("delivery_status") else None,
            delivery_method=str(result.get("delivery_method")) if result.get("delivery_method") else None,
            invocation_mode=str(result.get("invocation_mode")) if result.get("invocation_mode") else None,
            trace_id=str(result.get("trace_id")) if result.get("trace_id") else None,
            correlation_id=str(result.get("correlation_id")) if result.get("correlation_id") else None,
            stream_endpoint=str(result.get("stream_endpoint")) if result.get("stream_endpoint") else None,
            payload=result.get("payload"),
        )


def build_contract_description() -> Dict[str, Any]:
    """Returns the OpenAPI-compatible contract description for agentic HTTPS."""
    return {
        "protocol": "agentic_https",
        "version": "1.0",
        "identity_fields": [
            "agent_id", "public_key", "endpoint", "trust_state"
        ],
        "request_fields": [
            "intent", "identity", "transport", "invocation_mode", "expect_stream",
            "ttl_seconds", "trace_id", "correlation_id", "metadata"
        ],
        "response_fields": [
            "status", "success", "intent_id", "target_agent", "task_id",
            "error_code", "error_message", "delivery_status", "delivery_method",
            "invocation_mode", "trace_id", "correlation_id", "stream_endpoint", "payload"
        ],
        "streaming": "sse",
        "invocation_modes": [
            "native", "mesh_native", "http_native", "external_bridge", "mcp_bridge"
        ],
        "errors": [
            "BROKER_NOT_RUNNING", "VALIDATION_FAILED", "INVALID_SIGNATURE",
            "AGENT_NOT_FOUND", "BRP_DENIED", "BRP_REVIEW_REQUIRED", "TIMEOUT", "INTERNAL_ERROR"
        ]
    }
