"""
simp.db.database — SQLite and Postgres database layer for SIMP.

Provides:
- SQLiteDatabase  — file-backed SQLite with thread-safe writes
- PostgresDatabase — psycopg2-backed Postgres with env-driven config
- get_database()  — factory: Postgres if DATABASE_URL set, else SQLite
- reset_database() — reinitializes the global singleton (for tests)

Schema reflects migrations 001–005 (core tables, strategy registry,
rotation/audit, and routing_outcomes + reflection_lessons).
"""

from __future__ import annotations

import os
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = __import__("logging").getLogger(__name__)

# ── Global singleton ────────────────────────────────────────────────────────

_global_db: Optional[object] = None
_global_lock = threading.Lock()


def reset_database() -> None:
    """Reset the global database singleton (for test isolation)."""
    global _global_db
    with _global_lock:
        if _global_db is not None and hasattr(_global_db, "close"):
            try:
                _global_db.close()
            except Exception:
                pass
        _global_db = None


def get_database() -> "DatabaseBase":
    """
    Return the configured database instance.

    - DATABASE_URL set  → PostgresDatabase
    - not set           → SQLiteDatabase at data/simp.db
    """
    global _global_db
    with _global_lock:
        if _global_db is not None:
            return _global_db

        url = os.environ.get("DATABASE_URL", "").strip()
        if url:
            _global_db = PostgresDatabase(url)
        else:
            db_path = Path("data/simp.db")
            db_path.parent.mkdir(parents=True, exist_ok=True)
            _global_db = SQLiteDatabase(str(db_path))

        _global_db.initialize()
        return _global_db


# ── Base interface ──────────────────────────────────────────────────────────

class DatabaseBase:
    """Abstract interface shared by SQLiteDatabase and PostgresDatabase."""

    def initialize(self) -> None:
        raise NotImplementedError

    def record_routing_outcome(
        self,
        intent_hash: str,
        routed_to: str,
        latency_ms: float,
        success: bool,
    ) -> None:
        raise NotImplementedError

    def close(self) -> None:
        pass


# ── SQLiteDatabase ─────────────────────────────────────────────────────────

class SQLiteDatabase(DatabaseBase):
    """
    Thread-safe SQLite database for SIMP.

    Args:
        db_path: Path to the .db file (e.g. "data/simp.db").
                 Parent directory is created on first initialize().

    Example:
        db = SQLiteDatabase("data/simp.db")
        db.initialize()
        db.record_routing_outcome("abc123", "alpha_goose", 2.5, True)
    """

    def __init__(self, db_path: str) -> None:
        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.RLock()

    # ── Connection ─────────────────────────────────────────────────────────

    def _ensure_connection(self) -> sqlite3.Connection:
        if self._conn is None:
            # Auto-create parent directory
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(
                self._db_path,
                check_same_thread=False,
            )
            self._conn.row_factory = sqlite3.Row
        return self._conn

    # ── DatabaseBase ──────────────────────────────────────────────────────

    def initialize(self) -> None:
        """Create all SIMP tables (migrations 001–005 equivalent)."""
        conn = self._ensure_connection()
        cur = conn.cursor()
        cur.execute("PRAGMA foreign_keys = ON")

        # 001 — core tables
        cur.execute("""
            CREATE TABLE IF NOT EXISTS agents (
                agent_id   TEXT PRIMARY KEY,
                name       TEXT NOT NULL,
                kind       TEXT,
                status     TEXT DEFAULT 'active',
                config     TEXT DEFAULT '{}',
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at TEXT NOT NULL DEFAULT (datetime('now')),
                last_seen  TEXT,
                metadata   TEXT DEFAULT '{}'
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id    TEXT PRIMARY KEY,
                agent_id   TEXT REFERENCES agents(agent_id),
                intent    TEXT,
                status    TEXT DEFAULT 'pending',
                result    TEXT,
                error     TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at TEXT NOT NULL DEFAULT (datetime('now')),
                completed_at TEXT
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS mesh_messages (
                msg_id    TEXT PRIMARY KEY,
                sender_id TEXT,
                channel   TEXT,
                payload   TEXT,
                sent_at   TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS arb_opportunities (
                opp_id     TEXT PRIMARY KEY,
                pair       TEXT,
                exchange_a TEXT,
                exchange_b TEXT,
                spread_pct REAL,
                volume_usd REAL,
                status     TEXT DEFAULT 'detected',
                executed_at TEXT,
                profit_usd REAL,
                detected_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS strategy_versions (
                strategy_id TEXT PRIMARY KEY,
                version    TEXT,
                params     TEXT,
                stage      TEXT,
                deployed_at TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS strategy_performance (
                id         INTEGER PRIMARY KEY,
                strategy_id TEXT,
                timestamp  TEXT NOT NULL DEFAULT (datetime('now')),
                return_pct REAL,
                sharpe     REAL,
                max_drawdown REAL,
                volume_usd REAL,
                UNIQUE(strategy_id, timestamp)
            )
        """)

        # 003 — strategy registry
        cur.execute("""
            CREATE TABLE IF NOT EXISTS strategy_registry (
                strategy_id     TEXT NOT NULL,
                version         TEXT NOT NULL,
                name            TEXT,
                description     TEXT,
                params          TEXT DEFAULT '{}',
                stage           TEXT DEFAULT 'draft',
                min_capital     REAL DEFAULT 0,
                max_capital     REAL DEFAULT 1000000,
                applicable_regimes TEXT,
                applicable_pairs   TEXT,
                created_by      TEXT,
                created_at      TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at      TEXT NOT NULL DEFAULT (datetime('now')),
                promoted_at     TEXT,
                promoted_by     TEXT,
                deprecated_at   TEXT,
                deprecation_reason TEXT,
                PRIMARY KEY (strategy_id, version)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS strategy_promotion_audit (
                event_id    TEXT PRIMARY KEY,
                strategy_id  TEXT,
                from_stage  TEXT,
                to_stage    TEXT,
                version     TEXT,
                actor       TEXT,
                timestamp   TEXT NOT NULL DEFAULT (datetime('now')),
                reason      TEXT,
                notes       TEXT
            )
        """)

        # 004 — vault rotation
        cur.execute("""
            CREATE TABLE IF NOT EXISTS secret_rotation_log (
                event_id           TEXT PRIMARY KEY,
                secret_path        TEXT,
                state              TEXT,
                trigger            TEXT,
                version_before     TEXT,
                version_after      TEXT,
                started_at         TEXT NOT NULL DEFAULT (datetime('now')),
                completed_at       TEXT,
                retry_count        INTEGER DEFAULT 0,
                error              TEXT,
                actor              TEXT
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS secret_access_audit (
                id         INTEGER PRIMARY KEY,
                secret_path TEXT,
                accessor    TEXT,
                access_type TEXT,
                accessed_at TEXT NOT NULL DEFAULT (datetime('now')),
                success    INTEGER DEFAULT 1
            )
        """)

        # 005 — routing and reflection
        cur.execute("""
            CREATE TABLE IF NOT EXISTS routing_outcomes (
                id           INTEGER PRIMARY KEY,
                intent_hash  TEXT NOT NULL,
                routed_to    TEXT,
                latency_ms   REAL,
                success      INTEGER DEFAULT 0,
                decision     TEXT,
                routing_tier TEXT,
                confidence   REAL,
                created_at   TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)

        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_routing_intent_hash
                ON routing_outcomes(intent_hash)
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_routing_routed_to
                ON routing_outcomes(routed_to)
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_routing_success
                ON routing_outcomes(success)
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_routing_created
                ON routing_outcomes(created_at DESC)
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS reflection_lessons (
                id           INTEGER PRIMARY KEY,
                episode_id   TEXT NOT NULL,
                lesson_text  TEXT NOT NULL,
                policy_delta TEXT,
                embedding    TEXT,
                created_at   TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)

        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_reflection_episode
                ON reflection_lessons(episode_id)
        """)

        conn.commit()
        cur.close()
        logger.info("SQLiteDatabase initialized at %s", self._db_path)

    def record_routing_outcome(
        self,
        intent_hash: str,
        routed_to: str,
        latency_ms: float,
        success: bool,
    ) -> None:
        """
        Record a routing decision.

        Args:
            intent_hash: Hash of the intent that was routed.
            routed_to:   Agent ID or tier label (e.g. 'alpha_goose', 'tier_B').
            latency_ms:  Time taken to process the routing decision.
            success:     True if executed, False if rejected/deferred.
        """
        conn = self._ensure_connection()
        with self._lock:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO routing_outcomes
                    (intent_hash, routed_to, latency_ms, success, created_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    intent_hash,
                    routed_to,
                    latency_ms,
                    1 if success else 0,
                    datetime.now(timezone.utc).isoformat(),
                ),
            )
            conn.commit()
            cur.close()

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None


# ── PostgresDatabase ────────────────────────────────────────────────────────

class PostgresDatabase(DatabaseBase):
    """
    psycopg2-backed PostgreSQL database for SIMP.

    Args:
        conn_string: Full ``postgresql://...`` connection string, or the
                     value of the ``DATABASE_URL`` environment variable.

    Example:
        db = PostgresDatabase("postgresql://user:pass@localhost/simp")
        db.initialize()
        db.record_routing_outcome("abc123", "alpha_goose", 2.5, True)
    """

    def __init__(self, conn_string: str) -> None:
        self._conn_string = conn_string
        self._conn = None

    # ── Connection ─────────────────────────────────────────────────────────

    def _ensure_connection(self):
        if self._conn is None:
            import psycopg2
            from psycopg2 import pool

            self._conn = psycopg2.connect(self._conn_string)
            self._conn.autocommit = False
        return self._conn

    # ── DatabaseBase ──────────────────────────────────────────────────────

    def initialize(self) -> None:
        """Create all SIMP tables using raw SQL (migrations 001–005)."""
        conn = self._ensure_connection()
        cur = conn.cursor()

        # 001 — core tables
        cur.execute("""
            CREATE TABLE IF NOT EXISTS agents (
                agent_id   VARCHAR(128) PRIMARY KEY,
                name       VARCHAR(256) NOT NULL,
                kind       VARCHAR(64),
                status     VARCHAR(32) DEFAULT 'active',
                config     JSONB DEFAULT '{}',
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                last_seen  TIMESTAMPTZ,
                metadata   JSONB DEFAULT '{}'
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id    VARCHAR(128) PRIMARY KEY,
                agent_id   VARCHAR(128) REFERENCES agents(agent_id),
                intent    TEXT,
                status    VARCHAR(32) DEFAULT 'pending',
                result    JSONB,
                error     TEXT,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                completed_at TIMESTAMPTZ
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS mesh_messages (
                msg_id    VARCHAR(128) PRIMARY KEY,
                sender_id VARCHAR(128),
                channel   VARCHAR(256),
                payload   JSONB,
                sent_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS arb_opportunities (
                opp_id    VARCHAR(128) PRIMARY KEY,
                pair      VARCHAR(32),
                exchange_a VARCHAR(64),
                exchange_b VARCHAR(64),
                spread_pct FLOAT,
                volume_usd FLOAT,
                status    VARCHAR(32) DEFAULT 'detected',
                executed_at TIMESTAMPTZ,
                profit_usd FLOAT,
                detected_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS strategy_versions (
                strategy_id VARCHAR(128) PRIMARY KEY,
                version    VARCHAR(32),
                params     JSONB,
                stage      VARCHAR(32),
                deployed_at TIMESTAMPTZ,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS strategy_performance (
                id         SERIAL PRIMARY KEY,
                strategy_id VARCHAR(128),
                timestamp  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                return_pct FLOAT,
                sharpe     FLOAT,
                max_drawdown FLOAT,
                volume_usd FLOAT,
                UNIQUE(strategy_id, timestamp)
            )
        """)

        # 003 — strategy registry
        cur.execute("""
            CREATE TABLE IF NOT EXISTS strategy_registry (
                strategy_id VARCHAR(128) NOT NULL,
                version     VARCHAR(32) NOT NULL,
                name        VARCHAR(256),
                description TEXT,
                params      JSONB DEFAULT '{}',
                stage       VARCHAR(32) DEFAULT 'draft',
                min_capital FLOAT DEFAULT 0,
                max_capital FLOAT DEFAULT 1000000,
                applicable_regimes TEXT[],
                applicable_pairs   TEXT[],
                created_by  VARCHAR(128),
                created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                promoted_at TIMESTAMPTZ,
                promoted_by VARCHAR(128),
                deprecated_at TIMESTAMPTZ,
                deprecation_reason TEXT,
                PRIMARY KEY (strategy_id, version)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS strategy_promotion_audit (
                event_id    VARCHAR(128) PRIMARY KEY,
                strategy_id  VARCHAR(128),
                from_stage  VARCHAR(32),
                to_stage    VARCHAR(32),
                version     VARCHAR(32),
                actor       VARCHAR(128),
                timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                reason      TEXT,
                notes       TEXT
            )
        """)

        # 004 — vault rotation
        cur.execute("""
            CREATE TABLE IF NOT EXISTS secret_rotation_log (
                event_id     VARCHAR(128) PRIMARY KEY,
                secret_path  VARCHAR(512),
                state        VARCHAR(32),
                trigger      VARCHAR(32),
                version_before VARCHAR(32),
                version_after VARCHAR(32),
                started_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                completed_at TIMESTAMPTZ,
                retry_count INT DEFAULT 0,
                error       TEXT,
                actor       VARCHAR(128)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS secret_access_audit (
                id         SERIAL PRIMARY KEY,
                secret_path VARCHAR(512),
                accessor    VARCHAR(128),
                access_type VARCHAR(32),
                accessed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                success    BOOLEAN DEFAULT TRUE
            )
        """)

        # 005 — routing and reflection
        cur.execute("""
            CREATE TABLE IF NOT EXISTS routing_outcomes (
                id           SERIAL PRIMARY KEY,
                intent_hash  TEXT NOT NULL,
                routed_to    TEXT,
                latency_ms   FLOAT,
                success      BOOLEAN DEFAULT FALSE,
                decision     TEXT,
                routing_tier TEXT,
                confidence   FLOAT,
                created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)

        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_routing_intent_hash
                ON routing_outcomes(intent_hash)
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_routing_routed_to
                ON routing_outcomes(routed_to)
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_routing_success
                ON routing_outcomes(success)
        """)
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_routing_created
                ON routing_outcomes(created_at DESC)
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS reflection_lessons (
                id           SERIAL PRIMARY KEY,
                episode_id   TEXT NOT NULL,
                lesson_text  TEXT NOT NULL,
                policy_delta JSONB,
                embedding    TEXT,
                created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)

        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_reflection_episode
                ON reflection_lessons(episode_id)
        """)

        conn.commit()
        cur.close()
        logger.info("PostgresDatabase initialized")

    def record_routing_outcome(
        self,
        intent_hash: str,
        routed_to: str,
        latency_ms: float,
        success: bool,
    ) -> None:
        """
        Record a routing decision.

        Args:
            intent_hash: Hash of the intent that was routed.
            routed_to:   Agent ID or tier label.
            latency_ms:  Time taken to process the routing decision.
            success:     True if executed, False if rejected/deferred.
        """
        conn = self._ensure_connection()
        cur = conn.cursor()
        cur.execute(
            """
            INSERT INTO routing_outcomes
                (intent_hash, routed_to, latency_ms, success)
            VALUES (%s, %s, %s, %s)
            """,
            (intent_hash, routed_to, latency_ms, success),
        )
        conn.commit()
        cur.close()

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None