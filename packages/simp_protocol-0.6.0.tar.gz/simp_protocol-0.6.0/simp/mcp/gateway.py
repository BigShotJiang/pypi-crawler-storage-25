"""
SIMP MCP Gateway

Exposes every registered SIMP agent as a callable MCP tool.

This is the bridge between SIMP's agent ecosystem and the broader
MCP ecosystem (LangChain, AutoGen, CrewAI, Claude Desktop, etc.).

Any agent registered via POST /v1/agents/register automatically
appears as an MCP tool that any MCP client can discover and call.

Architecture:
    CapabilityRegistry (mesh/discovery_routes)
        → AgentToolAdapter (wraps agent as SimpMCPTool)
            → tool_registry.register() (exposes via MCP)
                → MCPServer (stdio + HTTP)
"""

import json
import logging
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

from .tool_registry import tool_registry
from .tool_schema import SimpMCPTool
# We'll import discovery_routes internally in sync() to avoid Flask dependency

logger = logging.getLogger("mcp.gateway")

@dataclass
class AgentToolAdapter:
    """
    Wraps a registered SIMP agent as an MCP tool.
    
    When an MCP client calls this tool, it routes the intent
    through SIMP's intent mesh, leveraging trust scoring, 
    fee settlement, and Ed25519 signing.
    """
    agent_id: str
    capabilities: List[str]
    public_key: str
    endpoint: Optional[str]
    
    def to_mcp_tool(self) -> SimpMCPTool:
        """Convert this agent to an MCP tool definition."""
        return SimpMCPTool(
            name=f"simp_agent__{self.agent_id.replace('-', '_')}",
            description=f"SIMP Agent: {self.agent_id}\nCapabilities: {', '.join(self.capabilities)}",
            input_schema={
                "type": "object",
                "properties": {
                    "intent": {
                        "type": "string",
                        "description": "The intent to route to this agent"
                    },
                    "parameters": {
                        "type": "object",
                        "description": "Parameters for the intent",
                        "additionalProperties": True
                    },
                    "settlement_mode": {
                        "type": "string",
                        "enum": ["instant", "batch", "channel"],
                        "default": "instant",
                        "description": "Payment settlement mode"
                    }
                },
                "required": ["intent"]
            },
            handler=self._handle_intent
        )
    
    async def _handle_intent(self, intent: str, parameters: Optional[Dict] = None,
                              settlement_mode: str = "instant") -> Dict[str, Any]:
        """
        Handle an MCP tool call by routing an intent to this agent.
        
        In production, this would:
        1. Create a CanonicalIntent
        2. Sign it with the caller's Ed25519 key
        3. Route it through IntentMeshRouter
        4. Settle payment via SimpPay
        5. Return the response
        
        For now, this returns a structured acknowledgment.
        """
        return {
            "status": "routed",
            "target_agent": self.agent_id,
            "intent": intent,
            "parameters": parameters or {},
            "settlement_mode": settlement_mode,
            "message": f"Intent routed to {self.agent_id}"
        }


class MCPGateway:
    """
    Gateway that syncs SIMP Agent Registry → MCP Tool Registry.
    
    Call sync() to refresh the tool listing from the agent registry.
    Call watch() to continuously sync in the background.
    """
    
    def __init__(self, sync_interval: int = 30):
        self.sync_interval = sync_interval
        self._adapters: Dict[str, AgentToolAdapter] = {}
        self._synced = False
    
    def sync(self) -> int:
        """Sync all registered agents to MCP tools. Returns count."""
        count = 0
        try:
            from ..server.discovery_routes import _agent_store, _get_shared_store
            agents = list(_get_shared_store().values())
            for agent in agents:
                agent_id = agent.get("agent_id") or agent.get("id", "")
                caps = agent.get("capabilities", agent.get("caps", []))
                pubkey = agent.get("public_key", agent.get("pubkey", ""))
                endpoint = agent.get("endpoint")
                
                if not agent_id:
                    continue
                
                adapter = AgentToolAdapter(agent_id, caps, pubkey, endpoint)
                mcp_tool = adapter.to_mcp_tool()
                tool_registry.register(mcp_tool)
                self._adapters[agent_id] = adapter
                count += 1
            
            self._synced = True
            logger.info("MCP Gateway: synced %d agents to MCP tools", count)
        except Exception as e:
            logger.warning("MCP Gateway: sync failed: %s", e)
        
        return count
    
    def get_agent_count(self) -> int:
        """Return number of synced agents."""
        return len(self._adapters)
    
    def list_available_agents(self) -> List[Dict[str, Any]]:
        """Return summary of all synced agents."""
        result = []
        for agent_id, adapter in self._adapters.items():
            result.append({
                "agent_id": agent_id,
                "capabilities": adapter.capabilities,
                "mcp_tool": f"simp_agent__{agent_id.replace('-', '_')}"
            })
        return result

# Singleton
mcp_gateway = MCPGateway()

__all__ = ["MCPGateway", "AgentToolAdapter", "mcp_gateway"]
