"""
SIMP MCP Stdio Server

Exposes SIMP agents as MCP tools via stdio, compatible with Claude Desktop
and other stdio-based MCP clients.

Usage:
    cd /path/to/simp && python3.10 -m simp.mcp.stdio_server

    Or run directly:
    cd /path/to/simp && python3.10 simp/mcp/stdio_server.py
"""

from __future__ import annotations

import json
import logging
import os
import sys
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [MCP] %(levelname)s: %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger("simp.mcp.stdio_server")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BROKER_URL = os.environ.get(
    "SIMP_BROKER_URL",
    "https://simp-broker.fly.dev",
)
LOCAL_BROKER_URL = os.environ.get(
    "SIMP_LOCAL_BROKER_URL",
    "http://localhost:5555",
)
REQUEST_TIMEOUT = float(os.environ.get("SIMP_MCP_TIMEOUT", "30.0"))

# MCP protocol constants
MCP_VERSION = "1.0"


# ---------------------------------------------------------------------------
# Data Classes
# ---------------------------------------------------------------------------

class McpJsonRpcError(Exception):
    """Represents a JSON-RPC error response."""
    def __init__(self, code: int, message: str, data: Optional[Any] = None):
        self.code = code
        self.message = message
        self.data = data
        super().__init__(message)


class MCPTool:
    """Describes an MCP tool exposed to the client."""
    def __init__(
        self,
        name: str,
        description: str,
        input_schema: Dict[str, Any],
        agent_id: str,
        capabilities: Optional[List[str]] = None,
    ):
        self.name = name
        self.description = description
        self.input_schema = input_schema
        self.agent_id = agent_id
        self.capabilities = capabilities or []

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


class SimplerAgent:
    """Lightweight agent descriptor fetched from the broker registry."""
    def __init__(
        self,
        agent_id: str,
        agent_type: str,
        endpoint: str,
        capabilities: List[str],
        state: str = "online",
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.endpoint = endpoint
        self.capabilities = capabilities
        self.state = state
        self.metadata = metadata or {}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SimplerAgent":
        return cls(
            agent_id=data.get("agent_id", ""),
            agent_type=data.get("agent_type", data.get("type", "")),
            endpoint=data.get("endpoint", ""),
            capabilities=data.get("capabilities", []),
            state=data.get("state", "online"),
            metadata=data.get("metadata", {}),
        )

    def to_mcp_tool(self) -> MCPTool:
        """Convert to an MCP tool definition."""
        name = f"simp_agent__{self.agent_id}"
        cap_str = ", ".join(self.capabilities) if self.capabilities else "general-purpose"
        description = (
            f"SIMP Agent: {self.agent_id} | "
            f"Type: {self.agent_type} | "
            f"Capabilities: {cap_str}"
        )
        return MCPTool(
            name=name,
            description=description,
            input_schema={
                "type": "object",
                "properties": {
                    "intent": {
                        "type": "string",
                        "description": "The task or intent description to send to this agent",
                    },
                    "parameters": {
                        "type": "object",
                        "description": "Additional key-value parameters for the intent",
                    },
                },
                "required": ["intent"],
            },
            agent_id=self.agent_id,
            capabilities=self.capabilities,
        )


# ---------------------------------------------------------------------------
# Broker Client
# ---------------------------------------------------------------------------

class BrokerClient:
    """
    HTTP client for the SIMP broker.
    Fetches agent registry and dispatches intents.
    """

    def __init__(
        self,
        broker_url: str = BROKER_URL,
        local_broker_url: str = LOCAL_BROKER_URL,
        timeout: float = REQUEST_TIMEOUT,
    ):
        self.broker_url = broker_url.rstrip("/")
        self.local_broker_url = local_broker_url.rstrip("/")
        self.timeout = timeout
        self._client: Optional[httpx.Client] = None
        self._lock = threading.Lock()

    @property
    def client(self) -> httpx.Client:
        """Lazily created HTTP client."""
        if self._client is None:
            with self._lock:
                if self._client is None:
                    self._client = httpx.Client(
                        timeout=self.timeout,
                        follow_redirects=True,
                        headers={"User-Agent": f"SIMP-MCP-Stdio/1.0"},
                    )
        return self._client

    def close(self) -> None:
        if self._client:
            with self._lock:
                if self._client:
                    self._client.close()
                    self._client = None

    def _fetch_agents_from_url(self, url: str) -> List[SimplerAgent]:
        """Attempt to fetch agents from a specific broker URL."""
        try:
            response = self.client.get(
                f"{url}/agents",
                headers={"Accept": "application/json"},
            )
            if response.status_code == 200:
                data = response.json()
                agents_data = data if isinstance(data, list) else data.get("agents", [])
                logger.info("Fetched %d agents from %s", len(agents_data), url)
                return [SimplerAgent.from_dict(a) for a in agents_data]
            else:
                logger.warning(
                    "Broker at %s returned status %s",
                    url, response.status_code,
                )
        except httpx.TimeoutException:
            logger.warning("Timeout fetching agents from %s", url)
        except httpx.ConnectError as e:
            logger.warning("Cannot connect to broker at %s: %s", url, e)
        except Exception as e:
            logger.error("Unexpected error fetching agents from %s: %s", url, e)
        return []

    def list_agents(self) -> List[SimplerAgent]:
        """
        Fetch registered agents from the broker.
        Tries remote broker first, falls back to local.
        """
        # Try remote broker
        agents = self._fetch_agents_from_url(self.broker_url)
        if agents:
            return agents

        # Fall back to local broker
        logger.info("Falling back to local broker at %s", self.local_broker_url)
        agents = self._fetch_agents_from_url(self.local_broker_url)
        return agents

    def dispatch_intent(
        self,
        target_agent: str,
        intent: str,
        parameters: Optional[Dict[str, Any]] = None,
        source_agent: str = "mcp_stdio_client",
    ) -> Dict[str, Any]:
        """
        Dispatch an intent to a target agent via the broker.

        Returns a dict with either:
          - {"status": "success", "data": ...}
          - {"status": "error", "error_code": ..., "error": ...}
        """
        # Build intent payload matching the broker's expected format
        intent_id = str(uuid.uuid4())
        payload = {
            "intent_id": intent_id,
            "source_agent": source_agent,
            "target_agent": target_agent,
            "intent_type": "mcp_tool_call",
            "params": {
                "intent": intent,
                "parameters": parameters or {},
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        # Try remote broker first
        resp = self._post_intent_to_url(self.broker_url, payload)
        if resp is not None:
            return resp

        # Fall back to local broker
        resp = self._post_intent_to_url(self.local_broker_url, payload)
        if resp is not None:
            return resp

        # Both failed
        return {
            "status": "error",
            "error_code": "BROKER_UNREACHABLE",
            "error": (
                f"Could not reach broker at {self.broker_url} "
                f"or {self.local_broker_url}"
            ),
        }

    def _post_intent_to_url(self, url: str, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Attempt to POST an intent to a specific broker URL. Returns None on failure."""
        try:
            response = self.client.post(
                f"{url}/intents/route",
                json=payload,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            )
            if response.status_code in (200, 201):
                try:
                    return response.json()
                except json.JSONDecodeError:
                    return {
                        "status": "success",
                        "data": response.text,
                    }
            else:
                logger.warning(
                    "Intent routing to %s returned HTTP %s: %s",
                    url, response.status_code, response.text[:500],
                )
                return {
                    "status": "error",
                    "error_code": f"HTTP_{response.status_code}",
                    "error": f"Broker returned status {response.status_code}",
                    "body": response.text[:500],
                }
        except httpx.TimeoutException:
            logger.warning("Timeout dispatching intent to %s", url)
            return None
        except httpx.ConnectError as e:
            logger.warning("Cannot connect to broker at %s: %s", url, e)
            return None
        except Exception as e:
            logger.error("Unexpected error dispatching intent to %s: %s", url, e)
            return None


# ---------------------------------------------------------------------------
# MCP Stdio Server
# ---------------------------------------------------------------------------

class McpStdioServer:
    """
    MCP server implemented over stdio.

    Reads JSON-RPC requests from stdin, writes responses to stdout.
    Handles: initialize, tools/list, tools/call, shutdown.
    """

    def __init__(self, broker_client: Optional[BrokerClient] = None):
        self.broker = broker_client or BrokerClient()
        self._tools: List[MCPTool] = []
        self._tools_lock = threading.Lock()
        self._initialized = False
        self._shutdown_requested = False

    # ── Tool management ────────────────────────────────────────────────────────

    def refresh_tools(self) -> None:
        """Re-fetch agent registry from broker and rebuild tool list."""
        logger.info("Refreshing agent registry from broker...")
        agents = self.broker.list_agents()
        tools = [agent.to_mcp_tool() for agent in agents]
        with self._tools_lock:
            self._tools = tools
        logger.info("Loaded %d agent tools", len(tools))

    def get_tools(self) -> List[MCPTool]:
        """Return current tool list (lazy-loaded on first call)."""
        with self._tools_lock:
            if not self._tools:
                self.refresh_tools()
            return list(self._tools)

    # ── JSON-RPC request handling ───────────────────────────────────────────────

    def handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """
        Dispatch a JSON-RPC request and return the response dict.
        The response dict is either a result or an error response.
        """
        method = request.get("method", "")
        req_id = request.get("id")

        try:
            if method == "initialize":
                return self._handle_initialize(request, req_id)
            elif method == "tools/list":
                return self._handle_tools_list(request, req_id)
            elif method == "tools/call":
                return self._handle_tools_call(request, req_id)
            elif method == "shutdown":
                return self._handle_shutdown(request, req_id)
            elif method == "notifications/initialized":
                # Client notification after initialize — no response needed
                return None
            else:
                raise McpJsonRpcError(
                    code=-32601,
                    message=f"Method not found: {method}",
                )
        except McpJsonRpcError:
            raise
        except Exception as e:
            logger.error("Unexpected error handling %s: %s", method, e)
            raise McpJsonRpcError(
                code=-32603,
                message=f"Internal error: {e}",
            )

    def _handle_initialize(
        self, request: Dict[str, Any], req_id: Any
    ) -> Dict[str, Any]:
        """Handle JSON-RPC initialize — return server capabilities."""
        self._initialized = True
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "protocolVersion": MCP_VERSION,
                "capabilities": {
                    "tools": {},
                },
                "serverInfo": {
                    "name": "simp-mcp-stdio",
                    "version": "1.0.0",
                },
            },
        }

    def _handle_tools_list(
        self, request: Dict[str, Any], req_id: Any
    ) -> Dict[str, Any]:
        """Handle tools/list — return all available SIMP agent tools."""
        tools = self.get_tools()
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {
                "tools": [t.to_dict() for t in tools],
            },
        }

    def _handle_tools_call(
        self, request: Dict[str, Any], req_id: Any
    ) -> Dict[str, Any]:
        """Handle tools/call — dispatch intent to target agent."""
        params = request.get("params", {})
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        # Validate tool name
        if not tool_name.startswith("simp_agent__"):
            return self._error_response(
                req_id,
                -32602,
                f"Unknown tool: {tool_name}",
            )

        agent_id = tool_name[len("simp_agent__"):]
        intent = arguments.get("intent", "")
        parameters = arguments.get("parameters", {})

        if not intent:
            return self._error_response(
                req_id,
                -32602,
                "Missing required field: intent",
            )

        logger.info(
            "Calling tool %s for agent %s with intent: %s",
            tool_name, agent_id, intent[:80],
        )

        result = self.broker.dispatch_intent(
            target_agent=agent_id,
            intent=intent,
            parameters=parameters,
        )

        # Convert broker response to MCP tool result format
        if result.get("status") == "success":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(result.get("data", result), indent=2),
                        }
                    ],
                    "isError": False,
                },
            }
        else:
            error_msg = result.get("error", str(result))
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": f"[ERROR] {result.get('error_code', 'UNKNOWN')}: {error_msg}",
                        }
                    ],
                    "isError": True,
                },
            }

    def _handle_shutdown(
        self, request: Dict[str, Any], req_id: Any
    ) -> Dict[str, Any]:
        """Handle shutdown — mark shutdown and return."""
        self._shutdown_requested = True
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "result": {"success": True},
        }

    def _error_response(
        self, req_id: Any, code: int, message: str
    ) -> Dict[str, Any]:
        """Build a JSON-RPC error response."""
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {
                "code": code,
                "message": message,
            },
        }

    # ── Stdio I/O ──────────────────────────────────────────────────────────────

    def read_message(self) -> Optional[Dict[str, Any]]:
        """Read one JSON-RPC message from stdin. Returns None on EOF."""
        try:
            line = sys.stdin.readline()
            if not line:
                return None
            line = line.strip()
            if not line:
                return None
            return json.loads(line)
        except json.JSONDecodeError as e:
            logger.error("Failed to parse JSON from stdin: %s", e)
            raise McpJsonRpcError(-32700, f"Parse error: {e}")

    def write_message(self, msg: Dict[str, Any]) -> None:
        """Write one JSON-RPC message to stdout."""
        sys.stdout.write(json.dumps(msg, indent=None) + "\n")
        sys.stdout.flush()

    def write_error(self, req_id: Any, code: int, message: str) -> None:
        """Write a JSON-RPC error response to stdout."""
        self.write_message({
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": code, "message": message},
        })

    def run(self) -> None:
        """
        Main loop: read requests from stdin, write responses to stdout.
        Runs until shutdown or EOF on stdin.
        """
        logger.info("SIMP MCP Stdio Server starting...")
        self.refresh_tools()
        logger.info("Server ready, waiting for requests...")

        while not self._shutdown_requested:
            try:
                request = self.read_message()
                if request is None:
                    logger.info("stdin closed — exiting")
                    break

                response = self.handle_request(request)
                if response is not None:
                    self.write_message(response)

            except McpJsonRpcError as e:
                # Try to extract req_id from current request for error response
                req_id = None
                try:
                    # We need to track the current request ID differently
                    # Since handle_request raises, we parse here
                    pass
                except Exception:
                    pass
                # Fallback: write error with null id
                self.write_message({
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": e.code, "message": e.message},
                })
            except Exception as e:
                logger.error("Fatal error in main loop: %s", e)
                self.write_message({
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": -32603, "message": f"Fatal: {e}"},
                })
                break

        logger.info("SIMP MCP Stdio Server shutting down")
        self.broker.close()


# ---------------------------------------------------------------------------
# Entry Points
# ---------------------------------------------------------------------------

def main() -> None:
    """Run the MCP stdio server."""
    server = McpStdioServer()
    server.run()


if __name__ == "__main__":
    main()