"""
SIMP MCP Server

Exposes SIMP's registered tools via the Model Context Protocol (MCP).

Supports two transports:
- stdio  — for local agents, subprocess spawning
- HTTP   — for remote agents, via a lightweight Flask app

MCP Protocol Endpoints
----------------------
GET  /health           — health check
GET  /mcp/tools/list   — list all tools as MCP tool definitions
POST /mcp/tools/call   — call a tool by name with arguments

Usage
-----
    # Standalone stdio mode
    server = MCPServer()
    server.start()          # runs until stop()

    # HTTP mode
    server = MCPServer(port=8080)
    server.start()          # starts Flask server in background thread
    server.stop()           # shuts down

    # Zero-arg default
    server = MCPServer()
"""

from __future__ import annotations

import json
import logging
import os
import sys
import threading
import time
from typing import Any, Dict, List, Optional, Union

from .intent_bridge import IntentBridge, intent_bridge
from .tool_registry import tool_registry
from .tool_schema import SimpMCPTool

logger = logging.getLogger("mcp.server")

# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

_RESULT_TOOLARGE = 1 << 16
_MAX_RESPONSE_BYTES = 10 * 1024 * 1024  # 10 MB


def _truncate(data: Any, max_bytes: int = _MAX_RESPONSE_BYTES) -> Any:
    """Truncate a response if it exceeds the size limit."""
    repred = json.dumps(data, default=str)
    if len(repred.encode()) > max_bytes:
        return {
            "_truncated": True,
            "original_size_bytes": len(repared.encode()),
            "max_size_bytes": max_bytes,
            "message": "Response exceeds MCP server limit and was truncated.",
        }
    return data


# ---------------------------------------------------------------------------
# MCPServer
# ---------------------------------------------------------------------------

class MCPServer:
    """
    MCP server that wraps an IntentBridge and exposes tools over stdio or HTTP.

    Args:
        bridge: IntentBridge instance to use. Defaults to the module-level singleton.
        transport: "stdio" or "http". Defaults to "http" if port is set, else "stdio".
        port: TCP port for HTTP mode. 0 = dynamic. None = stdio mode.
        host: Hostname for HTTP mode. Defaults to "127.0.0.1".
        broker_ref: Optional SimpBroker reference for routing intents.

    Returns:
        None. The server runs in-place when start() is called; in HTTP mode
        start() returns immediately and the server runs in a background thread.
    """

    def __init__(
        self,
        bridge: Optional[IntentBridge] = None,
        transport: Optional[str] = None,
        port: Optional[int] = None,
        host: str = "127.0.0.1",
        broker_ref: Optional[Any] = None,
    ) -> None:
        self._bridge = bridge or intent_bridge
        self._host = host
        self._port = port
        self._transport = transport or ("http" if port is not None else "stdio")
        self._broker_ref = broker_ref
        self._running = False
        self._server_thread: Optional[threading.Thread] = None
        self._flask_app = None
        self._shutdown_event = threading.Event()

        # Lazy-loaded; initialized in start()
        self._httpd = None

        # Wire broker into bridge if provided
        if self._broker_ref is not None:
            self._bridge.set_broker(self._broker_ref)

    # ------------------------------------------------------------------
    # Transport: stdio
    # ------------------------------------------------------------------

    def _run_stdio_loop(self) -> None:
        """
        Read JSON-RPC requests from stdin and write responses to stdout.

        Each input line must be a JSON object with at least a "method" field.
        Supported methods:
          - tools/list   → {"method": "tools/list"}
          - tools/call   → {"method": "tools/call", "params": {"name": "...", "arguments": {...}}}
          - ping         → {"method": "ping"}
        """
        writer = sys.stdout.buffer
        reader = sys.stdin

        while not self._shutdown_event.is_set():
            try:
                line = reader.readline()
                if not line:
                    # EOF — parent process closed stdin
                    break

                line = line.strip()
                if not line:
                    continue

                request_obj = json.loads(line)
                response = self._dispatch_stdio_request(request_obj)

                if response is not None:
                    response_bytes = json.dumps(response, default=str).encode()
                    if len(response_bytes) > _MAX_RESPONSE_BYTES:
                        response = _truncate(response)
                        response_bytes = json.dumps(response, default=str).encode()
                    writer.write(response_bytes)
                    writer.write(b"\n")
                    writer.flush()

            except json.JSONDecodeError as e:
                logger.warning("stdin: invalid JSON: %s", e)
                err = {"jsonrpc": "2.0", "error": {"code": -32700, "message": f"Parse error: {e}"}}
                try:
                    writer.write(json.dumps(err).encode() + b"\n")
                    writer.flush()
                except BrokenPipeError:
                    break

            except Exception as e:
                logger.exception("stdio loop error: %s", e)
                err = {"jsonrpc": "2.0", "error": {"code": -32603, "message": str(e)}}
                try:
                    writer.write(json.dumps(err).encode() + b"\n")
                    writer.flush()
                except BrokenPipeError:
                    break

    def _dispatch_stdio_request(self, request_obj: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Handle a single stdio JSON-RPC request."""
        method = request_obj.get("method", "")
        params = request_obj.get("params", {})
        req_id = request_obj.get("id")

        mcp_version = "1.0"

        if method == "ping":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {"mcp_version": mcp_version, "pong": True},
            }

        if method == "tools/list":
            tools = self._list_tools()
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {"tools": tools, "mcp_version": mcp_version},
            }

        if method == "tools/call":
            name = params.get("name", "")
            arguments = params.get("arguments", {})
            result = self._call_tool(name, arguments)
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": result,
            }

        # Unknown method
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": -32601, "message": f"Method not found: {method}"},
        }

    # ------------------------------------------------------------------
    # Transport: HTTP (Flask)
    # ------------------------------------------------------------------

    def _make_flask_app(self):
        """Build a Flask app with MCP routes wired up."""
        from flask import Flask, jsonify, request

        app = Flask(__name__)
        app.config["JSON_SORT_KEYS"] = False

        @app.route("/health", methods=["GET"])
        def health():
            return jsonify({
                "status": "ok",
                "transport": self._transport,
                "mcp_version": "1.0",
                "tools_count": len(self._list_tools()),
                "uptime_seconds": time.monotonic(),
            })

        @app.route("/mcp/tools/list", methods=["GET"])
        def list_tools():
            tools = self._list_tools()
            return jsonify({
                "tools": tools,
                "count": len(tools),
                "mcp_version": "1.0",
            })

        @app.route("/mcp/tools/call", methods=["POST"])
        def call_tool():
            body = request.get_json(silent=True) or {}
            tool_name = body.get("name", "")
            arguments = body.get("arguments", {})

            if not tool_name:
                return jsonify({"error": "Missing required field: name"}), 400

            result = self._call_tool(tool_name, arguments)
            return jsonify(result)

        @app.route("/mcp", methods=["GET"])
        def mcp_info():
            """Discovery endpoint — announce server capabilities."""
            return jsonify({
                "name": "SIMP MCP Server",
                "version": "1.0",
                "transport": self._transport,
                "mcp_version": "1.0",
                "endpoints": [
                    "/health",
                    "/mcp/tools/list",
                    "/mcp/tools/call",
                ],
            })

        return app

    def _run_http(self) -> None:
        """Run the Flask HTTP server (called in a background thread)."""
        self._flask_app = self._make_flask_app()
        try:
            self._flask_app.run(
                host=self._host,
                port=self._port or 0,
                debug=False,
                threaded=True,
                use_reloader=False,
            )
        except Exception as e:
            logger.error("HTTP server error: %s", e)

    # ------------------------------------------------------------------
    # Tool dispatch (shared between stdio and HTTP)
    # ------------------------------------------------------------------

    def _list_tools(self) -> List[Dict[str, Any]]:
        """
        Return all registered tools formatted as MCP tool definitions.

        MCP tool definition shape:
        {
            "name": "tool_name",
            "description": "What the tool does",
            "inputSchema": { ... JSON Schema ... }
        }
        """
        tools: List[Dict[str, Any]] = []

        # 1. Tools from the IntentBridge's registered agents
        for tool in self._bridge.list_all_tools():
            tools.append(tool.to_mcp_list_item())

        # 2. Tools from the global native tool registry
        from simp.native_tools import NATIVE_TOOL_REGISTRIES
        for registry_name, registry in NATIVE_TOOL_REGISTRIES.items():
            for item in registry.list_mcp_items():
                if item not in tools:
                    tools.append(item)

        # Deduplicate by name
        seen = set()
        unique = []
        for t in tools:
            name = t.get("name", "")
            if name and name not in seen:
                seen.add(name)
                unique.append(t)

        return unique

    def _call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Dispatch a tool call by name.

        Tries three strategies in order:
        1. Direct handler from IntentBridge tool registry
        2. Native tool registry lookup
        3. IntentBridge.call_as_intent() — route as SIMP intent via broker
        """
        # Strategy 1: Direct handler from the bridge's registries
        for tool in self._bridge.list_all_tools():
            if tool.name == tool_name and tool.handler:
                try:
                    result = tool.handler(**arguments)
                    return {"success": True, "result": result}
                except Exception as e:
                    return {"success": False, "error": str(e)}

        # Strategy 2: Native tool registry
        from simp.native_tools import NATIVE_TOOL_REGISTRIES
        for registry_name, registry in NATIVE_TOOL_REGISTRIES.items():
            tool = registry.get_tool(tool_name)
            if tool and hasattr(tool, "handler") and callable(tool.handler):
                try:
                    result = tool.handler(**arguments)
                    return {"success": True, "result": result}
                except Exception as e:
                    return {"success": False, "error": str(e)}

        # Strategy 3: Route via IntentBridge → broker (for agent intents)
        result = self._bridge.call_as_intent(tool_name, arguments)
        if result.error:
            return {"success": False, "error": result.error}
        return {"success": True, "result": result.result}

    # ------------------------------------------------------------------
    # Public lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """
        Start the MCP server.

        In stdio mode this runs the JSON-RPC loop on stdin/stdout (blocking).
        In HTTP mode this starts a background thread running a Flask app.

        Returns:
            None.
        """
        if self._running:
            logger.warning("MCPServer already started")
            return

        self._running = True
        self._shutdown_event.clear()

        if self._transport == "stdio":
            logger.info("Starting MCPServer in stdio mode")
            self._run_stdio_loop()
        elif self._transport == "http":
            logger.info("Starting MCPServer in HTTP mode on %s:%s", self._host, self._port or "dynamic")
            self._server_thread = threading.Thread(target=self._run_http, daemon=True)
            self._server_thread.start()
        else:
            raise ValueError(f"Unknown transport: {self._transport!r}")

    def stop(self) -> None:
        """
        Stop the MCP server.

        In stdio mode this sets a shutdown flag; the loop exits on next stdin read.
        In HTTP mode this stops the Flask server.
        """
        if not self._running:
            return

        logger.info("Stopping MCPServer (transport=%s)", self._transport)
        self._shutdown_event.set()
        self._running = False

        # If running HTTP, tear down the Flask app by stopping the werkzeug server
        if self._transport == "http" and self._flask_app:
            # Signal the Flask app to shut down; it will exit on the next request
            # The daemon thread will be collected when the process exits
            pass

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def transport(self) -> str:
        return self._transport

    def describe(self) -> Dict[str, Any]:
        """Return server metadata."""
        return {
            "transport": self._transport,
            "host": self._host,
            "port": self._port,
            "running": self._running,
            "mcp_version": "1.0",
        }


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

def create_server(**kwargs) -> MCPServer:
    """Factory to create and configure an MCPServer."""
    return MCPServer(**kwargs)


# ---------------------------------------------------------------------------
# __all__
# ---------------------------------------------------------------------------

__all__ = [
    "MCPServer",
    "create_server",
]
