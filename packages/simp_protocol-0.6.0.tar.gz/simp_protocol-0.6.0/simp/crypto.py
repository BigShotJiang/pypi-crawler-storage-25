"""
SIMP Cryptographic utilities.

Uses PyNaCl (libsodium) for Ed25519 signing — cryptography's Ed25519 wrapper
is broken on OpenSSL 4.0.0 (Apple Silicon / dev builds).
"""
import base64
import hashlib
import hmac
import json
import logging

import nacl.bindings
import nacl.exceptions
import nacl.signing

logger = logging.getLogger("SIMP.Crypto")


class SimpCrypto:
    """Cryptographic utilities for SIMP using Ed25519 via PyNaCl."""

    @staticmethod
    def generate_keypair() -> tuple[bytes, bytes]:
        """Generate Ed25519 keypair. Returns (private_key_bytes, public_key_bytes).

        Private key is 32 raw seed bytes (libsodium-compatible).
        Public key is 32 raw bytes matching IETF RFC 8032.
        """
        sk = nacl.signing.SigningKey.generate()
        return bytes(sk), bytes(sk.verify_key)

    @staticmethod
    def seed_to_keypair(seed: bytes) -> tuple[bytes, bytes]:
        """Derive Ed25519 keypair from a 32-byte seed.

        Useful for deterministic key generation.
        """
        if len(seed) != 32:
            raise ValueError("Seed must be exactly 32 bytes")
        sk = nacl.signing.SigningKey(seed)
        return bytes(sk), bytes(sk.verify_key)

    @staticmethod
    def sign_intent(intent_dict: dict, private_key_bytes: bytes) -> str:
        """Sign an intent dict using Ed25519. Returns base64-encoded signature.

        Signs the canonical JSON bytes directly — NOT a hash of the content.
        This avoids the double-hashing vulnerability (padding oracle attack risk).
        """
        sk = nacl.signing.SigningKey(private_key_bytes)
        canonical = json.dumps(intent_dict, sort_keys=True, separators=(',', ':')).encode()
        signed = sk.sign(canonical)
        return base64.b64encode(signed.signature).decode()

    @staticmethod
    def sign_intent_v2(intent_dict: dict, private_key_bytes: bytes) -> str:
        """Sign an intent dict using Ed25519. Returns base64-encoded signature.

        .. deprecated::
            Identical to :meth:`sign_intent` — exists for backward compatibility only.
            Will be removed in a future release.
        """
        return SimpCrypto.sign_intent(intent_dict, private_key_bytes)

    @staticmethod
    def verify_signature(intent_dict: dict, signature: str, public_key_bytes: bytes) -> bool:
        """Verify an Ed25519 signature over an intent dict.

        Verifies against canonical JSON bytes — matches sign_intent behavior.
        """
        try:
            vk = nacl.signing.VerifyKey(public_key_bytes)
            canonical = json.dumps(intent_dict, sort_keys=True, separators=(',', ':')).encode()
            vk.verify(canonical, base64.b64decode(signature))
            return True
        except nacl.exceptions.BadSignatureError:
            return False
        except Exception:
            logger.exception("Unexpected verification error")
            return False

    @staticmethod
    def compute_hmac(data: bytes, key: bytes) -> str:
        """Compute HMAC-SHA256."""
        return base64.b64encode(hmac.new(key, data, hashlib.sha256).digest()).decode()

    @staticmethod
    def derive_key(master: bytes, context: str) -> bytes:
        """Derive a sub-key from master using HKDF-lite."""
        info = context.encode() + b'\x00'
        return hashlib.sha256(master + info).digest()
