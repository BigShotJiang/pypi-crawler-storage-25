"""
Broker Raft — Raft-Ledger integration for SIMP broker.

Wraps a Ledger instance with Raft consensus so all token writes go through
the Raft log before being applied to the local state machine. Reads are served
locally from the replica without Raft overhead.

RAFT_ENABLED=False → single-node mode, no Raft overhead.
RAFT_ENABLED=True  → Raft consensus, ledger writes replicated to followers.
"""
import logging
import threading
import time
from typing import Any, Dict, List, Optional

import requests

from simp.raft_engine import RaftNode, RaftEntry
from simp.tokens.ledger import Ledger

logger = logging.getLogger("SimpMesh.BrokerRaft")


class LeaderRelinquished(Exception):
    """Raised when a read-index check reveals this broker is no longer leader."""
    pass


class RaftLedgerBroker:
    """Ledger wrapped with Raft replication."""

    def __init__(self, ledger: Ledger, broker_id: str):
        self._ledger = ledger
        self._broker_id = broker_id
        self._raft: Optional[RaftNode] = None
        _cfg = __import__("simp.config", fromlist=["config"]).config
        self._raft_enabled = getattr(_cfg, "RAFT_ENABLED", False)

        if self._raft_enabled:
            cfg = __import__("simp.config", fromlist=["config"]).config
            self._raft = RaftNode(
                broker_id=broker_id,
                leader_address=getattr(cfg, "RAFT_LEADER_ADDRESS", "http://127.0.0.1:5555"),
                bind_port=getattr(cfg, "RAFT_BIND_PORT", 5556),
                election_timeout_ms=getattr(cfg, "RAFT_ELECTION_TIMEOUT_MS", 150),
                heartbeat_interval_ms=getattr(cfg, "RAFT_HEARTBEAT_INTERVAL_MS", 50),
                batch_threshold=getattr(cfg, "RAFT_BATCH_THRESHOLD", 50),
            )
            self._raft.on_commit_callback(self._apply_to_ledger)
            self._raft.start()
            logger.info("RaftLedgerBroker started with Raft (broker_id=%s)", broker_id)
        else:
            logger.info("RaftLedgerBroker started in single-node mode (RAFT_ENABLED=False)")

    def _apply_to_ledger(self, entry_data: Dict[str, Any]) -> None:
        """Apply a committed Raft entry to the local ledger state machine."""
        op = entry_data.get("op")
        dispatch = {
            "account_update_balance": lambda e: self._ledger.account_update_balance(
                e["agent_id"], e["delta"], conn=None),
            "account_create": lambda e: self._ledger.account_create(
                e["agent_id"], e["pubkey_b64"], conn=None),
            "txn_write": lambda e: self._ledger.txn_write(e["txn"], conn=None),
            "escrow_open": lambda e: self._ledger.escrow_open(
                e["requester"], e["responder"], e["dispute_bond"], e.get("intent_ref"), conn=None),
            "escrow_release": lambda e: self._ledger.escrow_release(
                e["escrow_id"], e["winner"], e["loser"], conn=None),
            "escrow_execute": lambda e: self._ledger.escrow_execute(e["escrow_id"], conn=None),
            "escrow_dispute": lambda e: self._ledger.escrow_dispute(
                e["escrow_id"], e["dispute_winner"], conn=None),
            "escrow_cancel": lambda e: self._ledger.escrow_cancel(e["escrow_id"], conn=None),
            "bundle_create": lambda e: self._ledger.bundle_create(
                e["intent_type"], e["participants"], conn=None),
            "bundle_fund": lambda e: self._ledger.bundle_fund(
                e["bundle_id"], e["agent_id"], e["stake_amount"], conn=None),
            "bundle_execute": lambda e: self._ledger.bundle_execute(e["bundle_id"], conn=None),
            "bundle_dispute": lambda e: self._ledger.bundle_dispute(
                e["bundle_id"], e["slashed_agent"], conn=None),
            "stake_lock": lambda e: self._ledger.stake_lock(
                e["agent_id"], e["amount"], conn=None),
            "stake_release": lambda e: self._ledger.stake_release(
                e["agent_id"], e["amount"], conn=None),
            "trust_adjust": lambda e: self._ledger.trust_adjust(
                e["agent_id"], e["delta"], e.get("reason", "raft"), conn=None),
            "inflation_distribute": lambda e: self._ledger.inflation_distribute(conn=None),
            "sponsor_onboard": lambda e: self._ledger.sponsor_onboard(
                e["sponsor_id"], e["sponsored_agent"], e.get("sponsor_bond", 500_000),
                e.get("delegation_fee_bps", 100), conn=None),
            "sponsor_charge_delegation_fee": lambda e: self._ledger.sponsor_charge_delegation_fee(
                e["sponsor_id"], e["sponsored_agent"], e["fee_amount"], conn=None),
            "sponsor_release": lambda e: self._ledger.sponsor_release(
                e["sponsor_id"], e["sponsored_agent"], conn=None),
            "operator_faucet": lambda e: self._ledger.operator_faucet(
                e["recipient"], e["amount"], e.get("reason", ""), conn=None),
            "intent_pay_fee": lambda e: self._ledger.intent_pay_fee(
                e.get("intent_type", ""), e["from_agent"], e["amount"],
                e.get("load_factor", 1.0), e.get("intent_ref"), conn=None),
            "agent_key_register": lambda e: self._ledger.agent_key_register(
                e["agent_id"], e["pubkey_b64"], e.get("purpose", "signing"),
                e.get("expires_at"), conn=None),
            "agent_key_revoke": lambda e: self._ledger.agent_key_revoke(
                e["agent_id"], e.get("revoked_reason", ""), conn=None),
            "agent_key_rotate": lambda e: self._ledger.agent_key_rotate(
                e["agent_id"], e["new_pubkey_b64"], e.get("revoke_reason", "raft-rotate"), conn=None),
        }
        handler = dispatch.get(op)
        if handler:
            try:
                handler(entry_data)
                logger.debug("Applied Raft entry: op=%s", op)
            except Exception as exc:
                logger.error("Failed to apply op %s: %s", op, exc)
        else:
            logger.warning("Unknown Raft op: %s", op)

    def write(self, op: str, params: Dict[str, Any]) -> bool:
        """Write to ledger via Raft (if enabled) or direct (if single-node)."""
        entry = {"op": op, **params}
        if self._raft_enabled and self._raft:
            success = self._raft.append_entries([entry])
            if success:
                committed = self._raft.wait_for_commit(timeout_ms=5000)
                return committed
            return False
        else:
            self._apply_to_ledger(entry)
            return True

    def read_index(self, timeout_ms: int = 5000) -> bool:
        """Confirm leader status before serving a consistent read."""
        if self._raft_enabled and self._raft:
            return self._raft.read_index(timeout_ms)
        return True  # Single-node mode: always consistent

    def read_ledger(self, linearizable: bool = False):
        """Return the underlying ledger for read operations.

        Args:
            linearizable: If True, verify this broker is still the leader before
                          serving the read. Raises LeaderRelinquished if leadership
                          is uncertain.
        """
        if linearizable:
            if self._raft_enabled and self._raft:
                if not self._raft.read_index():
                    raise LeaderRelinquished(
                        f"Broker {self._broker_id} is no longer leader; "
                        "re-read by forwarding to the current leader"
                    )
            elif not self.is_leader():
                raise LeaderRelinquished(
                    f"Broker {self._broker_id} is not the leader"
                )
        return self._ledger

    def is_leader(self) -> bool:
        return self._raft.is_leader() if self._raft else True

    def raft_status(self) -> Dict[str, Any]:
        """Return Raft cluster status."""
        if not self._raft:
            return {"raft_enabled": False, "mode": "single-node"}
        return {
            "raft_enabled": True,
            "broker_id": self._broker_id,
            "is_leader": self._raft.is_leader(),
            "leader_id": self._raft.leader_id(),
            "last_commit_index": self._raft.last_commit_index(),
            "term": self._raft.get_term(),
        }

    def handle_raft_rpc(self, rpc: Dict[str, Any]) -> Dict[str, Any]:
        """Handle incoming Raft RPC (AppendEntries, RequestVote, snapshot requests)."""
        method = rpc.get("method")
        if method == "append_entries":
            return self._handle_append_entries(rpc.get("params", {}))
        elif method == "request_vote":
            return self._handle_request_vote(rpc.get("params", {}))
        elif method == "pre_vote":
            return self._handle_pre_vote(rpc.get("params", {}))
        elif method == "snapshot_request":
            return self._handle_snapshot_request()
        elif method == "log_request":
            return self._handle_log_request(rpc.get("params", {}))
        return {"error": "unknown method"}

    def _handle_snapshot_request(self) -> Dict[str, Any]:
        """Return full state snapshot for log compaction and new broker catch-up."""
        import json
        ledger = self.read_ledger()
        snapshot_index = self._raft.last_commit_index() if self._raft else 0
        snapshot_term = self._raft.get_term() if self._raft else 0

        # Serialize all ledger tables
        conn = getattr(ledger, "_conn", None) or (getattr(ledger, "_write", None) and ledger._write())
        if conn is None:
            logger.error("No ledger connection available for snapshot")
            return {"error": "no ledger connection"}

        cursor = conn.cursor()

        accounts = cursor.execute("SELECT * FROM accounts").fetchall()
        transactions = cursor.execute("SELECT * FROM transactions").fetchall()
        escrow_records = cursor.execute("SELECT * FROM escrow_records").fetchall()
        intent_bundles = cursor.execute("SELECT * FROM intent_bundles").fetchall()
        agent_registry = cursor.execute("SELECT * FROM agent_registry").fetchall()
        trust_history = cursor.execute("SELECT * FROM trust_history").fetchall()

        snapshot = {
            "accounts": [dict(row) for row in accounts],
            "transactions": [dict(row) for row in transactions],
            "escrow_records": [dict(row) for row in escrow_records],
            "intent_bundles": [dict(row) for row in intent_bundles],
            "agent_registry": [dict(row) for row in agent_registry],
            "trust_history": [dict(row) for row in trust_history],
            "last_index": snapshot_index,
            "last_term": snapshot_term,
            "snapshot_index": snapshot_index,
            "version": int(time.time()),
        }
        return snapshot

    def _handle_log_request(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Return Raft log entries after given index."""
        after = params.get("after_index", 0)
        entries = []
        if self._raft:
            local_entries = self._raft.get_log_entries_after(after)
            if local_entries:
                entries = [e.data if hasattr(e, "data") else e for e in local_entries]
        return {"entries": entries}

    def _handle_append_entries(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle AppendEntries RPC from leader."""
        term = params.get("term", 0)
        prev_log_index = params.get("prev_log_index", 0)
        prev_log_term = params.get("prev_log_term", 0)
        entries = params.get("entries", [])
        leader_commit = params.get("leader_commit", 0)

        if self._raft is None:
            return {"success": False, "term": 0, "match_index": 0}

        current_term = self._raft.get_term()
        if term < current_term:
            return {"success": False, "term": current_term, "match_index": 0}

        match_index = prev_log_index
        for entry_dict in entries:
            idx = entry_dict.get("index", 0)
            entry_term = entry_dict.get("term", 0)
            data = entry_dict.get("data", {})
            self._raft.append_entries_local(idx, entry_term, data)
            match_index = idx

        if leader_commit > self._raft.last_commit_index():
            self._raft.advance_commit_index(leader_commit)

        return {"success": True, "term": current_term, "match_index": match_index}

    def _handle_request_vote(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle RequestVote RPC from candidate."""
        candidate_id = params.get("candidate_id", "")
        last_log_index = params.get("last_log_index", 0)
        last_log_term = params.get("last_log_term", 0)

        if self._raft is None:
            return {"vote_granted": False, "term": 0}

        current_term = self._raft.get_term()
        result = self._raft.request_vote(candidate_id, last_log_index, last_log_term)
        return {"vote_granted": result.vote_granted, "term": result.current_term}

    def _handle_pre_vote(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle PreVote RPC from candidate — voter doesn't update term or voting record."""
        candidate_id = params.get("candidate_id", "")
        last_log_index = params.get("last_log_index", 0)
        last_log_term = params.get("last_log_term", 0)

        if self._raft is None:
            return {"vote_granted": False, "term": 0}

        current_term = self._raft.get_term()
        result = self._raft.request_pre_vote(candidate_id, last_log_index, last_log_term)
        return {"vote_granted": result.vote_granted, "term": result.current_term}

    def get_raft_snapshot(self) -> Dict[str, Any]:
        """HTTP endpoint handler: serve full state snapshot."""
        return self._handle_snapshot_request()

    def get_raft_log(self, after_index: int = 0) -> Dict[str, Any]:
        """HTTP endpoint handler: serve log entries after index."""
        return self._handle_log_request({"after_index": after_index})

    def decommission_broker(self, broker_id: str) -> bool:
        """Remove a broker from the cluster membership.

        Removes the broker from RaftNode known_brokers and followers,
        and from PeerRegistry if available. Idempotent.

        Args:
            broker_id: The broker ID (address) to decommission.

        Returns:
            True if the broker was removed, False otherwise.
        """
        if not self._raft:
            logger.warning("decommission_broker called but Raft is not enabled")
            return False

        self._raft.remove_broker(broker_id)

        # Also remove from PeerRegistry if present
        try:
            from simp.federation.peer_registry import PeerRegistry
            registry = PeerRegistry()
            registry._peers = [p for p in registry._peers if p.get("broker_id") != broker_id]
            logger.info("Removed broker %s from PeerRegistry", broker_id)
        except Exception as e:
            logger.debug("PeerRegistry cleanup skipped: %s", e)

        logger.info("Broker %s decommissioned from cluster membership", broker_id)
        return True