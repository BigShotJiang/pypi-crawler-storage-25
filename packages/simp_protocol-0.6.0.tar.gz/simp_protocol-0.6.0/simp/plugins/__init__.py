"""
SIMP Plugin System — Optional modules that hook into the broker lifecycle.

Based on ElizaOS plugin pattern (Actions, Providers, Services, Evaluators).
Each plugin can hook into:
  - on_load:      Called when plugin is loaded
  - on_intent:    Called when an intent arrives (can modify/reject)
  - on_settle:    Called when a settlement completes
  - on_shutdown:  Called when broker stops
  - on_tick:      Called on each broker poll cycle (for scheduled tasks)

Usage:
    from simp.plugins import PluginABC, plugin_registry
    
    class MyPlugin(PluginABC):
        def on_load(self, broker):
            self.broker = broker
            
        async def on_intent(self, intent):
            # Log all intents
            logger.info(f"Intent: {intent.intent_type}")
            return intent  # Pass through

    plugin_registry.register(MyPlugin())
"""

import logging
from typing import Dict, List, Optional, Any, Callable

logger = logging.getLogger(__name__)


class PluginABC:
    """Base class for all SIMP plugins."""

    name: str = ""
    version: str = "0.1.0"
    description: str = ""

    def on_load(self, broker: Any) -> None:
        """Called when the plugin is loaded."""
        pass

    async def on_intent(self, intent: Any) -> Any:
        """Called when an intent arrives. Return modified intent or None to reject."""
        return intent

    async def on_response(self, response: Any) -> Any:
        """Called when a response is sent back. Return modified response or None to suppress."""
        return response

    async def on_settle(self, settlement: Any) -> None:
        """Called when a settlement completes."""
        pass

    def on_shutdown(self) -> None:
        """Called when the broker shuts down."""
        pass

    async def on_tick(self) -> None:
        """Called on each broker tick (for scheduled tasks, health checks, etc.)."""
        pass


class PluginRegistry:
    """Registry of loaded plugins."""

    def __init__(self):
        self._plugins: List[PluginABC] = []
        self._intent_hooks: List[Callable] = []
        self._response_hooks: List[Callable] = []
        self._tick_hooks: List[Callable] = []

    def register(self, plugin: PluginABC) -> None:
        """Register a plugin."""
        self._plugins.append(plugin)
        if hasattr(plugin.on_intent, "__call__"):
            self._intent_hooks.append(plugin.on_intent)
        if hasattr(plugin.on_response, "__call__"):
            self._response_hooks.append(plugin.on_response)
        if hasattr(plugin.on_tick, "__call__"):
            self._tick_hooks.append(plugin.on_tick)
        logger.info(f"Plugin registered: {plugin.name} v{plugin.version}")

    def load_all(self, broker: Any) -> None:
        """Call on_load for all plugins."""
        for plugin in self._plugins:
            try:
                plugin.on_load(broker)
                logger.debug(f"Plugin loaded: {plugin.name}")
            except Exception as e:
                logger.error(f"Plugin {plugin.name} on_load failed: {e}")

    async def process_intent(self, intent: Any) -> Optional[Any]:
        """Run intent through all plugin hooks."""
        for hook in self._intent_hooks:
            try:
                result = await hook(intent)
                if result is None:
                    return None  # Plugin rejected the intent
                intent = result
            except Exception as e:
                logger.error(f"Intent hook failed: {e}")
        return intent

    async def process_response(self, response: Any) -> Optional[Any]:
        """Run response through all plugin hooks."""
        for hook in self._response_hooks:
            try:
                result = await hook(response)
                if result is None:
                    return None
                response = result
            except Exception as e:
                logger.error(f"Response hook failed: {e}")
        return response

    async def tick(self) -> None:
        """Call on_tick for all plugins."""
        for hook in self._tick_hooks:
            try:
                await hook()
            except Exception as e:
                logger.error(f"Tick hook failed: {e}")

    def shutdown_all(self) -> None:
        """Shutdown all plugins."""
        for plugin in self._plugins:
            try:
                plugin.on_shutdown()
            except Exception as e:
                logger.error(f"Plugin {plugin.name} shutdown failed: {e}")

    @property
    def plugins(self) -> List[PluginABC]:
        return list(self._plugins)


# Singleton
plugin_registry = PluginRegistry()
