"""Tests for `OpCliSecretsStore` (U4).

All tests monkeypatch `asyncio.create_subprocess_exec` — no real `op`
binary is ever invoked, so the suite is portable across CI runners and
dev laptops without a 1Password install.
"""

from __future__ import annotations

import asyncio
from typing import Any

import pytest
from zeno.exceptions import (
    ConfigurationError,
    SecretNotFoundError,
    SecretsBackendError,
)
from zeno.protocols.secrets import SecretsStore
from zeno.secrets_1password import OpCliSecretsStore

# ---------------------------------------------------------------------------
# Fake subprocess
# ---------------------------------------------------------------------------


class _FakeProc:
    """Fake `asyncio.subprocess.Process`-like object for monkeypatching.

    Returns canned `(stdout, stderr)` from `communicate()`, optionally
    delays to simulate a hang. `returncode` is set after `communicate`
    to mimic the real Process lifecycle.
    """

    def __init__(
        self,
        *,
        stdout: bytes = b"",
        stderr: bytes = b"",
        returncode: int = 0,
        delay: float = 0.0,
    ) -> None:
        self._stdout = stdout
        self._stderr = stderr
        self._returncode_after = returncode
        self._delay = delay
        self.returncode: int | None = None
        self.kill_calls = 0
        self.wait_calls = 0

    async def communicate(self) -> tuple[bytes, bytes]:
        if self._delay > 0:
            await asyncio.sleep(self._delay)
        self.returncode = self._returncode_after
        return self._stdout, self._stderr

    def kill(self) -> None:
        self.kill_calls += 1
        self.returncode = -9

    async def wait(self) -> int:
        self.wait_calls += 1
        if self.returncode is None:
            self.returncode = -9
        return self.returncode


def _make_exec_stub(
    proc_factory: Any,
    *,
    calls: list[dict[str, Any]] | None = None,
    raise_error: BaseException | None = None,
) -> Any:
    async def _stub(*args: Any, **kwargs: Any) -> Any:
        if calls is not None:
            calls.append({"args": args, "env": kwargs.get("env")})
        if raise_error is not None:
            raise raise_error
        return proc_factory()

    return _stub


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


async def test_happy_path_returns_stripped_stdout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(
            lambda: _FakeProc(stdout=b"sk-abc123\n", returncode=0),
            calls=calls,
        ),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore(references={"OPENAI_API_KEY": "op://V/openai/credential"})
    value = await store.get("OPENAI_API_KEY")

    assert value == "sk-abc123"
    assert len(calls) == 1
    assert calls[0]["args"][:3] == ("op", "read", "op://V/openai/credential")


async def test_literal_op_url_bypasses_references_map(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(
            lambda: _FakeProc(stdout=b"value\n"),
            calls=calls,
        ),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore()  # references=None
    value = await store.get("op://V/foo/bar")

    assert value == "value"
    assert calls[0]["args"][:3] == ("op", "read", "op://V/foo/bar")


async def test_missing_binary_raises_configuration_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(lambda: None, raise_error=FileNotFoundError("op")),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore(references={"K": "op://V/i/f"})
    with pytest.raises(ConfigurationError) as excinfo:
        await store.get("K")
    assert "1Password CLI" in str(excinfo.value)
    assert "brew install 1password-cli" in str(excinfo.value)


async def test_missing_token_raises_configuration_error_before_subprocess(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    exec_called = False

    async def _should_not_run(*_args: Any, **_kwargs: Any) -> Any:
        nonlocal exec_called
        exec_called = True
        raise AssertionError("subprocess must not run when token is missing")

    monkeypatch.setattr(asyncio, "create_subprocess_exec", _should_not_run)
    monkeypatch.delenv("OP_SERVICE_ACCOUNT_TOKEN", raising=False)

    store = OpCliSecretsStore(references={"K": "op://V/i/f"})
    with pytest.raises(ConfigurationError) as excinfo:
        await store.get("K")
    assert "OP_SERVICE_ACCOUNT_TOKEN" in str(excinfo.value)
    assert exec_called is False


async def test_explicit_token_overrides_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(lambda: _FakeProc(stdout=b"v\n"), calls=calls),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "from-env")

    store = OpCliSecretsStore(references={"K": "op://V/i/f"}, token="ops_explicit")
    await store.get("K")

    env = calls[0]["env"]
    assert env is not None
    assert env["OP_SERVICE_ACCOUNT_TOKEN"] == "ops_explicit"
    # And the explicit-env dict must not forward unrelated parent env.
    assert "HOME" not in env


async def test_nonzero_exit_item_not_found_raises_secret_not_found(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(
            lambda: _FakeProc(
                stderr=b'[ERROR] "op://V/i/f" isn\'t an item in any vault',
                returncode=1,
            )
        ),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore(references={"K": "op://V/i/f"})
    with pytest.raises(SecretNotFoundError):
        await store.get("K")


async def test_nonzero_exit_auth_failure_raises_backend_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(
            lambda: _FakeProc(
                stderr=b"[ERROR] authentication required: 401 Unauthorized",
                returncode=1,
            )
        ),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore(references={"K": "op://V/i/f"})
    with pytest.raises(SecretsBackendError) as excinfo:
        await store.get("K")
    assert "401" in str(excinfo.value) or "auth" in str(excinfo.value).lower()


async def test_timeout_kills_and_reaps_and_raises_backend_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeProc(stdout=b"late\n", delay=1.0)
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(lambda: fake),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore(references={"K": "op://V/i/f"}, timeout=0.05)
    with pytest.raises(SecretsBackendError) as excinfo:
        await store.get("K")
    assert "timeout" in str(excinfo.value).lower()
    assert fake.kill_calls >= 1
    assert fake.wait_calls >= 1


async def test_cache_hit_does_not_shell_twice(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(
            lambda: _FakeProc(stdout=b"v\n"),
            calls=calls,
        ),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore(references={"K": "op://V/i/f"}, cache_ttl=60.0)
    await store.get("K")
    await store.get("K")

    assert len(calls) == 1


async def test_cache_expiry_reshells(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(
            lambda: _FakeProc(stdout=b"v\n"),
            calls=calls,
        ),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    # Freeze `time.monotonic` so expiry is deterministic.
    now = [0.0]

    def _fake_monotonic() -> float:
        return now[0]

    monkeypatch.setattr(
        "zeno.secrets_1password.op_cli.time.monotonic",
        _fake_monotonic,
    )

    store = OpCliSecretsStore(references={"K": "op://V/i/f"}, cache_ttl=0.01)
    await store.get("K")
    now[0] += 1.0  # push well past cache_ttl
    await store.get("K")

    assert len(calls) == 2


async def test_cache_disabled_always_reshells(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []
    monkeypatch.setattr(
        asyncio,
        "create_subprocess_exec",
        _make_exec_stub(
            lambda: _FakeProc(stdout=b"v\n"),
            calls=calls,
        ),
    )
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore(references={"K": "op://V/i/f"}, cache_ttl=None)
    await store.get("K")
    await store.get("K")

    assert len(calls) == 2


async def test_reference_miss_raises_without_invoking_subprocess(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    exec_called = False

    async def _should_not_run(*_args: Any, **_kwargs: Any) -> Any:
        nonlocal exec_called
        exec_called = True
        raise AssertionError("subprocess must not run on reference miss")

    monkeypatch.setattr(asyncio, "create_subprocess_exec", _should_not_run)
    monkeypatch.setenv("OP_SERVICE_ACCOUNT_TOKEN", "ops_test")

    store = OpCliSecretsStore(references={"HAVE": "op://V/a/b"})
    with pytest.raises(SecretNotFoundError) as excinfo:
        await store.get("UNKNOWN")
    assert excinfo.value.name == "UNKNOWN"
    assert exec_called is False


def test_matches_secrets_store_protocol() -> None:
    assert isinstance(OpCliSecretsStore(), SecretsStore)
