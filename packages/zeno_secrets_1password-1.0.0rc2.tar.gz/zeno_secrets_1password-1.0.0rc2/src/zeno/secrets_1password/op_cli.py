"""`OpCliSecretsStore` — shells out to `op read` for each secret.

Implements the `SecretsStore` protocol (`async get(name) -> str`).
Never writes secrets anywhere except its own in-process cache; the
subprocess env contains only `PATH` and `OP_SERVICE_ACCOUNT_TOKEN`, so
unrelated parent env is not forwarded to `op`.

Errors map as follows:
  - `op` binary missing on PATH         -> `ConfigurationError`
  - `OP_SERVICE_ACCOUNT_TOKEN` missing  -> `ConfigurationError`
  - `op read` exit 1 + "not found"      -> `SecretNotFoundError`
  - `op read` exit 1 + anything else    -> `SecretsBackendError`
  - subprocess timeout                  -> `SecretsBackendError("timeout: ...")`

The reference indirection (`references={"OPENAI_API_KEY": "op://V/.../f"}`)
lets callers hand logical secret names to tools without leaking 1Password
path structure through the codebase. A caller can also skip the map
entirely by passing a literal `op://...` URL directly to `get()`.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import time
from typing import TYPE_CHECKING

from zeno.exceptions import (
    ConfigurationError,
    SecretNotFoundError,
    SecretsBackendError,
)

if TYPE_CHECKING:
    from collections.abc import Mapping


_NOT_FOUND_MARKERS = (
    "isn't an item",
    "no such",
    "item not found",
    "couldn't find",
)


class OpCliSecretsStore:
    """`SecretsStore` that resolves each `get()` by shelling to `op read`.

    Args:
        references: Optional `{logical_name: "op://..."}` map. When a
            caller passes a logical name that is not itself an `op://`
            URL, it is looked up here; absent entries raise
            `SecretNotFoundError` without touching the CLI.
        token: Service-account token. Overrides
            `OP_SERVICE_ACCOUNT_TOKEN` env var when given. If both are
            unset, `get()` raises `ConfigurationError`.
        cache_ttl: Seconds to cache a resolved secret in-process. `None`
            disables caching. Default 60.
        timeout: Seconds to wait for `op read` before killing the
            subprocess and raising `SecretsBackendError`.
        op_path: Binary name / full path for the CLI. Default `"op"`.
    """

    def __init__(
        self,
        *,
        references: Mapping[str, str] | None = None,
        token: str | None = None,
        cache_ttl: float | None = 60.0,
        timeout: float = 5.0,
        op_path: str = "op",
    ) -> None:
        self._references: dict[str, str] = dict(references) if references else {}
        self._token = token
        self._cache_ttl = cache_ttl
        self._timeout = timeout
        self._op_path = op_path
        self._cache: dict[str, tuple[str, float]] = {}

    async def get(self, name: str) -> str:
        cached = self._cache_lookup(name)
        if cached is not None:
            return cached
        ref = self._resolve_ref(name)
        value = await self._run_op(ref)
        self._cache_store(name, value)
        return value

    def _resolve_ref(self, name: str) -> str:
        if name.startswith("op://"):
            return name
        try:
            return self._references[name]
        except KeyError as exc:
            raise SecretNotFoundError(name) from exc

    def _cache_lookup(self, name: str) -> str | None:
        if self._cache_ttl is None:
            return None
        hit = self._cache.get(name)
        if hit is None:
            return None
        value, expires_at = hit
        if time.monotonic() >= expires_at:
            del self._cache[name]
            return None
        return value

    def _cache_store(self, name: str, value: str) -> None:
        if self._cache_ttl is None:
            return
        self._cache[name] = (value, time.monotonic() + self._cache_ttl)

    async def _run_op(self, ref: str) -> str:
        token = self._token or os.environ.get("OP_SERVICE_ACCOUNT_TOKEN")
        if not token:
            raise ConfigurationError(
                "OP_SERVICE_ACCOUNT_TOKEN is not set; either pass token=... to "
                "OpCliSecretsStore(...) or export the env var before starting "
                "the app. See 1Password service-account docs."
            )

        env = {"PATH": os.environ.get("PATH", ""), "OP_SERVICE_ACCOUNT_TOKEN": token}

        try:
            proc = await asyncio.create_subprocess_exec(
                self._op_path,
                "read",
                ref,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
        except FileNotFoundError as exc:
            raise ConfigurationError(
                f"1Password CLI ({self._op_path!r}) not found on PATH. "
                "Install via `brew install 1password-cli` (macOS) or see "
                "https://developer.1password.com/docs/cli/get-started/."
            ) from exc

        try:
            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(), timeout=self._timeout
            )
        except TimeoutError as exc:
            with contextlib.suppress(ProcessLookupError):
                proc.kill()
            with contextlib.suppress(Exception):
                await proc.wait()
            raise SecretsBackendError(
                f"timeout: `op read {ref}` did not complete within {self._timeout:.2f}s"
            ) from exc

        if proc.returncode != 0:
            stderr_text = stderr_bytes.decode("utf-8", errors="replace").strip()
            lowered = stderr_text.lower()
            if any(marker in lowered for marker in _NOT_FOUND_MARKERS):
                raise SecretNotFoundError(ref)
            raise SecretsBackendError(f"`op read {ref}` exited {proc.returncode}: {stderr_text}")

        return stdout_bytes.decode("utf-8").rstrip("\n")
