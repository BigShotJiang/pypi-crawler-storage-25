"""`zeno-secrets-1password` — 1Password-backed `SecretsStore` for Zeno.

Public surface:

- `OpCliSecretsStore` — reads secrets via the 1Password CLI (`op read`).
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from zeno.secrets_1password.op_cli import OpCliSecretsStore

try:
    __version__ = version("zeno-secrets-1password")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

__all__ = ["OpCliSecretsStore", "__version__"]
