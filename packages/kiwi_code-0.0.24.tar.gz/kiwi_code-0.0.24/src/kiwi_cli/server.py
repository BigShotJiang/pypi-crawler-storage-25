"""Server / environment resolution helpers.

Kiwi Code accepts a ``--server`` argument in both the TUI (``kiwi``) and
non-interactive CLI (``kiwicli``).

The value can be:
- a preset name: ``app`` | ``dev`` | ``local``
- a full URL (http/https/ws/wss)
- a bare hostname (assumed https)

This module intentionally contains *no persistence*. It is runtime-only.
"""

from __future__ import annotations


SERVER_PRESETS: dict[str, dict[str, str]] = {
    "app": {"ws": "wss://api.meetkiwi.ai", "http": "https://api.meetkiwi.ai"},
    "dev": {"ws": "wss://dev.api.myautobots.com", "http": "https://dev.api.myautobots.com"},
    "local": {"ws": "ws://localhost:8000", "http": "http://localhost:8000"},
}


def server_from_backend_url(backend_url: str) -> str:
    """Pick a runtime ``--server`` value from an HTTP backend_url."""
    url = backend_url.rstrip("/")
    for preset_name, preset in SERVER_PRESETS.items():
        if preset.get("http") == url:
            return preset_name
    return url


def http_url_from_server(server: str) -> str:
    """Resolve runtime ``--server`` string to the HTTP base URL."""
    preset = SERVER_PRESETS.get(server)
    if preset:
        return preset["http"]

    url = server.rstrip("/")
    if url.startswith("https://"):
        return url
    if url.startswith("http://"):
        return url
    if url.startswith("wss://"):
        return url.replace("wss://", "https://", 1)
    if url.startswith("ws://"):
        return url.replace("ws://", "http://", 1)
    # bare host
    return f"https://{url}"
