"""Helpers for starting and inspecting the local Kiwi runtime (CLI agent).

Constraints / design:
- We do not modify the runtime implementation (``kiwi_runtime``). We only spawn
  it as an external process.
- Runtime identity is per *run id* (action_result_id). One runtime process is
  associated with one run id.
- When a run id is not yet known (fresh conversation), we start a *pending*
  runtime, then bind it to the run id once it is created.

State directories:
    ~/.kiwi/runtimes/by-run/<run_id>/
        pid
        log
        meta.json

    ~/.kiwi/runtimes/pending/<uuid>/
        pid
        log
        meta.json
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import subprocess
from typing import Any, Literal
import uuid

import psutil
from loguru import logger

from kiwi_cli.server import SERVER_PRESETS, http_url_from_server, server_from_backend_url

RuntimeScope = Literal["restricted", "full"]


@dataclass(frozen=True)
class RuntimeConnectArgs:
    """Arguments for starting kiwi-runtime.

    These mirror ``kiwi-runtime connect`` flags.
    """

    server: str | None = None
    email: str | None = None
    token: str | None = None
    scope: RuntimeScope = "restricted"
    allow_dirs: tuple[str, ...] = ()


RUNTIMES_DIR = Path.home() / ".kiwi" / "runtimes"
BY_RUN_DIR = RUNTIMES_DIR / "by-run"
PENDING_DIR = RUNTIMES_DIR / "pending"



def _read_pid(path: Path) -> int | None:
    if not path.exists():
        return None
    try:
        return int(path.read_text(encoding="utf-8").strip())
    except Exception:
        return None


def _pid_is_kiwi_runtime(pid: int) -> bool:
    """Check the PID still belongs to a kiwi-runtime connect process.

    Important: PID reuse is common. We verify the cmdline includes our module.
    """
    try:
        p = psutil.Process(pid)
    except Exception:
        return False
    try:
        if not p.is_running():
            return False
        # Avoid treating zombies as alive/valid.
        try:
            if p.status() == psutil.STATUS_ZOMBIE:
                return False
        except Exception:
            pass
        cmdline = p.cmdline() or []
    except Exception:
        return False
    joined = " ".join(cmdline).lower()
    # Typical: <python> -m kiwi_runtime.main connect ...
    return ("kiwi_runtime.main" in joined) and (" connect" in f" {joined} ")


def _log_indicates_disconnected(log_path: Path) -> bool:
    """Heuristic: if recent runtime logs show disconnection, treat it as invalid."""
    try:
        if not log_path.exists():
            return False

        # Read a tail chunk (avoid loading huge logs).
        max_bytes = 65536
        with open(log_path, "rb") as f:
            try:
                f.seek(0, 2)
                size = f.tell()
                f.seek(max(0, size - max_bytes), 0)
            except Exception:
                pass
            tail = f.read(max_bytes)

        text = tail.decode("utf-8", errors="ignore")
        markers = [
            "disconnected. goodbye!",
            "connection closed:",
            "service restart",
        ]
        return any(m in text.lower() for m in markers)
    except Exception:
        return False


def _pid_matches_create_time(pid: int, expected_create_time: float | None) -> bool:
    if expected_create_time is None:
        return True
    try:
        p = psutil.Process(pid)
        ct = p.create_time()
    except Exception:
        return False
    # Allow small differences due to float precision.
    return abs(ct - expected_create_time) < 2.0


def _runtime_valid(pid: int, *, meta: dict[str, Any] | None, log_path: Path) -> bool:
    """Determine whether an on-disk runtime record is still usable."""
    if not pid:
        return False
    if not _pid_alive(pid):
        return False
    if not _pid_is_kiwi_runtime(pid):
        return False
    expected_ct = None
    try:
        if isinstance(meta, dict):
            expected_ct = meta.get("create_time")
            if isinstance(expected_ct, str):
                expected_ct = float(expected_ct)
    except Exception:
        expected_ct = None
    if not _pid_matches_create_time(pid, expected_ct if isinstance(expected_ct, (int, float)) else None):
        return False
    # If logs show a disconnect, restart on next /connect-cli.
    if _log_indicates_disconnected(log_path):
        return False
    return True


def _pid_alive(pid: int) -> bool:
    try:
        return psutil.pid_exists(pid)
    except Exception:
        return False


def _runtime_dir_for_run(run_id: str) -> Path:
    d = BY_RUN_DIR / run_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def _runtime_dir_for_pending(pending_id: str) -> Path:
    d = PENDING_DIR / pending_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def pid_path_for_run(run_id: str) -> Path:
    return _runtime_dir_for_run(run_id) / "pid"


def log_path_for_run(run_id: str) -> Path:
    """Return the effective log path for a run.

    Normally, pending runtimes are moved into the by-run directory once the run_id
    exists. On Windows, the runtime keeps the log file open and directory renames
    can fail with access-denied errors.

    In those cases we "soft bind" by storing the real log path in meta.json.
    This helper resolves that indirection so UI screens (Ctrl+O) can still find logs.
    """
    d = _runtime_dir_for_run(run_id)
    default = d / "log"

    # Prefer the canonical location when it exists.
    if default.exists():
        return default

    # Fallback: meta.json may point to an alternate log location (soft bind).
    mp = d / "meta.json"
    if mp.exists():
        try:
            meta = json.loads(mp.read_text(encoding="utf-8") or "{}")
            lp = meta.get("log_path")
            if isinstance(lp, str) and lp.strip():
                p = Path(lp)
                if p.exists():
                    return p
        except Exception:
            pass

    return default


def meta_path_for_run(run_id: str) -> Path:
    return _runtime_dir_for_run(run_id) / "meta.json"


def pid_path_for_pending(pending_id: str) -> Path:
    return _runtime_dir_for_pending(pending_id) / "pid"


def log_path_for_pending(pending_id: str) -> Path:
    return _runtime_dir_for_pending(pending_id) / "log"


def meta_path_for_pending(pending_id: str) -> Path:
    return _runtime_dir_for_pending(pending_id) / "meta.json"


def get_running_pid_for_run(run_id: str) -> int | None:
    pid = _read_pid(pid_path_for_run(run_id))
    if not pid:
        return None

    mp = meta_path_for_run(run_id)
    meta: dict[str, Any] | None = None
    if mp.exists():
        try:
            meta = json.loads(mp.read_text(encoding="utf-8") or "{}")
        except Exception:
            meta = None

    if _runtime_valid(pid, meta=meta, log_path=log_path_for_run(run_id)):
        return pid

    # stale/invalid
    try:
        pid_path_for_run(run_id).unlink(missing_ok=True)
    except Exception:
        pass
    return None


def get_running_pid_for_pending(pending_id: str) -> int | None:
    pid = _read_pid(pid_path_for_pending(pending_id))
    if not pid:
        return None

    mp = meta_path_for_pending(pending_id)
    meta: dict[str, Any] | None = None
    if mp.exists():
        try:
            meta = json.loads(mp.read_text(encoding="utf-8") or "{}")
        except Exception:
            meta = None

    if _runtime_valid(pid, meta=meta, log_path=log_path_for_pending(pending_id)):
        return pid

    try:
        pid_path_for_pending(pending_id).unlink(missing_ok=True)
    except Exception:
        pass
    return None


def _write_meta(path: Path, meta: dict[str, Any]) -> None:
    try:
        path.write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
    except Exception:
        pass


def _spawn_runtime(
    *,
    python_exe: str,
    cwd: str,
    args: RuntimeConnectArgs,
    token_fallback: str | None,
    log_path: Path,
    pid_path: Path,
    meta_path: Path,
    meta_extra: dict[str, Any] | None = None,
) -> tuple[bool, int | None, str]:
    server = args.server
    if not server:
        return False, None, "Missing runtime server"

    token = args.token or token_fallback
    if not token:
        return False, None, "Missing token (login first or pass --token)"

    cmd: list[str] = [
        python_exe,
        "-m",
        "kiwi_runtime.main",
        "connect",
        "--server",
        server,
        "--token",
        token,
        "--scope",
        args.scope,
    ]
    if args.email:
        cmd.extend(["--email", args.email])
    for d in args.allow_dirs:
        cmd.extend(["--allow", d])

    env = os.environ.copy()
    env.setdefault("PYTHONUNBUFFERED", "1")

    # Ensure the runtime doesn't crash on Windows consoles/locales that default
    # to legacy encodings (cp1252, cp437).
    env.setdefault("PYTHONUTF8", "1")
    env.setdefault("PYTHONIOENCODING", "utf-8:replace")

    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_fp = open(log_path, "a", encoding="utf-8", errors="replace")
    except Exception as e:
        return False, None, f"Could not open runtime log file: {e}"

    try:
        logger.info(f"Starting kiwi-runtime: {' '.join(cmd)} (cwd={cwd})")
        proc = subprocess.Popen(
            cmd,
            cwd=cwd,
            env=env,
            stdout=log_fp,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    except Exception as e:
        try:
            log_fp.close()
        except Exception:
            pass
        return False, None, f"Failed to start runtime: {e}"

    try:
        pid_path.write_text(str(proc.pid), encoding="utf-8")
    except Exception:
        pass

    meta: dict[str, Any] = {
        "server": server,
        "scope": args.scope,
        "allow": list(args.allow_dirs),
        "email": args.email,
        "pid": proc.pid,
    }
    try:
        meta["create_time"] = psutil.Process(proc.pid).create_time()
    except Exception:
        pass
    if meta_extra:
        meta.update(meta_extra)
    _write_meta(meta_path, meta)

    return True, proc.pid, f"Runtime started (pid={proc.pid})"


def ensure_runtime_for_run(
    *,
    run_id: str,
    python_exe: str,
    cwd: str,
    args: RuntimeConnectArgs,
    token_fallback: str | None,
) -> tuple[bool, int | None, Path | None, str]:
    """Ensure a runtime exists for run_id; reuse if still alive."""
    existing = get_running_pid_for_run(run_id)
    lp = log_path_for_run(run_id)
    if existing:
        return True, existing, lp, f"Runtime already running for run {run_id} (pid={existing})"

    ok, pid, msg = _spawn_runtime(
        python_exe=python_exe,
        cwd=cwd,
        args=args,
        token_fallback=token_fallback,
        log_path=lp,
        pid_path=pid_path_for_run(run_id),
        meta_path=meta_path_for_run(run_id),
        meta_extra={"run_id": run_id, "state": "by-run"},
    )
    return ok, pid, lp if pid else None, msg


def start_pending_runtime(
    *,
    python_exe: str,
    cwd: str,
    args: RuntimeConnectArgs,
    token_fallback: str | None,
) -> tuple[bool, str | None, int | None, Path | None, str]:
    """Start a pending runtime (not yet bound to a run id)."""
    pending_id = str(uuid.uuid4())
    lp = log_path_for_pending(pending_id)

    ok, pid, msg = _spawn_runtime(
        python_exe=python_exe,
        cwd=cwd,
        args=args,
        token_fallback=token_fallback,
        log_path=lp,
        pid_path=pid_path_for_pending(pending_id),
        meta_path=meta_path_for_pending(pending_id),
        meta_extra={"pending_id": pending_id, "state": "pending"},
    )

    if not ok:
        return False, None, None, None, msg

    return True, pending_id, pid, lp, msg


def bind_pending_to_run(
    *,
    pending_id: str,
    run_id: str,
 ) -> tuple[bool, Path | None, str]:
    """Bind a pending runtime state directory to a run id.

    If a runtime already exists for the run id, we keep the existing one and
    leave the pending runtime untouched (it will be handled on exit cleanup).
    """
    if get_running_pid_for_run(run_id):
        return False, None, f"Runtime already exists for run {run_id}; not binding pending"

    src = _runtime_dir_for_pending(pending_id)
    dst = _runtime_dir_for_run(run_id)

    try:
        # If destination is empty, replace it by moving src.
        # Note: Path.rename works across same filesystem.
        # We want dst to be <by-run>/<run_id>; so remove it if it is empty.
        if dst.exists() and dst.is_dir() and not any(dst.iterdir()):
            dst.rmdir()
        src.rename(dst)
    except Exception as e:
        # Windows often blocks renaming/moving directories that contain an open log
        # file handle. Instead of failing (and losing the ability to show logs for
        # the run), do a "soft bind": keep the pending directory as-is but write a
        # by-run meta.json + pid that points to the pending log.
        try:
            # Ensure destination exists (it may have been removed above).
            dst.mkdir(parents=True, exist_ok=True)

            pending_pid = _read_pid(src / "pid")
            pending_log = src / "log"

            pending_meta_path = src / "meta.json"
            pending_meta: dict[str, Any] = {}
            if pending_meta_path.exists():
                try:
                    pending_meta = json.loads(pending_meta_path.read_text(encoding="utf-8") or "{}")
                except Exception:
                    pending_meta = {}

            # Mark the pending runtime as bound so it doesn't show up twice in the
            # cleanup UI.
            pending_meta.update({"bound_run_id": run_id, "bound_mode": "soft"})
            _write_meta(pending_meta_path, pending_meta)

            # Make the by-run PID available so future /connect-cli reuses the same
            # runtime instead of spawning duplicates.
            if pending_pid:
                try:
                    (dst / "pid").write_text(str(pending_pid), encoding="utf-8")
                except Exception:
                    pass

            # Write by-run meta.json pointing at the real log file.
            mp = dst / "meta.json"
            run_meta: dict[str, Any] = {}
            if mp.exists():
                try:
                    run_meta = json.loads(mp.read_text(encoding="utf-8") or "{}")
                except Exception:
                    run_meta = {}

            # Carry over some runtime fields when available.
            for k in ("server", "scope", "allow", "email", "create_time"):
                if k in pending_meta and k not in run_meta:
                    run_meta[k] = pending_meta[k]

            run_meta.update(
                {
                    "run_id": run_id,
                    "state": "by-run",
                    "pending_id": pending_id,
                    "bind_mode": "soft",
                    "log_path": str(pending_log),
                }
            )
            if pending_pid and "pid" not in run_meta:
                run_meta["pid"] = pending_pid
            _write_meta(mp, run_meta)

            return (
                True,
                pending_log,
                f"Bound pending runtime {pending_id} -> run {run_id} (soft bind; rename failed: {e})",
            )
        except Exception:
            return False, None, f"Failed to bind pending runtime: {e}"

    # Update meta.json with run_id (hard bind).
    try:
        mp = dst / "meta.json"
        meta: dict[str, Any] = {}
        if mp.exists():
            meta = json.loads(mp.read_text(encoding="utf-8") or "{}")
        meta.update({"run_id": run_id, "state": "by-run"})
        _write_meta(mp, meta)
    except Exception:
        pass

    return True, dst / "log", f"Bound pending runtime {pending_id} -> run {run_id}"


def kill_pid(pid: int) -> bool:
    """Best-effort terminate a PID (and its children)."""
    try:
        p = psutil.Process(pid)
    except Exception:
        return False

    # Terminate children first (runtime may spawn shells / subprocesses).
    try:
        for child in p.children(recursive=True):
            try:
                child.terminate()
            except Exception:
                pass
    except Exception:
        pass

    try:
        p.terminate()
    except Exception:
        pass

    try:
        p.wait(timeout=3)
    except Exception:
        pass

    # Force-kill anything still alive.
    if _pid_alive(pid):
        try:
            for child in p.children(recursive=True):
                try:
                    child.kill()
                except Exception:
                    pass
        except Exception:
            pass
        try:
            p.kill()
        except Exception:
            return False

    return True


def list_known_runtimes() -> list[dict[str, Any]]:
    """List runtimes recorded on disk (by-run and pending).

    Returns items with an `alive` flag computed using `_runtime_valid` (not just pid_exists),
    so PID reuse / disconnected runtimes don't wedge `/connect-cli` and don't show up
    in the exit cleanup prompt.
    """
    results: list[dict[str, Any]] = []

    for kind, base in (("by-run", BY_RUN_DIR), ("pending", PENDING_DIR)):
        if not base.exists():
            continue
        for d in sorted(base.iterdir()):
            if not d.is_dir():
                continue
            pid_file = d / "pid"
            log_file = d / "log"
            meta_file = d / "meta.json"
            pid = _read_pid(pid_file)
            meta: dict[str, Any] = {}
            if meta_file.exists():
                try:
                    meta = json.loads(meta_file.read_text(encoding="utf-8") or "{}")
                except Exception:
                    meta = {}

            # If a pending runtime was soft-bound to a run, skip it to avoid duplicate
            # entries in cleanup screens.
            if kind == "pending" and meta.get("bound_run_id"):
                continue

            effective_log = log_file
            lp = meta.get("log_path")
            if isinstance(lp, str) and lp.strip():
                try:
                    effective_log = Path(lp)
                except Exception:
                    effective_log = log_file

            alive = bool(pid and _runtime_valid(int(pid), meta=meta, log_path=effective_log))
            if pid and not alive:
                # Clean up the pid file so future sessions don't think a reused PID is valid.
                try:
                    pid_file.unlink(missing_ok=True)
                except Exception:
                    pass

            results.append(
                {
                    "kind": kind,
                    "id": d.name,
                    "pid": pid,
                    "alive": alive,
                    "log_path": str(effective_log),
                    "meta": meta,
                }
            )

    return results
