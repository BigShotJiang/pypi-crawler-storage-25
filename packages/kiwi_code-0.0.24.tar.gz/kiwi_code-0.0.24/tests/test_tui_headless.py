"""Headless Textual TUI tests using Textual's built-in ``run_test`` harness.

These exercise the real ``AutobotsTUI`` app the way a user would see it
but drive it through Textual's Pilot so they run anywhere (including CI
without a real terminal).
"""
from __future__ import annotations

from pathlib import Path

import json
import pytest


@pytest.mark.asyncio
async def test_tui_shows_login_when_unauthenticated(isolated_home: Path) -> None:
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        # No tokens on disk → we must land on the login screen.
        assert type(app.screen).__name__ == "LoginScreen"


@pytest.mark.asyncio
async def test_tui_login_inputs_render(isolated_home: Path) -> None:
    from textual.widgets import Input

    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        # Both the email and password inputs should be present.
        inputs = {i.id for i in app.screen.query(Input)}
        assert "username-input" in inputs
        assert "password-input" in inputs


@pytest.mark.asyncio
async def test_tui_action_switch_clears_chat(isolated_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Switching actions should reset the visible chat (new conversation UX)."""
    # Create tokens so the app boots straight into the Dashboard screen.
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    # Avoid any real HTTP calls during action selection.
    import kiwi_cli.commands as commands
    monkeypatch.setattr(commands, "actions_get", lambda _client, id: [f"OK: {id}"])

    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen
        screen.add_message("hello", "user")
        messages = screen.query_one("#messages")
        assert len(list(messages.children)) == 1

        await screen._on_action_picked_async("new-action-id")
        await pilot.pause()

        # The old chat should be cleared; next user message starts a new run.
        assert len(list(messages.children)) == 0



@pytest.mark.asyncio
async def test_tui_allows_empty_prompt(isolated_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Sending an empty prompt should still trigger a run."""
    # Create tokens so the app boots straight into the Dashboard screen.
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    from kiwi_tui.screens.dashboard import DashboardScreen
    called: list[str] = []
    monkeypatch.setattr(DashboardScreen, "process_message", lambda self, msg: called.append(msg))

    from kiwi_tui.main import AutobotsTUI
    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen
        chat_input = screen.query_one("#chat-input")
        chat_input.value = ""
        screen._do_send()
        await pilot.pause()

    assert called == [""]

@pytest.mark.asyncio
async def test_tui_quits_cleanly(isolated_home: Path) -> None:
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("ctrl+c")
        await pilot.pause()
    # Reaching here without an exception is the assertion.
