# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Kiwi Code is a TUI + CLI client for the Kiwi AI platform. It provides a chat interface (Textual) and CLI tools (Typer) for managing AI actions, action graphs, and their runs. A WebSocket-based runtime agent executes shell commands on behalf of the LLM.

## Build & Run Commands

```bash
# Package manager: uv | Build backend: hatchling | Python: 3.13+
uv sync                    # Install/sync dependencies
uv build                   # Build package

# Run
make run                   # Launch TUI (kiwi)
make dev                   # TUI with live reload
make serve                 # Serve TUI in browser (port 8566)
make cli                   # Run CLI (kiwicli)
make runtime ARGS="..."    # Run runtime agent with args

# Test
make test-hello            # Test backend API connection
uv run python test_hello.py  # Same, without make

# Clean
make clean                 # Remove caches and build artifacts
```

There are three entry points defined in pyproject.toml:
- `kiwi` → `kiwi_tui.main:main` (TUI)
- `kiwicli` → `kiwi_cli.cli:cli` (CLI)
- `kiwi-runtime` → `kiwi_runtime.main:main` (WebSocket agent)

## Architecture

```
┌─────────────────────────────────┐
│      Shared Libraries           │
│  commands.py · client.py        │
│  auth.py · models.py · server.py│
└──────────┬──────────┬───────────┘
           │          │
    ┌──────▼──────┐   └──────────────┐
    │ kiwi (TUI)  │   kiwicli (CLI)  │
    │ Textual app │   Typer CLI      │
    └──────┬──────┘   └──────────────┘
           │ auto-starts
    ┌──────▼──────────────────┐
    │ kiwi-runtime            │
    │ WebSocket agent         │
    │ One per working dir     │
    │ Survives TUI restarts   │
    └─────────────────────────┘
```

**Key design decisions:**
- Shared infrastructure lives in `kiwi_cli`; TUI imports from it via absolute imports (e.g., `from kiwi_cli.auth import TokenManager`)
- One runtime agent per working directory, managed via `runtime_manager.py`
- Runtime state stored in `~/.kiwi/runtimes/<key>/` (pid, log, cwd, tokens)
- Auth tokens stored in `~/.kiwi/tokens.json` with 0600 permissions
- No persisted app config; server is selected per invocation via `--server` (defaults to prod)

## Three Source Packages

- **`src/kiwi_cli/`** — Typer CLI app and shared infrastructure: auth, client, server, commands, models, runtime_manager, logger. Both `kiwi_tui` and the CLI entry point depend on this package.
- **`src/kiwi_tui/`** — Textual TUI app, screens, and widgets. Imports shared modules from `kiwi_cli`.
- **`src/kiwi_runtime/`** — Standalone WebSocket agent (~43KB `main.py`) that connects to Kiwi server and executes shell commands, sandboxed to CWD by default

## Server Presets (runtime)

- `app` → `https://api.meetkiwi.ai` (production)
- `dev` → `https://dev.api.myautobots.com` (default for TUI)
- `local` → `http://localhost:8000`

## CI/CD

GitHub Actions (`publish.yml`): triggered by manual dispatch or `v*.*.*` tags. Runs smoke tests (`kiwicli --help`, `kiwi-runtime --help`, `kiwicli runtime status`), builds, and publishes to PyPI.
