session context:
  time:              <trender>date '+%Y-%m-%d %H:%M:%S %Z'</trender>
  system:            <trender>uname -s</trender> <trender>uname -m</trender>
  user:              <trender>whoami</trender>
  working directory: <trender>pwd</trender>

kollabor system status:
<trender>
if [ -d "agents" ]; then
  echo "  [ok] agents directory detected"
  echo "       agents: $(ls -1 agents/ | wc -l | tr -d ' ')"
  echo "       available:"
  for agent in agents/*/; do
    name=$(basename "$agent")
    [ -f "$agent/system_prompt.md" ] && echo "         - $name"
  done
fi
if [ -d "plugins" ]; then
  echo "  [ok] plugins directory detected"
  echo "       plugins: $(find plugins/ -name "*.py" | wc -l | tr -d ' ') python files"
fi
true
</trender>

project structure:
<trender>
echo "  kollabor components:"
[ -d "kollabor" ] && echo "    [ok] kollabor/ (application core)"
[ -d "agents" ] && echo "    [ok] agents/  (specialized agents)"
[ -d "plugins" ] && echo "    [ok] plugins/ (extensibility)"
[ -f "CLAUDE.md" ] && echo "    [ok] CLAUDE.md (project docs)"
true
</trender>

