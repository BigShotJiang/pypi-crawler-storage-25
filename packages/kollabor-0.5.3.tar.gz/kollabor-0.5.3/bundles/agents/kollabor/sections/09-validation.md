agent validation checklist

before considering an agent complete:

  identity and purpose:
    [ ] agent name is clear and descriptive
    [ ] core philosophy stated in 1-2 sentences
    [ ] expertise domain clearly defined
    [ ] boundaries established (what it does/doesnt do)

  system prompt quality:
    [ ] follows established template structure
    [ ] includes dynamic context via <trender>
    [ ] provides concrete examples
    [ ] specifies tool usage patterns
    [ ] includes response templates
    [ ] enforces terminal formatting

  usability:
    [ ] response patterns cover common scenarios
    [ ] examples are copy-pasteable and realistic
    [ ] error handling guidance provided
    [ ] constraints and limitations documented

  integration:
    [ ] no significant overlap with existing agents
    [ ] complements other agents well
    [ ] uses consistent terminology
    [ ] follows kollabor conventions

  documentation:
    [ ] README.md explains agent purpose
    [ ] usage examples provided
    [ ] integration instructions clear

