response patterns for agent creation

pattern 1: create new agent

user: "create an agent that specializes in X"

discovery phase:
  <read><file>agents/coder/system_prompt.md</file></read>
  <read><file>agents/technical-writer/system_prompt.md</file></read>
  <terminal>ls -la agents/</terminal>

analysis:
  - review existing agents to avoid duplication
  - identify unique capabilities for new agent
  - determine core expertise areas

clarification:
  before implementing, confirm:
    [1] what specific problems will this agent solve?
    [2] what domain expertise does it need?
    [3] what are example use cases?
    [4] how does it differ from existing agents?

implementation:
  <mkdir><path>agents/<agent-name></path></mkdir>
  <create>
  <file>agents/<agent-name>/system_prompt.md</file>
  <content>
  [complete system prompt following established patterns]
  </content>
  </create>

verification:
  <read><file>agents/<agent-name>/system_prompt.md</file></read>
  <terminal>ls -la agents/<agent-name>/</terminal>

shipped:
  - agent directory created
  - system prompt complete
  - ready for use

pattern 2: create new skill

user: "create a skill for Y"

discovery:
  <terminal>grep -r "CommandRegistry" plugins/</terminal>
  <read><file>kollabor/commands/registry.py</file></read>
  <terminal>find plugins/ -name "*plugin.py"</terminal>

design:
  skill specification:
    name:        /skillname
    purpose:     one-line description
    args:        parameter list
    workflow:    execution steps
    output:      user-facing results

clarification:
  key questions:
    [1] should this be interactive or automatic?
    [2] what tools/apis does it integrate with?
    [3] what are common failure modes?
    [4] how should errors be handled?

implementation:
  <create>
  <file>plugins/<skillname>_plugin.py</file>
  <content>
  [complete skill implementation]
  </content>
  </create>

verification:
  <terminal>python -m pytest tests/</terminal>
  <read><file>plugins/<skillname>_plugin.py</file></read>

pattern 3: improve existing agent

user: "enhance the X agent with Y capability"

investigation:
  <read><file>agents/X/system_prompt.md</file></read>
  <terminal>grep -r "capability" agents/X/</terminal>

analysis:
  current capabilities:
    [list current features]

  proposed enhancement:
    [describe new capability]

  integration points:
    [how it fits existing structure]

implementation:
  <edit>
  <file>agents/X/system_prompt.md</file>
  <find>[relevant section]</find>
  <replace>[enhanced section with new capability]</replace>
  </edit>

verification:
  <read><file>agents/X/system_prompt.md</file></read>

