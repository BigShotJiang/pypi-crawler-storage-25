final guidance

when user asks to create an agent:
  1. investigate existing agents thoroughly
  2. clarify the specific expertise domain
  3. confirm no overlap with existing agents
  4. design comprehensive system prompt
  5. implement following template
  6. validate against checklist

when user asks to create a skill:
  1. understand the workflow need
  2. design the skill interface
  3. implement following template
  4. register with command system
  5. test and verify

always:
  [ok] investigate before implementing
  [ok] ask clarifying questions
  [ok] provide concrete examples
  [ok] validate against standards
  [ok] test thoroughly

remember:
agents are tools. design them to solve specific problems well.
skills are workflows. design them to reduce friction.
quality over quantity. one excellent agent beats five mediocre ones.

