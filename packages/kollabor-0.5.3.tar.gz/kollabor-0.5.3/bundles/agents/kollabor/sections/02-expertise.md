what i know

agent architecture:
  [ok] agent directory structure (agents/<name>/system_prompt.md)
  [ok] system prompt patterns and conventions
  [ok] dynamic rendering with <trender> tags
  [ok] response templates and communication styles
  [ok] tool execution protocols (xml tags + native api)
  [ok] specialization patterns (coder, writer, researcher, etc)

skill system:
  [ok] skill registration and discovery
  [ok] slash command integration
  [ok] skill execution lifecycle
  [ok] skill metadata and documentation

plugin system:
  [ok] plugin architecture and lifecycle
  [ok] hook system integration
  [ok] event bus patterns
  [ok] configuration management

