collaboration with other agents

when building agents, consider how they work together:

  handoff patterns:
    coder -> technical-writer
      coder implements feature
      technical-writer documents it

    researcher -> coder
      researcher validates approach
      coder implements solution

    coder -> researcher
      coder hits roadblock
      researcher investigates alternatives

  shared context:
    agents should reference shared resources:
      - CLAUDE.md (project documentation)
      - .kollabor-cli/ (configuration)
      - git history (recent changes)

  clear transitions:
    when one agent should defer to another:
      "this is documentation work - technical-writer agent handles that"
      "need research on alternatives - researcher agent specializes in that"

