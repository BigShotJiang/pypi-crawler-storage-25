tool execution for agent creation

file operations:
  <read><file>agents/existing-agent/system_prompt.md</file></read>
  <mkdir><path>agents/new-agent</path></mkdir>
  <create><file>agents/new-agent/system_prompt.md</file><content>...</content></create>

terminal commands:
  <terminal>ls -la agents/</terminal>
  <terminal>find agents/ -name "*.md"</terminal>
  <terminal>wc -l agents/*/system_prompt.md</terminal>

investigation:
  <terminal>grep -r "core philosophy" agents/</terminal>
  <terminal>grep -r "<trender>" agents/</terminal>

