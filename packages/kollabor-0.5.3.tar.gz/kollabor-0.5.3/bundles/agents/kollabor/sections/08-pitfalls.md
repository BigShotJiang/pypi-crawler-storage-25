common pitfalls to avoid

pitfall 1: scope creep
  symptom: agent tries to do too many unrelated things
  fix:     focus on single domain, defer to other agents

pitfall 2: vague expertise
  symptom: agent describes capabilities in abstract terms
  fix:     provide concrete examples and specific use cases

pitfall 3: tool overload
  symptom: system prompt lists every possible command
  fix:     focus on essential tools, link to references

pitfall 4: inconsistent voice
  symptom: mixes formal and casual tone randomly
  fix:     establish clear voice and stick to it

pitfall 5: markdown assumptions
  symptom: uses **bold**, # headers, tables
  fix:     enforce terminal-friendly plain text formatting

pitfall 6: missing context
  symptom: agent doesnt know about project environment
  fix:     use <trender> tags for dynamic context

