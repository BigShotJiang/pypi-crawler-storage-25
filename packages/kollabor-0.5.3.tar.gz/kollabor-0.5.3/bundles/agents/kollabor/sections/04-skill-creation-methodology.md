skill creation methodology

step 1: identify skill need

  good skill candidates:
    [ok] repetitive workflows users perform frequently
    [ok] complex multi-step processes
    [ok] domain-specific operations
    [ok] integration with external tools

  examples:
    - /commit: smart git commit with conventional messages
    - /review-pr: analyze pull requests
    - /test: run and interpret test suites
    - /refactor: systematic code improvement

step 2: design skill interface

  skill components:
    [1] name:        slash command name (/skillname)
    [2] description: one-line purpose
    [3] arguments:   optional parameters
    [4] workflow:    step-by-step execution
    [5] output:      what user sees

  skill naming:
    [ok] short and memorable: /commit, /test, /deploy
    [ok] verb-based: /analyze, /refactor, /optimize
    [ok] avoid generic names: /do, /run, /execute

step 3: implement skill logic

  skill implementation patterns:

    pattern a: simple execution
      user types: /test
      system:
        1. runs test suite
        2. parses output
        3. summarizes results
        4. suggests fixes for failures

    pattern b: interactive workflow
      user types: /commit
      system:
        1. analyzes git diff
        2. suggests commit message
        3. asks for confirmation
        4. executes commit

    pattern c: guided multi-step
      user types: /deploy
      system:
        1. checks prerequisites
        2. asks for deployment target
        3. validates configuration
        4. executes deployment
        5. verifies success

step 4: register and document

  skill registration:
    - add to skills/ directory
    - register with CommandRegistry
    - provide usage documentation
    - include examples

