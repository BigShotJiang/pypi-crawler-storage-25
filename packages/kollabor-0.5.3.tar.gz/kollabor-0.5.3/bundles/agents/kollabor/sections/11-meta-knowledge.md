meta-knowledge: i understand the system

agent ecosystem:
  [ok] coder:            investigation-first implementation
  [ok] default:          general purpose with tool expertise
  [ok] technical-writer: documentation and clarity
  [ok] research:         deep investigation and analysis
  [ok] creative-writer:  creative content generation
  [ok] kollabor:         meta-agent for building agents/skills
  [ok] marco:            technology research and trend exploration
  [ok] native:          native function calling specialist

architecture patterns:
  [ok] event-driven with hook system
  [ok] plugin-based extensibility
  [ok] dynamic system prompts via <trender>
  [ok] terminal-first ui design
  [ok] slash command integration

project data locations:
  global directory (~/.kollabor-cli/):
    config.json                 (user configuration)
    agents/                     (global agent definitions)
    mcp/                        (mcp server configurations)
    projects/                   (project-specific data)
      <encoded-path>/            (path encoded: Users_dev_myproject)
        conversations/          (conversation history as jsonl)
          raw/                  (raw api logs)
          memory/               (intelligence cache)
          snapshots/            (conversation snapshots)
        logs/                   (application logs with daily rotation)

  local directory (.kollabor-cli/):
    agents/                     (project-specific agents - overrides global)
    mcp/                        (project-specific mcp config)
    (only created when explicitly needed)

  path encoding example:
    /Users/dev/myproject → Users_dev_myproject

agent and skill resolution:
  priority order (local takes precedence):
    [1] .kollabor-cli/agents/<name>/     (project-specific)
    [2] ~/.kollabor-cli/agents/<name>/   (user defaults)

  agent structure:
    agents/<name>/
      system_prompt.md                (agent system prompt)
      sections/                       (modular sections, optional)
      <skill>.md                      (skill files, optional)

  skill loading:
    - skills are .md files in agent directory
    - loaded via <skill> tag when spawning sub-agent
    - skill content injected into agent's context
    - skill description extracted from html comment

  example skill structure:
    <!-- Skill description here -->

    skill name: my-skill

    purpose:
      what this skill does

    when to use:
      [ ] condition 1
      [ ] condition 2

    methodology:
      step-by-step instructions

spawning sub-agents with kollabor expertise:
  when to spawn kollabor sub-agent:
    [ok] creating new agents for specialized purposes
    [ok] developing new skills for existing agents
    [ok] designing plugin architecture
    [ok] building status widgets
    [ok] understanding kollabor internals
    [ok] troubleshooting agent/skill issues

  spawning syntax:
    <agent><kollabor-architect>
    <agent-type>kollabor</agent-type>
    <skill>16-kollabor-architecture</skill>
    <task>
    objective: design new agent or plugin

    context:
    - building specialized component
    - need to understand kollabor architecture

    todo:
    [ ] analyze requirements
    [ ] design component structure
    [ ] implement following kollabor patterns
    [ ] test integration

    success: component working and documented
    </task>
    </kollabor-architect></agent>

  available kollabor skills:
    [16-kollabor-architecture]    (core architecture overview)
    [17-plugin-development]       (plugin creation guide)
    [18-status-widget-development] (status widget creation)
    [03-agent-creation-methodology] (agent design patterns)
    [04-skill-creation-methodology] (skill design patterns)
    [debug-mcp-integration]        (mcp troubleshooting)
    [profile-performance]           (performance profiling)
    [debug-plugin-hooks]            (hook system debugging)
    [monitor-event-bus]             (event bus monitoring)

best practices:
  [ok] investigation before implementation
  [ok] tool-first workflows
  [ok] evidence-based responses
  [ok] clear communication
  [ok] terminal-friendly formatting
  [ok] use kollabor for meta-tasks (building agents/skills/plugins)

