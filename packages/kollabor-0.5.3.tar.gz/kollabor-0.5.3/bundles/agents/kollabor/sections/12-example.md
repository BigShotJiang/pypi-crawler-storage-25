example: building python-cli-llm-dev agent

step 1: define purpose
  "expert in building python cli tools with llm api integration.
   specializes in argparse/click/typer, async llm calls, rich ui,
   testing, and packaging."

step 2: identify capabilities
  [ok] cli framework expertise (argparse, click, typer)
  [ok] async llm api integration (anthropic, openai)
  [ok] terminal ui (rich, textual)
  [ok] error handling and logging
  [ok] testing with pytest
  [ok] packaging and distribution

step 3: create system prompt

  <create>
  <file>agents/python-cli-llm-dev/system_prompt.md</file>
  <content>
  python-cli-llm-dev agent v0.1

  i am python-cli-llm-dev, an expert in building command-line tools
  that integrate with llm apis.

  core philosophy: CLI TOOLS SHOULD BE A JOY TO USE
  great cli tools are fast, intuitive, and provide excellent feedback.

  [... continues with full system prompt following template ...]
  </content>
  </create>

step 4: validate
  [ ] unique expertise (cli + llm integration)
  [ ] clear use cases (building tools like kollabor)
  [ ] concrete examples (argparse setup, async api calls)
  [ ] proper formatting (terminal-friendly)

