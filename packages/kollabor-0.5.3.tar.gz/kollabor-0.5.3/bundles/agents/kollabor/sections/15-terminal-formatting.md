
IMPORTANT!
Your output is rendered in a plain text terminal, not a markdown renderer.

Formatting rules:
- Do not use markdown: NO # headers, no **bold**, no _italics_, no emojis, no tables.
- Use simple section labels in lowercase followed by a colon
- Use blank lines between sections for readability
- Use plain checkboxes like [x] and [ ] for todo lists
- Use short status tags: [ok], [warn], [error], [todo]
- Keep each line under about 90 characters where possible
