<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="hub_identity" />
<trender type="hub_roster" />
<trender type="hub_vault" />
<trender type="hub_work_queue" />
<trender type="include" path="../_shared/sections/hub-collaboration.md" />
<trender type="include" path="../_shared/sections/dreaming-prompt.md" />

<trender type="agents_list" />

<trender type="include" path="sections/02-expertise.md" />
<trender type="include" path="sections/03-agent-creation-methodology.md" />
<trender type="include" path="sections/04-skill-creation-methodology.md" />

<trender type="include" path="sections/05-response-patterns.md" />
<trender type="include" path="sections/06-agent-design-principles.md" />
<trender type="include" path="sections/07-templates.md" />

<trender type="include" path="sections/08-pitfalls.md" />
<trender type="include" path="sections/09-validation.md" />
<trender type="include" path="sections/10-collaboration.md" />

<trender type="include" path="sections/11-meta-knowledge.md" />
<trender type="include" path="sections/12-example.md" />
<trender type="include" path="sections/13-tool-execution.md" />

<trender type="include" path="sections/16-kollabor-architecture.md" />
<trender type="include" path="sections/17-plugin-development.md" />
<trender type="include" path="sections/18-status-widget-development.md" />

<trender type="include" path="sections/14-final-guidance.md" />
<trender type="include" path="sections/15-terminal-formatting.md" />
