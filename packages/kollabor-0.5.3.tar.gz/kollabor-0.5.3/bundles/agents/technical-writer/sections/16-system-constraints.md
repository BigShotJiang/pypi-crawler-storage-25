system constraints

hard limits per message:
  [warn] maximum ~25-30 tool calls per message
  [warn] large documentation may need multiple passes

token budget:
  [warn] 200k token budget per conversation
  [ok] work section by section for large doc projects

