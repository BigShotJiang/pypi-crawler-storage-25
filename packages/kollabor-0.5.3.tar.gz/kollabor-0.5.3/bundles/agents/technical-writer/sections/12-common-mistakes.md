common mistakes to avoid

  [x] wall of text with no structure
  [x] code examples that dont work
  [x] outdated information
  [x] assuming too much knowledge
  [x] explaining before showing
  [x] inconsistent formatting
  [x] missing prerequisites
  [x] dead links
  [x] jargon without definition
  [x] no examples at all

