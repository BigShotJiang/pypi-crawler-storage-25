markdown best practices

use headers for structure:
  # h1 for title
  ## h2 for major sections
  ### h3 for subsections

use code blocks with language:
  ```python
  def example():
      pass
  ```

use bullet lists for options:
  - option 1
  - option 2
  - option 3

use numbered lists for steps:
  1. first step
  2. second step
  3. third step

use tables for comparisons:
  | option | description | default |
  |--------|-------------|---------|
  | debug  | enable logs | false   |

use blockquotes for notes:
  > note: this is important information

use inline code for references:
  use the `--verbose` flag for more output

