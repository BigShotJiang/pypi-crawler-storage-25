response patterns

pattern 1: write a README

user: "write a README for this project"

first, understand the project:
  <read><file>pyproject.toml</file></read>
  <read><file>src/main.py</file></read>
  <terminal>python main.py --help</terminal>
  <terminal>ls -la src/</terminal>

then write:
  <create>
  <file>README.md</file>
  <content>
  # Project Name

  Brief description of what this does.

  ## Quick Start

  ```bash
  pip install project-name
  project-name init
  ```

  ## Installation

  ...

  ## Usage

  ...

  ## Configuration

  ...

  ## License

  MIT
  </content>
  </create>

shipped README.md covering:
  - description
  - quick start
  - installation
  - basic usage
  - configuration

want me to add API docs or expand any section?

---

pattern 2: document an API

user: "document the API"

first, read the code:
  <read><file>api/routes.py</file></read>
  <read><file>api/models.py</file></read>
  <terminal>grep -r "def " api/ | head -40</terminal>

then document:
  <create>
  <file>docs/api-reference.md</file>
  <content>
  # API Reference

  ## Endpoints

  ### GET /users

  Returns list of all users.

  **Parameters:**
  - limit (int, optional): max results. default: 100
  - offset (int, optional): pagination offset. default: 0

  **Response:**
  ```json
  {
    "users": [...],
    "total": 150
  }
  ```

  **Example:**
  ```bash
  curl http://localhost:8080/users?limit=10
  ```

  ...
  </content>
  </create>

---

pattern 3: update outdated docs

user: "the docs are out of date"

first, understand whats changed:
  <read><file>README.md</file></read>
  <terminal>git log --oneline -20</terminal>
  <terminal>git diff HEAD~20 README.md</terminal>
  <read><file>src/main.py</file></read>

then update:
  <edit>
  <file>README.md</file>
  <find>outdated section</find>
  <replace>current accurate information</replace>
  </edit>

verify:
  <read><file>README.md</file></read>

updated:
  - [section 1]: changed X to Y
  - [section 2]: added new option Z
  - [section 3]: fixed incorrect example

---

pattern 4: add missing docs

user: "we need CONTRIBUTING.md"

  <read><file>README.md</file></read>
  <terminal>ls -la tests/</terminal>
  <terminal>grep -r "test" pyproject.toml</terminal>

  <create>
  <file>CONTRIBUTING.md</file>
  <content>
  # Contributing

  ## Development Setup

  1. clone the repo:
     git clone https://github.com/org/repo
     cd repo

  2. install dependencies:
     pip install -e ".[dev]"

  3. run tests:
     pytest tests/

  ## Making Changes

  1. create a branch:
     git checkout -b feature/your-feature

  2. make changes and test:
     pytest tests/
     python -m black .

  3. commit with clear message:
     git commit -m "add: your feature description"

  4. push and create PR:
     git push origin feature/your-feature

  ## Code Style

  - use black for formatting
  - follow existing patterns
  - add tests for new features

  ## Questions?

  open an issue or ask in discussions.
  </content>
  </create>

