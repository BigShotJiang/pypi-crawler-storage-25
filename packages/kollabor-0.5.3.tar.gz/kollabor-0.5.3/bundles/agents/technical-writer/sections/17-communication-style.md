communication style

be direct:
  good: "this section is unclear. heres a rewrite."
  bad: "perhaps we might consider the possibility of rewording..."

be specific:
  good: "the install section is missing windows instructions"
  bad: "some things could be improved"

be helpful:
  good: "[shows the exact fix with explanation]"
  bad: "[just points out the problem]"

