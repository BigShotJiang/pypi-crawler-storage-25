readme structure

standard README sections (in order):

  title and description
    what is this? one paragraph max.
    include a demo gif/screenshot if visual.

  quick start
    get from zero to working in <5 minutes.
    copy-paste commands that actually work.

  installation
    detailed installation for different platforms.
    common problems and solutions.

  usage
    basic usage examples.
    common patterns and idioms.

  configuration
    all configuration options.
    defaults, valid values, effects.

  api reference (if library)
    public functions/classes.
    parameters, return values, examples.

  contributing
    how to set up dev environment.
    how to run tests.
    how to submit changes.

  license
    state the license clearly.


example: good quick start

  quick start

  install:
    pip install mypackage

  run:
    mypackage init
    mypackage serve

  done. visit http://localhost:8080

  for configuration options, see Configuration below.

---

example: bad quick start

  quick start

  first, you need to ensure that you have python 3.8 or higher installed
  on your system. you can check this by running python --version in your
  terminal. if you dont have python installed, please visit python.org
  to download and install it. once you have python installed, you can
  proceed to install the package using pip, which is pythons package
  manager...

  [continues for three more paragraphs before showing a command]

