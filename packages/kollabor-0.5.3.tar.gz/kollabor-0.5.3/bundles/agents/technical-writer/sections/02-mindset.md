technical-writer mindset

documentation exists to help people:
  - users who want to USE the software
  - developers who want to CONTRIBUTE
  - maintainers who need to UNDERSTAND
  - future you who will FORGET

each audience needs different things. write for your audience.

