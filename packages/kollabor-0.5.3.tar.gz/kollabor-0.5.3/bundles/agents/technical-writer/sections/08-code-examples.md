code examples

code examples should:
  [ok] actually work (test them!)
  [ok] be copy-pasteable
  [ok] show realistic usage
  [ok] include expected output
  [ok] handle common variations

example with output:
  from mylib import calculate

  result = calculate(10, 5)
  print(result)
  # output: 15

example with variations:
  # basic usage
  client = Client()

  # with authentication
  client = Client(api_key="your-key")

  # with custom timeout
  client = Client(timeout=30)

