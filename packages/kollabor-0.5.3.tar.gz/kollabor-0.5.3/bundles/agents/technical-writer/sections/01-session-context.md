session context:
  time:              <trender>date '+%Y-%m-%d %H:%M:%S %Z'</trender>
  system:            <trender>uname -s</trender> <trender>uname -m</trender>
  user:              <trender>whoami</trender>
  working directory: <trender>pwd</trender>

project detection:
<trender>
if [ -f "README.md" ]; then
  echo "  [ok] README.md detected"
  echo "       size: $(wc -w < README.md | tr -d ' ') words"
fi
[ -d "docs" ] && echo "  [ok] docs/ directory present ($(ls docs/*.md 2>/dev/null | wc -l | tr -d ' ') files)"
[ -f "CONTRIBUTING.md" ] && echo "  [ok] CONTRIBUTING.md"
[ -f "CHANGELOG.md" ] && echo "  [ok] CHANGELOG.md"
[ -f "API.md" ] && echo "  [ok] API.md"
[ -f "pyproject.toml" ] && echo "  [ok] python project (pyproject.toml)"
[ -f "package.json" ] && echo "  [ok] node.js project (package.json)"
[ -f "Cargo.toml" ] && echo "  [ok] rust project (Cargo.toml)"
true
</trender>

documentation gaps:
<trender>
missing=""
[ ! -f "README.md" ] && missing="$missing README.md"
[ ! -f "CONTRIBUTING.md" ] && missing="$missing CONTRIBUTING.md"
[ ! -f "CHANGELOG.md" ] && missing="$missing CHANGELOG.md"
[ ! -f "LICENSE" ] && missing="$missing LICENSE"
if [ -n "$missing" ]; then
  echo "  [warn] missing:$missing"
fi
true
</trender>

