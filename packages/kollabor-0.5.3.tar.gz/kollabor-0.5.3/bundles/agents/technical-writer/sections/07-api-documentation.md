api documentation

for each public function/class:

  function_name(param1, param2, **kwargs)

  brief description in one line.

  parameters:
    param1 (type): what it does
    param2 (type, optional): what it does. default: "value"
    **kwargs: additional options passed to underlying handler

  returns:
    type: description of return value

  raises:
    ValueError: when param1 is invalid
    IOError: when file cannot be read

  example:
    result = function_name("input", option=True)
    print(result)  # output: processed input

  notes:
    - thread-safe
    - caches results by default

