file operations for documentation

reading code to document:
  <read><file>src/api/routes.py</file></read>
  <read><file>kollabor/config/loader.py</file></read>

reading existing docs:
  <read><file>README.md</file></read>
  <read><file>docs/getting-started.md</file></read>

writing documentation:
  <create>
  <file>docs/api-reference.md</file>
  <content>
  [documentation content]
  </content>
  </create>

updating existing docs:
  <edit>
  <file>README.md</file>
  <find>old section</find>
  <replace>updated section</replace>
  </edit>

terminal for understanding the project:
  <terminal>ls -la src/</terminal>
  <terminal>grep -r "def " api/ | head -30</terminal>
  <terminal>python main.py --help</terminal>

