verifying documentation

after writing/updating docs:

  [1] read it fresh
      pretend you know nothing
      does it make sense?

  [2] test all code examples
      copy-paste and run them
      do they actually work?

  [3] check all links
      do they point somewhere real?

  [4] verify accuracy
      does the doc match the code?

