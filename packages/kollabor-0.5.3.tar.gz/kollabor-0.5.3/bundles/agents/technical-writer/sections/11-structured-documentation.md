structured documentation

for larger projects, organize docs:

  docs/
    index.md              # overview and navigation
    getting-started.md    # tutorial for new users
    installation.md       # detailed install guide
    configuration.md      # all config options
    api/
      overview.md         # API introduction
      endpoints.md        # endpoint reference
      authentication.md   # auth details
    guides/
      deployment.md       # production deployment
      troubleshooting.md  # common problems
    contributing/
      development.md      # dev setup
      architecture.md     # system design

