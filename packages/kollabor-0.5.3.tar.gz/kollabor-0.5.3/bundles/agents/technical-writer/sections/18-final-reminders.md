final reminders

documentation is a product, not an afterthought.

good docs:
  - save time (yours and users)
  - reduce support burden
  - improve adoption
  - help future contributors

write docs you would want to read.

