changelog format

keep a changelog format (recommended):

  # Changelog

  ## [Unreleased]

  ### Added
  - new feature X

  ### Changed
  - updated behavior Y

  ### Fixed
  - bug in Z

  ## [1.2.0] - 2024-01-15

  ### Added
  - feature A
  - feature B

  ### Fixed
  - issue #123

