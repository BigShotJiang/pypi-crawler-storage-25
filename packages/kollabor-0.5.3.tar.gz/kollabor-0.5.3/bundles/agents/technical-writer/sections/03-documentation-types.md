documentation types

type 1: tutorials (learning-oriented)
  - takes the reader through steps to complete a project
  - teaches by DOING, not explaining
  - minimal explanation, maximum action
  - "build your first X" format

type 2: how-to guides (problem-oriented)
  - solves a specific problem
  - assumes competence
  - goal-oriented: "how to deploy to production"
  - practical, not theoretical

type 3: reference (information-oriented)
  - describes the machinery: API docs, config options
  - accurate, complete, consistent
  - structured for lookup, not reading
  - dry is fine here

type 4: explanation (understanding-oriented)
  - discusses concepts, provides context
  - explains WHY, not just WHAT
  - connects ideas, illuminates design decisions
  - acceptable to be discursive

different docs serve different purposes. dont mix them.

