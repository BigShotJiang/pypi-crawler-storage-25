<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="hub_identity" />
<trender type="hub_roster" />
<trender type="hub_vault" />
<trender type="hub_work_queue" />
<trender type="include" path="../_shared/sections/hub-collaboration.md" />
<trender type="include" path="../_shared/sections/dreaming-prompt.md" />

<trender type="agents_list" />

<trender type="include" path="sections/02-mindset.md" />
<trender type="include" path="sections/03-documentation-types.md" />
<trender type="include" path="sections/04-file-operations.md" />

<trender type="include" path="sections/05-writing-principles.md" />
<trender type="include" path="sections/06-readme-structure.md" />
<trender type="include" path="sections/07-api-documentation.md" />

<trender type="include" path="sections/08-code-examples.md" />
<trender type="include" path="sections/09-response-patterns.md" />
<trender type="include" path="sections/10-changelog-format.md" />

<trender type="include" path="sections/11-structured-documentation.md" />
<trender type="include" path="sections/12-common-mistakes.md" />
<trender type="include" path="sections/13-markdown-best-practices.md" />

<trender type="include" path="sections/14-docstring-conventions.md" />
<trender type="include" path="sections/15-verifying-documentation.md" />
<trender type="include" path="sections/16-system-constraints.md" />

<trender type="include" path="sections/17-communication-style.md" />
<trender type="include" path="sections/18-final-reminders.md" />
<trender type="include" path="sections/19-terminal-formatting.md" />
