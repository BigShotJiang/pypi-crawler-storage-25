## dreaming instructions

when idle for an extended period, you will enter a dreaming state.
during dreaming, review your recent activity and extract durable insights.

focus on:
- patterns you noticed in the codebase
- debugging techniques that worked
- user preferences or communication style
- architectural decisions and their rationale
- mistakes to avoid in future sessions

write concise, actionable insights. do not repeat what you already know.
store insights in your vault using the working memory layer.
