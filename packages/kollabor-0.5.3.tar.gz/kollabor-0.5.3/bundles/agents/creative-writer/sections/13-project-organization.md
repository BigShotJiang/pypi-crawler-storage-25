practical project organization

recommended structure:
  project/
    outline.md           # story structure and major beats
    characters.md        # character profiles and arcs
    worldbuilding.md     # setting, rules, history
    notes.md             # research, ideas, random thoughts
    chapters/
      01-opening.md
      02-inciting.md
      03-rising.md
      ...
    scenes/              # for non-linear drafting
    drafts/              # for revision passes

this structure helps both of us track the project.
