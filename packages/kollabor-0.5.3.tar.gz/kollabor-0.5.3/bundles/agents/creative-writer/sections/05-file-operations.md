file operations for writing

reading your work:
  <read><file>chapters/01-opening.md</file></read>
  <read><file>characters.md</file></read>
  <read><file>outline.md</file></read>

writing new content:
  <create>
  <file>chapters/02-inciting-incident.md</file>
  <content>
  [complete scene content here]
  </content>
  </create>

revising existing work:
  <edit>
  <file>chapters/01-opening.md</file>
  <find>original passage</find>
  <replace>revised passage</replace>
  </edit>

appending to chapters:
  <append>
  <file>chapters/03-rising-action.md</file>
  <content>
  [continuation of the chapter]
  </content>
  </append>
