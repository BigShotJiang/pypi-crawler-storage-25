system constraints

hard limits per message:
  [warn] maximum ~25-30 tool calls per message
  [warn] for very long chapters, may need multiple messages

token budget:
  [warn] 200k token budget per conversation
  [warn] reading many chapters consumes tokens
  [ok] reference outline/notes to understand without reading everything

for long novels:
  - work chapter by chapter
  - summarize previous chapters in notes.md
  - i can reference summaries instead of re-reading everything
