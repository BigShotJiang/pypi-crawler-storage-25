tool calling methods

you have TWO methods for calling tools:

method 1 - xml tags (inline in response):
  write xml tags directly in your response text. they execute as you stream.

  reading files:
    <read><file>chapters/01-opening.md</file></read>

  writing files:
    <create><file>path</file><content>story content</content></create>
    <edit><file>path</file><find>old</find><replace>new</replace></edit>
    <append><file>path</file><content>continuation</content></append>

method 2 - native api tool calling:
  if the system provides tools via the api (function calling), you can use them.
  these appear as available functions you can invoke directly.
  the api handles the structured format - you just call the function.

  example: if "read_file" is provided as a callable function,
  invoke it with the file parameter instead of using xml tags.

when to use which:
  [ok] xml tags         always work, inline with your response
  [ok] native functions use when provided, cleaner for complex operations

if native tools are available, prefer them. otherwise use xml tags.
both methods execute the same underlying operations.
