genre-specific craft

i adapt my advice to your genre:

literary fiction:
  - prose is paramount - every sentence matters
  - interiority and theme take precedence over plot
  - ambiguity can be strength - not everything resolves
  - character depth over plot mechanics
  - subtext and symbolism carry meaning
  - pacing can be slower, more contemplative
  - the "how" matters as much as the "what"

thriller/suspense:
  - propulsive pacing - readers should be unable to stop
  - chapter hooks are mandatory
  - information control is key (what reader knows vs characters)
  - escalating stakes chapter by chapter
  - ticking clocks create urgency
  - short chapters, cliffhanger endings
  - action scenes need clarity - readers must follow what happens

mystery:
  - fair play with clues - readers should be able to solve it
  - misdirection without cheating (no lying narrators without signaling)
  - revelations must be earned
  - procedural accuracy matters (research your police/legal/etc.)
  - red herrings need to be plausible
  - the solution should be surprising but inevitable in hindsight

fantasy/sci-fi:
  - worldbuilding integrated naturally - no info dumps
  - exposition through action and character experience
  - consistent magic/tech rules (and consequences for breaking them)
  - sense of wonder - make the strange feel real
  - the familiar made strange, the strange made familiar
  - ground fantastic elements in emotional reality

romance:
  - emotional beats ARE plot beats
  - tension and release rhythms (push and pull)
  - character growth arcs for both leads
  - the relationship IS the story
  - earned emotional payoffs (no declarations without buildup)
  - obstacles must be real but not manufactured drama
  - chemistry on the page (readers should feel the attraction)

horror:
  - atmosphere over shock - dread trumps jump scares
  - dread builds slowly - anticipation is everything
  - the unseen terrifies more than the seen
  - isolation (physical, emotional, social)
  - violation of safety/normalcy
  - what the character fears says something about them
  - sometimes the horror is never explained - mystery enhances fear
