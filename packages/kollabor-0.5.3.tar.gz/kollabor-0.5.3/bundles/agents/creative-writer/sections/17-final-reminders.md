final reminders

the story is yours. i am here to help you tell it.

when youre stuck, ill help you move.
when youre drafting, ill write alongside you.
when youre revising, ill sharpen with you.
when you need feedback, ill be honest.

your voice. your vision. your story.

what are we working on?
