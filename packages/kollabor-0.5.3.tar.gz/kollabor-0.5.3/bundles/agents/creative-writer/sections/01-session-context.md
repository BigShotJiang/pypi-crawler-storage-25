session context:
  time:              <trender>date '+%Y-%m-%d %H:%M:%S %Z'</trender>
  user:              <trender>whoami</trender>
  working directory: <trender>pwd</trender>

writing project:
<trender>
if [ -d "chapters" ] || [ -d "scenes" ] || [ -d "drafts" ] || [ -d "manuscript" ]; then
  echo "  [ok] writing project detected"
  [ -d "chapters" ] && echo "       chapters: $(ls chapters/*.md 2>/dev/null | wc -l | tr -d ' ') files"
  [ -d "scenes" ] && echo "       scenes: $(ls scenes/*.md 2>/dev/null | wc -l | tr -d ' ') files"
  [ -d "drafts" ] && echo "       drafts: $(ls drafts/*.md 2>/dev/null | wc -l | tr -d ' ') files"
  [ -d "manuscript" ] && echo "       manuscript: $(ls manuscript/*.md 2>/dev/null | wc -l | tr -d ' ') files"
  [ -f "outline.md" ] && echo "       [ok] outline.md present"
  [ -f "characters.md" ] && echo "       [ok] characters.md present"
  [ -f "worldbuilding.md" ] && echo "       [ok] worldbuilding.md present"
  [ -f "notes.md" ] && echo "       [ok] notes.md present"
else
  echo "  [info] no structured writing project found"
  echo "         tip: create chapters/, scenes/, or drafts/ to organize work"
fi
true
</trender>

word count:
<trender>
total=0
for dir in chapters scenes drafts manuscript; do
  if [ -d "$dir" ]; then
    count=$(cat $dir/*.md 2>/dev/null | wc -w | tr -d ' ')
    total=$((total + count))
  fi
done
if [ $total -gt 0 ]; then
  echo "  total words: $total"
  if [ $total -lt 7500 ]; then
    echo "  length: short story (<7,500 words)"
  elif [ $total -lt 17500 ]; then
    echo "  length: novelette (7,500-17,500 words)"
  elif [ $total -lt 40000 ]; then
    echo "  length: novella (17,500-40,000 words)"
  else
    echo "  length: novel (40,000+ words)"
  fi
fi
</trender>
