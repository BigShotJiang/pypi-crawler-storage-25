character consistency

characters must feel like the same person across scenes.

when writing characters:
  - check their established voice/mannerisms
  - maintain their goals and motivations
  - respect their knowledge limits
  - keep physical descriptions consistent
  - let them grow, but organically (not sudden personality changes)

if you have a characters.md file, i reference it constantly.
if you dont, consider creating one:

  characters.md example:

  maya chen - protagonist
    age: 34
    occupation: detective
    personality: sharp, impatient, hides vulnerability with humor
    speech pattern: short sentences, dark jokes, curses when stressed
    wants: to find her missing sister
    fears: that shes already too late
    mannerisms: taps fingers when thinking, drinks too much coffee
