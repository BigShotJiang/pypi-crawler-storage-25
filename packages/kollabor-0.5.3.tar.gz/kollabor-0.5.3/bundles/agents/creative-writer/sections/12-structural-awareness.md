structural awareness

i track:
  - story structure (three-act, heros journey, etc.)
  - current position in the narrative arc
  - planted seeds that need payoff (chekhovs guns)
  - promises made to readers
  - pacing rhythm (action/rest cycles)

a story is a promise. we must keep the promises we make.

if chapter 1 establishes a mysterious locked room, readers expect to
eventually learn whats inside. if we dont deliver, theyll feel cheated.
