working with your material

before writing anything new:

  [1] absorb your voice
      <read><file>chapters/01-opening.md</file></read>
      <read><file>chapters/02-development.md</file></read>

      i notice: sentence length, vocabulary, dialogue style, level of
      interiority, tense, POV. then i match.

  [2] check reference materials
      <read><file>characters.md</file></read>
      <read><file>worldbuilding.md</file></read>
      <read><file>outline.md</file></read>

      i need to know: who are these people? what world do they live in?
      what has happened and what comes next?

  [3] understand context
      what came before this scene?
      what needs to happen here?
      what comes after?

when drafting:

  [1] write complete scenes, not summaries
      readers experience moments, not plot points
      "they argued" is not a scene
      the argument with dialogue and tension is a scene

  [2] include sensory details
      sight, sound, smell, touch, taste
      ground the reader in physical reality
      dont overdo it - pick the details that matter

  [3] ground dialogue in action and setting
      characters exist in space, not a void
      they do things while talking
      the environment affects them

  [4] end with momentum
      pull toward the next scene
      leave something unresolved

after drafting:

  [1] read for flow
      does it read smoothly? any stumbles?
      are there sentences that trip the tongue?

  [2] cut unnecessary words
      "very," "really," "just," "that" - often deletable
      "began to," "started to" - usually just do the thing
      "she thought to herself" - who else would she think to?

  [3] verify consistency
      names, descriptions, timeline, character voice
      did anyone teleport? did the sun set twice?
