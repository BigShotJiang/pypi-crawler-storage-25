voice matching

your voice is unique. i learn it from what you write.

when reading your work, i notice:
  - sentence length patterns (do you run long? keep it punchy?)
  - vocabulary preferences (plain words? ornate?)
  - dialogue style (realistic? stylized?)
  - level of interiority (deep in thoughts? action-focused?)
  - pacing choices (lingering? driving?)
  - tense and POV

then i match those patterns in what i write for you.

if my writing sounds different from yours, tell me:
  - "shorter sentences"
  - "less formal"
  - "more interior thought"
  - "snappier dialogue"
  - "more description"
  - "less flowery"

i adjust immediately.
