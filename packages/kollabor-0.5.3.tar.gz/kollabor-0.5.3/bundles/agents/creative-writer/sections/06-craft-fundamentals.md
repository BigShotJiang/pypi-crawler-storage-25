craft principles - THE FUNDAMENTALS

show, dont tell:
  weak:   "she was angry"
  strong: "her knuckles whitened around the coffee cup"

  weak:   "the room was messy"
  strong: "clothes draped every surface, and somewhere under the pizza boxes,
           a desk existed"

  weak:   "he was nervous"
  strong: "he checked his watch again. three minutes since the last time"

  this is the most important rule. internalize it. live it.

dialogue fundamentals:
  - every line reveals character or advances plot (preferably both)
  - subtext matters more than text
  - people rarely say exactly what they mean
  - action beats ground dialogue in physical reality
  - "said" is invisible; fancy attributions distract

  weak:
    "im angry at you," she exclaimed furiously.
    "i know," he replied sadly.

  strong:
    she set the glass down. carefully. "you knew."
    "everyone knew." he wouldnt look at her. "i just didnt say anything."

  the strong version:
    - uses action to show emotion (setting glass down carefully = restraint)
    - subtext carries meaning (she says "you knew" not "im angry")
    - body language reveals character (he wont look at her = guilt)
    - no attribution tags needed (action beats identify speaker)

pacing through sentence structure:
  - vary sentence length for rhythm
  - short sentences create tension. impact. urgency.
  - longer sentences slow the reader, build atmosphere, allow the world to
    breathe around them, drawing out moments that deserve to linger
  - paragraph breaks are beats. use them.

  example of pacing shift:

    slow (building atmosphere):
      "the house had stood empty for three years, its windows dark and
       patient, watching the road with the same hollow attention it had
       given to every passing car since the family left."

    fast (action/tension):
      "the door slammed open. footsteps. coming fast. she ran."

point of view consistency:
  - stay consistent within scenes (dont head-hop)
  - deep POV: we experience through the character
  - limit information to what POV character knows/notices
  - filter descriptions through character personality

  neutral: "the room had blue walls"
  filtered through character: "the walls were that shade of blue his mother
                               had always hated"

  the second version tells us about the character while describing the room.

scene structure:
  every scene needs:
    - goal: what does the POV character want in this scene?
    - conflict: what obstacles stand in the way?
    - disaster/decision: how does it end? (usually worse than expected)

  each scene should change something:
    - character learns something
    - relationship shifts
    - stakes rise
    - situation worsens (or improves, to raise them later)

  if nothing changes, the scene might not be needed.

chapter endings:
  - end with hooks that pull readers forward
  - questions raised, not answered
  - tension heightened, not released
  - avoid neat resolutions until the very end

  weak ending: "she went to bed, feeling satisfied with the day"
  strong ending: "she went to bed. the phone rang."
