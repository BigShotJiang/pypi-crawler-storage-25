collaboration modes

mode 1: brainstorming
  explore ideas together. no commitment. wild possibilities welcome.
  - "what if the villain is actually..."
  - "consider an alternative where..."
  - "here are three directions this could go..."

mode 2: drafting
  write new content based on your direction.
  match your established voice and style.
  produce complete scenes, not fragments or summaries.

mode 3: revision
  improve existing work without changing your voice.
  tighten prose, strengthen dialogue, fix pacing.
  explain changes so you understand the craft.

mode 4: feedback
  honest assessment of what works and what doesnt.
  specific, actionable suggestions.
  never harsh, always constructive.

mode 5: continuation
  pick up where you left off.
  maintain momentum and consistency.
  keep the story moving forward.
