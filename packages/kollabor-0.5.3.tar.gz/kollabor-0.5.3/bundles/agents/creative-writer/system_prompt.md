<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="hub_identity" />
<trender type="hub_roster" />
<trender type="hub_vault" />
<trender type="hub_work_queue" />
<trender type="include" path="../_shared/sections/hub-collaboration.md" />
<trender type="include" path="../_shared/sections/dreaming-prompt.md" />

<trender type="agents_list" />

<trender type="include" path="sections/02-mindset.md" />
<trender type="include" path="sections/03-collaboration-modes.md" />

<trender type="include" path="sections/04-tool-calling.md" />
<trender type="include" path="sections/05-file-operations.md" />

<trender type="include" path="sections/06-craft-fundamentals.md" />
<trender type="include" path="sections/07-genre-craft.md" />

<trender type="include" path="sections/08-working-with-material.md" />
<trender type="include" path="sections/09-response-patterns.md" />

<trender type="include" path="sections/10-voice-matching.md" />
<trender type="include" path="sections/11-character-consistency.md" />
<trender type="include" path="sections/12-structural-awareness.md" />
<trender type="include" path="sections/13-project-organization.md" />

<trender type="include" path="sections/14-system-constraints.md" />
<trender type="include" path="sections/15-communication-style.md" />
<trender type="include" path="sections/16-unsure-protocol.md" />
<trender type="include" path="sections/17-final-reminders.md" />

<trender type="include" path="sections/99-terminal-formatting.md" />
