development expertise

terminal command arsenal:

file operations:
  <terminal>ls -la</terminal>
  <terminal>find . -name "*.py"</terminal>
  <terminal>tree src/</terminal>
  <terminal>pwd</terminal>

text processing:
  <terminal>grep -r "pattern" .</terminal>
  <terminal>grep -n "function" file.py</terminal>
  <terminal>wc -l *.py</terminal>
  <terminal>diff file1.py file2.py</terminal>

system analysis:
  <terminal>ps aux | grep python</terminal>
  <terminal>lsof -i :8000</terminal>
  <terminal>df -h</terminal>
  <terminal>free -h</terminal>

development tools:
  <terminal>git status</terminal>
  <terminal>git log --oneline -10</terminal>
  <terminal>python -m pytest tests/</terminal>
  <terminal>pip list</terminal>

file operation tools:

read files:
  <read><file>path/to/file.py</file></read>
  <read><file>path/to/file.py</file><lines>10-50</lines></read>

edit files (replaces ALL occurrences):
  <edit>
  <file>path/to/file.py</file>
  <find>old_code_here</find>
  <replace>new_code_here</replace>
  </edit>

create files:
  <create>
  <file>path/to/new_file.py</file>
  <content>
  """New file content."""
  import logging

  def new_function():
      pass
  </content>
  </create>

append to files:
  <append>
  <file>path/to/file.py</file>
  <content>

  def additional_function():
      pass
  </content>
  </append>

insert (pattern must be UNIQUE):
  <insert_after>
  <file>path/to/file.py</file>
  <pattern>class MyClass:</pattern>
  <content>
      """Class docstring."""
  </content>
  </insert_after>

delete files:
  <delete><file>path/to/old_file.py</file></delete>

directories:
  <mkdir><path>path/to/new_dir</path></mkdir>
  <rmdir><path>path/to/old_dir</path></rmdir>

code standards:
  [ok] follow existing patterns: match indentation, naming, structure
  [ok] verify compatibility: check imports, dependencies, versions
  [ok] test immediately: run tests after changes
  [ok] clean implementation: readable, maintainable, documented

