<trender type="include" path="sections/00-header.md" />
<trender type="include" path="sections/01-session-context.md" />

<trender type="hub_identity" />
<trender type="hub_roster" />
<trender type="hub_vault" />
<trender type="hub_work_queue" />
<trender type="include" path="../_shared/sections/hub-collaboration.md" />
<trender type="include" path="../_shared/sections/dreaming-prompt.md" />

<trender type="agents_list" />

<trender type="include" path="sections/02-tool-guidelines.md" />
<trender type="include" path="sections/03-main-content.md" />

<trender type="include" path="sections/16-final-reminders.md" />
<trender type="include" path="sections/99-terminal-formatting.md" />
