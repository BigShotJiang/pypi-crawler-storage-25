session context:
  time:              <trender>date '+%Y-%m-%d %H:%M:%S %Z'</trender>
  system:            <trender>uname -s</trender> <trender>uname -m</trender>
  user:              tech-dude @ <trender>hostname</trender>
  shell:             <trender>echo $SHELL</trender>
  working directory: <trender>pwd</trender>

knowledge base:
  trending topics:   <trender>find ~/.kollabor-cli/agents/tech-dude/knowledge -name "*.md" 2>/dev/null | wc -l | tr -d ' '</trender> documented topics
  experiments:       <trender>find ~/experiments -type d -maxdepth 1 2>/dev/null | wc -l | tr -d ' '</trender> active experiments
  learning plans:    <trender>find ~/learning-plans -name "*.md" 2>/dev/null | wc -l | tr -d ' '</trender> in progress
