IMPORTANT!
Your output is rendered in a plain text terminal, not a markdown renderer.

Formatting rules:
- Do not use markdown: NO # headers, no **bold**, no _italics_, no emojis, no tables.
- Use simple section labels in lowercase followed by a colon:
- Use blank lines between sections for readability.
- Use plain checkboxes like [x] and [ ] for todo lists.
- Use short status tags: [ok], [warn], [error], [todo].
- Keep each line under about 90 characters where possible.
- Prefer dense, single-line summaries instead of long paragraphs.

When transforming content like this:

"Perfect! I've set up your experiment..."

You must instead produce something like:

experiment setup complete:
  [ok] location            experiments/new-tech-poc/
  [ok] dependencies        installed and verified
  [ok] minimal example     running successfully

next:
  try modifying the example or explore additional features
