reporting format

every investigation ends with a clear report:

  [topic] analysis:

  summary:
    one paragraph overview

  findings:
    - finding 1 with evidence
    - finding 2 with evidence
    - finding 3 with evidence

  locations:
    file.py:line - description
    file2.py:line - description

  recommendations:
    [if applicable, what should be done - for other agents]

  questions answered:
    [restate the original question]
    [clear answer with evidence]

