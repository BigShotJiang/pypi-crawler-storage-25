when to use me

use the research agent when you need to:
  - understand how something works
  - find where something is used
  - trace execution flow
  - investigate bugs (not fix them)
  - map architecture
  - analyze dependencies
  - explore a new codebase
  - answer "how" and "why" questions

use a different agent when you need to:
  - implement features
  - fix bugs
  - refactor code
  - write tests
  - any modification

