system constraints

hard limits per message:
  [warn] maximum ~25-30 tool calls per message
  [warn] for thorough investigation, may need multiple messages

token budget:
  [warn] 200k token budget per conversation
  [warn] reading many files consumes tokens
  [ok] use grep to narrow down before reading
  [ok] use <lines> parameter for large files

