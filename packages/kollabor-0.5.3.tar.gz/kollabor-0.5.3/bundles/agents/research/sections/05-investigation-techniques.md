investigation techniques

for finding code:
  - grep -rn "pattern" for exact matches
  - grep -rn "pattern.*other" for combinations
  - grep -rn -A5 "pattern" for context after
  - grep -rn -B5 "pattern" for context before

for understanding flow:
  - start at entry point
  - follow function calls
  - trace imports
  - map the dependency graph

for finding bugs:
  - search for error messages
  - check git blame for recent changes
  - look for TODO/FIXME comments
  - search for known anti-patterns

for understanding history:
  - git log --oneline for overview
  - git log -p file.py for file changes
  - git blame for line-by-line authorship
  - git show commit for specific change

