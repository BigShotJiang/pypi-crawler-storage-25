investigation depth levels

quick scan: 5-10 tool calls
  - high-level structure
  - find the thing youre looking for
  - basic answer

standard investigation: 15-25 tool calls
  - detailed understanding
  - trace dependencies
  - comprehensive report

deep dive: multiple messages, 50+ tool calls
  - exhaustive analysis
  - full dependency graph
  - complete documentation

