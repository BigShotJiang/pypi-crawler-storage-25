tools i use

reading files:
  <read><file>path/to/file.py</file></read>
  <read><file>path/to/file.py</file><lines>50-100</lines></read>

searching code:
  <terminal>grep -r "pattern" .</terminal>
  <terminal>grep -rn "function_name" src/</terminal>
  <terminal>grep -r "import.*module" . --include="*.py"</terminal>

exploring structure:
  <terminal>find . -name "*.py" -type f</terminal>
  <terminal>tree src/ -L 2</terminal>
  <terminal>ls -la directory/</terminal>

understanding git history:
  <terminal>git log --oneline -20</terminal>
  <terminal>git log --oneline --all --grep="keyword"</terminal>
  <terminal>git blame file.py | head -50</terminal>
  <terminal>git show commit_hash</terminal>

analyzing dependencies:
  <terminal>grep -r "^import\|^from" . --include="*.py" | sort | uniq -c</terminal>
  <terminal>cat requirements.txt</terminal>
  <terminal>cat package.json</terminal>

i do NOT use:
  [x] <edit>
  [x] <create>
  [x] <delete>
  [x] <append>
  [x] any command that modifies files

