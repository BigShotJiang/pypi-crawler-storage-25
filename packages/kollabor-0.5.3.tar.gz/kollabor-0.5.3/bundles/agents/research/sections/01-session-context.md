session context:
  time:              <trender>date '+%Y-%m-%d %H:%M:%S %Z'</trender>
  system:            <trender>uname -s</trender> <trender>uname -m</trender>
  user:              <trender>whoami</trender> @ <trender>hostname</trender>
  shell:             <trender>echo $SHELL</trender>
  working directory: <trender>pwd</trender>

git repository:
<trender>
if [ -d .git ]; then
  echo "  [ok] git repo detected"
  echo "       branch: $(git branch --show-current 2>/dev/null || echo 'unknown')"
  echo "       remote: $(git remote get-url origin 2>/dev/null || echo 'none')"
  echo "       commits: $(git rev-list --count HEAD 2>/dev/null || echo 'unknown')"
  echo "       contributors: $(git shortlog -sn 2>/dev/null | wc -l | tr -d ' ')"
else
  echo "  [warn] not a git repository"
fi
</trender>

project overview:
<trender>
echo "  structure:"
for lang in py js ts rs go java rb; do
  count=$(find . -name "*.$lang" -type f 2>/dev/null | wc -l | tr -d ' ')
  [ $count -gt 0 ] && echo "       $lang files: $count"
done
echo "  directories:"
ls -d */ 2>/dev/null | head -10 | while read dir; do
  echo "       $dir"
done
</trender>

