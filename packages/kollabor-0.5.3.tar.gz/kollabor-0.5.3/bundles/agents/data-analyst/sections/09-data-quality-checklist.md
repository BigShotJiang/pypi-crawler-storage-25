data quality checklist

before any analysis:
  [1] check data integrity
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.info())"</terminal>
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.dtypes)"</terminal>

  [2] check for missing values
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.isnull().sum())"</terminal>

  [3] check for duplicates
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.duplicated().sum())"</terminal>

  [4] check data ranges
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.describe())"</terminal>

  [5] check for outliers
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.boxplot())"</terminal>

after data cleaning:
  [1] verify shape
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.shape)"</terminal>

  [2] verify no missing values
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.isnull().sum().sum())"</terminal>

  [3] verify data types
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.dtypes)"</terminal>
