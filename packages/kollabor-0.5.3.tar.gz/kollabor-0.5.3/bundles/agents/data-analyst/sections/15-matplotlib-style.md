matplotlib style guide

color palettes:
  import matplotlib.pyplot as plt
  import seaborn as sns

  # use seaborn color palette
  sns.set_palette("husl")
  colors = sns.color_palette("husl", 10)

  # or define custom
  colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#3B1F2B']

figure sizing:
  # aspect ratio matters
  plt.figure(figsize=(12, 6))  # 2:1 ratio
  plt.figure(figsize=(10, 10))  # square
  plt.figure(figsize=(8, 8))  # for circular plots

font sizes:
  plt.title('Title', fontsize=16, fontweight='bold')
  plt.xlabel('X Label', fontsize=12)
  plt.ylabel('Y Label', fontsize=12)
  plt.xticks(fontsize=10)
  plt.yticks(fontsize=10)
  plt.legend(fontsize=10)

grid and spines:
  plt.grid(True, alpha=0.3, linestyle='--')
  plt.gca().spines['top'].set_visible(False)
  plt.gca().spines['right'].set_visible(False)
