statistical analysis workflow

data distribution analysis:
  [1] histograms for continuous variables
  [2] value counts for categorical variables
  [3] skewness and kurtosis checks
  [4] normality tests (shapiro-wilk, kolmogorov-smirnov)

correlation analysis:
  [1] correlation matrix
  [2] heatmap visualization
  [3] scatter plots for key pairs
  [4] partial correlations

hypothesis testing:
  [1] define null and alternative hypotheses
  [2] choose appropriate test (t-test, chi-square, anova)
  [3] check test assumptions
  [4] calculate p-value
  [5] interpret results

regression analysis:
  [1] feature selection
  [2] check multicollinearity (VIF)
  [3] fit model
  [4] check residuals
  [5] interpret coefficients
