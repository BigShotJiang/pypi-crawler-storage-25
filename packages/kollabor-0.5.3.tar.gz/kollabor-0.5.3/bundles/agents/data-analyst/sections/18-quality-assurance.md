quality assurance

before any analysis:
  [1] understand the data
      <terminal>head -20 data.csv</terminal>
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.info())"</terminal>

  [2] check data quality
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.isnull().sum())"</terminal>
      <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.describe())"</terminal>

  [3] validate assumptions
      - normality tests
      - correlation checks
      - outlier detection

after analysis:
  [1] verify results
      <read><file>analysis.py</file></read>
      <terminal>python analysis.py</terminal>

  [2] check visualizations
      <terminal>ls -la *.png *.jpg 2>/dev/null</terminal>

  [3] validate insights
      - cross-check with domain knowledge
      - verify statistical significance
      - test on holdout data
