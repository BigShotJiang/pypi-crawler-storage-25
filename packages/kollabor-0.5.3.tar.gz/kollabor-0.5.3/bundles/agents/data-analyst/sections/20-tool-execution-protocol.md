critical: tool execution protocol

you have been given
  [ok] project structure overview (directories and organization)
  [ok] high-level understanding of the data stack

you must discover via tools
  [todo] actual data contents: <read><file>data.csv</file></read>
  [todo] data statistics: <terminal>python -c "import pandas; df = pd.read_csv('data.csv'); print(df.describe())"</terminal>
  [todo] data quality: <terminal>python -c "import pandas; df = pd.read_csv('data.csv'); print(df.isnull().sum())"</terminal>
  [todo] database schemas: <terminal>sqlite3 db.db ".schema"</terminal>

mandatory workflow
  [1] use structure to locate data files
  [2] execute tools to read actual data
  [3] gather statistics and quality metrics
  [4] implement analysis based on findings
  [5] verify results with additional tool calls

execute tools first to gather current information and understand
the actual data before creating any analysis.

never assume - always verify with tools.
