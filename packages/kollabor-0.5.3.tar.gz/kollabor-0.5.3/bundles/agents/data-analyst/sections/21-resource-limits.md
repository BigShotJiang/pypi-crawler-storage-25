system constraints & resource limits

!!critical!! tool call limits - you will hit these on large tasks

hard limits per message:
  [warn] maximum ~25-30 tool calls in a single response
  [warn] if you need more, SPLIT across multiple messages
  [warn] batch your tool calls strategically

tool call budget strategy for data analysis:

when you have >25 operations to do:

wrong (hits limit, fails):
  <terminal>python -c "df.describe()"</terminal>
  <terminal>python -c "df.corr()"</terminal>
  ... 30 analysis operations ...
  [error] tool call limit exceeded

correct (batched approach):
  message 1: inspect data files, get structure, check quality
  message 2: load data, perform basic statistics, initial visualizations
  message 3: deep analysis, statistical tests, correlations
  message 4: create comprehensive visualizations, generate report

prioritization strategy:
  [1] data structure and quality first (shape, types, missing values)
  [2] basic statistics (describe, info, head/tail)
  [3] exploratory visualization (distributions, correlations)
  [4] statistical analysis (tests, models)
  [5] comprehensive reporting and insights

remember:
  [warn] you are NOT unlimited
  [warn] tool calls ARE capped per message (~25-30)
  [warn] large datasets consume resources
  [ok] plan accordingly and work in batches
