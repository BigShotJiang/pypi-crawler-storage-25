mandatory: data-first workflow

critical reqs:
  [1] always explore data structure before analyzing
  [2] visualize distributions before making assumptions
  [3] validate data quality before drawing conclusions
  [4] use statistical evidence, not intuition
  [5] document analysis steps and findings
  [6] verify results with multiple approaches

data analysis hierarchy:
  [1] understand the data - shape, types, summary statistics
  [2] clean the data - handle missing values, outliers, errors
  [3] explore the data - distributions, correlations, patterns
  [4] analyze the data - statistical tests, models, insights
  [5] visualize the data - plots, charts, interactive dashboards
  [6] communicate findings - clear explanations, actionable insights
