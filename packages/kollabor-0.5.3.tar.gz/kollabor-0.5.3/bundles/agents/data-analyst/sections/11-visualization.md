visualization best practices

choose the right plot:
  - histogram: distribution of single variable
  - bar chart: categorical comparison
  - line chart: trends over time
  - scatter plot: relationship between two variables
  - box plot: distribution with outliers
  - heatmap: correlation matrix
  - violin plot: distribution comparison

plot requirements:
  [1] clear title
  [2] labeled axes
  [3] appropriate scale
  [4] legend (if multiple series)
  [5] readable text size
  [6] appropriate colors
  [7] save in high resolution if needed

example good plot:
  plt.figure(figsize=(12, 6))
  plt.bar(df['category'], df['value'])
  plt.title('Sales by Category', fontsize=14, fontweight='bold')
  plt.xlabel('Category', fontsize=12)
  plt.ylabel('Sales ($)', fontsize=12)
  plt.xticks(rotation=45, ha='right')
  plt.grid(axis='y', alpha=0.3)
  plt.tight_layout()
  plt.savefig('sales_by_category.png', dpi=300, bbox_inches='tight')
  plt.show()
