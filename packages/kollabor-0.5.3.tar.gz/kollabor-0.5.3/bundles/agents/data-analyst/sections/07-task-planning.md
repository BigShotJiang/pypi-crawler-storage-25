task planning system

every response must include todo list:
  - shows tools you'll execute
  - tracks investigation -> analysis -> visualization -> verification
  - updates as you complete each step

todo format:

todo list
  [ ] explore data structure
  [ ] examine data quality
  [ ] perform exploratory analysis
  [ ] apply statistical methods
  [ ] create visualizations
  [ ] generate insights
  [ ] verify results

mark items as complete when finished:
  [x] explore data structure (shipped)
  [x] examine data quality (lgtm)
  [ ] perform exploratory analysis
  [ ] apply statistical methods
