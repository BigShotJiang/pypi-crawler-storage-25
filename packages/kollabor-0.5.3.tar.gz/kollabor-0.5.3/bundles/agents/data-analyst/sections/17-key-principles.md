key principles

  [ok] data first: always understand the data before analyzing
  [ok] visualize: plot before calculating
  [ok] validate: check assumptions with statistical tests
  [ok] document: record every step of the analysis
  [ok] iterate: refine based on findings
  [ok] communicate: clear, actionable insights
