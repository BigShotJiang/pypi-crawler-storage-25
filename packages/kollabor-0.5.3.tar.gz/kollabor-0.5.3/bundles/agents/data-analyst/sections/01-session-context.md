session context:
  time:              <trender>date '+%Y-%m-%d %H:%M:%S %Z'</trender>
  system:            <trender>uname -s</trender> <trender>uname -m</trender>
  user:              <trender>whoami</trender> @ <trender>hostname</trender>
  shell:             <trender>echo $SHELL</trender>
  working directory: <trender>pwd</trender>

git repository:
<trender>
if [ -d .git ]; then
  echo "  [ok] git repo detected"
  echo "       branch: $(git branch --show-current 2>/dev/null || echo 'unknown')"
  echo "       remote: $(git remote get-url origin 2>/dev/null || echo 'none')"
  echo "       status: $(git status --short 2>/dev/null | wc -l | tr -d ' ') files modified"
  echo "       last commit: $(git log -1 --format='%h - %s (%ar)' 2>/dev/null || echo 'none')"
else
  echo "  [warn] not a git repository"
fi
</trender>

data environment:
<trender>
echo "  python packages:"
python -c "import pandas; print(f'    [ok] pandas {pandas.__version__}')" 2>/dev/null || echo "    [warn] pandas not installed"
python -c "import numpy; print(f'    [ok] numpy {numpy.__version__}')" 2>/dev/null || echo "    [warn] numpy not installed"
python -c "import matplotlib; print(f'    [ok] matplotlib {matplotlib.__version__}')" 2>/dev/null || echo "    [warn] matplotlib not installed"
python -c "import seaborn; print(f'    [ok] seaborn {seaborn.__version__}')" 2>/dev/null || echo "    [info] seaborn not installed"
python -c "import sqlite3; print(f'    [ok] sqlite3 available')" 2>/dev/null || echo "    [warn] sqlite3 not available"
python -c "import sqlalchemy; print(f'    [ok] sqlalchemy {sqlalchemy.__version__}')" 2>/dev/null || echo "    [info] sqlalchemy not installed"
</trender>

data files:
<trender>
echo "  data files detected:"
find . -maxdepth 2 -type f \( -name "*.csv" -o -name "*.json" -o -name "*.xlsx" -o -name "*.parquet" -o -name "*.db" -o -name "*.sqlite" -o -name "*.sql" \) 2>/dev/null | head -10 | while read f; do
  size=$(ls -lh "$f" | awk '{print $5}')
  lines=$(wc -l < "$f" 2>/dev/null || echo "?")
  echo "    [ok] $f ($size, $lines lines)"
done
if [ $(find . -maxdepth 2 -type f \( -name "*.csv" -o -name "*.json" -o -name "*.xlsx" -o -name "*.parquet" -o -name "*.db" -o -name "*.sqlite" -o -name "*.sql" \) 2>/dev/null | wc -l) -eq 0 ]; then
  echo "    [warn] no data files found"
fi
</trender>

database connections:
<trender>
if [ -f "database.ini" ] || [ -f ".env" ]; then
  echo "  [ok] database config found"
  grep -i -E "database|db_|postgres|mysql|sqlite" .env 2>/dev/null | head -3 | while read line; do
    echo "       $line" | sed 's/=.*/=***/'
  done
else
  echo "  [warn] no database config found"
fi
</trender>

project files:
<trender>
echo "  key files present:"
[ -f "requirements.txt" ] && echo "    [ok] requirements.txt"
[ -f "pyproject.toml" ] && echo "    [ok] pyproject.toml"
[ -f "README.md" ] && echo "    [ok] README.md"
[ -f ".gitignore" ] && echo "    [ok] .gitignore"
[ -f "data/" ] && echo "    [ok] data/ directory"
[ -f "notebooks/" ] || [ -f "notebook/" ] && echo "    [ok] notebooks directory"
</trender>

recent analysis:
<trender>
if [ -d .git ]; then
  echo "  recent commits related to data:"
  git log --oneline --all --grep="data\|analysis\|dataset" -5 2>/dev/null || echo "    no data-related commits"
fi
</trender>
