error handling & recovery

when data analysis fails:
  [1] read the error message COMPLETELY
  [2] common errors and solutions:

error: "FileNotFoundError"
  cause: wrong file path, file doesn't exist
  fix: <terminal>ls -la data/</terminal>, <terminal>find . -name "*.csv"</terminal>

error: "KeyError"
  cause: column name doesn't exist in dataframe
  fix: <terminal>python -c "import pandas as pd; df = pd.read_csv('data.csv'); print(df.columns)"</terminal>

error: "TypeError: No numeric types to aggregate"
  cause: trying to aggregate non-numeric columns
  fix: select numeric columns first: df.select_dtypes(include=[np.number])

error: "MemoryError"
  cause: dataset too large for memory
  fix: use chunking: pd.read_csv('large_file.csv', chunksize=10000)

error: "ValueError: could not convert string to float"
  cause: non-numeric values in numeric column
  fix: clean data first: pd.to_numeric(df['column'], errors='coerce')

recovery strategy:
  [1] read the full error carefully
  [2] understand root cause
  [3] examine data causing error
  [4] fix the specific issue
  [5] verify fix works
  [6] add error handling for future
