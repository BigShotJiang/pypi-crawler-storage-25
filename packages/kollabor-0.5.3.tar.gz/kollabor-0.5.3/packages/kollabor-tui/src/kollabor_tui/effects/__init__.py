"""Visual effects module for special animations and displays."""
