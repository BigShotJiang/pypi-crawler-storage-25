"""Message coordination system for preventing race conditions.

This coordinator solves the fundamental race condition where multiple
message writing systems interfere with each other, causing messages
to be overwritten or cleared unexpectedly.

IMPORTANT: All terminal state changes (input rendering, clearing, buffer
transitions) should go through this coordinator to prevent state bugs.

This module provides atomic message display coordination and unified
state management to prevent interference between different message
writing systems.
"""

import logging
import time
from typing import Any, Dict, List, Optional, Tuple

# Import renderer and display filter system from kollabor_tui
from kollabor_tui.message_renderer import (
    DisplayFilterRegistry,
    MessageType,
    ModernMessageRenderer,
)
from kollabor_tui.renderer_protocol import MessageRendererProtocol

logger = logging.getLogger(__name__)


class MessageDisplayCoordinator:
    """Coordinates message display AND render state to prevent interference.

    Key Features:
    - Atomic message sequences (all messages display together)
    - Unified state management (prevents clearing conflicts)
    - Proper ordering (system messages before responses)
    - Protection from interference (no race conditions)
    - Buffer transition management (modal, fullscreen, etc.)
    - Message buffering during alternate buffer (altview/modal) sessions:
      messages rendered while in an altview are queued and flushed when
      returning to the main UI, so agent output is never lost.
    """

    def __init__(
        self, terminal_renderer, renderer: Optional[MessageRendererProtocol] = None
    ):
        """Initialize message display coordinator.

        Args:
            terminal_renderer: TerminalRenderer instance for display
            renderer: Message renderer instance (defaults to ModernMessageRenderer)
        """
        self.terminal_renderer = terminal_renderer
        self.renderer: MessageRendererProtocol = renderer or ModernMessageRenderer()
        self.message_queue: List[Tuple[str, str, Dict[str, Any]]] = []
        self.is_displaying = False

        # Navigation awareness - prevents render conflicts with status navigation
        self.navigation_active: bool = False

        # Saved state for buffer transitions (modal, fullscreen, etc.)
        self._saved_main_buffer_state: Optional[Dict[str, Any]] = None
        self._in_alternate_buffer = False

        # Buffered rendered output: messages that arrived while in an altview.
        # Each entry is (category, rendered_string, timestamp).
        # Categories: "tool_call", "tool_result", "assistant", "system", "error", "raw"
        self._buffered_output: List[Tuple[str, str, float]] = []
        self._away_start_time: float = 0.0

        # Reference to render loop for triggering renders after message display
        self._render_loop = None

        logger.debug("MessageDisplayCoordinator initialized")

    # === Output routing ===

    def _output_rendered(self, rendered: str, category: str = "system") -> None:
        """Route rendered output to terminal or buffer.

        When the main UI is in alternate buffer mode (an altview is active),
        the rendered string is buffered instead of printed. The buffer is
        flushed when the altview exits, so the user sees all agent output
        that arrived while they were away.

        Args:
            rendered: Fully rendered string (ANSI-formatted) ready to display.
            category: Message category for smart flush summarization.
        """
        if self._in_alternate_buffer:
            self._buffered_output.append((category, rendered, time.monotonic()))
            logger.debug(
                "Buffered %s message while in alternate buffer (%d total)",
                category,
                len(self._buffered_output),
            )
        else:
            print(rendered, flush=True)

    def _flush_buffered_output(self) -> None:
        """Print buffered messages with a summary card on return from altview.

        Called by exit_alternate_buffer(). Shows a compact summary of what
        happened while the user was away, then prints all messages in order.
        Must exit raw mode before printing so \\n includes \\r (carriage return).
        """
        if not self._buffered_output:
            return

        count = len(self._buffered_output)
        logger.info("Flushing %d buffered messages after alternate buffer exit", count)

        # Exit raw mode so print() newlines work correctly (LF -> CR+LF).
        from kollabor_tui.terminal_state import TerminalMode

        terminal_state = self.terminal_renderer.terminal_state
        was_raw = terminal_state.current_mode == TerminalMode.RAW
        if was_raw:
            terminal_state.exit_raw_mode()

        try:
            self._print_return_summary()
            for _category, rendered, _ts in self._buffered_output:
                print(rendered, flush=True)
        finally:
            if was_raw:
                terminal_state.enter_raw_mode()

        self._buffered_output.clear()

    def _print_return_summary(self) -> None:
        """Print a compact summary card before flushing buffered messages."""
        from kollabor_tui.design_system import S, T, TagBox

        # Calculate away duration
        away_secs = 0.0
        if self._away_start_time > 0:
            away_secs = time.monotonic() - self._away_start_time

        # Count by category
        counts: Dict[str, int] = {}
        for category, _rendered, _ts in self._buffered_output:
            counts[category] = counts.get(category, 0) + 1

        # Build summary parts
        parts = []
        if counts.get("tool_call", 0):
            parts.append(f"{counts['tool_call']} tool call(s)")
        if counts.get("assistant", 0):
            parts.append(f"{counts['assistant']} response(s)")
        if counts.get("error", 0):
            parts.append(f"{counts['error']} error(s)")
        if counts.get("system", 0):
            parts.append(f"{counts['system']} system msg(s)")

        total = len(self._buffered_output)
        if not parts:
            parts.append(f"{total} message(s)")

        # Format away time
        if away_secs >= 60:
            time_str = f"{away_secs / 60:.1f}m"
        else:
            time_str = f"{away_secs:.1f}s"

        summary_text = (
            f" {S.DIM}returned ({time_str} away, {', '.join(parts)}){S.RESET_DIM}"
        )

        try:
            theme = T()
            summary_box = TagBox.render(
                lines=[summary_text],
                tag_bg=theme.dark[0],
                tag_fg=theme.text_dim,
                tag_width=3,
                content_colors=theme.dark[0],
                content_fg=theme.text_dim,
                content_width=70,
                tag_chars=[" ~ "],
                use_gradient=False,
            )
            print(summary_box, flush=True)
        except Exception:
            # Fallback if design system isn't available
            print(f"  ~ returned ({time_str} away, {', '.join(parts)})", flush=True)

    @property
    def buffered_output_count(self) -> int:
        """Number of messages currently buffered during alternate buffer mode."""
        return len(self._buffered_output)

    # === Core message display ===

    def _capture_render_state(self) -> Dict[str, Any]:
        """Capture current render state for later restoration.

        Returns:
            Dictionary containing render state snapshot.
        """
        return {
            "writing_messages": self.terminal_renderer.writing_messages,
            "input_line_written": self.terminal_renderer.input_line_written,
            "last_line_count": self.terminal_renderer.last_line_count,
            "thinking_active": self.terminal_renderer.thinking_active,
        }

    def queue_message(self, message_type: str, content: str, **kwargs) -> None:
        """Queue a message for coordinated display.

        Args:
            message_type: Type of message ("system", "assistant", "user", "error")
            content: Message content to display
            **kwargs: Additional arguments for message formatting
        """
        self.message_queue.append((message_type, content, kwargs))
        logger.debug(f"Queued {message_type} message: {content[:50]}...")

    def display_queued_messages(self) -> None:
        """Display all queued messages in proper atomic sequence.

        This method ensures all queued messages display together
        without interference from other systems.
        """
        if self.is_displaying or not self.message_queue:
            return

        # When in alternate buffer, still render messages but they go
        # into the buffer instead of stdout (handled by _output_rendered).
        # Skip the navigation guard -- agent messages should still be captured.
        if not self._in_alternate_buffer:
            if self.navigation_active:
                logger.debug("Skipping message display: navigation active")
                return

        logger.debug(f"Displaying {len(self.message_queue)} queued messages")

        # Enter atomic display mode
        self.is_displaying = True

        pipe_mode = getattr(self.terminal_renderer, "pipe_mode", False)

        # Only touch terminal state when NOT in alternate buffer and NOT in pipe mode
        if not self._in_alternate_buffer and not pipe_mode:
            self.terminal_renderer.writing_messages = True
            self.terminal_renderer.clear_active_area()

        try:
            # Display all messages in sequence
            for message_type, content, kwargs in self.message_queue:
                self._display_single_message(message_type, content, kwargs)

        finally:
            self.message_queue.clear()
            self.is_displaying = False

            # Only reset terminal state when NOT in alternate buffer and NOT in pipe mode
            if not self._in_alternate_buffer and not pipe_mode:
                self.terminal_renderer.writing_messages = False
                self.terminal_renderer.input_line_written = False
                self.terminal_renderer.last_line_count = 0
                self.terminal_renderer.invalidate_render_cache()
                self.terminal_renderer.terminal_state.write_raw("\r\033[?25h")

                if hasattr(self.terminal_renderer, "render_active_area"):
                    try:
                        import asyncio

                        loop = asyncio.get_event_loop()
                        if loop.is_running():
                            asyncio.create_task(
                                self.terminal_renderer.render_active_area()
                            )
                        logger.debug("Triggered immediate render after message display")
                    except Exception as e:
                        logger.warning(f"Failed to trigger immediate render: {e}")

            logger.debug("Completed atomic message display")

    def display_message_sequence(
        self, messages: List[Tuple[str, str, Dict[str, Any]]]
    ) -> None:
        """Display a sequence of messages atomically.

        This is the primary method for coordinated message display.
        All messages in the sequence will display together without
        interference from other systems.

        Args:
            messages: List of (message_type, content, kwargs) tuples

        Example:
            coordinator.display_message_sequence([
                ("system", "Thought for 2.1 seconds", {}),
                ("assistant", "Hello! How can I help you?", {})
            ])
        """
        # Queue all messages
        for message_type, content, kwargs in messages:
            self.queue_message(message_type, content, **kwargs)

        # Display them atomically
        self.display_queued_messages()

    def display_raw_text(self, text: str) -> None:
        """Display pre-formatted text atomically, coordinated with the render loop.

        Unlike display_message_sequence, this prints text as-is without
        routing through message type renderers. Use for text with custom
        ANSI formatting (gradients, etc.) that should not be wrapped in boxes.
        """
        if self.is_displaying:
            return

        # When in alternate buffer, buffer the raw text
        if self._in_alternate_buffer:
            self._buffered_output.append(("raw", text, time.monotonic()))
            logger.debug(
                "Buffered raw text while in alternate buffer (%d total)",
                len(self._buffered_output),
            )
            return

        # Skip during navigation to prevent render conflicts
        if self.navigation_active:
            logger.debug("Skipping raw text display: navigation active")
            return

        pipe_mode = getattr(self.terminal_renderer, "pipe_mode", False)

        # Enter atomic display mode
        self.is_displaying = True
        if not pipe_mode:
            self.terminal_renderer.writing_messages = True
            # Clear active area once before printing
            self.terminal_renderer.clear_active_area()

        try:
            # Write text without toggling raw mode - toggling while the input
            # handler thread is blocked on stdin.read(1) corrupts termios state
            # and can crash the terminal emulator.  In raw mode \n doesn't move
            # to column 0, so we convert to \r\n ourselves.
            raw_text = text.replace("\n", "\r\n") + "\r\n"
            self.terminal_renderer.terminal_state.write_raw(raw_text)

        finally:
            self.is_displaying = False

            if not pipe_mode:
                # Exit atomic display mode
                self.terminal_renderer.writing_messages = False
                # Reset render state for clean input box rendering
                self.terminal_renderer.input_line_written = False
                self.terminal_renderer.last_line_count = 0
                self.terminal_renderer.invalidate_render_cache()
                # Ensure cursor is visible and at start of new line
                self.terminal_renderer.terminal_state.write_raw("\r\033[?25h")

                # Trigger immediate render to show input box after display
                if hasattr(self.terminal_renderer, "render_active_area"):
                    try:
                        import asyncio

                        loop = asyncio.get_event_loop()
                        if loop.is_running():
                            asyncio.create_task(
                                self.terminal_renderer.render_active_area()
                            )
                        logger.debug(
                            "Triggered immediate render after raw text display"
                        )
                    except Exception as e:
                        logger.warning(f"Failed to trigger immediate render: {e}")

            logger.debug("Completed raw text display")

    def write_streaming_chunk(self, chunk: str) -> None:
        """Write a streaming token chunk directly to terminal.

        Bypasses atomic batching — bare write for real-time token output.
        Called once per streaming chunk from StreamingHandler.
        """
        if self._in_alternate_buffer:
            return
        raw = chunk.replace("\n", "\r\n")
        self.terminal_renderer.terminal_state.write_raw(raw)

    def _display_single_message(
        self, message_type: str, content: str, kwargs: Dict[str, Any]
    ) -> None:
        """Display a single message using the active renderer.

        All rendering is delegated to self.renderer (which implements
        MessageRendererProtocol). The renderer determines the visual style.
        Output is routed through _output_rendered() which handles buffering
        when in alternate buffer mode.

        Args:
            message_type: Type of message to display
            content: Message content
            kwargs: Additional formatting arguments
        """
        try:
            terminal_state = self.terminal_renderer.terminal_state
            from kollabor_tui.terminal_state import TerminalMode

            # When in alternate buffer, skip raw mode toggling entirely --
            # we're just rendering to a buffer, not writing to the terminal.
            in_alt = self._in_alternate_buffer
            was_raw = False
            if not in_alt:
                was_raw = terminal_state.current_mode == TerminalMode.RAW
                if was_raw:
                    terminal_state.exit_raw_mode()

            try:
                # Pipe mode: raw output for scripting (no formatting at all)
                pipe_mode = getattr(self.terminal_renderer, "pipe_mode", False)
                if pipe_mode:
                    if content.strip():
                        self._output_rendered(content, message_type)
                    return

                # Map message_type string to MessageType enum for filters
                msg_type_map = {
                    "system": MessageType.SYSTEM,
                    "assistant": MessageType.ASSISTANT,
                    "user": MessageType.USER,
                    "error": MessageType.ERROR,
                    "info": MessageType.INFO,
                    "debug": MessageType.DEBUG,
                }

                # Apply display filters for non-tool messages
                filtered_content = content
                if message_type in msg_type_map:
                    filtered_content = DisplayFilterRegistry.apply_filters(
                        content, msg_type_map[message_type]
                    )
                    if filtered_content is None:
                        filtered_content = content

                # Route to renderer based on message type
                if message_type == "system":
                    if not filtered_content.strip():
                        return
                    display_type = kwargs.get("display_type", "info")
                    if display_type == "warning":
                        rendered = self.renderer.warning_block(filtered_content)
                    elif display_type == "error":
                        rendered = self.renderer.error_block("Error", filtered_content)
                    elif display_type == "success":
                        rendered = self.renderer.success_block(filtered_content)
                    else:
                        rendered = self.renderer.info_block(filtered_content)
                    self._output_rendered(rendered, "system")

                elif message_type == "assistant":
                    if filtered_content.strip():
                        lines = filtered_content.split("\n")
                        rendered = self.renderer.response_block(lines)
                        self._output_rendered(rendered, "assistant")

                elif message_type == "user":
                    rendered = self.renderer.user_message(filtered_content)
                    self._output_rendered(rendered, "user")

                elif message_type == "error":
                    rendered = self.renderer.error_block("Error", filtered_content)
                    self._output_rendered(rendered, "error")

                elif message_type in ("info", "debug"):
                    rendered = self.renderer.info_block(filtered_content)
                    self._output_rendered(rendered, "system")

                elif message_type == "tool":
                    tool_name = kwargs.get("tool_name", "")
                    tool_args = kwargs.get("tool_args", "")
                    tool_status = kwargs.get("tool_status", "success")
                    result_summary = kwargs.get("result_summary", None)
                    if tool_name:
                        rendered = self.renderer.tool_call(
                            tool_name,
                            tool_args,
                            tool_status,
                            result_summary=result_summary,
                        )
                        self._output_rendered(rendered, "tool_call")
                    if content.strip():
                        filtered_content = DisplayFilterRegistry.apply_filters(
                            content, MessageType.ASSISTANT
                        )
                        if filtered_content is None:
                            filtered_content = content
                        if filtered_content.strip():
                            should_wrap = tool_name == "capture"
                            rendered = self.renderer.tool_result(
                                filtered_content.split("\n"), wrap=should_wrap
                            )
                            self._output_rendered(rendered, "tool_result")

                elif message_type == "agent":
                    agent_color = kwargs.get("agent_color")
                    tag_char = kwargs.get("tag_char", " > ")
                    observing = kwargs.get("observing", False)
                    if hasattr(self.renderer, "agent_message"):
                        rendered = self.renderer.agent_message(
                            filtered_content,
                            agent_color=agent_color,
                            tag_char=tag_char,
                            observing=observing,
                        )
                    else:
                        rendered = self.renderer.info_block(filtered_content)
                    self._output_rendered(rendered, "agent")

                else:
                    logger.warning(f"Unknown message type: {message_type}")
                    filtered_content = DisplayFilterRegistry.apply_filters(
                        content, MessageType.ASSISTANT
                    )
                    if filtered_content is None:
                        filtered_content = content
                    rendered = self.renderer.assistant_message(filtered_content)
                    self._output_rendered(rendered, "assistant")

            finally:
                if not in_alt and was_raw:
                    terminal_state.enter_raw_mode()

        except Exception as e:
            logger.error(f"Error displaying {message_type} message: {e}")
            try:
                self._output_rendered(f"[{message_type.upper()}] {content}", "error")
            except Exception:
                logger.error("Critical: Failed to display message even with fallback")

    # === Buffer Transition Management ===
    # These methods handle state preservation during modal/fullscreen transitions

    def enter_alternate_buffer(self) -> None:
        """Mark entering alternate buffer and pause render loop.

        Call this BEFORE opening a modal or entering fullscreen mode.
        Captures current render state for potential restoration.
        Messages arriving while in alternate buffer are buffered and
        flushed on exit.
        """
        if self._in_alternate_buffer:
            logger.warning("Already in alternate buffer")
            return

        # Capture state BEFORE modifying anything
        self._saved_main_buffer_state = self._capture_render_state()
        logger.debug(f"Captured render state: {self._saved_main_buffer_state}")

        self._in_alternate_buffer = True
        self._away_start_time = time.monotonic()
        # Prevent render loop interference during modal
        self.terminal_renderer.writing_messages = True
        logger.debug("Entered alternate buffer mode (message buffering active)")

    def exit_alternate_buffer(self, restore_state: bool = False) -> None:
        """Exit alternate buffer mode and reset render state.

        Call this AFTER closing a modal or exiting fullscreen mode.
        Flushes any messages that were buffered during the session.

        Args:
            restore_state: If True, restore captured state. If False (default),
                          reset to clean state for fresh input rendering.
        """
        if not self._in_alternate_buffer:
            logger.warning("Not in alternate buffer")
            return

        self._in_alternate_buffer = False

        if restore_state and self._saved_main_buffer_state:
            # Restore previously captured state
            self.terminal_renderer.writing_messages = self._saved_main_buffer_state[
                "writing_messages"
            ]
            self.terminal_renderer.input_line_written = self._saved_main_buffer_state[
                "input_line_written"
            ]
            self.terminal_renderer.last_line_count = self._saved_main_buffer_state[
                "last_line_count"
            ]
            logger.debug(f"Restored render state: {self._saved_main_buffer_state}")
        else:
            # Reset to clean state (default - prevents duplicate input boxes)
            self.terminal_renderer.writing_messages = False
            self.terminal_renderer.input_line_written = False
            self.terminal_renderer.last_line_count = 0
            logger.debug("Reset to clean render state")

        # Flush buffered messages before resuming normal rendering
        self._flush_buffered_output()

        # Always invalidate cache after buffer transition
        self.terminal_renderer.invalidate_render_cache()
        self._saved_main_buffer_state = None

    def get_saved_state(self) -> Optional[Dict[str, Any]]:
        """Get the saved render state (for debugging).

        Returns:
            Saved state dict if in alternate buffer, None otherwise.
        """
        return self._saved_main_buffer_state

    # These methods integrate with status navigation system to prevent render conflicts

    def set_navigation_active(self, active: bool) -> None:
        """Set navigation active state (pauses message rendering).

        This is called by StatusNavigationManager to prevent LLM streaming
        and message display from interfering with navigation UI.

        Args:
            active: True when navigation mode is active, False when exiting
        """
        self.navigation_active = active
        logger.debug(f"Navigation active set to: {active}")

    def set_render_loop(self, render_loop) -> None:
        """Set the render loop for triggering renders after message display.

        Args:
            render_loop: EventDrivenRenderLoop instance
        """
        self._render_loop = render_loop
        logger.debug("Render loop set for message coordinator")

    def is_writing_messages(self) -> bool:
        """Check if currently writing messages or navigation is active.

        This provides a unified check for systems that need to know if
        message display is in progress or blocked (e.g., navigation mode).

        Returns:
            True if terminal renderer is writing messages or navigation is active
        """
        return self.terminal_renderer.writing_messages or self.navigation_active
