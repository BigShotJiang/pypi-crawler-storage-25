"""kollabor-events: Event bus and hook system for Kollabor."""

from .bus import EventBus
from .data_models import (
    ConversationMessage,
    ConversationMetadata,
    SessionMetadata,
    SessionSummary,
)
from .dict_utils import (
    deep_merge,
    flatten_dict,
    merge_multiple,
    safe_get,
    safe_set,
    unflatten_dict,
)
from .error_utils import (
    ErrorAccumulator,
    handle_startup_errors,
    log_and_continue,
    retry_on_failure,
    safe_execute,
    safe_execute_async,
    validate_and_log,
)
from .executor import HookExecutor
from .hook_adapter import HookAdapter
from .models import (
    CommandCategory,
    CommandDefinition,
    CommandMode,
    CommandResult,
    Event,
    EventType,
    Hook,
    HookPriority,
    HookStatus,
    ParameterDefinition,
    SlashCommand,
    SubcommandInfo,
    UIConfig,
)
from .processor import EventProcessor
from .ready_message import ReadyMessageCollector, ReadyMessageItem
from .registry import HookRegistry

__all__ = [
    "EventBus",
    "Event",
    "EventType",
    "Hook",
    "HookStatus",
    "HookPriority",
    "CommandMode",
    "CommandCategory",
    "UIConfig",
    "ParameterDefinition",
    "SubcommandInfo",
    "CommandDefinition",
    "SlashCommand",
    "CommandResult",
    "HookRegistry",
    "HookExecutor",
    "EventProcessor",
    "HookAdapter",
    "ReadyMessageItem",
    "ReadyMessageCollector",
    # Data models
    "ConversationMessage",
    "SessionMetadata",
    "SessionSummary",
    "ConversationMetadata",
    # Dict utils
    "deep_merge",
    "safe_get",
    "safe_set",
    "merge_multiple",
    "flatten_dict",
    "unflatten_dict",
    # Error utils
    "log_and_continue",
    "safe_execute",
    "safe_execute_async",
    "retry_on_failure",
    "ErrorAccumulator",
    "handle_startup_errors",
    "validate_and_log",
]
