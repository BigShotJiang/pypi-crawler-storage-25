"""Turn runner - executes one full LLM turn and emits SSE events."""

import asyncio
import logging
import time
from typing import Any, AsyncGenerator, Dict, List

from . import sse
from .session import EngineSession

logger = logging.getLogger(__name__)

MAX_AGENTIC_TURNS = 20  # prevent runaway loops


class TurnRunner:
    """
    Runs a full multi-turn LLM conversation loop for one user message.
    Produces SSE events via asyncio.Queue.

    The pattern:
      1. Add user message to history
      2. Call LLM (streaming tokens → SSE)
      3. Parse tool calls from response
      4. Execute each tool (permission check may pause → SSE)
      5. If stop_reason == tool_use: loop back
      6. Otherwise: turn_complete
    """

    async def run(
        self, session: EngineSession, message: str
    ) -> AsyncGenerator[Dict, None]:
        """
        Run a turn. Yields SSE event dicts.
        Uses an internal queue so producer (turn logic) and consumer (SSE)
        can run concurrently via asyncio.
        """
        queue: asyncio.Queue = asyncio.Queue()

        # Wire the queue into the session so permission_callback can emit to it
        session._sse_queue = queue

        # Run turn logic as a background task
        task = asyncio.create_task(self._run_turn(session, message, queue))
        session._active_turn_task = task

        try:
            while True:
                event = await queue.get()
                if event is None:  # sentinel - turn finished
                    break
                yield event
        finally:
            session._sse_queue = None
            session._active_turn_task = None
            if not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass

    async def _run_turn(
        self,
        session: EngineSession,
        message: str,
        queue: asyncio.Queue,
    ) -> None:
        """Producer: runs the full turn loop, puts events to queue."""
        total_input_tokens = 0
        total_output_tokens = 0
        total_tool_calls = 0
        stop_reason = "end_turn"

        try:
            # Add user message to history
            session.history.append({"role": "user", "content": message})

            for turn_num in range(MAX_AGENTIC_TURNS):
                logger.debug(
                    f"Session {session.session_id}: agentic turn {turn_num + 1}"
                )

                # Build streaming token callback
                async def token_callback(chunk: str):
                    await queue.put(sse.token(session.session_id, chunk))

                # Get available tools
                tools = await session.get_tools()

                # Debug: log what we're about to send to LLM
                import sys

                print("[ENGINE-DEBUG] Calling LLM with:", file=sys.stderr)
                print(
                    f"[ENGINE-DEBUG]   profile.provider={session.profile.provider}",
                    file=sys.stderr,
                )
                print(
                    f"[ENGINE-DEBUG]   profile.model={session.profile.get_model()}",
                    file=sys.stderr,
                )
                print(
                    f"[ENGINE-DEBUG]   profile.base_url={session.profile.base_url or '(empty)'}",
                    file=sys.stderr,
                )
                print(
                    f"[ENGINE-DEBUG]   history_length={len(session.history)}",
                    file=sys.stderr,
                )
                print(
                    f"[ENGINE-DEBUG]   tools_count={len(tools) if tools else 0}",
                    file=sys.stderr,
                )

                # Call LLM (streaming)
                response_text = await session.api_service.call_llm(
                    conversation_history=session.history,
                    streaming_callback=token_callback,
                    tools=tools,
                )

                # Emit thinking content if present
                if session.api_service.last_thinking_content:
                    await queue.put(
                        sse.thinking(
                            session.session_id,
                            session.api_service.last_thinking_content,
                        )
                    )

                # Accumulate token usage
                usage = session.api_service.last_token_usage
                total_input_tokens += usage.get("prompt_tokens", 0)
                total_output_tokens += usage.get("completion_tokens", 0)

                stop_reason = session.api_service.last_stop_reason or "end_turn"
                tool_calls = session.api_service.last_tool_calls or []

                # Add assistant response to history
                assistant_content = self._build_assistant_content(
                    response_text, tool_calls
                )
                session.history.append(
                    {"role": "assistant", "content": assistant_content}
                )

                # No tool calls → turn done
                if not tool_calls:
                    break

                # Execute each tool
                tool_results = []
                for tool_call in tool_calls:
                    result = await self._execute_tool(session, tool_call, queue)
                    tool_results.append(result)
                    total_tool_calls += 1

                # Add tool results to history
                self._add_tool_results_to_history(session, tool_results)

                # If stop was end_turn (not tool_use), we're done
                if stop_reason != "tool_use":
                    break

            # Turn complete
            session.total_turns += 1
            session.total_input_tokens += total_input_tokens
            session.total_output_tokens += total_output_tokens

            await queue.put(
                sse.turn_complete(
                    session_id=session.session_id,
                    input_tokens=total_input_tokens,
                    output_tokens=total_output_tokens,
                    tool_calls=total_tool_calls,
                    stop_reason=stop_reason,
                )
            )

        except asyncio.CancelledError:
            await queue.put(
                sse.error(
                    session_id=session.session_id,
                    code="cancelled",
                    message="Turn cancelled by user",
                )
            )
        except Exception as e:
            logger.exception(f"Session {session.session_id}: turn error: {e}")
            code = _classify_error(e)

            # Include full error details for debugging
            error_msg = str(e)
            error_type = type(e).__name__

            # Build detailed error message for SSE
            sse_msg = f"{error_type}: {error_msg}"
            if hasattr(e, "provider"):
                sse_msg += f" [provider={e.provider}]"
            if hasattr(e, "error_code"):
                sse_msg += f" [code={e.error_code}]"
            if hasattr(e, "original_error"):
                sse_msg += f" [original={type(e.original_error).__name__}: {str(e.original_error)}]"

            import sys

            print(f"[ENGINE-ERROR] {sse_msg}", file=sys.stderr)
            sys.stderr.flush()

            await queue.put(
                sse.error(
                    session_id=session.session_id,
                    code=code,
                    message=sse_msg,
                    retryable=code in ("rate_limit", "timeout"),
                )
            )
        finally:
            await queue.put(None)  # sentinel

    async def _execute_tool(
        self,
        session: EngineSession,
        tool_call: Dict[str, Any],
        queue: asyncio.Queue,
    ) -> Dict[str, Any]:
        """Execute one tool call, emitting tool_start and tool_result events."""
        tool_id = tool_call.get("id", "")
        tool_name = tool_call.get("name", tool_call.get("type", "unknown"))
        tool_type = tool_call.get("type", "unknown")
        tool_input = tool_call.get("input", tool_call.get("arguments", {}))

        await queue.put(
            sse.tool_start(
                session_id=session.session_id,
                tool_id=tool_id,
                tool_name=tool_name,
                tool_type=tool_type,
                input=tool_input,
            )
        )

        start = time.monotonic()
        result = await session.tool_executor.execute_tool(tool_call)
        elapsed = time.monotonic() - start

        await queue.put(
            sse.tool_result(
                session_id=session.session_id,
                tool_id=tool_id,
                tool_name=tool_name,
                success=result.success,
                output=result.output,
                error=result.error,
                execution_time=elapsed,
                metadata=result.metadata,
            )
        )

        return {
            "tool_id": tool_id,
            "tool_call": tool_call,
            "result": result,
        }

    def _build_assistant_content(self, text: str, tool_calls: List[Dict]) -> Any:
        """
        Build assistant message content.
        For Anthropic: list of content blocks.
        For simple cases: plain string.
        """
        if not tool_calls:
            return text

        content = []
        if text:
            content.append({"type": "text", "text": text})
        for tc in tool_calls:
            content.append(
                {
                    "type": "tool_use",
                    "id": tc.get("id", ""),
                    "name": tc.get("name", tc.get("type", "")),
                    "input": tc.get("input", tc.get("arguments", {})),
                }
            )
        return content

    def _add_tool_results_to_history(
        self,
        session: EngineSession,
        tool_results: List[Dict],
    ) -> None:
        """Add tool results as a user message with tool_result content blocks."""
        if not tool_results:
            return

        content = []
        for tr in tool_results:
            tool_call = tr["tool_call"]
            result = tr["result"]
            content.append(
                {
                    "type": "tool_result",
                    "tool_use_id": tool_call.get("id", ""),
                    "content": (
                        result.output if result.success else f"Error: {result.error}"
                    ),
                    "is_error": not result.success,
                }
            )

        session.history.append({"role": "user", "content": content})


def _classify_error(exc: Exception) -> str:
    msg = str(exc).lower()
    if "rate limit" in msg or "429" in msg:
        return "rate_limit"
    if "auth" in msg or "401" in msg or "403" in msg:
        return "auth_error"
    if "context" in msg and ("length" in msg or "window" in msg):
        return "context_exceeded"
    if "timeout" in msg:
        return "timeout"
    return "internal"
