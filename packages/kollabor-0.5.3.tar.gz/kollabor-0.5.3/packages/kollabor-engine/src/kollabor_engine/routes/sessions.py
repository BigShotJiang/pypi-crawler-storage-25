"""Session lifecycle routes."""

import logging
import re
import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException  # type: ignore[import-not-found]
from pydantic import BaseModel

from kollabor_ai import LLMProfile

from ..server import get_session_registry
from ..session import EngineSession

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/sessions", tags=["sessions"])

# Pattern to detect <trender> tags (security: block user-controlled dynamic content)
# Matches: <trender>...</trender> and <trender type="..." ... />
TRENDER_PATTERN = re.compile(
    r"<trender\b[^>]*>.*?</trender>|<trender\b[^>]*/?>", re.DOTALL | re.IGNORECASE
)


class Credentials(BaseModel):
    """Raw API credentials - used when caller manages its own LLM profiles."""

    provider: str = "anthropic"
    api_key: str
    model: str
    base_url: str = ""
    max_tokens: Optional[int] = None


class CreateSessionRequest(BaseModel):
    profile: str = "default"
    system_prompt: Optional[str] = None
    workspace: Optional[str] = None
    approval_mode: str = "confirm_all"
    mcp_servers: List[str] = []
    metadata: dict = {}
    credentials: Optional[Credentials] = None


def _sanitize_system_prompt(prompt: Optional[str]) -> Optional[str]:
    """Sanitize user-provided system prompt to block command injection.

    Blocks <trender> tags which could execute arbitrary shell commands.
    Replaces them with a safe placeholder string.

    Args:
        prompt: User-provided system prompt string

    Returns:
        Sanitized prompt with trender tags replaced, or None if input is None
    """
    if not prompt:
        return prompt

    # Check for trender tags and replace with safe placeholder
    if TRENDER_PATTERN.search(prompt):
        logger.warning(
            "Blocked <trender> tags in user-provided system prompt (command injection prevention)"
        )
        return TRENDER_PATTERN.sub("[dynamic content removed for security]", prompt)

    return prompt


@router.post("")
async def create_session(body: CreateSessionRequest):
    registry = get_session_registry()

    # Sanitize user-provided system prompt to block command injection
    safe_system_prompt = _sanitize_system_prompt(body.system_prompt)

    # Load profile from credentials or ProfileManager
    profile: Optional[LLMProfile] = None

    if body.credentials:

        creds = body.credentials

        # For custom provider, send the URL as-is (user provides full path)
        # For openai/anthropic, strip /chat/completions since SDK appends it
        base_url = creds.base_url or ""

        # Debug: log received credentials
        import sys

        print("[ENGINE-DEBUG] Creating session with credentials:", file=sys.stderr)
        print(f"[ENGINE-DEBUG]   provider={creds.provider}", file=sys.stderr)
        print(f"[ENGINE-DEBUG]   model={creds.model}", file=sys.stderr)
        print(f"[ENGINE-DEBUG]   base_url={base_url}", file=sys.stderr)
        print(f"[ENGINE-DEBUG]   max_tokens={creds.max_tokens}", file=sys.stderr)
        print(
            f"[ENGINE-DEBUG]   api_key=sk-*** (length={len(creds.api_key)})",
            file=sys.stderr,
        )

        profile = LLMProfile(
            name="app-inline",
            provider=creds.provider,
            model=creds.model,
            api_key=creds.api_key,
            base_url=base_url,
            max_tokens=creds.max_tokens,
            streaming=True,
            supports_tools=True,
        )
    else:
        from kollabor_ai import ProfileManager

        pm = ProfileManager()
        profile = pm.get_profile(body.profile)
        if not profile:
            raise HTTPException(
                status_code=404, detail=f"Profile '{body.profile}' not found"
            )
        assert profile is not None  # narrowed by raise above

    session_id = f"sess_{uuid.uuid4().hex[:12]}"
    session = EngineSession(
        session_id=session_id,
        profile=profile,
        approval_mode=body.approval_mode,
        workspace=body.workspace,
        system_prompt=safe_system_prompt,
        mcp_server_names=body.mcp_servers,
    )
    ok = await session.initialize()
    if not ok:
        logger.warning(f"Session {session_id} initialized with provider errors")

    registry[session_id] = session
    logger.info(f"Session {session_id} created")
    return session.to_dict()


@router.get("")
async def list_sessions():
    registry = get_session_registry()
    return {"sessions": [s.to_dict() for s in registry.values()]}


@router.get("/{session_id}")
async def get_session(session_id: str):
    registry = get_session_registry()
    session = registry.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session.to_dict()


@router.delete("/{session_id}")
async def delete_session(session_id: str):
    registry = get_session_registry()
    session = registry.pop(session_id, None)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    await session.shutdown()
    return {"ok": True, "session_id": session_id}


@router.get("/{session_id}/history")
async def get_history(session_id: str, limit: Optional[int] = None):
    registry = get_session_registry()
    session = registry.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    history = session.history
    if limit:
        history = history[-limit:]
    return {"session_id": session_id, "history": history}


@router.delete("/{session_id}/history")
async def clear_history(session_id: str):
    registry = get_session_registry()
    session = registry.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    # Keep system prompt if present
    if session.history and session.history[0].get("role") == "system":
        session.history = session.history[:1]
    else:
        session.history = []

    return {"ok": True, "session_id": session_id}


@router.get("/{session_id}/system-prompt")
async def get_system_prompt(session_id: str):
    registry = get_session_registry()
    session = registry.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    # Return session.system_prompt if set, otherwise extract from history
    prompt = session.system_prompt
    if not prompt and session.history and session.history[0].get("role") == "system":
        prompt = session.history[0].get("content", "")

    return {"session_id": session_id, "system_prompt": prompt or ""}


@router.post("/{session_id}/system-prompt/rebuild")
async def rebuild_system_prompt(session_id: str):
    """Rebuild system prompt by rendering <trender> tags.

    Security note: Only renders prompts that were set at session creation time
    (which have already been sanitized). User-provided trender tags are blocked.
    """
    registry = get_session_registry()
    session = registry.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    # Check if a turn is in progress - warn about potential race condition
    if session._active_turn_task and not session._active_turn_task.done():
        logger.warning(
            f"Session {session_id}: rebuild_system_prompt called during active turn. "
            "History modification may cause inconsistent state."
        )

    # Get raw prompt
    raw_prompt = session.system_prompt or ""
    if (
        not raw_prompt
        and session.history
        and session.history[0].get("role") == "system"
    ):
        raw_prompt = session.history[0].get("content", "")

    if not raw_prompt:
        return {"session_id": session_id, "system_prompt": ""}

    # Render using prompt_renderer if available with comprehensive exception handling
    rendered = raw_prompt  # Fallback to original if rendering fails
    try:
        from kollabor_ai.prompt_renderer import render_system_prompt

        # Wrap render in try/except for all possible exceptions
        rendered = render_system_prompt(raw_prompt, timeout=5)

    except ImportError:
        # Fallback: simple regex replacement for <trender> tags
        import re

        rendered = re.sub(
            r"<trender>.*?</trender>", "[command output]", raw_prompt, flags=re.DOTALL
        )
        rendered = re.sub(
            r'<trender\s+type="[^"]*"[^>]*/>', "[included content]", rendered
        )
        logger.info(
            f"Session {session_id}: prompt_renderer not available, used regex fallback"
        )

    except Exception as e:
        # Log error but don't crash - return original prompt
        logger.error(
            f"Session {session_id}: failed to render system prompt: {type(e).__name__}: {e}"
        )
        # Keep original prompt, don't update storage/history
        return {
            "session_id": session_id,
            "system_prompt": raw_prompt,
            "warning": f"Rendering failed: {type(e).__name__}",
        }

    # Update storage and history
    session.system_prompt = rendered
    if session.history and session.history[0].get("role") == "system":
        session.history[0]["content"] = rendered

    return {"session_id": session_id, "system_prompt": rendered}


# Session-specific MCP endpoints
# These are in the sessions router (not mcp router) to avoid double /mcp prefix


@router.get("/{session_id}/mcp")
async def get_session_mcp(session_id: str):
    """Get MCP connection status for a specific session."""
    registry = get_session_registry()
    session = registry.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    mcp = session.mcp_integration
    connections = mcp.server_connections
    tools = mcp.tool_registry

    result: Dict[str, Any] = {"session_id": session_id, "servers": {}}

    for server_name, server_config in mcp.mcp_servers.items():
        conn = connections.get(server_name)
        server_tools = [
            name for name, info in tools.items() if info.get("server") == server_name
        ]

        if conn and conn.initialized:
            result["servers"][server_name] = {
                "status": "connected",
                "tool_count": len(server_tools),
                "tools": server_tools,
            }
        elif server_config.get("enabled", True):
            result["servers"][server_name] = {
                "status": "disconnected",
                "error": "Connection not attempted or failed",
            }
        else:
            result["servers"][server_name] = {
                "status": "disconnected",
                "error": "Server disabled in configuration",
            }

    result["total_tools"] = len(tools)
    return result


@router.post("/{session_id}/mcp/{server_name}/connect")
async def connect_server(session_id: str, server_name: str):
    """Connect to an MCP server for a specific session."""
    registry = get_session_registry()
    session = registry.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    mcp = session.mcp_integration

    if server_name not in mcp.mcp_servers:
        raise HTTPException(
            status_code=404,
            detail=f"MCP server '{server_name}' not found in configuration",
        )

    if server_name in mcp.server_connections:
        conn = mcp.server_connections[server_name]
        if conn.initialized:
            raise HTTPException(
                status_code=409, detail=f"Server '{server_name}' is already connected"
            )

    server_config = mcp.mcp_servers[server_name]
    if not server_config.get("enabled", True):
        raise HTTPException(
            status_code=400, detail=f"Server '{server_name}' is disabled"
        )

    # Trigger async connection
    return {
        "ok": True,
        "server_name": server_name,
        "status": "connecting",
        "session_id": session_id,
    }


@router.post("/{session_id}/mcp/{server_name}/disconnect")
async def disconnect_server(session_id: str, server_name: str):
    """Disconnect from an MCP server for a session."""
    registry = get_session_registry()
    session = registry.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    mcp = session.mcp_integration

    if server_name not in mcp.server_connections:
        raise HTTPException(
            status_code=404, detail=f"No active connection to '{server_name}'"
        )

    # Count tools to be removed
    tools_to_remove = [
        name
        for name, info in mcp.tool_registry.items()
        if info.get("server") == server_name
    ]

    # Close connection
    await mcp.server_connections[server_name].close()
    del mcp.server_connections[server_name]

    # Remove tools
    for tool_name in tools_to_remove:
        del mcp.tool_registry[tool_name]

    return {
        "ok": True,
        "server_name": server_name,
        "status": "disconnected",
        "tools_removed": len(tools_to_remove),
        "session_id": session_id,
    }


@router.get("/{session_id}/mcp/{server_name}/tools")
async def list_server_tools(session_id: str, server_name: str):
    """List tools provided by a connected MCP server."""
    registry = get_session_registry()
    session = registry.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    mcp = session.mcp_integration

    tools = []
    for tool_name, tool_info in mcp.tool_registry.items():
        if tool_info.get("server") == server_name:
            definition = tool_info.get("definition", {})
            tools.append(
                {
                    "name": tool_name,
                    "description": definition.get("description", ""),
                    "parameters": definition.get(
                        "parameters", definition.get("inputSchema", {})
                    ),
                }
            )

    return {
        "server_name": server_name,
        "status": "connected" if tools else "disconnected",
        "tools": tools,
        "total": len(tools),
    }


@router.get("/{session_id}/mcp/{server_name}/status")
async def get_server_status(session_id: str, server_name: str):
    """Get detailed status of a single MCP server connection."""
    registry = get_session_registry()
    session = registry.get(session_id)

    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    mcp = session.mcp_integration
    conn = mcp.server_connections.get(server_name)

    server_tools = [
        name
        for name, info in mcp.tool_registry.items()
        if info.get("server") == server_name
    ]

    if conn and conn.initialized:
        return {
            "server_name": server_name,
            "status": "connected",
            "connected_at": None,
            "uptime_seconds": 0,
            "tool_count": len(server_tools),
            "tools": server_tools,
            "process": {
                "pid": conn.process.pid if conn.process else None,
                "command": conn.command,
            },
            "error": None,
        }
    else:
        mcp.mcp_servers.get(server_name, {})
        return {
            "server_name": server_name,
            "status": "disconnected",
            "error": "Not connected",
            "connected_at": None,
            "uptime_seconds": 0,
            "tool_count": 0,
            "tools": [],
        }
