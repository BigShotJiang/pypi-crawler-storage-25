"""Slash command system for Kollabor CLI."""
