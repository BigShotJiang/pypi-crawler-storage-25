"""Core components for Kollabor CLI."""

from .version import __version__

__all__ = ["__version__"]
