"""Tests for the `agentberlin strategies` SDK resource and CLI command.

Covers default `list()` (full catalog), the `shortlist=True` narrowing, and
the corresponding `agentberlin strategies list [--shortlist ...]` CLI flag.
HTTP calls are stubbed via the `responses` library.
"""

import json

import pytest
import responses
from click.testing import CliRunner

from agentberlin import AgentBerlin
from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _strategy(id: str, name: str = "S", category: str = "c", intent: str = "monitor", summary: str = "sum") -> dict:
    return {
        "id": id,
        "name": name,
        "category": category,
        "intent": intent,
        "summary": summary,
        "required_capabilities": [],
        "applicable": {"business_models": [], "industries": []},
        "cadence": "weekly",
        "details": "do the thing",
        "created_by": "tester",
        "version": "1",
        "last_reviewed": "2026-04-23",
    }


class TestStrategiesResource:
    @responses.activate
    def test_list_default_posts_empty_body(self, mock_token):
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/strategies/list",
            json={"strategies": [_strategy("a"), _strategy("b")]},
            status=200,
        )

        client = AgentBerlin(token=mock_token)
        out = client.strategies.list()

        assert [s.id for s in out] == ["a", "b"]
        assert json.loads(responses.calls[0].request.body) == {}

    @responses.activate
    def test_list_shortlist_sends_flag_and_domain(self, mock_token):
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/strategies/list",
            json={"strategies": [_strategy("a")]},
            status=200,
        )

        client = AgentBerlin(token=mock_token)
        out = client.strategies.list(shortlist=True, project_domain="acme.test")

        assert [s.id for s in out] == ["a"]
        assert json.loads(responses.calls[0].request.body) == {
            "shortlist": True,
            "project_domain": "acme.test",
        }

    def test_list_shortlist_without_domain_raises(self, mock_token):
        client = AgentBerlin(token=mock_token)
        with pytest.raises(ValueError, match="project_domain"):
            client.strategies.list(shortlist=True)


class TestStrategiesListCLI:
    @responses.activate
    def test_default_renders_table(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/strategies/list",
            json={"strategies": [_strategy("alpha", name="Alpha")]},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["strategies", "list", "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "alpha" in result.output
        assert "Alpha" in result.output
        assert json.loads(responses.calls[0].request.body) == {}

    @responses.activate
    def test_shortlist_with_explicit_domain(self) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/strategies/list",
            json={"strategies": [_strategy("beta", name="Beta")]},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "strategies",
                "list",
                "--shortlist",
                "--project-domain",
                "acme.test",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "beta" in result.output
        assert json.loads(responses.calls[0].request.body) == {
            "shortlist": True,
            "project_domain": "acme.test",
        }

    def test_shortlist_without_domain_or_env_fails(self, monkeypatch) -> None:
        monkeypatch.delenv("PROJECT_DOMAIN", raising=False)
        # Stub session config so no saved domain leaks in.
        monkeypatch.setattr(
            "agentberlin.cli.load_session_config", lambda: {}
        )

        runner = CliRunner()
        result = runner.invoke(main, ["strategies", "list", "--shortlist", "--token", "t"])

        assert result.exit_code != 0
        assert "project domain" in result.output.lower()
