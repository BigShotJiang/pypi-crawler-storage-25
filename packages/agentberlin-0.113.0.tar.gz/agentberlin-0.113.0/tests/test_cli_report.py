"""Tests for the `agentberlin report` CLI subcommand group.

Covers manifest-shape validation, kind enforcement, id-writeback, and URL
routing across `apply`, `publish`, and `submit`. HTTP calls are stubbed via
the `responses` library so tests don't hit a real backend.
"""

import json
from pathlib import Path
from typing import Any

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _write_manifest(tmp_path: Path, data: dict[str, Any], name: str = "manifest.json") -> Path:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return path


def _read_manifest(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def _write(path: Path, text: str) -> Path:
    path.write_text(text)
    return path


def _html(tmp_path: Path, name: str = "index.html") -> Path:
    return _write(tmp_path / name, "<html><body>viewer</body></html>")


def _spec(tmp_path: Path, name: str = "spec.json") -> Path:
    return _write(tmp_path / name, json.dumps({"version": 1, "fields": []}))


def _data(tmp_path: Path, name: str = "data.json") -> Path:
    return _write(tmp_path / name, json.dumps({"score": 42}))


# ---------------------------------------------------------------------------
# report apply
# ---------------------------------------------------------------------------


class TestReportApply:
    @responses.activate
    def test_apply_without_id_creates_and_writes_back(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "slug": "audit",
                "name": "Audit",
                "description": "Weekly",
                "details": "Workflow X produces { rows: [...] }; render as a table.",
            },
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/index.html",
            },
            status=202,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "rpt_abc" in result.output
        assert "metadata applied" in result.output.lower()
        assert _read_manifest(manifest)["id"] == "rpt_abc"

        body = json.loads(responses.calls[0].request.body)
        assert body == {
            "slug": "audit",
            "project_domain": "example.com",
            "title": "Audit",
            "description": "Weekly",
            "details": "Workflow X produces { rows: [...] }; render as a table.",
        }

    @responses.activate
    def test_apply_with_id_patches_with_details(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "id": "rpt_abc",
                "slug": "audit",
                "details": "Workflow Y now produces a score field; surface it as a dial.",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/index.html",
            },
            status=202,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "metadata applied" in result.output.lower()
        body = json.loads(responses.calls[0].request.body)
        assert body["details"] == "Workflow Y now produces a score field; surface it as a dial."
        assert body["project_domain"] == "example.com"
        assert "slug" not in body

    @responses.activate
    def test_apply_with_id_metadata_only(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "id": "rpt_abc",
                "slug": "audit",
                "name": "New title",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/index.html",
            },
            status=200,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        body = json.loads(responses.calls[0].request.body)
        assert body["title"] == "New title"
        assert body["project_domain"] == "example.com"
        assert "details" not in body
        assert "description" not in body

    def test_apply_first_time_requires_details(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"kind": "report", "slug": "audit", "name": "Audit"}
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "details" in result.output.lower()

    def test_apply_rejects_manifest_without_slug(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"kind": "report", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "slug" in result.output.lower()

    def test_apply_rejects_manifest_with_schedule(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "slug": "audit",
                "details": "...",
                "schedule": {"type": "manual"},
            },
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "schedule" in result.output.lower()

    def test_apply_rejects_manifest_with_wrong_kind(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"kind": "workflow", "name": "X", "details": "..."}
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "kind" in result.output.lower()

    @responses.activate
    def test_apply_surfaces_409_duplicate(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {"kind": "report", "slug": "audit", "details": "x"},
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports",
            json={"error": "Report with slug 'audit' already exists. The manifest needs an 'id' to update an existing report."},
            status=409,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "already exists" in result.output


# ---------------------------------------------------------------------------
# report publish
# ---------------------------------------------------------------------------


def _publish_manifest(tmp_path: Path, slug: str = "audit", report_id: str = "rpt_abc") -> Path:
    return _write_manifest(
        tmp_path,
        {"kind": "report", "id": report_id, "slug": slug, "name": "Audit"},
    )


class TestReportPublish:
    @responses.activate
    def test_publish_uploads_html_and_spec_from_dir(self, tmp_path: Path) -> None:
        _html(tmp_path)
        _spec(tmp_path)
        manifest = _publish_manifest(tmp_path)

        responses.add(
            responses.PUT,
            f"{DEFAULT_BASE_URL}/reports/audit/layout",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/index.html",
            },
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        body = responses.calls[0].request.body
        assert b'name="file"' in body
        assert b'name="spec"' in body
        assert b"index.html" in body
        assert b"spec.json" in body
        assert b"example.com" in body  # project_domain field is part of the multipart body

    def test_publish_requires_id(self, tmp_path: Path) -> None:
        _html(tmp_path)
        _spec(tmp_path)
        manifest = _write_manifest(
            tmp_path, {"kind": "report", "slug": "audit"}, name="no_id.json"
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "id" in result.output.lower()

    def test_publish_errors_when_index_html_missing(self, tmp_path: Path) -> None:
        _spec(tmp_path)
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "index.html" in result.output

    def test_publish_errors_when_spec_json_missing(self, tmp_path: Path) -> None:
        _html(tmp_path)
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "publish",
                "-m",
                str(manifest),
                "--dir",
                str(tmp_path),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "spec.json" in result.output


# ---------------------------------------------------------------------------
# report submit
# ---------------------------------------------------------------------------


class TestReportSubmit:
    @responses.activate
    def test_submit_happy_path(self, tmp_path: Path) -> None:
        data = _data(tmp_path)
        manifest = _publish_manifest(tmp_path)
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/audit/submit",
            json={
                "success": True,
                "report_id": "rpt_abc",
                "url": "https://cdn/example.com/reports/audit/data.json",
            },
            status=200,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(data),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "audit" in result.output.lower()

    def test_submit_rejects_non_json(self, tmp_path: Path) -> None:
        bad = _write(tmp_path / "data.csv", "a,b\n1,2\n")
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(bad),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert ".json" in result.output

    def test_submit_rejects_invalid_json(self, tmp_path: Path) -> None:
        bad = _write(tmp_path / "data.json", "{not json")
        manifest = _publish_manifest(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(bad),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "valid JSON" in result.output or "not valid JSON" in result.output

    def test_submit_requires_id(self, tmp_path: Path) -> None:
        data = _data(tmp_path)
        manifest = _write_manifest(
            tmp_path, {"kind": "report", "slug": "audit"}, name="no_id.json"
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(data),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "id" in result.output.lower()

    @responses.activate
    def test_submit_surfaces_404(self, tmp_path: Path) -> None:
        data = _data(tmp_path)
        manifest = _publish_manifest(tmp_path, slug="missing")
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/missing/submit",
            json={"error": "not found"},
            status=404,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "submit",
                "-m",
                str(manifest),
                "--file",
                str(data),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "not found" in result.output.lower()


# ---------------------------------------------------------------------------
# report list / get
# ---------------------------------------------------------------------------


class TestReportList:
    @responses.activate
    def test_list_renders_markdown(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/list",
            json={
                "reports": [
                    {
                        "id": "rpt_abc",
                        "slug": "audit",
                        "name": "Audit Report",
                        "updated_at": "2025-04-01T00:00:00Z",
                    },
                    {"id": "rpt_def", "slug": "weekly"},
                ]
            },
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "list", "--project-domain", "example.com", "--token", "t"],
        )
        assert result.exit_code == 0, result.output
        assert "audit" in result.output
        assert "weekly" in result.output
        assert "Audit Report" in result.output

        body = json.loads(responses.calls[0].request.body)
        assert body == {"project_domain": "example.com"}


class TestReportGet:
    @responses.activate
    def test_get_writes_manifest_html_and_spec(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/get",
            json={
                "manifest": {
                    "kind": "report",
                    "id": "rpt_abc",
                    "slug": "audit",
                    "name": "Audit Report",
                    "details": "Render workflows table.",
                },
                "index_html": "<html><body>hi</body></html>",
                "spec": '{"fields": []}',
            },
            status=200,
        )

        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                main,
                [
                    "report",
                    "get",
                    "audit",
                    "--project-domain",
                    "example.com",
                    "--token",
                    "t",
                ],
            )
            assert result.exit_code == 0, result.output

            body = json.loads(responses.calls[0].request.body)
            assert body == {"project_domain": "example.com", "slug": "audit"}

            target = Path("reports") / "audit"
            manifest = json.loads((target / "manifest.json").read_text())
            assert manifest["slug"] == "audit"
            assert manifest["details"] == "Render workflows table."
            assert (target / "index.html").read_text().startswith("<html>")
            assert (target / "spec.json").read_text() == '{"fields": []}'

    @responses.activate
    def test_get_skips_missing_optional_files(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/get",
            json={
                "manifest": {
                    "kind": "report",
                    "id": "rpt_abc",
                    "slug": "audit",
                    "details": "First-time brief.",
                }
            },
            status=200,
        )

        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                main,
                [
                    "report",
                    "get",
                    "audit",
                    "--project-domain",
                    "example.com",
                    "--token",
                    "t",
                ],
            )
            assert result.exit_code == 0, result.output
            target = Path("reports") / "audit"
            assert (target / "manifest.json").is_file()
            assert not (target / "index.html").exists()
            assert not (target / "spec.json").exists()

    @responses.activate
    def test_get_404_friendly_error(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/get",
            json={"error": "Report not found"},
            status=404,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "get", "missing", "--project-domain", "example.com", "--token", "t"],
        )
        assert result.exit_code != 0
        assert "missing" in result.output

    @responses.activate
    def test_get_then_apply_round_trips(self, tmp_path: Path) -> None:
        """The manifest a `get` writes must round-trip through `apply`.

        On the PATCH path the apply payload drops `slug` (it goes in the URL)
        and requires at least one other changeable field — name, description,
        or details. A synthesized manifest with details satisfies that.
        """
        synthesized = {
            "kind": "report",
            "id": "rpt_abc",
            "slug": "audit",
            "name": "Audit Report",
            "details": "Render workflows table.",
        }
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/get",
            json={"manifest": synthesized},
            status=200,
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={"success": True, "report_id": "rpt_abc"},
            status=200,
        )

        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            r1 = runner.invoke(
                main,
                ["report", "get", "audit", "--project-domain", "example.com", "--token", "t"],
            )
            assert r1.exit_code == 0, r1.output
            manifest_path = Path("reports") / "audit" / "manifest.json"

            r2 = runner.invoke(
                main,
                [
                    "report",
                    "apply",
                    "-m",
                    str(manifest_path),
                    "--project-domain",
                    "example.com",
                    "--token",
                    "t",
                ],
            )
            assert r2.exit_code == 0, r2.output

            patch_call = next(c for c in responses.calls if c.request.method == "PATCH")
            # PATCH body is JSON — slug is in the URL; title from name; details preserved.
            body = json.loads(patch_call.request.body)
            assert body == {
                "project_domain": "example.com",
                "title": "Audit Report",
                "details": "Render workflows table.",
            }
