"""Wenyan（文言）語言的 Python 實作。

目前包含：
  - 詞法分析（`詞法分析器`）
  - 文言數字轉換（`漢字數字`）
  - Wenyan AST（語法樹）與 Python AST 轉譯（見 `AST_SPEC.md`）
"""

import ast
import importlib
import importlib.abc
import importlib.util
import keyword
import os
import re
import sys
from bisect import bisect_right
from dataclasses import dataclass
from functools import lru_cache
from typing import Callable, Iterator, NoReturn, TypeVar, cast

__all__ = [
    "詞法分析器",
    "漢字數字",
    "漢字變數字",
    "主術",
    "自舉主術",
    "安裝文言匯入鉤子",
    "卸載文言匯入鉤子",
    "載入文言模組",
    "符號",
    "文法之禍",
    "文法錯誤",
    # AST / 轉譯（MVP）
    "程式",
    "句",
    "值",
    "名值",
    "言值",
    "數值",
    "爻值",
    "其值",
    "其餘值",
    "宣告句",
    "初始化句",
    "命名句",
    "匯入句",
    "術參數",
    "術定義句",
    "施句",
    "以施句",
    "取句",
    "返回句",
    "列充句",
    "列銜句",
    "物屬性",
    "物定義句",
    "書之句",
    "噫句",
    "算術句",
    "變句",
    "夫句",
    "之句",
    "之長句",
    "昔今句",
    "若句",
    "恆為是句",
    "為是遍句",
    "乃止句",
    "乃止是遍句",
    "凡句",
    "試句",
    "捕捉子句",
    "擲句",
    "註釋句",
    "宏句",
    "文法分析器",
    "解析",
    "轉譯為PythonAST",
    "編譯為PythonAST",
]
版本號 = "0.1.0"


def _尋文言檔(
    模組全名: str, 路徑列: list[str] | None = None
) -> tuple[str, bool] | None:
    片段 = 模組全名.split(".")
    if not 片段:
        return None
    搜尋列: list[str] = []
    if 路徑列 is None:
        for 路 in sys.path:
            if isinstance(路, str):
                搜尋列.append(路)
        相對路 = os.path.join(*片段)
    else:
        搜尋列 = [路 for 路 in 路徑列 if isinstance(路, str)]
        相對路 = 片段[-1]

    for 基 in 搜尋列:
        模組檔 = os.path.abspath(os.path.join(基, f"{相對路}.wy"))
        if os.path.isfile(模組檔):
            return 模組檔, False
        套件檔 = os.path.abspath(os.path.join(基, 相對路, "序.wy"))
        if os.path.isfile(套件檔):
            return 套件檔, True
    return None


class 文言模組載者(importlib.abc.Loader):
    def __init__(self, 檔路徑: str, 為套件: bool) -> None:
        self._檔路徑 = 檔路徑
        self._為套件 = 為套件

    def create_module(self, 規格: object) -> None:
        return None

    def exec_module(self, 模組: object) -> None:
        if not hasattr(模組, "__dict__"):
            raise TypeError("模組物件缺少 __dict__")
        with open(self._檔路徑, "r", encoding="utf-8") as 檔案:
            內容 = 檔案.read()
        模組樹 = 編譯為PythonAST(內容, self._檔路徑)
        程式碼 = compile(模組樹, self._檔路徑, "exec")
        作用域 = cast(dict[str, object], 模組.__dict__)
        作用域["__file__"] = self._檔路徑
        模組名 = cast(str, getattr(模組, "__name__"))
        if self._為套件:
            作用域["__package__"] = 模組名
            作用域["__path__"] = [os.path.dirname(self._檔路徑)]
        else:
            作用域["__package__"] = 模組名.rpartition(".")[0]
        exec(程式碼, 作用域, 作用域)


class 文言模組尋者(importlib.abc.MetaPathFinder):
    def find_spec(
        self,
        全名: str,
        路徑: object = None,
        目標: object = None,
    ) -> importlib.machinery.ModuleSpec | None:
        路徑列: list[str] | None
        if 路徑 is None:
            路徑列 = None
        else:
            路徑列 = [路 for 路 in cast(list[object], 路徑) if isinstance(路, str)]
        命中 = _尋文言檔(全名, 路徑列)
        if 命中 is None:
            return None
        檔路徑, 為套件 = 命中
        載者 = 文言模組載者(檔路徑, 為套件)
        規格 = importlib.util.spec_from_loader(
            全名, 載者, origin=檔路徑, is_package=為套件
        )
        if 規格 is None:
            return None
        if 為套件:
            規格.submodule_search_locations = [os.path.dirname(檔路徑)]
        return 規格


def 安裝文言匯入鉤子() -> None:
    for 尋者 in sys.meta_path:
        if isinstance(尋者, 文言模組尋者):
            return
    sys.meta_path.insert(0, 文言模組尋者())


def 卸載文言匯入鉤子() -> None:
    sys.meta_path[:] = [
        尋者 for 尋者 in sys.meta_path if not isinstance(尋者, 文言模組尋者)
    ]


def 載入文言模組(模組名: str) -> object:
    安裝文言匯入鉤子()
    return importlib.import_module(模組名)


忽略符號 = frozenset({"。", "、", "，", "矣", " ", "\t", "\n", "\r", "　"})

數字對照: dict[str, int] = {
    "零": 0,
    "〇": 0,
    "一": 1,
    "二": 2,
    "三": 3,
    "四": 4,
    "五": 5,
    "六": 6,
    "七": 7,
    "八": 8,
    "九": 9,
}

小單位: dict[str, int] = {"十": 10, "百": 100, "千": 1000}

大單位: dict[str, int] = {
    "萬": 10**4,
    "億": 10**8,
    "兆": 10**12,
    "京": 10**16,
    "垓": 10**20,
    "秭": 10**24,
    "穰": 10**28,
    "溝": 10**32,
    "澗": 10**36,
    "正": 10**40,
    "載": 10**44,
    "極": 10**48,
}

小數單位序: dict[str, int] = {
    "分": 1,
    "釐": 2,
    "毫": 3,
    "絲": 4,
    "忽": 5,
    "微": 6,
    "纖": 7,
    "沙": 8,
    "塵": 9,
    "埃": 10,
    "渺": 11,
    "漠": 12,
}

數值字符 = frozenset(
    "負·又零〇一二三四五六七八九十百千萬億兆京垓秭穰溝澗正載極分釐毫絲忽微纖沙塵埃渺漠"
)

關鍵詞: list[str] = [
    "吾有",
    "今有",
    "物之",
    "有",
    "數",
    "列",
    "言",
    "術",
    "爻",
    "物",
    "元",
    "書之",
    "名之曰",
    "施",
    "以施",
    "曰",
    "噫",
    "取",
    "昔之",
    "今",
    "是矣",
    "是也",
    "不復存矣",
    "其",
    "乃得",
    "乃得矣",
    "乃歸空無",
    "是謂",
    "之術也",
    "必先得",
    "是術曰",
    "乃行是術曰",
    "欲行是術",
    "也",
    "云云",
    "凡",
    "中之",
    "恆為是",
    "為是",
    "遍",
    "乃止",
    "乃止是遍",
    "若非",
    "若",
    "者",
    "若其然者",
    "若其不然者",
    "或若",
    "其物如是",
    "之物也",
    "夫",
    "等於",
    "不等於",
    "不大於",
    "不小於",
    "大於",
    "小於",
    "加",
    "減",
    "乘",
    "除",
    "中有陽乎",
    "中無陰乎",
    "變",
    "所餘幾何",
    "以",
    "於",
    "之長",
    "之",
    "充",
    "銜",
    "其餘",
    "陰",
    "陽",
    "吾嘗觀",
    "中",
    "之書",
    "方悟",
    "之義",
    "嗚呼",
    "之禍",
    "姑妄行此",
    "如事不諧",
    "豈",
    "之禍歟",
    "不知何禍歟",
    "乃作罷",
    "或云",
    "蓋謂",
    "注曰",
    "疏曰",
    "批曰",
]

關鍵詞依長度 = sorted(關鍵詞, key=len, reverse=True)
關鍵詞前綴: dict[str, list[str]] = {}
for 詞 in 關鍵詞依長度:
    關鍵詞前綴.setdefault(詞[0], []).append(詞)  # ty:ignore[invalid-argument-type, not-subscriptable]


class 文法之禍(SyntaxError):
    """文法錯誤。

    Args:
        訊息: 錯誤訊息。
        位置: 錯誤位置資訊（SyntaxError 兼容格式）。
    """

    ...


文法錯誤 = 文法之禍


@dataclass(frozen=True)
class 符號:
    """詞法單元。"""

    類别: str
    值: str | None
    位置: slice

    @property
    def position(self) -> slice:
        return self.位置

    @property
    def type(self) -> str:
        return self.類别

    @property
    def value(self) -> str | None:
        return self.值


@dataclass
class 詞法分析器:
    """詞法分析器。"""

    內容: str
    文檔名: str = "<言>"

    def __iter__(self) -> Iterator[符號]:
        內容 = self.內容
        長度 = len(內容)
        索引 = 0
        數據起點: int | None = None
        while 索引 < 長度:
            字 = 內容[索引]

            if 字 == "『" or (
                字 == "「" and 索引 + 1 < 長度 and 內容[索引 + 1] == "「"
            ):
                if 數據起點 is not None:
                    yield 符號("數據", 內容[數據起點:索引], slice(數據起點, 索引))
                    數據起點 = None
                文字, 結束 = self._讀言(索引)
                if 字 == "「" and 結束 < 長度 and 內容[結束] == "」":
                    # 與 @wenyan/cli 對齊：雙引言後緊接額外「」時，尾「」視為字面值。
                    結束 += 1
                    文字 += "」"
                yield 符號("言", 文字, slice(索引, 結束))
                索引 = 結束
                continue

            if 字 in 忽略符號:
                if 數據起點 is not None:
                    yield 符號("數據", 內容[數據起點:索引], slice(數據起點, 索引))
                    數據起點 = None
                索引 += 1
                continue

            if 字 == "「":
                if 數據起點 is not None:
                    yield 符號("數據", 內容[數據起點:索引], slice(數據起點, 索引))
                    數據起點 = None
                結束 = 內容.find("」", 索引 + 1)
                if 結束 == -1:
                    self._拋出語法錯誤("名未尽", 索引)
                yield 符號("名", 內容[索引 + 1 : 結束], slice(索引, 結束 + 1))
                索引 = 結束 + 1
                continue

            關鍵 = None
            if 候選 := 關鍵詞前綴.get(字):
                for 詞 in 候選:
                    if 內容.startswith(詞, 索引):
                        關鍵 = 詞
                        break
            if 關鍵 is not None:
                if 數據起點 is not None:
                    yield 符號("數據", 內容[數據起點:索引], slice(數據起點, 索引))
                    數據起點 = None
                結束 = 索引 + len(關鍵)
                yield 符號(關鍵, None, slice(索引, 結束))
                索引 = 結束
                continue

            if 字 in 數值字符:
                if 數據起點 is not None:
                    yield 符號("數據", 內容[數據起點:索引], slice(數據起點, 索引))
                    數據起點 = None
                開始 = 索引
                索引 += 1
                while 索引 < 長度 and 內容[索引] in 數值字符:
                    索引 += 1
                片段 = 內容[開始:索引]
                try:
                    數字字串 = 漢字數字(片段)
                except 文法之禍:
                    self._拋出語法錯誤("非法數", 開始)
                yield 符號("數", 數字字串, slice(開始, 索引))
                continue

            if 數據起點 is None:
                數據起點 = 索引
            索引 += 1

        if 數據起點 is not None:
            yield 符號("數據", 內容[數據起點:索引], slice(數據起點, 索引))

    def _讀言(self, 起點: int) -> tuple[str, int]:
        內容 = self.內容
        索引 = 起點
        內容片段: list[str] = []
        層級 = 0
        while 索引 < len(內容):
            字 = 內容[索引]
            if 字 == "「":
                層級 += 1
            elif 字 == "」":
                層級 -= 1
            elif 字 == "『":
                層級 += 2
            elif 字 == "』":
                層級 -= 2
            內容片段.append(字)
            索引 += 1
            if 層級 == 0:
                文字 = "".join(內容片段)
                if 文字.startswith("「"):
                    文字 = 文字[2:]
                else:
                    文字 = 文字[1:]
                if 文字.endswith("」"):
                    文字 = 文字[:-2]
                else:
                    文字 = 文字[:-1]
                文字 = 文字.replace('"', '\\"').replace("\n", "\\n")
                return 文字, 索引
        self._拋出語法錯誤("言未尽", 起點)
        raise AssertionError("unreachable")

    def _拋出語法錯誤(self, 訊息: str, 索引: int) -> None:
        行號, 列偏移, 行文字 = 計算行列(self.內容, 索引)
        raise 文法之禍(訊息, (self.文檔名, 行號, 列偏移, 行文字))


def 計算行列(內容: str, 索引: int) -> tuple[int, int, str]:
    """計算行號、列偏移與行文字。

    Args:
        內容: 原始文字。
        索引: 0-based 索引。

    Returns:
        (行號, 列偏移, 行文字)。
    """

    行首 = 內容.rfind("\n", 0, 索引)
    if 行首 == -1:
        行首 = 0
        行號 = 1
    else:
        行首 += 1
        行號 = 內容.count("\n", 0, 行首) + 1
    行末 = 內容.find("\n", 索引)
    if 行末 == -1:
        行末 = len(內容)
    列偏移 = 索引 - 行首 + 1
    行文字 = 內容[行首:行末]
    return 行號, 列偏移, 行文字


@lru_cache(maxsize=4096)
def 漢字數字(漢字數: str) -> str:
    """將文言數字轉成十進位字串。

    Args:
        漢字數: 文言數字字串。

    Returns:
        十進位字串（必要時含小數點）。

    Raises:
        語法錯誤: 若字串不是合法數字。
    """

    if not 漢字數:
        raise 文法之禍("空數字")
    if any(字 not in 數值字符 for 字 in 漢字數):
        raise 文法之禍("非數值字符")

    負號 = False
    if 漢字數.startswith("負"):
        負號 = True
        漢字數 = 漢字數[1:]
        if "負" in 漢字數:
            raise 文法之禍("多重負號")
    elif "負" in 漢字數:
        raise 文法之禍("負號位置錯誤")

    if not 漢字數:
        raise 文法之禍("空數字")

    if "·" in 漢字數:
        if 漢字數.count("·") != 1:
            raise 文法之禍("多重小數點")
        if "又" in 漢字數:
            raise 文法之禍("混用小數點與又")
        for 字 in 漢字數:
            if 字 == "·":
                continue
            if 字 not in 數字對照:
                raise 文法之禍("非數字")
        if 漢字數.startswith("·") or 漢字數.endswith("·"):
            raise 文法之禍("小數點位置錯誤")
        整數部, 小數部 = 漢字數.split("·", 1)
        整數數字 = "".join(str(數字對照[字]) for 字 in 整數部) if 整數部 else "0"
        小數數字 = "".join(str(數字對照[字]) for 字 in 小數部)
        整數數字 = 整數數字.lstrip("0") or "0"
        結果 = 整數數字 if not 小數數字 else f"{整數數字}.{小數數字}"
        return f"-{結果}" if 負號 else 結果

    if "又" in 漢字數:
        if 漢字數.count("又") != 1:
            raise 文法之禍("多重又")
        整數部, 尾部 = 漢字數.split("又", 1)
        if not 尾部:
            raise 文法之禍("又後為空")
        整數值 = 解析整數(整數部) if 整數部 else 0
        if any(字 in 小數單位序 for 字 in 尾部):
            小數數字 = 解析小數(尾部)
            if not 小數數字 or set(小數數字) == {"0"}:
                結果 = str(整數值)
            else:
                結果 = f"{整數值}.{小數數字}"
        else:
            尾值 = 解析整數(尾部)
            結果 = str(整數值 + 尾值)
        return f"-{結果}" if 負號 else 結果

    if any(字 in 小數單位序 for 字 in 漢字數):
        小數數字 = 解析小數(漢字數)
        if not 小數數字 or set(小數數字) == {"0"}:
            結果 = "0"
        else:
            結果 = f"0.{小數數字}"
        return f"-{結果}" if 負號 else 結果

    整數值 = 解析整數(漢字數)
    結果 = str(整數值)
    return f"-{結果}" if 負號 else 結果


漢字變數字 = 漢字數字


def 解析整數(漢字數: str) -> int:
    """解析整數部分。

    Args:
        漢字數: 整數字串。

    Returns:
        整數值。

    Raises:
        語法錯誤: 若格式不合法。
    """

    if not 漢字數:
        return 0
    if any(字 in 小數單位序 for 字 in 漢字數) or "·" in 漢字數 or "又" in 漢字數:
        raise 文法之禍("非法整數")
    if all(字 in 數字對照 for 字 in 漢字數):
        數字字串 = "".join(str(數字對照[字]) for 字 in 漢字數)
        return int(數字字串) if 數字字串 else 0

    總和 = 0
    節值 = 0
    當前數 = 0
    有數 = False
    for 字 in 漢字數:
        if 字 in 數字對照:
            當前數 = 數字對照[字]
            有數 = True
        elif 字 in 小單位:
            單位 = 小單位[字]
            if not 有數:
                當前數 = 1
            節值 += 當前數 * 單位
            當前數 = 0
            有數 = False
        elif 字 in 大單位:
            單位 = 大單位[字]
            if not 有數 and 節值 == 0:
                節值 = 1
            else:
                節值 += 當前數
            總和 += 節值 * 單位
            節值 = 0
            當前數 = 0
            有數 = False
        else:
            raise 文法之禍("非法整數")
    return 總和 + 節值 + (當前數 if 有數 else 0)


def 解析小數(漢字數: str) -> str:
    """解析小數部分並回傳小數位字串。

    Args:
        漢字數: 小數字串。

    Returns:
        小數位字串。

    Raises:
        語法錯誤: 若格式不合法。
    """

    if not 漢字數:
        raise 文法之禍("空小數")
    位序 = 小數單位序
    下一位 = 1
    位數: list[str] = []
    索引 = 0
    while 索引 < len(漢字數):
        字 = 漢字數[索引]
        if 字 in 數字對照:
            數字 = 數字對照[字]
            if 索引 + 1 < len(漢字數) and 漢字數[索引 + 1] in 位序:
                單位字 = 漢字數[索引 + 1]
                目標位 = 位序[單位字]
                if 目標位 < 下一位:
                    raise 文法之禍("小數位錯序")
                while 下一位 < 目標位:
                    位數.append("0")
                    下一位 += 1
                位數.append(str(數字))
                下一位 = 目標位 + 1
                索引 += 2
            else:
                if 下一位 > 12:
                    raise 文法之禍("小數位過長")
                位數.append(str(數字))
                下一位 += 1
                索引 += 1
        elif 字 in 位序:
            目標位 = 位序[字]
            if 目標位 < 下一位:
                raise 文法之禍("小數位錯序")
            while 下一位 < 目標位:
                位數.append("0")
                下一位 += 1
            位數.append("1")
            下一位 = 目標位 + 1
            索引 += 1
        else:
            raise 文法之禍("非法小數")
    return "".join(位數)


# ---------------------------------------------------------------------------
# Wenyan AST（MVP）
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class 節點:
    """語法樹節點基類。

    Args:
        位置: 對應原始碼片段的 `slice(start, end)`，用於錯誤定位。
    """

    位置: slice


@dataclass(frozen=True)
class 值(節點):
    """值（表達式）基類。"""


@dataclass(frozen=True)
class 名值(值):
    """名（identifier）。"""

    名: str


@dataclass(frozen=True)
class 言值(值):
    """言（字面量字串）。

    注意：`文` 為 lexer 產出的「已做最小轉義」內容（例如 `\\n`、`\\"`），
    轉譯成 Python `ast.Constant` 時需還原成真實字元。
    """

    文: str


@dataclass(frozen=True)
class 數值(值):
    """數（數值字面量）。"""

    文: str


@dataclass(frozen=True)
class 爻值(值):
    """爻（陰/陽）。"""

    真: bool


@dataclass(frozen=True)
class 其值(值):
    """其（暫存棧頂）。"""


@dataclass(frozen=True)
class 其餘值(值):
    """其餘（容器下標語法中的 REST）。"""


@dataclass(frozen=True)
class 句(節點):
    """語句基類。"""


@dataclass(frozen=True)
class 程式(節點):
    """程式根節點。"""

    句列: list[句]


@dataclass(frozen=True)
class 宣告句(句):
    """變數宣告（`吾有/今有`）。"""

    數量: int
    類型: str
    初值列: list[值]
    名列: list[str]
    公開: bool


@dataclass(frozen=True)
class 初始化句(句):
    """初始化宣告（`有`）。"""

    類型: str
    初值: 值
    名: str | None


@dataclass(frozen=True)
class 命名句(句):
    """命名（`名之曰`；從暫存棧取值）。"""

    名列: list[str]


@dataclass(frozen=True)
class 匯入句(句):
    """匯入（`吾嘗觀 ... 之書 ... 方悟 ... 之義`）。"""

    模組: str
    名列: list[str]


@dataclass(frozen=True)
class 術參數(節點):
    """術參數。"""

    名: str
    類型: str
    其餘: bool = False


@dataclass(frozen=True)
class 術定義句(句):
    """術定義（函數）。"""

    名: str
    參數列: list[術參數]
    體: list[句]
    公開: bool


@dataclass(frozen=True)
class 施句(句):
    """呼叫（`施 <術> 於 <值>...`）。"""

    術: 值
    參數列: list[值]


@dataclass(frozen=True)
class 以施句(句):
    """呼叫（`以施 <術>`）。"""

    術: 值


@dataclass(frozen=True)
class 取句(句):
    """取參數（`取 <數>` / `取其餘`）。"""

    數量: int | None
    其餘: bool = False


@dataclass(frozen=True)
class 返回句(句):
    """返回（`乃得/乃得矣/乃歸空無`）。"""

    值: 值 | None
    取棧: bool
    空無: bool


@dataclass(frozen=True)
class 列充句(句):
    """列追加（`充`）。"""

    列: 值
    值列: list[值]


@dataclass(frozen=True)
class 列銜句(句):
    """列/言銜接（`銜`）。"""

    列: 值
    列列: list[值]


@dataclass(frozen=True)
class 物屬性(節點):
    """物屬性（`物之...者`）。"""

    鍵: 言值
    類型: str
    值: 值


@dataclass(frozen=True)
class 物定義句(句):
    """物定義（`其物如是 ... 是謂 ... 之物也`）。"""

    名: str
    屬性列: list[物屬性]


@dataclass(frozen=True)
class 書之句(句):
    """輸出（`書之`）。"""


@dataclass(frozen=True)
class 噫句(句):
    """清空暫存棧（`噫`）。"""


@dataclass(frozen=True)
class 算術句(句):
    """二元運算（含算術/餘數/邏輯）。"""

    算: str
    左: 值
    右: 值


@dataclass(frozen=True)
class 變句(句):
    """一元運算（`變`）。"""

    值: 值


@dataclass(frozen=True)
class 夫句(句):
    """取值入棧（`夫 <值>`）。"""

    值: 值


@dataclass(frozen=True)
class 之句(句):
    """下標取值（`夫 <容器> 之 <索引>`）。"""

    容器: 值
    索引: 值


@dataclass(frozen=True)
class 之長句(句):
    """取長度（`夫 <容器> 之長`）。"""

    容器: 值


@dataclass(frozen=True)
class 昔今句(句):
    """賦值或刪除（`昔之...者 今 ... 是矣` / `... 不復存矣`）。"""

    左名: str
    左下標: 值 | None
    右值: 值 | None
    右下標: 值 | None
    刪除: bool


文言值 = 值


@dataclass(frozen=True)
class 條件原子(節點):
    """條件式中的原子（值 + 可選後綴）。"""

    值: 文言值
    下標: 文言值 | None
    之長: bool


@dataclass(frozen=True)
class 或若子句(節點):
    """`或若` 子句。"""

    條件: list[條件原子 | str]
    體: list[句]


@dataclass(frozen=True)
class 若句(句):
    """若（if/elif/else）。"""

    條件: list[條件原子 | str]
    反轉: bool
    然: list[句]
    另若列: list[或若子句]
    否則: list[句]


@dataclass(frozen=True)
class 恆為是句(句):
    """無條件循環（`恆為是 ... 云云/也`）。"""

    體: list[句]


@dataclass(frozen=True)
class 為是遍句(句):
    """次數循環（`為是 <次數> 遍 ... 云云/也`）。"""

    次數: 值
    體: list[句]


@dataclass(frozen=True)
class 乃止句(句):
    """break（`乃止`）。"""


@dataclass(frozen=True)
class 乃止是遍句(句):
    """continue（`乃止是遍`）。"""


@dataclass(frozen=True)
class 凡句(句):
    """遍歷（`凡 ... 中之 ...`）。"""

    容器: 值
    變數名: str
    體: list[句]


@dataclass(frozen=True)
class 捕捉子句(節點):
    """捕捉子句。"""

    錯名: 值 | None
    變數名: str | None
    體: list[句]
    亦可: bool


@dataclass(frozen=True)
class 試句(句):
    """異常處理（`姑妄行此`）。"""

    體: list[句]
    捕捉列: list[捕捉子句]


@dataclass(frozen=True)
class 擲句(句):
    """拋出（`嗚呼 ... 之禍`）。"""

    名: 值
    訊: 值 | None


@dataclass(frozen=True)
class 註釋句(句):
    """註釋（`注曰/疏曰/批曰`）。"""

    文: str


@dataclass(frozen=True)
class 宏句(句):
    """宏定義（`或云/蓋謂`）。"""

    模式: str
    置換: str


@dataclass(frozen=True)
class 宏定義:
    """宏定義（預處理用）。"""

    模式: str
    置換: str
    正則: re.Pattern
    占位列: list[str]


@dataclass
class 編譯環境:
    """編譯過程共用快取。"""

    根目錄: str
    模組快取: dict[str, list[ast.stmt]]
    宏快取: dict[str, list[宏定義]]
    源碼快取: dict[str, str]
    宏解析中: set[str]
    編譯中: set[str]
    已載入: set[str]


內建型別詞 = frozenset({"數", "列", "言", "爻", "物", "術", "元"})
塊終止詞 = frozenset({"云云", "也"})
條件終止詞 = frozenset({"者", "或若", "若非", "云云", "也"})
若分支終止詞 = frozenset({"或若", "若非", "云云", "也", "是謂"})
若收束詞 = frozenset({"云云", "也", "是謂"})
算術介詞 = frozenset({"以", "於"})
返回終止詞 = frozenset({"是矣", "是也"})
試終止詞 = frozenset({"如事不諧"})
捕捉終止詞 = frozenset({"豈", "不知何禍歟", "乃作罷"})
算術詞對照 = {"加": "+", "減": "-", "乘": "*", "除": "/"}
比較詞對照 = {
    "等於": "==",
    "不等於": "!=",
    "不大於": "<=",
    "不小於": ">=",
    "大於": ">",
    "小於": "<",
}
邏輯詞對照 = {"中有陽乎": "||", "中無陰乎": "&&"}
循環終止詞 = frozenset({"云云", "也", "是謂", "乃得", "乃得矣", "乃歸空無"})
循環收束詞 = frozenset({"是謂", "乃得", "乃得矣", "乃歸空無"})
結構收束詞 = frozenset(
    {
        "也",
        "云云",
        "若非",
        "或若",
        "是謂",
        "乃得",
        "乃得矣",
        "乃歸空無",
        "如事不諧",
        "豈",
        "不知何禍歟",
        "乃作罷",
    }
)
比較AST運算子對照 = {
    "==": ast.Eq,
    "!=": ast.NotEq,
    "<=": ast.LtE,
    ">=": ast.GtE,
    "<": ast.Lt,
    ">": ast.Gt,
}
算術AST運算子對照 = {
    "+": ast.Add,
    "-": ast.Sub,
    "*": ast.Mult,
    "/": ast.Div,
    "%": ast.Mod,
}
邏輯AST運算子對照 = {"||": ast.Or, "&&": ast.And}
宣告預設值表: dict[str, int | str | bool | None] = {
    "數": 0,
    "言": "",
    "爻": False,
    "元": None,
}


def _區塊終點(開頭: slice, *句列組: list[句] | list[或若子句]) -> slice:
    終點 = next((句列[-1].位置.stop for 句列 in 句列組 if 句列), 開頭.stop)
    return slice(開頭.start, 終點)


class 文法分析器:
    """將 `詞法分析器` 的輸出轉為 Wenyan AST。"""

    def __init__(self, 內容: str, 文檔名: str = "<言>") -> None:
        self.內容 = 內容
        self.文檔名 = 文檔名
        self.符號列 = list(詞法分析器(內容, 文檔名))
        self._索引 = 0

    def 解析程式(self) -> 程式:
        """解析整個程式。"""

        起點 = 0
        句列 = self._解析語句列(終止詞=frozenset())
        終點 = len(self.內容)
        return 程式(slice(起點, 終點), 句列)

    # ---- 基礎操作 -----------------------------------------------------

    def _看(self) -> 符號 | None:
        if self._索引 < len(self.符號列):
            return self.符號列[self._索引]
        return None

    def _取(self) -> 符號:
        符 = self._看()
        if 符 is None:
            self._拋出文法錯誤("意外之終", len(self.內容))
        self._索引 += 1
        return 符

    def _是關鍵詞(self, 符: 符號 | None, 詞: str) -> bool:
        return 符 is not None and 符.類别 == 詞 and 符.值 is None

    def _期(self, 詞: str) -> 符號:
        符 = self._取()
        if not self._是關鍵詞(符, 詞):
            self._拋出文法錯誤(f"當為「{詞}」", 符.位置.start)
        return 符

    def _拋出文法錯誤(self, 訊息: str, 索引: int) -> NoReturn:
        行號, 列偏移, 行文字 = 計算行列(self.內容, 索引)
        raise 文法之禍(訊息, (self.文檔名, 行號, 列偏移, 行文字))

    def _解析可選命名(self) -> str | None:
        if not self._是關鍵詞(self._看(), "名之曰"):
            return None
        self._取()
        return self._解析名()

    def _解析以值列(self, 開: 符號, 訊息: str) -> list[值]:
        值列: list[值] = []
        if not self._是關鍵詞(self._看(), "以"):
            self._拋出文法錯誤(訊息, 開.位置.start)
        while self._是關鍵詞(self._看(), "以"):
            self._取()
            值列.append(self._解析值())
        return 值列

    def _當前位置(self, 開: 符號) -> slice:
        return slice(開.位置.start, self.符號列[self._索引 - 1].位置.stop)

    def _略終者(self) -> None:
        if self._是關鍵詞(self._看(), "者"):
            self._取()

    # ---- 值 -----------------------------------------------------------

    def _解析值(self) -> 值:
        符 = self._取()
        文 = 符.值
        if 文 is None:
            類 = 符.類别
            if 類 == "其":
                return 其值(符.位置)
            if 類 == "其餘":
                return 其餘值(符.位置)
            if 類 == "陰":
                return 爻值(符.位置, False)
            if 類 == "陽":
                return 爻值(符.位置, True)
        elif 符.類别 == "名":
            return 名值(符.位置, 文)
        elif 符.類别 == "言":
            return 言值(符.位置, 文)
        elif 符.類别 == "數":
            return 數值(符.位置, 文)
        elif 符.類别 == "數據":
            return 名值(符.位置, 文)
        self._拋出文法錯誤("不識之值", 符.位置.start)
        raise AssertionError("unreachable")

    def _解析名(self) -> str:
        符 = self._取()
        if 符.類别 != "名" or 符.值 is None:
            self._拋出文法錯誤("當為名", 符.位置.start)
        return 符.值

    def _解析數量(self) -> int:
        符 = self._取()
        if 符.類别 != "數" or 符.值 is None:
            self._拋出文法錯誤("當為數", 符.位置.start)
        if "." in 符.值:
            self._拋出文法錯誤("數量不可為小數", 符.位置.start)
        try:
            數量 = int(符.值)
        except ValueError:
            self._拋出文法錯誤("非法數量", 符.位置.start)
        if 數量 <= 0:
            self._拋出文法錯誤("數量不可為零", 符.位置.start)
        return 數量

    def _解析型別詞(self) -> str:
        符 = self._取()
        if 符.值 is not None or 符.類别 not in 內建型別詞:
            self._拋出文法錯誤("當為型別詞", 符.位置.start)
        return 符.類别

    # ---- 條件式 -------------------------------------------------------

    def _解析條件原子(self) -> 條件原子:
        值節 = self._解析值()
        位置 = 值節.位置
        下標: 值 | None = None
        之長 = False
        if self._是關鍵詞(self._看(), "之"):
            self._取()
            下標 = self._解析值()
            位置 = slice(值節.位置.start, 下標.位置.stop)
        elif self._是關鍵詞(self._看(), "之長"):
            之長符 = self._取()
            之長 = True
            位置 = slice(值節.位置.start, 之長符.位置.stop)
        return 條件原子(位置, 值節, 下標, 之長)

    def _解析條件式(self) -> list[條件原子 | str]:
        片段: list[條件原子 | str] = [self._解析條件原子()]
        while True:
            符 = self._看()
            if 符 is None:
                break
            if 符.值 is None and 符.類别 in 條件終止詞:
                break
            if 符.值 is None and 符.類别 in 比較詞對照:
                self._取()
                片段.append(比較詞對照[符.類别])
                片段.append(self._解析條件原子())
                continue
            if 符.值 is None and 符.類别 in 邏輯詞對照:
                self._取()
                片段.append(邏輯詞對照[符.類别])
                片段.append(self._解析條件原子())
                continue
            self._拋出文法錯誤("非法條件式", 符.位置.start)
        return 片段

    def _可視為區塊終止後繼(self, 符: 符號 | None) -> bool:
        return 符 is not None and not (符.值 is None and 符.類别 in 結構收束詞)

    # ---- 語句 ---------------------------------------------------------

    def _解析語句列(self, 終止詞: frozenset[str]) -> list[句]:
        句列: list[句] = []
        while True:
            符 = self._看()
            if 符 is None:
                break
            if 符.值 is None and 符.類别 in 終止詞:
                break
            句列.append(self._解析語句())
        return 句列

    def _解析語句(self) -> 句:
        符 = self._看()
        if 符 is None:
            self._拋出文法錯誤("意外之終", len(self.內容))

        if self._是關鍵詞(符, "吾嘗觀"):
            return self._解析匯入句()
        if self._是關鍵詞(符, "或云"):
            return self._解析宏句()
        if (
            self._是關鍵詞(符, "注曰")
            or self._是關鍵詞(符, "疏曰")
            or self._是關鍵詞(符, "批曰")
        ):
            return self._解析註釋句()
        if self._是關鍵詞(符, "姑妄行此"):
            return self._解析試句()
        if self._是關鍵詞(符, "嗚呼"):
            return self._解析擲句()
        if self._是關鍵詞(符, "取"):
            return self._解析取句()
        if self._是關鍵詞(符, "以施"):
            開 = self._取()
            return 以施句(self._當前位置(開), self._解析值())
        if self._是關鍵詞(符, "施"):
            return self._解析施句()
        if self._是關鍵詞(符, "以"):
            下符 = (
                self.符號列[self._索引 + 1]
                if self._索引 + 1 < len(self.符號列)
                else None
            )
            if 下符 is not None and self._是關鍵詞(下符, "名之曰"):
                self._取()
                return self._解析命名句()
        if self._是關鍵詞(符, "充"):
            return self._解析列充句()
        if self._是關鍵詞(符, "銜"):
            return self._解析列銜句()
        if self._是關鍵詞(符, "其物如是"):
            return self._解析物定義句()
        if self._是關鍵詞(符, "凡"):
            return self._解析凡句()
        if self._是關鍵詞(符, "乃得矣"):
            return self._解析返回句(取棧=True)
        if self._是關鍵詞(符, "乃歸空無"):
            return self._解析返回句(空無=True)
        if self._是關鍵詞(符, "乃得"):
            return self._解析返回句()
        if self._是關鍵詞(符, "吾有") or self._是關鍵詞(符, "今有"):
            if self._是術定義起始():
                return self._解析術定義句()
            return self._解析宣告句()
        if self._是關鍵詞(符, "有"):
            return self._解析初始化句()
        if self._是關鍵詞(符, "名之曰"):
            return self._解析命名句()
        if self._是關鍵詞(符, "書之"):
            開 = self._取()
            return 書之句(開.位置)
        if self._是關鍵詞(符, "噫"):
            開 = self._取()
            return 噫句(開.位置)
        if self._是關鍵詞(符, "昔之"):
            return self._解析昔今句()
        if 符.值 is None and 符.類别 in {"加", "減", "乘", "除"}:
            return self._解析算術句()
        if self._是關鍵詞(符, "變"):
            開 = self._取()
            值節 = self._解析值()
            位置 = slice(開.位置.start, 值節.位置.stop)
            return 變句(位置, 值節)
        if self._是關鍵詞(符, "夫"):
            return self._解析夫句()
        if (
            self._是關鍵詞(符, "若")
            or self._是關鍵詞(符, "若其然者")
            or self._是關鍵詞(符, "若其不然者")
        ):
            return self._解析若句()
        if self._是關鍵詞(符, "恆為是"):
            return self._解析恆為是句()
        if self._是關鍵詞(符, "為是"):
            return self._解析為是遍句()
        if self._是關鍵詞(符, "是術曰") or self._是關鍵詞(符, "乃行是術曰"):
            self._拋出文法錯誤("術體不可獨立", 符.位置.start)
        if self._是關鍵詞(符, "乃止"):
            開 = self._取()
            return 乃止句(開.位置)
        if self._是關鍵詞(符, "乃止是遍"):
            開 = self._取()
            return 乃止是遍句(開.位置)
        if self._是關鍵詞(符, "也"):
            終 = self._取()
            return 註釋句(終.位置, "")
        if self._是關鍵詞(符, "云云"):
            self._拋出文法錯誤("不當之終", 符.位置.start)

        self._拋出文法錯誤("不識之句", 符.位置.start)
        raise AssertionError("unreachable")

    def _解析宣告句(self) -> 宣告句:
        開 = self._取()
        公開 = self._是關鍵詞(開, "今有")
        數量 = self._解析數量()
        類型 = self._解析型別詞()
        初值列: list[值] = []
        while self._是關鍵詞(self._看(), "曰"):
            self._取()
            初值列.append(self._解析值())
        名列: list[str] = []
        if self._是關鍵詞(self._看(), "名之曰"):
            self._取()
            名列.append(self._解析名())
            while self._是關鍵詞(self._看(), "曰"):
                self._取()
                名列.append(self._解析名())
        if len(初值列) > 數量:
            self._拋出文法錯誤("初值多於數量", 開.位置.start)
        if len(名列) > 數量:
            self._拋出文法錯誤("名多於數量", 開.位置.start)
        return 宣告句(self._當前位置(開), 數量, 類型, 初值列, 名列, 公開)

    def _解析初始化句(self) -> 初始化句:
        開 = self._期("有")
        類型 = self._解析型別詞()
        初值 = self._解析值()
        名 = self._解析可選命名()
        return 初始化句(self._當前位置(開), 類型, 初值, 名)

    def _解析命名句(self) -> 命名句:
        開 = self._期("名之曰")
        名列 = [self._解析名()]
        while self._是關鍵詞(self._看(), "曰"):
            self._取()
            名列.append(self._解析名())
        return 命名句(self._當前位置(開), 名列)

    def _是術定義起始(self) -> bool:
        起點 = self._索引
        if 起點 >= len(self.符號列):
            return False
        符 = self.符號列[起點]
        if not (self._是關鍵詞(符, "吾有") or self._是關鍵詞(符, "今有")):
            return False
        if 起點 + 2 >= len(self.符號列):
            return False
        if self.符號列[起點 + 1].類别 != "數":
            return False
        if not self._是關鍵詞(self.符號列[起點 + 2], "術"):
            return False
        探 = 起點 + 3
        止 = min(len(self.符號列), 探 + 64)
        while 探 < 止:
            符 = self.符號列[探]
            if self._是關鍵詞(符, "是術曰") or self._是關鍵詞(符, "乃行是術曰"):
                return True
            探 += 1
        return False

    def _解析術定義句(self) -> 術定義句:
        開 = self._取()
        公開 = self._是關鍵詞(開, "今有")
        數量 = self._解析數量()
        類型 = self._解析型別詞()
        if 類型 != "術":
            self._拋出文法錯誤("術定義須為術", 開.位置.start)
        if 數量 != 1:
            self._拋出文法錯誤("術定義數量須為一", 開.位置.start)
        if not self._是關鍵詞(self._看(), "名之曰"):
            self._拋出文法錯誤("術定義須命名", 開.位置.start)
        self._取()
        名 = self._解析名()
        if self._是關鍵詞(self._看(), "曰"):
            self._拋出文法錯誤("術名不可多", 開.位置.start)
        if self._是關鍵詞(self._看(), "欲行是術"):
            self._取()
        參數列: list[術參數] = []
        已見其餘參 = False
        if self._是關鍵詞(self._看(), "必先得"):
            self._取()
            while True:
                其餘參組 = self._是關鍵詞(self._看(), "其餘")
                if 其餘參組:
                    self._取()
                    組數量 = 1
                    組型別 = self._解析型別詞()
                else:
                    組數量 = self._解析數量()
                    組型別 = self._解析型別詞()
                名列: list[tuple[str, slice]] = []
                while self._是關鍵詞(self._看(), "曰"):
                    self._取()
                    名稱 = self._解析名()
                    名符 = self.符號列[self._索引 - 1]
                    名列.append((名稱, 名符.位置))
                if len(名列) != 組數量:
                    self._拋出文法錯誤(
                        "其餘參數須一名" if 其餘參組 else "參數數量不符",
                        開.位置.start,
                    )
                for 名稱, 位 in 名列:
                    參數列.append(術參數(位, 名稱, 組型別, 其餘參組))
                if 其餘參組:
                    已見其餘參 = True
                下符 = self._看()
                if 下符 is None:
                    break
                if 已見其餘參:
                    if 下符.類别 == "數" or self._是關鍵詞(下符, "其餘"):
                        self._拋出文法錯誤("其餘參數須居末", 下符.位置.start)
                    break
                if 下符.類别 == "數" or self._是關鍵詞(下符, "其餘"):
                    下二 = (
                        self.符號列[self._索引 + 1]
                        if self._索引 + 1 < len(self.符號列)
                        else None
                    )
                    if 下二 is not None and 下二.值 is None and 下二.類别 in 內建型別詞:
                        continue
                break
        if not (
            self._是關鍵詞(self._看(), "是術曰")
            or self._是關鍵詞(self._看(), "乃行是術曰")
        ):
            self._拋出文法錯誤("術體未始", 開.位置.start)
        self._取()
        體 = self._解析語句列(終止詞=frozenset({"是謂"}))
        self._期("是謂")
        self._解析名()
        self._期("之術也")
        return 術定義句(self._當前位置(開), 名, 參數列, 體, 公開)

    def _解析匯入句(self) -> 匯入句:
        開 = self._期("吾嘗觀")
        模組符 = self._取()
        if 模組符.類别 != "言" or 模組符.值 is None:
            self._拋出文法錯誤("當為書名", 模組符.位置.start)
        模組 = _還原言值(模組符.值)
        self._期("之書")
        名列: list[str] = []
        if self._是關鍵詞(self._看(), "方悟"):
            self._取()
            while True:
                符 = self._看()
                if 符 is None:
                    self._拋出文法錯誤("方悟未終", 開.位置.start)
                if self._是關鍵詞(符, "之義"):
                    self._取()
                    break
                名列.append(self._解析名())
        return 匯入句(self._當前位置(開), 模組, 名列)

    def _解析宏句(self) -> 宏句:
        開 = self._期("或云")
        模式符 = self._取()
        if 模式符.類别 != "言" or 模式符.值 is None:
            self._拋出文法錯誤("宏式當為言", 模式符.位置.start)
        self._期("蓋謂")
        置換符 = self._取()
        if 置換符.類别 != "言" or 置換符.值 is None:
            self._拋出文法錯誤("宏替當為言", 置換符.位置.start)
        return 宏句(self._當前位置(開), _還原言值(模式符.值), _還原言值(置換符.值))

    def _解析註釋句(self) -> 註釋句:
        開 = self._取()
        文符 = self._看()
        if 文符 is not None and 文符.類别 == "言" and 文符.值 is not None:
            self._取()
            位置 = slice(開.位置.start, 文符.位置.stop)
            return 註釋句(位置, _還原言值(文符.值))
        行終 = self.內容.find("\n", 開.位置.stop)
        if 行終 == -1:
            行終 = len(self.內容)
        文 = self.內容[開.位置.stop : 行終].strip()
        while True:
            觀 = self._看()
            if 觀 is None or 觀.位置.start >= 行終:
                break
            self._取()
        位置 = slice(開.位置.start, 行終)
        return 註釋句(位置, 文)

    def _解析捕捉子句(self, 起: int, 錯名: 值 | None, 亦可: bool) -> 捕捉子句:
        變數名 = self._解析可選命名()
        捕體 = self._解析語句列(終止詞=捕捉終止詞)
        終符 = self.符號列[self._索引 - 1]
        return 捕捉子句(slice(起, 終符.位置.stop), 錯名, 變數名, 捕體, 亦可)

    def _解析試句(self) -> 試句:
        開 = self._期("姑妄行此")
        體 = self._解析語句列(終止詞=試終止詞)
        if not self._是關鍵詞(self._看(), "如事不諧"):
            self._拋出文法錯誤("試句未終", 開.位置.start)
        self._取()
        捕捉列: list[捕捉子句] = []
        while True:
            符 = self._看()
            if 符 is None:
                self._拋出文法錯誤("試句未終", 開.位置.start)
            if self._是關鍵詞(符, "乃作罷"):
                self._取()
                return 試句(self._當前位置(開), 體, 捕捉列)
            if self._是關鍵詞(符, "豈"):
                起 = 符.位置.start
                self._取()
                錯名 = self._解析值()
                self._期("之禍歟")
                捕捉列.append(self._解析捕捉子句(起, 錯名, False))
                continue
            if self._是關鍵詞(符, "不知何禍歟"):
                起 = 符.位置.start
                self._取()
                捕捉列.append(self._解析捕捉子句(起, None, True))
                continue
            self._拋出文法錯誤("捕捉未始", 符.位置.start)

    def _解析擲句(self) -> 擲句:
        開 = self._期("嗚呼")
        名 = self._解析值()
        self._期("之禍")
        訊: 值 | None = None
        if self._是關鍵詞(self._看(), "曰"):
            self._取()
            訊 = self._解析值()
        return 擲句(self._當前位置(開), 名, 訊)

    def _解析取句(self) -> 取句:
        開 = self._期("取")
        其餘 = self._是關鍵詞(self._看(), "其餘")
        if 其餘:
            self._取()
        數量 = None if 其餘 else self._解析數量()
        return 取句(self._當前位置(開), 數量, 其餘)

    def _解析施句(self) -> 施句:
        開 = self._期("施")
        術 = self._解析值()
        參數列: list[值] = []
        while self._是關鍵詞(self._看(), "於"):
            self._取()
            參數列.append(self._解析值())
        return 施句(self._當前位置(開), 術, 參數列)

    def _解析列充句(self) -> 列充句:
        開 = self._期("充")
        列 = self._解析值()
        return 列充句(self._當前位置(開), 列, self._解析以值列(開, "充需以值"))

    def _解析列銜句(self) -> 列銜句:
        開 = self._期("銜")
        列 = self._解析值()
        return 列銜句(self._當前位置(開), 列, self._解析以值列(開, "銜需以列"))

    def _解析物定義句(self) -> 物定義句:
        開 = self._期("其物如是")
        屬性列: list[物屬性] = []
        while self._是關鍵詞(self._看(), "物之"):
            self._取()
            鍵符 = self._取()
            if 鍵符.類别 != "言" or 鍵符.值 is None:
                self._拋出文法錯誤("物鍵當為言", 鍵符.位置.start)
            鍵 = 言值(鍵符.位置, 鍵符.值)
            self._期("者")
            類型 = self._解析型別詞()
            self._期("曰")
            值節 = self._解析值()
            終符 = self.符號列[self._索引 - 1]
            屬性列.append(
                物屬性(slice(鍵符.位置.start, 終符.位置.stop), 鍵, 類型, 值節)
            )
        self._期("是謂")
        名 = self._解析名()
        self._期("之物也")
        return 物定義句(self._當前位置(開), 名, 屬性列)

    def _解析凡句(self) -> 凡句:
        開 = self._期("凡")
        容器 = self._解析值()
        self._期("中之")
        變數名 = self._解析名()
        體 = self._解析語句列(終止詞=塊終止詞)
        終符 = self._取()
        if 終符.值 is not None or 終符.類别 not in 塊終止詞:
            self._拋出文法錯誤("凡未終", 終符.位置.start)
        return 凡句(self._當前位置(開), 容器, 變數名, 體)

    def _解析返回句(self, 取棧: bool = False, 空無: bool = False) -> 返回句:
        開 = self._取()
        if 空無:
            return 返回句(開.位置, None, False, True)
        if 取棧:
            return 返回句(開.位置, None, True, False)
        值節 = self._解析值()
        終點 = 值節.位置.stop
        終符 = self._看()
        if 終符 is not None and 終符.值 is None and 終符.類别 in 返回終止詞:
            終點 = self._取().位置.stop
        位置 = slice(開.位置.start, 終點)
        return 返回句(位置, 值節, False, False)

    def _解析算術句(self) -> 算術句:
        開 = self._取()
        算 = 開.類别
        甲 = self._解析值()
        介 = self._取()
        if 介.值 is not None or 介.類别 not in 算術介詞:
            self._拋出文法錯誤("當為介詞", 介.位置.start)
        乙 = self._解析值()
        左, 右 = (甲, 乙) if 介.類别 == "以" else (乙, 甲)
        運 = 算術詞對照.get(算, "/")
        if 算 == "除" and self._是關鍵詞(self._看(), "所餘幾何"):
            mod符 = self._取()
            運 = "%"
            終點 = mod符.位置.stop
        else:
            終點 = 乙.位置.stop
        位置 = slice(開.位置.start, 終點)
        return 算術句(位置, 運, 左, 右)

    def _解析夫句(self) -> 句:
        開 = self._期("夫")
        甲 = self._解析值()
        if self._是關鍵詞(self._看(), "之"):
            self._取()
            索 = self._解析值()
            self._略終者()
            return 之句(slice(開.位置.start, 索.位置.stop), 甲, 索)
        if self._是關鍵詞(self._看(), "之長"):
            之長符 = self._取()
            self._略終者()
            return 之長句(slice(開.位置.start, 之長符.位置.stop), 甲)
        # 邏輯二元：夫 <甲> <乙> 中有陽乎/中無陰乎
        符 = self._看()
        若可值 = 符 is not None and (
            (符.類别 in {"名", "言", "數", "數據"} and 符.值 is not None)
            or self._是關鍵詞(符, "其")
            or self._是關鍵詞(符, "陰")
            or self._是關鍵詞(符, "陽")
        )
        if 若可值:
            乙 = self._解析值()
            op符 = self._看()
            if op符 is not None and op符.值 is None and op符.類别 in 邏輯詞對照:
                self._取()
                運 = 邏輯詞對照[op符.類别]
                self._略終者()
                return 算術句(slice(開.位置.start, op符.位置.stop), 運, 甲, 乙)
            # 回退：非邏輯二元，視為僅取值
            self._索引 -= 1
        self._略終者()
        return 夫句(slice(開.位置.start, 甲.位置.stop), 甲)

    def _解析昔今句(self) -> 昔今句:
        開 = self._期("昔之")
        左名 = self._解析名()
        左下標: 值 | None = None
        if self._是關鍵詞(self._看(), "之"):
            self._取()
            左下標 = self._解析值()
        self._期("者")
        self._期("今")
        if self._是關鍵詞(self._看(), "不復存矣"):
            self._取()
            if self._是關鍵詞(self._看(), "是也"):
                是也符 = self._取()
                # 與 @wenyan/cli 對齊：刪除後可寫「是也」，且僅在可收束區塊時保留「也」作終止。
                if self._可視為區塊終止後繼(self._看()):
                    self.符號列.insert(self._索引, 符號("也", None, 是也符.位置))
            return 昔今句(self._當前位置(開), 左名, 左下標, None, None, True)
        右值 = self._解析值()
        右下標: 值 | None = None
        if self._是關鍵詞(self._看(), "之"):
            self._取()
            右下標 = self._解析值()
        終符 = self._看()
        if 終符 is not None and self._是關鍵詞(終符, "是矣"):
            self._取()
        elif 終符 is not None and self._是關鍵詞(終符, "是也"):
            self._取()
            if self._可視為區塊終止後繼(self._看()):
                # 與 @wenyan/cli 對齊："是也" 視情境可等價於 "是" + "也"，保留 "也" 作區塊終止。
                self.符號列.insert(
                    self._索引, 符號("也", None, self.符號列[self._索引 - 1].位置)
                )
        elif 終符 is not None and 終符.類别 == "數據" and 終符.值 == "是":
            終 = self._取()
            終點 = 終.位置.stop
            下符 = self._看()
            if self._是關鍵詞(下符, "也") and 下符 is not None:
                夾段 = self.內容[終.位置.stop : 下符.位置.start]
                if not any(字 in "。、，" for 字 in 夾段):
                    終點 = self._取().位置.stop
            位置 = slice(開.位置.start, 終點)
            return 昔今句(位置, 左名, 左下標, 右值, 右下標, False)
        if 終符 is not None and self._是關鍵詞(終符, "也"):
            self._取()
        return 昔今句(self._當前位置(開), 左名, 左下標, 右值, 右下標, False)

    def _解析若句(self) -> 若句:
        開 = self._取()
        反轉 = self._是關鍵詞(開, "若其不然者")
        if self._是關鍵詞(開, "若其然者") or 反轉:
            條件: list[條件原子 | str] = [條件原子(開.位置, 其值(開.位置), None, False)]
        else:
            條件 = self._解析條件式()
            self._期("者")
        然 = self._解析語句列(終止詞=若分支終止詞)
        另若列: list[或若子句] = []
        while self._是關鍵詞(self._看(), "或若"):
            或若開 = self._取()
            或若條 = self._解析條件式()
            self._期("者")
            或若體 = self._解析語句列(終止詞=若分支終止詞)
            終 = self.符號列[self._索引 - 1]
            另若列.append(
                或若子句(slice(或若開.位置.start, 終.位置.stop), 或若條, 或若體)
            )
        否則: list[句] = []
        if self._是關鍵詞(self._看(), "若非"):
            self._取()
            否則 = self._解析語句列(終止詞=若收束詞)
        內文位置 = _區塊終點(開.位置, 否則, 另若列, 然)
        終結 = self._看()
        if 終結 is None or (終結.值 is None and 終結.類别 == "是謂"):
            位置 = 內文位置
        elif 終結.值 is None and 終結.類别 in 塊終止詞:
            self._取()
            位置 = self._當前位置(開)
        else:
            self._拋出文法錯誤("若未終", 開.位置.start)
            raise AssertionError("unreachable")
        return 若句(位置, 條件, 反轉, 然, 另若列, 否則)

    def _收束循環位置(self, 開: 符號, 體: list[句]) -> slice:
        終符 = self._看()
        if 終符 is not None and 終符.值 is None and 終符.類别 in 塊終止詞:
            self._取()
            return self._當前位置(開)
        if 終符 is None or (終符.值 is None and 終符.類别 in 循環收束詞):
            return _區塊終點(開.位置, 體)
        self._拋出文法錯誤("循環未終", 終符.位置.start)
        raise AssertionError("unreachable")

    def _解析恆為是句(self) -> 恆為是句:
        開 = self._期("恆為是")
        體 = self._解析語句列(終止詞=循環終止詞)
        return 恆為是句(self._收束循環位置(開, 體), 體)

    def _解析為是遍句(self) -> 為是遍句:
        開 = self._期("為是")
        次數 = self._解析值()
        self._期("遍")
        體 = self._解析語句列(終止詞=循環終止詞)
        return 為是遍句(self._收束循環位置(開, 體), 次數, 體)


def _前處理錯誤(內容: str, 文檔名: str, 訊息: str, 索引: int) -> None:
    行號, 列偏移, 行文字 = 計算行列(內容, 索引)
    raise 文法之禍(訊息, (文檔名, 行號, 列偏移, 行文字))


def _建立編譯環境() -> 編譯環境:
    根目錄 = os.path.dirname(os.path.abspath(__file__))
    return 編譯環境(根目錄, {}, {}, {}, set(), set(), set())


def _嘗試解析文言模組路徑(模組: str, 文檔名: str, 環境: 編譯環境) -> str | None:
    相對 = 模組.replace("/", os.sep)
    if 文檔名 in {"<言>", "<stdin>"}:
        當前目錄 = os.getcwd()
    else:
        路徑 = 文檔名
        if not os.path.isabs(路徑):
            路徑 = os.path.abspath(路徑)
        當前目錄 = os.path.dirname(路徑)
    根庫目錄 = os.path.join(環境.根目錄, "lib")
    平台庫目錄 = os.path.join(環境.根目錄, "lib", "py")
    if 相對 == "曆法":
        搜尋目錄 = [當前目錄, 根庫目錄, 平台庫目錄]
    else:
        搜尋目錄 = [當前目錄, 平台庫目錄, 根庫目錄]
    for 基 in 搜尋目錄:
        候選 = os.path.join(基, f"{相對}.wy")
        if os.path.isfile(候選):
            return os.path.abspath(候選)
        候選 = os.path.join(基, 相對, "序.wy")
        if os.path.isfile(候選):
            return os.path.abspath(候選)
    return None


def _讀取源碼(路徑: str, 環境: 編譯環境) -> str:
    if 路徑 in 環境.源碼快取:
        return 環境.源碼快取[路徑]
    with open(路徑, "r", encoding="utf-8") as 檔案:
        內容 = 檔案.read()
    環境.源碼快取[路徑] = 內容
    return 內容


AST位置 = tuple[int, int, int, int]
AST節點型 = TypeVar("AST節點型", bound=ast.AST)
_位置節點類快取: dict[type[ast.AST], bool] = {}


def _AST位置齊全(節點: ast.AST) -> bool:
    欄 = 節點.__dict__
    return (
        "lineno" in 欄
        and "col_offset" in 欄
        and "end_lineno" in 欄
        and "end_col_offset" in 欄
    )


def _寫入AST位置(節點: ast.AST, 位置: AST位置) -> None:
    節點類 = type(節點)
    若有 = _位置節點類快取.get(節點類)
    if 若有 is None:
        若有 = "lineno" in getattr(節點類, "_attributes", ())
        _位置節點類快取[節點類] = 若有
    if not 若有:
        return
    行, 列, 末行, 末列 = 位置
    setattr(節點, "lineno", 行)
    setattr(節點, "col_offset", 列)
    setattr(節點, "end_lineno", 末行)
    setattr(節點, "end_col_offset", 末列)


def _標注AST子樹(根: AST節點型, 位置: AST位置, 僅缺: bool = False) -> AST節點型:
    疊: list[ast.AST] = [根]
    while 疊:
        節點 = 疊.pop()
        if not (僅缺 and _AST位置齊全(節點)):
            _寫入AST位置(節點, 位置)
        疊.extend(ast.iter_child_nodes(節點))
    return 根


def _補齊AST位置(根: ast.AST, 預設位置: AST位置) -> None:
    疊: list[tuple[ast.AST, AST位置]] = [(根, 預設位置)]
    while 疊:
        節點, 承繼位置 = 疊.pop()
        當前位置 = 承繼位置
        if "lineno" in getattr(type(節點), "_attributes", ()):
            欄 = 節點.__dict__
            行 = 欄.get("lineno")
            列 = 欄.get("col_offset")
            末行 = 欄.get("end_lineno")
            末列 = 欄.get("end_col_offset")
            if (
                isinstance(行, int)
                and isinstance(列, int)
                and isinstance(末行, int)
                and isinstance(末列, int)
            ):
                當前位置 = (行, 列, 末行, 末列)
            else:
                _寫入AST位置(節點, 承繼位置)
                當前位置 = 承繼位置
            行, 列, 末行, 末列 = 當前位置
            if 行 < 1:
                raise AssertionError(f"AST位置非法行號: {type(節點).__name__}")
            if 列 < 0:
                raise AssertionError(f"AST位置非法列偏移: {type(節點).__name__}")
            if 末行 < 行:
                raise AssertionError(f"AST位置非法終止行: {type(節點).__name__}")
            if 末列 < 0:
                raise AssertionError(f"AST位置非法終止列: {type(節點).__name__}")
            if 末行 == 行 and 末列 < 列:
                raise AssertionError(f"AST位置終止早於起點: {type(節點).__name__}")
        for 子節點 in ast.iter_child_nodes(節點):
            疊.append((子節點, 當前位置))


def _載名(名: str) -> ast.Name:
    return ast.Name(名, ast.Load())


def _存名(名: str) -> ast.Name:
    return ast.Name(名, ast.Store())


def _叫函(函: ast.expr, 參: list[ast.expr]) -> ast.Call:
    return ast.Call(函, 參, [])


def _叫法(主: ast.expr, 名: str, 參: list[ast.expr]) -> ast.Call:
    return _叫函(ast.Attribute(主, 名, ast.Load()), 參)


def _作句(值: ast.expr) -> ast.Expr:
    return ast.Expr(值)


_返句 = ast.Return


def _串接(*項: ast.expr) -> ast.expr:
    式 = 項[0]
    for 子 in 項[1:]:
        式 = ast.BinOp(left=式, op=ast.Add(), right=子)
    return 式


def _展開(值: ast.expr) -> ast.Starred:
    return ast.Starred(值, ast.Load())


def _切片載(
    值: ast.expr,
    始: ast.expr | None = None,
    迄: ast.expr | None = None,
) -> ast.Subscript:
    return ast.Subscript(值, ast.Slice(始, 迄, None), ast.Load())


def _造屬性指派(主體名: str, 屬性名: str, 值: ast.expr) -> ast.Assign:
    return ast.Assign(
        targets=[
            ast.Attribute(
                value=ast.Name(id=主體名, ctx=ast.Load()),
                attr=屬性名,
                ctx=ast.Store(),
            )
        ],
        value=值,
    )


def _造參數列(
    參數: list[ast.arg] | None = None,
    其餘: ast.arg | None = None,
    預設: list[ast.expr] | None = None,
) -> ast.arguments:
    return ast.arguments(
        posonlyargs=[],
        args=[] if 參數 is None else 參數,
        vararg=其餘,
        kwonlyargs=[],
        kw_defaults=[],
        kwarg=None,
        defaults=[] if 預設 is None else 預設,
    )


def _造參(名: str) -> ast.arg:
    return ast.arg(arg=名, annotation=None)


def _造函節(名: str, 參數列: ast.arguments, 體: list[ast.stmt]) -> ast.FunctionDef:
    return ast.FunctionDef(
        name=名,
        args=參數列,
        body=體,
        decorator_list=[],
        returns=None,
        type_comment=None,
    )


def _造術呼叫函(函名: str, 位置: AST位置 | None = None) -> ast.FunctionDef:
    _載, _存, _叫 = _載名, _存名, _叫函

    def _全參呼() -> ast.Call:
        return _叫(_載("術"), [_展開(_載("args"))])

    函節 = _造函節(
        函名,
        _造參數列(
            [_造參("術")],
            _造參("args"),
        ),
        [
            ast.Try(
                body=[
                    ast.Assign(
                        targets=[_存("需")],
                        value=ast.Attribute(
                            value=_載("術"), attr="__文言術參數數__", ctx=ast.Load()
                        ),
                    )
                ],
                handlers=[
                    ast.ExceptHandler(
                        type=_載("AttributeError"),
                        name=None,
                        body=[_返句(_全參呼())],
                    )
                ],
                orelse=[],
                finalbody=[],
            ),
            ast.Assign(
                targets=[_存("接其餘")],
                value=_叫(
                    _載("getattr"),
                    [
                        _載("術"),
                        ast.Constant(value="__文言術接其餘__"),
                        ast.Constant(value=False),
                    ],
                ),
            ),
            ast.Assign(
                targets=[_存("已")],
                value=_叫(_載("len"), [_載("args")]),
            ),
            ast.If(
                test=ast.Compare(
                    left=_載("已"), ops=[ast.GtE()], comparators=[_載("需")]
                ),
                body=[
                    ast.If(
                        test=_載("接其餘"),
                        body=[_返句(_全參呼())],
                        orelse=[],
                    ),
                    ast.Assign(
                        targets=[_存("結")],
                        value=_叫(
                            _載("術"),
                            [_展開(_切片載(_載("args"), 迄=_載("需")))],
                        ),
                    ),
                    ast.If(
                        test=ast.Compare(
                            left=_載("已"), ops=[ast.Eq()], comparators=[_載("需")]
                        ),
                        body=[_返句(_載("結"))],
                        orelse=[],
                    ),
                    _返句(
                        _叫(
                            _載(函名),
                            [
                                _載("結"),
                                _展開(_切片載(_載("args"), 始=_載("需"))),
                            ],
                        )
                    ),
                ],
                orelse=[],
            ),
            _造函節(
                "_後續",
                _造參數列(其餘=_造參("後")),
                [
                    _返句(
                        _叫(
                            _載(函名),
                            [
                                _載("術"),
                                _展開(
                                    ast.BinOp(
                                        left=_載("args"),
                                        op=ast.Add(),
                                        right=_載("後"),
                                    )
                                ),
                            ],
                        )
                    )
                ],
            ),
            _造屬性指派(
                "_後續",
                "__文言術參數數__",
                ast.BinOp(left=_載("需"), op=ast.Sub(), right=_載("已")),
            ),
            _造屬性指派("_後續", "__文言術接其餘__", _載("接其餘")),
            _返句(_載("_後續")),
        ],
    )
    if 位置 is not None:
        _標注AST子樹(函節, 位置, 僅缺=False)
    return 函節


def _造輸出格式函(函名: str, 位置: AST位置 | None = None) -> ast.FunctionDef:
    _載, _存 = _載名, _存名
    _叫, _串加 = _叫函, _串接

    餘項文字函 = _造函節(
        "餘項文字",
        _造參數列([_造參("餘項")]),
        [
            ast.If(
                test=ast.Compare(
                    left=_載("餘項"),
                    ops=[ast.Eq()],
                    comparators=[ast.Constant(value=1)],
                ),
                body=[_返句(ast.Constant(value="... 1 more item"))],
                orelse=[],
            ),
            _返句(
                ast.JoinedStr(
                    values=[
                        ast.Constant(value="... "),
                        ast.FormattedValue(value=_載("餘項"), conversion=-1),
                        ast.Constant(value=" more items"),
                    ]
                )
            ),
        ],
    )

    可單行函 = _造函節(
        "可單行",
        _造參數列(
            [
                _造參("項列"),
                _造參("起算"),
                _造參("斷行寬"),
            ]
        ),
        [
            ast.Assign(
                targets=[_存("總長")],
                value=ast.BinOp(
                    left=_叫(_載("len"), [_載("項列")]),
                    op=ast.Add(),
                    right=_載("起算"),
                ),
            ),
            ast.If(
                test=ast.Compare(
                    left=ast.BinOp(
                        left=_載("總長"),
                        op=ast.Add(),
                        right=_叫(_載("len"), [_載("項列")]),
                    ),
                    ops=[ast.Gt()],
                    comparators=[_載("斷行寬")],
                ),
                body=[_返句(ast.Constant(value=False))],
                orelse=[],
            ),
            ast.For(
                target=_存("項"),
                iter=_載("項列"),
                body=[
                    ast.AugAssign(
                        target=_存("總長"),
                        op=ast.Add(),
                        value=_叫(_載("len"), [_載("項")]),
                    ),
                    ast.If(
                        test=ast.Compare(
                            left=_載("總長"),
                            ops=[ast.Gt()],
                            comparators=[_載("斷行寬")],
                        ),
                        body=[_返句(ast.Constant(value=False))],
                        orelse=[],
                    ),
                ],
                orelse=[],
            ),
            _返句(ast.Constant(value=True)),
        ],
    )

    分組列元素函 = _造函節(
        "分組列元素",
        _造參數列(
            [
                _造參("項列"),
                _造參("原列"),
                _造參("縮排"),
                _造參("斷行寬"),
                _造參("緊湊度"),
                _造參("列上限"),
            ]
        ),
        [
            ast.Assign(targets=[_存("總長")], value=ast.Constant(value=0)),
            ast.Assign(targets=[_存("最長")], value=ast.Constant(value=0)),
            ast.Assign(
                targets=[_存("可分組項數")], value=_叫(_載("len"), [_載("項列")])
            ),
            ast.If(
                test=ast.BoolOp(
                    op=ast.And(),
                    values=[
                        ast.Compare(
                            left=_叫(_載("len"), [_載("原列")]),
                            ops=[ast.Gt()],
                            comparators=[_載("列上限")],
                        ),
                        _載("項列"),
                    ],
                ),
                body=[
                    ast.AugAssign(
                        target=_存("可分組項數"),
                        op=ast.Sub(),
                        value=ast.Constant(value=1),
                    )
                ],
                orelse=[],
            ),
            ast.Assign(
                targets=[_存("資料長")],
                value=ast.BinOp(
                    left=ast.List(elts=[ast.Constant(value=0)], ctx=ast.Load()),
                    op=ast.Mult(),
                    right=_載("可分組項數"),
                ),
            ),
            ast.For(
                target=_存("索"),
                iter=_叫(_載("range"), [_載("可分組項數")]),
                body=[
                    ast.Assign(
                        targets=[_存("長度")],
                        value=_叫(
                            _載("len"),
                            [
                                ast.Subscript(
                                    value=_載("項列"),
                                    slice=_載("索"),
                                    ctx=ast.Load(),
                                )
                            ],
                        ),
                    ),
                    ast.Assign(
                        targets=[
                            ast.Subscript(
                                value=_載("資料長"), slice=_載("索"), ctx=ast.Store()
                            )
                        ],
                        value=_載("長度"),
                    ),
                    ast.AugAssign(
                        target=_存("總長"),
                        op=ast.Add(),
                        value=ast.BinOp(
                            left=_載("長度"),
                            op=ast.Add(),
                            right=ast.Constant(value=2),
                        ),
                    ),
                    ast.If(
                        test=ast.Compare(
                            left=_載("長度"), ops=[ast.Gt()], comparators=[_載("最長")]
                        ),
                        body=[ast.Assign(targets=[_存("最長")], value=_載("長度"))],
                        orelse=[],
                    ),
                ],
                orelse=[],
            ),
            ast.Assign(
                targets=[_存("欄寬")],
                value=ast.BinOp(
                    left=_載("最長"), op=ast.Add(), right=ast.Constant(value=2)
                ),
            ),
            ast.If(
                test=ast.UnaryOp(
                    op=ast.Not(),
                    operand=ast.BoolOp(
                        op=ast.And(),
                        values=[
                            ast.Compare(
                                left=ast.BinOp(
                                    left=ast.BinOp(
                                        left=_載("欄寬"),
                                        op=ast.Mult(),
                                        right=ast.Constant(value=3),
                                    ),
                                    op=ast.Add(),
                                    right=_載("縮排"),
                                ),
                                ops=[ast.Lt()],
                                comparators=[_載("斷行寬")],
                            ),
                            ast.BoolOp(
                                op=ast.Or(),
                                values=[
                                    ast.Compare(
                                        left=ast.BinOp(
                                            left=_載("總長"),
                                            op=ast.Div(),
                                            right=_載("欄寬"),
                                        ),
                                        ops=[ast.Gt()],
                                        comparators=[ast.Constant(value=5)],
                                    ),
                                    ast.Compare(
                                        left=_載("最長"),
                                        ops=[ast.LtE()],
                                        comparators=[ast.Constant(value=6)],
                                    ),
                                ],
                            ),
                        ],
                    ),
                ),
                body=[_返句(_載("項列"))],
                orelse=[],
            ),
            ast.Assign(
                targets=[_存("偏置")],
                value=ast.BinOp(
                    left=_叫(
                        _載("max"),
                        [
                            ast.BinOp(
                                left=_載("欄寬"),
                                op=ast.Sub(),
                                right=ast.BinOp(
                                    left=_載("總長"),
                                    op=ast.Div(),
                                    right=_叫(_載("len"), [_載("項列")]),
                                ),
                            ),
                            ast.Constant(value=0.0),
                        ],
                    ),
                    op=ast.Pow(),
                    right=ast.Constant(value=0.5),
                ),
            ),
            ast.Assign(
                targets=[_存("估欄寬")],
                value=_叫(
                    _載("max"),
                    [
                        ast.BinOp(
                            left=ast.BinOp(
                                left=_載("欄寬"),
                                op=ast.Sub(),
                                right=ast.Constant(value=3),
                            ),
                            op=ast.Sub(),
                            right=_載("偏置"),
                        ),
                        ast.Constant(value=1),
                    ],
                ),
            ),
            ast.Assign(
                targets=[_存("欄數")],
                value=_叫(
                    _載("min"),
                    [
                        _叫(
                            _載("round"),
                            [
                                ast.BinOp(
                                    left=ast.BinOp(
                                        left=ast.BinOp(
                                            left=ast.BinOp(
                                                left=ast.Constant(value=2.5),
                                                op=ast.Mult(),
                                                right=_載("估欄寬"),
                                            ),
                                            op=ast.Mult(),
                                            right=_載("可分組項數"),
                                        ),
                                        op=ast.Pow(),
                                        right=ast.Constant(value=0.5),
                                    ),
                                    op=ast.Div(),
                                    right=_載("估欄寬"),
                                ),
                            ],
                        ),
                        ast.BinOp(
                            left=ast.BinOp(
                                left=_載("斷行寬"),
                                op=ast.Sub(),
                                right=_載("縮排"),
                            ),
                            op=ast.FloorDiv(),
                            right=_叫(_載("max"), [_載("欄寬"), ast.Constant(value=1)]),
                        ),
                        ast.BinOp(
                            left=_載("緊湊度"),
                            op=ast.Mult(),
                            right=ast.Constant(value=4),
                        ),
                        ast.Constant(value=15),
                    ],
                ),
            ),
            ast.If(
                test=ast.Compare(
                    left=_載("欄數"),
                    ops=[ast.LtE()],
                    comparators=[ast.Constant(value=1)],
                ),
                body=[_返句(_載("項列"))],
                orelse=[],
            ),
            ast.Assign(
                targets=[_存("各欄寬")], value=ast.List(elts=[], ctx=ast.Load())
            ),
            ast.For(
                target=_存("欄"),
                iter=_叫(_載("range"), [_載("欄數")]),
                body=[
                    ast.Assign(targets=[_存("行最長")], value=ast.Constant(value=0)),
                    ast.For(
                        target=_存("索"),
                        iter=_叫(
                            _載("range"),
                            [_載("欄"), _載("可分組項數"), _載("欄數")],
                        ),
                        body=[
                            ast.If(
                                test=ast.Compare(
                                    left=ast.Subscript(
                                        value=_載("資料長"),
                                        slice=_載("索"),
                                        ctx=ast.Load(),
                                    ),
                                    ops=[ast.Gt()],
                                    comparators=[_載("行最長")],
                                ),
                                body=[
                                    ast.Assign(
                                        targets=[_存("行最長")],
                                        value=ast.Subscript(
                                            value=_載("資料長"),
                                            slice=_載("索"),
                                            ctx=ast.Load(),
                                        ),
                                    )
                                ],
                                orelse=[],
                            )
                        ],
                        orelse=[],
                    ),
                    _作句(
                        _叫法(
                            _載("各欄寬"),
                            "append",
                            [
                                ast.BinOp(
                                    left=_載("行最長"),
                                    op=ast.Add(),
                                    right=ast.Constant(value=2),
                                )
                            ],
                        )
                    ),
                ],
                orelse=[],
            ),
            ast.Assign(targets=[_存("左補齊")], value=ast.Constant(value=True)),
            ast.For(
                target=_存("元"),
                iter=_切片載(_載("原列"), 迄=_載("可分組項數")),
                body=[
                    ast.If(
                        test=ast.BoolOp(
                            op=ast.Or(),
                            values=[
                                _叫(_載("isinstance"), [_載("元"), _載("bool")]),
                                ast.UnaryOp(
                                    op=ast.Not(),
                                    operand=_叫(
                                        _載("isinstance"),
                                        [
                                            _載("元"),
                                            ast.Tuple(
                                                elts=[_載("int"), _載("float")],
                                                ctx=ast.Load(),
                                            ),
                                        ],
                                    ),
                                ),
                            ],
                        ),
                        body=[
                            ast.Assign(
                                targets=[_存("左補齊")], value=ast.Constant(value=False)
                            ),
                            ast.Break(),
                        ],
                        orelse=[],
                    )
                ],
                orelse=[],
            ),
            ast.Assign(targets=[_存("分組")], value=ast.List(elts=[], ctx=ast.Load())),
            ast.For(
                target=_存("首"),
                iter=_叫(
                    _載("range"),
                    [ast.Constant(value=0), _載("可分組項數"), _載("欄數")],
                ),
                body=[
                    ast.Assign(
                        targets=[_存("末")],
                        value=_叫(
                            _載("min"),
                            [
                                ast.BinOp(
                                    left=_載("首"),
                                    op=ast.Add(),
                                    right=_載("欄數"),
                                ),
                                _載("可分組項數"),
                            ],
                        ),
                    ),
                    ast.Assign(
                        targets=[_存("行片")], value=ast.List(elts=[], ctx=ast.Load())
                    ),
                    ast.For(
                        target=_存("索"),
                        iter=_叫(
                            _載("range"),
                            [
                                _載("首"),
                                ast.BinOp(
                                    left=_載("末"),
                                    op=ast.Sub(),
                                    right=ast.Constant(value=1),
                                ),
                            ],
                        ),
                        body=[
                            ast.Assign(
                                targets=[_存("欄位文")],
                                value=ast.JoinedStr(
                                    values=[
                                        ast.FormattedValue(
                                            value=ast.Subscript(
                                                value=_載("項列"),
                                                slice=_載("索"),
                                                ctx=ast.Load(),
                                            ),
                                            conversion=-1,
                                        ),
                                        ast.Constant(value=", "),
                                    ]
                                ),
                            ),
                            ast.Assign(
                                targets=[_存("欄寬度")],
                                value=ast.Subscript(
                                    value=_載("各欄寬"),
                                    slice=ast.BinOp(
                                        left=_載("索"),
                                        op=ast.Sub(),
                                        right=_載("首"),
                                    ),
                                    ctx=ast.Load(),
                                ),
                            ),
                            _作句(
                                _叫法(
                                    _載("行片"),
                                    "append",
                                    [
                                        ast.IfExp(
                                            test=_載("左補齊"),
                                            body=_叫法(
                                                _載("欄位文"),
                                                "rjust",
                                                [_載("欄寬度")],
                                            ),
                                            orelse=_叫法(
                                                _載("欄位文"),
                                                "ljust",
                                                [_載("欄寬度")],
                                            ),
                                        )
                                    ],
                                )
                            ),
                        ],
                        orelse=[],
                    ),
                    ast.Assign(
                        targets=[_存("尾索")],
                        value=ast.BinOp(
                            left=_載("末"), op=ast.Sub(), right=ast.Constant(value=1)
                        ),
                    ),
                    ast.If(
                        test=_載("左補齊"),
                        body=[
                            _作句(
                                _叫法(
                                    _載("行片"),
                                    "append",
                                    [
                                        _叫法(
                                            ast.Subscript(
                                                value=_載("項列"),
                                                slice=_載("尾索"),
                                                ctx=ast.Load(),
                                            ),
                                            "rjust",
                                            [
                                                _叫(
                                                    _載("max"),
                                                    [
                                                        ast.BinOp(
                                                            left=ast.Subscript(
                                                                value=_載("各欄寬"),
                                                                slice=ast.BinOp(
                                                                    left=_載("尾索"),
                                                                    op=ast.Sub(),
                                                                    right=_載("首"),
                                                                ),
                                                                ctx=ast.Load(),
                                                            ),
                                                            op=ast.Sub(),
                                                            right=ast.Constant(value=2),
                                                        ),
                                                        ast.Constant(value=0),
                                                    ],
                                                )
                                            ],
                                        )
                                    ],
                                )
                            )
                        ],
                        orelse=[
                            _作句(
                                _叫法(
                                    _載("行片"),
                                    "append",
                                    [
                                        ast.Subscript(
                                            value=_載("項列"),
                                            slice=_載("尾索"),
                                            ctx=ast.Load(),
                                        )
                                    ],
                                )
                            )
                        ],
                    ),
                    _作句(
                        _叫法(
                            _載("分組"),
                            "append",
                            [
                                _叫法(
                                    ast.Constant(value=""),
                                    "join",
                                    [_載("行片")],
                                )
                            ],
                        )
                    ),
                ],
                orelse=[],
            ),
            ast.If(
                test=ast.Compare(
                    left=_叫(_載("len"), [_載("原列")]),
                    ops=[ast.Gt()],
                    comparators=[_載("列上限")],
                ),
                body=[
                    _作句(
                        _叫法(
                            _載("分組"),
                            "append",
                            [
                                ast.Subscript(
                                    value=_載("項列"),
                                    slice=_載("可分組項數"),
                                    ctx=ast.Load(),
                                )
                            ],
                        )
                    )
                ],
                orelse=[],
            ),
            _返句(_載("分組")),
        ],
    )

    分隔 = _串加(ast.Constant(value=","), _載("前綴"), ast.Constant(value="  "))
    格式列函 = _造函節(
        "格式列",
        _造參數列(
            [
                _造參("列值"),
                _造參("縮排"),
            ]
        ),
        [
            ast.Assign(targets=[_存("斷行寬")], value=ast.Constant(value=80)),
            ast.Assign(targets=[_存("緊湊度")], value=ast.Constant(value=3)),
            ast.Assign(targets=[_存("列上限")], value=ast.Constant(value=100)),
            ast.Assign(
                targets=[_存("項列")],
                value=ast.ListComp(
                    elt=_叫(
                        _載(函名),
                        [
                            _載("元"),
                            ast.BinOp(
                                left=_載("縮排"),
                                op=ast.Add(),
                                right=ast.Constant(value=2),
                            ),
                        ],
                    ),
                    generators=[
                        ast.comprehension(
                            target=_存("元"),
                            iter=_切片載(_載("列值"), 迄=_載("列上限")),
                            ifs=[],
                            is_async=0,
                        )
                    ],
                ),
            ),
            ast.If(
                test=ast.Compare(
                    left=_叫(_載("len"), [_載("列值")]),
                    ops=[ast.Gt()],
                    comparators=[_載("列上限")],
                ),
                body=[
                    _作句(
                        _叫法(
                            _載("項列"),
                            "append",
                            [
                                _叫(
                                    _載("餘項文字"),
                                    [
                                        ast.BinOp(
                                            left=_叫(_載("len"), [_載("列值")]),
                                            op=ast.Sub(),
                                            right=_載("列上限"),
                                        )
                                    ],
                                )
                            ],
                        )
                    )
                ],
                orelse=[],
            ),
            ast.Assign(targets=[_存("原長")], value=_叫(_載("len"), [_載("項列")])),
            ast.If(
                test=ast.BoolOp(
                    op=ast.And(),
                    values=[
                        _載("項列"),
                        ast.Compare(
                            left=_載("緊湊度"),
                            ops=[ast.GtE()],
                            comparators=[ast.Constant(value=1)],
                        ),
                        ast.Compare(
                            left=_叫(_載("len"), [_載("項列")]),
                            ops=[ast.Gt()],
                            comparators=[ast.Constant(value=6)],
                        ),
                    ],
                ),
                body=[
                    ast.Assign(
                        targets=[_存("項列")],
                        value=_叫(
                            _載("分組列元素"),
                            [
                                _載("項列"),
                                _載("列值"),
                                _載("縮排"),
                                _載("斷行寬"),
                                _載("緊湊度"),
                                _載("列上限"),
                            ],
                        ),
                    )
                ],
                orelse=[],
            ),
            ast.If(
                test=ast.Compare(
                    left=_載("原長"),
                    ops=[ast.Eq()],
                    comparators=[_叫(_載("len"), [_載("項列")])],
                ),
                body=[
                    ast.Assign(
                        targets=[_存("起算")],
                        value=ast.BinOp(
                            left=ast.BinOp(
                                left=ast.BinOp(
                                    left=_叫(_載("len"), [_載("項列")]),
                                    op=ast.Add(),
                                    right=_載("縮排"),
                                ),
                                op=ast.Add(),
                                right=ast.Constant(value=1),
                            ),
                            op=ast.Add(),
                            right=ast.Constant(value=10),
                        ),
                    ),
                    ast.If(
                        test=_叫(
                            _載("可單行"),
                            [_載("項列"), _載("起算"), _載("斷行寬")],
                        ),
                        body=[
                            ast.Assign(
                                targets=[_存("併")],
                                value=_叫法(
                                    ast.Constant(value=", "),
                                    "join",
                                    [_載("項列")],
                                ),
                            ),
                            ast.If(
                                test=ast.Compare(
                                    left=ast.Constant(value="\n"),
                                    ops=[ast.NotIn()],
                                    comparators=[_載("併")],
                                ),
                                body=[
                                    _返句(
                                        ast.JoinedStr(
                                            values=[
                                                ast.Constant(value="[ "),
                                                ast.FormattedValue(
                                                    value=_載("併"), conversion=-1
                                                ),
                                                ast.Constant(value=" ]"),
                                            ]
                                        )
                                    )
                                ],
                                orelse=[],
                            ),
                        ],
                        orelse=[],
                    ),
                ],
                orelse=[],
            ),
            ast.Assign(
                targets=[_存("前綴")],
                value=_串加(
                    ast.Constant(value="\n"),
                    ast.BinOp(
                        left=ast.Constant(value=" "),
                        op=ast.Mult(),
                        right=_載("縮排"),
                    ),
                ),
            ),
            _返句(
                _串加(
                    ast.Constant(value="["),
                    _載("前綴"),
                    ast.Constant(value="  "),
                    _叫法(分隔, "join", [_載("項列")]),
                    _載("前綴"),
                    ast.Constant(value="]"),
                )
            ),
        ],
    )

    函節 = _造函節(
        函名,
        _造參數列(
            [
                _造參("值"),
                _造參("縮排"),
            ],
            預設=[ast.Constant(value=0)],
        ),
        [
            餘項文字函,
            可單行函,
            分組列元素函,
            格式列函,
            ast.If(
                test=_叫(_載("isinstance"), [_載("值"), _載("bool")]),
                body=[
                    _返句(
                        ast.IfExp(
                            test=_載("值"),
                            body=ast.Constant(value="true"),
                            orelse=ast.Constant(value="false"),
                        )
                    )
                ],
                orelse=[],
            ),
            ast.If(
                test=_叫(_載("isinstance"), [_載("值"), _載("float")]),
                body=[
                    ast.If(
                        test=_叫法(_載("值"), "is_integer", []),
                        body=[_返句(_叫(_載("str"), [_叫(_載("int"), [_載("值")])]))],
                        orelse=[],
                    ),
                    _返句(_叫(_載("str"), [_載("值")])),
                ],
                orelse=[],
            ),
            ast.If(
                test=_叫(_載("isinstance"), [_載("值"), _載("int")]),
                body=[_返句(_叫(_載("str"), [_載("值")]))],
                orelse=[],
            ),
            ast.If(
                test=_叫(_載("isinstance"), [_載("值"), _載("list")]),
                body=[_返句(_叫(_載("格式列"), [_載("值"), _載("縮排")]))],
                orelse=[],
            ),
            ast.If(
                test=ast.Compare(
                    left=_載("值"),
                    ops=[ast.Is()],
                    comparators=[ast.Constant(value=None)],
                ),
                body=[_返句(ast.Constant(value="None"))],
                orelse=[],
            ),
            _返句(_叫(_載("str"), [_載("值")])),
        ],
    )
    if 位置 is not None:
        _標注AST子樹(函節, 位置, 僅缺=False)
    return 函節


內建序言源碼 = """
import json

__暫存 = []
__文言負索 = {}


def __其():
    if not __暫存:
        return None
    __其值 = __暫存[-1]
    __暫存.clear()
    return __其值


def __取(數量):
    if 數量 <= 0:
        return []
    if 數量 > len(__暫存):
        raise 文言之禍("虛指", "取值不足")
    片 = __暫存[-數量:]
    del __暫存[-數量:]
    return 片


def __取其餘():
    if not __暫存:
        return []
    片 = __暫存[:]
    __暫存.clear()
    return 片


def 取物(物, 端):
    if isinstance(端, str):
        if isinstance(物, dict):
            return 物.get(端)
        try:
            return 物[端]
        except Exception:
            try:
                return getattr(物, 端)
            except Exception:
                return None

    索 = int(端)
    if isinstance(物, list):
        if 索 <= 0:
            return __文言負索.get((id(物), 索))
        if 索 > len(物):
            return None
        return 物[索 - 1]

    try:
        return 物[索 - 1]
    except Exception:
        return None


def 置物(物, 端, 實):
    if isinstance(端, str):
        try:
            物[端] = 實
        except Exception:
            return 實
        return 實

    索 = int(端)
    if isinstance(物, list):
        if 索 <= 0:
            __文言負索[(id(物), 索)] = 實
            return 實
        索 -= 1
        if 索 >= len(物):
            物.extend([None] * (索 - len(物) + 1))
        物[索] = 實
        return 實

    物[索 - 1] = 實
    return 實


def 刪物(物, 端):
    if isinstance(端, str):
        if isinstance(物, dict):
            物.pop(端, None)
            return None
        try:
            del 物[端]
        except Exception:
            return None
        return None

    索 = int(端)
    if isinstance(物, list):
        if 索 <= 0:
            __文言負索.pop((id(物), 索), None)
            return None
        if 索 <= len(物):
            del 物[索 - 1]
        return None

    try:
        del 物[索 - 1]
    except Exception:
        return None
    return None


def 列物之端(物):
    if isinstance(物, dict):
        return list(物.keys())
    try:
        return list(物)
    except Exception:
        return []


def 識類(元):
    if isinstance(元, list):
        return "列"
    if isinstance(元, bool):
        return "爻"
    if isinstance(元, (int, float)):
        return "數"
    if isinstance(元, str):
        return "言"
    if callable(元):
        return "術"
    if isinstance(元, dict):
        return "物"
    return "元"


def 文言轉整(值, 預設=0):
    try:
        return int(float(值))
    except (TypeError, ValueError):
        return int(預設)


def 除零商(左):
    try:
        值 = float(左)
    except (TypeError, ValueError):
        return float('nan')
    if 值 == 0:
        return float('nan')
    return float('inf') if 值 > 0 else float('-inf')


def 除零餘():
    return float('nan')


def 空術(*_參):
    return 空術


def 載模組(模組名):
    return __import__(模組名)


class 文言之禍(Exception):
    def __init__(self, 名, 訊=None):
        super().__init__(訊)
        self.名 = 名
        self.訊 = 訊

    def __getitem__(self, 鍵):
        if 鍵 == "名":
            return self.名
        if 鍵 == "訊":
            return self.訊
        return None


class JSON:
    @staticmethod
    def _正規(物):
        if isinstance(物, float) and 物.is_integer():
            return int(物)
        if isinstance(物, list):
            return [JSON._正規(元) for 元 in 物]
        if isinstance(物, dict):
            return {鍵: JSON._正規(值) for 鍵, 值 in 物.items()}
        return 物

    @staticmethod
    def stringify(物):
        try:
            return json.dumps(JSON._正規(物), ensure_ascii=False, separators=(",", ":"))
        except TypeError:
            return str(物)


class String:
    @staticmethod
    def fromCharCode(值):
        try:
            return chr(int(值))
        except (TypeError, ValueError):
            return ""


JSON.stringify.__文言術參數數__ = 1
String.fromCharCode.__文言術參數數__ = 1
取物.__文言術參數數__ = 2
置物.__文言術參數數__ = 3
刪物.__文言術參數數__ = 2
列物之端.__文言術參數數__ = 1
識類.__文言術參數數__ = 1
除零商.__文言術參數數__ = 1
除零餘.__文言術參數數__ = 0
空術.__文言術參數數__ = 1
載模組.__文言術參數數__ = 1
"""


def _掃描匯入(內容: str, 文檔名: str) -> list[tuple[str, slice]]:
    符列 = list(詞法分析器(內容, 文檔名))
    結果: list[tuple[str, slice]] = []
    索引 = 0
    while 索引 < len(符列):
        符 = 符列[索引]
        if 符.值 is None and 符.類别 == "吾嘗觀":
            if 索引 + 1 < len(符列):
                書符 = 符列[索引 + 1]
                if 書符.類别 == "言" and 書符.值 is not None:
                    結果.append((_還原言值(書符.值), 符.位置))
                    索引 += 2
                    continue
        索引 += 1
    return 結果


def _編譯宏(模式: str, 置換: str) -> 宏定義:
    佔位符 = "甲乙丙丁戊己庚辛壬癸"
    片段: list[str] = []
    佔位列: list[str] = []
    索引 = 0
    while 索引 < len(模式):
        if (
            模式[索引] == "「"
            and 索引 + 2 < len(模式)
            and 模式[索引 + 2] == "」"
            and 模式[索引 + 1] in 佔位符
        ):
            片段.append("(.+?)")
            佔位列.append(模式[索引 + 1])
            索引 += 3
            continue
        片段.append(re.escape(模式[索引]))
        索引 += 1
    正則 = re.compile("".join(片段))
    return 宏定義(模式, 置換, 正則, 佔位列)


def 收集宏(內容: str, 文檔名: str) -> list[宏定義]:
    符列 = list(詞法分析器(內容, 文檔名))
    結果: list[宏定義] = []
    索引 = 0
    while 索引 < len(符列):
        符 = 符列[索引]
        if 符.值 is None and 符.類别 == "或云":
            if 索引 + 3 < len(符列):
                模式符 = 符列[索引 + 1]
                謂符 = 符列[索引 + 2]
                置換符 = 符列[索引 + 3]
                if (
                    模式符.類别 == "言"
                    and 模式符.值 is not None
                    and 謂符.值 is None
                    and 謂符.類别 == "蓋謂"
                    and 置換符.類别 == "言"
                    and 置換符.值 is not None
                ):
                    模式 = _還原言值(模式符.值)
                    置換 = _還原言值(置換符.值)
                    結果.append(_編譯宏(模式, 置換))
                    索引 += 4
                    continue
        索引 += 1
    return 結果


def _替換宏(宏: 宏定義, 匹配: re.Match) -> str:
    置換 = 宏.置換
    if not 宏.占位列:
        return 置換
    佔位符 = "甲乙丙丁戊己庚辛壬癸"
    片段: list[str] = []
    索引 = 0
    while 索引 < len(置換):
        if (
            置換[索引] == "「"
            and 索引 + 2 < len(置換)
            and 置換[索引 + 2] == "」"
            and 置換[索引 + 1] in 佔位符
        ):
            佔位 = 置換[索引 + 1]
            if 佔位 in 宏.占位列:
                序 = 宏.占位列.index(佔位)
                片段.append(匹配.group(序 + 1))
            else:
                片段.append("「" + 佔位 + "」")
            索引 += 3
            continue
        片段.append(置換[索引])
        索引 += 1
    return "".join(片段)


def _跳過引號(內容: str, 起點: int, 文檔名: str) -> int:
    if 內容.startswith("「「", 起點):
        索引 = 起點 + 2
        層級 = 2
    elif 內容.startswith("『", 起點):
        索引 = 起點 + 1
        層級 = 2
    elif 內容.startswith("「", 起點):
        索引 = 內容.find("」", 起點 + 1)
        if 索引 == -1:
            _前處理錯誤(內容, 文檔名, "名未尽", 起點)
        return 索引 + 1
    else:
        return 起點 + 1
    while 索引 < len(內容):
        字 = 內容[索引]
        if 字 == "「":
            層級 += 1
            索引 += 1
            continue
        if 字 == "」":
            層級 -= 1
            索引 += 1
            if 層級 == 0:
                return 索引
            continue
        if 字 == "『":
            層級 += 2
            索引 += 1
            continue
        if 字 == "』":
            層級 -= 2
            索引 += 1
            if 層級 == 0:
                return 索引
            continue
        索引 += 1
    _前處理錯誤(內容, 文檔名, "言未尽", 起點)
    raise AssertionError("unreachable")


def 擴展宏(內容: str, 宏列: list[宏定義], 文檔名: str) -> str:
    if not 宏列:
        return 內容
    for 宏 in 宏列:
        起始 = 0
        while True:
            字串範圍: list[tuple[int, int]] = []
            索引 = 0
            while 索引 < len(內容):
                if 內容.startswith("「「", 索引) or 內容.startswith("『", 索引):
                    終 = _跳過引號(內容, 索引, 文檔名)
                    字串範圍.append((索引, 終))
                    索引 = 終
                    continue
                索引 += 1

            匹配 = 宏.正則.search(內容, 起始)
            if 匹配 is None:
                break
            起點 = 匹配.start()
            範圍終: int | None = None
            for 左, 右 in 字串範圍:
                if 左 <= 起點 < 右:
                    範圍終 = 右
                    break
            if 範圍終 is not None:
                起始 = 範圍終
                continue
            替換 = _替換宏(宏, 匹配)
            內容 = 內容[: 匹配.start()] + 替換 + 內容[匹配.end() :]
            起始 = 匹配.start()
    return 內容


def _收集宏遞迴(
    路徑: str, 文檔名: str, 內容: str, 位置: slice, 環境: 編譯環境
) -> list[宏定義]:
    if 路徑 in 環境.宏快取:
        return 環境.宏快取[路徑]
    if 路徑 in 環境.宏解析中:
        _前處理錯誤(內容, 文檔名, "循環匯入", 位置.start)
    環境.宏解析中.add(路徑)
    原文 = _讀取源碼(路徑, 環境)
    匯入列 = _掃描匯入(原文, 路徑)
    宏列: list[宏定義] = []
    for 模組, 位 in 匯入列:
        模組路徑 = _嘗試解析文言模組路徑(模組, 路徑, 環境)
        if 模組路徑 is None:
            continue
        宏列.extend(_收集宏遞迴(模組路徑, 路徑, 原文, 位, 環境))
    宏列.extend(收集宏(原文, 路徑))
    環境.宏解析中.remove(路徑)
    環境.宏快取[路徑] = 宏列
    return 宏列


def _前處理源碼(內容: str, 文檔名: str, 環境: 編譯環境) -> str:
    匯入列 = _掃描匯入(內容, 文檔名)
    宏列: list[宏定義] = []
    for 模組, 位 in 匯入列:
        模組路徑 = _嘗試解析文言模組路徑(模組, 文檔名, 環境)
        if 模組路徑 is None:
            continue
        宏列.extend(_收集宏遞迴(模組路徑, 文檔名, 內容, 位, 環境))
    宏列.extend(收集宏(內容, 文檔名))
    return 擴展宏(內容, 宏列, 文檔名)


def _解析前處理(內容: str, 文檔名: str, 環境: 編譯環境) -> tuple[程式, str]:
    處理後 = _前處理源碼(內容, 文檔名, 環境)
    程 = 文法分析器(處理後, 文檔名).解析程式()
    return 程, 處理後


def 解析(內容: str, 文檔名: str = "<言>") -> 程式:
    """文言源碼轉 Wenyan AST。"""

    環境 = _建立編譯環境()
    程, _ = _解析前處理(內容, 文檔名, 環境)
    return 程


def _還原言值(文: str) -> str:
    """將 lexer 的最小轉義字串還原成真實字元。"""

    return 文.replace("\\n", "\n").replace('\\"', '"')


@dataclass
class 作用域資訊:
    """函數作用域所需宣告。"""

    全域: set[str]
    非區: set[str]


@dataclass
class _作用域節點:
    父: "_作用域節點 | None"
    本地: set[str]
    賦值: set[str]
    子: "list[_作用域節點]"
    術節: 術定義句 | None


def _分析作用域(句列: list[句]) -> dict[int, 作用域資訊]:
    根 = _作用域節點(None, set(), set(), [], None)

    def 收集(列: list[句], 節點: _作用域節點) -> None:
        for 節 in 列:
            if isinstance(節, (宣告句, 命名句)):
                節點.本地.update(節.名列)
            elif isinstance(節, 初始化句):
                if 節.名 is not None:
                    節點.本地.add(節.名)
            elif isinstance(節, (凡句, 恆為是句, 為是遍句)):
                if isinstance(節, 凡句):
                    節點.本地.add(節.變數名)
                收集(節.體, 節點)
            elif isinstance(節, 試句):
                收集(節.體, 節點)
                for 捕 in 節.捕捉列:
                    if 捕.變數名 is not None:
                        節點.本地.add(捕.變數名)
                    收集(捕.體, 節點)
            elif isinstance(節, 若句):
                收集(節.然, 節點)
                收集(節.否則, 節點)
                for 或若 in 節.另若列:
                    收集(或若.體, 節點)
            elif isinstance(節, (物定義句, 術定義句)):
                節點.本地.add(節.名)
                if isinstance(節, 術定義句):
                    子節 = _作用域節點(節點, set(), set(), [], 節)
                    子節.本地.update(參.名 for 參 in 節.參數列)
                    節點.子.append(子節)
                    收集(節.體, 子節)
            elif isinstance(節, 昔今句) and 節.左下標 is None:
                節點.賦值.add(節.左名)

    def 計算(節點: _作用域節點, 結果: dict[int, 作用域資訊]) -> None:
        for 子 in 節點.子:
            全域: set[str] = set()
            非區: set[str] = set()
            for 名 in 子.賦值:
                if 名 in 子.本地:
                    continue
                父 = 子.父
                while 父 is not None:
                    if 名 in 父.本地:
                        if 父.術節 is None:
                            全域.add(名)
                        else:
                            非區.add(名)
                        break
                    父 = 父.父
                else:
                    全域.add(名)
            if 子.術節 is not None:
                結果[id(子.術節)] = 作用域資訊(全域, 非區)
            計算(子, 結果)

    收集(句列, 根)
    結果: dict[int, 作用域資訊] = {}
    計算(根, 結果)
    return 結果


class PythonAST轉譯器:
    """將 Wenyan AST 轉譯為 Python `ast`。"""

    def __init__(
        self,
        內容: str,
        文檔名: str = "<言>",
        環境: 編譯環境 | None = None,
        插入序言: bool = True,
    ) -> None:
        self.內容 = 內容
        self.文檔名 = 文檔名
        self._內部序 = 0
        檔鑰 = 文檔名 if os.path.isabs(文檔名) else os.path.abspath(文檔名)
        self._內部前綴 = f"{abs(hash(檔鑰)) & 0xFFFF:x}"
        self._暫存名 = "__暫存"
        self._其函名 = "__其"
        self._待取數: int | None = None
        self._待取其餘 = False
        self._作用域資訊: dict[int, 作用域資訊] = {}
        self._環境 = 環境 if 環境 is not None else _建立編譯環境()
        self._插入序言 = 插入序言
        self._輸出格式函名 = "__輸出格式值"
        self._行首偏移: list[int] = [0]
        self._片段位置快取: dict[tuple[int, int], AST位置] = {}
        for 索引, 字 in enumerate(self.內容):
            if 字 == "\n":
                self._行首偏移.append(索引 + 1)

    def 轉譯(self, 程: 程式) -> ast.Module:
        """轉譯整個程式。"""

        模組錨點 = 程.句列[0].位置 if 程.句列 else slice(0, 0)
        模組位置 = self._片段轉位置(模組錨點)
        主體: list[ast.stmt] = []
        if self._插入序言:
            序言 = ast.parse(內建序言源碼, filename="<內建序言>").body
            for 句 in 序言:
                _標注AST子樹(句, 模組位置, 僅缺=False)
            主體.extend(序言)
        主體.append(_造輸出格式函(self._輸出格式函名, 模組位置))
        主體.extend(self._轉譯句列(程))
        模組 = ast.Module(body=主體, type_ignores=[])
        _補齊AST位置(模組, 模組位置)
        return 模組

    def _轉譯句列(self, 程: 程式) -> list[ast.stmt]:
        self._待取數 = None
        self._待取其餘 = False
        self._作用域資訊 = _分析作用域(程.句列)
        return self._轉句列(程.句列)

    def _新內部名(self, 前綴: str) -> str:
        self._內部序 += 1
        名 = f"__{前綴}{self._內部前綴}_{self._內部序}"
        return 名 if 名.isidentifier() else f"__tmp{self._內部前綴}_{self._內部序}"

    def _拋出文法錯誤(self, 訊息: str, 索引: int) -> None:
        行號, 列偏移, 行文字 = 計算行列(self.內容, 索引)
        raise 文法之禍(訊息, (self.文檔名, 行號, 列偏移, 行文字))

    def _檢名(self, 名: str, 位置: slice) -> None:
        if not 名.isidentifier() or keyword.iskeyword(名):
            self._拋出文法錯誤("名不合 Python 識別字", 位置.start)

    def _偏移轉行列(self, 偏移: int) -> tuple[int, int]:
        長度 = len(self.內容)
        夾住 = max(0, min(偏移, 長度))
        行索引 = max(bisect_right(self._行首偏移, 夾住) - 1, 0)
        行首 = self._行首偏移[行索引]
        return 行索引 + 1, 夾住 - 行首

    def _片段轉位置(self, 位置: slice) -> AST位置:
        起 = 0 if 位置.start is None else 位置.start
        迄 = 起 if 位置.stop is None else 位置.stop
        if 迄 < 起:
            迄 = 起
        鍵 = (起, 迄)
        若有 = self._片段位置快取.get(鍵)
        if 若有 is not None:
            return 若有
        行, 列 = self._偏移轉行列(起)
        末行, 末列 = self._偏移轉行列(迄)
        結果 = (行, 列, 末行, 末列)
        self._片段位置快取[鍵] = 結果
        return 結果

    def _標注並返(self, 節點: AST節點型, 位置: slice, 僅缺: bool = False) -> AST節點型:
        if not (僅缺 and _AST位置齊全(節點)):
            _寫入AST位置(節點, self._片段轉位置(位置))
        return 節點

    def _轉JS片段(self, 文: str) -> ast.expr | None:
        簡 = "".join(文.split())
        if 簡 == '(()=>document.getElementById("out").innerHTML="")':
            return ast.Lambda(
                args=_造參數列(),
                body=ast.Constant(value=None),
            )
        if re.fullmatch(r"\(x=>setInterval\(x,\d+\)\)", 簡):
            return ast.Lambda(
                args=_造參數列([_造參("x")]),
                body=_叫函(_載名("x"), []),
            )
        return None

    def _轉值(self, 節: 值) -> ast.expr:
        if isinstance(節, 名值):
            if 節.名.isidentifier() and not keyword.iskeyword(節.名):
                return self._標注並返(_載名(節.名), 節.位置)
            JS代 = self._轉JS片段(節.名)
            if JS代 is not None:
                return self._標注並返(JS代, 節.位置, 僅缺=False)
            try:
                return self._標注並返(
                    ast.parse(節.名, mode="eval").body, 節.位置, 僅缺=False
                )
            except SyntaxError:
                self._拋出文法錯誤("名不合 Python 表達式", 節.位置.start)
        if isinstance(節, 言值):
            return self._標注並返(ast.Constant(value=_還原言值(節.文)), 節.位置)
        if isinstance(節, 數值):
            try:
                if "." in 節.文:
                    return self._標注並返(ast.Constant(value=float(節.文)), 節.位置)
                return self._標注並返(ast.Constant(value=int(節.文)), 節.位置)
            except ValueError:
                self._拋出文法錯誤("非法數值", 節.位置.start)
        if isinstance(節, 爻值):
            return self._標注並返(ast.Constant(value=節.真), 節.位置)
        if isinstance(節, 其值):
            return self._標注並返(
                _叫函(_載名(self._其函名), []),
                節.位置,
            )
        if isinstance(節, 其餘值):
            self._拋出文法錯誤("其餘不可獨立成值", 節.位置.start)
        self._拋出文法錯誤("不識之值", 節.位置.start)
        raise AssertionError("unreachable")

    def _轉條件原子(self, 原子: 條件原子) -> ast.expr:
        基 = self._轉值(原子.值)
        if 原子.之長:
            return self._標注並返(
                _叫函(_載名("len"), [基]),
                原子.位置,
            )
        if 原子.下標 is None:
            return self._標注並返(基, 原子.位置, 僅缺=True)
        索 = 原子.下標
        if isinstance(索, 其餘值):
            return self._標注並返(
                _切片載(基, 始=ast.Constant(value=1)),
                原子.位置,
            )
        索引 = self._轉下標索引(索)
        return self._標注並返(
            _叫函(_載名("取物"), [基, 索引]),
            原子.位置,
        )

    def _轉下標索引(self, 索: 值) -> ast.expr:
        if isinstance(索, 言值):
            return self._標注並返(ast.Constant(value=_還原言值(索.文)), 索.位置)
        if isinstance(索, 數值):
            try:
                return self._標注並返(ast.Constant(value=int(float(索.文))), 索.位置)
            except ValueError:
                self._拋出文法錯誤("非法下標", 索.位置.start)
        索式 = self._轉值(索)
        return self._標注並返(
            _叫函(_載名("文言轉整"), [索式, ast.Constant(value=0)]),
            索.位置,
        )

    def _轉條件式(self, 片段: list[條件原子 | str], 反轉: bool) -> ast.expr:
        錨點: slice | None = None
        for 片段項 in 片段:
            if isinstance(片段項, 條件原子):
                錨點 = 片段項.位置
                break
        if 錨點 is None:
            錨點 = slice(0, 0)
        if not 片段:
            預設式 = ast.Constant(value=False)
            條件式: ast.expr = (
                ast.UnaryOp(op=ast.Not(), operand=預設式) if 反轉 else 預設式
            )
            return self._標注並返(條件式, 錨點)

        序: list[ast.expr | str] = []
        for 片段項 in 片段:
            if isinstance(片段項, str):
                序.append(片段項)
            else:
                序.append(self._轉條件原子(片段項))

        # 以 ||/&& 分段；段內只含比較運算（或單一值）。
        段列: list[list[ast.expr | str]] = []
        邏輯列: list[str] = []
        當前: list[ast.expr | str] = []
        for 序項 in 序:
            if isinstance(序項, str) and 序項 in {"||", "&&"}:
                段列.append(當前)
                邏輯列.append(序項)
                當前 = []
            else:
                當前.append(序項)
        段列.append(當前)

        def 段轉(段: list[ast.expr | str]) -> ast.expr:
            def 取式(項: ast.expr | str, 錯訊: str) -> ast.expr:
                if isinstance(項, str):
                    self._拋出文法錯誤(錯訊, 0)
                return cast(ast.expr, 項)

            if not 段:
                return ast.Constant(value=False)
            if len(段) == 1:
                return 取式(段[0], "條件式不合法")
            if len(段) % 2 == 0:
                self._拋出文法錯誤("條件式不完整", 0)
            左 = 取式(段[0], "條件式不合法")
            比較運算子列: list[ast.cmpop] = []
            比較對象列: list[ast.expr] = []
            for i in range(1, len(段), 2):
                op = 段[i]
                右 = 取式(段[i + 1], "比較式不合法")
                if isinstance(op, str):
                    運算子類 = 比較AST運算子對照.get(op)
                    if 運算子類 is None:
                        self._拋出文法錯誤("未知比較", 0)
                        raise AssertionError("unreachable")
                    比較運算子列.append(運算子類())
                else:
                    self._拋出文法錯誤("比較符非法", 0)
                比較對象列.append(右)
            return ast.Compare(left=左, ops=比較運算子列, comparators=比較對象列)

        段式列 = [段轉(段) for 段 in 段列]

        # && 優先於 ||
        或段: list[ast.expr] = []
        當前且: list[ast.expr] = [段式列[0]]
        for i, 邏 in enumerate(邏輯列):
            下一 = 段式列[i + 1]
            if 邏 == "&&":
                當前且.append(下一)
            else:
                或段.append(
                    當前且[0]
                    if len(當前且) == 1
                    else ast.BoolOp(op=ast.And(), values=當前且)
                )
                當前且 = [下一]
        或段.append(
            當前且[0] if len(當前且) == 1 else ast.BoolOp(op=ast.And(), values=當前且)
        )
        條件式 = 或段[0] if len(或段) == 1 else ast.BoolOp(op=ast.Or(), values=或段)
        結果 = ast.UnaryOp(op=ast.Not(), operand=條件式) if 反轉 else 條件式
        return self._標注並返(結果, 錨點, 僅缺=True)

    def _填體(self, 體: list[ast.stmt]) -> list[ast.stmt]:
        return 體 if 體 else [ast.Pass()]

    def _暫存術呼(
        self, 術名: str, 參數: list[ast.expr], 位置: slice | None = None
    ) -> ast.Call:
        錨點 = slice(0, 0) if 位置 is None else 位置
        return self._標注並返(
            ast.Call(
                func=ast.Attribute(
                    value=ast.Name(id=self._暫存名, ctx=ast.Load()),
                    attr=術名,
                    ctx=ast.Load(),
                ),
                args=參數,
                keywords=[],
            ),
            錨點,
            僅缺=True,
        )

    def _名指派(self, 名: str, 值: ast.expr, 位置: slice | None = None) -> ast.Assign:
        錨點 = slice(0, 0) if 位置 is None else 位置
        return self._標注並返(
            ast.Assign(
                targets=[ast.Name(id=名, ctx=ast.Store())],
                value=值,
            ),
            錨點,
            僅缺=True,
        )

    def _附暫存(self, 值式: ast.expr, 位置: slice | None = None) -> list[ast.stmt]:
        錨點 = slice(0, 0) if 位置 is None else 位置
        return [
            self._標注並返(
                _作句(self._暫存術呼("append", [值式], 錨點)),
                錨點,
                僅缺=True,
            )
        ]

    def _清暫存(self, 位置: slice | None = None) -> ast.stmt:
        錨點 = slice(0, 0) if 位置 is None else 位置
        return self._標注並返(
            _作句(self._暫存術呼("clear", [], 錨點)),
            錨點,
            僅缺=True,
        )

    def _轉句列(self, 句列: list[句]) -> list[ast.stmt]:
        主體: list[ast.stmt] = []
        for 句節 in 句列:
            轉譯句 = self._轉句(句節)
            錨點 = self._片段轉位置(句節.位置)
            for AST句 in 轉譯句:
                if not _AST位置齊全(AST句):
                    _寫入AST位置(AST句, 錨點)
            主體.extend(轉譯句)
        if self._待取數 is not None or self._待取其餘:
            索引 = 句列[-1].位置.stop if 句列 else 0
            self._拋出文法錯誤("取後未以施", 索引)
        return 主體

    def _轉句(self, 節: 句) -> list[ast.stmt]:
        if (self._待取數 is not None or self._待取其餘) and not isinstance(
            節, (以施句, 取句, 註釋句, 宏句)
        ):
            self._拋出文法錯誤("取後需以施", 節.位置.start)
        if isinstance(節, 匯入句):
            return self._轉匯入句(節)

        if isinstance(節, 術定義句):
            self._檢名(節.名, 節.位置)
            固定參列: list[術參數] = []
            其餘參: 術參數 | None = None
            for 參 in 節.參數列:
                self._檢名(參.名, 節.位置)
                if 參.其餘:
                    if 其餘參 is None:
                        其餘參 = 參
                else:
                    固定參列.append(參)
            本參數列 = [_造參(參.名) for 參 in 固定參列]
            if 其餘參 is not None:
                本參數列.append(_造參(其餘參.名))
            原待取 = self._待取數
            原待取其餘 = self._待取其餘
            self._待取數 = None
            self._待取其餘 = False
            原體 = self._轉句列(節.體)
            self._待取數 = 原待取
            self._待取其餘 = 原待取其餘
            原體 = self._填體(原體)
            宣告列: list[ast.stmt] = []
            資訊 = self._作用域資訊.get(id(節))
            全域名 = set(資訊.全域) if 資訊 is not None else set()
            非區名 = set(資訊.非區) if 資訊 is not None else set()
            全域名.add(self._暫存名)
            if 全域名:
                宣告列.append(ast.Global(names=sorted(全域名)))
            if 非區名:
                宣告列.append(ast.Nonlocal(names=sorted(非區名)))
            暫名 = self._新內部名("暫存")
            初始化 = [
                self._名指派(暫名, _載名(self._暫存名)),
                self._名指派(self._暫存名, ast.List(elts=[], ctx=ast.Load())),
            ]
            復原 = self._名指派(self._暫存名, _載名(暫名))
            體 = (
                宣告列
                + 初始化
                + [ast.Try(body=原體, handlers=[], orelse=[], finalbody=[復原])]
            )
            本名 = self._新內部名("術本")
            本函 = _造函節(本名, _造參數列(本參數列), 體)
            群名 = self._新內部名("參群")
            已名 = self._新內部名("已")
            結名 = self._新內部名("結")
            後名 = self._新內部名("後群")
            續名 = self._新內部名("續")
            呼名 = self._新內部名("調用")
            需數 = len(固定參列)
            接其餘 = 其餘參 is not None

            def _群前段() -> ast.Starred:
                return _展開(_切片載(_載名(群名), 迄=ast.Constant(value=需數)))

            def _群後段() -> ast.Subscript:
                return _切片載(_載名(群名), 始=ast.Constant(value=需數))

            if 接其餘:
                呼本參列: list[ast.expr] = []
                if 需數 > 0:
                    呼本參列.append(_群前段())
                呼本參列.append(
                    _叫函(
                        _載名("list"),
                        [_群後段()],
                    )
                )
                滿足體: list[ast.stmt] = [_返句(_叫函(_載名(本名), 呼本參列))]
            else:
                滿足體 = [
                    self._名指派(
                        結名,
                        _叫函(
                            _載名(本名),
                            [_群前段()],
                        ),
                    ),
                    ast.If(
                        test=ast.Compare(
                            left=_載名(已名),
                            ops=[ast.Eq()],
                            comparators=[ast.Constant(value=需數)],
                        ),
                        body=[_返句(_載名(結名))],
                        orelse=[
                            _返句(
                                _叫函(
                                    _載名(呼名),
                                    [
                                        _載名(結名),
                                        _展開(_群後段()),
                                    ],
                                )
                            )
                        ],
                    ),
                ]

            包函 = _造函節(
                節.名,
                _造參數列(其餘=_造參(群名)),
                [
                    self._名指派(
                        已名,
                        _叫函(_載名("len"), [_載名(群名)]),
                    ),
                    ast.If(
                        test=ast.Compare(
                            left=_載名(已名),
                            ops=[ast.GtE()],
                            comparators=[ast.Constant(value=需數)],
                        ),
                        body=滿足體,
                        orelse=[
                            _造函節(
                                續名,
                                _造參數列(其餘=_造參(後名)),
                                [
                                    _返句(
                                        _叫函(
                                            _載名(呼名),
                                            [
                                                _載名(節.名),
                                                _展開(
                                                    ast.BinOp(
                                                        left=_載名(群名),
                                                        op=ast.Add(),
                                                        right=_載名(後名),
                                                    )
                                                ),
                                            ],
                                        )
                                    )
                                ],
                            ),
                            _返句(_載名(續名)),
                        ],
                    ),
                ],
            )
            呼函 = _造術呼叫函(呼名, self._片段轉位置(節.位置))
            設本參 = _造屬性指派(本名, "__文言術參數數__", ast.Constant(value=需數))
            設包參 = _造屬性指派(節.名, "__文言術參數數__", ast.Constant(value=需數))
            設本餘 = _造屬性指派(本名, "__文言術接其餘__", ast.Constant(value=接其餘))
            設包餘 = _造屬性指派(節.名, "__文言術接其餘__", ast.Constant(value=接其餘))
            return [本函, 呼函, 包函, 設本參, 設包參, 設本餘, 設包餘]
        if isinstance(節, 宣告句):
            結果: list[ast.stmt] = []
            for i in range(節.數量):
                值節 = 節.初值列[i] if i < len(節.初值列) else None
                值式: ast.expr
                if 值節 is not None:
                    值式 = self._轉值(值節)
                elif 節.類型 == "列":
                    值式 = ast.List(elts=[], ctx=ast.Load())
                elif 節.類型 == "物":
                    值式 = ast.Dict(keys=[], values=[])
                elif 節.類型 == "術":
                    值式 = ast.Lambda(
                        args=_造參數列(),
                        body=ast.Constant(value=0),
                    )
                else:
                    值式 = ast.Constant(value=宣告預設值表.get(節.類型))
                if i < len(節.名列):
                    名 = 節.名列[i]
                    self._檢名(名, 節.位置)
                    結果.append(self._名指派(名, 值式))
                else:
                    結果.extend(self._附暫存(值式))
            return 結果

        if isinstance(節, 初始化句):
            初始化值式 = self._轉值(節.初值)
            if 節.名 is not None:
                self._檢名(節.名, 節.位置)
                return [self._名指派(節.名, 初始化值式)]
            return self._附暫存(初始化值式)

        if isinstance(節, 命名句):
            命名結果: list[ast.stmt] = []
            for 名 in reversed(節.名列):
                self._檢名(名, 節.位置)
                命名結果.append(self._名指派(名, self._暫存術呼("pop", [])))
            return 命名結果

        if isinstance(節, (施句, 以施句)):
            if isinstance(節, 施句):
                參數式 = [self._轉值(參) for 參 in 節.參數列]
            else:
                if self._待取數 is None and not self._待取其餘:
                    self._拋出文法錯誤("以施需先取", 節.位置.start)
                數量 = self._待取數
                取其餘 = self._待取其餘
                self._待取數 = None
                self._待取其餘 = False
                if 取其餘:
                    取值名 = "__取其餘"
                    取值參: list[ast.expr] = []
                else:
                    if 數量 is None:
                        self._拋出文法錯誤("以施需先取", 節.位置.start)
                    取值名 = "__取"
                    取值參 = [ast.Constant(value=數量)]
                取值呼 = _叫函(_載名(取值名), 取值參)
                參數式 = [_展開(取值呼)]
            return self._附暫存(_叫函(self._轉值(節.術), 參數式))

        if isinstance(節, 取句):
            self._待取其餘 = 節.其餘
            self._待取數 = None if 節.其餘 else 節.數量
            return []

        if isinstance(節, 返回句):
            返回值式: ast.expr | None
            if 節.空無:
                返回值式 = ast.Constant(value=None)
            elif 節.取棧:
                返回值式 = _叫函(_載名(self._其函名), [])
            else:
                返回值式 = None if 節.值 is None else self._轉值(節.值)
            return [_返句(返回值式)]

        if isinstance(節, 列充句):
            列式 = self._轉值(節.列)
            列充結果: list[ast.stmt]
            if not isinstance(列式, ast.Name):
                暫名 = self._新內部名("列")
                暫存指派 = self._名指派(暫名, 列式)
                列式 = _載名(暫名)
                列充結果 = [暫存指派]
            else:
                列充結果 = []
            for 值節 in 節.值列:
                列充結果.append(_作句(_叫法(列式, "append", [self._轉值(值節)])))
            return 列充結果

        if isinstance(節, 列銜句):
            列列 = [self._轉值(節.列)] + [self._轉值(列) for 列 in 節.列列]
            式 = 列列[0]
            for 右 in 列列[1:]:
                式 = ast.BinOp(left=式, op=ast.Add(), right=右)
            return self._附暫存(式)

        if isinstance(節, 物定義句):
            self._檢名(節.名, 節.位置)
            keys: list[ast.expr | None] = [self._轉值(屬.鍵) for 屬 in 節.屬性列]
            values = [self._轉值(屬.值) for 屬 in 節.屬性列]
            return [self._名指派(節.名, ast.Dict(keys=keys, values=values))]

        if isinstance(節, 凡句):
            self._檢名(節.變數名, 節.位置)
            體 = self._填體(self._轉句列(節.體))
            return [
                ast.For(
                    target=_存名(節.變數名),
                    iter=self._轉值(節.容器),
                    body=體,
                    orelse=[],
                )
            ]

        if isinstance(節, 試句):
            體 = self._填體(self._轉句列(節.體))
            禍名: str | None = None
            處理體: list[ast.stmt] = [ast.Pass()]
            if 節.捕捉列:
                禍名 = self._新內部名("禍")
                鏈: ast.stmt | None = None
                尾: ast.If | None = None
                捕尾體: list[ast.stmt] | None = None
                for 捕 in 節.捕捉列:
                    子體 = self._填體(self._轉句列(捕.體))
                    if 捕.變數名 is not None:
                        self._檢名(捕.變數名, 節.位置)
                        子體 = [self._名指派(捕.變數名, _載名(禍名))] + 子體
                    if 捕.亦可:
                        捕尾體 = 子體
                        break
                    錯名 = 捕.錯名
                    if 錯名 is None:
                        self._拋出文法錯誤("捕捉需錯名", 節.位置.start)
                    錯名值 = cast(值, 錯名)
                    測 = ast.Compare(
                        left=ast.Attribute(
                            value=_載名(禍名),
                            attr="名",
                            ctx=ast.Load(),
                        ),
                        ops=[ast.Eq()],
                        comparators=[self._轉值(錯名值)],
                    )
                    節點 = ast.If(test=測, body=子體, orelse=[])
                    if 鏈 is None:
                        鏈 = 節點
                    else:
                        if 尾 is None:
                            self._拋出文法錯誤("捕捉鏈不連續", 節.位置.start)
                        尾節 = cast(ast.If, 尾)
                        尾節.orelse = [節點]
                    尾 = 節點
                if 捕尾體 is None:
                    捕尾體 = [ast.Pass()]
                if 鏈 is None:
                    處理體 = 捕尾體
                else:
                    if 尾 is None:
                        self._拋出文法錯誤("捕捉鏈不連續", 節.位置.start)
                    尾節 = cast(ast.If, 尾)
                    尾節.orelse = 捕尾體
                    處理體 = [鏈]
            return [
                ast.Try(
                    body=體,
                    handlers=[
                        ast.ExceptHandler(
                            type=_載名("文言之禍"),
                            name=禍名,
                            body=處理體,
                        )
                    ],
                    orelse=[],
                    finalbody=[],
                )
            ]

        if isinstance(節, 擲句):
            args = [self._轉值(節.名)]
            if 節.訊 is not None:
                args.append(self._轉值(節.訊))
            return [
                ast.Raise(
                    exc=_叫函(_載名("文言之禍"), args),
                    cause=None,
                )
            ]

        if isinstance(節, (註釋句, 宏句)):
            return []

        if isinstance(節, 書之句):
            輸出列式: ast.expr = ast.IfExp(
                test=ast.UnaryOp(
                    op=ast.Not(),
                    operand=_叫法(
                        _叫函(_載名("globals"), []),
                        "get",
                        [
                            ast.Constant(value="__wenyan_no_output_hanzi__"),
                            ast.Constant(value=False),
                        ],
                    ),
                ),
                body=_載名(self._暫存名),
                orelse=ast.ListComp(
                    elt=_叫函(
                        _載名(self._輸出格式函名), [_載名("值"), ast.Constant(value=0)]
                    ),
                    generators=[
                        ast.comprehension(
                            target=_存名("值"),
                            iter=_載名(self._暫存名),
                            ifs=[],
                            is_async=0,
                        )
                    ],
                ),
            )
            return [
                _作句(_叫函(_載名("print"), [_展開(輸出列式)])),
                self._清暫存(),
            ]

        if isinstance(節, 噫句):
            return [self._清暫存()]

        if isinstance(節, 算術句):
            左 = self._轉值(節.左)
            右 = self._轉值(節.右)
            if 節.算 in 算術AST運算子對照:
                式 = ast.BinOp(left=左, op=算術AST運算子對照[節.算](), right=右)
            elif 節.算 in 邏輯AST運算子對照:
                式 = ast.BoolOp(op=邏輯AST運算子對照[節.算](), values=[左, 右])
            else:
                self._拋出文法錯誤("未知運算", 節.位置.start)
                raise AssertionError("unreachable")
            return self._附暫存(式)

        if isinstance(節, 變句):
            return self._附暫存(ast.UnaryOp(op=ast.Not(), operand=self._轉值(節.值)))

        if isinstance(節, 夫句):
            return self._附暫存(self._轉值(節.值))

        if isinstance(節, 之長句):
            return self._附暫存(_叫函(_載名("len"), [self._轉值(節.容器)]))

        if isinstance(節, 之句):
            return self._附暫存(
                self._轉條件原子(條件原子(節.位置, 節.容器, 節.索引, False))
            )

        if isinstance(節, 昔今句):
            self._檢名(節.左名, 節.位置)
            前置: list[ast.stmt] = []
            左索為言 = False
            if 節.左下標 is None:
                目標: ast.expr = _存名(節.左名)
                索 = None
            else:
                if isinstance(節.左下標, 其餘值):
                    self._拋出文法錯誤("不可對其餘賦值", 節.位置.start)
                左索為言 = isinstance(節.左下標, 言值)
                索名 = self._新內部名("索")
                前置.append(self._名指派(索名, self._轉下標索引(節.左下標)))
                索 = _載名(索名)
                索式 = (
                    索
                    if 左索為言
                    else ast.BinOp(left=索, op=ast.Sub(), right=ast.Constant(value=1))
                )
                目標 = ast.Subscript(
                    value=_載名(節.左名),
                    slice=索式,
                    ctx=ast.Store(),
                )

            if 節.刪除:
                if 節.左下標 is None:
                    return [self._名指派(節.左名, ast.Constant(value=None))]
                if 索 is None:
                    self._拋出文法錯誤("缺左下標", 節.位置.start)
                索式值 = cast(ast.expr, 索)
                return 前置 + [_作句(_叫函(_載名("刪物"), [_載名(節.左名), 索式值]))]

            if 節.右值 is None:
                self._拋出文法錯誤("缺右值", 節.位置.start)
            右值 = cast(值, 節.右值)
            右式: ast.expr = self._轉值(右值)
            if 節.右下標 is not None:
                原右 = 條件原子(節.位置, 右值, 節.右下標, False)
                右式 = self._轉條件原子(原右)
            if 節.左下標 is None:
                return 前置 + [ast.Assign(targets=[目標], value=右式)]
            if 左索為言:
                return 前置 + [
                    ast.Try(
                        body=[ast.Assign(targets=[目標], value=右式)],
                        handlers=[
                            ast.ExceptHandler(
                                type=_載名("Exception"),
                                name=None,
                                body=[ast.Pass()],
                            )
                        ],
                        orelse=[],
                        finalbody=[],
                    )
                ]
            if 索 is None:
                self._拋出文法錯誤("缺左下標", 節.位置.start)
            索式值 = cast(ast.expr, 索)

            return 前置 + [
                ast.If(
                    test=ast.BoolOp(
                        op=ast.And(),
                        values=[
                            _叫函(_載名("isinstance"), [_載名(節.左名), _載名("list")]),
                            ast.Compare(
                                left=索式值,
                                ops=[ast.LtE()],
                                comparators=[ast.Constant(value=0)],
                            ),
                        ],
                    ),
                    body=[
                        ast.Assign(
                            targets=[
                                ast.Subscript(
                                    value=_載名("__文言負索"),
                                    slice=ast.Tuple(
                                        elts=[
                                            _叫函(_載名("id"), [_載名(節.左名)]),
                                            索式值,
                                        ],
                                        ctx=ast.Load(),
                                    ),
                                    ctx=ast.Store(),
                                )
                            ],
                            value=右式,
                        )
                    ],
                    orelse=[
                        ast.If(
                            test=ast.BoolOp(
                                op=ast.And(),
                                values=[
                                    _叫函(
                                        _載名("isinstance"),
                                        [_載名(節.左名), _載名("list")],
                                    ),
                                    ast.Compare(
                                        left=索式值,
                                        ops=[ast.Gt()],
                                        comparators=[
                                            _叫函(_載名("len"), [_載名(節.左名)])
                                        ],
                                    ),
                                ],
                            ),
                            body=[
                                _作句(
                                    _叫法(
                                        _載名(節.左名),
                                        "extend",
                                        [
                                            ast.BinOp(
                                                left=ast.List(
                                                    elts=[ast.Constant(value=None)],
                                                    ctx=ast.Load(),
                                                ),
                                                op=ast.Mult(),
                                                right=ast.BinOp(
                                                    left=索式值,
                                                    op=ast.Sub(),
                                                    right=_叫函(
                                                        _載名("len"), [_載名(節.左名)]
                                                    ),
                                                ),
                                            )
                                        ],
                                    )
                                )
                            ],
                            orelse=[],
                        ),
                        ast.Assign(targets=[目標], value=右式),
                    ],
                )
            ]

        if isinstance(節, 若句):
            試 = self._轉條件式(節.條件, 節.反轉)
            然體 = self._填體(self._轉句列(節.然))
            否體: list[ast.stmt] = self._轉句列(節.否則)

            下個: list[ast.stmt] = self._填體(否體) if 否體 else []
            for 子 in reversed(節.另若列):
                子試 = self._轉條件式(子.條件, False)
                子體 = self._填體(self._轉句列(子.體))
                下個 = [ast.If(test=子試, body=子體, orelse=下個)]
            return [ast.If(test=試, body=然體, orelse=下個)]

        if isinstance(節, 恆為是句):
            體 = self._填體(self._轉句列(節.體))
            return [ast.While(test=ast.Constant(value=True), body=體, orelse=[])]

        if isinstance(節, 為是遍句):
            迭名 = self._新內部名("遍")
            體 = self._填體(self._轉句列(節.體))
            return [
                ast.For(
                    target=_存名(迭名),
                    iter=_叫函(_載名("range"), [self._轉值(節.次數)]),
                    body=體,
                    orelse=[],
                )
            ]

        if isinstance(節, 乃止句):
            return [ast.Break()]

        if isinstance(節, 乃止是遍句):
            return [ast.Continue()]

        self._拋出文法錯誤("此句未支援", 節.位置.start)
        raise AssertionError("unreachable")

    def _轉匯入句(self, 節: 匯入句) -> list[ast.stmt]:
        路徑 = _嘗試解析文言模組路徑(節.模組, self.文檔名, self._環境)
        if 路徑 is None:
            return self._轉宿主匯入句(節)
        if 路徑 in self._環境.已載入:
            return []
        if 路徑 in self._環境.編譯中:
            self._拋出文法錯誤("循環匯入", 節.位置.start)
        if 路徑 in self._環境.模組快取:
            self._環境.已載入.add(路徑)
            return self._環境.模組快取[路徑]
        self._環境.編譯中.add(路徑)
        try:
            原文 = _讀取源碼(路徑, self._環境)
            程, 處理後 = _解析前處理(原文, 路徑, self._環境)
            轉譯器 = PythonAST轉譯器(處理後, 路徑, self._環境, 插入序言=False)
            句列 = 轉譯器._轉譯句列(程)
            self._環境.模組快取[路徑] = 句列
            self._環境.已載入.add(路徑)
            return 句列
        finally:
            self._環境.編譯中.discard(路徑)

    def _轉宿主匯入句(self, 節: 匯入句) -> list[ast.stmt]:
        名列 = 節.名列
        for 名 in 名列:
            self._檢名(名, 節.位置)
        模組名 = self._新內部名("宿主模組")
        句列: list[ast.stmt] = [
            self._名指派(
                模組名,
                _叫函(
                    _載名("__import__"),
                    [
                        ast.Constant(value=節.模組),
                        _叫函(_載名("globals"), []),
                        _叫函(_載名("locals"), []),
                        ast.List(
                            elts=[ast.Constant(value=名) for 名 in 名列],
                            ctx=ast.Load(),
                        ),
                        ast.Constant(value=0),
                    ],
                ),
            )
        ]
        for 名 in 名列:
            句列.append(
                self._名指派(
                    名,
                    _叫函(_載名("getattr"), [_載名(模組名), ast.Constant(value=名)]),
                )
            )
        return 句列


def 轉譯為PythonAST(
    程: 程式, 內容: str, 文檔名: str = "<言>", 環境: 編譯環境 | None = None
) -> ast.Module:
    """Wenyan AST → Python AST。"""

    return PythonAST轉譯器(內容, 文檔名, 環境=環境).轉譯(程)


def 編譯為PythonAST(內容: str, 文檔名: str = "<言>") -> ast.Module:
    """文言源碼 → Python AST（lexer → parser → transformer）。"""

    環境 = _建立編譯環境()
    程, 處理後 = _解析前處理(內容, 文檔名, 環境)
    return 轉譯為PythonAST(程, 處理後, 文檔名, 環境)


def _載入自舉作用域(自舉檔路徑: str) -> dict[str, object]:
    with open(自舉檔路徑, "r", encoding="utf-8") as 檔案:
        內容 = 檔案.read()
    模組樹 = 編譯為PythonAST(內容, 自舉檔路徑)
    程式碼 = compile(模組樹, 自舉檔路徑, "exec")
    環境 = _建立編譯環境()
    當前文檔堆疊: list[str] = [自舉檔路徑]
    已載入模組: set[str] = set()

    def _設文檔(文檔名: str) -> None:
        當前文檔堆疊[:] = [文檔名]

    def _入文檔(文檔名: str) -> None:
        當前文檔堆疊.append(文檔名)

    def _出文檔() -> None:
        if len(當前文檔堆疊) > 1:
            當前文檔堆疊.pop()

    def _重置匯入() -> None:
        已載入模組.clear()

    def _前處理(源碼: str) -> str:
        文檔名 = 當前文檔堆疊[-1]
        return _前處理源碼(源碼, 文檔名, 環境)

    def _取模組文(模組: str) -> dict[str, object]:
        文檔名 = 當前文檔堆疊[-1]
        路徑 = _嘗試解析文言模組路徑(模組, 文檔名, 環境)
        if 路徑 is None:
            _前處理錯誤("", 文檔名, "匯入之書不見", 0)
            raise AssertionError("unreachable")
        if 路徑 in 已載入模組:
            return {"路": 路徑, "文": "", "已載": True}
        內容 = _讀取源碼(路徑, 環境)
        已載入模組.add(路徑)
        return {"路": 路徑, "文": 內容, "已載": False}

    作用域: dict[str, object] = {
        "__name__": "__main__",
        "__file__": 自舉檔路徑,
        "__wenyan_no_output_hanzi__": False,
    }
    exec(程式碼, 作用域, 作用域)
    作用域.update(
        {
            "_設文檔": _設文檔,
            "_入文檔": _入文檔,
            "_出文檔": _出文檔,
            "_重置匯入": _重置匯入,
            "_前處理": _前處理,
            "_取模組文": _取模組文,
        }
    )
    return 作用域


def 自舉主術(參數列表: list[str] | None = None) -> int:
    """執行自舉版 `wenyan.wy` 的命令列入口。

    Args:
        參數列表: 參數列表；None 表示使用 sys.argv[1:]。

    Returns:
        結束碼。
    """

    參數 = sys.argv[1:] if 參數列表 is None else 參數列表
    自舉檔路徑 = os.path.join(os.path.dirname(__file__), "wenyan.wy")
    自舉實路徑 = os.path.realpath(自舉檔路徑)
    當前路徑 = 自舉檔路徑

    try:
        作用域 = _載入自舉作用域(自舉檔路徑)
        if 參數:
            解譯物 = 作用域.get("解譯")
            內建主物 = 作用域.get("主術")
            if not callable(解譯物) or not callable(內建主物):
                raise 文法之禍("自舉入口不存在")
            解譯術 = cast(Callable[[str], object], 解譯物)
            內建主術 = cast(Callable[[], object], 內建主物)
            設文檔術 = 作用域.get("_設文檔")
            重置匯入術 = 作用域.get("_重置匯入")
            for 路徑 in 參數:
                當前路徑 = 路徑
                if 路徑 != "-" and os.path.realpath(路徑) == 自舉實路徑:
                    結果 = 內建主術()
                    if 結果 is not None:
                        結束碼 = int(cast(int | str, 結果))
                        if 結束碼 != 0:
                            return 結束碼
                    continue
                if callable(重置匯入術):
                    cast(Callable[[], object], 重置匯入術)()
                if 路徑 == "-":
                    if callable(設文檔術):
                        cast(Callable[[str], object], 設文檔術)("<stdin>")
                    內容 = sys.stdin.read()
                else:
                    if callable(設文檔術):
                        cast(Callable[[str], object], 設文檔術)(路徑)
                    with open(路徑, "r", encoding="utf-8") as 檔案:
                        內容 = 檔案.read()
                解譯術(內容)
            return 0

        主術物 = 作用域.get("主術")
        if not callable(主術物):
            raise 文法之禍("自舉入口不存在")
        結果 = cast(Callable[[], object], 主術物)()
        return 0 if 結果 is None else int(cast(int | str, 結果))
    except OSError as 錯:
        print(f"{當前路徑}: {錯}", file=sys.stderr)
        return 1
    except Exception as 錯:
        禍名 = getattr(錯, "名", None)
        禍訊 = getattr(錯, "訊", None)
        訊息 = (
            f"{禍名}之禍：{禍訊}"
            if isinstance(禍名, str) and isinstance(禍訊, str)
            else str(錯)
        )
        print(f"{當前路徑}: {訊息}", file=sys.stderr)
        return 1


def 主術(參數列表: list[str] | None = None) -> int:
    """執行命令列入口。

    Args:
        參數列表: 參數列表；None 表示使用 sys.argv[1:]。

    Returns:
        結束碼。
    """

    參數 = sys.argv[1:] if 參數列表 is None else 參數列表

    def 顯示說明() -> None:
        print(
            "用法：wenyan [--tokens|--wyast|--pyast] [--no-outputHanzi] <檔案.wy|-> ..."
        )
        print("  預設：編譯為 Python AST 並執行。")
        print("  --tokens：僅輸出詞法符號（debug）。")
        print("  --wyast：輸出 Wenyan AST（debug）。")
        print("  --pyast：輸出 Python AST dump（debug）。")
        print("  --no-outputHanzi：執行模式輸出阿拉伯數字（與 @wenyan/cli 相容）。")

    if not 參數:
        顯示說明()
        return 0

    模式 = "exec"
    不輸出漢字 = False
    while 參數 and 參數[0] != "-":
        選項 = 參數[0]
        if 選項 in {"-h", "--help"}:
            顯示說明()
            return 0
        if 選項 in {"--tokens", "--lex"}:
            模式 = "tokens"
            參數 = 參數[1:]
            continue
        if 選項 in {"--wyast"}:
            模式 = "wyast"
            參數 = 參數[1:]
            continue
        if 選項 in {"--pyast", "--ast"}:
            模式 = "pyast"
            參數 = 參數[1:]
            continue
        if 選項 == "--no-outputHanzi":
            不輸出漢字 = True
            參數 = 參數[1:]
            continue
        if 選項.startswith("-"):
            print(f"未知選項：{選項}", file=sys.stderr)
            return 2
        break

    if not 參數:
        print("未指定檔案。可用 -h/--help。", file=sys.stderr)
        return 2

    for 路徑 in 參數:
        try:
            if 路徑 == "-":
                內容 = sys.stdin.read()
                文檔名 = "<stdin>"
            else:
                with open(路徑, "r", encoding="utf-8") as 檔案:
                    內容 = 檔案.read()
                文檔名 = 路徑

            環境 = _建立編譯環境()
            if 模式 == "tokens":
                處理後 = _前處理源碼(內容, 文檔名, 環境)
                print(list(詞法分析器(處理後, 文檔名)))
                continue
            if 模式 == "wyast":
                程, _ = _解析前處理(內容, 文檔名, 環境)
                print(程)
                continue
            if 模式 == "pyast":
                程, 處理後 = _解析前處理(內容, 文檔名, 環境)
                模組樹 = 轉譯為PythonAST(程, 處理後, 文檔名, 環境)
                print(ast.dump(模組樹, include_attributes=True))
                continue

            程, 處理後 = _解析前處理(內容, 文檔名, 環境)
            模組樹 = 轉譯為PythonAST(程, 處理後, 文檔名, 環境)
            程式碼 = compile(模組樹, 文檔名, "exec")
            作用域 = {
                "__name__": "__main__",
                "__file__": 文檔名,
                "__wenyan_no_output_hanzi__": 不輸出漢字,
            }
            exec(程式碼, 作用域, 作用域)
        except 文法之禍 as 錯:
            檔名 = getattr(錯, "filename", "<言>") or "<言>"
            行號 = getattr(錯, "lineno", 0) or 0
            列偏移 = getattr(錯, "offset", 0) or 0
            行文 = getattr(錯, "text", None)
            訊息 = getattr(錯, "msg", str(錯))
            print(f"{檔名}:{行號}:{列偏移}: {訊息}", file=sys.stderr)
            if isinstance(行文, str) and 行文:
                行文 = 行文.rstrip("\n")
                print(行文, file=sys.stderr)
                if 列偏移 > 0:
                    print(" " * (列偏移 - 1) + "^", file=sys.stderr)
            return 1
        except OSError as 錯:
            print(f"{路徑}: {錯}", file=sys.stderr)
            return 1

    return 0


安裝文言匯入鉤子()


if __name__ == "__main__":
    sys.exit(主術())
