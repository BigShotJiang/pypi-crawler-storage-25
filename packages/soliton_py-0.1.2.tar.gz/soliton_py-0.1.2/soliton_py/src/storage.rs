//! Encrypted storage: community blobs and DM queue blobs.

use pyo3::prelude::*;
use pyo3::types::PyBytes;

use crate::errors::to_py_err;

/// Encrypted storage key ring.
///
/// Manages versioned encryption keys for community storage and DM queues.
/// Multiple key versions can coexist for key rotation — old keys decrypt
/// existing blobs while new keys encrypt new writes.
///
/// Use as a context manager for automatic zeroization::
///
///     with soliton.StorageKeyRing(1, key_bytes) as ring:
///         blob = ring.encrypt_blob("channel-1", "seg-0", plaintext)
///         data = ring.decrypt_blob("channel-1", "seg-0", blob)
#[pyclass]
pub struct StorageKeyRing {
    inner: Option<soliton::storage::StorageKeyRing>,
}

#[pymethods]
impl StorageKeyRing {
    /// Create a keyring with an initial active key.
    ///
    /// Args:
    ///     version: Key version (1-255). Version 0 is rejected.
    ///     key: 32-byte encryption key.
    #[new]
    fn new(version: u8, key: &[u8]) -> PyResult<Self> {
        if key.len() != 32 {
            return Err(crate::errors::InvalidLengthError::new_err(
                "key must be 32 bytes",
            ));
        }
        let key_arr: [u8; 32] = key.try_into().unwrap();
        let storage_key = soliton::storage::StorageKey::new(version, key_arr).map_err(to_py_err)?;
        let ring = soliton::storage::StorageKeyRing::new(storage_key).map_err(to_py_err)?;
        Ok(Self { inner: Some(ring) })
    }

    /// Add a key to the ring.
    ///
    /// Args:
    ///     version: Key version (1-255).
    ///     key: 32-byte encryption key.
    ///     make_active: If True, this key becomes the active key for new writes.
    fn add_key(&mut self, version: u8, key: &[u8], make_active: bool) -> PyResult<()> {
        if key.len() != 32 {
            return Err(crate::errors::InvalidLengthError::new_err(
                "key must be 32 bytes",
            ));
        }
        let ring = self
            .inner
            .as_mut()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("keyring closed"))?;
        let key_arr: [u8; 32] = key.try_into().unwrap();
        let storage_key = soliton::storage::StorageKey::new(version, key_arr).map_err(to_py_err)?;
        ring.add_key(storage_key, make_active).map_err(to_py_err)?;
        Ok(())
    }

    /// Remove a key version from the ring.
    ///
    /// The active version cannot be removed — set a new active key first.
    fn remove_key(&mut self, version: u8) -> PyResult<()> {
        let ring = self
            .inner
            .as_mut()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("keyring closed"))?;
        ring.remove_key(version).map_err(to_py_err)?;
        Ok(())
    }

    /// Encrypt a community storage blob.
    ///
    /// Args:
    ///     channel_id: Channel identifier (bound into AAD).
    ///     segment_id: Segment identifier (bound into AAD).
    ///     plaintext: Data to encrypt.
    ///
    /// Returns:
    ///     Encrypted blob bytes (self-describing — contains key version).
    #[pyo3(signature = (channel_id, segment_id, plaintext, compress=false))]
    fn encrypt_blob<'py>(
        &self,
        py: Python<'py>,
        channel_id: &str,
        segment_id: &str,
        plaintext: &[u8],
        compress: bool,
    ) -> PyResult<Py<PyBytes>> {
        let ring = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("keyring closed"))?;
        let key = ring
            .active_key()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("no active key"))?;
        let blob = soliton::storage::encrypt_blob(key, plaintext, channel_id, segment_id, compress)
            .map_err(to_py_err)?;
        Ok(PyBytes::new(py, &blob).into())
    }

    /// Decrypt a community storage blob.
    ///
    /// The blob's embedded key version selects the decryption key from the ring.
    fn decrypt_blob<'py>(
        &self,
        py: Python<'py>,
        channel_id: &str,
        segment_id: &str,
        blob: &[u8],
    ) -> PyResult<Py<PyBytes>> {
        let ring = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("keyring closed"))?;
        let pt = soliton::storage::decrypt_blob(ring, blob, channel_id, segment_id)
            .map_err(to_py_err)?;
        Ok(PyBytes::new(py, &pt).into())
    }

    /// Encrypt a DM queue blob.
    #[pyo3(signature = (recipient_fp, batch_id, plaintext, compress=false))]
    fn encrypt_dm_queue<'py>(
        &self,
        py: Python<'py>,
        recipient_fp: &[u8],
        batch_id: &str,
        plaintext: &[u8],
        compress: bool,
    ) -> PyResult<Py<PyBytes>> {
        if recipient_fp.len() != 32 {
            return Err(crate::errors::InvalidLengthError::new_err(
                "recipient_fp must be 32 bytes",
            ));
        }
        let ring = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("keyring closed"))?;
        let key = ring
            .active_key()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("no active key"))?;
        let fp: &[u8; 32] = recipient_fp.try_into().unwrap();
        let blob = soliton::storage::encrypt_dm_queue_blob(key, plaintext, fp, batch_id, compress)
            .map_err(to_py_err)?;
        Ok(PyBytes::new(py, &blob).into())
    }

    /// Decrypt a DM queue blob.
    fn decrypt_dm_queue<'py>(
        &self,
        py: Python<'py>,
        recipient_fp: &[u8],
        batch_id: &str,
        blob: &[u8],
    ) -> PyResult<Py<PyBytes>> {
        if recipient_fp.len() != 32 {
            return Err(crate::errors::InvalidLengthError::new_err(
                "recipient_fp must be 32 bytes",
            ));
        }
        let ring = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("keyring closed"))?;
        let fp: &[u8; 32] = recipient_fp.try_into().unwrap();
        let pt =
            soliton::storage::decrypt_dm_queue_blob(ring, blob, fp, batch_id).map_err(to_py_err)?;
        Ok(PyBytes::new(py, &pt).into())
    }

    fn close(&mut self) {
        self.inner = None;
    }

    fn __enter__(slf: Py<Self>) -> Py<Self> {
        slf
    }

    fn __exit__(
        &mut self,
        _exc_type: Option<&Bound<'_, PyAny>>,
        _exc_val: Option<&Bound<'_, PyAny>>,
        _exc_tb: Option<&Bound<'_, PyAny>>,
    ) {
        self.close();
    }
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<StorageKeyRing>()?;
    Ok(())
}
