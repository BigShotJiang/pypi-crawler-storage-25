//! Python bindings for libsoliton via PyO3.
//!
//! This crate wraps the core Rust API (not the CAPI) to provide a safe,
//! ergonomic Python interface. The Zig binding covers the CAPI path.

use pyo3::prelude::*;

mod auth;
mod call;
mod errors;
mod identity;
mod kex;
mod primitives;
mod ratchet;
mod storage;
mod stream;
mod verification;

/// libsoliton — post-quantum cryptographic library.
#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Version
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;
    m.add("VERSION", soliton::VERSION)?;

    // Register submodules.
    errors::register(m)?;
    primitives::register(m)?;
    identity::register(m)?;
    auth::register(m)?;
    kex::register(m)?;
    ratchet::register(m)?;
    storage::register(m)?;
    stream::register(m)?;
    call::register(m)?;
    verification::register(m)?;

    Ok(())
}
