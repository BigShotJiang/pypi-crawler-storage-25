//! LO-Auth: zero-knowledge authentication via KEM challenge-response.

use pyo3::prelude::*;
use pyo3::types::PyBytes;

use crate::errors::to_py_err;

/// Generate an authentication challenge (server-side).
///
/// Returns (ciphertext, expected_token) as a tuple of bytes.
#[pyfunction]
fn auth_challenge<'py>(py: Python<'py>, client_pk: &[u8]) -> PyResult<(Py<PyBytes>, Py<PyBytes>)> {
    let pk =
        soliton::identity::IdentityPublicKey::from_bytes(client_pk.to_vec()).map_err(to_py_err)?;
    let (ct, token) = soliton::auth::auth_challenge(&pk).map_err(to_py_err)?;
    Ok((
        PyBytes::new(py, ct.as_bytes()).into(),
        PyBytes::new(py, &*token).into(),
    ))
}

/// Respond to an authentication challenge (client-side).
///
/// Returns the 32-byte proof.
#[pyfunction]
fn auth_respond<'py>(
    py: Python<'py>,
    client_sk: &[u8],
    ciphertext: &[u8],
) -> PyResult<Py<PyBytes>> {
    let sk =
        soliton::identity::IdentitySecretKey::from_bytes(client_sk.to_vec()).map_err(to_py_err)?;
    let ct = soliton::primitives::xwing::Ciphertext::from_bytes(ciphertext.to_vec())
        .map_err(to_py_err)?;
    let proof = soliton::auth::auth_respond(&sk, &ct).map_err(to_py_err)?;
    Ok(PyBytes::new(py, &*proof).into())
}

/// Verify an authentication proof (server-side). Constant-time.
#[pyfunction]
fn auth_verify(expected_token: &[u8], proof: &[u8]) -> PyResult<bool> {
    if expected_token.len() != 32 || proof.len() != 32 {
        return Err(crate::errors::InvalidLengthError::new_err(
            "both inputs must be 32 bytes",
        ));
    }
    let a: &[u8; 32] = expected_token.try_into().unwrap();
    let b: &[u8; 32] = proof.try_into().unwrap();
    Ok(soliton::auth::auth_verify(a, b))
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(auth_challenge, m)?)?;
    m.add_function(wrap_pyfunction!(auth_respond, m)?)?;
    m.add_function(wrap_pyfunction!(auth_verify, m)?)?;
    Ok(())
}
