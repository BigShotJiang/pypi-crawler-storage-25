//! LO-KEX: asynchronous key exchange (KEM-based, similar to X3DH).

use pyo3::prelude::*;
use pyo3::types::PyBytes;

use crate::errors::to_py_err;

/// Sign a pre-key with the identity key.
///
/// Returns the hybrid signature bytes (3373 bytes).
#[pyfunction]
fn kex_sign_prekey<'py>(py: Python<'py>, ik_sk: &[u8], spk_pub: &[u8]) -> PyResult<Py<PyBytes>> {
    let sk = soliton::identity::IdentitySecretKey::from_bytes(ik_sk.to_vec()).map_err(to_py_err)?;
    let spk =
        soliton::primitives::xwing::PublicKey::from_bytes(spk_pub.to_vec()).map_err(to_py_err)?;
    let sig = soliton::kex::sign_prekey(&sk, &spk).map_err(to_py_err)?;
    Ok(PyBytes::new(py, sig.as_bytes()).into())
}

/// Verify a pre-key bundle.
///
/// Args:
///     bundle_ik_pk: Identity public key from the bundle.
///     known_ik_pk: Known identity public key for this peer.
///     spk_pub: Signed pre-key public key (1216 bytes).
///     spk_id: Signed pre-key ID.
///     spk_sig: Hybrid signature over spk_pub (3373 bytes).
///     crypto_version: Protocol version string (e.g. "lo-crypto-v1").
///     opk_pub: Optional one-time pre-key public key.
///     opk_id: Optional one-time pre-key ID.
///
/// Raises ``BundleVerificationError`` on failure.
#[pyfunction]
#[pyo3(signature = (bundle_ik_pk, known_ik_pk, spk_pub, spk_id, spk_sig, crypto_version, opk_pub=None, opk_id=None))]
#[allow(clippy::too_many_arguments)]
fn kex_verify_bundle(
    bundle_ik_pk: &[u8],
    known_ik_pk: &[u8],
    spk_pub: &[u8],
    spk_id: u32,
    spk_sig: &[u8],
    crypto_version: &str,
    opk_pub: Option<&[u8]>,
    opk_id: Option<u32>,
) -> PyResult<()> {
    let bik = soliton::identity::IdentityPublicKey::from_bytes(bundle_ik_pk.to_vec())
        .map_err(to_py_err)?;
    let kik = soliton::identity::IdentityPublicKey::from_bytes(known_ik_pk.to_vec())
        .map_err(to_py_err)?;
    let spk =
        soliton::primitives::xwing::PublicKey::from_bytes(spk_pub.to_vec()).map_err(to_py_err)?;
    let sig =
        soliton::identity::HybridSignature::from_bytes(spk_sig.to_vec()).map_err(to_py_err)?;

    let opk = match opk_pub {
        Some(data) => Some(
            soliton::primitives::xwing::PublicKey::from_bytes(data.to_vec()).map_err(to_py_err)?,
        ),
        None => None,
    };

    let bundle = soliton::kex::PreKeyBundle {
        ik_pub: bik,
        crypto_version: crypto_version.to_string(),
        spk_pub: spk,
        spk_id,
        spk_sig: sig,
        opk_pub: opk,
        opk_id,
    };

    // verify_bundle consumes the bundle and returns VerifiedBundle on success.
    soliton::kex::verify_bundle(bundle, &kik).map_err(to_py_err)?;
    Ok(())
}

/// Result of session initiation (Alice's side).
///
/// Contains the session init data to send to Bob, plus secret keys for
/// ratchet initialization. Use ``take_root_key`` and ``take_initial_chain_key``
/// to extract keys (destructive — second call returns zeros).
#[pyclass]
pub struct InitiatedSession {
    inner: Option<soliton::kex::InitiatedSession>,
}

#[pymethods]
impl InitiatedSession {
    /// Encoded session init message bytes.
    fn session_init_encoded<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        let encoded = soliton::kex::encode_session_init(&s.session_init).map_err(to_py_err)?;
        Ok(PyBytes::new(py, &encoded).into())
    }

    /// Extract root key (32 bytes). Destructive — zeroed after first call.
    fn take_root_key<'py>(&mut self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_mut()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        let rk = s.take_root_key();
        Ok(PyBytes::new(py, &*rk).into())
    }

    /// Extract initial chain key (32 bytes). Destructive — zeroed after first call.
    fn take_initial_chain_key<'py>(&mut self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_mut()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        let ck = s.take_initial_chain_key();
        Ok(PyBytes::new(py, &*ck).into())
    }

    /// Alice's ephemeral public key bytes (1216 bytes).
    fn ek_pk<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        Ok(PyBytes::new(py, s.ek_pk.as_bytes()).into())
    }

    /// Alice's ephemeral secret key bytes (2432 bytes).
    fn ek_sk<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        Ok(PyBytes::new(py, s.ek_sk().as_bytes()).into())
    }

    /// Sender hybrid signature bytes (3373 bytes).
    fn sender_sig<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        Ok(PyBytes::new(py, s.sender_sig.as_bytes()).into())
    }

    /// Whether an OPK was used.
    fn opk_used(&self) -> PyResult<bool> {
        let s = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        Ok(s.opk_used)
    }

    /// Sender fingerprint (SHA3-256 of Alice's IK).
    fn sender_fingerprint<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        Ok(PyBytes::new(py, &s.session_init.sender_ik_fingerprint).into())
    }

    /// Recipient fingerprint (SHA3-256 of Bob's IK).
    fn recipient_fingerprint<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        Ok(PyBytes::new(py, &s.session_init.recipient_ik_fingerprint).into())
    }

    fn close(&mut self) {
        self.inner = None;
    }

    fn __enter__(slf: Py<Self>) -> Py<Self> {
        slf
    }

    fn __exit__(
        &mut self,
        _exc_type: Option<&Bound<'_, PyAny>>,
        _exc_val: Option<&Bound<'_, PyAny>>,
        _exc_tb: Option<&Bound<'_, PyAny>>,
    ) {
        self.close();
    }
}

/// Initiate a session (Alice's side).
///
/// Args:
///     alice_ik_pk: Alice's identity public key.
///     alice_ik_sk: Alice's identity secret key.
///     bundle_ik_pk: Bob's identity public key (from bundle).
///     spk_pub: Bob's signed pre-key public key.
///     spk_id: Bob's signed pre-key ID.
///     spk_sig: Hybrid signature over spk_pub.
///     crypto_version: Protocol version string.
///     opk_pub: Optional one-time pre-key public key.
///     opk_id: Optional one-time pre-key ID.
#[pyfunction]
#[pyo3(signature = (alice_ik_pk, alice_ik_sk, bundle_ik_pk, spk_pub, spk_id, spk_sig, crypto_version, opk_pub=None, opk_id=None))]
#[allow(clippy::too_many_arguments)]
fn kex_initiate(
    alice_ik_pk: &[u8],
    alice_ik_sk: &[u8],
    bundle_ik_pk: &[u8],
    spk_pub: &[u8],
    spk_id: u32,
    spk_sig: &[u8],
    crypto_version: &str,
    opk_pub: Option<&[u8]>,
    opk_id: Option<u32>,
) -> PyResult<InitiatedSession> {
    let a_pk = soliton::identity::IdentityPublicKey::from_bytes(alice_ik_pk.to_vec())
        .map_err(to_py_err)?;
    let a_sk = soliton::identity::IdentitySecretKey::from_bytes(alice_ik_sk.to_vec())
        .map_err(to_py_err)?;
    let b_pk = soliton::identity::IdentityPublicKey::from_bytes(bundle_ik_pk.to_vec())
        .map_err(to_py_err)?;
    let spk =
        soliton::primitives::xwing::PublicKey::from_bytes(spk_pub.to_vec()).map_err(to_py_err)?;
    let sig =
        soliton::identity::HybridSignature::from_bytes(spk_sig.to_vec()).map_err(to_py_err)?;

    let opk = match opk_pub {
        Some(data) => Some(
            soliton::primitives::xwing::PublicKey::from_bytes(data.to_vec()).map_err(to_py_err)?,
        ),
        None => None,
    };

    // Clone Bob's PK before moving it into the bundle — verify_bundle
    // consumes the bundle but needs the known IK as a separate reference.
    let known_ik = soliton::identity::IdentityPublicKey::from_bytes(bundle_ik_pk.to_vec())
        .map_err(to_py_err)?;

    let bundle = soliton::kex::PreKeyBundle {
        ik_pub: b_pk,
        crypto_version: crypto_version.to_string(),
        spk_pub: spk,
        spk_id,
        spk_sig: sig,
        opk_pub: opk,
        opk_id,
    };

    // verify_bundle checks that the bundle's IK matches known_ik (Bob's PK)
    // and that the SPK signature is valid. The TOFU check (whether Bob's PK
    // is the one the caller trusts) is the caller's responsibility.
    let verified = soliton::kex::verify_bundle(bundle, &known_ik).map_err(to_py_err)?;

    let session = soliton::kex::initiate_session(&a_pk, &a_sk, &verified).map_err(to_py_err)?;
    Ok(InitiatedSession {
        inner: Some(session),
    })
}

/// Result of session receipt (Bob's side).
#[pyclass]
pub struct ReceivedSession {
    inner: Option<soliton::kex::ReceivedSession>,
}

#[pymethods]
impl ReceivedSession {
    /// Extract root key (32 bytes). Destructive.
    fn take_root_key<'py>(&mut self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_mut()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        let rk = s.take_root_key();
        Ok(PyBytes::new(py, &*rk).into())
    }

    /// Extract initial chain key (32 bytes). Destructive.
    fn take_initial_chain_key<'py>(&mut self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_mut()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        let ck = s.take_initial_chain_key();
        Ok(PyBytes::new(py, &*ck).into())
    }

    /// Peer's ephemeral public key (1216 bytes).
    fn peer_ek<'py>(&self, py: Python<'py>) -> PyResult<Py<PyBytes>> {
        let s = self
            .inner
            .as_ref()
            .ok_or_else(|| crate::errors::InvalidDataError::new_err("session consumed"))?;
        Ok(PyBytes::new(py, s.peer_ek.as_bytes()).into())
    }

    fn close(&mut self) {
        self.inner = None;
    }

    fn __enter__(slf: Py<Self>) -> Py<Self> {
        slf
    }

    fn __exit__(
        &mut self,
        _exc_type: Option<&Bound<'_, PyAny>>,
        _exc_val: Option<&Bound<'_, PyAny>>,
        _exc_tb: Option<&Bound<'_, PyAny>>,
    ) {
        self.close();
    }
}

/// Receive a session (Bob's side).
///
/// Args:
///     bob_ik_pk: Bob's identity public key.
///     bob_ik_sk: Bob's identity secret key.
///     alice_ik_pk: Alice's identity public key.
///     session_init_encoded: Encoded session init bytes from Alice.
///     sender_sig: Alice's hybrid signature (3373 bytes).
///     spk_sk: Bob's signed pre-key secret key.
///     opk_sk: Optional one-time pre-key secret key.
#[pyfunction]
#[pyo3(signature = (bob_ik_pk, bob_ik_sk, alice_ik_pk, session_init_encoded, sender_sig, spk_sk, opk_sk=None))]
fn kex_receive(
    bob_ik_pk: &[u8],
    bob_ik_sk: &[u8],
    alice_ik_pk: &[u8],
    session_init_encoded: &[u8],
    sender_sig: &[u8],
    spk_sk: &[u8],
    opk_sk: Option<&[u8]>,
) -> PyResult<ReceivedSession> {
    let b_pk =
        soliton::identity::IdentityPublicKey::from_bytes(bob_ik_pk.to_vec()).map_err(to_py_err)?;
    let b_sk =
        soliton::identity::IdentitySecretKey::from_bytes(bob_ik_sk.to_vec()).map_err(to_py_err)?;
    let a_pk = soliton::identity::IdentityPublicKey::from_bytes(alice_ik_pk.to_vec())
        .map_err(to_py_err)?;
    let si = soliton::kex::decode_session_init(session_init_encoded).map_err(to_py_err)?;
    let sig =
        soliton::identity::HybridSignature::from_bytes(sender_sig.to_vec()).map_err(to_py_err)?;
    let spk_secret =
        soliton::primitives::xwing::SecretKey::from_bytes(spk_sk.to_vec()).map_err(to_py_err)?;
    let opk_secret = match opk_sk {
        Some(data) => Some(
            soliton::primitives::xwing::SecretKey::from_bytes(data.to_vec()).map_err(to_py_err)?,
        ),
        None => None,
    };

    let session = soliton::kex::receive_session(
        &b_pk,
        &b_sk,
        &a_pk,
        &si,
        &sig,
        &spk_secret,
        opk_secret.as_ref(),
    )
    .map_err(to_py_err)?;
    Ok(ReceivedSession {
        inner: Some(session),
    })
}

/// Encode a session init to wire bytes.
#[pyfunction]
fn kex_encode_session_init<'py>(
    py: Python<'py>,
    session_init_encoded: &[u8],
) -> PyResult<Py<PyBytes>> {
    // This re-encodes from decoded form — useful for round-trip testing.
    let si = soliton::kex::decode_session_init(session_init_encoded).map_err(to_py_err)?;
    let encoded = soliton::kex::encode_session_init(&si).map_err(to_py_err)?;
    Ok(PyBytes::new(py, &encoded).into())
}

/// Decode session init from wire bytes.
///
/// Returns a dict with the decoded fields.
#[pyfunction]
fn kex_decode_session_init<'py>(py: Python<'py>, data: &[u8]) -> PyResult<Py<PyBytes>> {
    // For simplicity, just validate it decodes and return the same bytes.
    // The full structured access is via kex_receive which takes encoded bytes.
    let _si = soliton::kex::decode_session_init(data).map_err(to_py_err)?;
    Ok(PyBytes::new(py, data).into())
}

/// Build first-message AAD from fingerprints and encoded session init.
#[pyfunction]
fn kex_build_first_message_aad<'py>(
    py: Python<'py>,
    sender_fp: &[u8],
    recipient_fp: &[u8],
    session_init_encoded: &[u8],
) -> PyResult<Py<PyBytes>> {
    if sender_fp.len() != 32 || recipient_fp.len() != 32 {
        return Err(crate::errors::InvalidLengthError::new_err(
            "fingerprints must be 32 bytes",
        ));
    }
    let sfp: &[u8; 32] = sender_fp.try_into().unwrap();
    let rfp: &[u8; 32] = recipient_fp.try_into().unwrap();
    let aad = soliton::kex::build_first_message_aad_from_encoded(sfp, rfp, session_init_encoded)
        .map_err(to_py_err)?;
    Ok(PyBytes::new(py, &aad).into())
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<InitiatedSession>()?;
    m.add_class::<ReceivedSession>()?;
    m.add_function(wrap_pyfunction!(kex_sign_prekey, m)?)?;
    m.add_function(wrap_pyfunction!(kex_verify_bundle, m)?)?;
    m.add_function(wrap_pyfunction!(kex_initiate, m)?)?;
    m.add_function(wrap_pyfunction!(kex_receive, m)?)?;
    m.add_function(wrap_pyfunction!(kex_encode_session_init, m)?)?;
    m.add_function(wrap_pyfunction!(kex_decode_session_init, m)?)?;
    m.add_function(wrap_pyfunction!(kex_build_first_message_aad, m)?)?;
    Ok(())
}
