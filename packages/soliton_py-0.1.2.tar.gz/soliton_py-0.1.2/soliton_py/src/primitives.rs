//! Primitive cryptographic operations: SHA3-256, HMAC, HKDF.

use pyo3::prelude::*;
use pyo3::types::PyBytes;

use crate::errors::to_py_err;

/// SHA3-256 hash.
#[pyfunction]
fn sha3_256(py: Python<'_>, data: &[u8]) -> PyResult<Py<PyBytes>> {
    let hash = soliton::primitives::sha3_256::hash(data);
    Ok(PyBytes::new(py, &hash).into())
}

/// SHA3-256 hex fingerprint of a public key or arbitrary data.
#[pyfunction]
fn fingerprint_hex(data: &[u8]) -> String {
    soliton::primitives::sha3_256::fingerprint_hex(data)
}

/// HMAC-SHA3-256.
#[pyfunction]
fn hmac_sha3_256(py: Python<'_>, key: &[u8], data: &[u8]) -> PyResult<Py<PyBytes>> {
    let tag = soliton::primitives::hmac::hmac_sha3_256(key, data);
    Ok(PyBytes::new(py, &tag).into())
}

/// Constant-time HMAC-SHA3-256 verification.
#[pyfunction]
fn hmac_sha3_256_verify(a: &[u8], b: &[u8]) -> PyResult<bool> {
    if a.len() != 32 || b.len() != 32 {
        return Err(crate::errors::InvalidLengthError::new_err(
            "both inputs must be 32 bytes",
        ));
    }
    let a: &[u8; 32] = a.try_into().unwrap();
    let b: &[u8; 32] = b.try_into().unwrap();
    Ok(soliton::primitives::hmac::hmac_sha3_256_verify_raw(a, b))
}

/// HKDF-SHA3-256 extract-and-expand.
#[pyfunction]
#[pyo3(signature = (salt, ikm, info, *, length))]
fn hkdf_sha3_256(
    py: Python<'_>,
    salt: &[u8],
    ikm: &[u8],
    info: &[u8],
    length: usize,
) -> PyResult<Py<PyBytes>> {
    let mut out = vec![0u8; length];
    soliton::primitives::hkdf::hkdf_sha3_256(salt, ikm, info, &mut out).map_err(to_py_err)?;
    Ok(PyBytes::new(py, &out).into())
}

/// Generate an X-Wing keypair.
///
/// Returns (public_key, secret_key) as a tuple of bytes.
/// Public key is 1216 bytes, secret key is 2432 bytes.
#[pyfunction]
fn xwing_keygen(py: Python<'_>) -> PyResult<(Py<PyBytes>, Py<PyBytes>)> {
    let (pk, sk) = soliton::primitives::xwing::keygen().map_err(to_py_err)?;
    Ok((
        PyBytes::new(py, pk.as_bytes()).into(),
        PyBytes::new(py, sk.as_bytes()).into(),
    ))
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(sha3_256, m)?)?;
    m.add_function(wrap_pyfunction!(fingerprint_hex, m)?)?;
    m.add_function(wrap_pyfunction!(hmac_sha3_256, m)?)?;
    m.add_function(wrap_pyfunction!(hmac_sha3_256_verify, m)?)?;
    m.add_function(wrap_pyfunction!(hkdf_sha3_256, m)?)?;
    m.add_function(wrap_pyfunction!(xwing_keygen, m)?)?;
    Ok(())
}
