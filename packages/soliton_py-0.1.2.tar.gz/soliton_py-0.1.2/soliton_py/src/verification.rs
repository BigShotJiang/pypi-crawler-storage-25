//! Verification phrases for out-of-band identity verification.

use pyo3::prelude::*;

use crate::errors::to_py_err;

/// Generate a verification phrase from two identity public keys.
///
/// Each key must be 3200 bytes (full identity public key, not fingerprint).
/// Returns a human-readable phrase (6 words from the EFF large wordlist).
/// The phrase is symmetric — swapping the keys produces the same phrase.
#[pyfunction]
fn verification_phrase(pk_a: &[u8], pk_b: &[u8]) -> PyResult<String> {
    soliton::verification::verification_phrase(pk_a, pk_b).map_err(to_py_err)
}

pub fn register(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(verification_phrase, m)?)?;
    Ok(())
}
