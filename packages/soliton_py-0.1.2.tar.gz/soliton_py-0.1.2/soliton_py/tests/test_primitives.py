"""Tests for primitive cryptographic operations."""

import soliton


def test_sha3_256_known_vector():
    """FIPS 202 test vector: SHA3-256("abc")."""
    result = soliton.sha3_256(b"abc")
    expected = bytes.fromhex(
        "3a985da74fe225b2045c172d6bd390bd"
        "855f086e3e9d525b46bfe24511431532"
    )
    assert result == expected


def test_sha3_256_empty():
    """FIPS 202 test vector: SHA3-256("")."""
    result = soliton.sha3_256(b"")
    expected = bytes.fromhex(
        "a7ffc6f8bf1ed76651c14756a061d662"
        "f580ff4de43b49fa82d80a4b80f8434a"
    )
    assert result == expected


def test_fingerprint_hex():
    result = soliton.fingerprint_hex(b"abc")
    assert isinstance(result, str)
    assert len(result) == 64  # 32 bytes hex-encoded


def test_hmac_sha3_256():
    key = b"\x0b" * 32
    data = b"Hi There"
    tag = soliton.hmac_sha3_256(key, data)
    assert len(tag) == 32


def test_hmac_sha3_256_verify():
    key = b"\x0b" * 32
    data = b"Hi There"
    tag = soliton.hmac_sha3_256(key, data)
    assert soliton.hmac_sha3_256_verify(tag, tag) is True
    # Tampered tag should fail.
    tampered = bytearray(tag)
    tampered[0] ^= 0xFF
    assert soliton.hmac_sha3_256_verify(tag, bytes(tampered)) is False


def test_hkdf_sha3_256():
    salt = b"\x00" * 32
    ikm = b"\x0b" * 32
    info = b"test"
    okm = soliton.hkdf_sha3_256(salt, ikm, info, length=64)
    assert len(okm) == 64
