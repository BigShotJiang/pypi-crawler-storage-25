"""Tests for identity key management."""

import soliton


def test_keygen():
    with soliton.Identity.generate() as id:
        pk = id.public_key()
        sk = id.secret_key()
        assert len(pk) == 3200  # SOLITON_PUBLIC_KEY_SIZE
        assert len(sk) == 2496  # SOLITON_SECRET_KEY_SIZE


def test_fingerprint():
    with soliton.Identity.generate() as id:
        fp = id.fingerprint()
        assert len(fp) == 32
        assert fp != b"\x00" * 32


def test_fingerprint_hex():
    with soliton.Identity.generate() as id:
        hex_fp = id.fingerprint_hex()
        assert len(hex_fp) == 64


def test_sign_verify():
    with soliton.Identity.generate() as id:
        msg = b"test message"
        sig = id.sign(msg)
        assert len(sig) == 3373  # SOLITON_HYBRID_SIG_SIZE
        # Verify with same identity.
        id.verify(msg, sig)


def test_sign_verify_wrong_message():
    with soliton.Identity.generate() as id:
        sig = id.sign(b"correct")
        try:
            id.verify(b"wrong", sig)
            assert False, "should have raised"
        except soliton.VerificationError:
            pass


def test_context_manager_zeroizes():
    id = soliton.Identity.generate()
    with id:
        _ = id.secret_key()
    # After exiting context, secret key should be gone.
    try:
        id.secret_key()
        assert False, "should have raised"
    except soliton.InvalidDataError:
        pass


def test_from_bytes_roundtrip():
    with soliton.Identity.generate() as id:
        pk = id.public_key()
        sk = id.secret_key()
    # Reconstruct.
    id2 = soliton.Identity.from_bytes(pk, sk)
    msg = b"roundtrip"
    sig = id2.sign(msg)
    id2.verify(msg, sig)
    id2.close()


def test_public_only_cannot_sign():
    with soliton.Identity.generate() as id:
        pk = id.public_key()
    pub_only = soliton.Identity.from_public_bytes(pk)
    try:
        pub_only.sign(b"test")
        assert False, "should have raised"
    except soliton.InvalidDataError:
        pass
