"""Tests for LO-Auth challenge-response."""

import soliton


def test_auth_round_trip():
    with soliton.Identity.generate() as id:
        pk = id.public_key()
        sk = id.secret_key()

        # Server generates challenge.
        ct, token = soliton.auth_challenge(pk)

        # Client responds.
        proof = soliton.auth_respond(sk, ct)

        # Server verifies.
        assert soliton.auth_verify(token, proof) is True


def test_auth_wrong_proof():
    with soliton.Identity.generate() as id:
        pk = id.public_key()
        ct, token = soliton.auth_challenge(pk)
        # Tampered proof.
        fake_proof = b"\x00" * 32
        assert soliton.auth_verify(token, fake_proof) is False
