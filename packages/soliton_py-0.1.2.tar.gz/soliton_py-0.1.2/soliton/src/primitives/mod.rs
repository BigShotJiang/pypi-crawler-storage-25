//! Safe Rust wrappers over cryptographic primitives.
//!
//! Each module validates inputs and zeroizes intermediates.
//! All implementations are pure Rust — no C FFI.

pub mod aead;
pub mod argon2;
pub mod ed25519;
pub mod hkdf;
pub mod hmac;
pub mod mldsa;
pub mod mlkem;
pub mod random;
pub mod sha3_256;
pub mod x25519;
pub mod xwing;
