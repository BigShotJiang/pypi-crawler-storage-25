#![forbid(unsafe_code)]
#![deny(missing_docs)]
#![deny(clippy::cast_possible_truncation)]
//! # soliton
//!
//! Core cryptographic library for the LO protocol.
//!
//! Provides all cryptographic operations specified in Soliton Specification:
//! - Soliton composite key (X-Wing + Ed25519 + ML-DSA-65) generation and management
//! - Hybrid signatures (Ed25519 + ML-DSA-65)
//! - KEM-based authentication
//! - LO-KEX key agreement (session initiation and reception)
//! - LO-Ratchet (KEM ratchet + symmetric chain) message encryption
//! - Storage encryption (XChaCha20-Poly1305 + zstd)
//!
//! ## Backend
//!
//! Pure Rust on all targets (native and WASM):
//! - **RustCrypto**: ML-KEM-768, ML-DSA-65, XChaCha20-Poly1305, SHA3-256, HMAC, HKDF
//! - **curve25519-dalek / ed25519-dalek**: X25519, Ed25519
//! - **getrandom**: CSPRNG

// Prevent `test-utils` from being enabled in release builds.
// The feature gates test-only helpers (zeroed key constructors, state inspection)
// that must never be available outside of test/development contexts.
#[cfg(all(feature = "test-utils", not(debug_assertions)))]
compile_error!(
    "The `test-utils` feature must not be enabled in release builds. \
     It exposes internal state constructors that bypass security invariants."
);

/// Library version, matching the crate version from Cargo.toml.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Protocol constants (key sizes, HKDF labels, version strings).
pub mod constants;
/// Error types for all soliton operations.
pub mod error;

/// KEM-based authentication challenge/response (§4).
pub mod auth;
/// E2EE voice call key derivation (§6.12).
pub mod call;
/// LO composite identity key and hybrid signature operations (§2, §3).
pub mod identity;
/// LO-KEX session key agreement (§5).
pub mod kex;
/// Low-level cryptographic primitives (AEAD, KEM, signatures, hashing, RNG).
pub mod primitives;
/// LO-Ratchet and message encryption (§6, §7).
pub mod ratchet;
/// Server-side storage encryption with key rotation (§11).
pub mod storage;
/// Streaming/chunked AEAD for large payloads (§15).
pub mod streaming;
/// Verification phrase generation for out-of-band identity verification (§9).
pub mod verification;
