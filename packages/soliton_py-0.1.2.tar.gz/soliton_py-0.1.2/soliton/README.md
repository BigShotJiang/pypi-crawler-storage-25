# libsoliton

Pure-Rust post-quantum cryptographic library. Provides composite identity keys (X-Wing + ML-DSA-65), hybrid signatures, KEM-based authentication, asynchronous key exchange, double-ratchet message encryption, streaming AEAD, and encrypted storage — all without a C toolchain.

## Features

- **Hybrid post-quantum**: X-Wing (X25519 + ML-KEM-768) for KEM, Ed25519 + ML-DSA-65 for signatures
- **Double ratchet**: KEM-based ratchet with per-epoch forward secrecy and post-compromise security
- **Streaming AEAD**: Chunked XChaCha20-Poly1305 with random-access decrypt
- **Encrypted storage**: Versioned key rings, community blobs, DM queue blobs
- **Zero-knowledge auth**: KEM challenge-response proof of identity key possession
- **Pure Rust**: No C dependencies, no system linker requirements, cross-compiles to WASM

## Usage

```rust
use soliton::identity::generate_identity;
use soliton::primitives::sha3_256;

// Generate a post-quantum identity keypair
let id = generate_identity().unwrap();
let fingerprint = sha3_256::hash(id.public_key.as_bytes());

// Sign and verify
let sig = soliton::identity::hybrid_sign(&id.secret_key, b"hello").unwrap();
soliton::identity::hybrid_verify(&id.public_key, b"hello", &sig).unwrap();
```

See [CHEATSHEET.md](https://git.lo.sh/lo/libsoliton/src/branch/master/CHEATSHEET.md) for the full API reference.

## Documentation

- [Specification.md](https://git.lo.sh/lo/libsoliton/src/branch/master/Specification.md) — full cryptographic specification
- [Abstract.md](https://git.lo.sh/lo/libsoliton/src/branch/master/Abstract.md) — security analysis specification
- [CHEATSHEET.md](https://git.lo.sh/lo/libsoliton/src/branch/master/CHEATSHEET.md) — API quick reference

## License

[AGPL-3.0-only](https://git.lo.sh/lo/libsoliton/src/branch/master/LICENSE.md)
