"""libsoliton — post-quantum cryptographic library.

Pure-Rust post-quantum cryptographic library providing composite identity keys
(X-Wing + ML-DSA-65), hybrid signatures, KEM-based authentication, asynchronous
key exchange, double-ratchet message encryption, and encrypted storage.

Usage::

    import soliton

    # Identity
    with soliton.Identity.generate() as alice:
        sig = alice.sign(b"hello")
        alice.verify(b"hello", sig)

    # KEX (key exchange)
    initiated = soliton.kex_initiate(alice_pk, alice_sk, bob_pk, spk_pub, ...)
    received = soliton.kex_receive(bob_pk, bob_sk, alice_pk, si_encoded, ...)

    # Ratchet (ongoing messaging)
    with soliton.Ratchet.init_alice(root_key, chain_key, ...) as r:
        header, ct = r.encrypt(b"hello")

    # Streaming AEAD (file encryption)
    with soliton.StreamEncryptor(key) as enc:
        header = enc.header()
        chunk = enc.encrypt_chunk(data, is_last=True)

    # Storage
    with soliton.StorageKeyRing(1, key) as ring:
        blob = ring.encrypt_blob("ch", "seg", plaintext)

    # Auth
    ct, token = soliton.auth_challenge(client_pk)
    proof = soliton.auth_respond(client_sk, ct)
    ok = soliton.auth_verify(token, proof)
"""

from soliton._native import (
    # Version
    __version__,
    VERSION,
    # Errors
    SolitonError,
    InvalidLengthError,
    InvalidDataError,
    AeadError,
    VerificationError,
    BundleVerificationError,
    DecapsulationError,
    DuplicateMessageError,
    ChainExhaustedError,
    UnsupportedVersionError,
    UnsupportedCryptoVersionError,
    InternalError,
    # Identity
    Identity,
    # Primitives
    sha3_256,
    fingerprint_hex,
    hmac_sha3_256,
    hmac_sha3_256_verify,
    hkdf_sha3_256,
    xwing_keygen,
    # Auth
    auth_challenge,
    auth_respond,
    auth_verify,
    # Verification
    verification_phrase,
    # KEX
    InitiatedSession,
    ReceivedSession,
    kex_sign_prekey,
    kex_verify_bundle,
    kex_initiate,
    kex_receive,
    kex_encode_session_init,
    kex_decode_session_init,
    kex_build_first_message_aad,
    # Ratchet
    Ratchet,
    # Storage
    StorageKeyRing,
    # Streaming
    StreamEncryptor,
    StreamDecryptor,
    # Call Keys
    CallKeys,
)

__all__ = [
    "__version__",
    "VERSION",
    # Errors
    "SolitonError",
    "InvalidLengthError",
    "InvalidDataError",
    "AeadError",
    "VerificationError",
    "BundleVerificationError",
    "DecapsulationError",
    "DuplicateMessageError",
    "ChainExhaustedError",
    "UnsupportedVersionError",
    "UnsupportedCryptoVersionError",
    "InternalError",
    # Identity
    "Identity",
    # Primitives
    "sha3_256",
    "fingerprint_hex",
    "hmac_sha3_256",
    "hmac_sha3_256_verify",
    "hkdf_sha3_256",
    "xwing_keygen",
    # Auth
    "auth_challenge",
    "auth_respond",
    "auth_verify",
    # Verification
    "verification_phrase",
    # KEX
    "InitiatedSession",
    "ReceivedSession",
    "kex_sign_prekey",
    "kex_verify_bundle",
    "kex_initiate",
    "kex_receive",
    "kex_encode_session_init",
    "kex_decode_session_init",
    "kex_build_first_message_aad",
    # Ratchet
    "Ratchet",
    # Storage
    "StorageKeyRing",
    # Streaming
    "StreamEncryptor",
    "StreamDecryptor",
    # Call Keys
    "CallKeys",
]
