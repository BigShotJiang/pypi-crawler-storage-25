# Examples

Runnable scripts demonstrating `koios-model-utils`.  Each builds a tiny
ONNX file in-memory so the examples are self-contained — no fixtures,
no framework dependencies.

```bash
pip install koios-model-utils
python examples/01_minimal_embed.py
python examples/02_discrete_action_map.py
python examples/03_parse_round_trip.py
```

| Script | What it shows |
|---|---|
| [`01_minimal_embed.py`](01_minimal_embed.py) | Minimal `embed_koios_metadata` call — two inputs, one output, basic `TrainingMeta`. |
| [`02_discrete_action_map.py`](02_discrete_action_map.py) | DISCRETE output mode with a typed `ActionMapEntry` action map. |
| [`03_parse_round_trip.py`](03_parse_round_trip.py) | Embed → save → reload → `parse_koios_metadata`, with assertions confirming round-trip integrity. |

Real-world producers (Ronin's adapter, manual export scripts) follow the
same pattern but with a real model graph instead of the dummy
`build_dummy_onnx_model()` helper.
