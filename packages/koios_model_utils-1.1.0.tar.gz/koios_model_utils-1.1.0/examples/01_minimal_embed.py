"""Minimal example: embed koios metadata into an ONNX file.

Run from the repo root::

    python examples/01_minimal_embed.py

Writes ``out_minimal.onnx`` to the current directory.
"""

from __future__ import annotations

import onnx
from _common import build_dummy_onnx_model

from koios_model_utils import (
    Algorithm,
    InputBinding,
    NormalizationSource,
    NormalizationType,
    OutputBinding,
    TrainingMeta,
    embed_koios_metadata,
)


def main() -> None:
    model = build_dummy_onnx_model(n_inputs=2, n_outputs=1)

    inputs = [
        InputBinding(name="tank_temperature", description="Tank temperature (C)"),
        InputBinding(name="pressure", description="Vessel pressure (kPa)"),
    ]
    outputs = [
        OutputBinding(
            name="valve_position",
            description="Control valve position (%)",
            range_min=0.0,
            range_max=100.0,
            normalization_type=NormalizationType.SYMMETRIC,
            normalization_source=NormalizationSource.CUSTOM,
            custom_minimum=0.0,
            custom_maximum=100.0,
            clamp_output=True,
        ),
    ]
    training = TrainingMeta(
        scenario_name="tank_temperature",
        algorithm=Algorithm.PPO,
        obs_depth=5,
        sample_rate=1.0,
    )

    embed_koios_metadata(model, inputs=inputs, outputs=outputs, training=training)

    out_path = "out_minimal.onnx"
    onnx.save(model, out_path)
    print(f"Wrote {out_path} ({len(model.metadata_props)} metadata props)")


if __name__ == "__main__":
    main()
