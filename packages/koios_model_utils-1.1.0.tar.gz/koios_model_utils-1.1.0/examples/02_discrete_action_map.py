"""DISCRETE-output example: classifier / DQN head with an action map.

Run from the repo root::

    python examples/02_discrete_action_map.py

Writes ``out_discrete.onnx`` to the current directory.
"""

from __future__ import annotations

import onnx
from _common import build_dummy_onnx_model

from koios_model_utils import (
    ActionMapEntry,
    Algorithm,
    InputBinding,
    OutputBinding,
    OutputMode,
    TrainingMeta,
    embed_koios_metadata,
)


def main() -> None:
    model = build_dummy_onnx_model(n_inputs=3, n_outputs=1)

    inputs = [
        InputBinding(name="tank_level", description="Tank level (%)"),
        InputBinding(name="inflow_rate", description="Inflow rate (L/min)"),
        InputBinding(name="outflow_rate", description="Outflow rate (L/min)"),
    ]
    outputs = [
        OutputBinding(
            name="setpoint_action",
            description="Discrete setpoint adjustment",
        ),
    ]
    training = TrainingMeta(
        scenario_name="tank_level_control",
        algorithm=Algorithm.DQN,
        obs_depth=10,
        sample_rate=1.0,
        output_mode=OutputMode.DISCRETE,
        action_map=[
            ActionMapEntry(value=-1.0, label="Decrease setpoint"),
            ActionMapEntry(value=0.0, label="Hold"),
            ActionMapEntry(value=1.0, label="Increase setpoint"),
        ],
    )

    embed_koios_metadata(model, inputs=inputs, outputs=outputs, training=training)

    out_path = "out_discrete.onnx"
    onnx.save(model, out_path)
    print(f"Wrote {out_path} with {len(training.action_map or [])}-entry action map")


if __name__ == "__main__":
    main()
