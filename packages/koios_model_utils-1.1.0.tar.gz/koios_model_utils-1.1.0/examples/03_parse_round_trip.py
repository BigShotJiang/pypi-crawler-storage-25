"""Round-trip example: embed metadata, save, reload, parse, verify.

Run from the repo root::

    python examples/03_parse_round_trip.py
"""

from __future__ import annotations

import io

import onnx
from _common import build_dummy_onnx_model

from koios_model_utils import (
    Algorithm,
    InputBinding,
    NormalizationSource,
    NormalizationType,
    OutputBinding,
    TrainingMeta,
    embed_koios_metadata,
    parse_koios_metadata,
)


def main() -> None:
    model = build_dummy_onnx_model(n_inputs=2, n_outputs=1)

    inputs = [
        InputBinding(
            name="temperature",
            description="Sensor temperature (C)",
            normalization_type=NormalizationType.Z_SCORE,
            normalization_source=NormalizationSource.CUSTOM,
            custom_mean=20.0,
            custom_std=5.0,
        ),
        InputBinding(
            name="humidity",
            description="Relative humidity (%)",
            normalization_type=NormalizationType.MIN_MAX,
            normalization_source=NormalizationSource.TAG_RANGE,
        ),
    ]
    outputs = [
        OutputBinding(
            name="fan_speed",
            description="Fan speed setpoint (%)",
            normalization_type=NormalizationType.SYMMETRIC,
            normalization_source=NormalizationSource.CUSTOM,
            custom_minimum=0.0,
            custom_maximum=100.0,
            clamp_output=True,
        ),
    ]
    training = TrainingMeta(
        scenario_name="hvac_zone",
        algorithm=Algorithm.SAC,
        obs_depth=20,
        sample_rate=2.0,
        scan_rate=0.5,
    )

    embed_koios_metadata(model, inputs=inputs, outputs=outputs, training=training)

    buf = io.BytesIO()
    onnx.save(model, buf)
    buf.seek(0)
    reloaded = onnx.load(buf)

    parsed = parse_koios_metadata(reloaded)
    assert parsed.has_metadata, "expected metadata to be present"
    assert parsed.training is not None
    assert parsed.training.scenario_name == "hvac_zone"
    assert parsed.training.sample_rate == 2.0
    assert parsed.training.scan_rate == 0.5
    assert len(parsed.inputs) == 2
    assert parsed.inputs[0].normalization_type == NormalizationType.Z_SCORE
    assert parsed.inputs[0].custom_mean == 20.0
    assert parsed.inputs[1].normalization_source == NormalizationSource.TAG_RANGE
    assert len(parsed.outputs) == 1
    assert parsed.outputs[0].clamp_output is True

    print("Round-trip OK")
    print(f"  scenario:    {parsed.training.scenario_name}")
    print(f"  algorithm:   {parsed.training.algorithm}")
    print(f"  sample_rate: {parsed.training.sample_rate}s")
    print(f"  scan_rate:   {parsed.training.scan_rate}s")
    print(f"  inputs:      {[b.name for b in parsed.inputs]}")
    print(f"  outputs:     {[b.name for b in parsed.outputs]}")


if __name__ == "__main__":
    main()
