"""Shared helper for building a tiny ONNX model in-memory.

The examples don't ship a fixture file; they construct a trivial
identity model on demand so each script is self-contained.  In a real
producer you'd hand ``embed_koios_metadata`` a model you already
exported via ``torch.onnx.export``, ``tf2onnx``, or similar.
"""

from __future__ import annotations

import onnx
from onnx import TensorProto, helper


def build_dummy_onnx_model(n_inputs: int = 2, n_outputs: int = 1) -> onnx.ModelProto:
    """Build a minimal identity-style ONNX model for example purposes."""
    input_tensors = [
        helper.make_tensor_value_info(f"input_{i}", TensorProto.FLOAT, [1]) for i in range(n_inputs)
    ]
    output_tensors = [
        helper.make_tensor_value_info(f"output_{i}", TensorProto.FLOAT, [1])
        for i in range(n_outputs)
    ]

    nodes = [
        helper.make_node("Identity", [f"input_{i % n_inputs}"], [f"output_{i}"])
        for i in range(n_outputs)
    ]

    graph = helper.make_graph(nodes, "example", input_tensors, output_tensors)
    return helper.make_model(graph, producer_name="koios-model-utils-example", ir_version=10)
