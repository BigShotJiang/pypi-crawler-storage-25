# CLAUDE.md — agent guide for `koios-model-utils`

You are helping a user annotate an ONNX model with the metadata the
Koios IoT platform consumes on upload.  This file is the cheat sheet —
[`docs/CONTRACT.md`](docs/CONTRACT.md) is the long-form spec, read it
when you need detail.

## What this library is

A metadata writer / reader for ONNX files headed to Koios.  Two JSON
blobs go into `model.metadata_props`:

- `koios.training` — model-level info (algorithm, sample_rate, scan_rate, action map)
- `koios.bindings` — per-input and per-output configuration (names, normalization, failure bounds)

Both are produced by `embed_koios_metadata(...)` and read back by
`parse_koios_metadata(...)`.  Nothing else.

## What this library is NOT

- Not an ONNX exporter — bring your own `.onnx` file from any framework
- No Stable-Baselines3 dependency, no callbacks, no CLI (the 1.0 README
  referenced these; they were removed)
- Not a runtime — the Koios predict engine consumes the metadata; this
  library only writes it

If a user asks you to "export an SB3 model with this library", redirect:
they should call `torch.onnx.export` (or whatever their framework
uses) themselves, then hand the resulting `onnx.ModelProto` to
`embed_koios_metadata`.

## The contract is in `docs/CONTRACT.md`

Before answering questions about field semantics, defaults, server
behavior, or wire format — read [`docs/CONTRACT.md`](docs/CONTRACT.md).
It owns:

- Every wire key, its type, default, and what the webapp does with it
- Casing rules (SCREAMING_SNAKE_CASE on the wire)
- Schema versioning policy (when to bump, what's forward-compatible)
- Known footguns (the legacy MIN_MAX inference fallback, the
  TAG_RANGE + range_min/max collision, dead-weight `obs_depth`)

Don't restate the contract from training data — quote it from the file.

## Hard rules

1. **Use enum members, not raw strings.**  `NormalizationType.Z_SCORE`,
   not `"Z_SCORE"`, not `"z_score"`.  Raw strings still work for
   backward compat but enums catch typos at type-check time.

2. **Don't mutate fields after construction.**  Each dataclass runs
   its validator in `__post_init__` once.  Direct assignment
   (`b.normalization_type = NormalizationType.Z_SCORE`) skips
   re-validation.  Use `dataclasses.replace(b, ...)` to get a new
   instance that re-runs validation.

3. **Pair `failure_range_mode=CUSTOM` with both custom_failure
   bounds.**  The validator enforces this — leaving one unset raises.
   To disable failure detection entirely, use
   `FailureRangeMode.DISABLED`.

4. **For `TAG_RANGE` outputs, omit `range_min`/`range_max`.**  The
   server reads the bound tag's engineering range at runtime;
   embedding training-time bounds triggers a legacy MIN_MAX inference
   fallback and overrides the runtime lookup.  See CONTRACT §Known
   footguns.

5. **`output_denormalized=True` only when the ONNX graph already emits
   physical values** (e.g. a final affine layer that inverts
   normalization in-graph).  Forecasting models trained on normalized
   data should leave it `False`.

## Common tasks

### "Embed metadata into an existing ONNX file"

See [`examples/01_minimal_embed.py`](examples/01_minimal_embed.py).

### "I have a DQN / classifier — how do I set up the action map?"

`output_mode=OutputMode.DISCRETE` on `TrainingMeta`, plus a non-empty
`action_map` of `ActionMapEntry(value=..., label=...)`.  The validator
rejects DISCRETE + empty `action_map` and CONTINUOUS + non-empty
`action_map`.  See [`examples/02_discrete_action_map.py`](examples/02_discrete_action_map.py).

### "Read metadata back from an ONNX file"

`parse_koios_metadata(model)` returns a `ParsedKoiosMetadata` dataclass.
See [`examples/03_parse_round_trip.py`](examples/03_parse_round_trip.py).

### "My RL controller needs to run faster than the training sample rate"

Set `TrainingMeta.scan_rate` explicitly.  Leave it `None` (the default)
to inherit `sample_rate` — the right choice for forecasting models.

## Versioning

This library and the Koios webapp move in lockstep on the wire format.
A schema bump (currently `schema_version: 1`) requires a coordinated
webapp release.  See CONTRACT §"Schema versioning policy" for the
bump procedure.

When in doubt about whether a change is forward-compatible: additive
changes (new optional fields, new enum members) are fine; renames,
removals, and semantic changes need a v2 bump.
