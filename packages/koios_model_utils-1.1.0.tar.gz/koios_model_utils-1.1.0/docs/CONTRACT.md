# koios-model-utils ↔ koios-webapp-py contract

This document is the source of truth for what producers may write into
`koios.training` / `koios.bindings` and what the Koios webapp does with each
field.  It belongs to **koios-model-utils** because the library is the
canonical writer; the webapp is one consumer.

**Schema version: 1**

---

## Where this contract lives

```
producer (Ronin, manual scripts, future DRL workers)
    │
    │  embed_koios_metadata(model, inputs, outputs, training)
    ▼
ONNX file metadata_props
    ├── "koios.training"  →  JSON object
    └── "koios.bindings"  →  JSON object
    │
    │  parse_koios_metadata_from_dict(...)  (in webapp on upload)
    ▼
ParsedKoiosMetadata
    │
    │  _apply_training_metadata(model, parsed.training)
    │  _apply_binding_metadata(model, parsed)
    ▼
AIOPModel + AIOPModelBinding rows
```

The library owns: dataclass shape, JSON wire format, casing rules, and the
parser.  The webapp owns: the `_apply_*` functions, server policy (legacy
aliases, fallback inference, action_map list→dict), and DB persistence.

---

## koios.training payload

| Wire key | Type | Default | Required? | Server behavior |
|---|---|---|---|---|
| `schema_version` | int | always `1` | yes | Reject parse if `!= 1` |
| `scenario_name` | string | `""` | informational | Ignored |
| `algorithm` | string | `""` | informational | Ignored |
| `obs_depth` | int | `1` | informational | Ignored (today) |
| `sample_rate` | float (seconds) | `1.0` | informational | If `> 0`, sets `model.sample_rate`.  Also sets `model.scan_rate` *only when `scan_rate` below is omitted* |
| `scan_rate` | float (seconds) | omitted unless set | optional | When present, sets `model.scan_rate` independently of `sample_rate`.  Use for RL controllers that need to execute faster than the training sample interval |
| `model_type` | string (enum) | `"ABSOLUTE"` | yes | Sets `model.output_application` (with POSITIONAL/VELOCITY aliases for ABSOLUTE/RELATIVE) |
| `output_mode` | string (enum) | omitted unless set | optional | Sets `model.output_mode` |
| `action_map` | list of objects | omitted unless set | optional | Stored on file as `{"0": entry, "1": entry, ...}` |
| `exported_at` | ISO 8601 string | `datetime.now(UTC).isoformat()` | always written | Ignored |

### Field details

**`model_type`** — `"ABSOLUTE"` or `"RELATIVE"`.  Legacy aliases `"POSITIONAL"`
(→ ABSOLUTE) and `"VELOCITY"` (→ RELATIVE) are accepted by the server but
should not be used in new code.  Library 1.1+ canonicalizes case on
serialization, so `"positional"` becomes `"POSITIONAL"` on the wire (the
server then translates to ABSOLUTE).

**`output_mode`** — `"CONTINUOUS"` (one output binding per output neuron) or
`"DISCRETE"` (single output binding holding the action index, used by
classification / DQN-style heads).

**`action_map`** — list of `{value: number, label: string}` objects.  Producers
write a list; the server normalizes to a dict keyed by string indices for
stable lookup.  Only meaningful when `output_mode == DISCRETE`.

Each entry must contain exactly two fields:

| Field | Type | Notes |
|-------|------|-------|
| `value` | number | Engineering value written to the bound tag when the action is selected (e.g. setpoint delta, valve position).  `bool` is rejected — pass `0`/`1` instead. |
| `label` | string | Human-readable name shown in the UI's action-map rows. |

Extra keys on a producer entry are silently dropped on coercion.  Producers
using `koios-model-utils` ≥ 1.1.0 can pass either dataclass instances
(`ActionMapEntry(value=..., label=...)`) or raw dicts; either form is
strictly validated at `TrainingMeta` construction.  Producers emitting
ONNX without going through this library must use the dict form and the
canonical keys above.

**`sample_rate`** — wall-clock seconds between samples in the training
dataset.  Sets `model.sample_rate` (history resampling / lookback interval)
on upload.  Also seeds `model.scan_rate` (predict-engine execution interval)
when `scan_rate` is omitted — the right default for forecasting models that
run at the same cadence they were trained on.

**`scan_rate`** — wall-clock seconds between predict-engine executions, set
independently of `sample_rate`.  Use when the model needs to act faster (or
slower) than the data was sampled at — typical for RL controllers trained
on a coarse simulator step but deployed against a faster control loop.
Omit to inherit `sample_rate`.

---

## koios.bindings payload

```json
{
  "schema_version": 1,
  "output_denormalized": false,
  "inputs": [ /* list of input binding entries */ ],
  "outputs": [ /* list of output binding entries */ ]
}
```

| Wire key | Type | Default | Server behavior |
|---|---|---|---|
| `schema_version` | int | `1` | Reject parse if `!= 1` |
| `output_denormalized` | bool | `false` | When `true`, output bindings get `normalization_type=NONE` and use `range_min/range_max` as failure bounds (overrides any explicit normalization on output bindings) |
| `inputs` | list | `[]` | Each entry maps to an `AIOPModelBinding` with `usage=INPUT, binding_order=index+1` |
| `outputs` | list | `[]` | Each entry maps to an `AIOPModelBinding` with `usage=OUTPUT, binding_order=index+1` |

### Per-binding fields (input)

| Wire key | Type | Default | Required? | Server behavior |
|---|---|---|---|---|
| `binding_order` | int | computed (`index + 1`) | always written | Used by server to find the matching `AIOPModelBinding` row |
| `name` | string | `""` | recommended | Sets `binding.name` |
| `description` | string | `""` | optional | Sets `binding.description` |
| `normalization_type` | string (enum) | omitted if NONE | optional | Sets `binding.normalization_type`.  When omitted, defaults to NONE on the binding row |
| `normalization_source` | string (enum) | omitted if None | optional | Sets `binding.normalization_source` |
| `custom_minimum` | float | omitted if None | conditional | For MIN_MAX/SYMMETRIC + CUSTOM source — the lower training-time bound |
| `custom_maximum` | float | omitted if None | conditional | Upper bound, paired with `custom_minimum` |
| `custom_mean` | float | omitted if None | conditional | For Z_SCORE + CUSTOM source — training-time mean |
| `custom_std` | float | omitted if None | conditional | Z_SCORE std dev, paired with `custom_mean` |
| `failure_range_mode` | string (enum) | omitted unless `custom_failure=True` | optional | When `"CUSTOM"`, server uses explicit failure bounds; otherwise inherits from normalization range |
| `custom_failure_minimum` | float | omitted | conditional | Failure bound lower; paired with `failure_range_mode=CUSTOM` |
| `custom_failure_maximum` | float | omitted | conditional | Failure bound upper |

### Per-binding fields (output) — adds these to the input set

| Wire key | Type | Default | Required? | Server behavior |
|---|---|---|---|---|
| `range_min` | float | omitted if None | optional | **Wire-only field** — never persisted. Feeds `output_denormalized` and legacy MIN_MAX fallback (see below) |
| `range_max` | float | omitted if None | optional | Paired with `range_min` |
| `clamp_output` | bool | omitted if False | optional | Sets `binding.clamp_output` |

### Output-binding server policies

The server applies output bindings with two override paths in this order:

1. **`output_denormalized=true` + `range_min/max` both set.**  Forces
   `normalization_type=NONE` and `failure_range_mode=CUSTOM` with
   `custom_failure_minimum/maximum` taken from the training range.  Use this
   when the ONNX graph already emits physical values.

2. **Legacy MIN_MAX inference fallback.**  If `normalization_type=NONE` (or
   not set) but `range_min/max` *are* set, the server infers
   `MIN_MAX + CUSTOM` and seeds `custom_minimum/maximum` from `range_*`.
   Producers should **prefer explicit normalization** and avoid relying on
   this fallback — it's there for files predating the explicit
   normalization fields.  See the "Known footguns" section below.

Otherwise, the field-level mappings apply directly.

---

## Casing rules

String values for enum-typed fields are **SCREAMING_SNAKE_CASE on the wire**
(`"Z_SCORE"`, `"TAG_RANGE"`, `"ABSOLUTE"`, `"CONTINUOUS"`).

The library:

- accepts either an enum member or any-case string at construction time;
- canonicalizes to uppercase on serialization (library 1.1+) for the four
  enum-typed fields: `normalization_type`, `normalization_source`,
  `model_type`, `output_mode`;
- preserves `algorithm` casing exactly (informational, free-form).

The webapp's parser is case-insensitive for compatibility with files written
by 1.0.x.  New producers should rely on the library's canonical output and
never write lowercase wire values directly.

---

## Z_SCORE has stricter constraints

Server policy: when `normalization_type=Z_SCORE`, `failure_range_mode` is
**forced to `CUSTOM`**.  Z-Score normalization has no min/max, so the
`NORMALIZATION_RANGE` failure mode is meaningless.  The server applies this
override during `_apply_binding_metadata`; producers don't need to set
`custom_failure=True` explicitly, but should provide
`custom_failure_minimum/maximum` if they want failure-bound checks (otherwise
the bounds default to None and the server will not flag out-of-range
values).

---

## What's NOT in the contract

- **`AIOPModelBinding.range_min` / `range_max`** — these are wire-only fields,
  not columns.  Producers can write them but the server only uses them for
  the two override paths above.
- **Cross-binding consistency vs the ONNX graph** — the library does not check
  that `len(inputs)` matches the ONNX input neuron count.  Server iterates by
  `binding_order`; missing entries leave bindings blank, extras are silently
  ignored.
- **`obs_depth` cross-check against ONNX shape** — `obs_depth` is
  informational only today.
- **Re-validation after dataclass mutation.**  `__post_init__` runs once at
  construction.  If a producer constructs a binding and then mutates a field
  (`b.normalization_type = NormalizationType.Z_SCORE; b.custom_mean = ...`),
  the new state is not re-checked.  Producers that need to mutate after
  construction should call `dataclasses.replace(b, ...)` instead, which
  re-runs `__post_init__`.

---

## Schema versioning policy

The library writes `schema_version: 1` for both payloads.  The parser
**rejects** any payload with `schema_version != 1` via
`UnsupportedSchemaVersionError`.

### When to bump the version

| Change | Bump? |
|---|---|
| Add a new optional field | No (additive) |
| Add a new optional enum member | No (additive — old parsers will pass through unknown values as raw strings) |
| Rename an existing field | **Yes** (v2) |
| Change the type or semantics of a field | **Yes** (v2) |
| Remove a field | **Yes** (v2) |

When v2 lands, the library should either:

- Read both v1 and v2 payloads, with `embed` always writing v2; or
- Provide a v1→v2 migration helper for stored `training_metadata` JSON in
  the webapp (`AIOPModelFile.training_metadata` is the long-lived store).

The exact strategy isn't fixed yet — pick when v2 is needed.

### Forward-compat rules (within v1)

- Unknown wire keys are **silently ignored** by the parser.  Library 1.2+
  may add fields that 1.1 readers skip without error.
- Unknown enum member values are **passed through as raw strings** (the
  dataclass field type is `EnumT | str`).  Server policy decides what to do
  with unrecognized values.
- The dataclass shape is fixed at v1; new optional fields can be added
  with a default that round-trips through embed→parse.  Adding a non-default
  field is a breaking change to the dataclass API and warrants a library
  version bump (1.x → 2.0).

---

## Known footguns

### 1. The legacy MIN_MAX inference fallback

If a producer writes `range_min/range_max` on an output binding **without**
setting `normalization_type` (or sets it to `NONE`), the server infers
`MIN_MAX + CUSTOM + custom_minimum/maximum + clamp_output` from those
values.  This is **legacy behavior** for files pre-dating the explicit
normalization fields; new producers should always set `normalization_type`
explicitly.

The Ronin adapter explicitly *avoids* this trap by omitting `range_min/max`
on output bindings whose `normalization_source=TAG_RANGE`, because they
want the server to read the bound tag's engineering range at runtime — not
to bake training-time bounds.  See
`ronin/services/training/sensai_training/tasks/forecasting/models/koios_metadata.py::_extend_for_output`.

**Recommendation:** kill the legacy fallback in a future webapp version, or
make it explicit (e.g. an `infer_min_max=True` flag).

### 2. `obs_depth` is dead weight

`TrainingMeta.obs_depth` is written on every payload but the webapp ignores
it.  Ronin sets it to `input_chunk_length`.  Either:

- Start using it (cross-check against ONNX shape's time dimension on upload
  and warn on mismatch), or
- Drop it from the schema in v2.

---

## Runtime compatibility

The library writes ONNX files that the Koios platform's `onnxruntime` must
load.  Newer onnx libraries default to higher IR versions than the deployed
runtime supports — an `onnx 1.21` producer writes IR 13 by default, but the
platform's `onnxruntime 1.23.x` rejects anything above IR 11.

To keep producers de-coupled from the platform's deployed runtime version:

- The library pins `onnx` to a range whose default IR the platform can load
  (`onnx>=1.16,<1.21` as of writing).
- `embed_koios_metadata` lowers `model.ir_version` to `MAX_SUPPORTED_IR_VERSION`
  on every embed.  Producers who force-install a newer `onnx` still emit
  platform-compatible files.

### Bumping `MAX_SUPPORTED_IR_VERSION`

Required when a Koios release upgrades `onnxruntime`.  Order:

1. Bump `onnxruntime` in `koios-webapp-py` and `koios-predictengine-py`
   together (they must match).
2. Verify against representative customer models in a staging environment —
   newer ORT reads older IR, but op kernel behavior may shift across major
   versions.
3. In this library: widen the `onnx` upper bound and raise
   `MAX_SUPPORTED_IR_VERSION` in `metadata.py`.
4. Tag a library release.  Producers that re-export against the new library
   get the higher IR; existing files keep loading because newer ORT remains
   backward-compatible.

The current target compatibility window is documented in the library's
`pyproject.toml` `dependencies` block.

---

## Producer best practices

Authoring guidance for new producers (Ronin's adapter is the reference):

1. **Always pass enum members, not strings.**  `NormalizationType.Z_SCORE`,
   not `"z_score"` or `"Z_SCORE"`.  Type-checks better, fails earlier, and
   makes the call site readable.
2. **Set `normalization_type` and `normalization_source` together** for
   non-NONE cases.  Do not rely on the legacy MIN_MAX inference fallback.
3. **For `TAG_RANGE` outputs, omit `range_min/range_max`.**  Embedding
   training-time values defeats the runtime tag-range lookup.  See Ronin's
   `_extend_for_output`.
4. **Pair `failure_range_mode=CUSTOM` with `custom_failure_minimum/maximum`.**
   The dataclass validators enforce this — the combination raises at
   construction.  To explicitly disable failure detection, set
   `failure_range_mode=FailureRangeMode.DISABLED` and leave the bounds unset.
5. **Use `output_denormalized=True` only when the ONNX graph emits
   physical values.**  This is the SB3 case where output normalization is
   inverted in-graph (e.g. via a final affine layer).  Forecasting models
   trained on normalized data should leave it `False`.
