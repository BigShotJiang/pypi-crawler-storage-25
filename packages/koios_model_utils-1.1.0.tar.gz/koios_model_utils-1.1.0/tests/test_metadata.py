"""Tests for koios_model_utils.metadata."""

from __future__ import annotations

import json

import onnx
import pytest

from koios_model_utils.enums import (
    Algorithm,
    FailureRangeMode,
    ModelType,
    NormalizationSource,
    NormalizationType,
    OutputMode,
)
from koios_model_utils.metadata import (
    MAX_SUPPORTED_IR_VERSION,
    ActionMapEntry,
    InputBinding,
    KoiosMetadataDecodeError,
    OutputBinding,
    TrainingMeta,
    UnsupportedSchemaVersionError,
    embed_koios_metadata,
    parse_koios_metadata,
    parse_koios_metadata_from_dict,
)


def _make_dummy_onnx_model() -> onnx.ModelProto:
    """Create a minimal valid ONNX model for testing metadata embedding."""
    # Simple identity model: Y = X
    x = onnx.helper.make_tensor_value_info("X", onnx.TensorProto.FLOAT, [1, 3])
    y = onnx.helper.make_tensor_value_info("Y", onnx.TensorProto.FLOAT, [1, 3])
    node = onnx.helper.make_node("Identity", inputs=["X"], outputs=["Y"])
    graph = onnx.helper.make_graph([node], "test_graph", [x], [y])
    model = onnx.helper.make_model(graph, opset_imports=[onnx.helper.make_opsetid("", 18)])
    return model


class TestEmbedKoiosMetadata:
    def test_basic_embedding(self):
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(name="temperature", description="Tank temp (C)"),
            InputBinding(name="pressure", description="Vessel pressure (kPa)"),
        ]
        outputs = [
            OutputBinding(
                name="valve",
                range_min=0.0,
                range_max=100.0,
                normalization_type="symmetric",
                normalization_source="custom",
                custom_minimum=0.0,
                custom_maximum=100.0,
                clamp_output=True,
            ),
        ]
        training = TrainingMeta(
            scenario_name="tank_temperature",
            algorithm="PPO",
            obs_depth=5,
            sample_rate=1.0,
        )

        embed_koios_metadata(model, inputs=inputs, outputs=outputs, training=training)

        # Check metadata_props
        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert "koios.training" in meta_dict
        assert "koios.bindings" in meta_dict

        # Training metadata
        t = meta_dict["koios.training"]
        assert t["schema_version"] == 1
        assert t["scenario_name"] == "tank_temperature"
        assert t["algorithm"] == "PPO"
        assert t["obs_depth"] == 5
        assert t["sample_rate"] == 1.0
        assert t["model_type"] == "ABSOLUTE"
        assert "exported_at" in t

        # Bindings metadata
        b = meta_dict["koios.bindings"]
        assert b["schema_version"] == 1
        assert b["output_denormalized"] is False
        # obs_normalized is no longer written — it was never read by the server
        # (see CHANGELOG 1.0.0 contract-fix notes).
        assert "obs_normalized" not in b
        assert len(b["inputs"]) == 2
        assert len(b["outputs"]) == 1

        # Input bindings
        inp0 = b["inputs"][0]
        assert inp0["binding_order"] == 1
        assert inp0["name"] == "temperature"
        assert inp0["description"] == "Tank temp (C)"

        inp1 = b["inputs"][1]
        assert inp1["binding_order"] == 2
        assert inp1["name"] == "pressure"

        # Output binding
        out0 = b["outputs"][0]
        assert out0["binding_order"] == 1
        assert out0["name"] == "valve"
        assert out0["range_min"] == 0.0
        assert out0["range_max"] == 100.0
        assert out0["normalization_type"] == "SYMMETRIC"
        assert out0["custom_minimum"] == 0.0
        assert out0["custom_maximum"] == 100.0
        assert out0["clamp_output"] is True

    def test_no_training_meta(self):
        model = _make_dummy_onnx_model()
        inputs = [InputBinding(name="x")]
        outputs = [OutputBinding(name="y")]

        embed_koios_metadata(model, inputs=inputs, outputs=outputs)

        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        t = meta_dict["koios.training"]
        assert t["scenario_name"] == ""
        assert t["algorithm"] == ""

    def test_discrete_output_mode(self):
        model = _make_dummy_onnx_model()
        inputs = [InputBinding(name="x")]
        outputs = [OutputBinding(name="action", normalization_type="none")]
        training = TrainingMeta(
            output_mode="DISCRETE",
            action_map=[{"value": 0, "label": "low"}, {"value": 1, "label": "high"}],
        )

        embed_koios_metadata(model, inputs=inputs, outputs=outputs, training=training)

        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        t = meta_dict["koios.training"]
        assert t["output_mode"] == "DISCRETE"
        assert len(t["action_map"]) == 2

    def test_zscore_input_binding(self):
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(
                name="temp",
                normalization_type="z_score",
                normalization_source="custom",
                custom_mean=25.0,
                custom_std=5.0,
            ),
        ]
        outputs = [OutputBinding(name="y")]

        embed_koios_metadata(model, inputs=inputs, outputs=outputs)

        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        inp0 = meta_dict["koios.bindings"]["inputs"][0]
        assert inp0["normalization_type"] == "Z_SCORE"
        assert inp0["normalization_source"] == "CUSTOM"
        assert inp0["custom_mean"] == 25.0
        assert inp0["custom_std"] == 5.0

    def test_embed_normalizes_lowercase_strings_to_uppercase(self):
        """Library 1.1+ canonicalizes all enum-typed wire values to uppercase
        regardless of what the user passed on the dataclass."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[
                InputBinding(
                    name="x",
                    normalization_type="z_score",  # lowercase string input
                    normalization_source="custom",
                    custom_mean=0.0,
                    custom_std=1.0,
                ),
            ],
            outputs=[OutputBinding(name="y", normalization_type="symmetric")],
            training=TrainingMeta(model_type="absolute", output_mode="continuous"),
        )
        meta = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert meta["koios.training"]["model_type"] == "ABSOLUTE"
        assert meta["koios.training"]["output_mode"] == "CONTINUOUS"
        assert meta["koios.bindings"]["inputs"][0]["normalization_type"] == "Z_SCORE"
        assert meta["koios.bindings"]["inputs"][0]["normalization_source"] == "CUSTOM"
        assert meta["koios.bindings"]["outputs"][0]["normalization_type"] == "SYMMETRIC"

    def test_embed_normalizes_legacy_alias_casing(self):
        """``positional`` (lowercase) must serialize as ``POSITIONAL`` so the
        server's POSITIONAL/VELOCITY → ABSOLUTE/RELATIVE alias map (which is
        keyed on uppercase) actually fires."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
            training=TrainingMeta(model_type="positional"),
        )
        meta = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert meta["koios.training"]["model_type"] == "POSITIONAL"

    def test_embed_does_not_normalize_algorithm(self):
        """Algorithm is informational/free-form — preserve the producer's
        casing exactly (could be a custom algorithm name like ``MyPPO``)."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
            training=TrainingMeta(algorithm="MyCustomAlgo"),
        )
        meta = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert meta["koios.training"]["algorithm"] == "MyCustomAlgo"

    def test_failure_bounds_custom_mode(self):
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(
                name="temp",
                failure_range_mode=FailureRangeMode.CUSTOM,
                custom_failure_minimum=10.0,
                custom_failure_maximum=90.0,
            ),
        ]
        outputs = [OutputBinding(name="y")]

        embed_koios_metadata(model, inputs=inputs, outputs=outputs)

        meta_dict = {p.key: json.loads(p.value) for p in model.metadata_props}
        inp0 = meta_dict["koios.bindings"]["inputs"][0]
        assert inp0["failure_range_mode"] == "CUSTOM"
        assert inp0["custom_failure_minimum"] == 10.0
        assert inp0["custom_failure_maximum"] == 90.0

    def test_failure_bounds_disabled_mode_serializes(self):
        """Producers can explicitly disable failure detection."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x", failure_range_mode=FailureRangeMode.DISABLED)],
            outputs=[OutputBinding(name="y")],
        )
        meta = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert meta["koios.bindings"]["inputs"][0]["failure_range_mode"] == "DISABLED"

    def test_no_failure_mode_omits_key(self):
        """When failure_range_mode is None, the wire key is not emitted."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
        )
        meta = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert "failure_range_mode" not in meta["koios.bindings"]["inputs"][0]


class TestIRVersionCap:
    """``embed_koios_metadata`` lowers the file's IR version so the deployed
    onnxruntime can load it regardless of which onnx library the producer
    happens to have installed (newer onnx libs default to higher IR).

    Don't raise an already-compatible IR — that would be a regression for
    runtimes pinned below MAX_SUPPORTED_IR_VERSION.
    """

    @pytest.mark.parametrize(
        ("input_ir", "expected_ir"),
        [
            (13, MAX_SUPPORTED_IR_VERSION),
            (MAX_SUPPORTED_IR_VERSION, MAX_SUPPORTED_IR_VERSION),
            (8, 8),
        ],
        ids=["high_lowered", "at_cap_unchanged", "low_unchanged"],
    )
    def test_ir_version_cap(self, input_ir, expected_ir):
        model = _make_dummy_onnx_model()
        model.ir_version = input_ir
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
        )
        assert model.ir_version == expected_ir


class TestContractWithWebapp:
    """Lock in the key names that koios-webapp-py's services.py reads.

    These are the keys consumed by `_apply_training_metadata` and
    `_apply_binding_metadata` in
    ``koios-webapp-py/app/AiOpsInterface/apps/aiops/services.py``. If any of
    these names change server-side, this test fails and forces a
    coordinated fix rather than silent drift.
    """

    # Fields the server reads from each top-level payload.
    SERVER_TRAINING_KEYS = frozenset(
        {
            "schema_version",
            "sample_rate",
            "model_type",
            "output_mode",
            "action_map",
        }
    )
    SERVER_BINDINGS_TOP_LEVEL_KEYS = frozenset(
        {"schema_version", "output_denormalized", "inputs", "outputs"}
    )
    SERVER_INPUT_ENTRY_KEYS = frozenset(
        {
            "binding_order",
            "name",
            "description",
            "normalization_type",
            "normalization_source",
            "custom_minimum",
            "custom_maximum",
            "custom_mean",
            "custom_std",
            "failure_range_mode",
            "custom_failure_minimum",
            "custom_failure_maximum",
        }
    )
    SERVER_OUTPUT_ENTRY_KEYS = frozenset(
        SERVER_INPUT_ENTRY_KEYS
        | {
            "range_min",
            "range_max",
            "clamp_output",
        }
    )

    def _embed_everything(self):
        """Emit a payload that exercises every field on every dataclass."""
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(
                name="temp",
                description="Tank temp",
                normalization_type=NormalizationType.Z_SCORE,
                normalization_source=NormalizationSource.CUSTOM,
                custom_mean=25.0,
                custom_std=5.0,
                failure_range_mode=FailureRangeMode.CUSTOM,
                custom_failure_minimum=-10.0,
                custom_failure_maximum=110.0,
            ),
        ]
        outputs = [
            OutputBinding(
                name="valve",
                description="Valve %",
                range_min=0.0,
                range_max=100.0,
                normalization_type=NormalizationType.SYMMETRIC,
                normalization_source=NormalizationSource.CUSTOM,
                custom_minimum=0.0,
                custom_maximum=100.0,
                clamp_output=True,
                failure_range_mode=FailureRangeMode.CUSTOM,
                custom_failure_minimum=-5.0,
                custom_failure_maximum=105.0,
            ),
        ]
        training = TrainingMeta(
            scenario_name="tank",
            algorithm="PPO",
            sample_rate=1.0,
            model_type=ModelType.ABSOLUTE,
            output_mode=OutputMode.DISCRETE,
            action_map=[{"value": 0, "label": "off"}],
        )
        embed_koios_metadata(
            model,
            inputs=inputs,
            outputs=outputs,
            training=training,
            output_denormalized=True,
        )
        return {p.key: json.loads(p.value) for p in model.metadata_props}

    def test_training_payload_is_subset_of_server_keys(self):
        meta = self._embed_everything()["koios.training"]
        # Strip client-informational fields the server legitimately ignores.
        payload_keys = set(meta) - {
            "scenario_name",
            "algorithm",
            "obs_depth",
            "exported_at",
        }
        unknown = payload_keys - self.SERVER_TRAINING_KEYS
        assert not unknown, (
            f"koios.training contains keys the webapp does not read: {unknown}. "
            "Either remove them from metadata.py or teach the server about them."
        )

    def test_bindings_top_level_has_no_unknown_keys(self):
        b = self._embed_everything()["koios.bindings"]
        top_level = set(b)
        unknown = top_level - self.SERVER_BINDINGS_TOP_LEVEL_KEYS
        assert not unknown, (
            f"koios.bindings top-level contains keys the webapp does not read: {unknown}"
        )

    def test_input_entry_has_no_unknown_keys(self):
        b = self._embed_everything()["koios.bindings"]
        entry_keys = set(b["inputs"][0])
        unknown = entry_keys - self.SERVER_INPUT_ENTRY_KEYS
        assert not unknown, (
            f"koios.bindings.inputs[] entries contain keys the webapp does not read: {unknown}"
        )

    def test_output_entry_has_no_unknown_keys(self):
        b = self._embed_everything()["koios.bindings"]
        entry_keys = set(b["outputs"][0])
        unknown = entry_keys - self.SERVER_OUTPUT_ENTRY_KEYS
        assert not unknown, (
            f"koios.bindings.outputs[] entries contain keys the webapp does not read: {unknown}"
        )

    def test_failure_range_mode_serializes_explicitly(self):
        """failure_range_mode is now a first-class enum field, not a flip-bit."""
        b = self._embed_everything()["koios.bindings"]
        assert b["inputs"][0]["failure_range_mode"] == "CUSTOM"
        assert b["outputs"][0]["failure_range_mode"] == "CUSTOM"


class TestEnumsInterchangeable:
    """Passing enum members must produce identical payloads to raw strings.

    The public dataclasses accept either a ``StrEnum`` member or a raw
    string; both paths must serialize through ``json.dumps`` to the same
    wire bytes.  This protects users who adopt the enums from subtly
    different output.
    """

    def _embed_with_strings(self):
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[
                InputBinding(
                    name="temp",
                    normalization_type="z_score",
                    normalization_source="custom",
                    custom_mean=1.0,
                    custom_std=2.0,
                ),
            ],
            outputs=[
                OutputBinding(
                    name="valve",
                    normalization_type="symmetric",
                    normalization_source="custom",
                    range_min=0.0,
                    range_max=100.0,
                    custom_minimum=0.0,
                    custom_maximum=100.0,
                ),
            ],
            training=TrainingMeta(
                algorithm="PPO",
                model_type="ABSOLUTE",
                output_mode="CONTINUOUS",
            ),
        )
        return {p.key: p.value for p in model.metadata_props}

    def _embed_with_enums(self):
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[
                InputBinding(
                    name="temp",
                    normalization_type=NormalizationType.Z_SCORE,
                    normalization_source=NormalizationSource.CUSTOM,
                    custom_mean=1.0,
                    custom_std=2.0,
                ),
            ],
            outputs=[
                OutputBinding(
                    name="valve",
                    normalization_type=NormalizationType.SYMMETRIC,
                    normalization_source=NormalizationSource.CUSTOM,
                    range_min=0.0,
                    range_max=100.0,
                    custom_minimum=0.0,
                    custom_maximum=100.0,
                ),
            ],
            training=TrainingMeta(
                algorithm=Algorithm.PPO,
                model_type=ModelType.ABSOLUTE,
                output_mode=OutputMode.CONTINUOUS,
            ),
        )
        return {p.key: p.value for p in model.metadata_props}

    def test_bindings_payload_identical(self):
        s = self._embed_with_strings()
        e = self._embed_with_enums()
        assert s["koios.bindings"] == e["koios.bindings"]

    def test_training_payload_identical_modulo_timestamp(self):
        s = json.loads(self._embed_with_strings()["koios.training"])
        e = json.loads(self._embed_with_enums()["koios.training"])
        s.pop("exported_at", None)
        e.pop("exported_at", None)
        assert s == e

    def test_lowercase_none_string_omits_normalization_key_like_enum(self):
        """``InputBinding(normalization_type="none")`` must produce the same
        wire shape as ``InputBinding(normalization_type=NormalizationType.NONE)``
        — neither emits a ``normalization_type`` key.  Regression test for a
        case-sensitive guard that broke this for lowercase legacy strings."""
        m_str = _make_dummy_onnx_model()
        embed_koios_metadata(
            m_str,
            inputs=[InputBinding(name="x", normalization_type="none")],
            outputs=[OutputBinding(name="y")],
        )
        m_enum = _make_dummy_onnx_model()
        embed_koios_metadata(
            m_enum,
            inputs=[InputBinding(name="x", normalization_type=NormalizationType.NONE)],
            outputs=[OutputBinding(name="y")],
        )
        bindings_str = json.loads(
            next(p.value for p in m_str.metadata_props if p.key == "koios.bindings")
        )
        bindings_enum = json.loads(
            next(p.value for p in m_enum.metadata_props if p.key == "koios.bindings")
        )
        assert "normalization_type" not in bindings_str["inputs"][0]
        assert bindings_str == bindings_enum

    def test_enum_values_match_server_choice_names(self):
        """Library StrEnum values must match the server's IntegerChoices member
        names exactly.  The server's ``_choice_from_name`` does ``str(v).upper()``
        before lookup, but post-1.1 we always emit canonical uppercase wire
        values, so this is now exact-match (case sensitivity is just a
        compatibility cushion for files written by 1.0.x)."""
        assert {m.value for m in NormalizationType} == {
            "NONE",
            "MIN_MAX",
            "SYMMETRIC",
            "Z_SCORE",
        }
        assert {m.value for m in NormalizationSource} == {"TAG_RANGE", "CUSTOM"}


class TestParseKoiosMetadata:
    """Tests for parse_koios_metadata — the mirror image of embed_koios_metadata."""

    def test_no_metadata(self):
        """Model with no koios.* props returns empty ParsedKoiosMetadata."""
        model = _make_dummy_onnx_model()
        result = parse_koios_metadata(model)
        assert result.has_metadata is False
        assert result.training is None
        assert result.inputs == []
        assert result.outputs == []
        assert result.output_denormalized is False

    def test_round_trip_full(self):
        """Embed every field, parse it back — every field round-trips."""
        model = _make_dummy_onnx_model()
        inputs = [
            InputBinding(
                name="temp",
                description="Tank temp",
                normalization_type=NormalizationType.Z_SCORE,
                normalization_source=NormalizationSource.CUSTOM,
                custom_mean=25.0,
                custom_std=5.0,
                failure_range_mode=FailureRangeMode.CUSTOM,
                custom_failure_minimum=-10.0,
                custom_failure_maximum=110.0,
            ),
        ]
        outputs = [
            OutputBinding(
                name="valve",
                description="Valve %",
                range_min=0.0,
                range_max=100.0,
                normalization_type=NormalizationType.SYMMETRIC,
                normalization_source=NormalizationSource.CUSTOM,
                custom_minimum=0.0,
                custom_maximum=100.0,
                clamp_output=True,
                failure_range_mode=FailureRangeMode.CUSTOM,
                custom_failure_minimum=-5.0,
                custom_failure_maximum=105.0,
            ),
        ]
        training = TrainingMeta(
            scenario_name="tank",
            algorithm=Algorithm.PPO,
            obs_depth=5,
            sample_rate=2.5,
            model_type=ModelType.ABSOLUTE,
            output_mode=OutputMode.DISCRETE,
            action_map=[{"value": 0, "label": "off"}],
        )
        embed_koios_metadata(
            model,
            inputs=inputs,
            outputs=outputs,
            training=training,
            output_denormalized=True,
        )

        result = parse_koios_metadata(model)
        assert result.has_metadata is True
        assert result.output_denormalized is True

        assert result.training is not None
        assert result.training.scenario_name == "tank"
        assert result.training.algorithm == Algorithm.PPO
        assert result.training.obs_depth == 5
        assert result.training.sample_rate == 2.5
        assert result.training.model_type == ModelType.ABSOLUTE
        assert result.training.output_mode == OutputMode.DISCRETE
        assert result.training.action_map == [ActionMapEntry(value=0.0, label="off")]

        assert len(result.inputs) == 1
        ri = result.inputs[0]
        assert ri.name == "temp"
        assert ri.description == "Tank temp"
        assert ri.normalization_type == NormalizationType.Z_SCORE
        assert ri.normalization_source == NormalizationSource.CUSTOM
        assert ri.custom_mean == 25.0
        assert ri.custom_std == 5.0
        assert ri.failure_range_mode == FailureRangeMode.CUSTOM
        assert ri.custom_failure_minimum == -10.0
        assert ri.custom_failure_maximum == 110.0

        assert len(result.outputs) == 1
        ro = result.outputs[0]
        assert ro.name == "valve"
        assert ro.description == "Valve %"
        assert ro.range_min == 0.0
        assert ro.range_max == 100.0
        assert ro.normalization_type == NormalizationType.SYMMETRIC
        assert ro.normalization_source == NormalizationSource.CUSTOM
        assert ro.custom_minimum == 0.0
        assert ro.custom_maximum == 100.0
        assert ro.clamp_output is True
        assert ro.failure_range_mode == FailureRangeMode.CUSTOM
        assert ro.custom_failure_minimum == -5.0
        assert ro.custom_failure_maximum == 105.0

    def test_minimal(self):
        """Embed only required fields, parse returns sensible defaults."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
        )
        result = parse_koios_metadata(model)
        assert result.has_metadata is True
        assert result.training is not None
        assert result.training.scenario_name == ""
        assert result.training.sample_rate == 1.0
        assert result.training.model_type == ModelType.ABSOLUTE
        assert len(result.inputs) == 1
        assert result.inputs[0].name == "x"
        assert result.inputs[0].normalization_type == NormalizationType.NONE
        assert result.inputs[0].failure_range_mode is None

    def test_only_training_present(self):
        """A model with only koios.training, no koios.bindings."""
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(
                key="koios.training",
                value=json.dumps(
                    {
                        "schema_version": 1,
                        "sample_rate": 5.0,
                        "model_type": "ABSOLUTE",
                    }
                ),
            )
        )
        result = parse_koios_metadata(model)
        assert result.has_metadata is True
        assert result.training is not None
        assert result.training.sample_rate == 5.0
        assert result.training.model_type == ModelType.ABSOLUTE
        assert result.inputs == []
        assert result.outputs == []

    def test_empty_string_normalization_type_resolves_to_none(self):
        """Wire ``"normalization_type": ""`` (or null/missing) defaults to NONE.
        Locks in the falsy-value semantics of the parser's ``or`` fallback so
        a future refactor of ``_coerce_enum`` doesn't silently change it."""
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(
                key="koios.bindings",
                value=json.dumps(
                    {
                        "schema_version": 1,
                        "inputs": [{"binding_order": 1, "name": "x", "normalization_type": ""}],
                        "outputs": [],
                    }
                ),
            )
        )
        result = parse_koios_metadata(model)
        assert result.inputs[0].normalization_type is NormalizationType.NONE

    def test_only_bindings_present(self):
        """A model with only koios.bindings, no koios.training."""
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(
                key="koios.bindings",
                value=json.dumps(
                    {
                        "schema_version": 1,
                        "output_denormalized": False,
                        "inputs": [{"binding_order": 1, "name": "x"}],
                        "outputs": [{"binding_order": 1, "name": "y"}],
                    }
                ),
            )
        )
        result = parse_koios_metadata(model)
        assert result.has_metadata is True
        assert result.training is None
        assert len(result.inputs) == 1
        assert result.inputs[0].name == "x"
        assert len(result.outputs) == 1
        assert result.outputs[0].name == "y"

    def test_unknown_schema_version_training(self):
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(
                key="koios.training",
                value=json.dumps({"schema_version": 99, "sample_rate": 1.0}),
            )
        )
        with pytest.raises(UnsupportedSchemaVersionError):
            parse_koios_metadata(model)

    def test_unknown_schema_version_bindings(self):
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(
                key="koios.bindings",
                value=json.dumps({"schema_version": 2, "inputs": [], "outputs": []}),
            )
        )
        with pytest.raises(UnsupportedSchemaVersionError):
            parse_koios_metadata(model)

    def test_invalid_json_raises(self):
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(key="koios.training", value="not json {")
        )
        with pytest.raises(KoiosMetadataDecodeError):
            parse_koios_metadata(model)

    def test_non_object_json_raises(self):
        """A koios.* prop containing a JSON array/scalar (not an object) raises."""
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(key="koios.training", value=json.dumps([1, 2, 3]))
        )
        with pytest.raises(KoiosMetadataDecodeError):
            parse_koios_metadata(model)

    def test_validator_violation_in_training_wire_raises_decode_error(self):
        """Wire data that violates a TrainingMeta validator (e.g. zero
        sample_rate) surfaces as KoiosMetadataDecodeError, not a bare
        ValueError — keeps the documented parser error contract whole."""
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(
                key="koios.training",
                value=json.dumps({"schema_version": 1, "sample_rate": 0}),
            )
        )
        with pytest.raises(KoiosMetadataDecodeError, match="sample_rate"):
            parse_koios_metadata(model)

    def test_validator_violation_in_bindings_wire_raises_decode_error(self):
        """Same for bindings — empty name on an input binding."""
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(
                key="koios.bindings",
                value=json.dumps(
                    {
                        "schema_version": 1,
                        "inputs": [{"binding_order": 1, "name": ""}],
                        "outputs": [],
                    }
                ),
            )
        )
        with pytest.raises(KoiosMetadataDecodeError, match="non-empty"):
            parse_koios_metadata(model)

    def test_legacy_positional_alias_passes_through(self):
        """The library doesn't translate POSITIONAL/VELOCITY to ABSOLUTE/RELATIVE
        on parse — that's server policy.  But it does normalize the wire casing
        (see ``test_embed_normalizes_legacy_alias_casing``)."""
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(
                key="koios.training",
                value=json.dumps({"schema_version": 1, "model_type": "POSITIONAL"}),
            )
        )
        result = parse_koios_metadata(model)
        # POSITIONAL doesn't match any ModelType member; passes through as raw string
        # so the server can apply its own alias policy.
        assert result.training is not None
        assert result.training.model_type == "POSITIONAL"

    def test_failure_range_mode_round_trips(self):
        """``failure_range_mode`` is a first-class enum field on both sides."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[
                InputBinding(
                    name="x",
                    failure_range_mode=FailureRangeMode.CUSTOM,
                    custom_failure_minimum=0.0,
                    custom_failure_maximum=100.0,
                )
            ],
            outputs=[OutputBinding(name="y")],
        )
        result = parse_koios_metadata(model)
        assert result.inputs[0].failure_range_mode == FailureRangeMode.CUSTOM
        assert result.inputs[0].custom_failure_minimum == 0.0
        assert result.inputs[0].custom_failure_maximum == 100.0

    def test_ignores_non_koios_props(self):
        """Non-koios.* metadata props are left alone."""
        model = _make_dummy_onnx_model()
        model.metadata_props.append(
            onnx.StringStringEntryProto(key="producer.version", value="1.2.3")
        )
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
        )
        result = parse_koios_metadata(model)
        assert result.has_metadata is True
        assert result.training is not None

    def test_unknown_koios_prop_does_not_raise(self):
        """A future library version may add new ``koios.*`` props with
        non-object JSON values (string, list, scalar).  Older parsers must
        skip them silently rather than treating ``koios.*`` as an
        all-or-nothing object-only namespace."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
        )
        # Simulate a 1.2 producer adding a new prop the 1.1 parser doesn't know.
        model.metadata_props.append(
            onnx.StringStringEntryProto(key="koios.runtime", value=json.dumps("v2-runtime-tag"))
        )
        model.metadata_props.append(
            onnx.StringStringEntryProto(key="koios.experimental_list", value=json.dumps([1, 2, 3]))
        )
        result = parse_koios_metadata(model)  # must not raise
        assert result.has_metadata is True
        assert result.training is not None


class TestParseKoiosMetadataFromDict:
    """parse_koios_metadata_from_dict — same semantics, takes a dict directly."""

    def test_round_trip_via_dict(self):
        """Embed → extract to dict → parse_koios_metadata_from_dict — all fields preserved."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[
                InputBinding(
                    name="temp",
                    normalization_type=NormalizationType.MIN_MAX,
                    normalization_source=NormalizationSource.CUSTOM,
                    custom_minimum=0.0,
                    custom_maximum=100.0,
                )
            ],
            outputs=[
                OutputBinding(name="valve", range_min=0.0, range_max=100.0),
            ],
            training=TrainingMeta(sample_rate=2.5),
        )
        as_dict = {p.key: json.loads(p.value) for p in model.metadata_props}

        result = parse_koios_metadata_from_dict(as_dict)
        assert result.has_metadata is True
        assert result.training is not None
        assert result.training.sample_rate == 2.5
        assert result.inputs[0].name == "temp"
        assert result.inputs[0].normalization_type == NormalizationType.MIN_MAX
        assert result.inputs[0].custom_minimum == 0.0
        assert result.outputs[0].range_min == 0.0

    def test_empty_dict(self):
        result = parse_koios_metadata_from_dict({})
        assert result.has_metadata is False
        assert result.training is None
        assert result.inputs == []
        assert result.outputs == []

    def test_unrelated_keys_ignored(self):
        """Keys other than koios.training/koios.bindings are ignored."""
        result = parse_koios_metadata_from_dict(
            {
                "koios.training": {"schema_version": 1, "sample_rate": 1.0},
                "producer.info": {"name": "torch", "version": "2.0"},
            }
        )
        assert result.has_metadata is True
        assert result.training is not None


class TestEnumFieldResolution:
    """Enum-typed fields resolve to their canonical enum member at
    construction time, regardless of input casing.  This makes downstream
    code (validators, embed guards, user-facing access) able to use
    direct ``==`` comparisons against the enum members."""

    def test_input_binding_lowercase_string_resolves_to_enum(self):
        b = InputBinding(name="x", normalization_type="z_score")
        assert b.normalization_type is NormalizationType.Z_SCORE

    def test_input_binding_mixedcase_string_resolves_to_enum(self):
        b = InputBinding(name="x", normalization_type="Z_Score")
        assert b.normalization_type is NormalizationType.Z_SCORE

    def test_input_binding_enum_passes_through(self):
        b = InputBinding(name="x", normalization_type=NormalizationType.Z_SCORE)
        assert b.normalization_type is NormalizationType.Z_SCORE

    def test_normalization_source_string_resolves(self):
        b = InputBinding(
            name="x",
            normalization_type=NormalizationType.MIN_MAX,
            normalization_source="custom",
            custom_minimum=0.0,
            custom_maximum=1.0,
        )
        assert b.normalization_source is NormalizationSource.CUSTOM

    def test_failure_range_mode_string_resolves(self):
        b = InputBinding(
            name="x",
            failure_range_mode="disabled",
        )
        assert b.failure_range_mode is FailureRangeMode.DISABLED

    def test_output_binding_lowercase_string_resolves(self):
        b = OutputBinding(name="y", normalization_type="symmetric")
        assert b.normalization_type is NormalizationType.SYMMETRIC

    def test_training_meta_strings_resolve(self):
        t = TrainingMeta(
            algorithm="ppo",
            model_type="absolute",
            output_mode="continuous",
        )
        assert t.algorithm is Algorithm.PPO
        assert t.model_type is ModelType.ABSOLUTE
        assert t.output_mode is OutputMode.CONTINUOUS

    def test_unknown_string_passes_through(self):
        """Legacy aliases / unknown values stay as raw strings — the library
        can't normalize what it doesn't recognize.  Server policy decides
        what to do with them (e.g. POSITIONAL → ABSOLUTE alias map)."""
        t = TrainingMeta(model_type="POSITIONAL")
        assert t.model_type == "POSITIONAL"
        assert not isinstance(t.model_type, ModelType)

    def test_algorithm_freeform_string_passes_through(self):
        """Custom algorithm names like Ronin's GRUForecastModel stay raw."""
        t = TrainingMeta(algorithm="GRUForecastModel")
        assert t.algorithm == "GRUForecastModel"

    def test_none_inputs_default_correctly(self):
        """Optional enum fields stay None; required ones get the dataclass default."""
        b = InputBinding(name="x")
        assert b.normalization_type is NormalizationType.NONE
        assert b.normalization_source is None
        assert b.failure_range_mode is None


class TestInputBindingValidation:
    """Construction-time consistency checks for InputBinding."""

    def test_blank_name_rejected(self):
        with pytest.raises(ValueError, match="non-empty"):
            InputBinding(name="")
        with pytest.raises(ValueError, match="non-empty"):
            InputBinding(name="   ")

    def test_nan_in_floats_rejected(self):
        with pytest.raises(ValueError, match="not finite"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.Z_SCORE,
                normalization_source=NormalizationSource.CUSTOM,
                custom_mean=float("nan"),
                custom_std=1.0,
            )

    def test_inf_in_floats_rejected(self):
        with pytest.raises(ValueError, match="not finite"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.MIN_MAX,
                normalization_source=NormalizationSource.CUSTOM,
                custom_minimum=0.0,
                custom_maximum=float("inf"),
            )

    def test_inverted_custom_range_rejected(self):
        with pytest.raises(ValueError, match="custom_minimum.*<= custom_maximum"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.MIN_MAX,
                normalization_source=NormalizationSource.CUSTOM,
                custom_minimum=10.0,
                custom_maximum=0.0,
            )

    def test_inverted_failure_range_rejected(self):
        with pytest.raises(ValueError, match="custom_failure_minimum"):
            InputBinding(
                name="x",
                failure_range_mode=FailureRangeMode.CUSTOM,
                custom_failure_minimum=10.0,
                custom_failure_maximum=0.0,
            )

    def test_zero_std_rejected(self):
        with pytest.raises(ValueError, match="custom_std.*> 0"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.Z_SCORE,
                normalization_source=NormalizationSource.CUSTOM,
                custom_mean=0.0,
                custom_std=0.0,
            )

    def test_zscore_with_min_max_rejected(self):
        with pytest.raises(ValueError, match="Z_SCORE uses custom_mean/custom_std"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.Z_SCORE,
                normalization_source=NormalizationSource.CUSTOM,
                custom_mean=0.0,
                custom_std=1.0,
                custom_minimum=0.0,
            )

    def test_min_max_with_mean_std_rejected(self):
        with pytest.raises(ValueError, match="custom_minimum/custom_maximum, not custom_mean"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.MIN_MAX,
                normalization_source=NormalizationSource.CUSTOM,
                custom_minimum=0.0,
                custom_maximum=1.0,
                custom_mean=0.5,
            )

    def test_tag_range_with_custom_values_rejected(self):
        with pytest.raises(ValueError, match="TAG_RANGE source reads bounds"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.MIN_MAX,
                normalization_source=NormalizationSource.TAG_RANGE,
                custom_minimum=0.0,
                custom_maximum=1.0,
            )

    def test_custom_source_requires_min_max(self):
        with pytest.raises(ValueError, match="MIN_MAX.*requires custom_minimum and custom_maximum"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.MIN_MAX,
                normalization_source=NormalizationSource.CUSTOM,
            )

    def test_custom_source_zscore_requires_mean_std(self):
        with pytest.raises(ValueError, match="Z_SCORE.*requires custom_mean and custom_std"):
            InputBinding(
                name="x",
                normalization_type=NormalizationType.Z_SCORE,
                normalization_source=NormalizationSource.CUSTOM,
            )

    def test_custom_failure_mode_requires_bounds(self):
        with pytest.raises(ValueError, match="failure_range_mode=CUSTOM requires"):
            InputBinding(
                name="x",
                failure_range_mode=FailureRangeMode.CUSTOM,
                custom_failure_minimum=0.0,
                # missing custom_failure_maximum
            )

    def test_minimal_binding_passes(self):
        # No normalization, no failure mode — should construct cleanly.
        b = InputBinding(name="temp")
        assert b.normalization_type == NormalizationType.NONE


class TestOutputBindingValidation:
    """Construction-time consistency checks for OutputBinding."""

    def test_blank_name_rejected(self):
        with pytest.raises(ValueError, match="non-empty"):
            OutputBinding(name="")

    def test_inverted_range_rejected(self):
        with pytest.raises(ValueError, match="range_min.*<= range_max"):
            OutputBinding(name="y", range_min=10.0, range_max=0.0)

    def test_zscore_on_output_rejected(self):
        with pytest.raises(ValueError, match="Z_SCORE is not supported on outputs"):
            OutputBinding(
                name="y",
                normalization_type=NormalizationType.Z_SCORE,
                normalization_source=NormalizationSource.CUSTOM,
            )

    def test_tag_range_with_range_fields_rejected(self):
        with pytest.raises(ValueError, match="TAG_RANGE source reads bounds"):
            OutputBinding(
                name="y",
                normalization_type=NormalizationType.MIN_MAX,
                normalization_source=NormalizationSource.TAG_RANGE,
                range_min=0.0,
                range_max=100.0,
            )

    def test_tag_range_with_custom_min_max_rejected(self):
        with pytest.raises(ValueError, match="TAG_RANGE source rejects custom_minimum"):
            OutputBinding(
                name="y",
                normalization_type=NormalizationType.MIN_MAX,
                normalization_source=NormalizationSource.TAG_RANGE,
                custom_minimum=0.0,
                custom_maximum=100.0,
            )

    def test_custom_source_requires_min_max(self):
        with pytest.raises(ValueError, match="requires custom_minimum and custom_maximum"):
            OutputBinding(
                name="y",
                normalization_type=NormalizationType.SYMMETRIC,
                normalization_source=NormalizationSource.CUSTOM,
            )

    def test_minimal_output_passes(self):
        b = OutputBinding(name="valve")
        assert b.normalization_type == NormalizationType.NONE


class TestTrainingMetaValidation:
    """Construction-time consistency checks for TrainingMeta."""

    def test_zero_sample_rate_rejected(self):
        with pytest.raises(ValueError, match="sample_rate.*> 0"):
            TrainingMeta(sample_rate=0)

    def test_negative_sample_rate_rejected(self):
        with pytest.raises(ValueError, match="sample_rate.*> 0"):
            TrainingMeta(sample_rate=-1.0)

    def test_nan_sample_rate_rejected(self):
        with pytest.raises(ValueError, match="not finite"):
            TrainingMeta(sample_rate=float("nan"))

    def test_zero_obs_depth_rejected(self):
        with pytest.raises(ValueError, match="obs_depth.*>= 1"):
            TrainingMeta(obs_depth=0)

    def test_discrete_without_action_map_rejected(self):
        with pytest.raises(ValueError, match="DISCRETE requires.*action_map"):
            TrainingMeta(output_mode=OutputMode.DISCRETE)

    def test_continuous_with_action_map_rejected(self):
        with pytest.raises(ValueError, match="CONTINUOUS does not use action_map"):
            TrainingMeta(
                output_mode=OutputMode.CONTINUOUS,
                action_map=[{"value": 0, "label": "off"}],
            )

    def test_minimal_training_passes(self):
        t = TrainingMeta()
        assert t.sample_rate == 1.0
        assert t.model_type == ModelType.ABSOLUTE


class TestScanRate:
    """``scan_rate`` is independent of ``sample_rate`` so RL controllers can
    execute faster than the training data was sampled at."""

    def test_default_is_none(self):
        """When omitted, the server defaults scan_rate to sample_rate."""
        t = TrainingMeta(sample_rate=1.0)
        assert t.scan_rate is None

    def test_explicit_value_kept(self):
        t = TrainingMeta(sample_rate=1.0, scan_rate=0.1)
        assert t.scan_rate == 0.1

    @pytest.mark.parametrize(
        ("bad_value", "match"),
        [
            (0.0, "must be > 0"),
            (-1.0, "must be > 0"),
            (float("nan"), "not finite"),
            (float("inf"), "not finite"),
        ],
        ids=["zero", "negative", "nan", "inf"],
    )
    def test_invalid_value_rejected(self, bad_value, match):
        with pytest.raises(ValueError, match=f"scan_rate.*{match}"):
            TrainingMeta(sample_rate=1.0, scan_rate=bad_value)

    def test_round_trip_through_wire(self):
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
            training=TrainingMeta(sample_rate=1.0, scan_rate=0.1),
        )
        meta = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert meta["koios.training"]["scan_rate"] == 0.1

        parsed = parse_koios_metadata(model)
        assert parsed.training is not None
        assert parsed.training.scan_rate == 0.1

    def test_omitted_when_none(self):
        """Producers writing the default shouldn't pollute the wire."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[InputBinding(name="x")],
            outputs=[OutputBinding(name="y")],
            training=TrainingMeta(sample_rate=1.0),  # no scan_rate
        )
        meta = {p.key: json.loads(p.value) for p in model.metadata_props}
        assert "scan_rate" not in meta["koios.training"]


class TestActionMapEntryCoercion:
    """``TrainingMeta.action_map`` strict-at-construction contract.

    Catches producer-side schema drift (missing keys, wrong types) before
    metadata is embedded — the webapp's normalize step and the UI's
    action-map rendering both key strictly on ``value`` and ``label``.
    """

    def test_dict_entry_coerced_to_dataclass(self):
        t = TrainingMeta(
            output_mode=OutputMode.DISCRETE,
            action_map=[{"value": 0, "label": "off"}],
        )
        assert t.action_map == [ActionMapEntry(value=0.0, label="off")]

    def test_dataclass_entry_passes_through(self):
        entry = ActionMapEntry(value=1.5, label="on")
        t = TrainingMeta(output_mode=OutputMode.DISCRETE, action_map=[entry])
        assert t.action_map == [entry]

    def test_int_value_coerced_to_float(self):
        t = TrainingMeta(
            output_mode=OutputMode.DISCRETE,
            action_map=[{"value": 2, "label": "two"}],
        )
        assert t.action_map[0].value == 2.0
        assert isinstance(t.action_map[0].value, float)

    def test_extra_keys_dropped(self):
        """Producers may emit additional fields; coercion keeps only the spec keys."""
        t = TrainingMeta(
            output_mode=OutputMode.DISCRETE,
            action_map=[{"value": 0, "label": "off", "delta": -1, "internal_id": 7}],
        )
        assert t.action_map == [ActionMapEntry(value=0.0, label="off")]

    @pytest.mark.parametrize(
        ("bad_entry", "match"),
        [
            ({"label": "off"}, "missing required 'value' key"),
            ({"value": 0}, "missing required 'label' key"),
            ({"value": "off", "label": "off"}, "value must be a number"),
            # ``isinstance(True, int)`` is True; coercion explicitly excludes bools.
            ({"value": True, "label": "on"}, "value must be a number"),
            ({"value": 0, "label": 42}, "label must be a string"),
            ("off", "must be ActionMapEntry or dict"),
        ],
        ids=[
            "missing_value",
            "missing_label",
            "non_numeric_value",
            "bool_value",
            "non_string_label",
            "non_dict_entry",
        ],
    )
    def test_invalid_entry_rejected(self, bad_entry, match):
        with pytest.raises(ValueError, match=match):
            TrainingMeta(output_mode=OutputMode.DISCRETE, action_map=[bad_entry])

    def test_round_trip_through_wire(self):
        """ActionMapEntry survives embed -> parse intact."""
        model = _make_dummy_onnx_model()
        embed_koios_metadata(
            model,
            inputs=[],
            outputs=[],
            training=TrainingMeta(
                output_mode=OutputMode.DISCRETE,
                action_map=[
                    ActionMapEntry(value=-1.0, label="decrease"),
                    ActionMapEntry(value=0.0, label="hold"),
                    ActionMapEntry(value=1.0, label="increase"),
                ],
            ),
        )
        parsed = parse_koios_metadata(model)
        assert parsed.training.action_map == [
            ActionMapEntry(value=-1.0, label="decrease"),
            ActionMapEntry(value=0.0, label="hold"),
            ActionMapEntry(value=1.0, label="increase"),
        ]
