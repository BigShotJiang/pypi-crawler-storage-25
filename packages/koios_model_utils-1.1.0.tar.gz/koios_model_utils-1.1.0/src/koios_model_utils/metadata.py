"""Koios ONNX metadata embedding and parsing."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, TypeVar, cast

import onnx

from koios_model_utils.enums import (
    Algorithm,
    FailureRangeMode,
    ModelType,
    NormalizationSource,
    NormalizationType,
    OutputMode,
)
from koios_model_utils.validation import (
    validate_input_binding,
    validate_output_binding,
    validate_training_meta,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Dataclasses
#
# Enum-typed fields accept either an enum member or any-case string at
# construction time.  After ``__post_init__`` runs, recognized values are
# stored as the canonical enum member; unrecognized values (legacy aliases
# like ``POSITIONAL``, free-form algorithm names) pass through as raw
# strings for the server to apply policy.
#
# ``__post_init__`` runs once.  Field reassignment after construction
# (``b.normalization_type = "z_score"``) skips re-resolution and skips
# re-validation — the field will literally be the string ``"z_score"``,
# so ``b.normalization_type == NormalizationType.Z_SCORE`` returns False
# and the wire serialization paths see a raw string.  Use
# ``dataclasses.replace(b, ...)`` to construct a new instance with the
# changed fields, which re-runs ``__post_init__``.
# ---------------------------------------------------------------------------


@dataclass
class InputBinding:
    """One input (observation) binding for the Koios predict engine."""

    name: str
    description: str = ""
    normalization_type: NormalizationType | str = NormalizationType.NONE
    normalization_source: NormalizationSource | str | None = None
    custom_mean: float | None = None
    custom_std: float | None = None
    custom_minimum: float | None = None
    custom_maximum: float | None = None
    failure_range_mode: FailureRangeMode | str | None = None
    custom_failure_minimum: float | None = None
    custom_failure_maximum: float | None = None

    def __post_init__(self) -> None:
        self.normalization_type = (
            _coerce_enum(self.normalization_type, NormalizationType) or NormalizationType.NONE
        )
        self.normalization_source = _coerce_enum(self.normalization_source, NormalizationSource)
        self.failure_range_mode = _coerce_enum(self.failure_range_mode, FailureRangeMode)
        validate_input_binding(self)


@dataclass
class OutputBinding:
    """One output (action) binding for the Koios predict engine."""

    name: str
    description: str = ""
    range_min: float | None = None
    range_max: float | None = None
    normalization_type: NormalizationType | str = NormalizationType.NONE
    normalization_source: NormalizationSource | str | None = None
    custom_minimum: float | None = None
    custom_maximum: float | None = None
    clamp_output: bool = False
    failure_range_mode: FailureRangeMode | str | None = None
    custom_failure_minimum: float | None = None
    custom_failure_maximum: float | None = None

    def __post_init__(self) -> None:
        self.normalization_type = (
            _coerce_enum(self.normalization_type, NormalizationType) or NormalizationType.NONE
        )
        self.normalization_source = _coerce_enum(self.normalization_source, NormalizationSource)
        self.failure_range_mode = _coerce_enum(self.failure_range_mode, FailureRangeMode)
        validate_output_binding(self)


@dataclass(frozen=True, slots=True)
class ActionMapEntry:
    """One action in a DISCRETE-mode model's action map.

    ``value`` is the engineering value the action maps to (written to the
    bound tag on selection); ``label`` is the human-readable name shown
    in the UI.  The webapp's ``aiop_model_file.action_map`` JSON column
    and the UI's :class:`ActionMapEntry` TypeScript interface both key
    on these two fields.
    """

    value: float
    label: str


@dataclass
class TrainingMeta:
    """Model-level training metadata for the Koios predict engine."""

    scenario_name: str = ""
    algorithm: Algorithm | str = ""
    obs_depth: int = 1
    sample_rate: float = 1.0
    # When omitted, server inherits scan_rate from sample_rate.  See CONTRACT.md.
    scan_rate: float | None = None
    model_type: ModelType | str = ModelType.ABSOLUTE
    output_mode: OutputMode | str | None = None
    # Accepts either ActionMapEntry instances or raw dicts (``{"value": ...,
    # "label": ...}``); dicts are coerced to ActionMapEntry in
    # ``__post_init__``.  Extra keys on dicts are dropped.
    action_map: list[ActionMapEntry] | list[dict[str, object]] | None = None

    def __post_init__(self) -> None:
        self.algorithm = _coerce_enum(self.algorithm, Algorithm) or ""
        self.model_type = _coerce_enum(self.model_type, ModelType) or ModelType.ABSOLUTE
        self.output_mode = _coerce_enum(self.output_mode, OutputMode)
        self.action_map = _coerce_action_map(self.action_map)
        validate_training_meta(self)


def _coerce_action_map(
    raw: list[ActionMapEntry] | list[dict[str, object]] | None,
) -> list[ActionMapEntry] | None:
    """Normalize action_map entries to ``ActionMapEntry`` instances.

    Accepts dataclass instances or raw dicts; raises ``ValueError`` on
    missing or mis-typed keys so contract drift surfaces at construction
    instead of as blank rows in the UI.
    """
    if raw is None:
        return None
    out: list[ActionMapEntry] = []
    for i, entry in enumerate(raw):
        if isinstance(entry, ActionMapEntry):
            out.append(entry)
            continue
        if not isinstance(entry, dict):
            raise ValueError(
                f"TrainingMeta.action_map[{i}] must be ActionMapEntry or dict, "
                f"got {type(entry).__name__}"
            )
        if "value" not in entry:
            raise ValueError(
                f"TrainingMeta.action_map[{i}] is missing required 'value' key; "
                "each entry needs 'value' (number) and 'label' (str)"
            )
        if "label" not in entry:
            raise ValueError(
                f"TrainingMeta.action_map[{i}] is missing required 'label' key; "
                "each entry needs 'value' (number) and 'label' (str)"
            )
        value = entry["value"]
        label = entry["label"]
        # ``bool`` is a subclass of ``int``; reject explicitly so ``True``/``False``
        # don't slip past the number check and become 1.0/0.0 silently.
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(
                f"TrainingMeta.action_map[{i}].value must be a number, got {type(value).__name__}"
            )
        if not isinstance(label, str):
            raise ValueError(
                f"TrainingMeta.action_map[{i}].label must be a string, got {type(label).__name__}"
            )
        out.append(ActionMapEntry(value=float(value), label=label))
    return out


# Bump requires coordinated onnxruntime upgrade across webapp + PE.
# See CONTRACT.md "Runtime compatibility".
MAX_SUPPORTED_IR_VERSION = 10


# ---------------------------------------------------------------------------
# Core function
# ---------------------------------------------------------------------------


def embed_koios_metadata(
    onnx_model: onnx.ModelProto,
    *,
    inputs: list[InputBinding],
    outputs: list[OutputBinding],
    training: TrainingMeta | None = None,
    output_denormalized: bool = False,
) -> None:
    """Embed ``koios.training`` and ``koios.bindings`` metadata into an ONNX model (in-place).

    Parameters
    ----------
    onnx_model:
        Loaded ONNX model proto (modified in-place).
    inputs:
        Input binding definitions (one per observation feature).
    outputs:
        Output binding definitions (one per action).
    training:
        Optional model-level training metadata.
    output_denormalized:
        Set True if the ONNX graph already emits physical values (i.e. the
        model's output is denormalized in-graph).  When True, the server
        configures outputs with ``normalization_type=NONE`` and uses the
        training action range as custom failure bounds.  Default False for
        standard SB3 exports whose outputs are still in normalized space.
    """
    # koios.training
    if training is None:
        training = TrainingMeta()

    training_meta: dict[str, object] = {
        "schema_version": 1,
        "scenario_name": training.scenario_name,
        "algorithm": training.algorithm,  # informational, free-form, not normalized
        "obs_depth": training.obs_depth,
        "sample_rate": training.sample_rate,
        "model_type": _wire_enum(training.model_type),
        "exported_at": datetime.now(UTC).isoformat(),
    }
    if training.scan_rate is not None:
        training_meta["scan_rate"] = training.scan_rate
    if training.output_mode is not None:
        training_meta["output_mode"] = _wire_enum(training.output_mode)
    if training.action_map is not None:
        # action_map is list[ActionMapEntry] post-__post_init__ (the field's
        # declared union with list[dict] is for ergonomic construction only);
        # serialize to the wire dict form that the webapp's
        # _normalize_action_map and the UI's ActionMapEntry interface expect.
        entries = cast("list[ActionMapEntry]", training.action_map)
        training_meta["action_map"] = [{"value": e.value, "label": e.label} for e in entries]

    # koios.bindings
    input_dicts = []
    for i, inp in enumerate(inputs):
        entry: dict[str, object] = {
            "binding_order": i + 1,
            "name": inp.name,
            "description": inp.description,
        }
        # `inp.normalization_type` is canonical post-__post_init__: either an
        # enum member or a raw string for unrecognized values.
        if inp.normalization_type != NormalizationType.NONE:
            entry["normalization_type"] = _wire_enum(inp.normalization_type)
            if inp.normalization_source is not None:
                entry["normalization_source"] = _wire_enum(inp.normalization_source)
            if inp.custom_mean is not None:
                entry["custom_mean"] = inp.custom_mean
            if inp.custom_std is not None:
                entry["custom_std"] = inp.custom_std
            if inp.custom_minimum is not None:
                entry["custom_minimum"] = inp.custom_minimum
            if inp.custom_maximum is not None:
                entry["custom_maximum"] = inp.custom_maximum
        if inp.failure_range_mode is not None:
            entry["failure_range_mode"] = _wire_enum(inp.failure_range_mode)
            if inp.custom_failure_minimum is not None:
                entry["custom_failure_minimum"] = inp.custom_failure_minimum
            if inp.custom_failure_maximum is not None:
                entry["custom_failure_maximum"] = inp.custom_failure_maximum
        input_dicts.append(entry)

    output_dicts = []
    for i, out in enumerate(outputs):
        entry = {
            "binding_order": i + 1,
            "name": out.name,
            "description": out.description,
            "normalization_type": _wire_enum(out.normalization_type),
        }
        if out.range_min is not None:
            entry["range_min"] = out.range_min
        if out.range_max is not None:
            entry["range_max"] = out.range_max
        if out.normalization_source is not None:
            entry["normalization_source"] = _wire_enum(out.normalization_source)
        if out.custom_minimum is not None:
            entry["custom_minimum"] = out.custom_minimum
        if out.custom_maximum is not None:
            entry["custom_maximum"] = out.custom_maximum
        if out.clamp_output:
            entry["clamp_output"] = True
        if out.failure_range_mode is not None:
            entry["failure_range_mode"] = _wire_enum(out.failure_range_mode)
            if out.custom_failure_minimum is not None:
                entry["custom_failure_minimum"] = out.custom_failure_minimum
            if out.custom_failure_maximum is not None:
                entry["custom_failure_maximum"] = out.custom_failure_maximum
        output_dicts.append(entry)

    bindings_meta: dict[str, object] = {
        "schema_version": 1,
        "output_denormalized": output_denormalized,
        "inputs": input_dicts,
        "outputs": output_dicts,
    }

    onnx_model.metadata_props.append(
        onnx.StringStringEntryProto(key="koios.training", value=json.dumps(training_meta))
    )
    onnx_model.metadata_props.append(
        onnx.StringStringEntryProto(key="koios.bindings", value=json.dumps(bindings_meta))
    )

    if onnx_model.ir_version > MAX_SUPPORTED_IR_VERSION:
        onnx_model.ir_version = MAX_SUPPORTED_IR_VERSION

    logger.info(
        "Embedded koios.training metadata (%d inputs, %d outputs)", len(inputs), len(outputs)
    )


# ---------------------------------------------------------------------------
# Parsing — mirror image of embed_koios_metadata
# ---------------------------------------------------------------------------


class KoiosMetadataError(ValueError):
    """Base class for koios metadata parse errors."""


class UnsupportedSchemaVersionError(KoiosMetadataError):
    """The koios.* metadata uses a schema_version this library doesn't understand."""


class KoiosMetadataDecodeError(KoiosMetadataError):
    """A koios.* metadata prop is present but can't be decoded as the expected JSON shape."""


@dataclass
class ParsedKoiosMetadata:
    """Result of :func:`parse_koios_metadata`.

    Attributes
    ----------
    training:
        ``TrainingMeta`` if ``koios.training`` was present, else ``None``.
    inputs:
        Input bindings (empty if no ``koios.bindings`` prop).
    outputs:
        Output bindings (empty if no ``koios.bindings`` prop).
    output_denormalized:
        From ``koios.bindings.output_denormalized``.  Defaults to False.
    has_metadata:
        True if any ``koios.*`` prop was present on the model.
    """

    training: TrainingMeta | None = None
    inputs: list[InputBinding] = field(default_factory=list)
    outputs: list[OutputBinding] = field(default_factory=list)
    output_denormalized: bool = False
    has_metadata: bool = False


_EnumT = TypeVar("_EnumT", bound=StrEnum)


def _coerce_enum(value: Any, enum_cls: type[_EnumT]) -> _EnumT | str | None:
    """Best-effort coerce a wire value to an enum member.

    - ``None`` passes through as ``None``.
    - An existing enum member passes through unchanged.
    - A string matching any member's value (case-insensitive) returns that member.
    - Anything else returns ``str(value)`` so callers can still see what was on the wire.
    """
    if value is None:
        return None
    if isinstance(value, enum_cls):
        return value
    s = str(value)
    s_lower = s.lower()
    for member in enum_cls:
        if member.value.lower() == s_lower:
            return member
    return s


def _wire_enum(value: Any) -> Any:
    """Normalize an enum-typed value to its canonical uppercase wire form.

    Library 1.1+ writes uppercase strings for ``normalization_type``,
    ``normalization_source``, ``model_type``, and ``output_mode`` regardless of
    whether the user passed an enum member or a lowercase legacy string.  This
    keeps the wire format predictable and makes downstream tools that read the
    JSON directly (jq, log greps) work without case-insensitive matching.

    Unknown / non-string values pass through unchanged so callers can stash
    arbitrary content if needed (the existing schema doesn't, but future
    additions might).
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value.upper()
    return value


def _opt_float(value: Any) -> float | None:
    if value is None:
        return None
    return float(value)


def parse_koios_metadata(onnx_model: onnx.ModelProto) -> ParsedKoiosMetadata:
    """Read ``koios.training`` and ``koios.bindings`` from an ONNX model's metadata.

    The mirror image of :func:`embed_koios_metadata`.  Returns typed dataclasses
    with enum values coerced to their :class:`enum.StrEnum` members where
    recognized; unknown enum strings pass through as raw strings so callers can
    log them or apply policy.

    Raises
    ------
    UnsupportedSchemaVersionError:
        Either prop has a ``schema_version`` other than 1 (or missing).
    KoiosMetadataDecodeError:
        A ``koios.*`` prop value isn't valid JSON, or the decoded JSON isn't an object.
    """
    # Only the two known keys are decoded.  Future library versions may add
    # new ``koios.*`` props (potentially with non-object JSON values); older
    # parsers must skip them silently rather than raising — see the
    # forward-compat policy in CONTRACT.md.
    raw: dict[str, dict[str, Any]] = {}
    for prop in onnx_model.metadata_props:
        if prop.key not in _KNOWN_KOIOS_KEYS:
            continue
        try:
            decoded = json.loads(prop.value)
        except json.JSONDecodeError as e:
            raise KoiosMetadataDecodeError(f"{prop.key} is not valid JSON: {e}") from e
        if not isinstance(decoded, dict):
            raise KoiosMetadataDecodeError(
                f"{prop.key} must be a JSON object, got {type(decoded).__name__}"
            )
        raw[prop.key] = decoded

    return parse_koios_metadata_from_dict(raw)


_KNOWN_KOIOS_KEYS = frozenset({"koios.training", "koios.bindings"})


def parse_koios_metadata_from_dict(
    raw: dict[str, dict[str, Any]],
) -> ParsedKoiosMetadata:
    """Like :func:`parse_koios_metadata` but takes the JSON-decoded dict directly.

    Useful when the raw metadata has already been pulled out of ONNX and
    persisted (e.g. into a JSONField).  Keys other than ``koios.training`` and
    ``koios.bindings`` are ignored.
    """
    result = ParsedKoiosMetadata()

    training_raw = raw.get("koios.training")
    if training_raw is not None:
        result.has_metadata = True
        if training_raw.get("schema_version") != 1:
            raise UnsupportedSchemaVersionError(
                f"koios.training schema_version={training_raw.get('schema_version')!r}, expected 1"
            )
        try:
            result.training = _decode_training(training_raw)
        except ValueError as e:
            # Wire data violated a dataclass validator (e.g. empty name,
            # zero sample_rate).  Re-raise as a parse error so callers
            # catching KoiosMetadataError see it.
            if isinstance(e, KoiosMetadataError):
                raise
            raise KoiosMetadataDecodeError(f"koios.training contains invalid data: {e}") from e

    bindings_raw = raw.get("koios.bindings")
    if bindings_raw is not None:
        result.has_metadata = True
        if bindings_raw.get("schema_version") != 1:
            raise UnsupportedSchemaVersionError(
                f"koios.bindings schema_version={bindings_raw.get('schema_version')!r}, expected 1"
            )
        result.output_denormalized = bool(bindings_raw.get("output_denormalized", False))
        try:
            result.inputs = [_decode_input_binding(d) for d in bindings_raw.get("inputs", [])]
            result.outputs = [_decode_output_binding(d) for d in bindings_raw.get("outputs", [])]
        except ValueError as e:
            if isinstance(e, KoiosMetadataError):
                raise
            raise KoiosMetadataDecodeError(f"koios.bindings contains invalid data: {e}") from e

    return result


def _decode_training(d: dict[str, Any]) -> TrainingMeta:
    raw_scan_rate = d.get("scan_rate")
    return TrainingMeta(
        scenario_name=str(d.get("scenario_name", "")),
        algorithm=d.get("algorithm", ""),
        obs_depth=int(d.get("obs_depth", 1)),
        sample_rate=float(d.get("sample_rate", 1.0)),
        scan_rate=float(raw_scan_rate) if raw_scan_rate is not None else None,
        model_type=d.get("model_type") or ModelType.ABSOLUTE,
        output_mode=d.get("output_mode"),
        action_map=d.get("action_map"),
    )


def _decode_input_binding(d: dict[str, Any]) -> InputBinding:
    return InputBinding(
        name=str(d.get("name", "")),
        description=str(d.get("description", "")),
        normalization_type=d.get("normalization_type") or NormalizationType.NONE,
        normalization_source=d.get("normalization_source"),
        custom_mean=_opt_float(d.get("custom_mean")),
        custom_std=_opt_float(d.get("custom_std")),
        custom_minimum=_opt_float(d.get("custom_minimum")),
        custom_maximum=_opt_float(d.get("custom_maximum")),
        failure_range_mode=d.get("failure_range_mode"),
        custom_failure_minimum=_opt_float(d.get("custom_failure_minimum")),
        custom_failure_maximum=_opt_float(d.get("custom_failure_maximum")),
    )


def _decode_output_binding(d: dict[str, Any]) -> OutputBinding:
    return OutputBinding(
        name=str(d.get("name", "")),
        description=str(d.get("description", "")),
        range_min=_opt_float(d.get("range_min")),
        range_max=_opt_float(d.get("range_max")),
        normalization_type=d.get("normalization_type") or NormalizationType.NONE,
        normalization_source=d.get("normalization_source"),
        custom_minimum=_opt_float(d.get("custom_minimum")),
        custom_maximum=_opt_float(d.get("custom_maximum")),
        clamp_output=bool(d.get("clamp_output", False)),
        failure_range_mode=d.get("failure_range_mode"),
        custom_failure_minimum=_opt_float(d.get("custom_failure_minimum")),
        custom_failure_maximum=_opt_float(d.get("custom_failure_maximum")),
    )
