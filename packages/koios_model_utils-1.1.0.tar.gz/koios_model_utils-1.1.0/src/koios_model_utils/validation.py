"""Construction-time validation for the koios-model-utils dataclasses.

Each dataclass calls one of these helpers from ``__post_init__`` to catch
internally-inconsistent state at the point it's authored — not later when
the wire payload is parsed (or worse, silently misapplied by the server).

The rules deliberately err on the side of strictness: they reject combos
the server can't honor cleanly even if it would silently ignore them.
"""

from __future__ import annotations

import dataclasses
import math
from typing import TYPE_CHECKING

from koios_model_utils.enums import (
    FailureRangeMode,
    NormalizationSource,
    NormalizationType,
    OutputMode,
)

if TYPE_CHECKING:
    from koios_model_utils.metadata import (
        InputBinding,
        OutputBinding,
        TrainingMeta,
    )


def _check_finite_floats(name: str, b: object) -> None:
    """Reject NaN/Inf in any ``float | None`` dataclass field of ``b``.

    Iterates the dataclass schema so newly-added float fields get the same
    treatment without the validator needing to be updated.
    """
    for f in dataclasses.fields(b):  # type: ignore[arg-type]
        value = getattr(b, f.name)
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError(
                f"{name}.{f.name}={value!r} is not finite (NaN/Inf produces invalid JSON)"
            )


def _check_pair_ordered(
    type_name: str, lo_name: str, lo: float | None, hi_name: str, hi: float | None
) -> None:
    """Require ``lo <= hi`` when both are set."""
    if lo is not None and hi is not None and lo > hi:
        raise ValueError(f"{type_name}.{lo_name} ({lo}) must be <= {hi_name} ({hi})")


def validate_input_binding(b: InputBinding) -> None:
    """Validate a fresh ``InputBinding`` for internal consistency."""
    if not b.name or not b.name.strip():
        raise ValueError(
            "InputBinding.name must be a non-empty, non-whitespace string "
            "(it identifies the binding to the Koios server and the user)"
        )

    _check_finite_floats("InputBinding", b)
    _check_pair_ordered(
        "InputBinding",
        "custom_minimum",
        b.custom_minimum,
        "custom_maximum",
        b.custom_maximum,
    )
    _check_pair_ordered(
        "InputBinding",
        "custom_failure_minimum",
        b.custom_failure_minimum,
        "custom_failure_maximum",
        b.custom_failure_maximum,
    )

    if b.custom_std is not None and b.custom_std <= 0:
        raise ValueError(
            f"InputBinding.custom_std ({b.custom_std}) must be > 0 "
            "(zero or negative std would make Z-Score normalization undefined)"
        )

    # ``b`` already had its enum fields resolved in ``__post_init__``; field
    # holds either an enum member or a raw string (for unrecognized values).
    norm_type = b.normalization_type
    norm_source = b.normalization_source

    if norm_type == NormalizationType.Z_SCORE:
        if b.custom_minimum is not None or b.custom_maximum is not None:
            raise ValueError(
                "InputBinding: Z_SCORE uses custom_mean/custom_std, not "
                "custom_minimum/custom_maximum (server will ignore the min/max)"
            )

    if norm_type in (NormalizationType.MIN_MAX, NormalizationType.SYMMETRIC):
        if b.custom_mean is not None or b.custom_std is not None:
            raise ValueError(
                f"InputBinding: {norm_type} uses custom_minimum/custom_maximum, "
                "not custom_mean/custom_std (server will ignore the mean/std)"
            )

    if norm_source == NormalizationSource.TAG_RANGE and any(
        v is not None for v in (b.custom_minimum, b.custom_maximum, b.custom_mean, b.custom_std)
    ):
        raise ValueError(
            "InputBinding: TAG_RANGE source reads bounds from the bound "
            "tag at runtime; embedding custom_* values would collide with "
            "that intent"
        )

    if norm_source == NormalizationSource.CUSTOM and norm_type != NormalizationType.NONE:
        if norm_type == NormalizationType.Z_SCORE:
            if b.custom_mean is None or b.custom_std is None:
                raise ValueError(
                    "InputBinding: Z_SCORE + CUSTOM source requires custom_mean and custom_std"
                )
        elif b.custom_minimum is None or b.custom_maximum is None:
            raise ValueError(
                f"InputBinding: {norm_type} + CUSTOM source requires "
                "custom_minimum and custom_maximum"
            )

    failure_mode = b.failure_range_mode
    if failure_mode == FailureRangeMode.CUSTOM and (
        b.custom_failure_minimum is None or b.custom_failure_maximum is None
    ):
        raise ValueError(
            "InputBinding: failure_range_mode=CUSTOM requires both "
            "custom_failure_minimum and custom_failure_maximum"
        )


def validate_output_binding(b: OutputBinding) -> None:
    """Validate a fresh ``OutputBinding`` for internal consistency."""
    if not b.name or not b.name.strip():
        raise ValueError("OutputBinding.name must be a non-empty, non-whitespace string")

    _check_finite_floats("OutputBinding", b)
    _check_pair_ordered("OutputBinding", "range_min", b.range_min, "range_max", b.range_max)
    _check_pair_ordered(
        "OutputBinding",
        "custom_minimum",
        b.custom_minimum,
        "custom_maximum",
        b.custom_maximum,
    )
    _check_pair_ordered(
        "OutputBinding",
        "custom_failure_minimum",
        b.custom_failure_minimum,
        "custom_failure_maximum",
        b.custom_failure_maximum,
    )

    # ``b`` already had its enum fields resolved in ``__post_init__``; field
    # holds either an enum member or a raw string (for unrecognized values).
    norm_type = b.normalization_type
    norm_source = b.normalization_source

    if norm_type == NormalizationType.Z_SCORE:
        # OutputBinding has no custom_mean/custom_std fields, so Z_SCORE has
        # nowhere to put its scaling parameters.
        raise ValueError(
            "OutputBinding: Z_SCORE is not supported on outputs (no "
            "custom_mean/custom_std fields). Use SYMMETRIC or MIN_MAX."
        )

    if norm_source == NormalizationSource.TAG_RANGE:
        # Footgun documented in CONTRACT.md: range_min/range_max with
        # TAG_RANGE collides with the server's runtime tag-range lookup.
        if b.range_min is not None or b.range_max is not None:
            raise ValueError(
                "OutputBinding: TAG_RANGE source reads bounds from the bound "
                "tag at runtime; range_min/range_max must be omitted to avoid "
                "the server's legacy MIN_MAX inference fallback (see CONTRACT.md)"
            )
        if b.custom_minimum is not None or b.custom_maximum is not None:
            raise ValueError(
                "OutputBinding: TAG_RANGE source rejects custom_minimum/maximum "
                "(server reads the tag's engineering range at runtime)"
            )

    if norm_source == NormalizationSource.CUSTOM and norm_type != NormalizationType.NONE:
        if b.custom_minimum is None or b.custom_maximum is None:
            raise ValueError(
                f"OutputBinding: {norm_type} + CUSTOM source requires "
                "custom_minimum and custom_maximum"
            )

    failure_mode = b.failure_range_mode
    if failure_mode == FailureRangeMode.CUSTOM and (
        b.custom_failure_minimum is None or b.custom_failure_maximum is None
    ):
        raise ValueError(
            "OutputBinding: failure_range_mode=CUSTOM requires both "
            "custom_failure_minimum and custom_failure_maximum"
        )


def validate_training_meta(t: TrainingMeta) -> None:
    """Validate a fresh ``TrainingMeta`` for internal consistency."""
    if not math.isfinite(t.sample_rate):
        raise ValueError(f"TrainingMeta.sample_rate={t.sample_rate!r} is not finite")
    if t.sample_rate <= 0:
        raise ValueError(f"TrainingMeta.sample_rate ({t.sample_rate}) must be > 0 seconds")
    if t.scan_rate is not None:
        if not math.isfinite(t.scan_rate):
            raise ValueError(f"TrainingMeta.scan_rate={t.scan_rate!r} is not finite")
        if t.scan_rate <= 0:
            raise ValueError(f"TrainingMeta.scan_rate ({t.scan_rate}) must be > 0 seconds")
    if t.obs_depth < 1:
        raise ValueError(f"TrainingMeta.obs_depth ({t.obs_depth}) must be >= 1")

    output_mode = t.output_mode
    if output_mode == OutputMode.DISCRETE and not t.action_map:
        raise ValueError("TrainingMeta: output_mode=DISCRETE requires a non-empty action_map")
    if output_mode == OutputMode.CONTINUOUS and t.action_map:
        raise ValueError(
            "TrainingMeta: output_mode=CONTINUOUS does not use action_map "
            "(action_map is for DISCRETE classifiers / DQN heads)"
        )
