"""koios-model-utils — utilities for annotating ONNX models for the Koios IoT platform.

The library defines the wire format for ``koios.training`` / ``koios.bindings``
metadata that producers (Ronin, manual scripts, future DRL workers) embed into
ONNX files for Koios to consume on upload.  See ``docs/CONTRACT.md`` for the
authoritative spec.
"""

__version__ = "1.1.0"

from koios_model_utils.enums import (
    Algorithm,
    FailureRangeMode,
    ModelType,
    NormalizationSource,
    NormalizationType,
    OutputMode,
)
from koios_model_utils.metadata import (
    MAX_SUPPORTED_IR_VERSION,
    ActionMapEntry,
    InputBinding,
    KoiosMetadataDecodeError,
    KoiosMetadataError,
    OutputBinding,
    ParsedKoiosMetadata,
    TrainingMeta,
    UnsupportedSchemaVersionError,
    embed_koios_metadata,
    parse_koios_metadata,
    parse_koios_metadata_from_dict,
)

__all__ = [
    # enums
    "Algorithm",
    "FailureRangeMode",
    "ModelType",
    "NormalizationSource",
    "NormalizationType",
    "OutputMode",
    # dataclasses
    "ActionMapEntry",
    "InputBinding",
    "OutputBinding",
    "ParsedKoiosMetadata",
    "TrainingMeta",
    # constants
    "MAX_SUPPORTED_IR_VERSION",
    # functions
    "embed_koios_metadata",
    "parse_koios_metadata",
    "parse_koios_metadata_from_dict",
    # errors
    "KoiosMetadataError",
    "KoiosMetadataDecodeError",
    "UnsupportedSchemaVersionError",
]
