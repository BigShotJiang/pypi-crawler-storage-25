"""String enums for Koios metadata values.

Every enum here is a :class:`enum.StrEnum` — members are real strings and
serialize transparently through ``json.dumps``, so users may pass either
the enum member or the raw string literal wherever metadata values are
expected.

String values are SCREAMING_SNAKE_CASE and match the corresponding Django
``IntegerChoices`` member names in ``koios-webapp-py/.../aiops/choices.py``
exactly.  Renaming a member on the server requires updating the matching
member here (and bumping the schema version if the rename is incompatible).

Both the library parser and the webapp's ``_choice_from_name`` accept
wire values case-insensitively for backward compatibility with files
written by koios-model-utils 1.0.x (which serialized normalization values
in lowercase).  New producers should use the enum member directly.
"""

from __future__ import annotations

from enum import StrEnum


class NormalizationType(StrEnum):
    """How a binding's value is mapped into / out of model space."""

    NONE = "NONE"
    MIN_MAX = "MIN_MAX"
    SYMMETRIC = "SYMMETRIC"
    Z_SCORE = "Z_SCORE"


class NormalizationSource(StrEnum):
    """Where normalization parameters come from at runtime."""

    # The tag's engineering range (range_min / range_max on the bound tag).
    TAG_RANGE = "TAG_RANGE"
    # Explicit ``custom_minimum`` / ``custom_maximum`` / ``custom_mean`` /
    # ``custom_std`` values embedded in the ONNX metadata.
    CUSTOM = "CUSTOM"


class ModelType(StrEnum):
    """How the predict engine applies the model's output to the bound tag.

    Maps to the server's ``OutputApplicationChoices``. The legacy
    ``POSITIONAL`` / ``VELOCITY`` aliases are still accepted by the
    server but should not be used in new code.
    """

    ABSOLUTE = "ABSOLUTE"
    RELATIVE = "RELATIVE"


class OutputMode(StrEnum):
    """Whether the model emits a continuous value or a categorical action."""

    CONTINUOUS = "CONTINUOUS"
    DISCRETE = "DISCRETE"


class Algorithm(StrEnum):
    """Stable-Baselines3 algorithm identifiers recognized by the exporter."""

    PPO = "PPO"
    SAC = "SAC"
    TD3 = "TD3"
    A2C = "A2C"
    DQN = "DQN"


class FailureRangeMode(StrEnum):
    """How the predict engine decides whether a value is "out of range".

    Maps to the server's ``FailureRangeModeChoices``.  When unset on the wire,
    the server defaults to ``NORMALIZATION_RANGE``.
    """

    # No failure-range checks performed.
    DISABLED = "DISABLED"
    # Use the binding's ``custom_failure_minimum`` / ``custom_failure_maximum``.
    CUSTOM = "CUSTOM"
    # Derive from the active normalization range (e.g. MIN_MAX bounds).
    NORMALIZATION_RANGE = "NORMALIZATION_RANGE"
