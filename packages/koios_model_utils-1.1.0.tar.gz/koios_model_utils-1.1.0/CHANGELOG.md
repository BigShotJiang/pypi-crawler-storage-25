# Changelog

All notable changes to `koios-model-utils` are documented here. The format
loosely follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and
this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] — Unreleased

Adds a parser, stricter dataclass validation, and quality-of-life
improvements for DRL controllers.  All changes are additive and
backward-compatible with files written by 1.0.x.

### Added
- **`parse_koios_metadata(model)`** and **`parse_koios_metadata_from_dict(raw)`** —
  mirror of `embed_koios_metadata`.  Returns a `ParsedKoiosMetadata`
  dataclass with `training`, `inputs`, `outputs`, `output_denormalized`,
  and `has_metadata` fields.  Unknown enum values pass through as raw
  strings; unknown `schema_version` raises `UnsupportedSchemaVersionError`.
- **`ActionMapEntry`** dataclass (`value: float`, `label: str`) for
  typed DISCRETE-mode action maps.  `TrainingMeta.action_map` accepts
  either dataclass instances or raw dicts; dicts are coerced at
  construction with strict key validation (missing or wrong-type
  keys raise).
- **`TrainingMeta.scan_rate`** — wall-clock seconds between predict-engine
  executions, set independently of `sample_rate`.  When omitted, the
  server inherits `scan_rate` from `sample_rate` (the right default for
  forecasting models).  Set it explicitly for RL controllers that need
  to act faster than the simulator step they were trained against.
- **`FailureRangeMode`** enum (`DISABLED`, `CUSTOM`, `NORMALIZATION_RANGE`)
  for the input/output `failure_range_mode` field.
- **Construction-time validators** on every dataclass.  Each
  `__post_init__` calls `validate_input_binding` /
  `validate_output_binding` / `validate_training_meta`, which reject
  combinations the server can't honor (Z_SCORE + custom_minimum,
  TAG_RANGE + embedded custom bounds, DISCRETE + empty action_map,
  non-finite floats, negative `sample_rate`/`scan_rate`, etc.).  Bad
  state now fails at the call site instead of producing a wire payload
  the server silently misapplies.

### Changed
- **Uppercase wire format for enum-typed fields.**  Library 1.1+ writes
  SCREAMING_SNAKE_CASE on the wire (`Z_SCORE`, `TAG_RANGE`, `ABSOLUTE`,
  `CONTINUOUS`) for `normalization_type`, `normalization_source`,
  `model_type`, and `output_mode` regardless of whether the caller
  passes an enum member or a lowercase legacy string.  The webapp
  parser remains case-insensitive for compatibility with files
  written by 1.0.x.
- **Enum fields are canonicalized in `__post_init__`.**  After
  construction, `binding.normalization_type` is an enum member (or a
  raw string for unrecognized values), not the original input.  Use
  `dataclasses.replace(b, ...)` if you need to mutate a field after
  construction — direct assignment skips re-validation.

### Documentation
- Added [`docs/CONTRACT.md`](docs/CONTRACT.md) — the source of truth
  for the `koios.training` / `koios.bindings` wire format, server-side
  policies (legacy aliases, MIN_MAX inference fallback, output
  overrides), forward-compat rules within schema_version 1, and
  producer best practices.
- Added [`examples/`](examples/) with three runnable scripts covering
  a minimal embed, a discrete action-map model, and a round-trip
  parse.
- Added repo-root `CLAUDE.md` for agent-assisted producers.

### Compatibility
- `schema_version` remains `1`.  All additions round-trip through
  `embed` → `parse`.  Files written by 1.0.x parse cleanly under 1.1.
- Dataclass shape gained one new optional field (`scan_rate`) with a
  `None` default — non-breaking.

[1.1.0]: https://github.com/Ai-Ops-Inc/koios-model-utils/releases/tag/v1.1.0

## [1.0.0] — 2026-04-20

First stable release. This release fixes several wire-format bugs between
the client and the Koios webapp server — the result of the two sides
drifting apart before the contract was exercised end-to-end. See
[PR writeup] and `TestContractWithWebapp` for the tests that now lock
each key name into place.

### Fixed
- **Custom failure bounds were silently dropped for MIN_MAX / SYMMETRIC /
  NONE normalization.** The client wrote `custom_failure: true` along with
  `custom_failure_minimum/maximum`, but the server never read the
  `custom_failure` boolean — it reads `failure_range_mode` to decide
  whether to apply the custom bounds. Without that key the server
  defaulted to `NORMALIZATION_RANGE`, which derives failure bounds from
  the normalization range and ignores any custom values. Result:
  failure bounds quietly did nothing at runtime unless the binding
  happened to be Z-Score (which auto-forces CUSTOM server-side).

  1.0.0 now writes `failure_range_mode: "CUSTOM"` when `custom_failure`
  is True, which the server parses correctly. Applies to both input
  and output bindings.
- Dropped `custom_failure: true` (input entries) and `obs_normalized: false`
  (top-level bindings) from the wire payload — the server never read
  either one, so they were dead weight.

### Added
- **String enums** for every metadata value previously passed as a raw
  string: `NormalizationType`, `NormalizationSource`, `ModelType`,
  `OutputMode`, `Algorithm`. All are `enum.StrEnum` subclasses so
  members serialize transparently through `json.dumps`, and the
  dataclass fields accept either form (`NormalizationType.SYMMETRIC`
  or `"symmetric"` produce byte-identical payloads).  Raw strings are
  still fully supported.
- `OutputBinding.custom_failure`, `custom_failure_minimum`, and
  `custom_failure_maximum` — the server has always accepted these on
  output bindings but the client had no API for setting them.
- `embed_koios_metadata(..., output_denormalized: bool = False)` — lets
  users signal that the ONNX graph emits physical values already, so
  the server wires outputs as `normalization_type=NONE` and uses the
  training action range as custom failure bounds. Previously hardcoded
  to False; the "legacy MIN_MAX+CUSTOM auto-inference" branch on the
  server was the only reachable path.
- `TestContractWithWebapp` — tests that lock in the set of keys
  consumed by `koios-webapp-py`'s `_apply_training_metadata` and
  `_apply_binding_metadata`. If either side drifts, the tests fail
  loudly rather than silently dropping fields again.

### Changed
- Declared Production/Stable (was Alpha).
- `TrainingMeta.model_type` default is now `"ABSOLUTE"` (matches the
  current server enum name). The server still accepts the legacy
  `"POSITIONAL"` / `"VELOCITY"` aliases for backward compatibility —
  they just map to `ABSOLUTE` / `RELATIVE` respectively.

### License
- Relicensed from MIT to **Apache License 2.0** to align with the
  sibling Koios client libraries (`koios-client`, `koios-component-builder`).
  Apache 2.0 matches the prevailing convention for SDKs / client
  libraries at comparable companies (AWS, Google, OpenAI, Snowflake)
  and includes an explicit patent grant.  The `LICENSE` file at the
  repo root has been updated accordingly.

### Compatibility
- `schema_version` remains `1`. All fixes produce payloads the current
  webapp already accepts; this is entirely a client-side correctness
  release. No server-side changes required. No prior releases of this
  package have shipped real metadata into anyone's Koios install.

[1.0.0]: https://github.com/Ai-Ops-Inc/koios-model-utils/releases/tag/v1.0.0
