from functools import reduce, lru_cache
from hestia_earth.utils.lookup import download_lookup, get_table_value
from hestia_earth.utils.tools import to_precision, non_empty_list, list_sum
from hestia_earth.utils.model import find_term_match
from hestia_earth.utils.blank_node import get_node_value, get_lookup_value

from hestia_earth.aggregation.log import debugWeights, debugRequirements
from .lookup import (
    production_quantity_lookup,
    production_quantity_country,
    lookup_data_period_average,
    is_plantation,
)
from .term import (
    DEFAULT_COUNTRY_ID,
    _format_organic,
    _format_irrigated,
    _format_country_name,
)


def _weight_to_key(weights: list):
    return "_".join(non_empty_list(weights))


def _format_weight_key(key: str):
    return ", ".join(key.split("_")).capitalize()


_WEIGHTS_KEYS = [["organic", "conventional"], ["irrigated", "non-irrigated"]]
_WEIGHTS_COMBINATIONS = [
    _weight_to_key([organic_key, irrigated_key])
    for organic_key in _WEIGHTS_KEYS[0]
    for irrigated_key in _WEIGHTS_KEYS[1]
]


def format_weights(weights: list, include_default_combinations: bool = False):
    total = list_sum(non_empty_list([w.get("weight") for w in weights]))
    included_keys = non_empty_list([weight.get("key") for weight in weights])
    return "; ".join(
        [
            f"{_format_weight_key(weight.get('key'))}: {round(weight.get('weight') * 100 / total, 2)}%"
            for weight in weights
            if weight.get("key")
        ]
        + (
            [
                f"{_format_weight_key(key)}: 0%"
                for key in _WEIGHTS_COMBINATIONS
                if key not in included_keys
            ]
            if include_default_combinations and included_keys
            else []
        )
    )


def _group_weights(group: dict, weight: dict):
    key = weight.get("key")
    group[key] = group.get(key, 0) + weight.get("weight")
    return group


def format_plantation_weights(weights: list):
    # group weights by key and sum them
    grouped = reduce(_group_weights, weights, {})
    total = list_sum(list(grouped.values()))
    return (
        "; ".join(
            [
                f"{key.capitalize()} phase: {round(weight / total * 100)}%"
                for key, weight in grouped.items()
                if key
            ]
        )
        if total > 0
        else None
    )


def _country_organic_weight(country_id: str, start_year: int, end_year: int):
    lookup = download_lookup("region-standardsLabels-isOrganic.csv")
    data = get_table_value(lookup, "term.id", country_id, "organic")
    # default to 0 => assume nothing organic
    value = lookup_data_period_average(data, start_year, end_year, default=0)
    organic_weight = min(1, to_precision(value / 100)) if value else None

    debugRequirements(
        country_id=country_id,
        start_year=start_year,
        end_year=end_year,
        organic_weight_lookup_value=value,
        organic_weight=organic_weight,
    )

    return organic_weight


@lru_cache()
def _organic_weight(country_id: str, start_year: int, end_year: int):
    return (
        _country_organic_weight(country_id, start_year, end_year)
        or _country_organic_weight(DEFAULT_COUNTRY_ID, start_year, end_year)
        or 0
    )


_IRRIGATED_COLUMN_MAPPING = {
    "Agriculture irrigated": "Agriculture area actually irrigated",
    "Cropland irrigated": "Cropland area actually irrigated",
    "Land area irrigated": "Land area equipped for irrigation",
}


def _country_irrigated_weight(
    country_id: str, start_year: int, end_year: int, siteType: str = "Land area"
):
    lookup = download_lookup("region-irrigated.csv")

    total_area_data = get_table_value(lookup, "term.id", country_id, siteType)
    # default to 1 => assume whole area
    total_area = lookup_data_period_average(
        total_area_data, start_year, end_year, default=1
    )

    irrigated_column_name = _IRRIGATED_COLUMN_MAPPING.get(f"{siteType} irrigated")
    irrigated_data = get_table_value(
        lookup, "term.id", country_id, irrigated_column_name
    ) or get_table_value(lookup, "term.id", country_id, f"{siteType} irrigated")
    irrigated = lookup_data_period_average(irrigated_data, start_year, end_year)
    irrigated_weight = to_precision(irrigated / total_area) if irrigated else None

    debugRequirements(
        country_id=country_id,
        start_year=start_year,
        end_year=end_year,
        site_type=siteType,
        total_area=total_area,
        irrigated_area=irrigated,
        irrigated_weight=irrigated_weight,
    )

    return irrigated_weight


@lru_cache()
def _irrigated_weight(country_id: str, start_year: int, end_year: int):
    return (
        _country_irrigated_weight(country_id, start_year, end_year, "Cropland")
        or _country_irrigated_weight(country_id, start_year, end_year, "Agriculture")
        or _country_irrigated_weight(country_id, start_year, end_year, "all")
        or _country_irrigated_weight(country_id, start_year, end_year)
    )


def _country_weights(
    country_id: str, start_year: int, end_year: int, node: dict, completeness: dict
) -> dict:
    node_id = node.get("@id", node.get("id"))
    organic_weight = _organic_weight(country_id, start_year, end_year)
    irrigated_weight = (
        _irrigated_weight(country_id, start_year, end_year)
        or _irrigated_weight(DEFAULT_COUNTRY_ID, start_year, end_year)
        or 0
    )
    weight = (organic_weight if node.get("organic", False) else 1 - organic_weight) * (
        irrigated_weight if node.get("irrigated", False) else 1 - irrigated_weight
    )
    key = _weight_to_key(
        [
            "organic" if node.get("organic", False) else "conventional",
            "irrigated" if node.get("irrigated", False) else "non-irrigated",
        ]
    )
    return {node_id: {"weight": weight, "completeness": completeness, "key": key}}


def country_weights(data: dict):
    nodes = data.get("nodes")
    country_id = data.get("country").get("@id")
    start_year = data.get("start_year")
    end_year = data.get("end_year")
    completeness = data.get("node-completeness")
    weights = reduce(
        lambda prev, curr: prev
        | _country_weights(
            country_id, start_year, end_year, curr[1], completeness[curr[0]]
        ),
        enumerate(nodes),
        {},
    )
    debugWeights(weights)
    return weights


def country_weight_node_id(blank_node: dict):
    return "-".join(
        [
            _format_organic(blank_node.get("organic")),
            _format_irrigated(blank_node.get("irrigated")),
        ]
    )


def _world_weight(
    lookup, lookup_column: str, country_id: str, start_year: int, end_year: int
):
    country_value = (
        production_quantity_country(
            lookup, lookup_column, start_year, end_year, country_id
        )
        or 1
    )
    world_value = (
        production_quantity_country(lookup, lookup_column, start_year, end_year) or 1
    )
    return min(1, country_value / world_value)


def _world_weights(lookup, lookup_column, node: dict, completeness: dict) -> dict:
    node_id = node.get("@id", node.get("id"))
    country_id = node.get("country").get("@id")
    start_year = node.get("start_year")
    end_year = node.get("end_year")
    weight = (
        _world_weight(lookup, lookup_column, country_id, start_year, end_year)
        if lookup is not None
        else 1
    )
    return {node_id: {"weight": weight, "completeness": completeness}}


def world_weights(data: dict) -> dict:
    nodes = data.get("nodes", [])
    completeness = data.get("node-completeness")
    lookup, lookup_column = production_quantity_lookup(data.get("product"))
    weights = reduce(
        lambda prev, curr: prev
        | _world_weights(lookup, lookup_column, curr[1], completeness[curr[0]]),
        enumerate(nodes),
        {},
    )
    debugWeights(weights)
    # make sure we have at least one value with `weight`, otherwise we cannot generate an aggregated value
    no_weights = (
        next((v for v in weights.values() if v.get("weight", 0) > 0), None) is None
    )
    return None if no_weights else weights


def world_weight_node_id(blank_node: dict):
    return _format_country_name(blank_node)


_CALCULATE_PHASE_RATIO = {
    "productive": lambda lifespan, productive_lifespan: productive_lifespan / lifespan,
    "preparation": lambda lifespan, *args: 365 / lifespan,
    "non-productive": lambda lifespan, productive_lifespan: (
        lifespan - productive_lifespan - 365
    )
    / lifespan,
}


def plantation_weight_key(cycle: dict):
    practices = cycle.get("practices", [])
    productive_phase = get_node_value(
        find_term_match(practices, "productivePhasePermanentCrops"), default=None
    )
    preparation_phase = get_node_value(
        find_term_match(practices, "preparationPhasePermanentCrops"), default=None
    )
    return (
        "productive"
        if productive_phase
        else "preparation" if preparation_phase else "non-productive"
    )


def _plantation_weight(cycle: dict, product: dict):
    practices = cycle.get("practices", [])
    # use the lookup values to make sure all Cycles with the same "key" get the same weight
    plantation_lifespan = get_lookup_value({"term": product}, "Plantation_lifespan")
    plantation_non_productive_lifespan = get_lookup_value(
        {"term": product}, "Plantation_non-productive_lifespan"
    )
    plantation_productive_lifespan = (
        plantation_lifespan - plantation_non_productive_lifespan
    )

    productive_phase = get_node_value(
        find_term_match(practices, "productivePhasePermanentCrops"), default=None
    )
    preparation_phase = get_node_value(
        find_term_match(practices, "preparationPhasePermanentCrops"), default=None
    )
    weight_key = plantation_weight_key(cycle)
    return (
        _CALCULATE_PHASE_RATIO[weight_key](
            plantation_lifespan, plantation_productive_lifespan
        )
        if all(
            [
                v is not None
                for v in [
                    plantation_lifespan,
                    plantation_productive_lifespan,
                    productive_phase,
                    preparation_phase,
                ]
            ]
        )
        else 1
    )


def cycle_weight(cycle: dict, product: dict):
    plantation = is_plantation(product)
    return _plantation_weight(cycle, product) if plantation else 1


def _compute_plantation_weight_description(
    plantation_lifespan: float, non_productive_lifespan: float, weights: list = None
):
    plantation_productive_lifespan = (
        plantation_lifespan - non_productive_lifespan
        if all([plantation_lifespan, non_productive_lifespan])
        else None
    )

    included_keys = (
        set(non_empty_list([w.get("key") for w in weights])) if weights else None
    )

    def get_theoretical_ratio(key, phase_ratio_func):
        return phase_ratio_func(plantation_lifespan, plantation_productive_lifespan)

    phases = [
        {
            "key": "productive",
            "name": "Productive phase",
            "ratio": get_theoretical_ratio(
                "productive", _CALCULATE_PHASE_RATIO["productive"]
            ),
        },
        {
            "key": "non-productive",
            "name": "Non-productive phase",
            "ratio": get_theoretical_ratio(
                "non-productive", _CALCULATE_PHASE_RATIO["non-productive"]
            ),
        },
        {
            "key": "preparation",
            "name": "Preparation phase",
            "ratio": get_theoretical_ratio(
                "preparation", _CALCULATE_PHASE_RATIO["preparation"]
            ),
        },
    ]

    # only keep included ones for rescale
    rescale_phases = [
        p for p in phases if included_keys is None or p["key"] in included_keys
    ]
    total = sum(p["ratio"] for p in rescale_phases)

    def get_display_weight(phase):
        is_included = included_keys is None or phase["key"] in included_keys
        return (
            (
                phase["ratio"] / total
                if total > 0
                else 1 / len(rescale_phases) if len(rescale_phases) > 0 else 0
            )
            if is_included
            else 0
        )

    return ", ".join(
        [f"{p['name']}: {round(get_display_weight(p) * 100)}%" for p in phases]
    )


def _plantation_weight_description(product: dict, weights: list = None):
    plantation_lifespan = get_lookup_value({"term": product}, "Plantation_lifespan")
    non_productive_lifespan = get_lookup_value(
        {"term": product}, "Plantation_non-productive_lifespan"
    )
    return (
        _compute_plantation_weight_description(
            plantation_lifespan, non_productive_lifespan, weights
        )
        if all([plantation_lifespan, non_productive_lifespan])
        else None
    )


def cycle_weight_description(product: dict, weights: list = None):
    plantation = is_plantation(product)
    return (
        (
            "This aggregation uses the following weights: "
            + _plantation_weight_description(product, weights)
        )
        if plantation
        else None
    )
