import platform
import resource

from hestia_earth.utils.log import get_logger, log_join_args

logger = get_logger("hestia_earth.aggregation")


def log_memory_usage(**kwargs):
    factor = 1024 * (1024 if platform.system() in ["Darwin", "Windows"] else 1)
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / factor
    extra = (", " + log_join_args(**kwargs)) if len(kwargs.keys()) > 0 else ""
    logger.info("memory_used=%s, unit=MB" + extra, value)


def debugRequirements(**kwargs):
    logger.debug(log_join_args(**kwargs))


def _sum_values(values: list):
    """
    Sum up the values while handling `None` values.
    If all values are `None`, the result is `None`.
    """
    filtered_values = [v for v in values if v is not None]
    return sum(filtered_values) if len(filtered_values) > 0 else None


def debugWeights(weights: dict):
    total_weight = _sum_values(v.get("weight") for v in weights.values()) or 100
    for id, weight in weights.items():
        value = weight.get("weight")
        logger.debug(
            "id=%s, weight=%s, ratio=%s/%s",
            id,
            value * 100 / total_weight,
            value,
            total_weight,
        )
