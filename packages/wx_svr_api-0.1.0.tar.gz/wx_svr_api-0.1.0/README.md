# wx-svr-api

微信公众号服务端 API 封装：获取 `access_token`，支持从 `.env` 读取配置，以及可选的 Redis 缓存（TTL 7000 秒）。

- 源码：<https://github.com/easy-wx/wx-svr-ap>

## 安装

```bash
pip install wx-svr-api
```

## 用法

```python
from wx_svr_api import WxSvrApi

api = WxSvrApi.from_env()
token = api.get_access_token()
```

环境变量：`APPID`、`APPSECRET`；启用 Redis 缓存时配置 `REDIS_HOST`、`REDIS_PORT`、`REDIS_PASSWORD`、`REDIS_DB`。详见仓库内 `.env.example`。

## 文档

- [获取接口调用凭据（微信官方）](https://developers.weixin.qq.com/doc/subscription/api/base/api_getaccesstoken.html)
