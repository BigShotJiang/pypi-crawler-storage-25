"""微信公众号服务端 API 封装（获取 access_token）。

文档：https://developers.weixin.qq.com/doc/subscription/api/base/api_getaccesstoken.html
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import redis
import requests
from dotenv import load_dotenv
from redis.exceptions import RedisError

TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token"

# Redis 中 access_token 过期时间（秒），略小于官方 7200，避免边界过期
ACCESS_TOKEN_CACHE_TTL = 7000


class WxSvrApiError(Exception):
    """微信接口返回业务错误（含 errcode / errmsg）。"""

    def __init__(self, errcode: int, errmsg: str, raw: dict[str, Any] | None = None):
        self.errcode = errcode
        self.errmsg = errmsg
        self.raw = raw or {}
        super().__init__(f"[{errcode}] {errmsg}")


@dataclass(frozen=True)
class AccessToken:
    """getAccessToken 成功响应。"""

    access_token: str
    expires_in: int


def _redis_client_from_env() -> redis.Redis:
    """根据环境变量创建 Redis 客户端（decode_responses=True）。"""
    host = os.environ.get("REDIS_HOST", "127.0.0.1").strip() or "127.0.0.1"
    port = int(os.environ.get("REDIS_PORT", "6379"))
    password = os.environ.get("REDIS_PASSWORD")
    if password is not None:
        password = password.strip()
        if password == "":
            password = None
    db = int(os.environ.get("REDIS_DB", "0"))
    return redis.Redis(
        host=host,
        port=port,
        password=password,
        db=db,
        decode_responses=True,
    )


class WxSvrApi:
    """公众号后台接口调用封装（当前实现：获取全局 access_token，可选 Redis 缓存）。"""

    def __init__(
        self,
        appid: str,
        secret: str,
        *,
        session: requests.Session | None = None,
        timeout: float = 10.0,
        redis_client: redis.Redis | None = None,
    ):
        self._appid = appid
        self._secret = secret
        self._session = session or requests.Session()
        self._timeout = timeout
        self._redis = redis_client

    def _cache_key(self) -> str:
        return f"wx:mp:access_token:{self._appid}"

    @classmethod
    def from_env(
        cls,
        *,
        env_file: str | Path | None = None,
        session: requests.Session | None = None,
        timeout: float = 10.0,
        redis_client: redis.Redis | None = None,
        use_redis: bool = True,
    ) -> WxSvrApi:
        """
        从环境变量或 `.env` 读取 APPID、APPSECRET 并构造实例。
        默认加载当前工作目录下的 `.env`（可通过 env_file 指定路径）。
        use_redis 为 True 时按 REDIS_* 创建 Redis 客户端并启用缓存（可传入 redis_client 覆盖）。
        """
        load_dotenv(env_file)
        appid = os.environ.get("APPID", "").strip()
        secret = os.environ.get("APPSECRET", "").strip()
        if not appid or not secret:
            raise ValueError("APPID and APPSECRET must be set in environment or .env file")
        r = redis_client
        if r is None and use_redis:
            r = _redis_client_from_env()
        elif not use_redis:
            r = None
        return cls(appid, secret, session=session, timeout=timeout, redis_client=r)

    def _fetch_access_token_from_api(self) -> AccessToken:
        params = {
            "grant_type": "client_credential",
            "appid": self._appid,
            "secret": self._secret,
        }
        url = f"{TOKEN_URL}?{urlencode(params)}"
        resp = self._session.get(url, timeout=self._timeout)
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()

        if "errcode" in data and data.get("errcode", 0) != 0:
            raise WxSvrApiError(
                int(data["errcode"]),
                str(data.get("errmsg", "")),
                raw=data,
            )

        token = data.get("access_token")
        expires = data.get("expires_in")
        if not isinstance(token, str) or not isinstance(expires, int):
            raise WxSvrApiError(-1, "invalid response: missing access_token or expires_in", raw=data)

        return AccessToken(access_token=token, expires_in=expires)

    def get_access_token(self) -> AccessToken:
        """
        获取接口调用凭据：若配置了 Redis，则先读缓存，未命中再请求微信并写入 Redis（TTL 7000 秒）。

        :raises WxSvrApiError: 微信返回 errcode
        :raises requests.RequestException: 网络或 HTTP 层错误
        """
        if self._redis is not None:
            try:
                cached = self._redis.get(self._cache_key())
                if cached:
                    return AccessToken(access_token=cached, expires_in=ACCESS_TOKEN_CACHE_TTL)
            except RedisError:
                pass

        out = self._fetch_access_token_from_api()

        if self._redis is not None:
            try:
                self._redis.setex(self._cache_key(), ACCESS_TOKEN_CACHE_TTL, out.access_token)
            except RedisError:
                pass

        return out
