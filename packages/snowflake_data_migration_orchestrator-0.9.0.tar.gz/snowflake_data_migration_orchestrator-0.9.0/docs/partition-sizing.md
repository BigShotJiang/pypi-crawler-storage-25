# Partition Sizing (internal)

Shared calculator: `data_migration_cloud/tasks/handlers/partition_calculator.py`

## Six-factor model

`PartitionConfig` exposes six fields grouped into **targets** (user-configurable), **maxes** (internal / system-imposed), and **override**:

| Factor | Field | Meaning |
|--------|-------|---------|
| Target MB | `target_mb_per_partition` | Desired partition size in MB |
| Target rows | `target_rows_per_partition` | Desired partition size in rows |
| Max MB | `max_target_mb_per_partition` | Hard ceiling on partition MB |
| Max rows | `max_target_rows_per_partition` | Hard ceiling on partition rows |
| Max cells | `max_target_cells_per_partition` | Hard ceiling on cells per partition (rows × columns) |
| User override | `user_override` | When `True`, max caps are skipped entirely |

The two target fields are **mutually exclusive** at the user-config level (both DM and DV reject setting both). At runtime only one target is ever populated.

## Pipeline

1. **Target rows** — derived from whichever target is set (`target_rows_per_partition` directly, or `target_mb_per_partition / avg_row_mb`). Falls back to `row_count` (no split) when neither is set.
2. **Max rows** — `min(max_target_rows_per_partition, max_target_mb_per_partition / avg_row_mb, max_target_cells_per_partition / num_columns)`; tighter wins. Uncapped when none are set. **Skipped entirely when `user_override=True`.**
3. **Effective** — `min(target_rows, max_rows)`, at least 1. When `user_override=True`, effective equals target_rows.
4. **Partition count** — `ceil(row_count / effective)`, or 1 when `effective >= row_count`.

## Unified JSON contract

Both DM and DV now use camelCase field names:

| Field | Type | Description |
|-------|------|-------------|
| `columnNamesToPartitionBy` | `list[str]` | Columns to partition by |
| `targetPartitionSizeMb` | `int` | Target partition size in MB |
| `targetPartitionSizeRows` | `int` | Target partition size in rows |

**Auto mode**: omit both `targetPartitionSizeMb` and `targetPartitionSizeRows`. No `"auto"` string needed.

**User override**: when either `targetPartitionSizeMb` or `targetPartitionSizeRows` is explicitly set, the value is honored exactly without internal max caps.

## DM defaults

Resolved by `SmartPartitionConfigResolver` using platform/strategy profiles (auto mode only):

| Platform | Strategy | target MB | max MB |
|----------|----------|-----------|--------|
| Redshift | UNLOAD | 5 120 | 10 240 |
| Redshift | REGULAR | 2 048 | 5 120 |
| SQL Server | REGULAR | 1 024 | 2 048 |
| PostgreSQL | REGULAR | 1 024 | 2 048 |
| *(fallback)* | — | 2 048 | 5 120 |

When a user sets an explicit value, `user_override=True` is set and max caps are not applied.

## DV defaults

Set in `GenerateValidationQueriesHandler._create_partition_metadata` (auto mode only):

| Factor | Default | Condition |
|--------|---------|-----------|
| `target_mb_per_partition` | 200 MB | Always (auto mode) |
| `max_target_rows_per_partition` | 1 000 000 | Auto mode only |
| `max_target_cells_per_partition` | 4 000 000 | Auto mode + cell/hybrid `row_validation_mode` |

When a user sets `targetPartitionSizeRows` or `targetPartitionSizeMb`, `user_override=True` is set and max caps are not applied.

The cells limit is derived from the target table's column count via `INFORMATION_SCHEMA.COLUMNS`. It is only applied in auto mode when `row_validation_mode` is `cell` or `hybrid` and a `target_database` is configured.
