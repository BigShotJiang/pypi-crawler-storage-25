# Cloud Data Validation Workflow (engineering notes)

## CLI and Hatch scripts

- **Python:** `python -m data_migration_orchestrator create-data-validation-workflow <config.json> --source-platform <platform> [--name ...] [--connection-name ...]`
- **Hatch (from `data-migration-orchestrator/`):** `hatch run create-validation-workflow -- <config.json> --source-platform <platform> [extra args]`

Pass `--source-platform` on every invocation; its value must match `source_platform` in the JSON (the field remains required in the file for validation).

## Code map

| Area | Location |
|------|----------|
| CLI | `src/data_migration_orchestrator/commands/create_data_validation_workflow.py` |
| JSON schema (structural) | `data_validation_cloud/config/workflow_configuration_schema.py` |
| Parsed config / defaults | `data_validation_cloud/config/validation_configuration_parser.py` |
| Workflow initialization | `data_validation_cloud/data_validation_workflow_initializer.py` |
| Snowpipe result ingestion | `data_validation_cloud/utils/pipe_utils.py`, `utils/ensure_dv_pipe.py`, `tasks/snowpipe_flow.py`, `tasks/handlers/teardown_dv_snowpipe_handler.py`, shared helpers in `cloud_core/utils/pipe_utils.py` |
| Worker execution | `data-exchange-agent` — `tasks/data_validation/` (dispatched from `tasks/manager.py` for `data_validation` tasks) |

## Dependencies

- Orchestrator packages include validation modules in-repo.
- Workers need **`snowflake-data-validation`** installed to run validation tasks (row/cell/schema/metrics), in addition to source ODBC drivers as appropriate.

## Metadata layout

- Workflow rows for validation use `WORKFLOW_TYPE = 'data-validation'` in the **data migration** metadata schema (default `SNOWCONVERT_AI.DATA_MIGRATION`), same `WORKFLOW` table as migrations.
- Result tables and validation-specific objects live under the **data validation** schema (default `SNOWCONVERT_AI.DATA_VALIDATION`), controlled by `CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA`.

## Partition sizing (`partition_column`)

Handler: `data_validation_cloud/tasks/handlers/generate_validation_queries_handler.py` (`_create_partition_metadata`). Shared calculator: `data_migration_cloud/tasks/handlers/partition_calculator.py`.

Both DM and DV use the same unified four-factor pipeline in `PartitionCalculator`:

1. **Target rows** — derived from whichever user-configurable target is set (`target_rows_per_partition` directly, or `target_mb_per_partition / avg_row_mb`). The two are **mutually exclusive**. Falls back to `row_count` (no split) when neither is set. DV defaults to **200 MB** target.
2. **Max rows** — `min(max_target_rows_per_partition, max_target_mb_per_partition / avg_row_mb)` — internal system limits (not user-configurable). DV enforces **1 000 000** max rows; DM uses platform-specific max MB values.
3. **Effective** — `min(target_rows, max_rows)`, at least 1.
4. **Count** — `ceil(row_count / effective)` when `effective < row_count`, else 1.

## Result ingestion: Snowpipe vs. COPY INTO

L2 (metrics) and L3 (row / cell / hybrid) results are written to the shared
per-workflow results tables — `METRICS_VALIDATION_RESULTS`,
`ROW_VALIDATION_RESULTS`, `ROW_VALIDATION_SUMMARY`, `CHUNK_HASHES` and
`CELL_VALIDATION_RESULTS`. Two loading modes are available, selected by the
workflow-level `use_snowpipe_for_results` flag (default `true`):

- **Snowpipe mode** (`use_snowpipe_for_results = true`):
  - There is **one temporary Snowpipe per `(workflow_id, DvResultsPipeKey)`**
    (METRICS, ROW_DIFFS, ROW_SUMMARY, CHUNK_HASHES, CELL_DIFFS) living in
    the shared `TEMP` schema, named
    `DVO_PIPE_<WORKFLOW_ID>_<KEY>` (see
    `data_validation_cloud/utils/pipe_utils.py`). Concurrent workflows
    therefore never share a pipe, so `SYSTEM$PIPE_STATUS.pendingFileCount`
    is a reliable drain signal.
  - Pipes are created synchronously and torn down via an orchestrator
    cleanup task. On the first
    `ensure_dv_pipe(task_queue, warehouse, workflow_id, key)` call per
    process for a given `(workflow_id, key)`, the helper:
    * runs `CREATE PIPE IF NOT EXISTS` inline through the warehouse proxy
      (DV pipes are monitored via `SYSTEM$PIPE_STATUS` drain mode, so
      `LOG_EVENT_LEVEL` is left at the account default), and only after
      the DDL succeeds does it
    * push a `TEARDOWN_DV_SNOWPIPE` cleanup task (`.blocked().cleanup()`)
      that runs `DROP PIPE IF EXISTS` after every non-cleanup task
      terminates, even on failure.
    Doing the create synchronously guarantees the pipe exists before any
    DEA partition task pushed afterwards can issue `ALTER PIPE … REFRESH`
    against it. A process-local cache keyed by `(workflow_id, key)`
    prevents duplicate creates/teardowns within a process; cross-process
    duplicates are harmless because both DDL statements are idempotent.
  - Each pipe's `FROM` clause watches the whole validation stage root and
    uses a `PATTERN` regex that embeds the `workflow_id` so only files
    from this workflow's subtree are eligible. DEA partition tasks upload
    CSVs to the partition stage path and, after the upload succeeds, issue
    `ALTER PIPE ... REFRESH PREFIX='<workflow>/<table>/<level>/p<N>/...'`
    for every pipe attached to their payload (`result_pipes`).
  - Each pipe has a single drain task (`executor = SNOWPIPE`, `mode = drain`)
    per workflow level that polls `SYSTEM$PIPE_STATUS` until
    `pendingFileCount == 0`. Drain tasks are chained so that the DEA tasks
    fan in on the first drain, drains chain sequentially, and the last
    drain unblocks the `Evaluate` task. See
    `data_validation_cloud/tasks/snowpipe_flow.py`.
- **COPY INTO mode** (`use_snowpipe_for_results = false`):
  - Retains the original per-partition chain where each DEA task is
    followed by a `Write validation results` (`COPY INTO`) task, and all
    write tasks fan in to a single `Evaluate` task.

### Task chain after the change (L3 row, 2 partitions, Snowpipe mode)

> Pipes are created synchronously by `ensure_dv_pipe` while the planning
> task runs (before any node below is pushed to the queue), so they do
> not appear as task nodes in the chain.

```mermaid
graph LR
    V1[Validate L3 p0 DEA + ALTER PIPE REFRESH] --> D1[Drain ROW_DIFFS SNOWPIPE]
    V2[Validate L3 p1 DEA + ALTER PIPE REFRESH] --> D1
    D1 --> D2[Drain ROW_SUMMARY SNOWPIPE]
    D2 --> D3[Drain CHUNK_HASHES SNOWPIPE]
    D3 --> E[Evaluate L3 ORCH]
    E -. cleanup .-> T1[Teardown ROW_DIFFS]
    E -. cleanup .-> T2[Teardown ROW_SUMMARY]
    E -. cleanup .-> T3[Teardown CHUNK_HASHES]
```

> **Updating a pipe.** DV pipes are per-workflow and are dropped by the
> Teardown cleanup task at the end of each workflow, so you can change
> `build_create_pipe_sql` freely - every new workflow picks up the new
> DDL. No versioning or manual cleanup is required.

## User-facing reference

The public **README.md** documents the JSON fields and defaults (including partitioning and `use_snowpipe_for_results`). A minimal example file lives at `docs/public/example-workflows/example-data-validation-workflow.json`.
