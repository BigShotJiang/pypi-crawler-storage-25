# Incremental Sync (Design Spec)

## Status Quo
Previously, Data Migration Orchestrator supported only one-shot data migration. This involved steps/tasks such as:
1. Extract Metadata for Table
2. Determine Strategy for Partitioning (multiple partitions or single partition)
3. Analyze Boundaries for partitions (when using multiple partitions)
4. Extract data for each partition
5. Load the data for each partition

## Problem Statement
Instead of supporting only one-shot data migration, we are now supporting incremental sync, which behaves something like this:
1. Customer decides to migrate/sync a table.
2. The data is migrated using Data Migration Orchestrator.
3. We record some metadata about the data that was moved.
3. Some time passes.
4. Customer decides to migrate/sync a table.
5. The metadata for each partition is analyzed and only the data that has been changed is moved to the new partition.
6. Metadata is updated again.

This is currently supported for WATERMARK and CHECKSUM strategies. Customers must explicitly opt-in to incremental sync by configuring a synchronization strategy.

## High-Level Proposal
The tasks that we have needed to be framed differently. Instead of focusing on one-shot data migration, we needed to focus on all data migration being "incremental".
This can be framed with steps/tasks this way:
1. Extract Metadata for Table.
2. Determine Strategy for Partitioning (if it has not been determined already).
3. Analyze Boundaries for partitions (unless partitions have not been already defined).
4. Extract & Load each partition (actually this is composed of many steps/tasks that will depend on the synchronization strategy)
5. When marking the partition as loaded, we should also update the synchronization metadata for that 

Synchronizing a partition is done differently depending on the synchronization strategy. We have these synchronization strategies:
1. NONE: No incremental sync, always perform full partition extraction (default)
2. CHECKSUM: Remove the partition and move it again if there was a change on it (detected through checksums)
3. WATERMARK: Look at all the rows (in a partition) that have a greater value than the greater value observed during the last sync of this partition (on a specific column). For example, to move all the rows with UPDATED_AT greater than 2020-02-20, if that was the greater value that was observed during last sync.
4. CHANGE_TRACKING: Look at a specific table to understand which rows (in a partition) have changed since the last sync. Through a JOIN, all rows that have changed are selected and can be updated in the target table.

**Note:** `CHANGE_TRACKING` is design documentation only. It is **not** part of the shipped workflow JSON schema. Customer-facing configuration supports `none`, `checksum`, and `watermark` only (see the orchestrator README).

We currently support NONE, WATERMARK, and CHECKSUM strategies.

## Considerations
1. Once a partition strategy has been defined, it stays like that.
2. The metadata for each partition must be recorded in the PARTITION_METADATA table. There should be a VARIANT column SYNCHRONIZATION_DATA that will be different depending on the synchronization strategy. For example, in the case of CHECKSUM, it will include the CHECKSUM for the entire partition.
3. The metadata for each table/partition is associated with a specific workflow. However, when the same table from another workflow is being migrated, then the metadata for the table and the partitions will be copied. Each partition has a date at which sync happened, as well as the sync metadata. So new workflows can decide whether a partition needs to be updated (and which records must be updated). 
4. In the future, we might split partitions that have more data than expected (and we will also make sure to have our partitions covering the entire range of possible values). For now, disregard this.
5. Leverage the existing `SyncStrategy` enum when dealing with synchronization flows.

## Configuration

The synchronization strategy can be configured per-table in the workflow configuration. Each table entry can include an optional `synchronization` object that specifies how incremental sync should be performed.

### Schema

```json
{
  "tables": [
    {
      "source": { ... },
      "target": { ... },
      "primaryKeyColumns": ["<column_name>", ...],  // Optional, required when trackModifications is true
      "synchronization": {
        "strategy": "none" | "watermark" | "checksum" | "change-tracking",
        "watermarkColumn": "<column_name>",  // Required for watermark strategy
        "trackModifications": true | false   // Optional, enables deduplication for watermark strategy
      }
    }
  ]
}
```

### Strategy Options

#### None Strategy (Default)

No incremental sync is performed. Every migration performs a full extraction of all partition data. No synchronization metadata is stored. This is the default behavior and is suitable for one-shot migrations or when incremental sync overhead is not desired.

```json
{
  "synchronization": {
    "strategy": "none"
  }
}
```

#### Watermark Strategy

Uses a column (typically a timestamp like `UPDATED_AT` or `MODIFIED_DATE`) to identify rows that have changed since the last sync. Only rows with a watermark value greater than the last observed maximum are synced.

**Basic configuration (new rows only):**
```json
{
  "synchronization": {
    "strategy": "watermark",
    "watermarkColumn": "UPDATED_AT"
  }
}
```

**With modification tracking (handles updated rows):**

When `trackModifications` is enabled, the system will deduplicate rows after COPY INTO by removing old versions of modified rows, keeping only the latest version based on the watermark column. This requires `primaryKeyColumns` to be specified at the table level.

```json
{
  "source": { ... },
  "target": { ... },
  "primaryKeyColumns": ["ID"],
  "synchronization": {
    "strategy": "watermark",
    "watermarkColumn": "UPDATED_AT",
    "trackModifications": true
  }
}
```

#### Checksum Strategy

Computes a checksum (hash of all column values) for each partition and compares it with the stored checksum from the previous sync. If the checksum has changed, the entire partition is cleared and re-synced. Checksums are computed on every sync (including the first-time sync) to store the baseline for future comparisons.

See [checksum-computation.md](./checksum-computation.md) for platform-specific implementation details.

```json
{
  "synchronization": {
    "strategy": "checksum"
  }
}
```

#### Change Tracking Strategy (Future)

Uses a change tracking table to identify specific rows that have changed. Configuration for this strategy is more complex and will be defined in a future iteration.

### Default Behavior

If no `synchronization` configuration is provided, the system defaults to the `none` strategy, which performs full partition extraction without any incremental sync logic.

## Different Strategies

### None
#### Summary
With NONE strategy, every migration performs a full extraction of all partition data. No synchronization metadata is stored or compared. This is the simplest mode and has no incremental sync overhead.

#### Specific Changes
No special handling required. The standard extraction chain (EXTRACT -> LOAD) is used for all partitions.

### Watermark
#### Summary
We will retain the same chain of tasks, but the queries for extracting data will have a WHERE clause so that we only extract the rows for which the watermark column (specified in the configuration) has a value that is greater than the max value observed in that watermark column during the last synchronization. 

#### Specific Changes
1. When selecting data for each partition, the watermark is used to filter only the values that have changed.
2. After extraction of the partition data, before submitting the COPY INTO statement, select the max value for the watermark column of that partition. This is done with a SELECT in Snowflake, directly from the file (CSV or Parquet, or any other format). This value is set in the SYNCHRONIZATION_DATA VARIANT object in the PARTITION_METADATA table, with the key `candidate_max_watermark_value`.
3. If `trackModifications` is enabled, after COPY INTO completes, execute a DEDUPLICATE_PARTITION_DATA task that removes duplicate rows by keeping only the latest version (based on watermark column) for each primary key.
4. When completing the partition migration, also modify the SYNCHRONIZATION_DATA VARIANT object in the PARTITION_METADATA table. Update `max_watermark_value` with the value of `candidate_max_watermark_value` and then remove `candidate_max_watermark_value`. This ensures that the `max_watermark_value` is only updated in the migration of data was successful for this partition.

**Task Chain:**
- Without `trackModifications`: EXTRACT -> LOAD -> COPY_INTO -> COMPLETE_PARTITION_MIGRATION
- With `trackModifications`: EXTRACT -> LOAD -> COPY_INTO -> DEDUPLICATE_PARTITION_DATA -> COMPLETE_PARTITION_MIGRATION


#### Support for Modifications
Moving modified rows is a bit more complex than moving added rows, since we need to get rid of the previous version of the row. Our approach is to "deduplicate" duplicate rows after COPY INTO completes. We need a primary key and, after moving the new data, we remove duplicates by keeping only the row with the greatest watermark value for each primary key.

The deduplication query uses Snowflake's DELETE...USING pattern:
```sql
DELETE FROM target_table AS target
USING (
    SELECT primary_key_column, MAX(watermark_column) AS max_watermark
    FROM target_table
    WHERE <partition-range-condition>
    GROUP BY primary_key_column
) AS winners
WHERE target.primary_key_column = winners.primary_key_column
  AND target.watermark_column < winners.max_watermark
```

**How it works:**
1. The subquery finds the maximum watermark value for each primary key within the partition
2. The DELETE removes all rows where the watermark is less than the max for that primary key
3. Rows with the highest watermark (latest version) are preserved
4. If multiple rows share the same max watermark (ties), all are kept. In practice, this should not happen.

The `<partition-range-condition>` scopes the operation to the current partition only.

#### Considerations
- Modified rows are handled by enabling `trackModifications`, which deduplicates rows by primary key after COPY INTO, preserving the latest version based on the watermark column.
- Deleted rows are more complex and not currently supported. Consider using CHECKSUM strategy or CHANGE_TRACKING (future) for tables with deletions.

### Checksum
#### Summary
We will retain a very similar chain of tasks. The main difference is that, when incrementally syncing partitions, we will need to check which partitions have changed by looking at a `checksum` value that is computed per partition. This will normally involve hashing the values of all columns in all rows in that partition. For partitions that have changed, we wipe the current data and then copy them.

**Important**: Checksums are always computed, even on the first-time sync, so that the baseline checksum is available for future incremental syncs.

#### Specific Changes
1. We have to change the chain of tasks created for each partition. For each partition there is an initial task (COMPARE_CHECKSUM) used to compute the current checksum and determine if it has changed.
2. The COMPARE_CHECKSUM task dynamically creates subsequent tasks based on the comparison result:
   - If checksum has not changed (and we have a stored checksum), we immediately mark the synchronization as successful. No extraction tasks are created.
   - If checksum has changed (or this is the first-time sync with no stored checksum), we create the extraction chain: EXTRACT -> CLEAR_PARTITION_DATA -> LOAD. If the target table does not exist yet, the clear step completes without running DELETE.
3. The computed checksum is stored as `candidate_checksum` in SYNCHRONIZATION_DATA before extraction begins.
4. If extraction succeeded, then we promote `candidate_checksum` to `checksum` in the SYNCHRONIZATION_DATA VARIANT object in the column SYNCHRONIZATION_DATA of the PARTITION_METADATA table (in the appropriate row).

We should still use common building blocks instead of rewriting them, but some tasks will be particular to this workflow.

#### Considerations
We will need to generate a checksum value for an entire partition. This involves writing a query that hashes all columns of all rows in that partition. Some columns might need transformations before being hashed (normalization, for example).

See [checksum-computation.md](./checksum-computation.md) for the platform-specific checksum algorithms and column type handling.

### Change Tracking
TODO (in the future, for now, let's ignore this)
