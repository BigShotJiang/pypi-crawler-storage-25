# CONTRIBUTING

## Code Organization
Data Migration Orchestrator is organized in these main modules:
- `utils`: Utils that can be imported from anywhere.
- `cloud_core`: Core for Cloud operations, which includes definitions for Workflows and Tasks.
- `data_migration_core`: Core for Data Migration, which includes platform-agnostic logic.
- `data_migration_cloud`: Workflows Initializers, Task, and Task Handlers for Data Migration Workflows.
- `data_validation_core`: Constants and small shared pieces for Cloud Data Validation.
- `data_validation_cloud`: Workflows Initializers, Task Handlers, and related code for Data Validation Workflows (may import selected helpers from `data_migration_cloud`).
- `cloud_orchestrator`: The Orchestrator itself, which consumes the other modules to support the execution of Workflows of any kind.
- `commands`: CLI entry subcommands (`start`, workflow creation).

These modules follow a layered architecture with strict import rules. An arrow from module A to module B means that A can import from B. Colors represent the architecture layers:
- 🔵 **Blue**: Orchestration layer (`cloud_orchestrator`, `commands`)
- 🟢 **Green**: Migration logic layer (`data_migration_cloud`) and validation logic layer (`data_validation_cloud`)
- 🟠 **Orange**: Core components layer (`cloud_core`, `data_migration_core`, `data_validation_core`)
- 🟣 **Purple**: Foundation layer (`utils`)

![Module Dependencies](docs/diagrams/module-dependencies.png)

To refresh the PNG after editing the diagram source: `docs/diagrams/module-dependencies.mmd` (for example `npx @mermaid-js/mermaid-cli -i module-dependencies.mmd -o module-dependencies.png` from that directory).

## Commands

The orchestrator CLI supports multiple subcommands. When no subcommand is given, `start` is assumed for backward compatibility.

### Starting the Orchestrator
```bash
hatch run start
```

### Creating a Data Migration Workflow
Validate a data migration workflow configuration file and insert it into the `WORKFLOW` table:
```bash
hatch run create-migration-workflow <config-file> [--connection-name <name>] [--name <workflow-name>] [--source-platform <platform>]
```

| Option | Default | Description |
|--------|---------|-------------|
| `config_file` | *(required)* | Path to the JSON workflow configuration file |
| `--connection-name` | env vars | Snowflake connection name (see [Connection Management](#connection-management)) |
| `--name` | `MY_WORKFLOW` | Name for the workflow record |
| `--source-platform` | *(required)* | Source platform: `sqlserver`, `redshift`, or `postgresql` |

The command reads `affinity` from the configuration file itself (the top-level `affinity` field).

Example:
```bash
hatch run create-migration-workflow workflow-config.json --connection-name MY_CONN --name prod_migration --source-platform sqlserver
```

### Creating a Data Validation Workflow
Validate a Cloud Data Validation JSON config and insert a row with `WORKFLOW_TYPE = 'data-validation'`:
```bash
hatch run create-validation-workflow <config-file> --source-platform <platform> [--connection-name <name>] [--name <workflow-name>]
```

| Option | Default | Description |
|--------|---------|-------------|
| `config_file` | *(required)* | Path to the JSON data validation workflow configuration |
| `--connection-name` | env vars | Snowflake connection name |
| `--name` | `MY_VALIDATION_WORKFLOW` | Name for the workflow record |
| `--source-platform` | *(required)* | Source platform identifier; must match the `source_platform` value in the JSON configuration file. |

See [`docs/data-validation-workflow.md`](docs/data-validation-workflow.md) for module layout and metadata notes.

### Linting
Run linting with [ruff](https://docs.astral.sh/ruff/):
```bash
# Run lint checks (with auto-fix)
hatch run linter:check
```

### Type Checking
Run static type checking with [ty](https://docs.astral.sh/ty/) (extremely fast Python type checker from Astral):
```bash
# Check all source code
hatch run types:check-ty

# Check specific path
hatch run types:check-ty tests

# Watch mode - automatically re-checks on file changes
hatch run types:watch-ty
```

You can also run type checking with mypy:
```bash
hatch run types:check
```

### Import Validation
Check that you're not violating the rules of the dependencies between the main modules described in [Code Organization](#code-organization):
```bash
./scripts/validate_imports.py
```

### ty Diagnostics Baseline

The project uses a **diagnostics baseline** to prevent type error regressions. The CI will fail if the number of `ty` diagnostics increases beyond the baseline.

| Project | Baseline |
|---------|----------|
| data-migration-orchestrator | 35 |

To check diagnostics locally:
```bash
python .github/scripts/ty_check_diagnostics.py data-migration-orchestrator
```

If you **fix** type errors and reduce the count, please update the baseline in:
- `.github/workflows/data-migration-orchestrator-all-ci.yml`
- `.github/scripts/ty_check_diagnostics.py` (DEFAULT_BASELINES)

### Testing
Run the test suite:
```bash
# Run all tests with coverage
hatch run test_all.py3.11:check

# Run tests only
hatch run test_all.py3.11:unit
```

### CI Workflows

The following checks run automatically on PRs and pushes to `main`/`develop`:

1. **Linting** - Static analysis with ruff
2. **Type Check** - ty diagnostics baseline check
3. **Unit Tests** - pytest on Python 3.11 and 3.12 with coverage

## Docker

### Commands
Build image:
```bash
hatch run docker-build
```

Alternatively, build directly with Docker from the **parent directory** (required due to shared module dependencies):
```bash
# From the migrations-data-validation directory (parent)
docker build -f data-migration-orchestrator/Dockerfile -t data-migration-orchestrator:latest .
```

Run container:
```bash
hatch run docker-run
```

Interactive mode (debugging):
```bash
hatch run docker-run-interactive
```

### Setup
1. Create environment file from template:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` with your Snowflake credentials:
   ```env
   SNOWFLAKE_ACCOUNT=your_account
   SNOWFLAKE_USER=your_user
   SNOWFLAKE_PASSWORD=your_password
   SNOWFLAKE_WAREHOUSE=your_warehouse
   SNOWFLAKE_DATABASE=your_database
   SNOWFLAKE_SCHEMA=your_schema
   ```

3. Build and run:
   ```bash
   hatch run docker-build
   hatch run docker-run
   ```

### Connection Management
The application automatically detects the environment:

- **Local**: Uses credentials from `.env` file (via `SNOWFLAKE_ACCOUNT`, `SNOWFLAKE_USER`, `SNOWFLAKE_PASSWORD`, etc.)
- **SPCS**: Automatically uses Snowflake-injected credentials (OAuth)

No code changes needed when deploying to Snowflake Container Services (SPCS).

## End-to-End Flow
For testing the end-to-end flow, with one **Data Migration Orchestrator** running and one (or more) **Data Exchange Agents**, we have the following options:
1. Running all components locally.
2. Running all components in SPCS.
3. Mixed approach: running some components locally and other SPCS.

### Running all components locally
#### Starting the Data Migration Orchestrator
These steps will start the **Data Migration Orchestrator** locally, and when that is orchestrated, the corresponding resources in the Snowflake account will also be set up. That will allow you to start **Data Exchange Agents** in the same account.
*<snowflake-connection-name>* must be the name of the connection you want to use, as it appears on your `config.toml`/`connections.toml`.
1. Go to the `data-migration-orchestrator` directory (`cd data-migration-orchestrator`).
2. `export SNOWFLAKE_CONNECTION_NAME=<snowflake-connection-name>`.
3. `export DATA_MIGRATION_ORCHESTRATOR_AFFINITY=<affinity>` (this is optional, but is recommended for local development, to avoid confusion with multiple orchestrator instances from different devs). Supports wildcard patterns (e.g. `my-team-*` matches workflows with affinity `my-team-blue`, `my-team-red`, etc.).
4. `hatch run start` to start the program (it can also be started from the **VS Code** debugger just by clicking **Run and Debug** while being on the `main.py` file for this project).

#### Starting the Data Exchange Agent
These steps will start the **Data Exchange Agent** locally. They must be performed after the corresponding resources have been set up in the Snowflake account (which is done when the **Data Migration Orchestrator** starts).
1. Go to the `data-exchange-agent` directory (`cd data-exchange-agent`)
2. Create a `configuration.toml` file in the `data-exchange-agent` (it will be ignored by **Git**). there is a `configuration_example.toml` file in that same directory, which can be used as an example. A minimal configuration is also shown below.
3. `hatch run data-exchange-agent` to start the program (it can also be started from the **VS Code** debugger just by clicking **Run and Debug** while being on the `main.py` file for this project).

Example minimal config:
```toml
selected_task_source = "snowflake_stored_procedure"

[task_source.snowflake_stored_procedure]
connection_name = <snowflake-connection-name>

[application]
workers = 1
task_fetch_interval = 5s
debug_mode = false
affinity = <affinity>

[connections.target.snowflake_connection_name]
connection_name = <snowflake-connection-name>

[connections.source.sqlserver]
username = <sql-server-username>
password = <sql-server-password>
database = <sql-server-database-name>
host = <sql-server-host>
port = 1433
```

#### Creating a Workflow
Prepare a `workflow-config.json` (see the [Workflow Configuration Reference](README.md#workflow-configuration-reference) in the README for the configuration format). The `affinity` field inside the config must match the affinity you are using for the **Data Exchange Agent**.

```bash
hatch run create-migration-workflow workflow-config.json --connection-name <snowflake-connection-name> --source-platform sqlserver
```

This validates the configuration and creates a new record in the `SNOWCONVERT_AI.DATA_MIGRATION.WORKFLOW` table. If `--connection-name` is omitted, the connection from `SNOWFLAKE_CONNECTION_NAME` (or other env vars) is used.

### Running all components in SPCS
#### Starting the Data Migration Orchestrator
You must run the `./data-migration-orchestrator/scripts/upload-orchestrator.sh` script (on the root of the repository). This will update the image for the **Data Exchange Agent** and push it to the image registry on the Snowflake account. This script takes an optional `--connection` parameter that receives the name of the Snowflake connection. If not provided, the default will be used.

Then, execute this in the Snowflake account:
```sql
CREATE SERVICE IF NOT EXISTS SNOWCONVERT_AI.DATA_MIGRATION.DATA_MIGRATION_SERVICE
IN COMPUTE POOL <compute-pool-name>
FROM SPECIFICATION 
$$
spec:
  containers:
  - name: orchestrator
    image: /SNOWCONVERT_AI/PUBLIC/IMAGES/data-migration-orchestrator:latest
    env:
      SNOWFLAKE_WAREHOUSE: <warehouse>
    resources:
      requests:
        memory: 2Gi
        cpu: 0.5
$$
QUERY_WAREHOUSE = <warehouse>;
```

#### Starting the Data Exchange Agent
You must run the `./data-exchange-agent/scripts/upload-agent.sh` script (on the root of the repository). This will update the image for the **Data Exchange Agent** and push it to the image registry on the Snowflake account. This script takes an optional `--connection` parameter that receives the name of the Snowflake connection. If not provided, the default will be used.

Then, execute this in the Snowflake account:
```sql
-- 1 Create secret and grant usage over it (Source System)
CREATE OR REPLACE SECRET MY_DB.SECRETS.SQL_SERVER_PASSWORD
  TYPE = PASSWORD
  USERNAME = <sql-server-username>
  PASSWORD = <sql-server-password>;

GRANT USAGE ON SECRET MY_DB.SECRETS.SQL_SERVER_PASSWORD TO ROLE <data-migration-role-name>;

-- 2. Create network rule
CREATE OR REPLACE NETWORK RULE MY_DB.SECRETS.SQL_SERVER_PASSWORD
  MODE = EGRESS
  TYPE = HOST_PORT
  VALUE_LIST = ('<sql-server-host>');

-- 3. Create External Access Integration
CREATE OR REPLACE EXTERNAL ACCESS INTEGRATION SQL_SERVER_INTEGRATION
  ALLOWED_NETWORK_RULES = (DM_DEMO_AZURE_SQL_EGRESS_RULE)
  ENABLED = TRUE;

GRANT USAGE ON INTEGRATION SQL_SERVER_INTEGRATION TO ROLE <data-migration-role-name>;

-- 4. Create Service
CREATE SERVICE SNOWCONVERT_AI.DATA_MIGRATION.DATA_EXCHANGE_SERVICE
  IN COMPUTE POOL <compute-pool-name>
  FROM SPECIFICATION $$
    spec:
      containers:
        - name: agent
          image: /snowconvert_ai/public/images/data-exchange-agent:latest
          env:
            # Source System Config
            DATA_SOURCE_HOST: <sql-server-host>
            DATA_SOURCE_PORT: <1433>
            DATA_SOURCE_DATABASE: <sql-server-database>

            # Snowflake Config
            SNOWFLAKE_WAREHOUSE: <snowflake-warehouse>
            
            # Application
            WORKER_COUNT: 1
            AGENT_AFFINITY: <affinity>
            
          secrets:
            # Secrets (Source System)
          - snowflakeSecret: MY_DB.SECRETS.SQL_SERVER_PASSWORD
            secretKeyRef: USERNAME
            envVarName: DATA_SOURCE_USERNAME
          - snowflakeSecret: MY_DB.SECRETS.SQL_SERVER_PASSWORD
            secretKeyRef: PASSWORD
            envVarName: DATA_SOURCE_PASSWORD
  $$
  -- This line links the network hole to the service
  EXTERNAL_ACCESS_INTEGRATIONS = (SQL_SERVER_INTEGRATION)
  MIN_INSTANCES = 6
  MAX_INSTANCES = 6;
```

#### Creating a Workflow
Creating a workflow is the same independently of where the components are deployed (see [Creating a Workflow](#creating-a-workflow-1) above). Use `hatch run create-validation-workflow` for data validation configs.

### Mixed approach
You can combine the two approaches and run only the **Data Exchange Agent** locally and the **Data Migration Orchestrator** in SPCS (or the other way around). There is no significant difference when doing this.

## Keeping Documentation up to Date
When adding/modifying features, update the corresponding documentation:
- **README.md** is the user-facing source of truth (architecture, usage, configuration reference).
- **CONTRIBUTING.md** (this file) has developer content (commands, Docker, E2E, CI).
- The [Data Exchange Agent README](../data-exchange-agent/README.md) is the source of truth for Worker Configuration.
- Cursor rules and commands should be kept synchronized with the docs.

When changing configuration models or behavior, update the README's configuration reference and the example workflow files in `docs/public/example-workflows/` (including `example-data-validation-workflow.json` for validation).

## Snowflake Query Tagging

Every Snowflake query issued by the orchestrator carries a `QUERY_TAG` session parameter (a compact JSON string). This makes individual queries attributable in Snowflake's `QUERY_HISTORY`.

### Tag Categories

| Category | When | Tag contents |
|----------|------|-------------|
| **Baseline / infrastructure** | Lease refresh loop, task pull loop, startup | `{"DMVF_VERSION":"<orchestrator-version>"}` |
| **Task-processing** | Inside `_execute_task_with_context()` | `{"DMVF_WORKFLOW_ID":"…","DMVF_TASK_ID":"…","DMVF_ORCHESTRATOR_VERSION":"<orchestrator-version>"}` |

### How It Works

1. **Baseline tag** — After creating a thread's connection context (in `_lease_refresh_loop`, `_task_pull_loop`, and `make_worker_context()`), `set_query_tag()` is called with `DMVF_VERSION`.
2. **Task-level tag** — Before `_execute_task_with_context()`, the tag is overwritten with workflow/task IDs and `DMVF_ORCHESTRATOR_VERSION`. A `finally` block restores the baseline.

### Adding New Snowflake Queries

When writing new code that executes Snowflake queries:

- If the query runs **inside** `_execute_task_with_context()`, the task-level tag is already active — no action needed.
- If you add a **new background loop or thread** that issues Snowflake queries, set the baseline version tag on its connection after context creation (follow the pattern in `_lease_refresh_loop` / `_task_pull_loop`).
- Always use `set_query_tag()` and `build_query_tag()` from `cloud_core.query_tag` to construct and apply tags. Never hand-craft JSON or SQL for the `QUERY_TAG` parameter.

## Development Patterns
### Task Model
In the **Data Migration Orchestrator** we distribute work by converting workflows into sequences of many tasks:
- Distributing the work in tasks help us achieve fault-tolerance, distribute the workload across several workers, and have "resumability".
- These tasks can have successors/predecessors and be executed by different components of the architecture.
- We strive for tasks to be idempotent, retryable, and moderately "quick" to execute. This might not always be achievable.
- No specific executor is assigned to a task, although a specific executor type will be assigned depending on the kind of the task.
- Each task has a payload that depends on the kind of the task. There are no guarantees on the time at which a task will be executed. Because of that, we can't assume that a sucessor task will be executed immediately after its predecessor (hours/days could have passed since).

When adding features to the Orchestrator, consider this task model. For more information, you can visit the `task-model.md` document.

### Creating/Queuing Tasks
Create tasks using the `TaskBuilder` class and then queue them using the `TaskQueue`. When creating sequences of dependent tasks, you can use the `push_task_chain` method of the `TaskQueue`.

### Manipulating Stage Paths
We constantly are putting data/metadata into files in different paths of stages and then reading that data/metadata (or copying it into tables). For example, the default internal stage is `SNOWCONVERT_AI.DATA_MIGRATION.TASK_RESULTS` and we normally upload metadata/data of the tables we're moving.

We try to avoid passing stage paths through task payloads. Instead, we try to have a standardize pattern for stage paths. For example, if you want to access the path at which the schema information for a table was uploaded, then it might look something like this: `<stage-id>/workflows/<workflow-id>/table/<table-metadata-id>/schema/`.

### Scopes
Scopes are described in detail in the `scopes.md` doc. Those are useful for understanding what is the purpose of each task and to what "domain" it applies.

When creating scopes, we should use the `ScopeBuilder`. There are other helper functions that can be used when creating scopes (specially if the scope is very commonly created).

### Schema Migrations
When changing the schema (tables in the `SNOWCONVERT_AI.DATA_MIGRATION` schema, for example), we should do it through schema migrations. Check the `schema-migrations.md` doc for more information about this topic.

### Data Validation Snowpipes (per-workflow, temporary)
The DV result ingestion Snowpipes (`DVO_PIPE_<WORKFLOW_ID>_<KEY>` in the shared `TEMP` schema) are **scoped to a single workflow and cleaned up automatically**. `ensure_dv_pipe(task_queue, warehouse, workflow_id, key)` in `data_validation_cloud/utils/ensure_dv_pipe.py` runs `CREATE PIPE IF NOT EXISTS` synchronously through the warehouse proxy on first use for each `(workflow_id, key)` pair, and only after the DDL succeeds does it push a `TEARDOWN_DV_SNOWPIPE` cleanup task (`.blocked().cleanup()`, runs `DROP PIPE IF EXISTS`) — guaranteeing the pipe exists before any DEA partition task pushed afterwards can `ALTER PIPE … REFRESH` against it. A process-local cache prevents duplicate creates/teardowns within a process; cross-process duplicates are harmless because both DDL statements are idempotent. DV pipes are monitored via `SYSTEM$PIPE_STATUS` drain mode, so — unlike the DMO migration pipes — their `LOG_EVENT_LEVEL` is left at the account default.

Each pipe's `PATTERN` embeds the `workflow_id`, so concurrent workflows never ingest each other's files and `SYSTEM$PIPE_STATUS.pendingFileCount` is a reliable drain signal.

Because the pipe is dropped at the end of every workflow, you can change `build_create_pipe_sql` freely — every new workflow picks up the new DDL. No versioning, no manual cleanup.

## Anti-patterns
1. We want to avoid having duplicated dataclasses (or dataclasses that are almost equivalent) without a good reason.
2. We do not want to rely too much on magic strings. In cases where we are dealing with categories/kinds, we should prefer to create a `StrEnum`.
3. We want to avoid "carrying" too much information across tasks, particularly if you are sending a piece of information that is not meant for a task, but rather for a future task that might be created by the immediate task you are creating. We should strive to read configuration values from the TABLE_METADATA configuration column, for example. This also applies to the PARTITION_METADATA synchronization data, for example.
4. We want to avoid using `Any` if possible. In general, we try to keep the code as type-safe as possible.
5. We want to avoid complex types without a meaningful name. For example, types like `dict[str, dict[str, str]]` might be complex to understand when reading the code. A type alias or a dedicated class can help here.
6. Let's not make non-deterministic tests, or unit tests that can take a lot of time. Running all tests should be matter of less than 10 seconds.

## Considerations
1. If the **Workflow Config** schema changes, update the `example-workflow-config.json` file. Also, update the mechanism for schema validation in **SnowConvert Desktop**.
2. If the **Data Exchange Agent Config** schema changes, update the `data-exchange-agent/src/data_exchange_agent/configuration_example.toml` (and possibly the `data-exchange-agent/docker-artifacts/configuration.template.toml`).
3. For development, it is useful to set orchestrator affinity (by setting the `DATA_MIGRATION_ORCHESTRATOR_AFFINITY` to your affinity value). This will prevent other orchestrator instances (from other devs) from picking up the workflows you have created (and the other way around). Wildcard patterns are supported: setting the affinity to `team-*` will match workflows with affinity `team-blue`, `team-red`, etc.

## How to add a new platform?
### Basic Integration
For integrating a new platform, it suffices to:
1. Add the new value to the `SourceType` enum (to `shared/enums/source_type.py`). 
2. Add the corresponding *default mappings* in `default_mappings.py`. Some examples: `sqlserver_default_mappings.py` and `redshift_default_mappings.py`.
3. Create the directory for this new platform in the `src/data_migration_orchestrator/data_migration_cloud/platforms` directory. Follow the examples of existing platforms.
4. Add the corresponding subclass of `BaseQueryBuilder` for the platform. Some examples: `RedshiftQueryBuilder` and `SqlServerQueryBuilder`. Make sure to implement all methods and override base methods if needed.
5. Add the corresponding subclass of `BasePlatform` for the platform. Some examples: `RedshiftPlatform` and `SqlServerPlatform`. Make sure to implement all methods and override base methods if needed.
6. In `src/data_migration_orchestrator/data_migration_cloud/platforms/__init__.py`, you must register the platform and corresponding aliases (if any).

Some changes will likely be needed on the `data-exchange-agent` project.
Finally make sure to do appropriate manual testing and include new unit tests. 

### Optimizations
Some platforms might have an "optimized" way of extracting the data and pushing it to a Snowflake stage (internal or external).

#### Examples
##### SQL Server**
**BCP** tool is highly performant and can be used to extract the data to CSV files. This approach requires changes only on the **Data Exchange Agent** (and **BCP** is only leveraged for "bulk" data movement operations, not for small metadata queries).

##### Redshift
It is common to use the **UNLOAD** strategy, in which an **UNLOAD** statement is issued to the **Redshift** insteance (with the appropriate SQL query) and that creates a Parquet file in a **S3** bucket. On the side of the **Data Migration Orchestrator**, the workflow must receive configuration to use the **UNLOAD** strategy (this must also include the name of the external stage that is pointing to the **S3** bucket). This approach requires changes on both the **Data Exchange Agent** (to understand how to issue the **UNLOAD** statement) and in the **Data Migration Orchestrator** (to read the configuration and understand where to read the data from).

#### Considerations
- Take into account if a new extraction strategy must be added to the **Data Migration Orchestrator**. This would require changes in the workflow configuration models.
- Take into account if the optimization only requires changes to the **Data Exchange Agent** (which is preferred). An example of this is the **BCP** approach for **SQL Server**. 
