-- SPCS: Data Migration Orchestrator + Data Exchange Agent (Redshift)
-- Compute pool: MIGRATIONS_COMPUTE_POOL
--
-- Before running:
--   1. Push images from repo root (Docker + snow CLI):
--        ./data-migration-orchestrator/scripts/upload-orchestrator.sh [--connection <snowflake_connection>]
--        ./data-exchange-agent/scripts/upload-agent.sh [--connection <snowflake_connection>] --platform redshift
--   2. Replace placeholders below: <ROLE>, warehouse, Redshift host, secret FQN, S3 unload settings, affinity.
--   3. Grant the service role: READ on image repository, USAGE on compute pool, USAGE on integration, etc.
--
-- Image paths must match what you pushed (default from upload scripts):
--   /SNOWCONVERT_AI/PUBLIC/IMAGES/data-migration-orchestrator:latest
--   /SNOWCONVERT_AI/PUBLIC/IMAGES/data-exchange-agent:redshift

ALTER COMPUTE POOL MIGRATIONS_COMPUTE_POOL RESUME;

-- ---------------------------------------------------------------------------
-- Redshift egress (source DB). Adjust database/schema names to your layout.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE SECRET ALONSO_DB.PUBLIC.REDSHIFT_DEMO_SECRET
  TYPE = PASSWORD
  USERNAME = 'admin'
  PASSWORD = '<set-password>';

GRANT USAGE ON SECRET ALONSO_DB.PUBLIC.REDSHIFT_DEMO_SECRET TO ROLE <ROLE>;

CREATE OR REPLACE NETWORK RULE ALONSO_DB.PUBLIC.REDSHIFT_EGRESS_RULE
  MODE = EGRESS
  TYPE = HOST_PORT
  VALUE_LIST = (
    'migrations-wg-fde-dev.101645636301.us-west-2.redshift-serverless.amazonaws.com:5439'
  );

USE SCHEMA ALONSO_DB.PUBLIC;

CREATE OR REPLACE EXTERNAL ACCESS INTEGRATION REDSHIFT_INTEGRATION
  ALLOWED_NETWORK_RULES = (REDSHIFT_EGRESS_RULE)
  ENABLED = TRUE;

GRANT USAGE ON INTEGRATION REDSHIFT_INTEGRATION TO ROLE <ROLE>;

-- ---------------------------------------------------------------------------
-- Orchestrator (Snowflake-only; no external access integration required)
-- Name matches CONTRIBUTING.md (DATA_MIGRATION_SERVICE).
-- ---------------------------------------------------------------------------
CREATE SERVICE IF NOT EXISTS SNOWCONVERT_AI.DATA_MIGRATION.DATA_MIGRATION_SERVICE
  IN COMPUTE POOL MIGRATIONS_COMPUTE_POOL
  FROM SPECIFICATION
$$
spec:
  containers:
    - name: orchestrator
      image: /SNOWCONVERT_AI/PUBLIC/IMAGES/data-migration-orchestrator:latest
      env:
        SNOWFLAKE_WAREHOUSE: TB_DEV_WH
        DATA_MIGRATION_ORCHESTRATOR_AFFINITY: BLUE
      resources:
        requests:
          memory: 2Gi
          cpu: 0.5
        limits:
          memory: 4Gi
          cpu: 2
$$
  MIN_INSTANCES = 1
  MAX_INSTANCES = 1
  QUERY_WAREHOUSE = TB_DEV_WH;

-- ---------------------------------------------------------------------------
-- Data Exchange Agent (Redshift + optional UNLOAD to S3)
-- Fix YAML: `secrets` list items must be indented under `secrets:` (not under `containers:`).
-- ---------------------------------------------------------------------------
DROP SERVICE IF EXISTS SNOWCONVERT_AI.DATA_MIGRATION.DATA_EXCHANGE_SERVICE;

CREATE SERVICE SNOWCONVERT_AI.DATA_MIGRATION.DATA_EXCHANGE_SERVICE
  IN COMPUTE POOL MIGRATIONS_COMPUTE_POOL
  FROM SPECIFICATION
$$
spec:
  containers:
    - name: agent
      image: /SNOWCONVERT_AI/PUBLIC/IMAGES/data-exchange-agent:redshift
      env:
        DATA_SOURCE_HOST: migrations-wg-fde-dev.101645636301.us-west-2.redshift-serverless.amazonaws.com
        DATA_SOURCE_PORT: "5439"
        DATA_SOURCE_DATABASE: tpch_3tb
        SNOWFLAKE_WAREHOUSE: TB_DEV_WH
        MAX_PARALLEL_TASKS: "3"
        AGENT_AFFINITY: BLUE
        UNLOAD_S3_BUCKET: serverless-unload-bucket-fde-dev
        UNLOAD_IAM_ROLE_ARN: arn:aws:iam::101645636301:role/RedshiftServerlessUnloadRole-fde-dev
      resources:
        requests:
          memory: 2Gi
          cpu: 0.5
        limits:
          memory: 4Gi
          cpu: 2
      secrets:
        - snowflakeSecret: ALONSO_DB.PUBLIC.REDSHIFT_DEMO_SECRET
          secretKeyRef: USERNAME
          envVarName: DATA_SOURCE_USERNAME
        - snowflakeSecret: ALONSO_DB.PUBLIC.REDSHIFT_DEMO_SECRET
          secretKeyRef: PASSWORD
          envVarName: DATA_SOURCE_PASSWORD
$$
  EXTERNAL_ACCESS_INTEGRATIONS = (REDSHIFT_INTEGRATION)
  MIN_INSTANCES = 1
  MAX_INSTANCES = 8
  QUERY_WAREHOUSE = TB_DEV_WH;
