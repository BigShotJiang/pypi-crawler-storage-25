#!/bin/bash
# Build wheel for Data Migration Orchestrator
# Usage: ./build-wheel.sh [--verify] [--clean]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ORCHESTRATOR_DIR="${SCRIPT_DIR}/.."
PYTHON_VERSION="${PYTHON_VERSION:-python3}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Parse arguments
VERIFY=false
CLEAN=false
for arg in "$@"; do
    case $arg in
        --verify)
            VERIFY=true
            shift
            ;;
        --clean)
            CLEAN=true
            shift
            ;;
        --help)
            echo "Usage: ./build-wheel.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --verify    Verify the wheel by installing in a virtual environment"
            echo "  --clean     Clean dist directory before building"
            echo "  --help      Show this help message"
            exit 0
            ;;
    esac
done

echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}Building Data Migration Orchestrator Wheel${NC}"
echo -e "${GREEN}============================================${NC}"

# Check if hatch is installed
if ! command -v hatch &> /dev/null; then
    echo -e "${YELLOW}Hatch not found. Installing...${NC}"
    ${PYTHON_VERSION} -m pip install hatch click==8.2.0 -q
fi

cd "${ORCHESTRATOR_DIR}"

# Clean if requested
if [ "$CLEAN" = true ]; then
    echo -e "${YELLOW}Cleaning dist directory...${NC}"
    rm -rf dist/
fi

# Show package info
echo -e "\n${YELLOW}Package Information:${NC}"
hatch project metadata | head -20

# Build the wheel
echo -e "\n${YELLOW}Building wheel and sdist...${NC}"
hatch build

# Show generated artifacts
echo -e "\n${GREEN}Generated Artifacts:${NC}"
ls -la dist/

# Verify installation if requested
if [ "$VERIFY" = true ]; then
    echo -e "\n${YELLOW}Verifying wheel installation...${NC}"

    # Create temp virtual environment
    VENV_DIR=$(mktemp -d)
    ${PYTHON_VERSION} -m venv "${VENV_DIR}"

    # Install the wheel
    "${VENV_DIR}/bin/pip" install --upgrade pip -q
    "${VENV_DIR}/bin/pip" install dist/*.whl -q

    # Show installed package
    echo -e "\n${GREEN}Installed package info:${NC}"
    "${VENV_DIR}/bin/pip" show data-migration-orchestrator

    # Test import
    echo -e "\n${YELLOW}Testing import...${NC}"
    "${VENV_DIR}/bin/python" -c "import data_migration_orchestrator; print('Import successful!')"

    # Cleanup
    rm -rf "${VENV_DIR}"
    echo -e "${GREEN}Verification complete!${NC}"
fi

echo -e "\n${GREEN}============================================${NC}"
echo -e "${GREEN}Orchestrator wheel built successfully!${NC}"
echo -e "${GREEN}Artifacts location: ${ORCHESTRATOR_DIR}/dist/${NC}"
echo -e "${GREEN}============================================${NC}"
