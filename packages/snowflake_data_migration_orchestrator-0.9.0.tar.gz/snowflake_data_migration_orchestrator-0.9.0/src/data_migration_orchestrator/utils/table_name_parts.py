"""Shared data model and default parsing for qualified table names."""

from dataclasses import dataclass


@dataclass
class TableNameParts:
    """
    Parsed components of a qualified table name.

    Attributes:
        database: Database/catalog name (None if not specified), unquoted
        schema: Schema name (None if not specified), unquoted
        table: Table name (always present), unquoted

    """

    database: str | None
    schema: str | None
    table: str
