"""
Snowflake metadata database and schema names (orchestrator task/validation objects).

These are independent of connection session variables SNOWFLAKE_DATABASE / SNOWFLAKE_SCHEMA.
Override via environment variables when deploying to a non-default layout.
"""

import os


CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA = "CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA"
CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA = (
    "CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA"
)
CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA = (
    "CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA"
)

_DEFAULT_METADATA_DATABASE = "SNOWCONVERT_AI"
_DEFAULT_MIGRATION_SCHEMA = "DATA_MIGRATION"
_DEFAULT_VALIDATION_SCHEMA = "DATA_VALIDATION"
_DEFAULT_TEMP_SCHEMA = "TEMP"
_DEFAULT_EVENT_TABLE_NAME = "EVENTS"


def metadata_database() -> str:
    """Return the database name that holds migration and validation metadata objects."""
    return os.environ.get(
        CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA, _DEFAULT_METADATA_DATABASE
    )


def migration_metadata_schema() -> str:
    """Return the schema name for task queue, workflow, and data-migration metadata."""
    return os.environ.get(
        CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA,
        _DEFAULT_MIGRATION_SCHEMA,
    )


def validation_metadata_schema() -> str:
    """Return the schema name for data-validation metadata and result tables."""
    return os.environ.get(
        CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA,
        _DEFAULT_VALIDATION_SCHEMA,
    )


def qualified_migration_schema() -> str:
    """Return the fully qualified migration metadata schema (database.schema)."""
    return f"{metadata_database()}.{migration_metadata_schema()}"


def qualified_validation_schema() -> str:
    """Return the fully qualified validation metadata schema (database.schema)."""
    return f"{metadata_database()}.{validation_metadata_schema()}"


def temp_schema() -> str:
    """Return the schema name used for temporary Snowpipe objects."""
    return _DEFAULT_TEMP_SCHEMA


def qualified_temp_schema() -> str:
    """Return the fully qualified temp schema (database.schema)."""
    return f"{metadata_database()}.{temp_schema()}"


def qualified_event_table() -> str:
    """Return the fully qualified event table (database.schema.table)."""
    return f"{qualified_migration_schema()}.{_DEFAULT_EVENT_TABLE_NAME}"


def sql_template_context() -> dict[str, str]:
    """Return a context dict for Jinja2 SQL asset templates."""
    db = metadata_database()
    mig = migration_metadata_schema()
    val = validation_metadata_schema()
    return {
        "metadata_database": db,
        "migration_schema": mig,
        "validation_schema": val,
        "qualified_migration": f"{db}.{mig}",
        "qualified_validation": f"{db}.{val}",
    }
