"""
Streamlit-in-Snowflake metadata qualification (standalone module).

Deployed next to ``app.py`` on the Streamlit stage. It must not import
``data_migration_orchestrator`` so SiS can load it without the package wheel.
When running from an editable or installed package, use
``data_migration_orchestrator.utils.sis_streamlit_metadata``.

Env defaults stay aligned with ``snowflake_metadata.py``.
"""

from __future__ import annotations

import importlib
import os


CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA = "CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA"
CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA = (
    "CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA"
)
CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA = (
    "CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA"
)

_DEFAULT_METADATA_DATABASE = "SNOWCONVERT_AI"
_DEFAULT_MIGRATION_SCHEMA = "DATA_MIGRATION"
_DEFAULT_VALIDATION_SCHEMA = "DATA_VALIDATION"


def _metadata_database() -> str:
    return os.environ.get(
        CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA, _DEFAULT_METADATA_DATABASE
    )


def _migration_metadata_schema() -> str:
    return os.environ.get(
        CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA,
        _DEFAULT_MIGRATION_SCHEMA,
    )


def _validation_metadata_schema() -> str:
    return os.environ.get(
        CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA,
        _DEFAULT_VALIDATION_SCHEMA,
    )


def _qualified_migration_schema() -> str:
    return f"{_metadata_database()}.{_migration_metadata_schema()}"


def _qualified_validation_schema() -> str:
    return f"{_metadata_database()}.{_validation_metadata_schema()}"


def migration_schema_for_streamlit_dashboard() -> str:
    """Qualified migration metadata schema (``database.schema``) for dashboard SQL."""
    try:
        baked = importlib.import_module("_streamlit_baked_metadata")
    except ModuleNotFoundError:
        return _qualified_migration_schema()
    return str(baked.QUALIFIED_MIGRATION_SCHEMA)


def validation_schema_for_streamlit_dashboard() -> str:
    """Qualified validation metadata schema (``database.schema``) for dashboard SQL."""
    try:
        baked = importlib.import_module("_streamlit_baked_metadata")
    except ModuleNotFoundError:
        return _qualified_validation_schema()
    q = getattr(baked, "QUALIFIED_VALIDATION_SCHEMA", None)
    if q is not None:
        return str(q)
    return _qualified_validation_schema()
