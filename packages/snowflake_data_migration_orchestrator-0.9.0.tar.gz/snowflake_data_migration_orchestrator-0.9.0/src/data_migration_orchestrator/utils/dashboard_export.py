"""
Dashboard CSV export helpers (standalone, SiS-safe).

Pure helpers that convert pandas DataFrames into CSV bytes suitable for
``streamlit.download_button``. The helpers are column-renaming and
ordering-aware so the on-screen view can hide implementation-detail columns
while the CSV export retains them for power users and downstream tooling.

This module is deployed next to ``app.py`` on the Streamlit stage; it MUST
NOT import ``data_migration_orchestrator`` or any runtime dependency that is
not available on the SiS runtime.
"""

from __future__ import annotations

import io

from collections.abc import Iterable, Mapping, Sequence
from datetime import UTC, datetime

import pandas as pd


SECTION_MARKER_PREFIX = "# SECTION:"


def prepare_export_dataframe(
    df: pd.DataFrame,
    *,
    drop_cols: Iterable[str] = (),
    rename_map: Mapping[str, str] | None = None,
    column_order: Sequence[str] | None = None,
) -> pd.DataFrame:
    """
    Return a dataframe with columns dropped, renamed and reordered.

    - Missing columns in ``drop_cols`` and ``column_order`` are ignored so
      callers can use a stable superset across slightly different inputs.
    - ``rename_map`` is applied AFTER dropping but BEFORE reordering. Entries
      for absent columns are ignored.
    - ``column_order`` is applied after renaming; any column present in the
      frame but not in the order is appended at the end in its original order.
    - Returns a copy; the input frame is never mutated.
    """
    if df is None:
        return pd.DataFrame()

    result = df.copy()

    drop_set = {c for c in drop_cols if c in result.columns}
    if drop_set:
        result = result.drop(columns=list(drop_set))

    if rename_map:
        effective = {k: v for k, v in rename_map.items() if k in result.columns}
        if effective:
            result = result.rename(columns=effective)

    if column_order:
        requested = [c for c in column_order if c in result.columns]
        remaining = [c for c in result.columns if c not in requested]
        result = result[requested + remaining]

    return result


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    """Serialize ``df`` to UTF-8 CSV bytes (no row index, LF line endings)."""
    if df is None:
        df = pd.DataFrame()
    buf = io.StringIO()
    df.to_csv(buf, index=False, lineterminator="\n")
    return buf.getvalue().encode("utf-8")


def build_snapshot_csv(
    sections: Mapping[str, pd.DataFrame],
    *,
    generated_at: datetime | None = None,
) -> bytes:
    """
    Build a single multi-section CSV from several named dataframes.

    Each section is prefixed with a ``# SECTION: <name>`` marker line (which
    CSV parsers will see as a comment-like single-column row) followed by the
    CSV body. Sections are separated by a blank line. An empty dataframe
    still emits its section marker and header (when columns are present).

    The output begins with a ``# GENERATED_AT: <ISO8601 UTC>`` marker line so
    snapshots are self-describing.
    """
    if generated_at is None:
        generated_at = datetime.now(tz=UTC)
    iso = generated_at.strftime("%Y-%m-%dT%H:%M:%SZ")

    out = io.StringIO()
    out.write(f"# GENERATED_AT: {iso}\n\n")

    for idx, (name, df) in enumerate(sections.items()):
        if idx > 0:
            out.write("\n")
        out.write(f"{SECTION_MARKER_PREFIX} {name}\n")
        if df is None or (len(df) == 0 and df.columns.empty):
            out.write("(empty)\n")
            continue
        df.to_csv(out, index=False, lineterminator="\n")

    return out.getvalue().encode("utf-8")


def snapshot_filename(
    prefix: str,
    *,
    workflow_id: int | None,
    now: datetime | None = None,
) -> str:
    """
    Build a deterministic snapshot filename.

    Example: ``dm_snapshot_all_20260427T204230Z.csv``.
    """
    if now is None:
        now = datetime.now(tz=UTC)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    scope = f"wf{workflow_id}" if workflow_id is not None else "all"
    return f"{prefix}_{scope}_{stamp}.csv"


def per_tab_filename(
    prefix: str,
    tab: str,
    *,
    workflow_id: int | None,
    now: datetime | None = None,
) -> str:
    """Build a deterministic per-tab CSV download filename."""
    if now is None:
        now = datetime.now(tz=UTC)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    scope = f"wf{workflow_id}" if workflow_id is not None else "all"
    safe_tab = tab.replace(" ", "_").replace("/", "-").lower()
    return f"{prefix}_{safe_tab}_{scope}_{stamp}.csv"


__all__ = [
    "SECTION_MARKER_PREFIX",
    "build_snapshot_csv",
    "per_tab_filename",
    "prepare_export_dataframe",
    "snapshot_filename",
    "to_csv_bytes",
]
