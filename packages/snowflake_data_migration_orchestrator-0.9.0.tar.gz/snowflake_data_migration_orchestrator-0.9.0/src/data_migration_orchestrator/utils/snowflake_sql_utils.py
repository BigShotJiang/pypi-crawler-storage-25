"""Generic SQL utility functions for query construction and value sanitization."""


def escape_sql_string(value: str) -> str:
    """
    Escape a string value for safe use in Snowflake SQL string literals.

    Snowflake treats backslash as an escape character inside single-quoted
    strings, so both backslashes and single quotes must be escaped.

    Args:
        value: The string value to escape

    Returns:
        The escaped string (without surrounding quotes)

    """
    return value.replace("\\", "\\\\").replace("'", "''")


def quote_string_literal(value: str, unicode_prefix: bool = False) -> str:
    """
    Quote a string value for use in SQL queries.

    This function wraps a string value in single quotes for use as a SQL string literal.
    It also escapes internal single quotes by doubling them.

    Args:
        value: The string value to quote
        unicode_prefix: If True, prefix with N for SQL Server Unicode literals (N'...')

    Returns:
        The quoted string literal

    """
    escaped_value = escape_sql_string(value)
    prefix = "N" if unicode_prefix else ""
    return f"{prefix}'{escaped_value}'"
