"""
Streamlit-in-Snowflake metadata qualification.

Logic lives in :mod:`data_migration_orchestrator.utils.sis_streamlit_metadata` so the same
implementation can be uploaded to SiS without the package; this module re-exports
for in-process orchestrator use.
"""

from data_migration_orchestrator.utils.sis_streamlit_metadata import (
    migration_schema_for_streamlit_dashboard,
    validation_schema_for_streamlit_dashboard,
)


__all__ = [
    "migration_schema_for_streamlit_dashboard",
    "validation_schema_for_streamlit_dashboard",
]
