"""Render and execute Jinja2-templated SQL files (orchestrator schema assets)."""

from pathlib import Path

import snowflake.connector

from jinja2 import BaseLoader, Environment, StrictUndefined


def render_sql_jinja_template(source: str, context: dict[str, str]) -> str:
    """Render a SQL string with Jinja2 using the given context."""
    env = Environment(
        loader=BaseLoader(),
        autoescape=False,
        undefined=StrictUndefined,
    )
    return env.from_string(source).render(**context).strip()


def execute_templated_sql_file(
    cursor: snowflake.connector.cursor.SnowflakeCursor,
    file_path: str | Path,
    context: dict[str, str],
) -> None:
    """
    Read a .sql.j2 file, render with Jinja2, and execute on the cursor.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the rendered SQL is empty.
        Exception: On Snowflake execution errors (wrapped with file path).

    """
    path = Path(file_path)
    if not path.is_file():
        raise FileNotFoundError(f"SQL template file not found: {path}")

    raw = path.read_text(encoding="utf-8")
    sql = render_sql_jinja_template(raw, context)
    if not sql:
        raise ValueError(f"Rendered SQL is empty: {path}")

    try:
        cursor.execute(sql)
    except Exception as e:
        raise Exception(f"Failed to execute {path}: {e!s}") from e


def execute_migration_sql_asset(
    cursor: snowflake.connector.cursor.SnowflakeCursor,
    assets_dir: str | Path,
    relative_path: str,
    context: dict[str, str] | None = None,
) -> None:
    """Render and execute a path under the package assets directory (e.g. scripts/.../*.sql.j2)."""
    from data_migration_orchestrator.utils.snowflake_metadata import (
        sql_template_context,
    )

    ctx = sql_template_context() if context is None else context
    execute_templated_sql_file(cursor, Path(assets_dir) / relative_path, ctx)
