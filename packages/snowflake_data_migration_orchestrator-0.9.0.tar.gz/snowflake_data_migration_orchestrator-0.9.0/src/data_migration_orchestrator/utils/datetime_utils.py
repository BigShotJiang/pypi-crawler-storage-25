"""Datetime utility functions for formatting and validation."""

import re


# Regex pattern to detect datetime strings in common formats
# Matches: YYYY-MM-DD HH:MM:SS, YYYY-MM-DDTHH:MM:SS, with optional fractional seconds
# and optional timezone offset
DATETIME_PATTERN = re.compile(
    r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[+-]\d{2}:\d{2})?$"
)


def is_datetime_string(value: str) -> bool:
    """
    Check if a string looks like a datetime value.

    Matches common datetime formats:
    - YYYY-MM-DD HH:MM:SS
    - YYYY-MM-DDTHH:MM:SS
    - With optional fractional seconds (.NNNNNN)
    - With optional timezone offset (+HH:MM or -HH:MM)

    Args:
        value: The string to check

    Returns:
        True if the string matches a datetime pattern, False otherwise

    """
    return bool(DATETIME_PATTERN.match(value))
