"""
Dashboard aggregation helpers (standalone, SiS-safe).

Pure pandas helpers used by the Streamlit dashboards to aggregate per-execution
(``(workflow_id, table_name)``) rows into table-centric views and to apply
user-supplied text filters.

This module is deployed next to ``app.py`` on the Streamlit stage; it MUST NOT
import ``data_migration_orchestrator`` or any runtime dependency that is not
available on the SiS runtime.
"""

from __future__ import annotations

import pandas as pd


# Column name constants — shared across migration and validation dashboards.
COL_WORKFLOW_ID = "WORKFLOW_ID"
COL_TABLE_NAME = "TABLE_NAME"
COL_TABLE_ID = "TABLE_ID"

# Migration
COL_TOTAL_PARTITIONS = "TOTAL_PARTITIONS"
COL_LOADED_PARTITIONS = "LOADED_PARTITIONS"
COL_FAILED_PARTITIONS = "FAILED_PARTITIONS"
COL_EXTRACTING = "PARTITIONS_IN_EXTRACTION_PHASE"
COL_LOADING = "PARTITIONS_IN_LOADING_PHASE"
COL_TOTAL_ROWS = "TOTAL_ROWS"
COL_CLOUD_STAGE = "CLOUD_STAGE"
COL_EXAMPLE_ERROR = "EXAMPLE_ERROR_MESSAGE"
COL_EXAMPLE_WARNING = "EXAMPLE_WARNING_MESSAGE"

# Validation
COL_SCHEMA_VALIDATED = "SCHEMA_VALIDATED"
COL_METRICS_VALIDATED = "METRICS_VALIDATED"
COL_ROWS_VALIDATED = "ROWS_VALIDATED"
COL_VALIDATION_STATUS = "STATUS"
COL_ERROR_MESSAGE = "ERROR_MESSAGE"

# Computed columns
COL_STATUS = "STATUS"
COL_PROGRESS_PCT = "PROGRESS_PCT"
COL_RUNS_COUNT = "RUNS_COUNT"
COL_LATEST_WORKFLOW_ID = "LATEST_WORKFLOW_ID"
COL_LAST_ERROR_MESSAGE = "LAST_ERROR_MESSAGE"

# Migration status values (ordered by severity — first wins).
STATUS_FAILED = "Failed"
STATUS_IN_PROGRESS = "In progress"
STATUS_COMPLETE = "Complete"
STATUS_NOT_STARTED = "Not started"

_MIGRATION_STATUS_PRIORITY = {
    STATUS_FAILED: 0,
    STATUS_IN_PROGRESS: 1,
    STATUS_COMPLETE: 2,
    STATUS_NOT_STARTED: 3,
}


def _coerce_int(series: pd.Series) -> pd.Series:
    """Coerce to int64, replacing nulls with 0."""
    return pd.to_numeric(series, errors="coerce").fillna(0).astype("int64")


def compute_migration_row_status(
    total: pd.Series,
    loaded: pd.Series,
    failed: pd.Series,
) -> pd.Series:
    """
    Vectorized per-row migration status.

    Precedence: Failed > Complete > Not started > In progress. A row is "Not
    started" only when it has zero partitions; otherwise any non-complete,
    non-failed row is "In progress".
    """
    total = _coerce_int(total)
    loaded = _coerce_int(loaded)
    failed = _coerce_int(failed)

    status = pd.Series(
        [STATUS_IN_PROGRESS] * len(total), index=total.index, dtype=object
    )
    status = status.mask(total == 0, STATUS_NOT_STARTED)
    status = status.mask((total > 0) & (loaded == total), STATUS_COMPLETE)
    # Failed takes precedence over everything else.
    status = status.mask(failed > 0, STATUS_FAILED)
    return status


def compute_migration_progress_pct(
    total: pd.Series,
    loaded: pd.Series,
) -> pd.Series:
    """Vectorized progress percentage (0.0 when no partitions)."""
    total = _coerce_int(total)
    loaded = _coerce_int(loaded)
    safe_total = total.where(total > 0, 1)  # avoid div-by-zero
    pct = (loaded / safe_total) * 100.0
    return pct.where(total > 0, 0.0).round(1)


def filter_by_table_search(df: pd.DataFrame, search: str) -> pd.DataFrame:
    """
    Case-insensitive substring filter on ``TABLE_NAME``.

    An empty or whitespace-only ``search`` returns ``df`` unchanged. If the
    input has no ``TABLE_NAME`` column, return ``df`` unchanged.
    """
    if df is None or len(df) == 0 or not search or not search.strip():
        return df if df is not None else pd.DataFrame()
    if COL_TABLE_NAME not in df.columns:
        return df
    mask = (
        df[COL_TABLE_NAME]
        .astype(str)
        .str.contains(search.strip(), case=False, na=False, regex=False)
    )
    return df[mask].copy()


def _aggregate_error_message(series: pd.Series) -> object:
    """Return the first non-null, non-empty string in the series or None."""
    for value in series:
        if value is None:
            continue
        try:
            text = str(value).strip()
        except Exception:
            continue
        if text and text.lower() != "nan":
            return value
    return None


def aggregate_migration_tables_by_name(df: pd.DataFrame) -> pd.DataFrame:
    """
    Collapse per-(workflow, table) rows into one row per table name.

    The returned frame has one row per ``TABLE_NAME`` with columns:

    - ``TABLE_NAME``
    - ``STATUS`` — latest execution's status (Failed > In progress > Complete > Not started)
    - ``LATEST_WORKFLOW_ID``
    - ``RUNS_COUNT``
    - ``TOTAL_PARTITIONS`` / ``LOADED_PARTITIONS`` / ``FAILED_PARTITIONS``
      (plus per-phase partition counters) — all from the latest run
    - ``PROGRESS_PCT`` — for the latest run
    - ``TOTAL_ROWS`` — latest run (when column is present)
    - ``CLOUD_STAGE`` — latest run (when column is present)
    - ``LAST_ERROR_MESSAGE`` — most recent non-empty error across runs

    Recency signal: ``MAX(WORKFLOW_ID)`` per table name (workflow IDs are
    monotonic in this codebase).
    """
    if df is None or len(df) == 0:
        return pd.DataFrame(
            columns=[
                COL_TABLE_NAME,
                COL_STATUS,
                COL_LATEST_WORKFLOW_ID,
                COL_RUNS_COUNT,
                COL_TOTAL_PARTITIONS,
                COL_LOADED_PARTITIONS,
                COL_FAILED_PARTITIONS,
                COL_EXTRACTING,
                COL_LOADING,
                COL_PROGRESS_PCT,
                COL_TOTAL_ROWS,
                COL_CLOUD_STAGE,
                COL_LAST_ERROR_MESSAGE,
            ]
        )

    work = df.copy()
    # Normalize required numeric columns.
    for col in (
        COL_TOTAL_PARTITIONS,
        COL_LOADED_PARTITIONS,
        COL_FAILED_PARTITIONS,
        COL_EXTRACTING,
        COL_LOADING,
    ):
        if col in work.columns:
            work[col] = _coerce_int(work[col])
        else:
            work[col] = 0
    if COL_TOTAL_ROWS in work.columns:
        work[COL_TOTAL_ROWS] = _coerce_int(work[COL_TOTAL_ROWS])
    else:
        work[COL_TOTAL_ROWS] = 0
    if COL_CLOUD_STAGE not in work.columns:
        work[COL_CLOUD_STAGE] = None
    if COL_EXAMPLE_ERROR not in work.columns:
        work[COL_EXAMPLE_ERROR] = None

    # Sort by workflow id desc so "first" in groupby is the latest run.
    work = work.sort_values(
        by=[COL_TABLE_NAME, COL_WORKFLOW_ID],
        ascending=[True, False],
        kind="mergesort",
    )

    grouped = work.groupby(COL_TABLE_NAME, as_index=False, sort=True)
    aggregated = grouped.agg(
        **{
            COL_LATEST_WORKFLOW_ID: (COL_WORKFLOW_ID, "first"),
            COL_RUNS_COUNT: (COL_WORKFLOW_ID, "nunique"),
            COL_TOTAL_PARTITIONS: (COL_TOTAL_PARTITIONS, "first"),
            COL_LOADED_PARTITIONS: (COL_LOADED_PARTITIONS, "first"),
            COL_FAILED_PARTITIONS: (COL_FAILED_PARTITIONS, "first"),
            COL_EXTRACTING: (COL_EXTRACTING, "first"),
            COL_LOADING: (COL_LOADING, "first"),
            COL_TOTAL_ROWS: (COL_TOTAL_ROWS, "first"),
            COL_CLOUD_STAGE: (COL_CLOUD_STAGE, "first"),
            COL_LAST_ERROR_MESSAGE: (COL_EXAMPLE_ERROR, _aggregate_error_message),
        }
    )

    aggregated[COL_STATUS] = compute_migration_row_status(
        aggregated[COL_TOTAL_PARTITIONS],
        aggregated[COL_LOADED_PARTITIONS],
        aggregated[COL_FAILED_PARTITIONS],
    )
    aggregated[COL_PROGRESS_PCT] = compute_migration_progress_pct(
        aggregated[COL_TOTAL_PARTITIONS],
        aggregated[COL_LOADED_PARTITIONS],
    )

    aggregated = _sort_by_status_then_name(aggregated)
    # Stable column order.
    ordered = [
        COL_TABLE_NAME,
        COL_STATUS,
        COL_PROGRESS_PCT,
        COL_TOTAL_ROWS,
        COL_TOTAL_PARTITIONS,
        COL_LOADED_PARTITIONS,
        COL_FAILED_PARTITIONS,
        COL_EXTRACTING,
        COL_LOADING,
        COL_CLOUD_STAGE,
        COL_LAST_ERROR_MESSAGE,
        COL_LATEST_WORKFLOW_ID,
        COL_RUNS_COUNT,
    ]
    return aggregated[[c for c in ordered if c in aggregated.columns]]


def _sort_by_status_then_name(df: pd.DataFrame) -> pd.DataFrame:
    """Sort by status severity (Failed first) then alphabetically by name."""
    if df is None or len(df) == 0 or COL_STATUS not in df.columns:
        return df
    priority = df[COL_STATUS].map(_MIGRATION_STATUS_PRIORITY).fillna(99).astype("int64")
    result = df.assign(_priority=priority).sort_values(
        by=["_priority", COL_TABLE_NAME],
        kind="mergesort",
    )
    return result.drop(columns=["_priority"]).reset_index(drop=True)


def aggregate_validation_tables_by_name(df: pd.DataFrame) -> pd.DataFrame:
    """
    Collapse per-(workflow, table) validation rows into one row per table.

    The returned frame has one row per ``TABLE_NAME`` with columns:

    - ``TABLE_NAME``
    - ``STATUS`` — latest run's ``STATUS`` column (one of ``validated``, ``failed``, ``pending``)
    - ``SCHEMA_VALIDATED`` / ``METRICS_VALIDATED`` / ``ROWS_VALIDATED`` — latest run
    - ``LATEST_WORKFLOW_ID``
    - ``RUNS_COUNT``
    - ``LAST_ERROR_MESSAGE`` — most recent non-empty error across runs
    """
    if df is None or len(df) == 0:
        return pd.DataFrame(
            columns=[
                COL_TABLE_NAME,
                COL_VALIDATION_STATUS,
                COL_SCHEMA_VALIDATED,
                COL_METRICS_VALIDATED,
                COL_ROWS_VALIDATED,
                COL_LATEST_WORKFLOW_ID,
                COL_RUNS_COUNT,
                COL_LAST_ERROR_MESSAGE,
            ]
        )

    work = df.copy()
    for col in (COL_SCHEMA_VALIDATED, COL_METRICS_VALIDATED, COL_ROWS_VALIDATED):
        if col not in work.columns:
            work[col] = False
    if COL_ERROR_MESSAGE not in work.columns:
        work[COL_ERROR_MESSAGE] = None
    if COL_VALIDATION_STATUS not in work.columns:
        work[COL_VALIDATION_STATUS] = "pending"

    work = work.sort_values(
        by=[COL_TABLE_NAME, COL_WORKFLOW_ID],
        ascending=[True, False],
        kind="mergesort",
    )

    grouped = work.groupby(COL_TABLE_NAME, as_index=False, sort=True)
    aggregated = grouped.agg(
        **{
            COL_VALIDATION_STATUS: (COL_VALIDATION_STATUS, "first"),
            COL_SCHEMA_VALIDATED: (COL_SCHEMA_VALIDATED, "first"),
            COL_METRICS_VALIDATED: (COL_METRICS_VALIDATED, "first"),
            COL_ROWS_VALIDATED: (COL_ROWS_VALIDATED, "first"),
            COL_LATEST_WORKFLOW_ID: (COL_WORKFLOW_ID, "first"),
            COL_RUNS_COUNT: (COL_WORKFLOW_ID, "nunique"),
            COL_LAST_ERROR_MESSAGE: (COL_ERROR_MESSAGE, _aggregate_error_message),
        }
    )

    # Sort: failed first, then pending, then validated, then alphabetical.
    status_priority = {"failed": 0, "pending": 1, "validated": 2}
    priority = (
        aggregated[COL_VALIDATION_STATUS]
        .astype(str)
        .str.lower()
        .map(status_priority)
        .fillna(99)
        .astype("int64")
    )
    aggregated = aggregated.assign(_priority=priority).sort_values(
        by=["_priority", COL_TABLE_NAME],
        kind="mergesort",
    )
    aggregated = aggregated.drop(columns=["_priority"]).reset_index(drop=True)

    ordered = [
        COL_TABLE_NAME,
        COL_VALIDATION_STATUS,
        COL_SCHEMA_VALIDATED,
        COL_METRICS_VALIDATED,
        COL_ROWS_VALIDATED,
        COL_LAST_ERROR_MESSAGE,
        COL_LATEST_WORKFLOW_ID,
        COL_RUNS_COUNT,
    ]
    return aggregated[[c for c in ordered if c in aggregated.columns]]


__all__ = [
    "COL_CLOUD_STAGE",
    "COL_ERROR_MESSAGE",
    "COL_EXAMPLE_ERROR",
    "COL_EXAMPLE_WARNING",
    "COL_EXTRACTING",
    "COL_FAILED_PARTITIONS",
    "COL_LAST_ERROR_MESSAGE",
    "COL_LATEST_WORKFLOW_ID",
    "COL_LOADED_PARTITIONS",
    "COL_LOADING",
    "COL_METRICS_VALIDATED",
    "COL_PROGRESS_PCT",
    "COL_ROWS_VALIDATED",
    "COL_RUNS_COUNT",
    "COL_SCHEMA_VALIDATED",
    "COL_STATUS",
    "COL_TABLE_ID",
    "COL_TABLE_NAME",
    "COL_TOTAL_PARTITIONS",
    "COL_TOTAL_ROWS",
    "COL_VALIDATION_STATUS",
    "COL_WORKFLOW_ID",
    "STATUS_COMPLETE",
    "STATUS_FAILED",
    "STATUS_IN_PROGRESS",
    "STATUS_NOT_STARTED",
    "aggregate_migration_tables_by_name",
    "aggregate_validation_tables_by_name",
    "compute_migration_progress_pct",
    "compute_migration_row_status",
    "filter_by_table_search",
]
