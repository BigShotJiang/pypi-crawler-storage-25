"""
Command to create a Data Migration Workflow.

Reads a JSON configuration file, validates it using the same schema
the workflow initializer uses, and inserts a row into the WORKFLOW table.
"""

import argparse
import json
import sys

from pathlib import Path

import snowflake.connector

from data_migration_orchestrator.cloud_core.connection_manager import (
    get_connection_config,
)
from data_migration_orchestrator.commands import CREATE_DATA_MIGRATION_WORKFLOW
from data_migration_orchestrator.data_migration_cloud.config.workflow_configuration_schema import (
    validate_workflow_configuration,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)
from data_migration_orchestrator.utils.snowflake_sql_utils import escape_sql_string
from shared.enums.source_type import SourceType


# Only these dialects are supported for cloud data migration.
# Other SourceType members (e.g. postgresql, teradata) are recognised by the
# enum but do not yet have full migration support.
SUPPORTED_DATA_MIGRATION_DIALECTS: frozenset[SourceType] = frozenset(
    {SourceType.SQLSERVER, SourceType.REDSHIFT}
)


def register_subparser(subparsers: argparse._SubParsersAction) -> None:
    """Register the ``create-data-migration-workflow`` subcommand."""
    create_parser = subparsers.add_parser(
        CREATE_DATA_MIGRATION_WORKFLOW,
        help="Validate a workflow config and insert it into the WORKFLOW table",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m data_migration_orchestrator.main create-data-migration-workflow config.json
  python -m data_migration_orchestrator.main create-data-migration-workflow config.json --connection-name my_conn
  python -m data_migration_orchestrator.main create-data-migration-workflow config.json --name my_workflow --source-platform redshift
        """,
    )
    create_parser.set_defaults(func=create_data_migration_workflow)

    create_parser.add_argument(
        "config_file",
        type=Path,
        help="Path to the JSON workflow configuration file",
    )
    create_parser.add_argument(
        "--connection-name",
        type=str,
        default=None,
        help="Snowflake connection name (uses default from env vars if omitted)",
    )
    create_parser.add_argument(
        "--name",
        type=str,
        default="MY_WORKFLOW",
        help="Workflow name (default: MY_WORKFLOW)",
    )
    create_parser.add_argument(
        "--source-platform",
        type=str,
        help="Source platform",
    )


_TARGET_CLOUD_TYPE = "snowflake:stage"
_SCHEMA_VERSION = "1.0"


def _read_config_file(config_file: Path) -> dict:
    """Read and parse a JSON configuration file."""
    if not config_file.is_file():
        print(f"Error: configuration file not found: {config_file}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(config_file) as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        print(f"Error: invalid JSON in {config_file}: {e}", file=sys.stderr)
        sys.exit(1)


def _connect(connection_name: str | None) -> snowflake.connector.SnowflakeConnection:
    """
    Create a Snowflake connection.

    When *connection_name* is given it is used directly.  Otherwise the
    standard environment-variable-based configuration is used.

    Raises:
        SystemExit: If the connection cannot be established.

    """
    try:
        if connection_name is not None:
            print(f"Using Snowflake connection: {connection_name}")
            return snowflake.connector.connect(connection_name=connection_name)

        config = get_connection_config()
        display_name = config.get("connection_name") or config.get("account", "default")
        print(f"Using Snowflake connection: {display_name}")
        return snowflake.connector.connect(**config)
    except ValueError as e:
        # Missing required environment variables
        print(f"Error: connection configuration is incomplete: {e}", file=sys.stderr)
        sys.exit(1)
    except snowflake.connector.errors.DatabaseError as e:
        print(f"Error: could not connect to Snowflake: {e}", file=sys.stderr)
        sys.exit(1)


def _workflow_name_exists(
    cursor: snowflake.connector.cursor.SnowflakeCursor,
    name: str,
) -> bool:
    """Check whether a workflow with the given name already exists."""
    qm = qualified_migration_schema()
    cursor.execute(
        f"SELECT 1 FROM {qm}.WORKFLOW WHERE NAME = %s LIMIT 1",
        (name,),
    )
    return cursor.fetchone() is not None


def _build_insert_sql(
    *,
    name: str,
    source_platform: SourceType,
    configuration_json: str,
    affinity: str | None,
) -> str:
    qm = qualified_migration_schema()
    target_cloud_stage_name = f"@{qm}.TASK_RESULTS"
    affinity_sql = f"'{escape_sql_string(affinity)}'" if affinity else "NULL"
    return f"""\
INSERT INTO {qm}.WORKFLOW(
    NAME,
    WORKFLOW_TYPE,
    SOURCE_PLATFORM,
    TARGET_CLOUD_TYPE,
    TARGET_CLOUD_STAGE_NAME,
    TARGET_CLOUD_URL,
    SCHEMA_VERSION,
    INITIATOR_ID,
    CONFIGURATION,
    AFFINITY
)
SELECT
    '{escape_sql_string(name)}',
    'data-migration',
    '{escape_sql_string(source_platform.value)}',
    '{_TARGET_CLOUD_TYPE}',
    '{target_cloud_stage_name}',
    '',
    '{_SCHEMA_VERSION}',
    '',
    PARSE_JSON('{escape_sql_string(configuration_json)}'),
    {affinity_sql}
"""


def _validate_source_platform(raw_platform: str) -> SourceType:
    """
    Parse and gate-check the source platform.

    Raises:
        SystemExit: If the dialect is not supported for data migration.

    """
    try:
        source_type = SourceType.from_string(raw_platform)
    except (NotImplementedError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if source_type not in SUPPORTED_DATA_MIGRATION_DIALECTS:
        supported = ", ".join(
            sorted(s.value for s in SUPPORTED_DATA_MIGRATION_DIALECTS)
        )
        print(
            f"Error: data migration is not yet supported for '{source_type.value}'. "
            f"Supported source platforms: {supported}",
            file=sys.stderr,
        )
        sys.exit(1)

    return source_type


def create_data_migration_workflow(args: argparse.Namespace) -> None:
    """Entry point invoked by the CLI subcommand."""
    if not args.source_platform:
        print(
            "Error: --source-platform is required (e.g. sqlserver, redshift)",
            file=sys.stderr,
        )
        sys.exit(1)

    source_platform = _validate_source_platform(args.source_platform)

    config = _read_config_file(args.config_file)

    try:
        validated = validate_workflow_configuration(config)
    except Exception as e:
        print(f"Error: invalid workflow configuration: {e}", file=sys.stderr)
        sys.exit(1)

    print("Workflow configuration is valid.")

    if not validated.tables:
        print(
            "Error: workflow configuration contains no tables to migrate",
            file=sys.stderr,
        )
        sys.exit(1)

    affinity = validated.affinity
    configuration_json = json.dumps(config)

    sql = _build_insert_sql(
        name=args.name,
        source_platform=source_platform,
        configuration_json=configuration_json,
        affinity=affinity,
    )

    with _connect(args.connection_name) as connection:
        with connection.cursor() as cursor:
            try:
                if _workflow_name_exists(cursor, args.name):
                    print(
                        f"Error: a workflow named '{args.name}' already exists. "
                        "Choose a different name.",
                        file=sys.stderr,
                    )
                    sys.exit(1)
                cursor.execute(sql)
                print("Workflow created successfully.")
            except snowflake.connector.errors.ProgrammingError as e:
                print(f"Error: failed to create workflow: {e}", file=sys.stderr)
                sys.exit(1)
