"""
Helpers for recovering from Snowflake session invalidation (e.g. error 390111).

Works for long-lived processes in SPCS (OAuth token + session expiry) and for
local/console runs (idle session timeout).
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from snowflake.connector.errors import ProgrammingError


if TYPE_CHECKING:
    from data_migration_orchestrator.cloud_core.connection_manager import (
        ResilientConnection,
    )

# Snowflake: "Session no longer exists. New login required."
SF_SESSION_EXPIRED_ERRNO = 390111

# Initial attempt plus reconnect retries (local and SPCS).
DEFAULT_SESSION_RETRY_ATTEMPTS = 3


def is_session_expired_error(exc: BaseException) -> bool:
    """Return True if *exc* (or any chained ``__cause__``) is a 390111."""
    current: BaseException | None = exc
    while current is not None:
        if (
            isinstance(current, ProgrammingError)
            and getattr(current, "errno", None) == SF_SESSION_EXPIRED_ERRNO
        ):
            return True
        current = getattr(current, "__cause__", None)
    return False


def close_connection_safely(conn: Any | None) -> None:
    """Best-effort close; works with SnowflakeConnection and ResilientConnection."""
    if conn is None:
        return
    try:
        conn.close()
    except Exception:
        pass


def build_resilient_refresher() -> Callable[[Any | None], Any]:
    """
    Return a refresher callback for ``run_with_session_retry``.

    On 390111 the callback calls ``force_reconnect()`` on the **caller's**
    thread-local connection (passed as *old*) so each worker thread reconnects
    its own ``ResilientConnection`` rather than a shared instance.
    """
    from data_migration_orchestrator.cloud_core.connection_manager import (
        ResilientConnection,
    )

    def refresh(old: Any | None) -> ResilientConnection:
        if not isinstance(old, ResilientConnection):
            raise TypeError(f"Expected ResilientConnection, got {type(old).__name__}")
        old.force_reconnect()
        return old

    return refresh
