"""Snowflake metadata layout for the orchestrator (re-exports from utils)."""

from data_migration_orchestrator.utils.snowflake_metadata import (
    CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA,
    CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA,
    CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA,
    metadata_database,
    migration_metadata_schema,
    qualified_migration_schema,
    qualified_validation_schema,
    sql_template_context,
    validation_metadata_schema,
)


__all__ = [
    "CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA",
    "CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA",
    "CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA",
    "metadata_database",
    "migration_metadata_schema",
    "validation_metadata_schema",
    "qualified_migration_schema",
    "qualified_validation_schema",
    "sql_template_context",
]
