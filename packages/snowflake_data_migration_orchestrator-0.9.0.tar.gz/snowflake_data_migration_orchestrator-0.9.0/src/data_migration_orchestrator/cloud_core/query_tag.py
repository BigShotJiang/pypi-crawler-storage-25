"""
Snowflake QUERY_TAG helpers.

Provides functions to build a JSON query tag and to set / clear the
``QUERY_TAG`` session parameter on a Snowflake connection.  The tag is
attached to every query executed on the session and is visible in
``QUERY_HISTORY``.

Tag format (JSON, extensible)::

    {"DMVF_WORKFLOW_ID": "42", "DMVF_TASK_ID": "1017"}

To add new tags in the future, pass them as keyword arguments to
:func:`build_query_tag`.
"""

from __future__ import annotations

import json

from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)


logger = get_logger("query_tag")


def build_query_tag(
    *,
    workflow_id: int | str | None = None,
    task_id: int | str | None = None,
    **extra_tags: str,
) -> str:
    """
    Return a compact JSON string suitable for Snowflake's ``QUERY_TAG``.

    All values are coerced to strings.  ``None`` values are omitted.
    """
    tags: dict[str, str] = {}
    if workflow_id is not None:
        tags["DMVF_WORKFLOW_ID"] = str(workflow_id)
    if task_id is not None:
        tags["DMVF_TASK_ID"] = str(task_id)
    tags.update(extra_tags)
    return json.dumps(tags, separators=(",", ":"))


def set_query_tag(
    conn: Any,
    workflow_id: int | str | None = None,
    task_id: int | str | None = None,
    **extra_tags: str,
) -> None:
    """
    Set ``QUERY_TAG`` on *conn* for the current session.

    Uses ``ALTER SESSION SET QUERY_TAG`` so every subsequent query on the
    session carries the tag until it is cleared or overwritten.
    """
    tag = build_query_tag(workflow_id=workflow_id, task_id=task_id, **extra_tags)
    try:
        with conn.cursor() as cur:
            cur.execute(f"ALTER SESSION SET QUERY_TAG = '{_escape(tag)}'")
    except Exception:
        logger.debug("Failed to set QUERY_TAG", exc_info=True)


def clear_query_tag(conn: Any) -> None:
    """Best-effort unset of ``QUERY_TAG`` on *conn*."""
    try:
        with conn.cursor() as cur:
            cur.execute("ALTER SESSION UNSET QUERY_TAG")
    except Exception:
        logger.debug("Failed to clear QUERY_TAG", exc_info=True)


def _escape(value: str) -> str:
    """Escape single quotes for use inside a SQL string literal."""
    return value.replace("'", "''")
