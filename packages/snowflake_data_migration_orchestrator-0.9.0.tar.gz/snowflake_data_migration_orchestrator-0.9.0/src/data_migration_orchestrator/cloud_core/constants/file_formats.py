"""Fully qualified Snowflake file format names (data-migration metadata schema)."""

from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


def parquet_file_format_fqn() -> str:
    """Return fully qualified Parquet file format name in the migration metadata schema."""
    return f"{qualified_migration_schema()}.PARQUET_FILE_FORMAT"


def csv_file_format_fqn() -> str:
    """Return fully qualified CSV file format name in the migration metadata schema."""
    return f"{qualified_migration_schema()}.CSV_FILE_FORMAT"
