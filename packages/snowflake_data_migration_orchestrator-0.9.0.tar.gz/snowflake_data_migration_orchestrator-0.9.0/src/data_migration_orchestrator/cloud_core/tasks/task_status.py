from enum import StrEnum


class TaskStatus(StrEnum):
    """
    Enum representing possible task statuses.

    Used to track the state of tasks throughout their lifecycle.
    """

    PENDING = "pending"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    ABANDONED = "abandoned"
    BLOCKED = "blocked"
    PAUSED = "paused"
