import dataclasses
import json
import threading

from collections.abc import Callable
from functools import partial
from json import dumps as serialize_to_json
from typing import Any, ClassVar, Generic, Protocol, TypeVar

from snowflake.connector import DictCursor
from snowflake.connector import Error as SnowflakeError
from snowflake.connector import errors as sf_errors
from snowflake.connector.constants import QueryStatus

import data_migration_orchestrator.cloud_core.workflows.workflow_columns as workflow_columns

from data_migration_orchestrator.cloud_core.connection_manager import (
    SnowflakeConnectionLike,
)
from data_migration_orchestrator.cloud_core.constants.priorities import DEFAULT_PRIORITY
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.snowflake_session_retry import (
    DEFAULT_SESSION_RETRY_ATTEMPTS,
    is_session_expired_error,
)
from data_migration_orchestrator.cloud_core.stored_procedure_calls import (
    complete_task_call_template,
    fail_task_call_template,
    has_workflow_started_call_template,
    pull_tasks_call_template,
    push_task_call_template,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.snowpipe_task import (
    SnowpipeTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_core.workflows.stored_procedures_calls import (
    complete_workflows_call_template,
    delete_workflow_tasks_call_template,
    expire_stale_initializations_call_template,
    get_pending_workflows_call_template,
)
from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_event_table,
    qualified_migration_schema,
)
from data_migration_orchestrator.utils.snowflake_sql_utils import escape_sql_string
from shared.enums.source_type import SourceType


logger = get_logger("tasks.queues.table_task_queue")


class DataclassProtocol(Protocol):
    """Protocol for dataclass instances (required for dataclasses.asdict)."""

    __dataclass_fields__: ClassVar[dict[str, Any]]


TPayload = TypeVar("TPayload", bound=DataclassProtocol)
TRetry = TypeVar("TRetry")

# Transient Snowflake error codes handled specifically in _execute_statement
_SF_ERRNO_SESSION_EXPIRED = 390111
_SF_ERRNO_TRANSACTION_ABORT = 90232
_SF_ERRNO_UNKNOWN_FUNCTION = 2141

SnowflakeConnectionRefresher = Callable[
    [SnowflakeConnectionLike | None], SnowflakeConnectionLike
]


class TableTaskQueue(BaseTaskQueue[TPayload], Generic[TPayload]):
    """Concrete implementation of a task queue that works with a Snowflake table under the hood."""

    MAX_INITIALIZATION_FAILURES = 3
    _BATCH_INSERT_CHUNK_SIZE = 200

    max_tasks_to_pull: int = 1000

    def __init__(
        self,
        connection: SnowflakeConnectionLike,
        payload_mapper: Callable[[str, dict], TPayload],
        affinity: str | None = None,
        connection_refresher: SnowflakeConnectionRefresher | None = None,
    ) -> None:
        """
        Initialize the TableTaskQueue with a Snowflake connection.

        Args:
            connection: The Snowflake database connection (or ``ResilientConnection``).
            payload_mapper: A callable to map payload data to the appropriate type.
            affinity: The affinity group for this task queue.
            connection_refresher: Called on session expiry (390111) to replace the
                dead connection. For ``ResilientConnection`` callers, typically
                ``build_resilient_refresher(rc)``.

        """
        super().__init__(payload_mapper)
        self.affinity = affinity
        self.workflow_affinity_by_id: dict[int, str | None] = dict()
        self._pending_warehouse_tasks: dict[int, str] = {}
        self._warehouse_tasks_loaded: bool = False
        self._pending_snowpipe_tasks: dict[int, tuple[str, str, str, str]] = {}
        self._snowpipe_tasks_loaded: bool = False
        self._lock = threading.RLock()
        self._thread_local = threading.local()
        self._thread_local.connection = connection
        self._connection_refresher = connection_refresher

    @property
    def connection(self) -> SnowflakeConnectionLike:
        """Return the Snowflake connection for the current thread."""
        return self._thread_local.connection

    def register_thread_connection(self, connection: SnowflakeConnectionLike) -> None:
        """Register a per-thread Snowflake connection for the calling thread."""
        self._thread_local.connection = connection

    def run_with_session_retry(self, operation: Callable[[], TRetry]) -> TRetry:
        """
        Run a Snowflake operation with optional session recovery.

        Reconnects on session expiry (390111) when a refresher was configured.
        """
        if self._connection_refresher is None:
            return operation()
        for attempt in range(DEFAULT_SESSION_RETRY_ATTEMPTS):
            try:
                return operation()
            except Exception as e:
                if not is_session_expired_error(e):
                    raise
                if attempt >= DEFAULT_SESSION_RETRY_ATTEMPTS - 1:
                    raise
                logger.warning(
                    "Snowflake session expired (390111); reconnecting (attempt %d/%d)",
                    attempt + 1,
                    DEFAULT_SESSION_RETRY_ATTEMPTS,
                )
                old = self._thread_local.connection
                self._thread_local.connection = self._connection_refresher(old)
        raise RuntimeError("run_with_session_retry: unreachable")

    async def _execute_statement(self, statement: str) -> None:
        def op() -> None:
            try:
                with self.connection.cursor() as cursor:
                    cursor.execute(statement)
            except sf_errors.ProgrammingError as e:
                if e.errno == _SF_ERRNO_TRANSACTION_ABORT:
                    logger.debug(
                        "Transient transaction conflict (90232); will retry next cycle"
                    )
                    return
                if e.errno == _SF_ERRNO_UNKNOWN_FUNCTION:
                    logger.warning(
                        "Unknown function (2141); schema may still be deploying. "
                        "Statement: %s",
                        statement,
                    )
                    return
                raise

        self.run_with_session_retry(op)

    async def _push_task_internal(
        self,
        workflow_id: int,
        executor_type: ExecutorType,
        task_name: str,
        payload: TPayload,
        scope: str,
        priority: float = DEFAULT_PRIORITY,
        successor_task_id: int | None = None,
        is_blocked: bool = False,
        is_cleanup: bool = False,
    ) -> int | None:
        """
        Push a task into the task queue.

        Args:
            workflow_id: The ID of the workflow to which the task belongs.
            executor_type: The type of executor that should process the task.
            task_name: The name of the task.
            payload: The payload containing task data and metadata.
            scope: The hierarchical scope describing the task's purpose (e.g., 'Table[DB.SCHEMA.TABLE]::Preprocessing').
            priority: The priority of the task (default is 3).
            successor_task_id: The ID of the successor task, if any.
            is_blocked: Whether the task is initially blocked (default is False).
            is_cleanup: Whether this is a cleanup task (default is False).

        Returns:
            The ID of the newly created task, or None if creation failed.

        """
        affinity = await self.get_workflow_affinity(workflow_id) or None
        payload_json_string = serialize_to_json(
            dataclasses.asdict(payload), default=str
        )

        def op() -> int | None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    push_task_call_template(),
                    (
                        workflow_id,
                        executor_type.value,
                        task_name,
                        priority,
                        successor_task_id,
                        is_blocked,
                        affinity,
                        scope,
                        payload_json_string,
                        is_cleanup,
                    ),
                )
                row = cursor.fetchone()
                return row[0] if row else None

        task_id = self.run_with_session_retry(op)

        if (
            task_id is not None
            and executor_type == ExecutorType.WAREHOUSE
            and isinstance(payload, SnowflakeQueryTaskPayload)
            and payload.query_id
        ):
            with self._lock:
                self._pending_warehouse_tasks[task_id] = payload.query_id

        if (
            task_id is not None
            and executor_type == ExecutorType.SNOWPIPE
            and isinstance(payload, SnowpipeTaskPayload)
        ):
            with self._lock:
                self._pending_snowpipe_tasks[task_id] = (
                    payload.pipe_name,
                    payload.prefix,
                    payload.pipe_name_short,
                    payload.mode,
                )

        return task_id

    async def push_tasks_batch(
        self,
        tasks: list[Task[TPayload]],
    ) -> list[int]:
        """
        Push multiple tasks in a single INSERT statement, bypassing the stored procedure.

        IDs are pre-allocated from ``TASK_ID_SEQUENCE`` and written explicitly so the
        returned list matches the input order one-to-one without relying on any
        per-task uniqueness assumption (e.g. scope collisions are fine).
        """
        if not tasks:
            return []

        first_task = tasks[0]
        affinity = await self.get_workflow_affinity(first_task.workflow_id)
        qm = qualified_migration_schema()

        n = len(tasks)

        def allocate_ids_op() -> list[int]:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"SELECT {qm}.TASK_ID_SEQUENCE.NEXTVAL "
                    f"FROM TABLE(GENERATOR(ROWCOUNT => {n}))"
                )
                return [int(row[0]) for row in cursor.fetchall()]

        allocated_ids = self.run_with_session_retry(allocate_ids_op)
        if len(allocated_ids) != n:
            raise Exception(
                f"TASK_ID_SEQUENCE allocation returned {len(allocated_ids)} ids, "
                f"expected {n}"
            )

        chunk_size = self._BATCH_INSERT_CHUNK_SIZE
        for offset in range(0, len(tasks), chunk_size):
            chunk = tasks[offset : offset + chunk_size]
            chunk_ids = allocated_ids[offset : offset + chunk_size]
            self._push_tasks_batch_chunk(chunk, chunk_ids, affinity)

        logger.info(f"Batch-inserted {n} tasks for workflow {first_task.workflow_id}")
        return allocated_ids

    def _push_tasks_batch_chunk(
        self,
        tasks: list[Task[TPayload]],
        allocated_ids: list[int],
        affinity: str | None,
    ) -> None:
        """Insert a single chunk of tasks with the given pre-allocated IDs."""
        qm = qualified_migration_schema()
        value_rows: list[str] = []
        for task_id, task in zip(allocated_ids, tasks, strict=True):
            payload_json = escape_sql_string(
                serialize_to_json(dataclasses.asdict(task.payload), default=str)
            )
            successor = (
                str(task.successor_task_id)
                if task.successor_task_id is not None
                else "NULL"
            )
            if task.is_blocked:
                status = "blocked"
            elif task.executor_type in (
                ExecutorType.WAREHOUSE,
                ExecutorType.SNOWPIPE,
            ):
                status = "executing"
            else:
                status = "pending"
            escaped_name = escape_sql_string(task.task_name)
            escaped_scope = escape_sql_string(task.scope) if task.scope else ""
            affinity_sql = f"'{escape_sql_string(affinity)}'" if affinity else "NULL"
            leased_to_sql = "NULL"
            if task.executor_type == ExecutorType.WAREHOUSE:
                leased_to_sql = "'warehouse'"
            elif task.executor_type == ExecutorType.SNOWPIPE:
                leased_to_sql = "'snowpipe'"
            is_cleanup_sql = "TRUE" if task.is_cleanup else "FALSE"

            value_rows.append(
                f"({task_id}, {task.workflow_id}, '{escaped_name}', "
                f"'{task.executor_type.value}', {task.priority}, {affinity_sql}, "
                f"'{escaped_scope}', '{payload_json}', {successor}, '{status}', "
                f"{leased_to_sql}, {is_cleanup_sql})"
            )

        insert_sql = (
            f"INSERT INTO {qm}.TASK_QUEUE "
            "(ID, WORKFLOW_ID, NAME, EXECUTOR_TYPE, PRIORITY, AFFINITY, SCOPE, PAYLOAD, "
            "SUCCESSOR_TASK_ID, STATUS, LEASED_TO, START_TIME, IS_CLEANUP) "
            "SELECT column1, column2, column3, column4, column5, column6, column7, "
            "PARSE_JSON(column8), column9, column10, column11, "
            "CASE WHEN column11 IS NOT NULL THEN SYSDATE() END, "
            "column12 "
            f"FROM VALUES {', '.join(value_rows)}"
        )

        def insert_op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(insert_sql)

        self.run_with_session_retry(insert_op)

    async def push_independent_two_task_chains(
        self,
        chains: list[tuple[Task[TPayload], Task[TPayload]]],
    ) -> list[int]:
        """
        Override: batch-insert N independent [first -> second] chains in 3 SQL calls.

        Instead of 2N sequential stored procedure calls.
        """
        if not chains:
            return []

        # Prepare second tasks (blocked) as copies to avoid mutating caller's objects.
        # Preserve any pre-set successor_task_id for fan-in patterns.
        second_tasks: list[Task[TPayload]] = [
            dataclasses.replace(second, is_blocked=True) for _, second in chains
        ]

        # Batch-insert all second tasks
        second_task_ids = await self.push_tasks_batch(second_tasks)

        # Prepare first tasks (unblocked, successor = corresponding second task) as copies
        first_tasks: list[Task[TPayload]] = [
            dataclasses.replace(
                first, is_blocked=False, successor_task_id=second_task_ids[i]
            )
            for i, (first, _) in enumerate(chains)
        ]

        # Batch-insert all first tasks
        first_task_ids = await self.push_tasks_batch(first_tasks)

        all_ids = []
        for i in range(len(chains)):
            all_ids.append(first_task_ids[i])
            all_ids.append(second_task_ids[i])
        return all_ids

    async def check_tasks(
        self, workflow_id: int, task_ids: list[int]
    ) -> list[Task[TPayload]]:
        """Check tasks."""

        def op() -> list[Task[TPayload]]:
            with self.connection.cursor() as cursor:
                # TODO(SNOW-2687870): Do not use interpolation for writing array of ints in SQL code
                qm = qualified_migration_schema()
                cursor.execute(
                    f"CALL {qm}.CHECK_TASKS(%s, ARRAY_CONSTRUCT(%s)::ARRAY(INT))",
                    (workflow_id, task_ids),
                )
                rows = cursor.fetchall()
                return [self._map_task(row, workflow_id) for row in rows]

        return self.run_with_session_retry(op)

    async def unblock_tasks(self):
        """Unblocks tasks for which all predecessor tasks have been completed."""
        await self._execute_statement(
            f"CALL {qualified_migration_schema()}.UNBLOCK_TASKS()"
        )

    async def unblock_cleanup_tasks(self):
        """Unblock cleanup tasks whose workflow has no remaining non-terminal non-cleanup tasks."""
        await self._execute_statement(
            f"CALL {qualified_migration_schema()}.UNBLOCK_CLEANUP_TASKS()"
        )

    async def expire_leases(self):
        """Expire leases for tasks that have exceeded their lease duration."""
        await self._execute_statement(
            f"CALL {qualified_migration_schema()}.EXPIRE_LEASES()"
        )

    async def refresh_active_leases(self, task_ids: set[int]) -> None:
        """
        Refresh leases only for tasks actively being processed by a live worker.

        Uses inline SQL instead of a stored procedure because Snowflake SPs
        don't accept variable-length ID lists. The IDs come from an internal
        in-memory set (not user input), so interpolation is safe here.
        """
        if not task_ids:
            return
        ids_csv = ", ".join(str(tid) for tid in task_ids)

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"UPDATE {qualified_migration_schema()}.TASK_QUEUE "
                    f"SET LEASING_TIME = SYSDATE() "
                    f"WHERE ID IN ({ids_csv}) AND STATUS = '{TaskStatus.EXECUTING.value}'"
                )

        self.run_with_session_retry(op)

    async def refresh_warehouse_tasks(self):
        """
        Check tasks associated with queries running in a warehouse and mark them as complete.

        Uses the Snowflake Python connector's get_query_status() to check each
        pending warehouse task by query_id directly, instead of relying on
        QUERY_HISTORY_BY_WAREHOUSE() which can miss queries due to retention
        limits or timing issues.
        """
        with self._lock:
            if not self._warehouse_tasks_loaded:
                self._pending_warehouse_tasks = dict(
                    await self._fetch_pending_warehouse_tasks()
                )
                self._warehouse_tasks_loaded = True

            if not self._pending_warehouse_tasks:
                return

            logger.info(
                f"Checking status for {len(self._pending_warehouse_tasks)} pending warehouse task(s)"
            )
            completed_task_ids: list[int] = []
            for task_id, query_id in list(self._pending_warehouse_tasks.items()):
                try:
                    status = self.run_with_session_retry(
                        partial(
                            self.connection.get_query_status_throw_if_error,
                            query_id,
                        )
                    )
                except SnowflakeError as e:
                    error_message = str(e)
                    logger.warning(
                        f"Warehouse task {task_id} query failed: {error_message}"
                    )
                    await self._fail_warehouse_task(task_id, error_message)
                    completed_task_ids.append(task_id)
                    continue
                except Exception as e:
                    logger.warning(
                        f"Could not check status for warehouse task {task_id} "
                        f"(query_id={query_id}), will retry next cycle: {e}"
                    )
                    continue

                logger.info(
                    f"Warehouse task {task_id} (query_id={query_id}): status={status.name}"
                )

                if self.connection.is_still_running(status):
                    continue

                if status == QueryStatus.SUCCESS:
                    logger.info(f"Completing warehouse task {task_id}")
                    try:
                        await self._complete_warehouse_task(task_id)
                    except Exception as e:
                        logger.warning(
                            f"Could not mark warehouse task {task_id} as completed, "
                            f"will retry next cycle: {e}"
                        )
                        continue
                else:
                    logger.warning(
                        f"Warehouse task {task_id} query has unexpected terminal "
                        f"status: {status.name}, will retry next cycle"
                    )
                    continue
                completed_task_ids.append(task_id)

            for task_id in completed_task_ids:
                self._pending_warehouse_tasks.pop(task_id, None)

    async def _fetch_pending_warehouse_tasks(self) -> list[tuple[int, str]]:
        """Fetch all pending warehouse tasks and their associated query IDs from the database."""
        qm = qualified_migration_schema()

        def op() -> list[tuple[int, str]]:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"""
                    SELECT ID, PAYLOAD:query_id::TEXT AS QUERY_ID
                    FROM {qm}.TASK_QUEUE
                    WHERE EXECUTOR_TYPE = %s
                        AND STATUS IN (%s, %s)
                        AND PAYLOAD:query_id IS NOT NULL
                    """,
                    (
                        ExecutorType.WAREHOUSE.value,
                        TaskStatus.PENDING.value,
                        TaskStatus.EXECUTING.value,
                    ),
                )
                rows = cursor.fetchall()
                return [(int(row[0]), str(row[1])) for row in rows]

        return self.run_with_session_retry(op)

    async def _complete_warehouse_task(self, task_id: int) -> None:
        """Mark a warehouse task as completed via the COMPLETE_TASK stored procedure."""

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    complete_task_call_template(),
                    (ExecutorType.WAREHOUSE.value, task_id, None),
                )

        self.run_with_session_retry(op)

    async def _fail_warehouse_task(self, task_id: int, error_message: str) -> None:
        """Mark a warehouse task as failed via the FAIL_TASK stored procedure."""

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    fail_task_call_template(),
                    (task_id, ExecutorType.WAREHOUSE.value, error_message),
                )

        self.run_with_session_retry(op)

    async def refresh_snowpipe_tasks(self) -> None:
        """
        Check Snowpipe ingestion tasks and mark them as complete or failed.

        Two monitoring strategies are supported, selected by
        ``SnowpipeTaskPayload.mode``:

        - ``prefix``: scans the event table's ``file_lifecycle`` events for
          files under the refreshed prefix.
        - ``drain``: polls ``SYSTEM$PIPE_STATUS('<pipe>')`` to detect when the
          pipe is fully drained (no pending files, healthy execution state).

        Tasks still in ``BLOCKED`` state are kept in the in-memory tracker
        but skipped for this cycle: polling them would be wasted work since
        their upstream predecessors have not completed yet. When a predecessor
        completes, ``COMPLETE_TASK``'s eager-unblock branch flips the drain
        task to ``PENDING`` (or, for cleanup teardown tasks,
        ``UNBLOCK_CLEANUP_TASKS`` does so once every non-cleanup task in the
        workflow is terminal). The next refresh cycle then picks them up.
        """
        with self._lock:
            if not self._snowpipe_tasks_loaded:
                self._pending_snowpipe_tasks = dict(
                    await self._fetch_pending_snowpipe_tasks()
                )
                self._snowpipe_tasks_loaded = True

            if not self._pending_snowpipe_tasks:
                return

            try:
                current_statuses = await self._fetch_current_statuses_for(
                    list(self._pending_snowpipe_tasks.keys())
                )
            except Exception as e:
                logger.warning(
                    f"Could not fetch current snowpipe task statuses, "
                    f"skipping this refresh cycle: {e}"
                )
                return

            prefix_tasks: dict[int, tuple[str, str, str]] = {}
            drain_tasks: dict[int, tuple[str, str, str]] = {}
            blocked_count = 0
            vanished_task_ids: list[int] = []
            for task_id, (
                pipe_name,
                prefix,
                pipe_name_short,
                mode,
            ) in self._pending_snowpipe_tasks.items():
                status = current_statuses.get(task_id)
                if status is None:
                    vanished_task_ids.append(task_id)
                    continue
                if status == TaskStatus.BLOCKED.value:
                    blocked_count += 1
                    continue
                if mode == "drain":
                    drain_tasks[task_id] = (pipe_name, prefix, pipe_name_short)
                else:
                    prefix_tasks[task_id] = (pipe_name, prefix, pipe_name_short)

            for task_id in vanished_task_ids:
                self._pending_snowpipe_tasks.pop(task_id, None)

            if not prefix_tasks and not drain_tasks:
                return

            logger.info(
                f"Checking status for {len(prefix_tasks) + len(drain_tasks)} "
                f"pending snowpipe task(s)"
                + (
                    f" (skipping {blocked_count} still-blocked)"
                    if blocked_count
                    else ""
                )
            )

            completed_task_ids: list[int] = []

            if prefix_tasks:
                completed_task_ids.extend(
                    await self._refresh_snowpipe_prefix_tasks(prefix_tasks)
                )

            if drain_tasks:
                completed_task_ids.extend(
                    await self._refresh_snowpipe_drain_tasks(drain_tasks)
                )

            for task_id in completed_task_ids:
                self._pending_snowpipe_tasks.pop(task_id, None)

    async def _refresh_snowpipe_prefix_tasks(
        self, tasks: dict[int, tuple[str, str, str]]
    ) -> list[int]:
        """Check prefix-mode snowpipe tasks via the event table."""
        try:
            file_states = await self._fetch_snowpipe_file_states_for(
                {(short or name).upper() for name, _prefix, short in tasks.values()}
            )
        except Exception as e:
            logger.warning(f"Failed to query event table for snowpipe monitoring: {e}")
            return []

        completed_task_ids: list[int] = []
        for task_id, (pipe_name, prefix, pipe_name_short) in tasks.items():
            key = (pipe_name_short or pipe_name).upper()
            task_files = file_states.get(key, {})

            relevant: dict[str, str] = {}
            for file_path, state in task_files.items():
                if file_path.startswith(prefix) or not prefix:
                    relevant[file_path] = state

            if not relevant:
                logger.info(
                    f"Snowpipe task {task_id} (pipe={pipe_name}): "
                    f"no file_lifecycle events yet for prefix '{prefix}'"
                )
                continue

            errored_files = [fp for fp, st in relevant.items() if st == "ERRORED"]
            still_pending = [
                fp for fp, st in relevant.items() if st not in ("INGESTED", "ERRORED")
            ]

            if errored_files:
                error_message = (
                    f"{len(errored_files)} file(s) errored during Snowpipe ingestion: "
                    f"{errored_files[:5]}"
                )
                logger.warning(f"Snowpipe task {task_id}: {error_message}")
                await self._fail_snowpipe_task(task_id, error_message)
                completed_task_ids.append(task_id)
                continue

            if still_pending:
                logger.info(
                    f"Snowpipe task {task_id} (pipe={pipe_name}): "
                    f"{len(still_pending)} file(s) still ingesting"
                )
                continue

            logger.info(f"Completing snowpipe task {task_id}")
            try:
                await self._complete_snowpipe_task(task_id)
            except Exception as e:
                logger.warning(
                    f"Could not mark snowpipe task {task_id} as completed, "
                    f"will retry next cycle: {e}"
                )
                continue
            completed_task_ids.append(task_id)

        return completed_task_ids

    # Pipe execution states considered terminal/unhealthy. Any other state
    # (RUNNING, PAUSED transiently, etc.) means we keep waiting.
    _SNOWPIPE_BAD_STATES: ClassVar[frozenset[str]] = frozenset(
        {
            "STOPPED_CLONED",
            "STOPPED_MISSING_PIPE",
            "STOPPED_MISSING_TABLE",
            "STOPPED_STAGE_DROPPED",
            "STOPPED_FILE_FORMAT_DROPPED",
            "STOPPED_NOTIFICATION_INTEGRATION_DROPPED",
            "STOPPED_MISSING_INGEST_MANAGER",
            "STOPPED_FEATURE_DISABLED",
            "STOPPED_INTERNAL_ERROR",
        }
    )
    _SNOWPIPE_HEALTHY_IDLE_STATES: ClassVar[frozenset[str]] = frozenset(
        {"RUNNING", "PAUSED", "PAUSED_BY_USER", "PAUSED_BY_SNOWFLAKE_ADMIN"}
    )

    async def _refresh_snowpipe_drain_tasks(
        self, tasks: dict[int, tuple[str, str, str]]
    ) -> list[int]:
        """Check drain-mode snowpipe tasks via ``SYSTEM$PIPE_STATUS``."""
        completed_task_ids: list[int] = []

        # Group tasks by pipe to avoid redundant status calls.
        tasks_by_pipe: dict[str, list[int]] = {}
        for task_id, (pipe_name, _prefix, _short) in tasks.items():
            tasks_by_pipe.setdefault(pipe_name, []).append(task_id)

        for pipe_name, task_ids in tasks_by_pipe.items():
            try:
                status = await self._fetch_snowpipe_status(pipe_name)
            except Exception as e:
                logger.warning(
                    f"Could not query SYSTEM$PIPE_STATUS for {pipe_name}, "
                    f"will retry next cycle: {e}"
                )
                continue

            if status is None:
                logger.info(
                    f"SYSTEM$PIPE_STATUS returned no row for {pipe_name}; "
                    f"will retry next cycle"
                )
                continue

            execution_state = str(status.get("executionState", "")).upper()
            pending_file_count = status.get("pendingFileCount")
            try:
                pending_int = (
                    int(pending_file_count) if pending_file_count is not None else 0
                )
            except (TypeError, ValueError):
                pending_int = 0
            last_error = status.get("lastIngestedErrorMessage") or status.get("error")

            if execution_state in self._SNOWPIPE_BAD_STATES:
                error_message = (
                    f"Pipe {pipe_name} in unhealthy state '{execution_state}'"
                    + (f": {last_error}" if last_error else "")
                )
                for task_id in task_ids:
                    logger.warning(f"Snowpipe drain task {task_id}: {error_message}")
                    await self._fail_snowpipe_task(task_id, error_message)
                    completed_task_ids.append(task_id)
                continue

            if pending_int > 0:
                logger.info(
                    f"Snowpipe drain for {pipe_name}: "
                    f"{pending_int} file(s) still pending (state={execution_state})"
                )
                continue

            if (
                execution_state
                and execution_state not in self._SNOWPIPE_HEALTHY_IDLE_STATES
            ):
                logger.info(
                    f"Snowpipe drain for {pipe_name}: waiting for healthy idle "
                    f"state (current={execution_state})"
                )
                continue

            for task_id in task_ids:
                logger.info(f"Completing snowpipe drain task {task_id} for {pipe_name}")
                try:
                    await self._complete_snowpipe_task(task_id)
                except Exception as e:
                    logger.warning(
                        f"Could not mark snowpipe drain task {task_id} as completed, "
                        f"will retry next cycle: {e}"
                    )
                    continue
                completed_task_ids.append(task_id)

        return completed_task_ids

    async def _fetch_snowpipe_status(self, pipe_name: str) -> dict[str, Any] | None:
        """Query ``SYSTEM$PIPE_STATUS`` for a pipe and return the parsed JSON."""

        def op() -> dict[str, Any] | None:
            with self.connection.cursor() as cursor:
                cursor.execute(f"SELECT SYSTEM$PIPE_STATUS('{pipe_name}') AS STATUS")
                row = cursor.fetchone()
                if not row or row[0] is None:
                    return None
                raw = row[0]
                if isinstance(raw, (bytes, bytearray)):
                    raw = raw.decode("utf-8")
                try:
                    return json.loads(raw)
                except (TypeError, ValueError):
                    logger.warning(
                        f"SYSTEM$PIPE_STATUS for {pipe_name} returned unparseable "
                        f"payload: {raw!r}"
                    )
                    return None

        return self.run_with_session_retry(op)

    async def _fetch_pending_snowpipe_tasks(
        self,
    ) -> list[tuple[int, tuple[str, str, str, str]]]:
        """
        Fetch snowpipe tasks that may become pollable in the near future.

        We include ``BLOCKED`` rows in addition to ``PENDING``/``EXECUTING``
        so that drains whose upstream predecessors have not completed yet are
        still tracked in memory. :meth:`refresh_snowpipe_tasks` filters them
        out of each polling cycle via a cheap status re-read and picks them
        up automatically on the first cycle after they are unblocked.
        """
        qm = qualified_migration_schema()

        def op() -> list[tuple[int, tuple[str, str, str, str]]]:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"""
                    SELECT ID,
                           PAYLOAD:pipe_name::TEXT AS PIPE_NAME,
                           COALESCE(PAYLOAD:prefix::TEXT, '') AS PREFIX,
                           COALESCE(PAYLOAD:pipe_name_short::TEXT, '') AS PIPE_NAME_SHORT,
                           COALESCE(PAYLOAD:mode::TEXT, 'prefix') AS MODE
                    FROM {qm}.TASK_QUEUE
                    WHERE EXECUTOR_TYPE = %s
                        AND STATUS IN (%s, %s, %s)
                        AND PAYLOAD:pipe_name IS NOT NULL
                    """,
                    (
                        ExecutorType.SNOWPIPE.value,
                        TaskStatus.PENDING.value,
                        TaskStatus.EXECUTING.value,
                        TaskStatus.BLOCKED.value,
                    ),
                )
                rows = cursor.fetchall()
                return [
                    (
                        int(row[0]),
                        (str(row[1]), str(row[2]), str(row[3]), str(row[4])),
                    )
                    for row in rows
                ]

        return self.run_with_session_retry(op)

    async def _fetch_current_statuses_for(self, task_ids: list[int]) -> dict[int, str]:
        """
        Bulk-read current ``STATUS`` values for a set of task ids.

        Used by :meth:`refresh_snowpipe_tasks` to skip tasks that are still
        ``BLOCKED`` (their upstream predecessors have not completed, so any
        ``SYSTEM$PIPE_STATUS`` reading would be meaningless).
        """
        if not task_ids:
            return {}
        qm = qualified_migration_schema()
        ids_csv = ", ".join(str(int(t)) for t in task_ids)

        def op() -> dict[int, str]:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"SELECT ID, STATUS FROM {qm}.TASK_QUEUE "
                    f"WHERE ID IN ({ids_csv})"
                )
                return {int(row[0]): str(row[1]) for row in cursor.fetchall()}

        return self.run_with_session_retry(op)

    async def _fetch_snowpipe_file_states_for(
        self,
        pipe_names: set[str],
    ) -> dict[str, dict[str, str]]:
        """
        Query the event table for file_lifecycle events for a specific set of pipes.

        Returns a nested dict: ``{pipe_name_short: {file_path: latest_state}}``.
        The latest state per file is determined by taking the last event by
        timestamp (the query orders by timestamp and Python overwrites earlier
        entries for the same file).

        Pipe names are compared case-insensitively; callers should upper-case
        their inputs to stay consistent with Snowflake's identifier casing.
        """
        if not pipe_names:
            return {}

        pipe_names_csv = ", ".join(f"'{p}'" for p in pipe_names)
        evt = qualified_event_table()

        sql = f"""
            SELECT
                UPPER(resource_attributes:"snow.pipe.name"::TEXT) AS pipe_name,
                record_attributes:"snow.file.path"::TEXT AS file_path,
                PARSE_JSON(value):state::TEXT AS state
            FROM {evt}
            WHERE record:"name"::TEXT = 'file_lifecycle'
              AND UPPER(resource_attributes:"snow.pipe.name"::TEXT) IN ({pipe_names_csv})
              AND timestamp >= DATEADD(HOURS, -24, CURRENT_TIMESTAMP())
            ORDER BY timestamp
        """

        def op() -> list[Any]:
            with self.connection.cursor() as cursor:
                cursor.execute(sql)
                return cursor.fetchall()

        rows = self.run_with_session_retry(op)

        result: dict[str, dict[str, str]] = {}
        for row in rows:
            pname = str(row[0]).upper()
            fpath = str(row[1])
            state = str(row[2])
            result.setdefault(pname, {})[fpath] = state

        return result

    async def _complete_snowpipe_task(self, task_id: int) -> None:
        """
        Mark a snowpipe task as completed via the COMPLETE_TASK stored procedure.

        Snowpipe tasks are leased to the ``'snowpipe'`` sentinel at push time
        (see ``push_task_variant.sql.j2``), so we can go through ``COMPLETE_TASK``
        and inherit its eager-unblock branch for the successor task.
        """

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    complete_task_call_template(),
                    (ExecutorType.SNOWPIPE.value, task_id, None),
                )

        self.run_with_session_retry(op)

    async def _fail_snowpipe_task(self, task_id: int, error_message: str) -> None:
        """
        Mark a snowpipe task as failed via the FAIL_TASK stored procedure.

        Snowpipe tasks are leased to the ``'snowpipe'`` sentinel at push time
        (see ``push_task_variant.sql.j2``), so we can go through ``FAIL_TASK``
        and inherit its cascade-on-terminal-failure behavior for successors.
        """

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    fail_task_call_template(),
                    (task_id, ExecutorType.SNOWPIPE.value, error_message),
                )

        self.run_with_session_retry(op)

    async def get_tasks(self, max_tasks: int | None = None) -> list[Task]:
        """
        Get tasks for a workflow.

        Args:
            max_tasks: Maximum number of tasks to pull. If None, uses
                max_tasks_to_pull (1000).

        Returns:
            The list of tasks for the workflow.

        """
        limit = max_tasks if max_tasks is not None else self.max_tasks_to_pull

        def op() -> list[Any]:
            with self.connection.cursor(DictCursor) as cursor:
                cursor.execute(
                    pull_tasks_call_template(),
                    (
                        ExecutorType.ORCHESTRATOR.value,
                        ExecutorType.ORCHESTRATOR.value,
                        self.affinity,
                        limit,
                    ),
                )
                return cursor.fetchall()

        try:
            rows = self.run_with_session_retry(op)
        except sf_errors.ProgrammingError as e:
            if e.errno == _SF_ERRNO_TRANSACTION_ABORT:
                logger.debug(
                    "Transient lock contention (90232) during PULL_TASKS; "
                    "will retry next cycle"
                )
                return []
            raise
        logger.info("PULL_TASKS returned %d row(s) (limit=%d)", len(rows), limit)

        tasks = [
            self._map_task_by_column_name(
                row,
                executor_type=ExecutorType.ORCHESTRATOR,
                status=TaskStatus.EXECUTING,
            )
            for row in rows
        ]
        filtered_tasks = [task for task in tasks if task is not None]
        if len(filtered_tasks) != len(tasks):
            logger.warning(f"{len(tasks) - len(filtered_tasks)} task(s) failed to map")
        return filtered_tasks

    async def has_workflow_started(self, workflow_id: int) -> bool:
        """
        Check if the workflow has started.

        This checks if the workflow has any tasks in the task queue.
        """

        def op() -> bool:
            with self.connection.cursor() as cursor:
                cursor.execute(has_workflow_started_call_template(), (workflow_id,))
                row = cursor.fetchone()
                return bool(row[0]) if row else False

        return self.run_with_session_retry(op)

    async def complete_task(
        self,
        consumer_type: ExecutorType,
        task_id: int,
        execution_profile: str | None = None,
    ) -> bool:
        """
        Complete a task.

        Args:
            consumer_type: The type of consumer that completed the task.
            task_id: The ID of the task to complete.
            execution_profile: Optional JSON string with step-level timing data.

        Returns:
            True if the task was successfully completed, False otherwise.

        """

        def op() -> bool:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    complete_task_call_template(),
                    (consumer_type.value, task_id, execution_profile),
                )
                row = cursor.fetchone()
                return row[0] if row else False

        return self.run_with_session_retry(op)

    async def fail_task(
        self, consumer_id: str, task_id: int, error_message: str
    ) -> bool:
        """
        Mark a task as failed.

        Args:
            consumer_id: The ID of the consumer that failed the task.
            task_id: The ID of the task to mark as failed.
            error_message: The error message describing the failure.

        Returns:
            True if the task was marked as failed successfully, False otherwise.

        """

        def op() -> bool:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    fail_task_call_template(),
                    (task_id, consumer_id, error_message),
                )
                row = cursor.fetchone()
                return row[0] if row else False

        return self.run_with_session_retry(op)

    async def warn_task(self, task_id: int, warning_message: str) -> None:
        """Attach a non-blocking warning message to a task."""
        qm = qualified_migration_schema()

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"UPDATE {qm}.TASK_QUEUE SET LAST_WARNING_MESSAGE = %s WHERE ID = %s",
                    (warning_message, task_id),
                )

        self.run_with_session_retry(op)

    async def get_pending_workflows(self) -> list[Workflow]:
        """
        Get pending workflows to be started.

        Returns:
            The list of pending workflows to be started.

        """

        def op() -> list[Workflow]:
            with self.connection.cursor(DictCursor) as cursor:
                cursor.execute(get_pending_workflows_call_template(), (self.affinity,))
                rows = cursor.fetchall()
                return [self._map_row_to_workflow(row) for row in rows]

        return self.run_with_session_retry(op)

    async def complete_workflows(self):
        """Complete executing workflows for which all tasks are in terminal state."""
        await self._execute_statement(complete_workflows_call_template())

    async def set_workflow_running(self, workflow_id: int) -> None:
        """Transition a workflow from 'initializing' to 'running'."""
        qm = qualified_migration_schema()

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"""
                    UPDATE {qm}.WORKFLOW
                    SET STATUS = %s,
                        INITIALIZATION_START_TIME = NULL
                    WHERE ID = %s AND STATUS = %s
                    """,
                    (
                        WorkflowStatus.RUNNING.value,
                        workflow_id,
                        WorkflowStatus.INITIALIZING.value,
                    ),
                )

        self.run_with_session_retry(op)

    async def fail_workflow_initialization(
        self, workflow_id: int, error_message: str
    ) -> None:
        """Record a failed initialization attempt for a workflow."""
        qm = qualified_migration_schema()

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    f"""
                    UPDATE {qm}.WORKFLOW
                    SET
                        INITIALIZATION_FAILURES = INITIALIZATION_FAILURES + 1,
                        LAST_ERROR_MESSAGE = %s,
                        INITIALIZATION_START_TIME = NULL,
                        STATUS = CASE
                            WHEN INITIALIZATION_FAILURES + 1 >= %s THEN 'finished'
                            ELSE 'pending'
                        END,
                        END_TIME = CASE
                            WHEN INITIALIZATION_FAILURES + 1 >= %s THEN SYSDATE()
                            ELSE END_TIME
                        END
                    WHERE ID = %s AND STATUS = %s
                    """,
                    (
                        error_message,
                        self.MAX_INITIALIZATION_FAILURES,
                        self.MAX_INITIALIZATION_FAILURES,
                        workflow_id,
                        WorkflowStatus.INITIALIZING.value,
                    ),
                )

        self.run_with_session_retry(op)

    async def expire_stale_initializations(self) -> None:
        """Expire workflows stuck in 'initializing' for longer than the timeout."""
        await self._execute_statement(expire_stale_initializations_call_template())

    async def delete_workflow_tasks(self, workflow_id: int) -> None:
        """Delete all tasks, table metadata, and partition metadata for a workflow."""

        def op() -> None:
            with self.connection.cursor() as cursor:
                cursor.execute(delete_workflow_tasks_call_template(), (workflow_id,))

        self.run_with_session_retry(op)

    @staticmethod
    def _parse_workflow_status(raw_status: str) -> WorkflowStatus:

        if raw_status.startswith("assigning"):
            """
            If we get a status that starts with "assigning",
            it means that the workflow is being assigned to an orchestrator and will move to RUNNING state immediately
            """
            return WorkflowStatus.RUNNING
        return WorkflowStatus(raw_status)

    def _map_row_to_workflow(self, row: dict) -> Workflow:
        return Workflow(
            id=row[workflow_columns.ID],
            name=row[workflow_columns.NAME],
            source_platform=SourceType.from_string(
                row[workflow_columns.SOURCE_PLATFORM]
            ),
            target_cloud_type=row[workflow_columns.TARGET_CLOUD_TYPE],
            target_cloud_stage_name=row[workflow_columns.TARGET_CLOUD_STAGE_NAME],
            target_cloud_url=row.get(workflow_columns.TARGET_CLOUD_URL),
            schema_version=row.get(workflow_columns.SCHEMA_VERSION, ""),
            workflow_type=row[workflow_columns.WORKFLOW_TYPE],
            initiator_id=row.get(workflow_columns.INITIATOR_ID, ""),
            status=self._parse_workflow_status(row[workflow_columns.STATUS]),
            configuration=json.loads(row[workflow_columns.CONFIGURATION]),
            creation_time=row.get(workflow_columns.CREATION_TIME),
            end_time=row.get(workflow_columns.END_TIME),
            affinity=row.get(workflow_columns.AFFINITY) or None,
            initialization_failures=row.get(
                workflow_columns.INITIALIZATION_FAILURES, 0
            ),
        )

    async def get_workflow_affinity(self, workflow_id: int) -> str | None:
        """
        Get the affinity group for a workflow.

        Args:
            workflow_id: The ID of the workflow.

        Returns:
            The affinity group for the workflow, or None if not found.

        """
        with self._lock:
            if workflow_id in self.workflow_affinity_by_id:
                return self.workflow_affinity_by_id[workflow_id]

        qm = qualified_migration_schema()

        def op() -> dict[str, Any] | None:
            with self.connection.cursor(DictCursor) as cursor:
                cursor.execute(
                    f"""
                    SELECT AFFINITY
                    FROM {qm}.WORKFLOW
                    WHERE ID = %s
                    """,
                    (workflow_id,),
                )
                return cursor.fetchone()

        row = self.run_with_session_retry(op)
        if row is None:
            logger.warning(
                f"Workflow with ID {workflow_id} not found (when looking for affinity)."
            )
            return None

        affinity: str | None = row.get(workflow_columns.AFFINITY) or None
        with self._lock:
            self.workflow_affinity_by_id[workflow_id] = affinity
        return affinity
