from typing import Generic, Self, TypeVar

from data_migration_orchestrator.cloud_core.constants.priorities import DEFAULT_PRIORITY
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task


TPayload = TypeVar("TPayload")


class TaskBuilder(Generic[TPayload]):
    """Builder for the Task class."""

    def __init__(
        self,
        workflow_id: int,
        task_name: str,
        executor_type: ExecutorType,
        payload: TPayload,
        scope: str,
    ):
        """
        Create a task that will be queued.

        Do not use this to create tasks that have already been queued.
        """
        self.internal_task: Task = Task(
            workflow_id=workflow_id,
            executor_type=executor_type,
            task_name=task_name,
            priority=DEFAULT_PRIORITY,
            payload=payload,
            scope=scope,
            successor_task_id=None,
            is_blocked=False,
            is_cleanup=False,
            id=None,
            status=None,
        )
        # TODO(SNOW-3113561): Infer executor type according to task kind?

    def with_priority(self, priority: float) -> Self:
        """Set task priority (lower number = higher priority)."""
        self.internal_task.priority = priority
        return self

    def with_successor(self, successor_task_id: int | None) -> Self:
        """Set the ID of the task to unblock when this task completes."""
        self.internal_task.successor_task_id = successor_task_id
        return self

    def blocked(self) -> Self:
        """Set whether the task starts in blocked state."""
        self.internal_task.is_blocked = True
        return self

    def cleanup(self) -> Self:
        """Mark as a cleanup task that runs even when predecessors fail."""
        self.internal_task.is_cleanup = True
        return self

    def build(self) -> Task[TPayload]:
        """Return the built Task object."""
        return self.internal_task
