"""Task model for representing tasks in the migration system."""

from dataclasses import dataclass
from typing import Generic, TypeVar

from data_migration_orchestrator.cloud_core.constants.priorities import DEFAULT_PRIORITY
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus


TPayload = TypeVar("TPayload")


@dataclass
class Task(Generic[TPayload]):
    """
    Task for data migration workflows.

    This class serves dual purposes:
    1. Task Specification (before queueing): Created by TaskBuilder with all metadata
    2. Task Instance (after queueing): Retrieved from queue with id and status assigned

    When created by builder:
        - id is None (assigned by queue)
        - status is None (assigned by queue)
        - All other fields are populated

    When retrieved from queue:
        - id is assigned
        - status is assigned
        - All fields are populated
    """

    # Required fields
    workflow_id: int
    """The workflow this task belongs to"""

    executor_type: ExecutorType
    """The type of executor that will process this task"""

    task_name: str
    """Human-readable name for the task"""

    payload: TPayload
    """The task payload containing task-specific data"""

    scope: str
    """Hierarchical scope describing the task's purpose (e.g., 'Table[DB.SCHEMA.TABLE]::Preprocessing')"""

    # Optional fields with defaults
    priority: float = DEFAULT_PRIORITY
    """Task priority (lower number = higher priority)"""

    successor_task_id: int | None = None
    """Task to unblock when this task completes"""

    is_blocked: bool = False
    """Whether the task starts in blocked state"""

    is_cleanup: bool = False
    """Whether this is a cleanup task that must run even when predecessors fail"""

    id: int | None = None
    """Task ID (assigned when queued, None before queueing)"""

    status: TaskStatus | None = None
    """Task status (assigned when queued, None before queueing)"""

    def is_terminal(self) -> bool:
        """
        Check if the task is in a terminal state.

        Returns:
            True if task is completed, failed, or abandoned

        Raises:
            ValueError: If status is None (task not yet queued)

        """
        if self.status is None:
            raise ValueError("Cannot check terminal state of task without status")

        return self.status in (
            TaskStatus.COMPLETED,
            TaskStatus.FAILED,
            TaskStatus.ABANDONED,
        )

    def is_queued(self) -> bool:
        """
        Check if this task has been queued.

        Returns:
            True if task has been assigned an id and status

        """
        return self.id is not None and self.status is not None
