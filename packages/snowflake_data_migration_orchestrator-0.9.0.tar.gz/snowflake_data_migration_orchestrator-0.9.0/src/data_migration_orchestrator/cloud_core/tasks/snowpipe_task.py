from dataclasses import dataclass
from typing import Literal


SNOWPIPE_TASK_PAYLOAD_KIND = "snowpipe_ingestion"

SnowpipeMode = Literal["prefix", "drain"]


@dataclass
class SnowpipeTaskPayload:
    """
    Payload for a Snowpipe ingestion task.

    Supports two monitoring modes:

    - ``prefix`` (default): tracks a single ``ALTER PIPE REFRESH PREFIX='...'``
      invocation by scanning ``file_lifecycle`` events for files under ``prefix``.
      Used when the orchestrator itself triggered the refresh.
    - ``drain``: waits for a pipe to fully drain by polling
      ``SYSTEM$PIPE_STATUS('<pipe>')``. Completes when
      ``pendingFileCount == 0`` and ``executionState`` is a healthy idle state.
      Used when some other component (e.g. the data exchange agent) issues the
      refresh and the orchestrator only needs to wait for ingestion to finish.
    """

    pipe_name: str
    """Fully qualified Snowpipe name (e.g., DB.TEMP.DMO_PIPE_1_MY_TABLE)."""

    prefix: str = ""
    """Stage path prefix that was refreshed (ignored in ``drain`` mode)."""

    pipe_name_short: str = ""
    """Unqualified pipe name (e.g., DMO_PIPE_1_MY_TABLE).

    The event table ``resource_attributes:"snow.pipe.name"`` stores only the
    short name, so this is needed for filtering file_lifecycle events in
    ``prefix`` mode.
    """

    mode: SnowpipeMode = "prefix"
    """Monitoring strategy. See class docstring."""

    kind: Literal["snowpipe_ingestion"] = SNOWPIPE_TASK_PAYLOAD_KIND
