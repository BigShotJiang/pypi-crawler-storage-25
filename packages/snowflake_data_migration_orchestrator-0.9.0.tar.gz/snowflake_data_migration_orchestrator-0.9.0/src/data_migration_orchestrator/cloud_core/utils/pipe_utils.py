"""
Shared Snowpipe SQL helpers used by both data migration and data validation.

These helpers stay intentionally minimal: they only cover the DDL fragments
shared across Snowpipe users (``DROP PIPE`` and the
``SET LOG_EVENT_LEVEL = DEBUG`` hook for event-table monitoring). Building
the ``CREATE PIPE`` statement itself is domain-specific (Parquet for DMO,
CSV with explicit column mappings and regex PATTERNs for DV) and stays with
each domain's own ``pipe_utils``.

Only the DMO migration pipes enable ``LOG_EVENT_LEVEL = DEBUG`` because
they are monitored by scanning ``file_lifecycle`` events in the account
event table. DV pipes are monitored via ``SYSTEM$PIPE_STATUS`` (drain
mode) and therefore leave ``LOG_EVENT_LEVEL`` at the account default.
"""

from __future__ import annotations


def build_drop_pipe_sql(pipe_name: str) -> str:
    """Return the idempotent ``DROP PIPE IF EXISTS`` statement."""
    return f"DROP PIPE IF EXISTS {pipe_name}"


def build_enable_event_logging_sql(pipe_name: str) -> str:
    """
    Return the ``ALTER PIPE`` statement that enables event-table logging.

    ``LOG_EVENT_LEVEL = DEBUG`` surfaces Snowpipe ``file_lifecycle``
    events (RECEIVED / INGESTED) in the account event table, which the
    DMO migration pipes rely on for ingestion monitoring. DV pipes use
    ``SYSTEM$PIPE_STATUS`` instead and must not call this. See:
    https://docs.snowflake.com/en/user-guide/data-load-snowpipe-monitor-events
    """
    return f"ALTER PIPE {pipe_name} SET LOG_EVENT_LEVEL = DEBUG"
