"""Shared low-level utilities used by both migration and validation flows."""
