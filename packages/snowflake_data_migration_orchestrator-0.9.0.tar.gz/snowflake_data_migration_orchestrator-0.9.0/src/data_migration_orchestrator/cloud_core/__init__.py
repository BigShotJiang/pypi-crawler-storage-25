"""The Cloud Core module provides foundatinal components for working with Cloud Workflows and Cloud Tasks."""

from .warehouse import Warehouse


__all__ = ["Warehouse"]
