"""UnsupportedPayloadKindError exception."""


class UnsupportedPayloadKindError(Exception):
    """
    Exception raised when no handler is registered for a given payload kind.

    This exception is raised by TaskHandlerFactory when attempting to get or create
    a handler for a task payload kind that has no registered handler.
    """

    def __init__(
        self,
        payload_kind: str,
        available_kinds: list[str] | None = None,
    ):
        """
        Initialize the exception.

        Args:
            payload_kind: The unsupported payload kind that was requested
            available_kinds: Optional list of available/registered payload kinds

        """
        self.payload_kind = payload_kind
        self.available_kinds = available_kinds or []

        message = f"No handler registered for payload kind: {payload_kind}"
        if self.available_kinds:
            message += f". Available handlers: {self.available_kinds}"

        super().__init__(message)
