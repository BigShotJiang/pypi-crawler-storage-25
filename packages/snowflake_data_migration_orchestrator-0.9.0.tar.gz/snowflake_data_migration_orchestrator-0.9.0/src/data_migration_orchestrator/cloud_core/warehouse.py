from typing import Any

from data_migration_orchestrator.cloud_core.connection_manager import (
    SnowflakeConnectionLike,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.table_task_queue import (
    TableTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.snowpipe_task import (
    SnowpipeTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder


class Warehouse:
    """Represents a Snowflake warehouse and exposes operations associated with it."""

    def __init__(self, task_queue: TableTaskQueue[Any]) -> None:
        """
        Initialize using the task queue's Snowflake connection.

        Args:
            task_queue: Task queue whose per-thread Snowflake connection is used for
                warehouse queries (same connection as queue operations after workers
                call ``register_thread_connection``).

        """
        self.task_queue = task_queue

    @property
    def conn(self) -> SnowflakeConnectionLike:
        """Snowflake connection for the current thread (via the task queue)."""
        return self.task_queue.connection

    async def execute_snowflake_query_and_push_task(
        self,
        workflow_id: int,
        query: str,
        *args: Any,
        task_name: str,
        scope: str,
        priority: float,
        successor_task_id: int | None = None,
    ) -> int:
        """
        Execute a Snowflake query and push a task to the queue.

        Args:
            workflow_id: The workflow ID.
            query: The SQL query to execute.
            *args: Query parameters.
            task_name: The name of the task.
            scope: The hierarchical scope for this task (e.g., 'Table[DB.SCHEMA.TABLE]::Partition[0]::Loading')
            priority: The priority of the task.
            successor_task_id: Optional ID of the successor task.

        Returns:
            The task ID.

        """
        query_id = await self.execute_async_query(query, list(args))
        payload = SnowflakeQueryTaskPayload(query=query, query_id=query_id)
        task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=task_name,
                executor_type=ExecutorType.WAREHOUSE,
                payload=payload,
                scope=scope,
            )
            .with_successor(successor_task_id)
            .with_priority(priority)
            .build()
        )

        return await self.task_queue.push_task(task)

    async def execute_snowpipe_refresh_and_push_task(
        self,
        workflow_id: int,
        pipe_name: str,
        prefix: str,
        *,
        task_name: str,
        scope: str,
        priority: float,
        successor_task_id: int | None = None,
    ) -> int:
        """
        Refresh a Snowpipe for a given prefix and push a monitoring task.

        Issues ``ALTER PIPE ... REFRESH PREFIX='...'`` synchronously, then
        creates a task with ``ExecutorType.SNOWPIPE`` so the book-keeping loop
        can track ingestion progress.

        Args:
            workflow_id: The workflow ID.
            pipe_name: Fully qualified Snowpipe name.
            prefix: Stage path prefix to refresh.
            task_name: Human-readable task name.
            scope: Hierarchical scope for this task.
            priority: Task priority.
            successor_task_id: Optional successor task to unblock on completion.

        Returns:
            The task ID.

        """
        refresh_sql = f"ALTER PIPE {pipe_name} REFRESH PREFIX='{prefix}'"
        await self.execute_sync_query(refresh_sql)

        short_name = pipe_name.rsplit(".", 1)[-1] if "." in pipe_name else pipe_name
        payload = SnowpipeTaskPayload(
            pipe_name=pipe_name,
            prefix=prefix,
            pipe_name_short=short_name,
        )
        task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=task_name,
                executor_type=ExecutorType.SNOWPIPE,
                payload=payload,
                scope=scope,
            )
            .with_successor(successor_task_id)
            .with_priority(priority)
            .build()
        )

        return await self.task_queue.push_task(task)

    async def execute_snowpipe_drain_and_push_task(
        self,
        workflow_id: int,
        pipe_name: str,
        *,
        task_name: str,
        scope: str,
        priority: float,
        successor_task_id: int | None = None,
        is_blocked: bool = False,
    ) -> int:
        """
        Push a Snowpipe drain-monitoring task without issuing any refresh.

        Unlike :meth:`execute_snowpipe_refresh_and_push_task`, this helper does
        not call ``ALTER PIPE REFRESH`` — it only creates a ``SNOWPIPE`` task in
        ``drain`` mode. Use this when another component (e.g. the data exchange
        agent) is responsible for triggering refreshes and the orchestrator just
        needs to wait for ingestion to complete by polling
        ``SYSTEM$PIPE_STATUS``.

        Args:
            workflow_id: The workflow ID.
            pipe_name: Fully qualified Snowpipe name.
            task_name: Human-readable task name.
            scope: Hierarchical scope for this task.
            priority: Task priority.
            successor_task_id: Optional successor task to unblock on completion.
            is_blocked: Whether the task should start in ``blocked`` state (used
                when the drain task must wait on upstream DEA tasks).

        Returns:
            The task ID.

        """
        short_name = pipe_name.rsplit(".", 1)[-1] if "." in pipe_name else pipe_name
        payload = SnowpipeTaskPayload(
            pipe_name=pipe_name,
            prefix="",
            pipe_name_short=short_name,
            mode="drain",
        )
        builder = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=task_name,
                executor_type=ExecutorType.SNOWPIPE,
                payload=payload,
                scope=scope,
            )
            .with_successor(successor_task_id)
            .with_priority(priority)
        )
        if is_blocked:
            builder = builder.blocked()
        task = builder.build()

        return await self.task_queue.push_task(task)

    async def execute_async_query(self, query: str, args: list[Any]) -> str:
        """
        Execute a query asynchronously in Snowflake and return the query ID.

        Args:
            query: The SQL query to execute.
            args: Query parameters.

        Returns:
            The query ID from Snowflake.

        Raises:
            Exception: If the query execution fails or query ID is not returned.

        """
        if query == "":
            # TODO(SNOW-2860272): Currently we are not handling empty queries.
            return ""

        def op() -> str:
            with self.conn.cursor() as cursor:
                query_data = cursor.execute_async(query, args if args else None)
            qid: str | None = query_data.get("queryId")
            if qid is None:
                raise RuntimeError("Failed to execute query in Snowflake")
            return qid

        return self.task_queue.run_with_session_retry(op)

    async def execute_sync_query(self, query: str) -> list[dict[str, Any]]:
        """
        Execute a query synchronously and return results.

        Args:
            query: The SQL query to execute.

        Returns:
            List of dictionaries representing query results.

        Raises:
            Exception: If the query execution fails.

        """

        def op() -> list[dict[str, Any]]:
            with self.conn.cursor() as cursor:
                try:
                    cursor.execute(query)
                    rows = cursor.fetchall()
                    columns = (
                        [desc[0] for desc in cursor.description]
                        if cursor.description
                        else []
                    )
                    return [dict(zip(columns, row, strict=True)) for row in rows]
                except Exception as e:
                    raise RuntimeError(
                        f"Failed to execute query. Query: {query}. Error: {e}"
                    ) from e

        return self.task_queue.run_with_session_retry(op)
