from dataclasses import dataclass
from datetime import datetime

from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from shared.enums.source_type import SourceType


@dataclass
class Workflow:
    """Workflow model for representing workflows in the migration system."""

    id: int
    """Workflow ID"""

    name: str
    """The name given by the user to this data migration job/workflow"""

    source_platform: SourceType
    """The source platform to be migrated from"""

    target_cloud_type: str
    """The type of cloud storage to be used for the target"""

    target_cloud_stage_name: str
    """The name of the stage to be used for the target"""

    target_cloud_url: str | None
    """The URL of the cloud storage to be used for the target"""

    schema_version: str
    """The version of the schema"""

    workflow_type: str
    """The type of workflow"""

    initiator_id: str
    """The ID of the initiator of the workflow"""

    status: WorkflowStatus
    """The status of the workflow"""

    affinity: str | None = None
    """The affinity group for the workflow"""

    configuration: dict | None = None  # TODO: Change type for this
    """The configuration of the workflow as JSON"""

    creation_time: datetime | None = None
    """The time at which the workflow was created"""

    end_time: datetime | None = None
    """The time at which the workflow was completed (or definitely marked as failed)"""

    last_error_message: str | None = None
    """The last error message related to workflow initialization"""

    last_warning_message: str | None = None
    """The last warning message related to workflow configuration"""

    initialization_start_time: datetime | None = None
    """The time at which task initialization began"""

    initialization_failures: int = 0
    """The number of times task initialization has failed"""
