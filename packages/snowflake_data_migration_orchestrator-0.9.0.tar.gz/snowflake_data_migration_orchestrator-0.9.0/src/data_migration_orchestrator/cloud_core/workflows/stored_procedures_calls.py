"""Templates for workflow-related Snowflake stored procedure calls."""

from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


def get_pending_workflows_call_template() -> str:
    """Return parameterized SQL template for GET_PENDING_WORKFLOWS."""
    return f"CALL {qualified_migration_schema()}.GET_PENDING_WORKFLOWS(%s)"


def complete_workflows_call_template() -> str:
    """Return SQL template for COMPLETE_WORKFLOWS."""
    return f"CALL {qualified_migration_schema()}.COMPLETE_WORKFLOWS()"


def expire_stale_initializations_call_template() -> str:
    """Return SQL template for EXPIRE_STALE_INITIALIZATIONS."""
    return f"CALL {qualified_migration_schema()}.EXPIRE_STALE_INITIALIZATIONS()"


def delete_workflow_tasks_call_template() -> str:
    """Return parameterized SQL template for DELETE_WORKFLOW_TASKS."""
    return f"CALL {qualified_migration_schema()}.DELETE_WORKFLOW_TASKS(%s)"
