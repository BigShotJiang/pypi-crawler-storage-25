"""
Base workflow initializer class.

This module defines the abstract base class for all workflow initializers.
Workflow initializers are responsible for creating the initial set of tasks
for a workflow based on its configuration.
"""

from abc import ABC, abstractmethod

from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow


class BaseWorkflowInitializer(ABC):
    """
    Abstract base class for workflow initializers.

    Workflow initializers are responsible for creating the initial set of tasks
    for a workflow based on its type and configuration. Each workflow type can
    have its own initializer that defines its specific task creation logic.

    This follows the Strategy pattern, where different workflow types can have
    different strategies for creating initial tasks.

    Attributes:
        task_factory: Factory for creating task objects
        queue_manager: Manager for queuing tasks
        warehouse_proxy: Proxy for executing warehouse operations

    """

    @abstractmethod
    async def create_initial_tasks(self, workflow: Workflow) -> None:
        """
        Create the initial set of tasks for a workflow.

        This is the main entry point for task creation. Subclasses must implement
        this method to define the specific logic for their workflow type.

        Args:
            workflow: The workflow to create tasks for

        Raises:
            ConfigurationError: If the workflow configuration is invalid
            Exception: If task creation fails

        """
        ...
