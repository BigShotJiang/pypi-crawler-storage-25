from os import getenv


"""
The name of the environment variable that indicate the affinity of this orchestrator instance.
Orchestrators will only pick up workflows and tasks that match their affinity (or have no affinity set).
Supports wildcard patterns using '*' (e.g. "A*" matches "ABLUE", "ARED", etc.).
"""
ORCHESTRATOR_AFFINITY_ENV_VAR = "DATA_MIGRATION_ORCHESTRATOR_AFFINITY"


def get_affinity_from_env() -> str | None:
    """
    Retrieve the affinity value from environment variables.

    Returns:
        The affinity string if set, otherwise None.

    """
    return getenv(ORCHESTRATOR_AFFINITY_ENV_VAR)
