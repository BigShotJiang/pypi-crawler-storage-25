"""Telemetry lifecycle management for the orchestrator."""

import os
import platform
import time

from logging import Logger
from typing import TYPE_CHECKING, Any

from shared.telemetry import (
    FEATURE_ORCHESTRATION,
    UNKNOWN_ENVIRONMENT,
    MigrationFailureType,
    create_connection_with_telemetry,
    detect_runtime_environment,
    log_agent_start,
    log_agent_stop,
    log_framework_crash,
    sanitize_error_message,
)


if TYPE_CHECKING:
    import snowflake.connector


def create_orchestrator_connection(
    app_version: str, connection_config: dict[str, Any]
) -> "snowflake.connector.SnowflakeConnection":
    """
    Create a Snowflake connection with telemetry initialized.

    Args:
        app_version: The version of the data_migration_orchestrator application
        connection_config: Dictionary of connection parameters

    Returns:
        A Snowflake connection with telemetry initialized

    """
    return create_connection_with_telemetry(
        app_name="data_migration_orchestrator",
        app_version=app_version,
        runtime=detect_runtime_environment(),
        **connection_config,
    )


def log_orchestrator_start(
    affinity,
    log_level,
    log_destination,
    logger: Logger,
) -> None:
    """
    Log orchestrator startup event with context.

    Args:
        affinity: The orchestrator affinity setting
        log_level: The configured log level
        log_destination: The configured log destination
        logger: Logger instance for local logging

    """
    log_agent_start(
        feature=FEATURE_ORCHESTRATION,
        orchestrator_affinity=(str(affinity) if affinity else "none"),
        log_level=(log_level.name if hasattr(log_level, "name") else str(log_level)),
        log_destination=(
            log_destination.value
            if hasattr(log_destination, "value")
            else str(log_destination)
        ),
        python_version=platform.python_version(),
        platform_system=platform.system(),
        environment=os.getenv("ENVIRONMENT", UNKNOWN_ENVIRONMENT),
    )
    logger.info("Orchestrator startup event logged to telemetry")


def log_orchestrator_stop(start_time: float, logger: Logger) -> None:
    """
    Log orchestrator shutdown event with uptime metrics.

    Args:
        start_time: The timestamp when the orchestrator started (from time.time())
        logger: Logger instance for local logging

    """
    duration_ms = (time.time() - start_time) * 1000
    log_agent_stop(
        duration_ms=duration_ms,
        feature=FEATURE_ORCHESTRATION,
        graceful_shutdown="true",
        uptime_seconds=int(duration_ms / 1000),
    )
    logger.info(
        f"Orchestrator shutdown event logged to telemetry (uptime: {duration_ms/1000:.2f}s)"
    )


def log_orchestrator_crash(error: Exception) -> None:
    """
    Log a framework crash event.

    Args:
        error: The exception that caused the crash

    """
    log_framework_crash(
        failure_type=MigrationFailureType.FRAMEWORK_UNEXPECTED_ERROR,
        error_msg=sanitize_error_message(str(error)),
    )
