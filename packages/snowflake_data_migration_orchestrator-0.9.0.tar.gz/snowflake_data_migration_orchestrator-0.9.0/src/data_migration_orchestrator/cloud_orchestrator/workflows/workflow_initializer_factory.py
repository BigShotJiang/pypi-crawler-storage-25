"""
Workflow initializer factory.

This module provides a factory for creating workflow initializers based on
workflow type. It follows the registry pattern to map workflow types to their
corresponding initializer implementations.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.workflows.base_workflow_initializer import (
    BaseWorkflowInitializer,
)
from data_migration_orchestrator.cloud_orchestrator.exceptions.unsupported_workflow_type_error import (
    UnsupportedWorkflowTypeError,
)
from data_migration_orchestrator.cloud_orchestrator.workflows.workflow_type import (
    WorkflowType,
)


logger = get_logger("workflow_initializer_factory")


class WorkflowInitializerFactory:
    """
    Factory for creating workflow initializers.

    This factory creates initializers for different workflow types.
    It provides a clean separation between workflow type determination
    and the actual task creation logic.

    Usage:
        factory = WorkflowInitializerFactory(
            task_factory=task_factory,
            queue_manager=queue_manager,
            warehouse_proxy=warehouse_proxy,
        )
        initializer = factory.get_initializer(WorkflowType.DATA_MIGRATION)
        await initializer.create_initial_tasks(workflow)

    """

    def __init__(self):
        """Initialize the workflow initializer factory."""
        self._initializers: dict[WorkflowType, BaseWorkflowInitializer] = {}

    def get_initializer(self, workflow_type: WorkflowType) -> BaseWorkflowInitializer:
        """
        Get an initializer for the given workflow type.

        Args:
            workflow_type: The type of workflow (e.g., WorkflowType.DATA_MIGRATION)

        Returns:
            The appropriate workflow initializer

        Raises:
            UnsupportedWorkflowTypeError: If no initializer exists for the workflow type

        """
        initializer = self._initializers.get(workflow_type)

        if initializer is None:
            raise UnsupportedWorkflowTypeError(
                workflow_type, list(self._initializers.keys())
            )

        return initializer

    def register_initializer(
        self, workflow_type: WorkflowType, initializer: BaseWorkflowInitializer
    ) -> None:
        """
        Register a custom initializer for a workflow type.

        This allows extending the factory with custom initializers for new
        workflow types.

        Args:
            workflow_type: The workflow type to register
            initializer: The initializer instance to use for this type

        """
        self._initializers[workflow_type] = initializer
        logger.info(f"Registered initializer for workflow type: {workflow_type}")

    def has_initializer(self, workflow_type: WorkflowType) -> bool:
        """
        Check if an initializer exists for the workflow type.

        Args:
            workflow_type: The workflow type to check

        Returns:
            True if an initializer exists, False otherwise

        """
        return workflow_type in self._initializers

    def get_supported_workflow_types(self) -> list[WorkflowType]:
        """
        Get list of supported workflow types.

        Returns:
            List of workflow types that have initializers

        """
        return list(self._initializers.keys())
