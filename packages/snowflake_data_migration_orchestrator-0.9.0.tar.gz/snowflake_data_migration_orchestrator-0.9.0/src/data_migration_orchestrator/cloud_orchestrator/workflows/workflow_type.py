from enum import StrEnum
from typing import Self


class WorkflowType(StrEnum):
    """Supported workflow types."""

    DATA_MIGRATION = "data-migration"
    DATA_VALIDATION = "data-validation"

    @classmethod
    def from_string(cls, workflow_type: str) -> Self:
        """
        Convert string to WorkflowType enum.

        Raises:
            NotImplementedError: If workflow type is not supported.

        """
        supported_workflow_types = [cls.DATA_MIGRATION.value, cls.DATA_VALIDATION.value]
        if workflow_type.lower() not in supported_workflow_types:
            supported_workflow_types_str = ", ".join(supported_workflow_types)
            raise NotImplementedError(
                f"Only {supported_workflow_types_str} are supported, got '{workflow_type}'"
            )
        return cls(workflow_type.lower())
