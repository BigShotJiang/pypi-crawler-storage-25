"""Schema migration: migration CSV file format uses Record Separator as row delimiter."""

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


logger = get_logger("schema.migrations.migration_0004")


class Migration0004CsvRecordDelimiter(BaseMigration):
    """Re-apply migration CSV_FILE_FORMAT so RECORD_DELIMITER matches BCP (U+001E)."""

    @property
    def version(self) -> int:
        """Return version 4 for CSV record delimiter migration."""
        return 4

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "CSV file format — set RECORD_DELIMITER to Record Separator (0x1E) for BCP rows"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Re-create migration CSV_FILE_FORMAT with RECORD_DELIMITER (0x1E)."""
        script_paths = [
            "scripts/file-formats/csv_file_format.sql.j2",
        ]

        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)

            logger.info("Successfully applied CSV record delimiter migration")
