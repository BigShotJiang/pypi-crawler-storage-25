"""Add EXECUTION_PROFILE column to TASK_QUEUE and update COMPLETE_TASK to accept it."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.utils.snowflake_metadata import sql_template_context


class Migration0016ExecutionProfile(BaseMigration):
    """Add EXECUTION_PROFILE VARIANT column and update COMPLETE_TASK procedure."""

    @property
    def version(self) -> int:
        """Return version 16."""
        return 16

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Add EXECUTION_PROFILE column and update COMPLETE_TASK to store it"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Add EXECUTION_PROFILE column and refresh COMPLETE_TASK procedure."""
        with connection.cursor() as cursor:
            # The prior COMPLETE_TASK(TEXT, INTEGER) signature must be dropped
            # before creating the new COMPLETE_TASK(TEXT, INTEGER, VARIANT DEFAULT NULL)
            # signature; otherwise Snowflake rejects the CREATE as an ambiguous
            # overload (000949 / 42723) because calling with two positional args
            # could match either signature.
            qualified_migration = sql_template_context()["qualified_migration"]
            cursor.execute(
                f"DROP PROCEDURE IF EXISTS {qualified_migration}.COMPLETE_TASK(VARCHAR, NUMBER)"
            )

            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/task-queue/task_queue_add_execution_profile.sql.j2",
                    "scripts/task-queue/procedures/complete_task.sql.j2",
                ],
            )
