"""Add TOTAL_ROWS to TABLE_PROGRESS and pass it through TABLE_PROGRESS_WITH_EXAMPLE_ERROR."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0020TableProgressTotalRows(BaseMigration):
    """
    Re-apply TABLE_PROGRESS views so they expose ``TOTAL_ROWS`` (SUM of partition rows).

    The Streamlit dashboard's Tables tab and Overview KPIs select ``TOTAL_ROWS``
    from these views; without this upgrade, queries against the old view
    definitions fail and the dashboard reports "No migration data available".
    """

    @property
    def version(self) -> int:
        """Return version 20."""
        return 20

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Add TOTAL_ROWS to TABLE_PROGRESS and TABLE_PROGRESS_WITH_EXAMPLE_ERROR"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Recreate both views so TOTAL_ROWS is exposed."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/table-metadata/views/table_progress.sql.j2",
                    "scripts/table-metadata/views/table_progress_with_example_error.sql.j2",
                ],
            )
