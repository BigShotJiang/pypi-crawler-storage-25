"""Add workflow management stored procedures (pause, resume, cancel)."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0021WorkflowManagementProcedures(BaseMigration):
    """
    Deploy PAUSE/RESUME/CANCEL stored procedures for workflows and tables.

    These procedures allow operators to pause, resume, or cancel an entire
    workflow or a single table within a workflow.
    """

    @property
    def version(self) -> int:
        """Return version 21."""
        return 21

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Add workflow management procedures (pause, resume, cancel)"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Create the six workflow management stored procedures."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/workflows/procedures/pause_workflow.sql.j2",
                    "scripts/workflows/procedures/pause_table.sql.j2",
                    "scripts/workflows/procedures/resume_workflow.sql.j2",
                    "scripts/workflows/procedures/resume_table.sql.j2",
                    "scripts/workflows/procedures/cancel_workflow.sql.j2",
                    "scripts/workflows/procedures/cancel_table.sql.j2",
                ],
            )
