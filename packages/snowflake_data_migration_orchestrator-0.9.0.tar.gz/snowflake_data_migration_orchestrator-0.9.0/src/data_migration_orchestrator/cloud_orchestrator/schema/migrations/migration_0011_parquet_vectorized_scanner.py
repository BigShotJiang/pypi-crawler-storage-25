"""Re-create Parquet file format with USE_VECTORIZED_SCANNER = TRUE."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0011ParquetVectorizedScanner(BaseMigration):
    """Re-create Parquet file format with USE_VECTORIZED_SCANNER enabled."""

    @property
    def version(self) -> int:
        """Return version 11."""
        return 11

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Re-create Parquet file format with USE_VECTORIZED_SCANNER = TRUE"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Re-create the Parquet file format."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/file-formats/parquet_file_format.sql.j2",
                ],
            )
