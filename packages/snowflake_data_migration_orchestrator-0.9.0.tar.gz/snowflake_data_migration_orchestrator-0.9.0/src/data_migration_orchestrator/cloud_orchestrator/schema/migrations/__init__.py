"""Schema migrations for Data Migration Orchestrator."""

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0001_initial import (
    Migration0001Initial,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0002_data_validation import (
    Migration0002DataValidation,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0003_partition_support import (
    Migration0003PartitionSupport,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0004_csv_record_delimiter import (
    Migration0004CsvRecordDelimiter,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0005_validation_progress import (
    Migration0005ValidationProgress,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0006_cell_row_index_type import (
    Migration0006CellRowIndexType,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0007_metrics_partition_number import (
    Migration0007MetricsPartitionNumber,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0008_unblock_tasks_race_condition import (
    Migration0008UnblockTasksRaceCondition,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0009_partition_level_status import (
    Migration0009PartitionLevelStatus,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0010_random_pull_order import (
    Migration0010RandomPullOrder,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0011_parquet_vectorized_scanner import (
    Migration0011ParquetVectorizedScanner,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0012_row_validation_partition_number import (
    Migration0012RowValidationPartitionNumber,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0013_eager_unblock import (
    Migration0013EagerUnblock,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0014_task_warning_message import (
    Migration0014TaskWarningMessage,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0015_snowpipe_and_cleanup import (
    Migration0015SnowpipeAndCleanup,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0016_execution_profile import (
    Migration0016ExecutionProfile,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0017_unblock_cleanup_tasks import (
    Migration0017UnblockCleanupTasks,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0018_lease_snowpipe_tasks import (
    Migration0018LeaseSnowpipeTasks,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0019_dv_warning_views import (
    Migration0019DvWarningViews,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0020_table_progress_total_rows import (
    Migration0020TableProgressTotalRows,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0021_workflow_management_procedures import (
    Migration0021WorkflowManagementProcedures,
)


__all__ = [
    "BaseMigration",
    "Migration0001Initial",
    "Migration0002DataValidation",
    "Migration0003PartitionSupport",
    "Migration0004CsvRecordDelimiter",
    "Migration0005ValidationProgress",
    "Migration0006CellRowIndexType",
    "Migration0007MetricsPartitionNumber",
    "Migration0008UnblockTasksRaceCondition",
    "Migration0009PartitionLevelStatus",
    "Migration0010RandomPullOrder",
    "Migration0011ParquetVectorizedScanner",
    "Migration0012RowValidationPartitionNumber",
    "Migration0013EagerUnblock",
    "Migration0014TaskWarningMessage",
    "Migration0015SnowpipeAndCleanup",
    "Migration0016ExecutionProfile",
    "Migration0017UnblockCleanupTasks",
    "Migration0018LeaseSnowpipeTasks",
    "Migration0019DvWarningViews",
    "Migration0020TableProgressTotalRows",
    "Migration0021WorkflowManagementProcedures",
]
