"""Create DATA_VALIDATION_ERROR and DATA_VALIDATION_WARNING views and refresh TABLE_PROGRESS_DETAIL."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0019DvWarningViews(BaseMigration):
    """Add DV error/warning views and refresh TABLE_PROGRESS_DETAIL to surface warnings."""

    @property
    def version(self) -> int:
        """Return version 19."""
        return 19

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "Create DATA_VALIDATION_ERROR/WARNING views, update TABLE_PROGRESS_DETAIL"
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Create DV error/warning views and refresh the progress detail view."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/data-validation/views/data_validation_error.sql.j2",
                    "scripts/data-validation/views/data_validation_warning.sql.j2",
                    "scripts/data-validation/views/table_progress_detail.sql.j2",
                ],
            )
