"""Data validation progress view migration."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0005ValidationProgress(BaseMigration):
    """Migration that creates the TABLE_PROGRESS view in the DATA_VALIDATION schema."""

    @property
    def version(self) -> int:
        """Return version 5 for validation progress migration."""
        return 5

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Data validation progress view"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Apply the validation progress migration.

        Args:
            connection: Active Snowflake connection

        Raises:
            Exception: If any SQL script fails to execute

        """
        script_paths = [
            "scripts/data-validation/views/table_progress.sql.j2",
        ]

        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)
