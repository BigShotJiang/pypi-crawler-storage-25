"""Initial schema migration for Data Migration Orchestrator."""

from typing import Any

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    metadata_database,
    migration_metadata_schema,
)
from data_migration_orchestrator.utils.snowflake_schema import (
    ensure_database_and_schema_sync,
)


logger = get_logger("schema.migrations.migration_0001")


class Migration0001Initial(BaseMigration):
    """
    Initial migration that sets up the complete database schema.

    This migration executes all SQL scripts in the assets directory in the correct
    dependency order to bootstrap a fresh database.
    """

    @property
    def version(self) -> int:
        """Return version 1 for initial migration."""
        return 1

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "Initial schema setup - creates database, tables, sequences, and procedures"
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Apply the initial migration by executing all SQL scripts in order.

        Args:
            connection: Active Snowflake connection

        Raises:
            Exception: If any SQL script fails to execute

        """
        # Define the execution order of SQL scripts
        script_paths = [
            # 1. Core tables and sequences
            "scripts/task-queue/task_id_sequence.sql.j2",
            "scripts/task-queue/task_queue.sql.j2",
            "scripts/task-queue/task_results.sql.j2",
            "scripts/workflows/workflow.sql.j2",
            "scripts/file-formats/csv_file_format.sql.j2",
            "scripts/file-formats/parquet_file_format.sql.j2",
            # 2. Table metadata tables and sequences
            "scripts/table-metadata/table_metadata_id_sequence.sql.j2",
            "scripts/table-metadata/partition_metadata_id_sequence.sql.j2",
            "scripts/table-metadata/table_metadata.sql.j2",
            "scripts/table-metadata/partition_metadata.sql.j2",
            # 3. Task queue procedures (alphabetical order)
            "scripts/task-queue/procedures/check_tasks.sql.j2",
            "scripts/task-queue/procedures/complete_task.sql.j2",
            "scripts/task-queue/procedures/copy_parquet_into_table.sql.j2",
            "scripts/task-queue/procedures/create_table.sql.j2",
            "scripts/task-queue/procedures/expire_leases.sql.j2",
            "scripts/task-queue/procedures/fail_task.sql.j2",
            "scripts/task-queue/procedures/has_workflow_started.sql.j2",
            "scripts/task-queue/procedures/pull_single_task.sql.j2",
            "scripts/task-queue/procedures/pull_many_tasks.sql.j2",
            "scripts/task-queue/procedures/pull_tasks.sql.j2",
            "scripts/task-queue/procedures/push_task_variant.sql.j2",
            "scripts/task-queue/procedures/push_task_text.sql.j2",
            "scripts/task-queue/procedures/refresh_leases.sql.j2",
            "scripts/task-queue/procedures/unblock_tasks.sql.j2",
            # 4. Table metadata procedures & views
            "scripts/table-metadata/procedures/insert_table_metadata.sql.j2",
            "scripts/table-metadata/procedures/insert_partition_metadata.sql.j2",
            "scripts/table-metadata/procedures/get_table_configuration.sql.j2",
            "scripts/table-metadata/procedures/find_existing_table_metadata.sql.j2",
            "scripts/table-metadata/procedures/copy_table_metadata.sql.j2",
            "scripts/table-metadata/procedures/copy_partition_metadata.sql.j2",
            "scripts/table-metadata/procedures/get_partition_metadata.sql.j2",
            "scripts/table-metadata/views/table_progress.sql.j2",
            "scripts/table-metadata/views/data_migration_error.sql.j2",
            "scripts/table-metadata/views/data_migration_warning.sql.j2",
            "scripts/table-metadata/views/table_progress_with_example_error.sql.j2",
            # 5. Workflow procedures
            "scripts/workflows/procedures/get_pending_workflows.sql.j2",
            "scripts/workflows/procedures/complete_workflows.sql.j2",
            "scripts/workflows/procedures/retry_workflow.sql.j2",
            "scripts/workflows/procedures/expire_stale_initializations.sql.j2",
            "scripts/workflows/procedures/delete_workflow_tasks.sql.j2",
            # 6. Schema migration tracking table (created last)
            "scripts/task-queue/schema_migration_table.sql.j2",
        ]

        with connection.cursor() as cursor:
            self._ensure_database_and_schema(cursor)
            self._execute_migration_sql_assets(cursor, script_paths)

            logger.info("Successfully applied initial migration")

    def _ensure_database_and_schema(
        self, cursor: snowflake.connector.cursor.SnowflakeCursor
    ) -> None:
        """
        Ensure the configured metadata database and data-migration schema exist.

        Uses SHOW commands to check existence first, avoiding CREATE IF NOT EXISTS
        which requires CREATE privileges even when the object already exists.

        Args:
            cursor: Snowflake cursor to execute SQL with

        """

        def _execute_and_fetch(sql: str) -> Any:
            cursor.execute(sql)
            return cursor.fetchone()

        ensure_database_and_schema_sync(
            _execute_and_fetch,
            metadata_database(),
            migration_metadata_schema(),
        )
