"""Lease snowpipe tasks to the 'snowpipe' sentinel at push time."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0018LeaseSnowpipeTasks(BaseMigration):
    """
    Re-apply PUSH_TASK so snowpipe tasks are leased to the 'snowpipe' sentinel.

    This lets snowpipe completions/failures go through the standard
    ``COMPLETE_TASK`` / ``FAIL_TASK`` procedures (which are lease-gated) and
    inherit their eager-unblock and failure-cascade behavior.
    """

    @property
    def version(self) -> int:
        """Return version 18."""
        return 18

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Lease snowpipe tasks at push time so COMPLETE_TASK/FAIL_TASK can run against them"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Re-apply PUSH_TASK with the updated LEASED_TO assignment."""
        script_paths = [
            "scripts/task-queue/procedures/push_task_variant.sql.j2",
        ]
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)
