"""Add UNBLOCK_CLEANUP_TASKS procedure for cleanup-task unblocking."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0017UnblockCleanupTasks(BaseMigration):
    """Migration that creates the UNBLOCK_CLEANUP_TASKS procedure."""

    @property
    def version(self) -> int:
        """Return version 17."""
        return 17

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Create UNBLOCK_CLEANUP_TASKS procedure for cleanup-task unblocking"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Create the UNBLOCK_CLEANUP_TASKS procedure."""
        script_paths = [
            "scripts/task-queue/procedures/unblock_cleanup_tasks.sql.j2",
        ]
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)
