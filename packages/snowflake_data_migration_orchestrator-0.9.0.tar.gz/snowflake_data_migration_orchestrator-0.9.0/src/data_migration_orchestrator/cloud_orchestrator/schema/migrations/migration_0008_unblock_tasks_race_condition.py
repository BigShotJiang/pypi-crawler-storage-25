"""Prevent UNBLOCK_TASKS race condition during concurrent task insertion."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0008UnblockTasksRaceCondition(BaseMigration):
    """Migration that re-applies UNBLOCK_TASKS and RETRY_WORKFLOW procedures."""

    @property
    def version(self) -> int:
        """Return version 8."""
        return 8

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Prevent UNBLOCK_TASKS race condition when predecessors are still being inserted"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Re-apply UNBLOCK_TASKS and RETRY_WORKFLOW with race condition fix."""
        script_paths = [
            "scripts/task-queue/procedures/unblock_tasks.sql.j2",
            "scripts/workflows/procedures/retry_workflow.sql.j2",
        ]
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)
