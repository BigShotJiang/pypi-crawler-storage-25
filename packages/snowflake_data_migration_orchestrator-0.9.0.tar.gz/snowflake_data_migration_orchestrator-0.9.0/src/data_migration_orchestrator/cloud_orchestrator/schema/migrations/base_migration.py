"""Base migration class for schema migrations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

import snowflake.connector

from snowflake.connector.cursor import SnowflakeCursor

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.utils.templated_sql import execute_migration_sql_asset


logger = get_logger(__name__)


class BaseMigration(ABC):
    """
    Abstract base class for schema migrations.

    All schema migrations must inherit from this class and implement the required methods.
    """

    @property
    @abstractmethod
    def version(self) -> int:
        """
        Return the migration version number.

        Returns:
            int: Unique version number for this migration (must be positive integer)

        """
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """
        Return a description of this migration.

        Returns:
            str: Human-readable description of what this migration does

        """
        pass

    def needs_reapply(
        self, connection: snowflake.connector.SnowflakeConnection
    ) -> bool:
        """
        Check whether this migration must be re-applied.

        Called for every applied migration on startup.
        Override in subclasses whose artifacts (schemas, tables, etc.) can be
        dropped independently of the migration tracker.

        Returns ``False`` by default (no re-apply needed).
        """
        return False

    @abstractmethod
    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Apply this migration.

        Args:
            connection: Active Snowflake connection to execute migration against

        Raises:
            Exception: If migration fails for any reason

        """
        pass

    def _get_assets_directory(self) -> str:
        """
        Return the absolute path to the package ``assets`` directory.

        ``base_migration.py`` lives next to concrete migrations under
        ``.../schema/migrations/``; three parents up is ``data_migration_orchestrator/``.
        """
        migrations_dir = Path(__file__).resolve().parent
        package_root = migrations_dir.parent.parent.parent
        assets_dir = package_root / "assets"
        if not assets_dir.exists():
            raise FileNotFoundError(f"Assets directory not found: {assets_dir}")
        return str(assets_dir)

    def _execute_migration_sql_assets(
        self,
        cursor: SnowflakeCursor,
        script_paths: list[str],
    ) -> None:
        """Render and execute ordered ``scripts/.../*.sql.j2`` paths under assets."""
        assets_dir = self._get_assets_directory()
        label = self.__class__.__name__
        for script_path in script_paths:
            logger.info(f"[{label}] Executing: {script_path}")
            execute_migration_sql_asset(cursor, assets_dir, script_path)
            logger.info(f"[{label}] Completed: {script_path}")

    def rollback(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Rollback this migration (optional, not implemented in initial version).

        Args:
            connection: Active Snowflake connection to execute rollback against

        Raises:
            NotImplementedError: Rollback is not yet supported

        """
        raise NotImplementedError("Rollback is not yet supported")

    def __repr__(self) -> str:
        """Return string representation of migration."""
        return f"{self.__class__.__name__}(version={self.version}, description='{self.description}')"
