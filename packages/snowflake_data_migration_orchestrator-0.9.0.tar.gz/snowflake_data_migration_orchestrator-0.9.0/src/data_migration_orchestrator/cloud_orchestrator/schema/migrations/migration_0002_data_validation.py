"""Data validation schema migration."""

from typing import Any

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    metadata_database,
    validation_metadata_schema,
)
from data_migration_orchestrator.utils.snowflake_schema import (
    ensure_database_and_schema_sync,
)


logger = get_logger("schema.migrations.migration_0002")


class Migration0002DataValidation(BaseMigration):
    """Migration that creates the DATA_VALIDATION schema and all validation objects."""

    @property
    def version(self) -> int:
        """Return version 2 for data validation migration."""
        return 2

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Data validation schema - tables, sequences, stages, file formats, and procedures"

    def needs_reapply(
        self, connection: snowflake.connector.SnowflakeConnection
    ) -> bool:
        """Re-apply if the DATA_VALIDATION schema was dropped."""
        with connection.cursor() as cursor:
            try:
                cursor.execute(
                    f"SHOW SCHEMAS LIKE '{validation_metadata_schema()}' "
                    f"IN DATABASE {metadata_database()}"
                )
                return cursor.fetchone() is None
            except Exception:
                return True

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Apply the data validation migration by creating the schema and all objects.

        Args:
            connection: Active Snowflake connection

        Raises:
            Exception: If any SQL script fails to execute

        """
        script_paths = [
            # 1. Sequences
            "scripts/data-validation/table_metadata_id_sequence.sql.j2",
            # 2. File formats and stages
            "scripts/data-validation/file_formats/csv_file_format.sql.j2",
            "scripts/data-validation/stages/task_results_stage.sql.j2",
            # 3. Metadata tables
            "scripts/data-validation/table_metadata.sql.j2",
            # 4. Result tables
            "scripts/data-validation/schema_validation_results.sql.j2",
            "scripts/data-validation/metrics_validation_results.sql.j2",
            "scripts/data-validation/row_validation_results.sql.j2",
            "scripts/data-validation/row_validation_summary.sql.j2",
            "scripts/data-validation/chunk_hashes.sql.j2",
            # 5. Procedures
            "scripts/data-validation/procedures/insert_table_metadata.sql.j2",
            "scripts/data-validation/procedures/get_table_configuration.sql.j2",
            "scripts/data-validation/procedures/update_table_validation_status.sql.j2",
        ]

        with connection.cursor() as cursor:
            self._ensure_data_validation_schema(cursor)
            self._execute_migration_sql_assets(cursor, script_paths)

            logger.info("Successfully applied data validation migration")

    def _ensure_data_validation_schema(
        self, cursor: snowflake.connector.cursor.SnowflakeCursor
    ) -> None:
        """Ensure the validation metadata schema exists within the metadata database."""

        def _execute_and_fetch(sql: str) -> Any:
            cursor.execute(sql)
            return cursor.fetchone()

        ensure_database_and_schema_sync(
            _execute_and_fetch,
            metadata_database(),
            validation_metadata_schema(),
        )
