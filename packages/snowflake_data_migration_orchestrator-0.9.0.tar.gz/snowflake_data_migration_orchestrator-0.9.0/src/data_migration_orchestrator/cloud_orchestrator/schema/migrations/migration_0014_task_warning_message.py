"""Add LAST_WARNING_MESSAGE column to TASK_QUEUE and create DATA_MIGRATION_WARNING view."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0014TaskWarningMessage(BaseMigration):
    """Add LAST_WARNING_MESSAGE to TASK_QUEUE and refresh dependent views."""

    @property
    def version(self) -> int:
        """Return version 14."""
        return 14

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Add LAST_WARNING_MESSAGE column and DATA_MIGRATION_WARNING view"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Add LAST_WARNING_MESSAGE column and refresh dependent views."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/task-queue/task_queue_add_warning_message.sql.j2",
                    "scripts/table-metadata/views/data_migration_error.sql.j2",
                    "scripts/table-metadata/views/data_migration_warning.sql.j2",
                    "scripts/table-metadata/views/table_progress_with_example_error.sql.j2",
                ],
            )
