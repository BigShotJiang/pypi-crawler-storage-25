"""
Recreate CELL_VALIDATION_RESULTS with ROW_INDEX as VARCHAR.

Key-based cell matching produces human-readable row identifiers (e.g.
``ID=75``) that cannot be loaded into an INT column.  The COPY INTO
silently skips every diff row when ``ON_ERROR = 'CONTINUE'``.

Snowflake does not allow ALTER COLUMN from NUMBER to VARCHAR, so the
table is recreated via the updated ``cell_validation_results.sql.j2``
DDL (which uses ``CREATE OR REPLACE TABLE``).
"""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0006CellRowIndexType(BaseMigration):
    """Migration that recreates CELL_VALIDATION_RESULTS with ROW_INDEX as VARCHAR."""

    @property
    def version(self) -> int:
        """Return version 6."""
        return 6

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Cell validation results - widen ROW_INDEX from INT to VARCHAR"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Recreate the table using the updated DDL template."""
        script_paths = [
            "scripts/data-validation/cell_validation_results.sql.j2",
        ]
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)
