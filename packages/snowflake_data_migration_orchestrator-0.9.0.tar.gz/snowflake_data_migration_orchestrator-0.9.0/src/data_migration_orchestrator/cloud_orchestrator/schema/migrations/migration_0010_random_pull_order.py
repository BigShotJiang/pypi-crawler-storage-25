"""Optimise pull procedures: RANDOM() tiebreaker, SELECT INTO, early COMMIT, better index."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0010RandomPullOrder(BaseMigration):
    """Optimise pull procedures and covering index."""

    @property
    def version(self) -> int:
        """Return version 10."""
        return 10

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "Optimise pull procedures: RANDOM() tiebreaker, SELECT INTO, "
            "early COMMIT, LEASED_TO in covering index"
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Re-create pull procedures and rebuild covering index with LEASED_TO."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/task-queue/procedures/pull_single_task.sql.j2",
                    "scripts/task-queue/procedures/pull_many_tasks.sql.j2",
                    "scripts/task-queue/idx_task_queue_pending_pull.sql.j2",
                ],
            )
