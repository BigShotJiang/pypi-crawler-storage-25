"""Eager successor unblocking inside COMPLETE_TASK / FAIL_TASK."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0013EagerUnblock(BaseMigration):
    """Add SUCCESSOR_TASK_ID index, warehouse LEASED_TO, and eager unblock logic."""

    @property
    def version(self) -> int:
        """Return version 13."""
        return 13

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "Eager successor unblocking in COMPLETE_TASK/FAIL_TASK, "
            "SUCCESSOR_TASK_ID index, warehouse LEASED_TO at creation"
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Apply index, updated PUSH_TASK, COMPLETE_TASK, and FAIL_TASK procedures."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/task-queue/idx_task_queue_successor.sql.j2",
                    "scripts/task-queue/procedures/push_task_variant.sql.j2",
                    "scripts/task-queue/procedures/complete_task.sql.j2",
                    "scripts/task-queue/procedures/fail_task.sql.j2",
                ],
            )
