"""Add PARTITION_NUMBER to METRICS_VALIDATION_RESULTS for per-partition metrics rows."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0007MetricsPartitionNumber(BaseMigration):
    """Migration that adds PARTITION_NUMBER to metrics validation results."""

    @property
    def version(self) -> int:
        """Return version 7."""
        return 7

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Metrics validation results - PARTITION_NUMBER for dashboard partition context"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Add nullable PARTITION_NUMBER; existing rows remain NULL."""
        script_paths = [
            "scripts/data-validation/metrics_validation_results_add_partition_number.sql.j2",
        ]
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)
