"""Add PARTITION_NUMBER column to ROW_VALIDATION_RESULTS for hybrid MD5-to-cell narrowing."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0012RowValidationPartitionNumber(BaseMigration):
    """Add PARTITION_NUMBER to ROW_VALIDATION_RESULTS for cell validation partitioning."""

    @property
    def version(self) -> int:
        """Return version 12."""
        return 12

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Add PARTITION_NUMBER column to ROW_VALIDATION_RESULTS"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Add PARTITION_NUMBER column."""
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(
                cursor,
                [
                    "scripts/data-validation/row_validation_results_add_partition_number.sql.j2",
                ],
            )
