"""Partition support and cell validation schema migration."""

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


logger = get_logger("schema.migrations.migration_0003")


class Migration0003PartitionSupport(BaseMigration):
    """Migration that adds partition metadata and cell validation objects."""

    @property
    def version(self) -> int:
        """Return version 3 for partition support migration."""
        return 3

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Partition support - partition metadata table, sequence, procedures, and cell validation results"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """
        Apply the partition support migration.

        Args:
            connection: Active Snowflake connection

        Raises:
            Exception: If any SQL script fails to execute

        """
        script_paths = [
            # 1. Sequences
            "scripts/data-validation/partition_metadata_id_sequence.sql.j2",
            # 2. Tables
            "scripts/data-validation/partition_metadata.sql.j2",
            "scripts/data-validation/cell_validation_results.sql.j2",
            # 3. Procedures
            "scripts/data-validation/procedures/insert_partition_metadata.sql.j2",
            "scripts/data-validation/procedures/get_partition_metadata.sql.j2",
            "scripts/data-validation/procedures/update_partition_validation_status.sql.j2",
        ]

        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)

            logger.info("Successfully applied partition support migration")
