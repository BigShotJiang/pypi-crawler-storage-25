"""Snowpipe and cleanup support: IS_CLEANUP column, event table, TEMP schema, and procedure updates."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    metadata_database,
    qualified_event_table,
    qualified_migration_schema,
    qualified_temp_schema,
)


class Migration0015SnowpipeAndCleanup(BaseMigration):
    """Add IS_CLEANUP column, create event table and TEMP schema, and update stored procedures."""

    @property
    def version(self) -> int:
        """Return version 15."""
        return 15

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return (
            "Add IS_CLEANUP column to TASK_QUEUE; "
            "create event table for Snowpipe file_lifecycle monitoring; "
            "set database-level EVENT_TABLE; create TEMP schema for pipe objects; "
            "update PUSH_TASK, UNBLOCK_TASKS, and COMPLETE_WORKFLOWS procedures"
        )

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Add IS_CLEANUP column, create event table and TEMP schema, update procedures."""
        qm = qualified_migration_schema()
        event_table = qualified_event_table()
        db = metadata_database()
        temp_schema = qualified_temp_schema()

        with connection.cursor() as cursor:
            try:
                cursor.execute(
                    f"ALTER TABLE {qm}.TASK_QUEUE ADD COLUMN IF NOT EXISTS IS_CLEANUP BOOLEAN DEFAULT FALSE"
                )
            except snowflake.connector.errors.ProgrammingError as e:
                if "ambiguous column name" not in str(e).lower():
                    raise
            cursor.execute(f"CREATE EVENT TABLE IF NOT EXISTS {event_table}")
            cursor.execute(f"ALTER DATABASE {db} SET EVENT_TABLE = {event_table}")
            cursor.execute(f"CREATE SCHEMA IF NOT EXISTS {temp_schema}")

        script_paths = [
            "scripts/task-queue/procedures/push_task_variant.sql.j2",
            "scripts/task-queue/procedures/push_task_text.sql.j2",
            "scripts/task-queue/procedures/unblock_tasks.sql.j2",
            "scripts/workflows/procedures/complete_workflows.sql.j2",
        ]
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)
