"""Add L2_STATUS / L3_STATUS columns and TABLE_PROGRESS_DETAIL view for DV dashboard."""

import snowflake.connector

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)


class Migration0009PartitionLevelStatus(BaseMigration):
    """Migration that adds per-level partition progress columns for data validation."""

    @property
    def version(self) -> int:
        """Return version 9."""
        return 9

    @property
    def description(self) -> str:
        """Return description of this migration."""
        return "Partition L2/L3 status columns and TABLE_PROGRESS_DETAIL view (VALID/INVALID/EXECUTION_ERROR)"

    def apply(self, connection: snowflake.connector.SnowflakeConnection) -> None:
        """Add L2_STATUS and L3_STATUS columns with PENDING default."""
        script_paths = [
            "scripts/data-validation/partition_metadata_add_l2_status.sql.j2",
            "scripts/data-validation/partition_metadata_add_l3_status.sql.j2",
            "scripts/data-validation/views/data_validation_error.sql.j2",
            "scripts/data-validation/views/data_validation_warning.sql.j2",
            "scripts/data-validation/views/table_progress_detail.sql.j2",
        ]
        with connection.cursor() as cursor:
            self._execute_migration_sql_assets(cursor, script_paths)
