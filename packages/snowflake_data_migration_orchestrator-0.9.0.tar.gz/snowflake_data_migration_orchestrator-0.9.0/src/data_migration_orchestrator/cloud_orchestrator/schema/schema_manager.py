"""Schema Manager for managing database migrations."""

import time

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0001_initial import (
    Migration0001Initial,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0002_data_validation import (
    Migration0002DataValidation,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0003_partition_support import (
    Migration0003PartitionSupport,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0004_csv_record_delimiter import (
    Migration0004CsvRecordDelimiter,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0005_validation_progress import (
    Migration0005ValidationProgress,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0006_cell_row_index_type import (
    Migration0006CellRowIndexType,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0007_metrics_partition_number import (
    Migration0007MetricsPartitionNumber,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0008_unblock_tasks_race_condition import (
    Migration0008UnblockTasksRaceCondition,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0009_partition_level_status import (
    Migration0009PartitionLevelStatus,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0010_random_pull_order import (
    Migration0010RandomPullOrder,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0011_parquet_vectorized_scanner import (
    Migration0011ParquetVectorizedScanner,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0012_row_validation_partition_number import (
    Migration0012RowValidationPartitionNumber,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0013_eager_unblock import (
    Migration0013EagerUnblock,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0014_task_warning_message import (
    Migration0014TaskWarningMessage,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0015_snowpipe_and_cleanup import (
    Migration0015SnowpipeAndCleanup,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0016_execution_profile import (
    Migration0016ExecutionProfile,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0017_unblock_cleanup_tasks import (
    Migration0017UnblockCleanupTasks,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0018_lease_snowpipe_tasks import (
    Migration0018LeaseSnowpipeTasks,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0019_dv_warning_views import (
    Migration0019DvWarningViews,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0020_table_progress_total_rows import (
    Migration0020TableProgressTotalRows,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0021_workflow_management_procedures import (
    Migration0021WorkflowManagementProcedures,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("schema_manager")


# Retry configuration for transient Snowflake errors during a migration.
# Defaults give a total wait budget of 5s + 10s = 15s before the third attempt
# and ~35s before giving up entirely, which is plenty for an asynchronous
# index build to finish on a small TASK_QUEUE.
TRANSIENT_RETRY_ATTEMPTS = 3
TRANSIENT_RETRY_INITIAL_DELAY_SECONDS = 5.0
TRANSIENT_RETRY_BACKOFF_MULTIPLIER = 2.0


# Snowflake does not allow two concurrent index builds on the same hybrid
# table. CREATE [OR REPLACE] INDEX returns immediately while the build runs
# asynchronously, so a follow-up CREATE INDEX on the same table can be
# rejected with an "is being built" / "another index" error until the prior
# build completes. The error is transient -- waiting a few seconds and
# retrying succeeds.
_TRANSIENT_ERROR_PHRASES: tuple[str, ...] = (
    "is being built",
    "another index",
)


def _is_transient_migration_error(exc: BaseException) -> bool:
    """
    Return True if *exc* is a known transient Snowflake error worth retrying.

    Walks the ``__cause__`` chain because ``execute_templated_sql_file``
    wraps the original ``ProgrammingError`` in a generic ``Exception``, so
    the top-level exception that reaches the schema manager is no longer a
    ``ProgrammingError``. We follow the chain like
    :func:`cloud_core.snowflake_session_retry.is_session_expired_error` does.

    Today this only covers the concurrent-index-build race (see
    ``_TRANSIENT_ERROR_PHRASES``); add new phrases here if other transient
    errors surface during migrations.
    """
    current: BaseException | None = exc
    while current is not None:
        if isinstance(current, snowflake.connector.errors.ProgrammingError):
            msg = str(current).lower()
            if any(phrase in msg for phrase in _TRANSIENT_ERROR_PHRASES):
                return True
        current = current.__cause__
    return False


# Explicit registration of all migrations
REGISTERED_MIGRATIONS: list[type[BaseMigration]] = [
    Migration0001Initial,
    Migration0002DataValidation,
    Migration0003PartitionSupport,
    Migration0004CsvRecordDelimiter,
    Migration0005ValidationProgress,
    Migration0006CellRowIndexType,
    Migration0007MetricsPartitionNumber,
    Migration0008UnblockTasksRaceCondition,
    Migration0009PartitionLevelStatus,
    Migration0010RandomPullOrder,
    Migration0011ParquetVectorizedScanner,
    Migration0012RowValidationPartitionNumber,
    Migration0013EagerUnblock,
    Migration0014TaskWarningMessage,
    Migration0015SnowpipeAndCleanup,
    Migration0016ExecutionProfile,
    Migration0017UnblockCleanupTasks,
    Migration0018LeaseSnowpipeTasks,
    Migration0019DvWarningViews,
    Migration0020TableProgressTotalRows,
    Migration0021WorkflowManagementProcedures,
]


class SchemaManager:
    """
    Manages schema migrations for the Data Migration Orchestrator.

    The Schema Manager is responsible for:
    - Tracking which migrations have been applied
    - Discovering pending migrations
    - Applying migrations in the correct order
    - Recording migration results

    Usage:
        manager = SchemaManager(connection)
        manager.migrate()  # Apply all pending migrations
    """

    def __init__(self, connection: snowflake.connector.SnowflakeConnection):
        """
        Initialize the Schema Manager.

        Args:
            connection: Active Snowflake connection for executing migrations

        """
        self.connection = connection

    def migrate(self) -> None:
        """
        Apply all pending migrations.

        This is the main entry point for running migrations. It:
        1. Checks which migrations have been applied
        2. Determines which migrations are pending (including those that need re-apply)
        3. Applies pending migrations in order
        4. Records results in the SCHEMA_MIGRATION table

        Raises:
            Exception: If any migration fails

        """
        logger.info("Starting migration process...")

        pending_migrations = self.get_pending_migrations()

        if not pending_migrations:
            logger.info("No pending migrations found. Schema is up to date.")
            return

        logger.info(f"Found {len(pending_migrations)} pending migration(s):")
        for migration in pending_migrations:
            logger.info(f"  - Version {migration.version}: {migration.description}")

        for migration in pending_migrations:
            self._apply_migration(migration)

        logger.info(f"Successfully applied {len(pending_migrations)} migration(s)")

    def get_pending_migrations(self) -> list[BaseMigration]:
        """
        Get migrations that need to be applied.

        A migration is considered pending when it has never been applied **or**
        when its ``needs_reapply`` check indicates its artifacts are missing
        (e.g. a schema was dropped outside the migration system).

        Returns:
            list[BaseMigration]: List of pending migrations sorted by version

        """
        # Check if schema migration table exists
        table_exists = self._ensure_schema_migration_table_exists()

        if not table_exists:
            # Fresh database - all registered migrations are pending
            logger.info(
                "SCHEMA_MIGRATION table does not exist. This is a fresh database."
            )
            available_migrations = self._get_available_migrations()
            return sorted(available_migrations, key=lambda m: m.version)

        # Get applied migration versions
        applied_versions = self._get_applied_migrations()
        logger.info(
            f"Found {len(applied_versions)} applied migration(s): {sorted(applied_versions)}"
        )

        available_migrations = self._get_available_migrations()

        pending: list[BaseMigration] = []
        for migration in available_migrations:
            if migration.version not in applied_versions:
                pending.append(migration)
            elif migration.needs_reapply(self.connection):
                logger.info(
                    f"Migration {migration.version} needs re-apply: "
                    f"{migration.description}"
                )
                pending.append(migration)

        return sorted(pending, key=lambda m: m.version)

    def _ensure_schema_migration_table_exists(self) -> bool:
        """
        Check if the SCHEMA_MIGRATION table exists.

        Returns:
            bool: True if table exists, False otherwise

        """
        with self.connection.cursor() as cursor:
            try:
                qm = qualified_migration_schema()
                cursor.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM {qm}.SCHEMA_MIGRATION
                    LIMIT 1
                """
                )
                cursor.fetchone()
                return True
            except snowflake.connector.errors.ProgrammingError as e:
                # Table doesn't exist
                error_msg = str(e).lower()
                if "does not exist" in error_msg or "invalid" in error_msg:
                    return False
                # Some other error - re-raise
                raise

    def _get_applied_migrations(self) -> set[int]:
        """
        Get set of applied migration versions.

        Returns:
            set[int]: Set of version numbers that have been successfully applied

        """
        with self.connection.cursor() as cursor:
            qm = qualified_migration_schema()
            cursor.execute(
                f"""
                SELECT VERSION
                FROM {qm}.SCHEMA_MIGRATION
                WHERE SUCCESS = TRUE
                ORDER BY VERSION
            """
            )
            results = cursor.fetchall()
            return {row[0] for row in results}

    def _get_available_migrations(self) -> list[BaseMigration]:
        """
        Get all registered migrations.

        Returns:
            list[BaseMigration]: List of instantiated migration objects

        """
        return [migration_class() for migration_class in REGISTERED_MIGRATIONS]

    def _apply_migration(self, migration: BaseMigration) -> None:
        """
        Apply a single migration and record the result.

        Transient Snowflake errors (see :func:`_is_transient_migration_error`)
        are retried with exponential backoff before the migration is recorded
        as failed.

        Args:
            migration: Migration to apply

        Raises:
            Exception: If migration fails after retries are exhausted

        """
        logger.info(f"Applying migration {migration.version}: {migration.description}")

        start_time = time.time()
        success = False
        error_message: str | None = None
        execution_time_ms = 0

        try:
            self._apply_migration_with_retries(migration)
            success = True
            execution_time_ms = int((time.time() - start_time) * 1000)

            logger.info(
                f"Migration {migration.version} completed in {execution_time_ms}ms"
            )

        except Exception as e:
            execution_time_ms = int((time.time() - start_time) * 1000)
            error_message = str(e)
            logger.error(
                f"Migration {migration.version} failed after {execution_time_ms}ms: {error_message}",
                exc_info=True,
            )
            raise

        finally:
            # Record the migration attempt
            self._record_migration(
                migration.version,
                migration.description,
                execution_time_ms,
                success,
            )

    def _apply_migration_with_retries(self, migration: BaseMigration) -> None:
        """
        Run ``migration.apply()`` with retries for transient Snowflake errors.

        Non-transient errors propagate on the first attempt; transient errors
        trigger up to :data:`TRANSIENT_RETRY_ATTEMPTS` total tries with an
        exponential backoff starting at
        :data:`TRANSIENT_RETRY_INITIAL_DELAY_SECONDS` and growing by
        :data:`TRANSIENT_RETRY_BACKOFF_MULTIPLIER` each step.
        """
        for attempt in range(1, TRANSIENT_RETRY_ATTEMPTS + 1):
            try:
                migration.apply(self.connection)
                self.connection.commit()  # Commit in case auto-commit is not enabled
                return
            except Exception as exc:
                if not _is_transient_migration_error(exc):
                    raise
                if attempt >= TRANSIENT_RETRY_ATTEMPTS:
                    logger.error(
                        f"Migration {migration.version} hit transient error on "
                        f"attempt {attempt}/{TRANSIENT_RETRY_ATTEMPTS} and "
                        f"exhausted retries: {exc}"
                    )
                    raise
                delay_seconds = TRANSIENT_RETRY_INITIAL_DELAY_SECONDS * (
                    TRANSIENT_RETRY_BACKOFF_MULTIPLIER ** (attempt - 1)
                )
                logger.warning(
                    f"Migration {migration.version} hit transient error on "
                    f"attempt {attempt}/{TRANSIENT_RETRY_ATTEMPTS}: {exc}. "
                    f"Retrying in {delay_seconds:.1f}s..."
                )
                time.sleep(delay_seconds)

    def _record_migration(
        self, version: int, description: str, execution_time_ms: int, success: bool
    ) -> None:
        """
        Record a migration in the SCHEMA_MIGRATION table.

        Args:
            version: Migration version number
            description: Migration description
            execution_time_ms: Execution time in milliseconds
            success: Whether the migration succeeded

        """
        with self.connection.cursor() as cursor:
            try:
                qm = qualified_migration_schema()
                cursor.execute(
                    f"""
                    INSERT INTO {qm}.SCHEMA_MIGRATION
                        (VERSION, DESCRIPTION, EXECUTION_TIME_MS, SUCCESS)
                    VALUES (%s, %s, %s, %s)
                """,
                    (version, description, execution_time_ms, success),
                )
            except Exception as e:
                logger.warning(f"Could not record migration {version}: {str(e)}")
                raise e
