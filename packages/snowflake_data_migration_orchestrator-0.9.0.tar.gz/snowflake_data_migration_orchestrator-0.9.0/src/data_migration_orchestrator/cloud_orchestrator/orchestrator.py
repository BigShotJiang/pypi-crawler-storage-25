import asyncio
import queue
import threading

from asyncio import sleep

from data_migration_orchestrator.__version__ import __version__
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.query_tag import set_query_tag
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_orchestrator.worker_context import (
    WorkerContext,
    WorkerContextFactory,
)
from data_migration_orchestrator.cloud_orchestrator.workflows.workflow_initializer_factory import (
    WorkflowInitializerFactory,
)
from data_migration_orchestrator.cloud_orchestrator.workflows.workflow_type import (
    WorkflowType,
)
from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationParser,
)
from data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer import (
    DataMigrationWorkflowInitializer,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    TaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_validation_cloud.data_validation_workflow_initializer import (
    DataValidationWorkflowInitializer,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload_kind import (
    DataValidationTaskPayloadKind,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)
from shared.telemetry import (
    EXTRA_WORKFLOW_ID,
    FEATURE_ORCHESTRATION,
    TARGET_SNOWFLAKE,
    UNKNOWN_PLATFORM,
    UNKNOWN_SOURCE,
    MigrationTracker,
    categorize_exception,
    log_telemetry_event,
    sanitize_error_message,
)


logger = get_logger("orchestrator")

WORK_QUEUE_MULTIPLIER = 16
LEASE_REFRESH_INTERVAL_SECONDS = 60
TASK_PULL_INTERVAL_SECONDS = 20


class Orchestrator:
    """
    Orchestrates the execution of data migration workflows.

    The Orchestrator manages task creation, scheduling, and execution for data migration
    workflows, coordinating between different executor types.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue[TaskPayload],
        warehouse_proxy: Warehouse,
        worker_context_factory: WorkerContextFactory,
        workflow_cycle_interval_seconds: int = 10,
        configuration_parser: ConfigurationParser | None = None,
        max_task_workers: int = 8,
        task_pull_interval_seconds: int = TASK_PULL_INTERVAL_SECONDS,
    ):
        """
        Initialize the Orchestrator.

        Args:
            task_queue: The task queue implementation for managing tasks (used by the main thread).
            warehouse_proxy: The warehouse proxy for executing warehouse operations (used by the main thread).
            worker_context_factory: Factory that creates per-thread resources (connection, task queue, warehouse, handler factory).
            workflow_cycle_interval_seconds: The interval in seconds between workflow cycles.
            configuration_parser: Parser for table configurations. If None, a default one is created.
            max_task_workers: Number of persistent worker threads for task execution.
            task_pull_interval_seconds: The interval in seconds between task pulls on the dedicated pull thread.

        """
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy
        self.is_running = False
        self.workflow_cycle_interval_seconds = workflow_cycle_interval_seconds
        self.configuration_parser = configuration_parser or ConfigurationParser()
        self.initializer_factory = self._create_workflow_initializer_factory()

        self._worker_context_factory = worker_context_factory
        self._max_task_workers = max_task_workers
        self._task_pull_interval_seconds = task_pull_interval_seconds
        self._work_queue: queue.Queue[Task | None] = queue.Queue()
        self._workers: list[threading.Thread] = []
        self._active_task_ids: set[int] = set()
        self._enqueued_task_ids: set[int] = set()
        self._active_tasks_lock = threading.Lock()
        self._lease_refresh_stop = threading.Event()
        self._lease_refresh_thread: threading.Thread | None = None
        self._task_pull_stop = threading.Event()
        self._task_pull_thread: threading.Thread | None = None

    async def start(self) -> None:
        """
        Start the Orchestrator.

        Spawns persistent worker threads, then enters the main loop which runs
        until the is_running flag is set to False.
        """
        self.is_running = True
        self._start_workers()
        while self.is_running:
            try:
                await self.execute_workflow_cycle()
            except Exception as e:
                logger.error(f"Error in orchestrator cycle: {e}", exc_info=True)

            await sleep(self.workflow_cycle_interval_seconds)

    async def execute_workflow_cycle(self) -> None:
        """
        Execute a single cycle of the workflow.

        This method performs book-keeping and handles pending workflows.
        Task pulling runs on a dedicated background thread (see ``_task_pull_loop``).
        """
        await self._do_book_keeping_for_tasks()
        await self._handle_workflows()

    async def _handle_workflows(self):
        """Handle the workflows."""
        logger.info("Handling workflows")
        pending_workflows = await self.task_queue.get_pending_workflows()
        logger.info("Found %d pending workflows", len(pending_workflows))

        for workflow in pending_workflows:
            logger.info("Creating tasks for workflow %s", workflow.id)

            # Track workflow start
            log_telemetry_event(
                action="workflow_start",
                status="success",
                task_id=str(workflow.id),
                source_type=(
                    workflow.source_platform
                    if hasattr(workflow, "source_platform")
                    else UNKNOWN_PLATFORM
                ),
                feature=FEATURE_ORCHESTRATION,
            )

            try:
                if workflow.initialization_failures > 0:
                    logger.info(
                        "Workflow %s has %d previous initialization failure(s), cleaning up tasks before re-initializing",
                        workflow.id,
                        workflow.initialization_failures,
                    )
                    await self.task_queue.delete_workflow_tasks(workflow.id)

                workflow_type: WorkflowType = WorkflowType.from_string(
                    workflow.workflow_type
                )
                logger.info(
                    "Creating tasks for workflow %s of type %s",
                    workflow.id,
                    workflow_type,
                )
                initializer = self.initializer_factory.get_initializer(workflow_type)
                await initializer.create_initial_tasks(workflow)

                await self.task_queue.set_workflow_running(workflow.id)
                logger.info("Successfully created tasks for workflow %s", workflow.id)

                # Track workflow tasks created successfully
                log_telemetry_event(
                    action="workflow_tasks_created",
                    status="success",
                    task_id=str(workflow.id),
                    source_type=(
                        workflow.source_platform
                        if hasattr(workflow, "source_platform")
                        else UNKNOWN_PLATFORM
                    ),
                    feature=FEATURE_ORCHESTRATION,
                )
            except Exception as e:
                logger.error(
                    "Failed to create tasks for workflow %s: %s",
                    workflow.id,
                    e,
                    exc_info=True,
                )

                await self.task_queue.fail_workflow_initialization(workflow.id, str(e))

                # Track workflow failure
                log_telemetry_event(
                    action="workflow_tasks_creation_failed",
                    status="error",
                    task_id=str(workflow.id),
                    failure_type=categorize_exception(e),
                    error_msg=sanitize_error_message(str(e)),
                    source_type=(
                        workflow.source_platform
                        if hasattr(workflow, "source_platform")
                        else UNKNOWN_PLATFORM
                    ),
                    feature=FEATURE_ORCHESTRATION,
                )
                continue

        logger.info("Completing workflows...")
        await self.task_queue.complete_workflows()
        logger.info("Completed workflows")

    async def _do_book_keeping_for_tasks(self):
        """
        Do book-keeping for the tasks.

        1. Expire workflows stuck in 'initializing' beyond the timeout.
        2. Refresh leases for tasks that a live worker is actively processing.
        3. Expire leases for tasks that have exceeded their lease duration.
        4. Complete tasks that are associated with queries running in a warehouse.
        5. Complete tasks that are associated with Snowpipe ingestion.
        6. Unblock cleanup tasks for which all non-cleanup tasks of their
           workflow are terminal.
        """
        try:
            logger.info("Expiring stale initializations...")
            await self.task_queue.expire_stale_initializations()

            with self._active_tasks_lock:
                leased_ids = self._active_task_ids | self._enqueued_task_ids
            if leased_ids:
                logger.debug(
                    "Refreshing leases for %d leased task(s) (%d active, %d enqueued)",
                    len(leased_ids),
                    len(self._active_task_ids),
                    len(self._enqueued_task_ids),
                )
                await self.task_queue.refresh_active_leases(leased_ids)

            logger.info("Expiring leases...")
            await self.task_queue.expire_leases()

            logger.info("Refreshing warehouse tasks...")
            await self.task_queue.refresh_warehouse_tasks()

            logger.info("Refreshing snowpipe tasks...")
            await self.task_queue.refresh_snowpipe_tasks()

            logger.info("Unblocking cleanup tasks...")
            await self.task_queue.unblock_cleanup_tasks()

        except Exception as e:
            logger.error(f"Error during task book-keeping: {e}", exc_info=True)

    async def _check_unblocked_tasks(self) -> list[Task]:
        """
        Check which tasks have been unblocked since the last execution.

        Keeps a large buffer so threads always have work ready and burst
        unblocks (e.g. hundreds of complete_partition tasks) drain quickly.
        Enqueued task leases are refreshed in _do_book_keeping_for_tasks.
        """
        max_queued = self._max_task_workers * WORK_QUEUE_MULTIPLIER
        available = max(0, max_queued - self._work_queue.qsize())
        if available == 0:
            logger.info("Work queue full, skipping task pull")
            return []
        return await self.task_queue.get_tasks(max_tasks=available)

    def _enqueue_tasks(self, tasks: list[Task]) -> None:
        """Place unblocked tasks onto the shared work queue for worker threads."""
        with self._active_tasks_lock:
            for task in tasks:
                if task.id is not None:
                    self._enqueued_task_ids.add(task.id)
                self._work_queue.put(task)
        logger.info("Enqueued %d task(s) for worker threads", len(tasks))

    # ------------------------------------------------------------------
    # Active task tracking (thread-safe)
    # ------------------------------------------------------------------

    def _register_active_task(self, task_id: int) -> None:
        with self._active_tasks_lock:
            self._active_task_ids.add(task_id)

    def _promote_to_active(self, task_id: int) -> None:
        """Move a task from the enqueued set to the active set when a worker picks it up."""
        with self._active_tasks_lock:
            self._enqueued_task_ids.discard(task_id)
            self._active_task_ids.add(task_id)

    def _unregister_active_task(self, task_id: int) -> None:
        with self._active_tasks_lock:
            self._active_task_ids.discard(task_id)
            self._enqueued_task_ids.discard(task_id)

    # ------------------------------------------------------------------
    # Dedicated lease refresh (runs in its own thread)
    # ------------------------------------------------------------------

    def _lease_refresh_loop(self) -> None:
        """
        Periodically refresh leases for active/enqueued tasks.

        Runs on a dedicated thread so that lease refresh is never blocked by
        slow Snowflake calls on the main orchestrator loop.  Uses its own
        Snowflake connection obtained from the worker context factory.
        """
        context = self._worker_context_factory()
        set_query_tag(context.connection, DMVF_VERSION=__version__)
        try:
            while not self._lease_refresh_stop.is_set():
                try:
                    with self._active_tasks_lock:
                        ids = self._active_task_ids | self._enqueued_task_ids
                    if ids:
                        ids_csv = ", ".join(str(tid) for tid in ids)
                        qm = qualified_migration_schema()
                        with context.connection.cursor() as cur:
                            cur.execute(
                                f"UPDATE {qm}.TASK_QUEUE "
                                f"SET LEASING_TIME = SYSDATE() "
                                f"WHERE ID IN ({ids_csv}) "
                                f"AND STATUS = '{TaskStatus.EXECUTING.value}'"
                            )
                        logger.debug(
                            "Lease-refresh thread refreshed %d task(s)", len(ids)
                        )
                except Exception:
                    logger.warning(
                        "Lease-refresh thread failed, will retry next interval",
                        exc_info=True,
                    )
                self._lease_refresh_stop.wait(LEASE_REFRESH_INTERVAL_SECONDS)
        finally:
            try:
                context.connection.close()
            except Exception:
                logger.warning(
                    "Failed to close lease-refresh connection", exc_info=True
                )

    # ------------------------------------------------------------------
    # Dedicated task pull (runs in its own thread)
    # ------------------------------------------------------------------

    def _task_pull_loop(self) -> None:
        """
        Periodically pull pending tasks from Snowflake and feed the work queue.

        Runs on a dedicated thread so that task pulling is decoupled from the
        (potentially slow) book-keeping and workflow handling on the main loop.
        Uses its own Snowflake connection obtained from the worker context factory.
        """
        context = self._worker_context_factory()
        self.task_queue.register_thread_connection(context.connection)
        set_query_tag(context.connection, DMVF_VERSION=__version__)
        try:
            while not self._task_pull_stop.is_set():
                try:
                    max_queued = self._max_task_workers * WORK_QUEUE_MULTIPLIER
                    available = max(0, max_queued - self._work_queue.qsize())
                    if available == 0:
                        logger.info("Work queue full, skipping task pull")
                    else:
                        tasks = asyncio.run(
                            self.task_queue.get_tasks(max_tasks=available)
                        )
                        if tasks:
                            logger.info(
                                "Pull thread got %d task(s): %s",
                                len(tasks),
                                [f"{t.id}:{t.task_name[:40]}" for t in tasks],
                            )
                            self._enqueue_tasks(tasks)
                except Exception:
                    logger.warning(
                        "Task-pull thread failed, will retry next interval",
                        exc_info=True,
                    )
                self._task_pull_stop.wait(self._task_pull_interval_seconds)
        finally:
            try:
                context.connection.close()
            except Exception:
                logger.warning("Failed to close task-pull connection", exc_info=True)

    # ------------------------------------------------------------------
    # Worker thread methods (run outside the async event loop)
    # ------------------------------------------------------------------

    def _task_worker(self) -> None:
        """
        Execute worker loop in a dedicated thread.

        Creates its own Snowflake connection and dependent resources on startup,
        then blocks on the shared work queue waiting for tasks to process.
        Exits when it receives a ``None`` sentinel value.
        """
        context: WorkerContext = self._worker_context_factory()
        self.task_queue.register_thread_connection(context.connection)
        try:
            while True:
                task = self._work_queue.get()
                if task is None:
                    self._work_queue.task_done()
                    break
                try:
                    if task.id is not None:
                        self._promote_to_active(task.id)
                    asyncio.run(self._execute_task_with_context(task, context))
                except Exception as e:
                    logger.error(f"Worker error on task {task.id}: {e}", exc_info=True)
                finally:
                    if task.id is not None:
                        self._unregister_active_task(task.id)
                    self._work_queue.task_done()
        finally:
            try:
                context.connection.close()
            except Exception:
                logger.warning("Failed to close worker connection", exc_info=True)

    async def _execute_task_with_context(self, task: Task, ctx: WorkerContext) -> None:
        """Execute a single task using the worker's own resources."""
        set_query_tag(
            ctx.connection,
            workflow_id=task.workflow_id,
            task_id=task.id,
            DMVF_ORCHESTRATOR_VERSION=__version__,
        )
        try:
            raw_kind = task.payload.kind

            # Determine whether this is a DV or DM task
            is_dv_task = False
            try:
                dv_kind = DataValidationTaskPayloadKind(raw_kind)
                is_dv_task = True
            except ValueError:
                dv_kind = None

            if is_dv_task:
                # DV tasks destined for DEA/warehouse should not reach the orchestrator
                if dv_kind in (
                    DataValidationTaskPayloadKind.DATA_VALIDATION,
                    DataValidationTaskPayloadKind.SNOWFLAKE_QUERY,
                ):
                    raise Exception(
                        f"{dv_kind} tasks should not be handled by the Orchestrator"
                    )
                payload_kind_str = str(dv_kind)
            else:
                payload_kind = (
                    TaskPayloadKind(raw_kind) if isinstance(raw_kind, str) else raw_kind
                )
                if payload_kind in (
                    TaskPayloadKind.DATA_MOVEMENT,
                    TaskPayloadKind.SNOWFLAKE_QUERY,
                ):
                    raise Exception(
                        f"{payload_kind} tasks should not be handled by the Orchestrator"
                    )
                payload_kind_str = str(payload_kind)

            with MigrationTracker(
                task_id=str(task.id),
                source_type=(
                    task.payload.source_type
                    if hasattr(task.payload, "source_type")
                    else UNKNOWN_SOURCE
                ),
                target_type=TARGET_SNOWFLAKE,
                feature=FEATURE_ORCHESTRATION,
                extra={
                    "payload_kind": payload_kind_str,
                    EXTRA_WORKFLOW_ID: str(task.workflow_id),
                },
            ) as tracker:
                logger.info(f"Handling task {task.id}: {task.task_name}")

                handler = None
                if is_dv_task and ctx.dv_handler_factory is not None:
                    assert (
                        dv_kind is not None
                    )  # set with is_dv_task in try/except above
                    handler = ctx.dv_handler_factory.get_handler(dv_kind)

                if handler is None:
                    handler = ctx.handler_factory.get_handler(
                        TaskPayloadKind(raw_kind)
                        if isinstance(raw_kind, str)
                        else raw_kind
                    )

                await handler.handle(task)
                logger.info(f"Completed task {task.id}")
                tracker.set_metrics(0, 0)
        except Exception as e:
            error_message = self._build_detailed_error_message(e)
            logger.error(
                f"ERROR handling task {task.id}: {error_message}",
                exc_info=True,
            )
            if task.id is not None:
                await ctx.task_queue.fail_task(
                    ExecutorType.ORCHESTRATOR.value, task.id, error_message
                )
        finally:
            set_query_tag(ctx.connection, DMVF_VERSION=__version__)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _start_workers(self) -> None:
        """Spawn persistent worker threads, the lease-refresh thread, and the task-pull thread."""
        self._lease_refresh_stop.clear()
        self._lease_refresh_thread = threading.Thread(
            target=self._lease_refresh_loop,
            name="orchestrator-lease-refresh",
            daemon=True,
        )
        self._lease_refresh_thread.start()

        self._task_pull_stop.clear()
        self._task_pull_thread = threading.Thread(
            target=self._task_pull_loop,
            name="orchestrator-task-pull",
            daemon=True,
        )
        self._task_pull_thread.start()

        for i in range(self._max_task_workers):
            thread = threading.Thread(
                target=self._task_worker,
                name=f"orchestrator-worker-{i}",
                daemon=True,
            )
            thread.start()
            self._workers.append(thread)

    def stop(self) -> None:
        """Signal all worker threads, the lease-refresh thread, and the task-pull thread to shut down."""
        self.is_running = False

        self._lease_refresh_stop.set()
        if self._lease_refresh_thread is not None:
            self._lease_refresh_thread.join(timeout=30)

        self._task_pull_stop.set()
        if self._task_pull_thread is not None:
            self._task_pull_thread.join(timeout=30)

        for _ in self._workers:
            self._work_queue.put(None)
        for worker in self._workers:
            worker.join(timeout=30)

    def _build_detailed_error_message(self, exception: Exception) -> str:
        """
        Build a detailed error message including exception type and message.

        Args:
            exception: The exception to extract details from

        Returns:
            A formatted error message with complete exception details

        """
        exception_type = type(exception).__name__
        exception_message = str(exception)
        return f"{exception_type}: {exception_message}"

    def _create_workflow_initializer_factory(self) -> WorkflowInitializerFactory:
        """
        Create a workflow initializer factory.

        Returns:
            A workflow initializer factory

        """
        factory = WorkflowInitializerFactory()
        factory.register_initializer(
            WorkflowType.DATA_MIGRATION,
            DataMigrationWorkflowInitializer(
                task_queue=self.task_queue,
                warehouse_proxy=self.warehouse_proxy,
                configuration_parser=self.configuration_parser,
            ),
        )
        factory.register_initializer(
            WorkflowType.DATA_VALIDATION,
            DataValidationWorkflowInitializer(
                task_queue=self.task_queue,
                warehouse_proxy=self.warehouse_proxy,
            ),
        )
        return factory
