"""
Entry point for the data migration orchestrator CLI.

Dispatches to subcommands registered in :mod:`data_migration_orchestrator.commands`
(``start``, ``create-data-migration-workflow``, ``create-data-validation-workflow``).
When invoked without a subcommand, ``start`` is assumed for backward compatibility.
"""

import argparse
import sys

from data_migration_orchestrator.commands import (
    START,
    create_data_migration_workflow,
    create_data_validation_workflow,
    start,
)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """
    Parse command-line arguments for the application.

    Supports subcommands: ``start`` (default), ``create-data-migration-workflow``,
    and ``create-data-validation-workflow``.
    When invoked without a subcommand, ``start`` is assumed for backward compatibility.

    Args:
        argv: Argument list to parse (defaults to sys.argv[1:]).

    Returns:
        Parsed command-line arguments

    """
    parser = argparse.ArgumentParser(
        description="Data Migration Orchestrator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest="command")
    start.register_subparser(subparsers)
    create_data_migration_workflow.register_subparser(subparsers)
    create_data_validation_workflow.register_subparser(subparsers)

    args = parser.parse_args(argv)

    if args.command is None:
        args = parser.parse_args([START] + (argv if argv is not None else sys.argv[1:]))

    return args


def main() -> None:
    """Entry point that dispatches to the selected subcommand."""
    args = parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
