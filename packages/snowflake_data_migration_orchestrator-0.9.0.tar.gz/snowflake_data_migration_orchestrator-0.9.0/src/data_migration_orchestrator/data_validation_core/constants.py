"""Constants for the Data Validation Core module."""

from snowflake.snowflake_data_validation.utils.constants import (
    RowValidationMode,
)

from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_validation_schema,
)


# Validation levels
SCHEMA_VALIDATION = "schema"
METRICS_VALIDATION = "metrics"
ROW_VALIDATION = "row"

SKIP_LEVEL = "skip"

VALIDATION_LEVELS = [SCHEMA_VALIDATION, METRICS_VALIDATION, ROW_VALIDATION]

# Row validation modes – aliases for backward compatibility
ROW_VALIDATION_MODE_ROW = RowValidationMode.ROW
ROW_VALIDATION_MODE_CELL = RowValidationMode.CELL
ROW_VALIDATION_MODE_HYBRID = RowValidationMode.HYBRID

# Result table names
SCHEMA_VALIDATION_RESULTS_TABLE = "SCHEMA_VALIDATION_RESULTS"
METRICS_VALIDATION_RESULTS_TABLE = "METRICS_VALIDATION_RESULTS"
ROW_VALIDATION_RESULTS_TABLE = "ROW_VALIDATION_RESULTS"
ROW_VALIDATION_SUMMARY_TABLE = "ROW_VALIDATION_SUMMARY"
CHUNK_HASHES_TABLE = "CHUNK_HASHES"
CELL_VALIDATION_RESULTS_TABLE = "CELL_VALIDATION_RESULTS"
TABLE_METADATA_TABLE = "TABLE_METADATA"
PARTITION_METADATA_TABLE = "PARTITION_METADATA"


def data_validation_full_schema() -> str:
    """Return the fully qualified validation metadata schema (database.schema)."""
    return qualified_validation_schema()


def fq_schema_validation_results() -> str:
    """Return fully qualified SCHEMA_VALIDATION_RESULTS table name."""
    return f"{data_validation_full_schema()}.{SCHEMA_VALIDATION_RESULTS_TABLE}"


def fq_metrics_validation_results() -> str:
    """Return fully qualified METRICS_VALIDATION_RESULTS table name."""
    return f"{data_validation_full_schema()}.{METRICS_VALIDATION_RESULTS_TABLE}"


def fq_row_validation_results() -> str:
    """Return fully qualified ROW_VALIDATION_RESULTS table name."""
    return f"{data_validation_full_schema()}.{ROW_VALIDATION_RESULTS_TABLE}"


def fq_row_validation_summary() -> str:
    """Return fully qualified ROW_VALIDATION_SUMMARY table name."""
    return f"{data_validation_full_schema()}.{ROW_VALIDATION_SUMMARY_TABLE}"


def fq_chunk_hashes() -> str:
    """Return fully qualified CHUNK_HASHES table name."""
    return f"{data_validation_full_schema()}.{CHUNK_HASHES_TABLE}"


def fq_cell_validation_results() -> str:
    """Return fully qualified CELL_VALIDATION_RESULTS table name."""
    return f"{data_validation_full_schema()}.{CELL_VALIDATION_RESULTS_TABLE}"


def fq_table_metadata() -> str:
    """Return fully qualified TABLE_METADATA table name."""
    return f"{data_validation_full_schema()}.{TABLE_METADATA_TABLE}"


def fq_partition_metadata() -> str:
    """Return fully qualified PARTITION_METADATA table name."""
    return f"{data_validation_full_schema()}.{PARTITION_METADATA_TABLE}"


def table_metadata_id_seq() -> str:
    """Return fully qualified TABLE_METADATA_ID_SEQ name."""
    return f"{data_validation_full_schema()}.TABLE_METADATA_ID_SEQ"


def partition_metadata_id_seq() -> str:
    """Return fully qualified PARTITION_METADATA_ID_SEQ name."""
    return f"{data_validation_full_schema()}.PARTITION_METADATA_ID_SEQ"


def task_results_stage() -> str:
    """Return fully qualified internal TASK_RESULTS stage name."""
    return f"{data_validation_full_schema()}.TASK_RESULTS"


def validation_csv_file_format_fqn() -> str:
    """Return fully qualified CSV file format name in the validation metadata schema."""
    return f"{data_validation_full_schema()}.CSV_FILE_FORMAT"


# Validation statuses for partitions (L2_STATUS / L3_STATUS)
VALIDATION_STATUS_PENDING = "PENDING"
VALIDATION_STATUS_VALIDATING = "VALIDATING"
VALIDATION_STATUS_VALID = "VALID"
VALIDATION_STATUS_INVALID = "INVALID"
VALIDATION_STATUS_EXECUTION_ERROR = "EXECUTION_ERROR"

# Snowflake result column names
COL_COLUMN_VALIDATED = "COLUMN_VALIDATED"
COL_SOURCE_VALUE = "SOURCE_VALUE"
COL_COLUMN_NAME = "COLUMN_NAME"
COL_DATA_TYPE = "DATA_TYPE"
COL_PARTITION_NUMBER = "PARTITION_NUMBER"
COL_MIN_VALUE = "MIN_VALUE"
COL_MAX_VALUE = "MAX_VALUE"

# Level evaluation outcomes
LEVEL_RESULT_PASSED = "PASSED"
LEVEL_RESULT_FAILED = "FAILED"

# Table completion statuses
TABLE_STATUS_PENDING = "PENDING"
TABLE_STATUS_IN_PROGRESS = "IN_PROGRESS"
TABLE_STATUS_COMPLETED = "COMPLETED"
TABLE_STATUS_FAILED = "FAILED"
TABLE_STATUS_SKIPPED = "SKIPPED"
