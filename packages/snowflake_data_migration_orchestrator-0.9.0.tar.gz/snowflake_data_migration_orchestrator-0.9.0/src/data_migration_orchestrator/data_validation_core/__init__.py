"""Data Validation Core."""
