"""Priority constants for data validation tasks."""

BASE_PRIORITY_FOR_VALIDATION_TASKS = 2

PRIORITY_FOR_WRITE_RESULTS_TASKS = 2


def compute_priority_for_validation_task(partition_id: int) -> float:
    """Compute priority for a validation task based on partition ID."""
    priority_offset = (partition_id % 100) * 0.01
    return BASE_PRIORITY_FOR_VALIDATION_TASKS + priority_offset
