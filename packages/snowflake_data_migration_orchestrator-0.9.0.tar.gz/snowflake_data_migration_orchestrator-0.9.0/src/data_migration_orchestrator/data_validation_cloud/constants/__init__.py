"""Constants for Data Validation Cloud."""
