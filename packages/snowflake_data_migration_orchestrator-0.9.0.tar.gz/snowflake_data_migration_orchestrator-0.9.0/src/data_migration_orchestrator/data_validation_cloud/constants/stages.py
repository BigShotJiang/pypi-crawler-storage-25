"""Constants for Snowflake stage identifiers used in data validation."""

from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_validation_schema,
)


def default_internal_stage() -> str:
    """Return the default internal stage for validation task results."""
    return f"@{qualified_validation_schema()}.TASK_RESULTS"
