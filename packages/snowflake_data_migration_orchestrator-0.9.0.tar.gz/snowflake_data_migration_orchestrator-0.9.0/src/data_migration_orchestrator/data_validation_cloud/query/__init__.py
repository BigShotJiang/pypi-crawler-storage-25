"""Query generation utilities for data validation workflows."""
