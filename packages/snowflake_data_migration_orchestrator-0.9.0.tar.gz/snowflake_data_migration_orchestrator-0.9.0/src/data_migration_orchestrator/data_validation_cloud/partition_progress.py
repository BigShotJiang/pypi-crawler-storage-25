"""Update validation PARTITION_METADATA per-level columns (L2_STATUS, L3_STATUS)."""

from __future__ import annotations

import re

from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_core.constants import (
    METRICS_VALIDATION,
    ROW_VALIDATION,
    VALIDATION_STATUS_EXECUTION_ERROR,
    VALIDATION_STATUS_VALIDATING,
    fq_partition_metadata,
)


_PARTITION_SCOPE_RE = re.compile(r"Partition\[([^\]]+)\]", re.IGNORECASE)


def partition_number_from_dv_task_scope(scope: str) -> int | None:
    """Parse ``Partition[n]`` from a DV task scope, if present."""
    m = _PARTITION_SCOPE_RE.search(scope or "")
    if not m:
        return None
    raw = m.group(1).strip()
    if raw.lower() == "none":
        return None
    try:
        return int(raw)
    except ValueError:
        return None


async def record_partition_write_milestone(
    warehouse: Warehouse,
    *,
    table_metadata_id: int,
    validation_level: str,
    partition_number: int | None,
    failed: bool,
) -> None:
    """
    Mark L2 or L3 partition progress after a write-results task.

    After a successful COPY, status is VALIDATING (results loaded; evaluate pending).
    After a failed COPY, status is FAILED.
    """
    if partition_number is None:
        return
    if validation_level not in (METRICS_VALIDATION, ROW_VALIDATION):
        return
    column = "L2_STATUS" if validation_level == METRICS_VALIDATION else "L3_STATUS"
    status = (
        VALIDATION_STATUS_EXECUTION_ERROR if failed else VALIDATION_STATUS_VALIDATING
    )
    await warehouse.execute_sync_query(
        f"UPDATE {fq_partition_metadata()} SET {column} = '{status}' "
        f"WHERE TABLE_ID = {table_metadata_id} AND PARTITION_NUMBER = {partition_number}"
    )


async def bulk_set_partition_level_status(
    warehouse: Warehouse,
    *,
    table_metadata_id: int,
    column: str,
    status: str,
) -> None:
    """Set L2_STATUS or L3_STATUS for every partition row of a table."""
    if column not in ("L2_STATUS", "L3_STATUS"):
        raise ValueError(f"Invalid partition progress column: {column}")
    await warehouse.execute_sync_query(
        f"UPDATE {fq_partition_metadata()} SET {column} = '{status}' "
        f"WHERE TABLE_ID = {table_metadata_id}"
    )
