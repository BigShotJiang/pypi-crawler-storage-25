"""
Hybrid row validation handler.

Implements the two-phase hybrid validation strategy:
1. Phase 1 — MD5 (row) validation per partition with individual evaluate tasks.
2. Phase 2 — Cell drilldown for partitions that failed MD5.

``max_failed_rows_number`` caps how many **cell-level diff rows** are produced in
phase 2 (drill-down detail), not whether drill-down runs. Row-validation failures
from phase 1 do not block phase 2; the DEA cell handler stops after collecting
enough cell diffs for clarity.

Phase 2 cell validation SELECTs are narrowed to **MD5-failed row keys** when those
keys are present in ``ROW_VALIDATION_RESULTS`` (same workflow / table / partition),
so the DEA does not re-fetch the entire partition for cell comparison.

Extracted from ``evaluate_level_result_handler`` to keep the level-gating
handler at a manageable size.
"""

from __future__ import annotations

import json

from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake import (
    build_snowflake_partition_condition,
)
from data_migration_orchestrator.data_validation_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_validation_cloud.partition_progress import (
    bulk_set_partition_level_status,
)
from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
    build_cell_validation_queries,
    build_normalized_cell_validation_queries,
    build_or_predicate_for_index_value_strings,
    merge_sql_where_clauses,
)
from data_migration_orchestrator.data_validation_cloud.scope import (
    build_evaluate_scope,
    build_validation_scope,
    build_write_results_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.dea_payload_factory import (
    DEAPayloadFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    EvaluateLevelResultPayload,
    WriteValidationResultsPayload,
)
from data_migration_orchestrator.data_validation_cloud.tasks.snowpipe_flow import (
    build_result_pipes_for_partition,
    build_snowpipe_level_chain,
)
from data_migration_orchestrator.data_validation_cloud.utils.pipe_utils import (
    DvResultsPipeKey,
)
from data_migration_orchestrator.data_validation_core.constants import (
    COL_COLUMN_VALIDATED,
    COL_MAX_VALUE,
    COL_MIN_VALUE,
    COL_PARTITION_NUMBER,
    COL_SOURCE_VALUE,
    ROW_VALIDATION,
    ROW_VALIDATION_MODE_ROW,
    TABLE_STATUS_COMPLETED,
    TABLE_STATUS_FAILED,
    VALIDATION_STATUS_INVALID,
    VALIDATION_STATUS_VALID,
    data_validation_full_schema,
    fq_cell_validation_results,
    fq_chunk_hashes,
    fq_row_validation_results,
    fq_row_validation_summary,
    fq_schema_validation_results,
    task_results_stage,
    validation_csv_file_format_fqn,
)
from data_migration_orchestrator.utils.snowflake_sql_utils import (
    quote_string_literal,
)


logger = get_logger("dv.hybrid_validation_handler")

# Keys for the metrics context dict (mirrors evaluate_level_result_handler)
_CTX_SOURCE_COLUMNS = "source_columns"
_CTX_TARGET_COLUMNS = "target_columns"
_CTX_SRC_DB = "src_db"
_CTX_SRC_SCHEMA = "src_schema"
_CTX_SRC_TABLE = "src_table"
_CTX_TGT_DB = "tgt_db"
_CTX_TGT_SCHEMA = "tgt_schema"
_CTX_TGT_TABLE = "tgt_table"
_CTX_SRC_FQ = "src_fq"
_CTX_TGT_FQ = "tgt_fq"


class HybridValidationHandler:
    """Handles hybrid (MD5 + cell drilldown) validation orchestration."""

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """Initialize with shared task queue and warehouse proxy."""
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    # ------------------------------------------------------------------
    # Public API — called by EvaluateLevelResultHandler
    # ------------------------------------------------------------------

    async def handle_partition_evaluation(
        self, payload: EvaluateLevelResultPayload, task_id: int
    ) -> None:
        """Handle hybrid mode partition-level evaluation after MD5 completion."""
        partition_info = self._extract_partition_from_identifier(
            payload.source_identifier
        )
        if not partition_info:
            logger.error(
                "Could not extract partition info from source_identifier: %s",
                payload.source_identifier,
            )
            await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task_id)
            return

        table_name, partition_num = partition_info

        partition_passed = await self._partition_passed_md5_for_scope(
            payload.workflow_id,
            payload.table_metadata_id,
            table_name,
            partition_num,
        )

        if not partition_passed:
            logger.info(
                "Hybrid mode: Partition %s failed MD5, triggering cell drill-down "
                "for table_metadata_id=%d",
                partition_num,
                payload.table_metadata_id,
            )
            await self._push_single_partition_cell_validation(payload, partition_num)
        else:
            logger.info(
                "Hybrid mode: Partition %s passed MD5 validation for table_metadata_id=%d",
                partition_num,
                payload.table_metadata_id,
            )

        await self._check_and_complete_hybrid_table(payload)
        await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task_id)

    async def push_hybrid_row_chain(
        self,
        payload: EvaluateLevelResultPayload,
        table_config: dict,
        partitions: list[dict],
    ) -> None:
        """Push hybrid validation: MD5 per partition with individual evaluation tasks."""
        src_db, src_schema, src_table = _parse_fqn(payload.source_identifier)
        tgt_db = table_config.get(keys.TARGET_DATABASE, "")
        tgt_schema = table_config.get(keys.TARGET_SCHEMA, src_schema)
        tgt_table = table_config.get(keys.TARGET_NAME, src_table)

        src_fq = (
            f"{src_db}.{src_schema}.{src_table}"
            if src_db
            else f"{src_schema}.{src_table}"
        )
        tgt_fq = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        index_column_list = table_config.get(keys.INDEX_COLUMN_LIST) or []
        target_index_column_list = (
            table_config.get(keys.TARGET_INDEX_COLUMN_LIST) or index_column_list
        )
        chunk_number = table_config.get(keys.CHUNK_NUMBER)
        max_failed_rows_number = table_config.get(keys.MAX_FAILED_ROWS_NUMBER)

        columns_metadata = await self._get_columns_metadata(
            payload.workflow_id,
            payload.table_metadata_id,
            payload.source_platform,
        )

        dea_factory = DEAPayloadFactory(
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_identifier=payload.source_identifier,
            source_platform=payload.source_platform,
        )

        use_snowpipe = payload.use_snowpipe_for_results
        row_pipe_keys = [
            DvResultsPipeKey.ROW_DIFFS,
            DvResultsPipeKey.ROW_SUMMARY,
            DvResultsPipeKey.CHUNK_HASHES,
        ]

        chains: list[tuple[Any, Any]] = []
        for partition in partitions:
            partition_num = partition.get(COL_PARTITION_NUMBER)
            min_val = partition.get(COL_MIN_VALUE)
            max_val = partition.get(COL_MAX_VALUE)

            user_source_where = table_config.get(keys.WHERE_CLAUSE) or ""
            user_target_where = table_config.get(keys.TARGET_WHERE_CLAUSE) or ""
            _pcols = table_config.get(keys.COLUMN_NAMES_TO_PARTITION_BY, [])
            partition_column = _pcols[0] if _pcols else None

            source_where = _build_scoped_where(
                user_source_where,
                partition_column,
                min_val,
                max_val,
                payload.source_platform,
                target_side=False,
            )
            target_where = _build_scoped_where(
                user_target_where,
                partition_column,
                min_val,
                max_val,
                payload.source_platform,
                target_side=True,
            )

            partition_identifier = (
                f"{payload.source_identifier}#partition_{partition_num}"
            )
            evaluate_payload = EvaluateLevelResultPayload(
                table_metadata_id=payload.table_metadata_id,
                completed_level=ROW_VALIDATION,
                next_level=None,
                continue_on_failure=payload.continue_on_failure,
                next_level_enabled=False,
                workflow_id=payload.workflow_id,
                source_platform=payload.source_platform,
                source_identifier=partition_identifier,
                row_validation_mode=ROW_VALIDATION_MODE_ROW,
                l3_drill_down_phase=True,
                use_snowpipe_for_results=use_snowpipe,
            )

            evaluate_task = (
                TaskBuilder(
                    workflow_id=payload.workflow_id,
                    task_name=f"Evaluate hybrid L3 partition {partition_num} for {payload.source_identifier}",
                    executor_type=ExecutorType.ORCHESTRATOR,
                    payload=evaluate_payload,
                    scope=build_evaluate_scope(partition_identifier, ROW_VALIDATION),
                )
                .blocked()
                .build()
            )
            evaluate_task_id = await self.task_queue.push_task(evaluate_task)
            if evaluate_task_id is None:
                raise RuntimeError(
                    f"Failed to push evaluate task for hybrid L3 partition {partition_num}"
                )

            stage_path = dea_factory.stage_path("row", partition_num)

            dea_payload = dea_factory.row_payload(
                index_column_list=index_column_list,
                target_index_column_list=target_index_column_list,
                chunk_number=chunk_number,
                columns_metadata=columns_metadata,
                source_where_clause=source_where,
                target_where_clause=target_where,
                max_failed_rows_number=max_failed_rows_number,
                partition_number=partition_num,
                source_table_fqn=src_fq,
                target_table_fqn=tgt_fq,
            )

            if use_snowpipe:
                snowpipe_chain = await build_snowpipe_level_chain(
                    task_queue=self.task_queue,
                    warehouse=self.warehouse_proxy,
                    workflow_id=payload.workflow_id,
                    level="row",
                    pipe_keys=row_pipe_keys,
                    evaluate_task_id=evaluate_task_id,
                )
                dea_payload.result_pipes = build_result_pipes_for_partition(
                    pipe_entries=snowpipe_chain.pipe_entries,
                    workflow_id=payload.workflow_id,
                    table_metadata_id=payload.table_metadata_id,
                    level="row",
                    partition_number=partition_num,
                )
                dea_task = (
                    TaskBuilder(
                        workflow_id=payload.workflow_id,
                        task_name=f"MD5 validation for hybrid partition {partition_num} of {payload.source_identifier}",
                        executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                        payload=dea_payload,
                        scope=build_validation_scope(
                            payload.source_identifier,
                            ROW_VALIDATION,
                            partition_num,
                        ),
                    )
                    .with_successor(snowpipe_chain.entry_task_id)
                    .build()
                )
                await self.task_queue.push_task(dea_task)
                continue

            dea_task = TaskBuilder(
                workflow_id=payload.workflow_id,
                task_name=f"MD5 validation for hybrid partition {partition_num} of {payload.source_identifier}",
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                payload=dea_payload,
                scope=build_validation_scope(
                    payload.source_identifier, ROW_VALIDATION, partition_num
                ),
            ).build()

            summary_copy_query = _build_row_summary_copy_query(stage_path)
            diffs_copy_query = _build_row_diffs_copy_query(stage_path, partition_num)
            hashes_copy_query = _build_chunk_hashes_copy_query(stage_path)

            write_payload = WriteValidationResultsPayload(
                query=f"{summary_copy_query}; {diffs_copy_query}; {hashes_copy_query}",
                table_metadata_id=payload.table_metadata_id,
                workflow_id=payload.workflow_id,
                validation_level=ROW_VALIDATION,
                partition_number=partition_num,
            )
            write_task = (
                TaskBuilder(
                    workflow_id=payload.workflow_id,
                    task_name=f"Write MD5 results for hybrid partition {partition_num}",
                    executor_type=ExecutorType.ORCHESTRATOR,
                    payload=write_payload,
                    scope=build_write_results_scope(
                        payload.source_identifier, ROW_VALIDATION, partition_num
                    ),
                )
                .with_successor(evaluate_task_id)
                .build()
            )

            chains.append((dea_task, write_task))

        if chains:
            await self.task_queue.push_independent_two_task_chains(chains)

        logger.info(
            "Pushed hybrid L3 validation chain for %s (%d partitions)",
            payload.source_identifier,
            len(partitions),
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_partition_from_identifier(
        source_identifier: str,
    ) -> tuple[str, int | None] | None:
        """Extract partition info from encoded source_identifier."""
        if "#partition_" not in source_identifier:
            return None

        parts = source_identifier.split("#partition_")
        if len(parts) != 2:
            return None

        table_name = parts[0]
        try:
            partition_num = int(parts[1]) if parts[1] != "None" else None
        except ValueError:
            return None

        return table_name, partition_num

    async def _partition_passed_md5_for_scope(
        self,
        workflow_id: int,
        table_metadata_id: int,
        table_name: str,
        partition_num: int | None,
    ) -> bool:
        """
        Check whether this partition passed MD5 validation (no mismatch rows).

        Uses per-partition scope when PARTITION_NUMBER is present; falls back to
        summary only if the results query fails (e.g. legacy schema).
        """
        safe_table = quote_string_literal(table_name)
        if partition_num is not None:
            part_clause = f"EQUAL_NULL(PARTITION_NUMBER, {int(partition_num)}::INT)"
        else:
            part_clause = "PARTITION_NUMBER IS NULL"

        mismatch_sql = (
            f"SELECT COUNT(*) AS CNT "
            f"FROM {fq_row_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id} "
            f"AND TABLE_NAME = {safe_table} "
            f"AND {part_clause} "
            f"AND RESULT IN ('FAILURE', 'NOT_FOUND_SOURCE', 'NOT_FOUND_TARGET')"
        )
        try:
            rows = await self.warehouse_proxy.execute_sync_query(mismatch_sql)
        except Exception as exc:
            logger.warning(
                "Hybrid: ROW_VALIDATION_RESULTS partition MD5 check failed (%s); "
                "using ROW_VALIDATION_SUMMARY fallback",
                exc,
            )
            return await self._partition_passed_md5_from_summary_fallback(
                workflow_id, table_metadata_id, table_name
            )

        cnt = int(rows[0].get("CNT", 0) if rows else 0)
        return cnt == 0

    async def _partition_passed_md5_from_summary_fallback(
        self, workflow_id: int, table_metadata_id: int, table_name: str
    ) -> bool:
        """Best-effort pass when PARTITION_NUMBER is unavailable (latest summary row)."""
        safe_table = quote_string_literal(table_name)
        summary_query = (
            f"SELECT IS_VALID "
            f"FROM {fq_row_validation_summary()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id} "
            f"AND TABLE_NAME = {safe_table} "
            f"ORDER BY CREATED_AT DESC "
            f"LIMIT 1"
        )
        results = await self.warehouse_proxy.execute_sync_query(summary_query)
        if not results:
            return False
        return bool(results[0].get("IS_VALID", False))

    async def _push_single_partition_cell_validation(
        self, payload: EvaluateLevelResultPayload, partition_num: int | None
    ) -> None:
        """Push cell validation for a single failed partition."""
        table_config = await self._fetch_table_config(payload.table_metadata_id)

        base_identifier = payload.source_identifier.split("#")[0]

        cell_metrics_ctx = await self._fetch_metrics_column_metadata(
            payload.workflow_id,
            payload.table_metadata_id,
            base_identifier,
            table_config,
            payload.source_platform,
        )

        src_db, src_schema, src_table = _parse_fqn(base_identifier)
        tgt_db = table_config.get(keys.TARGET_DATABASE, "")
        tgt_schema = table_config.get(keys.TARGET_SCHEMA, src_schema)
        tgt_table = table_config.get(keys.TARGET_NAME, src_table)
        src_fq = (
            f"{src_db}.{src_schema}.{src_table}"
            if src_db
            else f"{src_schema}.{src_table}"
        )
        tgt_fq = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        index_column_list = table_config.get(keys.INDEX_COLUMN_LIST) or []
        target_index_column_list = (
            table_config.get(keys.TARGET_INDEX_COLUMN_LIST) or index_column_list
        )

        max_failed_raw = table_config.get(keys.MAX_FAILED_ROWS_NUMBER)
        try:
            cell_max_failed_rows: int | None = (
                int(max_failed_raw) if max_failed_raw is not None else None
            )
        except (TypeError, ValueError):
            cell_max_failed_rows = None

        # Get partition metadata for WHERE clause construction
        if partition_num is not None:
            partitions = await self._get_partitions(payload.table_metadata_id)
            partition = next(
                (p for p in partitions if p.get(COL_PARTITION_NUMBER) == partition_num),
                None,
            )
            if not partition:
                logger.error(
                    "Could not find partition %s for table_metadata_id=%d",
                    partition_num,
                    payload.table_metadata_id,
                )
                return

            min_val = partition.get(COL_MIN_VALUE)
            max_val = partition.get(COL_MAX_VALUE)
            _pcols = table_config.get(keys.COLUMN_NAMES_TO_PARTITION_BY, [])
            partition_column = _pcols[0] if _pcols else None

            user_source_where = table_config.get(keys.WHERE_CLAUSE) or ""
            user_target_where = table_config.get(keys.TARGET_WHERE_CLAUSE) or ""

            source_where = _build_scoped_where(
                user_source_where,
                partition_column,
                min_val,
                max_val,
                payload.source_platform,
                target_side=False,
            )
            target_where = _build_scoped_where(
                user_target_where,
                partition_column,
                min_val,
                max_val,
                payload.source_platform,
                target_side=True,
            )
        else:
            source_where = table_config.get(keys.WHERE_CLAUSE) or ""
            target_where = table_config.get(keys.TARGET_WHERE_CLAUSE) or ""

        if index_column_list and target_index_column_list:
            source_where, target_where = (
                await self._narrow_hybrid_cell_where_to_md5_failures(
                    workflow_id=payload.workflow_id,
                    table_metadata_id=payload.table_metadata_id,
                    source_table_fqn=src_fq,
                    partition_number=partition_num,
                    index_column_list=index_column_list,
                    target_index_column_list=target_index_column_list,
                    source_where=source_where,
                    target_where=target_where,
                )
            )

        max_cols_batch = table_config.get(keys.MAX_COLUMNS_PER_CELL_BATCH)

        # Build cell validation queries (single SELECT with all columns).
        normalized_pair = None
        if cell_metrics_ctx:
            normalized_pair = build_normalized_cell_validation_queries(
                payload.source_platform,
                cell_metrics_ctx[_CTX_SRC_DB],
                cell_metrics_ctx[_CTX_SRC_SCHEMA],
                cell_metrics_ctx[_CTX_SRC_TABLE],
                cell_metrics_ctx[_CTX_SRC_FQ],
                cell_metrics_ctx[_CTX_TGT_DB],
                cell_metrics_ctx[_CTX_TGT_SCHEMA],
                cell_metrics_ctx[_CTX_TGT_TABLE],
                cell_metrics_ctx[_CTX_TGT_FQ],
                cell_metrics_ctx[_CTX_SOURCE_COLUMNS],
                cell_metrics_ctx[_CTX_TARGET_COLUMNS],
                source_where_clause=source_where,
                target_where_clause=target_where,
                order_by_columns=index_column_list or None,
            )
        if normalized_pair:
            source_query, target_query = normalized_pair
        else:
            logger.warning(
                "Hybrid cell validation: could not build normalized queries for %s "
                "(missing or misaligned column metadata); using raw SELECT *",
                base_identifier,
            )
            source_query, target_query = build_cell_validation_queries(
                src_fq,
                tgt_fq,
                source_where,
                target_where,
                order_by_columns=index_column_list or None,
            )

        dea_factory = DEAPayloadFactory(
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_identifier=base_identifier,
            source_platform=payload.source_platform,
        )

        stage_path = dea_factory.stage_path("cell", partition_num)
        copy_query = _build_cell_diffs_copy_query(stage_path)

        dea_payload = dea_factory.cell_payload(
            source_query=source_query,
            target_query=target_query,
            index_column_list=index_column_list,
            target_index_column_list=target_index_column_list,
            partition_number=partition_num,
            source_table_fqn=src_fq,
            target_table_fqn=tgt_fq,
            max_failed_rows_number=cell_max_failed_rows,
            max_columns_per_cell_batch=max_cols_batch,
        )
        if payload.use_snowpipe_for_results:
            snowpipe_chain = await build_snowpipe_level_chain(
                task_queue=self.task_queue,
                warehouse=self.warehouse_proxy,
                workflow_id=payload.workflow_id,
                level="cell",
                pipe_keys=[DvResultsPipeKey.CELL_DIFFS],
                evaluate_task_id=None,  # drill-down has no downstream task
            )
            dea_payload.result_pipes = build_result_pipes_for_partition(
                pipe_entries=snowpipe_chain.pipe_entries,
                workflow_id=payload.workflow_id,
                table_metadata_id=payload.table_metadata_id,
                level="cell",
                partition_number=partition_num,
            )
            dea_task = (
                TaskBuilder(
                    workflow_id=payload.workflow_id,
                    task_name=f"Cell validation for hybrid partition {partition_num} of {base_identifier}",
                    executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                    payload=dea_payload,
                    scope=build_validation_scope(
                        base_identifier, ROW_VALIDATION, partition_num
                    ),
                )
                .with_successor(snowpipe_chain.entry_task_id)
                .build()
            )
            await self.task_queue.push_task(dea_task)
            return

        dea_task = TaskBuilder(
            workflow_id=payload.workflow_id,
            task_name=f"Cell validation for hybrid partition {partition_num} of {base_identifier}",
            executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
            payload=dea_payload,
            scope=build_validation_scope(
                base_identifier, ROW_VALIDATION, partition_num
            ),
        ).build()

        write_payload = WriteValidationResultsPayload(
            query=copy_query,
            table_metadata_id=payload.table_metadata_id,
            workflow_id=payload.workflow_id,
            validation_level=ROW_VALIDATION,
            partition_number=partition_num,
        )
        write_task = TaskBuilder(
            workflow_id=payload.workflow_id,
            task_name=f"Write cell results for hybrid partition {partition_num}",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=write_payload,
            scope=build_write_results_scope(
                base_identifier, ROW_VALIDATION, partition_num
            ),
        ).build()

        await self.task_queue.push_independent_two_task_chains([(dea_task, write_task)])

    async def _narrow_hybrid_cell_where_to_md5_failures(
        self,
        *,
        workflow_id: int,
        table_metadata_id: int,
        source_table_fqn: str,
        partition_number: int | None,
        index_column_list: list[str],
        target_index_column_list: list[str],
        source_where: str,
        target_where: str,
    ) -> tuple[str, str]:
        """
        Add ``WHERE`` predicates so cell validation selects only MD5-failed rows.

        Reads serialized keys from ``ROW_VALIDATION_RESULTS`` (written by the
        preceding MD5 task). If the table has no ``PARTITION_NUMBER`` column yet
        or the query fails, returns the partition-scoped clauses unchanged.
        """
        try:
            if partition_number is not None:
                part_clause = (
                    f"EQUAL_NULL(PARTITION_NUMBER, {int(partition_number)}::INT)"
                )
            else:
                part_clause = "PARTITION_NUMBER IS NULL"
            safe_name = quote_string_literal(source_table_fqn)
            q = (
                f"SELECT SOURCE_INDEX_VALUES, TARGET_INDEX_VALUES "
                f"FROM {fq_row_validation_results()} "
                f"WHERE WORKFLOW_ID = {workflow_id} "
                f"AND TABLE_METADATA_ID = {table_metadata_id} "
                f"AND TABLE_NAME = {safe_name} "
                f"AND {part_clause}"
            )
            rows = await self.warehouse_proxy.execute_sync_query(q)
        except Exception as exc:
            logger.warning(
                "Hybrid cell: could not read MD5 failure keys from "
                "ROW_VALIDATION_RESULTS (%s); using partition-scoped scan only",
                exc,
            )
            return source_where, target_where

        if not rows:
            logger.info(
                "Hybrid cell: no MD5 diff rows found for narrow filter; "
                "using partition-scoped scan only"
            )
            return source_where, target_where

        src_strings = [str(r.get("SOURCE_INDEX_VALUES") or "") for r in rows]
        tgt_strings = [str(r.get("TARGET_INDEX_VALUES") or "") for r in rows]

        src_pred = build_or_predicate_for_index_value_strings(
            index_column_list, src_strings
        )
        tgt_pred = build_or_predicate_for_index_value_strings(
            target_index_column_list, tgt_strings
        )

        if not src_pred and not tgt_pred:
            return source_where, target_where

        new_src = (
            merge_sql_where_clauses(source_where, src_pred)
            if src_pred
            else source_where
        )
        new_tgt = (
            merge_sql_where_clauses(target_where, tgt_pred)
            if tgt_pred
            else target_where
        )

        logger.info(
            "Hybrid cell: narrowed SELECT to MD5-failed keys "
            "(%d diff row(s); source_predicate=%s target_predicate=%s)",
            len(rows),
            bool(src_pred),
            bool(tgt_pred),
        )
        return new_src, new_tgt

    async def _check_and_complete_hybrid_table(
        self, payload: EvaluateLevelResultPayload
    ) -> None:
        """Check if all partitions are done and complete the table validation if so."""
        cell_results_query = (
            f"SELECT COUNT(*) as diff_count "
            f"FROM {fq_cell_validation_results()} "
            f"WHERE WORKFLOW_ID = {payload.workflow_id} "
            f"AND TABLE_METADATA_ID = {payload.table_metadata_id}"
        )

        results = await self.warehouse_proxy.execute_sync_query(cell_results_query)
        diff_count = results[0].get("diff_count", 0) if results else 0

        status = TABLE_STATUS_FAILED if diff_count > 0 else TABLE_STATUS_COMPLETED

        await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.UPDATE_TABLE_VALIDATION_STATUS({payload.table_metadata_id}, '{status}')"
        )

        l3_partition_status = (
            VALIDATION_STATUS_INVALID if diff_count > 0 else VALIDATION_STATUS_VALID
        )
        await bulk_set_partition_level_status(
            self.warehouse_proxy,
            table_metadata_id=payload.table_metadata_id,
            column="L3_STATUS",
            status=l3_partition_status,
        )

        logger.info(
            "Hybrid mode completed for table_metadata_id=%d: %s (cell diffs: %d)",
            payload.table_metadata_id,
            status,
            diff_count,
        )

    async def _fetch_table_config(self, table_metadata_id: int) -> dict:
        """Fetch table configuration from Snowflake."""
        config_result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_TABLE_CONFIGURATION({table_metadata_id})"
        )
        table_config_variant = (
            next(iter(config_result[0].values())) if config_result else None
        )
        return (
            json.loads(table_config_variant)
            if isinstance(table_config_variant, str)
            else table_config_variant
        ) or {}

    async def _get_partitions(self, table_metadata_id: int) -> list[dict]:
        """Get partition metadata for a table."""
        result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_PARTITION_METADATA({table_metadata_id})"
        )
        if not result:
            return []
        if isinstance(result, list):
            return result
        return []

    async def _get_columns_metadata(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_platform: str,
    ) -> list[dict]:
        """
        Read source column names + data types from L1 schema results.

        Uses the same SQL-based approach as the evaluate handler, with a
        fallback to re-run COPY INTO from the stage if results are missing.
        """
        columns = await self._query_schema_columns(
            workflow_id, table_metadata_id, source_platform
        )
        if columns:
            return columns

        logger.warning(
            "No L1 schema results found for workflow=%d, table_metadata_id=%d. "
            "Attempting to load from stage as fallback.",
            workflow_id,
            table_metadata_id,
        )
        stage_path = (
            f"@{task_results_stage()}/{workflow_id}/{table_metadata_id}/schema/"
        )
        delete_sql = (
            f"DELETE FROM {fq_schema_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id}"
        )
        copy_sql = (
            f"COPY INTO {fq_schema_validation_results()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, VALIDATION_TYPE, TABLE_NAME, "
            f"COLUMN_VALIDATED, EVALUATION_CRITERIA, SOURCE_VALUE, "
            f"SNOWFLAKE_VALUE, STATUS, COMMENTS) "
            f"FROM (SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10 "
            f"FROM '{stage_path}') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"FORCE = TRUE ON_ERROR = 'CONTINUE'"
        )
        try:
            await self.warehouse_proxy.execute_sync_query(delete_sql)
            await self.warehouse_proxy.execute_sync_query(copy_sql)
        except Exception:
            logger.warning(
                "Fallback COPY INTO failed for workflow=%d, table_metadata_id=%d",
                workflow_id,
                table_metadata_id,
                exc_info=True,
            )

        return await self._query_schema_columns(
            workflow_id, table_metadata_id, source_platform
        )

    async def _query_schema_columns(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_platform: str,
    ) -> list[dict]:
        """Query SCHEMA_VALIDATION_RESULTS for column metadata."""
        schema_rows = await self.warehouse_proxy.execute_sync_query(
            f"SELECT COLUMN_VALIDATED, SOURCE_VALUE "
            f"FROM {fq_schema_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id} "
            f"AND EVALUATION_CRITERIA = 'DATA_TYPE' "
            f"AND SOURCE_VALUE != 'MISSING'"
        )
        columns: list[dict] = []
        if schema_rows:
            for row in schema_rows:
                col_name = row.get(COL_COLUMN_VALIDATED, "")
                src_type = row.get(COL_SOURCE_VALUE, "")
                if col_name and src_type:
                    if source_platform and source_platform.lower() == "redshift":
                        col_name = col_name.lower()
                    elif source_platform and source_platform.lower() == "teradata":
                        col_name = col_name.upper()
                    columns.append({"name": col_name, "data_type": src_type})
        return columns

    async def _fetch_metrics_column_metadata(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_identifier: str,
        table_config: dict,
        source_platform: str,
    ) -> dict[str, Any] | None:
        """
        Build the metrics column context dict needed for normalized cell queries.

        Source columns come from SCHEMA_VALIDATION_RESULTS (Teradata data types).
        Target columns come from information_schema.columns (Snowflake data types),
        matching the approach used in evaluate_level_result_handler.
        """
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            make_column_metadata,
        )

        source_columns_raw = await self._get_columns_metadata(
            workflow_id, table_metadata_id, source_platform
        )
        if not source_columns_raw:
            return None

        src_db, src_schema, src_table = _parse_fqn(source_identifier)
        tgt_db = table_config.get(keys.TARGET_DATABASE, "")
        tgt_schema = table_config.get(keys.TARGET_SCHEMA, src_schema)
        tgt_table = table_config.get(keys.TARGET_NAME, src_table)

        source_columns = [
            make_column_metadata(c["name"], c["data_type"]) for c in source_columns_raw
        ]

        tgt_fq_prefix = f"{tgt_db}." if tgt_db else ""
        target_col_rows = await self.warehouse_proxy.execute_sync_query(
            f"SELECT column_name, data_type "
            f"FROM {tgt_fq_prefix}information_schema.columns "
            f"WHERE table_schema = '{tgt_schema.upper()}' "
            f"AND table_name = '{tgt_table.upper()}' "
            f"ORDER BY ordinal_position"
        )

        target_columns = []
        if target_col_rows:
            for row in target_col_rows:
                col_name = row.get("COLUMN_NAME", row.get("column_name", ""))
                data_type = row.get("DATA_TYPE", row.get("data_type", ""))
                if col_name and data_type:
                    target_columns.append(
                        make_column_metadata(name=col_name, data_type=data_type)
                    )

        src_fq = (
            f"{src_db}.{src_schema}.{src_table}"
            if src_db
            else f"{src_schema}.{src_table}"
        )
        tgt_fq = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        return {
            _CTX_SOURCE_COLUMNS: source_columns,
            _CTX_TARGET_COLUMNS: target_columns,
            _CTX_SRC_DB: src_db,
            _CTX_SRC_SCHEMA: src_schema,
            _CTX_SRC_TABLE: src_table,
            _CTX_TGT_DB: tgt_db,
            _CTX_TGT_SCHEMA: tgt_schema,
            _CTX_TGT_TABLE: tgt_table,
            _CTX_SRC_FQ: src_fq,
            _CTX_TGT_FQ: tgt_fq,
        }


# ------------------------------------------------------------------
# Module-level static utilities (shared with evaluate_level_result_handler)
# ------------------------------------------------------------------


def _parse_fqn(fqn: str) -> tuple[str, str, str]:
    """Parse a fully-qualified name into (database, schema, table)."""
    parts = fqn.split(".")
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    if len(parts) == 2:
        return "", parts[0], parts[1]
    return "", "", fqn


def _build_scoped_where(
    user_where: str,
    partition_column: str | None,
    min_value: Any,
    max_value: Any,
    source_platform: str,
    *,
    target_side: bool,
) -> str:
    """Combine a user WHERE clause with a partition range condition."""
    if not partition_column or (min_value is None and max_value is None):
        return user_where

    if target_side:
        range_clause = build_snowflake_partition_condition(
            partition_column,
            min_value,
            max_value,
        )
    else:
        try:
            platform = PlatformRegistry.create_by_name_or_alias(
                source_platform,
            )
            range_clause = platform.query_builder.build_partition_condition(
                partition_column,
                min_value,
                max_value,
            )
        except (KeyError, ValueError):
            range_clause = build_snowflake_partition_condition(
                partition_column,
                min_value,
                max_value,
            )

    if range_clause == "1=1":
        return user_where

    if user_where:
        return f"({user_where}) AND {range_clause}"
    return range_clause


def _build_row_summary_copy_query(stage_path: str) -> str:
    """Build COPY INTO SQL for row validation summary."""
    return (
        f"COPY INTO {fq_row_validation_summary()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, TOTAL_CHUNKS, "
        f"MATCHING_CHUNKS, DIFFERING_CHUNKS, TOTAL_ROWS_COMPARED, "
        f"ROWS_NOT_FOUND_IN_TARGET, ROWS_NOT_FOUND_IN_SOURCE, "
        f"ROWS_WITH_DIFFERENCES, IS_VALID) "
        f"FROM (SELECT "
        f"$1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11 "
        f"FROM '{stage_path}/summary/') "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _build_row_diffs_copy_query(
    stage_path: str, partition_number: int | None = None
) -> str:
    """Build COPY INTO SQL for row validation diffs."""
    partition_expr = (
        f"{int(partition_number)}::INT" if partition_number is not None else "NULL::INT"
    )
    return (
        f"COPY INTO {fq_row_validation_results()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, "
        f"OBJECT_TYPE, RESULT, SOURCE_INDEX_VALUES, TARGET_INDEX_VALUES, "
        f"TARGET_TABLE_NAME, PARTITION_NUMBER) "
        f"FROM (SELECT "
        f"$1, $2, $3, $4, $5, $6, $7, $8, {partition_expr} "
        f"FROM '{stage_path}/diffs/') "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _build_chunk_hashes_copy_query(stage_path: str) -> str:
    """Build COPY INTO SQL for chunk hashes."""
    return (
        f"COPY INTO {fq_chunk_hashes()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, CHUNK_ID, "
        f"SOURCE_HASH, TARGET_HASH, IS_MATCH) "
        f"FROM (SELECT "
        f"$1, $2, $3, $4, $5, $6, $7 "
        f"FROM '{stage_path}/hashes/') "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )


def _build_cell_diffs_copy_query(stage_path: str) -> str:
    """Build COPY INTO SQL for cell validation diffs."""
    return (
        f"COPY INTO {fq_cell_validation_results()} "
        f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, "
        f"ROW_INDEX, COLUMN_NAME, SOURCE_VALUE, TARGET_VALUE) "
        f"FROM (SELECT "
        f"$1, $2, $3, $4, $5, $6, $7 "
        f"FROM '{stage_path}/diffs/') "
        f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
        f"ON_ERROR = 'CONTINUE'"
    )
