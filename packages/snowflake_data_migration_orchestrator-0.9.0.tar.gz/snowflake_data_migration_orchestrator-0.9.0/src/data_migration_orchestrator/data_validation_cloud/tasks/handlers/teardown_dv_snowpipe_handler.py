"""
Handler for TEARDOWN_DV_SNOWPIPE tasks.

Drops a per-workflow DV result Snowpipe. Scheduled as a cleanup task so
it runs after every non-cleanup task terminates, even when the workflow
failed.
"""

from __future__ import annotations

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.utils.pipe_utils import (
    build_drop_pipe_sql,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    TeardownDvSnowpipePayload,
)


logger = get_logger("dv.teardown_dv_snowpipe_handler")


class TeardownDvSnowpipeHandler:
    """Drop the per-workflow DV Snowpipe."""

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """Initialize the handler with shared orchestrator resources."""
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def handle(self, task: Task) -> None:
        """Run DROP PIPE IF EXISTS and complete the task."""
        payload: TeardownDvSnowpipePayload = task.payload
        assert task.id is not None, "Task must have an ID when being handled"

        logger.info(
            "Dropping DV Snowpipe %s (workflow=%d)",
            payload.pipe_name,
            payload.workflow_id,
        )
        await self.warehouse_proxy.execute_sync_query(
            build_drop_pipe_sql(payload.pipe_name)
        )

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )
