"""
Handler for PREPARE_DV_DRAIN tasks.

Fans out to one Snowpipe drain task per DV result pipe. The Prepare task
is pushed by :func:`build_snowpipe_level_chain` when a level has more
than one result pipe; it sits downstream of the DEA validate partitions
(fan-in) and, upon unblock, inserts one drain task per pipe that each
point at the downstream Evaluate task (fan-out + fan-in on Evaluate).

Why a handler instead of a direct chain: the task queue supports only
one ``SUCCESSOR_TASK_ID`` per task, so true fan-out must be implemented
by dynamically inserting the drain tasks at execution time. See
:file:`unblock_tasks.sql.j2` for the predicate that lets Evaluate unblock
only once Prepare + every drain has completed.
"""

from __future__ import annotations

from data_migration_orchestrator.cloud_core.constants.priorities import (
    DEFAULT_PRIORITY,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_cloud.scope import (
    ValidationScopeOperation,
    build_dv_snowpipe_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    PrepareDvDrainPayload,
)


logger = get_logger("dv.prepare_dv_drain_handler")


class PrepareDvDrainHandler:
    """Push one unblocked drain task per pipe, all pointing at Evaluate."""

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """Initialize the handler with shared orchestrator resources."""
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def handle(self, task: Task) -> None:
        """Insert drain tasks for each configured pipe, then complete."""
        payload: PrepareDvDrainPayload = task.payload
        assert task.id is not None, "Task must have an ID when being handled"

        if len(payload.pipe_names) != len(payload.pipe_keys):
            raise ValueError(
                "PrepareDvDrainPayload.pipe_names and pipe_keys must be the "
                f"same length (got {len(payload.pipe_names)} and "
                f"{len(payload.pipe_keys)})"
            )

        logger.info(
            "Fanning out %d DV Snowpipe drain(s) for workflow=%d level=%s "
            "(evaluate_task_id=%s)",
            len(payload.pipe_names),
            payload.workflow_id,
            payload.level,
            payload.evaluate_task_id,
        )

        for pipe_name, pipe_key in zip(
            payload.pipe_names, payload.pipe_keys, strict=True
        ):
            await self.warehouse_proxy.execute_snowpipe_drain_and_push_task(
                workflow_id=payload.workflow_id,
                pipe_name=pipe_name,
                task_name=f"Drain DV Snowpipe: {pipe_key}",
                scope=build_dv_snowpipe_scope(
                    payload.workflow_id,
                    pipe_key,
                    ValidationScopeOperation.SNOWPIPE_DRAIN,
                ),
                priority=DEFAULT_PRIORITY,
                successor_task_id=payload.evaluate_task_id,
                is_blocked=False,
            )

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )
