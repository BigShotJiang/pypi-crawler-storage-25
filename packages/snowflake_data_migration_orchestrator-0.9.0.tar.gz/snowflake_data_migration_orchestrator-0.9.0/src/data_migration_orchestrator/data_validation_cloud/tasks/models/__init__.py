"""Task models for data validation workflows."""
