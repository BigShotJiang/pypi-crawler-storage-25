"""Task payload kind enumeration for data validation workflows."""

from enum import StrEnum

from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SNOWFLAKE_QUERY_TASK_PAYLOAD_KIND,
)
from data_migration_orchestrator.cloud_core.tasks.snowpipe_task import (
    SNOWPIPE_TASK_PAYLOAD_KIND,
)


class DataValidationTaskPayloadKind(StrEnum):
    """
    All task types in the data validation workflow.

    Tasks are categorized by executor type:
    - ORCHESTRATOR: Coordination, query generation, level gating
    - DATA_EXCHANGE_AGENT: Source+target querying and validation
    - WAREHOUSE: Snowflake COPY INTO for writing results
    - SNOWPIPE: Snowpipe drain monitoring
    """

    # ==================== ORCHESTRATOR TASKS ====================
    EXTRACT_SOURCE_METADATA = "dv_extract_source_metadata"
    GENERATE_VALIDATION_QUERIES = "dv_generate_validation_queries"
    EVALUATE_LEVEL_RESULT = "dv_evaluate_level_result"
    TEARDOWN_DV_SNOWPIPE = "dv_teardown_snowpipe"
    PREPARE_DV_DRAIN = "dv_prepare_drain"

    # ==================== DATA EXCHANGE AGENT TASKS ====================
    DATA_VALIDATION = "data_validation"

    # ==================== WAREHOUSE TASKS ====================
    WRITE_VALIDATION_RESULTS = "dv_write_validation_results"
    SNOWFLAKE_QUERY = SNOWFLAKE_QUERY_TASK_PAYLOAD_KIND

    # ==================== SNOWPIPE TASKS ====================
    SNOWPIPE_INGESTION = SNOWPIPE_TASK_PAYLOAD_KIND
