"""
Helpers for wiring up Snowpipe-based DV result ingestion.

The Snowpipe flow replaces the per-partition ``Write results`` COPY INTO
task with:

1. One per-workflow Snowpipe per :class:`DvResultsPipeKey`, created
   synchronously by :func:`ensure_dv_pipe` on first use for a
   ``(workflow_id, key)`` pair (so that DEA tasks pushed afterwards
   never race ``ALTER PIPE ... REFRESH`` against the pipe's creation),
   and dropped by a queued Teardown cleanup task that runs after every
   non-cleanup task in the workflow has terminated.
2. A downstream barrier that ultimately unblocks Evaluate once every
   pipe has been fully drained:

   - Single-pipe levels (L2 metrics, L3 cell): a single ``SNOWPIPE``
     drain task that polls ``SYSTEM$PIPE_STATUS`` and fan-ins directly
     from the DEA partitions; its successor is Evaluate.
   - Multi-pipe levels (L3 row with diffs / summary / chunk-hashes):
     a single ``PrepareDvDrain`` orchestrator task that the DEA
     partitions fan in to. Once unblocked, its handler inserts one
     drain task per pipe, each pointing at Evaluate. All drains run
     in parallel and Evaluate unblocks via the usual "all predecessors
     completed" rule.

3. Upstream DEA tasks are responsible for issuing
   ``ALTER PIPE ... REFRESH PREFIX='...'`` right after they upload files
   to the internal stage.

The fan-out path exists because the task queue supports only a single
``SUCCESSOR_TASK_ID``, so true fan-out requires dynamic task insertion
at handler execution time.
"""

from __future__ import annotations

from dataclasses import dataclass

from data_migration_orchestrator.cloud_core.constants.priorities import (
    DEFAULT_PRIORITY,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_validation_cloud.scope import (
    ValidationScopeOperation,
    build_dv_snowpipe_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    PrepareDvDrainPayload,
    ResultPipeInfo,
)
from data_migration_orchestrator.data_validation_cloud.utils.ensure_dv_pipe import (
    ensure_dv_pipe,
)
from data_migration_orchestrator.data_validation_cloud.utils.pipe_utils import (
    DvResultsPipeKey,
    build_dv_stage_prefix,
)


@dataclass
class SnowpipeLevelChain:
    """
    Result of wiring the drain barrier for one validation level.

    Attributes:
        entry_task_id: Task ID that DEA tasks should set as their
            ``SUCCESSOR_TASK_ID``. It fans in all DEA partitions and,
            once unblocked, leads (directly or through a Prepare task)
            to the drain(s) that gate the Evaluate task.
        pipe_entries: Ordered ``(key, pipe_name)`` tuples; callers build
            partition-specific :class:`ResultPipeInfo` instances from
            these via :func:`build_result_pipes_for_partition`.

    """

    entry_task_id: int
    pipe_entries: list[tuple[DvResultsPipeKey, str]]


async def build_snowpipe_level_chain(
    task_queue: BaseTaskQueue,
    warehouse: Warehouse,
    workflow_id: int,
    level: str,
    pipe_keys: list[DvResultsPipeKey],
    evaluate_task_id: int | None,
) -> SnowpipeLevelChain:
    """
    Ensure per-workflow DV pipes are scheduled, then push the drain barrier.

    On first use in this process for a given ``(workflow_id, key)``,
    :func:`ensure_dv_pipe` synchronously runs ``CREATE PIPE IF NOT EXISTS``
    against ``warehouse`` and pushes a Teardown cleanup task via
    ``task_queue``. The pipe therefore exists before any DEA task is
    pushed, removing the race against DEA ``ALTER PIPE ... REFRESH``.

    Two flow shapes are supported, selected by the number of pipes:

    - ``len(pipe_keys) == 1``: one ``SNOWPIPE`` drain task is pushed
      directly, blocked on the DEA partitions and with Evaluate as its
      successor. Simplest path; used for L2 metrics and L3 cell.
    - ``len(pipe_keys) > 1``: one ``PrepareDvDrain`` orchestrator task is
      pushed, blocked on the DEA partitions and with Evaluate as its
      successor. Its handler inserts one drain per pipe at execution
      time, so the drains run in parallel. Used for L3 row mode.

    Args:
        task_queue: Task queue used to push Setup/Teardown/Prepare tasks.
        warehouse: Shared warehouse proxy used to push the single-pipe
            drain task via ``execute_snowpipe_drain_and_push_task``.
        workflow_id: Owning workflow id (also baked into the pipe name,
            the PATTERN, and the scope tags).
        level: Level token used for scopes and the Prepare payload.
        pipe_keys: DV result pipe keys in desired fan-out order.
        evaluate_task_id: Evaluate task that the drains should unblock.

    Returns:
        :class:`SnowpipeLevelChain` describing the wired-up flow.

    """
    if not pipe_keys:
        raise ValueError("pipe_keys must contain at least one key")

    pipe_entries: list[tuple[DvResultsPipeKey, str]] = []
    for key in pipe_keys:
        pipe_name = await ensure_dv_pipe(
            task_queue=task_queue,
            warehouse=warehouse,
            workflow_id=workflow_id,
            key=key,
        )
        pipe_entries.append((key, pipe_name))

    if len(pipe_entries) == 1:
        key, pipe_name = pipe_entries[0]
        drain_task_id = await warehouse.execute_snowpipe_drain_and_push_task(
            workflow_id=workflow_id,
            pipe_name=pipe_name,
            task_name=f"Drain DV Snowpipe: {key.value}",
            scope=build_dv_snowpipe_scope(
                workflow_id, key.value, ValidationScopeOperation.SNOWPIPE_DRAIN
            ),
            priority=DEFAULT_PRIORITY,
            successor_task_id=evaluate_task_id,
            is_blocked=True,
        )
        return SnowpipeLevelChain(
            entry_task_id=drain_task_id,
            pipe_entries=pipe_entries,
        )

    prepare_payload = PrepareDvDrainPayload(
        workflow_id=workflow_id,
        level=level,
        pipe_names=[name for _key, name in pipe_entries],
        pipe_keys=[key.value for key, _name in pipe_entries],
        evaluate_task_id=evaluate_task_id,
    )
    prepare_task = (
        TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Prepare DV drain ({level})",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=prepare_payload,
            scope=build_dv_snowpipe_scope(
                workflow_id,
                level,
                ValidationScopeOperation.SNOWPIPE_PREPARE_DRAIN,
            ),
        )
        .with_successor(evaluate_task_id)
        .with_priority(DEFAULT_PRIORITY)
        .blocked()
        .build()
    )
    prepare_task_id = await task_queue.push_task(prepare_task)
    assert prepare_task_id is not None, "PrepareDvDrain push must return a task id"

    return SnowpipeLevelChain(
        entry_task_id=prepare_task_id,
        pipe_entries=pipe_entries,
    )


# Per-pipe stage sub-directory the DEA writes to under the partition path.
# Metrics and cell both land directly under ``<level>/p<N>/``; L3 row mode
# splits diffs / summary / hashes into sibling subfolders.
_SUBDIR_BY_KEY: dict[DvResultsPipeKey, str] = {
    DvResultsPipeKey.METRICS: "",
    DvResultsPipeKey.ROW_DIFFS: "diffs",
    DvResultsPipeKey.ROW_SUMMARY: "summary",
    DvResultsPipeKey.CHUNK_HASHES: "hashes",
    DvResultsPipeKey.CELL_DIFFS: "diffs",
}


def build_result_pipes_for_partition(
    pipe_entries: list[tuple[DvResultsPipeKey, str]],
    workflow_id: int,
    table_metadata_id: int,
    level: str,
    partition_number: int | None,
) -> list[ResultPipeInfo]:
    """
    Build :class:`ResultPipeInfo` entries scoped to one DEA partition.

    Each entry's ``stage_prefix`` points at the exact sub-directory the
    DEA will upload to, so that one ``ALTER PIPE REFRESH PREFIX=`` per
    pipe only re-enqueues files for that partition.
    """
    base = build_dv_stage_prefix(
        workflow_id=workflow_id,
        table_metadata_id=table_metadata_id,
        level=level,
        partition_number=partition_number,
    )
    result_pipes: list[ResultPipeInfo] = []
    for key, pipe_name in pipe_entries:
        subdir = _SUBDIR_BY_KEY.get(key, "")
        stage_prefix = base if not subdir else f"{base}{subdir}/"
        result_pipes.append(
            ResultPipeInfo(pipe_name=pipe_name, stage_prefix=stage_prefix)
        )
    return result_pipes
