"""Wrapper for SDV TableConfiguration used in data validation workflows."""

from __future__ import annotations

from dataclasses import dataclass, field

from data_migration_orchestrator.data_validation_cloud.config.configuration_properties_keys import (
    APPLY_METRIC_COLUMN_MODIFIER,
    CHUNK_NUMBER,
    COLUMN_MAPPINGS,
    COLUMN_NAMES_TO_PARTITION_BY,
    COLUMN_SELECTION_LIST,
    CONTINUE_ON_FAILURE,
    EXCLUDE_METRICS,
    FULLY_QUALIFIED_NAME,
    INDEX_COLUMN_LIST,
    IS_CASE_SENSITIVE,
    MAX_COLUMNS_PER_CELL_BATCH,
    MAX_COLUMNS_PER_METRICS_BATCH,
    MAX_FAILED_ROWS_NUMBER,
    METRICS_VALIDATION,
    OBJECT_TYPE,
    ROW_VALIDATION,
    ROW_VALIDATION_MODE,
    SCHEMA_VALIDATION,
    TARGET_DATABASE,
    TARGET_INDEX_COLUMN_LIST,
    TARGET_NAME,
    TARGET_PARTITION_SIZE_MB,
    TARGET_PARTITION_SIZE_ROWS,
    TARGET_SCHEMA,
    TARGET_WHERE_CLAUSE,
    USE_COLUMN_SELECTION_AS_EXCLUDE_LIST,
    WHERE_CLAUSE,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
)


@dataclass(frozen=True)
class ValidationTableConfiguration:
    """
    Parsed table configuration for data validation.

    Holds all per-table validation settings from the workflow config JSON.
    These fields align with SDV's TableConfiguration model so the orchestrator
    can construct SDV objects directly.
    """

    fully_qualified_name: str
    use_column_selection_as_exclude_list: bool = False
    column_selection_list: list[str] = field(default_factory=list)
    target_name: str | None = None
    target_database: str | None = None
    target_schema: str | None = None
    where_clause: str = ""
    target_where_clause: str = ""
    index_column_list: list[str] = field(default_factory=list)
    target_index_column_list: list[str] = field(default_factory=list)
    column_mappings: dict[str, str] = field(default_factory=dict)
    is_case_sensitive: bool = False
    chunk_number: int | None = None
    max_failed_rows_number: int | None = None
    exclude_metrics: bool | None = None
    apply_metric_column_modifier: bool | None = None
    max_columns_per_metrics_batch: int | None = None
    max_columns_per_cell_batch: int | None = None
    object_type: str = "TABLE"
    column_names_to_partition_by: list[str] = field(default_factory=list)
    target_partition_size_rows: int | None = None
    target_partition_size_mb: int | None = None

    # Per-table overrides for validation levels and gating
    schema_validation: bool | None = None
    metrics_validation: bool | None = None
    row_validation: bool | None = None
    row_validation_mode: RowValidationMode | None = None
    continue_on_failure: bool | None = None

    def to_sdv_dict(self) -> dict:
        """Convert to a dict suitable for constructing SDV TableConfiguration."""
        d: dict = {
            FULLY_QUALIFIED_NAME: self.fully_qualified_name,
            USE_COLUMN_SELECTION_AS_EXCLUDE_LIST: self.use_column_selection_as_exclude_list,
            COLUMN_SELECTION_LIST: self.column_selection_list,
        }
        if self.target_name is not None:
            d[TARGET_NAME] = self.target_name
        if self.target_database is not None:
            d[TARGET_DATABASE] = self.target_database
        if self.target_schema is not None:
            d[TARGET_SCHEMA] = self.target_schema
        if self.where_clause:
            d[WHERE_CLAUSE] = self.where_clause
        if self.target_where_clause:
            d[TARGET_WHERE_CLAUSE] = self.target_where_clause
        if self.index_column_list:
            d[INDEX_COLUMN_LIST] = self.index_column_list
        if self.target_index_column_list:
            d[TARGET_INDEX_COLUMN_LIST] = self.target_index_column_list
        if self.column_mappings:
            d[COLUMN_MAPPINGS] = self.column_mappings
        if self.is_case_sensitive:
            d[IS_CASE_SENSITIVE] = self.is_case_sensitive
        if self.chunk_number is not None:
            d[CHUNK_NUMBER] = self.chunk_number
        if self.max_failed_rows_number is not None:
            d[MAX_FAILED_ROWS_NUMBER] = self.max_failed_rows_number
        if self.exclude_metrics is not None:
            d[EXCLUDE_METRICS] = self.exclude_metrics
        if self.apply_metric_column_modifier is not None:
            d[APPLY_METRIC_COLUMN_MODIFIER] = self.apply_metric_column_modifier
        if self.max_columns_per_metrics_batch is not None:
            d[MAX_COLUMNS_PER_METRICS_BATCH] = self.max_columns_per_metrics_batch
        if self.max_columns_per_cell_batch is not None:
            d[MAX_COLUMNS_PER_CELL_BATCH] = self.max_columns_per_cell_batch
        if self.object_type != "TABLE":
            d[OBJECT_TYPE] = self.object_type
        if self.column_names_to_partition_by:
            d[COLUMN_NAMES_TO_PARTITION_BY] = self.column_names_to_partition_by
        if self.target_partition_size_rows is not None:
            d[TARGET_PARTITION_SIZE_ROWS] = self.target_partition_size_rows
        if self.target_partition_size_mb is not None:
            d[TARGET_PARTITION_SIZE_MB] = self.target_partition_size_mb
        if self.schema_validation is not None:
            d[SCHEMA_VALIDATION] = self.schema_validation
        if self.metrics_validation is not None:
            d[METRICS_VALIDATION] = self.metrics_validation
        if self.row_validation is not None:
            d[ROW_VALIDATION] = self.row_validation
        if self.row_validation_mode is not None:
            d[ROW_VALIDATION_MODE] = self.row_validation_mode
        if self.continue_on_failure is not None:
            d[CONTINUE_ON_FAILURE] = self.continue_on_failure
        return d
