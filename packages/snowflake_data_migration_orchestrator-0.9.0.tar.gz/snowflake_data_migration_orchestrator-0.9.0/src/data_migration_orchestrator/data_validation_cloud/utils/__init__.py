"""Utility helpers for data validation workflows."""
