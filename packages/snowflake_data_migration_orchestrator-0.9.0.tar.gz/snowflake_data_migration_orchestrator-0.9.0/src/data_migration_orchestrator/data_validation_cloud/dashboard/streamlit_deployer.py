"""
Streamlit Data Validation Dashboard Deployer.

Handles automatic deployment of the data-validation Streamlit dashboard to
Snowflake when the orchestrator starts.
"""

import os
import shutil

from pathlib import Path

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.snowflake_account import (
    qualified_migration_schema,
)
from data_migration_orchestrator.cloud_core.streamlit_deployer import (
    StreamlitAppConfig,
    deploy_streamlit_app,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_validation_schema,
)


logger = get_logger("dv_streamlit_deployer")

STREAMLIT_APP_NAME = os.environ.get(
    "DV_STREAMLIT_APP_NAME", "DATA_VALIDATION_DASHBOARD"
)
STREAMLIT_STAGE_NAME = os.environ.get(
    "DV_STREAMLIT_STAGE_NAME", "DV_STREAMLIT_DASHBOARD_STAGE"
)

_BAKED_METADATA_NAME = "_streamlit_baked_metadata.py"
_SIS_STAGED_NAME = "sis_streamlit_metadata.py"
_DASHBOARD_AGGREGATION_NAME = "dashboard_aggregation.py"
_DASHBOARD_EXPORT_NAME = "dashboard_export.py"
_PACKAGE_ROOT = Path(__file__).resolve().parent.parent.parent
_SIS_STREAMLIT_METADATA_SOURCE = _PACKAGE_ROOT / "utils" / _SIS_STAGED_NAME
_DASHBOARD_AGGREGATION_SOURCE = _PACKAGE_ROOT / "utils" / _DASHBOARD_AGGREGATION_NAME
_DASHBOARD_EXPORT_SOURCE = _PACKAGE_ROOT / "utils" / _DASHBOARD_EXPORT_NAME


def _write_dv_baked_metadata(
    qualified_migration: str,
    qualified_validation: str,
    path: Path,
) -> None:
    path.write_text(
        '"""\n'
        "Generated when deploying to Streamlit in Snowflake; do not commit.\n\n"
        "Defines migration and validation metadata schemas from deploy time so the SiS\n"
        'runtime does not need CUSTOM_* environment variables.\n"""\n\n'
        f"QUALIFIED_MIGRATION_SCHEMA = {qualified_migration!r}\n"
        f"QUALIFIED_VALIDATION_SCHEMA = {qualified_validation!r}\n",
        encoding="utf-8",
    )


def deploy_dv_streamlit_if_needed(
    connection: snowflake.connector.SnowflakeConnection,
) -> None:
    """Deploy or update the DV dashboard when the local code has changed."""
    qm = qualified_migration_schema()
    qv = qualified_validation_schema()
    dashboard_dir = Path(__file__).parent
    baked_path = dashboard_dir / _BAKED_METADATA_NAME
    _write_dv_baked_metadata(qm, qv, baked_path)
    sis_staged = dashboard_dir / _SIS_STAGED_NAME
    shutil.copyfile(_SIS_STREAMLIT_METADATA_SOURCE, sis_staged)
    aggregation_staged = dashboard_dir / _DASHBOARD_AGGREGATION_NAME
    shutil.copyfile(_DASHBOARD_AGGREGATION_SOURCE, aggregation_staged)
    export_staged = dashboard_dir / _DASHBOARD_EXPORT_NAME
    shutil.copyfile(_DASHBOARD_EXPORT_SOURCE, export_staged)
    config = StreamlitAppConfig(
        qualified_schema=qv,
        app_name=STREAMLIT_APP_NAME,
        stage_name=STREAMLIT_STAGE_NAME,
        app_file=dashboard_dir / "app.py",
        companion_files=(
            baked_path,
            sis_staged,
            aggregation_staged,
            export_staged,
        ),
    )
    deploy_streamlit_app(connection, config, logger)
