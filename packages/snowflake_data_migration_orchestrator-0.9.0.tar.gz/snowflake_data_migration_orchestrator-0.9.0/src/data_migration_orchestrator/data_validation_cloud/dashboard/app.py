"""
Data Validation Dashboard.

Monitor and explore data validation results across workflows.
Designed for Streamlit in Snowflake (SiS).
"""

from __future__ import annotations

import math

from typing import Any

import altair as alt
import pandas as pd
import streamlit as st

from snowflake.snowpark.context import get_active_session


try:
    from sis_streamlit_metadata import (
        migration_schema_for_streamlit_dashboard,
        validation_schema_for_streamlit_dashboard,
    )
except ModuleNotFoundError:
    from data_migration_orchestrator.utils.sis_streamlit_metadata import (
        migration_schema_for_streamlit_dashboard,
        validation_schema_for_streamlit_dashboard,
    )

try:
    from dashboard_aggregation import (
        COL_ERROR_MESSAGE,
        COL_LAST_ERROR_MESSAGE,
        COL_LATEST_WORKFLOW_ID,
        COL_METRICS_VALIDATED,
        COL_ROWS_VALIDATED,
        COL_RUNS_COUNT,
        COL_SCHEMA_VALIDATED,
        COL_TABLE_NAME,
        COL_VALIDATION_STATUS,
        COL_WORKFLOW_ID,
        aggregate_validation_tables_by_name,
        filter_by_table_search,
    )
except ModuleNotFoundError:
    from data_migration_orchestrator.utils.dashboard_aggregation import (  # type: ignore[no-redef]
        COL_ERROR_MESSAGE,
        COL_LAST_ERROR_MESSAGE,
        COL_LATEST_WORKFLOW_ID,
        COL_METRICS_VALIDATED,
        COL_ROWS_VALIDATED,
        COL_RUNS_COUNT,
        COL_SCHEMA_VALIDATED,
        COL_TABLE_NAME,
        COL_VALIDATION_STATUS,
        COL_WORKFLOW_ID,
        aggregate_validation_tables_by_name,
        filter_by_table_search,
    )

try:
    from dashboard_export import (
        build_snapshot_csv,
        per_tab_filename,
        prepare_export_dataframe,
        snapshot_filename,
        to_csv_bytes,
    )
except ModuleNotFoundError:
    from data_migration_orchestrator.utils.dashboard_export import (  # type: ignore[no-redef]
        build_snapshot_csv,
        per_tab_filename,
        prepare_export_dataframe,
        snapshot_filename,
        to_csv_bytes,
    )


RESULT_STATUSES = ["SUCCESS", "WARNING", "FAILURE"]

STATUS_DISPLAY = {
    "SUCCESS": "Success",
    "WARNING": "Warning",
    "FAILURE": "Failure",
}

STATUS_EMOJI = {
    "SUCCESS": "🟢",
    "WARNING": "🟡",
    "FAILURE": "🔴",
}

st.set_page_config(
    page_title="Data Validation Dashboard",
    page_icon="🔍",
    layout="wide",
)

session = get_active_session()


def run_query(sql: str) -> pd.DataFrame:
    """Execute a query and return results as a pandas DataFrame."""
    return session.sql(sql).to_pandas()


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------


@st.cache_data(ttl=60)
def get_workflows():
    """
    Fetch workflows that have DV data, returning id→name mapping.

    Order is newest first by WORKFLOW.CREATION_TIME (then ID) so the dashboard
    can default the filter to the most recently created workflow.
    """
    try:
        df = run_query(
            f"""
            SELECT DISTINCT
                tm.WORKFLOW_ID,
                w.NAME,
                w.CREATION_TIME
            FROM {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm
            JOIN {migration_schema_for_streamlit_dashboard()}.WORKFLOW w ON tm.WORKFLOW_ID = w.ID
            ORDER BY w.CREATION_TIME DESC NULLS LAST, tm.WORKFLOW_ID DESC
            """
        )
        if len(df) > 0:
            return dict(
                zip(df["WORKFLOW_ID"].tolist(), df["NAME"].tolist(), strict=False)
            )
        return {}
    except Exception:
        return {}


@st.cache_data(ttl=30)
def get_table_metadata(workflow_id: int | None = None):
    """Fetch table metadata with validation status."""
    try:
        where = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        return run_query(
            f"""
            SELECT
                ID,
                WORKFLOW_ID,
                SOURCE_IDENTIFIER,
                TARGET_IDENTIFIER,
                HAS_BEEN_PREPROCESSED,
                VALIDATION_STATUS,
                CREATED_AT,
                UPDATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA
            {where}
            ORDER BY
                CASE VALIDATION_STATUS
                    WHEN 'FAILED' THEN 0
                    WHEN 'IN_PROGRESS' THEN 1
                    WHEN 'PENDING' THEN 2
                    WHEN 'COMPLETED' THEN 3
                    ELSE 4
                END,
                SOURCE_IDENTIFIER
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_table_progress_detail(workflow_id: int | None = None):
    """Per-table validation progress (L1/L2/L3, partitions) from TABLE_PROGRESS_DETAIL view."""
    try:
        where = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        return run_query(
            f"""
            SELECT *
            FROM {validation_schema_for_streamlit_dashboard()}.TABLE_PROGRESS_DETAIL
            {where}
            ORDER BY
                CASE VALIDATION_STATUS
                    WHEN 'FAILED' THEN 0
                    WHEN 'IN_PROGRESS' THEN 1
                    WHEN 'PENDING' THEN 2
                    WHEN 'COMPLETED' THEN 3
                    ELSE 4
                END,
                SOURCE_IDENTIFIER
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=45)
def get_validation_tables_summary(
    workflow_id: int | None = None,
) -> pd.DataFrame:
    """
    Per-(workflow, table) validation rollup from TABLE_PROGRESS.

    Returns one row per ``(WORKFLOW_ID, TABLE_NAME)`` with the flat schema the
    cross-workflow aggregation helper expects
    (``aggregate_validation_tables_by_name``).
    """
    try:
        qv = validation_schema_for_streamlit_dashboard()
        where = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                TABLE_NAME,
                SCHEMA_VALIDATED,
                METRICS_VALIDATED,
                ROWS_VALIDATED,
                STATUS,
                ERROR_MESSAGE
            FROM {qv}.TABLE_PROGRESS
            {where}
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_overview_metrics(workflow_id: int | None = None):
    """Aggregate KPIs across all validation result tables."""
    try:
        wf_filter = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        tm_filter = f"WHERE tm.WORKFLOW_ID = {workflow_id}" if workflow_id else ""

        return run_query(
            f"""
            WITH table_counts AS (
                SELECT
                    COUNT(*) AS total_tables,
                    SUM(CASE WHEN VALIDATION_STATUS = 'COMPLETED' THEN 1 ELSE 0 END) AS completed_tables,
                    SUM(CASE WHEN VALIDATION_STATUS = 'FAILED' THEN 1 ELSE 0 END) AS failed_tables,
                    SUM(CASE WHEN VALIDATION_STATUS = 'IN_PROGRESS' THEN 1 ELSE 0 END) AS in_progress_tables,
                    SUM(CASE WHEN VALIDATION_STATUS = 'PENDING' THEN 1 ELSE 0 END) AS pending_tables
                FROM {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA
                {wf_filter}
            ),
            schema_counts AS (
                SELECT
                    COUNT(*) AS schema_total,
                    SUM(CASE WHEN UPPER(sv.STATUS) = 'SUCCESS' THEN 1 ELSE 0 END) AS schema_pass,
                    SUM(CASE WHEN UPPER(sv.STATUS) = 'WARNING' THEN 1 ELSE 0 END) AS schema_warning,
                    SUM(CASE WHEN UPPER(sv.STATUS) = 'FAILURE' THEN 1 ELSE 0 END) AS schema_failure
                FROM {validation_schema_for_streamlit_dashboard()}.SCHEMA_VALIDATION_RESULTS sv
                JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON sv.TABLE_METADATA_ID = tm.ID
                {tm_filter}
            ),
            metrics_counts AS (
                SELECT
                    COUNT(*) AS metrics_total,
                    SUM(CASE WHEN UPPER(mv.STATUS) = 'SUCCESS' THEN 1 ELSE 0 END) AS metrics_pass,
                    SUM(CASE WHEN UPPER(mv.STATUS) = 'WARNING' THEN 1 ELSE 0 END) AS metrics_warning,
                    SUM(CASE WHEN UPPER(mv.STATUS) = 'FAILURE' THEN 1 ELSE 0 END) AS metrics_failure
                FROM {validation_schema_for_streamlit_dashboard()}.METRICS_VALIDATION_RESULTS mv
                JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON mv.TABLE_METADATA_ID = tm.ID
                {tm_filter}
            ),
            row_counts AS (
                SELECT
                    COALESCE(SUM(TOTAL_ROWS_COMPARED), 0) AS total_rows_compared,
                    COALESCE(SUM(ROWS_WITH_DIFFERENCES), 0) AS rows_with_diffs,
                    COALESCE(SUM(ROWS_NOT_FOUND_IN_TARGET), 0) AS rows_missing_target,
                    COALESCE(SUM(ROWS_NOT_FOUND_IN_SOURCE), 0) AS rows_missing_source,
                    SUM(CASE WHEN IS_VALID THEN 1 ELSE 0 END) AS row_tables_valid,
                    COUNT(*) AS row_tables_total
                FROM {validation_schema_for_streamlit_dashboard()}.ROW_VALIDATION_SUMMARY rv
                JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON rv.TABLE_METADATA_ID = tm.ID
                {tm_filter}
            )
            SELECT * FROM table_counts, schema_counts, metrics_counts, row_counts
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_schema_results(
    workflow_id: int | None = None,
    status_filter: list[str] | None = None,
    table_search: str | None = None,
):
    """Fetch schema validation results with optional filters."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
        if status_filter:
            quoted = ", ".join(f"'{s}'" for s in status_filter)
            conditions.append(f"UPPER(sv.STATUS) IN ({quoted})")
        if table_search:
            safe = table_search.replace("'", "''")
            conditions.append(f"sv.TABLE_NAME ILIKE '%{safe}%'")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        return run_query(
            f"""
            SELECT
                sv.WORKFLOW_ID,
                sv.TABLE_NAME,
                sv.COLUMN_VALIDATED,
                sv.EVALUATION_CRITERIA,
                sv.SOURCE_VALUE,
                sv.SNOWFLAKE_VALUE,
                UPPER(sv.STATUS) AS STATUS,
                sv.COMMENTS,
                sv.CREATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.SCHEMA_VALIDATION_RESULTS sv
            JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON sv.TABLE_METADATA_ID = tm.ID
            {where}
            ORDER BY
                CASE UPPER(sv.STATUS)
                    WHEN 'FAILURE' THEN 0
                    WHEN 'WARNING' THEN 1
                    WHEN 'SUCCESS' THEN 2
                    ELSE 3
                END,
                sv.TABLE_NAME, sv.COLUMN_VALIDATED
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_metrics_results(
    workflow_id: int | None = None,
    status_filter: list[str] | None = None,
    table_search: str | None = None,
):
    """Fetch metrics validation results with optional filters."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
        if status_filter:
            quoted = ", ".join(f"'{s}'" for s in status_filter)
            conditions.append(f"UPPER(mv.STATUS) IN ({quoted})")
        if table_search:
            safe = table_search.replace("'", "''")
            conditions.append(f"mv.TABLE_NAME ILIKE '%{safe}%'")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        qv = validation_schema_for_streamlit_dashboard()
        return run_query(
            f"""
            SELECT
                mv.WORKFLOW_ID,
                mv.TABLE_NAME,
                mv.PARTITION_NUMBER,
                TO_VARCHAR(pm.MIN_VALUE) AS PARTITION_MIN_VALUE,
                TO_VARCHAR(pm.MAX_VALUE) AS PARTITION_MAX_VALUE,
                mv.COLUMN_VALIDATED,
                mv.EVALUATION_CRITERIA,
                mv.SOURCE_VALUE,
                mv.SNOWFLAKE_VALUE,
                UPPER(mv.STATUS) AS STATUS,
                mv.COMMENTS,
                mv.CREATED_AT
            FROM {qv}.METRICS_VALIDATION_RESULTS mv
            JOIN {qv}.TABLE_METADATA tm ON mv.TABLE_METADATA_ID = tm.ID
            LEFT JOIN {qv}.PARTITION_METADATA pm
                ON pm.TABLE_ID = mv.TABLE_METADATA_ID
                AND pm.PARTITION_NUMBER = mv.PARTITION_NUMBER
            {where}
            ORDER BY
                CASE UPPER(mv.STATUS)
                    WHEN 'FAILURE' THEN 0
                    WHEN 'WARNING' THEN 1
                    WHEN 'SUCCESS' THEN 2
                    ELSE 3
                END,
                mv.TABLE_NAME,
                mv.PARTITION_NUMBER NULLS LAST,
                mv.COLUMN_VALIDATED
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_row_validation_summary(
    workflow_id: int | None = None,
    table_search: str | None = None,
):
    """Fetch row validation summary."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
        if table_search:
            safe = table_search.replace("'", "''")
            conditions.append(f"rv.TABLE_NAME ILIKE '%{safe}%'")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        return run_query(
            f"""
            SELECT
                rv.WORKFLOW_ID,
                rv.TABLE_NAME,
                rv.TOTAL_CHUNKS,
                rv.MATCHING_CHUNKS,
                rv.DIFFERING_CHUNKS,
                rv.TOTAL_ROWS_COMPARED,
                rv.ROWS_NOT_FOUND_IN_TARGET,
                rv.ROWS_NOT_FOUND_IN_SOURCE,
                rv.ROWS_WITH_DIFFERENCES,
                rv.IS_VALID,
                rv.CREATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.ROW_VALIDATION_SUMMARY rv
            JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON rv.TABLE_METADATA_ID = tm.ID
            {where}
            ORDER BY
                rv.IS_VALID ASC,
                rv.TABLE_NAME
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_chunk_hashes(
    workflow_id: int | None = None,
    table_search: str | None = None,
    only_mismatches: bool = False,
):
    """Fetch chunk hash comparison data."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
        if table_search:
            safe = table_search.replace("'", "''")
            conditions.append(f"ch.TABLE_NAME ILIKE '%{safe}%'")
        if only_mismatches:
            conditions.append("ch.IS_MATCH = FALSE")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        return run_query(
            f"""
            SELECT
                ch.WORKFLOW_ID,
                ch.TABLE_NAME,
                ch.CHUNK_ID,
                ch.SOURCE_HASH,
                ch.TARGET_HASH,
                ch.HASH_ALGORITHM,
                ch.IS_MATCH,
                ch.CREATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.CHUNK_HASHES ch
            JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON ch.TABLE_METADATA_ID = tm.ID
            {where}
            ORDER BY ch.IS_MATCH ASC, ch.TABLE_NAME, ch.CHUNK_ID
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_data_validation_error_logs(
    workflow_id: int | None = None,
    table_name: str | None = None,
):
    """Failed DV tasks: table/partition parsed from SCOPE, aligned with migration Error logs."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        qv = validation_schema_for_streamlit_dashboard()
        conditions = [
            "W.WORKFLOW_TYPE = 'data-validation'",
            "TQ.STATUS IN ('failed', 'abandoned')",
            "TQ.SCOPE LIKE 'DV::%'",
        ]
        if workflow_id:
            conditions.append(f"TQ.WORKFLOW_ID = {workflow_id}")
        if table_name and table_name != "All tables":
            safe_table = table_name.replace("'", "''")
            conditions.append(f"TM.SOURCE_IDENTIFIER = '{safe_table}'")

        where_sql = "WHERE " + " AND ".join(conditions)
        return run_query(
            f"""
            SELECT
                TQ.WORKFLOW_ID AS WORKFLOW_ID,
                W.NAME AS WORKFLOW_NAME,
                TM.SOURCE_IDENTIFIER AS TABLE_NAME,
                PM.PARTITION_NUMBER,
                TQ.NAME AS TASK_NAME,
                TQ.START_TIME AS TASK_START_TIME,
                TQ.END_TIME AS TASK_END_TIME,
                TQ.LAST_ERROR_MESSAGE,
                TQ.LAST_WARNING_MESSAGE
            FROM {qm}.TASK_QUEUE AS TQ
            INNER JOIN {qm}.WORKFLOW AS W ON W.ID = TQ.WORKFLOW_ID
            LEFT JOIN {qv}.TABLE_METADATA AS TM
                ON TM.WORKFLOW_ID = TQ.WORKFLOW_ID
                AND TM.SOURCE_IDENTIFIER = REGEXP_SUBSTR(
                    TQ.SCOPE, 'DV::Table\\\\[([^\\\\]]+)\\\\]', 1, 1, 'e', 1
                )
            LEFT JOIN {qv}.PARTITION_METADATA AS PM
                ON PM.TABLE_ID = TM.ID
                AND PM.PARTITION_NUMBER = TRY_TO_NUMBER(
                    REGEXP_SUBSTR(TQ.SCOPE, 'Partition\\\\[([^\\\\]]+)\\\\]', 1, 1, 'e', 1)
                )
            {where_sql}
            ORDER BY TQ.START_TIME DESC
            """
        )
    except Exception:
        return pd.DataFrame()


_CELL_PAGE_SIZE = 100


def _cell_where_clause(workflow_id: int | None, table_search: str | None) -> str:
    """Build a shared WHERE clause for cell validation queries."""
    conditions = []
    if workflow_id:
        conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
    if table_search:
        safe = table_search.replace("'", "''")
        conditions.append(f"cvr.TABLE_NAME ILIKE '%{safe}%'")
    return "WHERE " + " AND ".join(conditions) if conditions else ""


@st.cache_data(ttl=30)
def get_cell_validation_count(
    workflow_id: int | None = None,
    table_search: str | None = None,
) -> int:
    """Count total cell-by-cell mismatch rows matching the current filters."""
    try:
        qv = validation_schema_for_streamlit_dashboard()
        where = _cell_where_clause(workflow_id, table_search)
        df = run_query(
            f"""
            SELECT COUNT(*) AS TOTAL
            FROM {qv}.CELL_VALIDATION_RESULTS cvr
            JOIN {qv}.TABLE_METADATA tm ON cvr.TABLE_METADATA_ID = tm.ID
            {where}
            """
        )
        return int(df["TOTAL"].iloc[0]) if len(df) > 0 else 0
    except Exception:
        return 0


@st.cache_data(ttl=30)
def get_cell_validation_results(
    workflow_id: int | None = None,
    table_search: str | None = None,
    page: int = 0,
):
    """Fetch a single page of L3 cell-by-cell mismatch rows."""
    try:
        qv = validation_schema_for_streamlit_dashboard()
        where = _cell_where_clause(workflow_id, table_search)
        offset = page * _CELL_PAGE_SIZE
        return run_query(
            f"""
            SELECT
                cvr.WORKFLOW_ID,
                cvr.TABLE_METADATA_ID,
                tm.SOURCE_IDENTIFIER,
                cvr.TABLE_NAME,
                cvr.ROW_INDEX,
                cvr.COLUMN_NAME,
                cvr.SOURCE_VALUE,
                cvr.TARGET_VALUE,
                cvr.CREATED_AT
            FROM {qv}.CELL_VALIDATION_RESULTS cvr
            JOIN {qv}.TABLE_METADATA tm ON cvr.TABLE_METADATA_ID = tm.ID
            {where}
            ORDER BY cvr.TABLE_NAME, cvr.ROW_INDEX, cvr.COLUMN_NAME, cvr.CREATED_AT
            LIMIT {_CELL_PAGE_SIZE} OFFSET {offset}
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_task_queue_executor_types(workflow_id: int | None) -> list[str]:
    """Distinct EXECUTOR_TYPE values, optionally scoped to one workflow."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        wf_clause = (
            f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id is not None else ""
        )
        df = run_query(
            f"""
            SELECT DISTINCT EXECUTOR_TYPE
            FROM {qm}.TASK_QUEUE
            {wf_clause}
            ORDER BY EXECUTOR_TYPE
            """
        )
        if len(df) == 0:
            return []
        col = df.columns[0]
        return [str(x) for x in df[col].dropna().tolist() if str(x).strip() != ""]
    except Exception:
        return []


def _task_queue_conditions(
    workflow_id: int | None,
    status_filter: str,
    executor_type: str | None,
) -> str:
    """Build the WHERE clause shared by task-queue queries."""
    conditions: list[str] = []
    if workflow_id is not None:
        conditions.append(f"WORKFLOW_ID = {workflow_id}")
    if status_filter == "non_terminal":
        conditions.append("STATUS NOT IN ('completed', 'failed', 'abandoned')")
    elif status_filter == "completed":
        conditions.append("STATUS = 'completed'")
    elif status_filter == "failed":
        conditions.append("STATUS IN ('failed', 'abandoned')")
    elif status_filter == "executing":
        conditions.append("STATUS = 'executing'")
    elif status_filter != "all":
        return "__INVALID__"

    if executor_type:
        safe_et = executor_type.replace("'", "''")
        conditions.append(f"EXECUTOR_TYPE = '{safe_et}'")

    return "WHERE " + " AND ".join(conditions) if conditions else ""


@st.cache_data(ttl=30)
def get_task_queue_count(
    workflow_id: int | None,
    status_filter: str,
    executor_type: str | None,
) -> int:
    """Total number of TASK_QUEUE rows matching the current filters."""
    try:
        where_sql = _task_queue_conditions(workflow_id, status_filter, executor_type)
        if where_sql == "__INVALID__":
            return 0
        qm = migration_schema_for_streamlit_dashboard()
        df = run_query(f"SELECT COUNT(*) AS CNT FROM {qm}.TASK_QUEUE {where_sql}")
        return int(df.iloc[0, 0]) if len(df) > 0 else 0
    except Exception:
        return 0


@st.cache_data(ttl=30)
def get_task_queue(
    workflow_id: int | None,
    status_filter: str,
    executor_type: str | None,
    limit: int = 50,
    offset: int = 0,
) -> pd.DataFrame:
    """TASK_QUEUE rows with optional workflow, status bucket, and executor filters."""
    try:
        where_sql = _task_queue_conditions(workflow_id, status_filter, executor_type)
        if where_sql == "__INVALID__":
            return pd.DataFrame()

        qm = migration_schema_for_streamlit_dashboard()
        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                ID,
                NAME,
                EXECUTOR_TYPE,
                STATUS,
                PRIORITY,
                AFFINITY,
                LAST_ERROR_MESSAGE,
                FAILURES,
                PAYLOAD,
                LEASING_TIME,
                CREATION_TIME,
                START_TIME,
                END_TIME
            FROM {qm}.TASK_QUEUE
            {where_sql}
            ORDER BY NAME
            LIMIT {limit} OFFSET {offset}
            """
        )
    except Exception:
        return pd.DataFrame()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_int(value) -> int:
    """Convert a value to int, treating NaN/None as 0."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return 0
    return int(value)


def _status_icon(status: str) -> str:
    """Return an emoji for a given validation status."""
    return STATUS_EMOJI.get(status.upper() if isinstance(status, str) else "", "⚪")


def _status_label(status: str) -> str:
    """Return a human-friendly label for a status value."""
    return STATUS_DISPLAY.get(status.upper() if isinstance(status, str) else "", status)


def _render_status_badges(df: pd.DataFrame, col: str = "STATUS") -> pd.DataFrame:
    """Prepend status emoji to the STATUS column for visual scanning."""
    if col in df.columns:
        out = df.copy()
        out[col] = out[col].apply(lambda v: f"{_status_icon(v)} {_status_label(v)}")
        return out
    return df


def _result_status_pills(
    key_prefix: str,
    default: list[str] | None = None,
) -> list[str]:
    """Render multi-select status filter and return selected values."""
    options = RESULT_STATUSES
    fmt = {s: f"{STATUS_EMOJI[s]} {STATUS_DISPLAY[s]}" for s in options}
    selected_display = st.multiselect(
        "Filter by status",
        options=[fmt[s] for s in options],
        default=[fmt[s] for s in (default or ["FAILURE"])],
        key=f"{key_prefix}_status",
    )
    reverse = {v: k for k, v in fmt.items()}
    return [reverse[d] for d in selected_display]


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

st.title("🔍 Data validation dashboard")

_FILENAME_PREFIX = "dv"

# -- Sidebar ---------------------------------------------------------------
with st.sidebar:
    st.header("Filters")

    if st.button("Refresh data"):
        st.cache_data.clear()
        st.session_state.pop("cell_loaded", None)

    workflows = get_workflows()  # {id: name, ...}
    wf_display = {
        wf_id: name or f"Workflow {wf_id}" for wf_id, name in workflows.items()
    }
    wf_options = ["All workflows"] + [wf_display[wid] for wid in wf_display]
    name_to_id = {display: wid for wid, display in wf_display.items()}

    default_wf_index = 1 if len(workflows) > 0 else 0
    selected_wf_str = st.selectbox(
        "Workflow",
        options=wf_options,
        index=default_wf_index,
        key="wf_filter",
        help="Secondary filter. Workflows are an execution detail; "
        "tables are the primary user-facing concept (see the **Tables** tab).",
        disabled=len(workflows) == 0,
    )

    selected_wf = (
        None if selected_wf_str == "All workflows" else name_to_id.get(selected_wf_str)
    )

    # Sidebar-level table search applies across every table-driven tab. It
    # pre-fills the existing per-tab search inputs via st.session_state so
    # users don't need to type the same search in multiple places.
    table_search_global = st.text_input(
        "Table search",
        value=st.session_state.get("dv_table_search_global", ""),
        key="dv_table_search_global",
        help="Case-insensitive substring match on the table name. "
        "Pre-fills the search input in every tab.",
        placeholder="e.g. SALES or DB.SCHEMA.ORDERS",
    )
    # Propagate the global search into per-tab inputs so filters remain in sync.
    for _per_tab_key in (
        "schema_search",
        "metrics_search",
        "row_search",
        "cell_search",
        "table_search",
    ):
        st.session_state.setdefault(_per_tab_key, table_search_global)
        if st.session_state.get("_dv_last_global_search") != table_search_global:
            st.session_state[_per_tab_key] = table_search_global
    st.session_state["_dv_last_global_search"] = table_search_global

    st.markdown("---")
    advanced_mode = st.checkbox(
        "Show advanced / debug views",
        value=False,
        key="dv_advanced_mode",
        help="Reveal the Tasks (task queue) debug tab and raw internal columns.",
    )

    if len(workflows) == 0:
        st.warning("No workflows found.")

    st.markdown("---")
    st.caption("📦 Export all-tab snapshot for offline analysis")
    snapshot_slot = st.empty()

# -- Tabs -------------------------------------------------------------------
_BASIC_DV_TABS: tuple[str, ...] = (
    "📋 Tables",
    "📊 Overview",
    "Schema validation",
    "Metrics validation",
    "Row validation",
    "Cell Validation",
    "Table progress",
    "Error logs",
)
_ADVANCED_DV_TABS: tuple[str, ...] = ("📌 Tasks",)

dv_tab_labels = list(_BASIC_DV_TABS)
if advanced_mode:
    dv_tab_labels += list(_ADVANCED_DV_TABS)

dv_tabs = st.tabs(dv_tab_labels)
dv_tab_by_name: dict[str, Any] = dict(zip(dv_tab_labels, dv_tabs, strict=True))

tab_tables_primary = dv_tab_by_name["📋 Tables"]
tab_overview = dv_tab_by_name["📊 Overview"]
tab_schema = dv_tab_by_name["Schema validation"]
tab_metrics = dv_tab_by_name["Metrics validation"]
tab_rows = dv_tab_by_name["Row validation"]
tab_cell = dv_tab_by_name["Cell Validation"]
tab_tables = dv_tab_by_name["Table progress"]
tab_errors = dv_tab_by_name["Error logs"]
tab_tasks = dv_tab_by_name["📌 Tasks"] if advanced_mode else None


# ---- Display helpers ------------------------------------------------------


def _dv_download_button(
    *,
    label: str,
    df: pd.DataFrame,
    tab_name: str,
    workflow_id: int | None,
    key: str,
) -> None:
    """
    Render a CSV download link for a dataframe as a data-URI anchor.

    Avoids ``st.download_button`` so the browser never contacts SiS's stage
    URL (certain browsers/extensions append ``?title=app · Streamlit`` to
    the presigned URL, invalidating the AWS signature).
    """
    import base64

    if df is None or len(df) == 0:
        return
    csv_bytes = to_csv_bytes(prepare_export_dataframe(df))
    b64 = base64.b64encode(csv_bytes).decode("ascii")
    filename = per_tab_filename(_FILENAME_PREFIX, tab_name, workflow_id=workflow_id)
    _ = key  # kept for API compatibility; data-URI anchors need no key
    st.markdown(
        f'<a href="data:text/csv;base64,{b64}" download="{filename}" '
        'style="display:inline-block;padding:0.35rem 0.9rem;'
        "background-color:#f0f2f6;border:1px solid #d9dce4;"
        "border-radius:0.35rem;text-decoration:none;color:#0f1116;"
        'font-size:0.88rem;margin:0.15rem 0;">'
        f"{label}</a>",
        unsafe_allow_html=True,
    )


# ---- Primary Tables tab (aggregate + drill-down) --------------------------
tables_summary_df = get_validation_tables_summary(selected_wf)
if table_search_global:
    tables_summary_df = filter_by_table_search(tables_summary_df, table_search_global)

with tab_tables_primary:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing tables for **{selected_wf_str}**")
    if table_search_global:
        st.caption(f"Table filter: `{table_search_global}`")

    if len(tables_summary_df) == 0:
        st.info(
            "No validation table data available. Run a data validation workflow "
            "first, or widen the workflow/table filters."
        )
        aggregated_tables_df = pd.DataFrame()
    else:
        if selected_wf is None:
            aggregated_tables_df = aggregate_validation_tables_by_name(
                tables_summary_df
            )
            primary_df = aggregated_tables_df
        else:
            # Single-workflow view: one row per table; no aggregation needed.
            primary_df = tables_summary_df.copy()
            aggregated_tables_df = primary_df

        # KPIs.
        total_tables = int(primary_df[COL_TABLE_NAME].nunique())
        status_series = (
            primary_df.get(COL_VALIDATION_STATUS, pd.Series(dtype=str))
            .astype(str)
            .str.lower()
        )
        failed = int((status_series == "failed").sum())
        validated = int((status_series == "validated").sum())
        pending = int((status_series == "pending").sum())

        def _bool_count(col_name: str) -> int:
            """Count truthy rows for a validation-flag column (NA → False)."""
            series = primary_df.get(col_name, pd.Series(dtype=bool))
            return int(series.fillna(False).astype(bool).sum())

        schema_passed = _bool_count(COL_SCHEMA_VALIDATED)
        metrics_passed = _bool_count(COL_METRICS_VALIDATED)
        rows_passed = _bool_count(COL_ROWS_VALIDATED)

        # "Fully validated" = every enabled level passed AND overall status is
        # validated. Gives users the single "X of Y done" answer they need.
        fully_validated_mask = (
            primary_df.get(COL_SCHEMA_VALIDATED, False).fillna(False).astype(bool)
            & primary_df.get(COL_METRICS_VALIDATED, False).fillna(False).astype(bool)
            & primary_df.get(COL_ROWS_VALIDATED, False).fillna(False).astype(bool)
            & (status_series == "validated")
        )
        fully_validated = int(fully_validated_mask.sum())

        st.markdown(
            f"**{fully_validated:,} of {total_tables:,} tables fully validated** "
            "(all of schema + metrics + rows passed for the latest run)."
        )

        cols = st.columns(4)
        with cols[0]:
            st.metric("Tables", f"{total_tables:,}")
        with cols[1]:
            st.metric(
                "Failed",
                f"{failed:,}",
                delta="needs attention" if failed > 0 else None,
                delta_color="inverse",
            )
        with cols[2]:
            st.metric("Validated", f"{validated:,}")
        with cols[3]:
            st.metric("Pending", f"{pending:,}")

        level_cols = st.columns(3)
        with level_cols[0]:
            st.metric(
                "Schema (L1) passed",
                f"{schema_passed:,} / {total_tables:,}",
                help="Tables whose schema validation succeeded on the latest run.",
            )
        with level_cols[1]:
            st.metric(
                "Metrics (L2) passed",
                f"{metrics_passed:,} / {total_tables:,}",
                help="Tables whose metrics validation succeeded on the latest run.",
            )
        with level_cols[2]:
            st.metric(
                "Rows (L3) passed",
                f"{rows_passed:,} / {total_tables:,}",
                help="Tables whose row validation succeeded on the latest run.",
            )

        _dv_download_button(
            label="Download this view as CSV",
            df=primary_df,
            tab_name="tables",
            workflow_id=selected_wf,
            key="dv_download_tables",
        )

        # On-screen view with friendly labels; CSV keeps raw column names.
        view_rename = {
            COL_TABLE_NAME: "Table",
            COL_VALIDATION_STATUS: "Status",
            COL_SCHEMA_VALIDATED: "Schema ✓",
            COL_METRICS_VALIDATED: "Metrics ✓",
            COL_ROWS_VALIDATED: "Rows ✓",
            COL_LAST_ERROR_MESSAGE: "Last error",
            COL_RUNS_COUNT: "Runs",
            COL_LATEST_WORKFLOW_ID: "Latest workflow id",
        }
        on_screen = prepare_export_dataframe(
            primary_df,
            rename_map=view_rename,
        )
        st.dataframe(on_screen, use_container_width=True)

        st.markdown("### Inspect a table")
        inspect_options = ["(select a table)"] + sorted(
            primary_df[COL_TABLE_NAME].dropna().unique().tolist()
        )
        inspected = st.selectbox(
            "Table to inspect",
            options=inspect_options,
            index=0,
            key="dv_tables_inspect",
            label_visibility="collapsed",
        )
        if inspected and inspected != "(select a table)":
            executions = tables_summary_df[
                tables_summary_df[COL_TABLE_NAME] == inspected
            ].copy()
            if len(executions) > 0:
                exec_rename = {
                    COL_WORKFLOW_ID: "Workflow id",
                    COL_VALIDATION_STATUS: "Status",
                    COL_SCHEMA_VALIDATED: "Schema ✓",
                    COL_METRICS_VALIDATED: "Metrics ✓",
                    COL_ROWS_VALIDATED: "Rows ✓",
                    COL_ERROR_MESSAGE: "Error",
                }
                st.caption(
                    f"{len(executions)} workflow execution(s) touched **{inspected}**."
                )
                _dv_download_button(
                    label="Download executions as CSV",
                    df=executions,
                    tab_name=f"table_detail_{inspected}",
                    workflow_id=selected_wf,
                    key="dv_download_table_executions",
                )
                st.dataframe(
                    prepare_export_dataframe(executions, rename_map=exec_rename),
                    use_container_width=True,
                )

                st.markdown("**Quick links** — pre-fill this table into the search on:")
                link_cols = st.columns(4)
                link_target: str | None = None
                with link_cols[0]:
                    if st.button(
                        "🧬 Schema results",
                        key="dv_link_schema",
                        help="Pre-fill this table as the search on the Schema validation tab.",
                    ):
                        st.session_state["schema_search"] = inspected
                        link_target = "Schema validation"
                with link_cols[1]:
                    if st.button(
                        "📐 Metrics results",
                        key="dv_link_metrics",
                        help="Pre-fill this table as the search on the Metrics validation tab.",
                    ):
                        st.session_state["metrics_search"] = inspected
                        link_target = "Metrics validation"
                with link_cols[2]:
                    if st.button(
                        "🔢 Row results",
                        key="dv_link_rows",
                        help="Pre-fill this table as the search on the Row validation tab.",
                    ):
                        st.session_state["row_search"] = inspected
                        link_target = "Row validation"
                with link_cols[3]:
                    if st.button(
                        "🔍 Cell details",
                        key="dv_link_cell",
                        help="Pre-fill this table as the search on the Cell Validation tab.",
                    ):
                        st.session_state["cell_search"] = inspected
                        link_target = "Cell Validation"
                if link_target is not None:
                    # Streamlit doesn't support programmatic tab switching from
                    # within the tab itself, so tell the user where to click
                    # next and reassure them the filter is applied.
                    st.success(
                        f"✅ Filter `{inspected}` applied to **{link_target}**. "
                        f"Click the **{link_target}** tab above to see it."
                    )
            else:
                st.caption("No per-execution data to show.")


# ===== OVERVIEW ============================================================
with tab_overview:
    overview = get_overview_metrics(selected_wf)

    if len(overview) > 0:
        m = overview.iloc[0]

        if selected_wf is not None and selected_wf_str != "All workflows":
            st.info(f"Showing data for **{selected_wf_str}**")

        # -- Table-level KPIs
        st.subheader("Tables")
        cols = st.columns(5)
        with cols[0]:
            st.metric("Total", _safe_int(m["TOTAL_TABLES"]))
        with cols[1]:
            st.metric("Completed", _safe_int(m["COMPLETED_TABLES"]))
        with cols[2]:
            st.metric("In progress", _safe_int(m["IN_PROGRESS_TABLES"]))
        with cols[3]:
            st.metric("Pending", _safe_int(m["PENDING_TABLES"]))
        with cols[4]:
            failed_t = _safe_int(m["FAILED_TABLES"])
            st.metric(
                "Failed",
                failed_t,
                delta="needs attention" if failed_t > 0 else None,
                delta_color="inverse",
            )

        # -- Schema validation KPIs
        st.subheader("Schema validation checks")
        cols = st.columns(4)
        with cols[0]:
            st.metric("Total checks", _safe_int(m["SCHEMA_TOTAL"]))
        with cols[1]:
            st.metric("🟢 Success", _safe_int(m["SCHEMA_PASS"]))
        with cols[2]:
            st.metric("🟡 Warning", _safe_int(m["SCHEMA_WARNING"]))
        with cols[3]:
            sf = _safe_int(m["SCHEMA_FAILURE"])
            st.metric(
                "🔴 Failure",
                sf,
                delta="needs attention" if sf > 0 else None,
                delta_color="inverse",
            )

        # -- Metrics validation KPIs
        st.subheader("Metrics validation checks")
        cols = st.columns(4)
        with cols[0]:
            st.metric("Total checks", _safe_int(m["METRICS_TOTAL"]))
        with cols[1]:
            st.metric("🟢 Success", _safe_int(m["METRICS_PASS"]))
        with cols[2]:
            st.metric("🟡 Warning", _safe_int(m["METRICS_WARNING"]))
        with cols[3]:
            mf = _safe_int(m["METRICS_FAILURE"])
            st.metric(
                "🔴 Failure",
                mf,
                delta="needs attention" if mf > 0 else None,
                delta_color="inverse",
            )

        # -- Row validation KPIs
        st.subheader("Row validation")
        row_total = _safe_int(m["ROW_TABLES_TOTAL"])
        if row_total > 0:
            cols = st.columns(5)
            with cols[0]:
                st.metric("Tables checked", row_total)
            with cols[1]:
                st.metric("Valid", _safe_int(m["ROW_TABLES_VALID"]))
            with cols[2]:
                st.metric("Rows compared", f"{_safe_int(m['TOTAL_ROWS_COMPARED']):,}")
            with cols[3]:
                rd = _safe_int(m["ROWS_WITH_DIFFS"])
                st.metric(
                    "Rows with diffs",
                    f"{rd:,}",
                    delta="needs attention" if rd > 0 else None,
                    delta_color="inverse",
                )
            with cols[4]:
                missing = _safe_int(m["ROWS_MISSING_TARGET"]) + _safe_int(
                    m["ROWS_MISSING_SOURCE"]
                )
                st.metric("Rows missing", f"{missing:,}")
        else:
            st.info("No row validation data available yet.")

        # -- Combined bar chart
        st.subheader("Validation status breakdown")
        chart_data = pd.DataFrame(
            {
                "Level": [
                    "Schema",
                    "Schema",
                    "Schema",
                    "Metrics",
                    "Metrics",
                    "Metrics",
                ],
                "Status": ["Success", "Warning", "Failure"] * 2,
                "Count": [
                    _safe_int(m["SCHEMA_PASS"]),
                    _safe_int(m["SCHEMA_WARNING"]),
                    _safe_int(m["SCHEMA_FAILURE"]),
                    _safe_int(m["METRICS_PASS"]),
                    _safe_int(m["METRICS_WARNING"]),
                    _safe_int(m["METRICS_FAILURE"]),
                ],
            }
        )
        chart_data = chart_data[chart_data["Count"] > 0]
        if len(chart_data) > 0:
            pivot = chart_data.pivot_table(
                index="Level", columns="Status", values="Count", fill_value=0
            )
            col_order = [
                c for c in ["Success", "Warning", "Failure"] if c in pivot.columns
            ]
            st.bar_chart(pivot[col_order])
        else:
            st.info("No validation results yet.")
    else:
        st.warning(
            "No validation data available. Run a data validation workflow first."
        )


# ===== SCHEMA VALIDATION ===================================================
with tab_schema:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing schema results for **{selected_wf_str}**")

    col_filter, col_search = st.columns([1, 2])
    with col_filter:
        schema_statuses = _result_status_pills("schema")
    with col_search:
        schema_search = st.text_input(
            "Search tables",
            placeholder="Filter by table name...",
            key="schema_search",
            label_visibility="collapsed",
        )

    schema_summary_df = get_schema_results(selected_wf, None, schema_search or None)
    schema_df = get_schema_results(
        selected_wf,
        schema_statuses if schema_statuses else None,
        schema_search or None,
    )

    if len(schema_summary_df) > 0:
        cols = st.columns(4)
        with cols[0]:
            st.metric("Total results", len(schema_summary_df))
        for i, s in enumerate(RESULT_STATUSES):
            with cols[i + 1]:
                cnt = len(schema_summary_df[schema_summary_df["STATUS"] == s])
                st.metric(f"{STATUS_EMOJI[s]} {STATUS_DISPLAY[s]}", cnt)

        if len(schema_df) > 0:
            _dv_download_button(
                label="Download schema results as CSV",
                df=schema_df,
                tab_name="schema_results",
                workflow_id=selected_wf,
                key="dv_download_schema",
            )
            st.dataframe(
                _render_status_badges(schema_df),
                use_container_width=True,
            )

            if st.checkbox("Show detail view", key="schema_detail"):
                for _, row in schema_df.iterrows():
                    label = (
                        f"{_status_icon(row['STATUS'])} {row['TABLE_NAME']} "
                        f"| {row['COLUMN_VALIDATED']} | {row['EVALUATION_CRITERIA']}"
                    )
                    with st.expander(label):
                        c1, c2 = st.columns(2)
                        with c1:
                            st.text(f"Source:    {row['SOURCE_VALUE']}")
                        with c2:
                            st.text(f"Snowflake: {row['SNOWFLAKE_VALUE']}")
                        if row["COMMENTS"]:
                            st.caption(row["COMMENTS"])
        else:
            st.info(
                "No rows match the current status filter. Counts above include all "
                "statuses for the current workflow and table search."
            )
    else:
        st.info("No schema validation results match the current filters.")


# ===== METRICS VALIDATION ==================================================
with tab_metrics:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing metrics results for **{selected_wf_str}**")

    col_filter, col_search = st.columns([1, 2])
    with col_filter:
        metrics_statuses = _result_status_pills("metrics")
    with col_search:
        metrics_search = st.text_input(
            "Search tables",
            placeholder="Filter by table name...",
            key="metrics_search",
            label_visibility="collapsed",
        )

    metrics_summary_df = get_metrics_results(selected_wf, None, metrics_search or None)
    metrics_df = get_metrics_results(
        selected_wf,
        metrics_statuses if metrics_statuses else None,
        metrics_search or None,
    )

    if len(metrics_summary_df) > 0:
        cols = st.columns(4)
        with cols[0]:
            st.metric("Total results", len(metrics_summary_df))
        for i, s in enumerate(RESULT_STATUSES):
            with cols[i + 1]:
                cnt = len(metrics_summary_df[metrics_summary_df["STATUS"] == s])
                st.metric(f"{STATUS_EMOJI[s]} {STATUS_DISPLAY[s]}", cnt)

        if len(metrics_df) > 0:
            _dv_download_button(
                label="Download metrics results as CSV",
                df=metrics_df,
                tab_name="metrics_results",
                workflow_id=selected_wf,
                key="dv_download_metrics",
            )
            st.dataframe(
                _render_status_badges(metrics_df),
                use_container_width=True,
            )

            if st.checkbox("Show detail view", key="metrics_detail"):
                for _, row in metrics_df.iterrows():
                    part_bits: list[str] = []
                    pn = row.get("PARTITION_NUMBER")
                    if pn is not None and not pd.isna(pn):
                        part_bits.append(f"p{int(pn)}")
                    pmin = row.get("PARTITION_MIN_VALUE")
                    pmax = row.get("PARTITION_MAX_VALUE")
                    if pmin is not None and not pd.isna(pmin):
                        part_bits.append(f"min={pmin}")
                    if pmax is not None and not pd.isna(pmax):
                        part_bits.append(f"max={pmax}")
                    part_suffix = f" | {' '.join(part_bits)}" if part_bits else ""
                    label = (
                        f"{_status_icon(row['STATUS'])} {row['TABLE_NAME']}{part_suffix} "
                        f"| {row['COLUMN_VALIDATED']} | {row['EVALUATION_CRITERIA']}"
                    )
                    with st.expander(label):
                        c1, c2 = st.columns(2)
                        with c1:
                            st.text(f"Source:    {row['SOURCE_VALUE']}")
                        with c2:
                            st.text(f"Snowflake: {row['SNOWFLAKE_VALUE']}")
                        if row["COMMENTS"]:
                            st.caption(row["COMMENTS"])
        else:
            st.info(
                "No rows match the current status filter. Counts above include all "
                "statuses for the current workflow and table search."
            )
    else:
        st.info("No metrics validation results match the current filters.")


# ===== ROW VALIDATION ======================================================
with tab_rows:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing row validation for **{selected_wf_str}**")

    row_search = st.text_input(
        "Search tables",
        placeholder="Filter by table name...",
        key="row_search",
        label_visibility="collapsed",
    )

    # -- Summary
    st.subheader("Row validation summary")
    row_summary_df = get_row_validation_summary(selected_wf, row_search or None)

    if len(row_summary_df) > 0:
        cols = st.columns(4)
        total_t = len(row_summary_df)
        valid_t = len(row_summary_df[row_summary_df["IS_VALID"] == True])  # noqa: E712
        with cols[0]:
            st.metric("Tables", total_t)
        with cols[1]:
            st.metric("Valid", valid_t)
        with cols[2]:
            st.metric("Invalid", total_t - valid_t)
        with cols[3]:
            total_diffs = int(row_summary_df["ROWS_WITH_DIFFERENCES"].sum())
            st.metric("Total row diffs", f"{total_diffs:,}")

        display = row_summary_df.copy()
        display["VALID"] = display["IS_VALID"].apply(
            lambda v: "🟢 Yes" if v else "🔴 No"
        )
        _dv_download_button(
            label="Download row summary as CSV",
            df=row_summary_df,
            tab_name="row_summary",
            workflow_id=selected_wf,
            key="dv_download_row_summary",
        )
        st.dataframe(display, use_container_width=True)
    else:
        st.info("No row validation summary data available.")

    # -- Chunk hashes
    st.subheader("Chunk hash comparison")
    only_mismatches = st.checkbox(
        "Show only mismatches", value=True, key="chunk_mismatch"
    )
    chunk_df = get_chunk_hashes(selected_wf, row_search or None, only_mismatches)

    if len(chunk_df) > 0:
        chunk_display = chunk_df.copy()
        chunk_display["MATCH"] = chunk_display["IS_MATCH"].apply(
            lambda v: "🟢 Match" if v else "🔴 Mismatch"
        )
        st.dataframe(chunk_display, use_container_width=True)
    else:
        if only_mismatches:
            st.success("All chunk hashes match!")
        else:
            st.info("No chunk hash data available.")


# ===== L3 CELL VALIDATION ==================================================
with tab_cell:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing cell validation for **{selected_wf_str}**")

    st.caption(
        "Each row is a **cell-level mismatch** between source and target. "
        "Empty results mean no mismatches were recorded for the current filters."
    )

    cell_search = st.text_input(
        "Search tables",
        placeholder="Filter by table name...",
        key="cell_search",
        label_visibility="collapsed",
    )

    if st.button("Load cell validation results", key="load_cell"):
        st.session_state["cell_loaded"] = True
        st.session_state["cell_wf"] = selected_wf
        st.session_state["cell_page"] = 0

    if st.session_state.get("cell_loaded"):
        cell_wf = st.session_state["cell_wf"]
        cell_tbl = st.session_state.get("cell_search") or None
        cell_page = st.session_state.get("cell_page", 0)

        total = get_cell_validation_count(cell_wf, cell_tbl)
        total_pages = max(1, (total + _CELL_PAGE_SIZE - 1) // _CELL_PAGE_SIZE)
        cell_page = min(cell_page, total_pages - 1)

        cell_df = get_cell_validation_results(cell_wf, cell_tbl, cell_page)

        st.metric("Cell mismatches", f"{total:,}")

        if len(cell_df) > 0:
            nav_cols = st.columns([1, 2, 1])
            with nav_cols[0]:
                if st.button("← Previous", key="cell_prev", disabled=cell_page <= 0):
                    st.session_state["cell_page"] = cell_page - 1
            with nav_cols[1]:
                start = cell_page * _CELL_PAGE_SIZE + 1
                end = min(start + _CELL_PAGE_SIZE - 1, total)
                st.markdown(
                    f"<div style='text-align:center'>Showing {start:,}–{end:,} of {total:,} (page {cell_page + 1}/{total_pages})</div>",
                    unsafe_allow_html=True,
                )
            with nav_cols[2]:
                if st.button(
                    "Next →", key="cell_next", disabled=cell_page >= total_pages - 1
                ):
                    st.session_state["cell_page"] = cell_page + 1

            st.dataframe(cell_df, use_container_width=True)
            _dv_download_button(
                label="Download this page as CSV",
                df=cell_df,
                tab_name="cell_validation",
                workflow_id=selected_wf,
                key="dv_download_cell",
            )
        else:
            st.info("No cell validation results match the current filters.")
    else:
        st.info("Click **Load cell validation results** to fetch mismatch data.")


# ===== TABLE PROGRESS ======================================================

_PROGRESS_STATUS_COLORS = {
    "Pending": "#bdc3c7",
    "In progress": "#3498db",
    "Waiting for eval": "#8e44ad",
    "Valid": "#27ae60",
    "Invalid": "#e74c3c",
    "Execution error": "#f39c12",
}

_PROGRESS_STATUS_ORDER = [
    "Valid",
    "Invalid",
    "Execution error",
    "Waiting for eval",
    "In progress",
    "Pending",
]


def _build_table_chart_data(df: pd.DataFrame) -> pd.DataFrame:
    """Build long-form chart data for table-level progress (Preprocessing, L1)."""
    rows: list[dict] = []

    preprocessed = int((df["HAS_BEEN_PREPROCESSED"] == True).sum())  # noqa: E712
    not_preprocessed = len(df) - preprocessed
    if preprocessed:
        rows.append(
            {"Level": "Preprocessing", "Status": "Valid", "Count": preprocessed}
        )
    if not_preprocessed:
        rows.append(
            {"Level": "Preprocessing", "Status": "Pending", "Count": not_preprocessed}
        )

    if "SCHEMA_VALIDATION_ENABLED" in df.columns:
        sv = df[df["SCHEMA_VALIDATION_ENABLED"] == True]  # noqa: E712
    else:
        sv = df

    l1_valid = l1_invalid = l1_in_progress = l1_pending = 0
    for _, r in sv.iterrows():
        l1_complete = r.get("L1_COMPLETE")
        l1_passed = r.get("L1_PASSED")
        preprocessed_flag = r.get("HAS_BEEN_PREPROCESSED")

        if l1_complete is True and l1_passed is True:
            l1_valid += 1
        elif l1_complete is True and l1_passed is False:
            l1_invalid += 1
        elif preprocessed_flag is True:
            l1_in_progress += 1
        else:
            l1_pending += 1

    for status, count in [
        ("Valid", l1_valid),
        ("Invalid", l1_invalid),
        ("In progress", l1_in_progress),
        ("Pending", l1_pending),
    ]:
        if count:
            rows.append({"Level": "L1", "Status": status, "Count": count})

    return (
        pd.DataFrame(rows)
        if rows
        else pd.DataFrame(columns=["Level", "Status", "Count"])
    )


def _build_partition_chart_data(df: pd.DataFrame) -> pd.DataFrame:
    """Build long-form chart data for partition-level progress (L2, L3)."""
    rows: list[dict] = []

    for level, prefix in [("L2", "L2_PARTITIONS_"), ("L3", "L3_PARTITIONS_")]:
        for status, suffix in [
            ("Pending", "PENDING"),
            ("In progress", "IN_PROGRESS"),
            ("Waiting for eval", "WAITING_EVAL"),
            ("Valid", "VALID"),
            ("Invalid", "INVALID"),
            ("Execution error", "ERRORED"),
        ]:
            col = f"{prefix}{suffix}"
            if col in df.columns:
                total = int(df[col].sum())
                if total:
                    rows.append({"Level": level, "Status": status, "Count": total})

    return (
        pd.DataFrame(rows)
        if rows
        else pd.DataFrame(columns=["Level", "Status", "Count"])
    )


def _render_progress_chart(
    chart_data: pd.DataFrame,
    level_sort: list[str],
    height: int = 120,
) -> alt.Chart:
    """Create a horizontal stacked bar chart from long-form progress data."""
    domain = [s for s in _PROGRESS_STATUS_ORDER if s in chart_data["Status"].values]
    color_range = [_PROGRESS_STATUS_COLORS[s] for s in domain]

    return (
        alt.Chart(chart_data)
        .mark_bar()
        .encode(
            y=alt.Y("Level:N", sort=level_sort, axis=alt.Axis(title=None)),
            x=alt.X("Count:Q", title="Count"),
            color=alt.Color(
                "Status:N",
                scale=alt.Scale(domain=domain, range=color_range),
                legend=alt.Legend(title="Status"),
            ),
            order=alt.Order("order:Q"),
            tooltip=["Level:N", "Status:N", "Count:Q"],
        )
        .transform_calculate(order=f"indexof({domain!r}, datum.Status)")
        .properties(height=height)
    )


def _build_per_table_level_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Build a per-table summary of L1/L2/L3 validation status with partition progress."""
    rows: list[dict] = []
    for _, r in df.iterrows():
        sv_enabled = r.get("SCHEMA_VALIDATION_ENABLED", True)
        l1_complete = r.get("L1_COMPLETE")
        l1_passed = r.get("L1_PASSED")

        if sv_enabled is False:
            l1_status = "N/A"
        elif l1_complete is True and l1_passed is True:
            l1_status = "✅ Passed"
        elif l1_complete is True and l1_passed is False:
            l1_status = "❌ Failed"
        elif r.get("HAS_BEEN_PREPROCESSED") is True:
            l1_status = "🔵 In Progress"
        else:
            l1_status = "⏳ Pending"

        total = int(r.get("TOTAL_PARTITIONS") or 0)

        l2_valid = int(r.get("L2_PARTITIONS_VALID") or 0)
        l2_invalid = int(r.get("L2_PARTITIONS_INVALID") or 0)
        l2_errored = int(r.get("L2_PARTITIONS_ERRORED") or 0)
        l2_done = l2_valid + l2_invalid + l2_errored

        l3_valid = int(r.get("L3_PARTITIONS_VALID") or 0)
        l3_invalid = int(r.get("L3_PARTITIONS_INVALID") or 0)
        l3_errored = int(r.get("L3_PARTITIONS_ERRORED") or 0)
        l3_done = l3_valid + l3_invalid + l3_errored

        error_msg = r.get("EXAMPLE_ERROR_MESSAGE")
        warning_msg = r.get("EXAMPLE_WARNING_MESSAGE")

        rows.append(
            {
                "Table": r.get("SOURCE_IDENTIFIER", ""),
                "L1 (Schema)": l1_status,
                "L2 Completed": f"{l2_done} / {total}",
                "L2 Passed": l2_valid,
                "L2 Failed": l2_invalid + l2_errored,
                "L3 Completed": f"{l3_done} / {total}",
                "L3 Passed": l3_valid,
                "L3 Failed": l3_invalid + l3_errored,
                "Error": (
                    ""
                    if error_msg is None
                    or (isinstance(error_msg, float) and pd.isna(error_msg))
                    else str(error_msg)
                ),
                "Warning": (
                    ""
                    if warning_msg is None
                    or (isinstance(warning_msg, float) and pd.isna(warning_msg))
                    else str(warning_msg)
                ),
            }
        )

    cols = [
        "Table",
        "L1 (Schema)",
        "L2 Completed",
        "L2 Passed",
        "L2 Failed",
        "L3 Completed",
        "L3 Passed",
        "L3 Failed",
        "Error",
        "Warning",
    ]
    return pd.DataFrame(rows, columns=cols) if rows else pd.DataFrame(columns=cols)


with tab_tables:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing tables for **{selected_wf_str}**")

    table_df = get_table_progress_detail(selected_wf)

    if len(table_df) > 0:
        status_counts = table_df["VALIDATION_STATUS"].value_counts()

        cols = st.columns(5)
        with cols[0]:
            st.metric("Total tables", len(table_df))
        for i, s in enumerate(["COMPLETED", "IN_PROGRESS", "PENDING", "FAILED"]):
            with cols[i + 1]:
                cnt = int(status_counts.get(s, 0))
                color = {
                    "COMPLETED": "🟢",
                    "IN_PROGRESS": "🔵",
                    "PENDING": "⚪",
                    "FAILED": "🔴",
                }.get(s, "")
                st.metric(f"{color} {s.replace('_', ' ').title()}", cnt)

        search = st.text_input(
            "Search tables",
            placeholder="Filter by table name...",
            key="table_search",
            label_visibility="collapsed",
        )

        display = table_df
        if search:
            display = table_df[
                table_df["SOURCE_IDENTIFIER"].str.contains(search, case=False, na=False)
            ]

        # -- Progress bar charts (use filtered data) ---
        table_chart_data = _build_table_chart_data(display)
        partition_chart_data = _build_partition_chart_data(display)

        col_chart_left, col_chart_right = st.columns(2)
        with col_chart_left:
            st.markdown("**Per-table progress**")
            if len(table_chart_data) > 0:
                st.altair_chart(
                    _render_progress_chart(table_chart_data, ["Preprocessing", "L1"]),
                    use_container_width=True,
                )
            else:
                st.info("No table-level progress data yet.")
        with col_chart_right:
            st.markdown("**Per-partition progress**")
            if len(partition_chart_data) > 0:
                st.altair_chart(
                    _render_progress_chart(partition_chart_data, ["L2", "L3"]),
                    use_container_width=True,
                )
            else:
                st.info("No partition-level progress data yet.")

        st.caption(
            "**Pending** = not yet started. "
            "**In progress** = a worker is actively processing. "
            "**Waiting for eval** = results uploaded, waiting for evaluation. "
            "**Valid** = completed, data matches. "
            "**Invalid** = completed, data differs. "
            "**Execution error** = task failed, data status unknown. "
            "Partition-level progress (L2/L3) appears after preprocessing "
            "and L1 create the partition metadata."
        )

        # -- Per-table L1 / L2 / L3 granular summary --------------------------
        st.markdown("#### Per-table validation level status")
        level_summary = _build_per_table_level_summary(display)
        if len(level_summary) > 0:
            _dv_download_button(
                label="Download per-table summary as CSV",
                df=level_summary,
                tab_name="table_progress_summary",
                workflow_id=selected_wf,
                key="dv_download_table_progress_summary",
            )
            st.dataframe(level_summary, use_container_width=True)
            st.caption(
                "**L1 (Schema)**: pass/fail applies when schema validation is "
                "enabled; tables without it show N/A. "
                "**L2/L3 Completed**: partitions with a terminal status "
                "(valid, invalid, or errored) vs total partitions. "
                "**Passed**: partitions where data matches. "
                "**Failed**: partitions where data differs or execution errored."
            )
        else:
            st.info("No per-table data available.")

        # -- Full partition-level detail (expandable) --------------------------
        with st.expander("Detailed partition breakdown"):
            if len(display) > 0:
                fmt = display.copy()
                status_map = {
                    "COMPLETED": "🟢 Completed",
                    "IN_PROGRESS": "🔵 In Progress",
                    "PENDING": "⚪ Pending",
                    "FAILED": "🔴 Failed",
                }
                fmt["VALIDATION_STATUS"] = fmt["VALIDATION_STATUS"].map(
                    lambda v: status_map.get(v, v)
                )
                if "HAS_BEEN_PREPROCESSED" in fmt.columns:
                    fmt["PREPROCESSED"] = fmt["HAS_BEEN_PREPROCESSED"].apply(
                        lambda v: "Yes" if v is True else ("No" if v is False else "")
                    )
                for col, label in (
                    ("L1_COMPLETE", "L1 done"),
                    ("L1_PASSED", "L1 pass"),
                ):
                    if col in fmt.columns:
                        fmt[label] = fmt[col].apply(
                            lambda v: (
                                "N/A" if pd.isna(v) else ("Yes" if bool(v) else "No")
                            )
                        )

                _l2l3_renames = {
                    "L2_PARTITIONS_PENDING": "L2 pending",
                    "L2_PARTITIONS_IN_PROGRESS": "L2 in progress",
                    "L2_PARTITIONS_WAITING_EVAL": "L2 waiting eval",
                    "L2_PARTITIONS_VALID": "L2 valid",
                    "L2_PARTITIONS_INVALID": "L2 invalid",
                    "L2_PARTITIONS_ERRORED": "L2 errored",
                    "L3_PARTITIONS_PENDING": "L3 pending",
                    "L3_PARTITIONS_IN_PROGRESS": "L3 in progress",
                    "L3_PARTITIONS_WAITING_EVAL": "L3 waiting eval",
                    "L3_PARTITIONS_VALID": "L3 valid",
                    "L3_PARTITIONS_INVALID": "L3 invalid",
                    "L3_PARTITIONS_ERRORED": "L3 errored",
                }
                fmt = fmt.rename(
                    columns={k: v for k, v in _l2l3_renames.items() if k in fmt.columns}
                )

                column_order = [
                    "SOURCE_IDENTIFIER",
                    "TARGET_IDENTIFIER",
                    "VALIDATION_STATUS",
                    "PREPROCESSED",
                    "TOTAL_PARTITIONS",
                    "L1 done",
                    "L1 pass",
                    "L2 pending",
                    "L2 in progress",
                    "L2 waiting eval",
                    "L2 valid",
                    "L2 invalid",
                    "L2 errored",
                    "L3 pending",
                    "L3 in progress",
                    "L3 waiting eval",
                    "L3 valid",
                    "L3 invalid",
                    "L3 errored",
                    "EXAMPLE_ERROR_MESSAGE",
                    "EXAMPLE_WARNING_MESSAGE",
                ]
                column_order = [c for c in column_order if c in fmt.columns]
                st.dataframe(fmt[column_order], use_container_width=True)
                st.caption(
                    "L1 pass/fail applies when schema validation is enabled. "
                    "L2/L3 per-partition counts come from PARTITION_METADATA. "
                    "**Valid** = data matches; **Invalid** = data differs; "
                    "**Execution error** = task failed, data status unknown."
                )
            else:
                st.info("No tables match the current filter.")
    else:
        st.info(
            "No table progress available (run schema migrations if the detail view is missing)."
        )


# ===== ERROR LOGS ==========================================================
with tab_errors:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing errors for **{selected_wf_str}**")

    meta_for_filter = get_table_metadata(selected_wf)
    table_names = ["All tables"]
    if len(meta_for_filter) > 0 and "SOURCE_IDENTIFIER" in meta_for_filter.columns:
        unique_tables = meta_for_filter["SOURCE_IDENTIFIER"].dropna().unique().tolist()
        if unique_tables:
            table_names = table_names + sorted(unique_tables)

    selected_err_table = st.selectbox(
        "Filter by table",
        options=table_names,
        label_visibility="collapsed",
        key="dv_errors_table_filter",
    )

    error_df = get_data_validation_error_logs(selected_wf, selected_err_table)

    if len(error_df) > 0:
        st.caption(f"Showing {len(error_df):,} error records")

        _dv_download_button(
            label="Download errors as CSV",
            df=error_df,
            tab_name="errors",
            workflow_id=selected_wf,
            key="dv_download_errors",
        )

        flat_view = st.checkbox(
            "Show flat error list",
            value=True,
            key="dv_errors_flat_view",
            help="Toggle off to see errors grouped by table.",
        )

        if flat_view:
            st.dataframe(
                error_df,
                use_container_width=True,
            )
        else:
            error_by_table = error_df.groupby("TABLE_NAME", sort=False)
            ordered_tables = error_df["TABLE_NAME"].drop_duplicates().dropna().tolist()
            for table_name in ordered_tables:
                rows = error_by_table.get_group(table_name)
                latest_msg = str(rows.iloc[0].get("LAST_ERROR_MESSAGE") or "")
                preview = latest_msg[:120] + ("…" if len(latest_msg) > 120 else "")
                with st.expander(
                    f"**{table_name}** — {len(rows)} error(s) — {preview}",
                    expanded=False,
                ):
                    st.dataframe(rows, use_container_width=True)

        if st.checkbox("Show full error details", key="dv_errors_show_details"):
            for _idx, row in error_df.iterrows():
                part = row["PARTITION_NUMBER"]
                part_label = (
                    f"Partition {int(part)}"
                    if part is not None
                    and not (isinstance(part, float) and pd.isna(part))
                    else "Partition —"
                )
                tbl = row["TABLE_NAME"]
                tbl_s = (
                    "Unknown table"
                    if tbl is None or (isinstance(tbl, float) and pd.isna(tbl))
                    else str(tbl)
                )
                with st.expander(f"{tbl_s} — {part_label}"):
                    msg = row["LAST_ERROR_MESSAGE"]
                    st.code(
                        "" if msg is None or pd.isna(msg) else str(msg),
                        language=None,
                    )
                    warn = row.get("LAST_WARNING_MESSAGE")
                    if warn is not None and not (
                        isinstance(warn, float) and pd.isna(warn)
                    ):
                        st.warning(str(warn))
    else:
        st.success("No errors found for the current filters.")


# ===== TASKS (TASK_QUEUE) ==================================================
_TASK_STATUS_LABELS = (
    "All statuses",
    "Non-terminal (pending, executing, blocked)",
    "Completed",
    "Failed (failed or abandoned)",
    "Executing",
)
_TASK_STATUS_KEYS = ("all", "non_terminal", "completed", "failed", "executing")

if tab_tasks is not None:
    with tab_tasks:
        st.warning(
            "**Debug view.** Each **workflow** is broken down into **tasks**: one "
            "row here is one queued unit of work. This tab is intentionally "
            "detailed (payload, errors, timings). Users should prefer the "
            "**Tables** tab for status reporting."
        )

        if selected_wf is not None and selected_wf_str != "All workflows":
            st.info(f"Showing tasks for **{selected_wf_str}**")

        c1, c2 = st.columns(2)
        with c1:
            status_label = st.selectbox(
                "Task status",
                options=_TASK_STATUS_LABELS,
                index=0,
                key="dv_tasks_status_filter",
            )
        with c2:
            executor_options = ["All executor types"] + get_task_queue_executor_types(
                selected_wf
            )
            executor_label = st.selectbox(
                "Executor type",
                options=executor_options,
                index=0,
                key="dv_tasks_executor_filter",
            )

        status_key = dict(zip(_TASK_STATUS_LABELS, _TASK_STATUS_KEYS, strict=True))[
            status_label
        ]
        executor_arg = (
            None if executor_label == "All executor types" else executor_label
        )

        TASKS_PAGE_SIZE = 50
        total_tasks = get_task_queue_count(selected_wf, status_key, executor_arg)
        total_pages = max(1, math.ceil(total_tasks / TASKS_PAGE_SIZE))

        if "tasks_page" not in st.session_state:
            st.session_state["tasks_page"] = 1
        if st.session_state["tasks_page"] > total_pages:
            st.session_state["tasks_page"] = total_pages

        current_page = st.session_state["tasks_page"]
        offset = (current_page - 1) * TASKS_PAGE_SIZE

        task_df = get_task_queue(
            selected_wf,
            status_key,
            executor_arg,
            limit=TASKS_PAGE_SIZE,
            offset=offset,
        )

        if total_tasks > 0:
            row_start = offset + 1
            row_end = min(offset + TASKS_PAGE_SIZE, total_tasks)
            st.caption(f"Showing {row_start:,}–{row_end:,} of {total_tasks:,} task(s)")
            _dv_download_button(
                label="Download tasks (this page) as CSV",
                df=task_df,
                tab_name="tasks",
                workflow_id=selected_wf,
                key="dv_download_tasks",
            )
            st.dataframe(task_df, use_container_width=True)

            nav_prev, nav_info, nav_next = st.columns([1, 2, 1])
            with nav_prev:
                st.button(
                    "← Previous",
                    disabled=current_page <= 1,
                    key="tasks_prev",
                    on_click=lambda: st.session_state.update(
                        tasks_page=st.session_state["tasks_page"] - 1
                    ),
                )
            with nav_info:
                st.markdown(
                    f"<div style='text-align:center;padding-top:0.45rem'>"
                    f"Page <b>{current_page}</b> of <b>{total_pages}</b>"
                    f"</div>",
                    unsafe_allow_html=True,
                )
            with nav_next:
                st.button(
                    "Next →",
                    disabled=current_page >= total_pages,
                    key="tasks_next",
                    on_click=lambda: st.session_state.update(
                        tasks_page=st.session_state["tasks_page"] + 1
                    ),
                )
        else:
            st.info("No tasks match the current filters.")
else:
    # Advanced mode is off — expose task_df as an empty frame for snapshot.
    task_df = pd.DataFrame()


# ---- Global snapshot export ------------------------------------------------


def _dv_snapshot_sections() -> dict[str, pd.DataFrame]:
    sections: dict[str, pd.DataFrame] = {}
    if len(tables_summary_df) > 0:
        if len(aggregated_tables_df) > 0:
            sections["tables_aggregate"] = aggregated_tables_df
        sections["table_executions"] = tables_summary_df
    # Pull the on-screen dataframes that were already materialized; skip if empty.
    try:
        if len(error_df) > 0:
            sections["errors"] = error_df
    except NameError:
        pass
    try:
        if len(schema_summary_df) > 0:
            sections["schema_results"] = schema_summary_df
    except NameError:
        pass
    try:
        if len(metrics_summary_df) > 0:
            sections["metrics_results"] = metrics_summary_df
    except NameError:
        pass
    try:
        if len(row_summary_df) > 0:
            sections["row_summary"] = row_summary_df
    except NameError:
        pass
    # Cell validation is loaded on-demand; include the page currently on screen
    # (if the user has loaded it) so the snapshot is complete when exported.
    try:
        if len(cell_df) > 0:
            sections["cell_validation"] = cell_df
    except NameError:
        pass
    if advanced_mode and len(task_df) > 0:
        sections["task_queue"] = task_df
    return sections


with snapshot_slot.container():
    dv_sections = _dv_snapshot_sections()
    has_dv_data = any(len(df) > 0 for df in dv_sections.values())
    if has_dv_data:
        import base64 as _b64

        _snap_bytes = build_snapshot_csv(dv_sections)
        _snap_name = snapshot_filename(_FILENAME_PREFIX, workflow_id=selected_wf)
        _snap_b64 = _b64.b64encode(_snap_bytes).decode("ascii")
        st.markdown(
            f'<a href="data:text/csv;base64,{_snap_b64}" download="{_snap_name}" '
            'style="display:inline-block;padding:0.45rem 0.9rem;'
            "background-color:#ffeecc;border:1px solid #e0b265;"
            "border-radius:0.35rem;text-decoration:none;color:#0f1116;"
            'font-size:0.9rem;margin:0.2rem 0;" '
            "title=\"Download a multi-section CSV with every tab's data. "
            'Respects the current workflow and table-search filters.">'
            "📦 Export snapshot (CSV)</a>",
            unsafe_allow_html=True,
        )
    else:
        st.caption("No data in scope to export yet.")
