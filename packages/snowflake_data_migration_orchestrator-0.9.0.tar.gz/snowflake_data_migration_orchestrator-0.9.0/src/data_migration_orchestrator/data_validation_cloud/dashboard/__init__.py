"""Data Validation Dashboard module for Streamlit deployment."""

from data_migration_orchestrator.data_validation_cloud.dashboard.streamlit_deployer import (
    deploy_dv_streamlit_if_needed,
)


__all__ = ["deploy_dv_streamlit_if_needed"]
