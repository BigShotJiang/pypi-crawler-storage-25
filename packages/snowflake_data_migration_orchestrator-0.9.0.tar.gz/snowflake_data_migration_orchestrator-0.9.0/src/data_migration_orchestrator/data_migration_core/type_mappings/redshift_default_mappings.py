"""
Redshift to Snowflake data type mappings.

This module provides a comprehensive mapping from Amazon Redshift data types
to their equivalent Snowflake data types.

Reference:
- Redshift data types: https://docs.aws.amazon.com/redshift/latest/dg/c_Supported_data_types.html
- Snowflake data types: https://docs.snowflake.com/en/sql-reference/intro-summary-data-types
"""

# Comprehensive mapping of Redshift types to Snowflake types
# Keys are lowercase for case-insensitive lookup
REDSHIFT_TO_SNOWFLAKE_TYPE_MAPPINGS: dict[str, str] = {
    # Integer types
    "smallint": "NUMBER(5,0)",
    "int2": "NUMBER(5,0)",
    "integer": "NUMBER(10,0)",
    "int": "NUMBER(10,0)",
    "int4": "NUMBER(10,0)",
    "bigint": "NUMBER(19,0)",
    "int8": "NUMBER(19,0)",
    # Decimal/Numeric types (precision preserved in actual migration)
    "decimal": "NUMBER(20,10)",
    "numeric": "NUMBER(20,10)",
    # Floating point types
    "real": "FLOAT",
    "float4": "FLOAT",
    "double precision": "FLOAT",
    "float8": "FLOAT",
    "float": "FLOAT",
    # Character types
    "char": "VARCHAR",
    "character": "VARCHAR",
    "nchar": "VARCHAR",
    "bpchar": "VARCHAR",
    "varchar": "VARCHAR",
    "character varying": "VARCHAR",
    "nvarchar": "VARCHAR",
    "text": "VARCHAR",
    # Boolean type
    "boolean": "BOOLEAN",
    "bool": "BOOLEAN",
    # Date/Time types
    "date": "DATE",
    "timestamp": "TIMESTAMP_NTZ",
    "timestamp without time zone": "TIMESTAMP_NTZ",
    "timestamptz": "TIMESTAMP_TZ",
    "timestamp with time zone": "TIMESTAMP_TZ",
    "time": "TIME",
    "time without time zone": "TIME",
    # TIMETZ: preserve timezone by storing as TIMESTAMP_TZ (Snowflake has no TIME WITH TZ)
    "timetz": "TIMESTAMP_TZ",
    "time with time zone": "TIMESTAMP_TZ",
    # Interval types (Snowflake has no direct equivalent; store as text)
    # Aligned with snowflake-data-validation redshift_to_snowflake_datatypes_mapping_template.yaml
    "intervaly2m": "VARCHAR",
    "intervald2s": "VARCHAR",
    # Binary types
    "varbyte": "BINARY",
    "varbinary": "BINARY",
    "binary varying": "BINARY",
    # Semi-structured types
    "super": "VARIANT",
    # Redshift HLLSKETCH (hyperloglog); no Snowflake equivalent
    # Aligned with snowflake-data-validation: HLLSKETCH -> VARIANT
    "hllsketch": "VARIANT",
    # Geometric/Geographic types
    "geometry": "GEOMETRY",
    "geography": "GEOGRAPHY",
    # OID type (internal)
    "oid": "NUMBER(10,0)",
}


# Mapping of Redshift types to Snowflake Iceberg-compatible types
# Iceberg does not support VARIANT, OBJECT, or ARRAY; use VARCHAR instead
# Keys are lowercase for case-insensitive lookup
REDSHIFT_TO_SNOWFLAKE_ICEBERG_TYPE_MAPPINGS: dict[str, str] = {
    # Integer types
    "smallint": "NUMBER(5,0)",
    "int2": "NUMBER(5,0)",
    "integer": "NUMBER(10,0)",
    "int": "NUMBER(10,0)",
    "int4": "NUMBER(10,0)",
    "bigint": "NUMBER(19,0)",
    "int8": "NUMBER(19,0)",
    # Decimal/Numeric types (precision preserved in actual migration)
    "decimal": "NUMBER(20,10)",
    "numeric": "NUMBER(20,10)",
    # Floating point types
    "real": "FLOAT",
    "float4": "FLOAT",
    "double precision": "FLOAT",
    "float8": "FLOAT",
    "float": "FLOAT",
    # Character types
    "char": "VARCHAR",
    "character": "VARCHAR",
    "nchar": "VARCHAR",
    "bpchar": "VARCHAR",
    "varchar": "VARCHAR",
    "character varying": "VARCHAR",
    "nvarchar": "VARCHAR",
    "text": "VARCHAR",
    # Boolean type
    "boolean": "BOOLEAN",
    "bool": "BOOLEAN",
    # Date/Time types
    "date": "DATE",
    "timestamp": "TIMESTAMP_NTZ",
    "timestamp without time zone": "TIMESTAMP_NTZ",
    "timestamptz": "TIMESTAMP_TZ",
    "timestamp with time zone": "TIMESTAMP_TZ",
    "time": "TIME",
    "time without time zone": "TIME",
    # TIMETZ: preserve timezone by storing as TIMESTAMP_TZ (Snowflake has no TIME WITH TZ)
    "timetz": "TIMESTAMP_TZ",
    "time with time zone": "TIMESTAMP_TZ",
    # Interval types (Snowflake has no direct equivalent; store as text)
    "intervaly2m": "VARCHAR",
    "intervald2s": "VARCHAR",
    # Binary types
    "varbyte": "BINARY",
    "varbinary": "BINARY",
    "binary varying": "BINARY",
    # Semi-structured types (Iceberg does not support VARIANT; use VARCHAR)
    "super": "VARCHAR",
    # Redshift HLLSKETCH; Iceberg does not support VARIANT; use VARCHAR
    "hllsketch": "VARCHAR",
    # Geometric/Geographic types
    "geometry": "GEOMETRY",
    "geography": "GEOGRAPHY",
    # OID type (internal)
    "oid": "NUMBER(10,0)",
}


def get_snowflake_type(
    redshift_type: str,
    precision: int | None = None,
    scale: int | None = None,
    length: int | None = None,
) -> str:
    """
    Get the Snowflake equivalent type for a Redshift type.

    This function provides more precise mapping when precision/scale/length
    are known from the source schema.

    Args:
        redshift_type: Redshift data type name
        precision: Numeric precision (for DECIMAL/NUMERIC)
        scale: Numeric scale (for DECIMAL/NUMERIC)
        length: Character length (for CHAR/VARCHAR)

    Returns:
        Snowflake data type string

    """
    normalized = redshift_type.lower().strip()

    # Handle parameterized types
    if normalized in ("decimal", "numeric") and precision is not None:
        actual_scale = scale if scale is not None else 0
        return f"NUMBER({precision},{actual_scale})"

    if normalized in ("char", "character", "nchar", "bpchar") and length is not None:
        return f"CHAR({length})"

    if (
        normalized in ("varchar", "character varying", "nvarchar")
        and length is not None
    ):
        return f"VARCHAR({length})"

    if normalized in ("varbyte", "varbinary", "binary varying") and length is not None:
        return f"BINARY({length})"

    # Fall back to default mapping
    return REDSHIFT_TO_SNOWFLAKE_TYPE_MAPPINGS.get(normalized, "VARCHAR")
