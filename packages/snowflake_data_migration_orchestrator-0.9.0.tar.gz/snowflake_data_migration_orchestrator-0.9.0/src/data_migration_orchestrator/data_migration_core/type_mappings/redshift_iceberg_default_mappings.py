"""
Redshift Iceberg (Glue Data Catalog) to Snowflake data type mappings.

This module provides a mapping from Apache Iceberg / AWS Glue Data Catalog
data types to their equivalent Snowflake data types. These types are
encountered when migrating Redshift tables that use the Iceberg table format
backed by the AWS Glue Data Catalog.

Reference:
- Iceberg types: https://iceberg.apache.org/spec/#schemas-and-data-types
- Glue Data Catalog: https://docs.aws.amazon.com/glue/latest/dg/aws-glue-api-catalog-tables.html
- Snowflake data types: https://docs.snowflake.com/en/sql-reference/intro-summary-data-types
"""

# Comprehensive mapping of Iceberg/Glue types to Snowflake types
# Keys are lowercase for case-insensitive lookup
REDSHIFT_ICEBERG_TO_SNOWFLAKE_TYPE_MAPPINGS: dict[str, str] = {
    # Boolean type
    "boolean": "BOOLEAN",
    # Integer types
    "int": "NUMBER(10,0)",
    "integer": "NUMBER(10,0)",
    "bigint": "NUMBER(19,0)",
    "long": "NUMBER(19,0)",
    # Floating point types
    "float": "FLOAT",
    "double": "DOUBLE",
    # Decimal/Numeric types (precision preserved in actual migration)
    "decimal": "DECIMAL",
    # Character types
    "string": "VARCHAR",
    # Binary types
    "binary": "BINARY",
    "fixed": "BINARY",
    # Date/Time types
    "date": "DATE",
    "timestamp": "TIMESTAMP_NTZ",
    "timestamptz": "TIMESTAMP_LTZ",
    "timestamp with time zone": "TIMESTAMP_LTZ",
    # UUID type (stored as fixed-length string)
    "uuid": "VARCHAR(36)",
    # Complex types (no direct Snowflake equivalent; store as text)
    "list": "VARCHAR",
    "map": "VARCHAR",
    "struct": "VARCHAR",
    "array": "VARCHAR",
}
