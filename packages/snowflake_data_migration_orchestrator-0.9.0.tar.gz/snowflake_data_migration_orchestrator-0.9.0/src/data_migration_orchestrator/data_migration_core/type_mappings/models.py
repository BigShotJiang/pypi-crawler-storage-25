"""Data models for type mappings."""

from dataclasses import dataclass
from enum import StrEnum

from shared.enums.source_type import SourceType


class TypeMappingCategory(StrEnum):
    """
    Canonical categories for grouping similar data types.

    These categories help organize types by their semantic meaning,
    regardless of the source database system.
    """

    BINARY = "Binary"
    CHARACTER = "Character"
    NCHARACTER = "NCharacter"
    DATE = "Date"
    DATETIME = "Datetime"
    TIME = "Time"
    TIMESTAMP = "Timestamp"
    FLOAT = "Float"
    LOGICAL = "Logical"
    NUMERIC = "Numeric"
    VARIANT = "Variant"  # JSON, XML, semi-structured
    GEOGRAPHY = "Geography"  # Geospatial types
    OTHER = "Other"


@dataclass(frozen=True)
class TypeMapping:
    """
    Represents a single type mapping from source to Snowflake.

    Attributes:
        source_type: The source database type name (e.g., "VARCHAR", "INT")
        snowflake_type: The corresponding Snowflake type (e.g., "VARCHAR", "NUMBER")
        category: The semantic category this type belongs to
        is_lob: Whether this is a Large Object (LOB) type
        notes: Optional notes about the mapping (e.g., precision handling)

    """

    source_type: str
    snowflake_type: str
    category: TypeMappingCategory
    is_lob: bool = False
    notes: str | None = None

    def __post_init__(self):
        """Validate and normalize the type mapping."""
        # Normalize source type to uppercase for consistency
        object.__setattr__(self, "source_type", self.source_type.upper())
        object.__setattr__(self, "snowflake_type", self.snowflake_type.upper())

    def __str__(self) -> str:
        """Return a human-readable representation."""
        lob_marker = " (LOB)" if self.is_lob else ""
        return (
            f"{self.source_type} -> {self.snowflake_type} [{self.category}]{lob_marker}"
        )


@dataclass
class SourceTypeInfo:
    """
    Information about a source database type system.

    Attributes:
        source_system: Name of the source database system (e.g., "sqlserver", "postgresql")
        mappings: Dictionary of source types to TypeMapping objects
        version: Optional version information for the mapping set

    """

    source_system: SourceType
    mappings: dict[str, TypeMapping]
    version: str = "1.0"

    def get_mapping(self, source_type: str) -> TypeMapping | None:
        """
        Get the type mapping for a source type.

        Args:
            source_type: The source database type name (case-insensitive)

        Returns:
            TypeMapping object if found, None otherwise

        """
        return self.mappings.get(source_type.upper())

    def get_snowflake_type(self, source_type: str) -> str | None:
        """
        Get the Snowflake type for a source type.

        Args:
            source_type: The source database type name (case-insensitive)

        Returns:
            Snowflake type name if mapping found, None otherwise

        """
        mapping = self.get_mapping(source_type)
        return mapping.snowflake_type if mapping else None

    def list_all_source_types(self) -> list[str]:
        """
        Get a list of all supported source types.

        Returns:
            Sorted list of source type names

        """
        return sorted(self.mappings.keys())

    def list_by_category(self, category: TypeMappingCategory) -> list[TypeMapping]:
        """
        Get all type mappings in a specific category.

        Args:
            category: The category to filter by

        Returns:
            List of TypeMapping objects in the specified category

        """
        return [m for m in self.mappings.values() if m.category == category]
