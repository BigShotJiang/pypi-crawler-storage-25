"""
Type mappings for data migration between source databases and Snowflake.

This module provides a comprehensive type mapping system that:
- Maps source database types to Snowflake types via hardcoded defaults
- Supports multiple source database systems (SQL Server, PostgreSQL, Oracle, etc.)
- Provides metadata about types (LOB types, rollup categories)
- Allows custom user overrides via configuration files (YAML, future: JSON)

Default mappings are hardcoded in Python for performance and based on
the snowflake-data-validation project.

Usage:
    from data_migration_orchestrator.type_mappings import TypeMappingLoader

    # Load default mappings for SQL Server
    loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)
    snowflake_type = loader.get_snowflake_type("VARCHAR")
    # Returns: "VARCHAR"

    # Load with custom overrides
    loader = TypeMappingLoader(
        source_type=SourceType.SQLSERVER,
        custom_mappings_file="my_overrides.yaml"
    )

    # Get all mappings as dictionary
    all_mappings = loader.get_all_mappings()
"""

from data_migration_orchestrator.data_migration_core.type_mappings.default_mappings import (
    DEFAULT_TYPE_MAPPINGS,
    get_default_mappings,
)
from data_migration_orchestrator.data_migration_core.type_mappings.models import (
    TypeMapping,
    TypeMappingCategory,
)
from data_migration_orchestrator.data_migration_core.type_mappings.sqlserver_default_mappings import (
    SQLSERVER_TO_SNOWFLAKE_TYPES,
)


__all__ = [
    "TypeMapping",
    "TypeMappingCategory",
    "DEFAULT_TYPE_MAPPINGS",
    "get_default_mappings",
    "SQLSERVER_TO_SNOWFLAKE_TYPES",
]
