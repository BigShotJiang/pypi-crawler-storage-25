"""
Shared column-name constants for query results.

These constants define the canonical column names used in metadata and schema
query results across all platforms. They are referenced by query builders,
stage readers, and other modules that consume query output.
"""

# Column names for schema query results
COLUMN_NAME = "column_name"
DATA_TYPE = "data_type"
MAX_LENGTH = "max_length"
NUMERIC_PRECISION_COL = "precision"
NUMERIC_SCALE_COL = "scale"
IS_NULLABLE_COL = "is_nullable"
ORDINAL_POSITION_COL = "ordinal_position"
