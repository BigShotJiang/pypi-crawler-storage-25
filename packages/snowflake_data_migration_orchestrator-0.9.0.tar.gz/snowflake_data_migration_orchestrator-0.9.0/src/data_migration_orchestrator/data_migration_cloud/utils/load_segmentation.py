"""Utilities for splitting staged files into COPY INTO segments."""

from __future__ import annotations

from dataclasses import dataclass, field

from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    StageFile,
)


SNOWFLAKE_FILES_PARAM_LIMIT = 1000
"""Maximum number of file names accepted by a single Snowflake FILES clause."""


@dataclass(frozen=True)
class LoadSegment:
    """A group of files to be loaded in a single COPY INTO statement."""

    files: list[str] = field(default_factory=list)
    """Relative file names for the ``FILES`` parameter."""

    total_size_bytes: int = 0
    """Sum of the individual file sizes in bytes."""


def compute_segments(
    stage_files: list[StageFile],
    target_segment_size_bytes: int,
) -> list[LoadSegment]:
    """
    Partition *stage_files* into segments for parallel COPY INTO execution.

    Files are assigned greedily in order: each file is added to the current
    segment until adding it would exceed *target_segment_size_bytes* **or**
    the Snowflake ``FILES`` parameter limit (1 000 files).  A file that is
    larger than the target size is placed in its own segment.

    Args:
        stage_files: Files returned by :func:`list_stage_files`, assumed
            already sorted by name.
        target_segment_size_bytes: Target cumulative size per segment.

    Returns:
        A non-empty list of ``LoadSegment`` instances.  When *stage_files*
        is empty an empty list is returned.

    """
    if not stage_files:
        return []

    segments: list[LoadSegment] = []
    current_files: list[str] = []
    current_size = 0

    for sf in stage_files:
        would_exceed_size = (
            current_files and current_size + sf.size_bytes > target_segment_size_bytes
        )
        would_exceed_count = len(current_files) >= SNOWFLAKE_FILES_PARAM_LIMIT

        if would_exceed_size or would_exceed_count:
            segments.append(
                LoadSegment(files=current_files, total_size_bytes=current_size)
            )
            current_files = []
            current_size = 0

        current_files.append(sf.name)
        current_size += sf.size_bytes

    if current_files:
        segments.append(LoadSegment(files=current_files, total_size_bytes=current_size))

    return segments
