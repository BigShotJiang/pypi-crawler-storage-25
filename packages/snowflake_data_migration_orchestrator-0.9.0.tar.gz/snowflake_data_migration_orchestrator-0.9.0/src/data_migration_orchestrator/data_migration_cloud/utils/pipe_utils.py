"""Utilities for building Snowpipe identifiers used by the data migration workflow."""

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableConfiguration,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    resolve_stage_for_strategy,
)
from data_migration_orchestrator.utils.snowflake_metadata import qualified_temp_schema


def build_pipe_name(workflow_id: int, target_table: str) -> str:
    """
    Build a deterministic, case-normalized pipe name from workflow ID and target table.

    The returned identifier is upper-cased so it matches how Snowflake stores
    unquoted identifiers (in the catalog and in the event table's
    ``snow.pipe.name``). This lets the orchestrator's event-table monitoring
    match rows by short name without case-sensitivity gotchas.

    Args:
        workflow_id: The workflow ID.
        target_table: Fully-qualified or partially-qualified target table
            identifier (e.g. ``db.schema.table`` or ``schema.table``).

    Returns:
        Fully-qualified pipe name in the TEMP schema, upper-cased
        (e.g. ``SNOWCONVERT_AI.TEMP.DMO_PIPE_1_BASIC``).

    """
    parts = target_table.split(".")
    if len(parts) == 3:
        _db, _schema, table = parts
        safe_table = table.replace('"', "").replace("'", "")
    else:
        safe_table = target_table.replace(".", "_").replace('"', "").replace("'", "")
    return f"{qualified_temp_schema()}.DMO_PIPE_{workflow_id}_{safe_table}".upper()


def build_snowpipe_stage_path(
    table_config: TableConfiguration,
    workflow_id: int,
    table_metadata_id: int,
) -> str:
    """
    Build the stage path used in CREATE PIPE for a table.

    Returns the table-level ``data/`` parent so any per-partition
    ``ALTER PIPE ... REFRESH PREFIX=<partition path>`` matches.

    The path must be a stage prefix that *contains* every partition location
    where the extraction will land files. Partition paths are constructed by
    ``stage_path_for_partition_data`` / ``build_external_stage_data_path`` as
    ``{stage_id}[/{external_base}]/task_results/workflows/{wf}/tables/{tid}/data/{partition}/``.

    For UNLOAD extraction the stage resolves to the external S3 stage; for
    other strategies it resolves to the default internal stage.
    """
    stage_resolution = resolve_stage_for_strategy(
        table_config.extraction_strategy,
        strategy_config=None,
        workflow_external_stage=None,
        table_external_stage=table_config.extraction.external_stage,
    )

    base_parts = [stage_resolution.stage_id.rstrip("/")]
    if stage_resolution.external_stage_base_path:
        base_parts.append(stage_resolution.external_stage_base_path.strip("/"))
    base_parts.append(
        f"task_results/workflows/{workflow_id}/tables/{table_metadata_id}/data"
    )
    return "/".join(base_parts) + "/"
