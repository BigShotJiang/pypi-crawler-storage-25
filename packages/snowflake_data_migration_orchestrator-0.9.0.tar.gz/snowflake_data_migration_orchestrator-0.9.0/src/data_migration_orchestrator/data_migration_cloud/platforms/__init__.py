"""
Source platform abstractions and registry.

This package provides the extensible platform architecture for supporting
multiple source database systems in data migration workflows.

Public API:
    BasePlatform: Abstract base class for source platforms
    BaseQueryBuilder: Abstract base class for platform-specific SQL generation
    PlatformRegistry: Registry for platform implementations
    PostgresqlPlatform: PostgreSQL platform implementation
    PostgresqlQueryBuilder: PostgreSQL-specific query builder
    RedshiftPlatform: Amazon Redshift platform implementation
    RedshiftQueryBuilder: Redshift-specific query builder
    SqlServerPlatform: Microsoft SQL Server platform implementation
    SqlServerQueryBuilder: SQL Server-specific query builder
"""

from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.platforms.postgresql.platform import (
    PostgresqlPlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.postgresql.query_builder import (
    PostgresqlQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.redshift.platform import (
    RedshiftPlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.redshift.query_builder import (
    RedshiftQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.platform import (
    SqlServerPlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.query_builder import (
    SqlServerQueryBuilder,
)
from shared.enums.source_type import SourceType


# Register Redshift platform
PlatformRegistry.register("redshift", RedshiftPlatform)

# Register Redshift aliases
PlatformRegistry.register_alias("aws-redshift", SourceType.REDSHIFT)
PlatformRegistry.register_alias("amazon-redshift", SourceType.REDSHIFT)

# Register SQL Server platform
PlatformRegistry.register("sqlserver", SqlServerPlatform)

# Register SQL Server aliases
PlatformRegistry.register_alias("mssql", SourceType.SQLSERVER)
PlatformRegistry.register_alias("sql-server", SourceType.SQLSERVER)
PlatformRegistry.register_alias("microsoft-sql-server", SourceType.SQLSERVER)

# Register PostgreSQL platform
PlatformRegistry.register("postgresql", PostgresqlPlatform)

# Register PostgreSQL aliases
PlatformRegistry.register_alias("postgres", SourceType.POSTGRESQL)
PlatformRegistry.register_alias("pg", SourceType.POSTGRESQL)

__all__ = [
    "BasePlatform",
    "BaseQueryBuilder",
    "PlatformRegistry",
    "PostgresqlPlatform",
    "PostgresqlQueryBuilder",
    "RedshiftPlatform",
    "RedshiftQueryBuilder",
    "SqlServerPlatform",
    "SqlServerQueryBuilder",
]
