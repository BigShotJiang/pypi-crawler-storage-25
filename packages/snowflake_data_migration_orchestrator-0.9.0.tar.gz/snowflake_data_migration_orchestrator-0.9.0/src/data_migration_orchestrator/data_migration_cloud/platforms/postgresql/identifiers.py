"""
PostgreSQL identifier normalization and quoting.

PostgreSQL folds unquoted identifiers to lowercase and uses double-quote
notation for identifiers that need quoting.
"""

from __future__ import annotations

import re


# Valid unquoted PostgreSQL identifiers: letter or underscore followed by
# letters, digits, underscores, or dollar signs.
_VALID_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_$]*$")


def is_already_quoted(identifier: str) -> bool:
    """Check if an identifier is already double-quoted."""
    return identifier.startswith('"') and identifier.endswith('"')


def needs_quoting(identifier: str) -> bool:
    """
    Check if a PostgreSQL identifier needs to be quoted.

    An identifier needs quoting if it doesn't match the valid pattern
    (letter/underscore followed by letters/digits/underscores/$).
    Reserved words are *not* automatically quoted.
    """
    if not identifier:
        return True
    if is_already_quoted(identifier):
        return False
    return not _VALID_IDENTIFIER_PATTERN.match(identifier)


def quote_identifier_if_needed(identifier: str) -> str:
    """
    Quote an identifier with double quotes only when necessary.

    Already-quoted identifiers and identifiers matching the valid pattern
    are returned unchanged.
    """
    if not identifier:
        return '""'
    if is_already_quoted(identifier):
        return identifier
    if not needs_quoting(identifier):
        return identifier
    escaped = identifier.replace('"', '""')
    return f'"{escaped}"'


def normalize_identifier_postgresql(identifier: str) -> str:
    """
    Normalize an identifier for PostgreSQL.

    PostgreSQL folds unquoted identifiers to lowercase.  Identifiers that
    require quoting (special characters, leading digit, etc.) preserve
    their original case.
    """
    possibly_quoted = quote_identifier_if_needed(identifier)
    if is_already_quoted(possibly_quoted):
        return possibly_quoted
    return possibly_quoted.lower()
