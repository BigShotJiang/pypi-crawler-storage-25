"""
PostgreSQL platform implementation.

This module provides the PostgresqlPlatform class that defines PostgreSQL-specific
behavior for data migration workflows.
"""

from functools import cached_property

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.postgresql.query_builder import (
    PostgresqlQueryBuilder,
)
from data_migration_orchestrator.data_migration_core.type_mappings.postgresql_default_mappings import (
    POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS,
)
from shared.enums.source_type import SourceType


class PostgresqlPlatform(BasePlatform):
    """
    Platform implementation for PostgreSQL.

    Supports extraction via ODBC (REGULAR) strategy. PostgreSQL does not have
    a native bulk export command like Redshift's UNLOAD, so ODBC is the
    primary extraction method.
    """

    @property
    def name(self) -> SourceType:
        """Return the canonical platform name."""
        return SourceType.POSTGRESQL

    @property
    def display_name(self) -> str:
        """Return a human-readable platform name."""
        return "PostgreSQL"

    @property
    def aliases(self) -> list[str]:
        """Return common aliases for this platform."""
        return ["postgres", "pg", "postgresql"]

    @property
    def default_strategy(self) -> ExtractionStrategy:
        """Return the default extraction strategy."""
        return ExtractionStrategy.REGULAR

    @property
    def supported_strategies(self) -> list[ExtractionStrategy]:
        """Return all supported extraction strategies."""
        return [ExtractionStrategy.REGULAR]

    @cached_property
    def query_builder(self) -> BaseQueryBuilder:
        """Return the PostgreSQL query builder instance."""
        return PostgresqlQueryBuilder()

    @property
    def type_mappings(self) -> dict[str, str]:
        """Return PostgreSQL to Snowflake type mappings."""
        return POSTGRESQL_TO_SNOWFLAKE_TYPE_MAPPINGS

    def get_type_mapping(self, source_type: str) -> str | None:
        """
        Get the Snowflake type for a PostgreSQL type.

        Args:
            source_type: PostgreSQL data type name

        Returns:
            Corresponding Snowflake type or None if not mapped

        """
        # Normalize to lowercase for lookup
        normalized = source_type.lower().strip()
        return self.type_mappings.get(normalized)
