"""
Amazon Redshift identifier normalization and quoting.

Redshift follows PostgreSQL conventions: unquoted identifiers are folded to
lowercase, and double-quote notation is used for quoting.
"""

from __future__ import annotations

import re


# Valid unquoted Redshift identifiers: letter or underscore followed by
# letters, digits, underscores, or dollar signs.
_VALID_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_$]*$")


def is_already_quoted(identifier: str) -> bool:
    """Check if an identifier is already double-quoted."""
    return identifier.startswith('"') and identifier.endswith('"')


def needs_quoting(identifier: str) -> bool:
    """
    Check if a Redshift identifier needs to be quoted.

    An identifier needs quoting if it doesn't match the valid pattern
    (letter/underscore followed by letters/digits/underscores/$).
    Reserved words are *not* automatically quoted.
    """
    if not identifier:
        return True
    if is_already_quoted(identifier):
        return False
    return not _VALID_IDENTIFIER_PATTERN.match(identifier)


def quote_identifier_if_needed(identifier: str) -> str:
    """
    Quote an identifier with double quotes only when necessary.

    Already-quoted identifiers and identifiers matching the valid pattern
    are returned unchanged.
    """
    if not identifier:
        return '""'
    if is_already_quoted(identifier):
        return identifier
    if not needs_quoting(identifier):
        return identifier
    escaped = identifier.replace('"', '""')
    return f'"{escaped}"'


def normalize_identifier_redshift(identifier: str) -> str:
    """
    Normalize an identifier for Redshift.

    Redshift folds unquoted identifiers to lowercase.  Identifiers that
    require quoting (special characters, leading digit, etc.) preserve
    their original case.
    """
    possibly_quoted = quote_identifier_if_needed(identifier)
    if is_already_quoted(possibly_quoted):
        return possibly_quoted
    return possibly_quoted.lower()


def is_bracket_delimited(identifier: str) -> bool:
    """Return whether *identifier* uses SQL Server-style square brackets."""
    if not identifier:
        return False
    return identifier.startswith("[") and identifier.endswith("]")


def redshift_catalog_string_value(identifier: str) -> str:
    """
    Return the catalog string for Redshift system-view predicates.

    Use this in predicates against SVV_TABLE_INFO, information_schema, and
    similar views where catalog columns store unquoted SQL identifiers
    lowercased.

    If the configured name is delimited (double quotes or square brackets),
    delimiters are stripped and the inner spelling is preserved. Otherwise
    the value is lowercased.
    """
    if not identifier:
        return identifier
    s = identifier.strip()
    if not s:
        return s
    if is_already_quoted(s):
        return s[1:-1].replace('""', '"')
    if is_bracket_delimited(s):
        return s[1:-1]
    return s.lower()
