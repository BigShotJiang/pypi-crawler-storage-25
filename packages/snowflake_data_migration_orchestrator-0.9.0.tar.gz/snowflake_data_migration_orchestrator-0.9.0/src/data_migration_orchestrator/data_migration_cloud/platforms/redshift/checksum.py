"""
Redshift checksum query generation.

Builds partition-level checksum queries using CRC32 intermediate hashing,
farmFingerprint64, and AVG aggregation.  All functions are stateless; the
only dependency on the query builder is a ``quote_identifier`` callable
passed in by the caller.

Algorithm (per the DMVA reference ``system_redshift.get_checksum_values``):
    1. Charamelize each column (cast to VARCHAR representation).
    2. Apply ``crc32()`` to each charamerized column.
    3. Concatenate CRC32 results with ``||``.
    4. Apply ``farmFingerprint64()`` on the concatenation (returns BIGINT).
    5. Cast to ``DECIMAL(38,0)``.
    6. ``AVG()`` across all rows in the partition.
    7. Cast to VARCHAR for the final checksum string.

Note on aggregation choice:
    AVG is used instead of SUM because ``farmFingerprint64`` returns a
    BIGINT and ``SUM(BIGINT)`` in Redshift returns BIGINT, which can
    overflow with as few as two rows.  AVG is inherently bounded by the
    input range and is therefore overflow-safe regardless of table size.

    Future improvement: consider switching to SUM with bucket slicing
    (splitting the 8-byte BIGINT into 2x4-byte buckets summed as
    ``DECIMAL(38,0)``), mirroring the SQL Server pattern for
    finer-grained change detection while remaining overflow-safe.
"""

from __future__ import annotations

from collections.abc import Callable

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    NULL_TOKEN,
    ColumnInfo,
    PartitionInfo,
)


logger = get_logger("platforms.redshift.checksum")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_NUMERIC_PRECISION = 38

_CHARACTER_TYPES = frozenset(
    {
        "char",
        "character",
        "nchar",
        "bpchar",
        "varchar",
        "character varying",
        "nvarchar",
        "text",
    }
)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def build_redshift_checksum_query(
    *,
    partition_info: PartitionInfo,
    source_table_id: TableIdentifier,
    columns: list[ColumnInfo],
    quote_identifier_fn: Callable[[str], str],
    where_clause: str,
) -> str:
    """
    Build a Redshift checksum query using CRC32 + farmFingerprint64 + AVG.

    The query:
    1. Charamerizes each column (cast to VARCHAR)
    2. Applies ``crc32()`` to each charamerized column
    3. Concatenates all CRC32 results with ``||``
    4. Computes ``farmFingerprint64(...)`` for each row
    5. Casts to ``DECIMAL(38,0)``
    6. AVGs across all rows in the partition

    Args:
        partition_info: Partition boundaries and table info.
        source_table_id: Source table identifier.
        columns: Column metadata list.
        quote_identifier_fn: Platform-specific identifier quoting callable.
        where_clause: Pre-built partition boundary condition (without WHERE keyword).

    Returns:
        SQL query that computes the partition checksum.

    """
    if not columns:
        logger.warning(
            f"No columns for {source_table_id.fully_qualified_friendly_name}, "
            "falling back to COUNT(*)"
        )
        return _build_count_only_query(
            partition_info, quote_identifier_fn, where_clause
        )

    column_expressions = _build_column_expressions(columns, quote_identifier_fn)
    hashed_columns_expr = _build_hashed_columns_expression(column_expressions)
    checksum_select = _build_checksum_aggregation()
    table_ref = _build_fqn(partition_info, quote_identifier_fn)

    return f"""SELECT
    {checksum_select} AS checksum
FROM (
    SELECT {hashed_columns_expr} AS hashed_columns
    FROM {table_ref}
    WHERE {where_clause}
) t"""


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------
def _build_fqn(
    partition_info: PartitionInfo,
    quote_identifier_fn: Callable[[str], str],
) -> str:
    return (
        f"{quote_identifier_fn(partition_info.database)}."
        f"{quote_identifier_fn(partition_info.schema)}."
        f"{quote_identifier_fn(partition_info.table_name)}"
    )


def _build_column_expressions(
    columns: list[ColumnInfo],
    quote_identifier_fn: Callable[[str], str],
) -> list[str]:
    """Build CRC32-wrapped column expressions for each column."""
    expressions = []
    for col in columns:
        char_expr = _charamelize(col, quote_identifier_fn)
        crc_expr = f"crc32({char_expr})"
        if col.is_nullable:
            crc_expr = f"COALESCE({crc_expr}, '{NULL_TOKEN}')"
        expressions.append(crc_expr)
    return expressions


def _build_hashed_columns_expression(column_expressions: list[str]) -> str:
    """Build the farmFingerprint64 expression over concatenated CRC32 values."""
    concatenated = " || ".join(column_expressions)
    return f"CAST(farmFingerprint64({concatenated}) AS DECIMAL({_NUMERIC_PRECISION},0))"


def _build_checksum_aggregation() -> str:
    """Build the AVG-based aggregation expression."""
    return "CAST(COALESCE(AVG(hashed_columns), 0) AS VARCHAR(40))"


def _charamelize(
    column: ColumnInfo,
    quote_identifier_fn: Callable[[str], str],
) -> str:
    """Convert a column to character representation for CRC32 hashing."""
    col_ref = quote_identifier_fn(column.column_name)
    data_type = column.data_type.lower()

    match data_type:
        case "super":
            return f"JSON_SERIALIZE({col_ref})"

        case "timetz" | "time with time zone":
            return f"CAST({col_ref} AS VARCHAR)"

        case "boolean" | "bool":
            return (
                f"CASE {col_ref} "
                f"WHEN true THEN 'TRUE' "
                f"WHEN false THEN 'FALSE' "
                f"ELSE NULL END"
            )

        case "varbyte" | "varbinary" | "binary varying":
            return f"RIGHT(CAST({col_ref} AS VARCHAR), -2)"

        case _ if data_type in _CHARACTER_TYPES:
            return col_ref

        case _:
            return f"CAST({col_ref} AS VARCHAR)"


def _build_count_only_query(
    partition_info: PartitionInfo,
    quote_identifier_fn: Callable[[str], str],
    where_clause: str,
) -> str:
    """Fallback query returning only COUNT when no columns are available."""
    table_ref = _build_fqn(partition_info, quote_identifier_fn)

    return f"""SELECT
    CAST(COUNT(*) AS VARCHAR(40)) AS checksum
FROM {table_ref}
WHERE {where_clause}"""
