"""
SQL Server identifier parsing, normalization, quoting, and unquoting.

Handles SQL Server-specific identifier conventions:
- Bracket notation: [schema].[table]
- Double-quote notation: "schema"."table"
- Case-insensitive unquoted identifiers normalized to uppercase
"""

from __future__ import annotations

import re

from data_migration_orchestrator.utils.table_name_parts import TableNameParts


# Valid SQL Server identifiers (no quoting needed):
# starts with a letter or underscore, followed by letters/digits/underscores.
_VALID_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def is_already_quoted(identifier: str) -> bool:
    """
    Check if an identifier is already quoted for SQL Server.

    SQL Server accepts both bracket notation ``[name]`` and double quotes
    ``"name"``.
    """
    return (identifier.startswith("[") and identifier.endswith("]")) or (
        identifier.startswith('"') and identifier.endswith('"')
    )


def needs_quoting(identifier: str) -> bool:
    """
    Check if a SQL Server identifier needs to be quoted.

    An identifier needs quoting if it doesn't match the valid identifier
    pattern (letter/underscore followed by letters/digits/underscores).
    Reserved words are *not* automatically quoted.
    """
    if not identifier:
        return True
    if is_already_quoted(identifier):
        return False
    return not _VALID_IDENTIFIER_PATTERN.match(identifier)


def quote_identifier(identifier: str, force_quote: bool = True) -> str:
    """
    Quote an identifier for SQL Server using double quotes.

    SQL Server supports both ``[brackets]`` and ``"double quotes"``; we use
    double quotes for consistency with other platforms.  Internal ``"``
    characters are escaped by doubling them.

    Args:
        identifier: The identifier to quote
        force_quote: If True, always quote. If False, only quote if necessary.

    Returns:
        The quoted identifier in ``"double quote"`` notation

    """
    if not identifier:
        return '""'
    if is_already_quoted(identifier):
        return identifier
    if not force_quote and not needs_quoting(identifier):
        return identifier
    escaped = identifier.replace('"', '""')
    return f'"{escaped}"'


def unquote_identifier(identifier: str) -> str:
    """
    Remove SQL Server quoting from an identifier.

    Handles both bracket notation ``[name]`` and double quote notation
    ``"name"``.
    """
    if identifier.startswith("[") and identifier.endswith("]"):
        return identifier[1:-1].replace("]]", "]")
    if identifier.startswith('"') and identifier.endswith('"'):
        return identifier[1:-1].replace('""', '"')
    return identifier


# ---------------------------------------------------------------------------
# Higher-level helpers that compose the primitives above
# ---------------------------------------------------------------------------


def parse_table_name_sqlserver(table_name: str) -> TableNameParts:
    """
    Parse a qualified table name using SQL Server quoting conventions.

    Handles bracket notation ``[name]``, double-quote notation ``"name"``,
    and plain unquoted identifiers.  Escaped brackets (``]]``) and escaped
    double-quotes (``""``) inside quoted identifiers are unescaped.

    Args:
        table_name: Qualified table name (already stripped / validated by caller)

    Returns:
        TableNameParts with database, schema, and table components

    """
    has_brackets = "[" in table_name
    has_double_quotes = '"' in table_name

    if has_brackets or has_double_quotes:
        bracketed_pattern = r"\[([^\]]*(?:\]\][^\]]*)*)\]"
        quoted_pattern = r'"([^"]*(?:""[^"]*)*)"'
        unquoted_pattern = r'([^.\[\]"]+)'
        pattern = f"({bracketed_pattern})|({quoted_pattern})|({unquoted_pattern})"

        parts: list[str] = []
        for match in re.finditer(pattern, table_name):
            full_match = match.group(0)
            if full_match.startswith("["):
                inner = full_match[1:-1].replace("]]", "]")
                parts.append(inner)
            elif full_match.startswith('"'):
                inner = full_match[1:-1].replace('""', '"')
                parts.append(inner)
            else:
                parts.append(full_match)
    else:
        parts = table_name.split(".")

    parts = [p.strip() for p in parts if p.strip()]

    if not parts:
        raise ValueError(f"Invalid table name: {table_name}")

    if len(parts) == 1:
        return TableNameParts(database=None, schema=None, table=parts[0])
    elif len(parts) == 2:
        return TableNameParts(database=None, schema=parts[0], table=parts[1])
    else:
        return TableNameParts(database=parts[-3], schema=parts[-2], table=parts[-1])


def normalize_identifier_sqlserver(identifier: str) -> str:
    """
    Normalize an identifier for SQL Server.

    Unquoted identifiers are case-insensitive in SQL Server, so they are
    uppercased.  Identifiers that require quoting (special characters, etc.)
    preserve their original case.

    Args:
        identifier: The identifier to normalize

    Returns:
        The normalized (and possibly quoted) identifier

    """
    possibly_quoted = quote_identifier_for_ref_sqlserver(identifier)
    if is_already_quoted(possibly_quoted):
        return possibly_quoted
    return possibly_quoted.upper()


def quote_identifier_for_ref_sqlserver(
    identifier: str, force_quote: bool = False
) -> str:
    """
    Quote an identifier only when needed for SQL Server table references.

    Unlike the query-builder's ``quote_identifier`` (which always wraps in
    square brackets), this only quotes when the identifier contains special
    characters, starts with a digit, or is already quoted.

    Args:
        identifier: The identifier to quote
        force_quote: If True, always quote regardless of whether it's needed

    Returns:
        The appropriately quoted identifier

    """
    should_quote = (
        force_quote or needs_quoting(identifier) or is_already_quoted(identifier)
    )
    if should_quote:
        return quote_identifier(identifier, force_quote=True)
    return identifier
