"""
SQL Server checksum query generation.

Builds partition-level checksum queries using HASHBYTES with MD5 and
bucket-sliced aggregation.  All functions are stateless; the only
dependency on the query builder is a ``quote_identifier`` callable
passed in by the caller.
"""

from __future__ import annotations

from collections.abc import Callable

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    NULL_TOKEN,
    ColumnInfo,
    PartitionInfo,
)


logger = get_logger("platforms.sqlserver.checksum")

# ---------------------------------------------------------------------------
# Hash / bucket constants
# ---------------------------------------------------------------------------
_HASH_ALGORITHM = "md5"
_BITS_PER_HASH = 128
_BYTES_PER_HASH = _BITS_PER_HASH // 8  # 16 bytes
_BUCKETS_PER_HASH = 4
_BYTES_PER_BUCKET = _BYTES_PER_HASH // _BUCKETS_PER_HASH  # 4 bytes per bucket
_NUMERIC_PRECISION = 38

# Column types that cannot be passed to HASHBYTES
_SKIPPED_TYPES = frozenset({"image", "ntext", "text"})


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def build_sqlserver_checksum_query(
    *,
    partition_info: PartitionInfo,
    source_table_id: TableIdentifier,
    columns: list[ColumnInfo],
    quote_identifier_fn: Callable[[str], str],
    where_clause: str,
) -> str:
    """
    Build a SQL Server checksum query using HASHBYTES with bucket slicing.

    The query:
    1. Converts each column to character representation
    2. Concatenates all columns with '|' separator
    3. Computes HASHBYTES('md5', ...) for each row
    4. Splits the hash into 4-byte buckets
    5. SUMs each bucket independently (as NUMERIC(38,0) to prevent overflow)
    6. Concatenates bucket sums with ':' separator

    Args:
        partition_info: Partition boundaries and table info
        source_table_id: Source table identifier
        columns: Column metadata list
        quote_identifier_fn: Platform-specific identifier quoting callable
        where_clause: Pre-built partition boundary condition (without WHERE keyword).

    Returns:
        SQL query that computes the partition checksum

    """
    hashable_columns = [
        col for col in columns if col.data_type.lower() not in _SKIPPED_TYPES
    ]

    if not hashable_columns:
        logger.warning(
            f"No hashable columns for {source_table_id.fully_qualified_friendly_name}, "
            "falling back to COUNT(*)"
        )
        return _build_count_only_query(
            partition_info, quote_identifier_fn, where_clause
        )

    hashed_columns_expr = _build_hashed_columns_expression(
        hashable_columns, quote_identifier_fn
    )
    checksum_select = _build_checksum_aggregation()
    table_ref = _build_fqn(partition_info, quote_identifier_fn)

    return f"""SELECT
    {checksum_select} AS checksum
FROM (
    SELECT {hashed_columns_expr} AS hashed_columns
    FROM {table_ref}
    WHERE {where_clause}
) t"""


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------
def _build_fqn(
    partition_info: PartitionInfo,
    quote_identifier_fn: Callable[[str], str],
) -> str:
    return (
        f"{quote_identifier_fn(partition_info.database)}."
        f"{quote_identifier_fn(partition_info.schema)}."
        f"{quote_identifier_fn(partition_info.table_name)}"
    )


def _build_hashed_columns_expression(
    columns: list[ColumnInfo],
    quote_identifier_fn: Callable[[str], str],
) -> str:
    """Build the HASHBYTES expression for all columns."""
    column_expressions = []
    for col in columns:
        char_expr = _charamelize(col, quote_identifier_fn)
        if col.is_nullable:
            char_expr = f"ISNULL({char_expr}, '{NULL_TOKEN}')"
        column_expressions.append(char_expr)

    concatenated = " + '|' + ".join(column_expressions)
    return f"HASHBYTES('{_HASH_ALGORITHM}', {concatenated})"


def _charamelize(
    column: ColumnInfo,
    quote_identifier_fn: Callable[[str], str],
) -> str:
    """Convert a column to character representation for hashing."""
    col_ref = quote_identifier_fn(column.column_name)
    data_type = column.data_type.lower()

    match data_type:
        case "datetimeoffset":
            return f"REPLACE(CONVERT(nvarchar(35), {col_ref}, 127), 'T', ' ')"

        case "geometry" | "geography":
            return f"{col_ref}.STAsText()"

        case "hierarchyid":
            return f"{col_ref}.ToString()"

        case "timestamp" | "rowversion":
            return f"CONVERT(nvarchar(max), CAST({col_ref} AS varbinary(8)), 2)"

        case "uniqueidentifier":
            return f"CONVERT(nvarchar(36), {col_ref})"

        case "xml":
            return f"CAST(CONVERT(XML, {col_ref}) AS nvarchar(max))"

        case "binary" | "varbinary":
            return f"CONVERT(nvarchar(max), {col_ref}, 2)"

        case "date":
            return f"CONVERT(nvarchar(10), {col_ref}, 23)"

        case "time":
            return f"CONVERT(nvarchar(16), {col_ref}, 121)"

        case "datetime" | "datetime2" | "smalldatetime":
            return f"REPLACE(CONVERT(nvarchar(29), {col_ref}, 121), 'T', ' ')"

        case "float" | "real":
            return f"CONVERT(nvarchar(50), {col_ref}, 2)"

        case "bit":
            return f"CAST({col_ref} AS nvarchar(1))"

        case (
            "decimal"
            | "numeric"
            | "money"
            | "smallmoney"
            | "int"
            | "bigint"
            | "smallint"
            | "tinyint"
        ):
            precision = column.numeric_precision or _NUMERIC_PRECISION
            scale = column.numeric_scale or 0
            return f"LTRIM(STR({col_ref}, {precision + 2}, {scale}))"

        case _:
            return f"CAST({col_ref} AS nvarchar(max))"


def _build_checksum_aggregation() -> str:
    """Build the bucket-sliced aggregation expression."""
    bucket_expressions = []
    for i in range(_BUCKETS_PER_HASH):
        start_pos = (i * _BYTES_PER_BUCKET) + 1
        bucket_expr = (
            f"CAST("
            f"ISNULL("
            f"SUM("
            f"CAST("
            f"CAST(SUBSTRING(hashed_columns, {start_pos}, {_BYTES_PER_BUCKET}) AS BIGINT) "
            f"AS NUMERIC({_NUMERIC_PRECISION},0)"
            f")"
            f"), 0"
            f") AS VARCHAR(40)"
            f")"
        )
        bucket_expressions.append(bucket_expr)

    return " + ':' + ".join(bucket_expressions)


def _build_count_only_query(
    partition_info: PartitionInfo,
    quote_identifier_fn: Callable[[str], str],
    where_clause: str,
) -> str:
    """Fallback query returning only COUNT when no columns are hashable."""
    table_ref = _build_fqn(partition_info, quote_identifier_fn)

    return f"""SELECT
    CAST(COUNT_BIG(*) AS VARCHAR(40)) AS checksum
FROM {table_ref}
WHERE {where_clause}"""
