"""
Microsoft SQL Server platform implementation.

This module provides the SqlServerPlatform class that defines SQL Server-specific
behavior for data migration workflows.
"""

from functools import cached_property

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.identifiers import (
    parse_table_name_sqlserver,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.query_builder import (
    SqlServerQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.type_mappings import (
    SQLSERVER_TO_SNOWFLAKE_TYPE_MAPPINGS,
)
from data_migration_orchestrator.utils.table_name_parts import TableNameParts
from shared.enums.source_type import SourceType


class SqlServerPlatform(BasePlatform):
    """
    Platform implementation for Microsoft SQL Server.

    Supports extraction via ODBC strategy. SQL Server does not have a native
    bulk export command like Redshift's UNLOAD, so ODBC is the primary method.
    BCP (Bulk Copy Program) can be used for improved performance when available.
    """

    @property
    def name(self) -> SourceType:
        """Return the canonical platform name."""
        return SourceType.SQLSERVER

    @property
    def display_name(self) -> str:
        """Return a human-readable platform name."""
        return "Microsoft SQL Server"

    @property
    def aliases(self) -> list[str]:
        """Return common aliases for this platform."""
        return ["mssql", "sql-server", "microsoft-sql-server"]

    @property
    def default_strategy(self) -> ExtractionStrategy:
        """Return the default extraction strategy."""
        return ExtractionStrategy.REGULAR

    @property
    def supported_strategies(self) -> list[ExtractionStrategy]:
        """Return all supported extraction strategies."""
        return [ExtractionStrategy.REGULAR]

    @cached_property
    def query_builder(self) -> BaseQueryBuilder:
        """Return the SQL Server query builder instance."""
        return SqlServerQueryBuilder()

    @property
    def type_mappings(self) -> dict[str, str]:
        """Return SQL Server to Snowflake type mappings."""
        return SQLSERVER_TO_SNOWFLAKE_TYPE_MAPPINGS

    def get_type_mapping(self, source_type: str) -> str | None:
        """
        Get the Snowflake type for a SQL Server type.

        Args:
            source_type: SQL Server data type name

        Returns:
            Corresponding Snowflake type or None if not mapped

        """
        # Normalize to lowercase for lookup
        normalized = source_type.lower().strip()
        return self.type_mappings.get(normalized)

    def supports_strategy(self, strategy_name: ExtractionStrategy) -> bool:
        """
        Check if a strategy is supported.

        Args:
            strategy_name: Name of the extraction strategy

        Returns:
            True if strategy is supported

        """
        return strategy_name.lower() in [s.lower() for s in self.supported_strategies]

    def parse_table_name(self, table_name: str) -> TableNameParts:
        """Parse a table name using SQL Server quoting conventions."""
        if not table_name or not table_name.strip():
            raise ValueError("table_name cannot be empty")
        return parse_table_name_sqlserver(table_name.strip())
