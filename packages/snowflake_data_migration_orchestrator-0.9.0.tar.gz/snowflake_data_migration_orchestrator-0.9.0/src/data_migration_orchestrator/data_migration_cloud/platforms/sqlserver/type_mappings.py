"""
SQL Server to Snowflake type mappings.

This module defines the mapping from SQL Server data types to their
Snowflake equivalents for schema conversion during migration.
"""

# SQL Server to Snowflake type mappings
# Reference: https://docs.snowflake.com/en/sql-reference/data-types
SQLSERVER_TO_SNOWFLAKE_TYPE_MAPPINGS: dict[str, str] = {
    # Exact Numeric Types
    "bit": "BOOLEAN",
    "tinyint": "SMALLINT",
    "smallint": "SMALLINT",
    "int": "INTEGER",
    "integer": "INTEGER",
    "bigint": "BIGINT",
    "decimal": "DECIMAL",
    "numeric": "NUMERIC",
    "money": "DECIMAL(19,4)",
    "smallmoney": "DECIMAL(10,4)",
    # Approximate Numeric Types
    "float": "FLOAT",
    "real": "REAL",
    # Date and Time Types
    "date": "DATE",
    "time": "TIME",
    "datetime": "TIMESTAMP_NTZ",
    "datetime2": "TIMESTAMP_NTZ",
    "smalldatetime": "TIMESTAMP_NTZ",
    "datetimeoffset": "TIMESTAMP_TZ",
    # Character String Types
    "char": "CHAR",
    "varchar": "VARCHAR",
    "text": "VARCHAR(16777216)",
    "nchar": "CHAR",
    "nvarchar": "VARCHAR",
    "ntext": "VARCHAR(16777216)",
    # Binary Types
    "binary": "BINARY",
    "varbinary": "VARBINARY",
    "image": "VARBINARY",
    # Other Types
    "uniqueidentifier": "VARCHAR(36)",
    "xml": "VARIANT",
    "sql_variant": "VARIANT",
    "hierarchyid": "VARCHAR(4000)",
    "geometry": "GEOGRAPHY",
    "geography": "GEOGRAPHY",
    # Timestamp (rowversion) - not actual timestamp
    "timestamp": "BINARY(8)",
    "rowversion": "BINARY(8)",
}
