"""
Snowflake identifier quoting and unquoting.

Handles Snowflake-specific identifier conventions:
- Double-quote notation: "schema"."table"
- Unquoted identifiers are case-insensitive (stored as uppercase)
"""

from __future__ import annotations

import re


# Valid Snowflake identifiers (no quoting needed):
# starts with a letter or underscore, followed by letters/digits/underscores/$.
_VALID_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_$]*$")


def is_already_quoted(identifier: str) -> bool:
    """Check if an identifier is already double-quoted."""
    return identifier.startswith('"') and identifier.endswith('"')


def needs_quoting(identifier: str) -> bool:
    """
    Check if a Snowflake identifier needs to be quoted.

    Unquoted identifiers are case-insensitive in Snowflake (converted to
    uppercase automatically), so lowercase names work without quoting.
    Only structural issues (spaces, dots, leading digits, etc.) require
    quoting.
    """
    if not identifier:
        return True
    if is_already_quoted(identifier):
        return False
    return not _VALID_IDENTIFIER_PATTERN.match(identifier)


def quote_identifier(identifier: str, force_quote: bool = True) -> str:
    """
    Quote an identifier for Snowflake using double quotes.

    Internal ``"`` characters are escaped by doubling them.

    Args:
        identifier: The identifier to quote
        force_quote: If True, always quote. If False, only quote if necessary.

    Returns:
        The quoted identifier in ``"double quote"`` notation

    """
    if not identifier:
        return '""'
    if is_already_quoted(identifier):
        return identifier
    if not force_quote and not needs_quoting(identifier):
        return identifier
    escaped = identifier.replace('"', '""')
    return f'"{escaped}"'


def unquote_identifier(identifier: str) -> str:
    """Remove Snowflake double-quote quoting from an identifier."""
    if is_already_quoted(identifier):
        return identifier[1:-1].replace('""', '"')
    return identifier
