"""Snowflake platform module for target database operations."""

from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.query_builder import (
    PartitionRange,
    SnowflakeQueryBuilder,
    build_snowflake_partition_condition,
)


__all__ = [
    "PartitionRange",
    "SnowflakeQueryBuilder",
    "build_snowflake_partition_condition",
]
