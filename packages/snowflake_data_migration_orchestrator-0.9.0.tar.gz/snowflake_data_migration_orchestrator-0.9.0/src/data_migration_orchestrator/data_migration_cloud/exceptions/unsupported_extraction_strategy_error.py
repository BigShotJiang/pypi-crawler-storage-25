"""UnsupportedPayloadKindError exception."""


class UnsupportedExtractionStrategyError(Exception):
    """
    Exception raised when no handler is registered for a given payload kind.

    This exception is raised by TaskHandlerFactory when attempting to get or create
    a handler for a task payload kind that has no registered handler.
    """

    def __init__(
        self,
        extraction_strategy_name: str,
        platform_name: str,
    ):
        """
        Initialize the exception.

        Args:
            extraction_strategy_name: The name of the extraction strategy.
            platform_name: The name of the platform from which the data will be extracted.

        """
        self.extraction_strategy_name = extraction_strategy_name
        self.platform_name = platform_name

        message = f"The extraction strategy '{extraction_strategy_name}' is not supported for the platform '{platform_name}'."
        super().__init__(message)
