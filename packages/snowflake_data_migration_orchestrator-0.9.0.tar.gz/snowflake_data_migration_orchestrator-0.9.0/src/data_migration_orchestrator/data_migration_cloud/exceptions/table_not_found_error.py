"""TableNotFoundError exception for non-existent source tables."""

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from shared.enums.source_type import SourceType


class TableNotFoundError(Exception):
    """
    Exception raised when a table specified in the configuration does not exist in the source.

    This exception is raised when metadata or schema extraction returns empty results,
    indicating that the configured table does not exist in the source database.
    """

    def __init__(
        self,
        table_name: str,
        database: str,
        schema: str,
        source_type: SourceType | None = None,
        detail: str | None = None,
    ):
        """
        Initialize the exception.

        Args:
            table_name: The name of the table that was not found
            database: The database name where the table was expected
            schema: The schema name where the table was expected
            source_type: The type of source database (e.g., 'sqlserver', 'postgresql')
            detail: Additional detail about the error

        """
        self.table_name = table_name
        self.database = database
        self.schema = schema
        self.source_type = source_type
        self.detail = detail

        # Build the fully qualified table name if parts are available
        if table_name:
            table_id = TableIdentifier(
                database_name=database, schema_name=schema, table_name=table_name
            )
            table_fqn = table_id.fully_qualified_friendly_name
            message = f"Table '{table_fqn}' does not exist in the source database"
        else:
            message = "Table does not exist in the source database"

        if source_type:
            message += f" (source type: {source_type})"

        message += (
            ". Please verify that the table name, schema, and database "
            "specified in your configuration are correct and that the table exists."
        )

        if detail:
            message += f" Detail: {detail}"

        super().__init__(message)
