"""Custom exceptions for the tasks module."""

from .table_not_found_error import TableNotFoundError
from .unsupported_extraction_strategy_error import UnsupportedExtractionStrategyError
from .view_not_supported_error import ViewNotSupportedError


__all__ = [
    "TableNotFoundError",
    "UnsupportedExtractionStrategyError",
    "ViewNotSupportedError",
]
