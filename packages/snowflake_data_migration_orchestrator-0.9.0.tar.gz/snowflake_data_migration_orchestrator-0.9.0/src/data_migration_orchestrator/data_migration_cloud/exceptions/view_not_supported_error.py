"""ViewNotSupportedError exception for source objects that are views, not tables."""

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from shared.enums.source_type import SourceType


class ViewNotSupportedError(Exception):
    """
    Exception raised when a configured source object is a VIEW instead of a TABLE.

    Data migration currently only supports base tables. When the preprocessing
    check detects a VIEW, this exception halts the task chain with a clear
    error message directing the user to correct their configuration.
    """

    def __init__(
        self,
        table_name: str,
        database: str,
        schema: str,
        source_type: SourceType | None = None,
        detail: str | None = None,
    ):
        """
        Initialize the exception.

        Args:
            table_name: The name of the object that turned out to be a view
            database: The database name where the object resides
            schema: The schema name where the object resides
            source_type: The type of source database (e.g., 'redshift', 'sqlserver')
            detail: Additional detail about the error

        """
        self.table_name = table_name
        self.database = database
        self.schema = schema
        self.source_type = source_type
        self.detail = detail

        table_id = TableIdentifier(
            database_name=database, schema_name=schema, table_name=table_name
        )
        fqn = table_id.fully_qualified_friendly_name
        message = (
            f"'{fqn}' is a VIEW, not a TABLE. "
            f"Data migration does not support views. "
            f"Please remove this entry from your configuration or replace it "
            f"with the underlying base table."
        )

        if source_type:
            message += f" (source type: {source_type})"

        if detail:
            message += f" Detail: {detail}"

        super().__init__(message)
