from data_migration_orchestrator.cloud_core.tasks.snowpipe_task import (
    SnowpipeTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    ClearPartitionDataPayload,
    ComparePartitionChecksumPayload,
    CompletePartitionMigrationTaskPayload,
    CreatePartitionTasksPayload,
    DataMovementTaskPayload,
    DeduplicatePartitionDataPayload,
    DeterminePartitionStrategyTaskPayload,
    PreprocessingCheckPayload,
    ProcessChecksumResultPayload,
    ProcessStagedDataTaskPayload,
    SetupSnowpipePayload,
    SnowflakeQueryTaskPayload,
    TaskPayload,
    TeardownSnowpipePayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)


def map_data_migration_task_payload(kind: str, payload_dict: dict) -> TaskPayload:
    """Map a task payload dictionary to the appropriate dataclass based on the kind."""
    match kind:
        case TaskPayloadKind.DATA_MOVEMENT.value:
            return DataMovementTaskPayload(**payload_dict)
        case TaskPayloadKind.PREPROCESSING_CHECK.value:
            return PreprocessingCheckPayload(**payload_dict)
        case TaskPayloadKind.DETERMINE_PARTITION_STRATEGY.value:
            return DeterminePartitionStrategyTaskPayload(**payload_dict)
        case TaskPayloadKind.CREATE_PARTITION_TASKS.value:
            return CreatePartitionTasksPayload(**payload_dict)
        case TaskPayloadKind.PROCESS_STAGED_DATA.value:
            return ProcessStagedDataTaskPayload(**payload_dict)
        case TaskPayloadKind.SNOWFLAKE_QUERY.value:
            return SnowflakeQueryTaskPayload(**payload_dict)
        case TaskPayloadKind.COMPLETE_PARTITION_MIGRATION.value:
            return CompletePartitionMigrationTaskPayload(**payload_dict)
        case TaskPayloadKind.COMPARE_PARTITION_CHECKSUM.value:
            return ComparePartitionChecksumPayload(**payload_dict)
        case TaskPayloadKind.PROCESS_CHECKSUM_RESULT.value:
            return ProcessChecksumResultPayload(**payload_dict)
        case TaskPayloadKind.CLEAR_PARTITION_DATA.value:
            return ClearPartitionDataPayload(**payload_dict)
        case TaskPayloadKind.DEDUPLICATE_PARTITION_DATA.value:
            return DeduplicatePartitionDataPayload(**payload_dict)
        case TaskPayloadKind.SNOWPIPE_INGESTION.value:
            return SnowpipeTaskPayload(**payload_dict)
        case TaskPayloadKind.SETUP_SNOWPIPE.value:
            return SetupSnowpipePayload(**payload_dict)
        case TaskPayloadKind.TEARDOWN_SNOWPIPE.value:
            return TeardownSnowpipePayload(**payload_dict)
        case _:
            raise ValueError(f"Unknown task payload kind: {kind}")
