"""
Shared helper to ensure a target table exists before writes.

Used by both ``SetupSnowpipeHandler`` (which runs ``CREATE TABLE IF NOT EXISTS``
right before ``CREATE PIPE``) and ``StagedDataHandler`` (defensive lazy-create
on first load). Idempotent: when ``table_already_exists`` is True, this is a
no-op.

Builds ``CREATE TABLE`` (or ``CREATE ICEBERG TABLE``) DDL from an extracted
source schema and a type-mapping loader, then executes it against the warehouse.
"""

from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    IcebergTargetConfig,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.identifiers import (
    quote_identifier as quote_identifier_snowflake,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers._create_table_ddl import (
    apply_numeric_precision,
    build_create_table_ddl,
)
from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
    TypeMappingLoader,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)


logger = get_logger("tasks.handlers.target_table_creator")


async def create_target_table_if_missing(
    *,
    warehouse_proxy: Warehouse,
    full_table_name: str,
    source_schema: list[dict[str, Any]],
    type_mapping_loader: TypeMappingLoader,
    column_name_mappings: dict[str, str] | None,
    iceberg_config: IcebergTargetConfig | None,
    is_iceberg_source_stage: bool,
    target_table_id: Any = None,
    table_already_exists: bool = False,
) -> dict[str, str]:
    """
    Create the target table from an extracted source schema if missing.

    Returns a mapping ``{TARGET_COLUMN_NAME_UPPER: TARGET_TYPE_WITH_PARAMS}``
    used by callers (e.g. StagedDataHandler) to drive type-aware COPY INTO
    casts. When the table already exists, returns an empty dict and does
    nothing.
    """
    if table_already_exists:
        logger.info(f"Target table {full_table_name} already exists; skipping CREATE.")
        return {}

    column_definitions: list[str] = []
    created_table_target_types: dict[str, str] = {}

    for col in source_schema:
        source_type = col[DATA_TYPE]

        if is_iceberg_source_stage:
            target_type_with_params = source_type
        else:
            target_type = type_mapping_loader.get_snowflake_type(source_type)
            if not target_type:
                logger.warning(
                    f"No mapping found for type '{source_type}', "
                    f"skipping column '{col[COLUMN_NAME]}'"
                )
                continue
            target_type_with_params = apply_numeric_precision(target_type, col)

        source_col_name = col[COLUMN_NAME]
        target_col_name = source_col_name
        if column_name_mappings:
            target_col_name = column_name_mappings.get(source_col_name, source_col_name)
        quoted = quote_identifier_snowflake(target_col_name, force_quote=True)
        column_definitions.append(f"{quoted} {target_type_with_params}")
        created_table_target_types[target_col_name.upper()] = target_type_with_params

    create_table_sql = build_create_table_ddl(
        full_table_name=full_table_name,
        column_definitions=column_definitions,
        iceberg_config=iceberg_config,
        target_table_id=target_table_id,
    )
    await warehouse_proxy.execute_sync_query(create_table_sql)
    logger.info(f"Created table {full_table_name}")
    return created_table_target_types
