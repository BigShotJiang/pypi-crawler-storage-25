"""
Service for fetching and managing table configuration.

This module provides utilities to fetch table configuration from TABLE_METADATA table.
"""

import json

from typing import cast

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    DEFAULT_EXTRACTION_STRATEGY,
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    DEFAULT_SYNCHRONIZATION_STRATEGY,
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    DEFAULT_LOADING_STRATEGY,
    DEFAULT_TARGET_TABLE_TYPE,
    ExtractionConfig,
    IcebergTargetConfig,
    LoadingConfig,
    LoadingStrategy,
    LoadSegmentationConfig,
    PartitionSizeConfig,
    SynchronizationConfig,
    TableConfiguration,
    TableIdentifier,
    parse_partition_size,
)
from data_migration_orchestrator.utils.lru_cache import LRUCache
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("tasks.handlers.table_configuration_service")


# Cache for table configuration by table_metadata_id
# Shared across all service instances
_table_config_cache: LRUCache[int, TableConfiguration | None] = LRUCache(
    max_size=200,
    ttl_seconds=3600.0,  # 1 hour
)


class TableConfigurationService:
    """
    Service for fetching table configuration from TABLE_METADATA.

    This service retrieves table configuration stored during workflow
    initialization and provides it to handlers that need this configuration.
    """

    def __init__(self, warehouse_proxy: Warehouse):
        """
        Initialize the table configuration service.

        Args:
            warehouse_proxy: Proxy for executing warehouse queries

        """
        self.warehouse_proxy = warehouse_proxy

    async def fetch_table_configuration(
        self, table_metadata_id: int | None
    ) -> TableConfiguration | None:
        """
        Fetch table configuration from TABLE_METADATA table with caching.

        Args:
            table_metadata_id: ID of the table metadata record

        Returns:
            TableConfiguration object, or None if not found

        """
        if table_metadata_id is None:
            return None

        # Check cache first
        cached = _table_config_cache.get_with_sentinel(table_metadata_id)
        if cached is not LRUCache.NOT_FOUND:
            cached_value = cast(TableConfiguration | None, cached)
            if cached_value is not None:
                logger.debug(
                    f"Cache hit: table config for table_metadata_id={table_metadata_id}"
                )
            return cached_value

        # Cache miss - fetch from database
        try:
            query = (
                f"CALL {qualified_migration_schema()}.GET_TABLE_CONFIGURATION("
                f"{table_metadata_id})"
            )
            result = await self.warehouse_proxy.execute_sync_query(query)
            config: TableConfiguration | None = None

            if not result:
                _table_config_cache.set(table_metadata_id, config)
                return None

            first_row = result[0]
            raw_config = next(iter(first_row.values()), None)

            # Snowflake VARIANT is returned as JSON string
            if raw_config:
                try:
                    config_dict = (
                        json.loads(raw_config)
                        if isinstance(raw_config, str)
                        else raw_config
                    )
                    config = self._parse_table_configuration(config_dict)
                except (json.JSONDecodeError, TypeError) as e:
                    logger.warning(f"Failed to parse table configuration: {e}")

            # Cache the result (including None)
            _table_config_cache.set(table_metadata_id, config)

            if config is not None:
                logger.debug(
                    f"Fetched and cached table config for table_metadata_id={table_metadata_id}"
                )
            return config
        except Exception as e:
            logger.error(
                f"Failed to fetch table config for table_metadata_id={table_metadata_id}: {e}"
            )
            return None

    async def fetch_required_table_configuration(
        self, table_metadata_id: int
    ) -> TableConfiguration:
        """
        Fetch table configuration and raise if not found.

        Args:
            table_metadata_id: ID of the table metadata record
        Returns:
            TableConfiguration object
        Raises:
            Exception if configuration is not found or cannot be fetched

        """
        config = await self.fetch_table_configuration(table_metadata_id)
        if config is None:
            raise Exception(
                f"Table configuration not found for table_metadata_id={table_metadata_id}"
            )
        return config

    def _parse_table_configuration(self, config_dict: dict) -> TableConfiguration:
        """
        Parse a configuration dictionary into a TableConfiguration object.

        Args:
            config_dict: Raw configuration dictionary from database

        Returns:
            TableConfiguration object

        """
        # Parse source identifier
        source_dict = config_dict.get(keys.SOURCE, {})
        source = TableIdentifier(
            database_name=source_dict.get(keys.DATABASE_NAME, ""),
            schema_name=source_dict.get(keys.SCHEMA_NAME, ""),
            table_name=source_dict.get(keys.TABLE_NAME, ""),
        )

        # Parse target identifier
        target_dict = config_dict.get(keys.TARGET, {})
        target = TableIdentifier(
            database_name=target_dict.get(keys.DATABASE_NAME, ""),
            schema_name=target_dict.get(keys.SCHEMA_NAME, ""),
            table_name=target_dict.get(keys.TABLE_NAME, ""),
        )

        # Parse partition columns
        partition_columns = config_dict.get(keys.COLUMN_NAMES_TO_PARTITION_BY, [])

        # Parse column type mappings
        column_type_mappings = self._parse_column_type_mappings(
            config_dict.get(keys.COLUMN_TYPE_MAPPINGS)
        )

        # Parse column name mappings
        column_name_mappings = self._parse_column_name_mappings(
            config_dict.get(keys.COLUMN_NAME_MAPPINGS)
        )

        # Parse primary key columns
        primary_key_columns = config_dict.get(keys.PRIMARY_KEY_COLUMNS, [])

        # Parse synchronization config
        synchronization = self._parse_synchronization_config(
            config_dict.get(keys.SYNCHRONIZATION)
        )

        # Parse extraction config
        extraction = self._parse_extraction_config(config_dict.get(keys.EXTRACTION))

        # Parse partition size config
        partition_size = self._parse_partition_size_config(config_dict)

        # Parse and sanitize where clause criteria
        where_clause_criteria = self._sanitize_where_clause_criteria(
            config_dict.get(keys.WHERE_CLAUSE_CRITERIA)
        )

        # Parse target table type and Iceberg configuration
        _raw_table_type = target_dict.get(keys.TABLE_TYPE)
        target_table_type = (
            DEFAULT_TARGET_TABLE_TYPE if _raw_table_type is None else _raw_table_type
        )
        iceberg_config = self._parse_iceberg_config(
            target_dict.get(keys.ICEBERG_CONFIG)
        )

        # Parse loading configuration (warehouse vs Snowpipe)
        loading = self._parse_loading_config(config_dict.get(keys.LOADING))

        # Parse load segmentation configuration
        load_segmentation = self._parse_load_segmentation_config(
            config_dict.get(keys.LOAD_SEGMENTATION)
        )

        return TableConfiguration(
            source=source,
            target=target,
            partition_columns=partition_columns,
            column_type_mappings=column_type_mappings,
            column_name_mappings=column_name_mappings,
            primary_key_columns=primary_key_columns,
            synchronization=synchronization,
            extraction=extraction,
            partition_size=partition_size,
            where_clause_criteria=where_clause_criteria,
            target_table_type=target_table_type,
            iceberg_config=iceberg_config,
            loading=loading,
            load_segmentation=load_segmentation,
        )

    @staticmethod
    def _parse_iceberg_config(
        iceberg_dict: dict | None,
    ) -> IcebergTargetConfig | None:
        """Parse Iceberg configuration from the stored target dict."""
        if not iceberg_dict:
            return None
        return IcebergTargetConfig.from_dict(iceberg_dict)

    @staticmethod
    def _sanitize_where_clause_criteria(raw_value: object) -> str | None:
        """
        Sanitize a ``whereClauseCriteria`` value coming from the DB.

        Applies the same rules as ``ConfigurationParser._parse_where_clause_criteria``:
        strips a leading ``WHERE`` keyword (case-insensitive), trims whitespace,
        and ignores non-string values.
        """
        if raw_value is None:
            return None
        if not isinstance(raw_value, str):
            return None

        cleaned = raw_value.strip()
        if not cleaned:
            return None

        upper = cleaned.upper()
        if upper.startswith("WHERE "):
            cleaned = cleaned[6:].strip()
        elif upper == "WHERE":
            cleaned = ""

        return cleaned if cleaned else None

    def _parse_column_type_mappings(
        self, raw_mappings: list[dict] | dict | None
    ) -> dict[str, str]:
        """
        Parse column type mappings from raw database value.

        Args:
            raw_mappings: Raw mappings from database (list of dicts or dict)

        Returns:
            Dict mapping source types to target types

        """
        if not raw_mappings:
            return {}

        # Handle list format: [{"sourceType": "X", "targetType": "Y"}, ...]
        if isinstance(raw_mappings, list):
            result: dict[str, str] = {}
            for mapping in raw_mappings:
                source_type = mapping.get(keys.SOURCE_TYPE)
                target_type = mapping.get(keys.TARGET_TYPE)
                if source_type and target_type:
                    result[source_type.upper()] = target_type.upper()
            return result

        # Handle direct dict format: {"MONEY": "DECIMAL(19,4)", ...}
        if isinstance(raw_mappings, dict):
            return {k.upper(): v.upper() for k, v in raw_mappings.items()}

        return {}

    def _parse_column_name_mappings(
        self, raw_mappings: list[dict] | dict | None
    ) -> dict[str, str]:
        """
        Parse column name mappings from raw database value.

        Args:
            raw_mappings: Raw mappings from database (list of dicts or dict)

        Returns:
            Dict mapping source column names to target column names

        """
        if not raw_mappings:
            return {}

        # Handle list format: [{"sourceName": "X", "targetName": "Y"}, ...]
        if isinstance(raw_mappings, list):
            result: dict[str, str] = {}
            for mapping in raw_mappings:
                source_name = mapping.get(keys.SOURCE_NAME)
                target_name = mapping.get(keys.TARGET_NAME)
                if source_name and target_name:
                    result[source_name] = target_name
            return result

        # Handle direct dict format: {"old_name": "new_name", ...}
        if isinstance(raw_mappings, dict):
            return dict(raw_mappings)

        return {}

    @staticmethod
    def _parse_load_segmentation_config(
        seg_dict: dict | None,
    ) -> LoadSegmentationConfig | None:
        """Parse load segmentation configuration from stored dictionary."""
        if not seg_dict or not isinstance(seg_dict, dict):
            return None

        target_mb = seg_dict.get(keys.TARGET_SEGMENT_SIZE_MB)
        if (
            target_mb is None
            or not isinstance(target_mb, int | float)
            or target_mb <= 0
        ):
            return None

        return LoadSegmentationConfig(target_segment_size_mb=int(target_mb))

    def _parse_synchronization_config(
        self, sync_dict: dict | None
    ) -> SynchronizationConfig:
        """
        Parse synchronization configuration from raw dictionary.

        Args:
            sync_dict: Raw synchronization config dictionary

        Returns:
            SynchronizationConfig object

        """
        if not sync_dict:
            return SynchronizationConfig()

        strategy_str = sync_dict.get(keys.STRATEGY)
        watermark_column = sync_dict.get(keys.WATERMARK_COLUMN)
        track_modifications = sync_dict.get(keys.TRACK_MODIFICATIONS, False)

        if strategy_str:
            try:
                strategy = SyncStrategy.from_string(strategy_str)
            except NotImplementedError:
                strategy = DEFAULT_SYNCHRONIZATION_STRATEGY
        else:
            strategy = DEFAULT_SYNCHRONIZATION_STRATEGY

        return SynchronizationConfig(
            strategy=strategy,
            watermark_column=watermark_column,
            track_modifications=track_modifications,
        )

    def _parse_extraction_config(
        self, extraction_dict: dict | None
    ) -> ExtractionConfig:
        """
        Parse extraction configuration from raw dictionary.

        Uses a tagged union pattern where the 'strategy' field determines the type
        and which additional fields are relevant.

        Args:
            extraction_dict: Raw extraction config dictionary

        Returns:
            ExtractionConfig object

        """
        if not extraction_dict:
            return ExtractionConfig()

        strategy_str = extraction_dict.get(keys.STRATEGY)
        external_stage = extraction_dict.get(keys.EXTERNAL_STAGE)

        if strategy_str:
            try:
                strategy = ExtractionStrategy.from_string(strategy_str)
            except ValueError:
                strategy = DEFAULT_EXTRACTION_STRATEGY
        else:
            strategy = DEFAULT_EXTRACTION_STRATEGY

        return ExtractionConfig(
            strategy=strategy,
            external_stage=external_stage,
        )

    def _parse_loading_config(self, loading_dict: dict | None) -> LoadingConfig:
        """Parse loading configuration from raw dictionary."""
        if not loading_dict:
            return LoadingConfig()

        strategy_str = loading_dict.get(keys.STRATEGY)
        if strategy_str:
            try:
                strategy = LoadingStrategy.from_string(strategy_str)
            except ValueError:
                strategy = DEFAULT_LOADING_STRATEGY
        else:
            strategy = DEFAULT_LOADING_STRATEGY

        return LoadingConfig(strategy=strategy)

    def _parse_partition_size_config(self, config_dict: dict) -> PartitionSizeConfig:
        """
        Parse partition size configuration from stored database config.

        Reads flat ``targetPartitionSizeMb`` / ``targetPartitionSizeRows``
        fields and delegates to the shared ``parse_partition_size`` helper
        in lenient mode (invalid data falls back to auto with a warning).

        """
        target_mb = config_dict.get(keys.TARGET_PARTITION_SIZE_MB)
        target_rows = config_dict.get(keys.TARGET_PARTITION_SIZE_ROWS)
        result = parse_partition_size(target_mb, target_rows, strict=False)

        return result
