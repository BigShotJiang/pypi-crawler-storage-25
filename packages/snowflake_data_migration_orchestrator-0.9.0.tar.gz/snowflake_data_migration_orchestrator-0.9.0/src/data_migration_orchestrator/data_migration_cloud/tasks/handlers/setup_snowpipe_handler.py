"""
Handler for SETUP_SNOWPIPE tasks.

Ensures the target table exists (idempotent ``CREATE TABLE IF NOT EXISTS``)
and then creates the Snowpipe so subsequent partition loads can use
``ALTER PIPE REFRESH`` instead of ``COPY INTO``. Doing both in one task
eliminates the race where ``CREATE PIPE … AS COPY INTO <target>`` would
fail with ``invalid identifier`` when the target table had not yet been
lazily created by a partition loader.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.utils.pipe_utils import (
    build_enable_event_logging_sql,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_migration_cloud.services.schema_validator import (
    SchemaValidator,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.target_table_creator import (
    create_target_table_if_missing,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_config_service import (
    WorkflowConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    SetupSnowpipePayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    read_schema_from_stage,
    stage_path_for_schema,
)
from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
    TypeMappingLoader,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.setup_snowpipe")


class SetupSnowpipeHandler(BaseTaskHandler):
    """
    Handler that ensures the target table exists then creates a Snowpipe.

    The pipe's COPY INTO definition covers the table-level stage prefix.
    Individual partitions later trigger ALTER PIPE REFRESH with their
    specific sub-prefix.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ):
        """Initialize the setup snowpipe handler."""
        super().__init__(
            TaskPayloadKind.SETUP_SNOWPIPE,
            task_queue,
            warehouse_proxy,
        )
        self.table_config_service = TableConfigurationService(warehouse_proxy)
        self.workflow_config_service = WorkflowConfigService(warehouse_proxy)

    async def handle(self, task: Task) -> None:
        """
        Ensure the target table exists, then create the Snowpipe.

        Steps:

        1. Read the extracted source schema from the workflow's internal stage.
        2. Look up the inferred type mappings via ``TableConfigurationService``.
        3. Run idempotent ``CREATE TABLE IF NOT EXISTS`` (no-op if the
           target already exists).
        4. Run ``CREATE PIPE IF NOT EXISTS … AS COPY INTO <target>`` and
           enable event logging on the pipe.
        """
        if not isinstance(task.payload, SetupSnowpipePayload):
            raise ValueError(
                f"Expected SetupSnowpipePayload, got {type(task.payload).__name__}"
            )
        if task.id is None:
            raise ValueError("Task ID is required for SetupSnowpipeHandler")

        payload: SetupSnowpipePayload = task.payload

        await self._ensure_target_table(task.workflow_id, payload)

        create_pipe_sql = (
            f"CREATE PIPE IF NOT EXISTS {payload.pipe_name} "
            f"AUTO_INGEST = FALSE "
            f"AS COPY INTO {payload.target_table} "
            f"FROM {payload.stage_path} "
            f"FILE_FORMAT = (TYPE = 'PARQUET') "
            f"MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE"
        )

        logger.info(
            "Creating Snowpipe %s for table %s",
            payload.pipe_name,
            payload.target_table,
        )
        await self.warehouse_proxy.execute_sync_query(create_pipe_sql)

        await self.warehouse_proxy.execute_sync_query(
            build_enable_event_logging_sql(payload.pipe_name)
        )

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    async def _ensure_target_table(
        self, workflow_id: int, payload: SetupSnowpipePayload
    ) -> None:
        """
        Run idempotent ``CREATE TABLE IF NOT EXISTS`` for the target.

        Pulls the schema from the workflow's internal stage (populated by
        the schema-extraction task that runs upstream of Setup Snowpipe)
        and the column-mapping configuration from ``TABLE_METADATA``. The
        source-platform identifier needed for type translation is fetched
        from ``WORKFLOW.SOURCE_PLATFORM`` via ``WorkflowConfigService`` so
        workflow-level state stays the single source of truth instead of
        being copied onto every payload. Short-circuits on existing tables
        via ``SchemaValidator``.
        """
        table_config = (
            await self.table_config_service.fetch_required_table_configuration(
                payload.table_metadata_id
            )
        )
        target = table_config.target

        source_platform_raw = await self.workflow_config_service.fetch_source_platform(
            workflow_id
        )
        if not source_platform_raw:
            raise ValueError(
                f"Cannot determine source platform for workflow_id={workflow_id}"
            )
        source_platform = SourceType.from_string(source_platform_raw)

        schema_location = stage_path_for_schema(
            default_internal_stage(),
            workflow_id,
            payload.table_metadata_id,
        )
        source_schema = await read_schema_from_stage(
            self.warehouse_proxy, schema_location
        )

        loader = TypeMappingLoader(source_type=source_platform)

        validator = SchemaValidator(self.warehouse_proxy)
        validation_result = await validator.validate_schema(
            database_name=target.database_name,
            schema_name=target.schema_name,
            table_name=target.table_name,
            source_schema=source_schema,
            type_mapping_loader=loader,
        )

        await create_target_table_if_missing(
            warehouse_proxy=self.warehouse_proxy,
            full_table_name=payload.target_table,
            source_schema=source_schema,
            type_mapping_loader=loader,
            column_name_mappings=table_config.column_name_mappings or None,
            iceberg_config=table_config.iceberg_config,
            is_iceberg_source_stage=False,
            target_table_id=target,
            table_already_exists=validation_result.table_exists,
        )
