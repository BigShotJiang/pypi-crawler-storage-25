"""Preprocessing check handler – validates source object type before heavy extraction."""

from data_migration_orchestrator.cloud_core.constants.priorities import (
    PRIORITY_FOR_FAN_OUT_TASKS,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_migration_cloud.exceptions.table_not_found_error import (
    TableNotFoundError,
)
from data_migration_orchestrator.data_migration_cloud.exceptions.view_not_supported_error import (
    ViewNotSupportedError,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.scope import ScopeBuilder
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DataMovementTaskPayload,
    DeterminePartitionStrategyTaskPayload,
    PreprocessingCheckPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    read_object_type_from_stage,
    stage_path_for_metadata,
    stage_path_for_object_type,
    stage_path_for_schema,
)
from shared.enums.source_object_type import SourceObjectType
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.preprocessing_check")


class PreprocessingCheckHandler(BaseTaskHandler):
    """
    Validates the source object type and gates subsequent preprocessing.

    Reads the object-type result deposited on stage by the DEA, then:
    - Raises ``TableNotFoundError`` if the object does not exist (empty result).
    - Raises ``ViewNotSupportedError`` if the object is a VIEW.
    - Attaches a warning if the object type is unrecognized.
    - Creates metadata extraction, schema extraction, and partition-strategy
      tasks when the check passes.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ):
        """Initialize with task queue and warehouse proxy."""
        super().__init__(
            TaskPayloadKind.PREPROCESSING_CHECK,
            task_queue,
            warehouse_proxy,
        )

    async def handle(self, task: Task) -> None:
        """Validate source object type and create downstream tasks."""
        if not isinstance(task.payload, PreprocessingCheckPayload):
            raise ValueError(
                f"Expected PreprocessingCheckPayload, got {type(task.payload)}"
            )

        payload = task.payload
        source_type = SourceType.from_string(payload.source_type)

        object_type_location = stage_path_for_object_type(
            default_internal_stage(), task.workflow_id, payload.table_metadata_id
        )

        raw_object_type = await read_object_type_from_stage(
            self.warehouse_proxy, object_type_location
        )

        if raw_object_type is None:
            raise TableNotFoundError(
                table_name=payload.table_name,
                database=payload.database,
                schema=payload.schema,
                source_type=source_type,
                detail=(
                    f"Object type query returned no rows from {object_type_location}. "
                    f"The object '{payload.database}.{payload.schema}.{payload.table_name}' "
                    "does not exist in the source database."
                ),
            )

        object_type = SourceObjectType.from_string(raw_object_type)
        logger.info(
            f"Object type for {payload.database}.{payload.schema}.{payload.table_name}: "
            f"{object_type.value}"
        )

        if object_type == SourceObjectType.VIEW:
            raise ViewNotSupportedError(
                table_name=payload.table_name,
                database=payload.database,
                schema=payload.schema,
                source_type=source_type,
            )

        if object_type == SourceObjectType.UNKNOWN:
            warning_msg = (
                f"'{payload.database}.{payload.schema}.{payload.table_name}' has an "
                f"unrecognized object type '{raw_object_type}'. "
                f"Migration will proceed but results may be unexpected."
            )
            logger.warning(warning_msg)
            if task.id is not None:
                await self.task_queue.warn_task(task.id, warning_msg)

        await self._create_metadata_and_strategy_tasks(task.workflow_id, payload)

        if task.id is None:
            raise ValueError("Task ID is required to complete task")

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    async def _create_metadata_and_strategy_tasks(
        self,
        workflow_id: int,
        payload: PreprocessingCheckPayload,
    ) -> None:
        """Create metadata+schema extraction (DEA) -> partition strategy (Orchestrator) chain."""
        platform = PlatformRegistry.create_by_name_or_alias(payload.source_type)
        source_table_id = TableIdentifier(
            payload.database, payload.schema, payload.table_name
        )

        preprocessing_scope = ScopeBuilder.for_table(
            source_table_id, platform
        ).preprocessing()

        use_database_command = platform.query_builder.build_use_database_command(
            payload.database
        )

        fully_qualified_target = payload.target_table

        # 1. Blocked partition-strategy task
        partition_strategy_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Determine partition strategy: {payload.database}.{payload.schema}.{payload.table_name}",
                executor_type=ExecutorType.ORCHESTRATOR,
                scope=preprocessing_scope,
                payload=DeterminePartitionStrategyTaskPayload(
                    database=payload.database,
                    schema=payload.schema,
                    table_name=payload.table_name,
                    source_type=payload.source_type,
                    target_table=fully_qualified_target,
                    table_metadata_id=payload.table_metadata_id,
                ),
            )
            .with_priority(PRIORITY_FOR_FAN_OUT_TASKS)
            .blocked()
            .build()
        )
        strategy_id = await self.task_queue.push_task(partition_strategy_task)

        if strategy_id is None:
            raise RuntimeError(
                f"Failed to create partition strategy task for {payload.table_name}"
            )

        # 2. Metadata extraction task (DEA) -> unblocks strategy
        metadata_location = stage_path_for_metadata(
            default_internal_stage(), workflow_id, payload.table_metadata_id
        )
        qb = platform.query_builder
        metadata_query = qb.build_metadata_query(source_table_id)

        metadata_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Extract metadata: {payload.database}.{payload.schema}.{payload.table_name}",
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                scope=preprocessing_scope,
                payload=DataMovementTaskPayload(
                    database=payload.database,
                    schema=payload.schema,
                    source_type=payload.source_type,
                    source_id="*",
                    target_type=payload.target_cloud_type,
                    target_id=metadata_location,
                    statement_location_id=metadata_query,
                    use_database_command=use_database_command,
                ),
            )
            .with_successor(strategy_id)
            .build()
        )
        await self.task_queue.push_task(metadata_task)

        # 3. Schema extraction task (DEA) -> unblocks strategy
        schema_location = stage_path_for_schema(
            default_internal_stage(), workflow_id, payload.table_metadata_id
        )
        schema_query = qb.build_schema_query(source_table_id)

        schema_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                task_name=f"Extract schema: {payload.database}.{payload.schema}.{payload.table_name}",
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                scope=preprocessing_scope,
                payload=DataMovementTaskPayload(
                    database=payload.database,
                    schema=payload.schema,
                    source_type=payload.source_type,
                    source_id="*",
                    target_type=payload.target_cloud_type,
                    target_id=schema_location,
                    statement_location_id=schema_query,
                    use_database_command=use_database_command,
                ),
            )
            .with_successor(strategy_id)
            .build()
        )
        await self.task_queue.push_task(schema_task)

        logger.info(
            f"Created preprocessing chain for {payload.table_name}: "
            f"[metadata + schema] -> partition strategy ({strategy_id})"
        )
