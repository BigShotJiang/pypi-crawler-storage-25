"""
Data models for partition-level checksum computation.

This module provides the shared data classes used by platform-specific
checksum query builders and the checksum comparison handler.
"""

from dataclasses import dataclass


# Default null token used when converting NULL values to strings for hashing
NULL_TOKEN = "-99999999"


@dataclass
class ColumnInfo:
    """
    Column metadata for checksum query building.

    Attributes:
        column_name: The column name
        data_type: The SQL Server data type (e.g., 'int', 'varchar', 'datetime2')
        is_nullable: Whether the column allows NULL values
        numeric_precision: Precision for numeric types
        numeric_scale: Scale for numeric types

    """

    column_name: str
    data_type: str
    is_nullable: bool
    numeric_precision: int | None = None
    numeric_scale: int | None = None


@dataclass
class PartitionInfo:
    """
    Information about a partition for checksum query building.

    Attributes:
        database: Source database name
        schema: Source schema name
        table_name: Source table name
        partition_column: Column used for partitioning
        min_value: Minimum value of the partition range (inclusive)
        max_value: Maximum value of the partition range (inclusive)
        partition_number: The partition number/index

    """

    database: str
    schema: str
    table_name: str
    partition_column: str | None
    min_value: str | None
    max_value: str | None
    partition_number: int
