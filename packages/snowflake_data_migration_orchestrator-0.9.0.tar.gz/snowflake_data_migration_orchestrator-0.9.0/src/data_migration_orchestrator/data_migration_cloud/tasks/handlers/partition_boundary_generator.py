"""Partition boundary generator for creating WHERE clauses."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from shared.enums.source_type import SourceType


@dataclass
class PartitionBoundary:
    """Represents a partition with its WHERE clause."""

    partition_index: int
    where_clause: str | None  # None for full table (no filtering)
    min_value: Any
    max_value: Any
    row_count: int


class PartitionBoundaryGenerator:
    """Generates partition boundaries and WHERE clauses from NTILE results."""

    def __init__(self) -> None:
        """Initialize with no query builder (set per-call based on source_type)."""
        self._query_builder: BaseQueryBuilder | None = None
        self._platform: BasePlatform | None = None

    def _get_platform(self, source_type: SourceType) -> BasePlatform:
        """Get or create platform for the given source type."""
        if self._platform is None or self._platform.name != source_type:
            self._platform = PlatformRegistry.create_by_name_or_alias(source_type)
            self._query_builder = self._platform.query_builder
        return self._platform

    def _get_query_builder(self, source_type: SourceType) -> BaseQueryBuilder:
        """Get or create query builder for the given source type."""
        self._get_platform(source_type)
        assert self._query_builder is not None
        return self._query_builder

    def generate_boundaries(
        self,
        partition_column: str | None,
        boundary_values: list[dict],
        num_partitions: int,
        source_type: SourceType,
    ) -> list[PartitionBoundary]:
        """
        Generate partition boundaries from NTILE query results.

        Returns N interior partitions (from the NTILE results) plus two
        **edge partitions** that cover values below the observed minimum
        and above the observed maximum.  Edge partitions ensure that rows
        inserted outside the original range are detected on subsequent
        incremental sync runs.

        Args:
            partition_column: Column used for partitioning
            boundary_values: List of dicts with keys: partition_id, min_value_in_partition,
                           max_value_in_partition, n_rows
            num_partitions: Expected number of partitions
            source_type: Database type for proper column quoting

        Returns:
            List of PartitionBoundary objects with WHERE clauses.
            The list has ``num_partitions + 2`` entries: a lower edge
            (index 0), the N interior partitions, and an upper edge
            (index N + 1).

        """
        if not boundary_values:
            raise ValueError("No boundary values provided")

        if len(boundary_values) != num_partitions:
            raise ValueError(
                f"Expected {num_partitions} partitions, got {len(boundary_values)}"
            )

        if partition_column is None:
            raise ValueError("partition_column is required to generate boundaries")

        # Resolve platform and query builder for this source type
        query_builder = self._get_query_builder(source_type)
        platform = self._get_platform(source_type)
        quoted_partition_column = platform.quote_column_name(partition_column)

        # --- interior partitions (from NTILE results) ---
        partitions: list[PartitionBoundary] = []
        for idx, row in enumerate(boundary_values):
            partition_id = self._extract_value(row, "partition_id")
            min_val = self._extract_value(row, "min_value_in_partition")
            max_val = self._extract_value(row, "max_value_in_partition")
            n_rows = self._extract_value(row, "n_rows")

            is_last = idx == len(boundary_values) - 1
            next_min_val = (
                None
                if is_last
                else self._extract_value(
                    boundary_values[idx + 1], "min_value_in_partition"
                )
            )

            where_clause = self._build_where_clause(
                quoted_partition_column, min_val, max_val, is_last, next_min_val
            )

            partitions.append(
                PartitionBoundary(
                    partition_index=int(partition_id),
                    where_clause=where_clause,
                    min_value=min_val,
                    max_value=max_val,
                    row_count=int(n_rows),
                )
            )

        # --- edge partitions ---
        first_min = self._extract_value(boundary_values[0], "min_value_in_partition")
        last_max = self._extract_value(boundary_values[-1], "max_value_in_partition")

        lower_edge_condition = query_builder.build_partition_condition(
            partition_column, None, first_min
        )
        upper_edge_condition = query_builder.build_partition_condition(
            partition_column, last_max, None
        )

        lower_edge = PartitionBoundary(
            partition_index=0,
            where_clause=f"WHERE {lower_edge_condition}",
            min_value=None,
            max_value=first_min,
            row_count=0,
        )
        upper_edge = PartitionBoundary(
            partition_index=num_partitions + 1,
            where_clause=f"WHERE {upper_edge_condition}",
            min_value=last_max,
            max_value=None,
            row_count=0,
        )

        return [lower_edge] + partitions + [upper_edge]

    def generate_single_boundary(
        self,
        partition_column: str | None,
        partition_id: int,
        min_value: Any,
        max_value: Any,
        source_type: SourceType,
        row_count: int = 0,
    ) -> PartitionBoundary:
        """
        Generate a single partition boundary from min/max values.

        Used when recreating boundaries from existing partition metadata
        during incremental sync operations.

        Args:
            partition_column: Column used for partitioning
            partition_id: The partition number
            min_value: Minimum value for this partition (None for full table)
            max_value: Maximum value for this partition (None for full table)
            source_type: Database type for proper column quoting
            row_count: Number of rows in partition (may be 0 if unknown)

        Returns:
            PartitionBoundary object with WHERE clause (empty for full table)

        """
        # For full table extractions (single partition with no bounds),
        # don't add any WHERE clause - extract all rows
        if min_value is None and max_value is None:
            return PartitionBoundary(
                partition_index=partition_id,
                where_clause="",  # No filtering - full table extraction
                min_value=min_value,
                max_value=max_value,
                row_count=row_count,
            )

        # Delegate to build_partition_condition for consistent quoting and
        # operator semantics (exclusive bounds for edges, inclusive for both).
        query_builder = self._get_query_builder(source_type)
        condition = query_builder.build_partition_condition(
            partition_column, min_value, max_value
        )
        where_clause = f"WHERE {condition}"

        return PartitionBoundary(
            partition_index=partition_id,
            where_clause=where_clause,
            min_value=min_value,
            max_value=max_value,
            row_count=row_count,
        )

    def _extract_value(self, row: dict, key: str) -> Any:
        """Extract value from row, handling case-insensitive keys."""
        # Try exact match first
        if key in row:
            return row[key]
        # Try uppercase
        upper_key = key.upper()
        if upper_key in row:
            return row[upper_key]
        # Try lowercase
        lower_key = key.lower()
        if lower_key in row:
            return row[lower_key]

        raise KeyError(f"Key '{key}' not found in row: {row}")

    def _build_where_clause(
        self,
        partition_column: str,
        min_value: Any,
        max_value: Any,
        is_last: bool,
        next_min_value: Any = None,
    ) -> str:
        """
        Build WHERE clause for partition range.

        For non-last partitions, uses the next partition's min value as the exclusive
        upper bound to ensure all values between partitions are captured.
        For the last partition, uses <= with the max value to include the final boundary.

        This prevents gaps when partition boundaries are not consecutive.

        Args:
            partition_column: Already quoted partition column name
            min_value: Minimum value for this partition
            max_value: Maximum value for this partition
            is_last: True if this is the last partition
            next_min_value: Minimum value of the next partition (for non-last partitions)

        Returns:
            WHERE clause string with properly quoted column name

        """
        min_formatted = self._format_value(min_value)

        if is_last:
            # Last partition: include everything >= min_value up to and including max_value
            max_formatted = self._format_value(max_value)
            return f"WHERE {partition_column} >= {min_formatted} AND {partition_column} <= {max_formatted}"
        else:
            # Non-last partition: include everything >= min_value and < next partition's min
            next_min_formatted = self._format_value(next_min_value)
            return f"WHERE {partition_column} >= {min_formatted} AND {partition_column} < {next_min_formatted}"

    def _format_value(self, value: Any) -> str:
        """
        Format value for SQL using platform-specific formatting.

        Delegates to the query builder for proper datetime handling
        based on the source database type.
        """
        if self._query_builder is None:
            raise RuntimeError(
                "Query builder not initialized. Call generate_boundaries or generate_single_boundary first."
            )
        return self._query_builder.format_sql_value(value)
