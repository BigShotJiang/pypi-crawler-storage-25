"""Partition strategy handler for determining data extraction partitioning."""

from data_migration_orchestrator.cloud_core.constants.priorities import (
    PRIORITY_FOR_FAN_OUT_TASKS,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    LoadingStrategy,
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_migration_cloud.exceptions.table_not_found_error import (
    TableNotFoundError,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.scope import ScopeBuilder
from data_migration_orchestrator.data_migration_cloud.services.batch_size_calculator import (
    BYTES_PER_MB,
    calculate_suggested_batch_size,
)
from data_migration_orchestrator.data_migration_cloud.tasks.checksum_task_creator import (
    ChecksumTaskCreator,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundary,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_calculator import (
    PartitionCalculator,
    PartitionDecision,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.smart_partition_config_resolver import (
    SmartPartitionConfigResolver,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.synchronization_config_service import (
    SynchronizationConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_config_service import (
    WorkflowConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_progress_service import (
    WorkflowProgressService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    SyncData,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CreatePartitionTasksPayload,
    DataMovementTaskPayload,
    DeterminePartitionStrategyTaskPayload,
    SetupSnowpipePayload,
    TargetType,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_chain_creator import (
    PartitionInput,
    TaskChainContext,
    TaskChainCreator,
)
from data_migration_orchestrator.data_migration_cloud.utils.pipe_utils import (
    build_pipe_name,
    build_snowpipe_stage_path,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    read_metadata_from_stage,
    read_schema_from_stage,
    stage_path_for_boundaries,
    stage_path_for_metadata,
    stage_path_for_schema,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.partition_strategy")


class PartitionStrategyHandler(BaseTaskHandler):
    """
    Analyzes metadata and decides partitioning strategy.

    Uses the unified three-step PartitionCalculator pipeline (target rows →
    cap with max_rows → partition count):
    - Small tables: Creates single SELECT * task
    - Large tables: Creates ANALYZE -> PROCESS_RESULTS chain
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ):
        """Initialize handler with queue and warehouse proxy."""
        super().__init__(
            TaskPayloadKind.DETERMINE_PARTITION_STRATEGY,
            task_queue,
            warehouse_proxy,
        )
        self.progress_service = WorkflowProgressService(warehouse_proxy)
        self.sync_config_service = SynchronizationConfigService(warehouse_proxy)
        self.workflow_config_service = WorkflowConfigService(warehouse_proxy)
        self.table_config_service = TableConfigurationService(warehouse_proxy)

    async def handle(self, task: Task) -> None:
        """Read metadata, decide strategy, create appropriate tasks."""
        if not isinstance(task.payload, DeterminePartitionStrategyTaskPayload):
            raise ValueError(
                f"Expected DeterminePartitionStrategyTaskPayload, got {type(task.payload)}"
            )

        payload = task.payload
        source_type = SourceType.from_string(payload.source_type)

        # Fetch table config first to determine extraction strategy
        table_config = (
            await self.table_config_service.fetch_required_table_configuration(
                payload.table_metadata_id
            )
        )

        # Fetch strategy config for later use in task chain creation
        strategy_config = await self.workflow_config_service.fetch_strategy_config(
            task.workflow_id, table_config.extraction_strategy.value
        )

        logger.info(
            f"Using extraction strategy: {table_config.extraction_strategy.value}"
        )

        # Metadata and schema are always stored on the internal stage
        # (PUT only works with internal stages, regardless of extraction strategy)
        # The extraction strategy's external_stage is for data extraction/loading, not metadata
        metadata_location = stage_path_for_metadata(
            default_internal_stage(), task.workflow_id, payload.table_metadata_id
        )

        try:
            metadata = await read_metadata_from_stage(
                self.warehouse_proxy, metadata_location
            )
        except ValueError as e:
            error_msg = str(e)
            # Check for conditions that indicate the source table doesn't exist:
            # - "No metadata found" - empty result from stage query
            # - "Missing row_count" - NULL values returned (table not in sys.tables)
            if "No metadata found" in error_msg or "Missing row_count" in error_msg:
                raise TableNotFoundError(
                    table_name=payload.table_name,
                    database=payload.database,
                    schema=payload.schema,
                    source_type=source_type,
                    detail=f"Metadata extraction returned no results from {metadata_location}. "
                    f"Original error: {error_msg}",
                ) from e
            raise Exception(
                f"Failed to read metadata from {metadata_location}: {e}"
            ) from e
        except Exception as e:
            raise Exception(
                f"Failed to read metadata from {metadata_location}: {e}"
            ) from e

        row_count = metadata["row_count"]
        data_size_mb = metadata["data_size_mb"]

        # Resolve partition config from per-table partitionSize configuration,
        # platform, extraction strategy, and table size.
        resolved_config = SmartPartitionConfigResolver.resolve(
            partition_size_config=table_config.partition_size,
            source_type=source_type,
            extraction_strategy=table_config.extraction_strategy,
            data_size_mb=data_size_mb,
        )
        partition_calculator = PartitionCalculator(resolved_config)

        decision = partition_calculator.calculate_partition_strategy(
            row_count=row_count, data_size_mb=data_size_mb
        )

        logger.info(decision.reasoning)

        avg_row_size_bytes = (
            (data_size_mb * BYTES_PER_MB) / row_count if row_count > 0 else None
        )

        logger.info(
            f"Using sync strategy: {table_config.synchronization.strategy.value} for {payload.table_name}"
        )

        # Build platform-specific USE database command once for all downstream tasks
        platform = PlatformRegistry.create_by_name_or_alias(payload.source_type)
        use_database_command = platform.query_builder.build_use_database_command(
            payload.database
        )

        if decision.should_partition and not table_config.partition_column:
            warning_msg = (
                f"Table '{payload.table_name}' has no columnNamesToPartitionBy "
                f"configured. It will be extracted as a single unit "
                f"({row_count:,} rows, {data_size_mb:.2f} MB), which may be "
                f"slow or fail for large tables."
            )
            logger.warning(warning_msg)
            if task.id is not None:
                await self.task_queue.warn_task(task.id, warning_msg)
            decision = PartitionDecision(
                should_partition=False,
                num_partitions=1,
                rows_per_partition=row_count,
                reasoning=f"No partition column - single extraction ({row_count:,} rows)",
            )

        try:
            if decision.should_partition:
                # Create tasks for analysis of partitions and subsequent extraction
                # Schema is not needed here; it will be read later by CreatePartitionTasksHandler
                await self._create_analyze_chain(
                    task.workflow_id,
                    table_config,
                    payload,
                    decision,
                    avg_row_size_bytes,
                    platform,
                    use_database_command,
                    row_count=row_count,
                )
            else:
                # Read source schema only for single-partition path where it's needed
                # for building extraction queries with server-side type conversions
                schema_location = stage_path_for_schema(
                    default_internal_stage(),
                    task.workflow_id,
                    payload.table_metadata_id,
                )
                source_schema = await read_schema_from_stage(
                    self.warehouse_proxy, schema_location
                )
                suggested_batch_size = calculate_suggested_batch_size(
                    row_count, data_size_mb
                )
                await self._create_chain_for_single_partition(
                    task.workflow_id,
                    table_config,
                    payload,
                    suggested_batch_size=suggested_batch_size,
                    row_count=row_count,
                    source_schema=source_schema,
                    strategy_config=strategy_config,
                )
        except Exception as e:
            raise Exception(
                f"Failed to create extraction tasks for {payload.table_name}: {e}"
            ) from e

        if task.id is None:
            raise ValueError("Task ID is required to complete task")

        if table_config.loading_strategy == LoadingStrategy.SNOWPIPE:
            await self._queue_snowpipe_setup(
                workflow_id=task.workflow_id,
                table_config=table_config,
                platform=platform,
                target_table=platform.build_normalized_table_name(table_config.target),
                table_metadata_id=payload.table_metadata_id,
            )

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    async def _queue_snowpipe_setup(
        self,
        *,
        workflow_id: int,
        table_config: TableConfiguration,
        platform: BasePlatform,
        target_table: str,
        table_metadata_id: int,
    ) -> None:
        """
        Queue the ``Setup Snowpipe`` task for a new-table snowpipe migration.

        Pushed here (rather than at workflow init) because the extracted
        source schema is only on stage by the time this handler runs.
        ``SetupSnowpipeHandler`` runs ``CREATE TABLE IF NOT EXISTS`` *before*
        ``CREATE PIPE``, so the pipe never references a missing target and
        the race with lazy CREATE TABLE in ``staged_data_handler`` cannot
        occur.
        """
        scope = ScopeBuilder.for_table(table_config.source, platform).preprocessing()

        pipe_name = build_pipe_name(workflow_id, target_table)
        stage_path = build_snowpipe_stage_path(
            table_config, workflow_id, table_metadata_id
        )

        setup_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Setup Snowpipe: {target_table}",
            executor_type=ExecutorType.ORCHESTRATOR,
            scope=f"{scope}::SnowpipeSetup",
            payload=SetupSnowpipePayload(
                pipe_name=pipe_name,
                target_table=target_table,
                stage_path=stage_path,
                table_metadata_id=table_metadata_id,
            ),
        ).build()
        await self.task_queue.push_task(setup_task)

        logger.info(
            "Queued Setup Snowpipe for %s (pipe=%s)",
            target_table,
            pipe_name,
        )

    async def _create_analyze_chain(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        payload: DeterminePartitionStrategyTaskPayload,
        decision,
        avg_row_size_bytes: float | None,
        platform: BasePlatform,
        use_database_command: str | None = None,
        row_count: int | None = None,
    ) -> None:
        """Create chain: ANALYZE -> PROCESS_RESULTS -> N × [EXTRACT -> LOAD]."""
        logger.info(
            f"_create_analyze_chain: table_metadata_id={payload.table_metadata_id}"
        )

        # Boundaries are always stored on internal stage (PUT only works with internal stages)
        boundaries_location = stage_path_for_boundaries(
            default_internal_stage(), workflow_id, payload.table_metadata_id
        )

        # Build source table FQN for scopes
        source_table_id = TableIdentifier(
            payload.database, payload.schema, payload.table_name
        )
        preprocessing_scope = ScopeBuilder.for_table(
            source_table_id, platform
        ).preprocessing()

        # Create CREATE_PARTITION_TASKS task (blocked)
        create_tasks_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                executor_type=ExecutorType.ORCHESTRATOR,
                task_name=f"Create partition tasks: {payload.table_name}",
                scope=preprocessing_scope,
                payload=CreatePartitionTasksPayload(
                    database=payload.database,
                    schema=payload.schema,
                    table_name=payload.table_name,
                    source_type=payload.source_type,
                    num_partitions=decision.num_partitions,
                    target_table=payload.target_table,
                    avg_row_size_bytes=avg_row_size_bytes,
                    table_metadata_id=payload.table_metadata_id,
                ),
            )
            .with_priority(PRIORITY_FOR_FAN_OUT_TASKS)
            .blocked()
            .build()
        )
        create_tasks_task_id = await self.task_queue.push_task(create_tasks_task)

        if table_config.partition_column is None:
            raise ValueError(
                "partition_column is required to analyze partition boundaries"
            )

        # Create ANALYZE task -> unblocks create tasks
        boundary_query = platform.query_builder.build_partition_boundary_query(
            source_table_id,
            table_config.partition_column,
            decision.num_partitions,
            row_count=row_count,
        )
        logger.info(
            f"Analyze boundaries ({decision.num_partitions} partitions) for {payload.source_type}: {boundary_query}"
        )

        analyze_task = (
            TaskBuilder(
                workflow_id=workflow_id,
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                task_name=f"Analyze boundaries: {payload.table_name}",
                scope=preprocessing_scope,
                payload=DataMovementTaskPayload(
                    database=payload.database,
                    schema=payload.schema,
                    source_type=payload.source_type,
                    source_id=f"{payload.database}.{payload.schema}",
                    target_type=TargetType.SNOWFLAKE_STAGE,
                    target_id=boundaries_location,
                    statement_location_type="in-payload",
                    statement_location_id=boundary_query,
                    use_database_command=use_database_command,
                ),
            )
            .with_priority(PRIORITY_FOR_FAN_OUT_TASKS)
            .with_successor(create_tasks_task_id)
            .build()
        )
        analyze_task_id = await self.task_queue.push_task(analyze_task)

        logger.info(
            f"Chain: ANALYZE({analyze_task_id}) -> CREATE_TASKS({create_tasks_task_id})"
        )

    async def _create_chain_for_single_partition(
        self,
        workflow_id: int,
        table_config: TableConfiguration,
        payload: DeterminePartitionStrategyTaskPayload,
        suggested_batch_size: int | None,
        row_count: int,
        source_schema: list[dict],
        strategy_config: dict | None = None,
    ) -> None:
        """Create single EXTRACT -> LOAD chain without partitioning."""
        # For single extraction, use partition 0 as it represents the full table
        partition_number = 0

        # Insert partition metadata for tracking
        partition_metadata_id = await self.progress_service.insert_partition_metadata(
            table_metadata_id=payload.table_metadata_id,
            partition_number=partition_number,
            min_value=None,
            max_value=None,
            rows=row_count,
        )

        if partition_metadata_id is None:
            raise Exception(
                f"Failed to insert partition metadata for {payload.table_name}"
            )

        # Mark table as preprocessed now that partition exists
        await self.progress_service.update_table_preprocessed(payload.table_metadata_id)

        # Fetch stored checksum from previous sync (if any)
        sync_data: SyncData | None = (
            await self.sync_config_service.fetch_partition_sync_data(
                payload.table_metadata_id, partition_number
            )
        )

        # For NONE/WATERMARK strategies, create direct EXTRACT -> LOAD chain
        source_type = SourceType.from_string(payload.source_type)
        source_table_id = TableIdentifier(
            database_name=payload.database,
            schema_name=payload.schema,
            table_name=payload.table_name,
        )

        partition_input = PartitionInput(
            partition_index=partition_number,
            partition_metadata_id=partition_metadata_id,
            partition_boundary=PartitionBoundary(
                partition_index=partition_number,
                min_value=None,
                max_value=None,
                where_clause=None,
                row_count=row_count,
            ),
            sync_data=sync_data,
        )

        if table_config.synchronization.strategy == SyncStrategy.CHECKSUM:
            # For CHECKSUM strategy, create COMPARE_PARTITION_CHECKSUM task
            # This allows incremental sync to skip extraction if checksum unchanged
            checksum_task_creator = ChecksumTaskCreator(self.task_queue)
            await checksum_task_creator.create_checksum_comparison_tasks(
                workflow_id=workflow_id,
                table_metadata_id=payload.table_metadata_id,
                source_table_id=source_table_id,
                source_type=source_type,
                target_table=payload.target_table,
                partition_inputs=[partition_input],
            )
        else:
            # For NONE/WATERMARK strategies, create direct EXTRACT -> LOAD chain
            platform = PlatformRegistry.create_by_name_or_alias(payload.source_type)
            task_chain_context = TaskChainContext(
                workflow_id=workflow_id,
                table_metadata_id=payload.table_metadata_id,
                table_config=table_config,
                suggested_batch_size=suggested_batch_size,
                source_schema=source_schema,
                strategy_config=strategy_config or {},
            )
            task_chain_creator = TaskChainCreator(
                platform, self.task_queue, task_chain_context
            )
            await task_chain_creator.build_task_chain_for_extraction_and_load(
                partition_input
            )
