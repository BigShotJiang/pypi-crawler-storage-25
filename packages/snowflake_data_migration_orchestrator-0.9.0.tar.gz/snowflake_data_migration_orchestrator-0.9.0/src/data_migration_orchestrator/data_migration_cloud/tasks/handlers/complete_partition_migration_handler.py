"""
Complete partition migration handler.

This module defines the handler for COMPLETE_PARTITION_MIGRATION tasks.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    SynchronizationConfig,
)
from data_migration_orchestrator.data_migration_cloud.constants.metadata import (
    SYNC_DATA_CANDIDATE_CHECKSUM,
    SYNC_DATA_CANDIDATE_MAX_WATERMARK_VALUE,
    SYNC_DATA_CHECKSUM,
    SYNC_DATA_MAX_WATERMARK_VALUE,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.synchronization_config_service import (
    SynchronizationConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.partition_migration_status import (
    PartitionMigrationStatus,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CompletePartitionMigrationTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("tasks.handlers.complete_partition_migration")


class CompletePartitionMigrationHandler(BaseTaskHandler):
    """
    Handler for completing partition migration after COPY INTO.

    This handler updates the partition metadata status to COMPLETED and
    records synchronization metadata for incremental sync.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ):
        """
        Initialize the complete partition migration handler.

        Args:
            task_queue: The task queue for managing tasks
            warehouse_proxy: Warehouse proxy for executing status update queries

        """
        super().__init__(
            TaskPayloadKind.COMPLETE_PARTITION_MIGRATION,
            task_queue,
            warehouse_proxy,
        )
        self.sync_config_service = SynchronizationConfigService(warehouse_proxy)

    async def handle(self, task: Task) -> None:
        """
        Handle a complete partition migration task.

        Updates the partition metadata status to COMPLETED, records synchronization
        metadata, and marks the task as complete.

        Args:
            task: The task containing the CompletePartitionMigrationTaskPayload

        """
        payload: CompletePartitionMigrationTaskPayload = task.payload

        if task.id is None:
            raise ValueError(
                "Task ID is required for CompletePartitionMigrationHandler"
            )

        if self.warehouse_proxy is None:
            raise ValueError(
                "warehouse_proxy is required for CompletePartitionMigrationHandler"
            )

        partition_metadata_id = payload.partition_metadata_id

        sync_config = await self.sync_config_service.fetch_synchronization_config(
            payload.table_metadata_id
        )

        if sync_config.strategy == SyncStrategy.NONE:
            await self._complete_with_none_strategy(partition_metadata_id, task.id)
            return

        try:
            await self._update_sync_data(partition_metadata_id, sync_config)
            logger.info(
                f"Updated partition metadata {partition_metadata_id} status to COMPLETED "
                f"with sync data for strategy: {sync_config.strategy.value}"
            )
        except Exception as e:
            logger.error(
                f"Failed to update partition metadata {partition_metadata_id} status: {e}"
            )
            raise

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    async def _complete_with_none_strategy(
        self, partition_metadata_id: int, task_id: int
    ) -> None:
        """
        Fast path for NONE sync strategy.

        Update partition status and complete the task in a single Snowflake
        scripting block instead of two round-trips.
        """
        query = f"""
            BEGIN
                UPDATE {qualified_migration_schema()}.PARTITION_METADATA
                SET
                    MIGRATION_STATUS = '{PartitionMigrationStatus.COMPLETED}',
                    MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP(),
                    SYNC_TIMESTAMP = CURRENT_TIMESTAMP()
                WHERE ID = {partition_metadata_id};

                UPDATE {qualified_migration_schema()}.TASK_QUEUE
                SET
                    STATUS = 'completed',
                    END_TIME = SYSDATE()
                WHERE ID = {task_id}
                  AND LEASED_TO = '{ExecutorType.ORCHESTRATOR.value}';
            END;
        """
        await self.warehouse_proxy.execute_sync_query(query)
        logger.info(
            f"Completed partition {partition_metadata_id} and task {task_id} "
            f"in single call (NONE strategy)"
        )

    async def _update_sync_data(
        self,
        partition_metadata_id: int,
        sync_config: SynchronizationConfig,
    ) -> None:
        """
        Update partition metadata with completed status and sync data.

        Executes a SQL query that updates the SYNCHRONIZATION_DATA VARIANT column
        directly in Snowflake based on the sync strategy.

        Args:
            partition_metadata_id: ID of the partition metadata record
            sync_config: The synchronization configuration

        """
        if sync_config.strategy == SyncStrategy.NONE:
            await self._update_status_only(partition_metadata_id)
        elif sync_config.strategy == SyncStrategy.WATERMARK:
            await self._update_watermark_sync_data(partition_metadata_id)
        elif sync_config.strategy == SyncStrategy.CHECKSUM:
            await self._update_checksum_sync_data(partition_metadata_id)
        elif sync_config.strategy == SyncStrategy.CHANGE_TRACKING:
            await self._update_change_tracking_sync_data(partition_metadata_id)
        else:
            # Unknown strategy - just update status without modifying sync data
            logger.warning(
                f"Unknown sync strategy {sync_config.strategy.value} "
                f"- updating status only"
            )
            await self._update_status_only(partition_metadata_id)

    async def _update_watermark_sync_data(self, partition_metadata_id: int) -> None:
        """
        Update sync data for WATERMARK strategy.

        Promotes candidate_max_watermark_value to max_watermark_value and removes
        the candidate field, all in a single SQL query.

        Handles the case where SYNCHRONIZATION_DATA might be NULL or might not
        have the candidate key (e.g., first-time migration or failed capture).
        """
        candidate_key = SYNC_DATA_CANDIDATE_MAX_WATERMARK_VALUE
        max_key = SYNC_DATA_MAX_WATERMARK_VALUE

        # SQL that:
        # 1. If SYNCHRONIZATION_DATA is NULL or doesn't have candidate key, keep it as-is
        # 2. If it has candidate key, promote to max_watermark_value and remove candidate
        # Uses IFF to handle NULL cases safely
        query = f"""
            UPDATE {qualified_migration_schema()}.PARTITION_METADATA
            SET
                MIGRATION_STATUS = '{PartitionMigrationStatus.COMPLETED}',
                MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP(),
                SYNCHRONIZATION_DATA = IFF(
                    SYNCHRONIZATION_DATA IS NOT NULL
                    AND SYNCHRONIZATION_DATA:"{candidate_key}" IS NOT NULL,
                    OBJECT_DELETE(
                        OBJECT_INSERT(
                            SYNCHRONIZATION_DATA,
                            '{max_key}',
                            SYNCHRONIZATION_DATA:"{candidate_key}",
                            TRUE
                        ),
                        '{candidate_key}'
                    ),
                    SYNCHRONIZATION_DATA
                ),
                SYNC_TIMESTAMP = CURRENT_TIMESTAMP()
            WHERE ID = {partition_metadata_id}
        """
        await self.warehouse_proxy.execute_sync_query(query)
        logger.debug(
            f"Updated WATERMARK sync data for partition {partition_metadata_id}"
        )

    async def _update_checksum_sync_data(self, partition_metadata_id: int) -> None:
        """
        Update sync data for CHECKSUM strategy.

        Promotes candidate_checksum to checksum and removes the candidate field,
        all in a single SQL query.

        Handles the case where SYNCHRONIZATION_DATA might be NULL or might not
        have the candidate key (e.g., if checksum comparison was skipped).
        """
        candidate_key = SYNC_DATA_CANDIDATE_CHECKSUM
        checksum_key = SYNC_DATA_CHECKSUM

        # SQL that:
        # 1. If SYNCHRONIZATION_DATA is NULL or doesn't have candidate key, keep it as-is
        # 2. If it has candidate key, promote to checksum and remove candidate
        # Uses IFF to handle NULL cases safely
        query = f"""
            UPDATE {qualified_migration_schema()}.PARTITION_METADATA
            SET
                MIGRATION_STATUS = '{PartitionMigrationStatus.COMPLETED}',
                MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP(),
                SYNCHRONIZATION_DATA = IFF(
                    SYNCHRONIZATION_DATA IS NOT NULL
                    AND SYNCHRONIZATION_DATA:"{candidate_key}" IS NOT NULL,
                    OBJECT_DELETE(
                        OBJECT_INSERT(
                            SYNCHRONIZATION_DATA,
                            '{checksum_key}',
                            SYNCHRONIZATION_DATA:"{candidate_key}",
                            TRUE
                        ),
                        '{candidate_key}'
                    ),
                    SYNCHRONIZATION_DATA
                ),
                SYNC_TIMESTAMP = CURRENT_TIMESTAMP()
            WHERE ID = {partition_metadata_id}
        """
        await self.warehouse_proxy.execute_sync_query(query)
        logger.debug(
            f"Updated CHECKSUM sync data for partition {partition_metadata_id}"
        )

    async def _update_change_tracking_sync_data(
        self, partition_metadata_id: int
    ) -> None:
        """Update sync data for CHANGE_TRACKING strategy."""
        # TODO(SNOW-3067427): Implement change tracking sync data updates
        # For now, just update the status
        await self._update_status_only(partition_metadata_id)
        logger.debug(
            f"Updated CHANGE_TRACKING sync data for partition {partition_metadata_id}"
        )

    async def _update_status_only(self, partition_metadata_id: int) -> None:
        """Update only the migration status without modifying sync data."""
        query = f"""
            UPDATE {qualified_migration_schema()}.PARTITION_METADATA
            SET
                MIGRATION_STATUS = '{PartitionMigrationStatus.COMPLETED}',
                MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP(),
                SYNC_TIMESTAMP = CURRENT_TIMESTAMP()
            WHERE ID = {partition_metadata_id}
        """
        await self.warehouse_proxy.execute_sync_query(query)
