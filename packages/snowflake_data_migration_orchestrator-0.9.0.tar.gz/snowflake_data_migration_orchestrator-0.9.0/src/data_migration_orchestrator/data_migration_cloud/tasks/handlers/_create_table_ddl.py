"""
DDL builders for creating target tables.

Lives in its own module (separate from ``staged_data_handler``) so that
both ``StagedDataHandler`` and the new ``target_table_creator`` helper can
import it without producing a circular dependency.

Public functions:
- :func:`apply_numeric_precision`: Append precision/scale to ``NUMBER`` types.
- :func:`build_create_table_ddl`: Build ``CREATE TABLE`` / ``CREATE ICEBERG TABLE`` DDL.
"""

from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    SNOWFLAKE_CATALOG,
    IcebergTargetConfig,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    NUMERIC_PRECISION_COL,
    NUMERIC_SCALE_COL,
)


# Default NUMBER precision/scale used when the source schema does not provide
# precision/scale. Values larger than 28 integer digits would overflow
# NUMBER(38,10) so this default leaves 28 digits of headroom — sufficient for
# typical sources and within Snowflake NUMBER's 38 total digits.
DEFAULT_NUMBER_PRECISION = 38
DEFAULT_NUMBER_SCALE = 10


def apply_numeric_precision(target_type: str, col: dict) -> str:
    """
    Append precision and scale to NUMBER types when available from source metadata.

    For types like DECIMAL(10,2), NUMERIC(18,4), MONEY, SMALLMONEY, the source
    INFORMATION_SCHEMA provides NUMERIC_PRECISION and NUMERIC_SCALE. Without this,
    we use NUMBER(38,10) to avoid "Number out of representable range" for large
    decimals (e.g. 12345678901234.5678).

    Args:
        target_type: The mapped Snowflake type (e.g., "NUMBER(20,10)", "FLOAT").
        col: Source column metadata dict with keys like 'precision', 'scale'.

    Returns:
        Target type string, potentially with (precision, scale) appended.

    """
    base = target_type.upper().split("(")[0].strip()
    if base != "NUMBER":
        return target_type

    precision = col.get(NUMERIC_PRECISION_COL)
    scale = col.get(NUMERIC_SCALE_COL)

    if precision is not None:
        precision = int(precision)
        scale = int(scale) if scale is not None else 0
        return f"NUMBER({precision},{scale})"

    return f"NUMBER({DEFAULT_NUMBER_PRECISION},{DEFAULT_NUMBER_SCALE})"


def build_create_table_ddl(
    full_table_name: str,
    column_definitions: list[str],
    iceberg_config: IcebergTargetConfig | None,
    target_table_id: Any = None,
) -> str:
    """
    Build CREATE TABLE or CREATE ICEBERG TABLE DDL.

    When ``iceberg_config`` is provided, generates a ``CREATE ICEBERG TABLE``
    statement with the appropriate catalog, external volume, and base location
    settings. Otherwise generates a standard ``CREATE TABLE`` statement.

    Args:
        full_table_name: Fully qualified target table name.
        column_definitions: List of ``"col_name TYPE"`` strings.
        iceberg_config: Iceberg configuration, or None for native tables.
        target_table_id: TableIdentifier for deriving base_location when not
            explicitly configured.

    Returns:
        DDL string ready for execution.

    """
    cols_str = ", ".join(column_definitions)

    if iceberg_config is None:
        return f"CREATE TABLE {full_table_name} ({cols_str})"

    ddl = f"CREATE ICEBERG TABLE {full_table_name} ({cols_str})"
    ddl += f"\n  CATALOG = '{iceberg_config.catalog}'"

    if iceberg_config.external_volume:
        ddl += f"\n  EXTERNAL_VOLUME = '{iceberg_config.external_volume}'"

    if iceberg_config.catalog.upper() == SNOWFLAKE_CATALOG:
        if iceberg_config.base_location_prefix:
            base_location = (
                f"{iceberg_config.base_location_prefix.rstrip('/')}/"
                f"{full_table_name.replace('.', '/')}"
            )
        elif target_table_id is not None:
            base_location = full_table_name.replace(".", "/")
        else:
            base_location = full_table_name.replace(".", "/")
        ddl += f"\n  BASE_LOCATION = '{base_location}'"

    if iceberg_config.catalog_table_name:
        ddl += f"\n  CATALOG_TABLE_NAME = '{iceberg_config.catalog_table_name}'"

    if iceberg_config.catalog_sync:
        ddl += f"\n  CATALOG_SYNC = '{iceberg_config.catalog_sync}'"

    return ddl


__all__ = ["apply_numeric_precision", "build_create_table_ddl"]
