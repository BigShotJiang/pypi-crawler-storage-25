"""
Service for reusing existing partition definitions across workflows.

This module provides utilities to find and copy existing partition metadata
from previous workflows for incremental sync operations.
"""

from dataclasses import dataclass
from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_core.workflows.workflow_columns import ID
from data_migration_orchestrator.data_migration_cloud.constants.metadata import (
    MAX_VALUE,
    MIN_VALUE,
    N_ROWS,
    PARTITION_NUMBER,
    SYNC_TIMESTAMP,
    SYNCHRONIZATION_DATA,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    SyncData,
    parse_sync_data,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("tasks.handlers.partition_reuse_service")


@dataclass
class ExistingPartition:
    """Represents an existing partition from a previous workflow."""

    id: int
    partition_number: int
    min_value: Any
    max_value: Any
    n_rows: int | None
    synchronization_data: SyncData | None
    sync_timestamp: str | None


@dataclass
class CopiedTableMetadata:
    """Result of copying table metadata to a new workflow."""

    new_table_metadata_id: int
    partitions_copied: int
    source_table_metadata_id: int


class PartitionReuseService:
    """
    Service for finding and reusing existing partition definitions.

    When a workflow targets a table that was previously migrated, this service
    finds the existing partition definitions and copies them to the new workflow,
    preserving synchronization metadata for incremental sync.
    """

    def __init__(self, warehouse_proxy: Warehouse):
        """
        Initialize the partition reuse service.

        Args:
            warehouse_proxy: Proxy for executing warehouse queries

        """
        self.warehouse_proxy = warehouse_proxy

    async def find_existing_table_metadata(self, source_identifier: str) -> int | None:
        """
        Find existing TABLE_METADATA for a source table.

        Searches for the most recently preprocessed table metadata for the
        given source identifier across all workflows.

        Args:
            source_identifier: Fully qualified source table name

        Returns:
            The table_metadata_id if found, None otherwise

        """
        try:
            query = (
                f"CALL {qualified_migration_schema()}.FIND_EXISTING_TABLE_METADATA("
                f"'{source_identifier}')"
            )
            result = await self.warehouse_proxy.execute_sync_query(query)

            if not result:
                return None

            first_row = result[0]
            table_metadata_id = next(iter(first_row.values()), None)

            if table_metadata_id:
                logger.info(
                    f"Found existing table metadata {table_metadata_id} "
                    f"for {source_identifier}"
                )
            return table_metadata_id

        except Exception as e:
            message = (
                f"Failed to find existing table metadata for {source_identifier}: {e}"
            )
            logger.error(message)
            raise Exception(message) from e

    async def copy_table_and_partitions(
        self,
        source_table_metadata_id: int,
        new_workflow_id: int,
        table_configuration_sql: str,
    ) -> CopiedTableMetadata | None:
        """
        Copy table metadata and all partitions to a new workflow.

        Copies the TABLE_METADATA row (with the current workflow's table
        configuration) and all associated PARTITION_METADATA rows, including
        SYNCHRONIZATION_DATA (critical for incremental sync).

        Args:
            source_table_metadata_id: ID of the source table metadata to copy
            new_workflow_id: ID of the new workflow to copy to
            table_configuration_sql: SQL expression for the current table
                configuration (e.g. ``PARSE_JSON('...')``)

        Returns:
            CopiedTableMetadata with the new IDs, or None if copy failed

        """
        try:
            # Copy TABLE_METADATA with the current workflow's configuration
            copy_table_query = (
                f"CALL {qualified_migration_schema()}.COPY_TABLE_METADATA("
                f"{source_table_metadata_id}, {new_workflow_id}, {table_configuration_sql})"
            )
            result = await self.warehouse_proxy.execute_sync_query(copy_table_query)

            if not result:
                logger.error("Failed to copy table metadata - no result returned")
                return None

            first_row = result[0]
            new_table_metadata_id = next(iter(first_row.values()), None)

            if not new_table_metadata_id:
                logger.error("Failed to copy table metadata - no ID returned")
                return None

            logger.info(
                f"Copied table metadata {source_table_metadata_id} -> "
                f"{new_table_metadata_id} for workflow {new_workflow_id}"
            )

            # Copy PARTITION_METADATA
            copy_partitions_query = (
                f"CALL {qualified_migration_schema()}.COPY_PARTITION_METADATA("
                f"{source_table_metadata_id}, {new_table_metadata_id})"
            )
            result = await self.warehouse_proxy.execute_sync_query(
                copy_partitions_query
            )

            partitions_copied = 0
            if result:
                first_row = result[0]
                partitions_copied = next(iter(first_row.values()), 0) or 0

            logger.info(
                f"Copied {partitions_copied} partition(s) from table {source_table_metadata_id} "
                f"to table {new_table_metadata_id} (including SYNCHRONIZATION_DATA)"
            )

            return CopiedTableMetadata(
                new_table_metadata_id=new_table_metadata_id,
                partitions_copied=partitions_copied,
                source_table_metadata_id=source_table_metadata_id,
            )

        except Exception as e:
            logger.error(
                f"Failed to copy table and partitions from {source_table_metadata_id}: {e}"
            )
            return None

    async def get_existing_partitions(
        self, table_metadata_id: int
    ) -> list[ExistingPartition]:
        """
        Get all existing partitions for a table.

        Args:
            table_metadata_id: ID of the table metadata

        Returns:
            List of ExistingPartition objects with partition definitions

        """
        try:
            query = (
                f"CALL {qualified_migration_schema()}.GET_PARTITION_METADATA("
                f"{table_metadata_id})"
            )
            result = await self.warehouse_proxy.execute_sync_query(query)

            if not result:
                return []

            partitions = []
            for row in result:
                # Parse SYNCHRONIZATION_DATA into typed SyncData object
                raw_sync_data = row.get(SYNCHRONIZATION_DATA)
                sync_data = parse_sync_data(raw_sync_data)

                partition = ExistingPartition(
                    id=row[ID],
                    partition_number=row[PARTITION_NUMBER],
                    min_value=row.get(MIN_VALUE),
                    max_value=row.get(MAX_VALUE),
                    n_rows=row.get(N_ROWS),
                    synchronization_data=sync_data,
                    sync_timestamp=row.get(SYNC_TIMESTAMP),
                )
                partitions.append(partition)

            logger.debug(
                f"Retrieved {len(partitions)} existing partition(s) "
                f"for table_metadata_id={table_metadata_id}"
            )
            return partitions

        except Exception as e:
            logger.error(
                f"Failed to get existing partitions for table {table_metadata_id}: {e}"
            )
            return []
