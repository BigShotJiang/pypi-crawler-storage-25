"""
Handler for TEARDOWN_SNOWPIPE tasks.

Drops a Snowpipe after migration work is complete (or has failed).
This handler is always used as a cleanup task so it runs regardless
of whether predecessors succeeded or failed.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.utils.pipe_utils import (
    build_drop_pipe_sql,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    TeardownSnowpipePayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)


logger = get_logger("tasks.handlers.teardown_snowpipe")


class TeardownSnowpipeHandler(BaseTaskHandler):
    """Handler that drops a Snowpipe during cleanup."""

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ):
        """Initialize the teardown snowpipe handler."""
        super().__init__(
            TaskPayloadKind.TEARDOWN_SNOWPIPE,
            task_queue,
            warehouse_proxy,
        )

    async def handle(self, task: Task) -> None:
        """Drop the Snowpipe and mark the task as completed."""
        payload: TeardownSnowpipePayload = task.payload

        logger.info("Dropping Snowpipe %s", payload.pipe_name)
        await self.warehouse_proxy.execute_sync_query(
            build_drop_pipe_sql(payload.pipe_name)
        )

        if task.id is None:
            raise ValueError("Task ID is required")

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )
