"""
Partition migration status enum.

This module defines the valid status values for partition migration tracking.
"""

from enum import StrEnum


class PartitionMigrationStatus(StrEnum):
    """
    Enum representing valid migration status values for partition metadata.

    Used to track the state of partitions throughout the migration lifecycle.
    These values are stored in the PARTITION_METADATA.MIGRATION_STATUS column.
    """

    EXTRACTING = "EXTRACTING"
    """Partition is being extracted from source or awaiting extraction."""

    LOADING = "LOADING"
    """Partition data is being loaded into target table."""

    COMPLETED = "COMPLETED"
    """Partition has been successfully migrated."""

    FAILED = "FAILED"
    """Partition migration failed."""
