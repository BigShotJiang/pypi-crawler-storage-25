"""
Core constants and enumerations for the data migration orchestrator.

This module contains fundamental constants and enums used across the entire
orchestrator package.
"""

from enum import StrEnum
from typing import Self


class SyncStrategy(StrEnum):
    """
    Synchronization strategies for incremental sync.

    Determines how partitions are checked for changes during incremental sync:
    - NONE: No incremental sync, always perform full partition extraction (default)
    - CHECKSUM: Compare checksums to detect partition changes, re-sync only changed partitions
    - WATERMARK: Use a column (e.g., UPDATED_AT) to track and sync only new/modified rows
    - CHANGE_TRACKING: Use a change tracking table to identify changed rows (future)
    """

    NONE = "none"
    CHECKSUM = "checksum"
    WATERMARK = "watermark"
    CHANGE_TRACKING = "change-tracking"

    @classmethod
    def from_string(cls, strategy: str) -> Self:
        """
        Convert string to SyncStrategy enum.

        Raises:
            NotImplementedError: If sync strategy is not supported.

        """
        normalized_strategy = strategy.lower()
        supported_strategies = [
            cls.NONE.value,
            cls.CHECKSUM.value,
            cls.WATERMARK.value,
            cls.CHANGE_TRACKING.value,
        ]
        if normalized_strategy not in supported_strategies:
            supported_str = ", ".join(f"'{s}'" for s in supported_strategies)
            raise NotImplementedError(
                f"Supported sync strategies are {supported_str}, got '{normalized_strategy}'"
            )
        return cls(normalized_strategy)


# Default synchronization strategy used when not specified in configuration
DEFAULT_SYNCHRONIZATION_STRATEGY = SyncStrategy.NONE
