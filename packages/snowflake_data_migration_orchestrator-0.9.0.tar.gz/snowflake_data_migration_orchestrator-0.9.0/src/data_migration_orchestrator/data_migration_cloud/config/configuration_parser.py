"""
Parser for workflow table configurations.

This module provides the ConfigurationParser class for parsing and validating
raw table configuration dictionaries into strongly-typed TableConfiguration objects.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config import (
    configuration_properties_keys,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    DEFAULT_TARGET_TABLE_TYPE,
    ICEBERG_TARGET_TABLE_TYPE,
    SNOWFLAKE_CATALOG,
    ExtractionConfig,
    IcebergTargetConfig,
    LoadingConfig,
    LoadingStrategy,
    LoadSegmentationConfig,
    PartitionSizeConfig,
    SynchronizationConfig,
    TableConfiguration,
    TableIdentifier,
    parse_partition_size,
)


logger = get_logger("utils.configuration_parser")


class ConfigurationError(Exception):
    """Raised when table configuration is invalid."""

    pass


class ConfigurationParser:
    """
    Parses and validates workflow table configurations.

    This class handles the conversion of raw dictionary configurations
    (as received from workflow definitions) into strongly-typed
    TableConfiguration objects with proper validation.

    """

    # Fields that should be deep-merged (nested objects)
    _DEEP_MERGE_FIELDS = frozenset(
        {
            configuration_properties_keys.SOURCE,
            configuration_properties_keys.TARGET,
            configuration_properties_keys.SYNCHRONIZATION,
            configuration_properties_keys.EXTRACTION,
            configuration_properties_keys.LOADING,
        }
    )

    # Fields that should be shallow-replaced (collections/lists)
    _SHALLOW_REPLACE_FIELDS = frozenset(
        {
            configuration_properties_keys.COLUMN_TYPE_MAPPINGS,
            configuration_properties_keys.COLUMN_NAME_MAPPINGS,
            configuration_properties_keys.COLUMN_NAMES_TO_PARTITION_BY,
            configuration_properties_keys.PRIMARY_KEY_COLUMNS,
        }
    )

    def _deep_merge_dicts(self, default: dict, override: dict) -> dict:
        """
        Deep merge two dictionaries. Override values take precedence.

        For nested dictionaries, the merge is recursive. For other types,
        the override value completely replaces the default.

        Args:
            default: The default dictionary to merge into
            override: The dictionary with override values

        Returns:
            A new dictionary with merged values

        """
        result = dict(default)
        for key, override_value in override.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(override_value, dict)
            ):
                # Recursively merge nested dicts
                result[key] = self._deep_merge_dicts(result[key], override_value)
            else:
                # Override value takes precedence
                result[key] = override_value
        return result

    def _merge_table_configs(self, default: dict, table: dict) -> dict:
        """
        Merge a table configuration with defaults using appropriate strategy per field.

        Merging rules:
        - Nested objects (source, target, synchronization): Deep merge
        - Collection fields (columnTypeMappings, etc.): Shallow replace (table replaces default)
        - Scalar fields: Table value overrides default

        Args:
            default: The default table configuration dictionary
            table: The table-specific configuration dictionary

        Returns:
            A new dictionary with merged configuration

        """
        result = dict(default)

        for key, table_value in table.items():
            if key in self._DEEP_MERGE_FIELDS:
                # Deep merge for nested objects
                default_value = result.get(key, {})
                if isinstance(default_value, dict) and isinstance(table_value, dict):
                    result[key] = self._deep_merge_dicts(default_value, table_value)
                else:
                    result[key] = table_value
            elif key in self._SHALLOW_REPLACE_FIELDS:
                # Shallow replace for collections - table value completely replaces default
                result[key] = table_value
            else:
                # Scalar fields - table value overrides default
                result[key] = table_value

        return result

    def parse_table_configuration(self, raw_config: dict) -> TableConfiguration:
        """
        Parse a raw table configuration dictionary into a TableConfiguration.

        Args:
            raw_config: Raw dictionary from workflow configuration containing
                       'source', 'target', and optional 'columnNamesToPartitionBy'
                       and 'columnTypeMappings' fields.

        Returns:
            A validated TableConfiguration object.

        Raises:
            ConfigurationError: If required fields are missing or invalid.

        """
        # Parse source endpoint
        source_dict = raw_config.get(configuration_properties_keys.SOURCE)
        if not source_dict:
            raise ConfigurationError(
                "Missing required field 'source' in table configuration"
            )
        source = self._parse_table_endpoint(source_dict, "source")

        # Parse target endpoint
        target_dict = raw_config.get(configuration_properties_keys.TARGET)
        if not target_dict:
            raise ConfigurationError(
                "Missing required field 'target' in table configuration"
            )
        target = self._parse_table_endpoint(target_dict, "target")

        # Parse partition columns
        partition_columns = self._parse_partition_columns(raw_config)

        # Parse column type mappings (optional)
        column_type_mappings = self._parse_column_type_mappings(raw_config)

        # Parse column name mappings (optional)
        column_name_mappings = self._parse_column_name_mappings(raw_config)

        # Parse primary key columns (optional, table-level metadata)
        primary_key_columns = self._parse_primary_key_columns(raw_config)

        # Parse synchronization configuration (optional)
        synchronization = self._parse_synchronization_config(
            raw_config, source.fully_qualified_friendly_name, primary_key_columns
        )

        # Parse extraction configuration (optional)
        extraction = self._parse_extraction_config(
            raw_config, source.fully_qualified_friendly_name
        )

        # Parse partition size configuration (optional)
        partition_size = self._parse_partition_size_config(
            raw_config, source.fully_qualified_friendly_name
        )

        # Parse where clause criteria (optional)
        where_clause_criteria = self._parse_where_clause_criteria(raw_config)

        # Parse target table type and Iceberg configuration (optional)
        target_table_type, iceberg_config = self._parse_iceberg_target_config(
            raw_config, source.fully_qualified_friendly_name
        )

        # Parse loading configuration (optional — warehouse vs Snowpipe)
        loading = self._parse_loading_config(
            raw_config, source.fully_qualified_friendly_name
        )

        # Parse load segmentation configuration (optional)
        load_segmentation = self._parse_load_segmentation_config(
            raw_config, source.fully_qualified_friendly_name
        )

        return TableConfiguration(
            source=source,
            target=target,
            partition_columns=partition_columns,
            column_type_mappings=column_type_mappings,
            column_name_mappings=column_name_mappings,
            primary_key_columns=primary_key_columns,
            synchronization=synchronization,
            extraction=extraction,
            partition_size=partition_size,
            where_clause_criteria=where_clause_criteria,
            target_table_type=target_table_type,
            iceberg_config=iceberg_config,
            loading=loading,
            load_segmentation=load_segmentation,
        )

    def parse_tables(
        self,
        tables_config: list[dict],
        default_config: dict | None = None,
    ) -> list[TableConfiguration]:
        """
        Parse all table configurations from a workflow.

        If a default_config is provided, each table configuration is merged with
        the defaults before parsing. This allows tables to have partial configurations
        that inherit from a common template.

        Merging rules:
        - Nested objects (source, target, synchronization): Deep merge
        - Collection fields (columnTypeMappings, etc.): Table value replaces default
        - Scalar fields: Table value overrides default

        Args:
            tables_config: List of raw table configuration dictionaries.
            default_config: Optional default configuration to merge with each table.

        Returns:
            List of validated TableConfiguration objects.

        Raises:
            ConfigurationError: If any table configuration is invalid after merging.

        """
        configurations = []
        for i, raw_config in enumerate(tables_config):
            try:
                # Merge with defaults if provided
                if default_config:
                    merged_config = self._merge_table_configs(
                        default_config, raw_config
                    )
                else:
                    merged_config = raw_config

                config = self.parse_table_configuration(merged_config)
                configurations.append(config)
            except ConfigurationError as e:
                raise ConfigurationError(
                    f"Invalid configuration for table at index {i}: {e}"
                ) from e
        return configurations

    def _parse_table_endpoint(self, endpoint_dict: dict, name: str) -> TableIdentifier:
        """
        Parse a table endpoint (source or target) from configuration.

        Args:
            endpoint_dict: Dictionary containing tableName, schemaName, databaseName
            name: Name of the endpoint for error messages ('source' or 'target')

        Returns:
            TableIdentifier object.

        Raises:
            ConfigurationError: If required fields are missing.

        """
        missing_fields: list[str] = []

        def get_required(key: str, field_name: str) -> str:
            value = endpoint_dict.get(key)
            if not value:
                missing_fields.append(field_name)
                return ""
            return value

        database_name = get_required(
            configuration_properties_keys.DATABASE_NAME, "databaseName"
        )
        schema_name = get_required(
            configuration_properties_keys.SCHEMA_NAME, "schemaName"
        )
        table_name = get_required(configuration_properties_keys.TABLE_NAME, "tableName")

        if missing_fields:
            raise ConfigurationError(
                f"Missing required field(s) in {name}: {', '.join(missing_fields)}"
            )

        return TableIdentifier(
            database_name=database_name,
            schema_name=schema_name,
            table_name=table_name,
        )

    def _parse_partition_columns(self, raw_config: dict) -> list[str]:
        """
        Parse partition columns from configuration.

        An empty or absent list means "no partitioning" -- the table will be
        extracted as a single full-table partition without any WHERE clause
        filtering. This is only recommended for very small tables; for larger
        tables a partition column should be specified to enable parallel
        extraction.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            List of partition column names (may be empty).

        """
        column_names = raw_config.get(
            configuration_properties_keys.COLUMN_NAMES_TO_PARTITION_BY
        )

        if not column_names:
            return []

        return list(column_names)

    def _parse_column_type_mappings(self, raw_config: dict) -> dict[str, str]:
        """
        Parse column type mappings from configuration.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            Dict mapping source types to target types (empty if not specified).

        """
        mappings_list = raw_config.get(
            configuration_properties_keys.COLUMN_TYPE_MAPPINGS, []
        )

        if not mappings_list:
            return {}

        column_type_mappings: dict[str, str] = {}
        for i, mapping_dict in enumerate(mappings_list):
            source_type = mapping_dict.get(configuration_properties_keys.SOURCE_TYPE)
            target_type = mapping_dict.get(configuration_properties_keys.TARGET_TYPE)

            if not source_type or not target_type:
                logger.warning(
                    f"Skipping invalid column type mapping at index {i}: "
                    f"missing sourceType or targetType"
                )
                continue

            # Normalize to uppercase
            column_type_mappings[source_type.upper()] = target_type.upper()

        if column_type_mappings:
            logger.info(
                f"Parsed {len(column_type_mappings)} custom column type mapping(s)"
            )

        return column_type_mappings

    @staticmethod
    def _resolve_snowflake_identifier(name: str) -> str:
        """
        Resolve a name following Snowflake identifier semantics.

        Double-quoted names are kept as-is (quotes preserved) so downstream
        code can distinguish case-sensitive identifiers from case-insensitive
        ones via ``is_already_quoted``.  Unquoted names are uppercased,
        matching Snowflake's default behaviour.
        """
        if name.startswith('"') and name.endswith('"'):
            return name
        return name.upper()

    def _parse_column_name_mappings(self, raw_config: dict) -> dict[str, str]:
        """
        Parse column name mappings from configuration.

        Target names are resolved following Snowflake identifier semantics:
        double-quoted names keep their quotes (so downstream code can detect
        case-sensitivity via ``is_already_quoted``), while unquoted names are
        uppercased.  Downstream SQL generation should use
        ``quote_identifier_snowflake`` rather than manual ``f'"{name}"'``.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            Dict mapping source column names to target column names (empty if not specified).

        """
        mappings_list = raw_config.get(
            configuration_properties_keys.COLUMN_NAME_MAPPINGS, []
        )

        if not mappings_list:
            return {}

        column_name_mappings: dict[str, str] = {}
        for i, mapping_dict in enumerate(mappings_list):
            source_name = mapping_dict.get(configuration_properties_keys.SOURCE_NAME)
            target_name = mapping_dict.get(configuration_properties_keys.TARGET_NAME)

            if not source_name or not target_name:
                logger.warning(
                    f"Skipping invalid column name mapping at index {i}: "
                    f"missing sourceName or targetName"
                )
                continue

            target_name = self._resolve_snowflake_identifier(target_name)

            column_name_mappings[source_name] = target_name

        if column_name_mappings:
            logger.info(
                f"Parsed {len(column_name_mappings)} custom column name mapping(s)"
            )

        return column_name_mappings

    def _parse_where_clause_criteria(self, raw_config: dict) -> str | None:
        """
        Parse optional whereClauseCriteria from configuration.

        Strips a leading ``WHERE`` keyword (case-insensitive) if present,
        trims whitespace, and ignores non-string values.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            Cleaned WHERE condition string, or None if not specified / empty.

        """
        criteria = raw_config.get(configuration_properties_keys.WHERE_CLAUSE_CRITERIA)

        if not criteria:
            return None

        if not isinstance(criteria, str):
            logger.warning(
                f"Ignoring non-string whereClauseCriteria value: "
                f"{type(criteria).__name__}"
            )
            return None

        cleaned = criteria.strip()
        if not cleaned:
            return None

        upper = cleaned.upper()
        if upper.startswith("WHERE "):
            cleaned = cleaned[6:].strip()
        elif upper == "WHERE":
            cleaned = ""

        if not cleaned:
            return None

        logger.info(f"Parsed whereClauseCriteria: {cleaned}")
        return cleaned

    def _parse_primary_key_columns(self, raw_config: dict) -> list[str]:
        """
        Parse primary key columns from configuration.

        Args:
            raw_config: Raw table configuration dictionary

        Returns:
            List of primary key column names (empty if not specified).

        """
        pk_columns = raw_config.get(configuration_properties_keys.PRIMARY_KEY_COLUMNS)

        if not pk_columns:
            return []

        logger.info(f"Parsed {len(pk_columns)} primary key column(s)")

        return list(pk_columns)

    def _parse_synchronization_config(
        self, raw_config: dict, table_name: str, primary_key_columns: list[str]
    ) -> SynchronizationConfig:
        """
        Parse synchronization configuration from table configuration.

        Args:
            raw_config: Raw table configuration dictionary
            table_name: Table name for error messages
            primary_key_columns: List of primary key columns from table configuration

        Returns:
            SynchronizationConfig object (uses defaults if not specified).

        Raises:
            ConfigurationError: If watermark strategy is specified without watermarkColumn,
                or if trackModifications is enabled without primaryKeyColumns.

        """
        sync_dict = raw_config.get(configuration_properties_keys.SYNCHRONIZATION)

        if not sync_dict:
            # Return default configuration
            return SynchronizationConfig()

        # Parse strategy
        strategy_str = sync_dict.get(configuration_properties_keys.STRATEGY)
        if strategy_str:
            try:
                strategy = SyncStrategy.from_string(strategy_str)
            except NotImplementedError as e:
                raise ConfigurationError(
                    f"Invalid synchronization strategy for {table_name}: {e}"
                ) from e
        else:
            # Use default strategy if not specified
            strategy = SynchronizationConfig().strategy

        # Parse watermark column (required for WATERMARK strategy)
        watermark_column = sync_dict.get(configuration_properties_keys.WATERMARK_COLUMN)

        if strategy == SyncStrategy.WATERMARK and not watermark_column:
            raise ConfigurationError(
                f"Synchronization strategy 'watermark' requires 'watermarkColumn' "
                f"to be specified for table {table_name}"
            )

        # Parse track_modifications (optional, defaults to False)
        track_modifications = sync_dict.get(
            configuration_properties_keys.TRACK_MODIFICATIONS, False
        )

        # Validate: trackModifications requires primaryKeyColumns for WATERMARK strategy
        if (
            strategy == SyncStrategy.WATERMARK
            and track_modifications
            and not primary_key_columns
        ):
            raise ConfigurationError(
                f"Synchronization with 'trackModifications' enabled requires "
                f"'primaryKeyColumns' to be specified for table {table_name}"
            )

        logger.info(
            f"Parsed synchronization config for {table_name}: "
            f"strategy={strategy.value}, watermark_column={watermark_column}, "
            f"track_modifications={track_modifications}"
        )

        return SynchronizationConfig(
            strategy=strategy,
            watermark_column=watermark_column,
            track_modifications=track_modifications,
        )

    def _parse_extraction_config(
        self, raw_config: dict, table_name: str
    ) -> ExtractionConfig:
        """
        Parse extraction configuration from table configuration.

        Uses a tagged union pattern where the 'strategy' field determines the type
        and which additional fields are relevant.

        Args:
            raw_config: Raw table configuration dictionary
            table_name: Table name for error messages

        Returns:
            ExtractionConfig object (uses defaults if not specified).

        Raises:
            ConfigurationError: If UNLOAD strategy is specified without externalStage.

        """
        extraction_dict = raw_config.get(configuration_properties_keys.EXTRACTION)

        if not extraction_dict:
            return ExtractionConfig()

        # Parse strategy type
        strategy_str = extraction_dict.get(configuration_properties_keys.STRATEGY)
        if strategy_str:
            try:
                strategy = ExtractionStrategy.from_string(strategy_str)
            except ValueError as e:
                raise ConfigurationError(
                    f"Invalid extraction strategy for {table_name}: {e}"
                ) from e
        else:
            strategy = ExtractionConfig().strategy

        # Parse external_stage (required for UNLOAD strategy)
        external_stage = extraction_dict.get(
            configuration_properties_keys.EXTERNAL_STAGE
        )

        if strategy == ExtractionStrategy.UNLOAD and not external_stage:
            raise ConfigurationError(
                f"Extraction strategy 'unload' requires 'externalStage' "
                f"to be specified for table {table_name}"
            )

        logger.info(
            f"Parsed extraction config for {table_name}: "
            f"strategy={strategy.value}, external_stage={external_stage}"
        )

        return ExtractionConfig(
            strategy=strategy,
            external_stage=external_stage,
        )

    def _parse_partition_size_config(
        self, raw_config: dict, table_name: str
    ) -> PartitionSizeConfig:
        """
        Parse partition size from flat ``targetPartitionSizeMb`` / ``targetPartitionSizeRows`` fields.

        Delegates to the shared ``parse_partition_size`` helper in strict
        mode, wrapping any ``ValueError`` into a ``ConfigurationError``
        with table-name context.

        """
        target_mb = raw_config.get(
            configuration_properties_keys.TARGET_PARTITION_SIZE_MB
        )
        target_rows = raw_config.get(
            configuration_properties_keys.TARGET_PARTITION_SIZE_ROWS
        )
        try:
            result = parse_partition_size(target_mb, target_rows, strict=True)
        except ValueError as exc:
            raise ConfigurationError(f"Partition size for {table_name}: {exc}") from exc

        if not result.is_auto:
            logger.info(f"Parsed partition size for {table_name}: {result}")

        return result

    def _parse_iceberg_target_config(
        self, raw_config: dict, table_name: str
    ) -> tuple[str, IcebergTargetConfig | None]:
        """
        Parse target table type and Iceberg configuration from table configuration.

        Reads ``tableType`` from the ``target`` section. When set to ``"iceberg"``,
        also parses the ``icebergConfig`` sub-object with catalog, external volume,
        base location prefix, and optional catalog sync settings.

        Args:
            raw_config: Raw table configuration dictionary
            table_name: Table name for error messages

        Returns:
            Tuple of (target_table_type, iceberg_config). iceberg_config is None
            when target_table_type is "native".

        Raises:
            ConfigurationError: If Iceberg target is specified without required fields.

        """
        target_dict = raw_config.get(configuration_properties_keys.TARGET, {})
        # Explicit JSON null must not bypass the default; dict.get only substitutes
        # when the key is absent (null still returns None).
        table_type = target_dict.get(configuration_properties_keys.TABLE_TYPE)
        if table_type is None:
            table_type = DEFAULT_TARGET_TABLE_TYPE

        if table_type not in (DEFAULT_TARGET_TABLE_TYPE, ICEBERG_TARGET_TABLE_TYPE):
            raise ConfigurationError(
                f"Invalid target tableType '{table_type}' for {table_name}: "
                f"must be '{DEFAULT_TARGET_TABLE_TYPE}' or '{ICEBERG_TARGET_TABLE_TYPE}'"
            )

        if table_type == DEFAULT_TARGET_TABLE_TYPE:
            return table_type, None

        # Parse Iceberg configuration
        iceberg_dict = target_dict.get(configuration_properties_keys.ICEBERG_CONFIG)
        if not iceberg_dict:
            raise ConfigurationError(
                f"Target tableType 'iceberg' requires 'icebergConfig' "
                f"to be specified for table {table_name}"
            )

        catalog = iceberg_dict.get(
            configuration_properties_keys.CATALOG, SNOWFLAKE_CATALOG
        )
        external_volume = iceberg_dict.get(
            configuration_properties_keys.EXTERNAL_VOLUME
        )
        catalog_table_name = iceberg_dict.get(
            configuration_properties_keys.CATALOG_TABLE_NAME
        )

        # Snowflake-managed Iceberg requires external_volume
        if catalog.upper() == SNOWFLAKE_CATALOG and not external_volume:
            raise ConfigurationError(
                f"Snowflake-managed Iceberg tables require 'externalVolume' "
                f"in icebergConfig for table {table_name}"
            )

        # External catalog requires catalog_table_name
        if catalog.upper() != SNOWFLAKE_CATALOG and not catalog_table_name:
            raise ConfigurationError(
                f"External catalog Iceberg tables require 'catalogTableName' "
                f"in icebergConfig for table {table_name}"
            )

        iceberg_config = IcebergTargetConfig.from_dict(iceberg_dict)

        logger.info(
            f"Parsed Iceberg target config for {table_name}: "
            f"catalog={iceberg_config.catalog}, "
            f"external_volume={iceberg_config.external_volume}"
        )

        return table_type, iceberg_config

    def _parse_loading_config(self, raw_config: dict, table_name: str) -> LoadingConfig:
        """
        Parse loading configuration (warehouse COPY INTO vs Snowpipe).

        Args:
            raw_config: Raw table configuration dictionary
            table_name: Table name for error messages

        Returns:
            LoadingConfig with the parsed strategy, defaulting to WAREHOUSE.

        Raises:
            ConfigurationError: If the strategy value is not recognised.

        """
        loading_dict = raw_config.get(configuration_properties_keys.LOADING)

        if not loading_dict or not isinstance(loading_dict, dict):
            return LoadingConfig()

        strategy_str = loading_dict.get(configuration_properties_keys.STRATEGY)
        if not strategy_str:
            return LoadingConfig()

        try:
            strategy = LoadingStrategy.from_string(strategy_str)
        except ValueError:
            raise ConfigurationError(
                f"Invalid loading strategy '{strategy_str}' for {table_name}. "
                f"Supported values: {[s.value for s in LoadingStrategy]}"
            ) from None

        return LoadingConfig(strategy=strategy)

    def _parse_load_segmentation_config(
        self, raw_config: dict, table_name: str
    ) -> LoadSegmentationConfig | None:
        """
        Parse load segmentation configuration from table configuration.

        Args:
            raw_config: Raw table configuration dictionary
            table_name: Table name for error messages

        Returns:
            LoadSegmentationConfig if configured, None otherwise.

        Raises:
            ConfigurationError: If the configuration object is malformed.

        """
        seg_dict = raw_config.get(configuration_properties_keys.LOAD_SEGMENTATION)

        if seg_dict is None:
            return None

        if not isinstance(seg_dict, dict):
            raise ConfigurationError(
                f"loadSegmentation for {table_name} must be an object"
            )

        target_segment_size_mb = seg_dict.get(
            configuration_properties_keys.TARGET_SEGMENT_SIZE_MB
        )

        if target_segment_size_mb is None:
            raise ConfigurationError(
                f"loadSegmentation for {table_name} requires 'targetSegmentSizeMb'"
            )

        if not isinstance(target_segment_size_mb, int) or target_segment_size_mb <= 0:
            raise ConfigurationError(
                f"'targetSegmentSizeMb' for {table_name} must be a positive integer, "
                f"got {target_segment_size_mb}"
            )

        logger.info(
            f"Parsed loadSegmentation for {table_name}: "
            f"targetSegmentSizeMb={target_segment_size_mb}"
        )

        return LoadSegmentationConfig(
            target_segment_size_mb=target_segment_size_mb,
        )
