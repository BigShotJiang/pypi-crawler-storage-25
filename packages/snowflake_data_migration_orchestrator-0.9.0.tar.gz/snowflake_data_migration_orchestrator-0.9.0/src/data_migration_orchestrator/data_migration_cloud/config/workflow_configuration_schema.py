"""
Pydantic schema models for structural validation of workflow configurations.

These models validate the raw JSON configuration dict (types, required fields,
unknown keys) before the ConfigurationParser performs semantic validation
and transformation into domain objects.

The standalone ``validate_workflow_configuration`` function is the public entry
point. It can be called from the workflow initializer, a REST API endpoint, a
CLI pre-check, or any other execution path that needs to validate a workflow
configuration.
"""

import re

from dataclasses import dataclass

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    VALID_ICEBERG_STRATEGIES,
    TargetTableType,
)


MAX_SUPPORTED_MAJOR_SCHEMA_VERSION = 1

_VERSION_PATTERN = re.compile(r"^\d+(\.\d+){0,2}$")


@dataclass(frozen=True)
class VersionNumber:
    """Parsed semantic version with major, minor, and patch components."""

    major: int
    minor: int = 0
    patch: int = 0

    @staticmethod
    def parse(value: str) -> "VersionNumber":
        """
        Parse a version string like ``"1"``, ``"1.2"``, or ``"1.2.3"``.

        Missing components default to 0.

        Raises:
            ValueError: If *value* does not match the expected pattern.

        """
        if not _VERSION_PATTERN.match(value):
            raise ValueError(
                f"Invalid version format '{value}': expected 'major', "
                f"'major.minor', or 'major.minor.patch' (e.g. '1', '1.2', '1.2.3')"
            )
        parts = value.split(".")
        return VersionNumber(
            major=int(parts[0]),
            minor=int(parts[1]) if len(parts) > 1 else 0,
            patch=int(parts[2]) if len(parts) > 2 else 0,
        )


class TableEndpointSchema(BaseModel):
    """Schema for a source or target table endpoint."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    database_name: str | None = Field(default=None, alias="databaseName")
    schema_name: str | None = Field(default=None, alias="schemaName")
    table_name: str | None = Field(default=None, alias="tableName")


class IcebergConfigSchema(BaseModel):
    """Schema for Iceberg-specific target configuration."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    catalog: str | None = None
    external_volume: str | None = Field(default=None, alias="externalVolume")
    base_location_prefix: str | None = Field(default=None, alias="baseLocationPrefix")
    catalog_table_name: str | None = Field(default=None, alias="catalogTableName")
    catalog_sync: str | None = Field(default=None, alias="catalogSync")
    source_data_stage: str | None = Field(default=None, alias="sourceDataStage")
    migration_strategy: str | None = Field(default=None, alias="migrationStrategy")

    @field_validator("migration_strategy")
    @classmethod
    def migration_strategy_must_be_valid(cls, v: str | None) -> str | None:
        """Only known Iceberg migration strategies are accepted."""
        if v is not None and v not in VALID_ICEBERG_STRATEGIES:
            raise ValueError(
                f"Invalid migrationStrategy '{v}': "
                f"must be one of {', '.join(sorted(VALID_ICEBERG_STRATEGIES))}"
            )
        return v


class TargetEndpointSchema(TableEndpointSchema):
    """
    Schema for a target table endpoint.

    Extends the base endpoint with optional Iceberg table configuration
    (``tableType`` and ``icebergConfig``).
    """

    table_type: str = Field(
        default=TargetTableType.NATIVE,
        alias="tableType",
    )
    iceberg_config: IcebergConfigSchema | None = Field(
        default=None, alias="icebergConfig"
    )

    @field_validator("table_type", mode="before")
    @classmethod
    def table_type_coerce_none_to_native(cls, v: object) -> object:
        """Treat omitted or JSON-null ``tableType`` as native (matches parser defaults)."""
        if v is None:
            return TargetTableType.NATIVE
        return v

    @field_validator("table_type")
    @classmethod
    def table_type_must_be_valid(cls, v: str | TargetTableType) -> str:
        """Only ``"native"`` and ``"iceberg"`` are accepted."""
        if v not in (TargetTableType.NATIVE, TargetTableType.ICEBERG):
            raise ValueError(f"Invalid tableType '{v}': must be 'native' or 'iceberg'")
        return str(v)


class ColumnTypeMappingSchema(BaseModel):
    """Schema for a single column type mapping entry."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    source_type: str = Field(alias="sourceType")
    target_type: str = Field(alias="targetType")


class ColumnNameMappingSchema(BaseModel):
    """Schema for a single column name mapping entry."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    source_name: str = Field(alias="sourceName")
    target_name: str = Field(alias="targetName")


class SynchronizationSchema(BaseModel):
    """Schema for the synchronization configuration block."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    strategy: str | None = None
    watermark_column: str | None = Field(default=None, alias="watermarkColumn")
    track_modifications: bool | None = Field(default=None, alias="trackModifications")


class ExtractionSchema(BaseModel):
    """Schema for the extraction strategy configuration block."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    strategy: str | None = None
    external_stage: str | None = Field(default=None, alias="externalStage")


class LoadingSchema(BaseModel):
    """Schema for the loading strategy configuration block."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    strategy: str | None = None


class LoadSegmentationSchema(BaseModel):
    """Schema for post-upload load segmentation configuration."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    target_segment_size_mb: int = Field(alias="targetSegmentSizeMb", gt=0)


class TableConfigurationSchema(BaseModel):
    """Schema for a single table configuration entry."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    source: TableEndpointSchema | None = None
    target: TargetEndpointSchema | None = None
    column_names_to_partition_by: list[str] | None = Field(
        default=None,
        alias="columnNamesToPartitionBy",
        description=(
            "Columns used to partition data during extraction. "
            "An empty array disables partitioning (the table is extracted as a single unit), "
            "which is only recommended for very small tables."
        ),
    )
    column_type_mappings: list[ColumnTypeMappingSchema] | None = Field(
        default=None, alias="columnTypeMappings"
    )
    column_name_mappings: list[ColumnNameMappingSchema] | None = Field(
        default=None, alias="columnNameMappings"
    )
    primary_key_columns: list[str] | None = Field(
        default=None, alias="primaryKeyColumns"
    )
    synchronization: SynchronizationSchema | None = None
    extraction: ExtractionSchema | None = None
    loading: LoadingSchema | None = None
    target_partition_size_mb: int | None = Field(
        default=None,
        alias="targetPartitionSizeMb",
        gt=0,
        description="Target partition size in MB. Mutually exclusive with targetPartitionSizeRows.",
    )
    target_partition_size_rows: int | None = Field(
        default=None,
        alias="targetPartitionSizeRows",
        gt=0,
        description="Target partition size in rows. Mutually exclusive with targetPartitionSizeMb.",
    )
    where_clause_criteria: str | None = Field(default=None, alias="whereClauseCriteria")
    load_segmentation: LoadSegmentationSchema | None = Field(
        default=None,
        alias="loadSegmentation",
        description=(
            "Post-upload load segmentation. When set, the orchestrator splits "
            "a single COPY INTO into multiple statements, each targeting a "
            "subset of staged files grouped by targetSegmentSizeMb."
        ),
    )

    @model_validator(mode="after")
    def _mutually_exclusive_partition_size(self) -> "TableConfigurationSchema":
        """Ensure targetPartitionSizeMb and targetPartitionSizeRows are not both set."""
        if (
            self.target_partition_size_mb is not None
            and self.target_partition_size_rows is not None
        ):
            raise ValueError(
                "Only one of 'targetPartitionSizeMb' or "
                "'targetPartitionSizeRows' may be specified"
            )
        return self


class WorkflowConfigurationSchema(BaseModel):
    """
    Top-level schema for a Data Migration Workflow configuration.

    Validates structural correctness of the raw JSON configuration dict.
    Semantic validation (e.g. watermark requires watermarkColumn) is handled
    separately by ConfigurationParser.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    schema_version: str | None = Field(default=None, alias="schemaVersion")
    tables: list[TableConfigurationSchema]
    default_table_configuration: TableConfigurationSchema | None = Field(
        default=None, alias="defaultTableConfiguration"
    )
    affinity: str | None = None

    @field_validator("schema_version")
    @classmethod
    def schema_version_must_be_supported(cls, v: str | None) -> str | None:
        """Validate format and major-version compatibility of schemaVersion."""
        if v is None:
            return v
        parsed = VersionNumber.parse(v)
        if parsed.major > MAX_SUPPORTED_MAJOR_SCHEMA_VERSION:
            raise ValueError(
                f"Schema version '{v}' is not supported; "
                f"maximum supported major version is {MAX_SUPPORTED_MAJOR_SCHEMA_VERSION}"
            )
        return v

    @field_validator("tables")
    @classmethod
    def tables_must_not_be_empty(
        cls,
        v: list[TableConfigurationSchema],
    ) -> list[TableConfigurationSchema]:
        """Ensure the tables list contains at least one entry."""
        if len(v) == 0:
            raise ValueError("'tables' must contain at least one table configuration")
        return v


def validate_workflow_configuration(
    configuration: dict | None,
) -> WorkflowConfigurationSchema:
    """
    Validate a raw workflow configuration dict.

    This is the public entry point for configuration validation. It can be
    called from any execution path (workflow initializer, API, CLI, etc.)
    independently.

    Args:
        configuration: The raw configuration dict from the workflow, or None.

    Returns:
        The validated WorkflowConfigurationSchema model.

    Raises:
        ConfigurationError: If the configuration is None or structurally invalid.

    """
    if configuration is None:
        raise ConfigurationError("Workflow configuration must not be None")

    try:
        return WorkflowConfigurationSchema.model_validate(configuration)
    except Exception as e:
        raise ConfigurationError(f"Invalid workflow configuration: {e}") from e
