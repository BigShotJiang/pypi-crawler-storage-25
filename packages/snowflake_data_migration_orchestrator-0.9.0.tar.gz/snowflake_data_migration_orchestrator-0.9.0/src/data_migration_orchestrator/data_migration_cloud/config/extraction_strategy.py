from enum import StrEnum
from typing import Self


class ExtractionStrategy(StrEnum):
    """
    Extraction strategies for data migration.

    Determines how data is extracted from the source database.
    - REGULAR: Regular extraction strategy (default)
    - UNLOAD: Unload strategy (for Snowflake)
    """

    REGULAR = "regular"
    UNLOAD = "unload"

    @classmethod
    def from_string(cls, extraction_strategy: str) -> Self:
        """
        Convert string to ExtractionStrategy enum.

        Args:
            extraction_strategy: String representation of the extraction strategy

        Returns:
            ExtractionStrategy enum value

        """
        normalized = extraction_strategy.lower()
        return cls(normalized)


# Default extraction strategy (full data extraction)
DEFAULT_EXTRACTION_STRATEGY = ExtractionStrategy.REGULAR
