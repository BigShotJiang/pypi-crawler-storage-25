"""
Data Migration Dashboard.

Monitor the progress of cloud data migration workflows.
Designed for Streamlit in Snowflake (SiS).

The dashboard is organized around **tables** (the primary user-facing concept),
with workflow/execution detail hidden behind an advanced/debug toggle.
"""

from __future__ import annotations

from typing import Any

import pandas as pd
import streamlit as st

from snowflake.snowpark.context import get_active_session


try:
    from sis_streamlit_metadata import migration_schema_for_streamlit_dashboard
except ModuleNotFoundError:
    from data_migration_orchestrator.utils.sis_streamlit_metadata import (
        migration_schema_for_streamlit_dashboard,
    )

try:
    from dashboard_aggregation import (
        COL_CLOUD_STAGE,
        COL_EXAMPLE_ERROR,
        COL_FAILED_PARTITIONS,
        COL_LAST_ERROR_MESSAGE,
        COL_LATEST_WORKFLOW_ID,
        COL_LOADED_PARTITIONS,
        COL_PROGRESS_PCT,
        COL_RUNS_COUNT,
        COL_STATUS,
        COL_TABLE_NAME,
        COL_TOTAL_PARTITIONS,
        COL_TOTAL_ROWS,
        STATUS_COMPLETE,
        STATUS_FAILED,
        STATUS_IN_PROGRESS,
        STATUS_NOT_STARTED,
        aggregate_migration_tables_by_name,
        compute_migration_progress_pct,
        compute_migration_row_status,
        filter_by_table_search,
    )
except ModuleNotFoundError:
    from data_migration_orchestrator.utils.dashboard_aggregation import (  # type: ignore[no-redef]
        COL_CLOUD_STAGE,
        COL_EXAMPLE_ERROR,
        COL_FAILED_PARTITIONS,
        COL_LAST_ERROR_MESSAGE,
        COL_LATEST_WORKFLOW_ID,
        COL_LOADED_PARTITIONS,
        COL_PROGRESS_PCT,
        COL_RUNS_COUNT,
        COL_STATUS,
        COL_TABLE_NAME,
        COL_TOTAL_PARTITIONS,
        COL_TOTAL_ROWS,
        STATUS_COMPLETE,
        STATUS_FAILED,
        STATUS_IN_PROGRESS,
        STATUS_NOT_STARTED,
        aggregate_migration_tables_by_name,
        compute_migration_progress_pct,
        compute_migration_row_status,
        filter_by_table_search,
    )

try:
    from dashboard_export import (
        build_snapshot_csv,
        per_tab_filename,
        prepare_export_dataframe,
        snapshot_filename,
        to_csv_bytes,
    )
except ModuleNotFoundError:
    from data_migration_orchestrator.utils.dashboard_export import (  # type: ignore[no-redef]
        build_snapshot_csv,
        per_tab_filename,
        prepare_export_dataframe,
        snapshot_filename,
        to_csv_bytes,
    )


st.set_page_config(
    page_title="Data Migration Dashboard",
    page_icon="🔄",
    layout="wide",
)

# Get active Snowflake session (SiS provides this automatically).
session = get_active_session()

# ---- Cache TTLs (seconds) -------------------------------------------------
# Raise these to reduce query volume; the explicit "Refresh data" button
# bypasses the cache for users who need immediate freshness.
_TTL_WORKFLOWS = 120
_TTL_OVERVIEW = 60
_TTL_TABLES = 45
_TTL_ERRORS = 45
_TTL_TASKS = 30
# Row caps on unbounded tables — prevent dashboard stalls on huge workflows.
_ERROR_ROW_LIMIT = 1000
_TASK_ROW_LIMIT = 1000

_FILENAME_PREFIX = "dm"

# ---- SQL helpers ----------------------------------------------------------


def run_query(sql: str) -> pd.DataFrame:
    """Execute a query and return results as a pandas DataFrame."""
    return session.sql(sql).to_pandas()


def _where_clause(conditions: list[str]) -> str:
    return ("WHERE " + " AND ".join(conditions)) if conditions else ""


def _sql_int(value: int | None) -> str:
    """Format an int literal or raise if not an int (prevent injection)."""
    if not isinstance(value, int):
        raise TypeError(f"expected int, got {type(value).__name__}")
    return str(value)


def _sql_str(value: str) -> str:
    """Format a string literal, escaping single quotes."""
    return "'" + str(value).replace("'", "''") + "'"


# ---- Cached queries -------------------------------------------------------


@st.cache_data(ttl=_TTL_WORKFLOWS)
def get_workflows() -> dict[int, str]:
    """Fetch workflows with progress: id → name (from WORKFLOW table)."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        df = run_query(
            f"""
            SELECT DISTINCT tp.WORKFLOW_ID, w.NAME
            FROM {qm}.TABLE_PROGRESS tp
            INNER JOIN {qm}.WORKFLOW w ON tp.WORKFLOW_ID = w.ID
            ORDER BY tp.WORKFLOW_ID DESC
            """
        )
        if len(df) > 0:
            return dict(
                zip(df["WORKFLOW_ID"].tolist(), df["NAME"].tolist(), strict=False)
            )
        return {}
    except Exception:
        return {}


@st.cache_data(ttl=_TTL_OVERVIEW)
def get_overview_metrics(workflow_id: int | None = None) -> pd.Series | None:
    """Fetch high-level migration metrics, optionally filtered by workflow."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        where_clause = (
            f"WHERE WORKFLOW_ID = {_sql_int(workflow_id)}" if workflow_id else ""
        )
        df = run_query(
            f"""
            SELECT
                COUNT(DISTINCT WORKFLOW_ID) as total_workflows,
                COUNT(DISTINCT TABLE_ID) as total_tables,
                COALESCE(SUM(TOTAL_PARTITIONS), 0) as total_partitions,
                COALESCE(SUM(LOADED_PARTITIONS), 0) as loaded_partitions,
                COALESCE(SUM(FAILED_PARTITIONS), 0) as failed_partitions,
                COALESCE(SUM(PARTITIONS_IN_EXTRACTION_PHASE), 0) as extracting,
                COALESCE(SUM(PARTITIONS_IN_LOADING_PHASE), 0) as loading,
                COALESCE(SUM(TOTAL_ROWS), 0) as total_rows,
                COUNT_IF(TOTAL_ROWS IS NULL) as tables_with_unknown_rows
            FROM {qm}.TABLE_PROGRESS
            {where_clause}
            """
        )
        return df.iloc[0] if len(df) > 0 else None
    except Exception:
        return None


@st.cache_data(ttl=_TTL_OVERVIEW)
def get_workflow_summary() -> pd.DataFrame:
    """Workflow-level rollup with bucket/stage metadata."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        df = run_query(
            f"""
            SELECT
                tp.WORKFLOW_ID as WORKFLOW_ID,
                COUNT(DISTINCT tp.TABLE_ID) as TABLES,
                COALESCE(SUM(tp.TOTAL_PARTITIONS), 0) as TOTAL_PARTITIONS,
                COALESCE(SUM(tp.LOADED_PARTITIONS), 0) as LOADED,
                COALESCE(SUM(tp.FAILED_PARTITIONS), 0) as FAILED,
                COALESCE(SUM(tp.PARTITIONS_IN_EXTRACTION_PHASE), 0)
                + COALESCE(SUM(tp.PARTITIONS_IN_LOADING_PHASE), 0) as IN_PROGRESS,
                COALESCE(SUM(tp.TOTAL_ROWS), 0) as TOTAL_ROWS,
                CASE
                    WHEN COALESCE(SUM(tp.TOTAL_PARTITIONS), 0) > 0
                    THEN ROUND(COALESCE(SUM(tp.LOADED_PARTITIONS), 0) * 100.0
                               / SUM(tp.TOTAL_PARTITIONS), 1)
                    ELSE 0
                END as PROGRESS_PCT,
                MAX(w.NAME) as NAME,
                MAX(w.TARGET_CLOUD_URL) as CLOUD_STAGE,
                MAX(w.TARGET_CLOUD_STAGE_NAME) as STAGE_NAME,
                MAX(w.LAST_ERROR_MESSAGE) as LAST_ERROR,
                MAX(w.LAST_WARNING_MESSAGE) as LAST_WARNING
            FROM {qm}.TABLE_PROGRESS tp
            LEFT JOIN {qm}.WORKFLOW w ON tp.WORKFLOW_ID = w.ID
            GROUP BY tp.WORKFLOW_ID
            ORDER BY tp.WORKFLOW_ID DESC
            """
        )
        if len(df) == 0:
            return df
        df = df.rename(columns={c: str(c).upper() for c in df.columns})
        col_order = [
            "WORKFLOW_ID",
            "NAME",
            "TABLES",
            "TOTAL_PARTITIONS",
            "LOADED",
            "FAILED",
            "IN_PROGRESS",
            "PROGRESS_PCT",
            "TOTAL_ROWS",
            "CLOUD_STAGE",
            "STAGE_NAME",
            "LAST_ERROR",
            "LAST_WARNING",
        ]
        return df[[c for c in col_order if c in df.columns]]
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=_TTL_TABLES)
def get_table_progress(workflow_id: int | None = None) -> pd.DataFrame:
    """Fetch table-level progress joined with workflow bucket/stage metadata."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        where_clause = (
            f"WHERE tpe.WORKFLOW_ID = {_sql_int(workflow_id)}" if workflow_id else ""
        )
        return run_query(
            f"""
            SELECT
                tpe.WORKFLOW_ID,
                tpe.TABLE_ID,
                tpe.TABLE_NAME,
                tpe.HAS_BEEN_PREPROCESSED,
                COALESCE(tpe.TOTAL_PARTITIONS, 0) as TOTAL_PARTITIONS,
                COALESCE(tpe.PARTITIONS_IN_EXTRACTION_PHASE, 0) as PARTITIONS_IN_EXTRACTION_PHASE,
                COALESCE(tpe.PARTITIONS_IN_LOADING_PHASE, 0) as PARTITIONS_IN_LOADING_PHASE,
                COALESCE(tpe.LOADED_PARTITIONS, 0) as LOADED_PARTITIONS,
                COALESCE(tpe.FAILED_PARTITIONS, 0) as FAILED_PARTITIONS,
                COALESCE(tpe.TOTAL_ROWS, 0) as TOTAL_ROWS,
                tpe.EXAMPLE_ERROR_MESSAGE,
                tpe.EXAMPLE_WARNING_MESSAGE,
                w.TARGET_CLOUD_URL as CLOUD_STAGE,
                w.TARGET_CLOUD_STAGE_NAME as STAGE_NAME
            FROM {qm}.TABLE_PROGRESS_WITH_EXAMPLE_ERROR tpe
            LEFT JOIN {qm}.WORKFLOW w ON tpe.WORKFLOW_ID = w.ID
            {where_clause}
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=_TTL_ERRORS)
def get_error_logs(
    workflow_id: int | None = None,
    table_name: str | None = None,
    limit: int = _ERROR_ROW_LIMIT,
) -> pd.DataFrame:
    """Fetch error logs (LIMITed), optionally filtered by workflow and/or table."""
    try:
        conditions: list[str] = []
        if workflow_id:
            conditions.append(f"WORKFLOW_ID = {_sql_int(workflow_id)}")
        if table_name and table_name != "All tables":
            conditions.append(f"TABLE_NAME = {_sql_str(table_name)}")
        qm = migration_schema_for_streamlit_dashboard()
        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                TABLE_NAME,
                PARTITION_NUMBER,
                COALESCE(PARTITION_ROWS, 0) as PARTITION_ROWS,
                TASK_NAME,
                TASK_START_TIME,
                TASK_END_TIME,
                LAST_ERROR_MESSAGE
            FROM {qm}.DATA_MIGRATION_ERROR
            {_where_clause(conditions)}
            ORDER BY TASK_START_TIME DESC
            LIMIT {_sql_int(limit)}
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=_TTL_TASKS)
def get_task_queue_executor_types(workflow_id: int | None) -> list[str]:
    """Distinct EXECUTOR_TYPE values, optionally scoped to one workflow."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        wf_clause = (
            f"WHERE WORKFLOW_ID = {_sql_int(workflow_id)}"
            if workflow_id is not None
            else ""
        )
        df = run_query(
            f"""
            SELECT DISTINCT EXECUTOR_TYPE
            FROM {qm}.TASK_QUEUE
            {wf_clause}
            ORDER BY EXECUTOR_TYPE
            """
        )
        if len(df) == 0:
            return []
        col = df.columns[0]
        return [str(x) for x in df[col].dropna().tolist() if str(x).strip() != ""]
    except Exception:
        return []


@st.cache_data(ttl=_TTL_TASKS)
def get_task_queue(
    workflow_id: int | None,
    status_filter: str,
    executor_type: str | None,
    limit: int = _TASK_ROW_LIMIT,
) -> pd.DataFrame:
    """TASK_QUEUE rows with optional workflow, status bucket, and executor filters."""
    try:
        conditions: list[str] = []
        if workflow_id is not None:
            conditions.append(f"WORKFLOW_ID = {_sql_int(workflow_id)}")
        if status_filter == "non_terminal":
            conditions.append("STATUS NOT IN ('completed', 'failed', 'abandoned')")
        elif status_filter == "completed":
            conditions.append("STATUS = 'completed'")
        elif status_filter == "failed":
            conditions.append("STATUS IN ('failed', 'abandoned')")
        elif status_filter == "executing":
            conditions.append("STATUS = 'executing'")
        elif status_filter != "all":
            return pd.DataFrame()

        if executor_type:
            conditions.append(f"EXECUTOR_TYPE = {_sql_str(executor_type)}")

        qm = migration_schema_for_streamlit_dashboard()
        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                ID,
                NAME,
                EXECUTOR_TYPE,
                STATUS,
                PRIORITY,
                AFFINITY,
                LAST_ERROR_MESSAGE,
                FAILURES,
                PAYLOAD,
                LEASING_TIME,
                CREATION_TIME,
                START_TIME,
                END_TIME
            FROM {qm}.TASK_QUEUE
            {_where_clause(conditions)}
            ORDER BY NAME
            LIMIT {_sql_int(limit)}
            """
        )
    except Exception:
        return pd.DataFrame()


# ---- Display helpers -------------------------------------------------------


# Columns that are implementation detail and hidden unless advanced=True.
_INTERNAL_TABLE_COLUMNS = ("TABLE_ID", "HAS_BEEN_PREPROCESSED", "STAGE_NAME")
_INTERNAL_ERROR_COLUMNS = ("TASK_NAME",)

# User-facing labels for the Tables view (applied only in the on-screen df;
# CSV export preserves raw column names for automation stability).
_TABLE_COLUMN_LABELS = {
    COL_TABLE_NAME: "Table",
    COL_STATUS: "Status",
    COL_PROGRESS_PCT: "% complete",
    COL_TOTAL_ROWS: "Total rows",
    COL_TOTAL_PARTITIONS: "Total partitions",
    COL_LOADED_PARTITIONS: "Loaded partitions",
    COL_FAILED_PARTITIONS: "Failed partitions",
    "PARTITIONS_IN_EXTRACTION_PHASE": "Extracting",
    "PARTITIONS_IN_LOADING_PHASE": "Loading",
    COL_CLOUD_STAGE: "Cloud stage",
    COL_LAST_ERROR_MESSAGE: "Last error",
    COL_LATEST_WORKFLOW_ID: "Latest workflow id",
    COL_RUNS_COUNT: "Runs",
    COL_EXAMPLE_ERROR: "Example error",
}

_BASIC_TABLE_VIEW_ORDER = (
    "Table",
    "Status",
    "% complete",
    "Total rows",
    "Failed partitions",
    "Cloud stage",
    "Last error",
    "Runs",
)


def _format_int_column(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Coerce a column to int64 for display (NaN → 0)."""
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype("int64")
    return df


def _format_row_count_column(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """
    Format a row-count column for display.

    Shows integer counts with thousands separators and renders NaN/None as
    ``—`` so users can distinguish "row count not tracked" from "genuinely
    zero rows". The migration worker only persists ``PARTITION_METADATA.N_ROWS``
    for single-partition tables today, so multi-partition tables surface as
    NULL in the view.
    """
    if col not in df.columns:
        return df
    numeric = pd.to_numeric(df[col], errors="coerce")
    df[col] = numeric.apply(lambda v: "—" if pd.isna(v) else f"{int(v):,}")
    return df


def _download_button(
    *,
    label: str,
    df: pd.DataFrame,
    tab_name: str,
    workflow_id: int | None,
    key: str,
    drop_cols: tuple[str, ...] = (),
) -> None:
    """
    Render a CSV download link for a dataframe.

    Uses an HTML anchor with a ``data:text/csv;base64,...`` href instead of
    ``st.download_button`` because the built-in button generates a presigned
    S3 stage URL that certain browser extensions mangle by appending the
    page title to the signature, causing ``SignatureDoesNotMatch`` errors.
    The data-URI approach embeds the CSV bytes directly in the page so the
    browser never contacts S3 and the download works everywhere.

    The CSV payload always includes internal columns (drop_cols is used only
    to remove truly sensitive or useless fields, not to hide the advanced view).
    """
    import base64

    if df is None or len(df) == 0:
        return
    export_df = prepare_export_dataframe(df, drop_cols=drop_cols)
    csv_bytes = to_csv_bytes(export_df)
    b64 = base64.b64encode(csv_bytes).decode("ascii")
    filename = per_tab_filename(_FILENAME_PREFIX, tab_name, workflow_id=workflow_id)
    # The ``key`` argument is accepted for backward compatibility but unused
    # by the anchor path — anchors don't need session-state keys the way
    # st.download_button does.
    _ = key
    href = f"data:text/csv;base64,{b64}"
    st.markdown(
        f'<a href="{href}" download="{filename}" '
        'style="display:inline-block;padding:0.35rem 0.9rem;'
        "background-color:#f0f2f6;border:1px solid #d9dce4;"
        "border-radius:0.35rem;text-decoration:none;color:#0f1116;"
        'font-size:0.88rem;margin:0.15rem 0;">'
        f"{label}</a>",
        unsafe_allow_html=True,
    )


# ---- Sidebar --------------------------------------------------------------


st.title("🔄 Data migration dashboard")

with st.sidebar:
    st.header("🔍 Filters")

    if st.button("🔄 Refresh data"):
        st.cache_data.clear()

    workflows = get_workflows()
    wf_display = {
        wf_id: (name or f"Workflow {wf_id}") for wf_id, name in workflows.items()
    }
    workflow_options = ["All workflows"] + [wf_display[wid] for wid in wf_display]
    name_to_id = {display: wid for wid, display in wf_display.items()}

    selected_workflow_str = st.selectbox(
        "Workflow",
        options=workflow_options,
        index=0,
        key="workflow_filter",
        help="Secondary filter. Workflows are an execution detail; "
        "the main view is organized around tables.",
        disabled=len(workflows) == 0,
    )

    selected_workflow: int | None = (
        None
        if selected_workflow_str == "All workflows"
        else name_to_id.get(selected_workflow_str)
    )

    table_search = st.text_input(
        "Table search",
        value="",
        key="table_search",
        help="Case-insensitive substring match on the table name. "
        "Applied across every table-driven view.",
        placeholder="e.g. SALES or DB.SCHEMA.ORDERS",
    )

    st.markdown("---")
    advanced_mode = st.checkbox(
        "Show advanced / debug views",
        value=False,
        key="advanced_mode",
        help="Reveal raw internal columns, the Workflows tab, and the Tasks "
        "(task queue) debug tab. Turn on only when debugging.",
    )

    if len(workflows) == 0:
        st.warning("No workflows found in the database.")

    st.markdown("---")
    st.caption("📦 Export all-tab snapshot for offline analysis")
    # The snapshot button renders below the sidebar body once the main content
    # has materialized the needed dataframes — see `render_snapshot_button`.
    snapshot_slot = st.empty()


# ---- Build tab list -------------------------------------------------------

_BASIC_TABS: tuple[str, ...] = (
    "📋 Tables",
    "⚠️ Errors",
    "📊 Overview",
)
_ADVANCED_TABS: tuple[str, ...] = (
    "🔀 Workflows",
    "📌 Tasks",
)

tab_labels = list(_BASIC_TABS)
if advanced_mode:
    tab_labels += list(_ADVANCED_TABS)

tabs = st.tabs(tab_labels)
tab_by_name: dict[str, Any] = dict(zip(tab_labels, tabs, strict=True))

# ---- Tables tab (primary) --------------------------------------------------

# Pull once; reused across tabs.
table_df = get_table_progress(selected_workflow)
filtered_table_df = filter_by_table_search(table_df, table_search)

with tab_by_name["📋 Tables"]:
    if selected_workflow is not None:
        st.info(f"Showing tables for **{selected_workflow_str}**")
    if table_search:
        st.caption(f"Table filter: `{table_search}`")

    if len(filtered_table_df) == 0:
        if len(table_df) == 0:
            st.info(
                "No table progress data available. Ensure the migration workflow "
                "is running and has begun extracting partitions."
            )
        else:
            st.info("No tables match the current search.")
    else:
        # Vectorized status + progress for the current (per-workflow) view.
        display_df = filtered_table_df.copy()
        display_df[COL_STATUS] = compute_migration_row_status(
            display_df[COL_TOTAL_PARTITIONS],
            display_df[COL_LOADED_PARTITIONS],
            display_df[COL_FAILED_PARTITIONS],
        )
        display_df[COL_PROGRESS_PCT] = compute_migration_progress_pct(
            display_df[COL_TOTAL_PARTITIONS],
            display_df[COL_LOADED_PARTITIONS],
        )

        # Aggregate across workflows when the user has not pinned a single one.
        if selected_workflow is None:
            agg_df = aggregate_migration_tables_by_name(filtered_table_df)
            primary_df = agg_df
        else:
            primary_df = display_df

        # Summary KPIs.
        total_tables = int(primary_df[COL_TABLE_NAME].nunique())
        tables_failed = int(
            (primary_df[COL_STATUS] == STATUS_FAILED).sum()
            if COL_STATUS in primary_df.columns
            else 0
        )
        tables_complete = int(
            (primary_df[COL_STATUS] == STATUS_COMPLETE).sum()
            if COL_STATUS in primary_df.columns
            else 0
        )
        tables_in_progress = int(
            (primary_df[COL_STATUS] == STATUS_IN_PROGRESS).sum()
            if COL_STATUS in primary_df.columns
            else 0
        )
        tables_not_started = int(
            (primary_df[COL_STATUS] == STATUS_NOT_STARTED).sum()
            if COL_STATUS in primary_df.columns
            else 0
        )
        # Row counts may be NULL for tables whose migration path did not
        # persist PARTITION_METADATA.N_ROWS. Sum over non-null values only and
        # count how many tables still lack a row count so we can annotate the
        # KPI honestly.
        row_series = pd.to_numeric(
            primary_df.get(COL_TOTAL_ROWS, pd.Series(dtype=float)),
            errors="coerce",
        )
        total_rows = int(row_series.dropna().sum())
        tables_missing_rows = int(row_series.isna().sum())

        cols = st.columns(5)
        with cols[0]:
            st.metric("Tables", f"{total_tables:,}")
        with cols[1]:
            st.metric(
                "Failed",
                f"{tables_failed:,}",
                delta="needs attention" if tables_failed > 0 else None,
                delta_color="inverse",
            )
        with cols[2]:
            st.metric("Complete", f"{tables_complete:,}")
        with cols[3]:
            st.metric("In progress", f"{tables_in_progress:,}")
        with cols[4]:
            st.metric("Total rows", f"{total_rows:,}")
        if tables_not_started > 0:
            st.caption(f"{tables_not_started:,} table(s) have not yet started.")
        if tables_missing_rows > 0:
            st.caption(
                f"Row count not tracked for {tables_missing_rows:,} table(s) "
                "— shown as — in the table below."
            )

        # On-screen view: friendly labels, internal columns hidden in basic mode.
        drop_for_view = tuple(c for c in _INTERNAL_TABLE_COLUMNS if not advanced_mode)
        # In advanced mode also drop EXAMPLE_WARNING_MESSAGE which is rarely useful.
        if not advanced_mode:
            drop_for_view = drop_for_view + (
                COL_EXAMPLE_ERROR,
                "EXAMPLE_WARNING_MESSAGE",
            )

        on_screen_df = prepare_export_dataframe(
            primary_df,
            drop_cols=drop_for_view,
            rename_map=_TABLE_COLUMN_LABELS,
        )
        on_screen_df = _format_row_count_column(on_screen_df, "Total rows")
        # Prefer compact column order in basic view.
        if not advanced_mode:
            on_screen_df = prepare_export_dataframe(
                on_screen_df, column_order=_BASIC_TABLE_VIEW_ORDER
            )

        _download_button(
            label="Download this view as CSV",
            df=primary_df,
            tab_name="tables",
            workflow_id=selected_workflow,
            key="download_tables",
        )
        st.dataframe(on_screen_df, use_container_width=True)

        # Drill-down: per-table detail.
        st.markdown("### Inspect a table")
        inspect_options = ["(select a table)"] + sorted(
            primary_df[COL_TABLE_NAME].dropna().unique().tolist()
        )
        inspected = st.selectbox(
            "Table",
            options=inspect_options,
            index=0,
            key="tables_inspect",
            label_visibility="collapsed",
        )
        if inspected and inspected != "(select a table)":
            executions = display_df[display_df[COL_TABLE_NAME] == inspected].copy()
            if len(executions) > 0:
                exec_view_cols = [
                    "WORKFLOW_ID",
                    COL_STATUS,
                    COL_PROGRESS_PCT,
                    COL_TOTAL_ROWS,
                    COL_TOTAL_PARTITIONS,
                    COL_LOADED_PARTITIONS,
                    COL_FAILED_PARTITIONS,
                    COL_CLOUD_STAGE,
                    COL_EXAMPLE_ERROR,
                ]
                exec_rename = {
                    "WORKFLOW_ID": "Workflow id",
                    COL_STATUS: "Status",
                    COL_PROGRESS_PCT: "% complete",
                    COL_TOTAL_ROWS: "Total rows",
                    COL_TOTAL_PARTITIONS: "Total partitions",
                    COL_LOADED_PARTITIONS: "Loaded partitions",
                    COL_FAILED_PARTITIONS: "Failed partitions",
                    COL_CLOUD_STAGE: "Cloud stage",
                    COL_EXAMPLE_ERROR: "Example error",
                }
                exec_view = prepare_export_dataframe(
                    executions,
                    rename_map=exec_rename,
                    column_order=[
                        exec_rename[c]
                        for c in exec_view_cols
                        if c in executions.columns
                    ],
                )
                _download_button(
                    label="Download executions as CSV",
                    df=executions,
                    tab_name=f"table_detail_{inspected}",
                    workflow_id=selected_workflow,
                    key="download_table_executions",
                )
                st.caption(
                    f"{len(executions)} workflow execution(s) touched **{inspected}**."
                )
                st.dataframe(exec_view, use_container_width=True)

                # Recent errors for this table.
                table_errors = get_error_logs(
                    selected_workflow, inspected, limit=_ERROR_ROW_LIMIT
                )
                if len(table_errors) > 0:
                    st.markdown(f"**Recent errors for `{inspected}`**")
                    _download_button(
                        label="Download table errors as CSV",
                        df=table_errors,
                        tab_name=f"table_errors_{inspected}",
                        workflow_id=selected_workflow,
                        key="download_table_errors",
                    )
                    st.dataframe(table_errors, use_container_width=True)
                else:
                    st.caption("No recorded errors for this table.")
            else:
                st.caption("No per-execution data to show.")

# ---- Errors tab (table-centric) -------------------------------------------

error_df = get_error_logs(selected_workflow)
if table_search:
    error_df = filter_by_table_search(error_df, table_search)

with tab_by_name["⚠️ Errors"]:
    if selected_workflow is not None:
        st.info(f"Showing errors for **{selected_workflow_str}**")

    if len(error_df) == 0:
        st.success("No errors found. All partitions are processing successfully.")
    else:
        rows_note = f"{len(error_df):,} error record(s)" + (
            f" (limited to {_ERROR_ROW_LIMIT:,})"
            if len(error_df) >= _ERROR_ROW_LIMIT
            else ""
        )
        st.caption(rows_note)

        _download_button(
            label="Download errors as CSV",
            df=error_df,
            tab_name="errors",
            workflow_id=selected_workflow,
            key="download_errors",
        )

        flat_view = st.checkbox(
            "Show flat error list",
            value=False,
            key="errors_flat_view",
            help="Switch from the table-grouped view to the raw error list.",
        )

        if flat_view:
            st.dataframe(error_df, use_container_width=True)
        else:
            # Group errors by table; show expanders sorted by most-recent-first.
            error_by_table = error_df.groupby(COL_TABLE_NAME, sort=False)
            ordered_tables = (
                error_df.sort_values(by="TASK_START_TIME", ascending=False)[
                    COL_TABLE_NAME
                ]
                .drop_duplicates()
                .tolist()
            )
            for table_name in ordered_tables:
                rows = error_by_table.get_group(table_name)
                most_recent_ts = rows["TASK_START_TIME"].max()
                latest_msg = (
                    str(rows.iloc[0]["LAST_ERROR_MESSAGE"]) if len(rows) else ""
                )
                preview = latest_msg[:120] + ("…" if len(latest_msg) > 120 else "")
                with st.expander(
                    f"**{table_name}** — {len(rows)} error(s), latest: {most_recent_ts} — {preview}",
                    expanded=False,
                ):
                    st.dataframe(rows, use_container_width=True)

# ---- Overview tab ---------------------------------------------------------

with tab_by_name["📊 Overview"]:
    metrics = get_overview_metrics(selected_workflow)
    if metrics is None:
        st.warning(
            "No migration data available. Ensure the migration workflow is running."
        )
    else:
        total_workflows = int(metrics["TOTAL_WORKFLOWS"] or 0)
        total_tables = int(metrics["TOTAL_TABLES"] or 0)
        total_partitions = int(metrics["TOTAL_PARTITIONS"] or 0)
        loaded = int(metrics["LOADED_PARTITIONS"] or 0)
        failed = int(metrics["FAILED_PARTITIONS"] or 0)
        extracting = int(metrics["EXTRACTING"] or 0)
        loading = int(metrics["LOADING"] or 0)
        total_rows = int(metrics.get("TOTAL_ROWS", 0) or 0)
        tables_with_unknown_rows = int(metrics.get("TABLES_WITH_UNKNOWN_ROWS", 0) or 0)
        progress_pct = (loaded / total_partitions * 100) if total_partitions > 0 else 0
        in_progress = extracting + loading

        if selected_workflow is not None:
            st.info(f"Showing data for **{selected_workflow_str}**")

        cols = st.columns(6 if selected_workflow is None else 5)
        col_idx = 0
        if selected_workflow is None:
            with cols[col_idx]:
                st.metric("Workflows", f"{total_workflows:,}")
            col_idx += 1
        with cols[col_idx]:
            st.metric("Tables", f"{total_tables:,}")
        with cols[col_idx + 1]:
            st.metric("Total rows", f"{total_rows:,}")
        with cols[col_idx + 2]:
            st.metric(
                "Loaded partitions",
                f"{loaded:,}",
                delta=f"{progress_pct:.1f}% complete",
            )
        with cols[col_idx + 3]:
            st.metric(
                "In progress",
                f"{in_progress:,}",
                delta=f"{extracting:,} extracting, {loading:,} loading",
                delta_color="off",
            )
        with cols[col_idx + 4]:
            st.metric(
                "Failed",
                f"{failed:,}",
                delta="needs attention" if failed > 0 else None,
                delta_color="inverse",
            )

        if tables_with_unknown_rows > 0:
            st.caption(
                f"Total rows excludes {tables_with_unknown_rows:,} table(s) "
                "whose row count was not recorded by the migration worker. "
                "See the Tables tab for per-table detail."
            )

        col1, col2 = st.columns(2)
        with col1:
            st.subheader("Overall progress")
            if total_partitions > 0:
                st.progress(loaded / total_partitions)
                st.caption(f"{loaded:,} of {total_partitions:,} partitions loaded")
            else:
                st.info("No partitions found")
        with col2:
            st.subheader("Partition status breakdown")
            status_data = pd.DataFrame(
                {
                    "Status": ["Loaded", "Extracting", "Loading", "Failed"],
                    "Count": [loaded, extracting, loading, failed],
                }
            )
            status_data = status_data[status_data["Count"] > 0]
            if len(status_data) > 0:
                st.bar_chart(status_data.set_index("Status"))
            else:
                st.info("No partition data available")

# ---- Workflows tab (advanced only) ----------------------------------------

workflow_df: pd.DataFrame
if advanced_mode:
    workflow_df = get_workflow_summary()
    with tab_by_name["🔀 Workflows"]:
        st.subheader("Workflow summary")
        st.caption(
            "Workflow-level view for debugging and execution audit. Tables remain "
            "the user-facing primary concept (see the **Tables** tab)."
        )
        if len(workflow_df) > 0:
            total_wf = len(workflow_df)
            completed_wf = len(workflow_df[workflow_df["PROGRESS_PCT"] == 100])
            failed_wf = len(workflow_df[workflow_df["FAILED"] > 0])

            cols = st.columns(4)
            with cols[0]:
                st.metric("Total workflows", total_wf)
            with cols[1]:
                st.metric("Completed", completed_wf)
            with cols[2]:
                st.metric(
                    "With errors",
                    failed_wf,
                    delta="needs attention" if failed_wf > 0 else None,
                    delta_color="inverse",
                )
            with cols[3]:
                st.metric("In progress", total_wf - completed_wf)

            _download_button(
                label="Download workflows as CSV",
                df=workflow_df,
                tab_name="workflows",
                workflow_id=selected_workflow,
                key="download_workflows",
            )
            st.dataframe(workflow_df, use_container_width=True)
        else:
            st.info("No workflow data available.")
else:
    workflow_df = pd.DataFrame()

# ---- Tasks tab (advanced only) --------------------------------------------

_TASK_STATUS_LABELS = (
    "All statuses",
    "Non-terminal (pending, executing, blocked)",
    "Completed",
    "Failed (failed or abandoned)",
    "Executing",
)
_TASK_STATUS_KEYS = ("all", "non_terminal", "completed", "failed", "executing")

task_df: pd.DataFrame = pd.DataFrame()
if advanced_mode:
    with tab_by_name["📌 Tasks"]:
        st.warning(
            "**Debug view.** Each **workflow** is broken down into **tasks**: one "
            "row here is one queued unit of work. This tab is intentionally detailed "
            "(payload, errors, timings). Users should prefer the **Tables** tab for "
            "status reporting."
        )
        if selected_workflow is not None:
            st.info(f"Showing tasks for **{selected_workflow_str}**")

        c1, c2 = st.columns(2)
        with c1:
            status_label = st.selectbox(
                "Task status",
                options=_TASK_STATUS_LABELS,
                index=0,
                key="tasks_status_filter",
            )
        with c2:
            executor_options = ["All executor types"] + get_task_queue_executor_types(
                selected_workflow
            )
            executor_label = st.selectbox(
                "Executor type",
                options=executor_options,
                index=0,
                key="tasks_executor_filter",
            )

        status_key = dict(zip(_TASK_STATUS_LABELS, _TASK_STATUS_KEYS, strict=True))[
            status_label
        ]
        executor_arg = (
            None if executor_label == "All executor types" else executor_label
        )
        task_df = get_task_queue(selected_workflow, status_key, executor_arg)

        if len(task_df) > 0:
            count_note = f"{len(task_df):,} task(s)" + (
                f" (limited to {_TASK_ROW_LIMIT:,})"
                if len(task_df) >= _TASK_ROW_LIMIT
                else ""
            )
            st.caption(count_note)
            _download_button(
                label="Download tasks as CSV",
                df=task_df,
                tab_name="tasks",
                workflow_id=selected_workflow,
                key="download_tasks",
            )
            st.dataframe(task_df, use_container_width=True)
        else:
            st.info("No tasks match the current filters.")

# ---- Global snapshot export -----------------------------------------------


def _build_snapshot_sections() -> dict[str, pd.DataFrame]:
    sections: dict[str, pd.DataFrame] = {}
    if len(filtered_table_df) > 0:
        sections["tables_aggregate"] = aggregate_migration_tables_by_name(
            filtered_table_df
        )
        sections["table_executions"] = filtered_table_df
    if len(error_df) > 0:
        sections["errors"] = error_df
    if advanced_mode and len(workflow_df) > 0:
        sections["workflow_summary"] = workflow_df
    if advanced_mode and len(task_df) > 0:
        sections["task_queue"] = task_df
    return sections


with snapshot_slot.container():
    sections = _build_snapshot_sections()
    has_data = any(len(df) > 0 for df in sections.values())
    if has_data:
        import base64 as _b64

        snap_bytes = build_snapshot_csv(sections)
        snap_name = snapshot_filename(_FILENAME_PREFIX, workflow_id=selected_workflow)
        snap_b64 = _b64.b64encode(snap_bytes).decode("ascii")
        st.markdown(
            f'<a href="data:text/csv;base64,{snap_b64}" download="{snap_name}" '
            'style="display:inline-block;padding:0.45rem 0.9rem;'
            "background-color:#ffeecc;border:1px solid #e0b265;"
            "border-radius:0.35rem;text-decoration:none;color:#0f1116;"
            'font-size:0.9rem;margin:0.2rem 0;" '
            "title=\"Download a multi-section CSV with every tab's data. "
            'Respects the current workflow and table-search filters.">'
            "📦 Export snapshot (CSV)</a>",
            unsafe_allow_html=True,
        )
    else:
        st.caption("No data in scope to export yet.")
