"""Constants for Snowflake stage identifiers used in data migration."""

from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


def default_internal_stage() -> str:
    """Return the default internal stage for task results and migration intermediate data."""
    return f"@{qualified_migration_schema()}.TASK_RESULTS"
