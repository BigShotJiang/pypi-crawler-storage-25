"""
Batch size calculation for optimal data extraction performance.

This module calculates a suggested batch size based on average row size,
targeting a specific memory footprint per batch.
"""

# Target size per batch in MB - tuned for memory efficiency and performance
TARGET_BATCH_SIZE_MB = 15

# Batch size boundaries
MIN_BATCH_SIZE = 1000
MAX_BATCH_SIZE = 100000
DEFAULT_BATCH_SIZE = 50000

# Conversion constant
BYTES_PER_MB = 1024 * 1024


def calculate_suggested_batch_size(row_count: int, data_size_mb: float) -> int | None:
    """
    Calculate suggested batch size based on average row size.

    Targets approximately TARGET_BATCH_SIZE_MB per batch, bounded by
    MIN_BATCH_SIZE and MAX_BATCH_SIZE.

    Args:
        row_count: Total number of rows in the table/partition.
        data_size_mb: Total data size in megabytes.

    Returns:
        Suggested batch size (number of rows), or None if calculation
        is not possible (e.g., empty table or missing data).
        When None is returned, the consumer should use DEFAULT_BATCH_SIZE.

    """
    if row_count <= 0 or data_size_mb <= 0:
        return None

    avg_row_size_mb = data_size_mb / row_count
    if avg_row_size_mb <= 0:
        return None

    suggested = int(TARGET_BATCH_SIZE_MB / avg_row_size_mb)
    return max(MIN_BATCH_SIZE, min(suggested, MAX_BATCH_SIZE))


def calculate_suggested_batch_size_from_bytes(
    avg_row_size_bytes: float,
) -> int | None:
    """
    Calculate suggested batch size from average row size in bytes.

    This is a convenience function when avg_row_size_bytes is already known
    (e.g., passed through task payloads).

    Args:
        avg_row_size_bytes: Average row size in bytes.

    Returns:
        Suggested batch size (number of rows), or None if calculation
        is not possible.

    """
    if avg_row_size_bytes <= 0:
        return None

    avg_row_size_mb = avg_row_size_bytes / BYTES_PER_MB
    suggested = int(TARGET_BATCH_SIZE_MB / avg_row_size_mb)
    return max(MIN_BATCH_SIZE, min(suggested, MAX_BATCH_SIZE))
