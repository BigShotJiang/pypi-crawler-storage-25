"""Schema validation utilities for detecting schema drift."""

from dataclasses import dataclass
from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
    TypeMappingLoader,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)
from data_migration_orchestrator.data_migration_core.queries.target_schema_queries import (
    build_table_exists_query,
    build_table_schema_query,
)


logger = get_logger("utils.schema_validator")

# Compatible type families for schema drift detection.
# Types within the same family are considered compatible when comparing schemas,
# meaning no "type_mismatch" drift will be reported.
# e.g. NUMBER and INTEGER are both numeric types and can hold similar data.
TYPE_FAMILIES: list[set[str]] = [
    {"NUMBER", "NUMERIC", "DECIMAL", "INT", "INTEGER", "BIGINT", "SMALLINT"},
    {"VARCHAR", "STRING", "TEXT", "CHAR"},
    {"TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ", "TIMESTAMP", "DATETIME"},
    {"FLOAT", "DOUBLE", "REAL"},
    {"BINARY", "VARBINARY"},
]


def _get_row_value(row: dict, key: str) -> Any:
    """Get value from row dict, handling Snowflake's uppercase/lowercase column names."""
    return row.get(key.upper()) or row.get(key.lower())


def _to_int(value: Any) -> int | None:
    """Convert value to int if not None."""
    return int(value) if value is not None else None


@dataclass
class ColumnSchema:
    """Represents a column's schema definition."""

    column_name: str
    data_type: str
    character_max_length: int | None = None
    numeric_precision: int | None = None
    numeric_scale: int | None = None
    is_nullable: str | None = None
    ordinal_position: int | None = None

    def get_full_type(self) -> str:
        """Get the full type string including precision/scale/length."""
        base = self.data_type.upper()

        if base in ("NUMBER", "NUMERIC", "DECIMAL") and self.numeric_precision:
            if self.numeric_scale is not None:
                return f"{base}({self.numeric_precision},{self.numeric_scale})"
            return f"{base}({self.numeric_precision})"

        if base in ("VARCHAR", "CHAR", "STRING", "TEXT", "BINARY", "VARBINARY"):
            if self.character_max_length:
                return f"{base}({self.character_max_length})"

        return base

    @property
    def base_type(self) -> str:
        """Get normalized base type without parameters."""
        return self.data_type.upper().split("(")[0].strip()


@dataclass
class SchemaDrift:
    """Represents a schema drift between expected and actual schemas."""

    column_name: str
    drift_type: str
    expected_type: str | None = None
    actual_type: str | None = None
    message: str = ""


@dataclass
class SchemaValidationResult:
    """Result of schema validation comparison."""

    table_exists: bool
    actual_schema: list[ColumnSchema]
    expected_schema: list[ColumnSchema]
    drifts: list[SchemaDrift]
    is_compatible: bool

    @property
    def has_drift(self) -> bool:
        """Check if there is any schema drift."""
        return len(self.drifts) > 0


class SchemaValidator:
    """Validates and compares table schemas for drift detection."""

    def __init__(self, warehouse_proxy, target_type: str = "snowflake"):
        """Initialize with a warehouse proxy and target database type."""
        self.warehouse_proxy = warehouse_proxy
        self.target_type = target_type

    async def table_exists(
        self, database_name: str, schema_name: str, table_name: str
    ) -> bool:
        """Check if a table exists in the target database."""
        query = build_table_exists_query(
            self.target_type, database_name, schema_name, table_name
        )
        try:
            result = await self.warehouse_proxy.execute_sync_query(query)
            if result:
                return int(_get_row_value(result[0], "table_exists") or 0) > 0
        except Exception as e:
            logger.debug(f"Table existence check failed: {e}")
        return False

    async def get_actual_schema(
        self, database_name: str, schema_name: str, table_name: str
    ) -> list[ColumnSchema]:
        """Get the actual schema of a table in the target database."""
        query = build_table_schema_query(
            self.target_type, database_name, schema_name, table_name
        )
        result = await self.warehouse_proxy.execute_sync_query(query)
        if not result:
            return []

        return [
            ColumnSchema(
                column_name=_get_row_value(row, "column_name"),
                data_type=_get_row_value(row, "data_type"),
                character_max_length=_to_int(
                    _get_row_value(row, "character_maximum_length")
                ),
                numeric_precision=_to_int(_get_row_value(row, "numeric_precision")),
                numeric_scale=_to_int(_get_row_value(row, "numeric_scale")),
                is_nullable=_get_row_value(row, "is_nullable"),
                ordinal_position=_to_int(_get_row_value(row, "ordinal_position")),
            )
            for row in result
        ]

    def build_expected_schema(
        self, source_schema: list[dict[str, Any]], loader: TypeMappingLoader
    ) -> list[ColumnSchema]:
        """Build expected Snowflake schema from source schema and type mappings."""
        expected = []
        for col in source_schema:
            target_type = loader.get_snowflake_type(col[DATA_TYPE])
            if not target_type:
                logger.warning(
                    f"No type mapping for '{col[DATA_TYPE]}', "
                    f"skipping column '{col[COLUMN_NAME]}'"
                )
                continue
            expected.append(
                ColumnSchema(
                    column_name=col[COLUMN_NAME],
                    data_type=target_type.upper(),
                    character_max_length=col.get("max_length"),
                    numeric_precision=col.get("precision"),
                    numeric_scale=col.get("scale"),
                    is_nullable=col.get("is_nullable"),
                    ordinal_position=col.get("ordinal_position"),
                )
            )
        return expected

    def compare_schemas(
        self, expected: list[ColumnSchema], actual: list[ColumnSchema]
    ) -> list[SchemaDrift]:
        """Compare expected schema with actual schema to detect drift."""
        expected_map = {c.column_name.upper(): c for c in expected}
        actual_map = {c.column_name.upper(): c for c in actual}

        missing_keys = expected_map.keys() - actual_map.keys()
        extra_keys = actual_map.keys() - expected_map.keys()
        common_keys = expected_map.keys() & actual_map.keys()

        missing = [
            self._drift("missing_in_target", expected_map[k]) for k in missing_keys
        ]
        extra = [self._drift("extra_in_target", actual_map[k]) for k in extra_keys]
        mismatches = [
            self._drift("type_mismatch", expected_map[k], actual_map[k])
            for k in common_keys
            if not self._types_compatible(expected_map[k], actual_map[k])
        ]

        return missing + extra + mismatches

    def _drift(
        self,
        drift_type: str,
        expected_col: ColumnSchema,
        actual_col: ColumnSchema | None = None,
    ) -> SchemaDrift:
        """Create a SchemaDrift object."""
        messages = {
            "missing_in_target": f"Column '{expected_col.column_name}' not found in actual table",
            "extra_in_target": f"Column '{expected_col.column_name}' exists but not in source",
            "type_mismatch": (
                f"Column '{expected_col.column_name}': "
                f"expected {expected_col.get_full_type()}, "
                f"found {actual_col.get_full_type() if actual_col else 'N/A'}"
            ),
        }
        return SchemaDrift(
            column_name=expected_col.column_name,
            drift_type=drift_type,
            expected_type=(
                expected_col.get_full_type()
                if drift_type != "extra_in_target"
                else None
            ),
            actual_type=actual_col.get_full_type() if actual_col else None,
            message=messages[drift_type],
        )

    def _types_compatible(self, expected: ColumnSchema, actual: ColumnSchema) -> bool:
        """Check if two column types are compatible (same type family)."""
        exp_base, actual_base = expected.base_type, actual.base_type

        if exp_base == actual_base:
            return True

        for family in TYPE_FAMILIES:
            is_expected_in_family = exp_base in family
            is_actual_in_family = actual_base in family
            if is_expected_in_family and is_actual_in_family:
                return True
            if is_expected_in_family or is_actual_in_family:
                return False

        return False

    async def validate_schema(
        self,
        database_name: str,
        schema_name: str,
        table_name: str,
        source_schema: list[dict[str, Any]],
        type_mapping_loader: TypeMappingLoader,
    ) -> SchemaValidationResult:
        """Validate target table schema against expected schema from type mappings."""
        full_name = f"{database_name}.{schema_name}.{table_name}"
        expected = self.build_expected_schema(source_schema, type_mapping_loader)
        exists = await self.table_exists(database_name, schema_name, table_name)

        if not exists:
            logger.info(f"Table {full_name} does not exist, will be created")
            return SchemaValidationResult(
                table_exists=False,
                actual_schema=[],
                expected_schema=expected,
                drifts=[],
                is_compatible=True,
            )

        actual = await self.get_actual_schema(database_name, schema_name, table_name)
        logger.info(f"Table {full_name} exists with {len(actual)} columns")

        drifts = self.compare_schemas(expected, actual)
        self._log_drifts(full_name, drifts)

        type_mismatches = sum(1 for d in drifts if d.drift_type == "type_mismatch")
        is_compatible = type_mismatches == 0

        if not is_compatible:
            logger.warning(
                f"Schema incompatibility for {full_name}: {type_mismatches} type mismatch(es)"
            )

        return SchemaValidationResult(
            table_exists=True,
            actual_schema=actual,
            expected_schema=expected,
            drifts=drifts,
            is_compatible=is_compatible,
        )

    def _log_drifts(self, table_name: str, drifts: list[SchemaDrift]) -> None:
        """Log schema drift warnings."""
        if not drifts:
            logger.info(f"No schema drift for {table_name}")
            return

        logger.warning(f"Schema drift for {table_name}: {len(drifts)} difference(s)")
        for drift in drifts:
            level = (
                logger.info if drift.drift_type == "extra_in_target" else logger.warning
            )
            prefix = {
                "type_mismatch": "TYPE MISMATCH",
                "missing_in_target": "MISSING COLUMN",
                "extra_in_target": "EXTRA COLUMN",
            }.get(drift.drift_type, "DRIFT")
            level(f"  {prefix}: {drift.message}")

    def get_columns_for_copy_into(
        self,
        validation_result: SchemaValidationResult,
        source_schema: list[dict[str, Any]],
    ) -> list[tuple[str, str]]:
        """Get column list for COPY INTO based on validation result."""
        if not validation_result.table_exists:
            # Table was created from expected_schema (columns with type mappings only).
            # COPY INTO must use that same column list, not full source_schema, so
            # the insert list matches the table (e.g. 25 cols not 28).
            source_by_name = {
                col[COLUMN_NAME].upper(): col[DATA_TYPE] for col in source_schema
            }
            return [
                (
                    col.column_name,
                    source_by_name.get(col.column_name.upper(), col.data_type),
                )
                for col in validation_result.expected_schema
            ]

        actual_names = {c.column_name.upper() for c in validation_result.actual_schema}
        columns = []

        for col in source_schema:
            if col[COLUMN_NAME].upper() in actual_names:
                columns.append((col[COLUMN_NAME], col[DATA_TYPE]))
            else:
                logger.warning(
                    f"Column '{col[COLUMN_NAME]}' not in actual table, skipping"
                )

        return columns
