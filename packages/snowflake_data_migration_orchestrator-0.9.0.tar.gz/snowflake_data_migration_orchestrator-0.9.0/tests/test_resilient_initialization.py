"""Tests for resilient workflow initialization."""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from data_migration_orchestrator.cloud_orchestrator.orchestrator import Orchestrator
from shared.enums.source_type import SourceType


def _make_workflow(
    workflow_id: int = 1,
    initialization_failures: int = 0,
    status: WorkflowStatus = WorkflowStatus.INITIALIZING,
) -> Workflow:
    return Workflow(
        id=workflow_id,
        name="test-workflow",
        source_platform=SourceType.SQLSERVER,
        target_cloud_type="snowflake:stage",
        target_cloud_stage_name="MY_STAGE",
        target_cloud_url=None,
        schema_version="1",
        workflow_type="data-migration",
        initiator_id="test-initiator",
        status=status,
        configuration={"tables": [{"source": {"tableName": "T"}}]},
        initialization_failures=initialization_failures,
    )


class TestWorkflowStatusEnum(unittest.TestCase):
    """Tests for the INITIALIZING workflow status value."""

    def test_initializing_status_exists(self):
        self.assertEqual(WorkflowStatus.INITIALIZING, "initializing")

    def test_initializing_is_distinct(self):
        statuses = list(WorkflowStatus)
        self.assertEqual(len(statuses), len(set(statuses)))
        self.assertIn(WorkflowStatus.INITIALIZING, statuses)


class TestHandleWorkflowsHappyPath(unittest.IsolatedAsyncioTestCase):
    """Happy-path: initialization succeeds and workflow moves to running."""

    def setUp(self):
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.get_pending_workflows = AsyncMock(
            return_value=[_make_workflow()]
        )
        self.mock_task_queue.set_workflow_running = AsyncMock()
        self.mock_task_queue.fail_workflow_initialization = AsyncMock()
        self.mock_task_queue.delete_workflow_tasks = AsyncMock()
        self.mock_task_queue.complete_workflows = AsyncMock()

        self.mock_initializer = AsyncMock()
        self.mock_initializer.create_initial_tasks = AsyncMock()

        self.orchestrator = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )
        self.orchestrator.initializer_factory = MagicMock()
        self.orchestrator.initializer_factory.get_initializer.return_value = (
            self.mock_initializer
        )

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event"
    )
    async def test_successful_initialization_sets_workflow_running(self, _telemetry):
        await self.orchestrator._handle_workflows()

        self.mock_initializer.create_initial_tasks.assert_awaited_once()
        self.mock_task_queue.set_workflow_running.assert_awaited_once_with(1)
        self.mock_task_queue.fail_workflow_initialization.assert_not_awaited()

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event"
    )
    async def test_no_task_deletion_on_first_attempt(self, _telemetry):
        await self.orchestrator._handle_workflows()

        self.mock_task_queue.delete_workflow_tasks.assert_not_awaited()


class TestHandleWorkflowsFailure(unittest.IsolatedAsyncioTestCase):
    """Initialization fails and the workflow records the failure."""

    def setUp(self):
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.get_pending_workflows = AsyncMock(
            return_value=[_make_workflow()]
        )
        self.mock_task_queue.set_workflow_running = AsyncMock()
        self.mock_task_queue.fail_workflow_initialization = AsyncMock()
        self.mock_task_queue.delete_workflow_tasks = AsyncMock()
        self.mock_task_queue.complete_workflows = AsyncMock()

        self.mock_initializer = AsyncMock()
        self.mock_initializer.create_initial_tasks = AsyncMock(
            side_effect=Exception("connection lost")
        )

        self.orchestrator = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )
        self.orchestrator.initializer_factory = MagicMock()
        self.orchestrator.initializer_factory.get_initializer.return_value = (
            self.mock_initializer
        )

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event"
    )
    async def test_failure_calls_fail_workflow_initialization(self, _telemetry):
        await self.orchestrator._handle_workflows()

        self.mock_task_queue.fail_workflow_initialization.assert_awaited_once_with(
            1, "connection lost"
        )
        self.mock_task_queue.set_workflow_running.assert_not_awaited()


class TestHandleWorkflowsRetry(unittest.IsolatedAsyncioTestCase):
    """Re-initialization deletes old tasks when initialization_failures > 0."""

    def setUp(self):
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.get_pending_workflows = AsyncMock(
            return_value=[_make_workflow(initialization_failures=1)]
        )
        self.mock_task_queue.set_workflow_running = AsyncMock()
        self.mock_task_queue.fail_workflow_initialization = AsyncMock()
        self.mock_task_queue.delete_workflow_tasks = AsyncMock()
        self.mock_task_queue.complete_workflows = AsyncMock()

        self.mock_initializer = AsyncMock()
        self.mock_initializer.create_initial_tasks = AsyncMock()

        self.orchestrator = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )
        self.orchestrator.initializer_factory = MagicMock()
        self.orchestrator.initializer_factory.get_initializer.return_value = (
            self.mock_initializer
        )

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event"
    )
    async def test_tasks_deleted_before_re_initialization(self, _telemetry):
        await self.orchestrator._handle_workflows()

        self.mock_task_queue.delete_workflow_tasks.assert_awaited_once_with(1)
        self.mock_initializer.create_initial_tasks.assert_awaited_once()
        self.mock_task_queue.set_workflow_running.assert_awaited_once_with(1)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.orchestrator.log_telemetry_event"
    )
    async def test_no_deletion_when_failures_is_zero(self, _telemetry):
        self.mock_task_queue.get_pending_workflows = AsyncMock(
            return_value=[_make_workflow(initialization_failures=0)]
        )

        await self.orchestrator._handle_workflows()

        self.mock_task_queue.delete_workflow_tasks.assert_not_awaited()


class TestBookkeepingExpiresStaleInitializations(unittest.IsolatedAsyncioTestCase):
    """Bookkeeping should call expire_stale_initializations."""

    def setUp(self):
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.expire_stale_initializations = AsyncMock()
        self.mock_task_queue.refresh_active_leases = AsyncMock()
        self.mock_task_queue.expire_leases = AsyncMock()
        self.mock_task_queue.refresh_warehouse_tasks = AsyncMock()

        self.orchestrator = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )

    async def test_expire_stale_initializations_called(self):
        await self.orchestrator._do_book_keeping_for_tasks()

        self.mock_task_queue.expire_stale_initializations.assert_awaited_once()

    async def test_expire_stale_initializations_before_expire_leases(self):
        call_order = []
        self.mock_task_queue.expire_stale_initializations = AsyncMock(
            side_effect=lambda: call_order.append("expire_stale_init")
        )
        self.mock_task_queue.expire_leases = AsyncMock(
            side_effect=lambda: call_order.append("expire_leases")
        )

        await self.orchestrator._do_book_keeping_for_tasks()

        self.assertIn("expire_stale_init", call_order)
        self.assertIn("expire_leases", call_order)
        self.assertLess(
            call_order.index("expire_stale_init"),
            call_order.index("expire_leases"),
        )


class TestWorkflowDataclass(unittest.TestCase):
    """Tests for the new fields on the Workflow dataclass."""

    def test_default_initialization_failures(self):
        wf = _make_workflow()
        self.assertEqual(wf.initialization_failures, 0)

    def test_custom_initialization_failures(self):
        wf = _make_workflow(initialization_failures=2)
        self.assertEqual(wf.initialization_failures, 2)

    def test_default_error_and_warning_messages(self):
        wf = _make_workflow()
        self.assertIsNone(wf.last_error_message)
        self.assertIsNone(wf.last_warning_message)

    def test_default_initialization_start_time(self):
        wf = _make_workflow()
        self.assertIsNone(wf.initialization_start_time)


if __name__ == "__main__":
    unittest.main()
