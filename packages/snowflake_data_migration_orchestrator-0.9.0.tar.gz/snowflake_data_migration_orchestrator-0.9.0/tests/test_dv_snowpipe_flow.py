"""Unit tests for DV Snowpipe level-chain wiring."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    PrepareDvDrainPayload,
    ResultPipeInfo,
)
from data_migration_orchestrator.data_validation_cloud.tasks.snowpipe_flow import (
    build_result_pipes_for_partition,
    build_snowpipe_level_chain,
)
from data_migration_orchestrator.data_validation_cloud.utils.ensure_dv_pipe import (
    _reset_cache_for_tests,
)
from data_migration_orchestrator.data_validation_cloud.utils.pipe_utils import (
    DvResultsPipeKey,
)


def _run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def _make_task_queue(start_id: int = 5000) -> MagicMock:
    counter = {"n": start_id}

    async def _push(_task):
        counter["n"] += 1
        return counter["n"]

    queue = MagicMock()
    queue.push_task = AsyncMock(side_effect=_push)
    return queue


@pytest.fixture(autouse=True)
def _reset_dv_pipe_cache():
    """
    Clear ensure_dv_pipe's process-local cache before each test.

    Autouse so it runs for class methods too (``setup_function`` only
    fires for module-level test functions).
    """
    _reset_cache_for_tests()


class TestBuildSnowpipeLevelChain:
    """Test the drain-task chain builder."""

    def test_single_pipe_chain_points_at_evaluate(self):
        task_queue = _make_task_queue()
        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(return_value=[])
        warehouse.execute_snowpipe_drain_and_push_task = AsyncMock(side_effect=[1001])

        chain = _run(
            build_snowpipe_level_chain(
                task_queue=task_queue,
                warehouse=warehouse,
                workflow_id=42,
                level="metrics",
                pipe_keys=[DvResultsPipeKey.METRICS],
                evaluate_task_id=555,
            )
        )

        assert chain.entry_task_id == 1001
        assert len(chain.pipe_entries) == 1
        key, pipe_name = chain.pipe_entries[0]
        assert key == DvResultsPipeKey.METRICS
        assert pipe_name.endswith(".DVO_PIPE_42_METRICS")

        # ensure_dv_pipe runs CREATE PIPE synchronously and pushes only the
        # Teardown via task_queue. No Prepare task for single-pipe flows.
        warehouse.execute_sync_query.assert_awaited_once()
        assert task_queue.push_task.await_count == 1

        warehouse.execute_snowpipe_drain_and_push_task.assert_awaited_once()
        call = warehouse.execute_snowpipe_drain_and_push_task.await_args
        assert call.kwargs["successor_task_id"] == 555
        assert call.kwargs["is_blocked"] is True

    def test_multi_pipe_chain_pushes_single_prepare_task(self):
        """Multi-pipe levels go through a PrepareDvDrain fan-out task."""
        task_queue = _make_task_queue()
        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(return_value=[])
        warehouse.execute_snowpipe_drain_and_push_task = AsyncMock()

        chain = _run(
            build_snowpipe_level_chain(
                task_queue=task_queue,
                warehouse=warehouse,
                workflow_id=7,
                level="row",
                pipe_keys=[
                    DvResultsPipeKey.ROW_DIFFS,
                    DvResultsPipeKey.ROW_SUMMARY,
                    DvResultsPipeKey.CHUNK_HASHES,
                ],
                evaluate_task_id=999,
            )
        )

        # No drain tasks are pushed at planning time; the Prepare handler
        # inserts them dynamically once unblocked.
        warehouse.execute_snowpipe_drain_and_push_task.assert_not_awaited()

        # CREATE PIPE per key (3) runs synchronously; only Teardown per key (3)
        # + 1 PrepareDvDrain = 4 pushes hit the queue.
        assert warehouse.execute_sync_query.await_count == 3
        assert task_queue.push_task.await_count == 4

        prepare_task = task_queue.push_task.await_args_list[-1].args[0]
        assert prepare_task.executor_type == ExecutorType.ORCHESTRATOR
        assert prepare_task.is_blocked is True
        assert prepare_task.successor_task_id == 999
        payload: PrepareDvDrainPayload = prepare_task.payload
        assert isinstance(payload, PrepareDvDrainPayload)
        assert payload.workflow_id == 7
        assert payload.level == "row"
        assert payload.evaluate_task_id == 999
        assert payload.pipe_keys == [
            DvResultsPipeKey.ROW_DIFFS.value,
            DvResultsPipeKey.ROW_SUMMARY.value,
            DvResultsPipeKey.CHUNK_HASHES.value,
        ]
        assert len(payload.pipe_names) == 3
        for name in payload.pipe_names:
            assert "DVO_PIPE_7_" in name

        # entry_task_id should be the Prepare task's id (last push).
        assert chain.entry_task_id == 5004
        assert len(chain.pipe_entries) == 3

    def test_multi_pipe_chain_allows_none_evaluate(self):
        """Drill-down flows pass evaluate_task_id=None."""
        task_queue = _make_task_queue()
        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(return_value=[])
        warehouse.execute_snowpipe_drain_and_push_task = AsyncMock()

        _run(
            build_snowpipe_level_chain(
                task_queue=task_queue,
                warehouse=warehouse,
                workflow_id=3,
                level="row",
                pipe_keys=[
                    DvResultsPipeKey.ROW_DIFFS,
                    DvResultsPipeKey.ROW_SUMMARY,
                    DvResultsPipeKey.CHUNK_HASHES,
                ],
                evaluate_task_id=None,
            )
        )

        prepare_task = task_queue.push_task.await_args_list[-1].args[0]
        assert prepare_task.successor_task_id is None
        payload: PrepareDvDrainPayload = prepare_task.payload
        assert payload.evaluate_task_id is None

    def test_empty_pipe_keys_raises(self):
        task_queue = _make_task_queue()
        warehouse = MagicMock()
        warehouse.execute_snowpipe_drain_and_push_task = AsyncMock()

        try:
            _run(
                build_snowpipe_level_chain(
                    task_queue=task_queue,
                    warehouse=warehouse,
                    workflow_id=1,
                    level="metrics",
                    pipe_keys=[],
                    evaluate_task_id=1,
                )
            )
        except ValueError:
            return
        raise AssertionError("expected ValueError for empty pipe_keys")


class TestBuildResultPipesForPartition:
    """Test per-partition ``ResultPipeInfo`` construction."""

    def test_metrics_uses_partition_root(self):
        pipes = build_result_pipes_for_partition(
            pipe_entries=[(DvResultsPipeKey.METRICS, "DB.T.PIPE_METRICS")],
            workflow_id=1,
            table_metadata_id=2,
            level="metrics",
            partition_number=3,
        )
        assert pipes == [
            ResultPipeInfo(
                pipe_name="DB.T.PIPE_METRICS", stage_prefix="1/2/metrics/p3/"
            )
        ]

    def test_row_pipes_have_distinct_subdirs(self):
        entries = [
            (DvResultsPipeKey.ROW_DIFFS, "DB.T.P_DIFFS"),
            (DvResultsPipeKey.ROW_SUMMARY, "DB.T.P_SUMMARY"),
            (DvResultsPipeKey.CHUNK_HASHES, "DB.T.P_HASHES"),
        ]
        pipes = build_result_pipes_for_partition(
            pipe_entries=entries,
            workflow_id=9,
            table_metadata_id=5,
            level="row",
            partition_number=0,
        )
        suffixes = [p.stage_prefix for p in pipes]
        assert suffixes == [
            "9/5/row/p0/diffs/",
            "9/5/row/p0/summary/",
            "9/5/row/p0/hashes/",
        ]

    def test_cell_diffs_uses_diffs_subdir(self):
        pipes = build_result_pipes_for_partition(
            pipe_entries=[(DvResultsPipeKey.CELL_DIFFS, "PIPE_CELL")],
            workflow_id=1,
            table_metadata_id=2,
            level="cell",
            partition_number=None,
        )
        assert pipes == [
            ResultPipeInfo(pipe_name="PIPE_CELL", stage_prefix="1/2/cell/diffs/")
        ]
