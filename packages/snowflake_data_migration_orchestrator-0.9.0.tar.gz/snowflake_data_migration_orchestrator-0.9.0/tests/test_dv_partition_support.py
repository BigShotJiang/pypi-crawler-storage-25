"""
Tests for DV multi-partition support.

Covers:
- Config chain: partition_column in schema, dataclass, parser
- Partition creation logic in GenerateValidationQueriesHandler
- Condition building in EvaluateLevelResultHandler._build_scoped_where
- DEAPayloadFactory partition WHERE clause passthrough
"""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_validation_cloud.config.configuration_properties_keys import (
    COLUMN_NAMES_TO_PARTITION_BY,
    TARGET_PARTITION_SIZE_MB,
    TARGET_PARTITION_SIZE_ROWS,
)
from data_migration_orchestrator.data_validation_cloud.config.validation_configuration_parser import (
    ValidationConfigurationParser,
)
from data_migration_orchestrator.data_validation_cloud.config.validation_table_configuration import (
    ValidationTableConfiguration,
)
from data_migration_orchestrator.data_validation_cloud.config.workflow_configuration_schema import (
    validate_data_validation_workflow_configuration,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.evaluate_level_result_handler import (
    EvaluateLevelResultHandler,
)
from data_migration_orchestrator.data_validation_cloud.partition_progress import (
    partition_number_from_dv_task_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.generate_validation_queries_handler import (
    DEFAULT_BASE_MAX_ROWS_PER_PARTITION,
    DEFAULT_MAX_CELLS_PER_PARTITION,
    GenerateValidationQueriesHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.dea_payload_factory import (
    DEAPayloadFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    DataValidationTaskPayload,
    GenerateValidationQueriesPayload,
)
from data_migration_orchestrator.data_validation_core.constants import fq_table_metadata


# =========================================================================
# Config chain tests
# =========================================================================


class TestPartitionColumnConfig:
    """Verify partition_column flows through the entire config chain."""

    def test_schema_accepts_column_names_to_partition_by(self):
        config = {
            "sourcePlatform": "redshift",
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "columnNamesToPartitionBy": ["id"],
                }
            ],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.tables[0].column_names_to_partition_by == ["id"]

    def test_schema_defaults_column_names_to_partition_by_to_none(self):
        config = {
            "sourcePlatform": "redshift",
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.tables[0].column_names_to_partition_by is None

    def test_dataclass_stores_partition_columns(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
            column_names_to_partition_by=["created_at"],
        )
        assert vtc.column_names_to_partition_by == ["created_at"]

    def test_to_sdv_dict_includes_column_names_to_partition_by(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
            column_names_to_partition_by=["id"],
        )
        d = vtc.to_sdv_dict()
        assert d[COLUMN_NAMES_TO_PARTITION_BY] == ["id"]

    def test_to_sdv_dict_omits_empty_partition_columns(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
        )
        d = vtc.to_sdv_dict()
        assert COLUMN_NAMES_TO_PARTITION_BY not in d

    def test_parser_passes_partition_columns(self):
        raw = {
            "sourcePlatform": "redshift",
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "columnNamesToPartitionBy": ["id"],
                }
            ],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert len(tables) == 1
        assert tables[0].column_names_to_partition_by == ["id"]

    def test_parser_defaults_partition_columns_to_empty(self):
        raw = {
            "sourcePlatform": "redshift",
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert tables[0].column_names_to_partition_by == []


class TestTargetPartitionSizeRowsConfig:
    """Verify targetPartitionSizeRows flows through the config chain."""

    def test_schema_accepts_global_target_partition_size_rows(self):
        config = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeRows": 100_000,
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.target_partition_size_rows == 100_000

    def test_schema_accepts_per_table_target_partition_size_rows(self):
        config = {
            "sourcePlatform": "redshift",
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "targetPartitionSizeRows": 25000,
                }
            ],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.tables[0].target_partition_size_rows == 25000

    def test_schema_defaults_target_partition_size_rows_to_none(self):
        config = {
            "sourcePlatform": "redshift",
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.target_partition_size_rows is None
        assert schema.tables[0].target_partition_size_rows is None

    def test_schema_rejects_zero_target_partition_size_rows(self):
        import pytest
        from pydantic import ValidationError

        config = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeRows": 0,
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        with pytest.raises(ValidationError):
            validate_data_validation_workflow_configuration(config)

    def test_schema_rejects_negative_target_partition_size_rows(self):
        import pytest
        from pydantic import ValidationError

        config = {
            "sourcePlatform": "redshift",
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "targetPartitionSizeRows": -1,
                }
            ],
        }
        with pytest.raises(ValidationError):
            validate_data_validation_workflow_configuration(config)

    def test_dataclass_stores_target_partition_size_rows(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
            target_partition_size_rows=75000,
        )
        assert vtc.target_partition_size_rows == 75000

    def test_to_sdv_dict_includes_target_partition_size_rows(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
            target_partition_size_rows=50000,
        )
        d = vtc.to_sdv_dict()
        assert d[TARGET_PARTITION_SIZE_ROWS] == 50000

    def test_to_sdv_dict_omits_none_target_partition_size_rows(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
        )
        d = vtc.to_sdv_dict()
        assert TARGET_PARTITION_SIZE_ROWS not in d

    def test_parser_inherits_global_target_partition_size_rows(self):
        raw = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeRows": 60000,
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert tables[0].target_partition_size_rows == 60000

    def test_parser_per_table_overrides_global(self):
        raw = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeRows": 60000,
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "targetPartitionSizeRows": 25000,
                }
            ],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert tables[0].target_partition_size_rows == 25000

    def test_parser_defaults_target_partition_size_rows_to_none(self):
        raw = {
            "sourcePlatform": "redshift",
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert tables[0].target_partition_size_rows is None


class TestPartitionTargetMutualExclusivity:
    """Verify targetPartitionSizeRows and targetPartitionSizeMb are mutually exclusive."""

    def test_schema_rejects_both_targets_at_global_level(self):
        import pytest
        from pydantic import ValidationError

        config = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeRows": 100_000,
            "targetPartitionSizeMb": 500,
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        with pytest.raises(ValidationError, match="Only one of"):
            validate_data_validation_workflow_configuration(config)

    def test_schema_rejects_both_targets_at_table_level(self):
        import pytest
        from pydantic import ValidationError

        config = {
            "sourcePlatform": "redshift",
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "targetPartitionSizeRows": 50_000,
                    "targetPartitionSizeMb": 300,
                }
            ],
        }
        with pytest.raises(ValidationError, match="Only one of"):
            validate_data_validation_workflow_configuration(config)

    def test_schema_allows_different_targets_at_different_levels(self):
        config = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeMb": 500,
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "targetPartitionSizeRows": 50_000,
                }
            ],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.target_partition_size_mb == 500
        assert schema.tables[0].target_partition_size_rows == 50_000

    def test_schema_allows_neither_target(self):
        config = {
            "sourcePlatform": "redshift",
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.target_partition_size_rows is None
        assert schema.target_partition_size_mb is None


class TestTargetPartitionSizeMbConfig:
    """Verify targetPartitionSizeMb flows through the config chain."""

    def test_schema_accepts_global_target_partition_size_mb(self):
        config = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeMb": 500,
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.target_partition_size_mb == 500

    def test_schema_accepts_per_table_target_partition_size_mb(self):
        config = {
            "sourcePlatform": "redshift",
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "targetPartitionSizeMb": 300,
                }
            ],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.tables[0].target_partition_size_mb == 300

    def test_to_sdv_dict_includes_target_partition_size_mb(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
            target_partition_size_mb=250,
        )
        d = vtc.to_sdv_dict()
        assert d[TARGET_PARTITION_SIZE_MB] == 250

    def test_parser_inherits_global_target_partition_size_mb(self):
        raw = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeMb": 400,
            "tables": [{"fullyQualifiedName": "db.schema.table"}],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert tables[0].target_partition_size_mb == 400

    def test_parser_per_table_overrides_global_mb(self):
        raw = {
            "sourcePlatform": "redshift",
            "targetPartitionSizeMb": 400,
            "tables": [
                {
                    "fullyQualifiedName": "db.schema.table",
                    "targetPartitionSizeMb": 100,
                }
            ],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert tables[0].target_partition_size_mb == 100


# =========================================================================
# Partition creation tests (GenerateValidationQueriesHandler)
# =========================================================================


class TestCreatePartitionMetadata:
    """Tests for _create_partition_metadata in the generate handler."""

    def _make_handler(self, query_results: dict[str, list] | None = None):
        """Build a handler with a mocked warehouse proxy."""
        task_queue = AsyncMock()
        warehouse = AsyncMock()

        call_index = {"i": 0}
        results_list: list[list] = []
        if query_results:
            results_list = list(query_results.values())

        async def execute_side_effect(query: str):
            idx = call_index["i"]
            call_index["i"] += 1
            if idx < len(results_list):
                return results_list[idx]
            return []

        warehouse.execute_sync_query = AsyncMock(side_effect=execute_side_effect)
        return GenerateValidationQueriesHandler(task_queue, warehouse), warehouse

    def test_no_partition_column_inserts_single(self):
        handler, warehouse = self._make_handler()
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={},
            )
        )
        warehouse.execute_sync_query.assert_called_once()
        call_sql = warehouse.execute_sync_query.call_args[0][0]
        assert "INSERT INTO" in call_sql
        assert "PARTITION_METADATA" in call_sql
        assert "FROM VALUES" in call_sql
        assert "VALIDATION_STATUS" in call_sql
        assert "'PENDING'" in call_sql

    def test_no_partition_column_calls_warn_task(self):
        handler, warehouse = self._make_handler()
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={},
            )
        )
        handler.task_queue.warn_task.assert_awaited_once()
        task_id_arg, msg_arg = handler.task_queue.warn_task.call_args[0]
        assert task_id_arg == 42
        assert "no columnNamesToPartitionBy" in msg_arg
        assert "db.schema.t" in msg_arg

    def test_empty_table_inserts_single(self):
        handler, warehouse = self._make_handler()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 0}],  # COUNT(*) result
                [],  # bulk INSERT
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={"columnNamesToPartitionBy": ["id"]},
            )
        )
        assert warehouse.execute_sync_query.call_count == 2

    def test_small_table_inserts_single(self):
        """Small table stays as single partition (effective target > row count)."""
        handler, warehouse = self._make_handler()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1000}],  # small table
                [{"TS_BYTES": 10 * 1024 * 1024}],  # 10 MB — well under 200 MB target
                [{"COL_COUNT": 10}],  # column count
                [],  # bulk INSERT
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                },
            )
        )
        assert warehouse.execute_sync_query.call_count == 4
        is_call = warehouse.execute_sync_query.call_args_list[1][0][0]
        assert "INFORMATION_SCHEMA.TABLES" in is_call
        last_call = warehouse.execute_sync_query.call_args[0][0]
        assert "INSERT INTO" in last_call
        assert "FROM VALUES" in last_call
        assert "(1, 1, NULL, NULL, NULL, 'PENDING')" in last_call

    def test_large_table_creates_multiple_partitions(self):
        """1M rows at 250 MB: size target capped by default 500K → NTILE(2)."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": 1,
                "MIN_VALUE_IN_PARTITION": 1,
                "MAX_VALUE_IN_PARTITION": 500000,
                "N_ROWS": 500000,
            },
            {
                "PARTITION_ID": 2,
                "MIN_VALUE_IN_PARTITION": 500001,
                "MAX_VALUE_IN_PARTITION": 1000000,
                "N_ROWS": 500000,
            },
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1_000_000}],  # COUNT(*)
                [{"TS_BYTES": 250 * 1024 * 1024}],  # 250 MB
                [{"COL_COUNT": 10}],  # column count
                ntile_results,  # NTILE query
                [],  # single bulk INSERT
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                },
            )
        )
        assert warehouse.execute_sync_query.call_count == 5

        ntile_call = warehouse.execute_sync_query.call_args_list[3][0][0]
        assert "NTILE" in ntile_call
        assert "SELECT id," in ntile_call
        assert "SAMPLE" not in ntile_call

    def test_config_target_rows_per_partition_controls_partition_count(self):
        """200K rows at 80 MB: target_rows_per_partition 50K capped by max 1M → NTILE(4)."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": i,
                "MIN_VALUE_IN_PARTITION": (i - 1) * 50000 + 1,
                "MAX_VALUE_IN_PARTITION": i * 50000,
                "N_ROWS": 50000,
            }
            for i in range(1, 5)
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 200_000}],  # COUNT(*)
                [{"TS_BYTES": 80 * 1024 * 1024}],  # 80 MB
                [{"COL_COUNT": 10}],  # column count
                ntile_results,  # NTILE(4) from row target
                [],  # single bulk INSERT
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                    "targetPartitionSizeRows": 50000,
                },
            )
        )
        assert warehouse.execute_sync_query.call_count == 5
        assert (
            "INFORMATION_SCHEMA.TABLES"
            in warehouse.execute_sync_query.call_args_list[1][0][0]
        )
        ntile_call = warehouse.execute_sync_query.call_args_list[3][0][0]
        assert "NTILE(4)" in ntile_call

    def test_default_max_target_rows_per_partition_value(self):
        """The handler default matches the module constant."""
        assert DEFAULT_BASE_MAX_ROWS_PER_PARTITION == 1_000_000

    def test_explicit_target_rows_overrides_max_cap(self):
        """2M rows with explicit targetPartitionSizeRows=2M → NTILE(1) = single partition (no cap)."""
        handler, warehouse = self._make_handler()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 2_000_000}],
                [{"TS_BYTES": 250 * 1024 * 1024}],
                [{"COL_COUNT": 10}],
                [],  # bulk INSERT (single partition)
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                    "targetPartitionSizeRows": 2_000_000,
                },
            )
        )
        assert warehouse.execute_sync_query.call_count == 4
        last_call = warehouse.execute_sync_query.call_args[0][0]
        assert "INSERT INTO" in last_call
        assert "FROM VALUES" in last_call

    def test_very_large_table_uses_sampling(self):
        """500M rows with max 1M → ceil(500M/1M)=500 → NTILE with SAMPLE BERNOULLI."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": i,
                "MIN_VALUE_IN_PARTITION": (i - 1) * 500000 + 1,
                "MAX_VALUE_IN_PARTITION": i * 500000,
                "N_ROWS": 500000,
            }
            for i in range(1, 101)
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 500_000_000}],  # COUNT(*) — above sampling threshold
                [{"TS_BYTES": 100 * 1024 * 1024}],  # 100 MB
                [{"COL_COUNT": 10}],  # column count
                ntile_results,
                [],  # single bulk INSERT
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                },
            )
        )

        ntile_call = warehouse.execute_sync_query.call_args_list[3][0][0]
        assert "NTILE" in ntile_call
        assert "SAMPLE BERNOULLI" in ntile_call
        assert warehouse.execute_sync_query.call_count == 5

    def test_sampled_n_rows_are_scaled_to_actual_total(self):
        """Sampled N_ROWS are scaled to actual total when sampling is used."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": 1,
                "MIN_VALUE_IN_PARTITION": 1,
                "MAX_VALUE_IN_PARTITION": 100,
                "N_ROWS": 200,
            },
            {
                "PARTITION_ID": 2,
                "MIN_VALUE_IN_PARTITION": 101,
                "MAX_VALUE_IN_PARTITION": 200,
                "N_ROWS": 300,
            },
            {
                "PARTITION_ID": 3,
                "MIN_VALUE_IN_PARTITION": 201,
                "MAX_VALUE_IN_PARTITION": 300,
                "N_ROWS": 500,
            },
        ]
        total_actual = 200_000_000
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": total_actual}],
                [{"TS_BYTES": 5000 * 1024 * 1024}],
                [{"COL_COUNT": 10}],
                ntile_results,
                [],
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                },
            )
        )
        insert_sql = warehouse.execute_sync_query.call_args_list[4][0][0]
        assert "INSERT INTO" in insert_sql
        assert "FROM VALUES" in insert_sql

    def test_no_scaling_below_sampling_threshold(self):
        """N_ROWS from NTILE are stored as-is when below sampling threshold."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": 1,
                "MIN_VALUE_IN_PARTITION": 1,
                "MAX_VALUE_IN_PARTITION": 500000,
                "N_ROWS": 500000,
            },
            {
                "PARTITION_ID": 2,
                "MIN_VALUE_IN_PARTITION": 500001,
                "MAX_VALUE_IN_PARTITION": 1000000,
                "N_ROWS": 500000,
            },
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1_000_000}],
                [{"TS_BYTES": 250 * 1024 * 1024}],
                [{"COL_COUNT": 10}],
                ntile_results,
                [],
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                },
            )
        )
        insert_sql = warehouse.execute_sync_query.call_args_list[4][0][0]
        assert "500000, 'PENDING'" in insert_sql

    def test_no_target_database_uses_row_fallback_without_catalog(self):
        """Two-part target FQN: no BYTES query; row cap yields NTILE(2) for 2M rows."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": 1,
                "MIN_VALUE_IN_PARTITION": 1,
                "MAX_VALUE_IN_PARTITION": 1000000,
                "N_ROWS": 1000000,
            },
            {
                "PARTITION_ID": 2,
                "MIN_VALUE_IN_PARTITION": 1000001,
                "MAX_VALUE_IN_PARTITION": 2000000,
                "N_ROWS": 1000000,
            },
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 2_000_000}],
                ntile_results,
                [],
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={"columnNamesToPartitionBy": ["id"]},
            )
        )
        assert warehouse.execute_sync_query.call_count == 3
        for call in warehouse.execute_sync_query.call_args_list:
            assert "INFORMATION_SCHEMA.TABLES" not in call[0][0]
        ntile_call = warehouse.execute_sync_query.call_args_list[1][0][0]
        assert "NTILE(2)" in ntile_call

    def test_target_rows_per_partition_overrides_bytes_target(self):
        """1M rows, 250 MB. target_rows_per_partition 100K → effective = min(100K, max 1M) = 100K → NTILE(10)."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": i,
                "MIN_VALUE_IN_PARTITION": (i - 1) * 100_000 + 1,
                "MAX_VALUE_IN_PARTITION": min(i * 100_000, 1_000_000),
                "N_ROWS": 100_000 if i < 10 else 100_000,
            }
            for i in range(1, 11)
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1_000_000}],
                [{"TS_BYTES": 250 * 1024 * 1024}],
                [{"COL_COUNT": 10}],
                ntile_results,
                [],
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                    "targetPartitionSizeRows": 100_000,
                },
            )
        )
        ntile_call = warehouse.execute_sync_query.call_args_list[3][0][0]
        assert "NTILE(10)" in ntile_call

    def test_build_query_no_sampling_below_threshold(self):
        query = GenerateValidationQueriesHandler._build_partition_boundary_query(
            tgt_fqn="DB.SCH.T", col_sql="ID", num_partitions=10, row_count=1_000_000
        )
        assert "NTILE(10)" in query
        assert "FROM DB.SCH.T" in query
        assert "SAMPLE" not in query

    def test_build_query_sampling_above_threshold(self):
        query = GenerateValidationQueriesHandler._build_partition_boundary_query(
            tgt_fqn="DB.SCH.T",
            col_sql="ID",
            num_partitions=100,
            row_count=500_000_000,
        )
        assert "NTILE(100)" in query
        assert "SAMPLE BERNOULLI" in query
        assert "FROM sampled" in query
        assert "FROM DB.SCH.T SAMPLE" in query

    def test_build_query_sampling_percentage_calculation(self):
        query = GenerateValidationQueriesHandler._build_partition_boundary_query(
            tgt_fqn="DB.SCH.T",
            col_sql="ID",
            num_partitions=100,
            row_count=2_000_000_000,
        )
        # 20M / 2B * 100 = 1.0%
        assert "1.000000" in query


class TestCellLimitPartitioning:
    """Tests for max-cells partition limit in cell/hybrid validation modes."""

    def _make_handler(self):
        task_queue = AsyncMock()
        warehouse = AsyncMock()
        return GenerateValidationQueriesHandler(task_queue, warehouse), warehouse

    def test_cell_mode_queries_column_count_and_partitions_by_cells(self):
        """Cell mode with 200 cols, 1M rows → cells limit 4M / 200 = 20K rows/partition → NTILE(50)."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": i,
                "MIN_VALUE_IN_PARTITION": (i - 1) * 20000 + 1,
                "MAX_VALUE_IN_PARTITION": i * 20000,
                "N_ROWS": 20000,
            }
            for i in range(1, 51)
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1_000_000}],
                [{"TS_BYTES": 250 * 1024 * 1024}],
                [{"COL_COUNT": 200}],
                ntile_results,
                [],
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                    "row_validation_mode": "cell",
                },
            )
        )
        assert warehouse.execute_sync_query.call_count == 5
        col_count_call = warehouse.execute_sync_query.call_args_list[2][0][0]
        assert "INFORMATION_SCHEMA.COLUMNS" in col_count_call
        ntile_call = warehouse.execute_sync_query.call_args_list[3][0][0]
        assert "NTILE(50)" in ntile_call

    def test_hybrid_mode_applies_cells_limit(self):
        """Hybrid mode also triggers the cells-based partition limit."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": i,
                "MIN_VALUE_IN_PARTITION": (i - 1) * 20000 + 1,
                "MAX_VALUE_IN_PARTITION": i * 20000,
                "N_ROWS": 20000,
            }
            for i in range(1, 51)
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1_000_000}],
                [{"TS_BYTES": 250 * 1024 * 1024}],
                [{"COL_COUNT": 200}],
                ntile_results,
                [],
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                    "row_validation_mode": "hybrid",
                },
            )
        )
        col_count_call = warehouse.execute_sync_query.call_args_list[2][0][0]
        assert "INFORMATION_SCHEMA.COLUMNS" in col_count_call
        ntile_call = warehouse.execute_sync_query.call_args_list[3][0][0]
        assert "NTILE(50)" in ntile_call

    def test_row_mode_also_queries_column_count(self):
        """Row mode also fetches column count and applies cells limit for L2 metrics."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": i,
                "MIN_VALUE_IN_PARTITION": (i - 1) * 20000 + 1,
                "MAX_VALUE_IN_PARTITION": i * 20000,
                "N_ROWS": 20000,
            }
            for i in range(1, 51)
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1_000_000}],
                [{"TS_BYTES": 250 * 1024 * 1024}],
                [{"COL_COUNT": 200}],
                ntile_results,
                [],
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                    "row_validation_mode": "row",
                },
            )
        )
        assert warehouse.execute_sync_query.call_count == 5
        col_count_call = warehouse.execute_sync_query.call_args_list[2][0][0]
        assert "INFORMATION_SCHEMA.COLUMNS" in col_count_call
        ntile_call = warehouse.execute_sync_query.call_args_list[3][0][0]
        assert "NTILE(50)" in ntile_call

    def test_no_target_database_skips_cells_limit(self):
        """Without target_database, cells limit cannot be applied (no column count)."""
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": 1,
                "MIN_VALUE_IN_PARTITION": 1,
                "MAX_VALUE_IN_PARTITION": 1000000,
                "N_ROWS": 1000000,
            },
            {
                "PARTITION_ID": 2,
                "MIN_VALUE_IN_PARTITION": 1000001,
                "MAX_VALUE_IN_PARTITION": 2000000,
                "N_ROWS": 1000000,
            },
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 2_000_000}],
                ntile_results,
                [],
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                task_id=42,
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "columnNamesToPartitionBy": ["id"],
                    "row_validation_mode": "cell",
                },
            )
        )
        # 3 calls: COUNT(*), NTILE, INSERT — no BYTES or COLUMNS queries
        assert warehouse.execute_sync_query.call_count == 3
        for call in warehouse.execute_sync_query.call_args_list:
            assert "INFORMATION_SCHEMA" not in call[0][0]

    def test_default_max_cells_per_partition_value(self):
        """The handler default matches the module constant."""
        assert DEFAULT_MAX_CELLS_PER_PARTITION == 4_000_000


class TestGenerateValidationQueriesMarksPreprocessed:
    """After partition metadata exists, TABLE_METADATA.HAS_BEEN_PREPROCESSED is set."""

    def test_handle_sets_has_been_preprocessed_when_no_levels_enabled(self):
        disabled = {
            "schema_validation": False,
            "metrics_validation": False,
            "row_validation": False,
        }
        task_queue = AsyncMock()
        warehouse = AsyncMock(
            execute_sync_query=AsyncMock(
                side_effect=[
                    [{"CFG": json.dumps(disabled)}],
                    [],
                    [],
                    [],
                ]
            )
        )
        handler = GenerateValidationQueriesHandler(task_queue, warehouse)
        task = Task(
            workflow_id=10,
            executor_type=ExecutorType.ORCHESTRATOR,
            task_name="gen",
            payload=GenerateValidationQueriesPayload(
                table_metadata_id=42,
                source_identifier="db.schema.t",
                workflow_id=10,
                source_platform="snowflake",
            ),
            scope="DV::Table[db.schema.t]::Preprocessing",
            id=1,
        )
        asyncio.run(handler.handle(task))

        sqls = [c[0][0] for c in warehouse.execute_sync_query.call_args_list]
        preprocessed = [s for s in sqls if "HAS_BEEN_PREPROCESSED = TRUE" in s]
        assert len(preprocessed) == 1
        assert fq_table_metadata() in preprocessed[0]
        assert "WHERE ID = 42" in preprocessed[0]
        task_queue.complete_task.assert_called_once_with(ExecutorType.ORCHESTRATOR, 1)


class TestPartitionNumberFromDvScope:
    """Scope parsing for partition progress updates."""

    def test_parses_partition_from_metrics_write_scope(self):
        scope = "DV::Table[db.schema.t]::Partition[7]::WriteResults[metrics]"
        assert partition_number_from_dv_task_scope(scope) == 7

    def test_returns_none_when_partition_absent(self):
        scope = "DV::Table[db.schema.t]::WriteResults[schema]"
        assert partition_number_from_dv_task_scope(scope) is None

    def test_partition_none_literal(self):
        scope = "DV::Table[x]::Partition[None]::WriteResults[row]"
        assert partition_number_from_dv_task_scope(scope) is None


# =========================================================================
# Condition building tests (EvaluateLevelResultHandler)
# =========================================================================


class TestBuildScopedWhere:
    """Tests for _build_scoped_where condition building."""

    def test_no_partition_column_returns_user_where(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="status = 'active'",
            partition_column=None,
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert result == "status = 'active'"

    def test_null_bounds_returns_user_where(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="status = 'active'",
            partition_column="id",
            min_value=None,
            max_value=None,
            source_platform="redshift",
            target_side=True,
        )
        assert result == "status = 'active'"

    def test_target_side_uses_snowflake_condition(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert "id >= 100" in result
        assert "id <= 200" in result

    def test_source_side_uses_platform_registry(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=False,
        )
        assert "id" in result
        assert ">=" in result

    def test_combines_user_where_with_partition(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="status = 'active'",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert "(status = 'active') AND" in result
        assert "id >= 100" in result

    def test_empty_user_where_returns_only_partition(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert "status" not in result
        assert "id >= 100" in result

    def test_only_min_value_target_side(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=None,
            source_platform="redshift",
            target_side=True,
        )
        assert "id > 100" in result

    def test_only_max_value_target_side(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=None,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert "id < 200" in result

    def test_unknown_source_platform_falls_back_to_snowflake(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="unknown_db",
            target_side=False,
        )
        assert "id >= 100" in result


# =========================================================================
# DEA Payload tests
# =========================================================================


class TestDEAPayloadWhereClause:
    """Tests for where clause fields on DataValidationTaskPayload and factory."""

    def test_payload_has_where_clause_fields(self):
        payload = DataValidationTaskPayload(
            source_query="SELECT 1",
            target_query="SELECT 1",
            validation_type="row",
            source_platform="redshift",
            target_type="snowflake:stage",
            target_id="@stage/1/1/row",
            table_name="db.schema.t",
            table_metadata_id=1,
            workflow_id=1,
            partition_number=None,
            database="",
            schema="",
            source_where_clause="id >= 100 AND id <= 200",
            target_where_clause="id >= 100 AND id <= 200",
        )
        assert payload.source_where_clause == "id >= 100 AND id <= 200"
        assert payload.target_where_clause == "id >= 100 AND id <= 200"

    def test_payload_defaults_where_clause_to_none(self):
        payload = DataValidationTaskPayload(
            source_query="",
            target_query="",
            validation_type="row",
            source_platform="redshift",
            target_type="snowflake:stage",
            target_id="@stage/1/1/row",
            table_name="t",
            table_metadata_id=1,
            workflow_id=1,
            partition_number=None,
            database="",
            schema="",
        )
        assert payload.source_where_clause is None
        assert payload.target_where_clause is None

    def test_factory_row_payload_passes_where_clauses(self):
        factory = DEAPayloadFactory(
            workflow_id=1,
            table_metadata_id=1,
            source_identifier="db.schema.t",
            source_platform="redshift",
        )
        payload = factory.row_payload(
            partition_number=1,
            source_where_clause="id >= 100",
            target_where_clause="id >= 100",
        )
        assert payload.source_where_clause == "id >= 100"
        assert payload.target_where_clause == "id >= 100"

    def test_factory_row_payload_defaults_where_to_none(self):
        factory = DEAPayloadFactory(
            workflow_id=1,
            table_metadata_id=1,
            source_identifier="db.schema.t",
            source_platform="redshift",
        )
        payload = factory.row_payload()
        assert payload.source_where_clause is None
        assert payload.target_where_clause is None


# =========================================================================
# L2 metrics query WHERE clause passthrough tests
# =========================================================================


class TestMetricsQueryWhereClause:
    """Verify build_metrics_queries and _build_table_context propagate WHERE clauses."""

    def test_build_table_context_sets_where_clause(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _build_table_context,
        )
        from snowflake.snowflake_data_validation.public import Origin, Platform

        ctx = _build_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.TARGET,
            database_name="db",
            schema_name="schema",
            table_name="t",
            where_clause="id >= 100 AND id <= 200",
        )
        assert ctx.has_where_clause is True
        assert ctx.where_clause == "id >= 100 AND id <= 200"

    def test_build_table_context_no_where_clause(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _build_table_context,
        )
        from snowflake.snowflake_data_validation.public import Origin, Platform

        ctx = _build_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.TARGET,
            database_name="db",
            schema_name="schema",
            table_name="t",
        )
        assert ctx.has_where_clause is False
        assert ctx.where_clause == ""

    def test_build_table_context_empty_string_where(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _build_table_context,
        )
        from snowflake.snowflake_data_validation.public import Origin, Platform

        ctx = _build_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.TARGET,
            database_name="db",
            schema_name="schema",
            table_name="t",
            where_clause="",
        )
        assert ctx.has_where_clause is False
        assert ctx.where_clause == ""

    def test_build_table_context_two_part_name_no_leading_dot(self):
        """Teradata-style db.table is parsed as ('', db, table); FQN must not start with '.'."""
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _build_table_context,
            build_schema_queries,
        )
        from snowflake.snowflake_data_validation.public import Origin, Platform

        ctx = _build_table_context(
            platform=Platform.TERADATA,
            origin=Origin.SOURCE,
            database_name="",
            schema_name="tpcds",
            table_name="catalog_sales",
        )
        assert ctx.fully_qualified_name == "TPCDS.CATALOG_SALES"
        assert not ctx.fully_qualified_name.startswith(".")

        source_sql, _ = build_schema_queries(
            source_platform_str="teradata",
            source_db="",
            source_schema="tpcds",
            source_table="catalog_sales",
            target_db="TPCDS_BENCHMARK",
            target_schema="PUBLIC",
            target_table="CATALOG_SALES",
        )
        assert "FROM TPCDS.CATALOG_SALES" in source_sql.replace("\n", " ")
        assert "FROM .TPCDS" not in source_sql


class TestDEAPayloadFactoryStagePath:
    """Tests for stage_path and metrics_payload."""

    def _factory(self):
        return DEAPayloadFactory(
            workflow_id=42,
            table_metadata_id=7,
            source_identifier="db.schema.t",
            source_platform="redshift",
        )

    def test_stage_path_with_partition(self):
        path = self._factory().stage_path("metrics", partition_number=1)
        assert path.endswith("/metrics/p1")

    def test_stage_path_no_partition(self):
        path = self._factory().stage_path("metrics")
        assert path.endswith("/metrics")
        assert "/p" not in path

    def test_metrics_payload_partition_in_target_id(self):
        factory = self._factory()
        payload = factory.metrics_payload(
            source_query="SELECT 1",
            target_query="SELECT 2",
            partition_number=3,
        )
        assert "/p3" in payload.target_id

    def test_metrics_payload_no_partition(self):
        factory = self._factory()
        payload = factory.metrics_payload(
            source_query="SELECT 1",
            target_query="SELECT 2",
        )
        assert payload.target_id.endswith("/metrics")
        assert "/p" not in payload.target_id


class TestBuildBatchedPartitionMetricsQueries:
    """Tests for _build_batched_partition_metrics_queries static method."""

    @staticmethod
    def _make_ctx() -> dict:
        from unittest.mock import Mock

        cols = [Mock(name=f"C{i}", data_type="INTEGER") for i in range(10)]
        return {
            "src_db": "SDB",
            "src_schema": "SSCH",
            "src_table": "ST",
            "tgt_db": "TDB",
            "tgt_schema": "TSCH",
            "tgt_table": "TT",
            "src_fq": "SDB.SSCH.ST",
            "tgt_fq": "TDB.TSCH.TT",
            "source_columns": cols,
            "target_columns": cols,
        }

    def test_returns_list_of_tuples(self):
        from unittest.mock import patch

        ctx = self._make_ctx()
        with patch(
            "data_migration_orchestrator.data_validation_cloud.tasks.handlers.evaluate_level_result_handler.build_batched_metrics_queries",
            return_value=[
                ("SELECT src_1", "SELECT tgt_1"),
                ("SELECT src_2", "SELECT tgt_2"),
            ],
        ):
            result = (
                EvaluateLevelResultHandler._build_batched_partition_metrics_queries(
                    ctx, source_platform="redshift"
                )
            )
        assert isinstance(result, list)
        assert len(result) == 2
        for pair in result:
            assert isinstance(pair, tuple)
            assert len(pair) == 2

    def test_delegates_to_build_batched_metrics_queries(self):
        from unittest.mock import patch

        ctx = self._make_ctx()
        with patch(
            "data_migration_orchestrator.data_validation_cloud.tasks.handlers.evaluate_level_result_handler.build_batched_metrics_queries",
            return_value=[("S1", "T1")],
        ) as mock_build:
            EvaluateLevelResultHandler._build_batched_partition_metrics_queries(
                ctx, source_platform="teradata", source_where_clause="id > 5"
            )
        mock_build.assert_called_once()
        call_kwargs = mock_build.call_args
        assert call_kwargs[1]["source_platform_str"] == "teradata"
        assert call_kwargs[1]["source_where_clause"] == "id > 5"


class TestSchemaQueryWhereClause:
    """Verify build_schema_queries propagates WHERE clauses into the rc_cte."""

    def test_schema_query_includes_source_where_clause(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            build_schema_queries,
        )

        source_sql, target_sql = build_schema_queries(
            source_platform_str="teradata",
            source_db="FINLGLDB",
            source_schema="",
            source_table="N_JOURNAL_ENTRY_LINE",
            target_db="EDW_FINANCE_BR_DB",
            target_schema="BR",
            target_table="N_JOURNAL_ENTRY_LINE",
            source_where_clause="PARTITION_COL >= 100",
        )
        assert "WHERE PARTITION_COL >= 100" in source_sql
        rc_cte_section = target_sql.split("rc_cte AS (")[1].split(")")[0]
        assert "WHERE" not in rc_cte_section

    def test_schema_query_includes_target_where_clause(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            build_schema_queries,
        )

        source_sql, target_sql = build_schema_queries(
            source_platform_str="teradata",
            source_db="FINLGLDB",
            source_schema="",
            source_table="N_JOURNAL_ENTRY_LINE",
            target_db="EDW_FINANCE_BR_DB",
            target_schema="BR",
            target_table="N_JOURNAL_ENTRY_LINE",
            target_where_clause="PARTITION_COL >= 100",
        )
        assert "WHERE PARTITION_COL >= 100" in target_sql

    def test_schema_query_no_where_clause_by_default(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            build_schema_queries,
        )

        source_sql, _ = build_schema_queries(
            source_platform_str="teradata",
            source_db="FINLGLDB",
            source_schema="",
            source_table="N_JOURNAL_ENTRY_LINE",
            target_db="EDW_FINANCE_BR_DB",
            target_schema="BR",
            target_table="N_JOURNAL_ENTRY_LINE",
        )
        flat = source_sql.replace("\n", " ")
        assert "WHERE" not in flat.split("DBC.Columns")[0]


# =========================================================================
# Sentinel-based batched metrics query generation tests
# =========================================================================


class TestStampWhereClause:
    """Tests for _stamp_where_clause sentinel replacement."""

    def test_replaces_sentinel_with_actual_where(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _WHERE_SENTINEL,
            _stamp_where_clause,
        )

        template = f"SELECT 1 FROM t WHERE {_WHERE_SENTINEL} "
        result = _stamp_where_clause(template, "id > 5")
        assert "WHERE id > 5" in result
        assert _WHERE_SENTINEL not in result

    def test_removes_sentinel_when_where_is_empty(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _WHERE_SENTINEL,
            _stamp_where_clause,
        )

        template = f"SELECT 1 FROM t WHERE {_WHERE_SENTINEL} )"
        result = _stamp_where_clause(template, "")
        assert "WHERE" not in result
        assert _WHERE_SENTINEL not in result

    def test_handles_multiple_cte_occurrences(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _WHERE_SENTINEL,
            _stamp_where_clause,
        )

        cte = f'"c" AS (SELECT 1 FROM t WHERE {_WHERE_SENTINEL} )'
        template = f"WITH {cte}, {cte}"
        result = _stamp_where_clause(template, "x = 1")
        assert result.count("WHERE x = 1") == 2
        assert _WHERE_SENTINEL not in result


class TestBuildBatchedMetricsQueriesForPartitions:
    """Tests for the partition-optimised batched metrics query builder."""

    def test_produces_same_results_as_per_partition_calls(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            build_batched_metrics_queries,
            build_batched_metrics_queries_for_partitions,
            make_column_metadata,
        )

        cols = [
            make_column_metadata("COL_A", "INTEGER"),
            make_column_metadata("COL_B", "VARCHAR"),
        ]
        where_pairs = [
            ("id >= 0 AND id < 100", "id >= 0 AND id < 100"),
            ("id >= 100 AND id < 200", "id >= 100 AND id < 200"),
            ("", ""),
        ]

        optimised = build_batched_metrics_queries_for_partitions(
            source_platform_str="teradata",
            source_db="SDB",
            source_schema="",
            source_table="T",
            source_columns=cols,
            target_db="TDB",
            target_schema="SCH",
            target_table="T",
            target_columns=cols,
            partition_where_clauses=where_pairs,
        )

        for idx, (src_where, tgt_where) in enumerate(where_pairs):
            baseline = build_batched_metrics_queries(
                source_platform_str="teradata",
                source_db="SDB",
                source_schema="",
                source_table="T",
                source_columns=cols,
                target_db="TDB",
                target_schema="SCH",
                target_table="T",
                target_columns=cols,
                source_where_clause=src_where,
                target_where_clause=tgt_where,
            )
            assert len(optimised[idx]) == len(baseline)
            for (opt_src, opt_tgt), (base_src, base_tgt) in zip(
                optimised[idx], baseline, strict=True
            ):
                assert opt_src == base_src
                assert opt_tgt == base_tgt

    def test_single_partition_no_where(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _WHERE_SENTINEL,
            build_batched_metrics_queries_for_partitions,
            make_column_metadata,
        )

        cols = [make_column_metadata("X", "INTEGER")]
        result = build_batched_metrics_queries_for_partitions(
            source_platform_str="teradata",
            source_db="DB",
            source_schema="",
            source_table="T",
            source_columns=cols,
            target_db="TDB",
            target_schema="S",
            target_table="T",
            target_columns=cols,
            partition_where_clauses=[("", "")],
        )
        assert len(result) == 1
        for src_q, tgt_q in result[0]:
            assert _WHERE_SENTINEL not in src_q
            assert _WHERE_SENTINEL not in tgt_q
            assert "WHERE" not in src_q
            assert "WHERE" not in tgt_q

    def test_returns_correct_partition_count(self):

        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            build_batched_metrics_queries_for_partitions,
            make_column_metadata,
        )

        cols = [make_column_metadata("A", "INTEGER")]
        where_pairs = [
            ("p >= 0", "p >= 0"),
            ("p >= 100", "p >= 100"),
            ("p >= 200", "p >= 200"),
        ]
        result = build_batched_metrics_queries_for_partitions(
            source_platform_str="teradata",
            source_db="DB",
            source_schema="",
            source_table="T",
            source_columns=cols,
            target_db="TDB",
            target_schema="S",
            target_table="T",
            target_columns=cols,
            partition_where_clauses=where_pairs,
        )
        assert len(result) == 3
