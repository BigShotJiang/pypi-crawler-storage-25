"""Tests for sdv_query_helper identifier normalization."""

import pytest

from snowflake.snowflake_data_validation.public import Platform

from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
    _normalize_identifier,
)


class TestNormalizeIdentifier:
    """Tests for _normalize_identifier across all supported platforms."""

    @pytest.mark.parametrize(
        "platform",
        [Platform.SNOWFLAKE, Platform.TERADATA],
    )
    def test_uppercasing_platforms(self, platform: Platform):
        assert _normalize_identifier("My_Table", platform) == "MY_TABLE"

    def test_redshift_lowercases(self):
        assert _normalize_identifier("My_Table", Platform.REDSHIFT) == "my_table"

    def test_sqlserver_preserves_case(self):
        assert _normalize_identifier("My_Table", Platform.SQLSERVER) == "My_Table"

    def test_already_uppercase_is_noop(self):
        assert _normalize_identifier("BASIC", Platform.SNOWFLAKE) == "BASIC"

    def test_already_lowercase_is_noop(self):
        assert _normalize_identifier("basic", Platform.REDSHIFT) == "basic"

    def test_empty_string(self):
        assert _normalize_identifier("", Platform.SNOWFLAKE) == ""
