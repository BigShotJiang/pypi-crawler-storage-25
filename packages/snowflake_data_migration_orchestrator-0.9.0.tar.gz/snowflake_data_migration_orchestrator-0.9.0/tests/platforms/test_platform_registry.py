"""
Unit tests for PlatformRegistry.

Tests the platform registration, retrieval, and alias resolution functionality.
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.platforms.base_platform import (
    BasePlatform,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)


class MockQueryBuilder(BaseQueryBuilder):
    """Mock query builder for testing."""

    @property
    def platform_name(self) -> str:
        return "mock"

    @property
    def identifier_quote_char(self) -> tuple[str, str]:
        return ('"', '"')

    def build_metadata_query(self, table_name: str) -> str:
        return f"SELECT COUNT(*) FROM {table_name}"

    def build_schema_query(self, table_name: str) -> str:
        return f"SELECT * FROM information_schema.columns WHERE table_name = '{table_name}'"

    def build_partition_boundary_query(
        self, table_name: str, column: str, num_partitions: int
    ) -> str:
        return (
            f"SELECT NTILE({num_partitions}) OVER (ORDER BY {column}) FROM {table_name}"
        )

    def quote_identifier(self, identifier: str) -> str:
        return f'"{identifier}"'

    def normalize_identifier(self, identifier: str) -> str:
        return identifier

    def quote_column_name(self, column_name: str) -> str:
        return column_name


class MockPlatform(BasePlatform):
    """Mock platform for testing."""

    @property
    def name(self) -> str:
        return "mock"

    @property
    def display_name(self) -> str:
        return "Mock Platform"

    @property
    def aliases(self) -> list[str]:
        return ["mockdb", "test-mock"]

    @property
    def default_strategy(self) -> str:
        return "odbc"

    @property
    def supported_strategies(self) -> list[str]:
        return ["odbc"]

    @property
    def query_builder(self) -> BaseQueryBuilder:
        return MockQueryBuilder()

    @property
    def type_mappings(self) -> dict[str, str]:
        return {"INT": "NUMBER", "VARCHAR": "VARCHAR"}


@pytest.fixture(autouse=True)
def reset_registry():
    """Reset the registry before each test and restore after."""
    # Save original state
    original_registry = PlatformRegistry._registry.copy()
    original_aliases = PlatformRegistry._aliases.copy()
    # Clear for test isolation
    PlatformRegistry._registry = {}
    PlatformRegistry._aliases = {}
    yield
    # Restore original state so other tests are not affected
    PlatformRegistry._registry = original_registry
    PlatformRegistry._aliases = original_aliases


class TestPlatformRegistry:
    """Tests for PlatformRegistry."""

    def test_register_platform(self):
        """Test registering a platform."""
        PlatformRegistry.register("mock", MockPlatform)
        assert PlatformRegistry.is_registered("mock")
        assert "mock" in PlatformRegistry.list_types()

    def test_get_registered_platform(self):
        """Test retrieving a registered platform."""
        PlatformRegistry.register("mock", MockPlatform)
        platform_class = PlatformRegistry.get("mock")
        assert platform_class == MockPlatform

    def test_get_unregistered_platform_raises_error(self):
        """Test that getting an unregistered platform raises KeyError."""
        with pytest.raises(KeyError) as exc_info:
            PlatformRegistry.get("nonexistent")
        assert "nonexistent" in str(exc_info.value)
        assert "not registered" in str(exc_info.value)

    def test_create_platform_instance(self):
        """Test creating a platform instance."""
        PlatformRegistry.register("mock", MockPlatform)
        platform = PlatformRegistry.create("mock")
        assert isinstance(platform, MockPlatform)
        assert platform.name == "mock"

    def test_list_types(self):
        """Test listing registered platform types."""
        PlatformRegistry.register("mock", MockPlatform)
        types = PlatformRegistry.list_types()
        assert "mock" in types

    def test_is_registered(self):
        """Test checking if a platform is registered."""
        assert not PlatformRegistry.is_registered("mock")
        PlatformRegistry.register("mock", MockPlatform)
        assert PlatformRegistry.is_registered("mock")

    def test_register_alias(self):
        """Test registering platform aliases."""
        PlatformRegistry.register("mock", MockPlatform)
        PlatformRegistry.register_alias("mockdb", "mock")
        PlatformRegistry.register_alias("test-mock", "mock")

        assert PlatformRegistry.resolve_alias("mockdb") == "mock"
        assert PlatformRegistry.resolve_alias("test-mock") == "mock"
        assert (
            PlatformRegistry.resolve_alias("mock") == "mock"
        )  # Non-alias returns itself

    def test_get_with_alias(self):
        """Test getting a platform using an alias."""
        PlatformRegistry.register("mock", MockPlatform)
        PlatformRegistry.register_alias("mockdb", "mock")

        platform_class = PlatformRegistry.get_by_name_or_alias("mockdb")
        assert platform_class == MockPlatform

    def test_list_platforms(self):
        """Test listing all registered platforms."""
        PlatformRegistry.register("mock", MockPlatform)
        platforms = PlatformRegistry.list_platforms()
        assert "mock" in platforms

    def test_error_message_lists_available_platforms(self):
        """Test that error message lists available platforms."""
        PlatformRegistry.register("mock", MockPlatform)
        with pytest.raises(KeyError) as exc_info:
            PlatformRegistry.get("invalid")
        assert "mock" in str(exc_info.value)
