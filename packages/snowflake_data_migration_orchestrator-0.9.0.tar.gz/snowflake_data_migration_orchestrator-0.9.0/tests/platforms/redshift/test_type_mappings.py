"""
Unit tests for Redshift type mappings registration and lookup.

Tests verify that:
1. Redshift is registered in the default type mapping registry
2. Type mappings can be loaded and accessed
3. Case-insensitive lookup works correctly
4. All expected Redshift types are mapped
"""

import pytest

from data_migration_orchestrator.data_migration_core.type_mappings import (
    TypeMappingCategory,
)
from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
    TypeMappingLoader,
)
from data_migration_orchestrator.data_migration_core.type_mappings.default_mappings import (
    get_available_source_types,
    get_default_mappings,
)
from shared.enums.source_type import SourceType


class TestRedshiftTypeMappingRegistration:
    """Tests for Redshift type mapping registration."""

    def test_redshift_in_available_source_types(self):
        """Test that Redshift is registered in default mappings."""
        source_types = get_available_source_types()
        assert SourceType.REDSHIFT.value in source_types

    def test_redshift_mappings_loadable(self):
        """Test that Redshift mappings can be loaded."""
        redshift_mappings = get_default_mappings(SourceType.REDSHIFT.value)
        assert redshift_mappings is not None
        assert len(redshift_mappings) > 0

    def test_redshift_has_expected_mapping_count(self):
        """Test that Redshift has a reasonable number of type mappings."""
        redshift_mappings = get_default_mappings(SourceType.REDSHIFT.value)
        # Redshift should have at least the basic types mapped
        assert len(redshift_mappings) >= 10


class TestRedshiftSpecificTypeMappings:
    """Tests for specific Redshift type mappings."""

    @pytest.fixture
    def redshift_mappings(self):
        """Get Redshift type mappings."""
        return get_default_mappings(SourceType.REDSHIFT.value)

    def test_integer_mapping(self, redshift_mappings):
        """Test that integer type is mapped correctly."""
        assert "integer" in redshift_mappings
        assert redshift_mappings["integer"] == "NUMBER(10,0)"

    def test_character_varying_mapping(self, redshift_mappings):
        """Test that character varying type is mapped correctly."""
        assert "character varying" in redshift_mappings
        assert redshift_mappings["character varying"] == "VARCHAR"

    def test_timestamp_without_time_zone_mapping(self, redshift_mappings):
        """Test that timestamp without time zone type is mapped correctly."""
        assert "timestamp without time zone" in redshift_mappings
        assert redshift_mappings["timestamp without time zone"] == "TIMESTAMP_NTZ"

    def test_boolean_mapping(self, redshift_mappings):
        """Test that boolean type is mapped correctly."""
        assert "boolean" in redshift_mappings
        assert redshift_mappings["boolean"] == "BOOLEAN"

    def test_all_keys_are_lowercase(self, redshift_mappings):
        """Test that all mapping keys are stored in lowercase."""
        for key in redshift_mappings.keys():
            assert key == key.lower(), f"Key '{key}' is not lowercase"


class TestRedshiftTypeMappingLoader:
    """Tests for TypeMappingLoader with Redshift source type."""

    @pytest.fixture
    def loader(self) -> TypeMappingLoader:
        """Create a TypeMappingLoader for Redshift."""
        return TypeMappingLoader(source_type=SourceType.REDSHIFT)

    def test_loader_initialization(self, loader: TypeMappingLoader):
        """Test that TypeMappingLoader can be initialized for Redshift."""
        assert loader.source_type == SourceType.REDSHIFT
        assert loader._source_info is not None

    def test_loader_has_mappings(self, loader: TypeMappingLoader):
        """Test that loader has mappings loaded."""
        all_mappings = loader.get_all_mappings()
        assert len(all_mappings) > 0

    def test_get_snowflake_type_uppercase(self, loader: TypeMappingLoader):
        """Test type lookup with UPPERCASE (as from information_schema)."""
        assert loader.get_snowflake_type("INTEGER") == "NUMBER(10,0)"
        assert loader.get_snowflake_type("CHARACTER VARYING") == "VARCHAR"
        assert (
            loader.get_snowflake_type("TIMESTAMP WITHOUT TIME ZONE") == "TIMESTAMP_NTZ"
        )
        assert loader.get_snowflake_type("BOOLEAN") == "BOOLEAN"

    def test_get_snowflake_type_lowercase(self, loader: TypeMappingLoader):
        """Test type lookup with lowercase."""
        assert loader.get_snowflake_type("integer") == "NUMBER(10,0)"
        assert loader.get_snowflake_type("character varying") == "VARCHAR"
        assert (
            loader.get_snowflake_type("timestamp without time zone") == "TIMESTAMP_NTZ"
        )
        assert loader.get_snowflake_type("boolean") == "BOOLEAN"

    def test_get_snowflake_type_mixedcase(self, loader: TypeMappingLoader):
        """Test type lookup with mixed case."""
        assert loader.get_snowflake_type("Integer") == "NUMBER(10,0)"
        assert loader.get_snowflake_type("Character Varying") == "VARCHAR"
        assert loader.get_snowflake_type("Boolean") == "BOOLEAN"


class TestRedshiftCaseInsensitiveLookup:
    """Tests for case-insensitive type lookup."""

    @pytest.fixture
    def loader(self) -> TypeMappingLoader:
        """Create a TypeMappingLoader for Redshift."""
        return TypeMappingLoader(source_type=SourceType.REDSHIFT)

    @pytest.mark.parametrize(
        "type_variant",
        [
            "integer",
            "INTEGER",
            "Integer",
            "InTeGeR",
        ],
    )
    def test_integer_case_variations(
        self, loader: TypeMappingLoader, type_variant: str
    ):
        """Test that integer type lookup works with any case."""
        snowflake_type = loader.get_snowflake_type(type_variant)
        assert snowflake_type == "NUMBER(10,0)"

    @pytest.mark.parametrize(
        "type_variant",
        [
            "character varying",
            "CHARACTER VARYING",
            "Character Varying",
            "ChArAcTeR VaRyInG",
        ],
    )
    def test_character_varying_case_variations(
        self, loader: TypeMappingLoader, type_variant: str
    ):
        """Test that character varying lookup works with any case."""
        snowflake_type = loader.get_snowflake_type(type_variant)
        assert snowflake_type == "VARCHAR"

    @pytest.mark.parametrize(
        "type_variant",
        [
            "timestamp without time zone",
            "TIMESTAMP WITHOUT TIME ZONE",
            "Timestamp Without Time Zone",
        ],
    )
    def test_timestamp_case_variations(
        self, loader: TypeMappingLoader, type_variant: str
    ):
        """Test that timestamp type lookup works with any case."""
        snowflake_type = loader.get_snowflake_type(type_variant)
        assert snowflake_type == "TIMESTAMP_NTZ"


class TestRedshiftTypeMappingIntegration:
    """Integration tests for Redshift type mapping system."""

    def test_redshift_available_in_registry(self):
        """Test that Redshift is available in the loader registry."""
        available_types = TypeMappingLoader.get_available_source_types()
        assert SourceType.REDSHIFT.value in available_types

    def test_loader_creation_does_not_raise(self):
        """Test that creating a Redshift loader does not raise an error."""
        try:
            loader = TypeMappingLoader(source_type=SourceType.REDSHIFT)
            assert loader is not None
        except Exception as e:
            pytest.fail(f"Failed to create TypeMappingLoader for Redshift: {e}")

    def test_end_to_end_type_lookup(self):
        """Test complete workflow of looking up Redshift type mappings."""
        # Initialize loader
        loader = TypeMappingLoader(source_type=SourceType.REDSHIFT)

        # Get mapping for common Redshift types
        int_mapping = loader.get_mapping("INTEGER")
        assert int_mapping is not None
        assert int_mapping.source_type == "INTEGER"
        assert int_mapping.snowflake_type == "NUMBER(10,0)"
        assert int_mapping.category == TypeMappingCategory.NUMERIC

        varchar_mapping = loader.get_mapping("CHARACTER VARYING")
        assert varchar_mapping is not None
        assert varchar_mapping.source_type == "CHARACTER VARYING"
        assert varchar_mapping.snowflake_type == "VARCHAR"
        assert varchar_mapping.category == TypeMappingCategory.CHARACTER

    def test_list_all_redshift_source_types(self):
        """Test listing all Redshift source types."""
        loader = TypeMappingLoader(source_type=SourceType.REDSHIFT)
        source_types = loader.list_all_source_types()

        assert isinstance(source_types, list)
        assert len(source_types) > 0
        # Verify some expected types are present
        assert "INTEGER" in source_types or "integer" in [
            t.upper() for t in source_types
        ]
        assert "BOOLEAN" in source_types or "boolean" in [
            t.upper() for t in source_types
        ]

        # Verify list is sorted
        assert source_types == sorted(source_types)


class TestRedshiftCommonTypes:
    """Tests for common Redshift data types."""

    @pytest.fixture
    def loader(self) -> TypeMappingLoader:
        """Create a TypeMappingLoader for Redshift."""
        return TypeMappingLoader(source_type=SourceType.REDSHIFT)

    def test_numeric_types(self, loader: TypeMappingLoader):
        """Test numeric type mappings."""
        # Test common numeric types
        numeric_types = [
            ("SMALLINT", "NUMBER(5,0)"),
            ("INTEGER", "NUMBER(10,0)"),
            ("BIGINT", "NUMBER(19,0)"),
            ("DECIMAL", "NUMBER(20,10)"),
            ("NUMERIC", "NUMBER(20,10)"),
            ("REAL", "FLOAT"),
            ("DOUBLE PRECISION", "FLOAT"),
        ]

        for source_type, expected_target in numeric_types:
            actual_target = loader.get_snowflake_type(source_type)
            assert (
                actual_target == expected_target
            ), f"{source_type} should map to {expected_target}, got {actual_target}"

    def test_string_types(self, loader: TypeMappingLoader):
        """Test string type mappings."""
        string_types = [
            ("CHAR", "VARCHAR"),
            ("CHARACTER", "VARCHAR"),
            ("VARCHAR", "VARCHAR"),
            ("CHARACTER VARYING", "VARCHAR"),
            ("TEXT", "VARCHAR"),
        ]

        for source_type, expected_target in string_types:
            actual_target = loader.get_snowflake_type(source_type)
            assert (
                actual_target == expected_target
            ), f"{source_type} should map to {expected_target}, got {actual_target}"

    def test_datetime_types(self, loader: TypeMappingLoader):
        """Test date and time type mappings."""
        datetime_types = [
            ("DATE", "DATE"),
            ("TIMESTAMP", "TIMESTAMP_NTZ"),
            ("TIMESTAMP WITHOUT TIME ZONE", "TIMESTAMP_NTZ"),
            ("TIMESTAMP WITH TIME ZONE", "TIMESTAMP_TZ"),
            ("TIMESTAMPTZ", "TIMESTAMP_TZ"),
        ]

        for source_type, expected_target in datetime_types:
            actual_target = loader.get_snowflake_type(source_type)
            assert (
                actual_target == expected_target
            ), f"{source_type} should map to {expected_target}, got {actual_target}"

    def test_boolean_type(self, loader: TypeMappingLoader):
        """Test boolean type mapping."""
        assert loader.get_snowflake_type("BOOLEAN") == "BOOLEAN"
        assert loader.get_snowflake_type("BOOL") == "BOOLEAN"
