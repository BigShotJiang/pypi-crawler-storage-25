"""
Unit tests for Redshift metadata and schema query generation via RedshiftQueryBuilder.

Tests verify that:
1. Metadata queries use SVV_TABLE_INFO with correct filtering
2. Schema queries use information_schema.columns with correct filtering
3. Query structure includes expected column aliases
4. Metadata and schema queries are meaningfully different
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.redshift.query_builder import (
    RedshiftQueryBuilder,
)


@pytest.fixture
def builder() -> RedshiftQueryBuilder:
    """Create a RedshiftQueryBuilder instance for testing."""
    return RedshiftQueryBuilder()


def _table(
    schema: str = "public", table: str = "customers", database: str = "mydb"
) -> TableIdentifier:
    return TableIdentifier(database_name=database, schema_name=schema, table_name=table)


class TestRedshiftMetadataQuery:
    """Tests for RedshiftQueryBuilder.build_metadata_query."""

    def test_uses_svv_table_info(self, builder: RedshiftQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert "svv_table_info" in query.lower()

    def test_returns_row_count_column(self, builder: RedshiftQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert "row_count" in query.lower()

    def test_returns_data_size_mb_column(self, builder: RedshiftQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert "data_size_mb" in query.lower()

    def test_filters_by_schema(self, builder: RedshiftQueryBuilder):
        query = builder.build_metadata_query(_table(schema="ecommerce_raw"))
        assert "ecommerce_raw" in query

    def test_filters_by_table(self, builder: RedshiftQueryBuilder):
        query = builder.build_metadata_query(_table(table="orders"))
        assert "orders" in query

    def test_starts_with_select(self, builder: RedshiftQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert query.strip().upper().startswith("SELECT")

    def test_is_substantial(self, builder: RedshiftQueryBuilder):
        query = builder.build_metadata_query(_table())
        assert len(query) > 50

    def test_does_not_divide_size_by_1024(self, builder: RedshiftQueryBuilder):
        """svv_table_info.size is already in 1 MB blocks; no extra /1024."""
        query = builder.build_metadata_query(_table(table="lineitem"))
        assert "/ 1024 / 1024" not in query

    def test_uppercase_schema_table_folded_in_predicate(
        self, builder: RedshiftQueryBuilder
    ):
        """Unquoted-style names in config must match Redshift catalog (lowercase)."""
        query = builder.build_metadata_query(
            _table(schema="E2E_TESTS_REDSHIFT_UNLOAD", table="BASIC")
        )
        assert "'e2e_tests_redshift_unload'" in query
        assert "'basic'" in query
        assert "E2E_TESTS_REDSHIFT_UNLOAD" not in query
        assert "'BASIC'" not in query


class TestRedshiftSchemaQuery:
    """Tests for RedshiftQueryBuilder.build_schema_query."""

    def test_uses_information_schema(self, builder: RedshiftQueryBuilder):
        query = builder.build_schema_query(_table())
        assert "information_schema" in query.lower()

    def test_selects_column_name(self, builder: RedshiftQueryBuilder):
        query = builder.build_schema_query(_table())
        assert "column_name" in query.lower()

    def test_selects_data_type(self, builder: RedshiftQueryBuilder):
        query = builder.build_schema_query(_table())
        assert "data_type" in query.lower()

    def test_selects_ordinal_position(self, builder: RedshiftQueryBuilder):
        query = builder.build_schema_query(_table())
        assert "ordinal_position" in query.lower()

    def test_filters_by_schema(self, builder: RedshiftQueryBuilder):
        query = builder.build_schema_query(_table(schema="ecommerce_raw"))
        assert "ecommerce_raw" in query

    def test_filters_by_table(self, builder: RedshiftQueryBuilder):
        query = builder.build_schema_query(_table(table="products"))
        assert "products" in query

    def test_uppercase_schema_table_folded_in_predicate(
        self, builder: RedshiftQueryBuilder
    ):
        query = builder.build_schema_query(
            _table(schema="E2E_TESTS_REDSHIFT_UNLOAD", table="BASIC")
        )
        assert "'e2e_tests_redshift_unload'" in query
        assert "'basic'" in query

    def test_starts_with_select(self, builder: RedshiftQueryBuilder):
        query = builder.build_schema_query(_table())
        assert query.strip().upper().startswith("SELECT")

    def test_is_substantial(self, builder: RedshiftQueryBuilder):
        query = builder.build_schema_query(_table())
        assert len(query) > 50


class TestRedshiftQueryStructure:
    """Cross-cutting tests comparing metadata vs. schema queries."""

    def test_queries_differ_by_purpose(self, builder: RedshiftQueryBuilder):
        table = _table(schema="public", table="test_table")
        metadata = builder.build_metadata_query(table)
        schema = builder.build_schema_query(table)

        assert metadata != schema
        assert "svv_table_info" in metadata.lower()
        assert "information_schema" in schema.lower()

    def test_metadata_query_contains_schema_and_table(
        self, builder: RedshiftQueryBuilder
    ):
        table = _table(schema="ecommerce_prod", table="customer_orders")
        query = builder.build_metadata_query(table)

        assert "ecommerce_prod" in query
        assert "customer_orders" in query

    def test_schema_query_contains_schema_and_table(
        self, builder: RedshiftQueryBuilder
    ):
        table = _table(schema="ecommerce_prod", table="customer_orders")
        query = builder.build_schema_query(table)

        assert "ecommerce_prod" in query
        assert "customer_orders" in query
