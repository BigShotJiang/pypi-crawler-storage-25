"""Tests for Redshift identifier helpers used in catalog predicates."""

from data_migration_orchestrator.data_migration_cloud.platforms.redshift.identifiers import (
    redshift_catalog_string_value,
)


def test_redshift_catalog_string_value_unquoted_folds_lower():
    """Assert unquoted identifiers fold to lowercase."""
    assert redshift_catalog_string_value("E2E_TESTS") == "e2e_tests"
    assert redshift_catalog_string_value("BASIC") == "basic"


def test_redshift_catalog_string_value_double_quoted_preserves_inner():
    """Assert double-quoted identifiers preserve inner spelling."""
    assert redshift_catalog_string_value('"MixedCase"') == "MixedCase"


def test_redshift_catalog_string_value_bracket_delimited():
    """Assert bracket-delimited identifiers strip delimiters and preserve case."""
    assert redshift_catalog_string_value("[AlsoMixed]") == "AlsoMixed"


def test_redshift_catalog_string_value_escaped_quote_in_delimited():
    """Assert doubled quotes inside a delimited identifier unescape correctly."""
    assert redshift_catalog_string_value('"""a""b"') == '"a"b'


def test_redshift_catalog_string_value_empty():
    """Assert empty input returns empty string."""
    assert redshift_catalog_string_value("") == ""
