"""
Tests for SQL Server identifier parsing, normalization, quoting, and unquoting.

These tests exercise the SQL Server-specific logic via the ``SqlServerPlatform``
methods (which delegate to ``sqlserver/identifiers.py``) as well as the
lower-level quoting/unquoting functions directly.
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.identifiers import (
    is_already_quoted,
    needs_quoting,
    quote_identifier,
    unquote_identifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.platform import (
    SqlServerPlatform,
)


@pytest.fixture
def platform() -> SqlServerPlatform:
    """Return a SqlServerPlatform instance for testing."""
    return SqlServerPlatform()


# ---------------------------------------------------------------------------
# parse_table_name
# ---------------------------------------------------------------------------
class TestParseTableNameSqlServer:
    """Tests for SqlServerPlatform.parse_table_name."""

    def test_simple_three_part_name(self, platform: SqlServerPlatform):
        result = platform.parse_table_name("AdventureWorks.Sales.Customer")
        assert result.database == "AdventureWorks"
        assert result.schema == "Sales"
        assert result.table == "Customer"

    def test_bracketed_identifiers(self, platform: SqlServerPlatform):
        result = platform.parse_table_name("[my.db].[my.schema].[my.table]")
        assert result.database == "my.db"
        assert result.schema == "my.schema"
        assert result.table == "my.table"

    def test_mixed_bracketed_identifiers(self, platform: SqlServerPlatform):
        result = platform.parse_table_name("mydb.[my.schema].mytable")
        assert result.database == "mydb"
        assert result.schema == "my.schema"
        assert result.table == "mytable"

    def test_bracket_in_schema(self, platform: SqlServerPlatform):
        result = platform.parse_table_name("dbo.[Order Details]")
        assert result.database is None
        assert result.schema == "dbo"
        assert result.table == "Order Details"

    def test_double_quoted_identifiers(self, platform: SqlServerPlatform):
        result = platform.parse_table_name('"mydb"."my.schema"."mytable"')
        assert result.database == "mydb"
        assert result.schema == "my.schema"
        assert result.table == "mytable"

    def test_mixed_double_quoted_identifiers(self, platform: SqlServerPlatform):
        result = platform.parse_table_name('mydb."my.schema".mytable')
        assert result.database == "mydb"
        assert result.schema == "my.schema"
        assert result.table == "mytable"

    def test_double_quoted_with_escaped_quotes(self, platform: SqlServerPlatform):
        result = platform.parse_table_name('"My""Table"')
        assert result.database is None
        assert result.schema is None
        assert result.table == 'My"Table'

    def test_escaped_brackets(self, platform: SqlServerPlatform):
        result = platform.parse_table_name("[Table[1]]]")
        assert result.table == "Table[1]"

    def test_reserved_word(self, platform: SqlServerPlatform):
        result = platform.parse_table_name("dbo.Order")
        assert result.schema == "dbo"
        assert result.table == "Order"

    def test_empty_raises_error(self, platform: SqlServerPlatform):
        with pytest.raises(ValueError, match="table_name cannot be empty"):
            platform.parse_table_name("")

    def test_none_raises_error(self, platform: SqlServerPlatform):
        with pytest.raises(ValueError, match="table_name cannot be empty"):
            platform.parse_table_name(None)  # type: ignore

    def test_whitespace_only_raises_error(self, platform: SqlServerPlatform):
        with pytest.raises(ValueError, match="table_name cannot be empty"):
            platform.parse_table_name("   ")


# ---------------------------------------------------------------------------
# build_normalized_table_name
# ---------------------------------------------------------------------------
class TestBuildNormalizedTableNameSqlServer:
    """Tests for SqlServerPlatform.build_normalized_table_name."""

    def _tid(self, db: str, schema: str, table: str) -> TableIdentifier:
        return TableIdentifier(database_name=db, schema_name=schema, table_name=table)

    def test_simple_identifiers_uppercased(self, platform: SqlServerPlatform):
        ref = platform.build_normalized_table_name(
            self._tid("mydb", "myschema", "mytable")
        )
        assert ref == "MYDB.MYSCHEMA.MYTABLE"

    def test_without_schema(self, platform: SqlServerPlatform):
        ref = platform.build_normalized_table_name(self._tid("mydb", "", "mytable"))
        assert ref == "MYDB.MYTABLE"

    def test_special_chars_quoted(self, platform: SqlServerPlatform):
        ref = platform.build_normalized_table_name(
            self._tid("mydb", "dbo", "Order Details")
        )
        assert ref == 'MYDB.DBO."Order Details"'

    def test_dots_in_name_quoted(self, platform: SqlServerPlatform):
        ref = platform.build_normalized_table_name(
            self._tid("my.db", "my.schema", "my.table")
        )
        assert ref == '"my.db"."my.schema"."my.table"'

    def test_reserved_word_not_auto_quoted(self, platform: SqlServerPlatform):
        ref = platform.build_normalized_table_name(self._tid("mydb", "dbo", "Order"))
        assert ref == "MYDB.DBO.ORDER"

    def test_mixed_quoting(self, platform: SqlServerPlatform):
        ref = platform.build_normalized_table_name(
            self._tid("AdventureWorks", "Sales", "Order Details")
        )
        assert ref == 'ADVENTUREWORKS.SALES."Order Details"'

    def test_starts_with_digit_quoted(self, platform: SqlServerPlatform):
        ref = platform.build_normalized_table_name(self._tid("mydb", "dbo", "123Table"))
        assert ref == 'MYDB.DBO."123Table"'


# ---------------------------------------------------------------------------
# quote_column_name
# ---------------------------------------------------------------------------
class TestQuoteColumnNameSqlServer:
    """Tests for SqlServerPlatform.quote_column_name."""

    def test_simple_column_not_quoted(self, platform: SqlServerPlatform):
        assert platform.quote_column_name("id") == "id"

    def test_column_with_spaces_quoted(self, platform: SqlServerPlatform):
        assert platform.quote_column_name("Order Date") == '"Order Date"'

    def test_mixed_case_not_quoted(self, platform: SqlServerPlatform):
        assert platform.quote_column_name("CustomerID") == "CustomerID"

    def test_reserved_word_not_auto_quoted(self, platform: SqlServerPlatform):
        assert platform.quote_column_name("order") == "order"

    def test_special_chars_quoted(self, platform: SqlServerPlatform):
        assert platform.quote_column_name("my-column") == '"my-column"'


# ---------------------------------------------------------------------------
# Low-level quoting primitives
# ---------------------------------------------------------------------------
class TestIsAlreadyQuotedSqlServer:
    """Tests for is_already_quoted."""

    def test_brackets_are_quoted(self):
        assert is_already_quoted("[MyTable]") is True
        assert is_already_quoted("[Order Details]") is True
        assert is_already_quoted("[my.schema]") is True

    def test_unquoted_is_not_quoted(self):
        assert is_already_quoted("MyTable") is False
        assert is_already_quoted("dbo") is False
        assert is_already_quoted("") is False

    def test_partial_brackets_not_quoted(self):
        assert is_already_quoted("[MyTable") is False
        assert is_already_quoted("MyTable]") is False


class TestNeedsQuotingSqlServer:
    """Tests for needs_quoting."""

    def test_simple_identifiers_do_not_need_quoting(self):
        assert needs_quoting("mytable") is False
        assert needs_quoting("MyTable") is False
        assert needs_quoting("my_table_123") is False

    def test_spaces_need_quoting(self):
        assert needs_quoting("Order Details") is True
        assert needs_quoting("My Table") is True

    def test_special_chars_need_quoting(self):
        assert needs_quoting("my.table") is True
        assert needs_quoting("table-name") is True
        assert needs_quoting("table$name") is True

    def test_leading_digit_needs_quoting(self):
        assert needs_quoting("123table") is True
        assert needs_quoting("1_column") is True

    def test_reserved_words_not_auto_quoted(self):
        assert needs_quoting("SELECT") is False
        assert needs_quoting("ORDER") is False

    def test_already_quoted_does_not_need_quoting(self):
        assert needs_quoting("[MyTable]") is False
        assert needs_quoting("[Order Details]") is False


class TestQuoteIdentifierSqlServer:
    """Tests for quote_identifier."""

    def test_simple_identifier(self):
        assert quote_identifier("my_table") == '"my_table"'

    def test_spaces(self):
        assert quote_identifier("Order Details") == '"Order Details"'

    def test_special_chars(self):
        assert quote_identifier("my.table") == '"my.table"'

    def test_empty(self):
        assert quote_identifier("") == '""'

    def test_internal_double_quote_escaped(self):
        assert quote_identifier('Table"1') == '"Table""1"'

    def test_already_quoted_brackets_returned_as_is(self):
        assert quote_identifier("[MyTable]") == "[MyTable]"

    def test_already_quoted_double_returned_as_is(self):
        assert quote_identifier('"MyTable"') == '"MyTable"'

    def test_no_force_simple_not_quoted(self):
        assert quote_identifier("mytable", force_quote=False) == "mytable"

    def test_no_force_needs_quoting_still_quoted(self):
        assert quote_identifier("Order Details", force_quote=False) == '"Order Details"'


class TestUnquoteIdentifierSqlServer:
    """Tests for unquote_identifier."""

    def test_unquote_brackets(self):
        assert unquote_identifier("[MyTable]") == "MyTable"

    def test_unquote_escaped_brackets(self):
        assert unquote_identifier("[Table[1]]]") == "Table[1]"

    def test_unquote_unquoted(self):
        assert unquote_identifier("MyTable") == "MyTable"

    def test_unquote_double_quoted(self):
        assert unquote_identifier('"MyTable"') == "MyTable"

    def test_unquote_escaped_double_quotes(self):
        assert unquote_identifier('"My""Table"') == 'My"Table'
