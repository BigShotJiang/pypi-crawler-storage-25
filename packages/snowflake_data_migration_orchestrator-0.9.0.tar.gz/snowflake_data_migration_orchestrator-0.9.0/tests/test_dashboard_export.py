"""Tests for ``data_migration_orchestrator.utils.dashboard_export``."""

from __future__ import annotations

from datetime import datetime, UTC

import pandas as pd

from data_migration_orchestrator.utils.dashboard_export import (
    SECTION_MARKER_PREFIX,
    build_snapshot_csv,
    per_tab_filename,
    prepare_export_dataframe,
    snapshot_filename,
    to_csv_bytes,
)


class TestPrepareExportDataframe:
    """Tests for the drop/rename/reorder export helper."""

    def test_none_input_returns_empty_frame(self):
        assert prepare_export_dataframe(None).empty

    def test_drops_specified_columns(self):
        df = pd.DataFrame({"A": [1], "B": [2], "C": [3]})
        out = prepare_export_dataframe(df, drop_cols=["B"])
        assert list(out.columns) == ["A", "C"]

    def test_unknown_drop_cols_are_ignored(self):
        df = pd.DataFrame({"A": [1]})
        out = prepare_export_dataframe(df, drop_cols=["A", "NON_EXISTENT"])
        assert list(out.columns) == []

    def test_rename_map_applied(self):
        df = pd.DataFrame({"A": [1], "B": [2]})
        out = prepare_export_dataframe(df, rename_map={"A": "alpha"})
        assert list(out.columns) == ["alpha", "B"]

    def test_rename_missing_column_ignored(self):
        df = pd.DataFrame({"A": [1]})
        out = prepare_export_dataframe(df, rename_map={"ZZZ": "wont_apply"})
        assert list(out.columns) == ["A"]

    def test_column_order_reorders(self):
        df = pd.DataFrame({"A": [1], "B": [2], "C": [3]})
        out = prepare_export_dataframe(df, column_order=["C", "A"])
        # Explicit columns first, remaining appended in original order.
        assert list(out.columns) == ["C", "A", "B"]

    def test_column_order_handles_missing(self):
        df = pd.DataFrame({"A": [1]})
        out = prepare_export_dataframe(df, column_order=["ZZZ", "A"])
        assert list(out.columns) == ["A"]

    def test_drop_rename_order_chain(self):
        df = pd.DataFrame({"INTERNAL": [0], "A": [1], "B": [2]})
        out = prepare_export_dataframe(
            df,
            drop_cols=["INTERNAL"],
            rename_map={"A": "alpha"},
            column_order=["B", "alpha"],
        )
        assert list(out.columns) == ["B", "alpha"]

    def test_input_frame_is_not_mutated(self):
        df = pd.DataFrame({"A": [1], "B": [2]})
        original_cols = list(df.columns)
        prepare_export_dataframe(df, drop_cols=["A"], rename_map={"B": "beta"})
        assert list(df.columns) == original_cols


class TestToCsvBytes:
    """Tests for the CSV bytes serializer."""

    def test_round_trip(self):
        df = pd.DataFrame({"A": [1, 2], "B": ["x", "y"]})
        csv_bytes = to_csv_bytes(df)
        assert isinstance(csv_bytes, bytes)
        text = csv_bytes.decode("utf-8")
        lines = text.strip().split("\n")
        assert lines[0] == "A,B"
        assert lines[1] == "1,x"
        assert lines[2] == "2,y"

    def test_none_input_yields_empty_csv(self):
        result = to_csv_bytes(None)
        assert result.decode("utf-8") == "\n"

    def test_empty_frame_writes_header_only(self):
        df = pd.DataFrame(columns=["A", "B"])
        text = to_csv_bytes(df).decode("utf-8")
        assert text.strip() == "A,B"

    def test_unicode_round_trip(self):
        df = pd.DataFrame({"name": ["café", "日本語"]})
        text = to_csv_bytes(df).decode("utf-8")
        assert "café" in text
        assert "日本語" in text

    def test_lf_line_terminator(self):
        df = pd.DataFrame({"A": [1, 2]})
        text = to_csv_bytes(df).decode("utf-8")
        assert "\r\n" not in text


class TestBuildSnapshotCsv:
    """Tests for the multi-section snapshot builder."""

    def test_generates_section_markers(self):
        sections = {
            "tables": pd.DataFrame({"TABLE_NAME": ["T1"], "STATUS": ["OK"]}),
            "errors": pd.DataFrame({"TABLE_NAME": ["T1"], "MSG": ["oops"]}),
        }
        text = build_snapshot_csv(sections).decode("utf-8")
        assert f"{SECTION_MARKER_PREFIX} tables" in text
        assert f"{SECTION_MARKER_PREFIX} errors" in text
        assert "TABLE_NAME,STATUS" in text
        assert "T1,OK" in text
        assert "TABLE_NAME,MSG" in text
        assert "T1,oops" in text

    def test_empty_section_emits_placeholder(self):
        sections = {"empty_section": pd.DataFrame()}
        text = build_snapshot_csv(sections).decode("utf-8")
        assert f"{SECTION_MARKER_PREFIX} empty_section" in text
        assert "(empty)" in text

    def test_generated_at_marker_present(self):
        fixed = datetime(2026, 4, 27, 20, 42, 30, tzinfo=UTC)
        text = build_snapshot_csv({}, generated_at=fixed).decode("utf-8")
        assert text.startswith("# GENERATED_AT: 2026-04-27T20:42:30Z\n")

    def test_deterministic_section_order(self):
        sections = {"z": pd.DataFrame({"X": [1]}), "a": pd.DataFrame({"Y": [2]})}
        text = build_snapshot_csv(sections).decode("utf-8")
        # Section order must follow the mapping insertion order (preserved).
        z_pos = text.index(f"{SECTION_MARKER_PREFIX} z")
        a_pos = text.index(f"{SECTION_MARKER_PREFIX} a")
        assert z_pos < a_pos


class TestFilenames:
    """Tests for snapshot and per-tab filename builders."""

    def test_snapshot_filename_with_workflow(self):
        ts = datetime(2026, 4, 27, 20, 42, 30, tzinfo=UTC)
        name = snapshot_filename("dm", workflow_id=42, now=ts)
        assert name == "dm_wf42_20260427T204230Z.csv"

    def test_snapshot_filename_all_scope(self):
        ts = datetime(2026, 1, 2, 3, 4, 5, tzinfo=UTC)
        name = snapshot_filename("dv", workflow_id=None, now=ts)
        assert name == "dv_all_20260102T030405Z.csv"

    def test_per_tab_filename_lowercases_and_replaces_spaces(self):
        ts = datetime(2026, 4, 27, 20, 42, 30, tzinfo=UTC)
        name = per_tab_filename("dm", "Table Progress", workflow_id=1, now=ts)
        assert name == "dm_table_progress_wf1_20260427T204230Z.csv"
