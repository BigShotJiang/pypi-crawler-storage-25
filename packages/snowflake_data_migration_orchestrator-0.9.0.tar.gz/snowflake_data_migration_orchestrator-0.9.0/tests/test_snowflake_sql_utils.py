"""Tests for generic SQL utility functions."""

from data_migration_orchestrator.utils.snowflake_sql_utils import (
    escape_sql_string,
    quote_string_literal,
)


class TestEscapeSqlString:
    """Tests for escape_sql_string function."""

    def test_no_special_characters(self):
        assert escape_sql_string("hello") == "hello"

    def test_escapes_single_quotes(self):
        assert escape_sql_string("it's") == "it''s"

    def test_escapes_backslashes(self):
        assert escape_sql_string("a\\b") == "a\\\\b"

    def test_escapes_backslash_before_quote(self):
        result = escape_sql_string('\\"Id\\"')
        assert result == '\\\\"Id\\\\"'

    def test_json_with_escaped_quotes(self):
        raw_json = '{"columnNameMappings": {"ID": "\\"Id\\""}}'
        result = escape_sql_string(raw_json)
        assert '\\\\"Id\\\\"' in result


class TestQuoteStringLiteral:
    """Tests for quote_string_literal function."""

    def test_quote_simple_string(self):
        result = quote_string_literal("my_value")
        assert result == "'my_value'"

    def test_quote_path_string(self):
        result = quote_string_literal("@stage/path/to/file.parquet")
        assert result == "'@stage/path/to/file.parquet'"

    def test_quote_with_spaces(self):
        result = quote_string_literal("Order Details")
        assert result == "'Order Details'"

    def test_quote_empty_string(self):
        result = quote_string_literal("")
        assert result == "''"

    def test_quote_with_unicode_prefix(self):
        result = quote_string_literal("my_value", unicode_prefix=True)
        assert result == "N'my_value'"

    def test_quote_with_unicode_prefix_false(self):
        result = quote_string_literal("my_value", unicode_prefix=False)
        assert result == "'my_value'"

    def test_quote_special_characters(self):
        result = quote_string_literal("value-with_special$chars")
        assert result == "'value-with_special$chars'"

    def test_quote_with_single_quote(self):
        result = quote_string_literal("O'Brien")
        assert result == "'O''Brien'"

    def test_quote_multiple_single_quotes(self):
        result = quote_string_literal("It's O'Brien's")
        assert result == "'It''s O''Brien''s'"
