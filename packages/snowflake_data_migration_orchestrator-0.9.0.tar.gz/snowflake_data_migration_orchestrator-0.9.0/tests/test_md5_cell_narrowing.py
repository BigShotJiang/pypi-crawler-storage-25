"""Unit tests for hybrid cell narrowing helpers (MD5 failed-key predicates)."""

import sys
import unittest
from types import ModuleType
from unittest.mock import MagicMock

# Stub SDV imports required by sdv_query_helper.
_sdv_public = ModuleType("snowflake.snowflake_data_validation.public")
for _attr in (
    "ColumnMetadata",
    "ObjectType",
    "Origin",
    "Platform",
    "SQLQueriesTemplateGenerator",
    "TableContext",
    "TemplatesLoaderManager",
    "generate_batched_metrics_queries",
    "generate_cell_validation_data_query",
    "generate_metrics_query",
    "generate_schema_query",
    "QueryExecutionResult",
    "validate_cell",
):
    setattr(_sdv_public, _attr, MagicMock())
sys.modules.setdefault("snowflake.snowflake_data_validation.public", _sdv_public)

_sdv_constants = ModuleType("snowflake.snowflake_data_validation.utils.constants")
_sdv_constants.DEFAULT_MAX_COLUMNS_PER_METRICS_BATCH = 50  # type: ignore[attr-defined]
sys.modules.setdefault(
    "snowflake.snowflake_data_validation.utils.constants", _sdv_constants
)

_sdv_helpers = ModuleType(
    "snowflake.snowflake_data_validation.utils.helpers.helper_templates"
)
_sdv_helpers.HelperTemplates = MagicMock()  # type: ignore[attr-defined]
sys.modules.setdefault(
    "snowflake.snowflake_data_validation.utils.helpers.helper_templates",
    _sdv_helpers,
)

from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (  # noqa: E402
    build_or_predicate_for_index_value_strings,
    merge_sql_where_clauses,
    parse_md5_diff_index_values,
)


class TestMd5CellNarrowing(unittest.TestCase):
    """Verify hybrid cell narrowing helpers (MD5 failed-key predicates)."""

    def test_parse_md5_diff_index_values(self):
        p = parse_md5_diff_index_values("ID=1, NAME=foo")
        self.assertEqual(p.get("ID"), "1")
        self.assertEqual(p.get("NAME"), "foo")

    def test_build_or_predicate(self):
        pred = build_or_predicate_for_index_value_strings(
            ["ID"],
            ["ID=42", "ID=99"],
        )
        self.assertIsNotNone(pred)
        assert pred is not None
        self.assertIn("42", pred)
        self.assertIn("99", pred)
        self.assertIn(" OR ", pred)

    def test_merge_where(self):
        self.assertEqual(
            merge_sql_where_clauses("a = 1", "b = 2"),
            "(a = 1) AND (b = 2)",
        )
        self.assertEqual(merge_sql_where_clauses("", "x"), "x")
        self.assertEqual(merge_sql_where_clauses("y", None), "y")


if __name__ == "__main__":
    unittest.main()
