"""
Tests for StagedDataHandler._validate_column_name_mappings.

Validates that column name mapping validation uses case-sensitive comparison
against raw column names from the actual schema.  Mapping values may carry
double quotes for case-sensitive identifiers (e.g. ``'"Id"'``); the
validator strips them via ``unquote_identifier`` before comparing against
the schema's bare column names.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.data_migration_cloud.services.schema_validator import (
    ColumnSchema,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler import (
    StagedDataHandler,
)


def _schema(*names: str) -> list[ColumnSchema]:
    return [ColumnSchema(column_name=n, data_type="VARCHAR") for n in names]


class TestValidateColumnNameMappings(unittest.TestCase):
    """Test cases for _validate_column_name_mappings."""

    def setUp(self):
        self.handler = StagedDataHandler(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(execute_sync_query=AsyncMock(return_value=[])),
        )
        self.table_name = "DB.SCHEMA.TABLE"

    def test_empty_mappings_passes(self):
        self.handler._validate_column_name_mappings({}, _schema("ID"), self.table_name)

    def test_empty_schema_passes(self):
        self.handler._validate_column_name_mappings(
            {"id": "old_id"}, [], self.table_name
        )

    def test_exact_match_passes(self):
        self.handler._validate_column_name_mappings(
            {"id": "ID"}, _schema("ID", "NAME"), self.table_name
        )

    def test_case_sensitive_mismatch_raises(self):
        """'Id' does not match column 'ID' — SQL generation quotes all identifiers, making them case-sensitive in Snowflake."""
        with self.assertRaises(ValueError):
            self.handler._validate_column_name_mappings(
                {"id": "Id"}, _schema("ID"), self.table_name
            )

    def test_missing_column_raises(self):
        with self.assertRaises(ValueError):
            self.handler._validate_column_name_mappings(
                {"id": "MISSING"}, _schema("ID", "NAME"), self.table_name
            )

    def test_mixed_case_column_exact_match(self):
        """A mixed-case column created with quotes in Snowflake is returned as-is in the schema metadata."""
        self.handler._validate_column_name_mappings(
            {"id": "Id"}, _schema("Id"), self.table_name
        )

    def test_multiple_mappings_all_valid(self):
        self.handler._validate_column_name_mappings(
            {"col_a": "MixedCase", "col_b": "PLAIN"},
            _schema("MixedCase", "PLAIN"),
            self.table_name,
        )

    def test_quoted_mapping_value_matches_bare_schema_column(self):
        """A quoted mapping value like '"Id"' matches bare schema column 'Id'."""
        self.handler._validate_column_name_mappings(
            {"id": '"Id"'}, _schema("Id"), self.table_name
        )

    def test_quoted_mapping_value_mismatch_raises(self):
        """A quoted mapping value '"Id"' does NOT match schema column 'ID'."""
        with self.assertRaises(ValueError):
            self.handler._validate_column_name_mappings(
                {"id": '"Id"'}, _schema("ID"), self.table_name
            )

    def test_error_message_lists_only_missing(self):
        with self.assertRaises(ValueError) as ctx:
            self.handler._validate_column_name_mappings(
                {"col_a": "wrong_case", "col_b": "PLAIN"},
                _schema("Wrong_Case", "PLAIN"),
                self.table_name,
            )
        self.assertIn("'col_a' -> 'wrong_case'", str(ctx.exception))
        self.assertNotIn("col_b", str(ctx.exception))
