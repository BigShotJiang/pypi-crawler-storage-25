"""Unit tests for create_target_table_if_missing helper."""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    SNOWFLAKE_CATALOG,
    IcebergTargetConfig,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.target_table_creator import (
    create_target_table_if_missing,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)


def _make_warehouse() -> MagicMock:
    wh = MagicMock()
    wh.execute_sync_query = AsyncMock(return_value=[])
    return wh


def _make_loader() -> MagicMock:
    loader = MagicMock()
    loader.get_snowflake_type = MagicMock(
        side_effect=lambda t: {
            "INT": "NUMBER(38,0)",
            "VARCHAR": "VARCHAR(16777216)",
        }[t.upper()]
    )
    return loader


class TestCreateTargetTableIfMissing(unittest.IsolatedAsyncioTestCase):
    """Tests for the shared create_target_table_if_missing helper."""

    async def test_creates_table_when_missing(self):
        wh = _make_warehouse()
        loader = _make_loader()
        source_schema = [
            {COLUMN_NAME: "id", DATA_TYPE: "INT"},
            {COLUMN_NAME: "name", DATA_TYPE: "VARCHAR"},
        ]

        await create_target_table_if_missing(
            warehouse_proxy=wh,
            full_table_name="DB.SCHEMA.T",
            source_schema=source_schema,
            type_mapping_loader=loader,
            column_name_mappings=None,
            iceberg_config=None,
            is_iceberg_source_stage=False,
            target_table_id=None,
            table_already_exists=False,
        )

        self.assertEqual(wh.execute_sync_query.await_count, 1)
        sql = wh.execute_sync_query.await_args.args[0]
        self.assertTrue(sql.startswith("CREATE TABLE DB.SCHEMA.T ("))
        self.assertIn("id", sql.lower())
        self.assertIn("name", sql.lower())

    async def test_noop_when_table_exists(self):
        wh = _make_warehouse()
        loader = _make_loader()
        source_schema = [{COLUMN_NAME: "id", DATA_TYPE: "INT"}]

        result = await create_target_table_if_missing(
            warehouse_proxy=wh,
            full_table_name="DB.SCHEMA.T",
            source_schema=source_schema,
            type_mapping_loader=loader,
            column_name_mappings=None,
            iceberg_config=None,
            is_iceberg_source_stage=False,
            target_table_id=None,
            table_already_exists=True,
        )

        self.assertEqual(wh.execute_sync_query.await_count, 0)
        self.assertEqual(result, {})

    async def test_iceberg_short_circuit_uses_create_iceberg_table(self):
        wh = _make_warehouse()
        loader = _make_loader()
        source_schema = [{COLUMN_NAME: "id", DATA_TYPE: "INT"}]
        iceberg_config = IcebergTargetConfig(
            catalog=SNOWFLAKE_CATALOG,
            external_volume="MY_VOL",
            base_location_prefix=None,
            catalog_table_name=None,
            catalog_sync=None,
        )

        await create_target_table_if_missing(
            warehouse_proxy=wh,
            full_table_name="DB.SCHEMA.T",
            source_schema=source_schema,
            type_mapping_loader=loader,
            column_name_mappings=None,
            iceberg_config=iceberg_config,
            is_iceberg_source_stage=True,
            target_table_id=None,
            table_already_exists=False,
        )

        self.assertEqual(wh.execute_sync_query.await_count, 1)
        sql = wh.execute_sync_query.await_args.args[0]
        self.assertTrue(sql.startswith("CREATE ICEBERG TABLE DB.SCHEMA.T"))
        self.assertIn("EXTERNAL_VOLUME = 'MY_VOL'", sql)


if __name__ == "__main__":
    unittest.main()
