"""Unit tests for load segmentation utilities."""

from data_migration_orchestrator.data_migration_cloud.utils.load_segmentation import (
    SNOWFLAKE_FILES_PARAM_LIMIT,
    LoadSegment,
    compute_segments,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    StageFile,
)


class TestComputeSegments:
    """Tests for compute_segments()."""

    def test_empty_file_list(self):
        result = compute_segments([], target_segment_size_bytes=1_000_000)
        assert result == []

    def test_single_file_below_target(self):
        files = [StageFile(name="a.parquet", size_bytes=500)]
        result = compute_segments(files, target_segment_size_bytes=1_000)
        assert len(result) == 1
        assert result[0].files == ["a.parquet"]
        assert result[0].total_size_bytes == 500

    def test_single_file_exceeds_target(self):
        files = [StageFile(name="big.parquet", size_bytes=5_000)]
        result = compute_segments(files, target_segment_size_bytes=1_000)
        assert len(result) == 1
        assert result[0].files == ["big.parquet"]
        assert result[0].total_size_bytes == 5_000

    def test_two_files_fit_in_one_segment(self):
        files = [
            StageFile(name="a.parquet", size_bytes=400),
            StageFile(name="b.parquet", size_bytes=400),
        ]
        result = compute_segments(files, target_segment_size_bytes=1_000)
        assert len(result) == 1
        assert result[0].files == ["a.parquet", "b.parquet"]
        assert result[0].total_size_bytes == 800

    def test_files_split_into_two_segments(self):
        files = [
            StageFile(name="a.parquet", size_bytes=600),
            StageFile(name="b.parquet", size_bytes=600),
        ]
        result = compute_segments(files, target_segment_size_bytes=1_000)
        assert len(result) == 2
        assert result[0].files == ["a.parquet"]
        assert result[0].total_size_bytes == 600
        assert result[1].files == ["b.parquet"]
        assert result[1].total_size_bytes == 600

    def test_exact_boundary(self):
        files = [
            StageFile(name="a.parquet", size_bytes=500),
            StageFile(name="b.parquet", size_bytes=500),
            StageFile(name="c.parquet", size_bytes=500),
        ]
        result = compute_segments(files, target_segment_size_bytes=1_000)
        assert len(result) == 2
        assert result[0].files == ["a.parquet", "b.parquet"]
        assert result[0].total_size_bytes == 1_000
        assert result[1].files == ["c.parquet"]
        assert result[1].total_size_bytes == 500

    def test_many_small_files(self):
        files = [
            StageFile(name=f"part_{i:04d}.parquet", size_bytes=100) for i in range(10)
        ]
        result = compute_segments(files, target_segment_size_bytes=350)
        assert len(result) == 4
        assert result[0].total_size_bytes == 300
        assert result[1].total_size_bytes == 300
        assert result[2].total_size_bytes == 300
        assert result[3].total_size_bytes == 100

    def test_mixed_sizes(self):
        files = [
            StageFile(name="tiny.parquet", size_bytes=10),
            StageFile(name="small.parquet", size_bytes=200),
            StageFile(name="big.parquet", size_bytes=5_000),
            StageFile(name="medium.parquet", size_bytes=400),
        ]
        result = compute_segments(files, target_segment_size_bytes=1_000)
        assert len(result) == 3
        assert result[0].files == ["tiny.parquet", "small.parquet"]
        assert result[1].files == ["big.parquet"]
        assert result[2].files == ["medium.parquet"]

    def test_snowflake_files_limit_enforced(self):
        count = SNOWFLAKE_FILES_PARAM_LIMIT + 50
        files = [StageFile(name=f"f{i}.parquet", size_bytes=1) for i in range(count)]
        # Target size is huge so only the file-count limit triggers splits
        result = compute_segments(files, target_segment_size_bytes=10**12)
        assert len(result) == 2
        assert len(result[0].files) == SNOWFLAKE_FILES_PARAM_LIMIT
        assert len(result[1].files) == 50

    def test_returns_load_segment_instances(self):
        files = [StageFile(name="a.parquet", size_bytes=100)]
        result = compute_segments(files, target_segment_size_bytes=1_000)
        assert isinstance(result[0], LoadSegment)
