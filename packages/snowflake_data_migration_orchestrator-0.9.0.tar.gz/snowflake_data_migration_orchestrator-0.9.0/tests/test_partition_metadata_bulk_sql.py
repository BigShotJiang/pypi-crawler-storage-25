"""Unit tests for partition_metadata_bulk_sql."""

import pytest

from data_migration_orchestrator.utils.partition_metadata_bulk_sql import (
    build_bulk_insert_partition_metadata_sql,
    format_sql_literal_for_values,
)


class TestFormatSqlLiteralForValues:
    """Tests for format_sql_literal_for_values."""

    def test_none(self):
        assert format_sql_literal_for_values(None) == "NULL"

    def test_bool(self):
        assert format_sql_literal_for_values(True) == "TRUE"
        assert format_sql_literal_for_values(False) == "FALSE"

    def test_int_float(self):
        assert format_sql_literal_for_values(42) == "42"
        assert format_sql_literal_for_values(3.14) == "3.14"

    def test_numeric_strings_unquoted(self):
        assert format_sql_literal_for_values("123") == "123"
        assert format_sql_literal_for_values("45.67") == "45.67"

    def test_string_quoted(self):
        assert format_sql_literal_for_values("hello") == "'hello'"

    def test_escapes_quotes(self):
        assert format_sql_literal_for_values("it's") == "'it''s'"


class TestBuildBulkInsertPartitionMetadataSql:
    """Tests for build_bulk_insert_partition_metadata_sql."""

    def test_empty_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            build_bulk_insert_partition_metadata_sql(
                "DB.SCH",
                1,
                [],
                status_column="MIGRATION_STATUS",
                status_sql_literal="'EXTRACTING'",
            )

    def test_migration_shape(self):
        sql = build_bulk_insert_partition_metadata_sql(
            "MIG.SCHEMA",
            10,
            [(0, None, None, None), (1, 1, 100, None)],
            status_column="MIGRATION_STATUS",
            status_sql_literal="'EXTRACTING'",
        )
        assert "INSERT INTO MIG.SCHEMA.PARTITION_METADATA" in sql
        assert "MIGRATION_STATUS" in sql
        assert "MIG.SCHEMA.PARTITION_METADATA_ID_SEQ.NEXTVAL" in sql
        assert "FROM VALUES" in sql
        assert "(10, 0, NULL, NULL, NULL, 'EXTRACTING')" in sql
        assert "(10, 1, 1, 100, NULL, 'EXTRACTING')" in sql
        assert "TO_VARIANT(column3)" in sql
        assert "TO_VARIANT(column4)" in sql

    def test_validation_shape(self):
        sql = build_bulk_insert_partition_metadata_sql(
            "DV.SCHEMA",
            7,
            [(1, None, None, None)],
            status_column="VALIDATION_STATUS",
            status_sql_literal="'PENDING'",
        )
        assert "INSERT INTO DV.SCHEMA.PARTITION_METADATA" in sql
        assert "VALIDATION_STATUS" in sql
        assert "(7, 1, NULL, NULL, NULL, 'PENDING')" in sql

    def test_n_rows_preserved(self):
        sql = build_bulk_insert_partition_metadata_sql(
            "S.SC",
            1,
            [(1, 10, 20, 500_000)],
            status_column="VALIDATION_STATUS",
            status_sql_literal="'PENDING'",
        )
        assert ", 500000, 'PENDING')" in sql
