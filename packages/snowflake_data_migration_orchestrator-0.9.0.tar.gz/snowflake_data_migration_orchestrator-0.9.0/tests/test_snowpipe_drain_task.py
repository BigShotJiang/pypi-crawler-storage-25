"""Unit tests for Snowpipe ``drain`` mode bookkeeping."""

from __future__ import annotations

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.cloud_core.tasks.queues.table_task_queue import (
    TableTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus


def _make_queue() -> TableTaskQueue:
    queue = TableTaskQueue(MagicMock(), lambda kind, payload_dict: payload_dict)
    queue._complete_snowpipe_task = AsyncMock(return_value=None)
    queue._fail_snowpipe_task = AsyncMock(return_value=None)
    return queue


class TestRefreshSnowpipeDrainTasks(unittest.IsolatedAsyncioTestCase):
    """Validate drain-mode bookkeeping against ``SYSTEM$PIPE_STATUS``."""

    async def test_drain_completes_when_pipe_is_idle_and_empty(self):
        queue = _make_queue()
        queue._fetch_snowpipe_status = AsyncMock(
            return_value={
                "executionState": "RUNNING",
                "pendingFileCount": 0,
            }
        )

        completed = await queue._refresh_snowpipe_drain_tasks(
            {101: ("DB.T.PIPE_A", "", "PIPE_A")}
        )

        self.assertEqual(completed, [101])
        queue._complete_snowpipe_task.assert_awaited_once_with(101)
        queue._fail_snowpipe_task.assert_not_awaited()

    async def test_drain_waits_when_pending_files_remain(self):
        queue = _make_queue()
        queue._fetch_snowpipe_status = AsyncMock(
            return_value={
                "executionState": "RUNNING",
                "pendingFileCount": 3,
            }
        )

        completed = await queue._refresh_snowpipe_drain_tasks(
            {101: ("DB.T.PIPE_A", "", "PIPE_A")}
        )

        self.assertEqual(completed, [])
        queue._complete_snowpipe_task.assert_not_awaited()
        queue._fail_snowpipe_task.assert_not_awaited()

    async def test_drain_fails_on_unhealthy_pipe_state(self):
        queue = _make_queue()
        queue._fetch_snowpipe_status = AsyncMock(
            return_value={
                "executionState": "STOPPED_MISSING_PIPE",
                "pendingFileCount": 0,
                "lastIngestedErrorMessage": "pipe was dropped",
            }
        )

        completed = await queue._refresh_snowpipe_drain_tasks(
            {202: ("DB.T.PIPE_BAD", "", "PIPE_BAD")}
        )

        self.assertEqual(completed, [202])
        queue._fail_snowpipe_task.assert_awaited_once()
        fail_args = queue._fail_snowpipe_task.await_args
        self.assertEqual(fail_args.args[0], 202)
        self.assertIn("STOPPED_MISSING_PIPE", fail_args.args[1])
        queue._complete_snowpipe_task.assert_not_awaited()

    async def test_drain_retries_on_missing_status(self):
        queue = _make_queue()
        queue._fetch_snowpipe_status = AsyncMock(return_value=None)

        completed = await queue._refresh_snowpipe_drain_tasks(
            {303: ("DB.T.PIPE_X", "", "PIPE_X")}
        )

        self.assertEqual(completed, [])
        queue._complete_snowpipe_task.assert_not_awaited()
        queue._fail_snowpipe_task.assert_not_awaited()

    async def test_shared_pipe_completes_both_tasks(self):
        """When two drain tasks reference the same pipe, one status call suffices."""
        queue = _make_queue()
        queue._fetch_snowpipe_status = AsyncMock(
            return_value={"executionState": "RUNNING", "pendingFileCount": 0}
        )

        completed = await queue._refresh_snowpipe_drain_tasks(
            {
                101: ("DB.T.PIPE_A", "", "PIPE_A"),
                102: ("DB.T.PIPE_A", "", "PIPE_A"),
            }
        )

        self.assertCountEqual(completed, [101, 102])
        self.assertEqual(queue._fetch_snowpipe_status.await_count, 1)
        self.assertEqual(queue._complete_snowpipe_task.await_count, 2)


class TestRefreshSnowpipeTasksSkipsBlocked(unittest.IsolatedAsyncioTestCase):
    """Validate that the outer refresh loop skips BLOCKED snowpipe tasks."""

    def _prepared_queue(self, statuses: dict[int, str]) -> TableTaskQueue:
        queue = _make_queue()
        queue._snowpipe_tasks_loaded = True
        queue._fetch_current_statuses_for = AsyncMock(return_value=statuses)
        queue._refresh_snowpipe_drain_tasks = AsyncMock(return_value=[])
        queue._refresh_snowpipe_prefix_tasks = AsyncMock(return_value=[])
        return queue

    async def test_blocked_drain_is_skipped_but_retained(self):
        queue = self._prepared_queue(statuses={101: TaskStatus.BLOCKED.value})
        queue._pending_snowpipe_tasks = {101: ("DB.T.PIPE_A", "", "PIPE_A", "drain")}

        await queue.refresh_snowpipe_tasks()

        queue._refresh_snowpipe_drain_tasks.assert_not_awaited()
        queue._refresh_snowpipe_prefix_tasks.assert_not_awaited()
        self.assertIn(101, queue._pending_snowpipe_tasks)

    async def test_unblocked_drain_is_polled(self):
        queue = self._prepared_queue(
            statuses={
                101: TaskStatus.BLOCKED.value,
                102: TaskStatus.PENDING.value,
            }
        )
        queue._pending_snowpipe_tasks = {
            101: ("DB.T.PIPE_A", "", "PIPE_A", "drain"),
            102: ("DB.T.PIPE_B", "", "PIPE_B", "drain"),
        }

        await queue.refresh_snowpipe_tasks()

        queue._refresh_snowpipe_drain_tasks.assert_awaited_once()
        polled = queue._refresh_snowpipe_drain_tasks.await_args.args[0]
        self.assertEqual(set(polled.keys()), {102})
        # Blocked task stays tracked for future cycles.
        self.assertIn(101, queue._pending_snowpipe_tasks)

    async def test_vanished_task_is_evicted(self):
        queue = self._prepared_queue(statuses={})
        queue._pending_snowpipe_tasks = {
            999: ("DB.T.PIPE_GONE", "", "PIPE_GONE", "drain")
        }

        await queue.refresh_snowpipe_tasks()

        queue._refresh_snowpipe_drain_tasks.assert_not_awaited()
        self.assertNotIn(999, queue._pending_snowpipe_tasks)

    async def test_status_fetch_failure_skips_cycle(self):
        queue = _make_queue()
        queue._snowpipe_tasks_loaded = True
        queue._fetch_current_statuses_for = AsyncMock(
            side_effect=RuntimeError("transient connection error")
        )
        queue._refresh_snowpipe_drain_tasks = AsyncMock(return_value=[])
        queue._refresh_snowpipe_prefix_tasks = AsyncMock(return_value=[])
        queue._pending_snowpipe_tasks = {101: ("DB.T.PIPE_A", "", "PIPE_A", "drain")}

        await queue.refresh_snowpipe_tasks()

        queue._refresh_snowpipe_drain_tasks.assert_not_awaited()
        queue._refresh_snowpipe_prefix_tasks.assert_not_awaited()
        # Task must stay tracked so a later cycle can retry.
        self.assertIn(101, queue._pending_snowpipe_tasks)

    async def test_blocked_prefix_task_is_skipped(self):
        queue = self._prepared_queue(
            statuses={
                201: TaskStatus.BLOCKED.value,
                202: TaskStatus.PENDING.value,
            }
        )
        queue._pending_snowpipe_tasks = {
            201: ("DB.T.PIPE_A", "prefix-a/", "PIPE_A", "prefix"),
            202: ("DB.T.PIPE_B", "prefix-b/", "PIPE_B", "prefix"),
        }

        await queue.refresh_snowpipe_tasks()

        queue._refresh_snowpipe_prefix_tasks.assert_awaited_once()
        polled = queue._refresh_snowpipe_prefix_tasks.await_args.args[0]
        self.assertEqual(set(polled.keys()), {202})
        self.assertIn(201, queue._pending_snowpipe_tasks)


if __name__ == "__main__":
    unittest.main()
