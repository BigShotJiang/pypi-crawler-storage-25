"""
Tests for task payload classes.

This module tests the task payload dataclasses, including the new fields
for table and partition metadata tracking.
"""

from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CompletePartitionMigrationTaskPayload,
    CreatePartitionTasksPayload,
    DataMovementTaskPayload,
    DeterminePartitionStrategyTaskPayload,
    ProcessStagedDataTaskPayload,
    TargetType,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from shared.enums.source_type import SourceType


class TestDeterminePartitionStrategyTaskPayload:
    """Test cases for DeterminePartitionStrategyTaskPayload."""

    def test_payload_creation_with_table_metadata_id(self):
        """Test payload creation with table_metadata_id field."""
        payload = DeterminePartitionStrategyTaskPayload(
            database="test_db",
            schema="dbo",
            table_name="users",
            source_type=SourceType.SQLSERVER.value,
            target_table="DEST_DB.DEST_SCHEMA.USERS",
            table_metadata_id=42,
        )

        assert payload.table_metadata_id == 42
        assert payload.kind == TaskPayloadKind.DETERMINE_PARTITION_STRATEGY

    def test_payload_creation_with_required_fields(self):
        """Test payload creation with required fields."""
        payload = DeterminePartitionStrategyTaskPayload(
            database="test_db",
            schema="dbo",
            table_name="orders",
            source_type=SourceType.SQLSERVER.value,
            target_table="DEST_DB.DEST_SCHEMA.ORDERS",
            table_metadata_id=1,
        )

        assert payload.table_metadata_id == 1
        assert payload.kind == TaskPayloadKind.DETERMINE_PARTITION_STRATEGY

    def test_payload_with_table_metadata_id_for_type_mappings(self):
        """Test payload with table_metadata_id (which stores column type mappings in DB)."""
        payload = DeterminePartitionStrategyTaskPayload(
            database="test_db",
            schema="dbo",
            table_name="products",
            source_type=SourceType.SQLSERVER.value,
            target_table="DEST_DB.DEST_SCHEMA.PRODUCTS",
            table_metadata_id=100,
        )

        # column_type_mappings are now stored in TABLE_METADATA table, referenced by table_metadata_id
        assert payload.table_metadata_id == 100

    def test_payload_with_extraction_strategy(self):
        """Test payload with optional extraction_strategy field."""
        payload = DeterminePartitionStrategyTaskPayload(
            database="test_db",
            schema="dbo",
            table_name="events",
            source_type=SourceType.SQLSERVER.value,
            target_table="DEST_DB.DEST_SCHEMA.EVENTS",
            table_metadata_id=50,
            extraction_strategy="unload",
        )

        assert payload.extraction_strategy == "unload"


class TestCreatePartitionTasksPayload:
    """Test cases for CreatePartitionTasksPayload."""

    def test_payload_creation_with_table_metadata_id(self):
        """Test payload creation with table_metadata_id field."""
        payload = CreatePartitionTasksPayload(
            database="test_db",
            schema="dbo",
            table_name="large_table",
            source_type=SourceType.SQLSERVER.value,
            num_partitions=10,
            target_table="DEST_DB.DEST_SCHEMA.LARGE_TABLE",
            table_metadata_id=55,
        )

        assert payload.table_metadata_id == 55
        assert payload.kind == TaskPayloadKind.CREATE_PARTITION_TASKS

    def test_payload_creation_with_required_fields(self):
        """Test payload creation with required fields."""
        payload = CreatePartitionTasksPayload(
            database="test_db",
            schema="dbo",
            table_name="events",
            source_type=SourceType.SQLSERVER.value,
            num_partitions=5,
            target_table="DEST_DB.DEST_SCHEMA.EVENTS",
            table_metadata_id=1,
        )

        assert payload.table_metadata_id == 1

    def test_payload_with_avg_row_size_and_table_metadata_id(self):
        """Test payload with avg_row_size_bytes and table_metadata_id."""
        payload = CreatePartitionTasksPayload(
            database="test_db",
            schema="dbo",
            table_name="logs",
            source_type=SourceType.SQLSERVER.value,
            num_partitions=20,
            target_table="DEST_DB.DEST_SCHEMA.LOGS",
            avg_row_size_bytes=512.5,
            table_metadata_id=77,
        )

        assert payload.avg_row_size_bytes == 512.5
        assert payload.table_metadata_id == 77


class TestProcessStagedDataTaskPayload:
    """Test cases for ProcessStagedDataTaskPayload."""

    def test_payload_creation_with_partition_metadata_id(self):
        """Test payload creation with partition_metadata_id field."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=123,
            partition_index=1,
            target_table="DEST_DB.DEST_SCHEMA.MY_TABLE",
        )

        assert payload.partition_metadata_id == 123
        assert payload.kind == TaskPayloadKind.PROCESS_STAGED_DATA

    def test_payload_creation_with_all_fields(self):
        """Test payload creation with all required fields."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=50,
            partition_metadata_id=200,
            partition_index=0,
            target_table="DEST_DB.DEST_SCHEMA.SMALL_TABLE",
        )

        assert payload.table_metadata_id == 50
        assert payload.partition_metadata_id == 200
        assert payload.partition_index == 0
        assert payload.kind == TaskPayloadKind.PROCESS_STAGED_DATA

    def test_payload_with_table_metadata_id_and_partition_metadata_id(self):
        """Test payload with table_metadata_id (for type mappings) and partition_metadata_id."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=456,
            partition_index=5,
            target_table="DEST_DB.DEST_SCHEMA.EVENTS",
        )

        # column_type_mappings are now stored in TABLE_METADATA table, referenced by table_metadata_id
        assert payload.table_metadata_id == 100
        assert payload.partition_metadata_id == 456


class TestCompletePartitionMigrationTaskPayload:
    """Test cases for CompletePartitionMigrationTaskPayload."""

    def test_payload_creation(self):
        """Test basic payload creation."""
        payload = CompletePartitionMigrationTaskPayload(
            partition_metadata_id=789,
        )

        assert payload.partition_metadata_id == 789
        assert payload.kind == TaskPayloadKind.COMPLETE_PARTITION_MIGRATION

    def test_payload_kind_is_correct(self):
        """Test that payload kind is COMPLETE_PARTITION_MIGRATION."""
        payload = CompletePartitionMigrationTaskPayload(partition_metadata_id=1)
        assert payload.kind == TaskPayloadKind.COMPLETE_PARTITION_MIGRATION
        assert payload.kind == "complete_partition_migration"

    def test_payload_with_different_ids(self):
        """Test payload creation with various partition_metadata_id values."""
        for partition_id in [1, 100, 999999, 0]:
            payload = CompletePartitionMigrationTaskPayload(
                partition_metadata_id=partition_id
            )
            assert payload.partition_metadata_id == partition_id


class TestDataMovementTaskPayload:
    """Test cases for DataMovementTaskPayload (existing payload)."""

    def test_payload_creation_basic(self):
        """Test basic payload creation."""
        payload = DataMovementTaskPayload(
            database="test_db",
            schema="dbo",
            source_type=SourceType.SQLSERVER.value,
            source_id="source-1",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="@MY_STAGE/data/",
            statement_location_id="SELECT * FROM users",
        )

        assert payload.kind == TaskPayloadKind.DATA_MOVEMENT
        assert payload.suggested_batch_size is None

    def test_payload_with_suggested_batch_size(self):
        """Test payload with suggested_batch_size."""
        payload = DataMovementTaskPayload(
            database="test_db",
            schema="dbo",
            source_type=SourceType.SQLSERVER.value,
            source_id="source-1",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="@MY_STAGE/data/",
            statement_location_id="SELECT * FROM large_table",
            suggested_batch_size=25000,
        )

        assert payload.suggested_batch_size == 25000

    def test_payload_with_s3_unload_target(self):
        """Test payload with S3_UNLOAD target type for Redshift UNLOAD."""
        payload = DataMovementTaskPayload(
            database="test_db",
            schema="public",
            source_type=SourceType.REDSHIFT.value,
            source_id="test_db.public",
            target_type=TargetType.S3_UNLOAD,
            target_id="1/2/partition_0/",
            statement_location_id="SELECT * FROM users",
        )

        assert payload.target_type == TargetType.S3_UNLOAD
        assert payload.target_id == "1/2/partition_0/"


class TestSnowflakeQueryTaskPayload:
    """Test cases for SnowflakeQueryTaskPayload."""

    def test_payload_creation_basic(self):
        """Test basic payload creation."""
        payload = SnowflakeQueryTaskPayload(
            query="COPY INTO MY_TABLE FROM @MY_STAGE",
        )

        assert payload.query == "COPY INTO MY_TABLE FROM @MY_STAGE"
        assert payload.query_id is None
        assert payload.kind == TaskPayloadKind.SNOWFLAKE_QUERY

    def test_payload_with_query_id(self):
        """Test payload with query_id."""
        payload = SnowflakeQueryTaskPayload(
            query="COPY INTO MY_TABLE FROM @MY_STAGE",
            query_id="01b5c8d4-0000-1234-0000-00000001",
        )

        assert payload.query_id == "01b5c8d4-0000-1234-0000-00000001"


class TestTaskPayloadKind:
    """Test cases for TaskPayloadKind enum."""

    def test_complete_partition_migration_kind_exists(self):
        """Test that COMPLETE_PARTITION_MIGRATION kind exists."""
        assert hasattr(TaskPayloadKind, "COMPLETE_PARTITION_MIGRATION")
        assert (
            TaskPayloadKind.COMPLETE_PARTITION_MIGRATION
            == "complete_partition_migration"
        )

    def test_all_orchestrator_task_kinds(self):
        """Test that all orchestrator task kinds are defined."""
        orchestrator_kinds = [
            TaskPayloadKind.DETERMINE_PARTITION_STRATEGY,
            TaskPayloadKind.CREATE_PARTITION_TASKS,
            TaskPayloadKind.PROCESS_STAGED_DATA,
            TaskPayloadKind.COMPLETE_PARTITION_MIGRATION,
        ]
        for kind in orchestrator_kinds:
            assert isinstance(kind, TaskPayloadKind)
            assert isinstance(kind.value, str)

    def test_kind_values_are_unique(self):
        """Test that all kind values are unique."""
        all_values = [kind.value for kind in TaskPayloadKind]
        assert len(all_values) == len(set(all_values))
