"""
Tests for the merged SetupSnowpipeHandler.

The handler now runs an idempotent ``CREATE TABLE IF NOT EXISTS`` before
``CREATE PIPE`` so that the pipe never references a missing target. These
tests pin both halves of that contract:

* missing-target path -> create_target_table_if_missing called with
  ``table_already_exists=False``, then CREATE PIPE, then event logging.
* existing-target path -> create_target_table_if_missing called with
  ``table_already_exists=True`` (no-op), then CREATE PIPE.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.setup_snowpipe_handler import (
    SetupSnowpipeHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    SetupSnowpipePayload,
)


MODULE = "data_migration_orchestrator.data_migration_cloud.tasks.handlers.setup_snowpipe_handler"


def _make_task() -> Task:
    payload = SetupSnowpipePayload(
        pipe_name="SNOWCONVERT_AI.TEMP.DMO_PIPE_1_T",
        target_table="DB.SCH.T",
        stage_path="@STAGE/1/42/",
        table_metadata_id=42,
    )
    task = Task(
        id=999,
        workflow_id=1,
        executor_type=ExecutorType.ORCHESTRATOR,
        task_name="Setup Snowpipe: DB.SCH.T",
        payload=payload,
        scope="Table[DB.SCH.T]::SnowpipeSetup",
    )
    return task


def _make_handler(
    *, source_platform: str | None = "redshift"
) -> tuple[SetupSnowpipeHandler, MagicMock, MagicMock]:
    queue = MagicMock()
    queue.complete_task = AsyncMock()

    warehouse = MagicMock()
    warehouse.execute_sync_query = AsyncMock(return_value=[])

    handler = SetupSnowpipeHandler(task_queue=queue, warehouse_proxy=warehouse)
    handler.table_config_service.fetch_required_table_configuration = AsyncMock(
        return_value=TableConfiguration(
            source=TableIdentifier("SRC_DB", "SRC_SCH", "T"),
            target=TableIdentifier("DB", "SCH", "T"),
        )
    )
    handler.workflow_config_service.fetch_source_platform = AsyncMock(
        return_value=source_platform
    )
    return handler, queue, warehouse


class TestSetupSnowpipeHandler(unittest.IsolatedAsyncioTestCase):
    """Behavioral tests for the merged setup-snowpipe + create-table flow."""

    @patch(f"{MODULE}.create_target_table_if_missing", new_callable=AsyncMock)
    @patch(f"{MODULE}.SchemaValidator")
    @patch(f"{MODULE}.read_schema_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.TypeMappingLoader")
    async def test_creates_table_when_missing_then_creates_pipe(
        self,
        _mock_loader,
        mock_read_schema,
        mock_validator_cls,
        mock_create_table,
    ):
        mock_read_schema.return_value = [{"COLUMN_NAME": "C", "DATA_TYPE": "INTEGER"}]
        validator = MagicMock()
        validator.validate_schema = AsyncMock(
            return_value=MagicMock(table_exists=False)
        )
        mock_validator_cls.return_value = validator

        handler, queue, warehouse = _make_handler()
        await handler.handle(_make_task())

        mock_create_table.assert_awaited_once()
        kwargs = mock_create_table.await_args.kwargs
        self.assertFalse(kwargs["table_already_exists"])
        self.assertEqual(kwargs["full_table_name"], "DB.SCH.T")

        executed = [c.args[0] for c in warehouse.execute_sync_query.await_args_list]
        self.assertTrue(
            any(s.startswith("CREATE PIPE IF NOT EXISTS") for s in executed)
        )
        self.assertTrue(
            any("ALTER PIPE" in s and "LOG_EVENT_LEVEL" in s for s in executed)
        )

        queue.complete_task.assert_awaited_once()

    @patch(f"{MODULE}.create_target_table_if_missing", new_callable=AsyncMock)
    @patch(f"{MODULE}.SchemaValidator")
    @patch(f"{MODULE}.read_schema_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.TypeMappingLoader")
    async def test_skips_table_creation_when_already_exists_then_creates_pipe(
        self,
        _mock_loader,
        mock_read_schema,
        mock_validator_cls,
        mock_create_table,
    ):
        """Incremental-sync path: target exists, helper short-circuits, pipe still created."""
        mock_read_schema.return_value = [{"COLUMN_NAME": "C", "DATA_TYPE": "INTEGER"}]
        validator = MagicMock()
        validator.validate_schema = AsyncMock(return_value=MagicMock(table_exists=True))
        mock_validator_cls.return_value = validator

        handler, queue, warehouse = _make_handler()
        await handler.handle(_make_task())

        mock_create_table.assert_awaited_once()
        self.assertTrue(mock_create_table.await_args.kwargs["table_already_exists"])

        executed = [c.args[0] for c in warehouse.execute_sync_query.await_args_list]
        self.assertTrue(
            any(s.startswith("CREATE PIPE IF NOT EXISTS") for s in executed)
        )
        queue.complete_task.assert_awaited_once()

    async def test_rejects_wrong_payload_type(self):
        handler, _queue, _warehouse = _make_handler()
        bad_task = _make_task()
        bad_task.payload = object()
        with self.assertRaises(ValueError):
            await handler.handle(bad_task)

    async def test_rejects_missing_task_id(self):
        handler, _queue, _warehouse = _make_handler()
        task = _make_task()
        task.id = None
        with self.assertRaises(ValueError):
            await handler.handle(task)

    @patch(f"{MODULE}.create_target_table_if_missing", new_callable=AsyncMock)
    @patch(f"{MODULE}.SchemaValidator")
    @patch(f"{MODULE}.read_schema_from_stage", new_callable=AsyncMock)
    @patch(f"{MODULE}.TypeMappingLoader")
    async def test_raises_when_workflow_missing_source_platform(
        self,
        _mock_loader,
        mock_read_schema,
        mock_validator_cls,
        _mock_create_table,
    ):
        """
        Workflow without ``SOURCE_PLATFORM`` must surface a clear error.

        The fix relies on ``WorkflowConfigService.fetch_source_platform`` to
        replace the previous payload-carried ``source_type``; if that lookup
        fails (e.g. the WORKFLOW row was deleted), the handler must abort
        with a descriptive error instead of constructing an invalid loader.
        """
        mock_read_schema.return_value = [{"COLUMN_NAME": "C", "DATA_TYPE": "INTEGER"}]
        validator = MagicMock()
        validator.validate_schema = AsyncMock(
            return_value=MagicMock(table_exists=False)
        )
        mock_validator_cls.return_value = validator

        handler, _queue, _warehouse = _make_handler(source_platform=None)
        with self.assertRaises(ValueError) as ctx:
            await handler.handle(_make_task())
        self.assertIn("source platform", str(ctx.exception).lower())


if __name__ == "__main__":
    unittest.main()
