"""Unit tests for ``ensure_dv_pipe`` per-workflow lazy provisioning."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    TeardownDvSnowpipePayload,
)
from data_migration_orchestrator.data_validation_cloud.utils.ensure_dv_pipe import (
    _reset_cache_for_tests,
    ensure_dv_pipe,
)
from data_migration_orchestrator.data_validation_cloud.utils.pipe_utils import (
    DvResultsPipeKey,
    build_create_pipe_sql,
    build_dv_pipe_name,
)


def _run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def _make_task_queue(start_id: int = 1000) -> MagicMock:
    """Build a task-queue mock that hands out incrementing task ids."""
    counter = {"n": start_id}

    async def _push(_task):
        counter["n"] += 1
        return counter["n"]

    queue = MagicMock()
    queue.push_task = AsyncMock(side_effect=_push)
    return queue


def _make_warehouse() -> MagicMock:
    """Build a warehouse mock whose ``execute_sync_query`` is awaitable."""
    warehouse = MagicMock()
    warehouse.execute_sync_query = AsyncMock(return_value=[])
    return warehouse


def _pushed_payloads(queue: MagicMock) -> list:
    return [call.args[0].payload for call in queue.push_task.await_args_list]


class TestEnsureDvPipe:
    """Per-workflow CREATE + Teardown should happen exactly once per key."""

    def setup_method(self) -> None:
        _reset_cache_for_tests()

    def test_first_call_runs_create_pipe_then_pushes_teardown(self):
        queue = _make_task_queue()
        warehouse = _make_warehouse()

        pipe_name = _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=42,
                key=DvResultsPipeKey.METRICS,
            )
        )

        assert pipe_name == build_dv_pipe_name(42, DvResultsPipeKey.METRICS)

        warehouse.execute_sync_query.assert_awaited_once_with(
            build_create_pipe_sql(42, pipe_name, DvResultsPipeKey.METRICS)
        )
        assert queue.push_task.await_count == 1

        payloads = _pushed_payloads(queue)
        assert isinstance(payloads[0], TeardownDvSnowpipePayload)
        assert payloads[0].workflow_id == 42
        assert payloads[0].pipe_name == pipe_name

    def test_create_pipe_runs_before_teardown_is_pushed(self):
        """The pipe must exist before any DEA task could observe it."""
        queue = _make_task_queue()
        warehouse = _make_warehouse()

        order: list[str] = []

        async def _record_create(_sql):
            order.append("create")
            return []

        async def _record_push(_task):
            order.append("push")
            return 1234

        warehouse.execute_sync_query = AsyncMock(side_effect=_record_create)
        queue.push_task = AsyncMock(side_effect=_record_push)

        _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=42,
                key=DvResultsPipeKey.CELL_DIFFS,
            )
        )

        assert order == ["create", "push"]

    def test_teardown_task_is_blocked_and_cleanup(self):
        queue = _make_task_queue()
        warehouse = _make_warehouse()

        _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=7,
                key=DvResultsPipeKey.ROW_DIFFS,
            )
        )

        (call,) = queue.push_task.await_args_list
        teardown_task = call.args[0]
        assert teardown_task.is_blocked is True
        assert teardown_task.is_cleanup is True

    def test_second_call_same_workflow_and_key_is_cached(self):
        queue = _make_task_queue()
        warehouse = _make_warehouse()

        first = _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=42,
                key=DvResultsPipeKey.ROW_DIFFS,
            )
        )
        second = _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=42,
                key=DvResultsPipeKey.ROW_DIFFS,
            )
        )

        assert first == second
        warehouse.execute_sync_query.assert_awaited_once()
        assert queue.push_task.await_count == 1

    def test_distinct_keys_provision_independently(self):
        queue = _make_task_queue()
        warehouse = _make_warehouse()

        metrics = _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=42,
                key=DvResultsPipeKey.METRICS,
            )
        )
        cell = _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=42,
                key=DvResultsPipeKey.CELL_DIFFS,
            )
        )

        assert metrics != cell
        assert warehouse.execute_sync_query.await_count == 2
        assert queue.push_task.await_count == 2

    def test_distinct_workflows_provision_independently(self):
        queue = _make_task_queue()
        warehouse = _make_warehouse()

        a = _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=1,
                key=DvResultsPipeKey.METRICS,
            )
        )
        b = _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=2,
                key=DvResultsPipeKey.METRICS,
            )
        )

        assert a != b
        assert warehouse.execute_sync_query.await_count == 2
        assert queue.push_task.await_count == 2

    def test_concurrent_calls_provision_once(self):
        """Multiple concurrent calls for the same key dedupe via the cache."""
        queue = _make_task_queue()
        warehouse = _make_warehouse()

        async def _go():
            return await asyncio.gather(
                *[
                    ensure_dv_pipe(
                        task_queue=queue,
                        warehouse=warehouse,
                        workflow_id=42,
                        key=DvResultsPipeKey.CHUNK_HASHES,
                    )
                    for _ in range(5)
                ]
            )

        results = _run(_go())
        assert len(set(results)) == 1
        warehouse.execute_sync_query.assert_awaited_once()
        assert queue.push_task.await_count == 1

    def test_create_pipe_failure_rolls_back_cache(self):
        """A CREATE PIPE failure must let a later caller retry."""
        queue = _make_task_queue()
        warehouse = _make_warehouse()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[RuntimeError("network down"), []]
        )

        try:
            _run(
                ensure_dv_pipe(
                    task_queue=queue,
                    warehouse=warehouse,
                    workflow_id=42,
                    key=DvResultsPipeKey.METRICS,
                )
            )
        except RuntimeError:
            pass
        else:
            raise AssertionError("Expected the simulated failure to propagate")

        # Retry should re-run CREATE and then push Teardown.
        _run(
            ensure_dv_pipe(
                task_queue=queue,
                warehouse=warehouse,
                workflow_id=42,
                key=DvResultsPipeKey.METRICS,
            )
        )

        assert warehouse.execute_sync_query.await_count == 2
        assert queue.push_task.await_count == 1
