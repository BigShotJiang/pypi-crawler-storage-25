# Copyright (c) 2024-2026 Snowflake Inc. All rights reserved.
# Licensed under the Apache License, Version 2.0.
"""
Tests for ClearPartitionDataHandler.

Validates the defense-in-depth fix for SNOW-3284306: the handler must
skip the DELETE and complete the task when the target table does not
exist yet, rather than crashing.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.clear_partition_data_handler import (
    ClearPartitionDataHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    ClearPartitionDataPayload,
)


class TestClearPartitionDataHandler(unittest.IsolatedAsyncioTestCase):
    """Tests for ClearPartitionDataHandler."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.complete_task = AsyncMock()
        self.mock_warehouse = MagicMock()
        self.mock_warehouse.execute_sync_query = AsyncMock()

        self.handler = ClearPartitionDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse,
        )

        self.table_config = TableConfiguration(
            source=TableIdentifier("src_db", "src_schema", "src_table"),
            target=TableIdentifier("tgt_db", "tgt_schema", "tgt_table"),
            partition_columns=["id"],
        )

    def _make_task(self) -> Task:
        """Create a task with ClearPartitionDataPayload."""
        payload = ClearPartitionDataPayload(
            target_table="tgt_db.tgt_schema.tgt_table",
            table_metadata_id=1,
            min_value="1",
            max_value="1000",
            partition_metadata_id=100,
        )
        task = Task(
            workflow_id=42,
            executor_type=ExecutorType.ORCHESTRATOR,
            task_name="Clear partition #1",
            payload=payload,
            scope="Table[tgt_db.tgt_schema.tgt_table]::ClearPartition",
        )
        task.id = 999
        return task

    @patch.object(
        ClearPartitionDataHandler, "_update_partition_status", new_callable=AsyncMock
    )
    async def test_skips_delete_when_target_table_does_not_exist(
        self, mock_update_status
    ):
        """SNOW-3284306: skip DELETE when target table doesn't exist (first sync)."""
        # Mock table_config_service to return our config
        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=self.table_config)
        )

        # Mock schema validator: table does NOT exist
        self.handler._schema_validator.table_exists = AsyncMock(return_value=False)

        task = self._make_task()
        await self.handler.handle(task)

        # Should have checked table existence
        self.handler._schema_validator.table_exists.assert_awaited_once_with(
            "tgt_db", "tgt_schema", "tgt_table"
        )

        # Should NOT have executed any DELETE query
        # (warehouse execute_sync_query should not be called for DELETE,
        # only indirectly via table_config_service which is mocked)
        mock_update_status.assert_not_called()

        # Should have completed the task to unblock the chain
        self.mock_task_queue.complete_task.assert_awaited_once()

    @patch.object(
        ClearPartitionDataHandler, "_update_partition_status", new_callable=AsyncMock
    )
    async def test_executes_delete_when_target_table_exists(self, mock_update_status):
        """When target table exists (subsequent sync), DELETE must execute normally."""
        # Mock table_config_service
        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=self.table_config)
        )

        # Mock schema validator: table DOES exist
        self.handler._schema_validator.table_exists = AsyncMock(return_value=True)

        task = self._make_task()
        await self.handler.handle(task)

        # Should have checked table existence
        self.handler._schema_validator.table_exists.assert_awaited_once_with(
            "tgt_db", "tgt_schema", "tgt_table"
        )

        # Should have updated partition status to LOADING
        mock_update_status.assert_awaited_once()

        # Should have executed the DELETE query via warehouse_proxy
        self.mock_warehouse.execute_sync_query.assert_awaited()

        # Should have completed the task
        self.mock_task_queue.complete_task.assert_awaited_once()
