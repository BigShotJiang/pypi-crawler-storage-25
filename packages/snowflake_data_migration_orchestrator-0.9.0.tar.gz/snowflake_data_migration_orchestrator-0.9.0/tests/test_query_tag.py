import json
import unittest
from unittest.mock import MagicMock

from data_migration_orchestrator.cloud_core.query_tag import (
    _escape,
    build_query_tag,
    clear_query_tag,
    set_query_tag,
)


class TestBuildQueryTag(unittest.TestCase):
    """Tests for build_query_tag JSON construction."""

    def test_workflow_and_task_ids(self):
        tag = build_query_tag(workflow_id=42, task_id=1017)
        parsed = json.loads(tag)
        assert parsed == {"DMVF_WORKFLOW_ID": "42", "DMVF_TASK_ID": "1017"}

    def test_omits_none_values(self):
        tag = build_query_tag(workflow_id=None, task_id=None)
        assert json.loads(tag) == {}

    def test_extra_tags(self):
        tag = build_query_tag(DMVF_VERSION="0.8.0")
        parsed = json.loads(tag)
        assert parsed == {"DMVF_VERSION": "0.8.0"}

    def test_combined_task_and_version(self):
        tag = build_query_tag(
            workflow_id=1, task_id=2, DMVF_ORCHESTRATOR_VERSION="0.8.0"
        )
        parsed = json.loads(tag)
        assert parsed == {
            "DMVF_WORKFLOW_ID": "1",
            "DMVF_TASK_ID": "2",
            "DMVF_ORCHESTRATOR_VERSION": "0.8.0",
        }

    def test_coerces_ints_to_strings(self):
        tag = build_query_tag(workflow_id=99, task_id=100)
        parsed = json.loads(tag)
        assert parsed["DMVF_WORKFLOW_ID"] == "99"
        assert parsed["DMVF_TASK_ID"] == "100"

    def test_compact_json(self):
        tag = build_query_tag(workflow_id=1, task_id=2)
        assert " " not in tag


class TestSetQueryTag(unittest.TestCase):
    """Tests for set_query_tag session ALTER execution."""

    def test_executes_alter_session(self):
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        set_query_tag(mock_conn, workflow_id=42, task_id=7)

        mock_cursor.execute.assert_called_once()
        sql = mock_cursor.execute.call_args[0][0]
        assert sql.startswith("ALTER SESSION SET QUERY_TAG = '")
        payload = json.loads(sql.split("'", 1)[1].rsplit("'", 1)[0])
        assert payload["DMVF_WORKFLOW_ID"] == "42"
        assert payload["DMVF_TASK_ID"] == "7"

    def test_version_only_tag(self):
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        set_query_tag(mock_conn, DMVF_VERSION="0.8.0")

        sql = mock_cursor.execute.call_args[0][0]
        payload = json.loads(sql.split("'", 1)[1].rsplit("'", 1)[0])
        assert payload == {"DMVF_VERSION": "0.8.0"}

    def test_swallows_exceptions(self):
        mock_conn = MagicMock()
        mock_conn.cursor.side_effect = RuntimeError("connection lost")
        set_query_tag(mock_conn, workflow_id=1)


class TestClearQueryTag(unittest.TestCase):
    """Tests for clear_query_tag session UNSET execution."""

    def test_executes_unset(self):
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        clear_query_tag(mock_conn)

        mock_cursor.execute.assert_called_once_with("ALTER SESSION UNSET QUERY_TAG")

    def test_swallows_exceptions(self):
        mock_conn = MagicMock()
        mock_conn.cursor.side_effect = RuntimeError("connection lost")
        clear_query_tag(mock_conn)


class TestEscape(unittest.TestCase):
    """Tests for _escape SQL string literal helper."""

    def test_no_quotes(self):
        assert _escape("hello") == "hello"

    def test_single_quote_doubled(self):
        assert _escape("it's") == "it''s"

    def test_multiple_quotes(self):
        assert _escape("a'b'c") == "a''b''c"

    def test_empty_string(self):
        assert _escape("") == ""

    def test_json_with_no_quotes(self):
        tag = build_query_tag(workflow_id=1)
        assert _escape(tag) == tag


class TestSetQueryTagEscaping(unittest.TestCase):
    """Verify that set_query_tag properly escapes tag values containing single quotes."""

    def test_escapes_single_quotes_in_tag(self):
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        set_query_tag(mock_conn, DMVF_NOTE="it's a test")

        sql = mock_cursor.execute.call_args[0][0]
        assert "''" in sql
        assert "it''s a test" in sql
