"""Unit tests for schema validation and drift detection."""

import pytest

from data_migration_orchestrator.data_migration_cloud.services.schema_validator import (
    ColumnSchema,
    SchemaValidationResult,
    SchemaValidator,
)


class TestSchemaValidator:
    """Tests for SchemaValidator drift detection."""

    @pytest.fixture
    def validator(self):
        """Create a SchemaValidator instance."""
        return SchemaValidator(warehouse_proxy=None)

    def test_no_drift_when_schemas_match(self, validator):
        """Test no drift detected when schemas are identical."""
        expected = [ColumnSchema("id", "NUMBER"), ColumnSchema("name", "VARCHAR")]
        existing = [ColumnSchema("id", "NUMBER"), ColumnSchema("name", "VARCHAR")]

        drifts = validator.compare_schemas(expected, existing)

        assert len(drifts) == 0

    def test_detects_missing_column(self, validator):
        """Test drift detected when column is missing in target."""
        expected = [ColumnSchema("id", "NUMBER"), ColumnSchema("email", "VARCHAR")]
        existing = [ColumnSchema("id", "NUMBER")]

        drifts = validator.compare_schemas(expected, existing)

        assert len(drifts) == 1
        assert drifts[0].drift_type == "missing_in_target"
        assert drifts[0].column_name == "email"

    def test_detects_extra_column(self, validator):
        """Test drift detected when target has extra column."""
        expected = [ColumnSchema("id", "NUMBER")]
        existing = [
            ColumnSchema("id", "NUMBER"),
            ColumnSchema("created_at", "TIMESTAMP"),
        ]

        drifts = validator.compare_schemas(expected, existing)

        assert len(drifts) == 1
        assert drifts[0].drift_type == "extra_in_target"

    def test_detects_type_mismatch(self, validator):
        """Test drift detected when column types are incompatible."""
        expected = [ColumnSchema("status", "BOOLEAN")]
        existing = [ColumnSchema("status", "VARCHAR")]

        drifts = validator.compare_schemas(expected, existing)

        assert len(drifts) == 1
        assert drifts[0].drift_type == "type_mismatch"

    def test_compatible_types_no_mismatch(self, validator):
        """Test no drift when types are in same family (e.g., NUMBER/INTEGER)."""
        expected = [ColumnSchema("count", "NUMBER")]
        existing = [ColumnSchema("count", "INTEGER")]

        drifts = validator.compare_schemas(expected, existing)

        assert len(drifts) == 0

    def test_column_names_case_insensitive(self, validator):
        """Test column matching is case-insensitive."""
        expected = [ColumnSchema("UserName", "VARCHAR")]
        existing = [ColumnSchema("USERNAME", "VARCHAR")]

        drifts = validator.compare_schemas(expected, existing)

        assert len(drifts) == 0

    def test_get_columns_for_new_table(self, validator):
        """For new table, COPY columns come from expected_schema (table was created from it)."""
        result = SchemaValidationResult(
            table_exists=False,
            actual_schema=[],
            expected_schema=[
                ColumnSchema("id", "NUMBER"),
                ColumnSchema("name", "VARCHAR"),
            ],
            drifts=[],
            is_compatible=True,
        )
        source = [
            {"column_name": "id", "data_type": "INT"},
            {"column_name": "name", "data_type": "VARCHAR"},
        ]

        columns = validator.get_columns_for_copy_into(result, source)

        assert columns == [("id", "INT"), ("name", "VARCHAR")]

    def test_get_columns_for_new_table_uses_expected_schema_only(self, validator):
        """New table has only mapped columns; COPY list must match (no 25 vs 28 mismatch)."""
        result = SchemaValidationResult(
            table_exists=False,
            actual_schema=[],
            expected_schema=[
                ColumnSchema("id", "NUMBER"),
                ColumnSchema("name", "VARCHAR"),
            ],
            drifts=[],
            is_compatible=True,
        )
        source = [
            {"column_name": "id", "data_type": "INT"},
            {"column_name": "name", "data_type": "VARCHAR"},
            {"column_name": "col_interval_ym", "data_type": "INTERVALY2M"},
            {"column_name": "col_hllsketch", "data_type": "HLLSKETCH"},
        ]

        columns = validator.get_columns_for_copy_into(result, source)

        # Must match table (expected_schema), not full source
        assert columns == [("id", "INT"), ("name", "VARCHAR")]

    def test_get_columns_for_existing_table_filters_missing(self, validator):
        """Test only matching columns returned for existing table."""
        result = SchemaValidationResult(
            table_exists=True,
            actual_schema=[
                ColumnSchema("id", "NUMBER"),
                ColumnSchema("name", "VARCHAR"),
            ],
            expected_schema=[],
            drifts=[],
            is_compatible=True,
        )
        source = [
            {"column_name": "id", "data_type": "INT"},
            {"column_name": "name", "data_type": "VARCHAR"},
            {"column_name": "email", "data_type": "VARCHAR"},  # Not in target
        ]

        columns = validator.get_columns_for_copy_into(result, source)

        assert columns == [("id", "INT"), ("name", "VARCHAR")]
