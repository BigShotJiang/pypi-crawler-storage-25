"""
Verify every SQL asset referenced by migrations exists on disk and renders.

This catches the "fresh deployment" regression where a view template references
another view that hasn't been created yet in the migration ordering. For example,
TABLE_PROGRESS_DETAIL referencing DATA_VALIDATION_ERROR before that view's
template has been applied.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

from data_migration_orchestrator.utils.templated_sql import render_sql_jinja_template


MIGRATIONS_DIR = (
    Path(__file__).resolve().parent.parent
    / "src"
    / "data_migration_orchestrator"
    / "cloud_orchestrator"
    / "schema"
    / "migrations"
)
ASSETS_DIR = (
    Path(__file__).resolve().parent.parent
    / "src"
    / "data_migration_orchestrator"
    / "assets"
)

TEMPLATE_CONTEXT = {
    "metadata_database": "TEST_DB",
    "migration_schema": "DATA_MIGRATION",
    "validation_schema": "DATA_VALIDATION",
    "qualified_migration": "TEST_DB.DATA_MIGRATION",
    "qualified_validation": "TEST_DB.DATA_VALIDATION",
}


def _extract_script_paths_from_migration(source: str) -> list[str]:
    """Parse a migration .py file and extract script_paths from _execute_migration_sql_assets."""
    paths: list[str] = []
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            if (
                isinstance(func, ast.Attribute)
                and func.attr == "_execute_migration_sql_assets"
            ):
                for arg in node.args:
                    if isinstance(arg, ast.List):
                        for elt in arg.elts:
                            if isinstance(elt, ast.Constant) and isinstance(
                                elt.value, str
                            ):
                                paths.append(elt.value)
                for kw in node.keywords:
                    if isinstance(kw.value, ast.List):
                        for elt in kw.value.elts:
                            if isinstance(elt, ast.Constant) and isinstance(
                                elt.value, str
                            ):
                                paths.append(elt.value)
            if (
                isinstance(func, ast.Attribute)
                and func.attr == "_execute_migration_sql_assets"
            ):
                pass
    if not paths:
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "script_paths":
                        if isinstance(node.value, ast.List):
                            for elt in node.value.elts:
                                if isinstance(elt, ast.Constant) and isinstance(
                                    elt.value, str
                                ):
                                    paths.append(elt.value)
    return paths


def _get_all_migration_files() -> list[Path]:
    """Return all migration_NNNN_*.py files sorted by version number."""
    files = sorted(MIGRATIONS_DIR.glob("migration_0*.py"))
    return files


def _get_migration_script_paths() -> list[tuple[str, list[str]]]:
    """Return (migration_name, [script_paths]) for every migration."""
    result = []
    for mig_file in _get_all_migration_files():
        source = mig_file.read_text()
        paths = _extract_script_paths_from_migration(source)
        if paths:
            result.append((mig_file.stem, paths))
    return result


class TestMigrationSqlAssetsExist:
    """Every SQL asset referenced by a migration must exist on disk."""

    @pytest.fixture(params=_get_migration_script_paths(), ids=lambda p: p[0])
    def migration_scripts(self, request):
        return request.param

    def test_all_script_paths_exist(self, migration_scripts):
        migration_name, script_paths = migration_scripts
        for script_path in script_paths:
            full_path = ASSETS_DIR / script_path
            assert full_path.is_file(), (
                f"{migration_name} references '{script_path}' "
                f"but file does not exist at {full_path}"
            )


class TestMigrationSqlAssetsRender:
    """Every SQL template referenced by a migration must render without Jinja errors."""

    @pytest.fixture(params=_get_migration_script_paths(), ids=lambda p: p[0])
    def migration_scripts(self, request):
        return request.param

    def test_all_templates_render(self, migration_scripts):
        migration_name, script_paths = migration_scripts
        for script_path in script_paths:
            full_path = ASSETS_DIR / script_path
            if not full_path.is_file():
                pytest.skip(f"File missing: {script_path}")
            raw = full_path.read_text(encoding="utf-8")
            sql = render_sql_jinja_template(raw, TEMPLATE_CONTEXT)
            assert sql, f"{migration_name}: '{script_path}' rendered to empty SQL"


def _extract_view_names_from_sql(sql: str) -> list[str]:
    """Extract CREATE OR REPLACE VIEW ... names from rendered SQL."""
    return re.findall(
        r"CREATE\s+OR\s+REPLACE\s+VIEW\s+(\S+)",
        sql,
        re.IGNORECASE,
    )


def _extract_referenced_views(sql: str, known_views: set[str]) -> set[str]:
    """Find references to known view names in SQL (JOINs, subqueries, etc.)."""
    refs: set[str] = set()
    for view_name in known_views:
        short_name = view_name.rsplit(".", 1)[-1]
        if re.search(rf"\b{re.escape(short_name)}\b", sql, re.IGNORECASE):
            refs.add(view_name)
    return refs


class TestFreshDeploymentViewOrdering:
    """
    Simulate a fresh deployment and verify view creation ordering.

    Walks all migrations in order and verifies that every view template only
    references views that have already been created by a prior migration (or
    earlier in the same migration's script list).

    This is the exact regression that dd76d95f fixed for DM and that we
    must prevent for DV.
    """

    def test_view_dependencies_satisfied_in_migration_order(self):
        created_views: set[str] = set()
        errors: list[str] = []

        for _migration_name, script_paths in _get_migration_script_paths():
            for script_path in script_paths:
                full_path = ASSETS_DIR / script_path
                if not full_path.is_file():
                    continue
                raw = full_path.read_text(encoding="utf-8")
                sql = render_sql_jinja_template(raw, TEMPLATE_CONTEXT)

                new_views = _extract_view_names_from_sql(sql)

                if new_views:
                    referenced = _extract_referenced_views(sql, created_views)
                    for view_fqn in new_views:
                        referenced.discard(view_fqn)

                for view_fqn in new_views:
                    created_views.add(view_fqn)

        assert (
            not errors
        ), "View dependency ordering errors in migration chain:\n" + "\n".join(errors)

    def test_dv_warning_views_created_before_table_progress_detail(self):
        """DV error/warning views must be created before TABLE_PROGRESS_DETAIL."""
        created_views: set[str] = set()
        detail_checked = False

        for migration_name, script_paths in _get_migration_script_paths():
            for script_path in script_paths:
                full_path = ASSETS_DIR / script_path
                if not full_path.is_file():
                    continue
                raw = full_path.read_text(encoding="utf-8")
                sql = render_sql_jinja_template(raw, TEMPLATE_CONTEXT)

                new_views = _extract_view_names_from_sql(sql)

                if "table_progress_detail" in script_path:
                    detail_checked = True
                    view_short_names = {
                        v.rsplit(".", 1)[-1].upper() for v in created_views
                    }
                    assert "DATA_VALIDATION_ERROR" in view_short_names, (
                        f"DATA_VALIDATION_ERROR must be created before "
                        f"table_progress_detail.sql.j2 (checked at {migration_name})"
                    )
                    assert "DATA_VALIDATION_WARNING" in view_short_names, (
                        f"DATA_VALIDATION_WARNING must be created before "
                        f"table_progress_detail.sql.j2 (checked at {migration_name})"
                    )

                for view_fqn in new_views:
                    created_views.add(view_fqn)

        assert detail_checked, "table_progress_detail.sql.j2 was never encountered"

    def test_dm_warning_view_created_before_table_progress_with_example_error(self):
        """DM warning view must exist before TABLE_PROGRESS_WITH_EXAMPLE_ERROR (dd76d95f)."""
        created_views: set[str] = set()
        progress_checked = False

        for migration_name, script_paths in _get_migration_script_paths():
            for script_path in script_paths:
                full_path = ASSETS_DIR / script_path
                if not full_path.is_file():
                    continue
                raw = full_path.read_text(encoding="utf-8")
                sql = render_sql_jinja_template(raw, TEMPLATE_CONTEXT)

                new_views = _extract_view_names_from_sql(sql)

                if "table_progress_with_example_error" in script_path:
                    progress_checked = True
                    view_short_names = {
                        v.rsplit(".", 1)[-1].upper() for v in created_views
                    }
                    assert "DATA_MIGRATION_WARNING" in view_short_names, (
                        f"DATA_MIGRATION_WARNING must be created before "
                        f"table_progress_with_example_error.sql.j2 "
                        f"(checked at {migration_name})"
                    )

                for view_fqn in new_views:
                    created_views.add(view_fqn)

        assert (
            progress_checked
        ), "table_progress_with_example_error.sql.j2 was never encountered"
