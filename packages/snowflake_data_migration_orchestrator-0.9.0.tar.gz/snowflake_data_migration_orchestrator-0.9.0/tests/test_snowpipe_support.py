"""
Tests for Snowpipe support.

Covers executor type, task payloads, cleanup task lifecycle,
payload mapper, loading strategy configuration, TEMP schema pipe naming,
metadata helpers, and event-based monitoring.
"""

import dataclasses

import pytest

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.snowpipe_task import (
    SNOWPIPE_TASK_PAYLOAD_KIND,
    SnowpipeTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationParser,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    DEFAULT_LOADING_STRATEGY,
    LoadingConfig,
    LoadingStrategy,
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    SetupSnowpipePayload,
    TeardownSnowpipePayload,
)
from data_migration_orchestrator.data_migration_cloud.utils.pipe_utils import (
    build_pipe_name,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_payload_mapper import (
    map_data_migration_task_payload,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_event_table,
    qualified_temp_schema,
    temp_schema,
)


# ---------------------------------------------------------------------------
# ExecutorType
# ---------------------------------------------------------------------------


class TestSnowpipeExecutorType:
    """Tests for the SNOWPIPE executor type."""

    def test_snowpipe_exists(self):
        assert ExecutorType.SNOWPIPE == "snowpipe"

    def test_snowpipe_is_distinct_from_warehouse(self):
        assert ExecutorType.SNOWPIPE != ExecutorType.WAREHOUSE

    def test_all_executor_types_unique(self):
        values = [e.value for e in ExecutorType]
        assert len(values) == len(set(values))


# ---------------------------------------------------------------------------
# SnowpipeTaskPayload
# ---------------------------------------------------------------------------


class TestSnowpipeTaskPayload:
    """Tests for the SnowpipeTaskPayload dataclass."""

    def test_payload_creation(self):
        payload = SnowpipeTaskPayload(
            pipe_name="SNOWCONVERT_AI.TEMP.DMO_PIPE_1_MY_TABLE",
            prefix="stage/1/42/",
            pipe_name_short="DMO_PIPE_1_MY_TABLE",
        )
        assert payload.pipe_name == "SNOWCONVERT_AI.TEMP.DMO_PIPE_1_MY_TABLE"
        assert payload.prefix == "stage/1/42/"
        assert payload.pipe_name_short == "DMO_PIPE_1_MY_TABLE"
        assert payload.kind == SNOWPIPE_TASK_PAYLOAD_KIND

    def test_pipe_name_short_defaults_to_empty(self):
        payload = SnowpipeTaskPayload(pipe_name="P", prefix="pfx")
        assert payload.pipe_name_short == ""

    def test_kind_literal(self):
        payload = SnowpipeTaskPayload(pipe_name="P", prefix="pfx")
        assert payload.kind == "snowpipe_ingestion"

    def test_payload_serializes(self):
        payload = SnowpipeTaskPayload(pipe_name="P", prefix="pfx", pipe_name_short="P")
        d = dataclasses.asdict(payload)
        assert d == {
            "pipe_name": "P",
            "prefix": "pfx",
            "pipe_name_short": "P",
            "mode": "prefix",
            "kind": "snowpipe_ingestion",
        }

    def test_payload_defaults_to_prefix_mode(self):
        payload = SnowpipeTaskPayload(pipe_name="P", prefix="pfx")
        assert payload.mode == "prefix"

    def test_payload_drain_mode(self):
        payload = SnowpipeTaskPayload(pipe_name="P", mode="drain")
        assert payload.mode == "drain"
        assert payload.prefix == ""


# ---------------------------------------------------------------------------
# SetupSnowpipePayload / TeardownSnowpipePayload
# ---------------------------------------------------------------------------


class TestSnowpipeLifecyclePayloads:
    """Tests for SetupSnowpipePayload and TeardownSnowpipePayload."""

    def test_setup_payload(self):
        payload = SetupSnowpipePayload(
            pipe_name="SNOWCONVERT_AI.TEMP.DMO_PIPE_1_MY_TABLE",
            target_table="DB.SCHEMA.MY_TABLE",
            stage_path="@STAGE/1/42/",
            table_metadata_id=42,
        )
        assert payload.kind == TaskPayloadKind.SETUP_SNOWPIPE
        assert payload.pipe_name == "SNOWCONVERT_AI.TEMP.DMO_PIPE_1_MY_TABLE"
        assert payload.stage_path == "@STAGE/1/42/"
        assert payload.table_metadata_id == 42
        assert not hasattr(payload, "source_type"), (
            "source_type must not be a payload field; the handler resolves it "
            "from WORKFLOW.SOURCE_PLATFORM via WorkflowConfigService."
        )

    def test_teardown_payload(self):
        payload = TeardownSnowpipePayload(
            pipe_name="SNOWCONVERT_AI.TEMP.DMO_PIPE_1_MY_TABLE",
        )
        assert payload.kind == TaskPayloadKind.TEARDOWN_SNOWPIPE
        assert payload.pipe_name == "SNOWCONVERT_AI.TEMP.DMO_PIPE_1_MY_TABLE"


# ---------------------------------------------------------------------------
# TaskPayloadKind
# ---------------------------------------------------------------------------


class TestTaskPayloadKindSnowpipe:
    """Tests for Snowpipe-related TaskPayloadKind enum members."""

    def test_snowpipe_kinds_exist(self):
        assert TaskPayloadKind.SNOWPIPE_INGESTION == "snowpipe_ingestion"
        assert TaskPayloadKind.SETUP_SNOWPIPE == "setup_snowpipe"
        assert TaskPayloadKind.TEARDOWN_SNOWPIPE == "teardown_snowpipe"

    def test_kind_values_unique(self):
        all_values = [k.value for k in TaskPayloadKind]
        assert len(all_values) == len(set(all_values))


# ---------------------------------------------------------------------------
# Cleanup task model
# ---------------------------------------------------------------------------


class TestCleanupTaskModel:
    """Tests for the is_cleanup field on Task and TaskBuilder."""

    def test_task_defaults_not_cleanup(self):
        task = Task(
            workflow_id=1,
            executor_type=ExecutorType.ORCHESTRATOR,
            task_name="test",
            payload=None,
            scope="test_scope",
        )
        assert task.is_cleanup is False

    def test_task_builder_cleanup(self):
        task = (
            TaskBuilder(
                workflow_id=1,
                task_name="teardown",
                executor_type=ExecutorType.ORCHESTRATOR,
                payload=TeardownSnowpipePayload(pipe_name="P"),
                scope="test_scope",
            )
            .blocked()
            .cleanup()
            .build()
        )
        assert task.is_cleanup is True
        assert task.is_blocked is True

    def test_task_builder_defaults_not_cleanup(self):
        task = TaskBuilder(
            workflow_id=1,
            task_name="normal",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=None,
            scope="test_scope",
        ).build()
        assert task.is_cleanup is False


# ---------------------------------------------------------------------------
# Payload mapper
# ---------------------------------------------------------------------------


class TestPayloadMapperSnowpipe:
    """Tests for Snowpipe payload deserialization via the payload mapper."""

    def test_map_snowpipe_ingestion(self):
        payload = map_data_migration_task_payload(
            "snowpipe_ingestion",
            {
                "pipe_name": "P",
                "prefix": "pfx",
                "pipe_name_short": "P",
                "kind": "snowpipe_ingestion",
            },
        )
        assert isinstance(payload, SnowpipeTaskPayload)
        assert payload.pipe_name == "P"
        assert payload.pipe_name_short == "P"

    def test_map_setup_snowpipe(self):
        payload = map_data_migration_task_payload(
            "setup_snowpipe",
            {
                "pipe_name": "P",
                "target_table": "T",
                "stage_path": "S",
                "table_metadata_id": 7,
                "kind": "setup_snowpipe",
            },
        )
        assert isinstance(payload, SetupSnowpipePayload)
        assert payload.target_table == "T"
        assert payload.table_metadata_id == 7

    def test_map_teardown_snowpipe(self):
        payload = map_data_migration_task_payload(
            "teardown_snowpipe",
            {"pipe_name": "P", "kind": "teardown_snowpipe"},
        )
        assert isinstance(payload, TeardownSnowpipePayload)
        assert payload.pipe_name == "P"


# ---------------------------------------------------------------------------
# Loading strategy configuration
# ---------------------------------------------------------------------------


class TestLoadingStrategyEnum:
    """Tests for the LoadingStrategy enum."""

    def test_default_is_warehouse(self):
        assert DEFAULT_LOADING_STRATEGY == LoadingStrategy.WAREHOUSE

    def test_from_string_warehouse(self):
        assert LoadingStrategy.from_string("warehouse") == LoadingStrategy.WAREHOUSE

    def test_from_string_snowpipe(self):
        assert LoadingStrategy.from_string("snowpipe") == LoadingStrategy.SNOWPIPE

    def test_from_string_case_insensitive(self):
        assert LoadingStrategy.from_string("SNOWPIPE") == LoadingStrategy.SNOWPIPE

    def test_from_string_invalid(self):
        with pytest.raises(ValueError):
            LoadingStrategy.from_string("invalid")


class TestConfigurationParserLoadingStrategy:
    """Tests for parsing the nested loading.strategy config key."""

    def setup_method(self):
        self.parser = ConfigurationParser()

    def _base_config(self, **overrides) -> dict:
        config = {
            "source": {
                "databaseName": "SRC_DB",
                "schemaName": "SRC_SCHEMA",
                "tableName": "MY_TABLE",
            },
            "target": {
                "databaseName": "TGT_DB",
                "schemaName": "TGT_SCHEMA",
                "tableName": "MY_TABLE",
            },
        }
        config.update(overrides)
        return config

    def test_default_loading_strategy(self):
        config = self.parser.parse_table_configuration(self._base_config())
        assert config.loading_strategy == LoadingStrategy.WAREHOUSE

    def test_explicit_warehouse(self):
        config = self.parser.parse_table_configuration(
            self._base_config(loading={"strategy": "warehouse"})
        )
        assert config.loading_strategy == LoadingStrategy.WAREHOUSE

    def test_snowpipe_strategy(self):
        config = self.parser.parse_table_configuration(
            self._base_config(loading={"strategy": "snowpipe"})
        )
        assert config.loading_strategy == LoadingStrategy.SNOWPIPE

    def test_invalid_loading_strategy(self):
        from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
            ConfigurationError,
        )

        with pytest.raises(ConfigurationError, match="loading strategy"):
            self.parser.parse_table_configuration(
                self._base_config(loading={"strategy": "invalid_strategy"})
            )

    def test_empty_loading_section_uses_default(self):
        config = self.parser.parse_table_configuration(self._base_config(loading={}))
        assert config.loading_strategy == LoadingStrategy.WAREHOUSE


class TestTableConfigurationLoadingStrategy:
    """Tests for the loading config on TableConfiguration."""

    def test_default(self):
        config = TableConfiguration(
            source=TableIdentifier("DB", "SCH", "TBL"),
            target=TableIdentifier("DB", "SCH", "TBL"),
        )
        assert config.loading.strategy == LoadingStrategy.WAREHOUSE
        assert config.loading_strategy == LoadingStrategy.WAREHOUSE

    def test_explicit_snowpipe(self):
        config = TableConfiguration(
            source=TableIdentifier("DB", "SCH", "TBL"),
            target=TableIdentifier("DB", "SCH", "TBL"),
            loading=LoadingConfig(strategy=LoadingStrategy.SNOWPIPE),
        )
        assert config.loading.strategy == LoadingStrategy.SNOWPIPE
        assert config.loading_strategy == LoadingStrategy.SNOWPIPE


# ---------------------------------------------------------------------------
# Metadata helpers
# ---------------------------------------------------------------------------


class TestSnowflakeMetadataHelpers:
    """Tests for temp_schema, qualified_temp_schema, and qualified_event_table helpers."""

    def test_temp_schema(self):
        assert temp_schema() == "TEMP"

    def test_qualified_temp_schema(self):
        assert qualified_temp_schema() == "SNOWCONVERT_AI.TEMP"

    def test_qualified_event_table(self):
        assert qualified_event_table() == "SNOWCONVERT_AI.DATA_MIGRATION.EVENTS"


# ---------------------------------------------------------------------------
# Pipe naming -- TEMP schema
# ---------------------------------------------------------------------------


class TestPipeNamingTempSchema:
    """Tests that build_pipe_name places pipes in the TEMP schema and is case-normalized."""

    def test_pipe_name_fq_target(self):
        name = build_pipe_name(1, "MY_DB.MY_SCHEMA.MY_TABLE")
        assert name == "SNOWCONVERT_AI.TEMP.DMO_PIPE_1_MY_TABLE"

    def test_pipe_name_unqualified(self):
        name = build_pipe_name(1, "SIMPLE_TABLE")
        assert name == "SNOWCONVERT_AI.TEMP.DMO_PIPE_1_SIMPLE_TABLE"

    def test_pipe_name_is_upper_cased(self):
        """
        Mixed-case input must yield an upper-cased identifier.

        This matches the value Snowflake stores for unquoted pipe identifiers
        in the catalog and in the file_lifecycle event table's
        ``snow.pipe.name`` attribute, so the monitoring query can match rows
        by short name without case-sensitivity gotchas.
        """
        name = build_pipe_name(1, "e2e_tests.e2e_tests_redshift_unload.basic")
        assert name == "SNOWCONVERT_AI.TEMP.DMO_PIPE_1_BASIC"
        assert name == name.upper()

    def test_pipe_name_upper_cased_unqualified(self):
        name = build_pipe_name(7, "mixedCase")
        assert name == "SNOWCONVERT_AI.TEMP.DMO_PIPE_7_MIXEDCASE"
