"""
Tests for StagedDataHandler partition status methods.

This module tests the partition metadata status update methods
in the StagedDataHandler, specifically the _update_partition_status method
and the creation of CompletePartitionMigrationTask as successor.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from shared.enums.file_type import FileType
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler import (
    StagedDataHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.partition_migration_status import (
    PartitionMigrationStatus,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CompletePartitionMigrationTaskPayload,
    ProcessStagedDataTaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)


class TestStagedDataHandlerPartitionStatus(unittest.TestCase):
    """Test cases for StagedDataHandler partition status methods."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=1)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    def test_handler_initialization(self):
        """Test handler initializes with correct task type."""
        self.assertEqual(self.handler.task_type, TaskPayloadKind.PROCESS_STAGED_DATA)


class TestUpdatePartitionStatus(unittest.IsolatedAsyncioTestCase):
    """Test cases for _update_partition_status method."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    async def test_update_partition_status_to_loading(self):
        """Test updating partition status to LOADING."""
        await self.handler._update_partition_status(
            partition_metadata_id=123,
            status=PartitionMigrationStatus.LOADING,
        )

        self.mock_warehouse_proxy.execute_sync_query.assert_called_once()
        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]

        self.assertIn("PARTITION_METADATA", query)
        self.assertIn("MIGRATION_STATUS = 'LOADING'", query)
        self.assertIn("WHERE ID = 123", query)

    async def test_update_partition_status_includes_timestamp(self):
        """Test that status update includes timestamp update."""
        await self.handler._update_partition_status(
            partition_metadata_id=456,
            status=PartitionMigrationStatus.COMPLETED,
        )

        call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
        query = call_args[0][0]

        self.assertIn("MIGRATION_STATUS_TIMESTAMP = CURRENT_TIMESTAMP()", query)

    async def test_update_partition_status_with_valid_id(self):
        """Test that update is executed when partition_metadata_id is valid."""
        await self.handler._update_partition_status(
            partition_metadata_id=100,
            status=PartitionMigrationStatus.LOADING,
        )

        self.mock_warehouse_proxy.execute_sync_query.assert_called_once()

    async def test_update_partition_status_skips_when_warehouse_proxy_is_none(self):
        """Test that update is skipped when warehouse_proxy is None."""
        handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=None,
        )

        await handler._update_partition_status(
            partition_metadata_id=100,
            status=PartitionMigrationStatus.LOADING,
        )
        # Should not raise

    async def test_update_partition_status_handles_error_gracefully(self):
        """Test that errors are handled gracefully (logged but not raised)."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=Exception("Database error")
        )

        # Should not raise - errors are logged but not propagated
        await self.handler._update_partition_status(
            partition_metadata_id=100,
            status=PartitionMigrationStatus.LOADING,
        )

    async def test_update_partition_status_with_different_statuses(self):
        """Test update with different status values."""
        statuses = [
            PartitionMigrationStatus.EXTRACTING,
            PartitionMigrationStatus.LOADING,
            PartitionMigrationStatus.COMPLETED,
            PartitionMigrationStatus.FAILED,
        ]

        for status in statuses:
            self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])
            await self.handler._update_partition_status(
                partition_metadata_id=100,
                status=status,
            )

            call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
            query = call_args[0][0]
            self.assertIn(f"MIGRATION_STATUS = '{status}'", query)

    async def test_update_partition_status_with_different_ids(self):
        """Test update with various partition metadata IDs."""
        for partition_id in [1, 100, 999999]:
            self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])
            await self.handler._update_partition_status(
                partition_metadata_id=partition_id,
                status=PartitionMigrationStatus.LOADING,
            )

            call_args = self.mock_warehouse_proxy.execute_sync_query.call_args
            query = call_args[0][0]
            self.assertIn(f"WHERE ID = {partition_id}", query)


class TestStagedDataHandlerCreatesSuccessorTask(unittest.IsolatedAsyncioTestCase):
    """Test cases for StagedDataHandler creating CompletePartitionMigrationTask."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=999)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            return_value=[
                {"COLUMN_NAME": "ID", "TYPE": "INTEGER"},
                {"COLUMN_NAME": "NAME", "TYPE": "VARCHAR"},
            ]
        )
        self.mock_warehouse_proxy.execute_snowflake_query_and_push_task = AsyncMock(
            return_value=None
        )

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.resolve_stage_for_strategy"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.read_schema_from_stage"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.SchemaValidator"
    )
    async def test_creates_successor_task_when_partition_metadata_id_present(
        self, mock_schema_validator, mock_read_schema, mock_resolve_stage
    ):
        """Test that CompletePartitionMigrationTask is created when partition_metadata_id is set."""
        # Setup mocks for table config and workflow config services
        mock_table_config = MagicMock()
        mock_table_config.extraction_strategy = MagicMock()
        mock_table_config.extraction_strategy.value = "regular"
        mock_table_config.column_type_mappings = None
        mock_table_config.column_name_mappings = None
        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=mock_table_config)
        )
        self.handler.workflow_config_service.fetch_strategy_config = AsyncMock(
            return_value={}
        )
        self.handler.workflow_config_service.fetch_workflow_external_stage = AsyncMock(
            return_value=None
        )

        # Mock _fetch_source_platform so the handler can resolve the platform
        self.handler._fetch_source_platform = AsyncMock(return_value="sqlserver")

        # Mock stage resolution
        mock_stage_resolution = MagicMock()
        mock_stage_resolution.is_external = False
        mock_stage_resolution.stage_id = default_internal_stage()
        mock_resolve_stage.return_value = mock_stage_resolution

        # Setup mocks
        mock_read_schema.return_value = [
            {"COLUMN_NAME": "ID", "DATA_TYPE": "int"},
            {"COLUMN_NAME": "NAME", "DATA_TYPE": "varchar"},
        ]

        mock_validator_instance = MagicMock()
        mock_validator_instance.validate_schema = AsyncMock(
            return_value=MagicMock(
                table_exists=True,
                has_drift=False,
                drifts=[],
            )
        )
        mock_validator_instance.get_columns_for_copy_into = MagicMock(
            return_value=[("ID", "NUMBER"), ("NAME", "VARCHAR")]
        )
        mock_schema_validator.return_value = mock_validator_instance

        # Mock file type detection and schema inference
        self.handler._detect_stage_file_type = AsyncMock(return_value=FileType.PARQUET)
        self.handler._infer_file_schema = AsyncMock(
            return_value={"ID": "NUMBER", "NAME": "TEXT"}
        )

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=123,
            partition_index=1,
            target_table="DB.SCHEMA.TABLE",
        )

        task = Task(
            id=1,
            workflow_id=100,
            task_name="Process staged data",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[1]::Loading",
        )

        await self.handler.handle(task)

        # Verify push_task was called for the successor task
        # The implementation passes a Task object as a positional argument
        push_task_calls = [
            call
            for call in self.mock_task_queue.push_task.call_args_list
            if call.args
            and hasattr(call.args[0], "payload")
            and isinstance(call.args[0].payload, CompletePartitionMigrationTaskPayload)
        ]

        self.assertEqual(len(push_task_calls), 1)
        successor_task = push_task_calls[0].args[0]
        self.assertEqual(successor_task.payload.partition_metadata_id, 123)

    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.resolve_stage_for_strategy"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.read_schema_from_stage"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.SchemaValidator"
    )
    async def test_no_successor_task_when_partition_metadata_id_is_none(
        self, mock_schema_validator, mock_read_schema, mock_resolve_stage
    ):
        """Test that no successor task is created when partition_metadata_id is None."""
        # Setup mocks for table config and workflow config services
        mock_table_config = MagicMock()
        mock_table_config.extraction_strategy = MagicMock()
        mock_table_config.extraction_strategy.value = "regular"
        mock_table_config.column_type_mappings = None
        mock_table_config.column_name_mappings = None
        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=mock_table_config)
        )
        self.handler.workflow_config_service.fetch_strategy_config = AsyncMock(
            return_value={}
        )
        self.handler.workflow_config_service.fetch_workflow_external_stage = AsyncMock(
            return_value=None
        )

        # Mock _fetch_source_platform so the handler can resolve the platform
        self.handler._fetch_source_platform = AsyncMock(return_value="sqlserver")

        # Mock stage resolution
        mock_stage_resolution = MagicMock()
        mock_stage_resolution.is_external = False
        mock_stage_resolution.stage_id = default_internal_stage()
        mock_resolve_stage.return_value = mock_stage_resolution

        # Setup mocks
        mock_read_schema.return_value = [
            {"COLUMN_NAME": "ID", "DATA_TYPE": "int"},
        ]

        mock_validator_instance = MagicMock()
        mock_validator_instance.validate_schema = AsyncMock(
            return_value=MagicMock(
                table_exists=True,
                has_drift=False,
                drifts=[],
            )
        )
        mock_validator_instance.get_columns_for_copy_into = MagicMock(
            return_value=[("ID", "NUMBER")]
        )
        mock_schema_validator.return_value = mock_validator_instance

        # Mock file type detection and schema inference
        self.handler._detect_stage_file_type = AsyncMock(return_value=FileType.PARQUET)
        self.handler._infer_file_schema = AsyncMock(return_value={"ID": "NUMBER"})

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=0,
            partition_index=0,
            target_table="DB.SCHEMA.TABLE",
        )

        task = Task(
            id=1,
            workflow_id=100,
            task_name="Process staged data",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[0]::Loading",
        )

        await self.handler.handle(task)

        # Verify CompletePartitionMigrationTaskPayload was still pushed
        # (partition_metadata_id is now always required, so successor task is always created)
        push_task_calls = [
            call
            for call in self.mock_task_queue.push_task.call_args_list
            if call.args
            and hasattr(call.args[0], "payload")
            and isinstance(call.args[0].payload, CompletePartitionMigrationTaskPayload)
        ]

        # With the new API, partition_metadata_id is always required,
        # so a successor task is always created
        self.assertEqual(len(push_task_calls), 1)


class TestEmptyExtractionHandling(unittest.IsolatedAsyncioTestCase):
    """Test that StagedDataHandler handles empty extractions (0 rows) gracefully."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=999)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.resolve_stage_for_strategy"
    )
    async def test_empty_extraction_marks_partition_completed(self, mock_resolve_stage):
        """When no staged files are found, partition should be marked COMPLETED."""
        mock_table_config = MagicMock()
        mock_table_config.extraction_strategy = MagicMock()
        mock_table_config.extraction_strategy.value = "regular"
        mock_table_config.extraction = MagicMock()
        mock_table_config.extraction.external_stage = None
        mock_table_config.iceberg_config = None
        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=mock_table_config)
        )
        self.handler.workflow_config_service.fetch_strategy_config = AsyncMock(
            return_value={}
        )
        self.handler.workflow_config_service.fetch_workflow_external_stage = AsyncMock(
            return_value=None
        )

        mock_stage_resolution = MagicMock()
        mock_stage_resolution.is_external = False
        mock_stage_resolution.stage_id = default_internal_stage()
        mock_resolve_stage.return_value = mock_stage_resolution

        # Mock _fetch_source_platform so the handler can resolve the platform
        self.handler._fetch_source_platform = AsyncMock(return_value="sqlserver")

        # Simulate _detect_stage_file_type raising ValueError (no files found)
        self.handler._detect_stage_file_type = AsyncMock(
            side_effect=ValueError("No files found at @stage/path/")
        )

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=42,
            partition_index=0,
            target_table="DB.SCHEMA.TABLE",
        )

        task = Task(
            id=1,
            workflow_id=100,
            task_name="Process staged data",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[DB.SCHEMA.TABLE]::Partition[0]::Loading",
        )

        await self.handler.handle(task)

        # Partition status should be updated to COMPLETED
        status_update_calls = [
            call
            for call in self.mock_warehouse_proxy.execute_sync_query.call_args_list
            if "MIGRATION_STATUS = 'COMPLETED'" in str(call)
            and "WHERE ID = 42" in str(call)
        ]
        self.assertEqual(len(status_update_calls), 1)

        # Task should be completed
        self.mock_task_queue.complete_task.assert_called_once_with(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=1,
        )

        # No COPY INTO or successor tasks should be created
        self.mock_task_queue.push_task.assert_not_called()
        self.mock_warehouse_proxy.execute_snowflake_query_and_push_task = AsyncMock()
        self.mock_warehouse_proxy.execute_snowflake_query_and_push_task.assert_not_called()


class TestCopyIntoUsesTargetTableName(unittest.IsolatedAsyncioTestCase):
    """Test that COPY INTO targets the target table, not the source table."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=999)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])
        self.mock_warehouse_proxy.execute_snowflake_query_and_push_task = AsyncMock(
            return_value=None
        )

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.resolve_stage_for_strategy"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.read_schema_from_stage"
    )
    @patch(
        "data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler.SchemaValidator"
    )
    async def test_copy_into_uses_target_table_not_source(
        self, mock_schema_validator, mock_read_schema, mock_resolve_stage
    ):
        """When source and target table names differ, COPY INTO must target the target table."""
        from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
            TableIdentifier,
            TableConfiguration,
        )

        source_id = TableIdentifier(
            database_name="SRC_DB", schema_name="SRC_SCHEMA", table_name="SRC_TABLE"
        )
        target_id = TableIdentifier(
            database_name="TGT_DB", schema_name="TGT_SCHEMA", table_name="TGT_TABLE"
        )
        table_config = TableConfiguration(source=source_id, target=target_id)

        self.handler.table_config_service.fetch_required_table_configuration = (
            AsyncMock(return_value=table_config)
        )
        self.handler.workflow_config_service.fetch_strategy_config = AsyncMock(
            return_value={}
        )
        self.handler.workflow_config_service.fetch_workflow_external_stage = AsyncMock(
            return_value=None
        )
        self.handler._fetch_source_platform = AsyncMock(return_value="sqlserver")

        mock_stage_resolution = MagicMock()
        mock_stage_resolution.is_external = False
        mock_stage_resolution.stage_id = default_internal_stage()
        mock_resolve_stage.return_value = mock_stage_resolution

        mock_read_schema.return_value = [
            {"COLUMN_NAME": "ID", "DATA_TYPE": "int"},
            {"COLUMN_NAME": "NAME", "DATA_TYPE": "varchar"},
        ]

        mock_validator_instance = MagicMock()
        mock_validator_instance.validate_schema = AsyncMock(
            return_value=MagicMock(
                table_exists=True,
                has_drift=False,
                drifts=[],
                actual_schema=None,
            )
        )
        mock_validator_instance.get_columns_for_copy_into = MagicMock(
            return_value=[("ID", "int"), ("NAME", "varchar")]
        )
        mock_schema_validator.return_value = mock_validator_instance

        self.handler._detect_stage_file_type = AsyncMock(return_value=FileType.PARQUET)
        self.handler._infer_file_schema = AsyncMock(
            return_value={"ID": "NUMBER", "NAME": "TEXT"}
        )

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=123,
            partition_index=1,
            target_table="TGT_DB.TGT_SCHEMA.TGT_TABLE",
        )

        task = Task(
            id=1,
            workflow_id=100,
            task_name="Process staged data",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            priority=1.0,
            payload=payload,
            scope="Table[TGT_DB.TGT_SCHEMA.TGT_TABLE]::Partition[1]::Loading",
        )

        await self.handler.handle(task)

        # Verify the COPY INTO SQL was executed against the TARGET table
        copy_into_call = self.mock_warehouse_proxy.execute_snowflake_query_and_push_task
        copy_into_call.assert_called_once()
        copy_into_sql = copy_into_call.call_args[1].get(
            "query",
            (
                copy_into_call.call_args[0][1]
                if len(copy_into_call.call_args[0]) > 1
                else None
            ),
        )
        self.assertIn("TGT_DB.TGT_SCHEMA.TGT_TABLE", copy_into_sql)
        self.assertNotIn("SRC_DB", copy_into_sql)
        self.assertNotIn("SRC_SCHEMA", copy_into_sql)
        self.assertNotIn("SRC_TABLE", copy_into_sql)

        # Verify schema validation was called with target identifiers
        mock_validator_instance.validate_schema.assert_called_once()
        validate_kwargs = mock_validator_instance.validate_schema.call_args
        self.assertEqual(validate_kwargs[1]["database_name"], "TGT_DB")
        self.assertEqual(validate_kwargs[1]["schema_name"], "TGT_SCHEMA")
        self.assertEqual(validate_kwargs[1]["table_name"], "TGT_TABLE")


class TestProcessStagedDataTaskPayloadPartitionMetadataId(unittest.TestCase):
    """Test cases for ProcessStagedDataTaskPayload with partition_metadata_id."""

    def test_payload_with_partition_metadata_id(self):
        """Test creating payload with partition_metadata_id."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=42,
            partition_index=1,
            target_table="DB.SCHEMA.TABLE",
        )

        self.assertEqual(payload.partition_metadata_id, 42)
        self.assertEqual(payload.kind, TaskPayloadKind.PROCESS_STAGED_DATA)

    def test_payload_with_all_fields(self):
        """Test creating payload with all fields."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=789,
            partition_index=5,
            target_table="DB.SCHEMA.TABLE",
        )

        self.assertEqual(payload.table_metadata_id, 100)
        self.assertEqual(payload.partition_metadata_id, 789)
        self.assertEqual(payload.partition_index, 5)
        self.assertEqual(payload.target_table, "DB.SCHEMA.TABLE")
        self.assertEqual(payload.kind, TaskPayloadKind.PROCESS_STAGED_DATA)


class TestIdempotencyGuard(unittest.IsolatedAsyncioTestCase):
    """Tests for SNOW-3380238: idempotency guard against duplicate COPY INTO."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=1)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse_proxy = MagicMock()
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(return_value=[])

        self.handler = StagedDataHandler(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
        )

    def _make_task(self, task_id=1, scope="Table[DB.S.T]::Partition[0]::Loading"):
        return Task(
            workflow_id=10,
            executor_type=ExecutorType.ORCHESTRATOR,
            task_name="Process staged data",
            payload=ProcessStagedDataTaskPayload(
                table_metadata_id=42,
                partition_index=0,
                partition_metadata_id=100,
                target_table="DB.S.T",
            ),
            scope=scope,
            id=task_id,
        )

    async def test_skips_when_copy_into_already_completed(self):
        """When a warehouse COPY INTO task already completed, skip re-execution."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=[
                # _find_existing_copy_into_task → found completed
                [{"ID": 999, "STATUS": "completed"}],
            ]
        )
        task = self._make_task()
        await self.handler.handle(task)

        # Should have completed the orchestrator task without further queries
        self.mock_task_queue.complete_task.assert_called_once_with(
            consumer_type=ExecutorType.ORCHESTRATOR, task_id=1
        )

    async def test_raises_when_copy_into_still_executing(self):
        """When a warehouse COPY INTO is in-flight, raise to defer retry."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=[
                # _find_existing_copy_into_task → found executing
                [{"ID": 999, "STATUS": "executing"}],
            ]
        )
        task = self._make_task()
        with self.assertRaises(RuntimeError) as ctx:
            await self.handler.handle(task)
        self.assertIn("already in-flight", str(ctx.exception))
        # Should NOT have completed the task
        self.mock_task_queue.complete_task.assert_not_called()

    async def test_skips_when_partition_already_completed(self):
        """When partition status is COMPLETED, skip re-execution."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=[
                # _find_existing_copy_into_task → nothing found
                [],
                # _get_partition_status → COMPLETED
                [{"MIGRATION_STATUS": str(PartitionMigrationStatus.COMPLETED)}],
            ]
        )
        task = self._make_task()
        await self.handler.handle(task)

        self.mock_task_queue.complete_task.assert_called_once_with(
            consumer_type=ExecutorType.ORCHESTRATOR, task_id=1
        )

    async def test_proceeds_when_no_existing_copy_into_and_not_completed(self):
        """Normal path: no existing COPY INTO, partition not COMPLETED → proceeds."""
        self.mock_warehouse_proxy.execute_sync_query = AsyncMock(
            side_effect=[
                # _find_existing_copy_into_task → nothing
                [],
                # _get_partition_status → EXTRACTING
                [{"MIGRATION_STATUS": str(PartitionMigrationStatus.EXTRACTING)}],
                # _update_partition_status → ok
                [],
                # _fetch_source_platform → needed by handle()
                # This will fail with a ValueError because we didn't mock the
                # full pipeline, but that confirms we passed the guard.
            ]
        )
        task = self._make_task()
        # The handler will proceed past the guard and fail on _fetch_source_platform
        # because the workflow doesn't exist. That's expected — we're testing the guard.
        with self.assertRaises((ValueError, Exception)):
            await self.handler.handle(task)

        # Should have called _update_partition_status (3rd query)
        calls = self.mock_warehouse_proxy.execute_sync_query.call_args_list
        self.assertGreaterEqual(len(calls), 3)
        status_update_sql = calls[2][0][0]
        self.assertIn("LOADING", status_update_sql)


if __name__ == "__main__":
    unittest.main()
