"""
Tests for the migration TABLE_PROGRESS view templates.

Verifies that the TABLE_PROGRESS and TABLE_PROGRESS_WITH_EXAMPLE_ERROR
templates render valid SQL that surfaces TOTAL_ROWS via SUM(P.N_ROWS). This is
the metric required by the table-centric dashboard (SNOW-3388960).
"""

from __future__ import annotations

from pathlib import Path

from data_migration_orchestrator.utils.templated_sql import render_sql_jinja_template


_ASSETS_DIR = (
    Path(__file__).resolve().parent.parent
    / "src"
    / "data_migration_orchestrator"
    / "assets"
)
_TEMPLATE_CONTEXT = {
    "metadata_database": "TEST_DB",
    "migration_schema": "DATA_MIGRATION",
    "qualified_migration": "TEST_DB.DATA_MIGRATION",
}


def _render(relative: str) -> str:
    path = _ASSETS_DIR / relative
    source = path.read_text(encoding="utf-8")
    return render_sql_jinja_template(source, _TEMPLATE_CONTEXT)


class TestTableProgressView:
    """The base TABLE_PROGRESS view must expose TOTAL_ROWS."""

    def test_table_progress_includes_total_rows_column(self):
        sql = _render("scripts/table-metadata/views/table_progress.sql.j2")
        assert "TOTAL_ROWS" in sql

    def test_table_progress_uses_sum_of_partition_n_rows(self):
        sql = _render("scripts/table-metadata/views/table_progress.sql.j2")
        # The view aggregates partition rows; the SUM is the metric source.
        # Intentionally no COALESCE — NULL must propagate to the dashboard so
        # "unknown row count" can be distinguished from "genuinely zero rows".
        assert "SUM(P.N_ROWS)" in sql
        assert "SUM(P.N_ROWS) AS TOTAL_ROWS" in sql

    def test_table_progress_still_exposes_existing_columns(self):
        sql = _render("scripts/table-metadata/views/table_progress.sql.j2")
        for column in (
            "TABLE_ID",
            "WORKFLOW_ID",
            "TABLE_NAME",
            "TOTAL_PARTITIONS",
            "LOADED_PARTITIONS",
            "FAILED_PARTITIONS",
            "PARTITIONS_IN_EXTRACTION_PHASE",
            "PARTITIONS_IN_LOADING_PHASE",
        ):
            assert column in sql, f"missing {column} in rendered TABLE_PROGRESS"


class TestTableProgressWithExampleErrorView:
    """The derived view must pass TOTAL_ROWS through."""

    def test_derived_view_passes_total_rows_through(self):
        sql = _render(
            "scripts/table-metadata/views/table_progress_with_example_error.sql.j2"
        )
        assert "TP.TOTAL_ROWS" in sql

    def test_derived_view_groups_by_total_rows(self):
        sql = _render(
            "scripts/table-metadata/views/table_progress_with_example_error.sql.j2"
        )
        # GROUP BY must include TOTAL_ROWS or the non-aggregated column would
        # break compilation; assert the grouping clause contains it.
        group_by = sql[sql.upper().index("GROUP BY") :]
        assert "TP.TOTAL_ROWS" in group_by
