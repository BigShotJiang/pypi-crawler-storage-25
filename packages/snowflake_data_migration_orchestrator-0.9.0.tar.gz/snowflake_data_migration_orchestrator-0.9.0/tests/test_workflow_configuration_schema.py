"""Unit tests for workflow configuration schema validation."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
)
from data_migration_orchestrator.data_migration_cloud.config.workflow_configuration_schema import (
    VersionNumber,
    WorkflowConfigurationSchema,
    validate_workflow_configuration,
)


def _minimal_table_config() -> dict:
    return {
        "source": {
            "databaseName": "source_db",
            "schemaName": "dbo",
            "tableName": "customers",
        },
        "target": {
            "databaseName": "target_db",
            "schemaName": "public",
            "tableName": "customers",
        },
        "columnNamesToPartitionBy": ["id"],
    }


class TestValidateWorkflowConfiguration:
    """Tests for the standalone validate_workflow_configuration function."""

    def test_valid_minimal_configuration(self):
        config = {"tables": [_minimal_table_config()]}

        result = validate_workflow_configuration(config)

        assert isinstance(result, WorkflowConfigurationSchema)
        assert len(result.tables) == 1

    def test_valid_with_affinity(self):
        config = {
            "tables": [_minimal_table_config()],
            "affinity": "blue",
        }

        result = validate_workflow_configuration(config)

        assert result.affinity == "blue"

    def test_valid_without_affinity(self):
        config = {"tables": [_minimal_table_config()]}

        result = validate_workflow_configuration(config)

        assert result.affinity is None

    def test_valid_multiple_tables(self):
        table1 = _minimal_table_config()
        table2 = _minimal_table_config()
        table2["source"]["tableName"] = "orders"
        config = {"tables": [table1, table2]}

        result = validate_workflow_configuration(config)

        assert len(result.tables) == 2

    def test_valid_with_default_table_configuration(self):
        config = {
            "defaultTableConfiguration": {
                "source": {"databaseName": "shared_db", "schemaName": "dbo"},
                "target": {"databaseName": "target_db", "schemaName": "public"},
            },
            "tables": [
                {
                    "source": {"tableName": "customers"},
                    "target": {"tableName": "customers"},
                    "columnNamesToPartitionBy": ["id"],
                },
            ],
        }

        result = validate_workflow_configuration(config)

        assert result.default_table_configuration is not None
        assert result.default_table_configuration.source is not None
        assert result.default_table_configuration.source.database_name == "shared_db"

    def test_valid_full_configuration(self):
        config = {
            "defaultTableConfiguration": {
                "extraction": {"strategy": "unload", "externalStage": "@MY_STAGE"},
            },
            "tables": [
                {
                    "source": {
                        "databaseName": "src",
                        "schemaName": "dbo",
                        "tableName": "orders",
                    },
                    "target": {
                        "databaseName": "tgt",
                        "schemaName": "public",
                        "tableName": "orders",
                    },
                    "columnNamesToPartitionBy": ["order_id"],
                    "columnTypeMappings": [
                        {"sourceType": "MONEY", "targetType": "DECIMAL(19,4)"},
                    ],
                    "columnNameMappings": [
                        {"sourceName": "id", "targetName": "old_id"},
                    ],
                    "primaryKeyColumns": ["order_id"],
                    "synchronization": {
                        "strategy": "watermark",
                        "watermarkColumn": "updated_at",
                        "trackModifications": True,
                    },
                    "extraction": {"strategy": "regular"},
                    "whereClauseCriteria": "is_deleted = 0",
                },
            ],
        }

        result = validate_workflow_configuration(config)

        table = result.tables[0]
        assert table.synchronization is not None
        assert table.synchronization.strategy == "watermark"
        assert table.where_clause_criteria == "is_deleted = 0"

    def test_returns_validated_model(self):
        config = {"tables": [_minimal_table_config()]}

        result = validate_workflow_configuration(config)

        assert isinstance(result, WorkflowConfigurationSchema)
        assert result.tables[0].source is not None
        assert result.tables[0].source.table_name == "customers"


class TestValidateWorkflowConfigurationErrors:
    """Tests for invalid configurations that should raise ConfigurationError."""

    def test_none_configuration_raises_error(self):
        with pytest.raises(ConfigurationError, match="must not be None"):
            validate_workflow_configuration(None)

    def test_missing_tables_key_raises_error(self):
        with pytest.raises(ConfigurationError, match="tables"):
            validate_workflow_configuration({})

    def test_empty_tables_list_raises_error(self):
        with pytest.raises(ConfigurationError, match="at least one"):
            validate_workflow_configuration({"tables": []})

    def test_tables_wrong_type_string_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": "not_a_list"})

    def test_tables_wrong_type_int_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": 42})

    def test_default_table_configuration_wrong_type_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration(
                {
                    "tables": [_minimal_table_config()],
                    "defaultTableConfiguration": "not_a_dict",
                }
            )

    def test_unknown_top_level_key_raises_error(self):
        with pytest.raises(ConfigurationError, match="extra_field"):
            validate_workflow_configuration(
                {
                    "tables": [_minimal_table_config()],
                    "extra_field": "should_fail",
                }
            )

    def test_unknown_key_in_table_raises_error(self):
        table = _minimal_table_config()
        table["unknownProperty"] = "bad"

        with pytest.raises(ConfigurationError, match="unknownProperty"):
            validate_workflow_configuration({"tables": [table]})

    def test_unknown_key_in_source_raises_error(self):
        table = _minimal_table_config()
        table["source"]["extraField"] = "bad"

        with pytest.raises(ConfigurationError, match="extraField"):
            validate_workflow_configuration({"tables": [table]})

    def test_unknown_key_in_synchronization_raises_error(self):
        table = _minimal_table_config()
        table["synchronization"] = {"strategy": "none", "badKey": True}

        with pytest.raises(ConfigurationError, match="badKey"):
            validate_workflow_configuration({"tables": [table]})

    def test_unknown_key_in_extraction_raises_error(self):
        table = _minimal_table_config()
        table["extraction"] = {"strategy": "regular", "badKey": "x"}

        with pytest.raises(ConfigurationError, match="badKey"):
            validate_workflow_configuration({"tables": [table]})

    def test_partition_columns_wrong_type_string_raises_error(self):
        table = _minimal_table_config()
        table["columnNamesToPartitionBy"] = "not_a_list"

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_partition_columns_wrong_element_type_raises_error(self):
        table = _minimal_table_config()
        table["columnNamesToPartitionBy"] = [123]

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_column_type_mappings_wrong_type_raises_error(self):
        table = _minimal_table_config()
        table["columnTypeMappings"] = "not_a_list"

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_column_type_mapping_missing_field_raises_error(self):
        table = _minimal_table_config()
        table["columnTypeMappings"] = [{"sourceType": "BIT"}]

        with pytest.raises(ConfigurationError, match="targetType"):
            validate_workflow_configuration({"tables": [table]})

    def test_column_name_mapping_missing_field_raises_error(self):
        table = _minimal_table_config()
        table["columnNameMappings"] = [{"sourceName": "id"}]

        with pytest.raises(ConfigurationError, match="targetName"):
            validate_workflow_configuration({"tables": [table]})

    def test_primary_key_columns_wrong_type_raises_error(self):
        table = _minimal_table_config()
        table["primaryKeyColumns"] = "not_a_list"

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_where_clause_criteria_wrong_type_raises_error(self):
        table = _minimal_table_config()
        table["whereClauseCriteria"] = 42

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_track_modifications_wrong_type_raises_error(self):
        table = _minimal_table_config()
        table["synchronization"] = {
            "strategy": "watermark",
            "trackModifications": "not_a_bool",
        }

        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_table_entry_is_list_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [["not", "a", "dict"]]})

    def test_table_entry_is_string_raises_error(self):
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": ["not_a_dict"]})


class TestSchemaVersion:
    """Tests for the schemaVersion field on WorkflowConfigurationSchema."""

    def test_valid_without_schema_version(self):
        config = {"tables": [_minimal_table_config()]}

        result = validate_workflow_configuration(config)

        assert result.schema_version is None

    @pytest.mark.parametrize("version", ["1.0.0", "1", "1.2", "0.9.0", "1.99.99"])
    def test_valid_schema_versions(self, version: str):
        config = {
            "schemaVersion": version,
            "tables": [_minimal_table_config()],
        }

        result = validate_workflow_configuration(config)

        assert result.schema_version == version

    @pytest.mark.parametrize("version", ["abc", "1.2.3.4", "", "1.2.x", "v1.0", ".1.2"])
    def test_invalid_format_raises_error(self, version: str):
        config = {
            "schemaVersion": version,
            "tables": [_minimal_table_config()],
        }

        with pytest.raises(ConfigurationError, match="Invalid"):
            validate_workflow_configuration(config)

    @pytest.mark.parametrize("version", ["2.0.0", "2.1.0", "3", "10.0.0"])
    def test_unsupported_major_version_raises_error(self, version: str):
        config = {
            "schemaVersion": version,
            "tables": [_minimal_table_config()],
        }

        with pytest.raises(ConfigurationError, match="not supported"):
            validate_workflow_configuration(config)


class TestVersionNumber:
    """Unit tests for the VersionNumber dataclass."""

    def test_parse_major_only(self):
        v = VersionNumber.parse("1")
        assert (v.major, v.minor, v.patch) == (1, 0, 0)

    def test_parse_major_minor(self):
        v = VersionNumber.parse("1.2")
        assert (v.major, v.minor, v.patch) == (1, 2, 0)

    def test_parse_full(self):
        v = VersionNumber.parse("1.2.3")
        assert (v.major, v.minor, v.patch) == (1, 2, 3)

    def test_parse_zero_components(self):
        v = VersionNumber.parse("0.0.0")
        assert (v.major, v.minor, v.patch) == (0, 0, 0)

    @pytest.mark.parametrize("bad", ["", "abc", "1.2.3.4", "1.x", "v1", ".1"])
    def test_parse_invalid_raises_value_error(self, bad: str):
        with pytest.raises(ValueError, match="Invalid version format"):
            VersionNumber.parse(bad)

    def test_frozen(self):
        v = VersionNumber.parse("1.2.3")
        with pytest.raises(AttributeError):
            v.major = 99  # type: ignore[misc]


class TestWorkflowConfigurationSchemaDirectly:
    """Tests for the Pydantic model directly (not through the wrapper function)."""

    def test_model_validate_valid(self):
        config = {"tables": [_minimal_table_config()]}
        model = WorkflowConfigurationSchema.model_validate(config)
        assert len(model.tables) == 1

    def test_model_rejects_extra_fields(self):
        config = {
            "tables": [_minimal_table_config()],
            "extraField": "value",
        }
        with pytest.raises(ValueError, match="extraField"):
            WorkflowConfigurationSchema.model_validate(config)


class TestPartitionSizeFields:
    """Tests for targetPartitionSizeMb / targetPartitionSizeRows flat fields."""

    def test_omitting_both_defaults_to_none(self):
        table = _minimal_table_config()
        config = {"tables": [table]}
        result = validate_workflow_configuration(config)
        assert result.tables[0].target_partition_size_mb is None
        assert result.tables[0].target_partition_size_rows is None

    def test_valid_target_partition_size_mb(self):
        table = _minimal_table_config()
        table["targetPartitionSizeMb"] = 2048
        config = {"tables": [table]}
        result = validate_workflow_configuration(config)
        assert result.tables[0].target_partition_size_mb == 2048
        assert result.tables[0].target_partition_size_rows is None

    def test_valid_target_partition_size_rows(self):
        table = _minimal_table_config()
        table["targetPartitionSizeRows"] = 500000
        config = {"tables": [table]}
        result = validate_workflow_configuration(config)
        assert result.tables[0].target_partition_size_rows == 500000
        assert result.tables[0].target_partition_size_mb is None

    def test_both_fields_raises_error(self):
        table = _minimal_table_config()
        table["targetPartitionSizeMb"] = 1024
        table["targetPartitionSizeRows"] = 10000
        with pytest.raises(ConfigurationError, match="Only one"):
            validate_workflow_configuration({"tables": [table]})

    @pytest.mark.parametrize(
        "field,value",
        [
            ("targetPartitionSizeMb", 0),
            ("targetPartitionSizeRows", -1),
        ],
        ids=["zero_target_mb", "negative_target_rows"],
    )
    def test_non_positive_value_raises_error(self, field, value):
        table = _minimal_table_config()
        table[field] = value
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_valid_in_default_table_configuration(self):
        config = {
            "defaultTableConfiguration": {
                "source": {"databaseName": "db", "schemaName": "dbo"},
                "target": {"databaseName": "tgt", "schemaName": "public"},
                "targetPartitionSizeMb": 4096,
            },
            "tables": [
                {
                    "source": {"tableName": "t"},
                    "target": {"tableName": "t"},
                    "columnNamesToPartitionBy": ["id"],
                },
            ],
        }
        result = validate_workflow_configuration(config)
        assert result.default_table_configuration is not None
        assert result.default_table_configuration.target_partition_size_mb == 4096


class TestIcebergTargetSchema:
    """Tests for Iceberg table type and icebergConfig in target endpoints."""

    def test_valid_iceberg_target_in_default_config(self):
        config = {
            "defaultTableConfiguration": {
                "source": {"databaseName": "src_db", "schemaName": "public"},
                "target": {
                    "databaseName": "tgt_db",
                    "schemaName": "public",
                    "tableType": "iceberg",
                    "icebergConfig": {
                        "catalog": "SNOWFLAKE",
                        "externalVolume": "my_ext_vol",
                        "baseLocationPrefix": "migrations/redshift",
                    },
                },
                "extraction": {
                    "strategy": "unload",
                    "externalStage": "TGT_DB.PUBLIC.S3_STAGE",
                },
            },
            "tables": [
                {
                    "source": {"tableName": "customers"},
                    "target": {"tableName": "customers"},
                    "columnNamesToPartitionBy": ["customer_id"],
                },
            ],
        }

        result = validate_workflow_configuration(config)

        target = result.default_table_configuration.target
        assert target.table_type == "iceberg"
        assert target.iceberg_config is not None
        assert target.iceberg_config.catalog == "SNOWFLAKE"
        assert target.iceberg_config.external_volume == "my_ext_vol"
        assert target.iceberg_config.base_location_prefix == "migrations/redshift"

    def test_valid_iceberg_target_per_table(self):
        table = _minimal_table_config()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "SNOWFLAKE",
            "externalVolume": "vol1",
        }
        config = {"tables": [table]}

        result = validate_workflow_configuration(config)

        target = result.tables[0].target
        assert target.table_type == "iceberg"
        assert target.iceberg_config.external_volume == "vol1"

    def test_valid_iceberg_with_catalog_sync(self):
        table = _minimal_table_config()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "SNOWFLAKE",
            "externalVolume": "vol1",
            "baseLocationPrefix": "data/tables",
            "catalogSync": "glue_catalog_integration",
        }
        config = {"tables": [table]}

        result = validate_workflow_configuration(config)

        iceberg = result.tables[0].target.iceberg_config
        assert iceberg.catalog_sync == "glue_catalog_integration"

    def test_valid_iceberg_with_external_catalog(self):
        table = _minimal_table_config()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "my_glue_integration",
            "externalVolume": "glue_ext_vol",
            "catalogTableName": "glue_table",
        }
        config = {"tables": [table]}

        result = validate_workflow_configuration(config)

        iceberg = result.tables[0].target.iceberg_config
        assert iceberg.catalog == "my_glue_integration"
        assert iceberg.catalog_table_name == "glue_table"

    def test_valid_native_table_type(self):
        table = _minimal_table_config()
        table["target"]["tableType"] = "native"
        config = {"tables": [table]}

        result = validate_workflow_configuration(config)

        assert result.tables[0].target.table_type == "native"
        assert result.tables[0].target.iceberg_config is None

    def test_valid_target_without_table_type_defaults_to_native(self):
        config = {"tables": [_minimal_table_config()]}

        result = validate_workflow_configuration(config)

        assert result.tables[0].target.table_type == "native"
        assert result.tables[0].target.iceberg_config is None

    def test_valid_target_with_null_table_type_defaults_to_native(self):
        table = _minimal_table_config()
        table["target"]["tableType"] = None
        config = {"tables": [table]}

        result = validate_workflow_configuration(config)

        assert result.tables[0].target.table_type == "native"
        assert result.tables[0].target.iceberg_config is None

    def test_invalid_table_type_raises_error(self):
        table = _minimal_table_config()
        table["target"]["tableType"] = "parquet"

        with pytest.raises(ConfigurationError, match="tableType"):
            validate_workflow_configuration({"tables": [table]})

    def test_unknown_key_in_iceberg_config_raises_error(self):
        table = _minimal_table_config()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "SNOWFLAKE",
            "unknownField": "bad",
        }

        with pytest.raises(ConfigurationError, match="unknownField"):
            validate_workflow_configuration({"tables": [table]})

    def test_source_rejects_table_type(self):
        """Source endpoints should NOT accept tableType (uses base schema)."""
        table = _minimal_table_config()
        table["source"]["tableType"] = "iceberg"

        with pytest.raises(ConfigurationError, match="tableType"):
            validate_workflow_configuration({"tables": [table]})

    def test_full_iceberg_workflow_example(self):
        """Validates the documented example from example-workflow-config-redshift-iceberg.json."""
        config = {
            "defaultTableConfiguration": {
                "source": {
                    "schemaName": "public",
                    "databaseName": "analytics_db",
                },
                "target": {
                    "schemaName": "public",
                    "databaseName": "TARGET_DB",
                    "tableType": "iceberg",
                    "icebergConfig": {
                        "catalog": "SNOWFLAKE",
                        "externalVolume": "my_iceberg_ext_vol",
                        "baseLocationPrefix": "migrations/redshift",
                    },
                },
                "extraction": {
                    "strategy": "unload",
                    "externalStage": "TARGET_DB.PUBLIC.S3_EXTERNAL_STAGE",
                },
            },
            "tables": [
                {
                    "source": {"tableName": "customers"},
                    "target": {"tableName": "customers"},
                    "columnNamesToPartitionBy": ["customer_id"],
                },
                {
                    "source": {"tableName": "events"},
                    "target": {
                        "tableName": "events",
                        "tableType": "iceberg",
                        "icebergConfig": {
                            "catalog": "SNOWFLAKE",
                            "externalVolume": "my_iceberg_ext_vol",
                            "baseLocationPrefix": "migrations/redshift",
                            "catalogSync": "glue_catalog_integration",
                        },
                    },
                    "columnNamesToPartitionBy": ["event_id"],
                },
            ],
        }

        result = validate_workflow_configuration(config)

        assert len(result.tables) == 2
        assert result.default_table_configuration.target.table_type == "iceberg"
        events_target = result.tables[1].target
        assert events_target.iceberg_config.catalog_sync == "glue_catalog_integration"


class TestLoadSegmentationSchema:
    """Tests for loadSegmentation structural validation."""

    def test_valid_load_segmentation(self):
        table = _minimal_table_config()
        table["loadSegmentation"] = {"targetSegmentSizeMb": 5000}
        result = validate_workflow_configuration({"tables": [table]})
        assert result.tables[0].load_segmentation is not None
        assert result.tables[0].load_segmentation.target_segment_size_mb == 5000

    def test_load_segmentation_absent(self):
        result = validate_workflow_configuration({"tables": [_minimal_table_config()]})
        assert result.tables[0].load_segmentation is None

    def test_load_segmentation_zero_rejected(self):
        table = _minimal_table_config()
        table["loadSegmentation"] = {"targetSegmentSizeMb": 0}
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_load_segmentation_negative_rejected(self):
        table = _minimal_table_config()
        table["loadSegmentation"] = {"targetSegmentSizeMb": -1}
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})

    def test_load_segmentation_extra_field_rejected(self):
        table = _minimal_table_config()
        table["loadSegmentation"] = {
            "targetSegmentSizeMb": 5000,
            "unknown": True,
        }
        with pytest.raises(ConfigurationError):
            validate_workflow_configuration({"tables": [table]})


# TODO: Use constants for the keys (also in other tests)
