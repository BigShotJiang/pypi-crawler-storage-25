"""
Tests for CreatePartitionTasksHandler.

This module tests the CreatePartitionTasksHandler class.
"""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.data_migration_cloud.tasks.handlers.create_partition_tasks_handler import (
    CreatePartitionTasksHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_progress_service import (
    WorkflowProgressService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)


class TestCreatePartitionTasksHandler(unittest.TestCase):
    """Test cases for CreatePartitionTasksHandler."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.push_task = AsyncMock(return_value=1)
        self.mock_task_queue.complete_task = AsyncMock(return_value=True)

        self.mock_warehouse = MagicMock()
        self.mock_warehouse.execute_sync_query = AsyncMock(return_value=[])

        self.handler = CreatePartitionTasksHandler(
            task_queue=self.mock_task_queue,
            warehouse=self.mock_warehouse,
        )

    def test_handler_initialization(self):
        """Test handler initializes with correct task type."""
        self.assertEqual(self.handler.task_type, TaskPayloadKind.CREATE_PARTITION_TASKS)

    def test_handler_has_progress_service(self):
        """Test handler initializes with a progress service."""
        self.assertIsInstance(self.handler.progress_service, WorkflowProgressService)

    def test_handler_has_boundary_generator(self):
        """Test handler initializes with a boundary generator."""
        self.assertIsNotNone(self.handler.boundary_generator)


if __name__ == "__main__":
    unittest.main()
