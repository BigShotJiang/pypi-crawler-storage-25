"""Tests for TableNotFoundError exception."""

import pytest

from data_migration_orchestrator.data_migration_cloud.exceptions.table_not_found_error import (
    TableNotFoundError,
)
from shared.enums.source_type import SourceType


class TestTableNotFoundError:
    """Test cases for TableNotFoundError exception."""

    def test_error_with_full_context(self):
        """Test error message with all context provided."""
        error = TableNotFoundError(
            table_name="users",
            database="my_database",
            schema="dbo",
            source_type=SourceType.SQLSERVER,
            detail="Additional detail here",
        )

        assert "my_database.dbo.users" in str(error)
        assert "does not exist in the source database" in str(error)
        assert "source type: sqlserver" in str(error)
        assert "Additional detail here" in str(error)
        assert error.table_name == "users"
        assert error.database == "my_database"
        assert error.schema == "dbo"
        assert error.source_type == SourceType.SQLSERVER
        assert error.detail == "Additional detail here"

    def test_error_with_table_name_database_schema(self):
        """Test error message with table, database and schema."""
        error = TableNotFoundError(
            table_name="orders",
            database="test_db",
            schema="dbo",
        )

        # Without source_type, the friendly name uses dot-separated format
        assert "test_db.dbo.orders" in str(error)
        assert "does not exist in the source database" in str(error)
        assert "Please verify" in str(error)
        assert error.table_name == "orders"
        assert error.database == "test_db"
        assert error.schema == "dbo"

    def test_error_with_empty_database(self):
        """Test error message with empty database."""
        error = TableNotFoundError(
            table_name="products",
            database="",
            schema="dbo",
        )

        assert "products" in str(error).lower()
        assert "does not exist in the source database" in str(error)

    def test_error_with_empty_schema(self):
        """Test error message with empty schema."""
        error = TableNotFoundError(
            table_name="items",
            database="inventory_db",
            schema="",
        )

        assert "items" in str(error).lower()
        assert "does not exist in the source database" in str(error)

    def test_error_with_source_type(self):
        """Test error message with source type."""
        error = TableNotFoundError(
            table_name="users",
            database="mydb",
            schema="public",
            source_type=SourceType.REDSHIFT,
        )

        assert "source type: redshift" in str(error)
        assert "does not exist" in str(error)

    def test_error_is_exception(self):
        """Test that TableNotFoundError is an Exception."""
        error = TableNotFoundError(
            table_name="test",
            database="db",
            schema="schema",
        )
        assert isinstance(error, Exception)

    def test_error_can_be_raised_and_caught(self):
        """Test that the error can be raised and caught."""
        with pytest.raises(TableNotFoundError) as exc_info:
            raise TableNotFoundError(
                table_name="missing_table",
                database="test_db",
                schema="test_schema",
                source_type=SourceType.SQLSERVER,
            )

        error = exc_info.value
        assert error.table_name == "missing_table"
        assert "test_db.test_schema.missing_table" in str(error)

    def test_error_with_detail_appended(self):
        """Test that detail is properly appended to message."""
        error = TableNotFoundError(
            table_name="test",
            database="db",
            schema="schema",
            detail="Metadata extraction returned no results",
        )

        message = str(error)
        assert (
            message.endswith("Detail: Metadata extraction returned no results")
            or "Detail: Metadata extraction returned no results" in message
        )

    def test_error_preserves_cause_when_chained(self):
        """Test that the error preserves the cause when chained."""
        original_error = ValueError("No metadata found")

        try:
            try:
                raise original_error
            except ValueError as e:
                raise TableNotFoundError(
                    table_name="test",
                    database="db",
                    schema="schema",
                    detail="Chained from ValueError",
                ) from e
        except TableNotFoundError as caught:
            assert caught.__cause__ is original_error
