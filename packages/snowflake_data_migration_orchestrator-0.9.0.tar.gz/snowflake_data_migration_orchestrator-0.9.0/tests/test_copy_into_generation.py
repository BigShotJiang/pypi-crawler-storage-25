"""Tests for COPY INTO generation with FILES parameter support."""

import pytest

from shared.enums.file_type import FileType
from shared.enums.source_type import SourceType

from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
    TypeMappingLoader,
)


@pytest.fixture
def loader():
    """Return a TypeMappingLoader configured for SQL Server."""
    return TypeMappingLoader(source_type=SourceType.SQLSERVER)


SIMPLE_COLUMNS = [("id", "INT"), ("name", "NVARCHAR")]


class TestFilesParameter:
    """Tests for FILES parameter in COPY INTO."""

    def test_no_files_uses_pattern(self, loader):
        sql = loader.generate_copy_into_statement(
            target_table="MY_DB.MY_SCHEMA.MY_TABLE",
            columns=SIMPLE_COLUMNS,
            stage_location="@MY_STAGE/path/",
            file_type=FileType.PARQUET,
        )
        assert "PATTERN =>" in sql
        assert "FILES" not in sql

    def test_files_parameter_replaces_pattern(self, loader):
        sql = loader.generate_copy_into_statement(
            target_table="MY_DB.MY_SCHEMA.MY_TABLE",
            columns=SIMPLE_COLUMNS,
            stage_location="@MY_STAGE/path/",
            file_type=FileType.PARQUET,
            files=["part_0000.parquet", "part_0001.parquet"],
        )
        assert "FILES = ('part_0000.parquet', 'part_0001.parquet')" in sql
        assert "PATTERN" not in sql

    def test_files_with_single_file(self, loader):
        sql = loader.generate_copy_into_statement(
            target_table="MY_DB.MY_SCHEMA.MY_TABLE",
            columns=SIMPLE_COLUMNS,
            stage_location="@MY_STAGE/path/",
            file_type=FileType.PARQUET,
            files=["only.parquet"],
        )
        assert "FILES = ('only.parquet')" in sql

    def test_csv_files_parameter(self, loader):
        sql = loader.generate_copy_into_statement(
            target_table="MY_DB.MY_SCHEMA.MY_TABLE",
            columns=SIMPLE_COLUMNS,
            stage_location="@MY_STAGE/path/",
            file_type=FileType.CSV,
            files=["data.csv", "data2.csv.gz"],
        )
        assert "FILES = ('data.csv', 'data2.csv.gz')" in sql
        assert "PATTERN" not in sql

    def test_copy_into_structure_with_files(self, loader):
        """Verify the overall SQL structure: COPY INTO ... FROM (...) FILES = (...)."""
        sql = loader.generate_copy_into_statement(
            target_table="DB.SCH.TBL",
            columns=[("id", "INT")],
            stage_location="@STG/data/",
            file_type=FileType.PARQUET,
            files=["a.parquet", "b.parquet"],
        )
        assert sql.startswith("COPY INTO DB.SCH.TBL\nFROM (")
        assert "FILE_FORMAT =>" in sql
        assert "\nFILES = ('a.parquet', 'b.parquet')" in sql
