"""
Unit tests for _build_create_table_ddl.

Tests cover DDL generation for native Snowflake tables, Snowflake-managed
Iceberg tables, and externally cataloged Iceberg tables.
"""

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    IcebergTargetConfig,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler import (
    _build_create_table_ddl,
)


class TestBuildCreateTableDDL:
    """Test suite for _build_create_table_ddl."""

    def test_native_table_ddl(self):
        """When iceberg_config is None, generates standard CREATE TABLE."""
        ddl = _build_create_table_ddl(
            full_table_name="DB.SCHEMA.MY_TABLE",
            column_definitions=["id NUMBER", "name VARCHAR"],
            iceberg_config=None,
        )

        assert ddl == "CREATE TABLE DB.SCHEMA.MY_TABLE (id NUMBER, name VARCHAR)"

    def test_snowflake_managed_iceberg_ddl(self):
        """Snowflake-managed Iceberg table includes CATALOG, EXTERNAL_VOLUME, BASE_LOCATION."""
        config = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="my_vol",
            base_location_prefix=None,
        )
        ddl = _build_create_table_ddl(
            full_table_name="DB.SCHEMA.MY_TABLE",
            column_definitions=["id NUMBER", "name VARCHAR"],
            iceberg_config=config,
        )

        assert "CREATE ICEBERG TABLE DB.SCHEMA.MY_TABLE" in ddl
        assert "CATALOG = 'SNOWFLAKE'" in ddl
        assert "EXTERNAL_VOLUME = 'my_vol'" in ddl
        assert "BASE_LOCATION = 'DB/SCHEMA/MY_TABLE'" in ddl

    def test_external_catalog_iceberg_ddl(self):
        """External catalog uses catalog integration name and CATALOG_TABLE_NAME."""
        config = IcebergTargetConfig(
            catalog="my_glue_integration",
            external_volume="my_vol",
            catalog_table_name="glue_db.my_table",
        )
        ddl = _build_create_table_ddl(
            full_table_name="DB.SCHEMA.MY_TABLE",
            column_definitions=["id NUMBER"],
            iceberg_config=config,
        )

        assert "CREATE ICEBERG TABLE DB.SCHEMA.MY_TABLE" in ddl
        assert "CATALOG = 'my_glue_integration'" in ddl
        assert "EXTERNAL_VOLUME = 'my_vol'" in ddl
        assert "CATALOG_TABLE_NAME = 'glue_db.my_table'" in ddl
        # External catalog should NOT have BASE_LOCATION
        assert "BASE_LOCATION" not in ddl

    def test_iceberg_ddl_with_catalog_sync(self):
        """When catalogSync is set, DDL includes CATALOG_SYNC clause."""
        config = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="my_vol",
            catalog_sync="my_glue_sync",
        )
        ddl = _build_create_table_ddl(
            full_table_name="DB.SCHEMA.MY_TABLE",
            column_definitions=["id NUMBER"],
            iceberg_config=config,
        )

        assert "CATALOG_SYNC = 'my_glue_sync'" in ddl

    def test_base_location_derived_from_table_name(self):
        """Without a prefix, base_location is the full table name with dots replaced by slashes."""
        config = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="my_vol",
            base_location_prefix=None,
        )
        ddl = _build_create_table_ddl(
            full_table_name="MY_DB.PUBLIC.ORDERS",
            column_definitions=["id NUMBER"],
            iceberg_config=config,
        )

        assert "BASE_LOCATION = 'MY_DB/PUBLIC/ORDERS'" in ddl

    def test_base_location_with_prefix(self):
        """When baseLocationPrefix is set, it is prepended to the table-name-derived path."""
        config = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="my_vol",
            base_location_prefix="data/warehouse",
        )
        ddl = _build_create_table_ddl(
            full_table_name="MY_DB.PUBLIC.ORDERS",
            column_definitions=["id NUMBER"],
            iceberg_config=config,
        )

        assert "BASE_LOCATION = 'data/warehouse/MY_DB/PUBLIC/ORDERS'" in ddl
