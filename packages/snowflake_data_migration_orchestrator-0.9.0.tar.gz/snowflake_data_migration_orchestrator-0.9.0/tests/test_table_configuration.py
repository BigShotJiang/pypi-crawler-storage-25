"""Unit tests for table configuration models."""

from dataclasses import FrozenInstanceError
import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableConfiguration,
    TableIdentifier,
)


class TestTableIdentifier:
    """Tests for TableIdentifier dataclass."""

    def test_basic_creation(self):
        """Test creating a basic table identifier."""
        endpoint = TableIdentifier(
            database_name="mydb",
            schema_name="myschema",
            table_name="mytable",
        )
        assert endpoint.database_name == "mydb"
        assert endpoint.schema_name == "myschema"
        assert endpoint.table_name == "mytable"

    def test_fully_qualified_friendly_name(self):
        """Test the fully_qualified_friendly_name property."""
        endpoint = TableIdentifier(
            database_name="source_db",
            schema_name="dbo",
            table_name="customers",
        )
        assert endpoint.fully_qualified_friendly_name == "source_db.dbo.customers"

    def test_immutability(self):
        """Test that TableIdentifier is frozen (immutable)."""
        endpoint = TableIdentifier(
            database_name="mydb",
            schema_name="myschema",
            table_name="mytable",
        )
        with pytest.raises(FrozenInstanceError):
            endpoint.table_name = "other_table"  # type: ignore[misc]


class TestTableConfiguration:
    """Tests for TableConfiguration dataclass."""

    def test_basic_creation(self):
        """Test creating a basic table configuration."""
        source = TableIdentifier(
            database_name="source_db",
            schema_name="dbo",
            table_name="customers",
        )
        target = TableIdentifier(
            database_name="target_db",
            schema_name="public",
            table_name="customers",
        )
        config = TableConfiguration(
            source=source,
            target=target,
            partition_columns=["id"],
        )
        assert config.source == source
        assert config.target == target
        assert config.partition_columns == ["id"]
        assert config.column_type_mappings == {}

    def test_with_column_type_mappings(self):
        """Test table configuration with custom type mappings."""
        source = TableIdentifier("source_db", "dbo", "orders")
        target = TableIdentifier("target_db", "public", "orders")
        mappings = {
            "BIT": "BOOLEAN",
            "MONEY": "DECIMAL(19,4)",
        }
        config = TableConfiguration(
            source=source,
            target=target,
            partition_columns=["order_id"],
            column_type_mappings=mappings,
        )
        assert len(config.column_type_mappings) == 2
        assert config.column_type_mappings["BIT"] == "BOOLEAN"
        assert config.column_type_mappings["MONEY"] == "DECIMAL(19,4)"

    def test_immutability(self):
        """Test that TableConfiguration is frozen (immutable)."""
        source = TableIdentifier("db", "schema", "table")
        target = TableIdentifier("db", "schema", "table")
        config = TableConfiguration(
            source=source,
            target=target,
            partition_columns=["id"],
        )
        with pytest.raises(FrozenInstanceError):
            config.partition_columns = ["other"]  # type: ignore[misc]

    def test_multiple_partition_columns(self):
        """Test configuration with multiple partition columns."""
        source = TableIdentifier("db", "schema", "table")
        target = TableIdentifier("db", "schema", "table")
        config = TableConfiguration(
            source=source,
            target=target,
            partition_columns=["year", "month", "day"],
        )
        assert config.partition_columns == ["year", "month", "day"]

    def test_partition_column_property_single(self):
        """Test partition_column property returns the single column."""
        source = TableIdentifier("db", "schema", "table")
        target = TableIdentifier("db", "schema", "table")
        config = TableConfiguration(
            source=source,
            target=target,
            partition_columns=["id"],
        )
        assert config.partition_column == "id"

    def test_partition_column_property_empty(self):
        """Test partition_column property returns None for empty list."""
        source = TableIdentifier("db", "schema", "table")
        target = TableIdentifier("db", "schema", "table")
        config = TableConfiguration(
            source=source,
            target=target,
            partition_columns=[],
        )
        assert config.partition_column is None

    def test_partition_column_property_multiple_raises(self):
        """Test partition_column property raises for multiple columns."""
        source = TableIdentifier("db", "schema", "table")
        target = TableIdentifier("db", "schema", "table")
        config = TableConfiguration(
            source=source,
            target=target,
            partition_columns=["year", "month"],
        )
        with pytest.raises(ValueError, match="Multiple partition columns"):
            _ = config.partition_column
