"""Tests for ResilientConnection, FailureTracker, and proactive age refresh."""

import time
import unittest
from unittest.mock import MagicMock, patch

from snowflake.connector.errors import ProgrammingError

from data_migration_orchestrator.cloud_core.connection_manager import (
    DEFAULT_MAX_CONNECTION_AGE_SECONDS,
    ORCHESTRATOR_SF_CONNECTION_MAX_AGE_ENV,
    FailureTracker,
    ResilientConnection,
    get_max_connection_age_seconds,
)
from data_migration_orchestrator.cloud_core.snowflake_session_retry import (
    SF_SESSION_EXPIRED_ERRNO,
    build_resilient_refresher,
    is_session_expired_error,
)


# ---------------------------------------------------------------------------
# FailureTracker
# ---------------------------------------------------------------------------
class TestFailureTracker(unittest.TestCase):
    """Unit tests for the FailureTracker circuit-breaker."""

    def test_initial_count_is_zero(self):
        ft = FailureTracker(max_consecutive_failures=3)
        self.assertEqual(ft.get_count(), 0)

    def test_increment_and_reset(self):
        ft = FailureTracker(max_consecutive_failures=5)
        ft.increment()
        ft.increment()
        self.assertEqual(ft.get_count(), 2)
        ft.reset()
        self.assertEqual(ft.get_count(), 0)

    def test_check_threshold_raises_when_exceeded(self):
        ft = FailureTracker(max_consecutive_failures=2)
        ft.increment()
        ft.increment()
        with self.assertRaises(ConnectionError):
            ft.check_threshold()

    def test_check_threshold_ok_below_limit(self):
        ft = FailureTracker(max_consecutive_failures=3)
        ft.increment()
        ft.check_threshold()


# ---------------------------------------------------------------------------
# get_max_connection_age_seconds
# ---------------------------------------------------------------------------
class TestGetMaxConnectionAgeSeconds(unittest.TestCase):
    """Unit tests for the env-based max connection age helper."""

    def test_default_when_unset(self):
        with patch.dict("os.environ", {}, clear=True):
            self.assertEqual(
                get_max_connection_age_seconds(),
                float(DEFAULT_MAX_CONNECTION_AGE_SECONDS),
            )

    def test_returns_none_for_zero(self):
        with patch.dict("os.environ", {ORCHESTRATOR_SF_CONNECTION_MAX_AGE_ENV: "0"}):
            self.assertIsNone(get_max_connection_age_seconds())

    def test_returns_none_for_negative(self):
        with patch.dict("os.environ", {ORCHESTRATOR_SF_CONNECTION_MAX_AGE_ENV: "-1"}):
            self.assertIsNone(get_max_connection_age_seconds())

    def test_returns_custom_value(self):
        with patch.dict("os.environ", {ORCHESTRATOR_SF_CONNECTION_MAX_AGE_ENV: "600"}):
            self.assertEqual(get_max_connection_age_seconds(), 600.0)

    def test_invalid_falls_back_to_default(self):
        with patch.dict("os.environ", {ORCHESTRATOR_SF_CONNECTION_MAX_AGE_ENV: "abc"}):
            self.assertEqual(
                get_max_connection_age_seconds(),
                float(DEFAULT_MAX_CONNECTION_AGE_SECONDS),
            )


# ---------------------------------------------------------------------------
# ResilientConnection
# ---------------------------------------------------------------------------
def _make_mock_raw_conn():
    conn = MagicMock()
    conn.is_closed.return_value = False
    cursor_ctx = MagicMock()
    conn.cursor.return_value = cursor_ctx
    cursor_ctx.__enter__ = MagicMock(return_value=cursor_ctx)
    cursor_ctx.__exit__ = MagicMock(return_value=False)
    cursor_ctx.execute.return_value = None
    cursor_ctx.fetchone.return_value = (1,)
    return conn


class TestResilientConnection(unittest.TestCase):
    """Unit tests for ResilientConnection wrapper."""

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_connect_on_init(self, mock_tel, mock_verify, mock_connect):
        raw = _make_mock_raw_conn()
        mock_connect.return_value = raw

        ft = FailureTracker()
        rc = ResilientConnection(
            connection_config={"account": "x", "user": "u", "password": "p"},
            app_version="1.0",
            failure_tracker=ft,
            max_connection_age_seconds=None,
        )

        mock_connect.assert_called_once()
        mock_verify.assert_called_once_with(raw)
        self.assertFalse(rc.is_closed())

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_retry_on_connect_failure(self, mock_tel, mock_verify, mock_connect):
        raw = _make_mock_raw_conn()
        mock_connect.side_effect = [Exception("fail"), raw]

        ft = FailureTracker()
        rc = ResilientConnection(
            connection_config={"account": "x", "user": "u", "password": "p"},
            app_version="1.0",
            failure_tracker=ft,
            max_connection_age_seconds=None,
        )

        self.assertEqual(mock_connect.call_count, 2)
        self.assertFalse(rc.is_closed())

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_circuit_breaker_trips(self, mock_tel, mock_verify, mock_connect):
        mock_connect.side_effect = Exception("fail")

        ft = FailureTracker(max_consecutive_failures=2)
        with self.assertRaises((ConnectionError,)):
            ResilientConnection(
                connection_config={"account": "x"},
                app_version="1.0",
                failure_tracker=ft,
                max_connection_age_seconds=None,
            )

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_proactive_age_refresh(self, mock_tel, mock_verify, mock_connect):
        raw1 = _make_mock_raw_conn()
        raw2 = _make_mock_raw_conn()
        mock_connect.side_effect = [raw1, raw2]

        ft = FailureTracker()
        rc = ResilientConnection(
            connection_config={"account": "x", "user": "u", "password": "p"},
            app_version="1.0",
            failure_tracker=ft,
            max_connection_age_seconds=0.01,
        )

        time.sleep(0.02)
        rc.cursor()
        self.assertEqual(mock_connect.call_count, 2)
        raw1.close.assert_called()

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_proactive_disabled_when_none(self, mock_tel, mock_verify, mock_connect):
        raw = _make_mock_raw_conn()
        mock_connect.return_value = raw

        ft = FailureTracker()
        rc = ResilientConnection(
            connection_config={"account": "x", "user": "u", "password": "p"},
            app_version="1.0",
            failure_tracker=ft,
            max_connection_age_seconds=None,
        )

        rc._creation_time = time.time() - 999999
        rc.cursor()
        self.assertEqual(mock_connect.call_count, 1)

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_force_reconnect(self, mock_tel, mock_verify, mock_connect):
        raw1 = _make_mock_raw_conn()
        raw2 = _make_mock_raw_conn()
        mock_connect.side_effect = [raw1, raw2]

        ft = FailureTracker()
        rc = ResilientConnection(
            connection_config={"account": "x", "user": "u", "password": "p"},
            app_version="1.0",
            failure_tracker=ft,
            max_connection_age_seconds=None,
        )

        rc.force_reconnect()
        self.assertEqual(mock_connect.call_count, 2)
        raw1.close.assert_called()

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_context_manager_closes(self, mock_tel, mock_verify, mock_connect):
        raw = _make_mock_raw_conn()
        mock_connect.return_value = raw

        ft = FailureTracker()
        with ResilientConnection(
            connection_config={"account": "x"},
            app_version="1.0",
            failure_tracker=ft,
            max_connection_age_seconds=None,
        ):
            pass

        raw.close.assert_called()


# ---------------------------------------------------------------------------
# build_resilient_refresher
# ---------------------------------------------------------------------------
class TestBuildResilientRefresher(unittest.TestCase):
    """Unit tests for build_resilient_refresher utility."""

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_refresher_calls_force_reconnect_on_old(
        self, mock_tel, mock_verify, mock_connect
    ):
        raw1 = _make_mock_raw_conn()
        raw2 = _make_mock_raw_conn()
        mock_connect.side_effect = [raw1, raw2]

        ft = FailureTracker()
        rc = ResilientConnection(
            connection_config={"account": "x"},
            app_version="1.0",
            failure_tracker=ft,
            max_connection_age_seconds=None,
        )

        refresher = build_resilient_refresher()
        result = refresher(rc)

        self.assertIs(result, rc)
        self.assertEqual(mock_connect.call_count, 2)

    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager.snowflake.connector.connect"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._verify_connection"
    )
    @patch(
        "data_migration_orchestrator.cloud_core.connection_manager._initialize_telemetry_safe"
    )
    def test_refresher_reconnects_worker_not_main(
        self, mock_tel, mock_verify, mock_connect
    ):
        """Each thread's refresher must reconnect *its own* connection."""
        raws = [_make_mock_raw_conn() for _ in range(4)]
        mock_connect.side_effect = raws

        ft = FailureTracker()
        main_conn = ResilientConnection(
            connection_config={"account": "x"},
            app_version="1.0",
            failure_tracker=ft,
            thread_name="main",
            max_connection_age_seconds=None,
        )
        worker_conn = ResilientConnection(
            connection_config={"account": "x"},
            app_version="1.0",
            failure_tracker=ft,
            thread_name="worker-0",
            max_connection_age_seconds=None,
        )

        refresher = build_resilient_refresher()
        result = refresher(worker_conn)

        self.assertIs(result, worker_conn, "refresher must return the worker's conn")
        self.assertIsNot(result, main_conn, "refresher must not return the main conn")
        self.assertEqual(mock_connect.call_count, 3)

    def test_refresher_raises_on_non_resilient(self):
        refresher = build_resilient_refresher()
        with self.assertRaises(TypeError):
            refresher(MagicMock())


# ---------------------------------------------------------------------------
# is_session_expired_error — __cause__ chain traversal
# ---------------------------------------------------------------------------
class TestIsSessionExpiredError(unittest.TestCase):
    """Unit tests for is_session_expired_error with cause-chain support."""

    def _make_390111(self, msg: str = "session gone") -> ProgrammingError:
        err = ProgrammingError(msg=msg)
        err.errno = SF_SESSION_EXPIRED_ERRNO
        return err

    def test_direct_programming_error(self):
        self.assertTrue(is_session_expired_error(self._make_390111()))

    def test_unrelated_programming_error(self):
        err = ProgrammingError(msg="syntax error")
        err.errno = 1234
        self.assertFalse(is_session_expired_error(err))

    def test_non_programming_error(self):
        self.assertFalse(is_session_expired_error(ValueError("nope")))

    def test_wrapped_in_runtime_error(self):
        """RuntimeError wrapping a 390111 ProgrammingError should be detected."""
        cause = self._make_390111()
        wrapper = RuntimeError("query failed")
        wrapper.__cause__ = cause
        self.assertTrue(is_session_expired_error(wrapper))

    def test_double_wrapped(self):
        """Two levels of wrapping should still be detected."""
        cause = self._make_390111()
        mid = RuntimeError("inner")
        mid.__cause__ = cause
        outer = RuntimeError("outer")
        outer.__cause__ = mid
        self.assertTrue(is_session_expired_error(outer))

    def test_wrapped_unrelated_error(self):
        cause = ValueError("not a session error")
        wrapper = RuntimeError("query failed")
        wrapper.__cause__ = cause
        self.assertFalse(is_session_expired_error(wrapper))


if __name__ == "__main__":
    unittest.main()
