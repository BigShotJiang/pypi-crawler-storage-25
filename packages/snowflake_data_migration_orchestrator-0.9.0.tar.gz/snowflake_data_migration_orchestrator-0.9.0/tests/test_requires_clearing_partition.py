# Copyright (c) 2024-2026 Snowflake Inc. All rights reserved.
# Licensed under the Apache License, Version 2.0.
"""
Tests for _requires_clearing_partition logic in TaskChainCreator.

CHECKSUM sync always queues CLEAR_PARTITION_DATA when building the post-checksum
extraction chain; ClearPartitionDataHandler skips DELETE when the target table
does not exist yet (first sync).
"""

import pytest
from unittest.mock import MagicMock

from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    ChecksumSyncData,
    WatermarkSyncData,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_chain_creator import (
    TaskChainContext,
    TaskChainCreator,
)


@pytest.fixture
def creator():
    """Create a TaskChainCreator with minimal mocks."""
    platform = MagicMock()
    task_queue = MagicMock()
    context = TaskChainContext(
        workflow_id=1,
        table_metadata_id=1,
        table_config=TableConfiguration(
            source=TableIdentifier("src_db", "src_schema", "src_table"),
            target=TableIdentifier("tgt_db", "tgt_schema", "tgt_table"),
        ),
        source_schema=[],
        suggested_batch_size=None,
    )
    return TaskChainCreator(platform, task_queue, context)


class TestRequiresClearingPartition:
    """Tests for the _requires_clearing_partition guard."""

    def test_returns_false_for_none_sync_data(self, creator):
        """No sync data at all (e.g., FULL/NONE strategy) -> no clearing."""
        assert creator._requires_clearing_partition(None) is False

    def test_returns_false_for_non_checksum_sync_data(self, creator):
        """WATERMARK sync data -> no clearing (only CHECKSUM uses clearing)."""
        watermark_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value="2024-01-01",
        )
        assert creator._requires_clearing_partition(watermark_data) is False

    def test_returns_true_for_checksum_sync_with_candidate_only(self, creator):
        """
        After storing candidate_checksum, promoted checksum is still None.

        We still require clearing so incremental re-sync removes stale rows;
        the clear handler no-ops if the target table does not exist.
        """
        sync_data = ChecksumSyncData(
            strategy=SyncStrategy.CHECKSUM,
            checksum=None,
            candidate_checksum="abc123",  # already written by handler
        )
        assert creator._requires_clearing_partition(sync_data) is True

    def test_returns_true_for_checksum_sync_no_promoted_no_candidate(self, creator):
        """Checksum strategy always clears when sync data is ChecksumSyncData."""
        sync_data = ChecksumSyncData(
            strategy=SyncStrategy.CHECKSUM,
            checksum=None,
            candidate_checksum=None,
        )
        assert creator._requires_clearing_partition(sync_data) is True

    def test_returns_true_for_subsequent_sync(self, creator):
        """
        Subsequent sync: checksum (promoted) is set from previous cycle.

        The partition already has data in the target table,
        so we need to clear before re-loading.
        """
        sync_data = ChecksumSyncData(
            strategy=SyncStrategy.CHECKSUM,
            checksum="previous_hash",
            candidate_checksum="new_hash",
        )
        assert creator._requires_clearing_partition(sync_data) is True

    def test_returns_true_for_subsequent_sync_no_new_candidate(self, creator):
        """Subsequent sync before candidate is written: checksum set, candidate None."""
        sync_data = ChecksumSyncData(
            strategy=SyncStrategy.CHECKSUM,
            checksum="previous_hash",
            candidate_checksum=None,
        )
        assert creator._requires_clearing_partition(sync_data) is True
