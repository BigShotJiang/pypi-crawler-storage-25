"""Tests for scope utilities."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.platform import (
    SqlServerPlatform,
)
from data_migration_orchestrator.data_migration_cloud.scope import (
    ScopeBuilder,
    build_partition_extraction_scope,
    build_partition_loading_scope,
    build_table_preprocessing_scope,
)


@pytest.fixture
def sqlserver_platform() -> SqlServerPlatform:
    """Return a SqlServerPlatform instance for testing."""
    return SqlServerPlatform()


class TestScopeBuilderForTable:
    """Tests for ScopeBuilder.for_table() factory method."""

    def test_for_table_creates_builder(self, sqlserver_platform: SqlServerPlatform):
        """Test that for_table returns a ScopeBuilder instance."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        builder = ScopeBuilder.for_table(table_id, sqlserver_platform)
        assert isinstance(builder, ScopeBuilder)


class TestScopeBuilderPartition:
    """Tests for ScopeBuilder.partition() method."""

    def test_partition_adds_fragment(self, sqlserver_platform: SqlServerPlatform):
        """Test that partition adds a Partition fragment."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(0)
            .extraction()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[0]::Extraction"

    def test_partition_with_positive_id(self, sqlserver_platform: SqlServerPlatform):
        """Test partition with various positive IDs."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(5)
            .extraction()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[5]::Extraction"

    def test_partition_returns_self_for_chaining(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that partition returns self for method chaining."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        builder = ScopeBuilder.for_table(table_id, sqlserver_platform)
        result = builder.partition(1)
        assert result is builder

    def test_partition_negative_id_raises_error(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that negative partition IDs raise ValueError."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        with pytest.raises(ValueError) as excinfo:
            ScopeBuilder.for_table(table_id, sqlserver_platform).partition(-1)
        assert "non-negative" in str(excinfo.value)
        assert "-1" in str(excinfo.value)


class TestScopeBuilderPreprocessing:
    """Tests for ScopeBuilder.preprocessing() method."""

    def test_preprocessing_table_scope(self, sqlserver_platform: SqlServerPlatform):
        """Test building a table-level preprocessing scope."""
        table_id = TableIdentifier(
            database_name="MY_DB", schema_name="MY_SCHEMA", table_name="MY_TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, sqlserver_platform).preprocessing()
        assert scope == "Table[MY_DB.MY_SCHEMA.MY_TABLE]::Preprocessing"

    def test_preprocessing_returns_string(self, sqlserver_platform: SqlServerPlatform):
        """Test that preprocessing returns a string."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, sqlserver_platform).preprocessing()
        assert isinstance(scope, str)


class TestScopeBuilderExtraction:
    """Tests for ScopeBuilder.extraction() method."""

    def test_extraction_table_scope(self, sqlserver_platform: SqlServerPlatform):
        """Test building a table-level extraction scope."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, sqlserver_platform).extraction()
        assert scope == "Table[DB.SCHEMA.TABLE]::Extraction"

    def test_extraction_partition_scope(self, sqlserver_platform: SqlServerPlatform):
        """Test building a partition-level extraction scope."""
        table_id = TableIdentifier(
            database_name="MY_DB", schema_name="MY_SCHEMA", table_name="MY_TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(2)
            .extraction()
        )
        assert scope == "Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[2]::Extraction"

    def test_extraction_returns_string(self, sqlserver_platform: SqlServerPlatform):
        """Test that extraction returns a string."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(0)
            .extraction()
        )
        assert isinstance(scope, str)


class TestScopeBuilderLoading:
    """Tests for ScopeBuilder.loading() method."""

    def test_loading_table_scope(self, sqlserver_platform: SqlServerPlatform):
        """Test building a table-level loading scope."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, sqlserver_platform).loading()
        assert scope == "Table[DB.SCHEMA.TABLE]::Loading"

    def test_loading_partition_scope(self, sqlserver_platform: SqlServerPlatform):
        """Test building a partition-level loading scope."""
        table_id = TableIdentifier(
            database_name="MY_DB", schema_name="MY_SCHEMA", table_name="MY_TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform).partition(2).loading()
        )
        assert scope == "Table[MY_DB.MY_SCHEMA.MY_TABLE]::Partition[2]::Loading"

    def test_loading_returns_string(self, sqlserver_platform: SqlServerPlatform):
        """Test that loading returns a string."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform).partition(0).loading()
        )
        assert isinstance(scope, str)


class TestScopeBuilderBuild:
    """Tests for ScopeBuilder.build() method."""

    def test_build_table_only(self, sqlserver_platform: SqlServerPlatform):
        """Test building a partial scope with just the table."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, sqlserver_platform).build()
        assert scope == "Table[DB.SCHEMA.TABLE]"

    def test_build_table_with_partition(self, sqlserver_platform: SqlServerPlatform):
        """Test building a partial scope with table and partition."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform).partition(3).build()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[3]"

    def test_build_useful_for_like_queries(self, sqlserver_platform: SqlServerPlatform):
        """Test that build creates scopes useful for LIKE patterns."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        partial = ScopeBuilder.for_table(table_id, sqlserver_platform).build()
        assert partial.startswith("Table[")
        assert "::" not in partial or partial.count("::") == 0


class TestScopeBuilderErrors:
    """Tests for ScopeBuilder error conditions."""

    def test_preprocessing_without_table_raises_error(self):
        """Test that calling preprocessing without for_table raises ValueError."""
        builder = ScopeBuilder()
        with pytest.raises(ValueError) as excinfo:
            builder.preprocessing()
        assert "for_table()" in str(excinfo.value)

    def test_extraction_without_table_raises_error(self):
        """Test that calling extraction without for_table raises ValueError."""
        builder = ScopeBuilder()
        with pytest.raises(ValueError) as excinfo:
            builder.extraction()
        assert "for_table()" in str(excinfo.value)

    def test_loading_without_table_raises_error(self):
        """Test that calling loading without for_table raises ValueError."""
        builder = ScopeBuilder()
        with pytest.raises(ValueError) as excinfo:
            builder.loading()
        assert "for_table()" in str(excinfo.value)

    def test_build_without_table_raises_error(self):
        """Test that calling build without for_table raises ValueError."""
        builder = ScopeBuilder()
        with pytest.raises(ValueError) as excinfo:
            builder.build()
        assert "for_table()" in str(excinfo.value)


class TestScopeBuilderFragmentSeparator:
    """Tests for ScopeBuilder fragment separator."""

    def test_fragment_separator_constant(self):
        """Test that FRAGMENT_SEPARATOR is correct."""
        assert ScopeBuilder.FRAGMENT_SEPARATOR == "::"

    def test_fragments_joined_with_separator(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that fragments are joined with the correct separator."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(1)
            .extraction()
        )
        assert scope.count("::") == 2
        parts = scope.split("::")
        assert parts[0] == "Table[DB.SCHEMA.TABLE]"
        assert parts[1] == "Partition[1]"
        assert parts[2] == "Extraction"


class TestBuildTableScope:
    """Tests for build_table_scope convenience function."""

    def test_build_table_scope_basic(self, sqlserver_platform: SqlServerPlatform):
        """Test basic table scope creation."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_table_preprocessing_scope(table_id, sqlserver_platform)
        assert scope == "Table[DB.SCHEMA.TABLE]::Preprocessing"

    def test_build_table_scope_with_sqlserver_normalizes(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that SQL Server platform uppercases unquoted identifiers."""
        table_id = TableIdentifier(
            database_name="db", schema_name="schema", table_name="table"
        )
        scope = build_table_preprocessing_scope(table_id, sqlserver_platform)
        assert scope == "Table[DB.SCHEMA.TABLE]::Preprocessing"

    def test_build_table_scope_matches_builder(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that convenience function matches builder output."""
        table_id = TableIdentifier(
            database_name="MY", schema_name="SCHEMA", table_name="TABLE"
        )
        convenience = build_table_preprocessing_scope(table_id, sqlserver_platform)
        builder = ScopeBuilder.for_table(table_id, sqlserver_platform).preprocessing()
        assert convenience == builder


class TestBuildPartitionExtractionScope:
    """Tests for build_partition_extraction_scope convenience function."""

    def test_build_partition_extraction_scope_basic(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test basic partition extraction scope creation."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_partition_extraction_scope(table_id, 2, sqlserver_platform)
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[2]::Extraction"

    def test_build_partition_extraction_scope_zero_partition(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test partition extraction scope with partition 0."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_partition_extraction_scope(table_id, 0, sqlserver_platform)
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[0]::Extraction"

    def test_build_partition_extraction_scope_sqlserver_normalizes(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that SQL Server platform uppercases unquoted identifiers."""
        table_id = TableIdentifier(
            database_name="my", schema_name="schema", table_name="table"
        )
        scope = build_partition_extraction_scope(table_id, 5, sqlserver_platform)
        assert scope == "Table[MY.SCHEMA.TABLE]::Partition[5]::Extraction"

    def test_build_partition_extraction_scope_matches_builder(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that convenience function matches builder output."""
        table_id = TableIdentifier(
            database_name="MY", schema_name="SCHEMA", table_name="TABLE"
        )
        partition_id = 7
        convenience = build_partition_extraction_scope(
            table_id, partition_id, sqlserver_platform
        )
        builder = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(partition_id)
            .extraction()
        )
        assert convenience == builder

    def test_build_partition_extraction_scope_negative_id_raises_error(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that negative partition IDs raise ValueError."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        with pytest.raises(ValueError):
            build_partition_extraction_scope(table_id, -1, sqlserver_platform)


class TestBuildPartitionLoadingScope:
    """Tests for build_partition_loading_scope convenience function."""

    def test_build_partition_loading_scope_basic(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test basic partition loading scope creation."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_partition_loading_scope(table_id, 2, sqlserver_platform)
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[2]::Loading"

    def test_build_partition_loading_scope_zero_partition(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test partition loading scope with partition 0."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = build_partition_loading_scope(table_id, 0, sqlserver_platform)
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[0]::Loading"

    def test_build_partition_loading_scope_sqlserver_normalizes(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that SQL Server platform uppercases unquoted identifiers."""
        table_id = TableIdentifier(
            database_name="my", schema_name="schema", table_name="table"
        )
        scope = build_partition_loading_scope(table_id, 5, sqlserver_platform)
        assert scope == "Table[MY.SCHEMA.TABLE]::Partition[5]::Loading"

    def test_build_partition_loading_scope_matches_builder(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that convenience function matches builder output."""
        table_id = TableIdentifier(
            database_name="MY", schema_name="SCHEMA", table_name="TABLE"
        )
        partition_id = 7
        convenience = build_partition_loading_scope(
            table_id, partition_id, sqlserver_platform
        )
        builder = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(partition_id)
            .loading()
        )
        assert convenience == builder

    def test_build_partition_loading_scope_negative_id_raises_error(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that negative partition IDs raise ValueError."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        with pytest.raises(ValueError):
            build_partition_loading_scope(table_id, -1, sqlserver_platform)


class TestScopeBuilderDocExamples:
    """Tests that verify the examples from the docstrings work correctly."""

    def test_table_preprocessing_example(self, sqlserver_platform: SqlServerPlatform):
        """Test the table preprocessing example from the docstring."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = ScopeBuilder.for_table(table_id, sqlserver_platform).preprocessing()
        assert scope == "Table[DB.SCHEMA.TABLE]::Preprocessing"

    def test_partition_extraction_example(self, sqlserver_platform: SqlServerPlatform):
        """Test the partition extraction example from the docstring."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(2)
            .extraction()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[2]::Extraction"

    def test_partition_loading_example(self, sqlserver_platform: SqlServerPlatform):
        """Test the partition loading example from the docstring."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform).partition(2).loading()
        )
        assert scope == "Table[DB.SCHEMA.TABLE]::Partition[2]::Loading"


class TestScopeBuilderRealWorldScenarios:
    """Tests for real-world usage scenarios."""

    def test_fully_qualified_table_names(self, sqlserver_platform: SqlServerPlatform):
        """Test with fully qualified table names including special characters."""
        table_id = TableIdentifier(
            database_name="SNOWCONVERT_AI",
            schema_name="DATA_MIGRATION",
            table_name="TASK_QUEUE",
        )
        scope = ScopeBuilder.for_table(table_id, sqlserver_platform).preprocessing()
        assert scope == "Table[SNOWCONVERT_AI.DATA_MIGRATION.TASK_QUEUE]::Preprocessing"

    def test_multiple_partitions_have_unique_scopes(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that different partitions generate unique scopes."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        scopes = [
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(i)
            .extraction()
            for i in range(5)
        ]
        assert len(scopes) == len(set(scopes))

    def test_extraction_and_loading_for_same_partition_differ(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that extraction and loading scopes for the same partition differ."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        extraction = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(1)
            .extraction()
        )
        loading = (
            ScopeBuilder.for_table(table_id, sqlserver_platform).partition(1).loading()
        )
        assert extraction != loading
        assert "Extraction" in extraction
        assert "Loading" in loading

    def test_scope_can_be_used_for_prefix_matching(
        self, sqlserver_platform: SqlServerPlatform
    ):
        """Test that partial scopes can be used for prefix matching."""
        table_id = TableIdentifier(
            database_name="DB", schema_name="SCHEMA", table_name="TABLE"
        )
        table_prefix = ScopeBuilder.for_table(table_id, sqlserver_platform).build()
        partition_scope = (
            ScopeBuilder.for_table(table_id, sqlserver_platform)
            .partition(1)
            .extraction()
        )
        assert partition_scope.startswith(table_prefix)
