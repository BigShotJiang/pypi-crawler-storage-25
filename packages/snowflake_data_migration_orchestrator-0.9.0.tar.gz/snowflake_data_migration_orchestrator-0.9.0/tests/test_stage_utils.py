"""Tests for stage utility functions."""

import unittest
from unittest.mock import AsyncMock, patch

import pytest

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    StageResolution,
    build_external_stage_data_path,
    read_boundaries_from_stage,
    read_metadata_from_stage,
    read_schema_from_stage,
    relative_path_for_boundaries,
    relative_path_for_checksum,
    relative_path_for_metadata,
    relative_path_for_partition_data,
    relative_path_for_schema,
    resolve_stage_for_strategy,
    stage_path_for_boundaries,
    stage_path_for_checksum,
    stage_path_for_metadata,
    stage_path_for_partition_data,
    stage_path_for_schema,
)


class TestDeterministicStagePaths:
    """Tests for deterministic path computation functions."""

    def test_stage_path_for_partition_data_full_table(self):
        """Test computing data path for full table (partition 0)."""
        result = stage_path_for_partition_data(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
            partition_index=0,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/data/full_table/"

    def test_stage_path_for_partition_data_partition_5(self):
        """Test computing data path for partition 5."""
        result = stage_path_for_partition_data(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
            partition_index=5,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/data/partition_5/"

    def test_stage_path_for_partition_data_fully_qualified_stage(self):
        """Test with fully qualified Snowflake stage name."""
        sid = default_internal_stage()
        result = stage_path_for_partition_data(
            stage_id=sid,
            workflow_id=123,
            table_metadata_id=456,
            partition_index=3,
        )
        assert result == (
            f"{sid}/" "task_results/workflows/123/tables/456/data/partition_3/"
        )

    def test_stage_path_for_schema(self):
        """Test computing schema path."""
        result = stage_path_for_schema(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/schema/"

    def test_stage_path_for_metadata(self):
        """Test computing metadata path."""
        result = stage_path_for_metadata(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/metadata/"

    def test_stage_path_for_boundaries(self):
        """Test computing boundaries path."""
        result = stage_path_for_boundaries(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
        )
        assert result == "@STAGE/task_results/workflows/1/tables/42/boundaries/"

    def test_stage_path_for_checksum(self):
        """Test computing checksum path."""
        result = stage_path_for_checksum(
            stage_id="@STAGE",
            workflow_id=1,
            table_metadata_id=42,
            partition_index=7,
        )
        assert (
            result == "@STAGE/task_results/workflows/1/tables/42/checksum/partition_7/"
        )

    def test_all_paths_share_common_base(self):
        """Test that all path functions share the same base structure."""
        stage_id = default_internal_stage()
        workflow_id = 99
        table_metadata_id = 101

        expected_base = f"{stage_id}/task_results/workflows/99/tables/101"

        data_path = stage_path_for_partition_data(
            stage_id, workflow_id, table_metadata_id, partition_index=0
        )
        schema_path = stage_path_for_schema(stage_id, workflow_id, table_metadata_id)
        metadata_path = stage_path_for_metadata(
            stage_id, workflow_id, table_metadata_id
        )
        boundaries_path = stage_path_for_boundaries(
            stage_id, workflow_id, table_metadata_id
        )
        checksum_path = stage_path_for_checksum(
            stage_id, workflow_id, table_metadata_id, partition_index=0
        )

        assert data_path.startswith(expected_base)
        assert schema_path.startswith(expected_base)
        assert metadata_path.startswith(expected_base)
        assert boundaries_path.startswith(expected_base)
        assert checksum_path.startswith(expected_base)

    def test_different_table_ids_produce_different_paths(self):
        """Test that different table_metadata_ids produce different paths."""
        path1 = stage_path_for_schema("@STAGE", 1, table_metadata_id=1)
        path2 = stage_path_for_schema("@STAGE", 1, table_metadata_id=2)
        assert path1 != path2

    def test_different_workflow_ids_produce_different_paths(self):
        """Test that different workflow_ids produce different paths."""
        path1 = stage_path_for_schema("@STAGE", workflow_id=1, table_metadata_id=1)
        path2 = stage_path_for_schema("@STAGE", workflow_id=2, table_metadata_id=1)
        assert path1 != path2


class TestResolveStageForStrategy:
    """Tests for UNLOAD / REGULAR stage resolution."""

    def test_regular_uses_internal_stage(self):
        r = resolve_stage_for_strategy(ExtractionStrategy.REGULAR)
        assert r.stage_id == default_internal_stage()
        assert r.is_external is False
        assert r.external_stage_base_path is None

    def test_unload_precedence_table_over_strategy_over_workflow(self):
        r = resolve_stage_for_strategy(
            ExtractionStrategy.UNLOAD,
            strategy_config={"external_stage": "@STRATEGY", "s3_prefix": "/pfx/"},
            workflow_external_stage="@WORKFLOW",
            table_external_stage="@TABLE",
        )
        assert r.stage_id == "@TABLE"
        assert r.is_external is True
        assert r.external_stage_base_path == "pfx"

    def test_unload_strategy_config_when_no_table_stage(self):
        r = resolve_stage_for_strategy(
            ExtractionStrategy.UNLOAD,
            strategy_config={"external_stage": "NO_AT"},
            workflow_external_stage="@WORKFLOW",
        )
        assert r.stage_id == "@NO_AT"

    def test_unload_workflow_fallback_only(self):
        r = resolve_stage_for_strategy(
            ExtractionStrategy.UNLOAD,
            workflow_external_stage="@ONLY",
        )
        assert r.stage_id == "@ONLY"

    def test_unload_missing_external_raises(self):
        with pytest.raises(ValueError, match="UNLOAD extraction strategy"):
            resolve_stage_for_strategy(ExtractionStrategy.UNLOAD)


class TestBuildExternalStageDataPath:
    """Tests for ``build_external_stage_data_path``."""

    def test_composes_stage_base_and_relative_partition_path(self):
        res = StageResolution(
            stage_id="@S",
            is_external=True,
            external_stage_base_path="wf/tbl",
        )
        out = build_external_stage_data_path(
            res, workflow_id=1, table_metadata_id=2, partition_index=3
        )
        assert out.startswith("@S/wf/tbl/")
        assert out.endswith("/data/partition_3/")


class TestRelativePathHelpers:
    """Tests for relative path helpers (no stage prefix)."""

    def test_all_relative_helpers_share_base_and_correct_suffixes(self):
        wf, tid, pidx = 10, 20, 4
        base = f"task_results/workflows/{wf}/tables/{tid}"
        assert (
            relative_path_for_partition_data(wf, tid, pidx)
            == f"{base}/data/partition_{pidx}/"
        )
        assert (
            relative_path_for_partition_data(wf, tid, 0) == f"{base}/data/full_table/"
        )
        assert relative_path_for_schema(wf, tid) == f"{base}/schema/"
        assert relative_path_for_metadata(wf, tid) == f"{base}/metadata/"
        assert relative_path_for_boundaries(wf, tid) == f"{base}/boundaries/"
        assert (
            relative_path_for_checksum(wf, tid, pidx)
            == f"{base}/checksum/partition_{pidx}/"
        )


class FakeStageQueryWarehouse:
    """Minimal fake: only execute_sync_query used by stage_utils readers."""

    def __init__(self, rows: list[dict]):
        self.rows = rows

    async def execute_sync_query(self, query: str):
        return self.rows


class TestReadFromStage(unittest.IsolatedAsyncioTestCase):
    """Async stage readers using a thin fake warehouse."""

    async def test_read_metadata_from_stage_success_uppercase_keys(self):
        wh = FakeStageQueryWarehouse([{"ROW_COUNT": 100, "DATA_SIZE_MB": 1.5}])
        out = await read_metadata_from_stage(wh, "@STAGE/metadata/")
        self.assertEqual(out, {"row_count": 100, "data_size_mb": 1.5})

    async def test_read_metadata_from_stage_empty_raises(self):
        wh = FakeStageQueryWarehouse([])
        with self.assertRaisesRegex(ValueError, "No metadata found"):
            await read_metadata_from_stage(wh, "@STAGE/m/")

    async def test_read_boundaries_from_stage_two_rows(self):
        wh = FakeStageQueryWarehouse(
            [
                {
                    "PARTITION_ID": 1,
                    "MIN_VALUE_IN_PARTITION": 0,
                    "MAX_VALUE_IN_PARTITION": 9,
                    "N_ROWS": 5,
                },
                {
                    "PARTITION_ID": 2,
                    "MIN_VALUE_IN_PARTITION": 10,
                    "MAX_VALUE_IN_PARTITION": 19,
                    "N_ROWS": 5,
                },
            ]
        )
        out = await read_boundaries_from_stage(wh, "@STAGE/b/")
        self.assertEqual(len(out), 2)
        self.assertEqual(out[0]["partition_id"], 1)
        self.assertEqual(out[1]["n_rows"], 5)

    async def test_read_boundaries_from_stage_too_few_rows_raises(self):
        wh = FakeStageQueryWarehouse([{"PARTITION_ID": 1, "N_ROWS": 1}])
        with self.assertRaisesRegex(ValueError, "Invalid boundaries"):
            await read_boundaries_from_stage(wh, "@STAGE/b/")

    @patch(
        "data_migration_orchestrator.data_migration_cloud.utils.stage_utils.asyncio.sleep",
        new_callable=AsyncMock,
    )
    async def test_read_schema_from_stage_success(self, _sleep):
        wh = FakeStageQueryWarehouse(
            [
                {
                    "COLUMN_NAME": "c1",
                    "DATA_TYPE": "varchar",
                    "ORDINAL_POSITION": 1,
                    "MAX_LENGTH": 10,
                    "PRECISION": None,
                    "SCALE": None,
                    "IS_NULLABLE": "Y",
                }
            ]
        )
        out = await read_schema_from_stage(wh, "@STAGE/schema/")
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["column_name"], "c1")
        self.assertEqual(out[0]["data_type"], "VARCHAR")
        self.assertEqual(out[0]["ordinal_position"], 1)

    @patch(
        "data_migration_orchestrator.data_migration_cloud.utils.stage_utils.asyncio.sleep",
        new_callable=AsyncMock,
    )
    async def test_read_schema_from_stage_missing_required_field_raises(self, _sleep):
        wh = FakeStageQueryWarehouse([{"COLUMN_NAME": "c1", "DATA_TYPE": "int"}])
        with self.assertRaisesRegex(ValueError, "Missing required schema fields"):
            await read_schema_from_stage(wh, "@STAGE/schema/")
