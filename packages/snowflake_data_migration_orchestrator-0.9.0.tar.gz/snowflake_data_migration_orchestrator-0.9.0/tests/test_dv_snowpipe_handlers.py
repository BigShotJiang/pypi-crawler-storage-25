"""Unit tests for the DV Snowpipe Teardown handler."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.teardown_dv_snowpipe_handler import (
    TeardownDvSnowpipeHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    TeardownDvSnowpipePayload,
)
from data_migration_orchestrator.data_validation_cloud.utils.pipe_utils import (
    DvResultsPipeKey,
    build_dv_pipe_name,
)


def _run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


def _make_task(payload, task_id: int = 123) -> Task:
    return Task(
        workflow_id=payload.workflow_id,
        executor_type=ExecutorType.ORCHESTRATOR,
        task_name="test",
        priority=0.0,
        payload=payload,
        scope="test",
        successor_task_id=None,
        is_blocked=False,
        is_cleanup=False,
        id=task_id,
        status=None,
    )


class TestTeardownDvSnowpipeHandler:
    """Teardown handler issues DROP PIPE IF EXISTS and completes."""

    def test_handle_runs_drop_pipe(self):
        pipe_name = build_dv_pipe_name(42, DvResultsPipeKey.METRICS)
        payload = TeardownDvSnowpipePayload(workflow_id=42, pipe_name=pipe_name)
        task = _make_task(payload)

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(return_value=None)
        task_queue = MagicMock()
        task_queue.complete_task = AsyncMock(return_value=None)

        handler = TeardownDvSnowpipeHandler(
            task_queue=task_queue, warehouse_proxy=warehouse
        )
        _run(handler.handle(task))

        warehouse.execute_sync_query.assert_awaited_once()
        sql = warehouse.execute_sync_query.await_args.args[0]
        assert sql == f"DROP PIPE IF EXISTS {pipe_name}"

        task_queue.complete_task.assert_awaited_once()
