"""Tests for DataValidationWorkflowInitializer."""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from data_migration_orchestrator.data_validation_cloud.data_validation_workflow_initializer import (
    DataValidationWorkflowInitializer,
)
from shared.enums.source_type import SourceType


class TestDvCreateInitialTasksBatchPush(unittest.IsolatedAsyncioTestCase):
    """Initial DV tasks are pushed via a single ``push_tasks_batch`` call."""

    async def test_push_tasks_batch_called_once_for_multiple_tables(self):
        config = {
            "source_platform": "redshift",
            "tables": [
                {"fully_qualified_name": "db.schema.t1"},
                {"fully_qualified_name": "db.schema.t2"},
            ],
        }
        workflow = Workflow(
            id=7,
            name="dv",
            source_platform=SourceType.REDSHIFT,
            target_cloud_type="snowflake:stage",
            target_cloud_stage_name="S",
            target_cloud_url=None,
            schema_version="1",
            workflow_type="data-validation",
            initiator_id="u",
            status=WorkflowStatus.INITIALIZING,
            configuration=config,
            initialization_failures=0,
        )

        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(return_value=[101, 102])

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [
                    {"ID": 201, "SOURCE_IDENTIFIER": "db.schema.t1"},
                    {"ID": 202, "SOURCE_IDENTIFIER": "db.schema.t2"},
                ],
            ]
        )

        init = DataValidationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        await init.create_initial_tasks(workflow)

        task_queue.push_tasks_batch.assert_awaited_once()
        batch_arg = task_queue.push_tasks_batch.call_args[0][0]
        self.assertEqual(len(batch_arg), 2)


if __name__ == "__main__":
    unittest.main()
