import json
import threading
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_orchestrator.orchestrator import (
    LEASE_REFRESH_INTERVAL_SECONDS,
    TASK_PULL_INTERVAL_SECONDS,
    WORK_QUEUE_MULTIPLIER,
    Orchestrator,
)
from data_migration_orchestrator.cloud_orchestrator.worker_context import WorkerContext
from data_migration_orchestrator.cloud_orchestrator.workflows.workflow_type import (
    WorkflowType,
)
from data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer import (
    DataMigrationWorkflowInitializer,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DataMovementTaskPayload,
    ProcessStagedDataTaskPayload,
    TargetType,
)
from data_migration_orchestrator.data_validation_cloud.data_validation_workflow_initializer import (
    DataValidationWorkflowInitializer,
)
from shared.enums.source_type import SourceType


class TestOrchestrator(unittest.IsolatedAsyncioTestCase):
    """
    Test suite for the Orchestrator class.

    This test class validates the Orchestrator functionality,
    particularly the _get_unblocked_tasks method and its
    interaction with the task queue.
    """

    def setUp(self):
        """Set up test fixtures before each test method."""
        self.workflow_id = "test-workflow-123"
        self.mock_task_queue = MagicMock()
        self.mock_warehouse_proxy = MagicMock()
        self.orchestrator = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=self.mock_warehouse_proxy,
            worker_context_factory=MagicMock(),
        )

    async def test_get_unblocked_tasks_empty_queue(self):
        """Test _get_unblocked_tasks when no tasks are available."""
        # Mock task_queue.get_tasks to return empty list
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])

        # Call _get_unblocked_tasks
        tasks = await self.orchestrator._check_unblocked_tasks()

        # Assertions
        self.assertEqual(tasks, [])
        self.mock_task_queue.get_tasks.assert_awaited_once()

    async def test_get_unblocked_tasks_single_task(self):
        """Test _get_unblocked_tasks when one task is available."""
        # Create a mock task
        payload = DataMovementTaskPayload(
            source_type="sql-server",
            source_id="test_db",
            target_type="snowflake:table",
            target_id="MY_DB.MY_SCHEMA.MY_TABLE",
            statement_location_id="SELECT * FROM test_table",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        task = Task(
            id=1,
            workflow_id=self.workflow_id,
            task_name="Test Task",
            executor_type="orchestrator",
            status=TaskStatus.PENDING,
            payload=payload,
            scope="Table[MY_DB.MY_SCHEMA.MY_TABLE]::Extraction",
        )

        # Mock task_queue.get_tasks to return one task
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[task])

        # Call _get_unblocked_tasks
        tasks = await self.orchestrator._check_unblocked_tasks()

        # Assertions
        self.assertEqual(len(tasks), 1)
        self.assertEqual(tasks[0], task)
        self.assertEqual(tasks[0].id, 1)
        self.assertEqual(tasks[0].status, TaskStatus.PENDING)
        self.mock_task_queue.get_tasks.assert_awaited_once()

    async def test_get_unblocked_tasks_multiple_tasks(self):
        """Test _get_unblocked_tasks when multiple tasks are available."""
        # Create multiple mock tasks
        payload1 = DataMovementTaskPayload(
            source_type="teradata",
            source_id="teradata_db",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="MY_DB.MY_SCHEMA.MY_STAGE/file1.parquet",
            statement_location_id="SELECT * FROM table1",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        payload2 = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=200,
            partition_index=0,
            target_table="MY_DB.MY_SCHEMA.TARGET_TABLE",
        )

        payload3 = DataMovementTaskPayload(
            source_type=SourceType.REDSHIFT.value,
            source_id="redshift_db",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="MY_DB.MY_SCHEMA.ANOTHER_TABLE",
            statement_location_id="MY_DB.MY_SCHEMA.MY_STAGE/query.sql",
            database="MY_DB",
            schema="MY_SCHEMA",
            statement_location_type="snowflake:stage",
        )

        tasks = [
            Task(
                id=10,
                workflow_id=self.workflow_id,
                task_name="Task 1",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload1,
                scope="Table[MY_DB.MY_SCHEMA.TABLE1]::Extraction",
            ),
            Task(
                id=20,
                workflow_id=self.workflow_id,
                task_name="Task 2",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload2,
                scope="Table[MY_DB.MY_SCHEMA.TARGET_TABLE]::Loading",
            ),
            Task(
                id=30,
                workflow_id=self.workflow_id,
                task_name="Task 3",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload3,
                scope="Table[MY_DB.MY_SCHEMA.ANOTHER_TABLE]::Extraction",
            ),
        ]

        # Mock task_queue.get_tasks to return multiple tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=tasks)

        # Call _get_unblocked_tasks
        result = await self.orchestrator._check_unblocked_tasks()

        # Assertions
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0].id, 10)
        self.assertEqual(result[1].id, 20)
        self.assertEqual(result[2].id, 30)
        self.mock_task_queue.get_tasks.assert_awaited_once()

    async def test_get_unblocked_tasks_passes_workflow_id(self):
        """Test that _get_unblocked_tasks calls get_tasks correctly."""
        # Mock task_queue.get_tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])

        # Call _get_unblocked_tasks
        await self.orchestrator._check_unblocked_tasks()

        # Verify that get_tasks was called
        self.mock_task_queue.get_tasks.assert_awaited_once()

    async def test_get_unblocked_tasks_with_different_workflow_ids(self):
        """Test _get_unblocked_tasks can be called multiple times."""
        # Reset mock
        self.mock_task_queue.reset_mock()
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])

        # Call _get_unblocked_tasks multiple times
        for _ in range(3):
            await self.orchestrator._check_unblocked_tasks()

        # Verify get_tasks was called multiple times
        self.assertEqual(self.mock_task_queue.get_tasks.await_count, 3)

    async def test_get_unblocked_tasks_returns_list(self):
        """Test that _get_unblocked_tasks always returns a list."""
        # Test with empty result
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])
        result = await self.orchestrator._check_unblocked_tasks()
        self.assertIsInstance(result, list)

        # Test with tasks
        task = Task(
            id=1,
            workflow_id=self.workflow_id,
            task_name="Test Task",
            executor_type="orchestrator",
            status=TaskStatus.PENDING,
            payload=DataMovementTaskPayload(
                source_type="mysql",
                source_id="db",
                target_type="snowflake:table",
                target_id="TABLE",
                statement_location_id="SELECT 1",
                database="MY_DB",
                schema="MY_SCHEMA",
            ),
            scope="Table[MY_DB.MY_SCHEMA.TABLE]::Extraction",
        )
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[task])
        result = await self.orchestrator._check_unblocked_tasks()
        self.assertIsInstance(result, list)

    async def test_get_unblocked_tasks_preserves_task_order(self):
        """Test that _get_unblocked_tasks preserves the order of tasks."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=50,
            partition_metadata_id=100,
            partition_index=0,
            target_table="target",
        )

        # Create tasks with specific order
        task_ids = [100, 50, 75, 25, 200]
        tasks = [
            Task(
                id=task_id,
                workflow_id=self.workflow_id,
                task_name=f"Task {task_id}",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload,
                scope=f"Table[target]::Partition[{task_id}]::Loading",
            )
            for task_id in task_ids
        ]

        # Mock task_queue.get_tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=tasks)

        # Call _get_unblocked_tasks
        result = await self.orchestrator._check_unblocked_tasks()

        # Verify order is preserved
        result_ids = [task.id for task in result]
        self.assertEqual(result_ids, task_ids)

    async def test_get_unblocked_tasks_handles_exceptions(self):
        """Test that _get_unblocked_tasks propagates exceptions from task_queue."""
        # Mock task_queue.get_tasks to raise an exception
        self.mock_task_queue.get_tasks = AsyncMock(
            side_effect=Exception("Database connection error")
        )

        # Verify exception is propagated
        with self.assertRaises(Exception) as context:
            await self.orchestrator._check_unblocked_tasks()

        self.assertIn("Database connection error", str(context.exception))

    async def test_get_unblocked_tasks_does_not_modify_tasks(self):
        """Test that _get_unblocked_tasks returns tasks without modification."""
        # Create a task with specific attributes
        original_payload = DataMovementTaskPayload(
            source_type="oracle",
            source_id="oracle_db",
            target_type="snowflake:table",
            target_id="MY_DB.MY_SCHEMA.MY_TABLE",
            statement_location_id="SELECT * FROM employees",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        original_task = Task(
            id=42,
            workflow_id=self.workflow_id,
            task_name="Original Task",
            executor_type="orchestrator",
            status=TaskStatus.PENDING,
            payload=original_payload,
            successor_task_id=100,
            scope="Table[MY_DB.MY_SCHEMA.MY_TABLE]::Extraction",
        )

        # Mock task_queue.get_tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[original_task])

        # Call _get_unblocked_tasks
        result = await self.orchestrator._check_unblocked_tasks()

        # Verify task is returned unchanged
        returned_task = result[0]
        self.assertEqual(returned_task.id, original_task.id)
        self.assertEqual(returned_task.status, original_task.status)
        self.assertEqual(returned_task.payload, original_payload)
        self.assertEqual(
            returned_task.successor_task_id, original_task.successor_task_id
        )

    async def test_get_unblocked_tasks_is_async(self):
        """Test that _get_unblocked_tasks is an async method."""
        import inspect

        self.assertTrue(
            inspect.iscoroutinefunction(self.orchestrator._check_unblocked_tasks)
        )

    async def test_get_unblocked_tasks_awaits_task_queue(self):
        """Test that _get_unblocked_tasks properly awaits the task_queue call."""
        # Create a mock that tracks if it was awaited
        mock_coro = AsyncMock(return_value=[])
        self.mock_task_queue.get_tasks = mock_coro

        # Call _get_unblocked_tasks
        await self.orchestrator._check_unblocked_tasks()

        # Verify the async method was awaited
        mock_coro.assert_awaited_once()

    async def test_get_unblocked_tasks_with_mixed_task_types(self):
        """Test _get_unblocked_tasks with different task payload types."""
        # Create tasks with different payload types
        data_movement_payload = DataMovementTaskPayload(
            source_type="postgresql",
            source_id="postgres_db",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="STAGE/file.parquet",
            statement_location_id="SELECT * FROM users",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        process_staged_payload = ProcessStagedDataTaskPayload(
            table_metadata_id=75,
            partition_metadata_id=150,
            partition_index=1,
            target_table="TARGET_TABLE",
        )

        tasks = [
            Task(
                id=1,
                workflow_id=self.workflow_id,
                task_name="Data Movement Task",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=data_movement_payload,
                scope="Table[MY_DB.MY_SCHEMA.USERS]::Extraction",
            ),
            Task(
                id=2,
                workflow_id=self.workflow_id,
                task_name="Process Staged Task",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=process_staged_payload,
                scope="Table[TARGET_TABLE]::Loading",
            ),
        ]

        # Mock task_queue.get_tasks
        self.mock_task_queue.get_tasks = AsyncMock(return_value=tasks)

        # Call _get_unblocked_tasks
        result = await self.orchestrator._check_unblocked_tasks()

        # Verify both tasks are returned with correct types
        self.assertEqual(len(result), 2)
        self.assertIsInstance(result[0].payload, DataMovementTaskPayload)
        self.assertIsInstance(result[1].payload, ProcessStagedDataTaskPayload)


class TestOrchestratorBackpressure(unittest.IsolatedAsyncioTestCase):
    """Tests for backpressure on task pulling."""

    def setUp(self):
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])
        self.orchestrator = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
            max_task_workers=4,
        )

    async def test_skips_pull_when_queue_full(self):
        """When the work queue is at full capacity, no tasks should be pulled."""
        full = 4 * WORK_QUEUE_MULTIPLIER
        for _ in range(full):
            self.orchestrator._work_queue.put("dummy")

        tasks = await self.orchestrator._check_unblocked_tasks()

        self.assertEqual(tasks, [])
        self.mock_task_queue.get_tasks.assert_not_awaited()

    async def test_pulls_remaining_capacity(self):
        """Should pull up to the remaining buffer capacity."""
        for _ in range(10):
            self.orchestrator._work_queue.put("dummy")

        await self.orchestrator._check_unblocked_tasks()

        expected = 4 * WORK_QUEUE_MULTIPLIER - 10
        self.mock_task_queue.get_tasks.assert_awaited_once_with(max_tasks=expected)

    async def test_pulls_full_buffer_when_queue_empty(self):
        """When no tasks are in the work queue, pull up to full buffer."""
        await self.orchestrator._check_unblocked_tasks()

        expected = 4 * WORK_QUEUE_MULTIPLIER
        self.mock_task_queue.get_tasks.assert_awaited_once_with(max_tasks=expected)


class TestOrchestratorBookkeeping(unittest.IsolatedAsyncioTestCase):
    """Tests for bookkeeping cycle."""

    def setUp(self):
        self.mock_task_queue = MagicMock()
        self.mock_task_queue.expire_stale_initializations = AsyncMock()
        self.mock_task_queue.refresh_active_leases = AsyncMock()
        self.mock_task_queue.expire_leases = AsyncMock()
        self.mock_task_queue.refresh_warehouse_tasks = AsyncMock()
        self.orchestrator = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )

    async def test_bookkeeping_calls_expire_leases(self):
        """Bookkeeping should still call expire_leases for recovery."""
        await self.orchestrator._do_book_keeping_for_tasks()

        self.mock_task_queue.expire_leases.assert_awaited_once()

    async def test_bookkeeping_refreshes_active_task_leases(self):
        """Bookkeeping should refresh leases for tasks workers are processing."""
        self.orchestrator._register_active_task(101)
        self.orchestrator._register_active_task(202)

        await self.orchestrator._do_book_keeping_for_tasks()

        self.mock_task_queue.refresh_active_leases.assert_awaited_once_with({101, 202})

    async def test_bookkeeping_refreshes_enqueued_task_leases(self):
        """Bookkeeping should refresh leases for tasks waiting in the work queue."""
        with self.orchestrator._active_tasks_lock:
            self.orchestrator._enqueued_task_ids.add(301)
            self.orchestrator._enqueued_task_ids.add(302)

        await self.orchestrator._do_book_keeping_for_tasks()

        self.mock_task_queue.refresh_active_leases.assert_awaited_once_with({301, 302})

    async def test_bookkeeping_refreshes_both_active_and_enqueued(self):
        """Bookkeeping should union active and enqueued IDs for lease refresh."""
        self.orchestrator._register_active_task(101)
        with self.orchestrator._active_tasks_lock:
            self.orchestrator._enqueued_task_ids.add(201)

        await self.orchestrator._do_book_keeping_for_tasks()

        self.mock_task_queue.refresh_active_leases.assert_awaited_once_with({101, 201})

    async def test_bookkeeping_skips_refresh_when_no_leased_tasks(self):
        """No active or enqueued tasks means no refresh_active_leases call."""
        await self.orchestrator._do_book_keeping_for_tasks()

        self.mock_task_queue.refresh_active_leases.assert_not_awaited()

    async def test_refresh_before_expire_ordering(self):
        """Active lease refresh must happen before expire_leases."""
        self.orchestrator._register_active_task(1)
        call_order = []
        self.mock_task_queue.refresh_active_leases = AsyncMock(
            side_effect=lambda ids: call_order.append("refresh")
        )
        self.mock_task_queue.expire_leases = AsyncMock(
            side_effect=lambda: call_order.append("expire")
        )

        await self.orchestrator._do_book_keeping_for_tasks()

        self.assertEqual(call_order[:2], ["refresh", "expire"])


class TestActiveTaskTracking(unittest.IsolatedAsyncioTestCase):
    """Tests for per-task lease refresh via active task tracking."""

    def setUp(self):
        self.orchestrator = Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )

    def test_register_and_unregister(self):
        self.orchestrator._register_active_task(42)
        self.assertIn(42, self.orchestrator._active_task_ids)

        self.orchestrator._unregister_active_task(42)
        self.assertNotIn(42, self.orchestrator._active_task_ids)

    def test_unregister_nonexistent_is_safe(self):
        self.orchestrator._unregister_active_task(999)

    def test_multiple_tasks_tracked(self):
        self.orchestrator._register_active_task(1)
        self.orchestrator._register_active_task(2)
        self.orchestrator._register_active_task(3)
        self.assertEqual(self.orchestrator._active_task_ids, {1, 2, 3})

    def test_promote_to_active_moves_from_enqueued(self):
        """promote_to_active should move a task from enqueued to active set."""
        with self.orchestrator._active_tasks_lock:
            self.orchestrator._enqueued_task_ids.add(42)

        self.orchestrator._promote_to_active(42)

        self.assertIn(42, self.orchestrator._active_task_ids)
        self.assertNotIn(42, self.orchestrator._enqueued_task_ids)

    def test_unregister_clears_from_both_sets(self):
        """Unregister should remove from both active and enqueued sets."""
        self.orchestrator._register_active_task(10)
        with self.orchestrator._active_tasks_lock:
            self.orchestrator._enqueued_task_ids.add(10)

        self.orchestrator._unregister_active_task(10)

        self.assertNotIn(10, self.orchestrator._active_task_ids)
        self.assertNotIn(10, self.orchestrator._enqueued_task_ids)

    def test_enqueue_tasks_tracks_ids(self):
        """_enqueue_tasks should add task IDs to the enqueued set."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=1,
            partition_metadata_id=2,
            partition_index=0,
            target_table="t",
        )
        tasks = [
            Task(
                id=5,
                workflow_id="w",
                task_name="t1",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload,
                scope="s1",
            ),
            Task(
                id=6,
                workflow_id="w",
                task_name="t2",
                executor_type="orchestrator",
                status=TaskStatus.PENDING,
                payload=payload,
                scope="s2",
            ),
        ]

        self.orchestrator._enqueue_tasks(tasks)

        self.assertEqual(self.orchestrator._enqueued_task_ids, {5, 6})
        self.assertEqual(self.orchestrator._work_queue.qsize(), 2)

    def test_concurrent_register_unregister(self):
        """Verify no corruption when multiple threads register/unregister simultaneously."""
        import threading

        errors: list[Exception] = []
        tasks_per_thread = 200
        num_threads = 8

        def worker(offset: int):
            try:
                for i in range(tasks_per_thread):
                    tid = offset + i
                    self.orchestrator._register_active_task(tid)
                for i in range(tasks_per_thread):
                    tid = offset + i
                    self.orchestrator._unregister_active_task(tid)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=worker, args=(t * tasks_per_thread,))
            for t in range(num_threads)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(errors, [])
        self.assertEqual(self.orchestrator._active_task_ids, set())


class TestOrchestratorExecuteWorkflowCycle(unittest.IsolatedAsyncioTestCase):
    """Single-cycle wiring: bookkeeping and workflows only (task pull is on its own thread)."""

    def setUp(self):
        self.mock_task_queue = MagicMock()
        self.orch = Orchestrator(
            task_queue=self.mock_task_queue,
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )

    async def test_execute_workflow_cycle_runs_bookkeeping_then_workflows(self):
        order: list[str] = []

        async def bk():
            order.append("bk")

        async def hw():
            order.append("hw")

        with (
            patch.object(self.orch, "_do_book_keeping_for_tasks", side_effect=bk),
            patch.object(self.orch, "_handle_workflows", side_effect=hw),
        ):
            await self.orch.execute_workflow_cycle()

        self.assertEqual(order, ["bk", "hw"])

    async def test_execute_workflow_cycle_does_not_pull_tasks(self):
        """Task pulling is handled by the dedicated pull thread, not the cycle."""
        self.mock_task_queue.get_tasks = AsyncMock(return_value=[])
        with (
            patch.object(
                self.orch, "_do_book_keeping_for_tasks", new_callable=AsyncMock
            ),
            patch.object(self.orch, "_handle_workflows", new_callable=AsyncMock),
        ):
            await self.orch.execute_workflow_cycle()

        self.mock_task_queue.get_tasks.assert_not_awaited()


class TestOrchestratorFactoryAndHelpers(unittest.TestCase):
    """Initializer factory registration and small helpers."""

    def test_create_workflow_initializer_factory_registers_dm_and_dv(self):
        orch = Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )
        factory = orch._create_workflow_initializer_factory()
        dm = factory.get_initializer(WorkflowType.DATA_MIGRATION)
        dv = factory.get_initializer(WorkflowType.DATA_VALIDATION)
        self.assertIsInstance(dm, DataMigrationWorkflowInitializer)
        self.assertIsInstance(dv, DataValidationWorkflowInitializer)

    def test_build_detailed_error_message(self):
        orch = Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )
        msg = orch._build_detailed_error_message(ValueError("boom"))
        self.assertEqual(msg, "ValueError: boom")


class TestOrchestratorExecuteTaskWithContext(unittest.IsolatedAsyncioTestCase):
    """Orchestrator must reject DEA-style payloads (guard rails)."""

    async def test_data_movement_task_fails_via_task_queue(self):
        orch = Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )
        mock_tq = MagicMock()
        mock_tq.fail_task = AsyncMock()
        mock_tq.connection = MagicMock()
        ctx = WorkerContext(
            task_queue=mock_tq,
            warehouse=MagicMock(),
            handler_factory=MagicMock(),
            dv_handler_factory=None,
        )
        payload = DataMovementTaskPayload(
            source_type="sql-server",
            source_id="x",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="@st/p/",
            statement_location_id="SELECT 1",
            database="D",
            schema="S",
        )
        task = Task(
            id=7,
            workflow_id=1,
            task_name="move",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.PENDING,
            payload=payload,
            scope="scope",
        )
        await orch._execute_task_with_context(task, ctx)
        mock_tq.fail_task.assert_awaited_once()
        call_kw = mock_tq.fail_task.await_args
        self.assertEqual(call_kw.args[0], ExecutorType.ORCHESTRATOR.value)
        self.assertEqual(call_kw.args[1], 7)
        self.assertIn("data_movement", call_kw.args[2])


class TestLeaseRefreshThread(unittest.TestCase):
    """Tests for the dedicated lease-refresh background thread."""

    def _make_orchestrator(self, context_factory=None):
        if context_factory is None:
            mock_ctx = MagicMock()
            mock_ctx.connection.cursor.return_value.__enter__ = MagicMock()
            mock_ctx.connection.cursor.return_value.__exit__ = MagicMock(
                return_value=False
            )
            context_factory = MagicMock(return_value=mock_ctx)
        return Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=context_factory,
        )

    def test_start_workers_launches_refresh_thread(self):
        """_start_workers should create and start the lease-refresh thread."""
        orch = self._make_orchestrator()
        orch._start_workers()
        try:
            self.assertIsNotNone(orch._lease_refresh_thread)
            self.assertTrue(orch._lease_refresh_thread.is_alive())
            self.assertEqual(
                orch._lease_refresh_thread.name, "orchestrator-lease-refresh"
            )
        finally:
            orch.stop()

    def test_stop_terminates_refresh_thread(self):
        """stop() should signal and join the lease-refresh thread."""
        orch = self._make_orchestrator()
        orch._start_workers()
        thread = orch._lease_refresh_thread
        self.assertTrue(thread.is_alive())

        orch.stop()

        self.assertTrue(orch._lease_refresh_stop.is_set())
        self.assertFalse(thread.is_alive())

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.orchestrator.qualified_migration_schema",
        return_value="DB.SCHEMA",
    )
    def test_refresh_loop_executes_update_for_active_ids(self, _mock_qm):
        """The refresh loop should UPDATE leasing time for active+enqueued IDs."""
        mock_cursor = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.connection.cursor.return_value.__enter__.return_value = mock_cursor
        factory = MagicMock(return_value=mock_ctx)

        orch = self._make_orchestrator(context_factory=factory)
        orch._register_active_task(101)
        with orch._active_tasks_lock:
            orch._enqueued_task_ids.add(202)

        # Let the loop body run once, then signal stop during wait()
        def stop_on_wait(timeout):
            orch._lease_refresh_stop.set()
            return True

        orch._lease_refresh_stop.wait = stop_on_wait
        orch._lease_refresh_loop()

        calls = mock_cursor.execute.call_args_list
        # First call: baseline version tag, second call: lease refresh UPDATE
        self.assertEqual(len(calls), 2)
        sql = calls[1][0][0]
        self.assertIn("UPDATE DB.SCHEMA.TASK_QUEUE", sql)
        self.assertIn("SET LEASING_TIME = SYSDATE()", sql)
        self.assertIn("101", sql)
        self.assertIn("202", sql)
        self.assertIn("executing", sql)

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.orchestrator.qualified_migration_schema",
        return_value="DB.SCHEMA",
    )
    def test_refresh_loop_skips_when_no_ids(self, _mock_qm):
        """No SQL should execute when there are no active or enqueued tasks."""
        mock_cursor = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.connection.cursor.return_value.__enter__.return_value = mock_cursor
        factory = MagicMock(return_value=mock_ctx)

        orch = self._make_orchestrator(context_factory=factory)

        def stop_on_wait(timeout):
            orch._lease_refresh_stop.set()
            return True

        orch._lease_refresh_stop.wait = stop_on_wait
        orch._lease_refresh_loop()

        # Only the baseline version tag ALTER SESSION should have been executed
        calls = mock_cursor.execute.call_args_list
        self.assertEqual(len(calls), 1)
        self.assertIn("ALTER SESSION SET QUERY_TAG", calls[0][0][0])

    @patch(
        "data_migration_orchestrator.cloud_orchestrator.orchestrator.qualified_migration_schema",
        return_value="DB.SCHEMA",
    )
    def test_refresh_loop_survives_exceptions(self, _mock_qm):
        """An exception during SQL execution should be caught; the loop continues."""
        call_count = 0

        mock_ctx = MagicMock()

        def cursor_side_effect():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("Snowflake blip")
            # Second call succeeds — but by then stop is set
            cm = MagicMock()
            cm.__enter__ = MagicMock(return_value=MagicMock())
            cm.__exit__ = MagicMock(return_value=False)
            return cm

        mock_ctx.connection.cursor = MagicMock(side_effect=cursor_side_effect)
        factory = MagicMock(return_value=mock_ctx)

        orch = self._make_orchestrator(context_factory=factory)
        orch._register_active_task(1)

        stop_event = orch._lease_refresh_stop

        # Let the loop run, fail once, then stop
        def stop_after_second_iteration():
            while call_count < 2:
                pass
            stop_event.set()

        stopper = threading.Thread(target=stop_after_second_iteration)

        # Override the interval to run quickly
        with patch(
            "data_migration_orchestrator.cloud_orchestrator.orchestrator.LEASE_REFRESH_INTERVAL_SECONDS",
            0.01,
        ):
            stopper.start()
            orch._lease_refresh_loop()
            stopper.join(timeout=5)

        self.assertGreaterEqual(call_count, 2)

    def test_refresh_loop_closes_connection_on_exit(self):
        """The connection should always be closed when the loop exits."""
        mock_ctx = MagicMock()
        factory = MagicMock(return_value=mock_ctx)

        orch = self._make_orchestrator(context_factory=factory)

        def stop_on_wait(timeout):
            orch._lease_refresh_stop.set()
            return True

        orch._lease_refresh_stop.wait = stop_on_wait
        orch._lease_refresh_loop()

        mock_ctx.connection.close.assert_called_once()

    def test_lease_refresh_interval_constant(self):
        self.assertEqual(LEASE_REFRESH_INTERVAL_SECONDS, 60)


class TestTaskPullThread(unittest.TestCase):
    """Tests for the dedicated task-pull background thread."""

    def _make_orchestrator(self, context_factory=None):
        if context_factory is None:
            mock_ctx = MagicMock()
            mock_ctx.connection.cursor.return_value.__enter__ = MagicMock()
            mock_ctx.connection.cursor.return_value.__exit__ = MagicMock(
                return_value=False
            )
            context_factory = MagicMock(return_value=mock_ctx)
        return Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=context_factory,
            max_task_workers=4,
        )

    def test_start_workers_launches_pull_thread(self):
        """_start_workers should create and start the task-pull thread."""
        orch = self._make_orchestrator()
        orch._start_workers()
        try:
            self.assertIsNotNone(orch._task_pull_thread)
            self.assertTrue(orch._task_pull_thread.is_alive())
            self.assertEqual(orch._task_pull_thread.name, "orchestrator-task-pull")
        finally:
            orch.stop()

    def test_stop_terminates_pull_thread(self):
        """stop() should signal and join the task-pull thread."""
        orch = self._make_orchestrator()
        orch._start_workers()
        thread = orch._task_pull_thread
        self.assertTrue(thread.is_alive())

        orch.stop()

        self.assertTrue(orch._task_pull_stop.is_set())
        self.assertFalse(thread.is_alive())

    def test_pull_loop_calls_get_tasks_and_enqueues(self):
        """The pull loop should call get_tasks and enqueue returned tasks."""
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=1,
            partition_metadata_id=2,
            partition_index=0,
            target_table="t",
        )
        task = Task(
            id=42,
            workflow_id=1,
            task_name="pulled-task",
            executor_type="orchestrator",
            status=TaskStatus.PENDING,
            payload=payload,
            scope="s",
        )

        mock_ctx = MagicMock()
        factory = MagicMock(return_value=mock_ctx)
        mock_task_queue = MagicMock()
        mock_task_queue.get_tasks = AsyncMock(return_value=[task])

        orch = self._make_orchestrator(context_factory=factory)
        orch.task_queue = mock_task_queue

        def stop_on_wait(timeout):
            orch._task_pull_stop.set()
            return True

        orch._task_pull_stop.wait = stop_on_wait
        orch._task_pull_loop()

        mock_task_queue.get_tasks.assert_awaited_once()
        self.assertIn(42, orch._enqueued_task_ids)
        self.assertEqual(orch._work_queue.qsize(), 1)

    def test_pull_loop_skips_when_queue_full(self):
        """When the work queue is full, get_tasks should not be called."""
        mock_ctx = MagicMock()
        factory = MagicMock(return_value=mock_ctx)
        mock_task_queue = MagicMock()
        mock_task_queue.get_tasks = AsyncMock(return_value=[])

        orch = self._make_orchestrator(context_factory=factory)
        orch.task_queue = mock_task_queue

        full = 4 * WORK_QUEUE_MULTIPLIER
        for _ in range(full):
            orch._work_queue.put("dummy")

        def stop_on_wait(timeout):
            orch._task_pull_stop.set()
            return True

        orch._task_pull_stop.wait = stop_on_wait
        orch._task_pull_loop()

        mock_task_queue.get_tasks.assert_not_awaited()

    def test_pull_loop_survives_exceptions(self):
        """An exception during get_tasks should be caught; the loop continues."""
        call_count = 0
        original_get_tasks = AsyncMock(side_effect=RuntimeError("Snowflake blip"))

        mock_ctx = MagicMock()
        factory = MagicMock(return_value=mock_ctx)
        mock_task_queue = MagicMock()

        def counting_get_tasks(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            return original_get_tasks(*args, **kwargs)

        mock_task_queue.get_tasks = counting_get_tasks

        orch = self._make_orchestrator(context_factory=factory)
        orch.task_queue = mock_task_queue

        stop_event = orch._task_pull_stop

        def stop_after_second_iteration():
            while call_count < 2:
                pass
            stop_event.set()

        stopper = threading.Thread(target=stop_after_second_iteration)
        orch._task_pull_interval_seconds = 0.01

        stopper.start()
        orch._task_pull_loop()
        stopper.join(timeout=5)

        self.assertGreaterEqual(call_count, 2)

    def test_pull_loop_closes_connection_on_exit(self):
        """The connection should always be closed when the loop exits."""
        mock_ctx = MagicMock()
        factory = MagicMock(return_value=mock_ctx)

        orch = self._make_orchestrator(context_factory=factory)

        def stop_on_wait(timeout):
            orch._task_pull_stop.set()
            return True

        orch._task_pull_stop.wait = stop_on_wait
        orch._task_pull_loop()

        mock_ctx.connection.close.assert_called_once()

    def test_pull_loop_registers_thread_connection(self):
        """The pull loop should register its connection for thread-local use."""
        mock_ctx = MagicMock()
        factory = MagicMock(return_value=mock_ctx)
        mock_task_queue = MagicMock()
        mock_task_queue.get_tasks = AsyncMock(return_value=[])

        orch = self._make_orchestrator(context_factory=factory)
        orch.task_queue = mock_task_queue

        def stop_on_wait(timeout):
            orch._task_pull_stop.set()
            return True

        orch._task_pull_stop.wait = stop_on_wait
        orch._task_pull_loop()

        mock_task_queue.register_thread_connection.assert_called_once_with(
            mock_ctx.connection
        )

    def test_task_pull_interval_constant(self):
        self.assertEqual(TASK_PULL_INTERVAL_SECONDS, 20)


class TestExecuteTaskQueryTag(unittest.IsolatedAsyncioTestCase):
    """Verify that _execute_task_with_context sets/restores query tags."""

    def _make_ctx(self):
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        mock_tq = MagicMock()
        mock_tq.fail_task = AsyncMock()
        mock_tq.connection = mock_conn

        mock_handler = AsyncMock()
        mock_handler_factory = MagicMock()
        mock_handler_factory.get_handler.return_value = mock_handler

        ctx = WorkerContext(
            task_queue=mock_tq,
            warehouse=MagicMock(),
            handler_factory=mock_handler_factory,
            dv_handler_factory=None,
        )
        return ctx, mock_cursor, mock_handler

    async def test_sets_task_tag_then_restores_version_tag(self):
        """Task-level tag should be set before handler, version tag restored after."""
        ctx, mock_cursor, mock_handler = self._make_ctx()
        orch = Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=1,
            partition_metadata_id=2,
            partition_index=0,
            target_table="t",
        )
        task = Task(
            id=42,
            workflow_id=7,
            task_name="test-task",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            payload=payload,
            scope="scope",
        )

        await orch._execute_task_with_context(task, ctx)

        calls = mock_cursor.execute.call_args_list
        self.assertGreaterEqual(len(calls), 2)

        # First call: task-level tag
        first_sql = calls[0][0][0]
        self.assertIn("ALTER SESSION SET QUERY_TAG", first_sql)
        first_tag = json.loads(first_sql.split("'", 1)[1].rsplit("'", 1)[0])
        self.assertEqual(first_tag["DMVF_WORKFLOW_ID"], "7")
        self.assertEqual(first_tag["DMVF_TASK_ID"], "42")
        self.assertIn("DMVF_ORCHESTRATOR_VERSION", first_tag)

        # Last call: restore baseline version tag
        last_sql = calls[-1][0][0]
        self.assertIn("ALTER SESSION SET QUERY_TAG", last_sql)
        last_tag = json.loads(last_sql.split("'", 1)[1].rsplit("'", 1)[0])
        self.assertIn("DMVF_VERSION", last_tag)
        self.assertNotIn("DMVF_WORKFLOW_ID", last_tag)

    async def test_restores_version_tag_on_handler_error(self):
        """Version tag must be restored even when the handler raises."""
        ctx, mock_cursor, mock_handler = self._make_ctx()
        mock_handler.handle.side_effect = RuntimeError("boom")
        orch = Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=MagicMock(),
        )

        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=1,
            partition_metadata_id=2,
            partition_index=0,
            target_table="t",
        )
        task = Task(
            id=99,
            workflow_id=5,
            task_name="fail-task",
            executor_type=ExecutorType.ORCHESTRATOR,
            status=TaskStatus.EXECUTING,
            payload=payload,
            scope="scope",
        )

        await orch._execute_task_with_context(task, ctx)

        calls = mock_cursor.execute.call_args_list
        last_sql = calls[-1][0][0]
        last_tag = json.loads(last_sql.split("'", 1)[1].rsplit("'", 1)[0])
        self.assertIn("DMVF_VERSION", last_tag)
        self.assertNotIn("DMVF_WORKFLOW_ID", last_tag)


class TestLeaseRefreshQueryTag(unittest.TestCase):
    """Verify the lease-refresh loop sets the baseline version tag."""

    def test_sets_baseline_version_tag(self):
        mock_cursor = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.connection.cursor.return_value.__enter__ = MagicMock(
            return_value=mock_cursor
        )
        mock_ctx.connection.cursor.return_value.__exit__ = MagicMock(return_value=False)
        factory = MagicMock(return_value=mock_ctx)

        orch = Orchestrator(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
            worker_context_factory=factory,
        )

        def stop_on_wait(timeout):
            orch._lease_refresh_stop.set()
            return True

        orch._lease_refresh_stop.wait = stop_on_wait
        orch._lease_refresh_loop()

        first_sql = mock_cursor.execute.call_args_list[0][0][0]
        self.assertIn("ALTER SESSION SET QUERY_TAG", first_sql)
        tag = json.loads(first_sql.split("'", 1)[1].rsplit("'", 1)[0])
        self.assertIn("DMVF_VERSION", tag)


class TestTaskPullQueryTag(unittest.TestCase):
    """Verify the task-pull loop sets the baseline version tag."""

    def test_sets_baseline_version_tag(self):
        mock_cursor = MagicMock()
        mock_ctx = MagicMock()
        mock_ctx.connection.cursor.return_value.__enter__ = MagicMock(
            return_value=mock_cursor
        )
        mock_ctx.connection.cursor.return_value.__exit__ = MagicMock(return_value=False)
        factory = MagicMock(return_value=mock_ctx)
        mock_task_queue = MagicMock()
        mock_task_queue.get_tasks = AsyncMock(return_value=[])

        orch = Orchestrator(
            task_queue=mock_task_queue,
            warehouse_proxy=MagicMock(),
            worker_context_factory=factory,
        )

        def stop_on_wait(timeout):
            orch._task_pull_stop.set()
            return True

        orch._task_pull_stop.wait = stop_on_wait
        orch._task_pull_loop()

        first_sql = mock_cursor.execute.call_args_list[0][0][0]
        self.assertIn("ALTER SESSION SET QUERY_TAG", first_sql)
        tag = json.loads(first_sql.split("'", 1)[1].rsplit("'", 1)[0])
        self.assertIn("DMVF_VERSION", tag)


if __name__ == "__main__":
    unittest.main()
