# Snowflake Data Migration Orchestrator

[![Python](https://img.shields.io/badge/python-3.11+-blue)](https://www.python.org/downloads/)

The Cloud Data Migration feature of SnowConvert provides a fault-tolerant, scalable solution for moving data from external sources into **Snowflake**. This tool is specifically designed for cases where a user is moving data from a system they plan to decommission. For replication purposes, other solutions are available that might better fit your use case.

## Architecture

- 1 **Orchestrator** is connected to the **Snowflake Account**.
  - It requires privileges to create/operate the **SNOWCONVERT_AI** database, in which metadata is stored.
- 1 or more **Workers** connect to the **Source System** and to the **Snowflake Account**.
  - **Workers** read data from the **Source System** and upload it to a **Snowflake Stage**.
  - **Workers** pick up tasks created by the **Orchestrator** and process them in parallel.
- Files uploaded to the Snowflake Stage are copied into the **Target Tables** using a [COPY INTO](https://docs.snowflake.com/en/sql-reference/sql/copy-into-table) statement.
  - The [COPY INTO](https://docs.snowflake.com/en/sql-reference/sql/copy-into-table) statement is submitted and monitored by the **Orchestrator**.

### Where to Deploy Orchestrator and Worker(s)?

The **Orchestrator** and **Worker(s)** can be deployed in multiple ways:

1. Both on [Snowpark Container Services](https://docs.snowflake.com/en/developer-guide/snowpark-container-services/overview) (in the **Snowflake Account**).
2. Both on the **Customer's Environment** (custom hardware, virtual machines, containers, etc.).
3. **Orchestrator** on [Snowpark Container Services](https://docs.snowflake.com/en/developer-guide/snowpark-container-services/overview) and **Worker(s)** on the **Customer's Environment** (or the other way around).

Requirements for the environment:

- The **Orchestrator** and **Worker(s)** are **Python packages**, so Python must be installed.
- The **Worker(s)** will typically require an **ODBC** driver to connect to the **Source System**.
- The **Orchestrator** needs to be able to connect to the **Snowflake Account**. The connection used must have privileges to create the **SNOWCONVERT_AI** database and create schemas/objects on that database.

## Setup

### Additional Configuration on Snowflake Account

When starting the Orchestrator, it will automatically try to set up resources in your Snowflake Account in the **SNOWCONVERT_AI** database (if it does not exist yet, it will be created). This is a one-time step and transparent to the user. Some considerations:

- The **Orchestrator** should connect with a role that has privileges to create the **SNOWCONVERT_AI** database and its objects.
- Whenever the **Orchestrator** starts, it should use a role that allows it to interact with the **SNOWCONVERT_AI** database and its resources. The easiest way to guarantee this is to always run it with the same role that was used for creating **SNOWCONVERT_AI** in the first place.

## Usage

In general, for migrating data using this solution, you will need to:

1. Start the **Orchestrator**.
2. Start the **Worker(s)**.
3. Create a **Data Migration Workflow**.
4. Monitor the **Data Migration Workflow** (asynchronously) until completion.

A **Data Migration Workflow** is essentially an action/goal for the system to complete, such as migrating a specific set of tables with a given configuration. You can submit multiple workflows simultaneously and monitor them. The Orchestrator breaks Data Migration Workflows into smaller tasks. Normally, this also involves splitting a table into partitions before extracting its data and loading it to **Snowflake**.

### Starting the Orchestrator

After installation, start the Orchestrator by running:

```shell
python -m data_migration_orchestrator start
```

When invoked without a subcommand, `start` is assumed for backward compatibility.

The `start` command accepts optional flags:

| Flag | Default | Description |
|------|---------|-------------|
| `--log-destination` | `both` | Where to send logs: `stdout`, `file`, or `both`. |
| `--log-file` | `logs/data_migration_orchestrator.log` | Path to the log file (used when destination includes `file`). |
| `--log-level` | `INFO` | Logging level: `DEBUG`, `INFO`, `WARNING`, `ERROR`, or `CRITICAL`. |

Before running, make sure that the **SNOWFLAKE_CONNECTION_NAME** environment variable is set to a value that matches one of the connection names in your Snowflake [config.toml](https://docs.snowflake.com/en/developer-guide/snowflake-cli/connecting/configure-connections) or [connections.toml](https://docs.snowflake.com/en/developer-guide/snowflake-cli/connecting/configure-connections). That is the name of the connection used to connect to the **Target Snowflake Account**.

**Connection** session defaults use `SNOWFLAKE_DATABASE` and `SNOWFLAKE_SCHEMA` where your environment provides them (for example in SPCS). Those are separate from **metadata object locations**: by default, workflow and task-queue objects live in `SNOWCONVERT_AI.DATA_MIGRATION` and data-validation objects in `SNOWCONVERT_AI.DATA_VALIDATION`. To deploy metadata under different database or schema names, set:

- `CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA` (default `SNOWCONVERT_AI`)
- `CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA` (default `DATA_MIGRATION`)
- `CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA` (default `DATA_VALIDATION`)

Workers that call task-queue stored procedures must use the same `CUSTOM_*` values as the orchestrator.

The **Orchestrator** will run until you stop it. **Data Migration Workflows** need an active **Orchestrator** to be completed. However, the **Orchestrator** can be safely stopped at any point and resumed later (ongoing **Data Migration Workflows** will be resumed at that point).

### Starting the Worker(s)

After installation (`pip install snowflake-data-exchange-agent`), start a Worker by running:

```shell
data-exchange-agent run -c <configuration-file-path>
```

The `-c` flag can be omitted; in that case, the worker will look for a file called **configuration.toml** in your current directory. When invoked without a subcommand (`data-exchange-agent -c ...`), `run` is assumed for backward compatibility. See the [Worker Configuration](#worker-configuration) section below for the full specification.

You can also verify connectivity before starting:

```shell
data-exchange-agent test -c <configuration-file-path>
```

This executes `SELECT 1` on every configured source and target connection and reports the results.

**Workers** will run until you stop them. **Data Migration Workflows** and **Cloud Data Validation Workflows** need at least one active **Worker** to be completed. However, the **Workers** can be safely stopped at any point and resumed later (ongoing workflows will be resumed at that point).

### Creating a Data Migration Workflow

After installation, create workflows by running:

```shell
python -m data_migration_orchestrator create-data-migration-workflow <workflow-config-file-path> --source-platform <source-platform> [--name <workflow-name>] [--connection-name <connection-name>]
```

- The **Workflow Configuration** specification can be found in the [Workflow Configuration Reference](#workflow-configuration-reference) section.
- **`--source-platform` is required** for this subcommand. Supported values are `sqlserver` and `redshift`.
- The workflow name must be composed of alphanumerical characters and cannot start with a digit. Defaults to `MY_WORKFLOW` when omitted.
- `--connection-name` is optional. When omitted, the orchestrator uses the default Snowflake connection from environment variables. When provided, it should match a named connection in your **config.toml** or **connections.toml** file.

### Monitoring a Data Migration Workflow

Each **Workflow** will go through different stages through its lifecycle:

1. **Pending**: No tasks have been created for this workflow yet.
2. **Executing**: Tasks have been created for this workflow and there are still tasks that haven't reached a terminal state (COMPLETED or FAILED).
3. **Completed:** All tasks have reached a terminal state (COMPLETED or FAILED).

In the **data migration metadata schema** (by default **SNOWCONVERT_AI.DATA_MIGRATION**) there are tables/views that can be queried to understand the status of one or more Workflows:

| View/Table | Description |
|------------|-------------|
| **WORKFLOW** | One row per workflow. Includes start/end time, status, and configuration. |
| **TABLE_PROGRESS_WITH_EXAMPLE_ERROR** | One row per table being migrated. Shows how many partitions are in each stage (extraction, loading, completed, or failed), along with related errors. Filterable by `WORKFLOW_ID`. |
| **DATA_MIGRATION_ERROR** | For each failed partition, contains the first known error. Filterable by `WORKFLOW_ID`. |
| **DATA_MIGRATION_WARNING** | Non-fatal warnings emitted during migration (e.g. type fallbacks, truncated columns). Filterable by `WORKFLOW_ID`. |

In the same schema, there is a [Streamlit](https://docs.snowflake.com/en/developer-guide/streamlit/about-streamlit) dashboard called **DATA_MIGRATION_DASHBOARD** that can be used to monitor the workflows. The dashboard is organized around **tables** (the primary user-facing concept) rather than workflow executions. Its default tabs are:

- **📋 Tables** — primary view. One row per distinct table aggregated across every workflow that migrated it, with drill-down to per-execution detail. Surfaces per-table `TOTAL_ROWS` and the target `CLOUD_STAGE` bucket.
- **⚠️ Errors** — table-grouped expanders (and a flat-list fallback) over recent migration errors.
- **📊 Overview** — high-level KPIs including total rows migrated.

Every tab has a **⬇ Download CSV** button for its on-screen dataframe, and the sidebar exposes a **📦 Export snapshot (CSV)** that bundles every active section into one multi-section file. The sidebar table search prefilters every table-driven view. Toggle **Show advanced / debug views** in the sidebar to reveal the **Workflows** and **Tasks** (task queue) debug tabs plus raw internal columns.

### Managing Workflows

The migration metadata schema (default **SNOWCONVERT_AI.DATA_MIGRATION**) exposes stored procedures for pausing, resuming, and cancelling work. They can be called directly from a Snowflake worksheet or any SQL client.

#### Pause

Pausing moves all `pending` and `executing` tasks to `paused` status and revokes any active leases. Paused tasks cannot be picked up by executors until they are resumed.

```sql
-- Pause an entire workflow
CALL DATA_MIGRATION.PAUSE_WORKFLOW(<workflow_id>);

-- Pause a single table within a workflow
CALL DATA_MIGRATION.PAUSE_TABLE(<workflow_id>, '<TABLE_SOURCE_IDENTIFIER>');
```

`PAUSE_WORKFLOW` also sets the workflow status to **paused**. `PAUSE_TABLE` leaves the workflow status unchanged.

#### Resume

Resuming moves all `paused` tasks back to `pending` so executors can pick them up again.

```sql
-- Resume an entire workflow
CALL DATA_MIGRATION.RESUME_WORKFLOW(<workflow_id>);

-- Resume a single table within a workflow
CALL DATA_MIGRATION.RESUME_TABLE(<workflow_id>, '<TABLE_SOURCE_IDENTIFIER>');
```

`RESUME_WORKFLOW` also sets the workflow status back to **running**.

#### Cancel

Cancelling moves all `pending`, `executing`, and `paused` tasks to `failed` with the error message `Manually cancelled.`. The failure is cascaded to any blocked successor tasks, and cleanup tasks are unblocked so they can run.

```sql
-- Cancel an entire workflow
CALL DATA_MIGRATION.CANCEL_WORKFLOW(<workflow_id>);

-- Cancel a single table within a workflow
CALL DATA_MIGRATION.CANCEL_TABLE(<workflow_id>, '<TABLE_SOURCE_IDENTIFIER>');
```

`CANCEL_WORKFLOW` also sets the workflow status to **cancelled**.

> **Note:** The `TABLE_SOURCE_IDENTIFIER` parameter is the fully qualified source table name as it appears in the task scope (e.g., `MY_DB.MY_SCHEMA.MY_TABLE`). You can find it in the **SCOPE** column of the **TASK_QUEUE** table inside the `Table[...]` fragment.

## Cloud Data Validation Workflows

The orchestrator can run **Cloud Data Validation** workflows in addition to data migration. Validation work is queued as `data_validation` tasks; the same **Worker** package (`snowflake-data-exchange-agent`) executes them when the optional **snowflake-data-validation** dependency is available in the worker environment. Create a validation workflow with:

```shell
python -m data_migration_orchestrator create-data-validation-workflow <validation-config-file-path> --source-platform <source-platform> [--name <workflow-name>] [--connection-name <connection-name>]
```

- **`--source-platform` is required** for this subcommand. Supported values are `sqlserver`, `redshift`, and `teradata`. Its value must match the `source_platform` field in the JSON configuration file.
- `--name` defaults to `MY_VALIDATION_WORKFLOW` when omitted.
- `--connection-name` is optional. When omitted, the orchestrator uses the default Snowflake connection from environment variables.
- New workflow rows are inserted into the **`WORKFLOW`** table in the **data migration metadata schema** (default **`SNOWCONVERT_AI.DATA_MIGRATION`**) with `WORKFLOW_TYPE` set to **`data-validation`**. Validation **results** and related objects are stored under the **data validation metadata schema** (default **`SNOWCONVERT_AI.DATA_VALIDATION`**, configurable with `CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA`).

### Monitoring a Data Validation Workflow

In the **data validation metadata schema** (by default **SNOWCONVERT_AI.DATA_VALIDATION**) there are views that can be queried to understand the status of validation workflows:

| View | Description |
|------|-------------|
| **TABLE_PROGRESS** | One row per validated table. Summarizes overall validation status. Filterable by `WORKFLOW_ID`. |
| **TABLE_PROGRESS_DETAIL** | Per-table breakdown with partition-level L2/L3 status (VALID, INVALID, EXECUTION_ERROR). Filterable by `WORKFLOW_ID`. |
| **DATA_VALIDATION_ERROR** | Errors encountered during validation. Filterable by `WORKFLOW_ID`. |
| **DATA_VALIDATION_WARNING** | Non-fatal warnings (e.g. unsupported column types, metric exclusions). Filterable by `WORKFLOW_ID`. |

In the same schema, there is a [Streamlit](https://docs.snowflake.com/en/developer-guide/streamlit/about-streamlit) dashboard called **DATA_VALIDATION_DASHBOARD** that provides a visual overview of validation progress and results. Like the migration dashboard it is organized around **tables**: the **📋 Tables** tab is the primary view (cross-workflow aggregate + per-table drill-down with quick-links that pre-filter Schema/Metrics/Rows/Cell tabs). The Schema / Metrics / Rows / Cell / Table progress / Errors tabs are retained; a sidebar **Show advanced / debug views** toggle reveals the Tasks (task queue) debug tab. Every tab has a **⬇ Download CSV** button, and the sidebar exposes a **📦 Export snapshot (CSV)** that bundles every active section into one file.

### Data Validation Workflow Configuration (Top Level)

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `source_platform` | String | Yes | Source dialect identifier (for example `sqlserver`, `redshift`, `teradata`). Must match the `--source-platform` argument when creating the workflow from the CLI. |
| `target_platform` | String | No | Defaults to `Snowflake`. |
| `target_database` | String | No | Default target database name for tables when not specified per table. |
| `validation_configuration` | Object | No | Global validation levels and options (see below). |
| `comparison_configuration` | Object | No | Numeric tolerance and optional type mapping file. |
| `database_mappings` | Object | No | Map of source database names to Snowflake database names. |
| `schema_mappings` | Object | No | Map of source schema names to Snowflake schema names. |
| `tables` | Array | Yes | At least one table (or view) to validate. |
| `views` | Array | No | Additional view entries using the same shape as `tables`. |
| `use_snowflake_compute` | Boolean | No | When `true`, enables Snowflake-side computation paths where supported. Default `false`. |
| `target_partition_size_rows` | Integer | No | **Desired** rows per partition. **Mutually exclusive** with `target_partition_size_mb`. Must be greater than 0 when set. When both targets are omitted, Data Validation defaults to **200 MB** per partition. See [Partitioning](#partitioning-column_names_to_partition_by). Overridable per table. |
| `target_partition_size_mb` | Integer | No | **Desired** MB per partition. **Mutually exclusive** with `target_partition_size_rows`. Must be greater than 0 when set. When both targets are omitted, Data Validation defaults to **200 MB** per partition. See [Partitioning](#partitioning-column_names_to_partition_by). Overridable per table. |
| `use_snowpipe_for_results` | Boolean | No | When `true` (default), L2/L3 validation results are ingested into the shared results tables via Snowpipe. Workers issue `ALTER PIPE REFRESH` after uploading each partition's files and the orchestrator waits for `SYSTEM$PIPE_STATUS` to report zero pending files before running the evaluate step. Set to `false` to fall back to the legacy per-partition `COPY INTO` tasks. |

### validation_configuration (global defaults)

When `validation_configuration` is omitted, the orchestrator applies these defaults: **schema** and **metrics** validation are **enabled**; **row** validation is **disabled**; `row_validation_mode` defaults to **`row`**; `continue_on_failure` defaults to **`false`**; `max_failed_rows_number` defaults to **100**; `exclude_metrics` defaults to **`false`**; `apply_metric_column_modifier` defaults to **`true`**. Any field set here can be overridden per table via a nested `validation_configuration` on that table entry.

| Property | Type | Description |
|----------|------|-------------|
| `schema_validation` | Boolean | Level 1: schema / column consistency checks. |
| `metrics_validation` | Boolean | Level 2: statistical metrics comparison. |
| `row_validation` | Boolean | Level 3: row-level or cell-level data comparison. |
| `row_validation_mode` | String | For row validation: typically `row` or `cell`. |
| `continue_on_failure` | Boolean | Whether to continue to the next validation level after a failure. |
| `max_failed_rows_number` | Integer | Cap on failed rows reported for L3 validation (must be greater than 0 when set). |
| `exclude_metrics` | Boolean | Whether to exclude unsupported metric columns. |
| `apply_metric_column_modifier` | Boolean | Whether to apply metric column modifiers. |

### comparison_configuration

| Property | Type | Description |
|----------|------|-------------|
| `tolerance` | Number | Numeric comparison tolerance for metrics (must be greater than 0 when set). Default applied by the orchestrator when omitted is **0.001**. |
| `type_mapping_file_path` | String | Optional path to a custom type mapping file for comparisons. |

### Per-table / per-view entry (`tables` and `views`)

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `fully_qualified_name` | String | Yes | Source object name (format depends on source platform). |
| `use_column_selection_as_exclude_list` | Boolean | No | Default `false`. |
| `column_selection_list` | String[] | No | Columns to include or exclude per `use_column_selection_as_exclude_list`. |
| `target_name` | String | No | Target object name override. |
| `target_database` | String | No | Per-table target database override. |
| `target_schema` | String | No | Per-table target schema override. |
| `where_clause` | String | No | Filter on the source side. |
| `target_where_clause` | String | No | Filter on the target side. |
| `index_column_list` | String[] | No | Columns used to align rows on the source. |
| `target_index_column_list` | String[] | No | Columns used to align rows on the target. |
| `column_mappings` | Object | No | Map of source column name to target column name. |
| `is_case_sensitive` | Boolean | No | Case sensitivity for identifiers. |
| `chunk_number` | Integer | No | Chunking hint for validation (greater than 0 when set). |
| `max_failed_rows_number` | Integer | No | Overrides global cap for this object. |
| `exclude_metrics` | Boolean | No | Per-object metrics exclusion override. |
| `apply_metric_column_modifier` | Boolean | No | Per-object modifier override. |
| `object_type` | String | No | Typically `TABLE` or `VIEW`. |
| `column_names_to_partition_by` | String[] | No | Columns used for range-based (NTILE) partitioning during validation. Without this, the table is processed as a single partition. |
| `target_partition_size_rows` | Integer | No | Per-table override for desired rows per partition. **Mutually exclusive** with `target_partition_size_mb`. Must be greater than 0. |
| `target_partition_size_mb` | Integer | No | Per-table override for desired MB per partition. **Mutually exclusive** with `target_partition_size_rows`. Must be greater than 0. |
| `validation_configuration` | Object | No | Nested object with the same fields as global `validation_configuration` to override defaults for this object only. |

### Partitioning (`column_names_to_partition_by`)

When `column_names_to_partition_by` is set, the orchestrator splits the table into range-based partitions. Both Data Migration and Data Validation share the same sizing logic:

1. **Compute a target rows-per-partition** from whichever user setting is provided (the two are mutually exclusive):
   - `target_partition_size_rows` — used as-is.
   - `target_partition_size_mb` — converted to rows via `target_mb / avg_row_mb`.
   - If neither is set, the table is not split by the target alone. Data Validation defaults to **200 MB**; Data Migration uses platform-tuned values.
2. **Apply an internal cap.** System-imposed maximums (not user-configurable) limit partition size to safe infrastructure bounds.
3. **Derive the partition count:** `ceil(row_count / effective_rows_per_partition)`, or 1 when the entire table fits in a single partition.

## Advanced Features

### Redshift UNLOAD

For **Redshift**, it is recommended to use the **UNLOAD** extraction strategy. The main idea behind this is:

- Large query results are written directly to an **S3 Bucket** instead of being downloaded to the machine in which the **Worker** is running.
- On **Snowflake** side, an [External Stage](https://docs.snowflake.com/en/user-guide/data-load-s3-create-stage) is set up to reference the corresponding **S3 Bucket**, so that **COPY INTO** statements can be done directly from that stage.

See the [Extraction Strategy](#extractionstrategy) section for configuration details.

### Incremental Synchronization

It is possible to migrate some tables and then re-migrate them in the future, moving only the data that has changed. See the [Synchronization Strategies](#synchronizationstrategy) section for the available strategies and their configuration.

## Query Tagging

Both the Orchestrator and the Worker automatically set Snowflake's [`QUERY_TAG`](https://docs.snowflake.com/en/sql-reference/parameters#query-tag) session parameter on every query they submit. Tags are compact JSON strings containing identifiers such as the workflow ID, task ID, and component version. You can use these tags to filter and attribute queries in [`QUERY_HISTORY`](https://docs.snowflake.com/en/sql-reference/account-usage/query_history):

```sql
SELECT query_text, query_tag, start_time
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE TRY_PARSE_JSON(query_tag):DMVF_WORKFLOW_ID IS NOT NULL
ORDER BY start_time DESC;
```

| Tag key | Present on | Description |
|---------|-----------|-------------|
| `DMVF_VERSION` | Infrastructure queries | Component package version. |
| `DMVF_WORKFLOW_ID` | Task-processing queries | Workflow that originated the task. |
| `DMVF_TASK_ID` | Task-processing queries | Individual task identifier. |
| `DMVF_ORCHESTRATOR_VERSION` | Orchestrator task-processing queries | Orchestrator package version. |
| `DMVF_WORKER_VERSION` | Worker task-processing queries | Worker package version. |

## Considerations and Recommendations

### Connecting to Snowflake with a PAT

It is recommended to use [Programmatic Access Tokens](https://docs.snowflake.com/en/user-guide/programmatic-access-tokens) for connections used by the Orchestrator and **Workers**. This ensures there won't be a need to constantly authenticate through the browser or with an Authenticator app. You will need to establish a [Network Policy](https://docs.snowflake.com/en/user-guide/network-policies) or temporarily bypass the requirement for a Network Policy (this can be done from **Snowsight**).

### Running Orchestrator and/or Workers on SPCS

If you want to leverage **Snowflake** compute for these tasks, you can:

1. Prepare **Docker** images that use the Python modules and have the appropriate configuration.
2. Push those Docker images to an [Image Repository](https://docs.snowflake.com/en/developer-guide/snowpark-container-services/working-with-registry-repository) in Snowflake.
3. Execute the **Orchestrator** and/or **Worker(s)** images using [Snowpark Container Services](https://docs.snowflake.com/en/developer-guide/snowpark-container-services/overview).

Some considerations:

- It is recommended to execute them as **Services**, not **Jobs**.
- It is possible to run only one component (Orchestrator or Workers) in SPCS and the other on another platform.
- It is a good practice to monitor the SPCS service and suspend it when it is not being used.
- Depending on the network configuration of the **Source System**, you might need to configure an [External Access Integration](https://docs.snowflake.com/en/sql-reference/sql/create-external-access-integration) so that these services can connect to your Source System.

### Initial Testing

It is recommended to deploy the DDL for the tables you want to migrate before starting data migration. This ensures the target types match the behavior you want in those tables and their related views/procedures. Converting the DDL from your source dialect into **Snowflake SQL** can be done through the Code Conversion capabilities of [SnowConvert AI](https://docs.snowflake.com/en/migrations/snowconvert-docs/overview) and/or [Cortex Code](https://docs.snowflake.com/en/user-guide/cortex-code/cortex-code). If you don't deploy the DDL before starting data migration, the types will be inferred and might not be as accurate as desired.

Additionally, it is a good practice to move a few rows from each table as a test before starting the full migration. This helps detect configuration or connectivity issues early.

### Managing Workers

The time it takes to complete a workflow depends heavily on many variables. One of the variables that affects the most is the number of workers (and the number of threads per worker), since that determines how many extraction tasks can be executed in parallel. Consider:

1. It is not necessary to run two workers on the same machine. If you want more parallelism on one machine, increase the thread count instead.
2. Network bandwidth greatly affects the speed of workers and is effectively shared between threads of a worker.
3. Even with many workers/threads processing tasks in parallel, your source system might not have enough resources to handle the load.
4. You might want to keep a low worker count to avoid overloading your source system.
5. You might want to stop some (or all) of your workers at times when your source system is already overloaded by unrelated operations, to avoid disrupting those operations.

## Workflow Configuration Reference

The workflow configuration file is a JSON object. Its structure is described below using named models -- each model's properties reference other models by name.

### WorkflowConfiguration (Top Level)

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `schemaVersion` | String | No | Version of the configuration schema (e.g. "1.0.0"). Accepts formats "major", "major.minor", or "major.minor.patch". Defaults to "1.0.0" if omitted. |
| `tables` | [TableConfiguration](#tableconfiguration)[] | Yes | An array of table-specific configurations defining which tables to migrate and how. |
| `defaultTableConfiguration` | [TableConfiguration](#tableconfiguration) | No | Shared settings inherited by all tables. Table-specific values override these defaults (see [merging rules](#default-table-configuration-merging-rules) below). |

### TableConfiguration

Defines the settings for migrating a single table.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `source` | [SourceTargetIdentifier](#sourcetargetidentifier) | Yes | Identifies the source table. |
| `target` | [SourceTargetIdentifier](#sourcetargetidentifier) | Yes | Identifies the target table in Snowflake. |
| `columnNamesToPartitionBy` | String[] | No | Columns used to partition data during extraction. When omitted or empty, the table is extracted as a single unit (recommended only for very small tables). |
| `extraction` | [ExtractionStrategy](#extractionstrategy) | No | Configures how data is extracted from the source database. |
| `synchronization` | [SynchronizationStrategy](#synchronizationstrategy) | No | Configures incremental synchronization behavior. |
| `columnTypeMappings` | [ColumnTypeMapping](#columntypemapping)[] | No | Type conversions applied during migration. |
| `columnNameMappings` | [ColumnNameMapping](#columnnamemapping)[] | No | Column renaming mappings. |
| `primaryKeyColumns` | String[] | No | Primary key columns for the source table. Required when using `trackModifications` in the watermark synchronization strategy. |
| `targetPartitionSizeMb` | Integer | No | Target partition size in MB. **Mutually exclusive** with `targetPartitionSizeRows`. Must be greater than 0 when set. When both `targetPartitionSizeMb` and `targetPartitionSizeRows` are omitted, the orchestrator picks sizes automatically (**auto** mode). See [Partition Size](#partition-size). |
| `targetPartitionSizeRows` | Integer | No | Target partition size in rows. **Mutually exclusive** with `targetPartitionSizeMb`. Must be greater than 0 when set. When both `targetPartitionSizeMb` and `targetPartitionSizeRows` are omitted, the orchestrator picks sizes automatically (**auto** mode). See [Partition Size](#partition-size). |
| `whereClauseCriteria` | String | No | SQL-like filter to select a subset of rows (e.g., `"is_deleted = 0"`). |
| `loadSegmentation` | [LoadSegmentation](#loadsegmentation) | No | Splits a single COPY INTO into multiple parallel statements, each targeting a subset of staged files. |
| `loading` | Object | No | **(Experimental)** Loading strategy override. Accepts `{ "strategy": "snowpipe" }` to use Snowpipe for ingestion instead of the default warehouse-based `COPY INTO`. Behavior and configuration may change in future releases. |

#### Default Table Configuration Merging Rules

When `defaultTableConfiguration` is provided, its values are merged into each table entry using these rules:

- **Nested objects** (`source`, `target`, `synchronization`, `extraction`): Deep merge -- fields within are merged individually.
- **Collections** (`columnTypeMappings`, `columnNameMappings`, etc.): Table value replaces default entirely.
- **Scalars** (`whereClauseCriteria`): Table value overrides default.

### SourceTargetIdentifier

Used by `source` and `target` in [TableConfiguration](#tableconfiguration) to identify a database object.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `databaseName` | String | Yes | Name of the database. |
| `schemaName` | String | Yes | Name of the schema. |
| `tableName` | String | Yes | Name of the table. |

The `target` object accepts two additional optional fields: `tableType` (`"native"` or `"iceberg"`) and `icebergConfig` (required when using Iceberg). If `tableType` is omitted or null, it defaults to **`"native"`** (standard Snowflake table). See [IcebergConfig](#icebergconfig-targeticebergconfig) and the [Redshift UNLOAD with Iceberg Tables](#redshift-unload-with-iceberg-tables) example.

### IcebergConfig (target.icebergConfig)

Used when `target.tableType` is **`"iceberg"`**. Fields are merged with `defaultTableConfiguration.target.icebergConfig`; table-level keys override defaults.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `catalog` | String | No | Default **`SNOWFLAKE`** for Snowflake-managed Iceberg. Use a **catalog integration** name for externally cataloged tables (for example AWS Glue). |
| `externalVolume` | String | For `catalog` **`SNOWFLAKE`** | Snowflake external volume for Iceberg data and metadata. |
| `baseLocationPrefix` | String | No | Optional path prefix for `BASE_LOCATION` when using Snowflake-managed Iceberg (`catalog` **`SNOWFLAKE`**). |
| `catalogTableName` | String | For external `catalog` | Fully qualified name of the table in the external catalog (for example `glue_db.my_table`). |
| `catalogSync` | String | No | Optional catalog integration used to sync Snowflake-managed metadata back to an external catalog. |
| `sourceDataStage` | String | No | Stage path starting with **`@`** pointing at existing Parquet files; used for **`copy_files`**-style loads with Snowflake-managed Iceberg. |
| `migrationStrategy` | String | No | One of **`catalog_link`**, **`convert_to_managed`**, **`copy_files`**. When omitted, the orchestrator infers a strategy from `catalog` and `sourceDataStage`. |

Snowflake account setup for Iceberg (external volumes, catalog integrations, stages, and privileges) follows Snowflake’s Iceberg documentation; use the examples above as a template for JSON fields.

### ColumnTypeMapping

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `sourceType` | String | Yes | Type name in the source system. |
| `targetType` | String | Yes | Target type in Snowflake. |

### ColumnNameMapping

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `sourceName` | String | Yes | Column name in the source system. |
| `targetName` | String | Yes | Target column name in Snowflake. |

### ExtractionStrategy

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `strategy` | `"regular"` or `"unload"` | Yes | Extraction method. `"regular"` is the default; `"unload"` is available for Redshift sources. |
| `externalStage` | String | UNLOAD only | Fully-qualified Snowflake external stage name (e.g., `"MY_DB.MY_SCHEMA.S3_STAGE"`). |

**regular** (default) -- Data is queried and downloaded through the Worker:

```json
"extraction": { "strategy": "regular" }
```

**unload** (Redshift only) -- Data is written to S3 via Redshift UNLOAD and loaded from an external stage:

```json
"extraction": { "strategy": "unload", "externalStage": "MY_DB.MY_SCHEMA.S3_EXTERNAL_STAGE" }
```

### Partition Size

Controls how large each partition should be during extraction. Configured at the [TableConfiguration](#tableconfiguration) level via two flat, mutually exclusive fields: `targetPartitionSizeMb` or `targetPartitionSizeRows`. When both are omitted, the system uses **auto** sizing.

| Form | Description |
|------|-------------|
| Both omitted (default) | **Auto**. The system picks optimal partition sizes based on the source platform, extraction strategy, and table size. |
| `"targetPartitionSizeMb": N` | Each partition targets approximately `N` megabytes of data. Must be greater than 0. |
| `"targetPartitionSizeRows": N` | Each partition targets `N` rows, regardless of data size. Must be greater than 0. |

Only one of `targetPartitionSizeMb` or `targetPartitionSizeRows` may be specified for a given table (setting both is a configuration error).

**Auto** (default) -- Omit both fields. The system selects partition sizes tuned for the platform and extraction strategy. Auto mode uses larger partitions for Redshift UNLOAD (where S3 handles large files well) and smaller partitions for ODBC-based extraction (SQL Server, Redshift REGULAR) where data flows through the Worker's memory.

**Fixed size in MB** -- Specify a target size per partition:

```json
"targetPartitionSizeMb": 2048
```

**Fixed row count** -- Specify a target number of rows per partition:

```json
"targetPartitionSizeRows": 500000
```

### LoadSegmentation

Controls post-upload load segmentation. When a large number of files are staged for a single partition (common with Redshift UNLOAD), the orchestrator can split the COPY INTO into multiple parallel statements, each targeting a subset of files. All resulting COPY INTO tasks fan-in to the same successor task.

| Property | Type | Required | Description |
|----------|------|----------|-------------|
| `targetSegmentSizeMb` | Integer | Yes | Target total file size (in MB) per COPY INTO segment. |

When `loadSegmentation` is omitted, a single COPY INTO is used for all files in the partition (the default behavior).

```json
"loadSegmentation": { "targetSegmentSizeMb": 5000 }
```

Each segment will contain files whose total size does not exceed the target. Files larger than the target are placed in their own segment. The Snowflake `FILES` parameter limit (1,000 files) is also enforced per statement.

### SynchronizationStrategy

Controls whether subsequent workflow runs perform a full re-extraction or only sync changed data.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `strategy` | `"none"`, `"checksum"`, or `"watermark"` | Yes | The synchronization method. |
| `watermarkColumn` | String | Watermark only | Column name to track (must be monotonically increasing). |
| `trackModifications` | Boolean | No | If `true`, uses the primary key to deduplicate modified rows. Requires `primaryKeyColumns` in [TableConfiguration](#tableconfiguration). |

**none** (default) -- Full extraction on every run. No synchronization metadata is stored.

```json
"synchronization": { "strategy": "none" }
```

- **Use when:** Data is small, changes are unpredictable, or guaranteed consistency is needed.

**checksum** -- Computes a hash of all column values per partition. Only changed partitions are cleared and re-extracted.

```json
"synchronization": { "strategy": "checksum" }
```

- **Use when:** You need to detect any change but lack a reliable monotonic column (e.g., dimension tables).
- **Trade-offs:** Requires a checksum computation on the source for every partition on every run.

**watermark** -- Tracks a monotonic column (timestamp, ID, version) to sync only rows newer than the last observed maximum.

```json
"synchronization": { "strategy": "watermark", "watermarkColumn": "UPDATED_AT" }
```

- **Use when:** Your table has a reliable monotonic column that increases on insert/update (e.g., fact tables, event logs).
- **Limitation:** Watermark alone cannot currently track deletions. Support for this will be added in the future.

### Quoting Identifiers

Names that need quoting (or brackets) must be manually quoted as they would normally be in JSON. For example: `"tableName": "\"MyCaseSensitiveTable\""`.

## Workflow Configuration Examples

### Basic Migration (SQL Server)

Migrates two tables with shared source/target schemas, type mappings, column renaming, watermark sync, and row filtering:

```json
{
  "defaultTableConfiguration": {
    "source": {
      "schemaName": "data_migration_cloud_test",
      "databaseName": "SampleStoreDB"
    },
    "target": {
      "schemaName": "data_migration_cloud_test",
      "databaseName": "samplestoredb"
    }
  },
  "tables": [
    {
      "source": { "tableName": "store_employee" },
      "target": { "tableName": "target_employee" },
      "columnNamesToPartitionBy": ["ID"]
    },
    {
      "source": { "tableName": "Sales_Simple" },
      "target": { "tableName": "Sales_Simple" },
      "columnNamesToPartitionBy": ["ID"],
      "columnTypeMappings": [
        { "sourceType": "MONEY", "targetType": "DECIMAL(19,4)" }
      ],
      "columnNameMappings": [
        { "sourceName": "id", "targetName": "old_id" },
        { "sourceName": "name", "targetName": "full_name" }
      ],
      "synchronization": {
        "strategy": "watermark",
        "watermarkColumn": "UPDATED_AT"
      },
      "targetPartitionSizeMb": 2048,
      "whereClauseCriteria": "is_deleted = 0"
    }
  ]
}
```

### Redshift UNLOAD

Uses the UNLOAD extraction strategy with an external stage for S3-based data transfer:

```json
{
  "defaultTableConfiguration": {
    "source": {
      "schemaName": "ecommerce_raw",
      "databaseName": "snowconvert_demo"
    },
    "target": {
      "schemaName": "ecommerce_raw",
      "databaseName": "TARGET_DB"
    },
    "extraction": {
      "strategy": "unload",
      "externalStage": "MY_DB.MY_SCHEMA.S3_EXTERNAL_STAGE"
    },
    "loadSegmentation": { "targetSegmentSizeMb": 5000 }
  },
  "tables": [
    {
      "source": { "tableName": "customers" },
      "target": { "tableName": "customers" },
      "columnNamesToPartitionBy": ["customer_id"]
    },
    {
      "source": { "tableName": "orders" },
      "target": { "tableName": "orders" },
      "columnNamesToPartitionBy": ["order_id"],
      "columnTypeMappings": [
        { "sourceType": "NUMERIC(10,2)", "targetType": "DECIMAL(10,2)" }
      ]
    }
  ]
}
```

### Redshift UNLOAD with Iceberg Tables

Combines Redshift UNLOAD with Iceberg table targets, including Snowflake-managed and Glue catalog configurations:

```json
{
  "defaultTableConfiguration": {
    "source": {
      "schemaName": "public",
      "databaseName": "analytics_db"
    },
    "target": {
      "schemaName": "public",
      "databaseName": "TARGET_DB",
      "tableType": "iceberg",
      "icebergConfig": {
        "catalog": "SNOWFLAKE",
        "externalVolume": "my_iceberg_ext_vol",
        "baseLocationPrefix": "migrations/redshift",
        "sourceDataStage": "@TARGET_DB.PUBLIC.ICEBERG_SOURCE_STAGE"
      }
    },
    "extraction": {
      "strategy": "unload",
      "externalStage": "TARGET_DB.PUBLIC.S3_EXTERNAL_STAGE"
    }
  },
  "tables": [
    {
      "source": { "tableName": "customers" },
      "target": { "tableName": "customers" },
      "columnNamesToPartitionBy": ["customer_id"]
    },
    {
      "source": { "tableName": "events" },
      "target": {
        "tableName": "events",
        "tableType": "iceberg",
        "icebergConfig": {
          "catalog": "my_glue_catalog_integration",
          "externalVolume": "my_iceberg_ext_vol",
          "catalogTableName": "glue_db.events"
        }
      },
      "columnNamesToPartitionBy": ["event_id"]
    },
    {
      "source": { "tableName": "orders" },
      "target": {
        "tableName": "orders",
        "tableType": "iceberg",
        "icebergConfig": {
          "catalog": "my_glue_catalog_integration",
          "externalVolume": "my_iceberg_ext_vol",
          "catalogTableName": "glue_db.orders",
          "migrationStrategy": "convert_to_managed"
        }
      },
      "columnNamesToPartitionBy": ["order_id"]
    }
  ]
}
```

### Incremental Sync with Watermark

Uses watermark-based synchronization with modification tracking for incremental data migration:

```json
{
  "defaultTableConfiguration": {
    "source": { "databaseName": "SRC", "schemaName": "dbo" },
    "target": { "databaseName": "TGT", "schemaName": "public" },
    "synchronization": {
      "strategy": "watermark",
      "watermarkColumn": "updated_at"
    }
  },
  "tables": [
    {
      "source": { "tableName": "orders" },
      "target": { "tableName": "orders" },
      "columnNamesToPartitionBy": ["order_id"],
      "primaryKeyColumns": ["order_id"],
      "synchronization": {
        "trackModifications": true
      }
    }
  ]
}
```

## Worker Configuration

This section documents the configuration for the Worker (`snowflake-data-exchange-agent` package). The Worker configuration file uses [TOML](https://toml.io/) format.

| Section | Property | Type | Description |
|---------|----------|------|-------------|
| **Top Level** | `selected_task_source` | String | Currently should always be set to `"snowflake_stored_procedure"`. |
| `[application]` | `max_parallel_tasks` | Integer | Maximum number of tasks the worker will process in parallel (using threads). |
| `[application]` | `task_fetch_interval` | Integer | Interval (in seconds) between attempts to fetch new tasks from the Orchestrator. |
| `[application]` | `snowflake_database_for_metadata` | String | Optional. Database where the orchestrator deployed the task queue (default `SNOWCONVERT_AI`). Must match the orchestrator's `CUSTOM_SNOWFLAKE_DATABASE_FOR_METADATA` if you override it there. |
| `[application]` | `snowflake_schema_for_data_migration_metadata` | String | Optional. Schema for `PULL_TASKS` / `COMPLETE_TASK` / `FAIL_TASK` (default `DATA_MIGRATION`). Must match the orchestrator's `CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_MIGRATION_METADATA` if overridden. |
| `[application]` | `local_results_directory` | String | Optional. Base directory where exported Parquet/CSV files are written before upload. Defaults to `~/.data_exchange_agent/result_data`. |
| `[connections.source.*]` | | Object | Configuration for source system connections. The Worker typically requires an ODBC driver. See examples below. |
| `[connections.target.snowflake_connection_name]` | `connection_name` | String | The name of the connection entry in the `~/.snowflake/config.toml` file to use. |

When `selected_task_source` is `snowflake_stored_procedure`, the worker calls the task-queue procedures using `application.snowflake_database_for_metadata` and `application.snowflake_schema_for_data_migration_metadata`. These values are independent of Snowflake session defaults (`SNOWFLAKE_DATABASE`, `SNOWFLAKE_SCHEMA`) in the connection profile.

**Example: SQL Server (Standard Authentication)**

```toml
[connections.source.sqlserver]
username = "username"
password = "password"
database = "database_name"
host = "127.0.0.1"
port = 1433
```

**Example: Amazon Redshift (IAM Authentication)**

```toml
[connections.source.redshift]
username = "demo-user"
database = "demo_db"
auth_method = "iam-provisioned-cluster"
cluster_id = "my-aws-cluster"
region = "us-west-2"
access_key_id = "your-access-key-id"
secret_access_key = "your-secret-access-key"
```

**Example: Amazon Redshift (Standard Authentication)**

```toml
[connections.source.redshift]
username = "myuser"
password = "mypassword"
database = "mydatabase"
host = "my-cluster.abcdef123456.us-west-2.redshift.amazonaws.com"
port = 5439
auth_method = "standard"
```

**Example: Teradata**

The Worker supports two Teradata drivers and automatically selects the best one available. The pure Python `teradatasql` driver is preferred; if it is not installed, the Worker falls back to `pyodbc` with the Teradata ODBC driver.

```toml
[connections.source.teradata]
host = "your-teradata-host.example.com"
port = 1025
database = "tpcds"
username = "your_username"
password = "your_password"
# driver_name = "Teradata Database ODBC Driver 17.20"  # only needed for ODBC fallback
```

> **Note:** Only one source connection is needed. The Snowflake target connection should point to a valid entry in your `~/.snowflake/config.toml`.

## Changelog

### v0.9.0

**Improvements**

- Vertical partitioning for cell validation on wide tables.
- Granular per-table L1/L2/L3 progress in the validation dashboard.
- Validated table-level `ROW_COUNT` during schema validation.
- Created Data Validation Snowpipes synchronously and restored the `task_queue` argument in the hybrid validation handler.
- Table-centric Streamlit dashboards with CSV export.

**Bug fixes**

- Fixed timestamp copy handling for SQL Server BCP loads.
- Fixed duplicate tasks created when evaluating L1 results under race conditions.
- Fixed decimal partition coercion and parallelized L3 validation fixes.
- Fixed orchestrator logging to `stderr` instead of `stdout`.

### v0.8.0

**New features**

- Added hybrid row validation mode — two-phase `MD5` + cell drilldown.
- Added support for smart partitioning in Cloud Data Validation.
- Added load segmentation for multi-file `COPY INTO`.
- Added `DEFAULT` normalization templates for various data types.

**Improvements**

- Improved result set snapshots validation.
- Added a Table Progress tab to the Streamlit dashboard for Data Validation.
- Improved Data Validation performance.
- Included thread name and ID in log output for easier troubleshooting.
- Improved the task queue to support a higher number of parallel workers.

**Bug fixes**

- Cloud Data Validation now defaults to `False` when null in the workflow config.
- Fixed `SQL` compilation memory exhaustion by batching L2 metrics queries for wide tables.
- Fixed cell validation key mismatch, partition `WHERE` clause handling, and metrics payload cleanup.
- Fixed duplicate rows caused by an orchestrator crash during `COPY INTO`.
- Fixed an issue with the incremental sync watermark on Redshift.
- Fixed usage of the vectorized scanner.

### v0.7.2

**Improvements**

- Log package and Python versions when the orchestrator starts.

**Bug fixes**

- Snowflake: recover cleanly when a session expires instead of staying stuck in a bad state.
- Task queue: avoid unblocking tasks before predecessor rows exist (stored procedures and schema migration).
- Improve generation of data validation queries for Teradata: handle very large counts and optional `WHERE` filters correctly.

### v0.7.1

**Improvements**

- Cloud Data Validation dashboard: paginate large tab views for easier browsing.
- Cloud validation: load large query results in smaller batches for the dashboard and query helpers.

**Bug fixes**

- Data migration partition planning no longer caps the number of partitions with a fixed maximum.
- Snowflake connectivity: more resilient sessions and automatic retry for transient failures.
