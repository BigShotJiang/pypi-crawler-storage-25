import { createRequire } from "node:module";
import fs from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";
import { listMemoryCorpusSupplements } from "openclaw/plugin-sdk/memory-core-host-runtime-core";

const require = createRequire(import.meta.url);
const manifest = require("./openclaw.plugin.json");

const SEARCH_PARAMETERS = {
  type: "object",
  additionalProperties: false,
  properties: {
    query: { type: "string" },
    maxResults: { type: "number" },
    minScore: { type: "number" },
    corpus: { type: "string", enum: ["memory", "wiki", "all", "sessions"] },
    rootFilter: {
      type: "array",
      items: { type: "string" },
      description: "Limit search to specific root ids (e.g. ['workspace-memory', 'workspace-bank'])"
    }
  },
  required: ["query"]
};

const GET_PARAMETERS = {
  type: "object",
  additionalProperties: false,
  properties: {
    path: { type: "string" },
    from: { type: "number" },
    lines: { type: "number" },
    corpus: { type: "string", enum: ["memory", "wiki", "all"] }
  },
  required: ["path"]
};

const WRITE_PARAMETERS = {
  type: "object",
  additionalProperties: false,
  properties: {
    path: {
      type: "string",
      description: "Relative path within a memory root (e.g. 'memory/2026-03-27.md', 'bank/entities/alice.md')"
    },
    content: { type: "string", description: "Content to write" },
    mode: {
      type: "string",
      enum: ["create", "overwrite", "append"],
      description: "Write mode: create (fail if exists), overwrite (create or replace), append (add to end). Default: overwrite"
    }
  },
  required: ["path", "content"]
};

// ---------------------------------------------------------------------------
// Memory prompt section builder (injected into agent system prompt)
// ---------------------------------------------------------------------------

function buildMemoryPromptSection({ availableTools, citationsMode }) {
  const hasSearch = availableTools.has("memory_search");
  const hasGet = availableTools.has("memory_get");
  const hasWrite = availableTools.has("memory_write");
  if (!hasSearch && !hasGet && !hasWrite) return [];

  const parts = [];

  if (hasSearch && hasGet) {
    parts.push(
      "Before answering anything about prior work, decisions, dates, people, preferences, or todos: " +
      "run memory_search with a descriptive query to recall from MEMORY.md, memory/, bank/, and configured note roots " +
      "via igrep semantic retrieval; then use memory_get to read specific file sections. " +
      "If low confidence after search, say you checked."
    );
  } else if (hasSearch) {
    parts.push(
      "Before answering anything about prior work, decisions, dates, people, preferences, or todos: " +
      "run memory_search with a descriptive query to recall from configured note roots via igrep semantic retrieval. " +
      "If low confidence after search, say you checked."
    );
  } else if (hasGet) {
    parts.push(
      "Before answering anything about prior work that points to a specific memory file: " +
      "run memory_get to pull only the needed lines. If low confidence after reading, say you checked."
    );
  }

  if (hasWrite) {
    parts.push(
      "Use memory_write to persist important decisions, preferences, and context for future recall. " +
      "Supports mode: create (new file), overwrite (replace), append (add to end)."
    );
  }

  const lines = ["## Memory Recall (igrep)", ...parts];
  if (citationsMode === "off") {
    lines.push(
      "Citations are disabled: do not mention file paths or line numbers unless explicitly asked."
    );
  } else {
    lines.push(
      "Citations: include Source: <path#line> when it helps verify memory snippets."
    );
  }
  lines.push("");
  return lines;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function jsonResult(payload) {
  return {
    content: [{ type: "text", text: JSON.stringify(payload, null, 2) }],
    details: payload
  };
}

function normalizeCorpus(raw, fallback) {
  return typeof raw === "string" && raw.trim() ? raw.trim() : fallback;
}

function readPositiveLimit(value, fallback) {
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

function rankSearchResults(items, limit) {
  return [...items]
    .sort((left, right) => {
      const leftScore = typeof left?.score === "number" ? left.score : 0;
      const rightScore = typeof right?.score === "number" ? right.score : 0;
      if (leftScore !== rightScore) {
        return rightScore - leftScore;
      }
      return String(left?.path || "").localeCompare(String(right?.path || ""));
    })
    .slice(0, Math.max(1, limit));
}

function readMinScore(params) {
  return typeof params?.minScore === "number" && Number.isFinite(params.minScore)
    ? params.minScore
    : null;
}

function applyMinScore(results, minScore) {
  if (minScore === null || !Array.isArray(results)) {
    return results;
  }
  return results.filter((entry) => typeof entry?.score === "number" && entry.score >= minScore);
}

async function searchCorpusSupplements({ query, maxResults, agentSessionKey, corpus }) {
  if (corpus === "memory" || corpus === "sessions") {
    return [];
  }
  const registrations = listMemoryCorpusSupplements();
  if (registrations.length === 0) {
    return [];
  }
  const results = (
    await Promise.all(
      registrations.map(async (registration) =>
        await registration.supplement.search({ query, maxResults, agentSessionKey, corpus })
      )
    )
  ).flat();
  return rankSearchResults(results, readPositiveLimit(maxResults, 10));
}

async function getCorpusSupplement({ lookup, fromLine, lineCount, agentSessionKey, corpus }) {
  if (corpus === "memory") {
    return null;
  }
  for (const registration of listMemoryCorpusSupplements()) {
    const result = await registration.supplement.get({
      lookup,
      fromLine,
      lineCount,
      agentSessionKey,
      corpus
    });
    if (result) {
      return result;
    }
  }
  return null;
}

function supplementGetToMemoryGetResult(supplement, fallbackPath) {
  if (!supplement) {
    return null;
  }
  const { content, ...rest } = supplement;
  return {
    ...rest,
    path: typeof rest.path === "string" && rest.path ? rest.path : fallbackPath,
    text: typeof content === "string" ? content : ""
  };
}

function positiveInteger(value, fallback) {
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

function resolvePluginConfig(raw) {
  const cfg = raw && typeof raw === "object" ? raw : {};
  return {
    command: typeof cfg.command === "string" && cfg.command.trim() ? cfg.command.trim() : "igrep",
    timeoutMs: positiveInteger(cfg.timeoutMs, 15000),
    defaultMaxResults: positiveInteger(cfg.defaultMaxResults, 6),
    perRootTopK: positiveInteger(cfg.perRootTopK, 8),
    maxSnippetChars: positiveInteger(cfg.maxSnippetChars, 700),
    searchMode: resolveSearchMode(cfg.searchMode),
    includeWorkspaceMemory: cfg.includeWorkspaceMemory !== false,
    includeWorkspaceBank: cfg.includeWorkspaceBank !== false,
    extraRoots: Array.isArray(cfg.extraRoots) ? cfg.extraRoots : [],
    writeEnabled: cfg.write && typeof cfg.write === "object" ? cfg.write.enabled === true : false
  };
}

function resolveSearchMode(raw) {
  if (typeof raw === "string" && ["fast", "normal", "ultra"].includes(raw)) {
    return raw;
  }
  return "normal";
}

function resolveCommand(api, command) {
  if (typeof command !== "string" || !command.trim()) {
    return "igrep";
  }
  const trimmed = command.trim();
  if (trimmed.startsWith("~") || trimmed.includes(path.sep)) {
    return api.resolvePath(trimmed);
  }
  return trimmed;
}

function slugifyRootId(raw, fallback) {
  const source = typeof raw === "string" ? raw : "";
  const normalized = source.trim().replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  return normalized || fallback;
}

function resolveConfigPath(input, api, workspaceDir) {
  if (typeof input !== "string" || !input.trim()) {
    return "";
  }
  const trimmed = input.trim();
  if (trimmed.startsWith("~")) {
    return api.resolvePath(trimmed);
  }
  if (path.isAbsolute(trimmed)) {
    return trimmed;
  }
  return path.resolve(workspaceDir, trimmed);
}

function uniqueRoots(items) {
  const seenIds = new Set();
  const roots = [];
  for (const item of items) {
    if (!item || typeof item.id !== "string" || typeof item.path !== "string") {
      continue;
    }
    const id = item.id.trim();
    const rootPath = item.path.trim();
    if (!id || !rootPath || seenIds.has(id)) {
      continue;
    }
    seenIds.add(id);
    roots.push({ id, path: rootPath });
  }
  return roots;
}

function buildRoots({ api, config, workspaceDir }) {
  const roots = [];
  if (config.includeWorkspaceMemory) {
    roots.push({ id: "workspace-memory-md", path: path.join(workspaceDir, "MEMORY.md") });
    roots.push({ id: "workspace-memory", path: path.join(workspaceDir, "memory") });
  }
  if (config.includeWorkspaceBank) {
    roots.push({ id: "workspace-bank", path: path.join(workspaceDir, "bank") });
  }
  for (let idx = 0; idx < config.extraRoots.length; idx += 1) {
    const extra = config.extraRoots[idx];
    if (!extra || typeof extra !== "object") {
      continue;
    }
    const id = slugifyRootId(extra.id, `extra-${idx + 1}`);
    const rootPath = resolveConfigPath(extra.path, api, workspaceDir);
    if (!rootPath) {
      continue;
    }
    roots.push({ id, path: rootPath });
  }
  return uniqueRoots(roots);
}

function defaultAgentId(config) {
  const list = Array.isArray(config?.agents?.list) ? config.agents.list : [];
  const entries = list.filter((entry) => entry && typeof entry === "object" && typeof entry.id === "string");
  const chosen = entries.find((entry) => entry.default) || entries[0];
  return chosen?.id?.trim() || "main";
}

function resolveWorkspaceDirForCli(api) {
  const cfg = api.config || {};
  const agentId = defaultAgentId(cfg);
  const resolved = api.runtime?.agent?.resolveAgentWorkspaceDir
    ? api.runtime.agent.resolveAgentWorkspaceDir(cfg, agentId)
    : undefined;
  if (typeof resolved === "string" && resolved.trim()) {
    return resolved;
  }
  return process.cwd();
}

function resolveWorkspaceDirForTool(ctx, api) {
  if (typeof ctx?.workspaceDir === "string" && ctx.workspaceDir.trim()) {
    return ctx.workspaceDir;
  }
  if (typeof ctx?.agentId === "string" && ctx.agentId.trim() && api.runtime?.agent?.resolveAgentWorkspaceDir) {
    const resolved = api.runtime.agent.resolveAgentWorkspaceDir(api.config || {}, ctx.agentId);
    if (typeof resolved === "string" && resolved.trim()) {
      return resolved;
    }
  }
  return resolveWorkspaceDirForCli(api);
}

function resolveToolContext(ctx, api, config) {
  const workspaceDir = resolveWorkspaceDirForTool(ctx, api);
  const roots = buildRoots({ api, config, workspaceDir });
  if (!workspaceDir || roots.length === 0) return null;
  return { workspaceDir, roots };
}

function runIgrepJson({ api, config, subcommand, payload }) {
  const command = resolveCommand(api, config.command);
  const args = ["openclaw", subcommand, "--payload", "-"];

  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      stdio: ["pipe", "pipe", "pipe"],
      env: process.env
    });
    let stdout = "";
    let stderr = "";
    let timedOut = false;
    const timeout = setTimeout(() => {
      timedOut = true;
      child.kill("SIGTERM");
    }, config.timeoutMs);

    child.stdout.on("data", (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.on("error", (err) => {
      clearTimeout(timeout);
      reject(err);
    });
    child.on("close", (code, signal) => {
      clearTimeout(timeout);
      if (timedOut) {
        reject(new Error(`igrep command timed out after ${config.timeoutMs}ms`));
        return;
      }
      if (code !== 0) {
        // CLI now outputs JSON error to stdout on failure; try parsing it first
        let reason;
        try {
          const parsed = JSON.parse(stdout);
          const rawError = parsed?.error;
          reason = (typeof rawError === "string" ? rawError : null) || stderr.trim() || `exit code ${code}`;
        } catch {
          reason = stderr.trim() || stdout.trim() || `exit code ${code}${signal ? ` (${signal})` : ""}`;
        }
        reject(new Error(reason));
        return;
      }
      try {
        resolve(JSON.parse(stdout || "{}"));
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        reject(new Error(`Failed to parse igrep JSON output: ${message}`));
      }
    });

    child.stdin.end(JSON.stringify(payload));
  });
}

function buildUnavailablePayload(err) {
  const message = err instanceof Error ? err.message : String(err);
  return {
    results: [],
    disabled: true,
    unavailable: true,
    error: message || "igrep memory unavailable",
    warning: "igrep memory retrieval is unavailable.",
    action: "Check igrep plugin configuration and retry memory_search."
  };
}

function renderResultLine(item) {
  return `${item.path}#L${item.startLine}-L${item.endLine} (${item.score})`;
}

function buildSearchPayload({ query, workspaceDir, roots, maxResults, rootFilter, corpus, config }) {
  const payload = {
    query,
    workspace_root: workspaceDir,
    roots,
    max_results: positiveInteger(maxResults, config.defaultMaxResults),
    per_root_top_k: config.perRootTopK,
    max_snippet_chars: config.maxSnippetChars,
    search_mode: config.searchMode,
    corpus: typeof corpus === "string" && corpus.trim() ? corpus.trim() : "memory",
    intent: `Memory recall: ${query.slice(0, 200)}`
  };
  if (Array.isArray(rootFilter) && rootFilter.length > 0) {
    payload.root_filter = rootFilter;
  }
  return payload;
}

function buildGetPayload({ relPath, workspaceDir, roots, fromLine, lineCount, corpus }) {
  return {
    path: relPath,
    workspace_root: workspaceDir,
    roots,
    from: Number.isInteger(fromLine) ? fromLine : undefined,
    lines: Number.isInteger(lineCount) ? lineCount : undefined,
    corpus: typeof corpus === "string" && corpus.trim() ? corpus.trim() : "memory",
    mode: "normal"
  };
}

function buildWritePayload({ relPath, content, writeMode, workspaceDir, roots }) {
  return {
    path: relPath,
    content,
    mode: writeMode || "overwrite",
    workspace_root: workspaceDir,
    roots
  };
}

async function pathExists(inputPath) {
  try {
    await fs.access(inputPath);
    return true;
  } catch {
    return false;
  }
}

async function listMarkdownFilesRecursive(rootDir) {
  const entries = await fs.readdir(rootDir, { withFileTypes: true }).catch(() => []);
  const files = [];
  for (const entry of entries) {
    const fullPath = path.join(rootDir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await listMarkdownFilesRecursive(fullPath)));
      continue;
    }
    if (entry.isFile() && entry.name.endsWith(".md")) {
      files.push(fullPath);
    }
  }
  return files.sort((left, right) => left.localeCompare(right));
}

function resolveArtifactWorkspaces(api, cfg) {
  const agents = Array.isArray(cfg?.agents?.list)
    ? cfg.agents.list.filter((entry) => entry && typeof entry === "object" && typeof entry.id === "string")
    : [];
  const byWorkspace = new Map();

  for (const agent of agents) {
    const agentId = agent.id.trim();
    if (!agentId) continue;
    const workspaceDir = api.runtime?.agent?.resolveAgentWorkspaceDir
      ? api.runtime.agent.resolveAgentWorkspaceDir(cfg, agentId)
      : "";
    if (typeof workspaceDir !== "string" || !workspaceDir.trim()) continue;
    const normalized = workspaceDir.trim();
    const existing = byWorkspace.get(normalized) || { workspaceDir: normalized, agentIds: [] };
    existing.agentIds.push(agentId);
    byWorkspace.set(normalized, existing);
  }

  if (byWorkspace.size === 0) {
    const workspaceDir = resolveWorkspaceDirForCli(api);
    byWorkspace.set(workspaceDir, { workspaceDir, agentIds: [defaultAgentId(cfg)] });
  }

  return [...byWorkspace.values()];
}

async function collectWorkspaceArtifacts({ workspaceDir, agentIds }) {
  const artifacts = [];
  const memoryMd = path.join(workspaceDir, "MEMORY.md");
  if (await pathExists(memoryMd)) {
    artifacts.push({
      kind: "memory-root",
      workspaceDir,
      relativePath: "MEMORY.md",
      absolutePath: memoryMd,
      agentIds,
      contentType: "markdown"
    });
  }

  for (const dirName of ["memory", "bank"]) {
    const rootDir = path.join(workspaceDir, dirName);
    for (const absolutePath of await listMarkdownFilesRecursive(rootDir)) {
      const relativePath = path.relative(workspaceDir, absolutePath).replace(/\\/g, "/");
      artifacts.push({
        kind: dirName === "memory" ? "daily-note" : "knowledge-bank",
        workspaceDir,
        relativePath,
        absolutePath,
        agentIds,
        contentType: "markdown"
      });
    }
  }

  return artifacts;
}

async function listIgrepMemoryPublicArtifacts({ api, cfg }) {
  const artifacts = [];
  for (const workspace of resolveArtifactWorkspaces(api, cfg)) {
    artifacts.push(...(await collectWorkspaceArtifacts(workspace)));
  }
  const deduped = new Map();
  for (const artifact of artifacts) {
    deduped.set(`${artifact.workspaceDir}\0${artifact.relativePath}\0${artifact.kind}`, artifact);
  }
  return [...deduped.values()];
}

// ---------------------------------------------------------------------------
// Plugin entry
// ---------------------------------------------------------------------------

export default definePluginEntry({
  id: manifest.id,
  name: manifest.name,
  description: manifest.description,
  kind: manifest.kind,
  configSchema: manifest.configSchema,
  register(api) {
    const config = resolvePluginConfig(api.pluginConfig);

    api.registerMemoryCapability({
      promptBuilder: buildMemoryPromptSection,
      publicArtifacts: {
        async listArtifacts({ cfg }) {
          return await listIgrepMemoryPublicArtifacts({ api, cfg });
        }
      }
    });

    api.registerTool(
      (ctx) => {
        const resolved = resolveToolContext(ctx, api, config);
        if (!resolved) return null;
        const { workspaceDir, roots } = resolved;

        return {
          name: "memory_search",
          label: "Memory Search",
          description:
            "Mandatory recall step: search MEMORY.md, memory/, bank/, and configured extra roots " +
            "with igrep noindex retrieval before answering questions about prior work, decisions, " +
            "dates, people, preferences, or todos.",
          parameters: SEARCH_PARAMETERS,
          async execute(_toolCallId, params) {
            try {
              const query = typeof params?.query === "string" ? params.query.trim() : "";
              if (!query) {
                throw new Error("query required");
              }
              const corpus = normalizeCorpus(params?.corpus, "memory");
              const minScore = readMinScore(params);
              if (corpus === "wiki") {
                const supplementResults = await searchCorpusSupplements({
                  query,
                  maxResults: params?.maxResults,
                  agentSessionKey: ctx?.sessionKey,
                  corpus
                });
                const results = applyMinScore(supplementResults, minScore);
                return jsonResult({
                  provider: "igrep",
                  route: "supplements",
                  corpus,
                  results
                });
              }
              const result = await runIgrepJson({
                api,
                config,
                subcommand: "memory-search",
                payload: buildSearchPayload({
                  query,
                  workspaceDir,
                  roots,
                  maxResults: params?.maxResults,
                  rootFilter: params?.rootFilter,
                  corpus,
                  config
                })
              });
              if (corpus === "all") {
                const supplements = await searchCorpusSupplements({
                  query,
                  maxResults: params?.maxResults,
                  agentSessionKey: ctx?.sessionKey,
                  corpus
                });
                const ownResults = Array.isArray(result.results) ? result.results : [];
                result.results = rankSearchResults(
                  [...ownResults, ...supplements],
                  readPositiveLimit(params?.maxResults, config.defaultMaxResults)
                );
              }
              result.results = applyMinScore(result.results, minScore);
              return jsonResult(result);
            } catch (err) {
              return jsonResult(buildUnavailablePayload(err));
            }
          }
        };
      },
      { names: ["memory_search"] }
    );

    api.registerTool(
      (ctx) => {
        const resolved = resolveToolContext(ctx, api, config);
        if (!resolved) return null;
        const { workspaceDir, roots } = resolved;

        return {
          name: "memory_get",
          label: "Memory Get",
          description:
            "Read a specific memory file path returned by memory_search, with optional from/lines windowing.",
          parameters: GET_PARAMETERS,
          async execute(_toolCallId, params) {
            try {
              const relPath = typeof params?.path === "string" ? params.path.trim() : "";
              if (!relPath) {
                throw new Error("path required");
              }
              const corpus = normalizeCorpus(params?.corpus, "memory");
              if (corpus === "wiki") {
                const supplement = await getCorpusSupplement({
                  lookup: relPath,
                  fromLine: params?.from,
                  lineCount: params?.lines,
                  agentSessionKey: ctx?.sessionKey,
                  corpus
                });
                return jsonResult(
                  supplementGetToMemoryGetResult(supplement, relPath) || {
                    path: relPath,
                    text: "",
                    disabled: true,
                    error: "wiki corpus result not found"
                  }
                );
              }
              const result = await runIgrepJson({
                api,
                config,
                subcommand: "memory-get",
                payload: buildGetPayload({
                  relPath,
                  workspaceDir,
                  roots,
                  fromLine: params?.from,
                  lineCount: params?.lines,
                  corpus
                })
              });
              if (corpus === "all" && !result.text) {
                const supplement = await getCorpusSupplement({
                  lookup: relPath,
                  fromLine: params?.from,
                  lineCount: params?.lines,
                  agentSessionKey: ctx?.sessionKey,
                  corpus
                });
                return jsonResult(supplementGetToMemoryGetResult(supplement, relPath) || result);
              }
              return jsonResult(result);
            } catch (err) {
              const message = err instanceof Error ? err.message : String(err);
              return jsonResult({ path: params?.path || "", text: "", disabled: true, error: message });
            }
          }
        };
      },
      { names: ["memory_get"] }
    );

    if (config.writeEnabled) {
      api.registerTool(
        (ctx) => {
          const resolved = resolveToolContext(ctx, api, config);
          if (!resolved) return null;
          const { workspaceDir, roots } = resolved;

          return {
            name: "memory_write",
            label: "Memory Write",
            description:
              "Write or append content to a memory file within MEMORY.md, memory/, bank/, or configured extra roots. " +
              "Use to persist decisions, preferences, entities, and context for future recall.",
            parameters: WRITE_PARAMETERS,
            async execute(_toolCallId, params) {
              try {
                const relPath = typeof params?.path === "string" ? params.path.trim() : "";
                const content = typeof params?.content === "string" ? params.content : "";
                if (!relPath) {
                  throw new Error("path required");
                }
                if (!content) {
                  throw new Error("content required");
                }
                const result = await runIgrepJson({
                  api,
                  config,
                  subcommand: "memory-write",
                  payload: buildWritePayload({
                    relPath,
                    content,
                    writeMode: params?.mode,
                    workspaceDir,
                    roots
                  })
                });
                return jsonResult(result);
              } catch (err) {
                const message = err instanceof Error ? err.message : String(err);
                return jsonResult({ path: params?.path || "", written: false, error: message });
              }
            }
          };
        },
        { names: ["memory_write"] }
      );
    }

    api.registerCli(
      ({ program }) => {
        const memory = program.command("memory").description("igrep-backed memory search");

        memory
          .command("status")
          .description("Show igrep memory roots and adapter status")
          .option("--json", "JSON output")
          .action(async (opts) => {
            const workspaceDir = resolveWorkspaceDirForCli(api);
            const result = await runIgrepJson({
              api,
              config,
              subcommand: "memory-status",
              payload: {
                workspace_root: workspaceDir,
                roots: buildRoots({ api, config, workspaceDir })
              }
            });
            if (opts.json) {
              console.log(JSON.stringify(result, null, 2));
              return;
            }
            console.log(`provider: ${result.provider}`);
            console.log(`strategy: ${result.strategy}`);
            console.log(`workspace: ${result.workspaceRoot}`);
            for (const root of result.roots || []) {
              console.log(`- ${root.id}: ${root.path} [${root.kind}]`);
            }
            for (const warning of result.warnings || []) {
              console.log(`warning: ${warning}`);
            }
          });

        memory
          .command("search")
          .description("Search memory roots with igrep noindex recall")
          .argument("<query>", "Search query")
          .option("--max-results <n>", "Max results", `${config.defaultMaxResults}`)
          .option("--root-filter <ids...>", "Limit to specific root ids")
          .option("--json", "JSON output")
          .action(async (query, opts) => {
            const workspaceDir = resolveWorkspaceDirForCli(api);
            const result = await runIgrepJson({
              api,
              config,
              subcommand: "memory-search",
              payload: buildSearchPayload({
                query,
                workspaceDir,
                roots: buildRoots({ api, config, workspaceDir }),
                maxResults: parseInt(opts.maxResults, 10),
                rootFilter: opts.rootFilter,
                corpus: "memory",
                config
              })
            });
            if (opts.json) {
              console.log(JSON.stringify(result, null, 2));
              return;
            }
            const items = Array.isArray(result.results) ? result.results : [];
            if (items.length === 0) {
              console.log("No memory matches found.");
              return;
            }
            for (const item of items) {
              console.log(renderResultLine(item));
              console.log(item.snippet);
              console.log("");
            }
          });

        memory
          .command("get")
          .description("Read one memory file path")
          .argument("<path>", "Path returned by memory_search")
          .option("--from <n>", "Start line")
          .option("--lines <n>", "Line count")
          .option("--json", "JSON output")
          .action(async (targetPath, opts) => {
            const workspaceDir = resolveWorkspaceDirForCli(api);
            const result = await runIgrepJson({
              api,
              config,
              subcommand: "memory-get",
              payload: buildGetPayload({
                relPath: targetPath,
                workspaceDir,
                roots: buildRoots({ api, config, workspaceDir }),
                fromLine: opts.from != null ? parseInt(opts.from, 10) : undefined,
                lineCount: opts.lines != null ? parseInt(opts.lines, 10) : undefined,
                corpus: "memory"
              })
            });
            if (opts.json) {
              console.log(JSON.stringify(result, null, 2));
              return;
            }
            console.log(result.text || "");
          });

        if (config.writeEnabled) {
          memory
            .command("write")
            .description("Write content to a memory file")
            .argument("<path>", "Relative path within a memory root")
            .argument("<content>", "Content to write")
            .option("--mode <mode>", "Write mode: create, overwrite, append", "overwrite")
            .option("--json", "JSON output")
            .action(async (targetPath, content, opts) => {
              const workspaceDir = resolveWorkspaceDirForCli(api);
              const result = await runIgrepJson({
                api,
                config,
                subcommand: "memory-write",
                payload: buildWritePayload({
                  relPath: targetPath,
                  content,
                  writeMode: opts.mode,
                  workspaceDir,
                  roots: buildRoots({ api, config, workspaceDir })
                })
              });
              if (opts.json) {
                console.log(JSON.stringify(result, null, 2));
                return;
              }
              console.log(result.written ? `Written: ${result.path}` : `Failed: ${result.error || "unknown"}`);
            });
        }

        memory
          .command("index")
          .description("Show igrep-memory indexing behavior")
          .action(() => {
            console.log("igrep-memory uses noindex recall. No separate memory index build step is required.");
          });
      },
      { commands: ["memory"], descriptors: [{ name: "memory", description: "igrep-backed memory search" }] }
    );
  }
});
