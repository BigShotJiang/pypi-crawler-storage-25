# igrep-memory

`igrep-memory` is the opt-in OpenClaw `kind: "memory"` replacement plugin. It
keeps the plugin thin and delegates retrieval to the `igrep` CLI, but enabling
it replaces OpenClaw's default `memory-core` slot.

For non-invasive recall that keeps memory-core, QMD, memory-wiki, and Active
Memory intact, prefer:

```bash
igrep openclaw plugin setup --flavor search
```

Requires OpenClaw >= 2026.4.26 (current plugin-sdk surface).

Design:

- Tools: `memory_search`, `memory_get`, and opt-in `memory_write`
- System prompt/public artifacts: `registerMemoryCapability({ promptBuilder, publicArtifacts })`
- Plugin entry: `definePluginEntry(...)`
- Retrieval engine: igrep noindex recall (configurable mode: fast/normal/ultra)
- Root model: `MEMORY.md`, `memory/`, `bank/`, plus configured `extraRoots`
- Index model: none; this plugin is intentionally grep-like and multi-root

## Compatibility

Activation still handles older OpenClaw config CLI variants:

- **Activation**: tries `--batch-json` first; falls back to per-key `config set` on older OpenClaw
- The unscoped package name (`igrep-memory`, derived from `@igrep/igrep-memory`) must match the manifest id (`igrep-memory`) — OpenClaw derives plugin id from package name

## Quick start

```bash
igrep openclaw plugin setup --flavor memory
igrep openclaw plugin setup --flavor memory --dry-run
```

`igrep openclaw plugin setup --flavor memory` runs `install + activate + doctor`.
The no-flag form remains a backward-compatible alias for `--flavor memory`.

`igrep skill install --target openclaw` is separate. It installs workspace
skill files, not the native OpenClaw memory plugin.

## Search mode

Default search mode is `normal` (noindex + NLP keyword expansion).
Override via:

1. Plugin config: `"searchMode": "fast"` in `openclaw.json`
2. CLI: `igrep openclaw plugin activate --search-mode fast`
3. Env var: `IGREP_OPENCLAW_SEARCH_MODE=fast` in `~/.igreprc/.env`

Modes: `fast` (dense + NLP, no LLM), `normal` (+ LLM expansion), `ultra` (deepest).
`flash` is excluded — memory recall needs at minimum dense embedding for quality.

## LLM zero-config fallback

`normal` / `ultra` search modes call an LLM for query expansion. If the user
hasn't configured `IGREP_LLM_URL`, igrep transparently falls back to the
OpenAI SDK's standard env vars:

- `OPENAI_API_KEY` — required to activate fallback
- `OPENAI_BASE_URL` — optional, defaults to `https://api.openai.com/v1`
- `OPENAI_MODEL` — optional, defaults to `gpt-5.4-nano`

Priority stays `IGREP_LLM_*` > project `.env` > user `.env` > `OPENAI_*`.
Scope is **LLM only** — embedding / rerank / OCR still require explicit
`IGREP_*_URL` (no OpenAI fallback for those).

OpenClaw passes its **entire** `process.env` to the spawned `igrep` CLI
(`env: process.env`, no filtering), so any env var visible to the OpenClaw
process reaches igrep automatically.

**⚠️ launchd / systemd caveat**: background service managers do **not**
inherit the user's shell environment. If you launch OpenClaw via launchd
(macOS) or systemd (Linux), `OPENAI_API_KEY` exported in `~/.zshrc` /
`~/.bashrc` will **not** reach the OpenClaw process, and thus will not
reach igrep. Add the variables explicitly to the service unit:

```ini
# systemd (Linux) — /etc/systemd/system/openclaw.service
[Service]
Environment="OPENAI_API_KEY=sk-..."
Environment="OPENAI_MODEL=gpt-5.4-nano"
```

```xml
<!-- launchd (macOS) — ~/Library/LaunchAgents/ai.openclaw.plist -->
<key>EnvironmentVariables</key>
<dict>
  <key>OPENAI_API_KEY</key><string>sk-...</string>
  <key>OPENAI_MODEL</key><string>gpt-5.4-nano</string>
</dict>
```

When running OpenClaw from an interactive terminal the fallback works
without any extra setup.

## Verification

```bash
# CLI pipeline tests (no gateway needed, 9 checks)
./scripts/verify-openclaw-cli

# End-to-end agent conversation (requires running gateway)
./scripts/verify-openclaw-e2e --openclaw /path/to/openclaw
```

## Advanced

Development path:

```bash
igrep openclaw plugin path
openclaw plugins install -l "$(igrep openclaw plugin path)"
```

Manual commands:

```bash
igrep openclaw plugin install
igrep openclaw plugin activate
igrep openclaw plugin activate --search-mode fast
igrep openclaw plugin doctor
igrep openclaw plugin config
igrep openclaw plugin setup --extra-root notes=~/notes/openclaw
```

## Config shape

```json
{
  "plugins": {
    "slots": {
      "memory": "igrep-memory"
    },
    "entries": {
      "igrep-memory": {
        "config": {
          "command": "igrep",
          "defaultMaxResults": 6,
          "perRootTopK": 8,
          "maxSnippetChars": 700,
          "searchMode": "normal",
          "includeWorkspaceMemory": true,
          "includeWorkspaceBank": true,
          "write": { "enabled": false },
          "extraRoots": [
            { "id": "notes", "path": "~/notes/openclaw" }
          ]
        }
      }
    }
  }
}
```

Relative `extraRoots[].path` values are resolved against the active agent
workspace.

## Tools

| Tool | Description |
|------|-------------|
| `memory_search` | Semantic search across all configured memory roots |
| `memory_get` | Read a specific file path returned by `memory_search` |
| `memory_write` | Create, overwrite, or append content to memory files when `write.enabled` is true |

`memory_write` is disabled by default. If enabled, modes are `create` (fail if
exists), `overwrite` (default), and `append`.
Writes are restricted to configured roots with extension whitelist
(`.md`, `.txt`, `.json`, `.yaml`, etc.) and path traversal protection.
