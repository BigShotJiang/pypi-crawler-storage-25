# igrep-search

`igrep-search` is the recommended OpenClaw integration. It is additive: it
registers igrep tools and a `MemoryCorpusSupplement` without replacing
OpenClaw's default `memory-core`.

Use it when you want code, document, and external filesystem recall to appear
through `memory_search({ corpus: "all" })` while keeping memory-core, QMD,
memory-wiki, Active Memory, and other memory providers intact.

```bash
igrep openclaw plugin setup --flavor search
igrep openclaw plugin doctor --flavor search
```

For the explicit memory-slot replacement plugin, use:

```bash
igrep openclaw plugin setup --flavor memory
```

That mode replaces `plugins.slots.memory`; this plugin does not.
