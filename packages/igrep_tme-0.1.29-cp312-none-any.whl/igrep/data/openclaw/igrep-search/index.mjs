import { spawn } from "node:child_process";
import path from "node:path";
import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";

const SEARCH_PARAMETERS = {
  type: "object",
  additionalProperties: false,
  properties: {
    query: { type: "string" },
    scope: { type: "string", enum: ["workspace", "code", "docs", "sessions", "all"] },
    filters: {
      type: "object",
      additionalProperties: false,
      properties: {
        rootIds: { type: "array", items: { type: "string" } },
        sourceKinds: { type: "array", items: { type: "string" } },
        paths: { type: "array", items: { type: "string" } },
        sessionKey: { type: "string" },
        chatType: { type: "string" }
      }
    },
    topK: { type: "number" }
  },
  required: ["query"]
};

const GET_PARAMETERS = {
  type: "object",
  additionalProperties: false,
  properties: {
    ref: { type: "string" },
    fromLine: { type: "number" },
    lines: { type: "number" }
  },
  required: ["ref"]
};

const MORE_PARAMETERS = {
  type: "object",
  additionalProperties: false,
  properties: {
    ref: { type: "string" },
    direction: { type: "string", enum: ["before", "after", "both"] },
    lines: { type: "number" }
  },
  required: ["ref"]
};

function jsonResult(payload) {
  return {
    content: [{ type: "text", text: JSON.stringify(payload, null, 2) }],
    details: payload
  };
}

function positiveInteger(value, fallback) {
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

function resolveSearchMode(raw) {
  if (typeof raw === "string" && ["fast", "normal", "ultra"].includes(raw)) {
    return raw;
  }
  return "normal";
}

function resolvePluginConfig(raw) {
  const cfg = raw && typeof raw === "object" ? raw : {};
  const indexRoots = Array.isArray(cfg.indexRoots)
    ? cfg.indexRoots
    : Array.isArray(cfg.extraRoots)
      ? cfg.extraRoots
      : [];
  return {
    command: typeof cfg.command === "string" && cfg.command.trim() ? cfg.command.trim() : "igrep",
    timeoutMs: positiveInteger(cfg.timeoutMs, 15000),
    defaultMaxResults: positiveInteger(cfg.defaultMaxResults, 8),
    perRootTopK: positiveInteger(cfg.perRootTopK, 10),
    maxSnippetChars: positiveInteger(cfg.maxSnippetChars, 900),
    maxContextChars: positiveInteger(cfg.maxContextChars, 0),
    searchMode: resolveSearchMode(cfg.searchMode),
    includeWorkspaceMemory: cfg.includeWorkspaceMemory !== false,
    includeWorkspaceBank: cfg.includeWorkspaceBank !== false,
    includeSessions: cfg.includeSessions === true,
    indexRoots
  };
}

function resolveCommand(api, command) {
  if (typeof command !== "string" || !command.trim()) {
    return "igrep";
  }
  const trimmed = command.trim();
  if (trimmed.startsWith("~") || trimmed.includes(path.sep)) {
    return api.resolvePath(trimmed);
  }
  return trimmed;
}

function slugifyRootId(raw, fallback) {
  const source = typeof raw === "string" ? raw : "";
  const normalized = source.trim().replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  return normalized || fallback;
}

function resolveConfigPath(input, api, workspaceDir) {
  if (typeof input !== "string" || !input.trim()) {
    return "";
  }
  const trimmed = input.trim();
  if (trimmed.startsWith("~")) {
    return api.resolvePath(trimmed);
  }
  if (path.isAbsolute(trimmed)) {
    return trimmed;
  }
  return path.resolve(workspaceDir, trimmed);
}

function uniqueRoots(items) {
  const seenIds = new Set();
  const roots = [];
  for (const item of items) {
    if (!item || typeof item.id !== "string" || typeof item.path !== "string") {
      continue;
    }
    const id = item.id.trim();
    const rootPath = item.path.trim();
    if (!id || !rootPath || seenIds.has(id)) {
      continue;
    }
    seenIds.add(id);
    roots.push({
      id,
      path: rootPath,
      ...(typeof item.trust === "string" && item.trust.trim() ? { trust: item.trust.trim() } : {}),
      ...(typeof item.sourceKind === "string" && item.sourceKind.trim()
        ? { sourceKind: item.sourceKind.trim() }
        : {})
    });
  }
  return roots;
}

function defaultAgentId(config) {
  const list = Array.isArray(config?.agents?.list) ? config.agents.list : [];
  const entries = list.filter((entry) => entry && typeof entry === "object" && typeof entry.id === "string");
  const chosen = entries.find((entry) => entry.default) || entries[0];
  return chosen?.id?.trim() || "main";
}

function resolveWorkspaceDirForCli(api) {
  const cfg = api.config || {};
  const agentId = defaultAgentId(cfg);
  const resolved = api.runtime?.agent?.resolveAgentWorkspaceDir
    ? api.runtime.agent.resolveAgentWorkspaceDir(cfg, agentId)
    : undefined;
  if (typeof resolved === "string" && resolved.trim()) {
    return resolved;
  }
  return process.cwd();
}

function resolveWorkspaceDirForTool(ctx, api) {
  if (typeof ctx?.workspaceDir === "string" && ctx.workspaceDir.trim()) {
    return ctx.workspaceDir;
  }
  if (typeof ctx?.agentId === "string" && ctx.agentId.trim() && api.runtime?.agent?.resolveAgentWorkspaceDir) {
    const resolved = api.runtime.agent.resolveAgentWorkspaceDir(api.config || {}, ctx.agentId);
    if (typeof resolved === "string" && resolved.trim()) {
      return resolved;
    }
  }
  return resolveWorkspaceDirForCli(api);
}

function buildRoots({ api, config, workspaceDir }) {
  const roots = [];
  if (config.includeWorkspaceMemory) {
    roots.push({
      id: "workspace-memory-md",
      path: path.join(workspaceDir, "MEMORY.md"),
      sourceKind: "memory",
      trust: "agent-memory"
    });
    roots.push({
      id: "workspace-memory",
      path: path.join(workspaceDir, "memory"),
      sourceKind: "memory",
      trust: "agent-memory"
    });
  }
  if (config.includeWorkspaceBank) {
    roots.push({
      id: "workspace-bank",
      path: path.join(workspaceDir, "bank"),
      sourceKind: "memory",
      trust: "agent-memory"
    });
  }
  for (let idx = 0; idx < config.indexRoots.length; idx += 1) {
    const extra = config.indexRoots[idx];
    if (!extra || typeof extra !== "object") {
      continue;
    }
    const rootPath = resolveConfigPath(extra.path, api, workspaceDir);
    if (!rootPath) {
      continue;
    }
    roots.push({
      id: slugifyRootId(extra.id, `root-${idx + 1}`),
      path: rootPath,
      trust: typeof extra.trust === "string" && extra.trust.trim() ? extra.trust.trim() : "user-file",
      sourceKind:
        typeof extra.sourceKind === "string" && extra.sourceKind.trim() ? extra.sourceKind.trim() : "external"
    });
  }
  return uniqueRoots(roots);
}

function normalizePathForCompare(input) {
  return String(input || "").replace(/\\/g, "/").replace(/\/+$/g, "");
}

function rootIsWithinWorkspace(root, workspaceDir) {
  const workspace = normalizePathForCompare(workspaceDir);
  const rootPath = normalizePathForCompare(root?.path);
  return rootPath === workspace || rootPath.startsWith(`${workspace}/`);
}

function filterRootsByScope(roots, workspaceDir, scope) {
  if (scope === "workspace") {
    return roots.filter((root) => rootIsWithinWorkspace(root, workspaceDir));
  }
  if (scope === "code") {
    return roots.filter((root) => root.sourceKind === "code");
  }
  if (scope === "docs") {
    return roots.filter((root) => ["docs", "document"].includes(root.sourceKind));
  }
  if (scope === "sessions") {
    return [];
  }
  return roots;
}

function resolveToolContext(ctx, api, config) {
  const workspaceDir = resolveWorkspaceDirForTool(ctx, api);
  const roots = buildRoots({ api, config, workspaceDir });
  if (!workspaceDir || roots.length === 0) return null;
  return { workspaceDir, roots, sessionKey: ctx?.sessionKey };
}

function runIgrepJson({ api, config, subcommand, payload }) {
  const command = resolveCommand(api, config.command);
  const args = ["openclaw", subcommand, "--payload", "-"];

  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      stdio: ["pipe", "pipe", "pipe"],
      env: process.env
    });
    let stdout = "";
    let stderr = "";
    let timedOut = false;
    const timeout = setTimeout(() => {
      timedOut = true;
      child.kill("SIGTERM");
    }, config.timeoutMs);

    child.stdout.on("data", (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.on("error", (err) => {
      clearTimeout(timeout);
      reject(err);
    });
    child.on("close", (code, signal) => {
      clearTimeout(timeout);
      if (timedOut) {
        reject(new Error(`igrep command timed out after ${config.timeoutMs}ms`));
        return;
      }
      if (code !== 0) {
        let reason;
        try {
          const parsed = JSON.parse(stdout);
          reason = typeof parsed?.error === "string" ? parsed.error : null;
        } catch {
          reason = null;
        }
        reject(new Error(reason || stderr.trim() || stdout.trim() || `exit code ${code}${signal ? ` (${signal})` : ""}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout || "{}"));
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        reject(new Error(`Failed to parse igrep JSON output: ${message}`));
      }
    });

    child.stdin.end(JSON.stringify(payload));
  });
}

function buildUnavailablePayload(err) {
  const message = err instanceof Error ? err.message : String(err);
  return {
    results: [],
    disabled: true,
    unavailable: true,
    error: message || "igrep search unavailable",
    warning: "igrep search is unavailable.",
    action: "Check igrep plugin configuration and retry."
  };
}

function corpusForScope(scope) {
  if (scope === "sessions") return "sessions";
  return "all";
}

function asStringArray(value) {
  if (!Array.isArray(value)) return undefined;
  const items = value.filter((item) => typeof item === "string" && item.trim()).map((item) => item.trim());
  return items.length > 0 ? items : undefined;
}

function buildSearchPayload({
  query,
  workspaceDir,
  roots,
  maxResults,
  rootFilter,
  sourceKindFilter,
  pathFilter,
  chatType,
  config,
  scope,
  sessionKey
}) {
  const payload = {
    query,
    workspace_root: workspaceDir,
    roots,
    max_results: positiveInteger(maxResults, config.defaultMaxResults),
    per_root_top_k: config.perRootTopK,
    max_snippet_chars: config.maxSnippetChars,
    search_mode: config.searchMode,
    corpus: corpusForScope(scope),
    intent: `Evidence recall: ${query.slice(0, 200)}`
  };
  if (Array.isArray(rootFilter) && rootFilter.length > 0) {
    payload.root_filter = rootFilter;
  }
  if (Array.isArray(sourceKindFilter) && sourceKindFilter.length > 0) {
    payload.source_kind_filter = sourceKindFilter;
  }
  if (Array.isArray(pathFilter) && pathFilter.length > 0) {
    payload.path_filter = pathFilter;
  }
  if (typeof chatType === "string" && chatType.trim()) {
    payload.chat_type = chatType.trim();
  }
  if (sessionKey) {
    payload.session_key = sessionKey;
  }
  return payload;
}

function stripLineSuffix(ref) {
  const text = typeof ref === "string" ? ref.trim() : "";
  const match = text.match(/^(.*)#L(\d+)(?:-L?(\d+))?$/);
  if (!match) return { path: text };
  return {
    path: match[1],
    startLine: Number.parseInt(match[2], 10),
    endLine: Number.parseInt(match[3] || match[2], 10)
  };
}

function buildGetPayload({ ref, workspaceDir, roots, fromLine, lineCount }) {
  const parsed = stripLineSuffix(ref);
  return {
    path: parsed.path,
    workspace_root: workspaceDir,
    roots,
    from: Number.isInteger(fromLine) ? fromLine : undefined,
    lines: Number.isInteger(lineCount) ? lineCount : undefined,
    mode: "normal",
    corpus: "all"
  };
}

function buildMorePayload({ ref, workspaceDir, roots, direction, lines }) {
  const parsed = stripLineSuffix(ref);
  const count = positiveInteger(lines, 40);
  let fromLine = parsed.startLine;
  let lineCount = count;
  if (Number.isInteger(parsed.startLine) && Number.isInteger(parsed.endLine)) {
    if (direction === "before") {
      fromLine = Math.max(1, parsed.startLine - count);
      lineCount = parsed.startLine - fromLine;
    } else if (direction === "after") {
      fromLine = parsed.endLine + 1;
    } else {
      fromLine = Math.max(1, parsed.startLine - count);
      lineCount = parsed.endLine - fromLine + 1 + count;
    }
  }
  return buildGetPayload({ ref: parsed.path, workspaceDir, roots, fromLine, lineCount });
}

function mapSupplementResult(item) {
  const pathText = typeof item?.path === "string" ? item.path : "";
  const startLine = Number.isInteger(item?.startLine) ? item.startLine : undefined;
  const endLine = Number.isInteger(item?.endLine) ? item.endLine : undefined;
  return {
    corpus: "igrep",
    path: pathText,
    title: path.basename(pathText),
    kind: typeof item?.sourceKind === "string" ? item.sourceKind : "file",
    score: typeof item?.score === "number" ? item.score : 0,
    snippet: typeof item?.snippet === "string" ? item.snippet : "",
    id: typeof item?.id === "string" ? item.id : undefined,
    startLine,
    endLine,
    citation: typeof item?.citation === "string" ? item.citation : undefined,
    source: "igrep",
    provenanceLabel: typeof item?.trust === "string" ? item.trust : "user-file",
    sourceType: typeof item?.sourceKind === "string" ? item.sourceKind : "file",
    sourcePath: pathText
  };
}

function createSearchTool({ api, config }) {
  return async function executeSearch(ctx, params) {
    const resolved = resolveToolContext(ctx, api, config);
    if (!resolved) {
      throw new Error("No igrep roots are configured.");
    }
    const query = typeof params?.query === "string" ? params.query.trim() : "";
    if (!query) {
      throw new Error("query required");
    }
    const filters = params?.filters && typeof params.filters === "object" ? params.filters : {};
    const rootFilter = asStringArray(filters.rootIds);
    const sourceKindFilter = asStringArray(filters.sourceKinds);
    const pathFilter = asStringArray(filters.paths);
    const roots = filterRootsByScope(resolved.roots, resolved.workspaceDir, params?.scope);
    return await runIgrepJson({
      api,
      config,
      subcommand: "memory-search",
      payload: buildSearchPayload({
        query,
        workspaceDir: resolved.workspaceDir,
        roots,
        maxResults: params?.topK,
        rootFilter,
        sourceKindFilter,
        pathFilter,
        chatType: filters.chatType,
        config,
        scope: params?.scope,
        sessionKey: filters.sessionKey || resolved.sessionKey
      })
    });
  };
}

export default definePluginEntry({
  id: "igrep-search",
  name: "igrep Search",
  description: "Additive filesystem, code, document, and session evidence recall powered by igrep",
  configSchema: {
    type: "object",
    additionalProperties: false,
    properties: {
      command: { type: "string" },
      timeoutMs: { type: "number", minimum: 1000, maximum: 60000 },
      defaultMaxResults: { type: "number", minimum: 1, maximum: 50 },
      perRootTopK: { type: "number", minimum: 1, maximum: 50 },
      maxSnippetChars: { type: "number", minimum: 100, maximum: 4000 },
      searchMode: { type: "string", enum: ["fast", "normal", "ultra"] },
      includeWorkspaceMemory: { type: "boolean" },
      includeWorkspaceBank: { type: "boolean" },
      includeSessions: { type: "boolean" },
      maxContextChars: { type: "number", minimum: 100 },
      indexRoots: { type: "array" }
    }
  },
  register(api) {
    const config = resolvePluginConfig(api.pluginConfig);
    const executeSearch = createSearchTool({ api, config });

    api.registerTool(
      (ctx) => ({
        name: "igrep_search",
        label: "igrep Search",
        description: "Search local filesystem, code, and document evidence with igrep without replacing memory-core.",
        parameters: SEARCH_PARAMETERS,
        async execute(_toolCallId, params) {
          try {
            return jsonResult(await executeSearch(ctx, params));
          } catch (err) {
            return jsonResult(buildUnavailablePayload(err));
          }
        }
      }),
      { names: ["igrep_search"] }
    );

    api.registerTool(
      (ctx) => ({
        name: "igrep_get",
        label: "igrep Get",
        description: "Read an exact path or ref returned by igrep_search.",
        parameters: GET_PARAMETERS,
        async execute(_toolCallId, params) {
          try {
            const resolved = resolveToolContext(ctx, api, config);
            if (!resolved) throw new Error("No igrep roots are configured.");
            const ref = typeof params?.ref === "string" ? params.ref.trim() : "";
            if (!ref) throw new Error("ref required");
            return jsonResult(await runIgrepJson({
              api,
              config,
              subcommand: "memory-get",
              payload: buildGetPayload({
                ref,
                workspaceDir: resolved.workspaceDir,
                roots: resolved.roots,
                fromLine: params?.fromLine,
                lineCount: params?.lines
              })
            }));
          } catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            return jsonResult({ ref: params?.ref || "", text: "", disabled: true, error: message });
          }
        }
      }),
      { names: ["igrep_get"] }
    );

    api.registerTool(
      (ctx) => ({
        name: "igrep_more",
        label: "igrep More",
        description: "Expand context before, after, or around an igrep ref.",
        parameters: MORE_PARAMETERS,
        async execute(_toolCallId, params) {
          try {
            const resolved = resolveToolContext(ctx, api, config);
            if (!resolved) throw new Error("No igrep roots are configured.");
            const ref = typeof params?.ref === "string" ? params.ref.trim() : "";
            if (!ref) throw new Error("ref required");
            return jsonResult(await runIgrepJson({
              api,
              config,
              subcommand: "memory-get",
              payload: buildMorePayload({
                ref,
                workspaceDir: resolved.workspaceDir,
                roots: resolved.roots,
                direction: params?.direction || "both",
                lines: params?.lines
              })
            }));
          } catch (err) {
            const message = err instanceof Error ? err.message : String(err);
            return jsonResult({ ref: params?.ref || "", text: "", disabled: true, error: message });
          }
        }
      }),
      { names: ["igrep_more"] }
    );

    api.registerTool(
      (ctx) => ({
        name: "igrep_status",
        label: "igrep Status",
        description: "Show resolved igrep OpenClaw search roots and adapter status.",
        parameters: { type: "object", additionalProperties: false, properties: {} },
        async execute() {
          try {
            const resolved = resolveToolContext(ctx, api, config);
            if (!resolved) throw new Error("No igrep roots are configured.");
            return jsonResult(await runIgrepJson({
              api,
              config,
              subcommand: "memory-status",
              payload: {
                workspace_root: resolved.workspaceDir,
                roots: resolved.roots,
                search_mode: config.searchMode
              }
            }));
          } catch (err) {
            return jsonResult(buildUnavailablePayload(err));
          }
        }
      }),
      { names: ["igrep_status"] }
    );

    api.registerMemoryCorpusSupplement({
      async search({ query, maxResults, agentSessionKey }) {
        try {
          const workspaceDir = resolveWorkspaceDirForCli(api);
          const roots = buildRoots({ api, config, workspaceDir });
          const result = await runIgrepJson({
            api,
            config,
            subcommand: "memory-search",
            payload: buildSearchPayload({
              query,
              workspaceDir,
              roots,
              maxResults,
              rootFilter: undefined,
              config,
              scope: "all",
              sessionKey: agentSessionKey
            })
          });
          const items = Array.isArray(result.results) ? result.results : [];
          return items.map(mapSupplementResult);
        } catch {
          return [];
        }
      },
      async get({ lookup, fromLine, lineCount }) {
        try {
          const workspaceDir = resolveWorkspaceDirForCli(api);
          const roots = buildRoots({ api, config, workspaceDir });
          const result = await runIgrepJson({
            api,
            config,
            subcommand: "memory-get",
            payload: buildGetPayload({
              ref: lookup,
              workspaceDir,
              roots,
              fromLine,
              lineCount
            })
          });
          const content = typeof result?.text === "string" ? result.text : "";
          if (!content) return null;
          const parsed = stripLineSuffix(lookup);
          return {
            corpus: "igrep",
            path: parsed.path,
            title: path.basename(parsed.path),
            kind: "file",
            content,
            fromLine: Number.isInteger(fromLine) ? fromLine : 1,
            lineCount: Number.isInteger(lineCount) ? lineCount : content.split(/\r?\n/).length,
            id: lookup,
            provenanceLabel: "user-file",
            sourceType: "file",
            sourcePath: parsed.path
          };
        } catch {
          return null;
        }
      }
    });

    api.registerMemoryPromptSupplement(({ availableTools }) => {
      if (!availableTools.has("memory_search")) return [];
      return [
        "When file, code, or document evidence may live outside MEMORY.md, use memory_search with corpus=all to include igrep results."
      ];
    });
  }
});
