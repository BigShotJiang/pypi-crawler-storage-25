# igrep Search

Use `igrep_search` for local filesystem, code, and document evidence that may
live outside OpenClaw `MEMORY.md`.

When using OpenClaw `memory_search`, pass `corpus: "all"` to include igrep
supplement results alongside memory-core results. Use `igrep_get` or
`memory_get` with the returned path/ref to read exact evidence before relying on
a snippet.
