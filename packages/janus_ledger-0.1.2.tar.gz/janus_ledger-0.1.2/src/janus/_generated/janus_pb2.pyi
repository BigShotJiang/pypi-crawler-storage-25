from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Timestamp(_message.Message):
    __slots__ = ("seconds", "nanos")
    SECONDS_FIELD_NUMBER: _ClassVar[int]
    NANOS_FIELD_NUMBER: _ClassVar[int]
    seconds: int
    nanos: int
    def __init__(self, seconds: _Optional[int] = ..., nanos: _Optional[int] = ...) -> None: ...

class Entity(_message.Message):
    __slots__ = ("id", "external_id", "name", "description", "metadata", "created_at", "updated_at")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    external_id: str
    name: str
    description: str
    metadata: _containers.ScalarMap[str, str]
    created_at: Timestamp
    updated_at: Timestamp
    def __init__(self, id: _Optional[str] = ..., external_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., created_at: _Optional[_Union[Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[Timestamp, _Mapping]] = ...) -> None: ...

class CreateEntityRequest(_message.Message):
    __slots__ = ("external_id", "name", "description", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    external_id: str
    name: str
    description: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, external_id: _Optional[str] = ..., name: _Optional[str] = ..., description: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class CreateEntityResponse(_message.Message):
    __slots__ = ("entity",)
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    entity: Entity
    def __init__(self, entity: _Optional[_Union[Entity, _Mapping]] = ...) -> None: ...

class GetEntityRequest(_message.Message):
    __slots__ = ("external_id_or_id",)
    EXTERNAL_ID_OR_ID_FIELD_NUMBER: _ClassVar[int]
    external_id_or_id: str
    def __init__(self, external_id_or_id: _Optional[str] = ...) -> None: ...

class GetEntityResponse(_message.Message):
    __slots__ = ("entity",)
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    entity: Entity
    def __init__(self, entity: _Optional[_Union[Entity, _Mapping]] = ...) -> None: ...

class ListEntitiesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListEntitiesResponse(_message.Message):
    __slots__ = ("entities",)
    ENTITIES_FIELD_NUMBER: _ClassVar[int]
    entities: _containers.RepeatedCompositeFieldContainer[Entity]
    def __init__(self, entities: _Optional[_Iterable[_Union[Entity, _Mapping]]] = ...) -> None: ...

class Book(_message.Message):
    __slots__ = ("id", "name", "type", "currency", "balance", "metadata", "created_at", "updated_at", "entity_id", "entity_external_id")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    BALANCE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    ENTITY_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    type: str
    currency: str
    balance: int
    metadata: _containers.ScalarMap[str, str]
    created_at: Timestamp
    updated_at: Timestamp
    entity_id: str
    entity_external_id: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., type: _Optional[str] = ..., currency: _Optional[str] = ..., balance: _Optional[int] = ..., metadata: _Optional[_Mapping[str, str]] = ..., created_at: _Optional[_Union[Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[Timestamp, _Mapping]] = ..., entity_id: _Optional[str] = ..., entity_external_id: _Optional[str] = ...) -> None: ...

class CreateBookRequest(_message.Message):
    __slots__ = ("name", "type", "currency", "metadata", "entity_external_id")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    NAME_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    ENTITY_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    type: str
    currency: str
    metadata: _containers.ScalarMap[str, str]
    entity_external_id: str
    def __init__(self, name: _Optional[str] = ..., type: _Optional[str] = ..., currency: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., entity_external_id: _Optional[str] = ...) -> None: ...

class CreateBookResponse(_message.Message):
    __slots__ = ("book",)
    BOOK_FIELD_NUMBER: _ClassVar[int]
    book: Book
    def __init__(self, book: _Optional[_Union[Book, _Mapping]] = ...) -> None: ...

class GetBookRequest(_message.Message):
    __slots__ = ("type_or_id",)
    TYPE_OR_ID_FIELD_NUMBER: _ClassVar[int]
    type_or_id: str
    def __init__(self, type_or_id: _Optional[str] = ...) -> None: ...

class GetBookResponse(_message.Message):
    __slots__ = ("book",)
    BOOK_FIELD_NUMBER: _ClassVar[int]
    book: Book
    def __init__(self, book: _Optional[_Union[Book, _Mapping]] = ...) -> None: ...

class ListBooksRequest(_message.Message):
    __slots__ = ("type", "limit", "offset", "entity_external_id")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    ENTITY_EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    type: str
    limit: int
    offset: int
    entity_external_id: str
    def __init__(self, type: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., entity_external_id: _Optional[str] = ...) -> None: ...

class ListBooksResponse(_message.Message):
    __slots__ = ("books",)
    BOOKS_FIELD_NUMBER: _ClassVar[int]
    books: _containers.RepeatedCompositeFieldContainer[Book]
    def __init__(self, books: _Optional[_Iterable[_Union[Book, _Mapping]]] = ...) -> None: ...

class BookEntryInput(_message.Message):
    __slots__ = ("book", "debit", "credit", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    BOOK_FIELD_NUMBER: _ClassVar[int]
    DEBIT_FIELD_NUMBER: _ClassVar[int]
    CREDIT_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    book: str
    debit: int
    credit: int
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, book: _Optional[str] = ..., debit: _Optional[int] = ..., credit: _Optional[int] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class CreateJournalEntryRequest(_message.Message):
    __slots__ = ("idempotency_key", "effective_date", "book_entries", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    EFFECTIVE_DATE_FIELD_NUMBER: _ClassVar[int]
    BOOK_ENTRIES_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    idempotency_key: str
    effective_date: str
    book_entries: _containers.RepeatedCompositeFieldContainer[BookEntryInput]
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, idempotency_key: _Optional[str] = ..., effective_date: _Optional[str] = ..., book_entries: _Optional[_Iterable[_Union[BookEntryInput, _Mapping]]] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...

class JournalEntry(_message.Message):
    __slots__ = ("id", "idempotency_key", "effective_date", "metadata", "created_at", "reversed_at", "reverses_id", "book_entries")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    EFFECTIVE_DATE_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    REVERSED_AT_FIELD_NUMBER: _ClassVar[int]
    REVERSES_ID_FIELD_NUMBER: _ClassVar[int]
    BOOK_ENTRIES_FIELD_NUMBER: _ClassVar[int]
    id: str
    idempotency_key: str
    effective_date: str
    metadata: _containers.ScalarMap[str, str]
    created_at: Timestamp
    reversed_at: Timestamp
    reverses_id: str
    book_entries: _containers.RepeatedCompositeFieldContainer[BookEntry]
    def __init__(self, id: _Optional[str] = ..., idempotency_key: _Optional[str] = ..., effective_date: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ..., created_at: _Optional[_Union[Timestamp, _Mapping]] = ..., reversed_at: _Optional[_Union[Timestamp, _Mapping]] = ..., reverses_id: _Optional[str] = ..., book_entries: _Optional[_Iterable[_Union[BookEntry, _Mapping]]] = ...) -> None: ...

class BookEntry(_message.Message):
    __slots__ = ("id", "book_name", "debit", "credit", "currency", "book_balance", "entity_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    BOOK_NAME_FIELD_NUMBER: _ClassVar[int]
    DEBIT_FIELD_NUMBER: _ClassVar[int]
    CREDIT_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    BOOK_BALANCE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    book_name: str
    debit: int
    credit: int
    currency: str
    book_balance: int
    entity_id: str
    def __init__(self, id: _Optional[str] = ..., book_name: _Optional[str] = ..., debit: _Optional[int] = ..., credit: _Optional[int] = ..., currency: _Optional[str] = ..., book_balance: _Optional[int] = ..., entity_id: _Optional[str] = ...) -> None: ...

class CreateJournalEntryResponse(_message.Message):
    __slots__ = ("journal_entry",)
    JOURNAL_ENTRY_FIELD_NUMBER: _ClassVar[int]
    journal_entry: JournalEntry
    def __init__(self, journal_entry: _Optional[_Union[JournalEntry, _Mapping]] = ...) -> None: ...

class ReverseJournalEntryRequest(_message.Message):
    __slots__ = ("entry_id", "idempotency_key", "reason")
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    entry_id: str
    idempotency_key: str
    reason: str
    def __init__(self, entry_id: _Optional[str] = ..., idempotency_key: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class ReverseJournalEntryResponse(_message.Message):
    __slots__ = ("journal_entry",)
    JOURNAL_ENTRY_FIELD_NUMBER: _ClassVar[int]
    journal_entry: JournalEntry
    def __init__(self, journal_entry: _Optional[_Union[JournalEntry, _Mapping]] = ...) -> None: ...

class GetJournalEntryRequest(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: str
    def __init__(self, id: _Optional[str] = ...) -> None: ...

class GetJournalEntryByKeyRequest(_message.Message):
    __slots__ = ("idempotency_key",)
    IDEMPOTENCY_KEY_FIELD_NUMBER: _ClassVar[int]
    idempotency_key: str
    def __init__(self, idempotency_key: _Optional[str] = ...) -> None: ...

class GetJournalEntryResponse(_message.Message):
    __slots__ = ("journal_entry",)
    JOURNAL_ENTRY_FIELD_NUMBER: _ClassVar[int]
    journal_entry: JournalEntry
    def __init__(self, journal_entry: _Optional[_Union[JournalEntry, _Mapping]] = ...) -> None: ...

class GetBalanceRequest(_message.Message):
    __slots__ = ("book", "as_of")
    BOOK_FIELD_NUMBER: _ClassVar[int]
    AS_OF_FIELD_NUMBER: _ClassVar[int]
    book: str
    as_of: Timestamp
    def __init__(self, book: _Optional[str] = ..., as_of: _Optional[_Union[Timestamp, _Mapping]] = ...) -> None: ...

class GetBalanceResponse(_message.Message):
    __slots__ = ("book_id", "book_name", "balance", "currency", "as_of")
    BOOK_ID_FIELD_NUMBER: _ClassVar[int]
    BOOK_NAME_FIELD_NUMBER: _ClassVar[int]
    BALANCE_FIELD_NUMBER: _ClassVar[int]
    CURRENCY_FIELD_NUMBER: _ClassVar[int]
    AS_OF_FIELD_NUMBER: _ClassVar[int]
    book_id: str
    book_name: str
    balance: int
    currency: str
    as_of: Timestamp
    def __init__(self, book_id: _Optional[str] = ..., book_name: _Optional[str] = ..., balance: _Optional[int] = ..., currency: _Optional[str] = ..., as_of: _Optional[_Union[Timestamp, _Mapping]] = ...) -> None: ...

class GetBalancesRequest(_message.Message):
    __slots__ = ("books", "as_of")
    BOOKS_FIELD_NUMBER: _ClassVar[int]
    AS_OF_FIELD_NUMBER: _ClassVar[int]
    books: _containers.RepeatedScalarFieldContainer[str]
    as_of: Timestamp
    def __init__(self, books: _Optional[_Iterable[str]] = ..., as_of: _Optional[_Union[Timestamp, _Mapping]] = ...) -> None: ...

class GetBalancesResponse(_message.Message):
    __slots__ = ("balances",)
    BALANCES_FIELD_NUMBER: _ClassVar[int]
    balances: _containers.RepeatedCompositeFieldContainer[GetBalanceResponse]
    def __init__(self, balances: _Optional[_Iterable[_Union[GetBalanceResponse, _Mapping]]] = ...) -> None: ...
