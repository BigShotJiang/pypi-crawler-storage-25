"""
Janus -- Python gRPC Client

Connects to a remote janus-server via gRPC.

Example:
    >>> ledger = Janus(server_url="localhost:50051")
    >>> entity = ledger.create_entity("acme", "Acme Corp")
    >>> book = ledger.create_book("cash", "asset", entity.external_id)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Optional

# --- Data classes ---


@dataclass
class Entity:
    id: str
    external_id: str
    name: str
    description: Optional[str] = None
    metadata: str = ""
    created_at: str = ""
    updated_at: str = ""


@dataclass
class Book:
    id: str
    entity_id: str
    name: str
    book_type: str = "asset"
    currency: str = "USD"
    metadata: str = ""
    created_at: str = ""
    updated_at: str = ""


@dataclass
class BookEntry:
    id: str
    book_name: str
    debit: Optional[int] = None
    credit: Optional[int] = None
    currency: str = "USD"
    book_balance: int = 0
    entity_id: Optional[str] = None


@dataclass
class JournalEntry:
    id: str
    idempotency_key: str
    effective_date: str = ""
    metadata: str = ""
    created_at: str = ""
    reversed_at: Optional[str] = None
    reversed_by_id: Optional[str] = None
    reverses_id: Optional[str] = None
    book_entries: list = field(default_factory=list)


@dataclass
class BalanceResult:
    book_id: str
    book_name: str
    balance: int = 0
    currency: str = "USD"
    as_of: str = ""


# --- Helpers ---


def money(amount: int, currency: str = "USD") -> dict:
    """Create a money dict from minor units (cents)."""
    return {"amount": amount, "currency": currency}


def from_decimal(amount: Decimal | float, currency: str = "USD", decimals: int = 2) -> dict:
    """Create a money dict from a decimal amount."""
    multiplier = 10**decimals
    return {"amount": int(round(float(amount) * multiplier)), "currency": currency}


def to_decimal(amount: int, decimals: int = 2) -> Decimal:
    """Convert minor units to decimal."""
    return Decimal(amount) / Decimal(10**decimals)


# --- Client ---


class Janus:
    """Janus gRPC client.

    Args:
        server_url: gRPC server address (e.g., "localhost:50051").
        secure: Use TLS for the gRPC connection.
    """

    def __init__(
        self,
        *,
        server_url: str,
        secure: bool = False,
    ):
        import grpc
        from janus._generated import janus_pb2 as pb2
        from janus._generated import janus_pb2_grpc as pb2_grpc

        self._pb2 = pb2
        self._pb2_grpc = pb2_grpc

        if secure:
            credentials = grpc.ssl_channel_credentials()
            self._channel = grpc.secure_channel(server_url, credentials)
        else:
            self._channel = grpc.insecure_channel(server_url)

        self._stub = self._pb2_grpc.JanusServiceStub(self._channel)

    # --- Proto-to-dataclass mapping helpers ---

    def _map_entity(self, e):
        return Entity(
            id=e.id,
            external_id=e.external_id,
            name=e.name,
            description=e.description or None,
            metadata=str(dict(e.metadata)),
            created_at=str(e.created_at.seconds) if e.HasField("created_at") else "",
            updated_at=str(e.updated_at.seconds) if e.HasField("updated_at") else "",
        )

    def _map_book(self, b):
        return Book(
            id=b.id,
            entity_id=b.entity_id,
            name=b.name,
            book_type=b.type or "asset",
            currency=b.currency,
            metadata=str(dict(b.metadata)),
            created_at=str(b.created_at.seconds) if b.HasField("created_at") else "",
            updated_at=str(b.updated_at.seconds) if b.HasField("updated_at") else "",
        )

    def _map_book_entry(self, be):
        return BookEntry(
            id=be.id,
            book_name=be.book_name,
            debit=be.debit if be.HasField("debit") else None,
            credit=be.credit if be.HasField("credit") else None,
            currency=be.currency,
            book_balance=be.book_balance,
            entity_id=be.entity_id or None,
        )

    def _map_journal_entry(self, je):
        return JournalEntry(
            id=je.id,
            idempotency_key=je.idempotency_key,
            effective_date=je.effective_date,
            metadata=str(dict(je.metadata)),
            created_at=str(je.created_at.seconds) if je.HasField("created_at") else "",
            reversed_at=str(je.reversed_at.seconds) if je.HasField("reversed_at") else None,
            reversed_by_id=None,
            reverses_id=je.reverses_id if je.HasField("reverses_id") else None,
            book_entries=[self._map_book_entry(be) for be in je.book_entries],
        )

    def _map_balance(self, b):
        return BalanceResult(
            book_id=b.book_id,
            book_name=b.book_name,
            balance=b.balance,
            currency=b.currency,
            as_of=str(b.as_of.seconds) if b.HasField("as_of") else "",
        )

    # --- Entity Operations ---

    def create_entity(
        self,
        external_id: str,
        name: str,
        description: Optional[str] = None,
        metadata: Optional[str] = None,
    ) -> Entity:
        import json
        meta = json.loads(metadata) if metadata else {}
        req = self._pb2.CreateEntityRequest(
            external_id=external_id,
            name=name,
            metadata=meta,
        )
        if description:
            req.description = description
        resp = self._stub.CreateEntity(req)
        return self._map_entity(resp.entity)

    def get_entity(self, external_id_or_id: str) -> Optional[Entity]:
        resp = self._stub.GetEntity(self._pb2.GetEntityRequest(external_id_or_id=external_id_or_id))
        if not resp.HasField("entity"):
            return None
        return self._map_entity(resp.entity)

    def list_entities(self) -> list[Entity]:
        resp = self._stub.ListEntities(self._pb2.ListEntitiesRequest())
        return [self._map_entity(e) for e in resp.entities]

    # --- Book Operations ---

    def create_book(
        self,
        name: str,
        book_type: str,
        entity_id: str,
        currency: Optional[str] = None,
        metadata: Optional[str] = None,
    ) -> Book:
        import json
        meta = json.loads(metadata) if metadata else {}
        req = self._pb2.CreateBookRequest(
            entity_external_id=entity_id,
            name=name,
            type=book_type,
            currency=currency or "USD",
            metadata=meta,
        )
        resp = self._stub.CreateBook(req)
        return self._map_book(resp.book)

    def get_book(self, name_or_id: str) -> Optional[Book]:
        resp = self._stub.GetBook(self._pb2.GetBookRequest(type_or_id=name_or_id))
        if not resp.HasField("book"):
            return None
        return self._map_book(resp.book)

    def list_books(
        self,
        book_type: Optional[str] = None,
        entity_id: Optional[str] = None,
    ) -> list[Book]:
        req = self._pb2.ListBooksRequest()
        if book_type:
            req.type = book_type
        if entity_id:
            req.entity_external_id = entity_id
        resp = self._stub.ListBooks(req)
        return [self._map_book(b) for b in resp.books]

    # --- Journal Entry Operations ---

    def create_journal_entry(
        self,
        idempotency_key: str,
        book_entries_json: str,
        effective_date: Optional[str] = None,
        metadata: Optional[str] = None,
    ) -> JournalEntry:
        import json
        entries = json.loads(book_entries_json)
        pb_entries = []
        for e in entries:
            entry = self._pb2.BookEntryInput(book=e["book"], metadata=e.get("metadata", {}))
            if "debit" in e and e["debit"] is not None:
                entry.debit = e["debit"]
            if "credit" in e and e["credit"] is not None:
                entry.credit = e["credit"]
            pb_entries.append(entry)

        meta = json.loads(metadata) if metadata else {}
        req = self._pb2.CreateJournalEntryRequest(
            idempotency_key=idempotency_key,
            book_entries=pb_entries,
            metadata=meta,
        )
        if effective_date:
            req.effective_date = effective_date
        resp = self._stub.CreateJournalEntry(req)
        return self._map_journal_entry(resp.journal_entry)

    def get_journal_entry(self, id: str) -> Optional[JournalEntry]:
        resp = self._stub.GetJournalEntry(self._pb2.GetJournalEntryRequest(id=id))
        if not resp.HasField("journal_entry"):
            return None
        return self._map_journal_entry(resp.journal_entry)

    def get_journal_entry_by_key(self, key: str) -> Optional[JournalEntry]:
        resp = self._stub.GetJournalEntryByKey(
            self._pb2.GetJournalEntryByKeyRequest(idempotency_key=key)
        )
        if not resp.HasField("journal_entry"):
            return None
        return self._map_journal_entry(resp.journal_entry)

    def reverse_journal_entry(
        self,
        entry_id: str,
        idempotency_key: str,
        reason: Optional[str] = None,
    ) -> JournalEntry:
        req = self._pb2.ReverseJournalEntryRequest(
            entry_id=entry_id, idempotency_key=idempotency_key,
        )
        if reason:
            req.reason = reason
        resp = self._stub.ReverseJournalEntry(req)
        return self._map_journal_entry(resp.journal_entry)

    # --- Balance Operations ---

    def get_balance(self, book: str) -> BalanceResult:
        resp = self._stub.GetBalance(self._pb2.GetBalanceRequest(book=book))
        return self._map_balance(resp)

    def get_balances(self, books: list[str]) -> list[BalanceResult]:
        resp = self._stub.GetBalances(self._pb2.GetBalancesRequest(books=books))
        return [self._map_balance(b) for b in resp.balances]

    def close(self):
        self._channel.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


__all__ = [
    "Janus",
    "Entity",
    "Book",
    "BookEntry",
    "JournalEntry",
    "BalanceResult",
    "money",
    "from_decimal",
    "to_decimal",
]
