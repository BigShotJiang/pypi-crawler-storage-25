from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import select

from spellbot.database import DatabaseSession
from spellbot.models import Watch

if TYPE_CHECKING:
    from spellbot.data import WatchData


async def fetch(guild_xid: int) -> list[WatchData]:
    """Fetch all watches for the given guild."""
    result = await DatabaseSession.execute(
        select(Watch).where(Watch.guild_xid == guild_xid).order_by(Watch.user_xid),
    )
    return [watch.to_data() for watch in result.scalars().all()]
