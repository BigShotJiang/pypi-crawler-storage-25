from __future__ import annotations

from typing import TYPE_CHECKING

from sqlalchemy import BigInteger, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship
from sqlalchemy.sql.expression import false
from sqlalchemy.sql.sqltypes import Boolean

from . import Base

if TYPE_CHECKING:
    from spellbot.data import GuildAwardData, UserAwardData

    from . import Guild, User  # noqa: F401


class GuildAward(Base):
    """Awards available on a guild."""

    __tablename__ = "guild_awards"

    id = Column(
        Integer,
        autoincrement=True,
        nullable=False,
        primary_key=True,
        doc="The ID used to refer to this award",
    )
    guild_xid = Column(
        BigInteger,
        ForeignKey("guilds.xid", ondelete="CASCADE"),
        index=True,
        nullable=False,
        doc="The guild associated with this award",
    )
    count = Column(
        Integer,
        index=True,
        nullable=False,
        doc="The number of games required to achieve this award",
    )
    repeating = Column(
        Boolean,
        nullable=False,
        default=False,
        server_default=false(),
        doc="If true, this award should be given every 'count' number of games",
    )
    remove = Column(
        Boolean,
        nullable=False,
        default=False,
        server_default=false(),
        doc="If true, this award should be removed from instead of given to the player",
    )
    verified_only = Column(
        Boolean,
        nullable=False,
        default=False,
        server_default=false(),
        doc="If true, this award will only ever apply to verified users",
    )
    unverified_only = Column(
        Boolean,
        nullable=False,
        default=False,
        server_default=false(),
        doc="If true, this award will only ever apply to unverified users",
    )
    role = Column(
        String(100),
        nullable=False,
        doc="The name of the Discord role to give as the award",
    )
    message = Column(
        String(500),
        nullable=False,
        doc="The message to DM users who achieve this award",
    )

    guild = relationship(
        "Guild",
        back_populates="awards",
        doc="The guild where this award is available",
    )

    def to_data(self) -> GuildAwardData:
        from spellbot.data import GuildAwardData  # allow_inline

        return GuildAwardData(
            id=self.id,  # type: ignore
            guild_xid=self.guild_xid,  # type: ignore
            count=self.count,  # type: ignore
            repeating=self.repeating,  # type: ignore
            remove=self.remove,  # type: ignore
            role=self.role,  # type: ignore
            message=self.message,  # type: ignore
            verified_only=self.verified_only,  # type: ignore
            unverified_only=self.unverified_only,  # type: ignore
        )


class UserAward(Base):
    """Awards that a user has achieved on a per guild basis."""

    __tablename__ = "user_awards"

    user_xid = Column(
        BigInteger,
        ForeignKey("users.xid", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
    )
    guild_xid = Column(
        BigInteger,
        ForeignKey("guilds.xid", ondelete="CASCADE"),
        primary_key=True,
        nullable=False,
        index=True,
    )
    guild_award_id = Column(Integer, nullable=True)

    def to_data(self) -> UserAwardData:
        from spellbot.data import UserAwardData  # allow_inline

        return UserAwardData(
            user_xid=self.user_xid,  # type: ignore
            guild_xid=self.guild_xid,  # type: ignore
            guild_award_id=self.guild_award_id,  # type: ignore
        )
