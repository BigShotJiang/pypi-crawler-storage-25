# Empty marker — turns profiles/ into a Python package so its YAML files
# can be shipped as package_data when WinSecAudit v2 is pip-installed.
