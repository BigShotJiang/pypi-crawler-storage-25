-- WinSecAudit v2 — SQLite schema (documentation only; executed via SQLAlchemy)
-- All datetimes are ISO 8601 UTC strings.
-- system_value / expected_value / cve_ids are JSON-serialised TEXT columns.

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ─────────────────────────────────────────────────────────────────────────────
-- machines: one row per audited host (hostname is the natural key)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS machines (
    id          TEXT PRIMARY KEY,   -- socket.gethostname()
    os_version  TEXT,
    last_seen   TEXT                -- ISO 8601 UTC; updated on every scan
);

-- ─────────────────────────────────────────────────────────────────────────────
-- scans: one row per audit run
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scans (
    id               TEXT PRIMARY KEY,  -- scan_{hostname}_{YYYYMMDD}_{HHMMSS}
    machine_id       TEXT    NOT NULL REFERENCES machines(id),
    timestamp        TEXT    NOT NULL,  -- ISO 8601 UTC
    profile          TEXT,              -- "basic" / "hardened" / …
    score            REAL,              -- 0.0 – 100.0
    grade            TEXT,              -- "A" / "B" / "C" / "D" / "F"
    total_checks     INTEGER,
    passed_checks    INTEGER,
    failed_checks    INTEGER,
    error_checks     INTEGER,
    skipped_checks   INTEGER,
    duration_seconds REAL
);

-- ─────────────────────────────────────────────────────────────────────────────
-- results: one row per check per scan
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS results (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id               TEXT    NOT NULL REFERENCES scans(id),
    check_name            TEXT,
    category              TEXT,
    status                TEXT,    -- CheckStatus.name: PASS / FAIL / ERROR / SKIPPED
    severity              TEXT,    -- Severity.name:    CRITICAL / HIGH / MEDIUM / LOW
    weight                INTEGER,
    system_value          TEXT,    -- JSON
    expected_value        TEXT,    -- JSON
    cve_ids               TEXT,    -- JSON array
    mitre_technique       TEXT,
    cis_id                TEXT,
    remediation_cmd       TEXT,
    remediation_supported INTEGER, -- 0 / 1
    error_message         TEXT     -- NULL when no error
);

-- ─────────────────────────────────────────────────────────────────────────────
-- Indexes
-- ─────────────────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_scans_machine_id   ON scans(machine_id);
CREATE INDEX IF NOT EXISTS idx_scans_timestamp    ON scans(timestamp);
CREATE INDEX IF NOT EXISTS idx_results_scan_id    ON results(scan_id);
CREATE INDEX IF NOT EXISTS idx_results_check_name ON results(check_name);
CREATE INDEX IF NOT EXISTS idx_results_status     ON results(status);
