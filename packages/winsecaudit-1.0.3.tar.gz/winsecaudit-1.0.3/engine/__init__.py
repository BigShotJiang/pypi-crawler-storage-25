# engine package — scan execution pipeline for WinSecAudit v2.
