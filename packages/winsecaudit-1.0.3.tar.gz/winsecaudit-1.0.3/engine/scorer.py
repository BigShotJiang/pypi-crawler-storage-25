"""
engine/scorer.py — weighted security score computation.

Scoring rules:
  PASS    → earns full weight
  FAIL    → earns 0
  ERROR   → earns 0  (unknown state = treat as failing for score purposes)
  SKIPPED → excluded from both earned weight AND max weight
             (inapplicable checks must not penalise the machine)

score = (earned_weight / max_weight) * 100
Edge case: all checks SKIPPED → max_weight == 0 → return 100.0
"""
from __future__ import annotations

import logging
from collections import defaultdict

from checks.base import CheckResult, CheckStatus

logger = logging.getLogger(__name__)

_SCORING_STATUSES = {CheckStatus.PASS, CheckStatus.FAIL, CheckStatus.ERROR}


def calculate_score(results: list[CheckResult]) -> dict:
    """
    Compute the weighted security score for a list of results.

    Returns a dict with keys:
        score, total_checks, passed_checks, failed_checks,
        error_checks, skipped_checks, max_possible_weight,
        earned_weight, category_scores,
        critical_failures, high_failures
    """
    total_checks   = len(results)
    passed_checks  = 0
    failed_checks  = 0
    error_checks   = 0
    skipped_checks = 0
    earned_weight  = 0
    max_weight     = 0

    critical_failures: list[str] = []
    high_failures:     list[str] = []

    # {category: {"earned": int, "max": int, "passed": int, "failed": int, "total": int}}
    cat_data: dict[str, dict] = defaultdict(
        lambda: {"earned": 0, "max": 0, "passed": 0, "failed": 0, "total": 0}
    )

    for result in results:
        cat = result.category
        cat_data[cat]["total"] += 1

        if result.status == CheckStatus.SKIPPED:
            skipped_checks += 1
            # SKIPPED contributes nothing to numerator or denominator
            continue

        # Non-skipped: contribute to max weight
        max_weight += result.weight
        cat_data[cat]["max"] += result.weight

        if result.status == CheckStatus.PASS:
            passed_checks += 1
            earned_weight += result.weight
            cat_data[cat]["earned"]  += result.weight
            cat_data[cat]["passed"]  += 1
        elif result.status == CheckStatus.FAIL:
            failed_checks += 1
            cat_data[cat]["failed"]  += 1
            # Track severity-bucketed failures for priority display
            if result.severity.value == "CRITICAL":
                critical_failures.append(result.check_name)
            elif result.severity.value == "HIGH":
                high_failures.append(result.check_name)
        elif result.status == CheckStatus.ERROR:
            error_checks += 1
            # ERROR earns 0 — already excluded from earned_weight above

    # Edge case: everything was SKIPPED
    if max_weight == 0:
        score = 100.0
    else:
        score = round((earned_weight / max_weight) * 100, 1)

    # Build per-category score dict
    category_scores: dict[str, dict] = {}
    for cat, data in cat_data.items():
        cat_max = data["max"]
        cat_score = (
            100.0
            if cat_max == 0
            else round((data["earned"] / cat_max) * 100, 1)
        )
        category_scores[cat] = {
            "score":  cat_score,
            "passed": data["passed"],
            "failed": data["failed"],
            "total":  data["total"],
        }

    return {
        "score":               score,
        "total_checks":        total_checks,
        "passed_checks":       passed_checks,
        "failed_checks":       failed_checks,
        "error_checks":        error_checks,
        "skipped_checks":      skipped_checks,
        "max_possible_weight": max_weight,
        "earned_weight":       earned_weight,
        "category_scores":     category_scores,
        "critical_failures":   critical_failures,
        "high_failures":       high_failures,
    }
