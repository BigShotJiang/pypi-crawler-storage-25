"""
engine/runner.py — check discovery and execution.

Responsibilities:
  - Discover all check classes via CheckRegistry
  - Run each check, catching any unhandled exceptions as ERROR results
  - Apply profile weight_overrides to result objects (via new CheckResult)
  - Record total wall-clock duration
  - Return raw results — no DB writes, no scoring here

Design decisions:
  - weight_overrides are applied AFTER run() because the result already
    carries the class-level weight; we replace it in a new frozen copy so
    the original class attribute is never mutated.
  - Per-check exceptions are wrapped as ERROR CheckResults so the caller
    always receives exactly one result per discovered check.
"""
from __future__ import annotations

import dataclasses
import logging
import time
from collections.abc import Callable
from pathlib import Path

from checks.base import BaseCheck, CheckResult, CheckRegistry, CheckStatus, Severity

logger = logging.getLogger(__name__)


def run_all_checks(
    checks_dir: Path,
    profile: dict,
    target: str | None = None,
    progress_callback: Callable[[str, int, int], None] | None = None,
) -> tuple[list[CheckResult], float]:
    """
    Discover and run all checks found under *checks_dir*.

    Args:
        checks_dir:          Path to the checks/ package directory.
        profile:             Parsed profile dict (from comparator.load_profile).
                             weight_overrides key is applied to results here.
        target:              Reserved for future WinRM remote scanning.
                             Logs a warning and falls through to local scan.
        progress_callback:   Optional callable(check_name, current, total) invoked
                             after each check completes. Used by the CLI progress bar.

    Returns:
        (results, duration_seconds)
        results — one CheckResult per discovered check, never raises.
    """
    if target is not None:
        logger.warning(
            "Remote scanning not yet implemented (target=%r). "
            "Falling through to local scan.",
            target,
        )

    weight_overrides: dict[str, int] = profile.get("weight_overrides") or {}

    check_classes: list[type[BaseCheck]] = CheckRegistry.discover(checks_dir)
    logger.info("Discovered %d checks", len(check_classes))

    results: list[CheckResult] = []
    start = time.monotonic()

    for check_cls in check_classes:
        instance = check_cls()
        check_name: str = check_cls.name

        try:
            result: CheckResult = instance.run()
        except Exception as exc:
            # Defense-in-depth: checks should never raise, but if they do
            # we capture the exception rather than aborting the whole scan.
            logger.error("Unhandled exception in check '%s': %s", check_name, exc)
            result = CheckResult(
                check_name=check_name,
                category=check_cls.category,
                status=CheckStatus.ERROR,
                system_value=None,
                expected_value=None,
                severity=check_cls.severity,
                weight=check_cls.weight,
                cve_ids=list(check_cls.cve_ids),
                mitre_technique=check_cls.mitre_technique,
                cis_id=check_cls.cis_id,
                remediation_cmd=check_cls.remediation_cmd,
                remediation_supported=check_cls.remediation_supported,
                error_message=f"Unhandled exception: {exc}",
            )

        # Apply weight_overrides — create a new frozen copy if the weight
        # differs; never mutate the class or the returned result object.
        if check_name in weight_overrides:
            override_weight = int(weight_overrides[check_name])
            if override_weight != result.weight:
                result = dataclasses.replace(result, weight=override_weight)

        results.append(result)
        if progress_callback is not None:
            progress_callback(check_name, len(results), len(check_classes))

    duration = time.monotonic() - start
    logger.info(
        "Scan complete: %d checks in %.2fs", len(results), duration
    )
    return results, duration
