"""
engine/comparator.py — profile loading and result adjustment.

Responsibilities:
  - Load YAML profiles from the profiles/ directory
  - Apply relaxed_checks: FAIL → PASS for checks the profile exempts
  - Expose available profiles for CLI enumeration

Design decisions:
  - apply_profile() uses dataclasses.replace() to produce new frozen
    CheckResult copies — mutation of frozen dataclasses is impossible and
    attempting it raises FrozenInstanceError, so we always produce new objects.
  - Missing profile keys (relaxed_checks, weight_overrides) are filled with
    safe defaults rather than raising, so a minimal YAML profile still works.
  - The relaxed-check note is stored in error_message because that is the only
    free-text field on CheckResult; it does not indicate an error to the scorer —
    the scorer sees status=PASS and ignores error_message entirely.
"""
from __future__ import annotations

import dataclasses
import logging
from pathlib import Path

import yaml

from checks.base import CheckResult, CheckStatus

logger = logging.getLogger(__name__)

_REQUIRED_KEYS = {
    "name":             "",
    "relaxed_checks":   [],
    "weight_overrides": {},
}


def load_profile(profile_name: str, profiles_dir: Path) -> dict:
    """
    Load and validate a profile YAML file.

    Args:
        profile_name:  Name without .yaml extension (e.g. "basic").
        profiles_dir:  Directory containing *.yaml profile files.

    Returns:
        Parsed profile dict with guaranteed keys: name, relaxed_checks,
        weight_overrides.

    Raises:
        FileNotFoundError: if the profile file does not exist.
    """
    profile_path = profiles_dir / f"{profile_name}.yaml"
    if not profile_path.exists():
        available = get_available_profiles(profiles_dir)
        raise FileNotFoundError(
            f"Profile '{profile_name}' not found at {profile_path}. "
            f"Available profiles: {available}"
        )

    with profile_path.open("r", encoding="utf-8") as fh:
        data: dict = yaml.safe_load(fh) or {}

    # Fill missing keys with safe defaults so callers never KeyError
    for key, default in _REQUIRED_KEYS.items():
        if key not in data or data[key] is None:
            logger.debug("Profile '%s' missing key '%s'; using default %r", profile_name, key, default)
            # Use a fresh copy for mutable defaults
            data[key] = type(default)() if isinstance(default, (list, dict)) else default

    return data


def apply_profile(
    results: list[CheckResult],
    profile: dict,
) -> list[CheckResult]:
    """
    Apply profile relaxation rules to a list of results.

    Checks listed in profile["relaxed_checks"] that FAILED are converted
    to PASS with a note in error_message.  All other results are returned
    unchanged.  A new list of new CheckResult objects is always returned —
    the input list and its objects are never modified.

    Args:
        results:  Raw results from runner.run_all_checks().
        profile:  Parsed profile dict from load_profile().

    Returns:
        Adjusted list of CheckResult objects.
    """
    relaxed: set[str] = set(profile.get("relaxed_checks") or [])
    profile_name: str = profile.get("name", "unknown")
    adjusted: list[CheckResult] = []

    for result in results:
        if result.check_name in relaxed and result.status == CheckStatus.FAIL:
            result = dataclasses.replace(
                result,
                status=CheckStatus.PASS,
                error_message=f"Relaxed by profile: {profile_name}",
            )
        adjusted.append(result)

    return adjusted


def get_available_profiles(profiles_dir: Path) -> list[str]:
    """
    Return the names (without .yaml extension) of all profiles found
    in *profiles_dir*.
    """
    if not profiles_dir.exists():
        return []
    return sorted(p.stem for p in profiles_dir.glob("*.yaml"))
