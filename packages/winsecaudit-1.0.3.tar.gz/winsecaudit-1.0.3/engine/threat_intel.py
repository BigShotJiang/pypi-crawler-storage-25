"""
engine/threat_intel.py — Threat intelligence enrichment pipeline.

Three independent data sources, each failing gracefully:
  1. NIST NVD  — per-CVE CVSS score, severity, description, publish date
  2. FIRST EPSS — per-CVE exploitation probability score (0.0–1.0)
  3. CISA KEV   — bulk catalog of known-exploited CVEs (one download, 24h TTL)

Design decisions:
  - NVD rate limit: 5 req/s without an API key. A module-level _last_nvd_call
    monotonic timestamp self-throttles to 0.2s between requests. No sleep on
    the first call; cost is zero for cached lookups.
  - CISA KEV is a ~5MB JSON file refreshed once per 24h. A module-level
    _kev_index dict (cveID → entry) is built once per process; subsequent
    lookups are O(1) dict access. The file mtime gates refresh decisions.
  - Cache entries in cve_map.json distinguish TI enrichment dicts from the
    legacy "CVE-ID": "check-name" string entries by isinstance(v, dict).
    Legacy entries are preserved unchanged.
  - Atomic write: os.replace(tmp_path, final_path) — atomic on POSIX,
    best-effort on Windows (MoveFileEx REPLACE_EXISTING).
  - Every API call is individually wrapped so one source failing does not
    prevent the other two from succeeding.
  - enrich_results() has a top-level try/except so a programming error in this
    module never crashes a scan.

NVD_API_KEY env var is read if present and sent as the apiKey query parameter,
raising the rate limit to 50 req/s. Not required — enrichment works without it.
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Paths — delegated to runtime_paths so they resolve correctly whether the
# package is run from source or installed via pip.
# ---------------------------------------------------------------------------

from winsecaudit_paths import CVE_CACHE_PATH as _CVE_CACHE_PATH
from winsecaudit_paths import KEV_CACHE_PATH as _KEV_CACHE_PATH

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_NVD_URL   = "https://services.nvd.nist.gov/rest/json/cves/2.0"
_EPSS_URL  = "https://api.first.org/data/v1/epss"
_KEV_URL   = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"

_CACHE_TTL_DAYS  = 7    # enrich_cve() cache TTL
_KEV_TTL_SECONDS = 86400  # 24 h in seconds
_REQUEST_TIMEOUT = 10   # seconds per HTTP call
_NVD_MIN_INTERVAL = 0.2  # seconds between NVD calls

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

_last_nvd_call: float = 0.0               # monotonic time of last NVD call
_kev_index: dict[str, dict] | None = None # cveID → KEV entry, built once per process


# ---------------------------------------------------------------------------
# Cache I/O
# ---------------------------------------------------------------------------

def _load_cache() -> dict:
    """Load cve_map.json, returning {} on any read error."""
    try:
        text = _CVE_CACHE_PATH.read_text(encoding="utf-8")
        return json.loads(text)
    except Exception as exc:
        logger.debug("CVE cache read failed (expected on first run): %s", exc)
        return {}


def _save_cache(cache: dict) -> None:
    """
    Atomically write cache to cve_map.json via a .tmp intermediary.
    os.replace() is atomic on POSIX and best-effort on Windows.
    """
    tmp = _CVE_CACHE_PATH.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(cache, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _CVE_CACHE_PATH)
    except Exception as exc:
        logger.error("CVE cache write failed: %s", exc)
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


def _cache_entry_fresh(entry: dict) -> bool:
    """Return True if the enrichment entry is younger than _CACHE_TTL_DAYS."""
    ts = entry.get("enriched_at", "")
    if not ts:
        return False
    try:
        enriched_at = datetime.fromisoformat(ts)
        return (datetime.utcnow() - enriched_at) < timedelta(days=_CACHE_TTL_DAYS)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Source 1: NIST NVD
# ---------------------------------------------------------------------------

def _fetch_nvd(cve_id: str) -> dict:
    """
    Fetch CVSS score, severity, description, and publish date from NVD API v2.0.
    Self-throttles to at most 1 request per 0.2s to stay under the anonymous
    rate limit of 5 req/s.  Returns {} on any error.
    """
    global _last_nvd_call

    # Rate-gate: sleep only the remaining interval since the last call
    elapsed = time.monotonic() - _last_nvd_call
    if elapsed < _NVD_MIN_INTERVAL:
        time.sleep(_NVD_MIN_INTERVAL - elapsed)
    _last_nvd_call = time.monotonic()

    params: dict[str, str] = {"cveId": cve_id}
    api_key = os.environ.get("NVD_API_KEY")
    if api_key:
        params["apiKey"] = api_key

    try:
        resp = requests.get(_NVD_URL, params=params, timeout=_REQUEST_TIMEOUT)
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        logger.warning("NVD fetch failed for %s: %s", cve_id, exc)
        return {}

    vulns = data.get("vulnerabilities", [])
    if not vulns:
        return {}

    cve_obj = vulns[0].get("cve", {})
    metrics  = cve_obj.get("metrics", {})

    # Prefer CVSS v3.1 → v3.0 → v2 (in that order)
    cvss_score:    float | None = None
    cvss_severity: str   | None = None

    for metric_key, sev_field in [
        ("cvssMetricV31", "baseSeverity"),
        ("cvssMetricV30", "baseSeverity"),
        ("cvssMetricV2",  "baseSeverity"),
    ]:
        metric_list = metrics.get(metric_key, [])
        if metric_list:
            # Prefer the "Primary" source when multiple vendors provide scores
            primary = next(
                (m for m in metric_list if m.get("type") == "Primary"),
                metric_list[0],
            )
            cvss_data  = primary.get("cvssData", {})
            cvss_score = cvss_data.get("baseScore")
            # v3.x baseSeverity lives in cvssData; v2 baseSeverity lives on the metric
            cvss_severity = (
                cvss_data.get("baseSeverity")
                or primary.get("baseSeverity")
            )
            break

    # First English description
    description: str | None = None
    for desc in cve_obj.get("descriptions", []):
        if desc.get("lang") == "en":
            description = desc.get("value")
            break

    published = cve_obj.get("published", None)
    if published:
        # Normalize to YYYY-MM-DD
        published = published[:10]

    return {
        "cvss_score":     cvss_score,
        "cvss_severity":  cvss_severity,
        "description":    description,
        "published_date": published,
    }


# ---------------------------------------------------------------------------
# Source 2: FIRST EPSS
# ---------------------------------------------------------------------------

def _fetch_epss(cve_id: str) -> dict:
    """
    Fetch exploitation probability from the FIRST EPSS API.
    Returns epss_score=0.0 and epss_percentile=0.0 if CVE is not in EPSS DB.
    Returns {} on network/parse error (caller will use 0.0 defaults).
    """
    try:
        resp = requests.get(
            _EPSS_URL,
            params={"cve": cve_id},
            timeout=_REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        logger.warning("EPSS fetch failed for %s: %s", cve_id, exc)
        return {}

    items = data.get("data", [])
    if not items:
        # CVE exists but has no EPSS score yet — return zero defaults
        return {"epss_score": 0.0, "epss_percentile": 0.0}

    entry = items[0]
    return {
        "epss_score":       float(entry.get("epss",       0.0)),
        "epss_percentile":  float(entry.get("percentile", 0.0)),
    }


# ---------------------------------------------------------------------------
# Source 3: CISA KEV (bulk, cached)
# ---------------------------------------------------------------------------

def _load_kev_from_file() -> dict[str, dict] | None:
    """Read KEV catalog from disk cache and build cveID index. Returns None on error."""
    try:
        text = _KEV_CACHE_PATH.read_text(encoding="utf-8")
        raw  = json.loads(text)
        vulns = raw.get("vulnerabilities", [])
        if not vulns:
            return None
        return {v["cveID"]: v for v in vulns if "cveID" in v}
    except Exception as exc:
        logger.debug("KEV cache file read failed: %s", exc)
        return None


def _refresh_kev_cache() -> dict[str, dict]:
    """
    Download the full CISA KEV catalog, write to disk, and return the in-memory
    index.  Returns {} on any download or parse failure so callers still work.
    """
    global _kev_index
    logger.info("Refreshing CISA KEV cache from %s", _KEV_URL)
    try:
        resp = requests.get(_KEV_URL, timeout=30)   # larger timeout for ~5MB file
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        logger.warning("CISA KEV download failed: %s", exc)
        return {}

    # Write raw catalog to disk for the 24h TTL cache
    tmp = _KEV_CACHE_PATH.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, _KEV_CACHE_PATH)
    except Exception as exc:
        logger.warning("Could not write KEV cache: %s", exc)
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass

    vulns = data.get("vulnerabilities", [])
    _kev_index = {v["cveID"]: v for v in vulns if "cveID" in v}
    return _kev_index


def _get_kev_index() -> dict[str, dict]:
    """
    Return the KEV cveID → entry index, using memory cache → disk cache →
    live download (in priority order).  24h TTL is checked via file mtime.
    """
    global _kev_index

    # In-memory cache (valid for the life of this process run)
    if _kev_index is not None:
        return _kev_index

    # Disk cache: check file mtime for 24h TTL
    if _KEV_CACHE_PATH.exists():
        age = time.time() - _KEV_CACHE_PATH.stat().st_mtime
        if age < _KEV_TTL_SECONDS:
            index = _load_kev_from_file()
            if index is not None:
                _kev_index = index
                return _kev_index

    # Cache missing or stale — download fresh
    return _refresh_kev_cache()


def _lookup_kev(cve_id: str) -> dict:
    """Return KEV fields for cve_id, or defaults if not in catalog."""
    try:
        index = _get_kev_index()
        entry = index.get(cve_id)
        if entry is None:
            return {
                "in_cisa_kev":       False,
                "kev_date_added":    None,
                "kev_ransomware_use": None,
            }
        return {
            "in_cisa_kev":        True,
            "kev_date_added":     entry.get("dateAdded"),
            "kev_ransomware_use": entry.get("knownRansomwareCampaignUse") or None,
        }
    except Exception as exc:
        logger.warning("KEV lookup failed for %s: %s", cve_id, exc)
        return {
            "in_cisa_kev":        False,
            "kev_date_added":     None,
            "kev_ransomware_use": None,
        }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def enrich_cve(cve_id: str, use_cache: bool = True) -> dict:
    """
    Return fully-enriched TI data for one CVE, checking the on-disk cache first.

    Cache hit (< 7 days old):  returns immediately, no network call.
    Cache miss / stale:        calls NVD + EPSS + KEV, updates cache.
    Any API failure:           logs warning, returns partial result with safe defaults.
    """
    # Check cache first
    if use_cache:
        cache = _load_cache()
        entry = cache.get(cve_id)
        if isinstance(entry, dict) and entry.get("cve_id") == cve_id:
            if _cache_entry_fresh(entry):
                logger.debug("Cache hit for %s", cve_id)
                return entry

    # Fetch from all three sources independently
    nvd_data  = _fetch_nvd(cve_id)
    epss_data = _fetch_epss(cve_id)
    kev_data  = _lookup_kev(cve_id)

    result: dict = {
        "cve_id":            cve_id,
        "cvss_score":        nvd_data.get("cvss_score"),
        "cvss_severity":     nvd_data.get("cvss_severity"),
        "description":       nvd_data.get("description"),
        "published_date":    nvd_data.get("published_date"),
        "epss_score":        epss_data.get("epss_score",      0.0),
        "epss_percentile":   epss_data.get("epss_percentile", 0.0),
        "in_cisa_kev":       kev_data.get("in_cisa_kev",      False),
        "kev_date_added":    kev_data.get("kev_date_added"),
        "kev_ransomware_use": kev_data.get("kev_ransomware_use"),
        "enriched_at":       datetime.utcnow().isoformat(timespec="seconds"),
    }

    # Save to cache (best-effort — failure here must not crash the caller)
    try:
        cache = _load_cache()
        cache[cve_id] = result
        _save_cache(cache)
    except Exception as exc:
        logger.warning("Could not persist cache entry for %s: %s", cve_id, exc)

    return result


def enrich_results(
    results: list,
    use_cache: bool = True,
) -> dict[str, dict]:
    """
    Enrich all unique CVE IDs found across *results* (any CheckResult or dict).
    Returns a mapping of cve_id → enriched dict.

    Resilience contract:
      - Per-CVE failures are caught individually; other CVEs still succeed.
      - The entire function is wrapped so a bug here never propagates to the scan.
      - Existing cached data is preserved if a fresh fetch fails.
    """
    try:
        # Collect unique CVE IDs from all results
        cve_ids: set[str] = set()
        for r in results:
            raw = getattr(r, "cve_ids", None)
            if raw is None and isinstance(r, dict):
                raw = r.get("cve_ids") or []
            if isinstance(raw, (list, tuple)):
                cve_ids.update(c for c in raw if c)
            elif isinstance(raw, str):
                # JSON string from DB round-trip
                try:
                    parsed = json.loads(raw)
                    if isinstance(parsed, list):
                        cve_ids.update(c for c in parsed if c)
                except Exception:
                    pass

        if not cve_ids:
            return {}

        # Load cache once for all lookups
        cache = _load_cache()

        enriched: dict[str, dict] = {}
        to_fetch: list[str] = []

        for cve_id in sorted(cve_ids):
            entry = cache.get(cve_id)
            if use_cache and isinstance(entry, dict) and entry.get("cve_id") == cve_id:
                if _cache_entry_fresh(entry):
                    enriched[cve_id] = entry
                    continue
            to_fetch.append(cve_id)

        logger.info(
            "TI enrichment: %d CVEs total, %d cached, %d to fetch",
            len(cve_ids), len(enriched), len(to_fetch),
        )

        for cve_id in to_fetch:
            try:
                data = enrich_cve(cve_id, use_cache=False)
                enriched[cve_id] = data
                # Update cache with the newly fetched entry
                cache[cve_id] = data
            except Exception as exc:
                logger.warning("enrich_cve failed for %s: %s — skipping", cve_id, exc)
                # Keep existing stale cache entry if available rather than losing it
                if isinstance(cache.get(cve_id), dict):
                    enriched[cve_id] = cache[cve_id]

        # Persist all updates in one write
        if to_fetch:
            try:
                _save_cache(cache)
            except Exception as exc:
                logger.warning("Batch cache save failed: %s", exc)

        return enriched

    except Exception as exc:
        logger.error("enrich_results failed entirely: %s — returning empty TI", exc)
        return {}


def get_enriched_summary(
    results: list,
    ti_data: dict[str, dict],
) -> dict:
    """
    Aggregate TI findings across all results into a high-level summary dict.

    Keys:
      total_cves       — unique CVE IDs across all results
      cisa_kev_count   — how many are in CISA KEV
      high_epss_count  — how many have EPSS score > 0.50
      critical_cves    — CVE IDs with CVSS base score >= 9.0
      most_dangerous   — CVE with highest EPSS that is also in KEV;
                         falls back to highest EPSS overall if none in KEV
    """
    all_cve_ids: set[str] = set()
    for r in results:
        raw = getattr(r, "cve_ids", None)
        if raw is None and isinstance(r, dict):
            raw = r.get("cve_ids") or []
        if isinstance(raw, (list, tuple)):
            all_cve_ids.update(c for c in raw if c)

    kev_hits:      list[str] = []
    high_epss:     list[str] = []
    critical_cves: list[str] = []
    most_dangerous: dict | None = None
    best_kev_epss:  float = -1.0
    best_epss:      float = -1.0

    for cve_id in all_cve_ids:
        entry = ti_data.get(cve_id, {})
        if not entry:
            continue

        epss  = entry.get("epss_score", 0.0) or 0.0
        cvss  = entry.get("cvss_score")
        in_kev = entry.get("in_cisa_kev", False)

        if in_kev:
            kev_hits.append(cve_id)
            if epss > best_kev_epss:
                best_kev_epss  = epss
                most_dangerous = entry

        if epss > 0.50:
            high_epss.append(cve_id)

        if cvss is not None and cvss >= 9.0:
            critical_cves.append(cve_id)

        # Fallback most_dangerous if no KEV hits yet
        if most_dangerous is None and epss > best_epss:
            best_epss      = epss
            most_dangerous = entry

    return {
        "total_cves":      len(all_cve_ids),
        "cisa_kev_count":  len(kev_hits),
        "high_epss_count": len(high_epss),
        "critical_cves":   sorted(critical_cves),
        "most_dangerous":  most_dangerous,
    }


def format_cve_line(cve_id: str, entry: dict) -> str:
    """
    Format a single CVE's enrichment data as a scannable one-line string.

    Examples:
      "CVE-2017-0144  CVSS 9.3  EPSS 0.974  \u26a0 CISA KEV [Ransomware: Known]"
      "CVE-2021-31956  CVSS 7.8  EPSS 0.623"
      "CVE-2017-0144  (enrichment unavailable)"
    """
    if not entry or "enriched_at" not in entry:
        return f"{cve_id}  (enrichment unavailable)"

    parts: list[str] = [cve_id]

    cvss = entry.get("cvss_score")
    if cvss is not None:
        parts.append(f"CVSS {cvss}")

    epss = entry.get("epss_score")
    if epss is not None and epss > 0:
        parts.append(f"EPSS {epss:.3f}")

    if entry.get("in_cisa_kev"):
        kev_tag = "\u26a0 CISA KEV"
        ransomware = entry.get("kev_ransomware_use")
        if ransomware:
            kev_tag += f" [Ransomware: {ransomware}]"
        parts.append(kev_tag)

    return "  ".join(parts)
