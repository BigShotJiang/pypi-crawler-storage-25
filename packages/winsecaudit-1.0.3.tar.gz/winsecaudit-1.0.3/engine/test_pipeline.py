"""
engine/test_pipeline.py — full end-to-end pipeline integration test.

Runs the complete audit pipeline and prints a Rich-free summary table to
stdout so it works in any terminal without extra dependencies.

Exit code 0 on success, 1 on any assertion failure.
"""
from __future__ import annotations

import socket
import sys
from datetime import datetime
from pathlib import Path

# Ensure project root is on sys.path when run as a script
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from db.database import init_db, save_scan, get_scan
from engine.comparator import load_profile, apply_profile
from engine.risk import assign_grade, build_scan_summary, get_priority_failures, results_to_db_rows
from engine.runner import run_all_checks
from engine.scorer import calculate_score

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
CHECKS_DIR   = _PROJECT_ROOT / "checks"
PROFILES_DIR = _PROJECT_ROOT / "profiles"


def _separator(char: str = "-", width: int = 60) -> str:
    return char * width


def _row(label: str, value: str, width: int = 60) -> str:
    label_w = 30
    return f"  {label:<{label_w}} {value}"


def main() -> int:
    print(_separator("="))
    print("  WinSecAudit v2 -- Pipeline Integration Test")
    print(_separator("="))

    # 1. Initialise database
    print("\n[1/11] Initialising database …")
    init_db()
    print("       OK")

    # 2. Load profile
    print("[2/11] Loading profile 'basic' …")
    profile = load_profile("basic", PROFILES_DIR)
    print(f"       OK  (relaxed checks: {len(profile['relaxed_checks'])})")

    # 3. Run all checks
    print("[3/11] Running checks …")
    raw_results, duration = run_all_checks(CHECKS_DIR, profile)
    print(f"       OK  ({len(raw_results)} checks in {duration:.2f}s)")

    # 4. Apply profile relaxations
    print("[4/11] Applying profile …")
    adjusted = apply_profile(raw_results, profile)
    relaxed_count = sum(
        1 for r in adjusted
        if r.error_message and r.error_message.startswith("Relaxed by profile")
    )
    print(f"       OK  ({relaxed_count} result(s) relaxed)")

    # 5. Calculate score
    print("[5/11] Calculating score …")
    score_data = calculate_score(adjusted)
    print(f"       OK  score={score_data['score']}")

    # 6. Assign grade
    print("[6/11] Assigning grade …")
    grade = assign_grade(score_data["score"])
    print(f"       OK  grade={grade}")

    # 7. Priority failures
    print("[7/11] Identifying priority failures …")
    priority = get_priority_failures(adjusted, max_items=5)
    print(f"       OK  ({len(priority)} priority failure(s))")

    # 8. Build scan summary
    print("[8/11] Building scan summary …")
    timestamp_tag = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    hostname = socket.gethostname()
    scan_id  = f"scan_{hostname}_{timestamp_tag}"
    scan_summary = build_scan_summary(adjusted, score_data, "basic", scan_id, duration)
    print(f"       OK  scan_id={scan_id}")

    # 9. Serialise results
    print("[9/11] Serialising result rows …")
    db_rows = results_to_db_rows(adjusted, scan_id)
    print(f"       OK  ({len(db_rows)} rows)")

    # 10. Save to DB
    print("[10/11] Saving to database …")
    saved_id = save_scan(scan_summary, db_rows)
    print(f"        OK  saved_id={saved_id}")

    # 11. Round-trip verification
    print("[11/11] Verifying DB round-trip …")
    retrieved = get_scan(saved_id)
    assert retrieved is not None, "get_scan() returned None — save failed!"
    assert retrieved["score"] == score_data["score"], (
        f"Score mismatch: saved {score_data['score']}, retrieved {retrieved['score']}"
    )
    assert len(retrieved["results"]) == len(adjusted), (
        f"Result count mismatch: saved {len(adjusted)}, retrieved {len(retrieved['results'])}"
    )
    print(f"        OK  score matches, {len(retrieved['results'])} results retrieved")

    # ---------------------------------------------------------------------------
    # Summary table
    # ---------------------------------------------------------------------------
    print()
    print(_separator("="))
    print("  SCAN SUMMARY")
    print(_separator("-"))
    print(_row("Scan ID",            scan_id))
    print(_row("Machine",            hostname))
    print(_row("Profile",            "basic"))
    print(_row("Score",              f"{score_data['score']}/100"))
    print(_row("Grade",              grade))
    print(_separator("-"))
    print(_row("Total checks",       str(score_data["total_checks"])))
    print(_row("Passed",             str(score_data["passed_checks"])))
    print(_row("Failed",             str(score_data["failed_checks"])))
    print(_row("Error",              str(score_data["error_checks"])))
    print(_row("Skipped",            str(score_data["skipped_checks"])))
    print(_row("Duration",           f"{duration:.2f}s"))
    print(_separator("-"))
    print("  TOP PRIORITY FAILURES")
    if priority:
        for i, r in enumerate(priority[:3], 1):
            print(_row(f"  {i}. {r.check_name[:26]}", r.severity.value))
    else:
        print("  (none)")
    print(_separator("-"))

    # Per-category breakdown
    print("  CATEGORY SCORES")
    for cat, cs in sorted(score_data["category_scores"].items()):
        bar = f"{cs['score']:5.1f}%  ({cs['passed']}P {cs['failed']}F / {cs['total']})"
        print(_row(f"  {cat[:28]}", bar))

    print(_separator("="))
    print("  DB round-trip: CONFIRMED")
    print(_separator("="))
    return 0


if __name__ == "__main__":
    sys.exit(main())
