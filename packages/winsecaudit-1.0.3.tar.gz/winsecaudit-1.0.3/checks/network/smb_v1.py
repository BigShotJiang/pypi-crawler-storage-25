from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Returns the value of EnableSMB1Protocol (True/False).
_PS_SCRIPT = "(Get-SmbServerConfiguration).EnableSMB1Protocol"


class SmbV1Check(BaseCheck):
    name = "SMBv1 Disabled"
    category = "Network Security"
    weight = 10
    severity = Severity.CRITICAL
    cve_ids: list[str] = ["CVE-2017-0144", "CVE-2017-0145"]
    mitre_technique = "T1021.002"
    cis_id = "18.3.3"
    remediation_cmd = "Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force"
    remediation_supported = True
    plain_name = 'Old File Sharing Protocol (SMBv1)'
    risk_summary = 'SIMPLE: An ancient file-sharing feature is enabled that has a dangerous security hole | TECH: SMBv1 protocol lacks modern security controls and is vulnerable to unauthenticated RCE'
    attack_scenario = 'SIMPLE: Hackers can take full control of your computer without needing a password — this is how WannaCry ransomware spread in 2017 | TECH: EternalBlue exploit (CVE-2017-0144) enables unauthenticated remote code execution via SMBv1 buffer overflow'
    why_fix = 'SIMPLE: Microsoft stopped supporting this in 2014. There is zero reason to keep it on | TECH: SMBv1 has no mitigations for EternalBlue; disable immediately on all endpoints'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force'

    def run(self) -> CheckResult:
        smb1_enabled: bool | None = None
        error_msg: str | None = None

        try:
            raw = run_powershell(_PS_SCRIPT)
            if raw:
                smb1_enabled = raw.strip().lower() == "true"
            else:
                error_msg = "PowerShell returned no output — check may be running on non-Windows."
        except (RuntimeError, TimeoutError) as exc:
            logger.error("SmbV1Check failed: %s", exc)
            error_msg = str(exc)

        if error_msg:
            status = CheckStatus.ERROR
        elif smb1_enabled is False:
            # EnableSMB1Protocol = False → protocol is disabled → PASS
            status = CheckStatus.PASS
        else:
            status = CheckStatus.FAIL

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value={"smb1_enabled": smb1_enabled},
            expected_value={"smb1_enabled": False},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
