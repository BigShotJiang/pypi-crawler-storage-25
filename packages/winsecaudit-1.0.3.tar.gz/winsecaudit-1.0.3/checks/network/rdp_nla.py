from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Three values read in one PS call — all emitted as pipe-delimited tokens.
# fDenyTSConnections: 1 = RDP disabled (safe regardless of NLA state).
# UserAuthentication: 1 = NLA enforced (BlueKeep/CVE-2019-0708 mitigated).
# PortNumber: read for informational context only; does not affect PASS/FAIL.
_PS_SCRIPT = r"""
try {
    $tsPath  = 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server'
    $wstPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp'

    $deny = $null
    $nla  = $null
    $port = 3389   # default if not explicitly set

    if (Test-Path $tsPath) {
        $v = Get-ItemProperty -Path $tsPath -Name 'fDenyTSConnections' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $deny = $v.fDenyTSConnections }
    }
    if (Test-Path $wstPath) {
        $v = Get-ItemProperty -Path $wstPath -Name 'UserAuthentication' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $nla = $v.UserAuthentication }
        $vp = Get-ItemProperty -Path $wstPath -Name 'PortNumber' -ErrorAction SilentlyContinue
        if ($null -ne $vp) { $port = $vp.PortNumber }
    }

    $denyOut = if ($null -eq $deny) { 'NULL' } else { "$deny" }
    $nlaOut  = if ($null -eq $nla)  { 'NULL' } else { "$nla" }

    "DENY:$denyOut|NLA:$nlaOut|PORT:$port"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class RDPNLACheck(BaseCheck):
    name = "RDP Network Level Authentication Enforced"
    category = "Network Security"
    weight = 9
    severity = Severity.CRITICAL
    cve_ids: list[str] = ["CVE-2019-0708"]
    mitre_technique = "T1021.001"
    cis_id = "18.9.59.2.2"
    remediation_cmd = (
        r'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"'
        r" /v UserAuthentication /t REG_DWORD /d 1 /f"
    )
    remediation_supported = True
    plain_name = 'Remote Desktop Security (NLA)'
    risk_summary = 'SIMPLE: Remote Desktop is enabled but does not require you to verify identity before showing the login screen | TECH: RDP is active without Network Level Authentication — pre-auth attack surface exposed'
    attack_scenario = 'SIMPLE: Attackers can attempt unlimited password guesses on your login screen, or exploit the BlueKeep vulnerability to take control without any password | TECH: No NLA means unauthenticated RDP negotiation — CVE-2019-0708 (BlueKeep) is exploitable'
    why_fix = 'SIMPLE: NLA adds an extra verification step before anyone even sees your login screen | TECH: NLA moves authentication before session establishment, eliminating pre-auth RCE surface'
    fix_steps = 'SIMPLE: Go to Settings -> Remote Desktop -> Require NLA | TECH: reg add HKLM\\SYSTEM\\CurrentControlSet\\Control\\Terminal Server\\WinStations\\RDP-Tcp /v UserAuthentication /t REG_DWORD /d 1 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("RDPNLACheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                deny_raw = parts.get("DENY", "NULL")
                nla_raw  = parts.get("NLA",  "NULL")
                port_raw = parts.get("PORT", "3389")

                deny = None if deny_raw == "NULL" else int(deny_raw)
                nla  = None if nla_raw  == "NULL" else int(nla_raw)
                port = int(port_raw) if port_raw.isdigit() else 3389

                # fDenyTSConnections absent → assume RDP is enabled (conservative).
                rdp_enabled  = (deny == 0) if deny is not None else True
                nla_enforced = (nla == 1)  if nla  is not None else False

                system_val = {
                    "rdp_enabled": rdp_enabled,
                    "nla_enforced": nla_enforced,
                    "rdp_port": port,
                }

                if not rdp_enabled:
                    # RDP disabled entirely — not exposed regardless of NLA setting
                    status = CheckStatus.PASS
                elif nla_enforced:
                    # RDP on but NLA gates pre-auth; BlueKeep class attacks blocked
                    status = CheckStatus.PASS
                else:
                    status = CheckStatus.FAIL
            except Exception as exc:
                logger.error("RDPNLACheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"nla_enforced": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
