from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Two independent registry locations — both must be configured securely for PASS.
# WpadOverride: 1 = WPAD URL auto-detection disabled (HKLM — machine-wide)
# AutoDetect:   0 = "Automatically detect settings" disabled (HKCU — current user)
# Decision: if either key is absent it is treated as the insecure default
# (0 for WpadOverride = WPAD active; 1 for AutoDetect = auto-detect on).
_PS_SCRIPT = r"""
try {
    $wpadPath    = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad'
    $inetPath    = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings'

    $wpadOverride = $null
    $autoDetect   = $null

    if (Test-Path $wpadPath) {
        $v = Get-ItemProperty -Path $wpadPath -Name 'WpadOverride' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $wpadOverride = $v.WpadOverride }
    }
    if (Test-Path $inetPath) {
        $v = Get-ItemProperty -Path $inetPath -Name 'AutoDetect' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $autoDetect = $v.AutoDetect }
    }

    $woOut = if ($null -eq $wpadOverride) { 'NULL' } else { "$wpadOverride" }
    $adOut = if ($null -eq $autoDetect)   { 'NULL' } else { "$autoDetect" }

    "WO:$woOut|AD:$adOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class WPADCheck(BaseCheck):
    name = "WPAD Disabled"
    category = "Network Security"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2016-3213"]
    mitre_technique = "T1557"
    cis_id = "N/A"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Wpad"'
        r" /v WpadOverride /t REG_DWORD /d 1 /f"
    )
    remediation_supported = True
    plain_name = 'Proxy Auto-Detection (WPAD)'
    risk_summary = 'SIMPLE: Your computer automatically searches for network proxies in a way attackers can exploit | TECH: WPAD auto-detection is active — susceptible to WPAD name collision and proxy hijacking'
    attack_scenario = 'SIMPLE: On any network, an attacker can silently redirect all your web traffic through their machine | TECH: Rogue WPAD server can intercept all HTTP(S) traffic, enabling MitM for credential theft and content injection'
    why_fix = 'SIMPLE: Automatic proxy detection is almost never needed and is a known attack vector | TECH: WPAD CVE-2016-3213 enables SYSTEM-level exploitation; disable unless explicitly required'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: Set WpadOverride=1 in HKLM and AutoDetect=0 in HKCU Internet Settings'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("WPADCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                wo_raw = parts.get("WO", "NULL")
                ad_raw = parts.get("AD", "NULL")

                wpad_override = None if wo_raw == "NULL" else int(wo_raw)
                auto_detect   = None if ad_raw == "NULL" else int(ad_raw)

                system_val = {
                    "wpad_override": wpad_override,
                    "auto_detect":   auto_detect,
                }

                # Both conditions must be met; missing key = insecure default = FAIL
                wo_ok = wpad_override == 1
                ad_ok = auto_detect == 0
                status = CheckStatus.PASS if (wo_ok and ad_ok) else CheckStatus.FAIL
            except Exception as exc:
                logger.error("WPADCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"wpad_override": 1, "auto_detect": 0},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
