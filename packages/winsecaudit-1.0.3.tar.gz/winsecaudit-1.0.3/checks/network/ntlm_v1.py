from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# All three values must meet their thresholds simultaneously.
# 0x20080000 = 537395200: requires NTLMv2 session security + 128-bit encryption.
# Missing keys emit "NULL" so Python always gets a fixed-width pipe response.
_PS_SCRIPT = r"""
try {
    $lsaPath    = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'
    $msv1Path   = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\MSV1_0'

    $lmc = $null
    $ncs = $null
    $nss = $null

    if (Test-Path $lsaPath) {
        $v = Get-ItemProperty -Path $lsaPath -Name 'LmCompatibilityLevel' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $lmc = $v.LmCompatibilityLevel }
    }
    if (Test-Path $msv1Path) {
        $v = Get-ItemProperty -Path $msv1Path -Name 'NtlmMinClientSec' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $ncs = $v.NtlmMinClientSec }
        $v = Get-ItemProperty -Path $msv1Path -Name 'NtlmMinServerSec' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $nss = $v.NtlmMinServerSec }
    }

    $lmcOut = if ($null -eq $lmc) { 'NULL' } else { "$lmc" }
    $ncsOut = if ($null -eq $ncs) { 'NULL' } else { "$ncs" }
    $nssOut = if ($null -eq $nss) { 'NULL' } else { "$nss" }

    "LMC:$lmcOut|NCS:$ncsOut|NSS:$nssOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""

_NTLMv2_MIN_CLIENT_SERVER = 537395200   # 0x20080000
_LM_COMPAT_MIN = 5


class NTLMv1Check(BaseCheck):
    name = "NTLMv1 Disabled"
    category = "Network Security"
    weight = 9
    severity = Severity.CRITICAL
    cve_ids: list[str] = ["CVE-2019-1040"]
    mitre_technique = "T1557.001"
    cis_id = "2.3.11.7"
    remediation_cmd = (
        r'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa"'
        r" /v LmCompatibilityLevel /t REG_DWORD /d 5 /f"
    )
    remediation_supported = True
    plain_name = 'Old Authentication Protocol (NTLMv1)'
    risk_summary = 'SIMPLE: Your computer supports a 30-year-old login method that is easily cracked | TECH: LmCompatibilityLevel not set to 5 — NTLMv1 downgrade attacks possible'
    attack_scenario = 'SIMPLE: Attackers can trick your computer into using the old method and crack your password in hours | TECH: NTLMv1 hashes are crackable in minutes with GPU; Responder + ntlmrelayx enables credential relay without cracking'
    why_fix = 'SIMPLE: NTLMv1 was designed before modern security — there is no reason to keep it | TECH: Force NTLMv2 minimum with 128-bit session security to prevent downgrade and relay attacks'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: Set LmCompatibilityLevel=5, NtlmMinClientSec=537395200, NtlmMinServerSec=537395200'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("NTLMv1Check failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                def _int_or_none(val: str) -> int | None:
                    return None if val == "NULL" else int(val)

                lmc = _int_or_none(parts.get("LMC", "NULL"))
                ncs = _int_or_none(parts.get("NCS", "NULL"))
                nss = _int_or_none(parts.get("NSS", "NULL"))

                system_val = {
                    "lm_compatibility_level": lmc,
                    "ntlm_min_client_sec": ncs,
                    "ntlm_min_server_sec": nss,
                }

                # Any NULL means the key is absent — Windows defaults are insecure,
                # so a missing value is treated as a FAIL, not as "unknown".
                lmc_ok = lmc is not None and lmc >= _LM_COMPAT_MIN
                ncs_ok = ncs is not None and ncs >= _NTLMv2_MIN_CLIENT_SERVER
                nss_ok = nss is not None and nss >= _NTLMv2_MIN_CLIENT_SERVER

                status = CheckStatus.PASS if (lmc_ok and ncs_ok and nss_ok) else CheckStatus.FAIL
            except Exception as exc:
                logger.error("NTLMv1Check parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={
                "lm_compatibility_level": _LM_COMPAT_MIN,
                "ntlm_min_client_sec": _NTLMv2_MIN_CLIENT_SERVER,
                "ntlm_min_server_sec": _NTLMv2_MIN_CLIENT_SERVER,
            },
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
