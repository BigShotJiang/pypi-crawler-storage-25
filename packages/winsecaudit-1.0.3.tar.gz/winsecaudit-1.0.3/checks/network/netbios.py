from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# NetbiosOptions values: 0 = use DHCP setting (enabled on most networks),
# 1 = enabled, 2 = disabled.
# Decision: 0 is treated as FAIL (CIS strict interpretation) — "use DHCP"
# resolves to NetBIOS-on in the majority of enterprise environments.
# Each interface is emitted as a separate line: "<guid>:<option>"
# A sentinel "NONE" is emitted when no interfaces are found.
_PS_SCRIPT = r"""
try {
    $path = 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces'
    if (-not (Test-Path $path)) {
        'NONE'
    } else {
        $ifaces = Get-ChildItem -Path $path -ErrorAction Stop
        if ($ifaces.Count -eq 0) {
            'NONE'
        } else {
            foreach ($iface in $ifaces) {
                $v = Get-ItemProperty -Path $iface.PSPath -Name 'NetbiosOptions' -ErrorAction SilentlyContinue
                $opt = if ($null -eq $v) { 'NULL' } else { "$($v.NetbiosOptions)" }
                "$($iface.PSChildName):$opt"
            }
        }
    }
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class NetBIOSCheck(BaseCheck):
    name = "NetBIOS over TCP/IP Disabled"
    category = "Network Security"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2008-4114"]
    mitre_technique = "T1557"
    cis_id = "18.5.4.1"
    remediation_cmd = (
        r"Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT"
        r"\Parameters\Interfaces\*' -Name NetbiosOptions -Value 2"
    )
    remediation_supported = False
    plain_name = 'NetBIOS Name Broadcasting'
    risk_summary = 'SIMPLE: Your computer is broadcasting its identity on the network in a way attackers can exploit | TECH: NetBIOS over TCP/IP is active on one or more interfaces — enables NBNS poisoning'
    attack_scenario = 'SIMPLE: Attackers on the same network can intercept your login credentials by responding to your computer broadcasts | TECH: NBNS poisoning via Responder captures NTLMv2 authentication for relay or offline cracking'
    why_fix = 'SIMPLE: Modern Windows does not need NetBIOS — disabling it removes an attack vector with no downside | TECH: NetBIOS is a legacy protocol superseded by DNS; no enterprise dependency should exist'
    fix_steps = 'SIMPLE: Disable in Network Adapter Settings -> TCP/IP -> Advanced -> WINS -> Disable NetBIOS | TECH: Set NetbiosOptions=2 on all NetBT interfaces via registry'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("NetBIOSCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.strip() == "NONE":
            error_msg = "No NetBT interfaces found"
            status = CheckStatus.ERROR
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                interfaces = []
                for line in raw.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    if ":" not in line:
                        continue
                    guid, _, opt_str = line.partition(":")
                    opt = None if opt_str == "NULL" else int(opt_str)
                    interfaces.append({"interface": guid, "netbios_option": opt})

                if not interfaces:
                    error_msg = "No NetBT interfaces found"
                    status = CheckStatus.ERROR
                else:
                    # Option 2 = explicitly disabled; anything else (0, 1, None) = on
                    all_disabled = all(
                        iface["netbios_option"] == 2 for iface in interfaces
                    )
                    system_val = {
                        "interfaces": interfaces,
                        "all_disabled": all_disabled,
                    }
                    status = CheckStatus.PASS if all_disabled else CheckStatus.FAIL
            except Exception as exc:
                logger.error("NetBIOSCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"all_disabled": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
