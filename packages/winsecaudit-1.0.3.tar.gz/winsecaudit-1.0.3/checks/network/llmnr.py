from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# EnableMulticast = 0 means LLMNR is disabled (multicast DNS queries suppressed).
# Key absent entirely means LLMNR is on by default — treat as FAIL.
# Decision: "NOT_SET" sentinel covers both "key missing" and "value missing" cases;
# both are equally dangerous because Windows defaults LLMNR to enabled.
_PS_SCRIPT = r"""
try {
    $path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'
    if (Test-Path $path) {
        $v = Get-ItemProperty -Path $path -Name 'EnableMulticast' -ErrorAction SilentlyContinue
        if ($null -ne $v) {
            "VAL:$($v.EnableMulticast)|SET:true"
        } else {
            'VAL:NOT_SET|SET:true'
        }
    } else {
        'VAL:NOT_SET|SET:false'
    }
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class LLMNRCheck(BaseCheck):
    name = "LLMNR Disabled"
    category = "Network Security"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2017-8563"]
    mitre_technique = "T1557.001"
    cis_id = "18.5.4.2"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient"'
        r" /v EnableMulticast /t REG_DWORD /d 0 /f"
    )
    remediation_supported = True
    plain_name = 'Network Name Poisoning Protection (LLMNR)'
    risk_summary = 'SIMPLE: A network feature is on that lets attackers intercept your login credentials on WiFi | TECH: LLMNR multicast name resolution is enabled — susceptible to Responder poisoning attacks'
    attack_scenario = 'SIMPLE: On any network (coffee shop, office), an attacker can steal your Windows password hash in seconds using a free tool | TECH: Responder responds to LLMNR queries with rogue authentication, capturing NTLMv2 hashes for offline cracking or relay'
    why_fix = 'SIMPLE: This feature is almost never needed and is one of the most common first steps in network attacks | TECH: LLMNR/NBT-NS poisoning is step 1 in virtually every internal pentest'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\NT\\DNSClient /v EnableMulticast /t REG_DWORD /d 0 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("LLMNRCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                raw_val = parts.get("VAL", "NOT_SET")
                policy_set = parts.get("SET", "false").lower() == "true"

                if raw_val == "NOT_SET":
                    enable_multicast = None
                    # Not configured = LLMNR active by default = vulnerable
                    status = CheckStatus.FAIL
                else:
                    enable_multicast = int(raw_val)
                    status = CheckStatus.PASS if enable_multicast == 0 else CheckStatus.FAIL

                system_val = {
                    "enable_multicast": enable_multicast,
                    "policy_set": policy_set,
                }
            except Exception as exc:
                logger.error("LLMNRCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"enable_multicast": 0},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
