# kernel & memory checks sub-package
