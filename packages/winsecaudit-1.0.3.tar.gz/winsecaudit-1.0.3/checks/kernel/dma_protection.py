from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# KernelDmaProtection: 1 = enabled on Windows 10 1803+; 2 on newer builds.
# PASS for any non-zero value — the spec says 1 or 2 both indicate protection.
_PS_SCRIPT = r"""
try {
    $dg = Get-CimInstance -ClassName Win32_DeviceGuard `
          -Namespace 'root\Microsoft\Windows\DeviceGuard' -ErrorAction Stop
    "DMA:$($dg.KernelDmaProtection)"
} catch [Microsoft.Management.Infrastructure.CimException] {
    'ERR:WMI_UNAVAILABLE'
} catch {
    $msg = $_.Exception.Message
    if ($msg -match 'Invalid namespace|not found|does not exist|WMI') {
        'ERR:WMI_UNAVAILABLE'
    } else {
        "ERR:$msg"
    }
}
"""


class DMAProtectionCheck(BaseCheck):
    name = "Kernel DMA Protection Enabled"
    category = "Kernel & Memory"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1052"
    cis_id = "N/A"
    remediation_cmd = "Enable Kernel DMA Protection in UEFI firmware settings"
    remediation_supported = False
    plain_name = 'Physical Port Attack Protection (DMA)'
    risk_summary = 'SIMPLE: Devices plugged into Thunderbolt or PCI ports could directly access your computer memory | TECH: Kernel DMA Protection disabled — PCIe devices have unrestricted DMA access to physical memory'
    attack_scenario = 'SIMPLE: Attackers with physical access can plug in a device and read all your RAM including passwords in under 30 seconds | TECH: DMA attacks via Thunderbolt/PCIe can dump entire physical memory, bypassing all software security'
    why_fix = 'SIMPLE: DMA protection stops physical attacks that no software can prevent | TECH: Kernel DMA Protection + IOMMU remapping restricts PCIe device memory access to authorized regions'
    fix_steps = 'SIMPLE: Enable in BIOS/UEFI settings — look for DMA Protection or Kernel DMA Protection | TECH: Requires IOMMU support in UEFI; enable in firmware Security settings'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("DMAProtectionCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:WMI_UNAVAILABLE":
            error_msg = "VBS WMI class not available on this Windows version"
            status = CheckStatus.SKIPPED
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                dma_raw = parts.get("DMA", "0").strip()
                # Empty string means WMI returned null for this property —
                # treat as 0 (not enabled) rather than crashing on int("").
                dma = int(dma_raw) if dma_raw else 0

                enabled = dma >= 1
                system_val = {
                    "kernel_dma_protection": dma,
                    "enabled": enabled,
                }
                status = CheckStatus.PASS if enabled else CheckStatus.FAIL
            except Exception as exc:
                logger.error("DMAProtectionCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"enabled": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
