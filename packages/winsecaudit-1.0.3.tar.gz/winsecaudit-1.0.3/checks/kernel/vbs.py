from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

_VBS_DESCRIPTIONS = {
    0: "Not enabled",
    1: "Enabled but not running",
    2: "Running",
}

# Win32_DeviceGuard WMI class is only available on Windows 10/2016+.
# Catch the namespace/class-not-found exception and emit ERR:WMI_UNAVAILABLE
# so Python maps it to SKIPPED, not ERROR — the feature cannot exist on the OS.
_PS_SCRIPT = r"""
try {
    $dg = Get-CimInstance -ClassName Win32_DeviceGuard `
          -Namespace 'root\Microsoft\Windows\DeviceGuard' -ErrorAction Stop
    $status   = $dg.VirtualizationBasedSecurityStatus
    $services = ($dg.SecurityServicesRunning -join ',')
    if (-not $services) { $services = 'NONE' }
    "VBS:$status|SVC:$services"
} catch [Microsoft.Management.Infrastructure.CimException] {
    'ERR:WMI_UNAVAILABLE'
} catch {
    $msg = $_.Exception.Message
    if ($msg -match 'Invalid namespace|not found|does not exist|WMI') {
        'ERR:WMI_UNAVAILABLE'
    } else {
        "ERR:$msg"
    }
}
"""


class VBSCheck(BaseCheck):
    name = "Virtualization-Based Security Enabled"
    category = "Kernel & Memory"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1055.009"
    cis_id = "N/A"
    remediation_cmd = (
        "Enable VBS in Windows Security → Device Security → Core isolation"
    )
    remediation_supported = False
    plain_name = 'Virtualization-Based Security (VBS)'
    risk_summary = 'SIMPLE: An advanced hardware protection layer that isolates critical security functions is not running | TECH: VBS/HVCI not enabled — kernel and credential isolation unavailable'
    attack_scenario = 'SIMPLE: Sophisticated attackers with admin access can manipulate core Windows security | TECH: Without VBS, kernel exploits and credential theft tools (Mimikatz) operate without hardware isolation barriers'
    why_fix = 'SIMPLE: VBS creates a secure vault inside your computer that even the OS cannot touch | TECH: VBS enables Credential Guard and HVCI — two of the strongest mitigations against post-compromise attacks'
    fix_steps = 'SIMPLE: Enable in Windows Security -> Device Security -> Core isolation -> Memory integrity | TECH: Enable via Group Policy: Computer Config -> Admin Templates -> System -> Device Guard -> Enable VBS'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("VBSCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:WMI_UNAVAILABLE":
            error_msg = "VBS WMI class not available on this Windows version"
            status = CheckStatus.SKIPPED
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                vbs_status = int(parts.get("VBS", "0"))
                svc_raw    = parts.get("SVC", "NONE")
                services   = (
                    []
                    if svc_raw == "NONE"
                    else [int(x) for x in svc_raw.split(",") if x.strip().isdigit()]
                )

                system_val = {
                    "vbs_status":              vbs_status,
                    "vbs_status_description":  _VBS_DESCRIPTIONS.get(vbs_status, f"Unknown ({vbs_status})"),
                    "security_services_running": services,
                }
                status = CheckStatus.PASS if vbs_status == 2 else CheckStatus.FAIL
            except Exception as exc:
                logger.error("VBSCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"vbs_status": 2},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
