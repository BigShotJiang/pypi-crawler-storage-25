from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# MoveImages absent = Windows ASLR is on (OS default).
# MoveImages = 0 = explicitly disabled = FAIL (attacker can predict module addresses).
# MoveImages = 1 = enabled. Any other non-zero value also treated as enabled.
_PS_SCRIPT = r"""
try {
    $path = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
    $mi = $null

    if (Test-Path $path) {
        $v = Get-ItemProperty -Path $path -Name 'MoveImages' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $mi = $v.MoveImages }
    }

    $miOut = if ($null -eq $mi) { 'NULL' } else { "$mi" }
    "MI:$miOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class ASLRCheck(BaseCheck):
    name = "ASLR Enabled"
    category = "Kernel & Memory"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1055"
    cis_id = "N/A"
    remediation_cmd = (
        r'reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"'
        r" /v MoveImages /t REG_DWORD /d 1 /f"
    )
    remediation_supported = True
    plain_name = 'Memory Randomization (ASLR)'
    risk_summary = 'SIMPLE: A protection that makes memory attacks harder to aim is disabled | TECH: MoveImages=0 — ASLR explicitly disabled, memory layout is deterministic'
    attack_scenario = 'SIMPLE: Attackers exploiting software can reliably aim their attacks because memory is always in the same place | TECH: Disabled ASLR makes ROP chain construction trivial — exploit reliability approaches 100%'
    why_fix = 'SIMPLE: ASLR makes exploits unpredictable and unreliable — most attacks fail without it | TECH: ASLR + DEP together prevent the vast majority of memory corruption exploitation'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management /v MoveImages /t REG_DWORD /d 1 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("ASLRCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                mi_raw = parts.get("MI", "NULL")

                move_images = None if mi_raw == "NULL" else int(mi_raw)

                # NULL = absent = OS default = ASLR on; 0 = explicitly disabled
                aslr_enabled = move_images != 0

                system_val = {
                    "move_images":   move_images,
                    "aslr_enabled":  aslr_enabled,
                }
                status = CheckStatus.PASS if aslr_enabled else CheckStatus.FAIL
            except Exception as exc:
                logger.error("ASLRCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"aslr_enabled": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
