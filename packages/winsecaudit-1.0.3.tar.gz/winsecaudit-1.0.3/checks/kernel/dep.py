from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

_DEP_DESCRIPTIONS = {
    0: "Disabled for all processes",
    1: "Enabled for Windows components only (AlwaysOn for system)",
    2: "OptIn — enabled only for programs that explicitly opt in",
    3: "OptOut — enabled for all processes except those that opt out",
}

_PS_SCRIPT = r"""
try {
    $os = Get-WmiObject -Class Win32_OperatingSystem -ErrorAction Stop
    "POLICY:$($os.DataExecutionPrevention_SupportPolicy)"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class DEPCheck(BaseCheck):
    name = "DEP (Data Execution Prevention) Enabled"
    category = "Kernel & Memory"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1055"
    cis_id = "N/A"
    remediation_cmd = "bcdedit /set {current} nx OptOut"
    remediation_supported = False
    plain_name = 'Memory Attack Protection (DEP)'
    risk_summary = 'SIMPLE: A protection that stops certain types of memory-based attacks is not fully enabled | TECH: Data Execution Prevention policy below OptOut — memory pages lack NX enforcement'
    attack_scenario = 'SIMPLE: Attackers exploiting software bugs can run their own code from memory areas that should be read-only | TECH: Without DEP/NX, stack and heap overflows can directly execute shellcode in data segments'
    why_fix = 'SIMPLE: DEP stops a whole class of attacks that exploit software vulnerabilities | TECH: DEP/NX is a foundational exploit mitigation — required for ASLR to be effective'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: bcdedit /set {current} nx OptOut'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("DEPCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                policy = int(parts.get("POLICY", "-1"))
                system_val = {
                    "dep_policy": policy,
                    "dep_policy_description": _DEP_DESCRIPTIONS.get(
                        policy, f"Unknown value ({policy})"
                    ),
                }
                # PASS for OptIn (2) or OptOut (3) — both provide meaningful protection
                status = CheckStatus.PASS if policy >= 2 else CheckStatus.FAIL
            except Exception as exc:
                logger.error("DEPCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"dep_policy": 3},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
