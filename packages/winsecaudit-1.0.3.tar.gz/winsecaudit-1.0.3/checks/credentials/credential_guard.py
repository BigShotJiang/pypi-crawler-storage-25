from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# SecurityServicesRunning is an array — value 1 = Credential Guard running.
# Also read two registry keys that gate CG at boot; both must be set for CG to
# start on next boot even if not yet running.
_PS_SCRIPT = r"""
try {
    $dg = Get-CimInstance -ClassName Win32_DeviceGuard `
          -Namespace 'root\Microsoft\Windows\DeviceGuard' -ErrorAction Stop

    $services = ($dg.SecurityServicesRunning -join ',')
    if (-not $services) { $services = 'NONE' }

    $vbsPath  = 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard'
    $lsaPath  = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'

    $vbsEnabled = $null
    $lsaFlags   = $null

    if (Test-Path $vbsPath) {
        $v = Get-ItemProperty -Path $vbsPath -Name 'EnableVirtualizationBasedSecurity' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $vbsEnabled = $v.EnableVirtualizationBasedSecurity }
    }
    if (Test-Path $lsaPath) {
        $v = Get-ItemProperty -Path $lsaPath -Name 'LsaCfgFlags' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $lsaFlags = $v.LsaCfgFlags }
    }

    $vbsOut = if ($null -eq $vbsEnabled) { 'NULL' } else { "$vbsEnabled" }
    $lsaOut = if ($null -eq $lsaFlags)   { 'NULL' } else { "$lsaFlags" }

    "SVC:$services|VBS:$vbsOut|LSA:$lsaOut"
} catch [Microsoft.Management.Infrastructure.CimException] {
    'ERR:WMI_UNAVAILABLE'
} catch {
    $msg = $_.Exception.Message
    if ($msg -match 'Invalid namespace|not found|does not exist|WMI') {
        'ERR:WMI_UNAVAILABLE'
    } else {
        "ERR:$msg"
    }
}
"""


class CredentialGuardCheck(BaseCheck):
    name = "Credential Guard Enabled"
    category = "Credential Security"
    weight = 9
    severity = Severity.CRITICAL
    cve_ids: list[str] = []
    mitre_technique = "T1003.001"
    cis_id = "N/A"
    remediation_cmd = (
        "Enable Credential Guard via Group Policy: Computer Configuration"
        " → Administrative Templates → System → Device Guard"
    )
    remediation_supported = False
    plain_name = 'Credential Guard (Anti-Theft Protection)'
    risk_summary = 'SIMPLE: An advanced protection that locks your passwords away from hackers is not enabled | TECH: Credential Guard is not running — LSASS credentials are accessible to user-mode attacks'
    attack_scenario = 'SIMPLE: Attackers can steal saved passwords and network credentials directly from your running computer | TECH: Without Credential Guard, Mimikatz and similar tools can dump NTLM hashes and Kerberos tickets from LSASS'
    why_fix = 'SIMPLE: Credential Guard puts passwords in a protected vault that even admins cannot access | TECH: Credential Guard uses VBS/HVCI to isolate LSA secrets in a separate security domain'
    fix_steps = 'SIMPLE: Enable via Windows Security -> Device Security -> Core isolation | TECH: Requires VBS — enable via Group Policy: Computer Config -> Admin Templates -> System -> Device Guard'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("CredentialGuardCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:WMI_UNAVAILABLE":
            error_msg = "VBS WMI class not available on this Windows version"
            status = CheckStatus.SKIPPED
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                svc_raw = parts.get("SVC", "NONE")
                vbs_raw = parts.get("VBS", "NULL")
                lsa_raw = parts.get("LSA", "NULL")

                services = (
                    []
                    if svc_raw == "NONE"
                    else [int(x) for x in svc_raw.split(",") if x.strip().isdigit()]
                )
                cg_running = 1 in services
                vbs_enabled = None if vbs_raw == "NULL" else int(vbs_raw)
                lsa_flags   = None if lsa_raw == "NULL" else int(lsa_raw)

                system_val = {
                    "security_services_running": services,
                    "credential_guard_running":  cg_running,
                    "vbs_enabled_registry":      vbs_enabled,
                    "lsa_cfg_flags":             lsa_flags,
                }
                status = CheckStatus.PASS if cg_running else CheckStatus.FAIL
            except Exception as exc:
                logger.error("CredentialGuardCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"credential_guard_running": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
