from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Check domain membership first — LAPS is meaningless on standalone machines.
# Four independent detection methods: any one indicating LAPS = PASS.
# Windows 11 22H2+ ships built-in LAPS as a Windows Capability.
_PS_SCRIPT = r"""
try {
    # Domain membership check
    $cs = Get-WmiObject -Class Win32_ComputerSystem -ErrorAction Stop
    if (-not $cs.PartOfDomain) {
        'SKIP:NOT_DOMAIN'
    } else {
        $lapsSvc    = $null -ne (Get-Service -Name 'LAPS*' -ErrorAction SilentlyContinue | Select-Object -First 1)
        $lapsGpo    = Test-Path 'HKLM:\SOFTWARE\Policies\Microsoft Services\AdmPwd'
        $lapsMod    = $null -ne (Get-Module -ListAvailable -Name 'AdmPwd.PS' -ErrorAction SilentlyContinue | Select-Object -First 1)
        $winLaps    = $false
        try {
            $cap = Get-WindowsCapability -Online -Name 'LAPS*' -ErrorAction Stop | Select-Object -First 1
            if ($null -ne $cap -and $cap.State -eq 'Installed') { $winLaps = $true }
        } catch { }

        $svcOut  = $lapsSvc.ToString().ToLower()
        $gpoOut  = $lapsGpo.ToString().ToLower()
        $modOut  = $lapsMod.ToString().ToLower()
        $winOut  = $winLaps.ToString().ToLower()

        "SVC:$svcOut|GPO:$gpoOut|MOD:$modOut|WIN:$winOut"
    }
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class LAPSCheck(BaseCheck):
    name = "LAPS (Local Admin Password Solution) Enabled"
    category = "Credential Security"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1078.003"
    cis_id = "N/A"
    remediation_cmd = (
        "Install Microsoft LAPS from"
        " https://www.microsoft.com/en-us/download/details.aspx?id=46899"
    )
    remediation_supported = False
    plain_name = 'Local Admin Password Management (LAPS)'
    risk_summary = 'SIMPLE: All computers on the network probably share the same local admin password | TECH: LAPS not deployed — local Administrator accounts likely share static credentials across domain'
    attack_scenario = 'SIMPLE: If an attacker learns the local admin password on one computer, they can log into every computer on the network | TECH: Shared local admin credentials enable pass-the-hash lateral movement across entire domain'
    why_fix = 'SIMPLE: LAPS gives every computer a unique, rotating password so one compromise cannot spread everywhere | TECH: LAPS randomizes local admin credentials per machine, eliminating credential reuse attack paths'
    fix_steps = 'SIMPLE: Ask your IT admin to deploy Microsoft LAPS across the organization | TECH: Install LAPS via GPO; deploy AdmPwd.PS module and configure via Group Policy Management'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT, timeout=60)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("LAPSCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "SKIP:NOT_DOMAIN":
            status = CheckStatus.SKIPPED
            error_msg = "LAPS not applicable on non-domain machines"
            system_val = {
                "laps_service_found":    False,
                "laps_gpo_policy_found": False,
                "laps_module_found":     False,
                "windows_laps_found":    False,
            }
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                def _bool(key: str) -> bool:
                    return parts.get(key, "false").lower() == "true"

                laps_svc = _bool("SVC")
                laps_gpo = _bool("GPO")
                laps_mod = _bool("MOD")
                laps_win = _bool("WIN")

                system_val = {
                    "laps_service_found":    laps_svc,
                    "laps_gpo_policy_found": laps_gpo,
                    "laps_module_found":     laps_mod,
                    "windows_laps_found":    laps_win,
                }

                laps_present = laps_svc or laps_gpo or laps_mod or laps_win
                status = CheckStatus.PASS if laps_present else CheckStatus.FAIL
            except Exception as exc:
                logger.error("LAPSCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"laps_service_found": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
