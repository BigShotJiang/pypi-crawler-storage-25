from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# UseLogonCredential = 1 stores credentials in plaintext in LSASS memory.
# Mimikatz sekurlsa::wdigest can extract them with a single command.
# Key ABSENT on Windows 8.1/2012R2+ means WDigest is off by default — PASS.
# Key ABSENT on older OS (pre-8.1) means WDigest is on — but we cannot detect
# OS version here without a separate call; per conservative decision, we treat
# absent key as PASS and rely on the OS check to flag legacy Windows.
_PS_SCRIPT = r"""
try {
    $path = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest'
    $ulc      = $null
    $keyExists = (Test-Path $path)

    if ($keyExists) {
        $v = Get-ItemProperty -Path $path -Name 'UseLogonCredential' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $ulc = $v.UseLogonCredential }
    }

    $ulcOut      = if ($null -eq $ulc) { 'NULL' } else { "$ulc" }
    $existsOut   = $keyExists.ToString().ToLower()

    "ULC:$ulcOut|EXISTS:$existsOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class WDigestCheck(BaseCheck):
    name = "WDigest Authentication Disabled"
    category = "Credential Security"
    weight = 10
    severity = Severity.CRITICAL
    cve_ids: list[str] = ["CVE-2021-36934"]
    mitre_technique = "T1003.001"
    cis_id = "N/A"
    remediation_cmd = (
        r'reg add "HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest"'
        r" /v UseLogonCredential /t REG_DWORD /d 0 /f"
    )
    remediation_supported = True
    plain_name = 'Password Stored in Memory (WDigest)'
    risk_summary = 'SIMPLE: Windows is storing your password in plain text in computer memory | TECH: WDigest UseLogonCredential=1 causes LSASS to cache cleartext credentials in memory'
    attack_scenario = 'SIMPLE: An attacker who gets into your computer can read your actual password directly from RAM | TECH: Mimikatz sekurlsa::wdigest dumps cleartext credentials from LSASS memory without any decryption needed'
    why_fix = 'SIMPLE: Your password should never be stored in plain text anywhere | TECH: WDigest cleartext caching is the most trivially exploited credential dumping technique post-compromise'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SYSTEM\\CurrentControlSet\\Control\\SecurityProviders\\WDigest /v UseLogonCredential /t REG_DWORD /d 0 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("WDigestCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                ulc_raw    = parts.get("ULC",    "NULL")
                exists_raw = parts.get("EXISTS", "false")

                ulc       = None if ulc_raw == "NULL" else int(ulc_raw)
                key_present = exists_raw.lower() == "true"
                plaintext_risk = ulc == 1

                system_val = {
                    "use_logon_credential":     ulc,
                    "key_present":              key_present,
                    "plaintext_credentials_risk": plaintext_risk,
                }

                # 1 = plaintext in LSASS = FAIL; 0 or absent = PASS
                status = CheckStatus.FAIL if plaintext_risk else CheckStatus.PASS
            except Exception as exc:
                logger.error("WDigestCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"use_logon_credential": 0},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
