from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# CachedLogonsCount is stored as a REG_SZ (string) — must be coerced to int.
# Key absent = Windows default of 10 cached credentials = FAIL.
# CIS recommends 0 for high-security systems; <=4 is acceptable for usability.
_PS_SCRIPT = r"""
try {
    $path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
    $clc      = $null
    $keyFound = $false

    if (Test-Path $path) {
        $v = Get-ItemProperty -Path $path -Name 'CachedLogonsCount' -ErrorAction SilentlyContinue
        if ($null -ne $v) {
            $clc      = $v.CachedLogonsCount
            $keyFound = $true
        }
    }

    $clcOut      = if ($null -eq $clc) { 'NULL' } else { "$clc" }
    $foundOut    = $keyFound.ToString().ToLower()

    "CLC:$clcOut|FOUND:$foundOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""

_MAX_ACCEPTABLE = 4
_DEFAULT_WHEN_ABSENT = 10


class CachedLogonsCheck(BaseCheck):
    name = "Cached Logon Credentials Limited"
    category = "Credential Security"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1003.005"
    cis_id = "2.3.7.1"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"'
        r" /v CachedLogonsCount /t REG_SZ /d 1 /f"
    )
    remediation_supported = True
    plain_name = 'Cached Login Credentials'
    risk_summary = 'SIMPLE: Windows is storing up to 10 old login credentials on the computer hard drive | TECH: CachedLogonsCount=10 — excessive cached domain credentials stored in SECURITY hive'
    attack_scenario = 'SIMPLE: If an attacker gets into your computer, they can find and crack stored login credentials for your network | TECH: Cached credentials in SECURITY registry hive are crackable offline via MS-CACHEv2 hash extraction'
    why_fix = 'SIMPLE: Fewer cached credentials means less for attackers to steal if they get in | TECH: Reduce to 1 or 0 — eliminates offline credential extraction risk from cached domain hashes'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon /v CachedLogonsCount /t REG_SZ /d 1 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("CachedLogonsCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                clc_raw   = parts.get("CLC",   "NULL")
                found_raw = parts.get("FOUND", "false")

                key_present = found_raw.lower() == "true"

                if clc_raw == "NULL":
                    # Absent = Windows default = 10
                    cached_count = _DEFAULT_WHEN_ABSENT
                else:
                    cached_count = int(clc_raw)

                system_val = {
                    "cached_logons_count": cached_count,
                    "key_present":         key_present,
                }
                status = CheckStatus.PASS if cached_count <= _MAX_ACCEPTABLE else CheckStatus.FAIL
            except Exception as exc:
                logger.error("CachedLogonsCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"cached_logons_count": 1},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
