from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Get-ExecutionPolicy -List emits one line per scope: "Scope  Policy"
# We capture all five scopes for reference but only MachinePolicy determines
# PASS/FAIL — it is the only scope that cannot be overridden by a local user.
# "Undefined" at MachinePolicy means no GPO has set a policy, which defaults
# to Unrestricted on many builds — treated as FAIL.
_PS_SCRIPT = r"""
try {
    $policies = Get-ExecutionPolicy -List -ErrorAction Stop
    foreach ($p in $policies) {
        "$($p.Scope):$($p.ExecutionPolicy)"
    }
} catch {
    "ERR:$($_.Exception.Message)"
}
"""

_PASS_POLICIES = frozenset({"Restricted", "AllSigned", "RemoteSigned"})
_SCOPE_KEYS = ("MachinePolicy", "UserPolicy", "Process", "CurrentUser", "LocalMachine")


class PSExecutionPolicyCheck(BaseCheck):
    name = "PowerShell Execution Policy Restricted"
    category = "Access Control"
    weight = 6
    severity = Severity.MEDIUM
    cve_ids: list[str] = []
    mitre_technique = "T1059.001"
    cis_id = "18.9.95.1"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell"'
        r" /v ExecutionPolicy /t REG_SZ /d RemoteSigned /f"
    )
    remediation_supported = True
    plain_name = 'PowerShell Script Restriction'
    risk_summary = 'SIMPLE: Windows is not blocking unknown or untrusted scripts from running | TECH: No MachinePolicy ExecutionPolicy set — scripts run without signature verification'
    attack_scenario = 'SIMPLE: Attackers can run malicious scripts they download from the internet without any warning | TECH: Unrestricted MachinePolicy allows unsigned remote scripts — bypasses Constrained Language Mode'
    why_fix = 'SIMPLE: Restricting scripts stops a huge category of malware that relies on PowerShell | TECH: RemoteSigned policy is a basic defense-in-depth control against script-based initial access'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\PowerShell /v ExecutionPolicy /t REG_SZ /d RemoteSigned /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("PSExecutionPolicyCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                scope_map: dict[str, str] = {}
                for line in raw.splitlines():
                    line = line.strip()
                    if not line or ":" not in line:
                        continue
                    scope, _, policy = line.partition(":")
                    scope_map[scope.strip()] = policy.strip()

                machine_policy = scope_map.get("MachinePolicy", "Undefined")

                system_val = {
                    "machine_policy":  machine_policy,
                    "user_policy":     scope_map.get("UserPolicy",   "Undefined"),
                    "process":         scope_map.get("Process",      "Undefined"),
                    "current_user":    scope_map.get("CurrentUser",  "Undefined"),
                    "local_machine":   scope_map.get("LocalMachine", "Undefined"),
                }

                # "Undefined" = no GPO configured = insecure default = FAIL
                status = (
                    CheckStatus.PASS
                    if machine_policy in _PASS_POLICIES
                    else CheckStatus.FAIL
                )
            except Exception as exc:
                logger.error("PSExecutionPolicyCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"machine_policy": "RemoteSigned"},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
