from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Two separate registry locations — either one being correctly set = PASS.
# NoAutorun (GP path): 1 = all autorun disabled via Group Policy.
# NoDriveTypeAutoRun (legacy path): 255 = disabled for all drive types.
# Decision: OR semantics — if either policy disables autorun the machine is safe.
_PS_SCRIPT = r"""
try {
    $gpPath  = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer'
    $legPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer'

    $noAutorun         = $null
    $noDriveTypeAutorun = $null

    if (Test-Path $gpPath) {
        $v = Get-ItemProperty -Path $gpPath -Name 'NoAutorun' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $noAutorun = $v.NoAutorun }
    }
    if (Test-Path $legPath) {
        $v = Get-ItemProperty -Path $legPath -Name 'NoDriveTypeAutoRun' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $noDriveTypeAutorun = $v.NoDriveTypeAutoRun }
    }

    $naOut   = if ($null -eq $noAutorun)          { 'NULL' } else { "$noAutorun" }
    $ndtaOut = if ($null -eq $noDriveTypeAutorun)  { 'NULL' } else { "$noDriveTypeAutorun" }

    "NA:$naOut|NDTA:$ndtaOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class AutoRunCheck(BaseCheck):
    name = "AutoRun Disabled"
    category = "Access Control"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2010-0568"]
    mitre_technique = "T1091"
    cis_id = "18.9.8.1"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"'
        r" /v NoDriveTypeAutoRun /t REG_DWORD /d 255 /f"
    )
    remediation_supported = True
    plain_name = 'USB AutoRun Protection'
    risk_summary = 'SIMPLE: Plugging in a USB drive can automatically run programs without asking you | TECH: AutoRun/AutoPlay is not disabled via policy — removable media can auto-execute payloads'
    attack_scenario = 'SIMPLE: A hacker leaves a USB drive in a parking lot — you plug it in and malware installs itself silently | TECH: AutoRun enables BadUSB and USB drop attacks — malicious HID or storage devices execute without user confirmation'
    why_fix = 'SIMPLE: You should always choose what runs on your computer — nothing should run automatically | TECH: AutoRun is a trivial initial access vector; disabling it eliminates an entire attack category'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoDriveTypeAutoRun /t REG_DWORD /d 255 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("AutoRunCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                na_raw   = parts.get("NA",   "NULL")
                ndta_raw = parts.get("NDTA", "NULL")

                no_autorun          = None if na_raw   == "NULL" else int(na_raw)
                no_drive_type_autorun = None if ndta_raw == "NULL" else int(ndta_raw)

                gp_disabled     = no_autorun == 1
                legacy_disabled = no_drive_type_autorun == 255
                autorun_disabled = gp_disabled or legacy_disabled

                system_val = {
                    "no_autorun_policy":     no_autorun,
                    "no_drive_type_autorun": no_drive_type_autorun,
                    "autorun_disabled":      autorun_disabled,
                }
                status = CheckStatus.PASS if autorun_disabled else CheckStatus.FAIL
            except Exception as exc:
                logger.error("AutoRunCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"autorun_disabled": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
