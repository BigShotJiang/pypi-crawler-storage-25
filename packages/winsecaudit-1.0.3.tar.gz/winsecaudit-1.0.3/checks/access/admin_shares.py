from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# AutoShareWks = 0 in registry = Windows will not recreate admin shares on next
# boot (they may still exist in the current session until reboot).
# Get-SmbShare finds currently active $ shares — IPC$ is excluded because it
# is required for Windows RPC and cannot be safely removed.
# Decision: PASS if AutoShareWks == 0 (policy disabled) OR if no $ shares
# exist beyond IPC$ (manually removed). AutoShareWks absent = shares enabled.
_PS_SCRIPT = r"""
try {
    $regPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'
    $autoShareWks = $null

    if (Test-Path $regPath) {
        $v = Get-ItemProperty -Path $regPath -Name 'AutoShareWks' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $autoShareWks = $v.AutoShareWks }
    }

    $shares = @(Get-SmbShare -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match '^\w+\$$' -and $_.Name -ne 'IPC$' } |
                Select-Object -ExpandProperty Name)

    $asOut     = if ($null -eq $autoShareWks) { 'NULL' } else { "$autoShareWks" }
    $shareList = if ($shares.Count -eq 0) { 'NONE' } else { $shares -join ',' }

    "AS:$asOut|SH:$shareList"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class AdminSharesCheck(BaseCheck):
    name = "Administrative Shares Disabled"
    category = "Access Control"
    weight = 6
    severity = Severity.MEDIUM
    cve_ids: list[str] = []
    mitre_technique = "T1021.002"
    cis_id = "2.3.10.1"
    remediation_cmd = (
        r'reg add "HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"'
        r" /v AutoShareWks /t REG_DWORD /d 0 /f"
    )
    remediation_supported = True
    plain_name = 'Hidden Admin Network Shares'
    risk_summary = 'SIMPLE: Windows is sharing your drives over the network with admin access by default | TECH: Administrative shares (C$, ADMIN$) are active — accessible to any admin credential on network'
    attack_scenario = 'SIMPLE: Anyone with your admin password can browse all your files over the network silently | TECH: Admin shares enable lateral movement via pass-the-hash without additional tooling'
    why_fix = 'SIMPLE: Unless you specifically need remote admin access, these shares should be off | TECH: Disabling admin shares removes the primary lateral movement pathway in Windows environments'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters /v AutoShareWks /t REG_DWORD /d 0 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("AdminSharesCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                as_raw = parts.get("AS", "NULL")
                sh_raw = parts.get("SH", "NONE")

                auto_share_wks = None if as_raw == "NULL" else int(as_raw)
                hidden_shares  = [] if sh_raw == "NONE" else sh_raw.split(",")
                ipc_only       = len(hidden_shares) == 0

                auto_share_disabled = auto_share_wks == 0

                system_val = {
                    "auto_share_wks_disabled": auto_share_disabled,
                    "hidden_shares":           hidden_shares,
                    "ipc_only":                ipc_only,
                }

                status = (
                    CheckStatus.PASS
                    if (auto_share_disabled or ipc_only)
                    else CheckStatus.FAIL
                )
            except Exception as exc:
                logger.error("AdminSharesCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"auto_share_wks_disabled": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
