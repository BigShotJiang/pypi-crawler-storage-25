from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Both keys live under the same registry path — read in one PS call.
# ConsentPromptBehaviorAdmin values:
#   0 = elevate without prompting (no UAC — extremely dangerous)
#   1 = prompt for credentials on secure desktop
#   2 = prompt for consent on secure desktop
#   3 = prompt for credentials
#   4 = prompt for consent
#   5 = prompt for consent for non-Windows binaries (default)
# Decision: >= 2 is PASS because any prompt is better than silently elevating.
# The human-readable description maps the most common values only.
_PS_SCRIPT = r"""
try {
    $path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
    $lua  = $null
    $cpba = $null

    if (Test-Path $path) {
        $v = Get-ItemProperty -Path $path -Name 'EnableLUA' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $lua = $v.EnableLUA }
        $v = Get-ItemProperty -Path $path -Name 'ConsentPromptBehaviorAdmin' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $cpba = $v.ConsentPromptBehaviorAdmin }
    }

    $luaOut  = if ($null -eq $lua)  { 'NULL' } else { "$lua" }
    $cpbaOut = if ($null -eq $cpba) { 'NULL' } else { "$cpba" }

    "LUA:$luaOut|CPBA:$cpbaOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""

_PROMPT_DESCRIPTIONS = {
    0: "No prompt (auto-elevate) — critical misconfiguration",
    1: "Prompt for credentials on secure desktop",
    2: "Prompt for consent on secure desktop",
    3: "Prompt for credentials",
    4: "Prompt for consent",
    5: "Prompt for consent for non-Windows binaries (default)",
}


class UACCheck(BaseCheck):
    name = "UAC Enabled and Configured"
    category = "Access Control"
    weight = 9
    severity = Severity.CRITICAL
    cve_ids: list[str] = ["CVE-2021-36934"]
    mitre_technique = "T1548.002"
    cis_id = "2.3.17.1"
    # Remediation must set BOTH EnableLUA and ConsentPromptBehaviorAdmin: the
    # check verifies enable_lua == 1 AND consent_prompt_behavior_admin >= 2.
    # Earlier versions only wrote EnableLUA which left the verify step failing.
    # Sequential `;` works in both PowerShell 5.1 and 7+ (unlike `&&`).
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"'
        r" /v EnableLUA /t REG_DWORD /d 1 /f"
        r" ; "
        r'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"'
        r" /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 2 /f"
    )
    remediation_supported = True
    plain_name = 'User Account Control (UAC)'
    risk_summary = 'SIMPLE: The safety prompt that asks Do you want to allow this app to make changes? is turned off | TECH: UAC is disabled or misconfigured — EnableLUA=0 removes the integrity level boundary'
    attack_scenario = 'SIMPLE: Any program you accidentally run can silently install malware with admin rights | TECH: Without UAC, any medium-integrity process can perform privileged operations without elevation prompt'
    why_fix = 'SIMPLE: UAC is what stops malicious programs from quietly taking over your computer | TECH: UAC provides mandatory integrity control separation between user and admin token'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v EnableLUA /t REG_DWORD /d 1 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("UACCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                lua_raw  = parts.get("LUA",  "NULL")
                cpba_raw = parts.get("CPBA", "NULL")

                enable_lua = None if lua_raw  == "NULL" else int(lua_raw)
                consent    = None if cpba_raw == "NULL" else int(cpba_raw)

                prompt_desc = _PROMPT_DESCRIPTIONS.get(
                    consent,
                    f"Unknown value ({consent})" if consent is not None else "Not configured"
                )

                system_val = {
                    "enable_lua": enable_lua,
                    "consent_prompt_behavior_admin": consent,
                    "prompt_description": prompt_desc,
                }

                lua_ok    = enable_lua == 1
                # None means key absent — Windows default is 5 (prompts) but we
                # treat absent key conservatively as 0 (no prompt) to force a finding.
                consent_ok = consent is not None and consent >= 2
                status = CheckStatus.PASS if (lua_ok and consent_ok) else CheckStatus.FAIL
            except Exception as exc:
                logger.error("UACCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"enable_lua": 1, "consent_prompt_behavior_admin": 2},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
