from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# HKLM takes priority over HKCU per Windows Script Host documentation.
# Enabled = 0 means WSH is disabled; key absent means WSH is enabled (default).
# Decision: HKLM absent AND HKCU absent → FAIL (WSH on by default).
# HKLM absent AND HKCU Enabled=0 → PASS (user-level disable is honoured when
# HKLM makes no claim).
_PS_SCRIPT = r"""
try {
    $hklmPath = 'HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings'
    $hkcuPath = 'HKCU:\Software\Microsoft\Windows Script Host\Settings'

    $hklmEnabled = $null
    $hkcuEnabled = $null

    if (Test-Path $hklmPath) {
        $v = Get-ItemProperty -Path $hklmPath -Name 'Enabled' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $hklmEnabled = $v.Enabled }
    }
    if (Test-Path $hkcuPath) {
        $v = Get-ItemProperty -Path $hkcuPath -Name 'Enabled' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $hkcuEnabled = $v.Enabled }
    }

    $hklmOut = if ($null -eq $hklmEnabled) { 'NULL' } else { "$hklmEnabled" }
    $hkcuOut = if ($null -eq $hkcuEnabled) { 'NULL' } else { "$hkcuEnabled" }

    "HKLM:$hklmOut|HKCU:$hkcuOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class WSHCheck(BaseCheck):
    name = "Windows Script Host Disabled"
    category = "Access Control"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1059.005"
    cis_id = "N/A"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Microsoft\Windows Script Host\Settings"'
        r" /v Enabled /t REG_DWORD /d 0 /f"
    )
    remediation_supported = True
    plain_name = 'Windows Script Host'
    risk_summary = 'SIMPLE: Windows can run .vbs and .js script files which are commonly used by malware | TECH: Windows Script Host is enabled — VBScript and JScript can execute with full user privileges'
    attack_scenario = 'SIMPLE: Malware often arrives as email attachments ending in .vbs or .js — they run automatically | TECH: WSH enables script-based malware execution without PowerShell restrictions or AMSI scanning'
    why_fix = 'SIMPLE: Most users never run .vbs or .js files intentionally — disabling WSH removes a malware vector | TECH: WSH scripts bypass many AV heuristics and execute outside PowerShell logging scope'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SOFTWARE\\Microsoft\\Windows Script Host\\Settings /v Enabled /t REG_DWORD /d 0 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("WSHCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                hklm_raw = parts.get("HKLM", "NULL")
                hkcu_raw = parts.get("HKCU", "NULL")

                hklm_enabled = None if hklm_raw == "NULL" else int(hklm_raw)
                hkcu_enabled = None if hkcu_raw == "NULL" else int(hkcu_raw)

                # Evaluate disable state per documented WSH priority rules
                if hklm_enabled == 0:
                    wsh_disabled = True
                elif hklm_enabled is None and hkcu_enabled == 0:
                    wsh_disabled = True
                else:
                    # HKLM present and != 0, or both absent (default = enabled)
                    wsh_disabled = False

                system_val = {
                    "hklm_enabled": hklm_enabled,
                    "hkcu_enabled": hkcu_enabled,
                    "wsh_disabled": wsh_disabled,
                }
                status = CheckStatus.PASS if wsh_disabled else CheckStatus.FAIL
            except Exception as exc:
                logger.error("WSHCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"wsh_disabled": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
