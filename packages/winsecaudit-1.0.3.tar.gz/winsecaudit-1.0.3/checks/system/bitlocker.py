from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Get-BitLockerVolume requires elevation.  An access-denied exception inside the
# PS script is caught and emitted as ERR:ELEVATION so it survives run_powershell's
# stderr swallowing.  We also normalise the drive-not-found case.
_PS_SCRIPT = r"""
try {
    $vol = Get-BitLockerVolume -MountPoint 'C:' -ErrorAction Stop
    $vs  = $vol.VolumeStatus
    $ps  = $vol.ProtectionStatus
    $pct = [int]$vol.EncryptionPercentage
    "VS:$vs|PS:$ps|PCT:$pct"
} catch [System.UnauthorizedAccessException] {
    'ERR:ELEVATION'
} catch {
    $msg = $_.Exception.Message
    if ($msg -match 'access.denied|privilege|administrator|unauthorized' -or
        $_.Exception -is [System.Security.SecurityException]) {
        'ERR:ELEVATION'
    } elseif ($msg -match "not found|C:|No such|Cannot find|does not exist") {
        'ERR:DRIVE_NOT_FOUND'
    } else {
        "ERR:$msg"
    }
}
"""

# Both FullyEncrypted and EncryptionInProgress are acceptable passing states.
_PASS_STATUSES = frozenset({"FullyEncrypted", "EncryptionInProgress"})


class BitLockerCheck(BaseCheck):
    name = "BitLocker Enabled on C: Drive"
    category = "System Hardening"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2015-6112"]
    mitre_technique = "T1486"
    cis_id = "18.9.11.1"
    remediation_cmd = "Enable-BitLocker -MountPoint 'C:' -EncryptionMethod Aes256"
    remediation_supported = False
    plain_name = 'Disk Encryption (BitLocker)'
    risk_summary = 'SIMPLE: Your hard drive is not encrypted — all files are readable if someone takes the drive | TECH: BitLocker volume protection is not active on C: — data at rest is unencrypted'
    attack_scenario = 'SIMPLE: If your laptop is stolen, the thief can read all your files by connecting the drive to another computer | TECH: Unencrypted volumes can be read via cold boot attack, direct disk access, or forensic imaging'
    why_fix = 'SIMPLE: Encryption means your data is unreadable to anyone who does not have your password | TECH: BitLocker AES-256 prevents offline data extraction regardless of physical access'
    fix_steps = 'SIMPLE: Go to Control Panel -> BitLocker Drive Encryption -> Turn on | TECH: Enable-BitLocker -MountPoint C: -EncryptionMethod Aes256 -UsedSpaceOnly'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("BitLockerCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:ELEVATION":
            error_msg = "Requires Administrator privileges"
        elif raw == "ERR:DRIVE_NOT_FOUND":
            error_msg = "C: drive not found"
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                volume_status = parts.get("VS", "Unknown")
                protection_status = parts.get("PS", "Unknown")
                encryption_pct = int(parts.get("PCT", "0"))
                system_val = {
                    "volume_status": volume_status,
                    "protection_status": protection_status,
                    "encryption_percentage": encryption_pct,
                }
                status = (
                    CheckStatus.PASS
                    if volume_status in _PASS_STATUSES
                    else CheckStatus.FAIL
                )
            except Exception as exc:
                logger.error("BitLockerCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"volume_status": "FullyEncrypted"},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
