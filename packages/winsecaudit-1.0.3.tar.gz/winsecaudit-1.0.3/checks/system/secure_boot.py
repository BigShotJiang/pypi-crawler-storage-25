from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Confirm-SecureBootUEFI throws PlatformNotSupportedException on Legacy BIOS
# and on most hypervisors.  We catch it inside the PS script and emit a typed
# token so run_powershell() (which swallows stderr) still passes the signal.
# Decision: any "not supported" variant → SKIPPED (machine physically cannot
# have Secure Boot; a finding here would be meaningless noise).
_PS_SCRIPT = r"""
try {
    $result = Confirm-SecureBootUEFI -ErrorAction Stop
    $result.ToString().ToLower()
} catch [System.PlatformNotSupportedException] {
    'ERR:NOTSUPPORTED'
} catch [System.UnauthorizedAccessException] {
    'ERR:ELEVATION'
} catch {
    $msg = $_.Exception.Message
    if ($msg -match 'not supported|platform|UEFI|cmdlet.*not.*supported') {
        'ERR:NOTSUPPORTED'
    } else {
        "ERR:$msg"
    }
}
"""


class SecureBootCheck(BaseCheck):
    name = "Secure Boot Enabled"
    category = "System Hardening"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2022-21894"]
    mitre_technique = "T1542.003"
    cis_id = "N/A"
    remediation_cmd = "Enable Secure Boot in UEFI/BIOS firmware settings"
    remediation_supported = False
    plain_name = 'Secure Boot'
    risk_summary = 'SIMPLE: A protection that prevents tampered software from loading when your computer starts is off | TECH: Secure Boot is disabled — bootloader and early-boot components are unsigned and unverified'
    attack_scenario = 'SIMPLE: Sophisticated attackers can install a hidden virus that survives Windows reinstallation | TECH: Without Secure Boot, bootkits (e.g. BlackLotus CVE-2022-21894) can persist in EFI partition'
    why_fix = 'SIMPLE: Secure Boot ensures only trusted software runs before Windows even loads | TECH: Secure Boot enforces UEFI certificate chain validation, blocking unsigned bootloaders and rootkits'
    fix_steps = 'SIMPLE: Enable Secure Boot in BIOS/UEFI settings (restart and press F2/DEL) | TECH: Enable in UEFI firmware: Security -> Secure Boot -> Enabled (requires CSM disabled)'

    def run(self) -> CheckResult:
        system_val: bool | str = False
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("SecureBootCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:NOTSUPPORTED":
            system_val = "Not supported (Legacy BIOS or VM)"
            status = CheckStatus.SKIPPED
            error_msg = "Confirm-SecureBootUEFI not supported on this platform"
        elif raw == "ERR:ELEVATION":
            error_msg = "Requires Administrator privileges"
            status = CheckStatus.ERROR
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
            status = CheckStatus.ERROR
        elif raw.lower() == "true":
            system_val = True
            status = CheckStatus.PASS
        elif raw.lower() == "false":
            system_val = False
            status = CheckStatus.FAIL
        else:
            error_msg = f"Unexpected output from Confirm-SecureBootUEFI: {raw!r}"
            status = CheckStatus.ERROR

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value=True,
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
