from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# AUOptions values:
#   0/1 = not configured / disabled  → FAIL
#   2   = notify before download      → FAIL  (manual action required)
#   3   = auto-download, notify install → FAIL (install not automatic)
#   4   = auto-download and schedule  → PASS
#   5   = allow local admin to choose → FAIL  (policy is not enforced)
#
# Group Policy path is checked first; local registry is the fallback.
# Decision: AUOptions == 4 is the ONLY PASS value (spec is explicit).
_PS_SCRIPT = r"""
try {
    $gpPath    = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
    $localPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update'
    $wsusPath  = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'

    $auOptions = $null
    $source    = 'not_configured'

    if (Test-Path $gpPath) {
        $v = Get-ItemProperty -Path $gpPath -Name 'AUOptions' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $auOptions = $v.AUOptions; $source = 'policy' }
    }

    if ($null -eq $auOptions -and (Test-Path $localPath)) {
        $v = Get-ItemProperty -Path $localPath -Name 'AUOptions' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $auOptions = $v.AUOptions; $source = 'local' }
    }

    if ($null -eq $auOptions) { $auOptions = 0; $source = 'not_configured' }

    $wsus = 'none'
    if (Test-Path $wsusPath) {
        $w = Get-ItemProperty -Path $wsusPath -Name 'WUServer' -ErrorAction SilentlyContinue
        if ($null -ne $w -and $w.WUServer) { $wsus = $w.WUServer }
    }

    "AU:$auOptions|SRC:$source|WSUS:$wsus"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""

# Only AUOptions=4 means fully automatic (download + schedule).
_PASS_AU_OPTION = 4


class WindowsUpdateCheck(BaseCheck):
    name = "Automatic Windows Updates Enabled"
    category = "System Hardening"
    weight = 9
    severity = Severity.CRITICAL
    cve_ids: list[str] = ["CVE-2020-1472"]
    mitre_technique = "T1190"
    cis_id = "18.9.108.1"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"'
        r" /v AUOptions /t REG_DWORD /d 4 /f"
    )
    remediation_supported = True
    plain_name = "Automatic Windows Updates"
    risk_summary = "SIMPLE: Your computer is not automatically downloading security fixes from Microsoft | TECH: Windows Update AUOptions not set to auto-download and schedule (value 4)"
    attack_scenario = "SIMPLE: Known vulnerabilities that Microsoft already fixed stay open on your computer, making it an easy target | TECH: Unpatched systems are trivially compromised using public exploits for known CVEs"
    why_fix = "SIMPLE: Most successful attacks exploit vulnerabilities Microsoft fixed months ago | TECH: Mean time to exploit for critical CVEs is under 7 days after patch release"
    fix_steps = "SIMPLE: Go to Settings → Windows Update → turn on Automatic Updates | TECH: reg add HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU /v AUOptions /t REG_DWORD /d 4 /f"

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("WindowsUpdateCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                au_options = int(parts.get("AU", "0"))
                source = parts.get("SRC", "unknown")
                wsus_raw = parts.get("WSUS", "none")
                wsus_server: str | None = None if wsus_raw in ("none", "") else wsus_raw
                system_val = {
                    "au_options": au_options,
                    "source": source,
                    "wsus_server": wsus_server,
                }
                status = CheckStatus.PASS if au_options == _PASS_AU_OPTION else CheckStatus.FAIL
            except Exception as exc:
                logger.error("WindowsUpdateCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"au_options": _PASS_AU_OPTION},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
