from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Emit a single pipe-delimited token line from inside try/catch so that
# run_powershell() always sees exit-code 0 and never swallows our signal.
# CommandNotFoundException covers systems without Defender (Server Core, etc.).
_PS_SCRIPT = r"""
try {
    $pref   = Get-MpPreference   -ErrorAction Stop
    $status = Get-MpComputerStatus -ErrorAction Stop
    $rt  = (-not $pref.DisableRealtimeMonitoring).ToString().ToLower()
    $av  = $status.AntivirusEnabled.ToString().ToLower()
    $ver = $status.AntivirusSignatureVersion
    "RT:$rt|AV:$av|VER:$ver"
} catch [System.Management.Automation.CommandNotFoundException] {
    'ERR:NOT_PRESENT'
} catch [System.Management.Automation.RuntimeException] {
    # Thrown on some SKUs where Defender service is absent at runtime.
    'ERR:NOT_PRESENT'
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class DefenderCheck(BaseCheck):
    name = "Windows Defender Real-Time Protection"
    category = "System Hardening"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1562.001"
    cis_id = "2.3.11.1"
    remediation_cmd = "Set-MpPreference -DisableRealtimeMonitoring $false"
    remediation_supported = True
    plain_name = "Windows Defender Antivirus"
    risk_summary = "SIMPLE: Real-time virus protection is turned off on this computer | TECH: Windows Defender real-time monitoring is disabled — malware executes without on-access scanning"
    attack_scenario = "SIMPLE: Malware, ransomware, and viruses can install and run without any warning | TECH: Without real-time protection, malicious executables and scripts run without AV interception"
    why_fix = "SIMPLE: Antivirus is your safety net when other defenses fail | TECH: Real-time monitoring provides last-line defense against known malware signatures and behavioral detection"
    fix_steps = "SIMPLE: Go to Windows Security → Virus & threat protection → turn on | TECH: Set-MpPreference -DisableRealtimeMonitoring $false"

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("DefenderCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:NOT_PRESENT":
            return CheckResult(
                check_name=self.name,
                category=self.category,
                status=CheckStatus.SKIPPED,
                system_value={},
                expected_value={"realtime_enabled": True, "antivirus_enabled": True},
                severity=self.severity,
                weight=self.weight,
                cve_ids=self.cve_ids,
                mitre_technique=self.mitre_technique,
                cis_id=self.cis_id,
                remediation_cmd=self.remediation_cmd,
                remediation_supported=self.remediation_supported,
                error_message="Windows Defender not present on this system",
            )
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            # Parse "RT:true|AV:true|VER:1.2.3.4"
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                realtime_enabled = parts.get("RT", "false").lower() == "true"
                antivirus_enabled = parts.get("AV", "false").lower() == "true"
                definition_version = parts.get("VER", "unknown")
                system_val = {
                    "realtime_enabled": realtime_enabled,
                    "antivirus_enabled": antivirus_enabled,
                    "definition_version": definition_version,
                }
                status = CheckStatus.PASS if (realtime_enabled and antivirus_enabled) else CheckStatus.FAIL
            except Exception as exc:
                logger.error("DefenderCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        if error_msg and not system_val:
            status = CheckStatus.ERROR

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"realtime_enabled": True, "antivirus_enabled": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
