from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# PowerShell snippet that emits three lines: Domain, Private, Public firewall state.
_PS_SCRIPT = (
    "(Get-NetFirewallProfile -Profile Domain).Enabled;"
    "(Get-NetFirewallProfile -Profile Private).Enabled;"
    "(Get-NetFirewallProfile -Profile Public).Enabled"
)


class FirewallCheck(BaseCheck):
    name = "Windows Firewall Enabled"
    category = "System Hardening"
    weight = 10
    severity = Severity.CRITICAL
    cve_ids: list[str] = []
    mitre_technique = "T1562.004"
    cis_id = "9.1.1"
    remediation_cmd = "netsh advfirewall set allprofiles state on"
    remediation_supported = True
    plain_name = "Windows Firewall"
    risk_summary = "SIMPLE: Your computer has no barrier blocking unwanted network connections | TECH: Windows Firewall profiles (Domain/Private/Public) are not enforcing inbound packet filtering"
    attack_scenario = "SIMPLE: Anyone on the same WiFi can try to break into your computer | TECH: Exposes all listening services to lateral movement; no implicit deny on inbound connections"
    why_fix = "SIMPLE: A firewall is your first line of defense — like locking your front door | TECH: Without host-based firewall, network segmentation alone cannot prevent intra-VLAN attacks"
    fix_steps = "SIMPLE: Go to Windows Security → Firewall & network protection → turn on for all networks | TECH: Run: netsh advfirewall set allprofiles state on"

    def run(self) -> CheckResult:
        profiles = {"domain": False, "private": False, "public": False}
        error_msg: str | None = None

        try:
            raw = run_powershell(_PS_SCRIPT)
            if raw:
                lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
                if len(lines) >= 3:
                    profiles["domain"] = lines[0].lower() == "true"
                    profiles["private"] = lines[1].lower() == "true"
                    profiles["public"] = lines[2].lower() == "true"
                else:
                    error_msg = f"Unexpected PowerShell output: {raw!r}"
            else:
                error_msg = "PowerShell returned no output — check may be running on non-Windows."
        except (RuntimeError, TimeoutError) as exc:
            logger.error("FirewallCheck failed: %s", exc)
            error_msg = str(exc)

        if error_msg:
            status = CheckStatus.ERROR
        elif all(profiles.values()):
            status = CheckStatus.PASS
        else:
            status = CheckStatus.FAIL

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=profiles,
            expected_value={"domain": True, "private": True, "public": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
