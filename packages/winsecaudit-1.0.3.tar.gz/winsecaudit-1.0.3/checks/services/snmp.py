from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

_PS_SCRIPT = r"""
try {
    $svc = Get-Service -Name 'SNMP' -ErrorAction SilentlyContinue
    if ($null -eq $svc) {
        'SVC:NONE|SVCST:NONE|PRESENT:false'
    } else {
        "SVC:$($svc.Status)|SVCST:$($svc.StartType)|PRESENT:true"
    }
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class SNMPCheck(BaseCheck):
    name = "SNMP Service Disabled"
    category = "Services"
    weight = 6
    severity = Severity.MEDIUM
    cve_ids: list[str] = ["CVE-2002-0013"]
    mitre_technique = "T1602.001"
    cis_id = "N/A"
    remediation_cmd = (
        "Stop-Service -Name SNMP -Force; Set-Service -Name SNMP -StartupType Disabled"
    )
    remediation_supported = True
    plain_name = 'SNMP Network Management'
    risk_summary = 'SIMPLE: A network monitoring service is running that has known security weaknesses | TECH: SNMP service active — v1/v2c community strings transmitted in cleartext'
    attack_scenario = 'SIMPLE: Attackers can read network configuration information or even change settings if SNMP is misconfigured | TECH: SNMP community string brute-force enables device enumeration; write access enables config tampering'
    why_fix = 'SIMPLE: Unless you specifically use SNMP for network monitoring, it should be disabled | TECH: SNMPv1/v2 have no authentication or encryption; SNMPv3 required if SNMP is needed'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: Stop-Service -Name SNMP -Force; Set-Service -Name SNMP -StartupType Disabled'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("SNMPCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                svc_status  = parts.get("SVC",     "NONE")
                svc_start   = parts.get("SVCST",   "NONE")
                present_raw = parts.get("PRESENT", "false")

                service_present    = present_raw.lower() == "true"
                service_status     = None if svc_status == "NONE" else svc_status
                service_start_type = None if svc_start  == "NONE" else svc_start

                system_val = {
                    "status":          service_status,
                    "start_type":      service_start_type,
                    "service_present": service_present,
                }

                if not service_present:
                    status = CheckStatus.PASS
                elif service_status == "Stopped" and service_start_type == "Disabled":
                    status = CheckStatus.PASS
                else:
                    status = CheckStatus.FAIL
            except Exception as exc:
                logger.error("SNMPCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"service_present": False},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
