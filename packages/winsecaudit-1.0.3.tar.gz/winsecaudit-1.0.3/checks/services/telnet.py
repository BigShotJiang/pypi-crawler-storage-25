from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Get-WindowsOptionalFeature requires elevation on some Windows SKUs.
# Feature not present = Telnet not installed = safe = PASS with state "NotPresent".
_PS_SCRIPT = r"""
try {
    $feat = Get-WindowsOptionalFeature -Online -FeatureName 'TelnetClient' -ErrorAction Stop
    "STATE:$($feat.State)|FOUND:true"
} catch [System.UnauthorizedAccessException] {
    'ERR:ELEVATION'
} catch {
    $msg = $_.Exception.Message
    if ($msg -match 'not.*found|feature.*not|0x80070490') {
        'STATE:NotPresent|FOUND:false'
    } elseif ($msg -match 'access.denied|privilege|administrator') {
        'ERR:ELEVATION'
    } else {
        "ERR:$msg"
    }
}
"""


class TelnetCheck(BaseCheck):
    name = "Telnet Client Disabled"
    category = "Services"
    weight = 6
    severity = Severity.MEDIUM
    cve_ids: list[str] = []
    mitre_technique = "T1021"
    cis_id = "N/A"
    remediation_cmd = (
        "Disable-WindowsOptionalFeature -Online -FeatureName TelnetClient -NoRestart"
    )
    remediation_supported = True
    plain_name = 'Telnet (Insecure Remote Access)'
    risk_summary = 'SIMPLE: An old remote access tool that sends everything including passwords as plain text is installed | TECH: Telnet client is present — provides unencrypted terminal access capability'
    attack_scenario = 'SIMPLE: If you or anything on your computer uses Telnet, passwords are visible to anyone on the network | TECH: Telnet transmits credentials in cleartext — trivial to capture with Wireshark or tcpdump'
    why_fix = 'SIMPLE: Use SSH instead — it does everything Telnet does but encrypted | TECH: Telnet has no encryption or authentication security; SSH supersedes it entirely'
    fix_steps = 'SIMPLE: This is removed automatically — click Yes when prompted | TECH: Disable-WindowsOptionalFeature -Online -FeatureName TelnetClient -NoRestart'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT, timeout=60)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("TelnetCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:ELEVATION":
            error_msg = "Requires Administrator privileges"
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                state       = parts.get("STATE", "Unknown")
                feature_found = parts.get("FOUND", "false").lower() == "true"

                system_val = {"state": state, "feature_found": feature_found}

                # Not present or explicitly disabled are both PASS
                status = (
                    CheckStatus.PASS
                    if state in ("Disabled", "NotPresent")
                    else CheckStatus.FAIL
                )
            except Exception as exc:
                logger.error("TelnetCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"state": "Disabled"},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
