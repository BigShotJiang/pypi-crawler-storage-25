from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# PrintNightmare (CVE-2021-34527) requires Print Spooler to be running.
# PASS requires both Stopped AND Disabled StartType — "Stopped/Manual" can
# be re-enabled by any user with sufficient rights and is not safe.
_PS_SCRIPT = r"""
try {
    $svc = Get-Service -Name 'Spooler' -ErrorAction Stop
    "STATUS:$($svc.Status)|STARTTYPE:$($svc.StartType)"
} catch [Microsoft.PowerShell.Commands.ServiceCommandException] {
    'ERR:SERVICE_NOT_FOUND'
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class PrintSpoolerCheck(BaseCheck):
    name = "Print Spooler Service Disabled"
    category = "Services"
    weight = 9
    severity = Severity.CRITICAL
    cve_ids: list[str] = ["CVE-2021-34527", "CVE-2021-1675"]
    mitre_technique = "T1204"
    cis_id = "N/A"
    remediation_cmd = (
        "Stop-Service -Name Spooler -Force; Set-Service -Name Spooler -StartupType Disabled"
    )
    remediation_supported = True
    plain_name = 'Print Spooler Service'
    risk_summary = 'SIMPLE: A Windows printing service is running that has a known critical vulnerability | TECH: Print Spooler service is exploitable via PrintNightmare (CVE-2021-34527) for LPE and RCE'
    attack_scenario = 'SIMPLE: Attackers can install malware and become the administrator of your computer | TECH: Authenticated users can load arbitrary DLLs via SpoolSS RPC, achieving SYSTEM-level code execution'
    why_fix = 'SIMPLE: Unless you print from this computer constantly, this service should be off | TECH: PrintNightmare is weaponized in ransomware campaigns; CISA mandated patching in 2021'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: Stop-Service -Name Spooler -Force; Set-Service -Name Spooler -StartupType Disabled'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("PrintSpoolerCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:SERVICE_NOT_FOUND":
            # Spooler missing entirely → safe (better than running)
            system_val = {"status": "NotInstalled", "start_type": "NotInstalled"}
            status = CheckStatus.PASS
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                svc_status = parts.get("STATUS",    "Unknown")
                start_type = parts.get("STARTTYPE", "Unknown")

                system_val = {"status": svc_status, "start_type": start_type}

                fully_disabled = (svc_status == "Stopped" and start_type == "Disabled")
                status = CheckStatus.PASS if fully_disabled else CheckStatus.FAIL
            except Exception as exc:
                logger.error("PrintSpoolerCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"status": "Stopped", "start_type": "Disabled"},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
