from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Check both the Windows service (ftpsvc) and the IIS FTP Windows Feature.
# Either present and enabled is a finding. Get-WindowsOptionalFeature needs
# elevation on some SKUs — handled via ERR:ELEVATION token.
_PS_SCRIPT = r"""
try {
    $svcStatus    = 'NONE'
    $svcStartType = 'NONE'
    $iisState     = 'NONE'

    $svc = Get-Service -Name 'ftpsvc' -ErrorAction SilentlyContinue
    if ($null -ne $svc) {
        $svcStatus    = "$($svc.Status)"
        $svcStartType = "$($svc.StartType)"
    }

    try {
        $feat = Get-WindowsOptionalFeature -Online -FeatureName 'IIS-FTPServer' -ErrorAction Stop
        $iisState = "$($feat.State)"
    } catch [System.UnauthorizedAccessException] {
        $iisState = 'ERR_ELEVATION'
    } catch {
        $iisState = 'NONE'
    }

    "SVC:$svcStatus|SVCST:$svcStartType|IIS:$iisState"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class FTPCheck(BaseCheck):
    name = "FTP Service Disabled"
    category = "Services"
    weight = 6
    severity = Severity.MEDIUM
    cve_ids: list[str] = []
    mitre_technique = "T1021.002"
    cis_id = "N/A"
    remediation_cmd = (
        "Stop-Service -Name ftpsvc -Force; Set-Service -Name ftpsvc -StartupType Disabled"
    )
    remediation_supported = True
    plain_name = 'FTP File Transfer Service'
    risk_summary = 'SIMPLE: A file transfer service that sends data and passwords without encryption is running | TECH: IIS FTP service is active — transmits credentials and data in cleartext'
    attack_scenario = 'SIMPLE: Anyone watching network traffic can see every file you transfer and your FTP password | TECH: FTP credentials captured via passive sniffing; no transport security by design'
    why_fix = 'SIMPLE: Use SFTP or FTPS instead — they do the same job with encryption | TECH: FTP has no TLS by default; disable unless specifically required with FTPS enforced'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: Stop-Service -Name ftpsvc -Force; Set-Service -Name ftpsvc -StartupType Disabled'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT, timeout=60)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("FTPCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                svc_status    = parts.get("SVC",   "NONE")
                svc_start     = parts.get("SVCST", "NONE")
                iis_state     = parts.get("IIS",   "NONE")

                service_status    = None if svc_status == "NONE" else svc_status
                service_start_type = None if svc_start  == "NONE" else svc_start
                iis_ftp_feature   = None if iis_state   in ("NONE", "ERR_ELEVATION") else iis_state

                # ftp_present: service exists OR IIS FTP feature is enabled
                svc_present = service_status is not None
                iis_enabled = iis_ftp_feature == "Enabled"
                ftp_present = svc_present or iis_enabled

                system_val = {
                    "service_status":     service_status,
                    "service_start_type": service_start_type,
                    "iis_ftp_feature":    iis_ftp_feature,
                    "ftp_present":        ftp_present,
                }

                if not ftp_present:
                    status = CheckStatus.PASS
                elif service_status == "Stopped" and service_start_type == "Disabled" and not iis_enabled:
                    status = CheckStatus.PASS
                else:
                    status = CheckStatus.FAIL
            except Exception as exc:
                logger.error("FTPCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"ftp_present": False},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
