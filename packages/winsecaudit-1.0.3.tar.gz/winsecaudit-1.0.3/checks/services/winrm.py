from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# WinRM stopped = best outcome.  If running, AllowUnencrypted must be false.
# `winrm get winrm/config/service` fails when the service is stopped — the
# PS script catches that and emits "NONE" for the AllowUnencrypted field.
_PS_SCRIPT = r"""
try {
    $svc = Get-Service -Name 'WinRM' -ErrorAction Stop
    $status    = $svc.Status
    $startType = $svc.StartType

    $allowUnenc = 'NONE'
    if ($status -eq 'Running') {
        try {
            $cfg = winrm get winrm/config/service 2>$null
            if ($cfg -match 'AllowUnencrypted\s*=\s*(\w+)') {
                $allowUnenc = $Matches[1].ToLower()
            }
        } catch {
            $allowUnenc = 'ERROR'
        }
    }

    "STATUS:$status|STARTTYPE:$startType|ALLUNENC:$allowUnenc"
} catch [Microsoft.PowerShell.Commands.ServiceCommandException] {
    'ERR:SERVICE_NOT_FOUND'
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class WinRMCheck(BaseCheck):
    name = "WinRM Service Secured"
    category = "Services"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1021.006"
    cis_id = "18.9.102.1"
    remediation_cmd = "Disable-PSRemoting -Force"
    remediation_supported = False
    plain_name = 'Remote Management Service (WinRM)'
    risk_summary = 'SIMPLE: A remote management service is running that could allow unencrypted access | TECH: WinRM is active with potential unencrypted transport — credential exposure risk on network'
    attack_scenario = 'SIMPLE: Attackers who get onto your network can manage your computer remotely | TECH: WinRM with AllowUnencrypted=true exposes credentials in cleartext; enables lateral movement via PSRemoting'
    why_fix = 'SIMPLE: If you do not use remote management, this service should be off | TECH: Disable WinRM if not required; if required, enforce HTTPS transport only'
    fix_steps = 'SIMPLE: This is fixed by running a command — click Yes when prompted | TECH: Disable-PSRemoting -Force'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("WinRMCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:SERVICE_NOT_FOUND":
            system_val = {"status": "NotInstalled", "start_type": "NotInstalled", "allow_unencrypted": None}
            status = CheckStatus.PASS
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                svc_status  = parts.get("STATUS",    "Unknown")
                start_type  = parts.get("STARTTYPE", "Unknown")
                au_raw      = parts.get("ALLUNENC",  "NONE")

                allow_unencrypted: bool | None = None
                if au_raw == "true":
                    allow_unencrypted = True
                elif au_raw == "false":
                    allow_unencrypted = False
                # NONE or ERROR → None (WinRM stopped or winrm cmd failed)

                system_val = {
                    "status":             svc_status,
                    "start_type":         start_type,
                    "allow_unencrypted":  allow_unencrypted,
                }

                if svc_status == "Stopped":
                    status = CheckStatus.PASS
                elif allow_unencrypted is False:
                    # Running but encryption enforced — acceptable
                    status = CheckStatus.PASS
                else:
                    # Running AND unencrypted (or unknown) — FAIL
                    status = CheckStatus.FAIL
            except Exception as exc:
                logger.error("WinRMCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"status": "Stopped"},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
