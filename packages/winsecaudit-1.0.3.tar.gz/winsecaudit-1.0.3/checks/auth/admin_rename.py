from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Query the built-in RID-500 account regardless of what it has been named.
# Decision: if the account is disabled but still named "Administrator", that is
# still a FAIL — an attacker who re-enables it gains a known username.
_PS_SCRIPT = r"""
try {
    $user = Get-LocalUser | Where-Object { $_.SID -like '*-500' } | Select-Object -First 1
    if ($null -eq $user) {
        'ERR:RID500_NOT_FOUND'
    } else {
        "NAME:$($user.Name)|ENABLED:$($user.Enabled.ToString().ToLower())"
    }
} catch {
    "ERR:$($_.Exception.Message)"
}
"""

_DEFAULT_NAME = "administrator"  # case-insensitive comparison target


class AdminRenameCheck(BaseCheck):
    name = "Default Administrator Account Renamed"
    category = "Authentication Security"
    weight = 5
    severity = Severity.MEDIUM
    cve_ids: list[str] = []
    mitre_technique = "T1078.001"
    cis_id = "2.3.1.1"
    remediation_cmd = r'wmic useraccount where "SID like \'%-500\'" rename "SecureAdmin"'
    remediation_supported = False
    plain_name = 'Default Administrator Account'
    risk_summary = 'SIMPLE: The built-in admin account still has its default name, making it a known target | TECH: RID-500 account retains default Administrator name — trivially targeted in credential attacks'
    attack_scenario = 'SIMPLE: Attackers always try Administrator as a username first — you are making their job easy | TECH: Default account name enables targeted brute-force and pass-the-hash without enumeration'
    why_fix = 'SIMPLE: Renaming it means attackers have to guess both the username and password | TECH: Obscuring RID-500 name adds friction to credential-based attacks and slows enumeration'
    fix_steps = 'SIMPLE: Go to Computer Management -> Local Users -> rename Administrator | TECH: wmic useraccount where SID like -500 rename SecureAdmin'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("AdminRenameCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw == "ERR:RID500_NOT_FOUND":
            # Extremely unlikely on any real Windows install, but handle it.
            error_msg = "RID-500 (built-in Administrator) account not found"
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                rid500_name = parts.get("NAME", "")
                rid500_enabled = parts.get("ENABLED", "false").lower() == "true"
                system_val = {
                    "rid500_name": rid500_name,
                    "rid500_enabled": rid500_enabled,
                }
                is_renamed = rid500_name.lower() != _DEFAULT_NAME
                status = CheckStatus.PASS if is_renamed else CheckStatus.FAIL
            except Exception as exc:
                logger.error("AdminRenameCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"rid500_name": "<not 'Administrator'>"},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
