from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity
from checks.auth._secedit_helper import get_secedit_policy

logger = logging.getLogger(__name__)


class PasswordComplexityCheck(BaseCheck):
    name = "Password Complexity Enabled"
    category = "Authentication Security"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2021-31956"]
    mitre_technique = "T1110.001"
    cis_id = "1.1.5"
    remediation_cmd = (
        "secedit /configure /db secedit.sdb "
        "/cfg %SystemRoot%\\inf\\defltbase.inf /overwrite"
    )
    remediation_supported = False
    plain_name = 'Password Strength Requirements'
    risk_summary = 'SIMPLE: Windows is not requiring strong passwords — users can set password123 | TECH: Password complexity policy disabled in effective security policy (secedit PasswordComplexity=0)'
    attack_scenario = 'SIMPLE: Attackers can guess weak passwords in seconds using automated tools | TECH: Enables dictionary and brute-force attacks against local accounts and RDP'
    why_fix = 'SIMPLE: Weak passwords are the #1 way accounts get hacked | TECH: Complexity requirements force mixed character classes, increasing keyspace against offline attacks'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: Enable via secedit or Group Policy: Computer Config -> Windows Settings -> Security Settings -> Account Policies'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            policy = get_secedit_policy()
        except Exception as exc:
            logger.error("PasswordComplexityCheck: unexpected error from secedit helper: %s", exc)
            policy = {}

        if not policy:
            error_msg = "secedit policy export failed or returned empty — cannot determine password complexity"
        else:
            try:
                raw_val = policy.get("PasswordComplexity", None)
                if raw_val is None:
                    # Key absent in export — treat as 0 (disabled) per Windows default when not set.
                    complexity = 0
                    error_msg = "PasswordComplexity key not found in secedit output; defaulting to 0"
                    status = CheckStatus.FAIL
                else:
                    complexity = int(raw_val)
                    status = CheckStatus.PASS if complexity == 1 else CheckStatus.FAIL

                system_val = {"password_complexity": complexity, "source": "secedit"}
            except (ValueError, TypeError) as exc:
                error_msg = f"Could not parse PasswordComplexity value: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"password_complexity": 1},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
