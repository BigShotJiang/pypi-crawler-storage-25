from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity
from checks.auth._secedit_helper import get_secedit_policy

logger = logging.getLogger(__name__)

_MIN_REQUIRED = 14  # CIS Benchmark Level 1 requirement


class MinPasswordLengthCheck(BaseCheck):
    name = "Minimum Password Length"
    category = "Authentication Security"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1110"
    cis_id = "1.1.4"
    remediation_cmd = "net accounts /minpwlen:14"
    remediation_supported = True
    plain_name = 'Minimum Password Length'
    risk_summary = 'SIMPLE: Users are allowed to set very short, easy-to-guess passwords | TECH: Minimum password length policy below 14 characters — insufficient against offline cracking'
    attack_scenario = 'SIMPLE: Short passwords can be cracked in minutes with common tools | TECH: Passwords under 14 chars are trivially brute-forced offline after NTLM hash extraction'
    why_fix = 'SIMPLE: Longer passwords are exponentially harder to guess or crack | TECH: Each additional character multiplies keyspace — 14+ chars makes offline attacks computationally expensive'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: net accounts /minpwlen:14'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            policy = get_secedit_policy()
        except Exception as exc:
            logger.error("MinPasswordLengthCheck: unexpected error from secedit helper: %s", exc)
            policy = {}

        if not policy:
            error_msg = "secedit policy export failed or returned empty — cannot determine password length"
        else:
            try:
                raw_val = policy.get("MinimumPasswordLength", None)
                if raw_val is None:
                    min_len = 0
                    error_msg = "MinimumPasswordLength key not found in secedit output; defaulting to 0"
                    status = CheckStatus.FAIL
                else:
                    min_len = int(raw_val)
                    status = CheckStatus.PASS if min_len >= _MIN_REQUIRED else CheckStatus.FAIL

                system_val = {"min_password_length": min_len, "source": "secedit"}
            except (ValueError, TypeError) as exc:
                error_msg = f"Could not parse MinimumPasswordLength value: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"min_password_length": _MIN_REQUIRED},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
