from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Returns "True" if the Guest account is active, "False" if disabled.
_PS_SCRIPT = "(Get-LocalUser -Name 'Guest').Enabled"


class GuestAccountCheck(BaseCheck):
    name = "Guest Account Disabled"
    category = "Authentication Security"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2010-0230"]
    mitre_technique = "T1078.001"
    cis_id = "2.3.1.5"
    remediation_cmd = "net user guest /active:no"
    remediation_supported = True
    plain_name = 'Guest Account'
    risk_summary = 'SIMPLE: A built-in account that anyone can log into without a password is enabled | TECH: Built-in Guest account is active — provides unauthenticated local access'
    attack_scenario = 'SIMPLE: Anyone with physical access to your computer can log in as Guest | TECH: Enabled Guest account provides initial foothold for local privilege escalation'
    why_fix = 'SIMPLE: There is no reason to have an open-door account — disable it | TECH: Guest account eliminates authentication requirement for local access'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: net user guest /active:no'

    def run(self) -> CheckResult:
        guest_enabled: bool | None = None
        error_msg: str | None = None

        try:
            raw = run_powershell(_PS_SCRIPT)
            if raw:
                guest_enabled = raw.strip().lower() == "true"
            else:
                error_msg = "PowerShell returned no output — check may be running on non-Windows."
        except (RuntimeError, TimeoutError) as exc:
            logger.error("GuestAccountCheck failed: %s", exc)
            error_msg = str(exc)

        if error_msg:
            status = CheckStatus.ERROR
        elif guest_enabled is False:
            status = CheckStatus.PASS
        else:
            # guest_enabled is True (account active) → FAIL
            status = CheckStatus.FAIL

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value={"guest_enabled": guest_enabled},
            expected_value={"guest_enabled": False},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
