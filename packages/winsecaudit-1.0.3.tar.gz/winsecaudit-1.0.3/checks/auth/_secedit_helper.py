"""
Shared helper for auth checks that need effective local security policy values.

Runs `secedit /export` exactly once per call, parses the INF-format output into
a flat {key: value} dict, and returns {} on any failure so callers can treat
missing keys as an ERROR condition without crashing.

This module must NOT subclass BaseCheck — it is a pure utility.
"""
from __future__ import annotations

import logging
import re

from checks.base import run_powershell

logger = logging.getLogger(__name__)

# Run secedit inside PowerShell so we never call subprocess directly.
# secedit exports UTF-16 LE; run_powershell() reads stdout as UTF-8, so we
# Base64-encode the bytes in PowerShell and decode them in Python — this is
# fully encoding-agnostic and survives any pipe/console encoding quirks.
_PS_EXPORT = r"""
try {
    $tmp = [System.IO.Path]::GetTempFileName()
    secedit /export /cfg "$tmp" /quiet | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $tmp)) {
        'ERR:SECEDIT_FAILED'
    } else {
        $raw   = [System.IO.File]::ReadAllBytes($tmp)
        $b64   = [System.Convert]::ToBase64String($raw)
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        $b64
    }
} catch {
    "ERR:$($_.Exception.Message)"
}
"""

# Sections whose key=value pairs we care about.
_TARGET_SECTIONS = frozenset({
    "[System Access]",
    "[Event Audit]",
    "[Privilege Rights]",
    "[Kerberos Policy]",
})


def get_secedit_policy() -> dict[str, str]:
    """
    Return effective local security policy as a flat {key: value} dict.
    Keys are taken verbatim from the INF file (e.g. "PasswordComplexity").
    Values are raw strings — callers must coerce to int where needed.
    Returns {} on any failure (non-Windows, elevation required, parse error).
    """
    import base64

    try:
        raw = run_powershell(_PS_EXPORT, timeout=60)
    except (RuntimeError, TimeoutError) as exc:
        logger.error("get_secedit_policy: PowerShell call failed: %s", exc)
        return {}
    except Exception as exc:
        logger.error("get_secedit_policy: unexpected error: %s", exc)
        return {}

    if not raw or raw.startswith("ERR:"):
        logger.error("get_secedit_policy: secedit export returned: %s", raw or "<empty>")
        return {}

    # Decode Base64 payload. secedit writes UTF-16 LE; ReadAllBytes gives us the
    # raw bytes. Try UTF-16 first (BOM-aware), fall back to UTF-8/latin-1.
    try:
        decoded_bytes = base64.b64decode(raw.strip())
        # Detect UTF-16 LE BOM (FF FE) or UTF-16 BE BOM (FE FF).
        if decoded_bytes[:2] in (b"\xff\xfe", b"\xfe\xff"):
            content = decoded_bytes.decode("utf-16", errors="replace")
        else:
            # secedit on some Windows versions writes ASCII/UTF-8 without BOM.
            content = decoded_bytes.decode("utf-8", errors="replace")
    except Exception as exc:
        logger.error("get_secedit_policy: base64/decode failed: %s", exc)
        return {}

    return _parse_inf(content)


def _parse_inf(content: str) -> dict[str, str]:
    """Parse an INF-format secedit export into a flat key=value dict."""
    result: dict[str, str] = {}
    in_target = False

    for line in content.splitlines():
        # Strip BOM that may appear on any line when PowerShell emits UTF-16.
        line = line.strip().lstrip("\ufeff")

        if not line or line.startswith(";"):
            continue

        if line.startswith("["):
            # Section header — normalise spacing for reliable comparison.
            in_target = re.sub(r"\s+", " ", line).strip() in _TARGET_SECTIONS
            continue

        if in_target and "=" in line:
            key, _, value = line.partition("=")
            result[key.strip()] = value.strip()

    return result
