from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity
from checks.auth._secedit_helper import get_secedit_policy

logger = logging.getLogger(__name__)

# LockoutBadCount = 0 means "never lock out" — always FAIL regardless of other values.
# Decision: PASS requires 1 ≤ LockoutBadCount ≤ 10 (CIS allows up to 10).
_LOCKOUT_MIN = 1
_LOCKOUT_MAX = 10


class AccountLockoutCheck(BaseCheck):
    name = "Account Lockout Threshold"
    category = "Authentication Security"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = ["CVE-2021-31958"]
    mitre_technique = "T1110.001"
    cis_id = "1.2.1"
    remediation_cmd = "net accounts /lockoutthreshold:5"
    remediation_supported = True
    plain_name = 'Account Lockout Policy'
    risk_summary = 'SIMPLE: Attackers can try unlimited password guesses without being locked out | TECH: Account lockout threshold not configured — no rate limiting on authentication attempts'
    attack_scenario = 'SIMPLE: Automated tools can try thousands of passwords against your account with no consequences | TECH: Unlimited authentication attempts enables online brute-force against local accounts and RDP'
    why_fix = 'SIMPLE: Locking accounts after failed attempts stops password guessing attacks cold | TECH: Lockout threshold of 5 prevents online brute-force while allowing legitimate mistakes'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: net accounts /lockoutthreshold:5'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            policy = get_secedit_policy()
        except Exception as exc:
            logger.error("AccountLockoutCheck: unexpected error from secedit helper: %s", exc)
            policy = {}

        if not policy:
            error_msg = "secedit policy export failed or returned empty — cannot determine lockout policy"
        else:
            try:
                lockout_count = int(policy.get("LockoutBadCount", "0"))
                lockout_duration = int(policy.get("LockoutDuration", "0"))
                reset_count = int(policy.get("ResetLockoutCount", "0"))

                system_val = {
                    "lockout_threshold": lockout_count,
                    "lockout_duration_minutes": lockout_duration,
                    "lockout_observation_window_minutes": reset_count,
                    "source": "secedit",
                }

                if _LOCKOUT_MIN <= lockout_count <= _LOCKOUT_MAX:
                    status = CheckStatus.PASS
                else:
                    # 0 = never locks out; >10 = too permissive per CIS
                    status = CheckStatus.FAIL

            except (ValueError, TypeError) as exc:
                error_msg = f"Could not parse lockout policy values: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"lockout_threshold": 5, "lockout_duration_minutes": 15},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
