# checks package — auto-discovered by CheckRegistry; no manual imports needed.
