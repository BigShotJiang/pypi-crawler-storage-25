"""
Core plugin architecture for WinSecAudit v2.
Defines the contract every check must fulfil, the result schema,
the PowerShell helper, and the auto-discovery registry.
"""
from __future__ import annotations

import importlib
import inspect
import logging
import pkgutil
import subprocess
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class CheckStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    ERROR = "ERROR"
    SKIPPED = "SKIPPED"


# ---------------------------------------------------------------------------
# Result schema
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CheckResult:
    check_name: str
    category: str
    status: CheckStatus
    system_value: Any
    expected_value: Any
    severity: Severity
    weight: int
    cve_ids: tuple[str, ...]         # tuple keeps frozen invariant; callers pass list, we coerce
    mitre_technique: str
    cis_id: str
    remediation_cmd: str
    remediation_supported: bool
    error_message: str | None = None

    def __post_init__(self) -> None:
        # Coerce list → tuple so the dataclass stays truly immutable.
        if isinstance(self.cve_ids, list):
            object.__setattr__(self, "cve_ids", tuple(self.cve_ids))


# ---------------------------------------------------------------------------
# Abstract base check
# ---------------------------------------------------------------------------

class BaseCheck(ABC):
    # ---- class-level contract (override in every subclass) -----------------
    name: str = ""
    category: str = ""
    weight: int = 0
    severity: Severity = Severity.LOW
    cve_ids: tuple[str, ...] = ()
    mitre_technique: str = ""
    cis_id: str = ""
    remediation_cmd: str = ""
    remediation_supported: bool = False

    # ---- optional human-readable explanation fields -------------------------
    plain_name: str = ""
    risk_summary: str = ""
    attack_scenario: str = ""
    why_fix: str = ""
    fix_steps: str = ""

    # ---- abstract ----------------------------------------------------------

    @abstractmethod
    def run(self) -> CheckResult:
        """Execute the check and return an immutable CheckResult."""

    # ---- concrete helpers --------------------------------------------------

    def remediate(self) -> dict:
        """
        Apply the remediation command for this check.

        Default behaviour: execute ``self.remediation_cmd`` via PowerShell
        (which can run netsh, secedit, reg, and PS cmdlets alike). Subclasses
        may override for custom logic (multi-step fixes, registry writes, etc.).

        Raises:
            NotImplementedError — when remediation_supported is False or no
                                  remediation_cmd is defined.
            RuntimeError        — when PowerShell reports a non-zero exit.
        """
        if not self.remediation_supported:
            raise NotImplementedError(
                f"Check '{self.name}' does not support automated remediation."
            )
        if not self.remediation_cmd:
            raise NotImplementedError(
                f"Check '{self.name}' has no remediation_cmd defined."
            )

        ps_executable = "powershell.exe" if sys.platform == "win32" else "powershell"
        cmd = [
            ps_executable,
            "-ExecutionPolicy", "Bypass",
            "-NoProfile",
            "-NonInteractive",
            "-Command", self.remediation_cmd,
        ]

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
                encoding="utf-8",
                errors="replace",
            )
        except FileNotFoundError:
            raise RuntimeError(
                "PowerShell executable not found. "
                "Run the remediation command manually: " + self.remediation_cmd
            )
        except subprocess.TimeoutExpired:
            raise TimeoutError(
                f"Remediation for '{self.name}' timed out after 60s."
            )

        if proc.returncode != 0:
            raise RuntimeError(
                f"Remediation exited {proc.returncode}: "
                f"{(proc.stderr or proc.stdout or '').strip()[:400]}"
            )

        return {
            "returncode": proc.returncode,
            "stdout":     proc.stdout.strip(),
            "stderr":     proc.stderr.strip(),
        }

    def verify(self) -> CheckResult:
        """Re-run the check and return its result (convenience alias for run)."""
        return self.run()

    def to_dict(self) -> dict:
        """Serialize the latest CheckResult to a plain dictionary."""
        result: CheckResult = self.run()
        return {
            "check_name": result.check_name,
            "category": result.category,
            "status": result.status.value,
            "system_value": result.system_value,
            "expected_value": result.expected_value,
            "severity": result.severity.value,
            "weight": result.weight,
            "cve_ids": list(result.cve_ids),
            "mitre_technique": result.mitre_technique,
            "cis_id": result.cis_id,
            "remediation_cmd": result.remediation_cmd,
            "remediation_supported": result.remediation_supported,
            "error_message": result.error_message,
        }


# ---------------------------------------------------------------------------
# PowerShell helper
# ---------------------------------------------------------------------------

def run_powershell(script: str, timeout: int = 30) -> str:
    """
    Execute a PowerShell snippet and return stdout as a clean string.

    Returns an empty string (and logs) on any execution failure so callers
    can treat a blank response as an ERROR condition rather than crashing.

    Raises:
        TimeoutError  – process did not finish within *timeout* seconds.
        RuntimeError  – PowerShell executable was not found on PATH.
    """
    ps_executable = "powershell.exe" if sys.platform == "win32" else "powershell"
    cmd = [
        ps_executable,
        "-ExecutionPolicy", "Bypass",
        "-NoProfile",
        "-NonInteractive",
        "-Command", script,
    ]

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
    except FileNotFoundError:
        raise RuntimeError(
            "PowerShell executable not found. "
            "Ensure powershell.exe is on PATH (Windows) or powershell is installed."
        )
    except subprocess.TimeoutExpired:
        raise TimeoutError(
            f"PowerShell script timed out after {timeout}s.\nScript: {script[:200]}"
        )
    except Exception as exc:  # pragma: no cover
        logger.error("Unexpected error running PowerShell: %s", exc)
        return ""

    if proc.returncode != 0:
        logger.error(
            "PowerShell exited %d.\nstderr: %s",
            proc.returncode,
            proc.stderr.strip(),
        )
        return ""

    # Strip UTF-8 BOM (\ufeff) that PowerShell sometimes emits.
    return proc.stdout.lstrip("\ufeff").strip()


# ---------------------------------------------------------------------------
# Auto-discovery registry (singleton pattern via class methods)
# ---------------------------------------------------------------------------

class CheckRegistry:
    """
    Discovers every concrete BaseCheck subclass under a given directory tree.
    This is the ONLY place checks are registered — no manual imports required.
    """

    @classmethod
    def discover(cls, checks_dir: Path) -> list[type[BaseCheck]]:
        """
        Walk *checks_dir* recursively, import every .py module found,
        and collect all non-abstract BaseCheck subclasses.

        Returns classes sorted by (category, name).
        """
        checks_dir = checks_dir.resolve()
        # Ensure the parent of checks_dir is on sys.path so imports resolve.
        parent = str(checks_dir.parent)
        if parent not in sys.path:
            sys.path.insert(0, parent)

        package_name = checks_dir.name
        discovered: list[type[BaseCheck]] = []

        for finder, module_name, _ in pkgutil.walk_packages(
            path=[str(checks_dir)],
            prefix=f"{package_name}.",
            onerror=lambda name: logger.warning("Could not import module: %s", name),
        ):
            try:
                module = importlib.import_module(module_name)
            except Exception as exc:
                logger.warning("Skipping module %s: %s", module_name, exc)
                continue

            for _, obj in inspect.getmembers(module, inspect.isclass):
                if (
                    issubclass(obj, BaseCheck)
                    and obj is not BaseCheck
                    and not inspect.isabstract(obj)
                    and obj not in discovered
                ):
                    discovered.append(obj)

        return sorted(discovered, key=lambda c: (c.category, c.name))
