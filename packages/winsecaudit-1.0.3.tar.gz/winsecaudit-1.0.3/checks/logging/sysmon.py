from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# Sysmon can be installed as "Sysmon" or "Sysmon64" — wildcard covers both.
# Absence of the service is a real security finding (no EDR telemetry), not
# an infrastructure error, so missing service → FAIL, not ERROR.
_PS_SCRIPT = r"""
try {
    $svc = Get-Service -Name 'Sysmon*' -ErrorAction SilentlyContinue | Select-Object -First 1
    $proc = Get-Process -Name 'Sysmon*' -ErrorAction SilentlyContinue | Select-Object -First 1

    $svcFound  = ($null -ne $svc).ToString().ToLower()
    $svcName   = if ($null -eq $svc)  { 'NONE' } else { $svc.Name }
    $svcStatus = if ($null -eq $svc)  { 'NONE' } else { $svc.Status }
    $procRun   = ($null -ne $proc).ToString().ToLower()

    "FOUND:$svcFound|NAME:$svcName|STATUS:$svcStatus|PROC:$procRun"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class SysmonCheck(BaseCheck):
    name = "Sysmon Installed and Running"
    category = "Logging & Auditing"
    weight = 7
    severity = Severity.MEDIUM
    cve_ids: list[str] = []
    mitre_technique = "T1562.001"
    cis_id = "N/A"
    remediation_cmd = (
        "Download Sysmon from https://docs.microsoft.com/en-us/sysinternals/downloads/sysmon"
        " and install with a config"
    )
    remediation_supported = False
    plain_name = 'Sysmon (Advanced Security Monitor)'
    risk_summary = 'SIMPLE: An advanced security monitoring tool that records detailed activity is not installed | TECH: Sysmon is not present — process creation, network connections, and registry changes are not logged'
    attack_scenario = 'SIMPLE: Without Sysmon, attackers can operate on your computer for months without leaving traceable evidence | TECH: Absence of Sysmon eliminates process lineage, DNS query, and network telemetry needed for threat hunting'
    why_fix = 'SIMPLE: Sysmon gives you a detailed security camera feed of everything happening on your computer | TECH: Sysmon is the foundational telemetry source for Windows detection engineering and DFIR'
    fix_steps = 'SIMPLE: Download Sysmon from Microsoft website and install with a config file | TECH: Download from sysinternals.com, install with: sysmon -accepteula -i sysmonconfig.xml'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("SysmonCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))

                service_found  = parts.get("FOUND",  "false").lower() == "true"
                service_name   = parts.get("NAME",   "NONE")
                service_status = parts.get("STATUS", "NONE")
                proc_running   = parts.get("PROC",   "false").lower() == "true"

                system_val = {
                    "service_found":   service_found,
                    "service_name":    None if service_name   == "NONE" else service_name,
                    "service_status":  None if service_status == "NONE" else service_status,
                    "process_running": proc_running,
                }

                # Absence of Sysmon is a finding, not an infrastructure error
                is_running = service_found and service_status == "Running"
                status = CheckStatus.PASS if is_running else CheckStatus.FAIL
            except Exception as exc:
                logger.error("SysmonCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"service_found": True, "service_status": "Running"},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
