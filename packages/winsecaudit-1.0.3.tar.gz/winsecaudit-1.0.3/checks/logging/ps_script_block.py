from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

_PS_SCRIPT = r"""
try {
    $path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging'
    $sbl  = $null
    $ibil = $null

    if (Test-Path $path) {
        $v = Get-ItemProperty -Path $path -Name 'EnableScriptBlockLogging' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $sbl = $v.EnableScriptBlockLogging }
        $v = Get-ItemProperty -Path $path -Name 'EnableScriptBlockInvocationLogging' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $ibil = $v.EnableScriptBlockInvocationLogging }
    }

    $sblOut  = if ($null -eq $sbl)  { 'NULL' } else { "$sbl" }
    $ibilOut = if ($null -eq $ibil) { 'NULL' } else { "$ibil" }

    "SBL:$sblOut|IBIL:$ibilOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class PSScriptBlockLoggingCheck(BaseCheck):
    name = "PowerShell Script Block Logging Enabled"
    category = "Logging & Auditing"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1059.001"
    cis_id = "18.9.95.1"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging"'
        r" /v EnableScriptBlockLogging /t REG_DWORD /d 1 /f"
    )
    remediation_supported = True
    plain_name = 'PowerShell Attack Logging'
    risk_summary = 'SIMPLE: Your computer is not recording what PowerShell commands are run | TECH: PowerShell Script Block Logging is disabled — malicious scripts execute without forensic trail'
    attack_scenario = 'SIMPLE: If a hacker runs commands on your computer, there is no record to detect or investigate it | TECH: PowerShell is the primary post-exploitation tool; without SBL, attack commands are invisible to SIEM'
    why_fix = 'SIMPLE: Logs are how you catch attackers and prove what happened during an incident | TECH: Script Block Logging captures obfuscated and decoded PowerShell, critical for detection engineering'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: reg add HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\PowerShell\\ScriptBlockLogging /v EnableScriptBlockLogging /t REG_DWORD /d 1 /f'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("PSScriptBlockLoggingCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                sbl_raw  = parts.get("SBL",  "NULL")
                ibil_raw = parts.get("IBIL", "NULL")

                sbl  = None if sbl_raw  == "NULL" else int(sbl_raw)
                ibil = None if ibil_raw == "NULL" else int(ibil_raw)

                system_val = {
                    "script_block_logging": sbl,
                    "invocation_logging": ibil,
                }
                status = CheckStatus.PASS if sbl == 1 else CheckStatus.FAIL
            except Exception as exc:
                logger.error("PSScriptBlockLoggingCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"script_block_logging": 1},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
