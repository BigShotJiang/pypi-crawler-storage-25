from __future__ import annotations

import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# ModuleNames is a registry key whose *values* (not subkeys) list the modules
# to log. A wildcard "*" value means all modules are captured.
_PS_SCRIPT = r"""
try {
    $basePath   = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging'
    $namesPath  = "$basePath\ModuleNames"
    $eml  = $null
    $wild = $false

    if (Test-Path $basePath) {
        $v = Get-ItemProperty -Path $basePath -Name 'EnableModuleLogging' -ErrorAction SilentlyContinue
        if ($null -ne $v) { $eml = $v.EnableModuleLogging }
    }

    if (Test-Path $namesPath) {
        $names = Get-ItemProperty -Path $namesPath -ErrorAction SilentlyContinue
        if ($null -ne $names) {
            # PSObject properties include PS built-ins; filter them out
            $vals = $names.PSObject.Properties |
                    Where-Object { $_.Name -notin @('PSPath','PSParentPath','PSChildName','PSProvider','PSDrive') } |
                    Select-Object -ExpandProperty Value
            if ($vals -contains '*') { $wild = $true }
        }
    }

    $emlOut  = if ($null -eq $eml) { 'NULL' } else { "$eml" }
    $wildOut = $wild.ToString().ToLower()

    "EML:$emlOut|WILD:$wildOut"
} catch {
    "ERR:$($_.Exception.Message)"
}
"""


class PSModuleLoggingCheck(BaseCheck):
    name = "PowerShell Module Logging Enabled"
    category = "Logging & Auditing"
    weight = 7
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1059.001"
    cis_id = "18.9.95.2"
    remediation_cmd = (
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ModuleLogging"'
        r" /v EnableModuleLogging /t REG_DWORD /d 1 /f"
    )
    remediation_supported = True
    plain_name = 'PowerShell Module Logging'
    risk_summary = 'SIMPLE: Windows is not logging which PowerShell modules and commands are being used | TECH: Module logging disabled — PowerShell pipeline execution not captured in event logs'
    attack_scenario = 'SIMPLE: Hackers can use PowerShell tools and leave no trace for investigators to find | TECH: Without module logging, attack frameworks like PowerSploit execute without Windows event telemetry'
    why_fix = 'SIMPLE: Logging is how security teams detect attacks in progress or investigate after the fact | TECH: Module logging feeds SIEM with PowerShell telemetry essential for threat hunting'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: Enable-PSModuleLogging via Group Policy or registry at HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\PowerShell\\ModuleLogging'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("PSModuleLoggingCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                parts = dict(item.split(":", 1) for item in raw.split("|"))
                eml_raw  = parts.get("EML",  "NULL")
                wild_raw = parts.get("WILD", "false")

                eml  = None if eml_raw == "NULL" else int(eml_raw)
                wild = wild_raw.lower() == "true"

                system_val = {
                    "module_logging_enabled": eml,
                    "module_names_wildcard": wild,
                }
                status = CheckStatus.PASS if eml == 1 else CheckStatus.FAIL
            except Exception as exc:
                logger.error("PSModuleLoggingCheck parse error: %s — raw=%r", exc, raw)
                error_msg = f"Parse error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"module_logging_enabled": 1},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )
