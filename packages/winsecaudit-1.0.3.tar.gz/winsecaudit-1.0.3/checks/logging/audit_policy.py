from __future__ import annotations

import csv
import io
import logging

from checks.base import BaseCheck, CheckResult, CheckStatus, Severity, run_powershell

logger = logging.getLogger(__name__)

# auditpol /get /category:* /r emits UTF-16 LE CSV on some Windows versions.
# Use Base64 transport (same pattern as _secedit_helper) to avoid pipe encoding
# corruption — ReadAllBytes + ToBase64String in PowerShell, decode in Python.
# Decision: we map both "Logon" and "Logoff" subcategories to the "logon" key
# and use the first match found; "Account Logon" maps to "account_logon".
_PS_SCRIPT = r"""
try {
    $tmp = [System.IO.Path]::GetTempFileName()
    auditpol /get /category:* /r > "$tmp" 2>$null
    if (-not (Test-Path $tmp) -or (Get-Item $tmp).Length -eq 0) {
        'ERR:AUDITPOL_FAILED'
    } else {
        $raw = [System.IO.File]::ReadAllBytes($tmp)
        $b64 = [System.Convert]::ToBase64String($raw)
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
        $b64
    }
} catch {
    "ERR:$($_.Exception.Message)"
}
"""

# Subcategory name fragments we care about (case-insensitive substring match).
# First match in the CSV wins for each slot.
_SUBCATEGORY_MAP = {
    "logon":           ["Logon", "Logoff"],
    "account_logon":   ["Kerberos Authentication Service", "Credential Validation", "Account Logon"],
    "privilege_use":   ["Sensitive Privilege Use", "Privilege Use"],
    "process_creation": ["Process Creation"],
}

_NO_AUDITING = "No Auditing"


class AuditPolicyCheck(BaseCheck):
    name = "Advanced Audit Policy Configured"
    category = "Logging & Auditing"
    weight = 8
    severity = Severity.HIGH
    cve_ids: list[str] = []
    mitre_technique = "T1562.002"
    cis_id = "17.1.1"
    remediation_cmd = (
        'auditpol /set /subcategory:"Logon" /success:enable /failure:enable'
    )
    remediation_supported = False
    plain_name = 'Security Event Logging'
    risk_summary = 'SIMPLE: Important security events like logins and privilege use are not being recorded | TECH: Advanced audit policy subcategories (Account Logon, Privilege Use, Process Creation) not configured'
    attack_scenario = 'SIMPLE: If someone breaks into your computer, there will be no log to show what happened or when | TECH: Without logon/process auditing, attacker activity is invisible to forensic investigation and SIEM detection'
    why_fix = 'SIMPLE: Security logs are the only way to know if you have been attacked and what was accessed | TECH: Audit policy is prerequisite for detection engineering — no logs means no alerts'
    fix_steps = 'SIMPLE: This is fixed automatically — click Yes when prompted | TECH: auditpol /set /subcategory:Logon /success:enable /failure:enable'

    def run(self) -> CheckResult:
        system_val: dict = {}
        error_msg: str | None = None
        status = CheckStatus.ERROR

        try:
            raw = run_powershell(_PS_SCRIPT, timeout=60)
        except (RuntimeError, TimeoutError) as exc:
            logger.error("AuditPolicyCheck failed: %s", exc)
            error_msg = str(exc)
            raw = ""

        if not raw:
            error_msg = error_msg or "PowerShell returned no output."
        elif raw.startswith("ERR:"):
            error_msg = raw[4:]
        else:
            try:
                import base64
                decoded = base64.b64decode(raw.strip())
                # auditpol /r output is UTF-16 LE on most Windows versions
                if decoded[:2] in (b"\xff\xfe", b"\xfe\xff"):
                    content = decoded.decode("utf-16", errors="replace")
                else:
                    content = decoded.decode("utf-8", errors="replace")

                system_val, error_msg, status = self._parse_auditpol(content)
            except Exception as exc:
                logger.error("AuditPolicyCheck decode error: %s", exc)
                error_msg = f"Decode error: {exc}"

        return CheckResult(
            check_name=self.name,
            category=self.category,
            status=status,
            system_value=system_val,
            expected_value={"all_configured": True},
            severity=self.severity,
            weight=self.weight,
            cve_ids=self.cve_ids,
            mitre_technique=self.mitre_technique,
            cis_id=self.cis_id,
            remediation_cmd=self.remediation_cmd,
            remediation_supported=self.remediation_supported,
            error_message=error_msg,
        )

    @staticmethod
    def _parse_auditpol(content: str) -> tuple[dict, str | None, CheckStatus]:
        results = {k: _NO_AUDITING for k in _SUBCATEGORY_MAP}

        try:
            reader = csv.DictReader(io.StringIO(content))
            # Normalise header names: strip whitespace and BOM
            if reader.fieldnames is None:
                return {}, "auditpol CSV had no header row", CheckStatus.ERROR

            fieldnames = [f.strip().lstrip("\ufeff") for f in reader.fieldnames]
            reader.fieldnames = fieldnames

            # Locate the subcategory and inclusion-setting columns
            subcat_col = next(
                (f for f in fieldnames if "subcategory" in f.lower() and "guid" not in f.lower()),
                None,
            )
            setting_col = next(
                (f for f in fieldnames if "inclusion" in f.lower() or "setting" in f.lower()),
                None,
            )

            if not subcat_col or not setting_col:
                return {}, f"Could not find expected columns in auditpol CSV: {fieldnames}", CheckStatus.ERROR

            for row in reader:
                subcategory = (row.get(subcat_col) or "").strip()
                setting     = (row.get(setting_col) or "").strip()
                if not subcategory:
                    continue

                for slot, candidates in _SUBCATEGORY_MAP.items():
                    if results[slot] != _NO_AUDITING:
                        continue  # already filled by a higher-priority candidate
                    for candidate in candidates:
                        if candidate.lower() in subcategory.lower():
                            results[slot] = setting
                            break

        except Exception as exc:
            return {}, f"CSV parse error: {exc}", CheckStatus.ERROR

        all_configured = all(v != _NO_AUDITING for v in results.values())
        results["all_configured"] = all_configured
        status = CheckStatus.PASS if all_configured else CheckStatus.FAIL
        return results, None, status
