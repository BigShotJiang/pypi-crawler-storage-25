"""
exporters/docx_export.py — Word DOCX report generator for WinSecAudit v2.

Uses python-docx public API only — no raw XML manipulation.
Built-in Word styles (Heading 1/2/3, Normal, Table Grid) are used throughout
so the document inherits the user's Normal.dotx template and looks correctly
styled in any Word version.

Cell background color for status rows is intentionally omitted: python-docx
exposes it only via XML (CT_Shd elements), which violates the no-raw-XML
constraint. FAIL rows instead use bold + italic text, which is unambiguous and
works in every Word version including LibreOffice.
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}


def _parse_ts(ts: str) -> str:
    """Format ISO timestamp → 'YYYY-MM-DD HH:MM UTC'."""
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M UTC")
    except Exception:
        return ts


def _fmt(value: Any, max_len: int = 200) -> str:
    """Flatten any Python value to a display string, truncated."""
    if value is None:
        return "—"
    if isinstance(value, (dict, list)):
        s = json.dumps(value, default=str)
    else:
        s = str(value)
    return (s[:max_len] + "…") if len(s) > max_len else s


def _cve_str(cve_ids: Any) -> str:
    if isinstance(cve_ids, (list, tuple)):
        return ", ".join(cve_ids) if cve_ids else "None"
    if isinstance(cve_ids, str):
        try:
            parsed = json.loads(cve_ids)
            return ", ".join(parsed) if parsed else "None"
        except Exception:
            pass
    return str(cve_ids) if cve_ids else "None"


def _category_stats(results: list[dict]) -> list[dict]:
    """Compute per-category counts and weighted score, sorted by score ascending."""
    cat: dict = defaultdict(lambda: {"total": 0, "passed": 0, "failed": 0, "earned": 0, "max_w": 0})
    for r in results:
        c      = r.get("category", "Unknown") or "Unknown"
        status = r.get("status", "") or ""
        weight = r.get("weight", 1) or 1
        cat[c]["total"] += 1
        if status == "SKIPPED":
            continue
        cat[c]["max_w"] += weight
        if status == "PASS":
            cat[c]["passed"] += 1
            cat[c]["earned"] += weight
        elif status == "FAIL":
            cat[c]["failed"] += 1

    rows = []
    for name, d in cat.items():
        score = round(d["earned"] / d["max_w"] * 100, 1) if d["max_w"] > 0 else 100.0
        rows.append({"category": name, "total": d["total"],
                     "passed": d["passed"], "failed": d["failed"], "score": score})
    rows.sort(key=lambda x: x["score"])
    return rows


def _add_table_row(table, cells: list[str], bold: bool = False, italic: bool = False) -> None:
    """Append a row to *table* with one cell per item in *cells*."""
    row = table.add_row()
    for i, text in enumerate(cells):
        cell = row.cells[i]
        cell.text = ""
        run = cell.paragraphs[0].add_run(str(text))
        run.bold  = bold
        run.italic = italic


def _add_header_row(table, headers: list[str]) -> None:
    """Write the header row using the first (already existing) row of *table*."""
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr_cells[i].text = ""
        run = hdr_cells[i].paragraphs[0].add_run(h)
        run.bold = True


def _code_paragraph(doc: Document, text: str) -> None:
    """Add a paragraph using Courier New (code style) to *doc*."""
    p   = doc.add_paragraph()
    run = p.add_run(text)
    run.font.name = "Courier New"
    run.font.size = Pt(9)


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _build_title_page(doc: Document, scan: dict) -> None:
    machine_id = scan.get("machine_id", "Unknown")
    ts         = _parse_ts(scan.get("timestamp", ""))
    profile    = scan.get("profile",   "basic")

    title = doc.add_heading("WinSecAudit Security Assessment Report", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_paragraph()  # blank spacer

    for label, value in [
        ("Machine",       machine_id),
        ("Date",          ts),
        ("Profile Used",  profile),
    ]:
        p = doc.add_paragraph(style="Normal")
        run_label = p.add_run(f"{label}: ")
        run_label.bold = True
        p.add_run(value)

    doc.add_page_break()


def _build_executive_summary(doc: Document, scan: dict) -> None:
    machine_id = scan.get("machine_id",    "Unknown")
    profile    = scan.get("profile",       "basic")
    total      = scan.get("total_checks",  0)
    passed     = scan.get("passed_checks", 0)
    failed     = scan.get("failed_checks", 0)
    errors     = scan.get("error_checks",  0)
    skipped    = scan.get("skipped_checks", 0)
    duration   = scan.get("duration_seconds", 0.0)
    score      = scan.get("score",         0.0)
    grade      = scan.get("grade",         "F")

    doc.add_heading("Executive Summary", level=2)

    # Narrative paragraph
    summary_text = (
        f"This assessment scanned {total} security controls on {machine_id} "
        f"using the {profile} profile. The machine achieved a score of "
        f"{score}/100 ({grade}), with {passed} controls passing and "
        f"{failed} failing."
    )
    doc.add_paragraph(summary_text, style="Normal")
    doc.add_paragraph()

    # Stats table (2 columns: Metric | Value)
    stats = [
        ("Total Checks",  str(total)),
        ("Passed",        str(passed)),
        ("Failed",        str(failed)),
        ("Errors",        str(errors)),
        ("Skipped",       str(skipped)),
        ("Scan Duration", f"{duration:.1f}s"),
        ("Score",         f"{score}/100"),
        ("Grade",         grade),
    ]
    tbl = doc.add_table(rows=1, cols=2)
    tbl.style = "Table Grid"
    _add_header_row(tbl, ["Metric", "Value"])
    for label, value in stats:
        _add_table_row(tbl, [label, value])

    doc.add_paragraph()


def _build_category_breakdown(doc: Document, results: list[dict]) -> None:
    doc.add_heading("Category Breakdown", level=2)

    cat_rows = _category_stats(results)
    headers  = ["Category", "Total", "Passed", "Failed", "Score %"]

    tbl = doc.add_table(rows=1, cols=5)
    tbl.style = "Table Grid"
    _add_header_row(tbl, headers)

    for c in cat_rows:
        row = tbl.add_row()
        values = [
            c["category"],
            str(c["total"]),
            str(c["passed"]),
            str(c["failed"]),
            f"{c['score']:.1f}%",
        ]
        for i, v in enumerate(values):
            cell = row.cells[i]
            cell.text = ""
            run = cell.paragraphs[0].add_run(v)
            # Bold the Score% cell so it's scannable
            if i == 4:
                run.bold = True

    doc.add_paragraph()


def _build_critical_high_failures(doc: Document, results: list[dict]) -> None:
    failures = [
        r for r in results
        if r.get("status") == "FAIL"
        and r.get("severity") in ("CRITICAL", "HIGH")
    ]
    if not failures:
        return

    failures.sort(key=lambda r: (
        _SEVERITY_ORDER.get(r.get("severity", "LOW"), 99),
        -(r.get("weight") or 0),
    ))

    doc.add_heading("Critical and High Failures", level=2)

    for r in failures:
        check_name = r.get("check_name", "")
        severity   = r.get("severity",   "HIGH")
        category   = r.get("category",   "")
        cis_id     = r.get("cis_id",     "") or "—"
        mitre      = r.get("mitre_technique", "") or "—"
        sys_val    = _fmt(r.get("system_value"))
        exp_val    = _fmt(r.get("expected_value"))
        rem_cmd    = r.get("remediation_cmd", "") or ""
        cve_str    = _cve_str(r.get("cve_ids"))

        doc.add_heading(check_name, level=3)

        # Meta line: severity / category / CIS / ATT&CK
        p = doc.add_paragraph(style="Normal")
        p.add_run(f"Severity: {severity}  |  Category: {category}  |  "
                  f"CIS: {cis_id}  |  ATT&CK: {mitre}")

        # Current vs Expected
        for label, val in [("Current value", sys_val), ("Expected value", exp_val)]:
            p = doc.add_paragraph(style="Normal")
            run_l = p.add_run(f"{label}: ")
            run_l.bold = True
            p.add_run(val)

        # CVE IDs
        p = doc.add_paragraph(style="Normal")
        run_l = p.add_run("CVE IDs: ")
        run_l.bold = True
        p.add_run(cve_str)

        # Remediation command in code style
        if rem_cmd:
            p = doc.add_paragraph(style="Normal")
            run_l = p.add_run("Remediation: ")
            run_l.bold = True
            _code_paragraph(doc, rem_cmd)

        doc.add_paragraph()  # spacing between checks


def _build_appendix(doc: Document, results: list[dict]) -> None:
    doc.add_page_break()
    doc.add_heading("Appendix — All Results", level=2)

    headers = ["Check Name", "Status", "Severity", "Category", "Weight"]
    tbl = doc.add_table(rows=1, cols=5)
    tbl.style = "Table Grid"
    _add_header_row(tbl, headers)

    for r in results:
        status = r.get("status", "")
        is_fail = status == "FAIL"

        values = [
            r.get("check_name", ""),
            status,
            r.get("severity",   ""),
            r.get("category",   ""),
            str(r.get("weight", "")),
        ]
        # FAIL rows: bold + italic (cell background requires XML — omitted per constraint)
        _add_table_row(tbl, values, bold=is_fail, italic=is_fail)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def export_docx(scan: dict, output_path: Path) -> Path:
    """
    Render a Word DOCX report from *scan* (a dict from get_scan()).
    Returns the resolved output path.
    """
    output_path = Path(output_path).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    results = scan.get("results", [])
    doc     = Document()

    _build_title_page(doc, scan)
    _build_executive_summary(doc, scan)
    _build_category_breakdown(doc, results)
    _build_critical_high_failures(doc, results)
    _build_appendix(doc, results)

    doc.save(str(output_path))
    return output_path
