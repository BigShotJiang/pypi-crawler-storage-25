"""
exporters/pdf.py — Professional PDF report generator for WinSecAudit v2.

Uses reportlab platypus only.  No images, no external fonts — Helvetica,
Helvetica-Bold, and Courier are the three built-in fonts used throughout.

Page numbering strategy: _NumberedCanvas defers "Page N of M" by saving each
page's full canvas state after showPage() and replaying it in save() once the
total page count is known.  This is the canonical reportlab two-pass pattern
without actually re-running the layout engine.

Header/footer placement: topMargin=2.5cm leaves 2.5cm of whitespace above the
content frame on all pages.  The navy header bar (1.2cm tall) is drawn in that
space by the onLaterPages callback.  The first page (cover) gets no header bar.
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.colors import Color, HexColor, black, white
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import (
    HRFlowable,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PAGE_W, PAGE_H = A4
MARGIN         = 1.5 * cm
TOP_MARGIN     = 2.5 * cm   # room for the header bar on later pages
BOTTOM_MARGIN  = 1.5 * cm   # room for the page-number footer
CONTENT_W      = PAGE_W - 2 * MARGIN

NAVY      = HexColor("#1E3A5F")
LIGHT_GRAY = HexColor("#F5F5F5")
MID_GRAY   = HexColor("#CCCCCC")
DARK_GRAY  = HexColor("#555555")

_GRADE_COLORS: dict[str, Color] = {
    "A": HexColor("#1B5E20"),   # dark green
    "B": HexColor("#827717"),   # olive
    "C": HexColor("#E65100"),   # orange
    "D": HexColor("#B71C1C"),   # dark red
    "F": HexColor("#880E4F"),   # deep crimson
}

_SEVERITY_COLORS: dict[str, Color] = {
    "CRITICAL": HexColor("#B71C1C"),
    "HIGH":     HexColor("#E53935"),
    "MEDIUM":   HexColor("#F57F17"),
    "LOW":      HexColor("#01579B"),
}

_STATUS_COLORS: dict[str, Color] = {
    "PASS":    HexColor("#2E7D32"),
    "FAIL":    HexColor("#C62828"),
    "ERROR":   HexColor("#F57F17"),
    "SKIPPED": HexColor("#757575"),
}

_SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}


# ---------------------------------------------------------------------------
# Deferred "Page N of M" canvas
# ---------------------------------------------------------------------------

class _NumberedCanvas(Canvas):
    """
    Saves each page's full canvas state after showPage() so that the total
    page count is available when save() is called.  Footer "Page N of M" is
    then drawn on every page during the save pass.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._saved_page_states: list[dict] = []

    def showPage(self) -> None:
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self) -> None:
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_footer(num_pages)
            Canvas.showPage(self)
        Canvas.save(self)

    def _draw_footer(self, page_count: int) -> None:
        self.saveState()
        self.setFont("Helvetica", 8)
        self.setFillColor(DARK_GRAY)
        self.drawRightString(
            PAGE_W - MARGIN,
            0.6 * cm,
            f"Page {self._pageNumber} of {page_count}",
        )
        self.restoreState()


# ---------------------------------------------------------------------------
# Header callbacks
# ---------------------------------------------------------------------------

def _first_page_cb(canvas: Canvas, doc: Any) -> None:
    """Cover page: no header bar, only the footer (handled by _NumberedCanvas)."""
    pass


def _make_later_page_cb(machine_id: str):
    """Return an onLaterPages callback that draws the navy header bar."""

    def _cb(canvas: Canvas, doc: Any) -> None:
        canvas.saveState()
        # Navy bar across the full page width
        canvas.setFillColor(NAVY)
        canvas.rect(0, PAGE_H - 1.2 * cm, PAGE_W, 1.2 * cm, fill=1, stroke=0)
        # White title text in the bar
        canvas.setFillColor(white)
        canvas.setFont("Helvetica-Bold", 10)
        canvas.drawString(
            MARGIN,
            PAGE_H - 0.85 * cm,
            f"WinSecAudit Report  \u2014  {machine_id}",
        )
        canvas.restoreState()

    return _cb


# ---------------------------------------------------------------------------
# Paragraph styles
# ---------------------------------------------------------------------------

def _make_styles() -> dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()

    return {
        "cover_title": ParagraphStyle(
            "CoverTitle",
            fontName="Helvetica-Bold",
            fontSize=28,
            textColor=NAVY,
            alignment=TA_CENTER,
            spaceAfter=12,
        ),
        "cover_sub": ParagraphStyle(
            "CoverSub",
            fontName="Helvetica",
            fontSize=12,
            textColor=DARK_GRAY,
            alignment=TA_CENTER,
            spaceAfter=6,
        ),
        "section_h": ParagraphStyle(
            "SectionH",
            fontName="Helvetica-Bold",
            fontSize=14,
            textColor=NAVY,
            spaceBefore=14,
            spaceAfter=6,
            borderPad=4,
        ),
        "check_name": ParagraphStyle(
            "CheckName",
            fontName="Helvetica-Bold",
            fontSize=11,
            textColor=black,
            spaceBefore=8,
            spaceAfter=2,
        ),
        "body": ParagraphStyle(
            "Body",
            fontName="Helvetica",
            fontSize=9,
            textColor=black,
            spaceAfter=3,
        ),
        "body_small": ParagraphStyle(
            "BodySmall",
            fontName="Helvetica",
            fontSize=8,
            textColor=DARK_GRAY,
            spaceAfter=2,
        ),
        "code": ParagraphStyle(
            "Code",
            fontName="Courier",
            fontSize=8,
            textColor=DARK_GRAY,
            spaceAfter=2,
        ),
        "badge": ParagraphStyle(
            "Badge",
            fontName="Helvetica-Bold",
            fontSize=22,
            textColor=white,
            alignment=TA_CENTER,
            leading=28,
        ),
    }


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _fmt(value: Any, max_len: int = 160) -> str:
    """Convert any value to a display string, truncated to max_len chars."""
    if value is None:
        return "\u2014"
    if isinstance(value, (dict, list)):
        s = json.dumps(value, default=str)
    else:
        s = str(value)
    return (s[:max_len] + "\u2026") if len(s) > max_len else s


def _parse_ts(ts: str) -> str:
    """Format ISO timestamp → 'YYYY-MM-DD HH:MM UTC'."""
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M UTC")
    except Exception:
        return ts


def _category_stats(results: list[dict]) -> list[dict]:
    """Compute per-category counts and weighted score, sorted by score ascending."""
    cat: dict = defaultdict(lambda: {"total": 0, "passed": 0, "failed": 0, "earned": 0, "max_w": 0})
    for r in results:
        c      = r.get("category", "Unknown") or "Unknown"
        status = r.get("status", "") or ""
        weight = r.get("weight", 1) or 1
        cat[c]["total"] += 1
        if status == "SKIPPED":
            continue
        cat[c]["max_w"] += weight
        if status == "PASS":
            cat[c]["passed"]  += 1
            cat[c]["earned"]  += weight
        elif status == "FAIL":
            cat[c]["failed"] += 1

    rows = []
    for name, d in cat.items():
        score = round(d["earned"] / d["max_w"] * 100, 1) if d["max_w"] > 0 else 100.0
        rows.append({
            "category": name,
            "total":    d["total"],
            "passed":   d["passed"],
            "failed":   d["failed"],
            "score":    score,
        })
    rows.sort(key=lambda x: x["score"])   # worst first
    return rows


def _alt_table_style(n_data_rows: int, header_bg: Color = NAVY) -> list:
    """Return base TableStyle commands: header bar + alternating body rows."""
    cmds = [
        ("BACKGROUND",    (0, 0), (-1, 0),  header_bg),
        ("TEXTCOLOR",     (0, 0), (-1, 0),  white),
        ("FONTNAME",      (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0),  9),
        ("FONTNAME",      (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 1), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [white, LIGHT_GRAY]),
        ("GRID",          (0, 0), (-1, -1), 0.4, MID_GRAY),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING",    (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("LEFTPADDING",   (0, 0), (-1, -1), 6),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
        ("WORDWRAP",      (0, 0), (-1, -1), "LTR"),
    ]
    return cmds


# ---------------------------------------------------------------------------
# Section builders
# ---------------------------------------------------------------------------

def _build_cover(scan: dict, styles: dict) -> list:
    machine_id  = scan.get("machine_id",    "Unknown")
    ts          = _parse_ts(scan.get("timestamp", ""))
    profile     = scan.get("profile",       "basic")
    score       = scan.get("score",         0.0)
    grade       = scan.get("grade",         "F")
    passed      = scan.get("passed_checks", 0)
    failed      = scan.get("failed_checks", 0)
    errors      = scan.get("error_checks",  0)
    skipped     = scan.get("skipped_checks", 0)
    total       = scan.get("total_checks",  0)
    duration    = scan.get("duration_seconds", 0.0)

    story = []

    # Title block
    story.append(Spacer(1, 1.5 * cm))
    story.append(Paragraph("WinSecAudit Security Report", styles["cover_title"]))
    story.append(Spacer(1, 0.3 * cm))
    story.append(Paragraph(f"Machine: <b>{machine_id}</b>",    styles["cover_sub"]))
    story.append(Paragraph(f"Scan Date: {ts}",                 styles["cover_sub"]))
    story.append(Paragraph(f"Profile: {profile}",              styles["cover_sub"]))
    story.append(Paragraph("Generated by: WinSecAudit v2.0",   styles["cover_sub"]))
    story.append(Spacer(1, 0.8 * cm))

    # Score badge — centered colored box
    badge_color = _GRADE_COLORS.get(grade, HexColor("#B71C1C"))
    badge_para  = Paragraph(
        f"{score}/100<br/>Grade: {grade}",
        styles["badge"],
    )
    badge_tbl = Table([[badge_para]], colWidths=[6 * cm], rowHeights=[2.4 * cm])
    badge_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0, 0), (-1, -1), badge_color),
        ("ALIGN",         (0, 0), (-1, -1), "CENTER"),
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("ROUNDEDCORNERS", [4]),
    ]))

    # Centre the badge using a 3-column wrapper
    wrapper = Table(
        [["", badge_tbl, ""]],
        colWidths=[(CONTENT_W - 6 * cm) / 2, 6 * cm, (CONTENT_W - 6 * cm) / 2],
    )
    wrapper.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
    story.append(wrapper)
    story.append(Spacer(1, 0.6 * cm))

    # Executive summary stats table
    stats_data = [
        ["Metric",         "Value"],
        ["Total Checks",   str(total)],
        ["Passed",         str(passed)],
        ["Failed",         str(failed)],
        ["Errors",         str(errors)],
        ["Skipped",        str(skipped)],
        ["Scan Duration",  f"{duration:.1f}s"],
    ]
    col_w = [CONTENT_W * 0.55, CONTENT_W * 0.45]
    stats_tbl = Table(stats_data, colWidths=col_w)

    n = len(stats_data)
    tbl_style = _alt_table_style(n - 1)
    # Color Passed row green, Failed row red
    for i, row in enumerate(stats_data):
        if row[0] == "Passed":
            tbl_style.append(("TEXTCOLOR", (1, i), (1, i), _STATUS_COLORS["PASS"]))
            tbl_style.append(("FONTNAME",  (1, i), (1, i), "Helvetica-Bold"))
        elif row[0] == "Failed":
            tbl_style.append(("TEXTCOLOR", (1, i), (1, i), _STATUS_COLORS["FAIL"]))
            tbl_style.append(("FONTNAME",  (1, i), (1, i), "Helvetica-Bold"))

    stats_tbl.setStyle(TableStyle(tbl_style))
    story.append(stats_tbl)

    return story


def _build_category_section(results: list[dict], styles: dict) -> list:
    story: list = []
    story.append(PageBreak())
    story.append(Paragraph("Category Breakdown", styles["section_h"]))
    story.append(Spacer(1, 0.2 * cm))

    cat_rows = _category_stats(results)
    header   = ["Category", "Checks", "Passed", "Failed", "Score %"]
    tbl_data = [header] + [
        [c["category"], c["total"], c["passed"], c["failed"], f"{c['score']:.1f}%"]
        for c in cat_rows
    ]
    col_w = [
        CONTENT_W * 0.38,
        CONTENT_W * 0.13,
        CONTENT_W * 0.13,
        CONTENT_W * 0.13,
        CONTENT_W * 0.23,
    ]
    tbl = Table(tbl_data, colWidths=col_w)
    tbl_style = _alt_table_style(len(cat_rows))
    # Color Score% cells based on value
    for i, c in enumerate(cat_rows, start=1):
        sc = c["score"]
        col = (
            _STATUS_COLORS["PASS"]  if sc >= 75 else
            HexColor("#F57F17")     if sc >= 50 else
            _STATUS_COLORS["FAIL"]
        )
        tbl_style.append(("TEXTCOLOR", (4, i), (4, i), col))
        tbl_style.append(("FONTNAME",  (4, i), (4, i), "Helvetica-Bold"))

    tbl.setStyle(TableStyle(tbl_style))
    story.append(tbl)
    return story


def _build_failures_section(results: list[dict], styles: dict) -> list:
    failures = [r for r in results if r.get("status") == "FAIL"]
    if not failures:
        return []

    failures.sort(key=lambda r: (
        _SEVERITY_ORDER.get(r.get("severity", "LOW"), 99),
        -(r.get("weight") or 0),
    ))

    story: list = []
    story.append(PageBreak())
    story.append(Paragraph("Security Failures", styles["section_h"]))

    for idx, r in enumerate(failures):
        check_name  = r.get("check_name", "")
        severity    = r.get("severity",   "LOW")
        category    = r.get("category",   "")
        cis_id      = r.get("cis_id",     "") or ""
        mitre       = r.get("mitre_technique", "") or ""
        sys_val     = _fmt(r.get("system_value"))
        exp_val     = _fmt(r.get("expected_value"))
        rem_cmd     = r.get("remediation_cmd", "") or ""
        cve_ids     = r.get("cve_ids")
        if isinstance(cve_ids, list):
            cve_str = ", ".join(cve_ids) if cve_ids else "None"
        else:
            cve_str = str(cve_ids) if cve_ids else "None"

        story.append(Spacer(1, 0.15 * cm))
        story.append(Paragraph(check_name, styles["check_name"]))

        # Severity badge row
        sev_color = _SEVERITY_COLORS.get(severity, black)
        meta_data  = [[
            Paragraph(f"<b>{severity}</b>", ParagraphStyle(
                "Sev", fontName="Helvetica-Bold", fontSize=8, textColor=white
            )),
            Paragraph(f"Category: {category}", styles["body_small"]),
            Paragraph(f"CIS: {cis_id or '—'}", styles["body_small"]),
            Paragraph(f"ATT&CK: {mitre or '—'}", styles["body_small"]),
        ]]
        meta_col_w = [2.5*cm, CONTENT_W*0.33, CONTENT_W*0.22, CONTENT_W*0.28]
        meta_tbl = Table(meta_data, colWidths=meta_col_w, rowHeights=[0.5*cm])
        meta_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (0, 0),  sev_color),
            ("ALIGN",         (0, 0), (0, 0),  "CENTER"),
            ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING",    (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ("LEFTPADDING",   (0, 0), (-1, -1), 4),
        ]))
        story.append(meta_tbl)
        story.append(Spacer(1, 0.1 * cm))

        # Key-value details
        kv_data = [
            [Paragraph("<b>Current Value:</b>",  styles["body_small"]),
             Paragraph(sys_val,                  styles["body_small"])],
            [Paragraph("<b>Expected Value:</b>", styles["body_small"]),
             Paragraph(exp_val,                  styles["body_small"])],
            [Paragraph("<b>CVE IDs:</b>",        styles["body_small"]),
             Paragraph(cve_str,                  styles["body_small"])],
        ]
        if rem_cmd:
            kv_data.append([
                Paragraph("<b>Remediation:</b>", styles["body_small"]),
                Paragraph(rem_cmd,               styles["code"]),
            ])
        kv_tbl = Table(kv_data, colWidths=[3.0*cm, CONTENT_W - 3.0*cm])
        kv_tbl.setStyle(TableStyle([
            ("VALIGN",        (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING",    (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ("LEFTPADDING",   (0, 0), (0, -1),  0),
            ("LEFTPADDING",   (1, 0), (1, -1),  6),
        ]))
        story.append(kv_tbl)

        if idx < len(failures) - 1:
            story.append(Spacer(1, 0.15 * cm))
            story.append(HRFlowable(width="100%", thickness=0.4, color=MID_GRAY))

    return story


def _build_appendix(results: list[dict], styles: dict) -> list:
    story: list = []
    story.append(PageBreak())
    story.append(Paragraph("Appendix — All Results", styles["section_h"]))
    story.append(Spacer(1, 0.2 * cm))

    header   = ["Check Name", "Category", "Status", "Severity", "Weight"]
    tbl_data = [header]
    for r in results:
        tbl_data.append([
            r.get("check_name", ""),
            r.get("category",   ""),
            r.get("status",     ""),
            r.get("severity",   ""),
            str(r.get("weight", "")),
        ])

    col_w = [
        CONTENT_W * 0.34,
        CONTENT_W * 0.22,
        CONTENT_W * 0.13,
        CONTENT_W * 0.13,
        CONTENT_W * 0.10,
    ]
    tbl = Table(tbl_data, colWidths=col_w, repeatRows=1)
    tbl_style = _alt_table_style(len(results))

    # Color-code Status and Severity text cells per row
    for i, r in enumerate(results, start=1):
        status_col = _STATUS_COLORS.get(r.get("status", ""), DARK_GRAY)
        sev_col    = _SEVERITY_COLORS.get(r.get("severity", ""), black)
        tbl_style.extend([
            ("TEXTCOLOR", (2, i), (2, i), status_col),
            ("FONTNAME",  (2, i), (2, i), "Helvetica-Bold"),
            ("TEXTCOLOR", (3, i), (3, i), sev_col),
            ("FONTNAME",  (3, i), (3, i), "Helvetica-Bold"),
        ])

    tbl.setStyle(TableStyle(tbl_style))
    story.append(tbl)
    return story


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def export_pdf(scan: dict, output_path: Path) -> Path:
    """
    Render a professional PDF report from *scan* (a dict from get_scan()).
    Returns the resolved output path.
    """
    output_path = Path(output_path).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    machine_id = scan.get("machine_id", "Unknown")
    results    = scan.get("results", [])
    styles     = _make_styles()

    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        rightMargin=MARGIN,
        leftMargin=MARGIN,
        topMargin=TOP_MARGIN,
        bottomMargin=BOTTOM_MARGIN,
        title=f"WinSecAudit Report — {machine_id}",
        author="WinSecAudit v2.0",
    )

    story: list = []
    story.extend(_build_cover(scan, styles))
    story.extend(_build_category_section(results, styles))
    story.extend(_build_failures_section(results, styles))
    story.extend(_build_appendix(results, styles))

    later_cb = _make_later_page_cb(machine_id)
    doc.build(
        story,
        onFirstPage=_first_page_cb,
        onLaterPages=later_cb,
        canvasmaker=_NumberedCanvas,
    )

    return output_path
