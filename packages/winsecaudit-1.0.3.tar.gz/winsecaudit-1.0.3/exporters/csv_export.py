"""
exporters/csv_export.py — Flat CSV export for WinSecAudit scan results.

Encoding: utf-8-sig (UTF-8 with BOM) so Excel auto-detects UTF-8 without a
manual import wizard step — critical for compliance officers who double-click
the file. newline='' on open() per the csv module docs to prevent the module's
own \r\n line terminator from being doubled by Python's text-mode translation
on Windows.

SIEM-friendly design: scan-level fields (machine_id, grade, etc.) are
denormalized onto every result row so each row is independently queryable in
Splunk / ELK without a JOIN.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

_COLUMNS = [
    "check_name", "category", "status", "severity", "weight",
    "system_value", "expected_value", "cve_ids",
    "mitre_technique", "cis_id", "remediation_cmd",
    "remediation_supported", "error_message",
    "scan_id", "machine_id", "scan_timestamp", "profile", "score", "grade",
]


def _to_str(value: object) -> str:
    """Flatten any Python value to a CSV-safe string."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, default=str)


def export_csv(scan: dict, output_path: Path) -> Path:
    """
    Write every result from *scan* to a UTF-8-BOM CSV at *output_path*.

    Scan-level fields are repeated on every row so the file is usable as a
    standalone flat table in SIEM tools.  Complex values (system_value,
    expected_value, cve_ids) are JSON-serialised to strings.

    Returns the resolved output path.
    """
    output_path = Path(output_path).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    scan_fields = {
        "scan_id":        scan.get("id", ""),
        "machine_id":     scan.get("machine_id", ""),
        "scan_timestamp": scan.get("timestamp", ""),
        "profile":        scan.get("profile", ""),
        "score":          scan.get("score", ""),
        "grade":          scan.get("grade", ""),
    }

    results = scan.get("results", [])

    with output_path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for r in results:
            row: dict = dict(r)
            # Flatten values that _deserialize_result() restored to Python objects
            for key in ("system_value", "expected_value", "cve_ids"):
                row[key] = _to_str(row.get(key))
            row.update(scan_fields)
            writer.writerow(row)

    return output_path
