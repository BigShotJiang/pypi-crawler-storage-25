"""
Runtime-data path resolver for WinSecAudit v2.

Auto-detects whether the package is being run from the source tree
(development) or from a pip-installed location (production), and
chooses the correct directories for:

  - the read-only YAML profiles (`PROFILES_DIR`)
  - the writable SQLite database, CVE / KEV caches (`DATA_DIR`)
  - generated PDF / DOCX / CSV reports (`OUTPUT_DIR`)

When running from source, paths land alongside the repo (data/, output/).
When pip-installed, writable paths land under the per-user data dir
(`~/.winsecaudit/` on POSIX, `%LOCALAPPDATA%/WinSecAudit/` on Windows).

This single module is imported by db/database.py, engine/threat_intel.py,
dashboard/app.py, and cli/main.py so that path logic stays in one place.
"""
from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Detect dev-vs-installed mode
# ---------------------------------------------------------------------------

_THIS_FILE   = Path(__file__).resolve()
_PARENT      = _THIS_FILE.parent
_HAS_REPO    = (_PARENT / "checks").is_dir() and (_PARENT / "winsecaudit.py").is_file()

# When running from a checked-out repo, prefer repo-relative paths (so smoke
# tests, dev-loop, and existing scripts keep working as before).
DEV_MODE: bool = _HAS_REPO


# ---------------------------------------------------------------------------
# Read-only assets (always shipped with the package)
# ---------------------------------------------------------------------------

CHECKS_DIR:   Path = _PARENT / "checks"
PROFILES_DIR: Path = _PARENT / "profiles"


# ---------------------------------------------------------------------------
# Writable directories
# ---------------------------------------------------------------------------

def _user_data_dir() -> Path:
    """Return a per-user, OS-appropriate data directory."""
    # Honour explicit override first
    env = os.environ.get("WINSECAUDIT_DATA_DIR")
    if env:
        return Path(env).expanduser().resolve()

    if os.name == "nt":   # Windows
        local = os.environ.get("LOCALAPPDATA")
        if local:
            return Path(local) / "WinSecAudit"
        return Path.home() / "AppData" / "Local" / "WinSecAudit"

    # POSIX
    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        return Path(xdg) / "winsecaudit"
    return Path.home() / ".local" / "share" / "winsecaudit"


if DEV_MODE:
    DATA_DIR:   Path = _PARENT / "data"
    OUTPUT_DIR: Path = _PARENT / "output"
else:
    DATA_DIR   = _user_data_dir()
    OUTPUT_DIR = DATA_DIR / "output"

# Make sure they exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Concrete file paths
# ---------------------------------------------------------------------------

DB_PATH:        Path = DATA_DIR / "winsecaudit.db"
CVE_CACHE_PATH: Path = DATA_DIR / "cve_map.json"
KEV_CACHE_PATH: Path = DATA_DIR / "cisa_kev_cache.json"


__all__ = [
    "DEV_MODE",
    "CHECKS_DIR",
    "PROFILES_DIR",
    "DATA_DIR",
    "OUTPUT_DIR",
    "DB_PATH",
    "CVE_CACHE_PATH",
    "KEV_CACHE_PATH",
]
