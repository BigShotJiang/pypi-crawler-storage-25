# Changelog

All notable changes to WinSecAudit are documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [2.0.0] — 2026-04-19

### Added

- **Plugin architecture** — `BaseCheck` abstract class with `CheckRegistry.discover()` for zero-config check auto-discovery via `pkgutil.walk_packages`.
- **35+ security checks** across 8 categories: Authentication, Credentials, Access Control, Network, Services, Kernel, System, and Logging.
- **Weighted scoring engine** — PASS earns weight; FAIL/ERROR earn 0; SKIPPED excluded from both numerator and denominator. All-SKIPPED edge case returns 100.0.
- **Risk grading** — A/B/C/D/F bands at 90/75/60/40/0 thresholds.
- **SQLAlchemy Core DB layer** — WAL mode, FK enforcement, machines/scans/results schema, drift detection via FULL OUTER JOIN emulation.
- **Profile system** — YAML profiles (`basic`, `hardened`) with `relaxed_checks` and `weight_overrides` keys; relaxed FAIL checks flip to PASS without penalty.
- **CLI (Typer + Rich)** — five commands: `scan`, `report`, `list`, `drift`, `remediate`; progress bar via `scan_progress_context()`; UTF-8 stdout wrapper for Windows console compatibility.
- **Exporters** — PDF (reportlab, "Page N of M" via `_NumberedCanvas`), DOCX (python-docx, public API only), CSV (utf-8-sig BOM for Excel/SIEM).
- **Threat intelligence pipeline** — NVD CVSS v3.1/v3.0/v2, FIRST EPSS, CISA KEV; per-CVE cache with 7-day TTL; CISA KEV bulk cache with 24-hour TTL; NVD rate gate at 5 req/s.
- **Smoke test suite** — `tests/smoke_test.py`, 10 tests, no pytest dependency; exits 0 on success.

### Changed

- PowerShell output now transported as Base64 UTF-16 LE to avoid console encoding issues on narrow codepage terminals.
- `engine/test_pipeline.py` replaced all Unicode box-drawing characters with ASCII equivalents for cp1252 compatibility.

### Fixed

- `Console(legacy_windows=False)` prevents Rich from using the Win32 `WriteConsole` API, which is bound to cp1252.
- `os.replace()` atomic write prevents partial cache corruption on power loss or process kill.
- Frozen `CheckResult` dataclass coerces `list → tuple` in `__post_init__` to satisfy the immutability invariant.
