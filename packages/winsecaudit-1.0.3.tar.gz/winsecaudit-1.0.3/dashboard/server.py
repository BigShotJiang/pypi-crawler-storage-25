"""
dashboard/server.py — uvicorn launcher for the WinSecAudit dashboard API.

Called by the `winsecaudit dashboard` CLI command.
The browser timer fires 1.5 s after this function is called so uvicorn has
time to bind the port before the browser opens.
"""
from __future__ import annotations


def launch(
    host: str = "127.0.0.1",
    port: int = 8080,
    open_browser: bool = False,
) -> None:
    from db.database import init_db
    init_db()

    if open_browser:
        import threading
        import webbrowser
        threading.Timer(
            1.5,
            lambda: webbrowser.open(f"http://{host}:{port}"),
        ).start()

    import uvicorn
    uvicorn.run(
        "dashboard.app:app",
        host=host,
        port=port,
        reload=False,
        log_level="warning",
    )
