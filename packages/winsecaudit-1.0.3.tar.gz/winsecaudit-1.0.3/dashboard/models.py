"""
dashboard/models.py — Pydantic response models for the WinSecAudit dashboard API.

All models use Pydantic v2 semantics.  Field types match the DB layer's output
after deserialization:
  - system_value / expected_value are str (JSON-encoded by app.py helpers before
    Pydantic sees them; DB returns raw Python objects after _deserialize_result).
  - cve_ids is list[str] (DB returns a Python list after _deserialize_result).
  - remediation_supported is bool (_deserialize_result already converts int→bool).
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class CVEDetail(BaseModel):
    cve_id: str
    cvss_score: float | None
    epss_score: float | None
    in_cisa_kev: bool
    kev_ransomware_use: str | None


class CheckResultRow(BaseModel):
    check_name: str
    category: str
    status: str            # "PASS" / "FAIL" / "ERROR" / "SKIPPED"
    severity: str          # "CRITICAL" / "HIGH" / "MEDIUM" / "LOW"
    weight: int
    system_value: str      # JSON-encoded string (coerced in app.py)
    expected_value: str    # JSON-encoded string (coerced in app.py)
    cve_ids: list[str]
    mitre_technique: str
    cis_id: str
    remediation_cmd: str
    remediation_supported: bool
    error_message: str | None


class ScanSummary(BaseModel):
    id: str
    machine_id: str
    timestamp: str
    profile: str
    score: float
    grade: str
    total_checks: int
    passed_checks: int
    failed_checks: int
    error_checks: int
    skipped_checks: int
    duration_seconds: float


class ScanDetail(ScanSummary):
    results: list[CheckResultRow]


class CategoryScore(BaseModel):
    category: str
    total: int
    passed: int
    failed: int
    score_pct: float


class DriftReport(BaseModel):
    scan_a: str
    scan_b: str
    score_delta: float
    regressions: list[dict]
    improvements: list[dict]
    stable_pass: int
    stable_fail: int
    new_checks: list[str]
    removed_checks: list[str]


class DashboardOverview(BaseModel):
    latest_scan: ScanSummary | None
    total_scans: int
    score_trend: list[dict]           # [{id, timestamp, score, grade}]
    category_scores: list[CategoryScore]
    critical_failures: list[CheckResultRow]
    high_failures: list[CheckResultRow]
    cisa_kev_count: int
    top_cves: list[CVEDetail]         # top 5 by epss_score DESC


class RemediationItem(BaseModel):
    check_name: str
    category: str
    severity: str
    remediation_cmd: str
    cve_ids: list[str]
