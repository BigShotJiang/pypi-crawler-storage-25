"""
dashboard/app.py — FastAPI application for the WinSecAudit read-only dashboard.

Design decisions:
  - All DB access goes through db/database.py public functions only — no raw SQL here.
  - cve_map.json is read directly for TI data (threat_intel.py owns the file format
    and this module is the authoritative consumer for the dashboard read path).
  - system_value / expected_value are stored as JSON strings in SQLite and deserialized
    to Python objects by _deserialize_result(); _to_str() re-encodes them as JSON
    strings to satisfy CheckResultRow's str type contract.
  - StaticFiles is mounted LAST so /api/* routes always win over the catch-all.
  - init_db() is called in the lifespan context so the engine is ready before the
    first request, and the TestClient path (which never triggers lifespan startup
    unless explicitly enabled) uses the already-initialized engine from the caller.
  - CORS is restricted to localhost:8080 / 127.0.0.1:8080 — this is a local-only tool
    and there is no authentication layer.
"""
from __future__ import annotations

import json
import logging
from collections import defaultdict
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from dashboard.models import (
    CategoryScore,
    CheckResultRow,
    CVEDetail,
    DashboardOverview,
    DriftReport,
    RemediationItem,
    ScanDetail,
    ScanSummary,
)

logger = logging.getLogger(__name__)

# Path resolution — delegated to runtime_paths so the dashboard works in
# both source-tree and pip-installed modes.
from winsecaudit_paths import CVE_CACHE_PATH as _CVE_CACHE_PATH

_PROJECT_ROOT  = Path(__file__).resolve().parent.parent
_STATIC_DIR    = Path(__file__).resolve().parent / "static"

# Severity ordering used for sorting remediation results
_SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}


# ---------------------------------------------------------------------------
# Lifespan — ensures DB is ready before any request
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    from db.database import init_db
    init_db()
    yield


# ---------------------------------------------------------------------------
# App + CORS
# ---------------------------------------------------------------------------

app = FastAPI(
    title="WinSecAudit",
    description="Read-only REST API for the WinSecAudit security dashboard.",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8080", "http://127.0.0.1:8080"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Internal helpers — coercion, normalization
# ---------------------------------------------------------------------------

def _to_str(value: Any) -> str:
    """Convert any DB-deserialized value to a JSON string for the API response."""
    if value is None:
        return "null"
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str)
    except Exception:
        return str(value)


def _coerce_cve_ids(raw: Any) -> list[str]:
    """Normalize cve_ids from DB (list, JSON string, or None) → list[str]."""
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return [str(c) for c in raw if c]
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                return [str(c) for c in parsed if c]
        except Exception:
            pass
    return []


def _result_to_row(r: dict) -> CheckResultRow:
    """Convert a DB result dict to a CheckResultRow Pydantic model."""
    return CheckResultRow(
        check_name            = r.get("check_name", "") or "",
        category              = r.get("category", "") or "",
        status                = r.get("status", "") or "",
        severity              = r.get("severity", "") or "",
        weight                = int(r.get("weight") or 0),
        system_value          = _to_str(r.get("system_value")),
        expected_value        = _to_str(r.get("expected_value")),
        cve_ids               = _coerce_cve_ids(r.get("cve_ids")),
        mitre_technique       = r.get("mitre_technique", "") or "",
        cis_id                = r.get("cis_id", "") or "",
        remediation_cmd       = r.get("remediation_cmd", "") or "",
        remediation_supported = bool(r.get("remediation_supported", False)),
        error_message         = r.get("error_message") or None,
    )


def _scan_to_summary(s: dict) -> ScanSummary:
    """Convert a DB scan dict (no results) to a ScanSummary Pydantic model."""
    return ScanSummary(
        id               = s.get("id", ""),
        machine_id       = s.get("machine_id", ""),
        timestamp        = s.get("timestamp", ""),
        profile          = s.get("profile", "") or "",
        score            = float(s.get("score") or 0.0),
        grade            = s.get("grade", "") or "",
        total_checks     = int(s.get("total_checks") or 0),
        passed_checks    = int(s.get("passed_checks") or 0),
        failed_checks    = int(s.get("failed_checks") or 0),
        error_checks     = int(s.get("error_checks") or 0),
        skipped_checks   = int(s.get("skipped_checks") or 0),
        duration_seconds = float(s.get("duration_seconds") or 0.0),
    )


def _compute_category_scores(results: list[dict]) -> list[CategoryScore]:
    """Compute per-category pass/fail/total/score_pct from a list of result dicts."""
    cat: dict[str, dict] = defaultdict(lambda: {"total": 0, "passed": 0, "failed": 0, "earned": 0, "max_w": 0})
    for r in results:
        c      = r.get("category", "Unknown") or "Unknown"
        status = r.get("status", "") or ""
        weight = int(r.get("weight") or 1)
        cat[c]["total"] += 1
        if status == "SKIPPED":
            continue
        cat[c]["max_w"] += weight
        if status == "PASS":
            cat[c]["passed"]  += 1
            cat[c]["earned"]  += weight
        elif status == "FAIL":
            cat[c]["failed"] += 1

    rows: list[CategoryScore] = []
    for name, d in cat.items():
        score_pct = round(d["earned"] / d["max_w"] * 100, 1) if d["max_w"] > 0 else 100.0
        rows.append(CategoryScore(
            category  = name,
            total     = d["total"],
            passed    = d["passed"],
            failed    = d["failed"],
            score_pct = score_pct,
        ))
    rows.sort(key=lambda x: x.score_pct)
    return rows


def _load_cve_cache() -> dict:
    """Read cve_map.json; return {} on any error. Only dict-valued entries are TI data."""
    try:
        text = _CVE_CACHE_PATH.read_text(encoding="utf-8")
        raw  = json.loads(text)
        # Filter to TI enrichment dicts only (legacy string entries are excluded)
        return {k: v for k, v in raw.items() if isinstance(v, dict)}
    except Exception as exc:
        logger.debug("CVE cache read failed: %s", exc)
        return {}


def _build_cve_detail(entry: dict) -> CVEDetail:
    return CVEDetail(
        cve_id             = entry.get("cve_id", ""),
        cvss_score         = entry.get("cvss_score"),
        epss_score         = entry.get("epss_score"),
        in_cisa_kev        = bool(entry.get("in_cisa_kev", False)),
        kev_ransomware_use = entry.get("kev_ransomware_use") or None,
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/api/v1/overview", response_model=DashboardOverview)
def overview() -> DashboardOverview:
    """Aggregate dashboard overview: latest scan, score trend, category scores, top CVEs."""
    try:
        from db.database import get_latest_scan, list_scans

        latest_raw = get_latest_scan()
        scans_raw  = list_scans(limit=10)

        latest_summary: ScanSummary | None = None
        category_scores: list[CategoryScore] = []
        critical_failures: list[CheckResultRow] = []
        high_failures: list[CheckResultRow] = []
        cisa_kev_count = 0
        top_cves: list[CVEDetail] = []

        # Score trend — lightweight summary rows (no results)
        score_trend = [
            {
                "id":        s.get("id", ""),
                "timestamp": s.get("timestamp", ""),
                "score":     float(s.get("score") or 0.0),
                "grade":     s.get("grade", ""),
            }
            for s in scans_raw
        ]

        if latest_raw:
            latest_summary = _scan_to_summary(latest_raw)
            results        = latest_raw.get("results", [])

            category_scores = _compute_category_scores(results)

            # Collect CVE IDs from FAIL results for KEV counting
            failed_cve_ids: set[str] = set()
            for r in results:
                status = r.get("status", "")
                if status == "FAIL":
                    cid_list = _coerce_cve_ids(r.get("cve_ids"))
                    failed_cve_ids.update(cid_list)

            # Build critical / high failure lists (sorted: severity then weight DESC)
            fail_results = [r for r in results if r.get("status") == "FAIL"]
            fail_results.sort(key=lambda r: (
                _SEVERITY_ORDER.get(r.get("severity", "LOW"), 99),
                -(int(r.get("weight") or 0)),
            ))
            for r in fail_results:
                sev = r.get("severity", "")
                row = _result_to_row(r)
                if sev == "CRITICAL":
                    critical_failures.append(row)
                elif sev == "HIGH":
                    high_failures.append(row)

            # CVE cache — KEV count restricted to CVEs from failing checks
            cve_cache = _load_cve_cache()
            cisa_kev_count = sum(
                1 for cid, entry in cve_cache.items()
                if cid in failed_cve_ids and entry.get("in_cisa_kev")
            )

            # Top 5 CVEs by EPSS score across all cache entries
            ti_entries = list(cve_cache.values())
            ti_entries.sort(key=lambda e: float(e.get("epss_score") or 0.0), reverse=True)
            top_cves = [_build_cve_detail(e) for e in ti_entries[:5]]

        return DashboardOverview(
            latest_scan       = latest_summary,
            total_scans       = len(scans_raw),
            score_trend       = score_trend,
            category_scores   = category_scores,
            critical_failures = critical_failures,
            high_failures     = high_failures,
            cisa_kev_count    = cisa_kev_count,
            top_cves          = top_cves,
        )

    except Exception as exc:
        logger.exception("overview() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/scans", response_model=list[ScanSummary])
def scans_list(
    limit:      int         = Query(20, ge=1, le=500, description="Max results"),
    machine_id: str | None  = Query(None, description="Filter by machine hostname"),
) -> list[ScanSummary]:
    """List saved scans ordered by timestamp DESC."""
    try:
        from db.database import list_scans
        rows = list_scans(machine_id=machine_id, limit=limit)
        return [_scan_to_summary(r) for r in rows]
    except Exception as exc:
        logger.exception("scans_list() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/scans/{scan_id}", response_model=ScanDetail)
def scan_detail(scan_id: str) -> ScanDetail:
    """Return a single scan with all result rows."""
    try:
        from db.database import get_scan
        raw = get_scan(scan_id)
        if raw is None:
            raise HTTPException(status_code=404, detail={"error": "Not found"})

        return ScanDetail(
            **_scan_to_summary(raw).model_dump(),
            results=[_result_to_row(r) for r in raw.get("results", [])],
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("scan_detail(%s) failed", scan_id)
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/scans/{scan_id}/categories", response_model=list[CategoryScore])
def scan_categories(scan_id: str) -> list[CategoryScore]:
    """Per-category pass/fail breakdown for a specific scan."""
    try:
        from db.database import get_scan
        raw = get_scan(scan_id)
        if raw is None:
            raise HTTPException(status_code=404, detail={"error": "Not found"})
        return _compute_category_scores(raw.get("results", []))
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("scan_categories(%s) failed", scan_id)
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/drift", response_model=DriftReport)
def drift(
    scan_a: str | None = Query(None, description="Older scan ID"),
    scan_b: str | None = Query(None, description="Newer scan ID"),
) -> DriftReport:
    """
    Compare two scans.  If scan_a / scan_b are omitted, uses the two most recent
    scans (oldest → newest).  Returns 404 if fewer than 2 scans exist.
    """
    try:
        from db.database import get_drift, list_scans

        if scan_a is None or scan_b is None:
            recent = list_scans(limit=2)
            if len(recent) < 2:
                raise HTTPException(
                    status_code=404,
                    detail={"error": "Fewer than 2 scans available for drift comparison"},
                )
            # list_scans returns newest first; drift is older → newer
            scan_a = recent[1]["id"]
            scan_b = recent[0]["id"]

        raw = get_drift(scan_a, scan_b)
        return DriftReport(
            scan_a        = raw.get("scan_a", scan_a),
            scan_b        = raw.get("scan_b", scan_b),
            score_delta   = float(raw.get("score_delta", 0.0)),
            regressions   = raw.get("regressions", []),
            improvements  = raw.get("improvements", []),
            stable_pass   = int(raw.get("stable_pass", 0)),
            stable_fail   = int(raw.get("stable_fail", 0)),
            new_checks    = raw.get("new_checks", []),
            removed_checks= raw.get("removed_checks", []),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("drift() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/checks/history/{check_name}", response_model=list[dict])
def check_history(
    check_name: str,
    limit: int = Query(10, ge=1, le=100),
) -> list[dict]:
    """Return the last N results for a specific check across scans."""
    try:
        from db.database import get_check_history
        rows = get_check_history(check_name, limit=limit)
        # Coerce JSON fields so all values are JSON-serializable
        out = []
        for r in rows:
            d = dict(r)
            d["system_value"]   = _to_str(d.get("system_value"))
            d["expected_value"] = _to_str(d.get("expected_value"))
            d["cve_ids"]        = _coerce_cve_ids(d.get("cve_ids"))
            out.append(d)
        return out
    except Exception as exc:
        logger.exception("check_history(%s) failed", check_name)
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/remediation", response_model=list[RemediationItem])
def remediation() -> list[RemediationItem]:
    """
    Return FAIL results from the latest scan where remediation_supported=True,
    sorted by severity (CRITICAL first).
    """
    try:
        from db.database import get_latest_scan

        latest = get_latest_scan()
        if latest is None:
            return []

        results = latest.get("results", [])
        items = [
            r for r in results
            if r.get("status") == "FAIL" and r.get("remediation_supported")
        ]
        items.sort(key=lambda r: _SEVERITY_ORDER.get(r.get("severity", "LOW"), 99))

        return [
            RemediationItem(
                check_name      = r.get("check_name", "") or "",
                category        = r.get("category", "") or "",
                severity        = r.get("severity", "") or "",
                remediation_cmd = r.get("remediation_cmd", "") or "",
                cve_ids         = _coerce_cve_ids(r.get("cve_ids")),
            )
            for r in items
        ]
    except Exception as exc:
        logger.exception("remediation() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


@app.get("/api/v1/health")
def health() -> dict:
    """Liveness check — returns DB path and scan count."""
    try:
        from db.database import list_scans, _DB_PATH
        scan_count = len(list_scans(limit=9999))
        return {
            "status":     "ok",
            "db_path":    str(_DB_PATH),
            "scan_count": scan_count,
        }
    except Exception as exc:
        logger.exception("health() failed")
        raise HTTPException(status_code=500, detail={"error": str(exc)})


# ---------------------------------------------------------------------------
# Static files — mounted LAST so /api/* routes always take priority
# ---------------------------------------------------------------------------

if _STATIC_DIR.exists():
    app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="static")
