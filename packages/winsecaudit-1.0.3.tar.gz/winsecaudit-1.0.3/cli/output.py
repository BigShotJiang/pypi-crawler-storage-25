"""
cli/output.py — Rich terminal rendering for WinSecAudit v2.

All console output lives here. cli/main.py never imports Rich directly —
it calls the named render functions below.

render_progress() is the per-check callback contract. Wire it up by entering
scan_progress_context() before calling run_all_checks(progress_callback=...).
"""
from __future__ import annotations

import json
from collections import defaultdict
from collections.abc import Callable, Generator
from contextlib import contextmanager
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table
from rich.text import Text

# ---------------------------------------------------------------------------
# Module-level console — single instance shared across all render functions.
# legacy_windows=False forces Rich to emit ANSI/VT100 sequences instead of the
# Win32 Console API, which is limited to cp1252 and cannot render Unicode glyphs.
# winsecaudit.py reconfigures sys.stdout to UTF-8 before this module loads, so
# ANSI output reaches the terminal correctly on Windows 10/11.
# ---------------------------------------------------------------------------

console     = Console(legacy_windows=False)
err_console = Console(stderr=True, legacy_windows=False)

# ---------------------------------------------------------------------------
# Style maps
# ---------------------------------------------------------------------------

_SEVERITY_STYLE: dict[str, str] = {
    "CRITICAL": "bold red",
    "HIGH":     "red",
    "MEDIUM":   "yellow",
    "LOW":      "cyan",
}

_STATUS_STYLE: dict[str, str] = {
    "PASS":    "bold green",
    "FAIL":    "bold red",
    "ERROR":   "bold yellow",
    "SKIPPED": "dim white",
}

_GRADE_STYLE: dict[str, str] = {
    "A": "bold green",
    "B": "bold yellow",
    "C": "yellow",
    "D": "bold red",
    "F": "bold red",
}

_GRADE_BORDER: dict[str, str] = {
    "A": "green",
    "B": "yellow",
    "C": "yellow",
    "D": "red",
    "F": "red",
}

_SEVERITY_ORDER: dict[str, int] = {
    "CRITICAL": 0,
    "HIGH":     1,
    "MEDIUM":   2,
    "LOW":      3,
}

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get(obj: Any, key: str, default: Any = None) -> Any:
    """Unified attribute/key getter for both CheckResult objects and dicts."""
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _severity_str(obj: Any) -> str:
    sev = _get(obj, "severity")
    if hasattr(sev, "value"):
        return sev.value
    return str(sev) if sev else "LOW"


def _status_str(obj: Any) -> str:
    st = _get(obj, "status")
    # CheckStatus enum has .name ("PASS"), .value ("PASS") — both equal
    if hasattr(st, "name"):
        return st.name
    return str(st) if st else "ERROR"


def _parse_cve_ids(obj: Any) -> list[str]:
    raw = _get(obj, "cve_ids") or []
    if isinstance(raw, (list, tuple)):
        return list(raw)
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, list) else []
        except Exception:
            return []
    return []


def fmt_value(val: Any) -> str:
    """
    Translate a raw check system_value / expected_value into plain English.

    Handles None, bool, plain scalars, and the domain-specific dicts that
    Windows checks return so the failures table is readable by non-technical users.
    """
    # ── None
    if val is None:
        return "Not configured"
    # ── bool (must precede int because bool is a subclass of int)
    if isinstance(val, bool):
        return "Yes" if val else "No"
    # ── string: try to parse JSON dicts that arrive from DB round-trips
    if isinstance(val, str):
        stripped = val.strip()
        if stripped.startswith("{"):
            try:
                parsed = json.loads(stripped)
                if isinstance(parsed, dict):
                    return fmt_value(parsed)
            except Exception:
                pass
        return val
    # ── plain scalar
    if not isinstance(val, dict):
        return str(val)

    # ── dict: apply domain-specific rules, then generic fallback
    d: dict = val
    if not d:
        return "Not configured"
    keys = set(d.keys())

    # Service status: {'status': ..., 'start_type': ...}
    if "status" in keys and "start_type" in keys:
        status    = d.get("status")
        start_typ = d.get("start_type")
        if status is not None and start_typ is not None:
            return f"{status} ({start_typ} startup)"
        return str(status) if status is not None else "Not configured"

    # UAC: enable_lua / consent prompt keys
    if keys & {"enable_lua", "consent_prompt_behavior_admin", "consent_prompt_behavior_user"}:
        if all(v is None for v in d.values()):
            return "UAC not configured"
        lua = d.get("enable_lua")
        if lua == 0 or lua is False:
            return "UAC disabled"
        if lua == 1 or lua is True:
            return "UAC enabled"
        return "UAC not configured"

    # Windows Update: {'au_options': ..., 'source': ..., 'wsus_server': ...}
    if "au_options" in keys:
        opts   = d.get("au_options")
        source = d.get("source", "")
        if opts == 0 or source == "not_configured":
            return f"Auto-update disabled (option {opts})"
        return f"Update option {opts}"

    # Password policy: {'password_complexity': ..., 'source': ...}
    if "password_complexity" in keys:
        pc = d.get("password_complexity")
        if pc == 0 or pc is False:
            return "Complexity disabled"
        if pc == 1 or pc is True:
            return "Complexity enabled"
        return str(pc)

    # Account lockout: {'lockout_threshold': ...}
    if "lockout_threshold" in keys:
        thresh = d.get("lockout_threshold")
        return f"Threshold: {thresh} attempts" if thresh is not None else "No lockout threshold"

    # LLMNR: {'enable_multicast': ..., 'policy_set': ...}
    if "enable_multicast" in keys and "policy_set" in keys:
        multicast = d.get("enable_multicast")
        policy    = d.get("policy_set")
        if multicast is None and policy:
            return "Not set (LLMNR active)"
        return "Policy set" if policy else "Not configured"

    # Windows Script Host: {'hklm_enabled': ..., 'hkcu_enabled': ..., 'wsh_disabled': ...}
    if "hklm_enabled" in keys and "hkcu_enabled" in keys:
        hklm = d.get("hklm_enabled")
        hkcu = d.get("hkcu_enabled")
        hklm_on = hklm == 1 or hklm is True
        hkcu_on = hkcu == 1 or hkcu is True
        if hklm_on and hkcu_on:
            return "Enabled (both HKLM and HKCU)"
        if hklm_on or hkcu_on:
            return "Enabled (partial)"
        return "Disabled"

    # Firewall profiles: {'domain': ..., 'private': ..., 'public': ...}
    if keys >= {"domain", "private", "public"}:
        prof = {k: d[k] for k in ("domain", "private", "public")}
        if all(v is True for v in prof.values()):
            return "All profiles ON"
        if all(not v for v in prof.values()):
            return "All profiles OFF"
        on = [k for k, v in prof.items() if v]
        return f"{', '.join(on)} ON" if on else "All profiles OFF"

    # SMB1: {'smb1_enabled': ...}
    if "smb1_enabled" in keys:
        enabled = d.get("smb1_enabled")
        if enabled is False or enabled == 0:
            return "Disabled"
        if enabled is True or enabled == 1:
            return "Enabled"

    # All values are None — extract context from first key name
    if all(v is None for v in d.values()):
        first_key = next(iter(keys), "value")
        clean = first_key.replace("_", " ").capitalize()
        return f"{clean} not configured"

    # Generic fallback: first non-None key=value pair
    for k, v in d.items():
        if v is not None:
            clean = k.replace("_", " ").capitalize()
            return f"{clean}: {v}"

    # Last resort
    k, v = next(iter(d.items()))
    return f"{k.replace('_', ' ').capitalize()}: {v}"


def parse_explanation(text: str, mode: str) -> str:
    """Extract the SIMPLE or TECH portion from a dual-mode explanation string."""
    if not text:
        return ""
    if mode == "simple" and "SIMPLE:" in text:
        part = text.split("| TECH:")[0]
        return part.replace("SIMPLE:", "").strip()
    if mode == "technical" and "TECH:" in text:
        return text.split("TECH:")[-1].strip()
    return text


def render_check_explanation(check_class: type, mode: str = "simple") -> None:
    """Print all 5 explanation fields from *check_class* in *mode* style."""
    fields = [
        ("Risk",       "risk_summary"),
        ("Attack",     "attack_scenario"),
        ("Why fix",    "why_fix"),
        ("How to fix", "fix_steps"),
    ]
    plain = getattr(check_class, "plain_name", "") or ""
    if plain:
        console.print(f"\n[bold]{plain}[/]")
    for label, attr in fields:
        raw = getattr(check_class, attr, "") or ""
        text = parse_explanation(raw, mode)
        if text:
            console.print(f"  [dim]{label}:[/] {text}")


def _compute_category_scores(results: list) -> dict:
    """Recompute per-category scores from a list of CheckResult or dict results."""
    cat_data: dict = defaultdict(
        lambda: {"earned": 0, "max": 0, "passed": 0, "failed": 0, "total": 0}
    )
    for r in results:
        cat    = _get(r, "category", "Unknown") or "Unknown"
        status = _status_str(r)
        weight = _get(r, "weight", 1) or 1
        cat_data[cat]["total"] += 1
        if status == "SKIPPED":
            continue
        cat_data[cat]["max"] += weight
        if status == "PASS":
            cat_data[cat]["earned"] += weight
            cat_data[cat]["passed"] += 1
        elif status == "FAIL":
            cat_data[cat]["failed"] += 1

    return {
        cat: {
            "score":  round(d["earned"] / d["max"] * 100, 1) if d["max"] > 0 else 100.0,
            "passed": d["passed"],
            "failed": d["failed"],
            "total":  d["total"],
        }
        for cat, d in cat_data.items()
    }


# ---------------------------------------------------------------------------
# Module-level progress state — set/cleared by scan_progress_context()
# ---------------------------------------------------------------------------

_active_progress: dict | None = None


# ---------------------------------------------------------------------------
# 1. render_scan_header
# ---------------------------------------------------------------------------

def render_scan_header(profile_name: str, timestamp: str) -> None:
    console.print(Panel(
        f"[bold cyan]WinSecAudit v2.0[/]  |  Profile: [yellow]{profile_name}[/]\n"
        f"[dim]{timestamp}[/]",
        border_style="cyan",
        padding=(0, 2),
    ))


# ---------------------------------------------------------------------------
# 2. render_progress — callback contract for run_all_checks
# ---------------------------------------------------------------------------

def render_progress(check_name: str, current: int, total: int) -> None:
    """
    Per-check progress callback. Effective only inside scan_progress_context().
    Pass this function as progress_callback to run_all_checks().
    """
    global _active_progress
    if _active_progress is None:
        return
    _active_progress["progress"].update(
        _active_progress["task"],
        completed=current,
        description=f"[cyan]Checking[/] {check_name[:48]}...",
    )


@contextmanager
def scan_progress_context(total: int) -> Generator[Callable[[str, int, int], None], None, None]:
    """
    Context manager that activates the Rich progress bar for a scan.
    Yields render_progress as the callback to pass to run_all_checks().
    transient=True clears the bar after the scan so the results table renders cleanly.
    """
    global _active_progress
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task: TaskID = progress.add_task("[cyan]Starting scan...[/]", total=total)
        _active_progress = {"progress": progress, "task": task}
        try:
            yield render_progress
        finally:
            _active_progress = None


# ---------------------------------------------------------------------------
# 3. render_score_box
# ---------------------------------------------------------------------------

def render_score_box(
    score: float,
    grade: str,
    passed: int,
    failed: int,
    total: int,
) -> None:
    grade_style  = _GRADE_STYLE.get(grade, "white")
    border_style = _GRADE_BORDER.get(grade, "white")
    content = (
        f"[{grade_style}]SECURITY SCORE   {score}/100   Grade: {grade}[/]\n"
        f"[green]{passed} passed[/]  [red]{failed} failed[/]  [dim]{total} total[/]"
    )
    console.print(Panel(content, border_style=border_style, padding=(0, 2)))


# ---------------------------------------------------------------------------
# 4. render_category_breakdown
# ---------------------------------------------------------------------------

def render_category_breakdown(category_scores: dict) -> None:
    table = Table(
        title="Category Breakdown",
        show_header=True,
        header_style="bold cyan",
        border_style="dim",
        expand=False,
    )
    table.add_column("Category",  style="white",   min_width=24)
    table.add_column("Score",     justify="right", min_width=7)
    table.add_column("Bar",       justify="left",  min_width=14)
    table.add_column("Counts",    justify="right", min_width=16)

    for cat, cs in sorted(category_scores.items()):
        sc     = cs["score"]
        filled = int(sc / 100 * 12)
        bar_style = "green" if sc >= 75 else "yellow" if sc >= 50 else "red"

        bar_text = Text()
        bar_text.append("\u2588" * filled,        style=bar_style)
        bar_text.append("\u2591" * (12 - filled), style="dim")

        failing_hint = f"  [red]\u2190 {cs['failed']} failing[/]" if cs["failed"] > 0 else ""

        table.add_row(
            cat,
            f"{sc:.1f}%",
            bar_text,
            f"[green]{cs['passed']}P[/] [red]{cs['failed']}F[/] / {cs['total']}{failing_hint}",
        )

    console.print(table)


# ---------------------------------------------------------------------------
# 5. render_failures
# ---------------------------------------------------------------------------

def render_failures(
    results: list,
    ti_data: dict | None = None,
    max_show: int = 10,
    explain_mode: str = "simple",
    check_map: dict | None = None,
) -> None:
    """
    Render the failures table.  When *ti_data* is provided (from enrich_results),
    the CVE/ATT&CK column shows enriched one-line summaries including CVSS, EPSS,
    and CISA KEV status.  Falls back to plain CVE IDs when ti_data is absent.

    When *check_map* is provided (name→class dict), each failing row includes a
    compact plain-English explanation below the check name.
    """
    failures = [r for r in results if _status_str(r) == "FAIL"]
    if not failures:
        console.print("[green]\u2714 No failures — all checks passed.[/]")
        return

    failures.sort(key=lambda r: (
        _SEVERITY_ORDER.get(_severity_str(r), 99),
        -(_get(r, "weight") or 0),
    ))

    table = Table(
        title=f"Failures  ({len(failures)} total, showing {min(len(failures), max_show)})",
        show_header=True,
        header_style="bold red",
        border_style="dim",
        expand=False,
        show_lines=True,
    )
    table.add_column("Severity",     min_width=10)
    table.add_column("Check",        min_width=28)
    table.add_column("Current",      min_width=14)
    table.add_column("Expected",     min_width=14)
    table.add_column("CVE / ATT&CK", min_width=26)

    # Import lazily so this module loads fast when TI is disabled
    _fmt_cve_line = None
    if ti_data:
        try:
            from engine.threat_intel import format_cve_line as _fmt_cve_line
        except Exception:
            _fmt_cve_line = None

    for r in failures[:max_show]:
        sev        = _severity_str(r)
        sev_style  = _SEVERITY_STYLE.get(sev, "white")
        cve_ids    = _parse_cve_ids(r)
        mitre      = _get(r, "mitre_technique") or ""
        check_name = _get(r, "check_name", "")

        # Build intel cell: enriched CVE lines when ti_data available, else plain
        if _fmt_cve_line and ti_data and cve_ids:
            intel_lines = [
                _fmt_cve_line(cid, ti_data.get(cid, {}))
                for cid in cve_ids[:2]
            ]
            if mitre:
                intel_lines.append(f"ATT&CK: {mitre}")
            intel = "\n".join(intel_lines)
        else:
            intel_parts: list[str] = []
            if cve_ids:
                intel_parts.append(", ".join(cve_ids[:2]))
            if mitre:
                intel_parts.append(mitre)
            intel = "  ".join(intel_parts) or "\u2014"

        # Build compact explanation block inside the Check cell
        check_cell_parts = [check_name]
        if check_map and check_name in check_map:
            cls = check_map[check_name]
            rs  = parse_explanation(getattr(cls, "risk_summary",    ""), explain_mode)
            asc = parse_explanation(getattr(cls, "attack_scenario", ""), explain_mode)
            if rs:
                check_cell_parts.append(f"  [dim]⚠  {rs}[/]")
            if asc:
                check_cell_parts.append(f"  [dim]\U0001f3af {asc}[/]")
        check_cell = "\n".join(check_cell_parts)

        table.add_row(
            Text(sev, style=sev_style),
            check_cell,
            fmt_value(_get(r, "system_value")),
            fmt_value(_get(r, "expected_value")),
            intel,
        )

    console.print(table)

    if len(failures) > max_show:
        console.print(
            f"[dim]... {len(failures) - max_show} more failures not shown. "
            f"Use --output json for full list.[/]"
        )

    first_fixable = next((r for r in failures if _get(r, "remediation_cmd")), None)
    if first_fixable:
        fix_name = _get(first_fixable, "check_name", "")
        console.print(f'\n[dim]To fix: winsecaudit fix "{fix_name}"  or run:  winsecaudit fix --all-high[/]')


# ---------------------------------------------------------------------------
# 6. render_single_check
# ---------------------------------------------------------------------------

def render_single_check(
    result: Any,
    check_class: type | None = None,
    explain_mode: str = "simple",
) -> None:
    status     = _status_str(result)
    severity   = _severity_str(result)
    status_style  = _STATUS_STYLE.get(status, "white")
    sev_style     = _SEVERITY_STYLE.get(severity, "white")
    border_style  = status_style.replace("bold ", "")

    check_name = _get(result, "check_name", "")
    category   = _get(result, "category", "")
    cve_ids    = _parse_cve_ids(result)
    mitre      = _get(result, "mitre_technique") or ""
    cis_id     = _get(result, "cis_id") or ""
    rem_cmd    = _get(result, "remediation_cmd") or ""
    err_msg    = _get(result, "error_message")
    weight     = _get(result, "weight", 0)

    sys_val = _get(result, "system_value", "N/A")
    exp_val = _get(result, "expected_value", "N/A")

    lines: list[str] = [
        f"[{status_style}][{status}][/]  [bold]{check_name}[/]  [dim]({category})[/]",
        f"Severity: [{sev_style}]{severity}[/]  |  Weight: {weight}",
        "",
        f"System value:   [cyan]{sys_val}[/]",
        f"Expected value: [cyan]{exp_val}[/]",
    ]

    if cve_ids:
        lines.append(f"CVE IDs:        [yellow]{', '.join(cve_ids)}[/]")
    if mitre:
        lines.append(f"ATT&CK:         [dim]{mitre}[/]")
    if cis_id:
        lines.append(f"CIS ID:         [dim]{cis_id}[/]")
    if rem_cmd:
        lines.append(f"Remediation:    [dim]{rem_cmd}[/]")
    if err_msg:
        lines.append(f"\n[yellow]Note: {err_msg}[/]")

    console.print(Panel("\n".join(lines), border_style=border_style, padding=(0, 2)))

    # Show explanation fields when a check class is provided
    if check_class is not None:
        expl_fields = [
            ("Risk",       "risk_summary"),
            ("Attack",     "attack_scenario"),
            ("Why fix",    "why_fix"),
            ("How to fix", "fix_steps"),
        ]
        shown = False
        for label, attr in expl_fields:
            raw  = getattr(check_class, attr, "") or ""
            text = parse_explanation(raw, explain_mode)
            if text:
                if not shown:
                    console.print()
                    shown = True
                console.print(f"  [dim]{label}:[/] {text}")


# ---------------------------------------------------------------------------
# 7. render_drift
# ---------------------------------------------------------------------------

def render_drift(drift_data: dict, show: str = "all") -> None:
    scan_a       = drift_data.get("scan_a", "?")
    scan_b       = drift_data.get("scan_b", "?")
    delta        = drift_data.get("score_delta", 0.0) or 0.0
    regressions  = drift_data.get("regressions",    [])
    improvements = drift_data.get("improvements",   [])
    stable_pass  = drift_data.get("stable_pass",    0)
    stable_fail  = drift_data.get("stable_fail",    0)
    new_checks   = drift_data.get("new_checks",     [])
    removed      = drift_data.get("removed_checks", [])

    if delta < 0:
        direction = f"[red]\u25bc REGRESSING[/]"
    elif delta > 0:
        direction = f"[green]\u25b2 IMPROVING[/]"
    else:
        direction = "[dim]STABLE[/]"

    console.rule("[bold cyan]DRIFT REPORT[/]")
    console.print(f"[dim]{scan_a}[/]  \u2192  [dim]{scan_b}[/]")
    console.print(f"Score delta: [bold]{delta:+.1f} pts[/]  {direction}")
    console.print()

    if show in ("all", "regressions") and regressions:
        console.print(f"[bold red]\u26a0 REGRESSIONS ({len(regressions)})[/]")
        for r in regressions:
            sev       = r.get("severity", "") or ""
            sev_style = _SEVERITY_STYLE.get(sev, "white")
            console.print(
                f"  [red]\u26a0[/] [bold]{r['check_name']}[/]"
                f"  [green]PASS[/] \u2192 [red]FAIL[/]"
                f"  [{sev_style}]{sev}[/]"
            )
        console.print()

    if show in ("all", "improvements") and improvements:
        console.print(f"[bold green]\u2713 IMPROVEMENTS ({len(improvements)})[/]")
        for r in improvements:
            console.print(
                f"  [green]\u2713[/] [bold]{r['check_name']}[/]"
                f"  [red]FAIL[/] \u2192 [green]PASS[/]"
            )
        console.print()

    stable_total = stable_pass + stable_fail
    console.print(
        f"[dim]\u2500 STABLE: {stable_total} checks unchanged "
        f"({stable_pass} passing, {stable_fail} failing)"
        f"  |  New: {len(new_checks)}  |  Removed: {len(removed)}[/]"
    )

    if not regressions and not improvements:
        console.print("[dim]No status changes between scans.[/]")


# ---------------------------------------------------------------------------
# 8. render_report
# ---------------------------------------------------------------------------

def render_report(scan: dict) -> None:
    results = scan.get("results", [])
    score   = scan.get("score",          0.0)
    grade   = scan.get("grade",          "F")
    passed  = scan.get("passed_checks",  0)
    failed  = scan.get("failed_checks",  0)
    total   = scan.get("total_checks",   0)
    scan_id = scan.get("id",             "unknown")
    ts      = scan.get("timestamp",      "")
    profile = scan.get("profile",        "basic")

    console.print()
    render_scan_header(profile, ts)
    render_score_box(score, grade, passed, failed, total)
    render_category_breakdown(_compute_category_scores(results))
    render_failures(results, max_show=10)
    console.print(f"\n[dim]Scan ID: {scan_id}[/]")


# ---------------------------------------------------------------------------
# 9. render_scan_results — master render called by scan command
# ---------------------------------------------------------------------------

def render_scan_results(
    results: list,
    score_data: dict,
    scan_summary: dict,
    ti_data: dict | None = None,
    explain_mode: str = "simple",
    check_map: dict | None = None,
) -> None:
    """Master render function called by the scan command after a full pipeline run."""
    render_scan_header(
        scan_summary.get("profile",   "basic"),
        scan_summary.get("timestamp", ""),
    )
    render_score_box(
        score  = score_data["score"],
        grade  = scan_summary.get("grade", "F"),
        passed = score_data["passed_checks"],
        failed = score_data["failed_checks"],
        total  = score_data["total_checks"],
    )
    render_category_breakdown(score_data["category_scores"])
    render_failures(
        results,
        ti_data=ti_data,
        max_show=10,
        explain_mode=explain_mode,
        check_map=check_map,
    )
    console.print(f"\n[dim]Scan ID: {scan_summary['id']}[/]")
