"""LeadHunt — Find B2B leads from Google Maps in seconds."""
__version__ = "1.0.0"
