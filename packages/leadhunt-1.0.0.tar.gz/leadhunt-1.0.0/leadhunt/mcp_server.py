"""
LeadHunt MCP Server — use LeadHunt from Claude, Cursor, Copilot, ChatGPT.

Install:
  pip install leadhunt
  leadhunt-mcp  # starts MCP server

Add to claude_desktop_config.json:
  {
    "mcpServers": {
      "leadhunt": {
        "command": "leadhunt-mcp",
        "env": {"GOOGLE_MAPS_API_KEY": "your-key-here"}
      }
    }
  }
"""
import os
import json
from fastmcp import FastMCP
from .scraper import find_leads, INDUSTRIES, COUNTRIES

mcp = FastMCP(
    "LeadHunt",
    instructions="""
LeadHunt finds real B2B leads from Google Maps.
Use find_leads to search for businesses by industry and city.
Use list_industries to see available industry categories.
Use list_countries to see supported countries.

Results include: business name, phone, email, website, address, rating, reviews, and a lead score (0-100).
Score 70+ = hot lead (no website, has phone+email, many reviews).
"""
)


def _get_api_key() -> str | None:
    key = os.getenv("GOOGLE_MAPS_API_KEY")
    if key:
        return key
    config_file = os.path.expanduser("~/.leadhunt/config.json")
    if os.path.exists(config_file):
        try:
            data = json.loads(open(config_file).read())
            return data.get("api_key")
        except Exception:
            pass
    return None


@mcp.tool()
def find_leads_tool(
    industry: str,
    city: str,
    country: str = "romania",
    no_website_only: bool = False,
    limit: int = 20,
) -> dict:
    """
    Find B2B leads from Google Maps.

    Args:
        industry: Industry to search (e.g. 'dentist', 'restaurant', 'salon', 'gym', 'lawyer').
                  Use list_industries() to see all options.
        city: City name (e.g. 'Bucharest', 'London', 'Amsterdam')
        country: Country code. Options: romania, uk, usa, canada, netherlands. Default: romania
        no_website_only: If True, returns ONLY businesses without a website (highest priority leads)
        limit: Maximum number of results (default 20, max 50)

    Returns:
        Dict with 'leads' list, 'total', 'without_website', 'with_email', 'with_phone' stats
    """
    api_key = _get_api_key()
    if not api_key:
        return {
            "error": "Google Maps API key not configured. Run 'leadhunt setup' in terminal or set GOOGLE_MAPS_API_KEY env variable.",
            "leads": []
        }

    limit = min(limit, 50)

    leads = find_leads(
        industry=industry,
        city=city,
        api_key=api_key,
        country=country,
        no_website_only=no_website_only,
        max_results=limit,
        extract_emails=True,
    )

    return {
        "leads": leads,
        "total": len(leads),
        "without_website": sum(1 for l in leads if not l["website"]),
        "with_email": sum(1 for l in leads if l.get("email")),
        "with_phone": sum(1 for l in leads if l.get("phone")),
        "top_lead": leads[0] if leads else None,
    }


@mcp.tool()
def list_industries() -> dict:
    """List all available industry categories for lead search."""
    return {
        "industries": list(sorted(INDUSTRIES.keys())),
        "count": len(INDUSTRIES),
        "examples": ["dentist", "restaurant", "salon", "gym", "lawyer", "construction", "medical", "auto", "cleaning"]
    }


@mcp.tool()
def list_countries() -> dict:
    """List supported countries for lead search."""
    return {
        "countries": {
            "romania": "🇷🇴 Romania (Romanian search terms)",
            "uk": "🇬🇧 United Kingdom (English)",
            "usa": "🇺🇸 United States (English)",
            "canada": "🇨🇦 Canada (English)",
            "netherlands": "🇳🇱 Netherlands (Dutch + English)",
        }
    }


def main():
    mcp.run()
