"""
LeadHunt — Google Maps lead scraper using official Places API.
Legal: uses official API, user provides their own key.
"""
import requests
import re
import time

SITE_RECOMANDARI = [
    "booking.com", "tripadvisor.com", "tripadvisor.ro", "facebook.com", "instagram.com",
    "yelp.com", "foursquare.com", "zomato.com", "paginiaurii.ro", "listafirme.ro",
    "topfirme.ro", "termene.ro", "recom.ro", "maps.google.com", "google.com",
    "waze.com", "restaurantguru.com", "yellowpages.com",
    "goudengids.nl", "telefoonboek.nl", "bedrijvengids.nl", "kvk.nl",
]

INDUSTRIES = {
    "dentist":        {"ro": ["stomatolog", "cabinet stomatologic", "dentist"], "en": ["dentist", "dental clinic"], "nl": ["tandarts", "tandartspraktijk"]},
    "restaurant":     {"ro": ["restaurant", "cafenea", "catering"], "en": ["restaurant", "cafe", "catering"], "nl": ["restaurant", "cafe", "cateringbedrijf"]},
    "salon":          {"ro": ["salon infrumusetare", "salon beauty", "coafor"], "en": ["beauty salon", "hair salon", "nail salon"], "nl": ["schoonheidssalon", "kapper", "nagelstudio"]},
    "lawyer":         {"ro": ["cabinet avocat", "avocat"], "en": ["law firm", "solicitor", "lawyer"], "nl": ["advocatenkantoor", "advocaat"]},
    "construction":   {"ro": ["firma constructii", "constructor"], "en": ["construction company", "builder"], "nl": ["aannemer", "bouwbedrijf"]},
    "medical":        {"ro": ["clinica medicala", "cabinet medical"], "en": ["medical clinic", "doctor surgery"], "nl": ["huisartsenpraktijk", "medisch centrum"]},
    "vet":            {"ro": ["cabinet veterinar", "veterinar"], "en": ["veterinary clinic", "vet"], "nl": ["dierenarts", "dierenkliniek"]},
    "accountant":     {"ro": ["cabinet contabilitate", "contabil"], "en": ["accountant", "accounting firm"], "nl": ["accountantskantoor", "boekhouder"]},
    "gym":            {"ro": ["sala fitness", "gym", "club fitness"], "en": ["gym", "fitness centre"], "nl": ["sportschool", "fitnesscentrum"]},
    "auto":           {"ro": ["service auto", "vulcanizare", "reparatii auto"], "en": ["car repair", "auto repair", "garage"], "nl": ["autogarage", "autobedrijf"]},
    "cleaning":       {"ro": ["firma curatenie", "servicii curatenie"], "en": ["cleaning company", "office cleaning"], "nl": ["schoonmaakbedrijf"]},
    "plumber":        {"ro": ["instalatii sanitare", "instalator"], "en": ["plumber", "plumbing company"], "nl": ["loodgieter", "installatiebedrijf"]},
    "electrician":    {"ro": ["instalatii electrice", "electrician"], "en": ["electrician", "electrical contractor"], "nl": ["elektricien", "elektrisch installatiebedrijf"]},
    "transport":      {"ro": ["transport marfa", "transport persoane"], "en": ["freight company", "courier"], "nl": ["transportbedrijf", "taxibedrijf"]},
    "hotel":          {"ro": ["hotel", "pensiune", "cazare"], "en": ["hotel", "guesthouse", "B&B"], "nl": ["hotel", "pension", "bed and breakfast"]},
    "bakery":         {"ro": ["cofetarie", "patiserie", "brutarie"], "en": ["bakery", "patisserie", "cake shop"], "nl": ["banketbakkerij", "bakkerij"]},
    "nursery":        {"ro": ["gradinita privata", "gradinita"], "en": ["nursery school", "private nursery"], "nl": ["kinderdagverblijf", "peuterspeelzaal"]},
    "security":       {"ro": ["firma paza", "firma securitate"], "en": ["security company", "security guard"], "nl": ["beveiligingsbedrijf"]},
    "funeral":        {"ro": ["pompe funebre", "servicii funerare"], "en": ["funeral home", "funeral director"], "nl": ["uitvaartondernemer"]},
    "carwash":        {"ro": ["spalatorie auto", "car wash"], "en": ["car wash", "auto wash"], "nl": ["autowasstraat", "carwash"]},
}

COUNTRIES = {
    "romania":      {"region": "ro", "language": "ro",  "suffix": "Romania",     "lang_key": "ro"},
    "uk":           {"region": "gb", "language": "en",  "suffix": "UK",          "lang_key": "en"},
    "usa":          {"region": "us", "language": "en",  "suffix": "USA",         "lang_key": "en"},
    "canada":       {"region": "ca", "language": "en",  "suffix": "Canada",      "lang_key": "en"},
    "netherlands":  {"region": "nl", "language": "nl",  "suffix": "Netherlands", "lang_key": "nl"},
    "japan":        {"region": "jp", "language": "en",  "suffix": "Japan",       "lang_key": "en"},
    "france":       {"region": "fr", "language": "fr",  "suffix": "France",      "lang_key": "en"},
    "germany":      {"region": "de", "language": "de",  "suffix": "Germany",     "lang_key": "en"},
    "spain":        {"region": "es", "language": "es",  "suffix": "Spain",       "lang_key": "en"},
    "italy":        {"region": "it", "language": "it",  "suffix": "Italy",       "lang_key": "en"},
    "australia":    {"region": "au", "language": "en",  "suffix": "Australia",   "lang_key": "en"},
    "brazil":       {"region": "br", "language": "pt",  "suffix": "Brazil",      "lang_key": "en"},
    "mexico":       {"region": "mx", "language": "es",  "suffix": "Mexico",      "lang_key": "en"},
    "india":        {"region": "in", "language": "en",  "suffix": "India",       "lang_key": "en"},
    "uae":          {"region": "ae", "language": "en",  "suffix": "UAE",         "lang_key": "en"},
    "singapore":    {"region": "sg", "language": "en",  "suffix": "Singapore",   "lang_key": "en"},
    "portugal":     {"region": "pt", "language": "pt",  "suffix": "Portugal",    "lang_key": "en"},
    "poland":       {"region": "pl", "language": "pl",  "suffix": "Poland",      "lang_key": "en"},
    "turkey":       {"region": "tr", "language": "tr",  "suffix": "Turkey",      "lang_key": "en"},
    "sweden":       {"region": "se", "language": "sv",  "suffix": "Sweden",      "lang_key": "en"},
    "norway":       {"region": "no", "language": "no",  "suffix": "Norway",      "lang_key": "en"},
    "denmark":      {"region": "dk", "language": "da",  "suffix": "Denmark",     "lang_key": "en"},
    "belgium":      {"region": "be", "language": "fr",  "suffix": "Belgium",     "lang_key": "en"},
    "switzerland":  {"region": "ch", "language": "de",  "suffix": "Switzerland", "lang_key": "en"},
    "austria":      {"region": "at", "language": "de",  "suffix": "Austria",     "lang_key": "en"},
    "greece":       {"region": "gr", "language": "el",  "suffix": "Greece",      "lang_key": "en"},
    "hungary":      {"region": "hu", "language": "hu",  "suffix": "Hungary",     "lang_key": "en"},
    "czechia":      {"region": "cz", "language": "cs",  "suffix": "Czech Republic", "lang_key": "en"},
    "southafrica":  {"region": "za", "language": "en",  "suffix": "South Africa","lang_key": "en"},
    "newzealand":   {"region": "nz", "language": "en",  "suffix": "New Zealand", "lang_key": "en"},
    "ireland":      {"region": "ie", "language": "en",  "suffix": "Ireland",     "lang_key": "en"},
    "southkorea":   {"region": "kr", "language": "en",  "suffix": "South Korea", "lang_key": "en"},
    "china":        {"region": "cn", "language": "en",  "suffix": "China",       "lang_key": "en"},
}


def is_real_website(url: str) -> bool:
    if not url:
        return False
    url_lower = url.lower()
    return not any(domain in url_lower for domain in SITE_RECOMANDARI)


def score_lead(lead: dict) -> int:
    score = 0
    if not lead.get("website"):
        score += 40
    if lead.get("phone"):
        score += 20
    if lead.get("email"):
        score += 20
    rating = lead.get("rating", 0) or 0
    reviews = lead.get("reviews", 0) or 0
    if reviews > 50:
        score += 15
    elif reviews > 20:
        score += 10
    elif reviews > 5:
        score += 5
    return min(score, 100)


def extract_email(website_url: str, timeout: int = 6) -> str | None:
    if not website_url:
        return None
    if not website_url.startswith("http"):
        website_url = "https://" + website_url
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    pages = [website_url, website_url.rstrip("/") + "/contact", website_url.rstrip("/") + "/contact.html"]
    for url in pages[:2]:
        try:
            r = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
            if r.status_code != 200:
                continue
            found = re.findall(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', r.text)
            skip = ["example", "test", "noreply", "no-reply", "wordpress", "sentry", "google", "schema"]
            clean = [e for e in found if not any(s in e.lower() for s in skip)]
            if clean:
                for prefix in ["contact@", "office@", "info@"]:
                    for e in clean:
                        if e.startswith(prefix):
                            return e.lower()
                return clean[0].lower()
            time.sleep(0.3)
        except Exception:
            continue
    return None


def _get_country_cfg(country: str) -> dict:
    """Get country config — falls back to English generic instead of Romania."""
    key = country.lower().replace(" ", "").replace("-", "")
    if key in COUNTRIES:
        return COUNTRIES[key]
    # Unknown country: use English, no region bias, use country name as suffix
    return {"region": "", "language": "en", "suffix": country.title(), "lang_key": "en"}


def search_places(query: str, city: str, api_key: str, country: str = "romania") -> list:
    cfg = _get_country_cfg(country)
    url = "https://maps.googleapis.com/maps/api/place/textsearch/json"
    params = {
        "query": f"{query} {city} {cfg['suffix']}",
        "language": cfg["language"],
        "key": api_key,
    }
    if cfg.get("region"):
        params["region"] = cfg["region"]
    results = []
    for _ in range(2):
        try:
            r = requests.get(url, params=params, timeout=15)
            data = r.json()
            if data.get("status") not in ["OK", "ZERO_RESULTS"]:
                break
            results.extend(data.get("results", []))
            token = data.get("next_page_token")
            if not token:
                break
            time.sleep(2.2)
            params = {"pagetoken": token, "key": api_key}
        except Exception:
            break
    return results


def get_place_details(place_id: str, api_key: str) -> dict:
    url = "https://maps.googleapis.com/maps/api/place/details/json"
    params = {
        "place_id": place_id,
        "fields": "name,formatted_phone_number,international_phone_number,website,formatted_address,rating,user_ratings_total",
        "key": api_key,
    }
    try:
        r = requests.get(url, params=params, timeout=15)
        return r.json().get("result", {})
    except Exception:
        return {}


def find_leads(
    industry: str,
    city: str,
    api_key: str,
    country: str = "romania",
    no_website_only: bool = False,
    max_results: int = 50,
    extract_emails: bool = True,
    progress_cb=None,
) -> list[dict]:
    """Main function — finds and scores B2B leads from Google Maps."""
    cfg = _get_country_cfg(country)
    lang_key = cfg["lang_key"]

    # Get search terms for this industry
    ind_data = INDUSTRIES.get(industry.lower())
    if ind_data:
        queries = ind_data.get(lang_key, ind_data.get("en", [industry]))[:2]
    else:
        queries = [industry]

    leads = []
    seen_ids = set()

    for query in queries:
        if len(leads) >= max_results:
            break
        places = search_places(query, city, api_key, country)
        time.sleep(0.3)

        for place in places:
            if len(leads) >= max_results:
                break
            place_id = place.get("place_id")
            if not place_id or place_id in seen_ids:
                continue
            seen_ids.add(place_id)

            if place.get("business_status") == "CLOSED_PERMANENTLY":
                continue

            details = get_place_details(place_id, api_key)
            time.sleep(0.2)

            website_raw = details.get("website", "")
            website = website_raw if is_real_website(website_raw) else None

            if no_website_only and website:
                continue

            phone = details.get("formatted_phone_number") or details.get("international_phone_number")
            email = None
            if extract_emails and website:
                email = extract_email(website)

            lead = {
                "name": details.get("name", place.get("name", "")),
                "phone": phone,
                "email": email,
                "website": website,
                "address": details.get("formatted_address", ""),
                "city": city,
                "country": country,
                "industry": industry,
                "rating": details.get("rating"),
                "reviews": details.get("user_ratings_total"),
                "has_website": bool(website),
                "score": 0,
            }
            lead["score"] = score_lead(lead)
            leads.append(lead)

            if progress_cb:
                progress_cb(lead)

    # Sort by score desc
    leads.sort(key=lambda x: x["score"], reverse=True)
    return leads
