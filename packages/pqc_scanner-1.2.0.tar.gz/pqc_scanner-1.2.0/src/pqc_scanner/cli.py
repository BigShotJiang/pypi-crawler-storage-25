import click
import os
import json
import webbrowser
import subprocess
import sys
import numpy as np
from scipy import stats

from pqc_scanner.scanner.timing import TimingAnalyzer, pin_to_core
from pqc_scanner.scanner.static import StaticAnalyzer
from pqc_scanner.scanner.report import ReportGenerator
from pqc_scanner.targets.ml_kem_target import MLKEMTarget
from pqc_scanner.targets.ml_dsa_target import MLDSATarget
from pqc_scanner.targets.baseline_target import BaselineTarget


# ─────────────────────────────────────────────
#  Shared helpers
# ─────────────────────────────────────────────

def run_timing(harness_ops, traces: int):
    analyzer = TimingAnalyzer(num_traces=traces)
    timing_results = []
    raw_traces = {}

    for name, fixed_fn, random_fn in harness_ops:
        click.echo(f"\n  -> {name}")
        r = analyzer.analyze(name, fixed_fn, random_fn)
        timing_results.append(r)
        raw_traces[name] = {
            "fixed":   r.fixed_times,
            "random":  r.random_times,
            "verdict": r.verdict
        }
        status = "LEAK DETECTED" if r.leaking else "PASS"
        click.echo(f"     [{status}]  t={r.t_statistic}  |  delta={r.difference_ns:.0f}ns  |  p={r.p_value}")

    return timing_results, raw_traces


def save_reports(report, output: str, open_html: bool, exit_on_findings: bool = True):
    reporter = ReportGenerator()
    json_path = f"{output}.json"
    html_path = f"{output}.html"

    with open(json_path, "w", encoding="utf-8") as f:
        f.write(reporter.to_json(report))
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(reporter.to_html(report))

    s = report["summary"]
    click.echo(f"\n{'='*55}")
    click.echo(f"  SCAN COMPLETE")
    click.echo(f"  Findings : {s['total']}")
    click.echo(f"  Critical : {s['critical']}")
    click.echo(f"  High     : {s['high']}")
    click.echo(f"  Medium   : {s['medium']}")
    click.echo(f"  JSON     : {json_path}")
    click.echo(f"  HTML     : {html_path}")
    click.echo(f"{'='*55}\n")

    if open_html:
        webbrowser.open(os.path.abspath(html_path))

    if exit_on_findings and s['total'] > 0:
        sys.exit(1)


# ─────────────────────────────────────────────
#  CLI group
# ─────────────────────────────────────────────

@click.group()
def cli():
    """PQC Side-Channel Scanner -- production-grade timing leak detection."""
    pass


# ─────────────────────────────────────────────
#  scan command
# ─────────────────────────────────────────────

@cli.command()
@click.option("--algorithm",  default="ml-kem",
              type=click.Choice(["ml-kem", "ml-dsa", "both"]),
              show_default=True)
@click.option("--traces",     default=10000,    show_default=True)
@click.option("--source-dir", default=None)
@click.option("--output",     default="report")
@click.option("--open-html",  is_flag=True)
@click.option("--pin-cpu",    is_flag=True,     help="Pin process to CPU core 0")
@click.option("--no-exit",    is_flag=True,     help="Do not exit with code 1 on findings")
def scan(algorithm, traces, source_dir, output, open_html, pin_cpu, no_exit):
    """
    Run a full side-channel scan on ML-KEM and/or ML-DSA.
    Exits with code 1 if findings are detected (use --no-exit to suppress).
    """
    click.echo("\n" + "="*55)
    click.echo("  PQC Side-Channel Scanner")
    click.echo(f"  Target: {algorithm.upper()}")
    click.echo("="*55)

    if pin_cpu:
        pin_to_core(0)

    all_timing_results = []
    all_raw_traces = {}

    if algorithm in ("ml-kem", "both"):
        click.echo("\n[ML-KEM-768] Initializing harness...")
        kem = MLKEMTarget()
        kem_ops = [
            ("KEM Decapsulation", kem.decapsulate_fixed,  kem.decapsulate_random),
            ("KEM Encapsulation", kem.encapsulate_fixed,  kem.encapsulate_random),
            ("KEM KeyGen",        kem.keygen_repeated,    kem.keygen_repeated),
        ]
        click.echo(f"\n[ML-KEM] TVLA ({traces} traces each)...")
        r, t = run_timing(kem_ops, traces)
        all_timing_results.extend(r)
        all_raw_traces.update(t)

    if algorithm in ("ml-dsa", "both"):
        click.echo("\n[ML-DSA-65] Initializing harness...")
        dsa = MLDSATarget()
        dsa_ops = [
            ("DSA Sign",   dsa.sign_fixed,      dsa.sign_random),
            ("DSA Verify", dsa.verify_fixed,    dsa.verify_random),
            ("DSA KeyGen", dsa.keygen_repeated, dsa.keygen_repeated),
        ]
        click.echo(f"\n[ML-DSA] TVLA ({traces} traces each)...")
        r, t = run_timing(dsa_ops, traces)
        all_timing_results.extend(r)
        all_raw_traces.update(t)

    static_findings = []
    click.echo("\n[Static Analysis]")
    if source_dir and os.path.exists(source_dir):
        sa = StaticAnalyzer()
        static_findings = sa.scan_directory(source_dir)
        click.echo(f"  Found {len(static_findings)} static issue(s)")
        for f in static_findings[:5]:
            click.echo(f"  [{f.severity}] {f.file}:{f.line} -- {f.issue}")
    else:
        click.echo("  Skipped (use --source-dir PATH to enable)")

    reporter = ReportGenerator()
    target_label = "ML-KEM-768 + ML-DSA-65" if algorithm == "both" else algorithm.upper()
    report = reporter.build_with_traces(all_timing_results, static_findings,
                                        target_label, all_raw_traces)
    save_reports(report, output, open_html, exit_on_findings=not no_exit)


# ─────────────────────────────────────────────
#  baseline command
# ─────────────────────────────────────────────

@cli.command()
@click.option("--traces",    default=10000,    show_default=True)
@click.option("--output",    default="baseline")
@click.option("--open-html", is_flag=True)
@click.option("--pin-cpu",   is_flag=True)
@click.option("--no-exit",   is_flag=True)
def baseline(traces, output, open_html, pin_cpu, no_exit):
    """
    Run SHA-256 as a Python-level noise floor characterization.
    Always run this before reporting findings.
    """
    if pin_cpu:
        pin_to_core(0)

    click.echo("\n" + "="*55)
    click.echo("  PQC Scanner -- Python Baseline")
    click.echo("  Target: SHA-256 (hashlib)")
    click.echo("  Purpose: Characterize WSL noise floor")
    click.echo("="*55)

    target = BaselineTarget()
    ops = [("SHA-256 Hash", target.hash_fixed, target.hash_random)]

    click.echo(f"\n[Baseline] TVLA ({traces} traces)...")
    timing_results, raw_traces = run_timing(ops, traces)

    reporter = ReportGenerator()
    report = reporter.build_with_traces(
        timing_results, [], "SHA-256 Baseline (noise floor characterization)", raw_traces
    )

    t = timing_results[0].t_statistic
    d = timing_results[0].difference_ns

    click.echo(f"\n  Python Noise Floor : {d:.0f}ns  (t={t})")
    click.echo(f"  ML-KEM delta       : ~5,300,000ns -- {5300000/max(d,1):,.0f}x above this floor")
    click.echo(f"  ML-KEM findings are unambiguously real signal.")

    save_reports(report, output, open_html, exit_on_findings=False)


# ─────────────────────────────────────────────
#  c-baseline command
# ─────────────────────────────────────────────

@cli.command(name="c-baseline")
@click.option("--traces",    default=100000,   show_default=True)
@click.option("--output",    default="c_baseline")
@click.option("--open-html", is_flag=True)
def c_baseline(traces, output, open_html):
    """
    Measure C-level noise floor using AES-128 (AES-NI hardware instruction).
    Reports noise floor delta for comparison with liboqs findings.
    """
    import csv
    import io as sio

    harness = os.path.join(os.path.dirname(__file__), "harness", "baseline_harness")
    if not os.path.exists(harness):
        click.echo("  ERROR: baseline_harness not found.")
        click.echo("  Build: gcc -O2 -o harness/baseline_harness harness/baseline_harness.c -lssl -lcrypto")
        return

    click.echo("\n" + "="*55)
    click.echo("  PQC Scanner -- C-Level Noise Floor")
    click.echo("  Target: AES-128 (AES-NI hardware instruction)")
    click.echo("="*55)

    click.echo(f"\n  Running ({traces:,} traces)...")
    result = subprocess.run(
        [harness, str(traces)],
        capture_output=True, text=True, timeout=300
    )

    if result.returncode != 0:
        click.echo(f"  ERROR: {result.stderr}")
        return

    for line in result.stderr.strip().splitlines():
        click.echo(f"  {line}")

    fixed, random = [], []
    reader = csv.DictReader(sio.StringIO(result.stdout))
    for row in reader:
        fixed.append(int(row["fixed_ns"]))
        random.append(int(row["random_ns"]))

    fixed_arr  = np.array(fixed,  dtype=float)
    random_arr = np.array(random, dtype=float)
    p95_f = np.percentile(fixed_arr,  95)
    p95_r = np.percentile(random_arr, 95)
    fixed_arr  = fixed_arr[fixed_arr   <= p95_f]
    random_arr = random_arr[random_arr <= p95_r]

    t_stat, _ = stats.ttest_ind(fixed_arr, random_arr, equal_var=False)
    delta = abs(np.mean(fixed_arr) - np.mean(random_arr))

    liboqs_decaps_delta = 37.0
    liboqs_encaps_delta = 264.0

    click.echo(f"\n{'='*55}")
    click.echo(f"  C-Level Noise Floor Results")
    click.echo(f"{'='*55}")
    click.echo(f"  AES-128 noise floor  : {delta:.1f}ns")
    click.echo(f"  liboqs Decaps delta  : {liboqs_decaps_delta:.0f}ns  ({liboqs_decaps_delta/delta:.1f}x above floor)")
    click.echo(f"  liboqs Encaps delta  : {liboqs_encaps_delta:.0f}ns  ({liboqs_encaps_delta/delta:.1f}x above floor)")
    click.echo(f"{'='*55}\n")


# ─────────────────────────────────────────────
#  compare command
# ─────────────────────────────────────────────

@cli.command()
@click.option("--traces",    default=10000,    show_default=True)
@click.option("--output",    default="compare")
@click.option("--open-html", is_flag=True)
@click.option("--pin-cpu",   is_flag=True)
@click.option("--no-exit",   is_flag=True)
def compare(traces, output, open_html, pin_cpu, no_exit):
    """Compare ML-KEM vs ML-DSA side by side."""

    click.echo("\n" + "="*55)
    click.echo("  PQC Scanner -- Algorithm Comparison")
    click.echo("  ML-KEM-768  vs  ML-DSA-65")
    click.echo("="*55)

    if pin_cpu:
        pin_to_core(0)

    analyzer = TimingAnalyzer(num_traces=traces)

    click.echo("\n[1/2] Scanning ML-KEM-768...")
    kem = MLKEMTarget()
    kem_ops = [
        ("Decapsulation", kem.decapsulate_fixed, kem.decapsulate_random),
        ("Encapsulation", kem.encapsulate_fixed, kem.encapsulate_random),
        ("KeyGen",        kem.keygen_repeated,   kem.keygen_repeated),
    ]
    kem_results = {}
    for name, fixed_fn, random_fn in kem_ops:
        click.echo(f"  -> {name}")
        r = analyzer.analyze(name, fixed_fn, random_fn)
        kem_results[name] = r
        click.echo(f"     t={r.t_statistic}  [{r.verdict}]")

    click.echo("\n[2/2] Scanning ML-DSA-65...")
    dsa = MLDSATarget()
    dsa_ops = [
        ("Sign",   dsa.sign_fixed,      dsa.sign_random),
        ("Verify", dsa.verify_fixed,    dsa.verify_random),
        ("KeyGen", dsa.keygen_repeated, dsa.keygen_repeated),
    ]
    dsa_results = {}
    for name, fixed_fn, random_fn in dsa_ops:
        click.echo(f"  -> {name}")
        r = analyzer.analyze(name, fixed_fn, random_fn)
        dsa_results[name] = r
        click.echo(f"     t={r.t_statistic}  [{r.verdict}]")

    html = _build_compare_html(kem_results, dsa_results, traces)
    html_path = f"{output}.html"
    json_path = f"{output}.json"

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)

    compare_data = {
        "scanner": "pqc-scanner v1.1.2",
        "mode": "compare",
        "traces_per_op": traces,
        "ml_kem": {
            op: {"t": r.t_statistic, "leaking": bool(r.leaking),
                 "severity": r.severity, "delta_ns": r.difference_ns}
            for op, r in kem_results.items()
        },
        "ml_dsa": {
            op: {"t": r.t_statistic, "leaking": bool(r.leaking),
                 "severity": r.severity, "delta_ns": r.difference_ns}
            for op, r in dsa_results.items()
        }
    }
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(compare_data, f, indent=2)

    any_leaking = any(r.leaking for r in list(kem_results.values()) + list(dsa_results.values()))

    click.echo(f"\n{'='*55}")
    click.echo(f"  COMPARISON COMPLETE")
    click.echo(f"  JSON : {json_path}")
    click.echo(f"  HTML : {html_path}")
    click.echo(f"{'='*55}\n")

    if open_html:
        webbrowser.open(os.path.abspath(html_path))

    if not no_exit and any_leaking:
        sys.exit(1)


# ─────────────────────────────────────────────
#  liboqs command
# ─────────────────────────────────────────────

@cli.command()
@click.option("--traces",    default=100000,   show_default=True)
@click.option("--output",    default="liboqs")
@click.option("--open-html", is_flag=True)
@click.option("--no-exit",   is_flag=True)
@click.option("--format", "fmt", default="html",
              type=click.Choice(["html", "sarif"]),
              show_default=True)
def liboqs(traces, output, open_html, no_exit, fmt):
    """
    Scan liboqs ML-KEM-768 using C harness with CLOCK_MONOTONIC_RAW.
    Production scan against the real library used by AWS, Cloudflare, Microsoft.
    """
    from pqc_scanner.targets.liboqs_target import LiboqsTarget
    from pqc_scanner.scanner.timing import TVLAResult

    click.echo("\n" + "="*55)
    click.echo("  PQC Scanner -- liboqs Production Scan")
    click.echo("  Target: liboqs ML-KEM-768 (C / CLOCK_MONOTONIC_RAW)")
    click.echo(f"  Traces: {traces:,}")
    click.echo("="*55)

    try:
        target = LiboqsTarget(num_traces=traces)
    except FileNotFoundError as e:
        click.echo(f"\n  ERROR: {e}")
        return

    timing_results = []
    raw_traces = {}
    any_leaking = False

    for mode, label in [("decaps", "ML-KEM Decapsulation"),
                         ("encaps", "ML-KEM Encapsulation")]:
        click.echo(f"\n  -> {label}")

        if mode == "decaps":
            fixed, random = target.run_decaps()
        else:
            fixed, random = target.run_encaps()

        fixed_arr  = np.array(fixed,  dtype=float)
        random_arr = np.array(random, dtype=float)
        p95_f = np.percentile(fixed_arr,  95)
        p95_r = np.percentile(random_arr, 95)
        fixed_arr  = fixed_arr[fixed_arr   <= p95_f]
        random_arr = random_arr[random_arr <= p95_r]

        t_stat, p_value = stats.ttest_ind(fixed_arr, random_arr, equal_var=False)
        abs_t   = abs(t_stat)
        leaking = abs_t > 4.5
        if leaking:
            any_leaking = True

        severity = "CRITICAL" if abs_t > 10 else ("HIGH" if abs_t > 4.5 else "PASS")
        verdict  = "LEAK DETECTED" if leaking else "PASS"
        delta    = abs(np.mean(fixed_arr) - np.mean(random_arr))

        click.echo(f"     [{verdict}]  t={t_stat:.4f}  |  delta={delta:.0f}ns  |  p={p_value:.2e}")

        result = TVLAResult(
            operation=label,
            t_statistic=round(t_stat, 4),
            p_value=round(p_value, 8),
            leaking=leaking,
            severity=severity,
            fixed_mean_ns=round(float(np.mean(fixed_arr)), 1),
            random_mean_ns=round(float(np.mean(random_arr)), 1),
            difference_ns=round(float(delta), 1),
            num_traces=len(fixed_arr),
            verdict=verdict,
            fixed_times=fixed_arr.tolist()[:500],
            random_times=random_arr.tolist()[:500]
        )
        timing_results.append(result)
        raw_traces[label] = {
            "fixed":   result.fixed_times,
            "random":  result.random_times,
            "verdict": verdict
        }

    reporter = ReportGenerator()
    report = reporter.build_with_traces(
        timing_results, [], "liboqs ML-KEM-768 (C / CLOCK_MONOTONIC_RAW)", raw_traces
    )
    save_reports(report, output, open_html, exit_on_findings=False)

    if fmt == "sarif":
        from pqc_scanner.scanner.sarif import save_sarif
        findings_list = [
            {
                "operation":     r.operation,
                "leaking":       r.leaking,
                "severity":      r.severity,
                "t_statistic":   r.t_statistic,
                "p_value":       r.p_value,
                "difference_ns": r.difference_ns,
                "num_traces":    r.num_traces,
            }
            for r in timing_results
        ]
        sarif_path = save_sarif(findings_list, "liboqs ML-KEM-768", output)
        click.echo(f"  SARIF    : {sarif_path}")

    if not no_exit and any_leaking:
        sys.exit(1)


# ─────────────────────────────────────────────
#  derand command (RNG root cause isolation)
# ─────────────────────────────────────────────

@cli.command()
@click.option("--traces",    default=100000,   show_default=True)
@click.option("--output",    default="derand")
@click.option("--open-html", is_flag=True)
def derand(traces, output, open_html):
    """
    RNG root cause isolation for ML-KEM encapsulation leak.
    Bypasses OS RNG using encaps_derand() with a fixed seed.
    PASS = leak is RNG-induced (not algorithmic).
    LEAK = leak is algorithmic (stronger finding).
    Run pqc-scanner liboqs first to confirm the normal scan leaks.
    """
    import csv
    import io as sio

    # Look for harness binaries relative to project root
    harness_dir  = os.path.abspath(os.path.join(os.path.expanduser("~"), "pqc-scanner", "harness"))
    portable_bin = os.path.join(harness_dir, "ml_kem_harness_derand")
    avx2_bin     = os.path.join(harness_dir, "ml_kem_harness_derand_avx2")
    avx2_lib     = os.path.expanduser("~/liboqs-avx2-install/lib")

    click.echo("\n" + "="*55)
    click.echo("  PQC Scanner -- Derand Root Cause Analysis")
    click.echo("  Target: ML-KEM-768 encaps_derand (RNG bypassed)")
    click.echo(f"  Traces: {traces:,}")
    click.echo("="*55)
    click.echo("  Purpose: Distinguish RNG-induced vs algorithmic leak")
    click.echo("  Method : Fixed seed passed to encaps_derand(), no OS RNG call")

    configs = [
        (portable_bin, "Portable C (no AVX2)", None),
        (avx2_bin,     "AVX2",                 {"LD_LIBRARY_PATH": avx2_lib}),
    ]

    results = []

    for binary, label, extra_env in configs:
        click.echo(f"\n  -> {label}")

        if not os.path.exists(binary):
            click.echo(f"     Binary not found: {binary}")
            click.echo(f"     Build with:")
            click.echo(f"     gcc -O2 -o {binary} harness/ml_kem_harness_derand.c -I/usr/local/include -L/usr/local/lib -loqs -lm")
            results.append({"label": label, "status": "not_found"})
            continue

        run_env = os.environ.copy()
        if extra_env:
            run_env.update(extra_env)

        ret = subprocess.run(
            [binary, str(traces)],
            capture_output=True, text=True, timeout=600, env=run_env
        )

        for line in ret.stderr.strip().splitlines():
            click.echo(f"    {line}")

        if ret.returncode != 0:
            click.echo(f"     ERROR: {ret.stderr[:200]}")
            results.append({"label": label, "status": "error"})
            continue

        fixed_ns, random_ns = [], []
        reader = csv.DictReader(sio.StringIO(ret.stdout))
        for row in reader:
            fixed_ns.append(int(row["fixed_ns"]))
            random_ns.append(int(row["random_ns"]))

        fa = np.array(fixed_ns,  dtype=float)
        ra = np.array(random_ns, dtype=float)
        fa = fa[fa <= np.percentile(fa, 95)]
        ra = ra[ra <= np.percentile(ra, 95)]

        t_stat, p_value = stats.ttest_ind(fa, ra, equal_var=False)
        delta   = abs(np.mean(fa) - np.mean(ra))
        leaking = abs(t_stat) > 4.5
        verdict = "LEAK DETECTED" if leaking else "PASS"

        click.echo(f"     [{verdict}]  t={t_stat:.4f}  |  delta={delta:.0f}ns  |  p={p_value:.2e}")

        results.append({
            "label":    label,
            "status":   "ok",
            "t":        round(float(t_stat), 4),
            "delta_ns": round(float(delta), 1),
            "p_value":  round(float(p_value), 8),
            "leaking":  bool(leaking),
            "verdict":  verdict,
            "traces":   len(fa)
        })

    # Interpretation
    ok_results = [r for r in results if r.get("status") == "ok"]
    all_pass   = ok_results and all(not r["leaking"] for r in ok_results)
    all_leak   = ok_results and all(r["leaking"]     for r in ok_results)

    click.echo(f"\n{'='*55}")
    click.echo("  ROOT CAUSE INTERPRETATION")
    click.echo(f"{'='*55}")

    if all_pass:
        click.echo("  VERDICT: RNG-INDUCED LEAK")
        click.echo("  Both derand builds PASS. The timing signal seen in the")
        click.echo("  normal scan originates from OQS_randombytes() variable")
        click.echo("  timing, NOT from secret-dependent branches in ML-KEM.")
        click.echo("  Fix: Use OQS_KEM_encaps_derand() with a pre-seeded DRBG.")
    elif all_leak:
        click.echo("  VERDICT: ALGORITHMIC LEAK")
        click.echo("  Both derand builds LEAK even without RNG. The timing")
        click.echo("  signal is in the cryptographic core itself.")
        click.echo("  This is a stronger finding -- report to security@openquantumsafe.org")
    else:
        click.echo("  VERDICT: MIXED / INCONCLUSIVE")
        click.echo("  Results differ between builds. Further analysis needed.")

    click.echo(f"{'='*55}\n")

    # Save JSON
    json_path = f"{output}.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({
            "scanner":      "pqc-scanner v1.1.2",
            "mode":         "derand",
            "traces":       traces,
            "description":  "RNG root cause isolation for ML-KEM encapsulation",
            "results":      results,
            "verdict":      "RNG-INDUCED" if all_pass else ("ALGORITHMIC" if all_leak else "INCONCLUSIVE")
        }, f, indent=2)

    click.echo(f"  JSON : {json_path}")


# ─────────────────────────────────────────────
#  compiler-sweep command
# ─────────────────────────────────────────────

@cli.command(name="compiler-sweep")
@click.option("--traces",  default=50000,  show_default=True)
@click.option("--runs",    default=3,      show_default=True)
@click.option("--output",  default="compiler_sweep")
def compiler_sweep(traces, runs, output):
    """
    Build the C harness with multiple compiler flags and scan each.
    Each config is run --runs times and the median t-statistic reported.
    """
    import csv
    import io as sio

    click.echo("\n" + "="*55)
    click.echo("  PQC Scanner -- Compiler Flag Sweep")
    click.echo(f"  {runs} runs per config, median t reported")
    click.echo("="*55)

    configs = [
        ("gcc",   "-O0",               "gcc -O0 (no optimization)"),
        ("gcc",   "-O2",               "gcc -O2 (standard)"),
        ("gcc",   "-O3",               "gcc -O3 (aggressive)"),
        ("gcc",   "-O3 -march=native", "gcc -O3 -march=native"),
        ("clang", "-O2",               "clang -O2"),
        ("clang", "-O3",               "clang -O3"),
    ]

    sweep_results = []
    harness_dir = os.path.join(os.path.dirname(__file__), "harness")
    src = os.path.join(harness_dir, "ml_kem_harness.c")

    for compiler, flags, label in configs:
        safe   = flags.replace(" ", "_").replace("-", "")
        binary = os.path.join(harness_dir, f"harness_{compiler}_{safe}")

        click.echo(f"\n[Building] {label}")
        ret = subprocess.run(
            f"{compiler} {flags} -o {binary} {src} -loqs -lssl -lcrypto",
            shell=True, capture_output=True, text=True
        )

        if ret.returncode != 0:
            click.echo(f"  Build failed: {ret.stderr[:200]}")
            sweep_results.append({
                "label": label, "status": "build_failed",
                "t": None, "verdict": "BUILD FAILED"
            })
            continue

        all_fixed, all_random = [], []
        failed = False

        for run_i in range(runs):
            click.echo(f"  Run {run_i+1}/{runs} ({traces:,} traces)...")
            run_ret = subprocess.run(
                [binary, str(traces), "decaps"],
                capture_output=True, text=True, timeout=600
            )
            if run_ret.returncode != 0:
                failed = True
                break
            reader = csv.DictReader(sio.StringIO(run_ret.stdout))
            for row in reader:
                all_fixed.append(int(row["fixed_ns"]))
                all_random.append(int(row["random_ns"]))

        if failed:
            sweep_results.append({
                "label": label, "status": "run_failed",
                "t": None, "verdict": "RUN FAILED"
            })
            os.remove(binary)
            continue

        fa = np.array(all_fixed,  dtype=float)
        ra = np.array(all_random, dtype=float)
        fa = fa[fa <= np.percentile(fa, 95)]
        ra = ra[ra <= np.percentile(ra, 95)]

        rng = np.random.default_rng(42)
        t_samples = []
        for _ in range(5):
            idx_f = rng.integers(0, len(fa), len(fa))
            idx_r = rng.integers(0, len(ra), len(ra))
            t_s, _ = stats.ttest_ind(fa[idx_f], ra[idx_r], equal_var=False)
            t_samples.append(t_s)

        t_stat       = float(np.median(t_samples))
        delta        = abs(np.mean(fa) - np.mean(ra))
        leaking      = abs(t_stat) > 4.5
        verdict      = "LEAK DETECTED" if leaking else "PASS"
        inconclusive = delta < 50.0

        note = " *inconclusive (delta < 50ns)" if inconclusive else ""
        click.echo(f"  [{verdict}]  t={t_stat:.4f}  delta={delta:.1f}ns{note}")

        sweep_results.append({
            "label":        label,
            "status":       "ok",
            "t":            round(t_stat, 4),
            "leaking":      bool(leaking),
            "verdict":      verdict,
            "delta_ns":     round(float(delta), 1),
            "inconclusive": bool(inconclusive),
            "runs":         runs,
            "total_traces": len(fa) + len(ra)
        })

        os.remove(binary)

    json_path = f"{output}.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump({
            "scanner": "pqc-scanner v1.1.2",
            "mode": "compiler_sweep",
            "traces_per_run": traces,
            "runs_per_config": runs,
            "results": sweep_results
        }, f, indent=2)

    click.echo(f"\n{'='*55}")
    click.echo(f"  COMPILER SWEEP COMPLETE")
    click.echo(f"{'='*55}")
    for r in sweep_results:
        if r["t"] is None:
            click.echo(f"  [FAIL ]  {'N/A':<12}  {r['label']}")
        else:
            marker = "LEAK " if r.get("leaking") else "PASS "
            flag   = "*" if r.get("inconclusive") else " "
            click.echo(f"  [{marker}]{flag} t={r['t']:<10}  delta={r['delta_ns']:.1f}ns  {r['label']}")

    click.echo(f"\n  Results saved to {json_path}\n")


# ─────────────────────────────────────────────
#  Compare HTML builder
# ─────────────────────────────────────────────

def _build_compare_html(kem_results: dict, dsa_results: dict, traces: int) -> str:

    def row_color(r):
        if r.severity == "CRITICAL": return "#ff4444"
        if r.severity == "HIGH":     return "#ff8800"
        return "#3fb950"

    def build_table(results: dict, label: str) -> str:
        rows = ""
        for op, r in results.items():
            color = row_color(r)
            icon  = "LEAK" if r.leaking else "PASS"
            rows += f"""
            <tr>
              <td>{op}</td>
              <td style="color:{color};font-weight:bold">{icon}</td>
              <td>{r.t_statistic}</td>
              <td>{r.difference_ns:,.0f} ns</td>
              <td>{r.severity}</td>
            </tr>"""
        return f"""
        <div class="table-wrap">
          <h3>{label}</h3>
          <table>
            <thead>
              <tr>
                <th>Operation</th><th>Verdict</th><th>t-statistic</th>
                <th>Delta</th><th>Severity</th>
              </tr>
            </thead>
            <tbody>{rows}</tbody>
          </table>
        </div>"""

    kem_table = build_table(kem_results, "ML-KEM-768 (Key Encapsulation)")
    dsa_table = build_table(dsa_results, "ML-DSA-65 (Digital Signature)")

    all_labels = json.dumps(
        [f"KEM: {op}" for op in kem_results] +
        [f"DSA: {op}" for op in dsa_results]
    )
    all_t_vals = json.dumps(
        [abs(r.t_statistic) for r in kem_results.values()] +
        [abs(r.t_statistic) for r in dsa_results.values()]
    )
    all_colors = json.dumps(
        ["rgba(88,166,255,0.8)"] * len(kem_results) +
        ["rgba(255,130,0,0.8)"]  * len(dsa_results)
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PQC Scanner -- Comparison</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: 'Segoe UI', monospace; background: #0d1117; color: #c9d1d9; padding: 2rem; }}
    h1 {{ color: #58a6ff; font-size: 1.5rem; margin-bottom: 0.2rem; }}
    .subtitle {{ color: #8b949e; font-size: 0.85rem; margin-bottom: 2rem; }}
    h2 {{ color: #58a6ff; font-size: 1.1rem; margin: 1.5rem 0 1rem; }}
    h3 {{ color: #c9d1d9; font-size: 0.95rem; margin-bottom: 0.75rem; }}
    .grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 2rem; }}
    .table-wrap {{ background: #161b22; border-radius: 8px; padding: 1.25rem; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
    th {{ color: #8b949e; text-align: left; padding: 6px 8px;
          border-bottom: 1px solid #30363d; font-weight: normal;
          text-transform: uppercase; font-size: 0.75rem; }}
    td {{ padding: 8px; border-bottom: 1px solid #21262d; }}
    .chart-card {{ background: #161b22; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem; }}
    .threshold-note {{ color: #8b949e; font-size: 0.78rem; margin-top: 0.75rem; }}
    .legend {{ display: flex; gap: 1.5rem; margin-bottom: 1rem; font-size: 0.82rem; }}
    .legend-dot {{ width: 12px; height: 12px; border-radius: 2px;
                   display: inline-block; margin-right: 6px; vertical-align: middle; }}
  </style>
</head>
<body>
  <h1>PQC Side-Channel Scanner -- Comparison</h1>
  <div class="subtitle">
    ML-KEM-768 vs ML-DSA-65 &nbsp;|&nbsp;
    {traces:,} traces per operation &nbsp;|&nbsp;
    TVLA threshold: |t| &gt; 4.5 &nbsp;|&nbsp;
    pqc-scanner v1.1.2
  </div>
  <h2>t-Statistic Comparison</h2>
  <div class="chart-card">
    <div class="legend">
      <span><span class="legend-dot" style="background:rgba(88,166,255,0.8)"></span>ML-KEM-768</span>
      <span><span class="legend-dot" style="background:rgba(255,130,0,0.8)"></span>ML-DSA-65</span>
    </div>
    <canvas id="compareChart" height="120"></canvas>
    <div class="threshold-note">Red dashed line = TVLA threshold (|t| = 4.5).</div>
  </div>
  <h2>Results</h2>
  <div class="grid">{kem_table}{dsa_table}</div>
  <script>
    var ctx = document.getElementById('compareChart').getContext('2d');
    new Chart(ctx, {{
      type: 'bar',
      data: {{
        labels: {all_labels},
        datasets: [{{ label: '|t|', data: {all_t_vals},
          backgroundColor: {all_colors}, borderWidth: 1 }}]
      }},
      options: {{
        responsive: true,
        plugins: {{ legend: {{ display: false }} }},
        scales: {{
          x: {{ ticks: {{ color: '#8b949e' }}, grid: {{ color: '#21262d' }} }},
          y: {{ ticks: {{ color: '#8b949e' }}, grid: {{ color: '#21262d' }},
               title: {{ display: true, text: '|t-statistic|', color: '#8b949e' }} }}
        }}
      }}
    }});
  </script>
</body>
</html>"""


if __name__ == "__main__":
    cli()


def main():
    cli()
