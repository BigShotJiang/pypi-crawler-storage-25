#!/bin/bash
# Builds the C timing harnesses after pip install
# Called automatically by pqc-scanner on first run

HARNESS_DIR="$(dirname "$0")"

echo "[*] Building C harnesses..."

gcc -O2 -o "$HARNESS_DIR/ml_kem_harness" \
    "$HARNESS_DIR/ml_kem_harness.c" \
    -loqs -lssl -lcrypto

if [ $? -eq 0 ]; then
    echo "[*] ml_kem_harness built successfully"
else
    echo "[!] Failed to build ml_kem_harness"
    echo "[!] Make sure liboqs is installed: https://github.com/Disha23112004/pqc-scanner#installation"
    exit 1
fi

gcc -O2 -o "$HARNESS_DIR/baseline_harness" \
    "$HARNESS_DIR/baseline_harness.c" \
    -lssl -lcrypto

if [ $? -eq 0 ]; then
    echo "[*] baseline_harness built successfully"
else
    echo "[!] Failed to build baseline_harness"
    exit 1
fi

echo "[*] All harnesses built."
