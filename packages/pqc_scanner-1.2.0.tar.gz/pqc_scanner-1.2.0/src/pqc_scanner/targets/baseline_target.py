import hashlib
import os

class BaselineTarget:
    """
    Constant-time baseline using SHA-256.

    Random messages are PRE-GENERATED at init so os.urandom()
    does not contaminate the timed measurement window.

    Without this fix, hash_random = urandom() + hash() while
    hash_fixed = hash() only -- the urandom syscall perturbs
    the scheduler and produces a false timing difference in WSL.

    This target should always PASS (t near 0).
    If it fails, your measurement environment has too much noise.
    """

    FIXED_MSG = b"a" * 64

    def __init__(self):
        print("  [*] Pre-generating baseline random messages...")
        self.random_msgs = [os.urandom(64) for _ in range(12000)]
        self._idx = 0
        print("  [*] Baseline ready.")

    def hash_fixed(self):
        hashlib.sha256(self.FIXED_MSG).digest()

    def hash_random(self):
        msg = self.random_msgs[self._idx % len(self.random_msgs)]
        self._idx += 1
        hashlib.sha256(msg).digest()
