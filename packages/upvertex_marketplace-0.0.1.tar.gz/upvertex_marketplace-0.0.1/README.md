# upvertex-marketplace

Namespace reservation for UpVertex Inc. (www.upvertex.com)