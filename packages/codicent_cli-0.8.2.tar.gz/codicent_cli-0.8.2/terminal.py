"""
codicent terminal — web terminal host

Spawns a local shell process and registers it as a terminal session on the
Codicent server.  Browser users can then connect to it via the web UI.

Usage:
  codicent terminal [shell]   # shell defaults to $SHELL or bash

The CLI tool:
  1. Spawns the shell locally via PTY (or subprocess on Windows)
  2. Connects to /terminal/host on the Codicent server via WebSocket
  3. Relays PTY I/O <-> WebSocket in real time
  4. Session output is logged to Codicent as #terminal-session when it ends
"""

import os
import sys
import threading
import signal
import uuid
import logging

try:
    import websocket as websocket_client  # websocket-client library
    _HAS_WS = True
except ImportError:
    _HAS_WS = False

# PTY support (Linux/macOS/WSL); falls back to subprocess on Windows
try:
    import pty
    import termios
    import fcntl
    import struct
    _HAS_PTY = True
except ImportError:
    _HAS_PTY = False

logger = logging.getLogger(__name__)


def _get_terminal_size():
    try:
        import shutil
        sz = shutil.get_terminal_size()
        return sz.columns, sz.lines
    except Exception:
        return 80, 24


def run_terminal_host(token: str, base_url: str, project: str, shell: str = None):
    """Start a local shell and host it as a Codicent terminal session."""

    if not _HAS_WS:
        print("[error] websocket-client is required: pip install websocket-client", file=sys.stderr)
        sys.exit(1)

    shell = shell or os.environ.get("SHELL", "bash")
    session_id = uuid.uuid4().hex

    # Build WebSocket URL
    ws_base = base_url.rstrip("/").replace("https://", "wss://").replace("http://", "ws://")
    ws_url = (
        f"{ws_base}/terminal/host"
        f"?project={project}"
        f"&command={os.path.basename(shell)}"
        f"&sessionId={session_id}"
        f"&access_token={token}"
    )

    print(f"[codicent terminal] project=@{project}  shell={shell}  session={session_id}")
    print(f"[codicent terminal] Connecting to {base_url} ...")

    stop_event = threading.Event()
    ws_app = None

    # ── PTY-based (POSIX) ─────────────────────────────────────────────
    if _HAS_PTY:
        cols, rows = _get_terminal_size()

        # Fork a PTY
        pid, fd = pty.fork()

        if pid == 0:
            # Child: exec the shell
            env = os.environ.copy()
            env["TERM"] = "xterm-256color"
            os.execvpe(shell, [shell, "-i"], env)
            sys.exit(1)

        # Parent: relay PTY <-> WebSocket

        def _set_pty_size(c, r):
            try:
                import struct, termios, fcntl
                fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", r, c, 0, 0))
            except Exception:
                pass

        _set_pty_size(cols, rows)

        def on_open(ws):
            print("[codicent terminal] Connected. Shell is ready in the browser.")
            # Send initial resize
            import json
            ws.send(json.dumps({"type": "resize", "cols": cols, "rows": rows}))

        def on_message(ws, message):
            # Incoming from browser: either resize JSON or raw stdin
            try:
                import json
                obj = json.loads(message)
                if obj.get("type") == "resize":
                    _set_pty_size(obj.get("cols", 80), obj.get("rows", 24))
                    return
            except (ValueError, KeyError):
                pass
            # Write to PTY stdin
            try:
                os.write(fd, message.encode() if isinstance(message, str) else message)
            except OSError:
                ws.close()

        def on_error(ws, error):
            print(f"[codicent terminal] WebSocket error: {error}", file=sys.stderr)

        def on_close(ws, code, reason):
            print(f"[codicent terminal] Disconnected ({code}). Session ended.")
            stop_event.set()

        ws_app = websocket_client.WebSocketApp(
            ws_url,
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
        )

        # Thread: read PTY output and forward to WebSocket
        def _pty_reader():
            import select as sel
            while not stop_event.is_set():
                try:
                    r, _, _ = sel.select([fd], [], [], 0.05)
                    if not r:
                        continue
                    data = os.read(fd, 4096)
                    if not data:
                        break
                    if ws_app.sock and ws_app.sock.connected:
                        ws_app.send(data.decode("utf-8", errors="replace"))
                except OSError:
                    break
                except Exception as e:
                    logger.debug(f"PTY reader: {e}")
            stop_event.set()
            if ws_app.sock:
                ws_app.close()

        t = threading.Thread(target=_pty_reader, daemon=True)
        t.start()

        def _sigchld_handler(signum, frame):
            stop_event.set()

        signal.signal(signal.SIGCHLD, _sigchld_handler)

        ws_app.run_forever()

        # Clean up child process
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass

    # ── Subprocess-based (Windows fallback) ──────────────────────────
    else:
        import subprocess
        import queue

        proc = subprocess.Popen(
            [shell],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )

        output_queue: queue.Queue = queue.Queue()

        def _stdout_reader():
            while True:
                chunk = proc.stdout.read(4096)
                if not chunk:
                    break
                output_queue.put(chunk.decode("utf-8", errors="replace"))
            stop_event.set()

        threading.Thread(target=_stdout_reader, daemon=True).start()

        def on_open(ws):
            print("[codicent terminal] Connected.")

            # Thread: drain queue -> WebSocket
            def _sender():
                while not stop_event.is_set():
                    try:
                        text = output_queue.get(timeout=0.05)
                        if ws.sock and ws.sock.connected:
                            ws.send(text)
                    except queue.Empty:
                        continue
                    except Exception:
                        break

            threading.Thread(target=_sender, daemon=True).start()

        def on_message(ws, message):
            try:
                import json
                obj = json.loads(message)
                if obj.get("type") == "resize":
                    return  # resize not applicable without PTY
            except (ValueError, KeyError):
                pass
            try:
                proc.stdin.write((message if isinstance(message, bytes) else message.encode()))
                proc.stdin.flush()
            except OSError:
                ws.close()

        def on_error(ws, error):
            print(f"[codicent terminal] WebSocket error: {error}", file=sys.stderr)

        def on_close(ws, code, reason):
            print("[codicent terminal] Disconnected.")
            stop_event.set()
            proc.terminate()

        ws_app = websocket_client.WebSocketApp(
            ws_url,
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
        )
        ws_app.run_forever()
