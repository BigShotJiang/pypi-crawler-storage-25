from setuptools import setup
from Cython.Build import cythonize

setup(
    name="datasci-ajay",
    version="0.5",
    # ext_modules=cythonize("datasci/eda.py"),
    packages=["datasci"],

    install_requires=[
        "numpy",
        "pandas",
        "matplotlib",
        "seaborn"
    ],

    package_data={
        "datasci": ["*.pyd"]
    },

    include_package_data=True,

    author="Ajay Sah",
    description="EDA + Data Science utilities",
)