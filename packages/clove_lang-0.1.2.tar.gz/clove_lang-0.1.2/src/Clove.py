from lark import Lark
from src.ast_nodes import CloveTransformer
from src.compiler import Compiler
from src.preprocessor import Preprocessor
import sys
import lark
import time
import argparse
from pathlib import Path
import secrets

class Clove:
    def __init__(self, source="", stdlib="CLV_STD", filename="RAND"):
        self.grammarpath = Path(__file__).resolve().parent / "Lang_Internals" / "grammar.lark"
        self.file=filename
        self.raw = source.strip().strip('\u200b').strip('\u00a0')
        self.source = Preprocessor().preprocess(source)
        self.stdlib = stdlib

    def transpile(self):
        try:
            with open(self.grammarpath, "r") as f:
                grammar = f.read()
            parser = Lark(grammar, start="start", parser="lalr", debug=True)
            _ = parser.parse(self.raw)
            raw = parser.parse(self.source)
            
            transformer = CloveTransformer()
            clove_ast = transformer.transform(raw)
            
            compiler = Compiler()
            final = compiler.compile(clove_ast)

            if self.file.lower().strip() == "rand":
                random_id = str(time.time() / secrets.choice(range(36000, 864000)))
                filename = f"{random_id}"
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(final)
            elif self.file.lower().strip() == "none":
                return final
            else:
                file = f"{self.file.removesuffix('.py')}.py"
                with open(file, "w", encoding="utf-8") as f:
                    f.write(final)
            return final
        except FileNotFoundError as e:
            print(e)
            sys.exit(1)
        except lark.exceptions.UnexpectedCharacters as e:
            print(f"\033[31mClove Error\033[0m : {e}")
            sys.exit(1)
        except lark.exceptions.UnexpectedToken as e:
            print(f"\033[31mClove Error\033[0m : {e}")
            sys.exit(1)
        except Exception as e:
            print(f"\033[31mClove Error\033[0m : {e}")
            sys.exit(1)

def main():
    parser = argparse.ArgumentParser(
        description="[\033[32mClove\033[0m Transpiler] - Compile or run Clove files."
    )
    
    parser.add_argument("input", type=str, help="The input file to process.")

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "-o", "--output", type=str, help="Compile and save to an output file path."
    )
    group.add_argument(
        "-r",
        "--run",
        action="store_true",
        help="Transpile and immediately run the Clove file.",
    )

    args = parser.parse_args()
    input_path = Path(args.input)

    if not input_path.exists():
        print(
            f"[\033[31mClove Transpiler Error\033[0m] : Input file '{input_path}' does not exist."
        )
        sys.exit(1)

    try:
        with open(input_path, "r") as f:
            source_code = f.read()

        if args.output:
            output_path = f"{args.output.removesuffix('.py')}.py"
            clove = Clove(source_code, filename=output_path)
            clove.transpile()
            print(
                f"[\033[32mClove\033[0m Transpiler] : Successfully compiled to {Path(output_path).absolute()}"
            )
            sys.exit(0)
        elif args.run:

            clove = Clove(source_code, filename=f"none")

            transpiled_code = clove.transpile()

            print(f"[\033[32mClove\033[0m Transpiler] : Running {input_path.name}...\n---")
            exec(transpiled_code, {"__name__": "__main__"})

            sys.exit(0)

    except Exception as e:
        print(f"[\033[31mError\033[0m] : Operation failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()