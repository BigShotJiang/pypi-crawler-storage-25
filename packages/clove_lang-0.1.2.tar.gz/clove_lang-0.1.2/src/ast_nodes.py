from lark import Transformer, Token
import lark

class ASTNode:
    pass

class ProgramNode(ASTNode):
    def __init__(self, decls) -> None:
        self.declarations = decls

class ExternDeclNode(ASTNode):
    def __init__(self, module_name):
        self.module_name = module_name.strip('"')

class IncludeDeclNode(ASTNode):
    def __init__(self, file_path):
        self.file_path = file_path.strip('"')

class FnDeclNode(ASTNode):
    def __init__(self, name, params, statements):
        self.name = name
        self.params = params
        self.statements = statements

class VarDeclNode(ASTNode):
    def __init__(self, name, expr):
        self.name = name
        self.expr = expr

class ReturnNode(ASTNode):
    def __init__(self, expr):
        self.expr = expr

class VarAsgnNode(ASTNode):
    def __init__(self, name, expr):
        self.name = name
        self.expr = expr

class FnCallNode(ASTNode):
    def __init__(self, name, args):
        self.name = name
        self.args = args
class InputExprNode(ASTNode):
    def __init__(self, prompt_expr=None):
        self.prompt_expr = prompt_expr

class ExecExprNode(ASTNode):
    def __init__(self, code=None):
        self.code = code
class FStringNode(ASTNode):
    def __init__(self, val):
        self.val = val

class LiteralNode(ASTNode):
    def __init__(self, type_, value):
        self.type = type_
        self.value = value

class ExprListNode(ASTNode):
    def __init__(self, expressions):
        self.expressions = expressions

class ParamNode(ASTNode):
    def __init__(self, name, default_value=None):
        self.name = name
        self.default_value = default_value

class NamedArgNode(ASTNode):
    def __init__(self, name, expr):
        self.name = name
        self.expr = expr



class CloveTransformer(Transformer):
    def program(self, items):
        flattened_decls = []
        for item in items:
            if isinstance(item, list):
                flattened_decls.extend(item)
            elif item is not None:
                flattened_decls.append(item)
        return ProgramNode(flattened_decls)

    def expr(self, items):
        components = []
        for item in items:
            if hasattr(item, 'value'): 
                components.append(str(item.value))
            elif hasattr(item, 'val'):
                components.append(str(item.val))
            elif hasattr(item, 'value'):
                components.append(str(item.value))
            else:                    
                components.append(str(item))
        return LiteralNode("math", " ".join(components))

    def block(self, items):
        return items
    
    def exec_expr(self, items):
        code = items[0] if (items and items[0] is not None) else None
        return ExecExprNode(code=code)
    def extern_decl(self, items):
        return ExternDeclNode(items[0].value)

    def include_decl(self, items):
        return IncludeDeclNode(items[0].value)

    def var_decl(self, items):
        return VarDeclNode(name=items[0].value, expr=items[1])
        
    def var_asgn(self, items):
        if len(items) == 3:
            full_name = f"{items[0].value}.{items[1].value}"
            expr = items[2]
        else:
            full_name = items[0].value
            expr = items[1]
        return VarAsgnNode(name=full_name, expr=expr)

    def fn_decl(self, items):
        fn_name = items[0].value
        params = items[1] if items[1] is not None else []
        raw_statements = items[2] if len(items) > 2 and items[2] is not None else []
        
        if isinstance(raw_statements, list):
            statements = [stmt for stmt in raw_statements if stmt is not None]
        else:
            statements = [raw_statements] if raw_statements is not None else []
            
        return FnDeclNode(name=fn_name, params=params, statements=statements)

    def param_list(self, items):
        return items

    def param(self, items):
        name = items[0].value
        default = items[1] if len(items) > 1 else None
        return ParamNode(name, default)

    def return_stmt(self, items):
        return ReturnNode(expr=items[0])

    def fn_call(self, items):
        if items[0] is not None: 
            module = items[0].value
            name = items[1].value
            args = items[2] if items[2] is not None else []
            full_name = f"{module}.{name}"
        else:
            name = items[1].value
            args = items[2] if items[2] is not None else []
            full_name = name
            
        return FnCallNode(name=full_name, args=args)
    def arg_list(self, items):
        return items

    def arg(self, items):
        if len(items) == 2 and items[0] is not None:
            return NamedArgNode(name=items[0].value, expr=items[1])
        return items[-1]

    def f_string(self, items):
        return FStringNode(val=items[0].value)
    def input_expr(self, items):
        prompt = items[0] if (items and items[0] is not None) else None
        return InputExprNode(prompt_expr=prompt)

    def num(self, items):
        return LiteralNode("num", items[0].value)

    def str(self, items):
        return LiteralNode("str", items[0].value)

    def var(self, items):
        if items[0] is not None:
            full_var_path = f"{items[0].value}.{items[1].value}"
        else:
            full_var_path = items[1].value
            
        return LiteralNode("var", full_var_path)

    def expr_list(self, items):
        return ExprListNode(items)

    def statement(self, items):
        return items[0]

    def start(self, items):
        return items[0]