import json
import os

filep = os.path.join("compiler_flags", "Clover.json")

fallback = """
{
    "run": false,
    "output_settings": {
        "outputf": "RAND",
        "pyc": false
    }
}
"""

def get_settings():
    try:
        with open(filep, "r") as f:
            return json.load(f)
    except PermissionError:
        print("\033[33m[compiler_flags.py]\033[0m : Unable to open Clover.json, switching to fallback.")
        return json.loads(fallback)
    except json.JSONDecodeError:
        try:
            print("\033[33m[compiler_flags.py]\033[0m : Clover.json had an error, switching to to fallback.")
            return json.loads(fallback)
        except json.JSONDecodeError as e:
            raise Exception(f"\033[33m[compiler_flags.py]\033[0m : Unable to parse fallback JSON.\nError : {e}")
    except OSError as e:
        raise Exception(f"\033[33m[compiler_flags.py]\033[0m : OSError caught - {e}")
    except Exception as e:
        raise Exception(f"\033[33m[compiler_flags.py]\033[0m : General Exception caught - {e}")
        