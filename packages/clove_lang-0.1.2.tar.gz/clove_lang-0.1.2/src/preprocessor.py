import os
import re

class Preprocessor:
    def __init__(self, std_dir="CLV_STD"):
        self.std_dir = std_dir
        self.include_regex = re.compile(r'@include\s*\(\s*"([^"\\]*)"\s*\)\s*;')
    def preprocess(self, source, visited=None):
        if visited == None:
            visited = set()
        def replace_match(match):
            filename = match.group(1)

            if filename in visited:
                return f"# @include \"{filename}\" skipped to prevent infinite recursion.\n"
            visited.add(filename)
            if not filename.endswith(".clv"):
                filename += ".clv"
            filep = os.path.join(self.std_dir, filename)

            if not os.path.exists(filep):
                raise FileNotFoundError(
                    f"\033[31m[\033[32mClove\033[0m Preprocessor Error\033[31m]\033[0m : Could not find \033[35m{filename}\033[0m at {self.std_dir}."
                )
            
            with open(filep, "r", encoding="utf-8") as f:
                included_s = f.read()

            return f"\n# --- Start of {filename} ---\n" + \
                   self.preprocess(included_s, visited) + \
                   f"\n# --- End of {filename} ---\n" 
        return self.include_regex.sub(replace_match, source)
