header = """
# ===============================================================================================================
#     ░▒▓██████▓▒░░▒▓█▓▒░      ░▒▓██████▓▒░░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓████████▓▒░      ░▒▓█▓▒░ 
#    ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░             ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░░▒▓█▓▒░   ░▒▓████▓▒░ 
#    ░▒▓█▓▒░      ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒▒▓█▓▒░░▒▓█▓▒░              ░▒▓█▓▒▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░ 
#    ░▒▓█▓▒░      ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒▒▓█▓▒░░▒▓██████▓▒░         ░▒▓█▓▒▒▓█▓▒░░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░ 
#    ░▒▓█▓▒░      ░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▓█▓▒░ ░▒▓█▓▒░               ░▒▓█▓▓█▓▒░ ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░ 
#    ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░ ░▒▓█▓▓█▓▒░ ░▒▓█▓▒░               ░▒▓█▓▓█▓▒░ ░▒▓█▓▒░░▒▓█▓▒░▒▓██▓▒░▒▓█▓▒░ 
#     ░▒▓██████▓▒░░▒▓████████▓▒░▒▓██████▓▒░   ░▒▓██▓▒░  ░▒▓████████▓▒░         ░▒▓██▓▒░  ░▒▓████████▓▒░▒▓██▓▒░▒▓█▓▒░ 
#                                                                                                                    
# ================================================================================================================                                                                                                       
"""

class Compiler:
    def __init__(self):
        self.modules = set()
        self.indentl = 0

    def indent(self):
        return "    " * self.indentl

    def compile(self, node):
        method = f"gen_{type(node).__name__}"
        gen = getattr(self, method, self.generic_gen)
        return gen(node)
    
    def generic_gen(self, node):
        raise NotImplementedError(f"No compilation method defined for class '{type(node).__name__}'")
    
    def gen_ProgramNode(self, node):
        parts = []
        parts.append("# Created by the Clove Transpiler")
        parts.append(header)
        for decl in node.declarations:
            parts.append(self.compile(decl))
        parts.append('\nif __name__ == "__main__":')
        parts.append('    main()')
        return "\n".join(parts)

    def gen_ExternDeclNode(self, node):
        if node.module_name in self.modules:
            return ""
        self.modules.add(node.module_name)
        return f"import {node.module_name}"
    def gen_ExecExprNode(self, node):
        if node.code:
            return f"exec({self.compile(node.code)})"
        return ""

    def gen_ExprListNode(self, node):
        compiled_exprs = [self.compile(expr) for expr in node.expressions]
        return ", ".join(compiled_exprs)

    def gen_ReturnNode(self, node):
        return f"return {self.compile(node.expr)}"

    def gen_FnDeclNode(self, node):
        lines = []
        param_strs = []
        for p in node.params:
            if p.default_value:
                default_val = self.compile(p.default_value)
                param_strs.append(f"{p.name}={default_val}")
            else:
                param_strs.append(p.name)
        
        params_str = ", ".join(param_strs)
        lines.append(f"def {node.name}({params_str}):")
        
        self.indentl += 1
        if node.name == "main":
            lines.append(self.indent() + "try:")
            self.indentl += 1
            
            if not node.statements:
                lines.append(self.indent() + "pass")
            else:
                for stmt in node.statements:
                    compstmt = self.compile(stmt)
                    indented_lines = [self.indent() + line if line else "" for line in compstmt.split("\n")]
                    lines.append("\n".join(indented_lines))
            self.indentl -= 1
            lines.append(self.indent() + "except Exception as e:")
            lines.append(self.indent() + '    print(f"\\033[31mRuntime Error\\033[0m : Unexpected Exception - \\033[33m{e}\\033[0m")')
        else:
            if not node.statements:
                lines.append(self.indent() + "pass")
            else:
                for stmt in node.statements:
                    lines.append(self.indent() + self.compile(stmt))
        self.indentl -= 1
        return "\n".join(lines) + "\n"

    def gen_VarDeclNode(self, node):
        return f"{node.name} = {self.compile(node.expr)}"

    def gen_VarAsgnNode(self, node):
        return f"{node.name} = {self.compile(node.expr)}"

    def gen_FnCallNode(self, node):
        arg_strings = []
        for arg in node.args:
            arg_strings.append(self.compile(arg))
        
        args_str = ", ".join(arg_strings)
        return f"{node.name}({args_str})"

    def gen_NamedArgNode(self, node):
        return f"{node.name}={self.compile(node.expr)}"
    def gen_InputExprNode(self, node):
        if node.prompt_expr:
            return f"input({self.compile(node.prompt_expr)})"
        else:
            return "input()"
    def gen_FStringNode(self, node):
        return f"f{node.val}"

    def gen_LiteralNode(self, node):
        return node.value