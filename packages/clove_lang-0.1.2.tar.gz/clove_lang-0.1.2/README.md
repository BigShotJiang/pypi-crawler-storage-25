# Clove v0.1

## History

Clove is a simple programming language, it is general purpose and transpiles down to python.

🇧🇿 The First Belizean-Born Programming Language
🏝️ The second Caribbean-born programming language ever. (first being Lingo by John Henry Micheal)


I made it in a weekend, this is the Alpha release, don't expect much, just a simple test for users to try the syntax.

## Installation

Uhh, it's pretty straightforward not gonna lie, just do :

```pip install clove-lang```

or if you are on a modern Unix system :

```pip install clove-lang --break-system-packages```

## Syntax

Clove's main strength is the syntax, basically rust, zig and python if they had a child.

```clove
// @extern is the Clove equivalent of import.
// @extern(module_string)
@extern("pyttsx3");

fn speak(words) {
    // Variables are declared in this format : let variable = value;
    let engine = pyttsx3.init();
    engine.say(words);
    engine.runAndWait();
}

fn main() {
    let words = input("What do you want to convert to \033[32mspeech\033[0m? > ");
    speak(words);
    print("Thanks!");
}
```

or, for graphical windows (tkinter) :

```clove
@extern("tkinter");
@extern("sys");

fn click() {
    print("The user clicked me, yay!");
    sys.exit(94512);
}
fn main() {
    let root = tkinter.Tk();
    let button = tkinter.Button(root, text="Click me!!! COME ON, CLICK ME!!!", command=click);
    button.pack(pady=10);
    root.mainloop();
}
```

## Usage 

Extremely simple usage :

```clv [input_file] [-o/--output] [output_file]```

or if you DON'T want to create a file :

```clv [-r/--run] [input_file]```

## Roadmap

* [x] f-strings

* [x] Python Bridging

* [x] Preprocessor

* [] stdlib

* [] Control Flow (while, for, if/else/elif)

* [] Classes

* [] Type Casting