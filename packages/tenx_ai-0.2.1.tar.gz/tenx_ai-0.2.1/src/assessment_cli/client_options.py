"""Build Claude Agent SDK client options (API env, model, tools, cwd)."""

from pathlib import Path
from typing import TYPE_CHECKING, Callable

from claude_agent_sdk import ClaudeAgentOptions

from assessment_cli.config import settings
from assessment_cli.edit_approval import build_tool_approval_handler
from assessment_cli.subagents import build_explore_agent
from assessment_cli.system_prompt import (
    build_assistant_system_prompt,
    build_technical_interviewer_system_prompt,
)

if TYPE_CHECKING:
    from assessment_cli.ui import CLIUI


def require_api_key() -> str:
    api_key = (settings.anthropic_api_key or "").strip()
    if not api_key:
        raise SystemExit("Missing ANTHROPIC_API_KEY. Set it in .env and retry.")
    return api_key


def _build_anthropic_env(*, session_id: str | None) -> dict[str, str]:
    """Return ANTHROPIC_* env vars for the Claude agent subprocess.

    When ANTHROPIC_BASE_URL is set the proxy holds the real API key; we send
    the proxy bearer token (with optional session_id encoded) as x-api-key so
    the proxy can authenticate and apply per-session rate limits.
    """
    if settings.anthropic_base_url:
        proxy_token = (settings.assessment_proxy_token or "").strip()
        key = f"{proxy_token}:{session_id}" if session_id else proxy_token
        return {
            "ANTHROPIC_API_KEY": key,
            "ANTHROPIC_BASE_URL": settings.anthropic_base_url,
        }
    return {"ANTHROPIC_API_KEY": require_api_key()}


def build_options(
    *,
    cwd: Path,
    ui: "CLIUI",
    session_id: str | None = None,
    pause_working: Callable[[], None] | None = None,
    resume_working: Callable[[], None] | None = None,
) -> ClaudeAgentOptions:
    env = _build_anthropic_env(session_id=session_id)
    permission_mode = settings.tenx_starting_mode

    # Intentionally no `allowed_tools` / `disallowed_tools`:
    # `--allowedTools` pre-approves those tools, so Claude Code skips the
    # permission-prompt-tool path entirely and our `can_use_tool` callback
    # never fires. Omitting the flag falls back to the default toolset and
    # lets Claude Code route Write/Edit/Bash through our callback based on
    # `permission_mode`.
    return ClaudeAgentOptions(
        env=env,
        model=settings.model,
        system_prompt=build_assistant_system_prompt(cwd=cwd),
        permission_mode=permission_mode,  # type: ignore[arg-type]
        can_use_tool=build_tool_approval_handler(
            cwd=cwd,
            ui=ui,
            pause_working=pause_working,
            resume_working=resume_working,
        ),
        max_budget_usd=settings.tenx_max_budget_usd,
        agents={"Explore": build_explore_agent()},
        include_partial_messages=True,
        cwd=str(cwd),
    )


def build_technical_interviewer_options(*, cwd: Path, session_id: str | None = None) -> ClaudeAgentOptions:
    env = _build_anthropic_env(session_id=session_id)

    output_format = {
        "type": "json_schema",
        "schema": {
            "type": "object",
            "required": ["questions"],
            "properties": {
                "questions": {
                    "type": "array",
                    "minItems": 3,
                    "maxItems": 3,
                    "items": {
                        "type": "object",
                        "required": ["prompt"],
                        "properties": {
                            "prompt": {"type": "string", "minLength": 1},
                        },
                        "additionalProperties": False,
                    },
                },
            },
            "additionalProperties": False,
        },
    }

    return ClaudeAgentOptions(
        env=env,
        model=settings.model,
        system_prompt=build_technical_interviewer_system_prompt(),
        allowed_tools=[],
        permission_mode="acceptEdits",
        include_partial_messages=True,
        output_format=output_format,
        cwd=str(cwd),
    )
