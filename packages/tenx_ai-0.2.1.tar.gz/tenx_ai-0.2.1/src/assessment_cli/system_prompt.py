"""Load bundled prompt text files for assistant and technical interviewer roles."""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path
from typing import Any

TENX_MD_FILENAME = "TENX.md"


def load_assistant_system_prompt() -> str:
    return (
        files("assessment_cli.prompts")
        .joinpath("assistant_system_prompt.md")
        .read_text(encoding="utf-8")
        .strip()
    )


def load_technical_interviewer_system_prompt() -> str:
    return (
        files("assessment_cli.prompts")
        .joinpath("technical_interviewer_system_prompt.md")
        .read_text(encoding="utf-8")
        .strip()
    )


def load_init_tenx_md_prompt() -> str:
    """User-facing prompt sent to the agent when the candidate types `/init`."""
    return (
        files("assessment_cli.prompts")
        .joinpath("init_tenx_md_prompt.md")
        .read_text(encoding="utf-8")
        .strip()
    )


def _read_tenx_md(cwd: Path) -> str:
    """Return the contents of `TENX.md` at the workspace root, or empty if absent.

    Read fresh on every call — the assistant may write or edit `TENX.md` during
    a session, and we want the next client reconnect (/clear) to pick up changes.
    """
    path = cwd / TENX_MD_FILENAME
    if not path.is_file():
        return ""
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def build_assistant_system_prompt(*, cwd: Path | None = None) -> str | dict[str, Any] | None:
    """Preset claude_code plus bundled system prompt + optional TENX.md."""
    text = load_assistant_system_prompt()
    if cwd is not None:
        tenx_md = _read_tenx_md(cwd)
        if tenx_md:
            text = f"{text}\n\n# Project instructions from TENX.md\n\n{tenx_md}"
    if not text:
        return None
    # Field name is required by the Claude Agent SDK for preset supplemental instructions.
    return {"type": "preset", "preset": "claude_code", "append": text}


def build_technical_interviewer_system_prompt() -> str | None:
    """Dedicated technical interviewer prompt text (no claude_code preset)."""
    text = load_technical_interviewer_system_prompt()
    return text or None
