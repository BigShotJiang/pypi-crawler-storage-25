﻿"""Parse assistant message text, tool calls, and usage metadata from the Claude Agent SDK."""

from __future__ import annotations

import json
from typing import Any

from claude_agent_sdk.types import ToolResultBlock, ToolUseBlock


def extract_text_blocks(content: Any) -> str:
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for block in content:
        if isinstance(block, dict):
            if block.get("type") == "text" and block.get("text"):
                parts.append(str(block.get("text")))
        else:
            text = getattr(block, "text", None)
            if text:
                parts.append(str(text))
    return "".join(parts)


def extract_usage(message: Any) -> dict[str, Any]:
    usage = getattr(message, "usage", None)
    if isinstance(usage, dict):
        return usage

    result = getattr(message, "result", None)
    if isinstance(result, dict):
        usage_from_result = result.get("usage")
        if isinstance(usage_from_result, dict):
            return usage_from_result
    return {}


def usage_turn_tokens(usage: dict[str, Any]) -> tuple[int, int]:
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    input_count = input_tokens if isinstance(input_tokens, int) and input_tokens >= 0 else 0
    output_count = output_tokens if isinstance(output_tokens, int) and output_tokens >= 0 else 0
    return input_count, output_count


def _truncate_tool_result_content(content: Any, max_length: int = 500) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        text = content
    elif isinstance(content, (dict, list)):
        text = json.dumps(content, default=str)
    else:
        text = str(content)
    if len(text) > max_length:
        return text[:max_length] + "..."
    return text


def describe_active_tool(content: Any) -> str | None:
    """Return a short human-readable label for the most recent tool_use in *content*.

    Used to update the spinner text so the user can see what the agent is doing.
    Returns ``None`` if no tool_use block is found.
    """
    if not isinstance(content, list):
        return None
    for block in reversed(content):
        name: str | None = None
        tool_input: Any = None
        if isinstance(block, ToolUseBlock):
            name = block.name
            tool_input = block.input
        elif isinstance(block, dict) and block.get("type") == "tool_use":
            name = block.get("name")
            tool_input = block.get("input")
        if not name:
            continue

        detail = ""
        if isinstance(tool_input, dict):
            if name in {"Read", "Write", "Edit"}:
                path = tool_input.get("file_path") or ""
                if path:
                    # Filename only — the full path is in the structured turn log.
                    detail = path.replace("\\", "/").rsplit("/", 1)[-1]
            elif name == "Bash":
                cmd = tool_input.get("command") or ""
                detail = cmd[:40] + ("…" if len(cmd) > 40 else "")
            elif name in {"Glob", "Grep"}:
                detail = tool_input.get("pattern") or ""
            elif name in {"WebSearch", "WebFetch"}:
                detail = tool_input.get("query") or tool_input.get("url") or ""
                if len(detail) > 40:
                    detail = detail[:40] + "…"
        if detail:
            return f"{name}({detail})"
        return name
    return None


def extract_tool_calls_from_content(content: Any) -> list[dict[str, Any]]:
    """Serialize tool_use / tool_result blocks from assistant `content` for JSON storage."""
    if not isinstance(content, list):
        return []
    out: list[dict[str, Any]] = []
    for block in content:
        if isinstance(block, ToolUseBlock):
            out.append(
                {
                    "type": "tool_use",
                    "id": block.id,
                    "name": block.name,
                    "input": block.input,
                }
            )
        elif isinstance(block, ToolResultBlock):
            out.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.tool_use_id,
                    "content": _truncate_tool_result_content(block.content),
                    "is_error": block.is_error,
                }
            )
        elif isinstance(block, dict):
            block_type = block.get("type")
            if block_type == "tool_use":
                out.append(
                    {
                        "type": "tool_use",
                        "id": block.get("id"),
                        "name": block.get("name"),
                        "input": block.get("input"),
                    }
                )
            elif block_type == "tool_result":
                out.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": block.get("tool_use_id"),
                        "content": _truncate_tool_result_content(block.get("content")),
                        "is_error": block.get("is_error"),
                    }
                )
    return out
