"""Console entrypoint for the Tenx assessment CLI."""

from __future__ import annotations

import asyncio
import logging
import sys

from assessment_cli.logging_config import configure_logging
from assessment_cli.session import run_session

logger = logging.getLogger(__name__)

# Textual puts the terminal into alt-screen + raw mode with mouse tracking
# and hides the cursor. Normally it restores all of that on clean shutdown,
# but a KeyboardInterrupt can escape before teardown runs (esp. on Windows
# where SIGINT fires before the key event reaches Textual), leaving the
# user's shell with no echo. These sequences undo that state.
_TERMINAL_RESET_SEQUENCES = (
    "\x1b[?1049l"  # exit alternate screen buffer
    "\x1b[?25h"    # show cursor
    "\x1b[?1000l"  # disable X10 mouse reporting
    "\x1b[?1002l"  # disable cell-motion mouse tracking
    "\x1b[?1003l"  # disable all-motion mouse tracking
    "\x1b[?1006l"  # disable SGR mouse mode
    "\x1b[?2004l"  # disable bracketed paste
    "\x1b[0m"      # reset text attributes
)


def _restore_terminal() -> None:
    # Best-effort: this runs on KeyboardInterrupt after Textual has likely
    # already detached stdout. Any failure here just means the shell is
    # slightly less tidy — log for diagnosis but don't re-raise over an
    # exit path that's already unwinding.
    try:
        sys.stdout.write(_TERMINAL_RESET_SEQUENCES)
        sys.stdout.flush()
    except OSError as exc:
        logger.debug("terminal restore failed: %s", exc)


def main() -> None:
    configure_logging()
    try:
        asyncio.run(run_session())
    except KeyboardInterrupt:
        _restore_terminal()
        logger.info("Received keyboard interrupt in tenx-ai entrypoint.")
        print("\nExiting.")

