"""Resolve GitHub identity fields from settings, Codespaces env vars, and git config."""

from __future__ import annotations

import logging
import os
import subprocess
from dataclasses import dataclass

from assessment_cli.config import settings

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class GitHubIdentity:
    github_username: str = ""
    github_name: str = ""
    github_email: str = ""

    def with_field(self, field_name: str, value: str) -> "GitHubIdentity":
        cleaned_value = (value or "").strip()
        if field_name == "github_username":
            return GitHubIdentity(cleaned_value, self.github_name, self.github_email)
        if field_name == "github_name":
            return GitHubIdentity(self.github_username, cleaned_value, self.github_email)
        if field_name == "github_email":
            return GitHubIdentity(self.github_username, self.github_name, cleaned_value)
        raise ValueError(f"Unsupported identity field: {field_name}")


def resolve_github_identity() -> GitHubIdentity:
    """Resolve identity from TENX_GITHUB_* first, then Codespaces env, then git config."""
    identity = GitHubIdentity(
        github_username=(settings.tenx_github_username or "").strip(),
        github_name=(settings.tenx_github_name or "").strip(),
        github_email=(settings.tenx_github_email or "").strip(),
    )
    if _is_truthy(os.environ.get("CODESPACES")):
        if not identity.github_username:
            identity = identity.with_field("github_username", os.environ.get("GITHUB_USER", ""))
        if not identity.github_name:
            identity = identity.with_field("github_name", os.environ.get("GIT_COMMITTER_NAME", ""))
        if not identity.github_email:
            identity = identity.with_field("github_email", os.environ.get("GIT_COMMITTER_EMAIL", ""))
    if not identity.github_name:
        identity = identity.with_field("github_name", _git_config("user.name"))
    if not identity.github_email:
        identity = identity.with_field("github_email", _git_config("user.email"))
    return identity


def _git_config(key: str) -> str:
    # Narrow the except list: FileNotFoundError covers a missing `git` binary
    # (common in minimal Codespaces images) and SubprocessError covers timeout
    # / non-zero exit. Anything else (OSError, programming errors) should
    # propagate rather than silently becoming an empty string.
    try:
        result = subprocess.run(
            ["git", "config", key], capture_output=True, text=True, timeout=2
        )
    except (FileNotFoundError, subprocess.SubprocessError) as exc:
        logger.debug("git config %s lookup failed: %s", key, exc)
        return ""
    return result.stdout.strip()


def _is_truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "on"}
