"""Support `python -m assessment_cli`."""

from assessment_cli.main import main

if __name__ == "__main__":
    main()

