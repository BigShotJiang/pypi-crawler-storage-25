"""prompt_toolkit + Rich terminal UI for the TenX assessment CLI.

The UI is intentionally stdout-native: output flows through a `rich.Console`
directly to the terminal (so scrollback, mouse-select, and copy behave like
any other CLI), and input phases are driven by short-lived
`prompt_toolkit.PromptSession` instances. A `rich.live.Live` region renders
the `Working…` spinner during a turn without any full-screen repaint.

Ctrl+C interrupts the active turn (SIGINT → KeyboardInterrupt in the REPL);
Ctrl+D exits the session.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any

from prompt_toolkit import PromptSession
from prompt_toolkit.key_binding import KeyBindings
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text
from rich.theme import Theme

logger = logging.getLogger(__name__)


# Single source of truth for every non-status color. Rich theme names (for
# markup like [accent]) and direct `Text` styling both read from here.
_PALETTE = {
    "accent":    "#7C86FF",  # periwinkle — title, chip, prompt glyph, timer
    "body":      "#E4E4E4",  # high-emphasis text
    "muted":     "#8B8B8B",  # medium text tier — instructional, dividers
    "low":       "#4A4A4A",  # low-emphasis (placeholder)
    "rule":      "#2A2A2A",  # subtle divider for Rich Panel borders
}

CLI_THEME = Theme(
    {
        "body":      _PALETTE["body"],
        "meta":      _PALETTE["muted"],
        "hint":      _PALETTE["muted"],
        "muted":     _PALETTE["low"],
        "accent":    _PALETTE["accent"],
        "chip":      _PALETTE["accent"],
        "timer":     _PALETTE["accent"],
        "title":     _PALETTE["accent"],
        "label":     _PALETTE["accent"],
        "assistant": _PALETTE["accent"],
        "prompt":    _PALETTE["accent"],
        "success":   "green",
        "error":     "bold red",
        "system":    "bright_magenta",
    }
)


def _supports_color() -> bool:
    return (
        sys.stdout.isatty()
        and sys.stderr.isatty()
        and os.environ.get("NO_COLOR") is None
    )


def _usage_tokens(usage: dict[str, Any]) -> tuple[int | None, int | None]:
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    if isinstance(input_tokens, int) and isinstance(output_tokens, int):
        return input_tokens, output_tokens
    return None, None


def _format_duration_mm_ss(total_seconds: int) -> str:
    safe_seconds = max(0, total_seconds)
    minutes, seconds = divmod(safe_seconds, 60)
    return f"{minutes:02d}:{seconds:02d}"


_TIMER_WARNING_THRESHOLDS: list[tuple[int, str]] = [
    (60, "1 minute"),
    (300, "5 minutes"),
]


def _pick_timer_warning(
    seconds_remaining: int,
    warnings_shown: set[int],
) -> tuple[int, str, set[int]] | None:
    """Return (threshold, label, thresholds_to_mark) for the most-urgent unseen warning.

    Returns None if no warning is due. The caller is responsible for merging
    `thresholds_to_mark` into its own `warnings_shown` — this helper does not
    mutate any input. Thresholds ordered most-urgent-first so a single
    seconds_remaining check fires at most one warning, and all larger
    thresholds are reported as ones to mark (so a long-idle resume that jumps
    straight into the 1-minute window doesn't retroactively fire the 5-minute
    warning).
    """
    for threshold_seconds, label in _TIMER_WARNING_THRESHOLDS:
        if threshold_seconds in warnings_shown:
            continue
        if seconds_remaining <= threshold_seconds:
            to_mark = {
                larger for larger, _ in _TIMER_WARNING_THRESHOLDS
                if larger >= threshold_seconds
            }
            return threshold_seconds, label, to_mark
    return None


def _styled_diff_line(line: str) -> Text:
    """Per-line styling for a unified-diff line."""
    if line.startswith("+++") or line.startswith("---"):
        return Text(line, style="bold cyan")
    if line.startswith("@@"):
        return Text(line, style="magenta")
    if line.startswith("+"):
        return Text(line, style="green")
    if line.startswith("-"):
        return Text(line, style="red")
    return Text(line)


def _resolve_question_answer(question_data: dict[str, Any], raw_answer: str) -> str:
    """Translate a typed AskUserQuestion answer into the label(s) the agent expects.

    If the answer is a comma-separated list of option indices, map them back to
    their label strings; otherwise treat the raw text as a free-form reply.
    """
    raw = raw_answer.strip()
    options = question_data.get("options")
    if not isinstance(options, list) or not raw:
        return raw
    chunks = [chunk.strip() for chunk in raw.split(",") if chunk.strip()]
    if not chunks or not all(chunk.isdigit() for chunk in chunks):
        return raw
    selected_labels: list[str] = []
    for chunk in chunks:
        option_index = int(chunk) - 1
        if 0 <= option_index < len(options):
            option = options[option_index]
            if isinstance(option, dict):
                selected_labels.append(str(option.get("label", "")))
    if not selected_labels:
        return raw
    is_multi_select = bool(question_data.get("multiSelect"))
    return ", ".join(selected_labels) if is_multi_select else selected_labels[0]


class ExitRequested(Exception):
    """Raised when the user ends the session (Ctrl+D or EOF) to unblock the REPL."""


_SPINNER_FRAMES: tuple[str, ...] = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")


_MODE_CYCLE = ("default", "acceptEdits", "plan")
_MODE_LABELS = {
    "default": "›",
    "acceptEdits": "auto-accept ›",
    "plan": "plan ›",
}
_MODE_DISPLAY = {
    "default": "review (approve edits)",
    "acceptEdits": "auto-accept",
    "plan": "plan",
}


class _WorkingSpinner:
    """Transient Rich Live wrapper for the `Working…` status line.

    Used as a context-like token returned by `CLIUI.start_working`. Keeps the
    existing session.py flow (pass the handle into `stop_working`) without
    leaking Rich internals.
    """

    def __init__(self, console: Console) -> None:
        self._console = console
        self._started_at: float | None = None
        self._live: Live | None = None
        self._tick_task: asyncio.Task[None] | None = None

    def start(self) -> None:
        self._started_at = time.monotonic()
        self._live = Live(
            self._render(),
            console=self._console,
            refresh_per_second=10,
            transient=True,
        )
        self._live.start()
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None:
            self._tick_task = loop.create_task(self._tick())

    async def _tick(self) -> None:
        try:
            while self._live is not None:
                self._live.update(self._render())
                await asyncio.sleep(0.1)
        except asyncio.CancelledError:
            pass

    def _render(self) -> Text:
        if self._started_at is None:
            return Text("")
        frame_index = int((time.monotonic() - self._started_at) * 10) % len(_SPINNER_FRAMES)
        rendered = Text()
        rendered.append(f"{_SPINNER_FRAMES[frame_index]} Working…", style=_PALETTE["accent"])
        rendered.append(" (Ctrl+C to interrupt)", style=_PALETTE["muted"])
        return rendered

    def stop(self) -> None:
        if self._tick_task is not None:
            self._tick_task.cancel()
            self._tick_task = None
        if self._live is not None:
            try:
                self._live.stop()
            except Exception as exc:
                logger.debug("spinner live stop failed: %s", exc)
            self._live = None
        self._started_at = None


class CLIUI:
    def __init__(self, *, model: str, proxy_url: str | None) -> None:
        from assessment_cli.config import settings

        self.model = model
        self.proxy_url = (proxy_url or "").strip()
        self.timer_deadline_monotonic: float | None = None
        self.timer_duration_seconds: int | None = None
        self.interrupt_event: asyncio.Event = asyncio.Event()
        # Set by _run_repl so the REPL's interrupt handler can reach the SDK.
        self._active_client: Any = None
        self._last_logged_tool: str | None = None
        self._permission_mode: str = settings.tenx_starting_mode
        self._active_spinner: _WorkingSpinner | None = None
        # Prompt queued by a plan rejection — the REPL consumes this before
        # asking the user for a fresh prompt, so the feedback the candidate
        # typed against a rejected plan becomes the next turn's input.
        self._queued_prompt: str | None = None

        self.console = Console(
            theme=CLI_THEME,
            highlight=False,
            no_color=not _supports_color(),
            soft_wrap=False,
        )
        # Lazy — created on first `read_prompt_async` call so the event loop
        # is running when prompt_toolkit inspects it.
        self._input_session: PromptSession[str] | None = None

    # ------------------------------------------------------------------
    # Internal output
    # ------------------------------------------------------------------

    def _write(self, content: Any) -> None:
        """Write a single line/renderable to stdout via Rich.

        Spacing convention (applies to all public show_*/commit_*/print_*
        methods): each block writes exactly one blank line BEFORE its content
        and none after. Block = one logical unit (user message, assistant
        reply, timer warning, etc.). This keeps inter-block gaps at a
        consistent one line and avoids compounding when consecutive blocks
        each add their own trailing blank.
        """
        self.console.print(content)

    # ------------------------------------------------------------------
    # Timer helpers
    # ------------------------------------------------------------------

    def set_timer(self, *, duration_seconds: int, deadline_monotonic: float) -> None:
        self.timer_duration_seconds = duration_seconds
        self.timer_deadline_monotonic = deadline_monotonic

    def _seconds_remaining(self) -> int | None:
        if self.timer_deadline_monotonic is None:
            return None
        return max(0, int(self.timer_deadline_monotonic - time.monotonic()))

    # ------------------------------------------------------------------
    # Permission mode helpers
    # ------------------------------------------------------------------

    def _prompt_prefix(self) -> str:
        return _MODE_LABELS.get(self._permission_mode, "›")

    async def cycle_permission_mode(self) -> str:
        """Advance to the next mode in the cycle; return the display label."""
        current_index = (
            _MODE_CYCLE.index(self._permission_mode)
            if self._permission_mode in _MODE_CYCLE
            else 0
        )
        next_mode = _MODE_CYCLE[(current_index + 1) % len(_MODE_CYCLE)]
        if self._active_client is not None:
            try:
                await self._active_client.set_permission_mode(next_mode)
            except Exception as exc:
                logger.warning("set_permission_mode failed: %s", exc)
                return _MODE_DISPLAY.get(self._permission_mode, self._permission_mode)
        self._permission_mode = next_mode
        return _MODE_DISPLAY.get(self._permission_mode, self._permission_mode)

    def show_mode(self) -> None:
        mode_display = _MODE_DISPLAY.get(self._permission_mode, self._permission_mode)
        self._write(
            f"[meta]Current mode:[/meta] {mode_display}  "
            "[hint](Shift+Tab to cycle: review → auto-accept → plan)[/hint]"
        )

    # ------------------------------------------------------------------
    # Inline approval helpers
    # ------------------------------------------------------------------

    def _write_bar_title(self, title_text: str) -> None:
        accent = _PALETTE["accent"]
        line = Text()
        line.append("│ ", style=accent)
        line.append(title_text, style="bold")
        self._write(line)

    def _write_bar_body(self, body_text: str, style: str = "body") -> None:
        accent = _PALETTE["accent"]
        line = Text()
        line.append("│ ", style=accent)
        if body_text:
            line.append(body_text, style=style)
        self._write(line)

    def _write_edit_options_hint(self) -> None:
        """Numbered hint shared by Write/Edit/Bash approval screens."""
        accent = _PALETTE["accent"]
        muted = _PALETTE["muted"]
        for key_label, description in (
            ("1", "Yes"),
            ("2", "No"),
            ("3", "Yes, don't ask again"),
        ):
            row = Text()
            row.append("│ ", style=accent)
            row.append(key_label, style=accent)
            row.append(f". {description}", style=muted)
            self._write(row)

    async def _await_edit_choice(self) -> str:
        """Disposable PromptSession resolving on 1 / 2 / 3 keypress.

        Everything else is swallowed so a stray Enter or typed character
        can't slip through and submit a turn mid-approval. Ctrl+C is
        treated as a reject (consistent with terminal convention).
        """
        kb = KeyBindings()
        result: dict[str, str] = {"key": ""}

        def _accept(event: Any, key: str) -> None:
            result["key"] = key
            event.app.exit()

        @kb.add("1")
        def _one(event: Any) -> None:
            _accept(event, "1")

        @kb.add("2")
        def _two(event: Any) -> None:
            _accept(event, "2")

        @kb.add("3")
        def _three(event: Any) -> None:
            _accept(event, "3")

        @kb.add("c-c")
        def _ctrl_c(event: Any) -> None:
            _accept(event, "2")

        @kb.add("<any>")
        def _swallow(event: Any) -> None:
            return

        session: PromptSession[str] = PromptSession(
            message="",
            key_bindings=kb,
            erase_when_done=True,
        )
        await session.prompt_async()
        return result["key"] or "2"

    async def switch_to_accept_edits(self) -> None:
        """Set permission mode to acceptEdits on both the UI and the SDK client.

        Raises on SDK failure rather than silently leaving the UI in a
        default-mode state while the candidate believes they're in auto-accept.
        The caller (`_decide_with_diff`) converts the exception into a visible
        error before returning Allow, so the candidate sees that the mode
        switch didn't take effect instead of discovering it via a surprise
        approval prompt on the next turn.
        """
        if self._active_client is not None:
            await self._active_client.set_permission_mode("acceptEdits")
        self._permission_mode = "acceptEdits"

    async def await_plan_decision(self, plan_text: str) -> str:
        """Render a plan and collect the candidate's decision.

        Returns "y" on approve, "n" on reject. On reject, a follow-up
        prompt collects the candidate's feedback and queues it as the next
        turn's user prompt (see `take_queued_prompt`), so the experience is
        "reject → type what to change → Claude replans" without a visible
        interruption seam.
        """
        self._write("")
        self._write_bar_title("Proposed plan")
        self._write_bar_body("")
        body = plan_text.strip()
        if body:
            # Markdown renderable — headings, bullets, code blocks render
            # formatted. Bar prefix is dropped on the body since markdown
            # reflows across multiple terminal lines and prefixing each
            # would break the frame.
            self._write(Markdown(body))
        else:
            self._write_bar_body("No plan text provided.", style="meta")
        self._write_bar_body("")
        self._write_bar_body("Would you like to proceed?", style="body")
        self._write_plan_options_hint()
        key = await self._await_plan_choice()
        if key == "1":
            return "y"
        # Rejection path — collect the candidate's feedback and queue it.
        self._write("")
        self._write_bar_body(
            "What should change? Type your feedback, then Enter.",
            style="meta",
        )
        feedback = (await self._read_answer()).strip()
        if feedback:
            self._queued_prompt = feedback
        return "n"

    def _write_plan_options_hint(self) -> None:
        accent = _PALETTE["accent"]
        muted = _PALETTE["muted"]
        for key_label, description in (
            ("1", "Yes, begin editing"),
            ("2", "No, keep planning"),
        ):
            row = Text()
            row.append("│ ", style=accent)
            row.append(key_label, style=accent)
            row.append(f". {description}", style=muted)
            self._write(row)

    async def _await_plan_choice(self) -> str:
        """Wait for '1' or '2' — treat Ctrl+C and any other key as a no-op pass."""
        kb = KeyBindings()
        result: dict[str, str] = {"key": ""}

        def _accept(event: Any, key: str) -> None:
            result["key"] = key
            event.app.exit()

        @kb.add("1")
        def _one(event: Any) -> None:
            _accept(event, "1")

        @kb.add("2")
        def _two(event: Any) -> None:
            _accept(event, "2")

        @kb.add("c-c")
        def _ctrl_c(event: Any) -> None:
            # Ctrl+C during a plan approval → treat as reject (same as '2').
            _accept(event, "2")

        @kb.add("<any>")
        def _swallow(event: Any) -> None:
            return

        session: PromptSession[str] = PromptSession(
            message="",
            key_bindings=kb,
            erase_when_done=True,
        )
        await session.prompt_async()
        return result["key"] or "2"

    def take_queued_prompt(self) -> str | None:
        """Pop and return a prompt queued by a prior plan rejection (or None)."""
        queued = self._queued_prompt
        self._queued_prompt = None
        return queued

    def has_queued_prompt(self) -> bool:
        """True if a plan rejection has queued feedback as the next prompt."""
        return self._queued_prompt is not None

    async def await_edit_decision(
        self, *, tool_name: str, path: str, diff_lines: list[str]
    ) -> str:
        """Return "1" (approve), "2" (reject), or "3" (approve + auto-accept)."""
        self._write("")
        self._write_bar_title(f"{tool_name} proposed change")
        if path:
            self._write_bar_body(path, style="meta")
        self._write_bar_body("")
        for diff_line in diff_lines:
            self._write(_styled_diff_line(diff_line))
        self._write_bar_body("")
        self._write_edit_options_hint()
        return await self._await_edit_choice()

    async def await_bash_decision(self, *, command: str, description: str) -> str:
        """Return "1" (approve), "2" (reject), or "3" (approve + auto-accept)."""
        self._write("")
        self._write_bar_title("Bash command")
        if description:
            self._write_bar_body(description, style="meta")
        self._write_bar_body(command, style="body")
        self._write_bar_body("")
        self._write_edit_options_hint()
        return await self._await_edit_choice()

    async def await_user_questions(
        self, questions: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Render AskUserQuestion prompts inline and collect typed answers."""
        answers: dict[str, str] = {}
        total = len(questions)
        accent = _PALETTE["accent"]
        muted = _PALETTE["muted"]
        for index, question_data in enumerate(questions, start=1):
            if not isinstance(question_data, dict):
                continue
            header = str(question_data.get("header", "")).strip()
            question_text = str(question_data.get("question", "")).strip()
            options = question_data.get("options")

            self._write("")
            self._write_bar_title(f"Question {index} of {total}")
            if header:
                self._write_bar_body(header, style="meta")
            if question_text:
                self._write_bar_body(question_text)
            if isinstance(options, list):
                for option_index, option in enumerate(options, start=1):
                    if not isinstance(option, dict):
                        continue
                    label = str(option.get("label", ""))
                    description = str(option.get("description", ""))
                    row = Text()
                    row.append("│ ", style=accent)
                    row.append(f"  {option_index}. ", style=accent)
                    row.append(label, style="body")
                    if description:
                        row.append(f" — {description}", style=muted)
                    self._write(row)
                self._write_bar_body("Type option number(s) or free text, then Enter.", style="meta")
            else:
                self._write_bar_body("Type your answer then Enter.", style="meta")

            raw = await self._read_answer()
            resolved = _resolve_question_answer(question_data, raw)
            answers[question_text] = resolved
        return {"questions": questions, "answers": answers}

    async def _read_answer(self) -> str:
        """One-shot text prompt used by AskUserQuestion — never the main REPL prompt."""
        session: PromptSession[str] = PromptSession(message="› ")
        try:
            return await session.prompt_async()
        except (EOFError, KeyboardInterrupt):
            return ""

    # ------------------------------------------------------------------
    # Show methods
    # ------------------------------------------------------------------

    def show_github_identity_panel(self, identity: Any, *, pending_field: str = "") -> None:
        """Show the GitHub identity form with auto-resolved fields ticked and pending field highlighted."""
        _FIELDS = [
            ("github_username", "Username"),
            ("github_name", "Name"),
            ("github_email", "Email"),
        ]
        all_resolved = not pending_field and all(getattr(identity, f, "") for f, _ in _FIELDS)

        rows: list[str] = []
        for field, label in _FIELDS:
            value = getattr(identity, field, "")
            padded = f"{label:<10}"
            if value:
                rows.append(f"  [success]✓[/success]  [meta]{padded}[/meta]  {value}")
            elif field == pending_field:
                rows.append(f"  [meta]›[/meta]  [body]{padded}[/body]  [meta]↵ type below[/meta]")
            else:
                rows.append(f"     [meta]{padded}[/meta]")

        subtitle = "[success]Identity linked[/success]" if all_resolved else None
        self._write(
            Panel(
                "\n".join(rows),
                title="[meta]GitHub[/meta]",
                subtitle=subtitle,
                border_style=_PALETTE["rule"],
                padding=(1, 1),
            )
        )

    def show_banner(self, *, version: str) -> None:
        """Stacked header with an accent-coloured vertical bar down its left edge."""
        bar = "[accent]│[/accent] "
        self._write("")
        self._write(f"{bar}[meta]TenX AI v{version}[/meta]")
        self._write(f"{bar}[meta]{self.model}[/meta]")
        self._write(f"{bar}[meta]{Path.cwd()}[/meta]")
        self._write(f"{bar}")
        self._write(f"{bar}[hint]Type [/hint][chip]/help[/chip][hint] for commands.[/hint]")
        if self.timer_duration_seconds is not None:
            duration_chip = _format_duration_mm_ss(self.timer_duration_seconds)
            self._write(
                f"{bar}[hint]Assessment timer: [/hint][timer]{duration_chip}[/timer]"
                "[hint]. Type [/hint][chip]/time[/chip]"
                "[hint] to check remaining time.[/hint]"
            )

    def show_help(self) -> None:
        _HELP_ROWS = [
            ("/help",       "Show this command list"),
            ("/init",       "Analyze the workspace and create TENX.md"),
            ("/status",     "Show active model and chat history API status"),
            ("/time",       "Show remaining assessment time"),
            ("/mode",       "Show current permission mode"),
            ("/meta",       "Toggle per-message usage/timing footer"),
            ("/submit",     "Submit your solution"),
            ("/clear",      "Start a fresh session"),
            ("/exit",       "Exit the CLI"),
            ("Shift+Tab",   "Cycle mode: default → auto-accept → plan"),
            ("Alt+Enter",   "Insert newline in input"),
            ("Ctrl+C",      "Interrupt current turn"),
            ("Ctrl+D",      "Exit the CLI"),
        ]
        col_width = max(len(cmd) for cmd, _ in _HELP_ROWS)
        self._write(Rule(style="muted"))
        for cmd, desc in _HELP_ROWS:
            self._write(f"  [accent]{cmd:<{col_width}}[/accent]  [muted]│[/muted]  {desc}")

    def show_status(self) -> None:
        state = "configured" if self.proxy_url else "not configured"
        self._write(
            f"[meta]Model:[/meta] {self.model}  "
            f"[meta]Chat history API:[/meta] {state}"
        )

    def show_session_reset(self) -> None:
        self._write("[success]Started a new session.[/success]")

    def show_meta_mode(self, enabled: bool) -> None:
        value = "ON" if enabled else "OFF"
        self._write(f"[system]Meta footer {value}.[/system]")

    def show_time_remaining(self) -> None:
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is None:
            self._write("[meta]Assessment timer is not active.[/meta]")
            return
        if seconds_remaining == 0:
            self._write("[error]Assessment timer: 00:00 (time expired).[/error]")
            return
        self._write(
            f"[meta]Assessment timer remaining:[/meta] {_format_duration_mm_ss(seconds_remaining)}"
        )

    def check_timer_warnings(self, *, warnings_shown: set[int]) -> None:
        """Show a warning when the timer crosses key thresholds (5min, 1min)."""
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is None:
            return
        picked = _pick_timer_warning(seconds_remaining, warnings_shown)
        if picked is None:
            return
        _threshold, label, to_mark = picked
        warnings_shown |= to_mark
        self._write("")
        self._write(
            f"[error]Warning: {label} remaining. "
            "Submit your work soon with 'tenx-submit'.[/error]"
        )

    def show_error(self, message: str, *, hint: str = "") -> None:
        body = message
        if hint:
            body += f"\n[hint]{hint}[/hint]"
        self._write(Panel(body, title="Error", border_style="error"))

    def show_user_message(self, prompt: str) -> None:
        """Echo the user's submitted prompt with a remaining-time prefix and neutral arrow."""
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is not None:
            timer_label = _format_duration_mm_ss(seconds_remaining)
            prefix_markup = f"[timer]({timer_label})[/timer] [meta]›[/meta] "
        else:
            prefix_markup = "[meta]›[/meta] "
        self._write("")
        prefix = Text.from_markup(prefix_markup)
        body = Text(prompt, style="body")
        self._write(prefix + body)

    # ------------------------------------------------------------------
    # Working spinner
    # ------------------------------------------------------------------

    def start_working(self) -> _WorkingSpinner:
        self._last_logged_tool = None
        spinner = _WorkingSpinner(self.console)
        spinner.start()
        self._active_spinner = spinner
        return spinner

    def update_working(self, status: _WorkingSpinner | None, tool_label: str) -> None:
        """Log each new tool call to the transcript; the spinner keeps `Working…`."""
        if status is None:
            return
        if tool_label != self._last_logged_tool:
            self._last_logged_tool = tool_label
            self._write(f"[meta]    {tool_label}[/meta]")

    def stop_working(self, status: _WorkingSpinner | None) -> None:
        if status is None:
            return
        try:
            status.stop()
        except Exception as exc:
            logger.debug("spinner stop failed: %s", exc)
        if self._active_spinner is status:
            self._active_spinner = None

    # ------------------------------------------------------------------
    # Assistant reply rendering
    # ------------------------------------------------------------------

    def _render_assistant_reply(self, text: str) -> Any:
        """Accent-bulleted, hanging-indented renderable for an assistant reply.

        Table.grid gives us a 2-column layout: the lavender bullet in col 0
        (width 2), and the Markdown body in col 1. Multi-line bodies wrap
        inside col 1, so continuation lines stay indented under the first
        character of text rather than wrapping back to column 0.
        """
        grid = Table.grid(padding=0)
        grid.add_column(width=2, no_wrap=True)
        grid.add_column()
        grid.add_row(Text.from_markup("[accent]•[/accent] "), Markdown(text))
        return grid

    def commit_live_reply(self, text: str) -> None:
        """Write the completed assistant reply to the transcript."""
        if text:
            self._write("")
            self._write(self._render_assistant_reply(text))

    def show_exit_summary(self, *, turn_count: int, session_id: str | None) -> None:
        """Print a brief summary when the session ends."""
        parts = [f"{turn_count} turn(s) recorded"]
        if session_id:
            parts.append(f"session {session_id[:8]}")
        self._write(
            f"[meta]Exiting ({', '.join(parts)}). Submit with 'tenx-submit'.[/meta]"
        )

    def print_meta_footer(self, *, duration_ms: int, usage: dict[str, Any]) -> None:
        input_tokens, output_tokens = _usage_tokens(usage)
        if input_tokens is not None and output_tokens is not None:
            self._write(
                f"[meta]{duration_ms} ms | input {input_tokens} | output {output_tokens}[/meta]"
            )
            return
        self._write(f"[meta]{duration_ms} ms[/meta]")

    # ------------------------------------------------------------------
    # Input
    # ------------------------------------------------------------------

    def _build_main_key_bindings(self) -> KeyBindings:
        kb = KeyBindings()

        # multiline=True means Enter inserts a newline by default; rebind so
        # Enter submits (matches every chat UI the candidate has used) and
        # Alt+Enter inserts a newline for multi-line prompts.
        @kb.add("enter")
        def _submit(event: Any) -> None:
            event.current_buffer.validate_and_handle()

        @kb.add("escape", "enter")  # Alt+Enter / Meta+Enter
        def _newline(event: Any) -> None:
            event.current_buffer.insert_text("\n")

        @kb.add("s-tab")
        def _cycle(event: Any) -> None:
            # Ignore mode-cycle during an active turn — `set_permission_mode`
            # racing with `receive_response` on the same Query is unsafe, and
            # the main prompt shouldn't be visible anyway while a turn runs.
            if self._active_spinner is not None:
                return

            async def _do() -> None:
                await self.cycle_permission_mode()
                event.app.invalidate()
            event.app.create_background_task(_do())

        return kb

    def _ensure_input_session(self) -> PromptSession[str]:
        if self._input_session is None:
            self._input_session = PromptSession(
                message=lambda: self._prompt_prefix() + " ",
                multiline=True,
                key_bindings=self._build_main_key_bindings(),
            )
        return self._input_session

    async def read_prompt_async(self) -> str:
        """Read the next submitted prompt from the user.

        Ctrl+D (EOF) raises `ExitRequested` so the REPL can exit cleanly.
        Ctrl+C is swallowed by prompt_toolkit and clears the buffer — at the
        input phase we don't want it to kill the process.
        """
        session = self._ensure_input_session()
        try:
            text = await session.prompt_async()
        except EOFError:
            raise ExitRequested from None
        except KeyboardInterrupt:
            return ""
        return text.strip()

    async def read_required_value_async(self, *, label: str, hint: str = "") -> str:
        """Prompt until a non-empty value is provided."""
        if hint:
            self._write(f"[hint]{hint}[/hint]")
        self._write(f"[meta]{label}:[/meta]")
        while True:
            raw_value = await self.read_prompt_async()
            cleaned_value = raw_value.strip()
            if cleaned_value:
                return cleaned_value
            self._write(f"[error]{label} is required.[/error]")
