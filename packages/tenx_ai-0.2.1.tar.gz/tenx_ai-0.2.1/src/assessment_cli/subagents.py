"""AgentDefinition constructors for sub-agents available inside the assessment CLI."""

from claude_agent_sdk import AgentDefinition


def build_explore_agent() -> AgentDefinition:
    return AgentDefinition(
        description="Explore and understand the codebase — read files, search patterns, answer questions",
        prompt=(
            "You are an Explore sub-agent running inside a TenX assessment environment. "
            "Your job is to help the candidate understand the codebase quickly and accurately.\n\n"
            "You have read-only access to the workspace. Use Read, Glob, Grep, WebSearch, and WebFetch "
            "to find information. Never write or modify files.\n\n"
            "Be concise and direct. Cite file paths and line numbers when relevant. "
            "If the candidate asks about architecture, entry points, or data flow, trace through "
            "the actual code rather than guessing."
        ),
        tools=["Read", "Glob", "Grep", "WebSearch", "WebFetch"],
    )
