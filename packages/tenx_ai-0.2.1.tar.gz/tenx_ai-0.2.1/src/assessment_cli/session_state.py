"""Persist and retrieve assessment session state shared across CLI commands."""

from __future__ import annotations

from pathlib import Path

from assessment_cli.config import resolved_agent_workspace_directory

SESSION_STATE_RELATIVE_PATH = Path(".tenx") / "assessment_session_id"
TIMER_START_RELATIVE_PATH = Path(".tenx") / "assessment_timer_start"


def session_state_path() -> Path:
    return resolved_agent_workspace_directory() / SESSION_STATE_RELATIVE_PATH


def read_assessment_session_id() -> str | None:
    """Returns the active session id until `tenx-submit` removes `.tenx/assessment_session_id`."""
    path = session_state_path()
    if not path.exists():
        return None

    stored_id = path.read_text(encoding="utf-8").strip()
    return stored_id or None


def write_assessment_session_id(session_id: str) -> None:
    cleaned_session_id = session_id.strip()
    if not cleaned_session_id:
        return

    path = session_state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(cleaned_session_id + "\n", encoding="utf-8")


def clear_assessment_session_id_file() -> None:
    """Remove `.tenx/assessment_session_id` after a successful submit so the next `tenx-ai` creates a new session."""
    path = session_state_path()
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def write_assessment_timer_start(iso_utc: str) -> None:
    path = resolved_agent_workspace_directory() / TIMER_START_RELATIVE_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(iso_utc + "\n", encoding="utf-8")


def read_assessment_timer_start() -> str | None:
    path = resolved_agent_workspace_directory() / TIMER_START_RELATIVE_PATH
    if not path.exists():
        return None
    return path.read_text(encoding="utf-8").strip() or None


def clear_assessment_timer_start() -> None:
    path = resolved_agent_workspace_directory() / TIMER_START_RELATIVE_PATH
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass
