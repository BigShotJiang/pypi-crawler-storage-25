"""Environment-backed settings for the assessment CLI runtime."""

from pathlib import Path

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_VALID_STARTING_MODES = {"default", "acceptEdits", "plan"}


def _find_env_file() -> Path | None:
    """Walk up from cwd looking for a `.env` file.

    Works for both layouts:
    - Monorepo dev (`cd packages/cli && tenx-ai`) — finds `.env` at the
      repo root two levels up.
    - PyPI install in Codespaces — cwd is the candidate's workspace,
      typically no `.env`; returns None and pydantic-settings falls back
      to the OS env vars injected by `devcontainer.json`'s `remoteEnv`.

    Resolving from `__file__` breaks once installed because
    `parents[4]` from `site-packages/assessment_cli/config.py` lands
    outside any meaningful directory.
    """
    for directory in (Path.cwd(), *Path.cwd().parents):
        candidate = directory / ".env"
        if candidate.is_file():
            return candidate
    return None


_ENV_FILE = _find_env_file()


class Settings(BaseSettings):
    anthropic_api_key: str | None = Field(default=None, validation_alias="ANTHROPIC_API_KEY")
    anthropic_base_url: str | None = Field(default=None, validation_alias="ANTHROPIC_BASE_URL")
    model: str = Field(
        default="claude-sonnet-4-5-20250929",
        validation_alias="MODEL",
    )
    assessment_proxy_url: str | None = Field(default=None, validation_alias="ASSESSMENT_PROXY_URL")
    assessment_proxy_token: str | None = Field(default=None, validation_alias="ASSESSMENT_PROXY_TOKEN")
    assessment_agent_cwd: str | None = Field(default=None, validation_alias="ASSESSMENT_AGENT_CWD")
    tenx_starting_mode: str = Field(default="default", validation_alias="TENX_STARTING_MODE")
    tenx_max_budget_usd: float = Field(default=5.0, validation_alias="TENX_MAX_BUDGET_USD")
    tenx_assessment_duration_seconds: int = Field(
        default=3600,
        ge=1,
        validation_alias="TENX_ASSESSMENT_DURATION_SECONDS",
    )
    tenx_github_username: str = Field(default="", validation_alias="TENX_GITHUB_USERNAME")
    tenx_github_name: str = Field(default="", validation_alias="TENX_GITHUB_NAME")
    tenx_github_email: str = Field(default="", validation_alias="TENX_GITHUB_EMAIL")
    environment: str = Field(default="", validation_alias="ENV")
    tenx_log_level: str = Field(default="WARNING", validation_alias="TENX_LOG_LEVEL")

    @model_validator(mode="after")
    def _validate_starting_mode(self) -> "Settings":
        if self.tenx_starting_mode not in _VALID_STARTING_MODES:
            raise SystemExit(
                f"TENX_STARTING_MODE={self.tenx_starting_mode!r} is invalid. "
                f"Valid values: {sorted(_VALID_STARTING_MODES)}"
            )
        return self

    model_config = SettingsConfigDict(
        env_file=str(_ENV_FILE) if _ENV_FILE else None,
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


settings = Settings()


def resolved_agent_workspace_directory() -> Path:
    """Directory the agent uses for tools (Read, Bash, …); optional override via ASSESSMENT_AGENT_CWD."""
    raw = (settings.assessment_agent_cwd or "").strip()
    if not raw:
        return Path.cwd().resolve()
    path = Path(raw).expanduser().resolve()
    if not path.is_dir():
        raise SystemExit(f"ASSESSMENT_AGENT_CWD must be an existing directory: {path}")
    return path

