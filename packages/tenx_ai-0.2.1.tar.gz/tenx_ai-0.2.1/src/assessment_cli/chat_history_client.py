"""HTTP client for proxy sessions and chat-history batch persistence."""

from __future__ import annotations

import logging
from pathlib import Path

import httpx

logger = logging.getLogger(__name__)


class ChatHistoryClient:
    def __init__(self, *, base_url: str | None, token: str | None) -> None:
        self.base_url = (base_url or "").rstrip("/")
        self.token = (token or "").strip()
        self._warned_disabled = False

    def _request_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def create_session(
        self,
        *,
        directory_name: str | None = None,
        github_username: str = "",
        github_name: str = "",
        github_email: str = "",
    ) -> tuple[str | None, str | None]:
        """POST /v1/sessions with optional `directory_name` (defaults to current working directory name)."""
        if not self.base_url:
            logger.debug("Skipping session creation because ASSESSMENT_PROXY_URL is not configured.")
            return None, None

        name = (directory_name if directory_name is not None else Path.cwd().name).strip()
        body: dict[str, str] = {
            "directory_name": name,
            "github_username": github_username.strip(),
            "github_name": github_name.strip(),
            "github_email": github_email.strip(),
        }
        logger.info(
            "Creating proxy session dir=%s user=%s name_present=%s email_present=%s",
            name,
            body["github_username"],
            bool(body["github_name"]),
            bool(body["github_email"]),
        )

        try:
            async with httpx.AsyncClient(timeout=10.0) as http_client:
                response = await http_client.post(
                    f"{self.base_url}/v1/sessions",
                    headers=self._request_headers(),
                    json=body,
                )
        except httpx.HTTPError as http_error:
            logger.warning("Session creation request failed: %s", http_error)
            return None, f"Failed to create assessment session: {http_error}"

        if response.status_code >= 300:
            detail = (response.text or "").strip()
            suffix = f" - {detail}" if detail else ""
            logger.warning("Session creation returned HTTP %s", response.status_code)
            return None, f"Proxy returned HTTP {response.status_code}{suffix}"

        try:
            data = response.json()
        except ValueError:
            logger.warning("Session creation returned non-JSON response.")
            return None, "Proxy returned invalid JSON for session creation"

        session_id = data.get("session_id")
        if not session_id:
            logger.warning("Session creation response missing session_id field.")
            return None, "Proxy session response missing session_id"
        logger.info("Created proxy session session_id=%s", session_id)
        return str(session_id), None

    async def save_assessment_turns_batch(self, payload: dict[str, object]) -> str | None:
        if not self.base_url:
            if self._warned_disabled:
                return None
            self._warned_disabled = True
            logger.warning("Assessment turns persistence is disabled because ASSESSMENT_PROXY_URL is not set.")
            return "Assessment proxy URL is not configured; chat history persistence is disabled."

        turn_count = len(payload.get("turns", [])) if isinstance(payload.get("turns"), list) else 0
        logger.info("Uploading assessment turns batch turn_count=%s", turn_count)
        try:
            async with httpx.AsyncClient(timeout=30.0) as http_client:
                response = await http_client.post(
                    f"{self.base_url}/v1/chat-history/assessment-turns/batch",
                    headers=self._request_headers(),
                    json=payload,
                )
        except httpx.HTTPError as http_error:
            logger.warning("Assessment turns batch request failed: %s", http_error)
            return f"Failed to save assessment turns to assessment proxy: {http_error}"

        if response.status_code >= 300:
            detail = (response.text or "").strip()
            suffix = f" - {detail}" if detail else ""
            logger.warning("Assessment turns batch returned HTTP %s", response.status_code)
            return f"Proxy returned HTTP {response.status_code}{suffix}"
        logger.info("Assessment turns batch accepted by proxy.")
        return None

    async def run_eval(self, payload: dict[str, object]) -> str | None:
        """POST /v1/eval with raw turns/FRQs/diff for proxy-side evaluation and PDF upload."""
        if not self.base_url:
            logger.debug("Skipping eval because ASSESSMENT_PROXY_URL is not configured.")
            return None

        logger.info("Requesting eval session_id=%s", payload.get("session_id"))
        try:
            async with httpx.AsyncClient(timeout=120.0) as http_client:
                response = await http_client.post(
                    f"{self.base_url}/v1/eval",
                    headers=self._request_headers(),
                    json=payload,
                )
        except httpx.HTTPError as http_error:
            logger.warning("Eval request failed: %s", http_error)
            return f"Failed to run evaluation: {http_error}"

        if response.status_code >= 300:
            detail = (response.text or "").strip()
            suffix = f" - {detail}" if detail else ""
            logger.warning("Eval request returned HTTP %s", response.status_code)
            return f"Proxy returned HTTP {response.status_code}{suffix}"
        logger.info("Eval completed by proxy.")
        return None

    async def save_free_response_questions_batch(self, payload: dict[str, object]) -> str | None:
        if not self.base_url:
            if self._warned_disabled:
                return None
            self._warned_disabled = True
            logger.warning("FRQ persistence is disabled because ASSESSMENT_PROXY_URL is not set.")
            return "Assessment proxy URL is not configured; FRQ persistence is disabled."

        question_count = len(payload.get("questions", [])) if isinstance(payload.get("questions"), list) else 0
        logger.info("Uploading FRQ batch question_count=%s", question_count)
        try:
            async with httpx.AsyncClient(timeout=30.0) as http_client:
                response = await http_client.post(
                    f"{self.base_url}/v1/chat-history/free-response-questions/batch",
                    headers=self._request_headers(),
                    json=payload,
                )
        except httpx.HTTPError as http_error:
            logger.warning("FRQ batch request failed: %s", http_error)
            return f"Failed to save free-response questions to assessment proxy: {http_error}"

        if response.status_code >= 300:
            detail = (response.text or "").strip()
            suffix = f" - {detail}" if detail else ""
            logger.warning("FRQ batch returned HTTP %s", response.status_code)
            return f"Proxy returned HTTP {response.status_code}{suffix}"
        logger.info("FRQ batch accepted by proxy.")
        return None
