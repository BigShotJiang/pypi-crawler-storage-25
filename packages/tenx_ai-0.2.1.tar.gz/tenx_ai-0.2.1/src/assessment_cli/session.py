"""Interactive REPL session: Claude queries, Rich UI, and optional chat history persistence."""

from __future__ import annotations

import asyncio
import logging
import sys
import time
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as package_version
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from claude_agent_sdk import ClaudeSDKClient
from claude_agent_sdk.types import AssistantMessage, ResultMessage

from assessment_cli.chat_history_client import ChatHistoryClient
from assessment_cli.clean_logs import clean_logs
from assessment_cli.client_options import build_options
from assessment_cli.config import resolved_agent_workspace_directory, settings
from assessment_cli.github_identity import GitHubIdentity, resolve_github_identity
from assessment_cli.session_state import (
    clear_assessment_session_id_file,
    clear_assessment_timer_start,
    read_assessment_session_id,
    read_assessment_timer_start,
    write_assessment_session_id,
    write_assessment_timer_start,
)
from assessment_cli.streaming import (
    describe_active_tool,
    extract_text_blocks,
    extract_tool_calls_from_content,
    extract_usage,
    usage_turn_tokens,
)
from assessment_cli.system_prompt import load_init_tenx_md_prompt
from assessment_cli.turn_log import append_assessment_turn, next_turn_index_for_session
from assessment_cli.ui import CLIUI, ExitRequested
from assessment_cli.utils import utc_now_iso

logger = logging.getLogger(__name__)


def _error_hint(error_text: str) -> str:
    """Map an API error string to an actionable hint.

    `ConnectionRefused` and credential failures need very different diagnostics;
    a generic 'check your .env' hint masks both. Match on common substrings to
    steer the candidate toward the right fix.
    """
    lower = error_text.lower()
    # Order matters: ZlibError/decompression is specifically a proxy-side header
    # mismatch, not a reachability problem. Check for it before the generic
    # "connect" wording (which SDK messages wrap around the real cause).
    if "zliberror" in lower or "decompression" in lower or "gunzip" in lower:
        return (
            "The proxy forwarded a response whose headers don't match the body "
            "(likely Content-Encoding: gzip on an already-decompressed body). "
            "This is a proxy bug, not an .env issue — restart the proxy to "
            "pick up fixes, or check its Anthropic passthrough handler."
        )
    if any(
        s in lower
        for s in ("connectionrefused", "connection refused",
                  "timed out", "timeout", "dns", "name or service not known",
                  "unable to connect")
    ):
        return (
            "The Anthropic endpoint isn't reachable. If you're routing through "
            "a local proxy, check ANTHROPIC_BASE_URL in .env and make sure the "
            "proxy is running on that port."
        )
    if any(
        s in lower
        for s in ("401", "403", "unauthorized", "forbidden",
                  "invalid api key", "authentication")
    ):
        return (
            "Authentication failed. Check ANTHROPIC_API_KEY (or "
            "ASSESSMENT_PROXY_TOKEN if using the proxy) in .env."
        )
    if "429" in lower or "rate limit" in lower:
        return "Rate limited. Wait a moment and try again."
    if "budget" in lower or "max_budget" in lower:
        return "You can still edit code manually and submit with 'tenx-submit'. Contact your evaluator with questions."
    return "Your input was not lost. Try again or type /clear to reset the session."


async def _create_client(
    *,
    cwd: Path,
    session_id: str | None = None,
    ui: CLIUI,
    pause_working: Any,
    resume_working: Any,
) -> ClaudeSDKClient:
    client = ClaudeSDKClient(
        options=build_options(
            cwd=cwd,
            session_id=session_id,
            ui=ui,
            pause_working=pause_working,
            resume_working=resume_working,
        )
    )
    await client.connect()
    return client


async def _prompt_missing_github_identity(ui: CLIUI, identity: GitHubIdentity) -> GitHubIdentity:
    resolved_identity = identity
    fields = (
        ("github_username", "GitHub username"),
        ("github_name", "GitHub name"),
        ("github_email", "GitHub email"),
    )
    missing = [f for f, _ in fields if not getattr(resolved_identity, f)]
    if not missing:
        return resolved_identity
    for field_name, label in fields:
        if getattr(resolved_identity, field_name):
            continue
        ui.show_github_identity_panel(resolved_identity, pending_field=field_name)
        value = await ui.read_required_value_async(label=label)
        resolved_identity = resolved_identity.with_field(field_name, value)
    ui.show_github_identity_panel(resolved_identity)
    return resolved_identity


def _remaining_timer_seconds(*, total_seconds: int, is_resuming: bool) -> int:
    if not is_resuming:
        return total_seconds
    stored = read_assessment_timer_start()
    if not stored:
        return total_seconds
    try:
        started_at = datetime.fromisoformat(stored.replace("Z", "+00:00"))
        elapsed = int((datetime.now(timezone.utc) - started_at).total_seconds())
        return max(1, total_seconds - elapsed)
    except ValueError:
        return total_seconds


def _resumed_session_is_expired(total_seconds: int) -> bool:
    """True when the persisted timer-start is older than the assessment duration."""
    stored = read_assessment_timer_start()
    if not stored:
        return False
    try:
        started_at = datetime.fromisoformat(stored.replace("Z", "+00:00"))
    except ValueError:
        return False
    elapsed = (datetime.now(timezone.utc) - started_at).total_seconds()
    return elapsed >= total_seconds


async def run_session() -> None:
    """Entry point — called by main.py via asyncio.run(). Unchanged signature."""
    ui = CLIUI(model=settings.model, proxy_url=settings.assessment_proxy_url)
    try:
        await _run_repl(ui)
    except ExitRequested:
        pass


async def _run_submit(ui: CLIUI) -> None:
    ui._write("[meta]Running tenx-submit…[/meta]")
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "assessment_cli.submit",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        assert proc.stdout is not None
        async for line in proc.stdout:
            ui._write(line.decode(errors="replace").rstrip())
        await proc.wait()
        if proc.returncode == 0:
            ui._write("[success]Submit complete.[/success]")
        else:
            ui._write(f"[error]tenx-submit exited with code {proc.returncode}.[/error]")
    except Exception as exc:
        logger.exception("tenx-submit failed")
        ui.show_error(str(exc), hint="Run 'tenx-submit' manually in a separate terminal.")


async def _run_repl(ui: CLIUI) -> None:
    """Full REPL body — drives the prompt_toolkit input session and SDK turns directly."""
    root_dir = resolved_agent_workspace_directory()
    proxy_host = urlsplit(settings.assessment_proxy_url or "").netloc
    logger.debug(
        "Starting assessment session model=%s proxy_host=%s proxy_token_configured=%s workspace=%s",
        settings.model,
        proxy_host,
        bool((settings.assessment_proxy_token or "").strip()),
        root_dir,
    )

    # Mutable holder so approval callbacks can always reference the current spinner.
    working_holder: list[Any] = [None]

    def pause_working() -> None:
        if working_holder[0] is not None:
            try:
                working_holder[0].stop()
            except Exception as exc:
                logger.debug("working spinner stop failed: %s", exc)

    def resume_working() -> None:
        if working_holder[0] is not None:
            try:
                working_holder[0].start()
            except Exception as exc:
                logger.debug("working spinner start failed: %s", exc)

    # Create proxy session before the SDK client so session_id can be embedded
    # in the Anthropic API key for per-session rate limiting at the proxy.
    chat_history = ChatHistoryClient(
        base_url=settings.assessment_proxy_url,
        token=settings.assessment_proxy_token,
    )
    github_identity = resolve_github_identity()
    # Reuse `.tenx/assessment_session_id` across `tenx-ai` runs until `tenx-submit` clears it.
    chat_session_id: str | None = None
    is_resuming_session = False
    if chat_history.base_url:
        existing_id = read_assessment_session_id()
        if existing_id and _resumed_session_is_expired(settings.tenx_assessment_duration_seconds):
            ui.show_error(
                "Your previous assessment timer has already expired.",
                hint="Expired sessions cannot be resumed. Start a new assessment?",
            )
            answer = await ui.read_required_value_async(
                label="Type 'yes' to start a new assessment, or 'no' to exit",
            )
            if answer.strip().lower() not in ("y", "yes"):
                raise ExitRequested
            clear_assessment_session_id_file()
            clear_assessment_timer_start()
            existing_id = None
        if existing_id:
            chat_session_id = existing_id
            is_resuming_session = True
            logger.info("Reusing assessment session session_id=%s", chat_session_id)
        else:
            github_identity = await _prompt_missing_github_identity(ui, github_identity)
            created_id, session_error = await chat_history.create_session(
                directory_name=Path.cwd().name,
                github_username=github_identity.github_username,
                github_name=github_identity.github_name,
                github_email=github_identity.github_email,
            )
            if session_error:
                logger.warning("Failed to create assessment session: %s", session_error)
                ui.show_error(
                    session_error,
                    hint="Check ASSESSMENT_PROXY_URL and ASSESSMENT_PROXY_TOKEN in your .env file.",
                )
            else:
                chat_session_id = created_id
                logger.info(
                    "Session created id=%s dir=%s user=%s name=%s email=%s",
                    chat_session_id,
                    Path.cwd().name,
                    github_identity.github_username,
                    bool(github_identity.github_name),
                    bool(github_identity.github_email),
                )
                try:
                    write_assessment_session_id(chat_session_id)
                    write_assessment_timer_start(utc_now_iso())
                except OSError as error:
                    logger.warning("Failed to persist assessment session id file: %s", error)
                    ui.show_error(
                        f"Failed to persist assessment session id: {error}",
                        hint="Ensure the .tenx/ directory is writable.",
                    )

    client = await _create_client(
        cwd=root_dir,
        session_id=chat_session_id,
        ui=ui,
        pause_working=pause_working,
        resume_working=resume_working,
    )
    ui._active_client = client
    assessment_duration_seconds = settings.tenx_assessment_duration_seconds
    timer_remaining_seconds = _remaining_timer_seconds(
        total_seconds=assessment_duration_seconds,
        is_resuming=is_resuming_session,
    )
    ui.set_timer(
        duration_seconds=timer_remaining_seconds,
        deadline_monotonic=time.monotonic() + timer_remaining_seconds,
    )

    ui.show_banner(version=_cli_version())
    meta_enabled = False
    session_cumulative_input_tokens = 0
    session_cumulative_output_tokens = 0
    turn_index = (
        next_turn_index_for_session(root_dir, chat_session_id)
        if chat_session_id
        else 0
    )
    turns_this_session = 0
    timer_warnings_shown: set[int] = set()
    previous_turn_ended_monotonic: float | None = None

    try:
        while True:
            # A plan rejection may have queued feedback as the next prompt
            # (see CLIUI.await_plan_decision). Consume it here before
            # blocking on user input so the candidate's feedback becomes
            # the next turn without an extra Enter.
            queued = ui.take_queued_prompt()
            if queued is not None:
                prompt = queued
            else:
                try:
                    prompt = await ui.read_prompt_async()
                except (EOFError, ExitRequested):
                    break

            if not prompt:
                continue

            ui.show_user_message(prompt)

            if prompt == "/exit":
                break
            if prompt == "/help":
                ui.show_help()
                continue
            if prompt == "/status":
                ui.show_status()
                continue
            if prompt == "/time":
                ui.show_time_remaining()
                continue
            if prompt == "/meta":
                meta_enabled = not meta_enabled
                ui.show_meta_mode(meta_enabled)
                continue
            if prompt == "/mode":
                ui.show_mode()
                continue
            if prompt == "/submit":
                await _run_submit(ui)
                continue
            if prompt == "/clear":
                await client.disconnect()
                client = await _create_client(
                    cwd=root_dir,
                    session_id=chat_session_id,
                    ui=ui,
                    pause_working=pause_working,
                    resume_working=resume_working,
                )
                ui._active_client = client
                # The fresh client starts in `settings.tenx_starting_mode`; sync
                # the UI side so the prompt prefix and `_current_mode` checks
                # don't disagree with the SDK after a /clear (see CLAUDE.md on
                # keeping observer/authority pairs in lockstep).
                ui._permission_mode = settings.tenx_starting_mode
                # Drop any queued plan-rejection feedback — it belonged to the
                # conversation we just discarded.
                ui.take_queued_prompt()
                ui.show_session_reset()
                continue

            # `/init` sends the canned "analyze + write TENX.md" prompt to
            # Claude but logs the user's action as `/init` (not the template)
            # so evaluators see what the candidate did, not the implementation.
            agent_prompt = load_init_tenx_md_prompt() if prompt == "/init" else prompt

            gap_ms_since_previous_turn = None
            if previous_turn_ended_monotonic is not None:
                gap_ms_since_previous_turn = int(
                    (time.perf_counter() - previous_turn_ended_monotonic) * 1000
                )
            started_at_iso = utc_now_iso()
            started = time.perf_counter()
            assistant_parts: list[str] = []
            usage: dict[str, Any] = {}
            status_code = 200
            assistant_started = False
            interrupted = False
            budget_exhausted = False
            ui.interrupt_event.clear()
            working = ui.start_working()
            working_holder[0] = working
            tool_calls_this_turn: list[dict[str, Any]] = []

            try:
                await client.query(agent_prompt)
                async for message in client.receive_response():
                    if ui.interrupt_event.is_set():
                        ui.stop_working(working)
                        working = None
                        working_holder[0] = None
                        interrupted = True
                        ui._write("[meta]Interrupted.[/meta]")
                        assistant_parts.append("[Request interrupted by user]")
                        try:
                            await client.interrupt()
                        except Exception as exc:
                            logger.debug("client interrupt failed: %s", exc)
                        break
                    if isinstance(message, ResultMessage):
                        is_budget_exhausted = message.subtype == "error_max_budget_usd"
                        # Claude Code emits `error_during_execution` when the turn is
                        # cancelled mid-flight — either the user pressed ESC to interrupt
                        # or rejected a tool-approval modal. Neither is a true error.
                        is_execution_interrupted = message.subtype == "error_during_execution"
                        if is_execution_interrupted:
                            ui.stop_working(working)
                            working = None
                            working_holder[0] = None
                            interrupted = True
                            # Plan rejection queues feedback as the next prompt;
                            # don't render a scary "Interrupted." between the
                            # rejected plan and the revised-plan response.
                            if not ui.has_queued_prompt():
                                ui._write("[meta]Interrupted.[/meta]")
                            assistant_parts.append("[Request interrupted by user]")
                            break
                        if is_budget_exhausted or message.is_error:
                            if is_budget_exhausted:
                                error_text = (
                                    "You have reached the usage limit for this assessment. "
                                    "You can still edit code manually and submit with "
                                    "'tenx-submit'. Contact your evaluator with questions."
                                )
                                budget_exhausted = True
                            else:
                                # ResultMessage carries error detail in `result` (string)
                                # and the category in `subtype`. There is no `.errors`
                                # list attribute — that's a Pydantic/requests pattern
                                # that doesn't exist on this SDK's type.
                                error_text = (
                                    message.result
                                    or f"API returned an error (subtype={message.subtype})"
                                )
                            status_code = 500
                            assistant_parts.append(error_text)
                            ui.stop_working(working)
                            working = None
                            working_holder[0] = None
                            ui.show_error(error_text, hint="" if budget_exhausted else _error_hint(error_text))
                            break
                    elif isinstance(message, AssistantMessage):
                        tool_calls_this_turn.extend(extract_tool_calls_from_content(message.content))

                        tool_label = describe_active_tool(message.content)
                        if tool_label and working is not None:
                            ui.update_working(working, tool_label)

                        candidate_text = extract_text_blocks(message.content)
                        if candidate_text:
                            if not assistant_started:
                                assistant_started = True
                            if not assistant_parts or len(candidate_text) >= len(assistant_parts[0]):
                                if assistant_parts:
                                    assistant_parts[0] = candidate_text
                                else:
                                    assistant_parts.append(candidate_text)

                    new_usage = extract_usage(message)
                    if new_usage:
                        usage.update(new_usage)

                if not interrupted and assistant_started and assistant_parts:
                    ui.commit_live_reply(assistant_parts[0])

            except KeyboardInterrupt:
                # Ctrl+C during a turn → interrupt the SDK and continue the REPL.
                ui.stop_working(working)
                working = None
                working_holder[0] = None
                interrupted = True
                ui._write("[meta]Interrupted.[/meta]")
                assistant_parts.append("[Request interrupted by user]")
                try:
                    await client.interrupt()
                except Exception as exc:
                    logger.debug("client interrupt failed: %s", exc)
            except Exception as error:
                logger.exception("REPL turn failed")
                status_code = 500
                error_message = f"{error}"
                assistant_parts.append(error_message)
                ui.stop_working(working)
                working = None
                working_holder[0] = None
                ui.show_error(
                    error_message,
                    hint="Your input was not lost. Try again or type /clear to reset the session.",
                )
            finally:
                ui.stop_working(working)
                working_holder[0] = None

            duration_ms = int((time.perf_counter() - started) * 1000)
            if meta_enabled:
                ui.print_meta_footer(duration_ms=duration_ms, usage=usage)

            assistant_raw = "".join(assistant_parts).strip()
            user_clean = clean_logs(prompt)
            assistant_clean = clean_logs(assistant_raw)
            turn_input_tokens, turn_output_tokens = usage_turn_tokens(usage)
            session_cumulative_input_tokens += turn_input_tokens
            session_cumulative_output_tokens += turn_output_tokens

            if status_code == 200 and not user_clean and not assistant_clean:
                previous_turn_ended_monotonic = time.perf_counter()
                continue

            if chat_session_id:
                created_at_iso = utc_now_iso()
                error_snippet = (assistant_raw[:2000] if assistant_raw else None) if status_code != 200 else None
                turn_record: dict[str, Any] = {
                    "session_id": chat_session_id,
                    "turn_index": turn_index,
                    "user_prompt": user_clean,
                    "assistant_text": assistant_clean,
                    "started_at": started_at_iso,
                    "created_at": created_at_iso,
                    "duration_ms": duration_ms,
                    "gap_ms_since_previous_turn": gap_ms_since_previous_turn,
                    "token_usage": {
                        "input": turn_input_tokens,
                        "output": turn_output_tokens,
                    },
                    "token_usage_cumulative": {
                        "input": session_cumulative_input_tokens,
                        "output": session_cumulative_output_tokens,
                    },
                    "tool_calls": tool_calls_this_turn,
                    "model": settings.model,
                    "cli_version": _cli_version(),
                    "status": "ok" if status_code == 200 else "error",
                    "error_message": error_snippet,
                }
                if github_identity.github_username:
                    turn_record["github_username"] = github_identity.github_username
                if github_identity.github_name:
                    turn_record["github_name"] = github_identity.github_name
                if github_identity.github_email:
                    turn_record["github_email"] = github_identity.github_email
                try:
                    append_assessment_turn(root_dir, turn_record)
                except OSError as error:
                    logger.warning("Failed to append assessment turn turn_index=%s: %s", turn_index, error)
                    ui.show_error(
                        f"Failed to append assessment turn log: {error}",
                        hint="Ensure the .tenx/ directory exists and is writable.",
                    )
                else:
                    logger.debug(
                        "Appended assessment turn turn_index=%s status=%s",
                        turn_index,
                        turn_record["status"],
                    )
                    turn_index += 1

            turns_this_session += 1
            previous_turn_ended_monotonic = time.perf_counter()

            if budget_exhausted:
                break

            # Check for timer warnings after each turn.
            ui.check_timer_warnings(warnings_shown=timer_warnings_shown)
    finally:
        ui._active_client = None
        ui.show_exit_summary(turn_count=turns_this_session, session_id=chat_session_id)
        logger.debug("Disconnecting Claude SDK client.")
        await client.disconnect()


def _cli_version() -> str:
    try:
        return package_version("tenx-ai")
    except PackageNotFoundError:
        return "0.0.0"
