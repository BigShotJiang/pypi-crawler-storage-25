"""Strip injected scaffolding from user/assistant text before persistence."""

from __future__ import annotations

import re

_SYSTEM_REMINDER_RE = re.compile(
    r"<system-reminder\b[^>]*>[\s\S]*?</system-reminder>",
    re.IGNORECASE,
)
_SYSTEM_REMINDER_UNDERSCORE_RE = re.compile(
    r"<system_reminder\b[^>]*>[\s\S]*?</system_reminder>",
    re.IGNORECASE,
)


def clean_logs(text: str) -> str:
    """Remove system-reminder blocks and collapse excessive blank lines."""
    if not text:
        return ""
    cleaned_text = _SYSTEM_REMINDER_RE.sub("", text)
    cleaned_text = _SYSTEM_REMINDER_UNDERSCORE_RE.sub("", cleaned_text)
    cleaned_text = re.sub(r"\n{3,}", "\n\n", cleaned_text)
    return cleaned_text.strip()

