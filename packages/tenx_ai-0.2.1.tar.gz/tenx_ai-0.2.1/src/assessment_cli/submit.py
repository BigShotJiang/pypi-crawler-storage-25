"""Git submit command: stage/commit/push, then upload turns and run FRQ (optional git skip for local dev)."""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import subprocess
import sys
from pathlib import Path

from rich.console import Console

from assessment_cli.chat_history_client import ChatHistoryClient
from assessment_cli.config import resolved_agent_workspace_directory, settings
from assessment_cli.frq_phase import run_frq_phase
from assessment_cli.logging_config import configure_logging
from assessment_cli.session_state import clear_assessment_session_id_file, read_assessment_session_id
from assessment_cli.turn_log import (
    assessment_turns_jsonl_path,
    clear_assessment_turns_log,
    upload_pending_assessment_turns_and_clear,
)

logger = logging.getLogger(__name__)


def _run_git_command(arguments: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    root_dir = resolved_agent_workspace_directory()
    logger.debug("Running git command args=%s cwd=%s", arguments, root_dir)
    return subprocess.run(
        ["git", *arguments],
        cwd=str(root_dir),
        check=check,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )


def _is_git_repository() -> bool:
    result = _run_git_command(["rev-parse", "--is-inside-work-tree"], check=False)
    return result.returncode == 0 and result.stdout.strip() == "true"


def _has_staged_changes() -> bool:
    result = _run_git_command(["diff", "--cached", "--quiet"], check=False)
    if result.returncode == 0:
        return False
    if result.returncode == 1:
        return True
    stderr_text = (result.stderr or "").strip()
    raise SystemExit(stderr_text or "Failed to check staged git diff.")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Stage all changes, create a commit, and push the current branch."
    )
    parser.add_argument(
        "-m",
        "--message",
        default="Assessment submission",
        help="Commit message (default: Assessment submission).",
    )
    return parser.parse_args()


def _capture_turns_from_jsonl(root_dir: Path) -> list[dict[str, object]]:
    """Read and parse turn records from JSONL before upload clears the file."""
    path = assessment_turns_jsonl_path(root_dir)
    if not path.exists() or path.stat().st_size == 0:
        return []
    captured: list[dict[str, object]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                captured.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return captured


def _capture_code_diff(root_dir: Path) -> str:
    """Capture the code diff to send to the proxy for evaluation."""
    is_local = (settings.environment or "").strip().lower() == "local"
    git_args = ["diff", "HEAD"] if is_local else ["show", "HEAD"]
    try:
        result = subprocess.run(
            ["git", *git_args],
            cwd=str(root_dir),
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=10,
        )
        diff_text = (result.stdout or "").strip() if result.returncode == 0 else ""
    except Exception:
        diff_text = ""
    if not diff_text:
        return "[code diff unavailable]"
    if len(diff_text) > 50_000:
        return diff_text[:50_000] + "\n...[truncated]..."
    return diff_text


async def _run_eval_phase(
    captured_turns: list[dict[str, object]],
    frq_pairs: list[dict[str, str]],
    root_dir: Path,
    session_id: str | None,
    chat_history: ChatHistoryClient,
) -> bool:
    """Send raw data to proxy for evaluation and PDF generation. Returns True on success."""
    try:
        code_diff = _capture_code_diff(root_dir)
        payload: dict[str, object] = {
            "session_id": session_id,
            "github_username": settings.tenx_github_username,
            "github_name": settings.tenx_github_name,
            "turns": captured_turns,
            "frq_pairs": [
                {"question": fp["question"], "candidate_answer": fp.get("answer", "")}
                for fp in frq_pairs
            ],
            "code_diff": code_diff,
        }
        print("Running evaluation...")
        eval_error = await chat_history.run_eval(payload)
        if eval_error:
            logger.warning("Evaluation failed: %s", eval_error)
            print(f"Warning: evaluation failed: {eval_error}", file=sys.stderr)
            return False
        print("Evaluation report uploaded.")
        return True
    except Exception as exc:
        logger.warning("Evaluation phase failed (non-fatal): %s", exc)
        print(f"Warning: evaluation failed: {exc}", file=sys.stderr)
        return False


async def _upload_assessment_turns_then_frq() -> str | None:
    console = Console(highlight=False)
    root_dir = resolved_agent_workspace_directory()
    session_id = read_assessment_session_id()

    # Capture turns before upload clears the JSONL file.
    captured_turns = _capture_turns_from_jsonl(root_dir)

    chat_history = ChatHistoryClient(
        base_url=settings.assessment_proxy_url,
        token=settings.assessment_proxy_token,
    )
    turn_count = len(captured_turns)
    logger.info("Starting assessment turn upload and FRQ phase workspace=%s", root_dir)
    status = console.status(
        f"[dim]Uploading {turn_count} turn(s)...[/dim]", spinner="dots12"
    )
    status.start()
    upload_error = await upload_pending_assessment_turns_and_clear(
        workspace_root=root_dir,
        chat_history=chat_history,
        clear=False,
    )
    status.stop()
    if upload_error:
        logger.warning("Assessment turn upload failed: %s", upload_error)
        return upload_error
    console.print(f"[green]Uploaded {turn_count} turn(s).[/green]")
    console.print()
    console.print("[bold]Starting FRQ phase...[/bold]")
    frq_pairs, frq_error = await run_frq_phase()
    if frq_error:
        logger.warning("FRQ phase failed: %s", frq_error)
    else:
        logger.info("FRQ phase completed successfully.")

    # Run evaluation after data is persisted; only clear the turn log on success.
    if captured_turns:
        eval_succeeded = await _run_eval_phase(
            captured_turns, frq_pairs, root_dir, session_id, chat_history
        )
        if eval_succeeded:
            clear_assessment_turns_log(root_dir)
        else:
            logger.warning("Skipping turn log clear because evaluation did not complete.")
    else:
        clear_assessment_turns_log(root_dir)

    return frq_error


def main() -> None:
    configure_logging()
    arguments = parse_arguments()
    root_dir = resolved_agent_workspace_directory()
    logger.info(
        "Starting tenx-submit workspace=%s env=%s",
        root_dir,
        (settings.environment or "").strip().lower(),
    )
    if not _is_git_repository():
        raise SystemExit(
            f"Workspace is not a git repository: {root_dir}\n"
            "Hint: Run 'git init' in your workspace directory first."
        )

    try:
        if (settings.environment or "").strip().lower() == "local":
            print("Skipping git add/commit/push (ENV=local).")
            logger.info("Skipping git add/commit/push because ENV=local.")
        else:
            _run_git_command(["add", "-A"])
            if _has_staged_changes():
                _run_git_command(["commit", "-m", arguments.message])
                # Show a short diffstat so the user sees what was committed.
                stat_result = _run_git_command(["diff", "--stat", "HEAD~1"], check=False)
                stat_text = (stat_result.stdout or "").strip()
                if stat_text:
                    print(stat_text)
                else:
                    print("Created commit.")
                logger.info("Created git commit for submission.")
            else:
                print("No staged changes after git add -A; skipping commit.")
                logger.info("No staged changes detected after git add -A.")
            _run_git_command(["push"])
            print("Pushed current branch.")
            logger.info("Pushed current branch.")
        print("Uploading assessment turns (if any)...")
        phase_error = asyncio.run(_upload_assessment_turns_then_frq())
        if phase_error:
            print(f"Error: {phase_error}", file=sys.stderr)
            print(
                "Hint: Check your network connection and proxy config, then retry with 'tenx-submit'.",
                file=sys.stderr,
            )
            logger.error("Submission flow failed with phase error: %s", phase_error)
            raise SystemExit(1)
        clear_assessment_session_id_file()
        console = Console(highlight=False)
        console.print("[bold green]Submission complete.[/bold green]")
        logger.info("Submission flow completed and assessment session id file cleared.")
    except subprocess.CalledProcessError as error:
        stdout_text = (error.stdout or "").strip()
        stderr_text = (error.stderr or "").strip()
        if stdout_text:
            print(stdout_text, file=sys.stderr)
        if stderr_text:
            print(stderr_text, file=sys.stderr)
        logger.error(
            "Git command failed returncode=%s stdout_present=%s stderr_present=%s",
            error.returncode,
            bool(stdout_text),
            bool(stderr_text),
        )
        raise SystemExit(error.returncode) from error
