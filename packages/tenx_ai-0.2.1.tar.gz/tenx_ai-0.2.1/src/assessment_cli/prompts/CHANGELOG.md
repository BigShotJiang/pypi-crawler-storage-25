# Prompt Version Changelog

All changes to system prompt files are logged here. Bump the version comment
at the top of each `.md` file whenever you edit it.

## assistant_system_prompt.md

### v1.3.0 — 2026-04-17
- Enforced Assessment Mode: disabled role-play, simulated scoring, and self-evaluation.
  Rationale: Eliminates hallucinated grading and preserves objective technical focus.
  Added Redirect Logic: automatically pivots out-of-scope queries back to the task.
  Rationale: Ensures high-integrity execution without meta-distractions.

### v1.2.0 — 2026-04-14
- Added "Streaming responsiveness" section to establish progress narration
  pattern: announce actions before using tools, optionally note results,
  creating continuous feedback rhythm (announce → act → result → next).
  Rationale: prevents long silences during tool execution; improves perceived
  responsiveness without requiring token-level streaming infrastructure;
  candidate sees what the AI is doing at each step, reducing uncertainty.

### v1.1.0 — 2026-04-14
- Replaced the single-line ambiguity rule with a three-tier policy:
  assume-and-state for scope/interpretation; pick-and-state-inline for
  tooling/mechanical choices; no-recommendation for engineering design
  (architecture, data structure, algorithm). Design decisions are the
  candidate's call and must not be supplanted by agent recommendations.
  Rationale: protect assessment signal on high-signal decisions while
  keeping the session fast on low-signal ones. Inline statements on
  tooling picks keep the transcript auditable — silence from the
  candidate is defensible as consent.

### v1.0.0 — 2026-04-08
- Initial versioned snapshot of existing prompt.

## technical_interviewer_system_prompt.md

### v1.0.0 — 2026-04-08
- Initial versioned snapshot of existing prompt.
