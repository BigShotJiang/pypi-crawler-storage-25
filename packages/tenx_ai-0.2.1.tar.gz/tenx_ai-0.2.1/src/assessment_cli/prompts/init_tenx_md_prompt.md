Please analyze this codebase and create a `TENX.md` file at the project root.

`TENX.md` is a brief guide for future AI assistant sessions on this project. It is loaded as additional system-prompt context on every new session, so subsequent conversations can pick up where you left off without re-exploring the same files.

Include:

- **Project purpose** — one-paragraph summary of what the codebase does and who uses it
- **Structure** — top-level directory layout with a one-liner per major folder
- **Commands** — how to build, test, run, and lint (exact shell commands)
- **Conventions** — coding style, naming patterns, architectural invariants worth preserving
- **Gotchas** — surprises a new contributor would trip on (shared contracts, hidden coupling, anti-patterns to avoid)

Keep it concise — ideally under 100 lines. Use markdown headings and short bullet lists. Do not duplicate information a reader can get from `README.md` or an obvious directory listing.

Workflow:
1. Start with a quick pass over the repo (Glob / Read) to understand shape — README, package.json / pyproject.toml, top-level directories.
2. Look at a handful of representative source files to infer conventions.
3. Write `TENX.md` at the project root using the Write tool.

Once the file exists, summarize in one or two sentences what you captured and suggest one or two edits the candidate might want to make before relying on it.
