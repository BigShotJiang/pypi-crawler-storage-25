"""Configure assessment CLI logging from environment-backed settings."""

from __future__ import annotations

import logging

from assessment_cli.config import settings

_configured = False


def configure_logging() -> None:
    """Initialize stderr logging once for CLI diagnostics."""
    global _configured
    if _configured:
        return
    logging.basicConfig(
        level=_resolved_log_level(settings.tenx_log_level),
        format="%(asctime)s %(levelname)s %(name)s - %(message)s",
    )
    _configured = True


def _resolved_log_level(level_name: str) -> int:
    """Map configured level names to stdlib logging constants."""
    normalized = (level_name or "WARNING").strip().upper()
    return getattr(logging, normalized, logging.WARNING)
