"""Tenx assessment CLI package."""

