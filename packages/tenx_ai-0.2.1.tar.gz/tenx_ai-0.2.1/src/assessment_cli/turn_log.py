"""Append and upload assessment turn records as JSONL under `.tenx/`."""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from pathlib import Path
from typing import Any

from assessment_cli.chat_history_client import ChatHistoryClient

logger = logging.getLogger(__name__)

TURNS_JSONL_RELATIVE = Path(".tenx") / "assessment_turns.jsonl"
SCHEMA_VERSION = 1


def assessment_turns_jsonl_path(workspace_root: Path) -> Path:
    return workspace_root / TURNS_JSONL_RELATIVE


def next_turn_index_for_session(workspace_root: Path, session_id: str) -> int:
    """Next `turn_index` for `session_id` from JSONL so restarts continue without duplicate indices."""
    path = assessment_turns_jsonl_path(workspace_root)
    if not path.exists() or path.stat().st_size == 0:
        return 0
    sid = session_id.strip()
    max_index = -1
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if obj.get("session_id") != sid:
            continue
        turn_index = obj.get("turn_index")
        if isinstance(turn_index, int) and turn_index > max_index:
            max_index = turn_index
    return max_index + 1 if max_index >= 0 else 0


def append_assessment_turn(workspace_root: Path, record: dict[str, Any]) -> None:
    """Append one JSON line; `record` must include `session_id` and turn fields."""
    payload = dict(record)
    payload["schema_version"] = SCHEMA_VERSION
    path = assessment_turns_jsonl_path(workspace_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(payload, ensure_ascii=False, default=str) + "\n"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(line)
    logger.debug("Appended assessment turn record path=%s", path)


def _turn_dict_for_api(line_obj: dict[str, Any]) -> dict[str, Any]:
    """Strip local-only keys for POST /v1/chat-history/assessment-turns/batch body items."""
    skip = {
        "schema_version",
        "session_id",
        "github_username",
        "github_name",
        "github_email",
    }
    return {key: value for key, value in line_obj.items() if key not in skip}


def clear_assessment_turns_log(workspace_root: Path) -> None:
    """Truncate the assessment turns JSONL file."""
    path = assessment_turns_jsonl_path(workspace_root)
    if path.exists():
        path.write_text("", encoding="utf-8")
        logger.info("Cleared assessment turn log path=%s", path)


async def upload_pending_assessment_turns_and_clear(
    *,
    workspace_root: Path,
    chat_history: ChatHistoryClient,
    clear: bool = True,
) -> str | None:
    """POST pending JSONL turns in session order, then optionally truncate the file on success.

    Returns an error string, or None on success. No-ops when proxy is not configured,
    the file is missing, or the file is empty.
    """
    if not chat_history.base_url:
        logger.debug("Skipping assessment turn upload because proxy base URL is not configured.")
        return None

    path = assessment_turns_jsonl_path(workspace_root)
    if not path.exists() or path.stat().st_size == 0:
        logger.debug("No pending assessment turn log to upload path=%s", path)
        return None

    raw_text = path.read_text(encoding="utf-8")
    lines = [line.strip() for line in raw_text.splitlines() if line.strip()]
    if not lines:
        logger.debug("Assessment turn log has no non-empty lines path=%s", path)
        return None

    parsed: list[dict[str, Any]] = []
    for line_number, line in enumerate(lines, start=1):
        try:
            parsed.append(json.loads(line))
        except json.JSONDecodeError as error:
            return f"Invalid JSON in assessment turns log line {line_number}: {error}"

    by_session: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in parsed:
        session_id = item.get("session_id")
        if not isinstance(session_id, str) or not session_id.strip():
            return "Assessment turn log line missing session_id."
        by_session[session_id.strip()].append(item)

    for session_id, turns in by_session.items():
        turns.sort(key=lambda row: int(row.get("turn_index", 0)))
        from assessment_cli.config import settings as cli_settings

        batch_body: dict[str, object] = {
            "session_id": session_id,
            "github_username": cli_settings.tenx_github_username,
            "turns": [_turn_dict_for_api(row) for row in turns],
        }
        logger.info(
            "Uploading pending assessment turns session_id=%s turn_count=%s",
            session_id,
            len(turns),
        )
        error_message = await chat_history.save_assessment_turns_batch(batch_body)
        if error_message:
            logger.warning(
                "Failed uploading pending assessment turns session_id=%s error=%s",
                session_id,
                error_message,
            )
            return error_message

    if clear:
        path.write_text("", encoding="utf-8")
        logger.info("Cleared uploaded assessment turn log path=%s", path)
    return None
