# cli

CLI client for Tenx hiring assessments.

## Highlights

- Uses the Claude Agent SDK for local interactive coding sessions.
- Appends each REPL turn to `.tenx/assessment_turns.jsonl` (when a session id is present).
- `tenx-submit` uploads pending turns to `proxy`, then runs the FRQ phase and saves free-response rows.

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -e ".[dev]"
copy .env.example .env
```

Set `ANTHROPIC_API_KEY` in `.env` before running.

## Run

```bash
tenx-ai
```

The CLI starts a 60-minute assessment timer when the process starts. Use `/time` to display the remaining time.

Set `TENX_ASSESSMENT_DURATION_SECONDS` in `.env` to override the timer length.

Or:

```bash
python -m assessment_cli
```

## Edit approval mode

Set `TENX_EDIT_APPROVAL=true` in `.env` to review proposed `Write`, `Edit`, and `Bash` tool actions before they run.

- `TENX_EDIT_APPROVAL=false` (default): similar to Claude Code `acceptEdits` for file edits.
- `TENX_EDIT_APPROVAL=true`: similar to Claude Code `default` mode for these tools.

Approval keys:

- `y` accept
- `n` reject
- `d` show full diff
- `?` show key help

Compared to Claude Code, this is a focused terminal subset of the same permission model concepts. For full Claude Code mode controls, see the [CLI reference](https://code.claude.com/en/cli-reference).

## Submit changes

Run this from your assessment workspace to stage, commit, and push:

```bash
tenx-submit
```

Optional commit message:

```bash
tenx-submit --message "Assessment submission"
```

By default, after a successful push, `tenx-submit`:

- Uploads any pending lines from `.tenx/assessment_turns.jsonl` to the proxy (then clears that file on success).
- Starts an FRQ phase: generates questions from your most recent commit (`HEAD`), prompts for answers, and saves rows to `proxy`.

For **local development**, set **`ENV=local`** in `.env` to skip `git add` / `commit` / `push` and go straight to upload + FRQ (workspace must still be a git repository for FRQ context).

## Chat history persistence

Set these in `.env` to enable persistence:

- `ASSESSMENT_PROXY_URL` (for example `http://localhost:8000`)
- `ASSESSMENT_PROXY_TOKEN` (must match the proxy’s `PROXY_BEARER_SECRET`)

When `ASSESSMENT_PROXY_URL` is unset, there is no session id and no JSONL logging to the proxy. FRQ persistence also requires the URL and token.

With `ASSESSMENT_PROXY_URL` set, the **first** `tenx-ai` run creates a session and writes `.tenx/assessment_session_id`; later runs **reuse** it until **`tenx-submit`** succeeds (which clears the JSONL upload and that file so the next assessment gets a **new** session).

## Breaking change (Phase 0)

The proxy path and JSON shape changed: see [`proxy/README.md`](../proxy/README.md).

## Security notes for Codespaces

- Do not store the Supabase secret API key in the CLI.
- Use only proxy URL and bearer token in CLI env.
- Treat `ASSESSMENT_PROXY_TOKEN` as sensitive and rotate if leaked.
