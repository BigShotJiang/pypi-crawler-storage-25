"""Training analysis Streamlit page."""
