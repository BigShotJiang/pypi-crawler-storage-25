from __future__ import annotations

import pytest
import respx
import httpx

import naggy
from naggy import NaggyClient, NaggyHTTPError
from naggy._event import llm_event, feedback_event


BASE = "https://test.naggy.local"


@pytest.fixture
def client():
    return NaggyClient("nag_sk_test", base_url=BASE)


def test_init_sets_default_client():
    c = naggy.init("nag_sk_x", base_url=BASE)
    assert naggy.get_client() is c
    assert c.api_key == "nag_sk_x"


def test_llm_event_shape():
    e = llm_event(provider="anthropic", model="claude-3-5-haiku-20241022", input_tokens=100, output_tokens=50)
    assert e["type"] == "llm_call"
    assert e["provider"] == "anthropic"
    assert e["input_tokens"] == 100
    assert "trace_id" in e
    assert "event_id" in e


def test_feedback_event_shape():
    e = feedback_event(trace_id="abc-123", score=0.9, label="good")
    assert e["type"] == "feedback"
    assert e["trace_id"] == "abc-123"
    assert e["score"] == 0.9


@respx.mock
def test_ingest(client):
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 1})
    )
    result = client.ingest([llm_event(provider="openai", model="gpt-4o")])
    assert result["accepted"] == 1
    assert route.called


@respx.mock
def test_http_error_raises(client):
    respx.get(f"{BASE}/v1/naggyai/overview").mock(
        return_value=httpx.Response(401, json={"error": "Unauthorized"})
    )
    with pytest.raises(NaggyHTTPError) as exc_info:
        client.overview()
    assert exc_info.value.status_code == 401


@respx.mock
def test_score(client):
    respx.get(f"{BASE}/v1/naggyai/score").mock(
        return_value=httpx.Response(200, json={"score": 82.5, "grade": "B"})
    )
    result = client.score()
    assert result["score"] == 82.5


@respx.mock
def test_list_insights(client):
    respx.get(f"{BASE}/v1/naggyai/insights").mock(
        return_value=httpx.Response(200, json={"insights": [{"id": "i1", "text": "Cost spike"}]})
    )
    items = client.list_insights()
    assert items[0]["id"] == "i1"


@respx.mock
def test_submit_feedback(client):
    respx.post(f"{BASE}/v1/naggyai/feedback").mock(
        return_value=httpx.Response(200, json={"status": "recorded"})
    )
    result = client.submit_feedback("trace-xyz", score=1.0, label="thumbs_up")
    assert result["status"] == "recorded"


def test_trace_context_no_client_is_silent():
    """trace_context with no client should not raise."""
    naggy._default_client = None
    with naggy.trace_context("anthropic", "claude-3-5-haiku-20241022") as ctx:
        ctx.input_tokens = 10
        ctx.output_tokens = 5
    # no exception = pass


@respx.mock
def test_trace_context_flushes(client):
    naggy.init("nag_sk_test", base_url=BASE)
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 1})
    )
    with naggy.trace_context("anthropic", "claude-opus-4-7") as ctx:
        ctx.input_tokens = 200
        ctx.output_tokens = 80
    assert route.called
    sent = route.calls[0].request
    import json
    body = json.loads(sent.content)
    assert body["events"][0]["provider"] == "anthropic"
    assert body["events"][0]["input_tokens"] == 200
