from __future__ import annotations

import pytest
import respx
import httpx

from naggy import AsyncNaggyClient, NaggyHTTPError
from naggy._event import llm_event


BASE = "https://test.naggy.local"


@pytest.fixture
def client():
    return AsyncNaggyClient("nag_sk_test", base_url=BASE)


@respx.mock
async def test_ingest(client):
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 1})
    )
    result = await client.ingest([llm_event(provider="openai", model="gpt-4o")])
    assert result["accepted"] == 1
    assert route.called


@respx.mock
async def test_http_error_raises(client):
    respx.get(f"{BASE}/v1/naggyai/overview").mock(
        return_value=httpx.Response(401, json={"error": "Unauthorized"})
    )
    with pytest.raises(NaggyHTTPError) as exc_info:
        await client.overview()
    assert exc_info.value.status_code == 401


@respx.mock
async def test_score(client):
    respx.get(f"{BASE}/v1/naggyai/score").mock(
        return_value=httpx.Response(200, json={"score": 91.0, "grade": "A"})
    )
    result = await client.score()
    assert result["score"] == 91.0


@respx.mock
async def test_list_insights(client):
    respx.get(f"{BASE}/v1/naggyai/insights").mock(
        return_value=httpx.Response(200, json={"insights": [{"id": "i2", "text": "Latency spike"}]})
    )
    items = await client.list_insights()
    assert items[0]["id"] == "i2"


@respx.mock
async def test_submit_feedback(client):
    respx.post(f"{BASE}/v1/naggyai/feedback").mock(
        return_value=httpx.Response(200, json={"status": "recorded"})
    )
    result = await client.submit_feedback("trace-abc", score=0.8, label="good")
    assert result["status"] == "recorded"


@respx.mock
async def test_health(client):
    respx.get(f"{BASE}/v1/naggyai/health").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )
    result = await client.health()
    assert result["status"] == "ok"


@respx.mock
async def test_revoke_key(client):
    respx.delete(f"{BASE}/v1/naggyai/keys/key-123").mock(
        return_value=httpx.Response(200, json={"revoked": True})
    )
    result = await client.revoke_key("key-123")
    assert result["revoked"] is True
