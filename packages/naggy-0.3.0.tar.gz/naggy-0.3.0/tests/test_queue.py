from __future__ import annotations

import pytest
import respx
import httpx

from naggy import AsyncNaggyClient, AsyncNaggyQueue, NaggyClient, NaggyQueue
from naggy._event import llm_event


BASE = "https://test.naggy.local"


# ── Sync NaggyQueue ───────────────────────────────────────────────────────────

@respx.mock
def test_queue_manual_flush():
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 2})
    )
    client = NaggyClient("nag_sk_test", base_url=BASE)
    queue = NaggyQueue(client, max_size=100, flush_interval=60.0)
    queue.push(llm_event(provider="openai", model="gpt-4o"))
    queue.push(llm_event(provider="anthropic", model="claude-opus-4-7"))
    assert not route.called
    queue.flush()
    assert route.called
    import json
    body = json.loads(route.calls[0].request.content)
    assert len(body["events"]) == 2
    queue.close()


@respx.mock
def test_queue_auto_flush_on_max_size():
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 3})
    )
    client = NaggyClient("nag_sk_test", base_url=BASE)
    queue = NaggyQueue(client, max_size=3, flush_interval=60.0)
    for _ in range(3):
        queue.push(llm_event(provider="openai", model="gpt-4o"))
    assert route.called
    queue.close()


@respx.mock
def test_queue_close_flushes_remaining():
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 1})
    )
    client = NaggyClient("nag_sk_test", base_url=BASE)
    queue = NaggyQueue(client, max_size=100, flush_interval=60.0)
    queue.push(llm_event(provider="openai", model="gpt-4o"))
    assert not route.called
    queue.close()
    assert route.called


@respx.mock
def test_queue_context_manager():
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 1})
    )
    client = NaggyClient("nag_sk_test", base_url=BASE)
    with NaggyQueue(client, max_size=100, flush_interval=60.0) as queue:
        queue.push(llm_event(provider="openai", model="gpt-4o"))
    assert route.called


@respx.mock
def test_queue_flush_error_drops_silently():
    respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(500, json={"error": "server error"})
    )
    client = NaggyClient("nag_sk_test", base_url=BASE)
    queue = NaggyQueue(client, max_size=100, flush_interval=60.0)
    queue.push(llm_event(provider="openai", model="gpt-4o"))
    queue.flush()  # should not raise
    queue.close()


# ── Async AsyncNaggyQueue ─────────────────────────────────────────────────────

@respx.mock
async def test_async_queue_manual_flush():
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 2})
    )
    client = AsyncNaggyClient("nag_sk_test", base_url=BASE)
    queue = AsyncNaggyQueue(client, max_size=100, flush_interval=60.0)
    await queue.push(llm_event(provider="openai", model="gpt-4o"))
    await queue.push(llm_event(provider="anthropic", model="claude-opus-4-7"))
    assert not route.called
    await queue.flush()
    assert route.called
    import json
    body = json.loads(route.calls[0].request.content)
    assert len(body["events"]) == 2


@respx.mock
async def test_async_queue_auto_flush_on_max_size():
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 3})
    )
    client = AsyncNaggyClient("nag_sk_test", base_url=BASE)
    queue = AsyncNaggyQueue(client, max_size=3, flush_interval=60.0)
    for _ in range(3):
        await queue.push(llm_event(provider="openai", model="gpt-4o"))
    assert route.called


@respx.mock
async def test_async_queue_close_flushes_remaining():
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 1})
    )
    client = AsyncNaggyClient("nag_sk_test", base_url=BASE)
    queue = AsyncNaggyQueue(client, max_size=100, flush_interval=60.0)
    await queue.push(llm_event(provider="openai", model="gpt-4o"))
    assert not route.called
    await queue.close()
    assert route.called


@respx.mock
async def test_async_queue_context_manager():
    route = respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(200, json={"accepted": 1})
    )
    client = AsyncNaggyClient("nag_sk_test", base_url=BASE)
    async with AsyncNaggyQueue(client, max_size=100, flush_interval=60.0) as queue:
        await queue.push(llm_event(provider="openai", model="gpt-4o"))
    assert route.called


@respx.mock
async def test_async_queue_flush_error_drops_silently():
    respx.post(f"{BASE}/v1/naggyai/events").mock(
        return_value=httpx.Response(500, json={"error": "server error"})
    )
    client = AsyncNaggyClient("nag_sk_test", base_url=BASE)
    queue = AsyncNaggyQueue(client, max_size=100, flush_interval=60.0)
    await queue.push(llm_event(provider="openai", model="gpt-4o"))
    await queue.flush()  # should not raise
