from __future__ import annotations

import functools
import time
import uuid
from contextlib import contextmanager
from typing import Any, Callable, Generator, TypeVar

F = TypeVar("F", bound=Callable[..., Any])

_PROVIDER_TOKENS: dict[str, tuple[str, str]] = {
    # provider -> (input_tokens_attr, output_tokens_attr) on response
    "anthropic": ("input_tokens", "output_tokens"),
    "openai": ("prompt_tokens", "completion_tokens"),
}


class TraceContext:
    """Holds mutable state for a single in-flight trace."""

    def __init__(
        self,
        trace_id: str,
        provider: str,
        model: str,
        environment: str,
    ) -> None:
        self.trace_id = trace_id
        self.provider = provider
        self.model = model
        self.environment = environment
        self._start = time.monotonic()
        self.input_tokens: int = 0
        self.output_tokens: int = 0
        self.cost_usd: float = 0.0
        self.status: str = "success"
        self.error: str | None = None

    def finish(self) -> dict[str, Any]:
        from ._event import llm_event
        return llm_event(
            provider=self.provider,
            model=self.model,
            input_tokens=self.input_tokens,
            output_tokens=self.output_tokens,
            cost_usd=self.cost_usd,
            latency_ms=int((time.monotonic() - self._start) * 1000),
            status=self.status,
            trace_id=self.trace_id,
            environment=self.environment,
        )


@contextmanager
def trace_context(
    provider: str,
    model: str,
    *,
    client: Any = None,
    environment: str = "production",
    trace_id: str | None = None,
) -> Generator[TraceContext, None, None]:
    """Context manager that records a trace and flushes it on exit."""
    from . import _default_client

    naggy = client or _default_client
    ctx = TraceContext(
        trace_id=trace_id or str(uuid.uuid4()),
        provider=provider,
        model=model,
        environment=environment,
    )
    try:
        yield ctx
    except Exception as exc:
        ctx.status = "error"
        ctx.error = type(exc).__name__
        raise
    finally:
        if naggy is not None:
            try:
                naggy.ingest([ctx.finish()])
            except Exception:
                pass  # never let telemetry break user code


def trace(
    provider: str,
    model: str,
    *,
    client: Any = None,
    environment: str = "production",
) -> Callable[[F], F]:
    """Decorator: wrap an LLM-calling function and send one event per call."""

    def decorator(fn: F) -> F:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with trace_context(provider, model, client=client, environment=environment) as ctx:
                result = fn(*args, **kwargs)
                _fill_tokens_from_response(ctx, provider, result)
                return result

        return wrapper  # type: ignore[return-value]

    return decorator


def _fill_tokens_from_response(ctx: TraceContext, provider: str, response: Any) -> None:
    """Best-effort token extraction from Anthropic/OpenAI response objects."""
    try:
        if provider == "anthropic" and hasattr(response, "usage"):
            ctx.input_tokens = getattr(response.usage, "input_tokens", 0) or 0
            ctx.output_tokens = getattr(response.usage, "output_tokens", 0) or 0
        elif provider == "openai" and hasattr(response, "usage"):
            ctx.input_tokens = getattr(response.usage, "prompt_tokens", 0) or 0
            ctx.output_tokens = getattr(response.usage, "completion_tokens", 0) or 0
    except Exception:
        pass
