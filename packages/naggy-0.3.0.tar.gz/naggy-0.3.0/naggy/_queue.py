from __future__ import annotations

import asyncio
import atexit
import logging
import threading
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ._client import AsyncNaggyClient, NaggyClient

logger = logging.getLogger(__name__)


class NaggyQueue:
    """Thread-safe event buffer that flushes to NaggyAI in batches.

    Flushes automatically when the buffer reaches *max_size* or every
    *flush_interval* seconds (background daemon thread).  Registers an
    atexit handler so in-flight events are sent on process exit.

    Usage::

        queue = NaggyQueue(client, max_size=100, flush_interval=5.0)
        queue.push(llm_event(...))
        queue.close()          # or use as a context manager
    """

    def __init__(
        self,
        client: NaggyClient,
        *,
        max_size: int = 100,
        flush_interval: float = 5.0,
    ) -> None:
        self._client = client
        self._max_size = max_size
        self._flush_interval = flush_interval
        self._buffer: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True, name="naggy-queue")
        self._thread.start()
        atexit.register(self.close)

    # ── Public API ────────────────────────────────────────────────────────────

    def push(self, event: dict[str, Any]) -> None:
        with self._lock:
            self._buffer.append(event)
            if len(self._buffer) >= self._max_size:
                self._flush_locked()

    def flush(self) -> None:
        with self._lock:
            self._flush_locked()

    def close(self) -> None:
        self._stop.set()
        self._thread.join(timeout=5.0)
        self.flush()

    # ── Context manager ───────────────────────────────────────────────────────

    def __enter__(self) -> NaggyQueue:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ── Internals ─────────────────────────────────────────────────────────────

    def _flush_locked(self) -> None:
        if not self._buffer:
            return
        events, self._buffer = self._buffer, []
        try:
            self._client.ingest(events)
        except Exception as exc:
            logger.warning("naggy: flush failed, %d events dropped: %s", len(events), exc)

    def _run(self) -> None:
        while not self._stop.wait(self._flush_interval):
            self.flush()


class AsyncNaggyQueue:
    """Async event buffer that flushes to NaggyAI in batches.

    Flushes automatically when the buffer reaches *max_size* or every
    *flush_interval* seconds (asyncio background task).

    Usage::

        async with AsyncNaggyQueue(async_client) as queue:
            await queue.push(llm_event(...))

        # or manually:
        queue = AsyncNaggyQueue(async_client)
        await queue.start()
        await queue.push(llm_event(...))
        await queue.close()
    """

    def __init__(
        self,
        client: AsyncNaggyClient,
        *,
        max_size: int = 100,
        flush_interval: float = 5.0,
    ) -> None:
        self._client = client
        self._max_size = max_size
        self._flush_interval = flush_interval
        self._buffer: list[dict[str, Any]] = []
        self._lock = asyncio.Lock()
        self._task: asyncio.Task[None] | None = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def start(self) -> None:
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._run())

    async def close(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self.flush()

    # ── Context manager ───────────────────────────────────────────────────────

    async def __aenter__(self) -> AsyncNaggyQueue:
        await self.start()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # ── Public API ────────────────────────────────────────────────────────────

    async def push(self, event: dict[str, Any]) -> None:
        async with self._lock:
            self._buffer.append(event)
            if len(self._buffer) >= self._max_size:
                await self._flush_locked()

    async def flush(self) -> None:
        async with self._lock:
            await self._flush_locked()

    # ── Internals ─────────────────────────────────────────────────────────────

    async def _flush_locked(self) -> None:
        if not self._buffer:
            return
        events, self._buffer = self._buffer, []
        try:
            await self._client.ingest(events)
        except Exception as exc:
            logger.warning("naggy: flush failed, %d events dropped: %s", len(events), exc)

    async def _run(self) -> None:
        while True:
            await asyncio.sleep(self._flush_interval)
            await self.flush()
