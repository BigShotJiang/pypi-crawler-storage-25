from __future__ import annotations

import time
from typing import Any


def instrument(anthropic_client: Any, *, naggy_client: Any = None, environment: str = "production") -> Any:
    """Patch an anthropic.Anthropic instance to auto-send events to NaggyAI."""
    from naggy import _default_client

    naggy = naggy_client or _default_client
    if naggy is None:
        raise RuntimeError("Call naggy.init() or pass naggy_client= before instrumenting.")

    original_create = anthropic_client.messages.create

    def patched_create(*args: Any, **kwargs: Any) -> Any:
        import uuid
        trace_id = str(uuid.uuid4())
        start = time.monotonic()
        status = "success"
        response = None
        try:
            response = original_create(*args, **kwargs)
            return response
        except Exception as exc:
            status = "error"
            raise
        finally:
            latency_ms = int((time.monotonic() - start) * 1000)
            input_tokens = output_tokens = 0
            model = kwargs.get("model", "unknown")
            if response is not None and hasattr(response, "usage"):
                input_tokens = getattr(response.usage, "input_tokens", 0) or 0
                output_tokens = getattr(response.usage, "output_tokens", 0) or 0
            from naggy._event import llm_event
            try:
                naggy.ingest([llm_event(
                    provider="anthropic",
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    latency_ms=latency_ms,
                    status=status,
                    trace_id=trace_id,
                    environment=environment,
                )])
            except Exception:
                pass

    anthropic_client.messages.create = patched_create
    return anthropic_client
