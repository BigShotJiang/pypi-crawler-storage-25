from __future__ import annotations

import time
import uuid
from typing import Any


def _now_ms() -> int:
    return int(time.time() * 1000)


def llm_event(
    *,
    provider: str,
    model: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cost_usd: float = 0.0,
    latency_ms: int = 0,
    status: str = "success",
    trace_id: str | None = None,
    environment: str = "production",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "type": "llm_call",
        "event_id": str(uuid.uuid4()),
        "timestamp_ms": _now_ms(),
        "provider": provider,
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cost_usd": cost_usd,
        "latency_ms": latency_ms,
        "status": status,
        "trace_id": trace_id or str(uuid.uuid4()),
        "environment": environment,
        **(metadata or {}),
    }


def feedback_event(
    *,
    trace_id: str,
    score: float,
    label: str = "",
    comment: str = "",
    environment: str = "production",
) -> dict[str, Any]:
    return {
        "type": "feedback",
        "event_id": str(uuid.uuid4()),
        "timestamp_ms": _now_ms(),
        "trace_id": trace_id,
        "score": score,
        "label": label,
        "comment": comment,
        "environment": environment,
    }
