# Fonts for Multilingual Notes (Non-Latin Scripts)

On-screen notes and subtitles use system defaults unless a font path is set. For **Devanagari (Hindi)**, **Arabic**, or other non-Latin scripts, you must use a font that includes the required glyphs; otherwise text will render as tofu (□).

## Recommended: Noto Fonts

**Noto Sans** (or **Noto Sans Devanagari**) supports Latin + Devanagari. Download:

- [Google Fonts: Noto Sans](https://fonts.google.com/noto/specimen/Noto+Sans)
- [Google Fonts: Noto Sans Devanagari](https://fonts.google.com/noto/specimen/Noto+Sans+Devanagari)

Or install via system package manager:

```bash
# macOS (Homebrew)
brew install font-noto-sans font-noto-sans-devanagari

# Ubuntu/Debian
sudo apt install fonts-noto fonts-noto-core fonts-noto-cjk
```

Place a `.ttf` file in this directory (e.g. `fonts/NotoSans-Regular.ttf`) or reference an installed path.

## Configuration

| Variable | Description |
|----------|-------------|
| `ON_SCREEN_NOTES_FONT_PATH` | Default font for all variants. Path to `.ttf` file. |
| `NOTES_FONT_L2` | Font for variant `l2` (second language). |
| `NOTES_FONT_HI_IN` | Font for `hi-IN` (Hindi India). |

Resolution order per variant: `NOTES_FONT_{VARIANT_ID}` → `NOTES_FONT_{LANG}` → `ON_SCREEN_NOTES_FONT_PATH`.

**Example (Hindi notes):**

```bash
ON_SCREEN_NOTES_ENABLED=1 \
ON_SCREEN_NOTES_FONT_PATH=/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc \
# or per variant:
NOTES_FONT_HI_IN=/path/to/NotoSansDevanagari-Regular.ttf \
make worker
```
