# SlideSherlock

Turn a PPTX into a narrated explainer video with visual guidance (highlight/trace/zoom), while preventing hallucinations using an Evidence Index + Verifier.

## Architecture

SlideSherlock is built with an **artifact-first pipeline** where every stage writes outputs to S3/MinIO with stable paths and updates Postgres status. For a full pipeline diagram, stage breakdown, and **recommended next steps** (testing, production hardening, features, deployment), see **[ARCHITECTURE.md](ARCHITECTURE.md)**.

### Key Components

1. **Evidence Index**: Tracks all evidence with `evidence_id` + `source_ref` (bbox / ppt shape id / page+char offsets)
2. **Diagram Understanding**: 
   - `G_native` from PPT objects (shapes/connectors/groups)
   - Optional `G_vision` from PNG + OCR
   - Merged to `G_unified` with provenance (NATIVE/VISION/BOTH) + confidence + NEEDS_REVIEW flags
3. **Script Generation**: Produces segments with `claim_id`, `evidence_ids`, `entity_ids`
4. **Verifier**: Enforces grounding with PASS/REWRITE/REMOVE, loops until no REWRITE remains
5. **Timeline Builder**: Generates HIGHLIGHT/TRACE/ZOOM actions mapped to entity geometry
6. **Renderer**: Generates overlays and composes final video with FFmpeg

## Repository Structure

```
/slidesherlock
  /apps
    /api          - REST API for job submission and status
    /worker       - Pipeline worker that processes jobs
  /packages
    /core         - Core business logic (diagram, script, verifier, timeline)
    /providers    - LLM/TTS/OCR provider interfaces
    /schemas      - TypeScript schemas and types
  /infra
    /docker       - Docker configurations
  docker-compose.yml
  Makefile
  README.md
```

## Prerequisites

### System Dependencies

- **Python 3.11+** (3.12 recommended)
- **Docker and Docker Compose** (for PostgreSQL, Redis, MinIO)
- **LibreOffice** (for PPTX to PDF conversion)
  - macOS: `brew install --cask libreoffice`
  - Ubuntu/Debian: `sudo apt-get install libreoffice`
  - CentOS/RHEL: `sudo yum install libreoffice`
- **Poppler** (for PDF to PNG conversion, required by pdf2image)
  - macOS: `brew install poppler`
  - Ubuntu/Debian: `sudo apt-get install poppler-utils`
  - CentOS/RHEL: `sudo yum install poppler-utils`
- **FFmpeg** (for video composition - future stage)

### Python Dependencies

All Python dependencies are consolidated in `requirements.txt` and will be installed automatically with `make setup`.

## Quick Start

1. **Start infrastructure services:**
   ```bash
   make up
   ```

2. **Install dependencies:**
   ```bash
   make install
   ```

3. **Build all packages:**
   ```bash
   make build
   ```

4. **Initialize database:**
   ```bash
   make migrate
   ```

5. **Start the API server (in one terminal):**
   ```bash
   make api
   ```

6. **Start the worker (in another terminal):**
   ```bash
   make worker
   ```

## Usage

### Submit a Job

```bash
curl -X POST http://localhost:3000/jobs \
  -F "file=@presentation.pptx"
```

Response:
```json
{
  "job_id": "uuid-here",
  "status": "PENDING",
  "message": "Job submitted successfully"
}
```

### Check Job Status

```bash
curl http://localhost:3000/jobs/{job_id}
```

### Get Artifacts

```bash
# Get script
curl http://localhost:3000/jobs/{job_id}/artifacts/script

# Get verify report
curl http://localhost:3000/jobs/{job_id}/artifacts/verify_report

# Get timeline
curl http://localhost:3000/jobs/{job_id}/artifacts/timeline

# Get final video
curl http://localhost:3000/jobs/{job_id}/artifacts/final_video -o output.mp4
```

## Configuration

### Environment Variables

**API Server:**
- `PORT` - API server port (default: 3000)
- `DATABASE_URL` - PostgreSQL connection string
- `REDIS_URL` - Redis connection string
- `MINIO_ENDPOINT` - MinIO endpoint URL
- `MINIO_ACCESS_KEY` - MinIO access key
- `MINIO_SECRET_KEY` - MinIO secret key
- `MINIO_BUCKET` - MinIO bucket name

**Worker:**
- `DATABASE_URL` - PostgreSQL connection string
- `REDIS_URL` - Redis connection string
- `MINIO_ENDPOINT` - MinIO endpoint URL
- `MINIO_ACCESS_KEY` - MinIO access key
- `MINIO_SECRET_KEY` - MinIO secret key
- `MINIO_BUCKET` - MinIO bucket name
- `OPENAI_API_KEY` - OpenAI API key (optional; see [Secrets](#secrets-never-commit) below)
- `USE_SYSTEM_TTS` - Set to "true" to use system TTS (macOS only)

### Secrets (never commit)

API keys and secrets must **not** be committed. Use environment variables or a local `.env` file.

1. **Copy the example file** (no secrets inside):
   ```bash
   cp .env.example .env
   ```
2. **Edit `.env`** and set only the keys you need (e.g. `OPENAI_API_KEY=sk-...`).
3. **`.env` is in `.gitignore`** – it will not be pushed to GitHub.

**OpenAI vision (optional):** For real diagram/photo understanding, set `OPENAI_API_KEY` in `.env` and `VISION_PROVIDER=openai`. If the key is not set, the pipeline uses the stub vision provider (generic captions) and logs that the key is missing.

- **Enable:** `VISION_PROVIDER=openai` (and optionally `VISION_EXTRACTOR_PROVIDER=openai`).
- **Config (env):** `OPENAI_VISION_MODEL` (default `gpt-4o`), `OPENAI_VISION_TEMPERATURE` (default `0`), `OPENAI_VISION_TIMEOUT_SECONDS` (default `60`).
- **Caching:** Results are cached in MinIO by image hash + model + lang + prompt version to avoid repeat API charges. Set `VISION_CACHE_ENABLED=false` to disable; cache path is `VISION_CACHE_PREFIX` (default `jobs/{job_id}/cache/vision/`).
- **Costs:** Each uncached image uses one vision API call; enable caching for development and re-runs. Outputs are validated and stored as evidence (used by script/verifier in later pipeline stages).

## Pipeline Stages

1. **EXTRACTING**: Extract content from PPTX, convert slides to PNG
2. **DIAGRAM_ANALYSIS**: Build evidence index and analyze diagram structure
3. **SCRIPT_GENERATION**: Generate narrated script with evidence grounding
4. **VERIFICATION**: Verify and rewrite script until all segments pass
5. **TIMELINE_BUILDING**: Generate timeline with visual actions
6. **RENDERING**: Generate overlays and compose final video
7. **COMPLETED**: Job finished successfully

## Artifact Paths

All artifacts are stored in MinIO with the following structure:

```
jobs/{job_id}/
  input.pptx
  extracted.json
  slides/
    slide-0.png
    slide-1.png
  evidence/
    index.json
  graph/
    native.json
    vision.json (optional)
    unified.json
  script.json
  verify_report.json
  coverage.json
  timeline/
    timeline.json
  overlays/
    {action_id}.png
  audio/
    {segment_id}.wav
  final.mp4
```

## Testing

Run tests:
```bash
make test
```

## Development

### No-Provider Mode

By default, SlideSherlock runs in "no-provider mode" where:
- LLM provider returns placeholder responses
- TTS provider returns empty audio
- OCR provider returns empty results

This allows testing the pipeline structure without external API dependencies.

### Adding Providers

To use real providers:

1. **OpenAI LLM**: Set `OPENAI_API_KEY` environment variable
2. **System TTS**: Set `USE_SYSTEM_TTS=true` (macOS only)
3. **OCR**: Implement a real OCR provider in `packages/providers/src/ocr.ts`

## License

MIT
