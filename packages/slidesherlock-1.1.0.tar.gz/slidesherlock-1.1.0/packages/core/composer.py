"""
Composer (Fig3 step 18).
Combine slide PNG + overlay + audio via FFmpeg; output final.mp4.
Supports: crossfade transitions, intro/outro cards, per-slide audio fades,
subtitles burn-in, optional BGM. Degrades gracefully when features disabled.
"""
from __future__ import annotations

import os
import subprocess
import tempfile
from typing import Any, List, Optional

# Optional imports for video_config
try:
    from video_config import VideoConfig, TRANSITION_CUT, TRANSITION_CROSSFADE
except ImportError:
    VideoConfig = None  # type: ignore
    TRANSITION_CUT = "cut"
    TRANSITION_CROSSFADE = "crossfade"

try:
    from audio_processor import apply_audio_fade, _get_duration_seconds
except ImportError:
    apply_audio_fade = None  # type: ignore
    _get_duration_seconds = None  # type: ignore

from video_encoder import get_video_encoder, get_video_encoder_args


def concat_audio(
    per_slide_audio_paths: List[str],
    output_audio_path: str,
    sample_rate: int = 48000,
    fade_ms: int = 0,
    intro_silence_sec: float = 0,
    outro_silence_sec: float = 0,
) -> str:
    """
    Concat per-slide audio files into one WAV. If fade_ms > 0, apply fade-in/out per slide.
    intro_silence_sec/outro_silence_sec: prepend/append silence for intro/outro cards.
    """
    if not per_slide_audio_paths and intro_silence_sec <= 0 and outro_silence_sec <= 0:
        raise ValueError("No audio files to concat")
    paths_to_concat = per_slide_audio_paths
    temp_faded: List[str] = []
    if fade_ms > 0 and apply_audio_fade:
        for i, p in enumerate(per_slide_audio_paths):
            fd, tmp = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            try:
                apply_audio_fade(p, tmp, fade_ms=fade_ms, sample_rate=sample_rate)
                temp_faded.append(tmp)
            except Exception:
                try:
                    os.unlink(tmp)
                except Exception:
                    pass
                temp_faded = []
                break
        if temp_faded and len(temp_faded) == len(per_slide_audio_paths):
            paths_to_concat = temp_faded
    parts: List[str] = []
    extra_temps: List[str] = []
    if intro_silence_sec > 0:
        fd, sil_in = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-f",
                "lavfi",
                "-i",
                f"anullsrc=r={sample_rate}:cl=mono",
                "-t",
                str(intro_silence_sec),
                "-ar",
                str(sample_rate),
                "-ac",
                "1",
                sil_in,
            ],
            check=True,
            capture_output=True,
            timeout=30,
        )
        parts.append(sil_in)
        extra_temps.append(sil_in)
    for p in paths_to_concat:
        parts.append(p)
    if outro_silence_sec > 0:
        fd, sil_out = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-f",
                "lavfi",
                "-i",
                f"anullsrc=r={sample_rate}:cl=mono",
                "-t",
                str(outro_silence_sec),
                "-ar",
                str(sample_rate),
                "-ac",
                "1",
                sil_out,
            ],
            check=True,
            capture_output=True,
            timeout=30,
        )
        parts.append(sil_out)
        extra_temps.append(sil_out)
    if not parts:
        parts = paths_to_concat
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            for p in parts:
                f.write(f"file '{os.path.abspath(p)}'\n")
            list_path = f.name
        try:
            subprocess.run(
                [
                    "ffmpeg",
                    "-y",
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    list_path,
                    "-ar",
                    str(sample_rate),
                    "-ac",
                    "1",
                    output_audio_path,
                ],
                check=True,
                capture_output=True,
                timeout=300,
            )
            return output_audio_path
        finally:
            if os.path.exists(list_path):
                os.unlink(list_path)
    finally:
        for t in temp_faded:
            try:
                if os.path.exists(t):
                    os.unlink(t)
            except Exception:
                pass
        for t in extra_temps:
            try:
                if os.path.exists(t):
                    os.unlink(t)
            except Exception:
                pass


def _get_video_duration(path: str) -> float:
    """Get duration of video file in seconds."""
    if _get_duration_seconds:
        return _get_duration_seconds(path) or 0.0
    try:
        r = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                path,
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if r.returncode == 0 and r.stdout.strip():
            return float(r.stdout.strip())
    except Exception:
        pass
    return 0.0


def _wrap_text_to_width(
    text: str,
    font: Any,
    max_width: int,
    draw: Any,
) -> List[str]:
    """Wrap text into lines that fit within max_width pixels."""
    if not text:
        return []
    words = text.split()
    if not words:
        return []
    lines: List[str] = []
    current = words[0]
    for word in words[1:]:
        test = current + " " + word
        bbox = draw.textbbox((0, 0), test, font=font)
        if bbox[2] - bbox[0] <= max_width:
            current = test
        else:
            lines.append(current)
            current = word
    lines.append(current)
    return lines


def _render_card_mp4(
    title: str,
    subtitle: str,
    duration_sec: float,
    width: int,
    height: int,
    output_path: str,
) -> str:
    """Render a title card (intro/outro) as MP4 with proper text wrapping and centering."""
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        raise RuntimeError("PIL required for intro/outro cards")

    # Clean and limit title — single sentence, max 80 chars
    title = (title or "").strip().replace("\n", " ").replace("\r", " ")
    title = " ".join(title.split())  # collapse whitespace
    if len(title) > 80:
        title = title[:77] + "..."
    subtitle = (subtitle or "").strip().replace("\n", " ").replace("\r", " ")
    subtitle = " ".join(subtitle.split())
    if len(subtitle) > 100:
        subtitle = subtitle[:97] + "..."

    # Adaptive font sizes based on canvas width (works for 1280x720, 1920x1080, etc.)
    title_font_size = max(48, int(width * 0.045))
    subtitle_font_size = max(24, int(width * 0.022))

    img = Image.new("RGB", (width, height), (20, 22, 30))
    draw = ImageDraw.Draw(img)

    # Subtle gradient overlay (top to bottom)
    for i in range(height):
        shade = 20 + int((i / height) * 12)
        draw.line([(0, i), (width, i)], fill=(shade, shade + 2, shade + 10))

    # Load fonts with fallback
    font_large = None
    font_small = None
    font_paths = [
        "/System/Library/Fonts/Helvetica.ttc",
        "/System/Library/Fonts/SFNSDisplay.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
    ]
    for fp in font_paths:
        if os.path.exists(fp):
            try:
                font_large = ImageFont.truetype(fp, title_font_size)
                font_small = ImageFont.truetype(fp, subtitle_font_size)
                break
            except Exception:
                continue
    if font_large is None:
        font_large = ImageFont.load_default()
        font_small = font_large

    # Word-wrap title to fit 80% of canvas width
    max_text_width = int(width * 0.8)
    title_lines = _wrap_text_to_width(title, font_large, max_text_width, draw)
    subtitle_lines = _wrap_text_to_width(subtitle, font_small, max_text_width, draw)

    # Calculate total text block height
    line_height_large = title_font_size + 12
    line_height_small = subtitle_font_size + 8
    total_height = len(title_lines) * line_height_large
    if subtitle_lines:
        total_height += 30 + len(subtitle_lines) * line_height_small

    # Vertically center the block
    y = (height - total_height) // 2

    # Draw title lines (centered)
    for line in title_lines:
        bbox = draw.textbbox((0, 0), line, font=font_large)
        tw = bbox[2] - bbox[0]
        x = (width - tw) // 2
        # Subtle shadow for depth
        draw.text((x + 2, y + 2), line, fill=(0, 0, 0), font=font_large)
        draw.text((x, y), line, fill=(255, 255, 255), font=font_large)
        y += line_height_large

    # Draw subtitle lines (centered, lighter color)
    if subtitle_lines:
        y += 20
        for line in subtitle_lines:
            bbox = draw.textbbox((0, 0), line, font=font_small)
            tw = bbox[2] - bbox[0]
            x = (width - tw) // 2
            draw.text((x, y), line, fill=(170, 175, 195), font=font_small)
            y += line_height_small

    # Accent line below title
    accent_y = (height - total_height) // 2 + len(title_lines) * line_height_large + 6
    if subtitle_lines:
        line_w = int(width * 0.15)
        draw.line(
            [(width // 2 - line_w // 2, accent_y), (width // 2 + line_w // 2, accent_y)],
            fill=(99, 102, 241),
            width=3,
        )
    card_png = output_path.replace(".mp4", "_card.png")
    img.save(card_png)
    try:
        # Match slide overlay codec params: h264, yuv420p, 15fps
        # Critical: framerate MUST match slide overlays for concat -c copy to work
        # Use libx264 for -loop 1 image input (h264_videotoolbox sometimes
        # fails with exit 187 on image loop + scale filter). Card clips are
        # 2s so software encode is instant.
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-loop",
                "1",
                "-framerate",
                "15",
                "-i",
                card_png,
                "-t",
                str(duration_sec),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-r",
                "15",
                "-vf",
                f"scale={width}:{height}",
                output_path,
            ],
            check=True,
            capture_output=True,
            timeout=60,
        )
    finally:
        if os.path.exists(card_png):
            try:
                os.unlink(card_png)
            except Exception:
                pass
    return output_path


def _compose_with_crossfade(
    video_paths: List[str],
    durations: List[float],
    transition_ms: int,
    output_path: str,
) -> str:
    """Compose videos with xfade transitions using chunked encoding.

    Instead of one giant xfade filter_complex that re-encodes the entire
    video (O(N × total_duration) — 15-25 min for 30 slides), we split
    slides into chunks of CROSSFADE_CHUNK_SIZE, apply xfade within each
    chunk (fast — only a few slides per filter graph), and concat the
    chunks with stream copy (instant).  Hard cut between chunks is
    visually unnoticeable in presentation videos.

    Expected speedup: 20-40× for decks with 20+ slides.
    Override chunk size via CROSSFADE_CHUNK_SIZE env var (default 8).
    Set to 999 for the old single-pass behavior (slower, seamless).
    """
    if len(video_paths) < 2:
        if len(video_paths) == 1:
            import shutil

            shutil.copy(video_paths[0], output_path)
            return output_path
        raise ValueError("Need at least one video")

    chunk_size = int(os.environ.get("CROSSFADE_CHUNK_SIZE", "8"))
    if chunk_size >= len(video_paths):
        # Small deck or chunk_size=999 — single pass (old behavior)
        return _xfade_single_pass(video_paths, durations, transition_ms, output_path)

    # Split into chunks and xfade each chunk independently
    chunk_paths: List[str] = []
    try:
        for start in range(0, len(video_paths), chunk_size):
            end = min(start + chunk_size, len(video_paths))
            chunk_vids = video_paths[start:end]
            chunk_durs = durations[start:end]

            if len(chunk_vids) == 1:
                # Single-slide chunk — no xfade needed, use as-is
                chunk_paths.append(chunk_vids[0])
                continue

            fd, chunk_out = tempfile.mkstemp(suffix=f"_chunk_{start}.mp4")
            os.close(fd)
            chunk_paths.append(chunk_out)
            _xfade_single_pass(chunk_vids, chunk_durs, transition_ms, chunk_out)

        # Concat chunks with stream copy (instant, no re-encode)
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            for cp in chunk_paths:
                f.write(f"file '{os.path.abspath(cp)}'\n")
            list_path = f.name

        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                list_path,
                "-c",
                "copy",
                output_path,
            ],
            check=True,
            capture_output=True,
            timeout=120,
        )
    finally:
        # Clean up temp chunk files (but not original slide videos)
        for cp in chunk_paths:
            if cp not in video_paths and os.path.exists(cp):
                try:
                    os.unlink(cp)
                except Exception:
                    pass
        if "list_path" in locals() and os.path.exists(list_path):
            try:
                os.unlink(list_path)
            except Exception:
                pass

    return output_path


def _xfade_single_pass(
    video_paths: List[str],
    durations: List[float],
    transition_ms: int,
    output_path: str,
) -> str:
    """Single-pass xfade filter_complex for a small number of videos.

    This is the original algorithm, now used only within chunks (≤8 slides)
    where the encode time is bounded. For the full-deck path, see
    _compose_with_crossfade which calls this per chunk.
    """
    fade_sec = transition_ms / 1000.0
    fade_sec = min(fade_sec, min(durations) * 0.4)
    inputs: List[str] = []
    for p in video_paths:
        inputs.extend(["-i", p])
    filters: List[str] = []
    cum_dur = durations[0]
    for i in range(1, len(video_paths)):
        offset = max(0, cum_dur - fade_sec)
        out_label = "vout" if i == len(video_paths) - 1 else f"v{i:02d}"
        in_a = "[0:v]" if i == 1 else f"[v{i-1:02d}]"
        in_b = f"[{i}:v]"
        filters.append(
            f"{in_a}{in_b}xfade=transition=fade:duration={fade_sec:.3f}:offset={offset:.3f}[{out_label}]"
        )
        cum_dur = cum_dur + durations[i] - fade_sec
    filter_str = ";".join(filters)
    cmd = (
        ["ffmpeg", "-y"]
        + inputs
        + [
            "-filter_complex",
            filter_str,
            "-map",
            "[vout]",
            "-c:v",
            get_video_encoder(),
            *get_video_encoder_args(),
            "-pix_fmt",
            "yuv420p",
            output_path,
        ]
    )
    # Per-chunk timeout: 8 slides × ~30s each × 15fps ≈ 3600 frames.
    # Even on libx264 software encode this finishes in <2 min.
    subprocess.run(cmd, check=True, capture_output=True, timeout=300)
    return output_path


def compose_video(
    per_slide_mp4_paths: List[str],
    total_duration_seconds: float,
    output_path: str,
    audio_path: Optional[str] = None,
    per_slide_audio_paths: Optional[List[str]] = None,
    audio_sample_rate: int = 48000,
    video_config: Optional[Any] = None,
    srt_path: Optional[str] = None,
    per_slide_durations: Optional[List[float]] = None,
    deck_title: str = "",
    deck_subtitle: str = "",
) -> str:
    """
    Concat per-slide MP4s and add audio. Returns output_path.
    When video_config provided, applies: crossfade, intro/outro, audio fades, subtitle burn-in, BGM.
    Degrades gracefully when config is None or features disabled.
    """
    if not per_slide_mp4_paths:
        raise ValueError("No slide videos to concat")
    config = video_config
    use_crossfade = (
        config
        and getattr(config, "transition", "") == TRANSITION_CROSSFADE
        and len(per_slide_mp4_paths) >= 2
    )
    use_intro = config and getattr(config, "intro_enabled", False)
    use_outro = config and getattr(config, "outro_enabled", False)
    fade_ms = getattr(config, "audio_fade_ms", 0) if config else 0
    use_subs_burn = (
        config
        and getattr(config, "subtitles_burn_in", False)
        and srt_path
        and os.path.exists(srt_path)
    )
    config and getattr(config, "bgm_enabled", False) and getattr(config, "bgm_path", None)
    # Get dimensions from first slide
    try:
        r = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=width,height",
                "-of",
                "csv=p=0",
                per_slide_mp4_paths[0],
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        wh = (r.stdout or "").strip().split(",")
        width = int(wh[0]) if len(wh) >= 1 and wh[0].isdigit() else 1280
        height = int(wh[1]) if len(wh) >= 2 and wh[1].isdigit() else 720
    except Exception:
        width, height = 1280, 720
    video_paths = list(per_slide_mp4_paths)
    durations = list(per_slide_durations) if per_slide_durations else []
    if not durations:
        for p in video_paths:
            durations.append(_get_video_duration(p) if hasattr(subprocess, "run") else 2.0)
    intro_path: Optional[str] = None
    outro_path: Optional[str] = None
    if use_intro and config:
        fd, intro_path = tempfile.mkstemp(suffix="_intro.mp4")
        os.close(fd)
        try:
            _render_card_mp4(
                getattr(config, "intro_title", deck_title or "Presentation"),
                getattr(config, "intro_subtitle", deck_subtitle),
                getattr(config, "intro_duration", 2.0),
                width,
                height,
                intro_path,
            )
        except Exception as e:
            print(f"  [composer] intro card render failed: {e}")
            intro_path = None
        if intro_path:
            video_paths.insert(0, intro_path)
            durations.insert(0, getattr(config, "intro_duration", 2.0))
    if use_outro and config:
        fd, outro_path = tempfile.mkstemp(suffix="_outro.mp4")
        os.close(fd)
        try:
            _render_card_mp4(
                getattr(config, "outro_text", "Thanks for watching"),
                "",
                getattr(config, "outro_duration", 2.0),
                width,
                height,
                outro_path,
            )
        except Exception as e:
            print(f"  [composer] outro card render failed: {e}")
            outro_path = None
        if outro_path:
            video_paths.append(outro_path)
            durations.append(getattr(config, "outro_duration", 2.0))
    concat_path: Optional[str] = None
    sub_path_temp: Optional[str] = None
    try:
        if use_crossfade and config:
            trans_ms = getattr(config, "transition_ms", 300)
            fd, concat_path = tempfile.mkstemp(suffix=".mp4")
            os.close(fd)
            try:
                _compose_with_crossfade(video_paths, durations, trans_ms, concat_path)
            except Exception:
                use_crossfade = False
                if concat_path and os.path.exists(concat_path):
                    try:
                        os.unlink(concat_path)
                    except Exception:
                        pass
                concat_path = None
        if not use_crossfade:
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
                for p in video_paths:
                    f.write(f"file '{os.path.abspath(p)}'\n")
                list_path = f.name
            concat_path = tempfile.mktemp(suffix=".mp4")
            try:
                subprocess.run(
                    [
                        "ffmpeg",
                        "-y",
                        "-f",
                        "concat",
                        "-safe",
                        "0",
                        "-i",
                        list_path,
                        "-c",
                        "copy",
                        concat_path,
                    ],
                    check=True,
                    capture_output=True,
                    timeout=300,
                )
            finally:
                if os.path.exists(list_path):
                    os.unlink(list_path)
        final_audio_path = audio_path
        intro_silence = getattr(config, "intro_duration", 0.0) if (use_intro and config) else 0.0
        outro_silence = getattr(config, "outro_duration", 0.0) if (use_outro and config) else 0.0
        if per_slide_audio_paths and not final_audio_path:
            fd, concat_audio_path = tempfile.mkstemp(suffix=".wav")
            os.close(fd)
            try:
                concat_audio(
                    per_slide_audio_paths,
                    concat_audio_path,
                    sample_rate=audio_sample_rate,
                    fade_ms=fade_ms,
                    intro_silence_sec=intro_silence,
                    outro_silence_sec=outro_silence,
                )
                final_audio_path = concat_audio_path
            except Exception:
                concat_audio(
                    per_slide_audio_paths,
                    concat_audio_path,
                    sample_rate=audio_sample_rate,
                    fade_ms=0,
                    intro_silence_sec=intro_silence,
                    outro_silence_sec=outro_silence,
                )
                final_audio_path = concat_audio_path
        else:
            concat_audio_path = None
        video_input = concat_path
        if use_subs_burn and srt_path and video_input:
            # Copy SRT to temp; use file:// for subtitles filter to avoid path escaping
            fd_srt, srt_temp = tempfile.mkstemp(suffix=".srt")
            os.close(fd_srt)
            sub_path_temp = tempfile.mktemp(suffix="_subs.mp4")
            try:
                with open(srt_path, "r", encoding="utf-8") as f:
                    with open(srt_temp, "w", encoding="utf-8") as out:
                        out.write(f.read())
                srt_uri = "file://" + os.path.abspath(srt_temp).replace("\\", "/")
                subprocess.run(
                    [
                        "ffmpeg",
                        "-y",
                        "-i",
                        video_input,
                        "-vf",
                        f"subtitles={srt_uri}",
                        "-c:a",
                        "copy",
                        sub_path_temp,
                    ],
                    check=True,
                    capture_output=True,
                    timeout=300,
                )
                video_input = sub_path_temp
            except Exception:
                sub_path_temp = None
            finally:
                if os.path.exists(srt_temp):
                    try:
                        os.unlink(srt_temp)
                    except Exception:
                        pass
        total_video_dur = sum(durations) if durations else total_duration_seconds
        if final_audio_path and os.path.exists(final_audio_path):
            audio_dur = _get_video_duration(final_audio_path) if hasattr(subprocess, "run") else 0.0
            video_dur = (
                _get_video_duration(video_input) if hasattr(subprocess, "run") else total_video_dur
            )
            if video_dur <= 0:
                video_dur = total_video_dur
            if audio_dur <= 0:
                audio_dur = total_video_dur
            # Pad the shorter stream to match the longer one (no -shortest, avoids abrupt cutoff)
            target_dur = max(video_dur, audio_dur) + 0.5  # 0.5s tail pad for clean ending
            fd_pad, padded_audio = tempfile.mkstemp(suffix="_padded.wav")
            os.close(fd_pad)
            try:
                subprocess.run(
                    [
                        "ffmpeg",
                        "-y",
                        "-i",
                        final_audio_path,
                        "-af",
                        f"apad=whole_dur={target_dur}",
                        "-ar",
                        str(audio_sample_rate),
                        "-ac",
                        "1",
                        padded_audio,
                    ],
                    check=True,
                    capture_output=True,
                    timeout=60,
                )
                subprocess.run(
                    [
                        "ffmpeg",
                        "-y",
                        "-i",
                        video_input,
                        "-i",
                        padded_audio,
                        "-map",
                        "0:v",
                        "-map",
                        "1:a",
                        "-c:v",
                        "copy",
                        "-c:a",
                        "aac",
                        output_path,
                    ],
                    check=True,
                    capture_output=True,
                    timeout=300,
                )
            finally:
                if os.path.exists(padded_audio):
                    try:
                        os.unlink(padded_audio)
                    except Exception:
                        pass
        else:
            total_dur = sum(durations) if durations else total_duration_seconds
            subprocess.run(
                [
                    "ffmpeg",
                    "-y",
                    "-f",
                    "lavfi",
                    "-i",
                    f"anullsrc=channel_layout=stereo:sample_rate={audio_sample_rate}:duration={total_dur}",
                    "-i",
                    video_input,
                    "-c:v",
                    "copy",
                    "-c:a",
                    "aac",
                    "-shortest",
                    "-map",
                    "1:v",
                    "-map",
                    "0:a",
                    output_path,
                ],
                check=True,
                capture_output=True,
                timeout=300,
            )
        if final_audio_path and final_audio_path != audio_path and os.path.exists(final_audio_path):
            try:
                os.unlink(final_audio_path)
            except Exception:
                pass
        return output_path
    finally:
        if intro_path and os.path.exists(intro_path):
            try:
                os.unlink(intro_path)
            except Exception:
                pass
        if outro_path and os.path.exists(outro_path):
            try:
                os.unlink(outro_path)
            except Exception:
                pass
        if concat_path and os.path.exists(concat_path):
            try:
                os.unlink(concat_path)
            except Exception:
                pass
        if sub_path_temp and os.path.exists(sub_path_temp):
            try:
                os.unlink(sub_path_temp)
            except Exception:
                pass
