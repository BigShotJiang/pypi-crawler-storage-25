"""Multi-file (Summary.xml) ingest, verified against a synthetic fixture.

The fixture in `tests/fixtures/multi/` mirrors what FileMaker emits for a
multi-file solution: one `Summary.xml` (FMPReport type="Summary") with
`<File link="..."/>` pointers to two per-file DDR exports
(FMPReport type="Report"). The two files deliberately use overlapping
BaseTable ids and overlapping per-BT field ids, so the synthesis paths
that keep the combined index unambiguous all get exercised.

Runs anywhere — no external fixtures required.
"""
from __future__ import annotations

import pathlib
import sqlite3

import pytest

FIXTURE_DIR = pathlib.Path(__file__).parent / "fixtures" / "multi"
SUMMARY = FIXTURE_DIR / "Summary.xml"
FILE_A = FIXTURE_DIR / "FileA_fmp12.xml"


@pytest.fixture(scope="module")
def single_db(tmp_path_factory) -> pathlib.Path:
    """Index just one file the normal way (FMPReport type='Report')."""
    from fmddr.index.build import build_index
    db = tmp_path_factory.mktemp("multi") / "single.fmddr.db"
    build_index(FILE_A, db, quiet=True)
    return db


@pytest.fixture(scope="module")
def summary_db(tmp_path_factory) -> pathlib.Path:
    """Index the Summary, which pulls in both linked files."""
    from fmddr.index.build import build_index_from_summary
    db = tmp_path_factory.mktemp("multi") / "summary.fmddr.db"
    build_index_from_summary(SUMMARY, db, quiet=True)
    return db


def test_single_file_records_one_file_row(single_db: pathlib.Path):
    conn = sqlite3.connect(single_db)
    files = conn.execute("SELECT id, name FROM file").fetchall()
    assert files == [(1, "FileA.fmp12")]
    # All rows belong to file_id=1 — no offset applied to the first file.
    assert conn.execute("SELECT COUNT(*) FROM base_table WHERE file_id != 1").fetchone()[0] == 0


def test_summary_aggregates_both_files(summary_db: pathlib.Path):
    conn = sqlite3.connect(summary_db)
    conn.row_factory = sqlite3.Row

    files = [dict(r) for r in conn.execute("SELECT id, name FROM file ORDER BY id")]
    assert [f["id"] for f in files] == [1, 2]
    assert [f["name"] for f in files] == ["FileA.fmp12", "FileB.fmp12"]

    by_file = {row["file_id"]: row["n"] for row in conn.execute(
        "SELECT file_id, COUNT(*) AS n FROM base_table GROUP BY file_id"
    )}
    assert by_file == {1: 2, 2: 2}    # two BTs per file


def test_overlapping_bt_ids_resolved_by_file_offset(summary_db: pathlib.Path):
    """FileA and FileB both define BaseTable id=1. The file_id offset must
    keep them distinct in the combined index."""
    from fmddr.index.build import FILE_ID_STRIDE
    conn = sqlite3.connect(summary_db)

    # Both files have raw BT id=1 — should produce 2 rows in base_table.
    rows = conn.execute(
        "SELECT id, file_id, name FROM base_table WHERE raw_id = 1 ORDER BY file_id"
    ).fetchall()
    assert len(rows) == 2
    assert rows[0] == (1, 1, "Customer")
    assert rows[1] == (FILE_ID_STRIDE + 1, 2, "Vendor")


def test_field_id_collision_resolved_via_synthesis(summary_db: pathlib.Path):
    """Field ids reset per base table — `<Field id="1">` exists in every
    BaseTable in this fixture (4 rows total). With the per-BT synthesis
    they must all persist as distinct rows."""
    conn = sqlite3.connect(summary_db)
    n_id_1 = conn.execute("SELECT COUNT(*) FROM field WHERE raw_id = 1").fetchone()[0]
    assert n_id_1 == 4   # __UID in every Customer/Order/Vendor/Item

    # Total fields = 2 BTs * 2 fields * 2 files = 8.
    assert conn.execute("SELECT COUNT(*) FROM field").fetchone()[0] == 8


def test_field_synthesis_formula(summary_db: pathlib.Path):
    """The synthesized field id must equal
       file_offset + bt_raw_id * BT_STRIDE + raw_field_id."""
    from fmddr.index.build import FILE_ID_STRIDE, BT_STRIDE
    conn = sqlite3.connect(summary_db)

    # Customer.Name: file 1, BT raw=1, field raw=2.
    expected = 0 * FILE_ID_STRIDE + 1 * BT_STRIDE + 2
    row = conn.execute(
        "SELECT f.id FROM field f JOIN base_table bt ON bt.id = f.base_table_id "
        "WHERE bt.name = 'Customer' AND f.name = 'Name'"
    ).fetchone()
    assert row[0] == expected

    # Item.UIDLength: file 2, BT raw=2, field raw=2.
    expected = 1 * FILE_ID_STRIDE + 2 * BT_STRIDE + 2
    row = conn.execute(
        "SELECT f.id FROM field f JOIN base_table bt ON bt.id = f.base_table_id "
        "WHERE bt.name = 'Item' AND f.name = 'UIDLength'"
    ).fetchone()
    assert row[0] == expected


def test_field_references_resolve_across_synthesis(summary_db: pathlib.Path):
    """The chunk walker stages raw `(field_id, via_to_name)` pairs and
    resolves them at the end of the build. Refs must land on the right
    synthesized field id."""
    from fmddr.query import resolvers, fields as q_fields
    conn = sqlite3.connect(summary_db)
    conn.row_factory = sqlite3.Row

    # Item.UIDLength (calc) names Item.__UID via a FieldRef chunk.
    uid = resolvers.resolve_field(conn, "Item::__UID")
    siblings = q_fields.field_field_refs(conn, uid["id"])
    assert sorted(s["name"] for s in siblings) == ["UIDLength"]

    # Customer.Name is referenced from a script step (Set Field) — verify the
    # `<Field table="Customer" id="2"/>` direct ref also synthesizes correctly.
    name = resolvers.resolve_field(conn, "Customer::Name")
    refs = q_fields.field_script_refs(conn, name["id"])
    assert any(r["script_name"] == "Add Customer" for r in refs)

    # Customer.Name appears on the layout via DDRInfo/Field — the layout-
    # object staging path also passes through synthesis.
    on_layouts = q_fields.field_on_layouts(conn, name["id"])
    assert any(ly["name"] == "Customer Detail" for ly in on_layouts)


def test_join_predicate_field_ids_synthesized(summary_db: pathlib.Path):
    """Relationship predicates store synthesized field ids — verify the
    FK is to actual field rows, not to broken raw ids."""
    conn = sqlite3.connect(summary_db)
    rows = conn.execute(
        "SELECT jp.left_field_id, jp.right_field_id, jp.operator "
        "FROM join_predicate jp"
    ).fetchall()
    assert len(rows) == 1
    lf, rf, op = rows[0]
    assert op == "Equal"
    # Both predicate fields must exist in `field`.
    assert conn.execute("SELECT COUNT(*) FROM field WHERE id = ?", (lf,)).fetchone()[0] == 1
    assert conn.execute("SELECT COUNT(*) FROM field WHERE id = ?", (rf,)).fetchone()[0] == 1


def test_summary_meta(summary_db: pathlib.Path):
    conn = sqlite3.connect(summary_db)
    meta = {k: v for k, v in conn.execute("SELECT key, value FROM meta")}
    assert meta["ddr_kind"] == "summary"
    assert meta["file_count"] == "2"
    assert meta["counts.fields"] == "8"
    assert meta["counts.tables"] == "4"
