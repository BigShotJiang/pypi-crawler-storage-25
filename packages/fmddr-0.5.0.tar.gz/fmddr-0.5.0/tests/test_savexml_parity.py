"""Parity harness: DDR vs SaveAsXML edge-table comparison.

This test ingests the *same* FileMaker file via both DDR (`<FMPReport
type="Report">`) and SaveAsXML (`<FMSaveAsXML>`) and compares the
resulting edge tables (`field_ref`, `script_ref`, `layout_ref`,
`custom_function_ref`).

The point isn't byte-equal counts — DDR's `DDRInfo` cross-reference
rollup and SaveAsXML's "raw payload + calc parser" approach will
produce slightly different edge sets. Acceptable divergence:

- SaveAsXML may emit *more* field-refs per step (it walks the entire
  step subtree; DDR's DDRInfo only lists primary/notable refs).
- DDR may emit field-refs for unqualified field names whose context
  comes from semantics our calc parser doesn't model (e.g. `Self::`).
- Inherently dynamic refs (`Evaluate`, `GetField` with computed args)
  are unresolvable in either format — neither produces edges.

Asserts here focus on shape (edge tables populated, top-N overlap)
rather than exact equality. The fixtures are large real-world DDR/
SaveAsXML pairs the user has locally — the test skips when they
aren't present (CI without those files).
"""
from __future__ import annotations

import pathlib
import sqlite3

import pytest


# ---------------------------------------------------------------------------
# Fixture discovery
# ---------------------------------------------------------------------------

DDR_DATA = pathlib.Path("/Users/ccorsi/Downloads/TradeSchool DDR/ts5dev_TradeSchool Data_fmp12.xml")
SAX_DATA = pathlib.Path("/Users/ccorsi/Downloads/TradeSchool Dev Apr 28 2026/ts5dev_TradeSchool Data.xml")


def _have_parity_fixtures() -> bool:
    return DDR_DATA.exists() and SAX_DATA.exists()


pytestmark = pytest.mark.skipif(
    not _have_parity_fixtures(),
    reason="Parity fixtures not available on this machine",
)


@pytest.fixture(scope="module")
def parity_dbs(tmp_path_factory) -> tuple[pathlib.Path, pathlib.Path]:
    """Build both indexes once for the module."""
    from fmddr.index.build import build_index
    from fmddr.index.savexml import build_index_from_savexml

    tmp = tmp_path_factory.mktemp("parity")
    ddr_db = tmp / "ddr.fmddr.db"
    sax_db = tmp / "sax.fmddr.db"
    build_index(DDR_DATA, ddr_db, quiet=True)
    build_index_from_savexml(SAX_DATA, sax_db, quiet=True)
    return ddr_db, sax_db


# ---------------------------------------------------------------------------
# Smoke: both formats build, both populate edge tables
# ---------------------------------------------------------------------------

def test_both_indexes_populate_field_ref(parity_dbs):
    ddr_db, sax_db = parity_dbs
    for db in (ddr_db, sax_db):
        n = sqlite3.connect(db).execute(
            "SELECT COUNT(*) FROM field_ref"
        ).fetchone()[0]
        assert n > 0, f"{db} has no field_ref rows"


def test_both_indexes_populate_script_ref(parity_dbs):
    ddr_db, sax_db = parity_dbs
    for db in (ddr_db, sax_db):
        n = sqlite3.connect(db).execute(
            "SELECT COUNT(*) FROM script_ref"
        ).fetchone()[0]
        assert n > 0, f"{db} has no script_ref rows"


def test_both_indexes_populate_layout_ref(parity_dbs):
    ddr_db, sax_db = parity_dbs
    for db in (ddr_db, sax_db):
        n = sqlite3.connect(db).execute(
            "SELECT COUNT(*) FROM layout_ref"
        ).fetchone()[0]
        assert n > 0, f"{db} has no layout_ref rows"


def test_savexml_populates_custom_function_ref(parity_dbs):
    """Phase B's calc resolver should emit cf-call edges from SaveAsXML."""
    _, sax_db = parity_dbs
    n = sqlite3.connect(sax_db).execute(
        "SELECT COUNT(*) FROM custom_function_ref"
    ).fetchone()[0]
    assert n > 0


# ---------------------------------------------------------------------------
# Top-N overlap: which fields and scripts each side flags as most-referenced
# ---------------------------------------------------------------------------

def _top_n_referenced_fields(db: pathlib.Path, n: int = 50) -> set[str]:
    rows = sqlite3.connect(db).execute(
        "SELECT f.name, COUNT(*) AS cnt "
        "FROM field_ref fr JOIN field f ON f.id = fr.field_id "
        "GROUP BY f.id "
        "ORDER BY cnt DESC, f.name "
        "LIMIT ?",
        (n,),
    ).fetchall()
    return {r[0] for r in rows}


def _top_n_referenced_scripts(db: pathlib.Path, n: int = 25) -> set[str]:
    rows = sqlite3.connect(db).execute(
        "SELECT s.name, COUNT(*) AS cnt "
        "FROM script_ref sr JOIN script s ON s.id = sr.callee_id "
        "GROUP BY s.id "
        "ORDER BY cnt DESC, s.name "
        "LIMIT ?",
        (n,),
    ).fetchall()
    return {r[0] for r in rows}


def test_top_referenced_fields_overlap(parity_dbs):
    """Top-N most-referenced fields should overlap substantially.

    DDR and SaveAsXML count refs differently — DDR's DDRInfo rolls up
    occurrences in calc/auto-enter context per-field-mention, while
    SaveAsXML's calc parser counts per text occurrence. The two
    distributions look similar but the tails of the top-N can diverge.
    Threshold: 20+/50 (40%) — anything materially below that suggests
    the calc resolver has missed a major class of refs.
    """
    ddr_db, sax_db = parity_dbs
    ddr_top = _top_n_referenced_fields(ddr_db, 50)
    sax_top = _top_n_referenced_fields(sax_db, 50)
    overlap = len(ddr_top & sax_top)
    assert overlap >= 20, (
        f"top-50 referenced field overlap is {overlap}/50; "
        f"DDR-only: {ddr_top - sax_top}, SaveAsXML-only: {sax_top - ddr_top}"
    )


def test_top_referenced_scripts_overlap(parity_dbs):
    """Top-25 most-called scripts should mostly match (script callers
    are a more structurally faithful set than field refs)."""
    ddr_db, sax_db = parity_dbs
    ddr_top = _top_n_referenced_scripts(ddr_db, 25)
    sax_top = _top_n_referenced_scripts(sax_db, 25)
    overlap = len(ddr_top & sax_top)
    assert overlap >= 12, (
        f"top-25 referenced script overlap is {overlap}/25; "
        f"DDR-only: {ddr_top - sax_top}, SaveAsXML-only: {sax_top - ddr_top}"
    )


# ---------------------------------------------------------------------------
# Per-owner-kind sanity (don't enforce equality — both formats classify
# differently — but each owner_kind that DDR populates should also be
# populated in SaveAsXML when the corresponding ref shape exists in the
# fixture).
# ---------------------------------------------------------------------------

def test_savexml_has_field_calc_refs(parity_dbs):
    _, sax_db = parity_dbs
    n = sqlite3.connect(sax_db).execute(
        "SELECT COUNT(*) FROM field_ref WHERE owner_kind = 'field_calc'"
    ).fetchone()[0]
    assert n > 0


def test_savexml_has_layout_object_refs(parity_dbs):
    _, sax_db = parity_dbs
    n = sqlite3.connect(sax_db).execute(
        "SELECT COUNT(*) FROM field_ref WHERE owner_kind = 'layout_object'"
    ).fetchone()[0]
    assert n > 0


def test_savexml_has_script_step_refs(parity_dbs):
    _, sax_db = parity_dbs
    n = sqlite3.connect(sax_db).execute(
        "SELECT COUNT(*) FROM field_ref WHERE owner_kind = 'script_step'"
    ).fetchone()[0]
    assert n > 0
