"""Build an index from an FMSaveAsXML clone export, plus diff round-trip."""
from __future__ import annotations

import codecs
import pathlib
import sqlite3
import subprocess
import sys

import pytest


def _fmddr_cmd(*args: str) -> list[str]:
    """Run fmddr via the test's Python interpreter so the venv-installed
    code (not whatever's on $PATH) is exercised."""
    return [sys.executable, "-m", "fmddr.cli", *args]


# ---------------------------------------------------------------------------
# Synthetic FMSaveAsXML fixture — a minimal but realistic skeleton.
# Two variants (V1 / V2) exercise added/removed/modified diff paths.
# ---------------------------------------------------------------------------

def _savexml(file_attr: str, body: str) -> str:
    return (
        '<?xml version="1.0"?>\n'
        f'<FMSaveAsXML version="2.2.3.0" Source="22.0.0" '
        f'File="{file_attr}" UUID="DEAD-BEEF" locale="English" Has_DDR_INFO="False">\n'
        '  <Structure membercount="2">\n'
        '    <AddAction>\n'
        f'{body}\n'
        '    </AddAction>\n'
        '  </Structure>\n'
        '</FMSaveAsXML>\n'
    )


# v1 body — 1 base table (2 fields), 2 scripts (one with steps), 1 CF, 1 layout, 1 TO, 1 relationship.
V1_BODY = """\
      <BaseTableCatalog membercount="1">
        <BaseTable id="1" name="Customer" comment=""><UUID/><TagList/></BaseTable>
      </BaseTableCatalog>
      <FieldsForTables membercount="1">
        <FieldCatalog>
          <UUID/><TagList/>
          <BaseTableReference id="1" name="Customer" UUID="BT1"/>
          <ObjectList membercount="2">
            <Field id="101" name="__UID" fieldtype="Normal" datatype="Text" comment="">
              <UUID/>
              <AutoEnter type="" prohibitModification="False">
                <Calculation><Text><![CDATA[Get ( UUID )]]></Text></Calculation>
              </AutoEnter>
              <Validation type="OnlyDuringDataEntry" allowOverride="True"/>
              <Storage index="All" global="False" maxRepetitions="1"/>
              <TagList/>
            </Field>
            <Field id="102" name="Name" fieldtype="Normal" datatype="Text" comment="display name">
              <UUID/>
              <AutoEnter type="" prohibitModification="False"/>
              <Validation type="OnlyDuringDataEntry" allowOverride="True"/>
              <Storage index="All" global="False" maxRepetitions="1"/>
              <TagList/>
            </Field>
          </ObjectList>
        </FieldCatalog>
      </FieldsForTables>
      <ScriptCatalog membercount="2">
        <UUID/><TagList/>
        <Script id="900" name="Add Customer" includeInMenu="False" runFullAccess="False"><UUID/><Options/><TagList/></Script>
        <Script id="901" name="Greet Customer" includeInMenu="False" runFullAccess="False"><UUID/><Options/><TagList/></Script>
      </ScriptCatalog>
      <StepsForScripts membercount="1">
        <Script>
          <ScriptReference id="900" name="Add Customer" UUID="S900"/>
          <ObjectList membercount="2">
            <Step hash="HASHA" index="0" id="141" name="Set Variable" enable="True">
              <UUID/><OwnerID/><Options>16388</Options>
              <ParameterValues membercount="1">
                <Parameter type="Variable">
                  <value><Calculation datatype="1" position="1"><Calculation><Text><![CDATA["x"]]></Text></Calculation></Calculation></value>
                  <Name value="$param"/>
                </Parameter>
              </ParameterValues>
            </Step>
            <Step hash="HASHB" index="1" id="76" name="Set Field" enable="True">
              <UUID/><OwnerID/><Options>0</Options>
              <ParameterValues membercount="1"/>
            </Step>
          </ObjectList>
        </Script>
      </StepsForScripts>
      <CustomFunctionsCatalog membercount="1">
        <UUID/><TagList/>
        <ObjectList membercount="1">
          <CustomFunction id="50" name="Hello" access="All">
            <UUID/><TagList/>
            <Display>Hello ( who )</Display>
            <ObjectList membercount="1"><Parameter name="who"/></ObjectList>
          </CustomFunction>
        </ObjectList>
      </CustomFunctionsCatalog>
      <CalcsForCustomFunctions membercount="1">
        <ObjectList membercount="1">
          <CustomFunctionCalc>
            <CustomFunctionReference id="50" name="Hello" UUID="CF50"/>
            <Calculation><Text><![CDATA["Hello, " & who]]></Text></Calculation>
          </CustomFunctionCalc>
        </ObjectList>
      </CalcsForCustomFunctions>
      <LayoutCatalog membercount="1">
        <UUID/><TagList/>
        <Layout id="500" name="Customer Detail" width="640">
          <UUID/>
        </Layout>
      </LayoutCatalog>
      <ValueListCatalog membercount="0"><UUID/><TagList/></ValueListCatalog>
      <TableOccurrenceCatalog membercount="1">
        <UUID/><TagList/>
        <TableOccurrence id="1001" name="Customer" type="Local" View="Collapse" height="40">
          <UUID/>
          <BaseTableSourceReference type="BaseTableReference">
            <BaseTableReference id="1" name="Customer" UUID="BT1"/>
          </BaseTableSourceReference>
          <CoordRect top="0" left="0" bottom="80" right="200"/>
          <Color red="128" green="128" blue="128" alpha="1.00"/>
          <TagList/>
        </TableOccurrence>
      </TableOccurrenceCatalog>
      <RelationshipCatalog membercount="0"><UUID/></RelationshipCatalog>
"""

# v2 differences vs v1:
#  - Field "Name" comment changed
#  - New field "Email"
#  - Script "Add Customer" Step[1] hash changed (HASHB → HASHB2)
#  - Script "Greet Customer" stays as header-only (no body either way)
#  - New script "Goodbye Customer"
#  - CF "Hello" body changed
#  - Layout "Customer Detail" raw XML changed (width)
V2_BODY = V1_BODY.replace(
    'comment="display name"', 'comment="full display name"',
).replace(
    '</ObjectList>\n        </FieldCatalog>',
    '''<Field id="103" name="Email" fieldtype="Normal" datatype="Text" comment="">
              <UUID/>
              <AutoEnter type="" prohibitModification="False"/>
              <Validation type="OnlyDuringDataEntry" allowOverride="True"/>
              <Storage index="All" global="False" maxRepetitions="1"/>
              <TagList/>
            </Field>
          </ObjectList>
        </FieldCatalog>''',
).replace(
    'hash="HASHB"', 'hash="HASHB2"',
).replace(
    '<Script id="901" name="Greet Customer"',
    '<Script id="902" name="Goodbye Customer" includeInMenu="False" runFullAccess="False"><UUID/><Options/><TagList/></Script>'
    '<Script id="901" name="Greet Customer"',
).replace(
    '"Hello, " & who', '"Hello, " & who & "!"',
).replace(
    'width="640"', 'width="800"',
)


def _write_savexml_utf16(path: pathlib.Path, content: str) -> None:
    """FileMaker emits FMSaveAsXML as UTF-16 with BOM; mirror that here."""
    path.write_bytes(codecs.BOM_UTF16_LE + content.encode("utf-16-le"))


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_index_savexml_basic_counts(tmp_path):
    from fmddr.index.savexml import build_index_from_savexml

    src = tmp_path / "v1.xml"
    _write_savexml_utf16(src, _savexml("Mini.fmp12", V1_BODY))
    db = tmp_path / "v1.fmddr.db"
    counts = build_index_from_savexml(src, db, quiet=True)

    assert counts["tables"] == 1
    assert counts["fields"] == 2
    assert counts["scripts"] == 2
    assert counts["steps"] == 2
    assert counts["custom_functions"] == 1
    assert counts["layouts"] == 1
    assert counts["tos"] == 1

    conn = sqlite3.connect(db)
    try:
        meta = dict(conn.execute("SELECT key, value FROM meta").fetchall())
        assert meta["source"] == "savexml"
        # Phase B: calc resolver runs, so the index is no longer partial.
        # Inherently dynamic refs (Evaluate, GetField with computed args)
        # are still skipped — but DDR doesn't resolve those either.
        assert meta["partial"] == "false"
        assert meta["fm_file_name"] == "Mini.fmp12"

        files = conn.execute("SELECT id, name FROM file").fetchall()
        assert files == [(1, "Mini.fmp12")]

        # CF body populated from CalcsForCustomFunctions.
        body = conn.execute(
            "SELECT body FROM custom_function WHERE name='Hello'"
        ).fetchone()[0]
        assert body == '"Hello, " & who'

        # CF parameters from ObjectList of <Parameter name="who"/>.
        params = conn.execute(
            "SELECT parameters FROM custom_function WHERE name='Hello'"
        ).fetchone()[0]
        assert params == "who"

        # Field calc text from AutoEnter/Calculation/Text.
        ae = conn.execute(
            "SELECT auto_enter_calc FROM field WHERE name='__UID'"
        ).fetchone()[0]
        assert ae == "Get ( UUID )"
    finally:
        conn.close()


def test_diff_savexml_pair(tmp_path):
    """Diff a v1 vs v2 synthetic SaveAsXML pair; expect specific change set."""
    from fmddr.diff import compute_diff
    from fmddr.index.savexml import build_index_from_savexml

    src1 = tmp_path / "v1.xml"
    src2 = tmp_path / "v2.xml"
    _write_savexml_utf16(src1, _savexml("Mini.fmp12", V1_BODY))
    _write_savexml_utf16(src2, _savexml("Mini.fmp12", V2_BODY))

    db1 = tmp_path / "v1.fmddr.db"
    db2 = tmp_path / "v2.fmddr.db"
    build_index_from_savexml(src1, db1, quiet=True)
    build_index_from_savexml(src2, db2, quiet=True)

    c1 = sqlite3.connect(db1); c1.row_factory = sqlite3.Row
    c2 = sqlite3.connect(db2); c2.row_factory = sqlite3.Row
    try:
        payload = compute_diff(c1, c2, detect_renames=True, include_impact=False)
    finally:
        c1.close(); c2.close()

    ents = payload["entities"]

    # Field Email added.
    assert any(r["name"] == "Email" for r in ents["field"]["added"])
    # Field Name comment changed → modified.
    name_mods = [m for m in ents["field"]["modified"] if m["key"].endswith("::Name")]
    assert name_mods, "expected Name field to be modified"
    # Add Customer script step hash changed → modified script.
    script_mods = [m for m in ents["script"]["modified"]
                   if m["key"].endswith("Add Customer")]
    assert script_mods
    assert script_mods[0]["step_changes"], "expected at least one step change"
    # New script Goodbye Customer.
    assert any(r["name"] == "Goodbye Customer" for r in ents["script"]["added"])
    # CF Hello body changed.
    cf_mods = [m for m in ents["custom_function"]["modified"]
               if m["key"].endswith("::Hello")]
    assert cf_mods
    assert "body" in cf_mods[0]["delta"]
    # Layout raw_xml_hash changed.
    lay_mods = [m for m in ents["layout"]["modified"]
                if m["key"].endswith("Customer Detail")]
    assert lay_mods
    assert "raw_xml_hash" in lay_mods[0]["delta"]


def test_diff_savexml_vs_ddr_allowed_with_note(tmp_path):
    """Phase C: cross-source diff (DDR vs SaveAsXML) runs but emits a note."""
    from fmddr.index.build import build_index
    from fmddr.index.savexml import build_index_from_savexml

    fixture = pathlib.Path(__file__).parent / "fixtures" / "mini.xml"
    ddr_db = tmp_path / "ddr.fmddr.db"
    build_index(fixture, ddr_db, quiet=True)

    src = tmp_path / "v1.xml"
    _write_savexml_utf16(src, _savexml("Mini.fmp12", V1_BODY))
    sav_db = tmp_path / "sav.fmddr.db"
    build_index_from_savexml(src, sav_db, quiet=True)

    proc = subprocess.run(
        _fmddr_cmd("diff", str(ddr_db), str(sav_db)),
        capture_output=True, text=True,
    )
    # Cross-source diff doesn't refuse — exits 0 (no changes) or 1 (changes).
    assert proc.returncode in (0, 1), proc.stderr
    # And surfaces the format-mismatch note up front.
    assert "ddr" in proc.stderr.lower() and "savexml" in proc.stderr.lower()


def test_orphans_runs_on_savexml_index(tmp_path):
    """Phase C: orphans runs against savexml indexes (no longer skipped)."""
    from fmddr.index.savexml import build_index_from_savexml

    src = tmp_path / "v1.xml"
    _write_savexml_utf16(src, _savexml("Mini.fmp12", V1_BODY))
    db = tmp_path / "v1.fmddr.db"
    build_index_from_savexml(src, db, quiet=True)

    proc = subprocess.run(
        _fmddr_cmd("orphans", "--db", str(db)),
        capture_output=True, text=True,
    )
    # Should succeed — savexml's partial flag is False after Phase B.
    assert proc.returncode == 0, proc.stderr


def test_savexml_resolves_structured_edges(tmp_path):
    """Phase A: structured refs (Perform Script, Go to Layout, Set Field
    target, layout triggers, FromField value lists, etc.) become rows in
    script_ref / layout_ref / field_ref / value_list_ref."""
    from fmddr.index.savexml import build_index_from_savexml

    body = """\
      <BaseTableCatalog membercount="1">
        <BaseTable id="1" name="Customer" comment=""><UUID/><TagList/></BaseTable>
      </BaseTableCatalog>
      <FieldsForTables membercount="1">
        <FieldCatalog>
          <UUID/><TagList/>
          <BaseTableReference id="1" name="Customer" UUID="BT1"/>
          <ObjectList membercount="1">
            <Field id="100" name="Name" fieldtype="Normal" datatype="Text" comment="">
              <UUID/>
              <Storage index="All" global="False" maxRepetitions="1"/>
              <TagList/>
            </Field>
          </ObjectList>
        </FieldCatalog>
      </FieldsForTables>
      <ScriptCatalog membercount="2">
        <UUID/><TagList/>
        <Script id="900" name="Add Customer" includeInMenu="False" runFullAccess="False"><UUID/><Options/><TagList/></Script>
        <Script id="901" name="Greet" includeInMenu="False" runFullAccess="False"><UUID/><Options/><TagList/></Script>
      </ScriptCatalog>
      <StepsForScripts membercount="1">
        <Script>
          <ScriptReference id="900" name="Add Customer" UUID="S900"/>
          <ObjectList membercount="2">
            <Step hash="HA" index="0" id="1" name="Perform Script" enable="True">
              <UUID/><OwnerID/><Options>64</Options>
              <ParameterValues membercount="1">
                <Parameter type="List">
                  <List name="From list" value="1">
                    <ScriptReference id="901" name="Greet" UUID="S901"/>
                  </List>
                </Parameter>
              </ParameterValues>
            </Step>
            <Step hash="HB" index="1" id="6" name="Go to Layout" enable="True">
              <UUID/><OwnerID/><Options>0</Options>
              <ParameterValues membercount="1">
                <Parameter type="LayoutReferenceContainer">
                  <LayoutReferenceContainer value="5">
                    <LayoutReference id="500" name="Customer Detail" UUID="L500"/>
                  </LayoutReferenceContainer>
                </Parameter>
              </ParameterValues>
            </Step>
          </ObjectList>
        </Script>
      </StepsForScripts>
      <CustomFunctionsCatalog membercount="0"><UUID/><TagList/><ObjectList/></CustomFunctionsCatalog>
      <CalcsForCustomFunctions membercount="0"><ObjectList/></CalcsForCustomFunctions>
      <LayoutCatalog membercount="1">
        <UUID/><TagList/>
        <Layout id="500" name="Customer Detail" width="640">
          <TableOccurrenceReference id="1001" name="Customer" UUID="TO1"/>
        </Layout>
      </LayoutCatalog>
      <ValueListCatalog membercount="1">
        <UUID/><TagList/>
        <ValueList id="10" name="Names">
          <Source value="FromField"/>
        </ValueList>
      </ValueListCatalog>
      <TableOccurrenceCatalog membercount="1">
        <UUID/><TagList/>
        <TableOccurrence id="1001" name="Customer" type="Local" View="Collapse" height="40">
          <UUID/>
          <BaseTableSourceReference type="BaseTableReference">
            <BaseTableReference id="1" name="Customer" UUID="BT1"/>
          </BaseTableSourceReference>
          <CoordRect top="0" left="0" bottom="80" right="200"/>
          <Color red="128" green="128" blue="128" alpha="1.00"/>
          <TagList/>
        </TableOccurrence>
      </TableOccurrenceCatalog>
      <RelationshipCatalog membercount="0"><UUID/></RelationshipCatalog>
      <OptionsForValueLists membercount="1">
        <ValueList>
          <ValueListReference id="10" name="Names" UUID="VL10"/>
          <Source value="FromField"/>
          <Field>
            <PrimaryField show="True" sort="False">
              <FieldReference id="100" name="Name" UUID="F100">
                <TableOccurrenceReference id="1001" name="Customer" UUID="TO1"/>
              </FieldReference>
            </PrimaryField>
          </Field>
        </ValueList>
      </OptionsForValueLists>
"""
    src = tmp_path / "v1.xml"
    _write_savexml_utf16(src, _savexml("Mini.fmp12", body))
    db = tmp_path / "v1.fmddr.db"
    build_index_from_savexml(src, db, quiet=True)

    conn = sqlite3.connect(db)
    try:
        # script_step → script edge: "Add Customer" calls "Greet"
        rows = conn.execute(
            "SELECT s_caller.name, s_callee.name FROM script_ref sr "
            "JOIN script s_caller ON s_caller.id = sr.caller_id "
            "JOIN script s_callee ON s_callee.id = sr.callee_id "
            "WHERE sr.caller_kind = 'script_step'"
        ).fetchall()
        assert ("Add Customer", "Greet") in rows

        # script_step → layout edge: "Add Customer" jumps to "Customer Detail"
        rows = conn.execute(
            "SELECT s.name, l.name FROM layout_ref lr "
            "JOIN script s ON s.id = lr.caller_id "
            "JOIN layout l ON l.id = lr.layout_id "
            "WHERE lr.caller_kind = 'script_step'"
        ).fetchall()
        assert ("Add Customer", "Customer Detail") in rows

        # Layout has its primary TO + base_table linkage.
        row = conn.execute(
            "SELECT table_occurrence_id, base_table_id FROM layout WHERE name='Customer Detail'"
        ).fetchone()
        assert row[0] is not None
        assert row[1] is not None

        # Value list FromField primary → field_id populated.
        vl_field = conn.execute(
            "SELECT field_id FROM value_list WHERE name='Names'"
        ).fetchone()[0]
        assert vl_field is not None

        # field_ref(value_list) row inserted.
        n = conn.execute(
            "SELECT COUNT(*) FROM field_ref WHERE owner_kind='value_list'"
        ).fetchone()[0]
        assert n >= 1
    finally:
        conn.close()


def test_savexml_resolves_calc_edges(tmp_path):
    """Phase B: calc parser extracts field + CF refs from raw calc text."""
    from fmddr.index.savexml import build_index_from_savexml

    body = """\
      <BaseTableCatalog membercount="1">
        <BaseTable id="1" name="Customer" comment=""><UUID/><TagList/></BaseTable>
      </BaseTableCatalog>
      <FieldsForTables membercount="1">
        <FieldCatalog>
          <UUID/><TagList/>
          <BaseTableReference id="1" name="Customer" UUID="BT1"/>
          <ObjectList membercount="3">
            <Field id="101" name="First" fieldtype="Normal" datatype="Text" comment="">
              <UUID/>
              <Storage index="All" global="False" maxRepetitions="1"/>
              <TagList/>
            </Field>
            <Field id="102" name="Last" fieldtype="Normal" datatype="Text" comment="">
              <UUID/>
              <Storage index="All" global="False" maxRepetitions="1"/>
              <TagList/>
            </Field>
            <Field id="103" name="Full" fieldtype="Calculated" datatype="Text" comment="">
              <UUID/>
              <Storage storeCalculationResults="True" autoIndex="True" index="Minimal" global="False" maxRepetitions="1"/>
              <Calculation>
                <TableOccurrenceReference id="1001" name="Customer" UUID="TO1"/>
                <Text>Customer::First &amp; " " &amp; Last &amp; " (" &amp; UpperCustomer( First ) &amp; ")"</Text>
              </Calculation>
              <TagList/>
            </Field>
          </ObjectList>
        </FieldCatalog>
      </FieldsForTables>
      <ScriptCatalog membercount="0"><UUID/><TagList/></ScriptCatalog>
      <StepsForScripts membercount="0"/>
      <CustomFunctionsCatalog membercount="1">
        <UUID/><TagList/>
        <ObjectList membercount="1">
          <CustomFunction id="50" name="UpperCustomer" access="All">
            <UUID/><TagList/>
            <Display>UpperCustomer ( s )</Display>
            <ObjectList membercount="1"><Parameter name="s"/></ObjectList>
          </CustomFunction>
        </ObjectList>
      </CustomFunctionsCatalog>
      <CalcsForCustomFunctions membercount="1">
        <ObjectList membercount="1">
          <CustomFunctionCalc>
            <CustomFunctionReference id="50" name="UpperCustomer" UUID="CF50"/>
            <Calculation>
              <Text>Upper ( s )</Text>
            </Calculation>
          </CustomFunctionCalc>
        </ObjectList>
      </CalcsForCustomFunctions>
      <LayoutCatalog membercount="0"><UUID/><TagList/></LayoutCatalog>
      <ValueListCatalog membercount="0"><UUID/><TagList/></ValueListCatalog>
      <TableOccurrenceCatalog membercount="1">
        <UUID/><TagList/>
        <TableOccurrence id="1001" name="Customer" type="Local" View="Collapse" height="40">
          <UUID/>
          <BaseTableSourceReference type="BaseTableReference">
            <BaseTableReference id="1" name="Customer" UUID="BT1"/>
          </BaseTableSourceReference>
          <CoordRect top="0" left="0" bottom="80" right="200"/>
          <Color red="128" green="128" blue="128" alpha="1.00"/>
          <TagList/>
        </TableOccurrence>
      </TableOccurrenceCatalog>
      <RelationshipCatalog membercount="0"><UUID/></RelationshipCatalog>
"""
    src = tmp_path / "v1.xml"
    _write_savexml_utf16(src, _savexml("Mini.fmp12", body))
    db = tmp_path / "v1.fmddr.db"
    build_index_from_savexml(src, db, quiet=True)

    conn = sqlite3.connect(db)
    try:
        # field_ref(field_calc): Full's calc references First (qualified) and
        # Last (unqualified, via default_to=Customer).
        rows = conn.execute(
            "SELECT f.name FROM field_ref fr "
            "JOIN field f ON f.id = fr.field_id "
            "JOIN field owner ON owner.id = fr.owner_id "
            "WHERE fr.owner_kind = 'field_calc' AND owner.name = 'Full' "
            "ORDER BY f.name"
        ).fetchall()
        names = [r[0] for r in rows]
        assert "First" in names, f"qualified Customer::First not resolved: {names}"
        assert "Last" in names, f"unqualified Last not resolved: {names}"

        # custom_function_ref: Full's calc calls UpperCustomer.
        rows = conn.execute(
            "SELECT cf.name FROM custom_function_ref cfr "
            "JOIN custom_function cf ON cf.id = cfr.function_id "
            "JOIN field f ON f.id = cfr.caller_id "
            "WHERE cfr.caller_kind = 'field_calc' AND f.name = 'Full'"
        ).fetchall()
        assert ("UpperCustomer",) in rows

        # custom_function_ref(custom_function): UpperCustomer's body doesn't
        # call any other CFs (it calls built-in Upper). So no row expected.
        n = conn.execute(
            "SELECT COUNT(*) FROM custom_function_ref WHERE caller_kind='custom_function'"
        ).fetchone()[0]
        assert n == 0
    finally:
        conn.close()


def test_strips_xml_illegal_control_chars(tmp_path):
    """A stray \\x03 control byte (which FM exporters emit) must not break parse."""
    from fmddr.index.savexml import build_index_from_savexml

    body = V1_BODY.replace(
        'comment="display name"',
        'comment="display\x03name"',  # FM-style stray ETX
    )
    src = tmp_path / "v1.xml"
    _write_savexml_utf16(src, _savexml("Mini.fmp12", body))
    db = tmp_path / "v1.fmddr.db"
    counts = build_index_from_savexml(src, db, quiet=True)
    assert counts["tables"] == 1
