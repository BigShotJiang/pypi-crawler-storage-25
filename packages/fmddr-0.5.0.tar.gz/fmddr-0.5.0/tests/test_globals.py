"""Tests for global variable lifecycle analysis."""
from __future__ import annotations

import pathlib
import sqlite3

import pytest

FIXTURE = pathlib.Path(__file__).parent / "fixtures" / "mini_globals.xml"


def test_globals_set_not_cleared(tmp_path: pathlib.Path) -> None:
    from fmddr.index.build import build_index
    from fmddr.query import scripts as q_scripts

    db_path = tmp_path / "globals.db"
    build_index(FIXTURE, db_path, quiet=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    rows = q_scripts.globals_set_not_cleared(conn)
    names = [r["script_name"] for r in rows]

    assert "Sets Global" in names, "script that only sets $$ctx should be flagged"
    assert "Sets And Clears Global" not in names, "script that clears $$ctx should not be flagged"


def test_globals_set_not_cleared_returns_var_name(tmp_path: pathlib.Path) -> None:
    from fmddr.index.build import build_index
    from fmddr.query import scripts as q_scripts

    db_path = tmp_path / "globals.db"
    build_index(FIXTURE, db_path, quiet=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    rows = q_scripts.globals_set_not_cleared(conn)
    assert len(rows) == 1
    assert rows[0]["var_name"] == "$$ctx"
