"""Unit tests for the FileMaker calculation parser."""
from __future__ import annotations

import pytest

from fmddr.parser.calc import (
    CFRef,
    Dynamic,
    FieldRef,
    FunctionRef,
    parse_calc,
)


# ---------------------------------------------------------------------------
# Qualified field refs (TO::Field)
# ---------------------------------------------------------------------------

def test_qualified_field_ref_basic():
    toks = parse_calc("Customer::Name")
    assert toks == [FieldRef(to="Customer", name="Name")]


def test_qualified_field_ref_multiple():
    toks = parse_calc("Customer::Name & \" \" & Customer::Phone")
    assert toks == [
        FieldRef(to="Customer", name="Name"),
        FieldRef(to="Customer", name="Phone"),
    ]


def test_qualified_field_ref_with_repetition():
    toks = parse_calc("Customer::Name[3]")
    assert toks == [FieldRef(to="Customer", name="Name", repetition=3)]


def test_qualified_field_ref_with_spaces_in_name():
    toks = parse_calc("Web Invoices::Name First")
    assert toks == [FieldRef(to="Web Invoices", name="Name First")]


# ---------------------------------------------------------------------------
# Strings and comments are masked out
# ---------------------------------------------------------------------------

def test_string_literal_does_not_emit_ref():
    toks = parse_calc('"Customer::Name"')
    assert toks == []


def test_string_with_escaped_quote():
    # FM strings escape quote with "" — the inner Customer::Name stays inside
    # the quoted region and shouldn't be extracted.
    toks = parse_calc('"foo ""bar"" Customer::Name"')
    assert toks == []


def test_line_comment_masks_ref():
    toks = parse_calc("// Customer::Name\nReal::Field")
    assert toks == [FieldRef(to="Real", name="Field")]


def test_block_comment_masks_ref():
    toks = parse_calc("/* Customer::Name */ Real::Field")
    assert toks == [FieldRef(to="Real", name="Field")]


def test_multiline_block_comment():
    toks = parse_calc("/* line1\n  Customer::Name\n  line3 */ Real::Field")
    assert toks == [FieldRef(to="Real", name="Field")]


# ---------------------------------------------------------------------------
# Function classification
# ---------------------------------------------------------------------------

def test_unknown_function_call():
    toks = parse_calc("Get ( UUID )")
    # Get is a built-in but no builtins set provided → builtin=False.
    assert toks == [FunctionRef(name="Get", builtin=False)]


def test_known_builtin():
    toks = parse_calc("Get ( UUID )", builtins={"Get"})
    assert toks == [FunctionRef(name="Get", builtin=True)]


def test_custom_function_call():
    toks = parse_calc("MyCF ( Customer::Name )", custom_functions={"MyCF"})
    assert toks == [
        CFRef(name="MyCF"),
        FieldRef(to="Customer", name="Name"),
    ]


def test_custom_function_distinguishes_from_builtin():
    """An identifier present in BOTH custom_functions and builtins
    classifies as CFRef (CFs take priority)."""
    toks = parse_calc(
        "Sum ( Orders::Amount )",
        custom_functions={"Sum"},
        builtins={"Sum"},
    )
    assert any(isinstance(t, CFRef) and t.name == "Sum" for t in toks)


# ---------------------------------------------------------------------------
# Dynamic regions
# ---------------------------------------------------------------------------

def test_evaluate_marked_dynamic():
    toks = parse_calc('Evaluate ( "Customer::" & $name )')
    assert any(isinstance(t, Dynamic) and t.function == "Evaluate" for t in toks)
    # No FieldRef extracted from inside Evaluate's argument.
    assert not any(isinstance(t, FieldRef) for t in toks)


def test_getfield_marked_dynamic():
    toks = parse_calc("GetField ( $field_name )")
    assert any(isinstance(t, Dynamic) and t.function == "GetField" for t in toks)


def test_dynamic_call_does_not_emit_function_ref():
    """An Evaluate(...) call shouldn't double-record as both Dynamic
    and FunctionRef('Evaluate')."""
    toks = parse_calc("Evaluate ( 1 )")
    fns = [t for t in toks if isinstance(t, FunctionRef)]
    assert not fns


def test_nested_dynamic_call_masks_inner():
    """Evaluate(GetField($x)) — the entire Evaluate region is masked,
    so GetField doesn't show up as its own Dynamic marker (it's nested
    inside the masked Evaluate text)."""
    toks = parse_calc("Evaluate ( GetField ( $x ) )")
    dynamics = [t for t in toks if isinstance(t, Dynamic)]
    assert len(dynamics) == 1
    assert dynamics[0].function == "Evaluate"


# ---------------------------------------------------------------------------
# Unqualified field refs (default_to + unqualified_field_names)
# ---------------------------------------------------------------------------

def test_unqualified_ref_resolves_against_default_to():
    toks = parse_calc(
        "First & \" \" & Last",
        default_to="Customer",
        unqualified_field_names={"First", "Last"},
    )
    assert FieldRef(to="Customer", name="First") in toks
    assert FieldRef(to="Customer", name="Last") in toks


def test_unqualified_skipped_without_context():
    """Without default_to, bare identifiers are not emitted (too ambiguous)."""
    toks = parse_calc("First & Last")
    # No FieldRef without TO context.
    assert not any(isinstance(t, FieldRef) for t in toks)


def test_unqualified_longest_match_wins():
    """When name set contains both "Name" and "Name Last", "Name Last"
    matches first if present in source."""
    toks = parse_calc(
        "Name Last",
        default_to="Customer",
        unqualified_field_names={"Name", "Name Last"},
    )
    field_refs = [t for t in toks if isinstance(t, FieldRef)]
    assert len(field_refs) == 1
    assert field_refs[0].name == "Name Last"


def test_unqualified_does_not_match_inside_qualified():
    """The unqualified pass shouldn't re-extract `Field` from `TO::Field`."""
    toks = parse_calc(
        "Customer::Field & Field",
        default_to="Customer",
        unqualified_field_names={"Field"},
    )
    field_refs = [t for t in toks if isinstance(t, FieldRef)]
    # 1 from qualified + 1 from unqualified residual — exactly 2.
    assert len(field_refs) == 2


def test_unqualified_does_not_match_inside_function_name():
    """A function call `MyFunc(` shouldn't emit a FieldRef for the name
    `MyFunc` even if it's in the unqualified field-name set."""
    toks = parse_calc(
        "MyFunc ( Customer::Name )",
        default_to="Customer",
        unqualified_field_names={"MyFunc"},
        custom_functions={"MyFunc"},
    )
    field_refs = [t for t in toks if isinstance(t, FieldRef)]
    # Only the explicit Customer::Name; MyFunc should be a CFRef, not a field.
    assert len(field_refs) == 1
    assert field_refs[0].name == "Name"


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

def test_empty_calc_returns_empty():
    assert parse_calc("") == []
    assert parse_calc("   \n   ") == []


def test_self_pseudo_to_extracted_but_unresolvable():
    """`Self::Field` parses as TO=Self. Resolution at the SaveAsXML
    ingest layer fails (no TO named "Self") — that's the correct
    behavior; this just confirms the parser surfaces it."""
    toks = parse_calc("Self::Name")
    assert toks == [FieldRef(to="Self", name="Name")]


def test_long_calc_with_mixed_constructs():
    text = """
    // Build a display name.
    Let (
        prefix = "Mr. ";
        prefix & Customer::First & " " & Last & " — " &
        UpperCustomer ( Customer::Email )
    )
    """
    toks = parse_calc(
        text,
        default_to="Customer",
        unqualified_field_names={"First", "Last", "Email"},
        custom_functions={"UpperCustomer"},
    )
    field_names = sorted(t.name for t in toks if isinstance(t, FieldRef))
    assert "First" in field_names
    assert "Last" in field_names
    assert "Email" in field_names
    assert any(isinstance(t, CFRef) and t.name == "UpperCustomer" for t in toks)
