"""Smoke tests: split, index, basic queries against the synthetic fixture."""
from __future__ import annotations

import json
import pathlib
import sqlite3

import pytest

FIXTURE = pathlib.Path(__file__).parent / "fixtures" / "mini.xml"


def test_load_utf8_passthrough_for_ascii():
    from fmddr.parser.stream import load_utf8
    data = load_utf8(FIXTURE)
    assert b"<FMPReport" in data


def test_split(tmp_path: pathlib.Path):
    from fmddr.parser.split import split
    out = tmp_path / "split"
    metrics = split(FIXTURE, out, quiet=True)
    assert metrics["counts"]["tables"] == 2
    assert metrics["counts"]["scripts"] == 2
    assert metrics["counts"]["layouts"] == 2
    assert (out / "_metrics.json").exists()
    assert (out / "tables" / "customer.xml").exists()
    assert (out / "scripts" / "customers" / "add-customer.xml").exists()
    assert (out / "layouts" / "customer-detail.xml").exists()
    assert (out / "layouts" / "reports" / "customer-report.xml").exists()


def test_split_script_format_text(tmp_path: pathlib.Path):
    from fmddr.parser.split import split
    out = tmp_path / "split"
    split(FIXTURE, out, quiet=True, script_format="text")
    # Scripts land as .txt, not .xml
    assert (out / "scripts" / "customers" / "add-customer.txt").exists()
    assert not (out / "scripts" / "customers" / "add-customer.xml").exists()
    # Tables and layouts stay XML
    assert (out / "tables" / "customer.xml").exists()
    assert (out / "layouts" / "customer-detail.xml").exists()
    body = (out / "scripts" / "customers" / "add-customer.txt").read_text()
    # StepText content is preserved verbatim — variable names, calc, field refs
    assert "Set Variable [ $param; Value:Get ( ScriptParameter ) ]" in body
    assert 'ExecuteSQL ( "SELECT __UID FROM Customer" ; "" ; "" )' in body
    assert "Set Field [ Customer::Name;" in body
    # Disabled steps are commented out
    assert "// Allow User Abort [ Off ]" in body


def test_script_to_text_indents_control_flow():
    import xml.etree.ElementTree as ET
    from fmddr.parser.split import _script_to_text

    xml = (
        '<Script id="1" name="Demo">'
        "<StepList>"
        '<Step enable="True" name="If"><StepText>If [ $x = 1 ]</StepText></Step>'
        '<Step enable="True" name="Set Variable"><StepText>Set Variable [ $y; Value:1 ]</StepText></Step>'
        '<Step enable="True" name="Else"><StepText>Else</StepText></Step>'
        '<Step enable="True" name="Loop"><StepText>Loop</StepText></Step>'
        '<Step enable="True" name="Set Variable"><StepText>Set Variable [ $y; Value:2 ]</StepText></Step>'
        '<Step enable="True" name="End Loop"><StepText>End Loop</StepText></Step>'
        '<Step enable="True" name="End If"><StepText>End If</StepText></Step>'
        "</StepList></Script>"
    )
    body = _script_to_text(ET.fromstring(xml))
    lines = body.splitlines()
    # If at depth 0, body indented one level, Else back to 0, nested Loop body at depth 2
    assert "If [ $x = 1 ]" in lines
    assert "    Set Variable [ $y; Value:1 ]" in lines
    assert "Else" in lines
    assert "    Loop" in lines
    assert "        Set Variable [ $y; Value:2 ]" in lines
    assert "    End Loop" in lines
    assert "End If" in lines


def test_index_build(tmp_path: pathlib.Path):
    from fmddr.index.build import build_index
    db = tmp_path / "mini.fmddr.db"
    counts = build_index(FIXTURE, db, quiet=True)
    assert counts["tables"] == 2
    assert counts["fields"] == 5
    assert counts["scripts"] == 2
    assert counts["steps"] == 6
    assert counts["layouts"] == 2
    assert counts["tos"] == 2
    assert counts["relationships"] == 1
    assert counts["custom_functions"] == 1

    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row

    # base_table
    rows = conn.execute("SELECT id,name,records FROM base_table ORDER BY id").fetchall()
    assert [dict(r) for r in rows] == [
        {"id": 1, "name": "Customer", "records": 42},
        {"id": 2, "name": "Order", "records": 1000},
    ]

    # field — Calculated, unstored, calc text captured
    namelen = conn.execute(
        "SELECT field_type, is_unstored, calc_text FROM field WHERE id=100103"
    ).fetchone()
    assert namelen["field_type"] == "Calculated"
    assert namelen["is_unstored"] == 1
    assert "Length ( Name )" in namelen["calc_text"]

    # field — AutoEnter calc captured for __UID
    uid = conn.execute("SELECT auto_enter_calc FROM field WHERE id=100101").fetchone()
    assert "Get ( UUID )" in uid["auto_enter_calc"]

    # script + steps
    script = conn.execute("SELECT * FROM script WHERE id=900").fetchone()
    assert script["name"] == "Add Customer"
    assert script["folder"] == "customers"

    steps = conn.execute(
        "SELECT step_index, step_type_name, var_name, has_get_script_parameter, "
        "       has_execute_sql, enabled "
        "FROM script_step WHERE script_id=900 ORDER BY step_index"
    ).fetchall()
    s = [dict(r) for r in steps]
    assert s[0]["step_type_name"] == "Set Variable"
    assert s[0]["var_name"] == "$param"
    assert s[0]["has_get_script_parameter"] == 1
    assert s[0]["has_execute_sql"] == 0
    assert s[1]["has_execute_sql"] == 1
    assert s[1]["has_get_script_parameter"] == 0
    assert s[-1]["enabled"] == 0  # the trailing Allow User Abort is disabled


def test_resolvers_and_queries(tmp_path: pathlib.Path):
    from fmddr.index.build import build_index
    from fmddr.query import resolvers, scripts as q_scripts, tables as q_tables
    db_path = tmp_path / "mini.fmddr.db"
    build_index(FIXTURE, db_path, quiet=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    # resolve by name
    t = resolvers.resolve_table(conn, "Customer")
    assert t["id"] == 1

    # resolve by id token
    t2 = resolvers.resolve_table(conn, "#1")
    assert t2["name"] == "Customer"

    # field by Table::Field
    f = resolvers.resolve_field(conn, "Customer::Name")
    assert f["id"] == 100102

    # ambiguous bare field name
    with pytest.raises(resolvers.Ambiguous):
        resolvers.resolve_field(conn, "__UID")

    # not found
    with pytest.raises(resolvers.NotFound):
        resolvers.resolve_table(conn, "Nope")

    # table_fields with type filter
    rows = q_tables.table_fields(conn, 1, field_type="Calculated")
    names = sorted(r["name"] for r in rows)
    assert names == ["Greeting", "NameLength"]

    # risky_steps for execute_sql
    risky = q_scripts.risky_steps(conn, has_flag="execute_sql")
    assert len(risky) == 1
    assert risky[0]["script_name"] == "Add Customer"
    assert risky[0]["step_index"] == 1


def test_reference_graph(tmp_path: pathlib.Path):
    from fmddr.index.build import build_index
    from fmddr.query import cf as q_cf, fields as q_fields, scripts as q_scripts
    db_path = tmp_path / "mini.fmddr.db"
    build_index(FIXTURE, db_path, quiet=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    # field 100102 (Customer::Name; raw FM id 102) is referenced by:
    #  - field_calc on NameLength (synth 100103) and Greeting (synth 100104)
    #  - script_step in Add Customer step 2 (Set Field) and Greet Customer step 0
    where = {r["owner_kind"]: r["count"] for r in q_fields.field_where(conn, 100102)}
    assert where["field_calc"] == 2
    assert where["script_step"] >= 2

    # field_field_refs returns sibling fields
    siblings = q_fields.field_field_refs(conn, 100102)
    sibling_names = sorted(r["name"] for r in siblings)
    assert sibling_names == ["Greeting", "NameLength"]

    # field_script_refs is per-step
    script_refs = q_fields.field_script_refs(conn, 100102)
    pairs = sorted((r["script_name"], r["step_index"]) for r in script_refs)
    assert pairs == [("Add Customer", 2), ("Greet Customer", 0)]

    # via_to_id was resolved from name "Customer" → TO id 1001
    assert any(r["via_to_id"] == 1001 for r in script_refs)

    # script_calls / called_by
    calls = q_scripts.script_calls(conn, 900)
    assert len(calls) == 1 and calls[0]["id"] == 901
    callers = q_scripts.script_called_by(conn, 901)
    step_callers = [c for c in callers if c["caller_kind"] == "script_step"]
    assert len(step_callers) == 1 and step_callers[0]["script_id"] == 900
    # Layout 500 references Greet Customer via OnLayoutExit trigger and a button.
    layout_kinds = sorted({c["caller_kind"] for c in callers
                           if c["caller_kind"] in ("layout_trigger", "layout_button")})
    assert layout_kinds == ["layout_button", "layout_trigger"]
    from fmddr.query import layouts as q_layouts
    layout_scripts = q_layouts.layout_scripts(conn, 500)
    kinds_for_901 = sorted({r["caller_kind"] for r in layout_scripts if r["id"] == 901})
    assert kinds_for_901 == ["layout_button", "layout_trigger"]

    # Custom function "Hello" is called by Greet Customer step 0 + Greeting field calc
    cf = q_cf.resolve(conn, "Hello")
    refs = q_cf.cf_called_by(conn, cf["id"])
    kinds = sorted({r["caller_kind"] for r in refs})
    assert "script_step" in kinds and "field_calc" in kinds

    # script.fields surfaces every distinct field (ignoring noise)
    fields = q_scripts.script_fields(conn, 900)
    field_names = sorted(r["name"] for r in fields)
    assert "Name" in field_names and "__UID" in field_names


def test_cli_stats_and_table_list(tmp_path: pathlib.Path, monkeypatch, capsys):
    from typer.testing import CliRunner
    from fmddr.cli import app
    from fmddr.index.build import build_index

    db_path = tmp_path / "mini.fmddr.db"
    build_index(FIXTURE, db_path, quiet=True)

    runner = CliRunner()
    r = runner.invoke(app, ["stats", "--db", str(db_path), "-o", "json"])
    assert r.exit_code == 0, r.output
    payload = json.loads(r.output)
    assert payload["kind"] == "stats"
    assert payload["result"]["counts"]["tables"] == 2

    r = runner.invoke(app, ["table", "list", "--db", str(db_path), "-o", "json"])
    assert r.exit_code == 0, r.output
    payload = json.loads(r.output)
    assert payload["kind"] == "table.list"
    names = sorted(t["name"] for t in payload["result"])
    assert names == ["Customer", "Order"]


def test_cli_resolver_exit_codes(tmp_path: pathlib.Path):
    from typer.testing import CliRunner
    from fmddr.cli import app
    from fmddr.index.build import build_index

    db_path = tmp_path / "mini.fmddr.db"
    build_index(FIXTURE, db_path, quiet=True)
    runner = CliRunner()

    # Not found → exit 1
    r = runner.invoke(app, ["table", "show", "Nope", "--db", str(db_path), "-o", "json"])
    assert r.exit_code == 1

    # Ambiguous → exit 2 (bare "__UID" exists in two tables)
    r = runner.invoke(app, ["field", "show", "__UID", "--db", str(db_path), "-o", "json"])
    assert r.exit_code == 2
