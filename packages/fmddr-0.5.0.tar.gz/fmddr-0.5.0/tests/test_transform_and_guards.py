"""Transform DDR→snippet + guards, exercised against the mini.xml fixture."""
from __future__ import annotations

import pathlib
import re

import pytest

from fmddr.clipboard.snippet import FileMakerClipboardError
from fmddr.edit.guards import run_guards
from fmddr.parser.split import split
from fmddr.transform.ddr_to_snippet import (
    extract_steps_as_snippet,
    parse_step_spec,
    transform_file_xml,
)

FIXTURE = pathlib.Path(__file__).parent / "fixtures" / "mini.xml"


@pytest.fixture(scope="module")
def split_dir(tmp_path_factory) -> pathlib.Path:
    out = tmp_path_factory.mktemp("clip-split") / "split"
    split(FIXTURE, out, quiet=True)
    return out


def test_transform_script(split_dir: pathlib.Path):
    p = next((split_dir / "scripts").rglob("*.xml"))
    out = transform_file_xml(p.read_text(encoding="utf-8"))
    assert out["fm_type"] == "Script"
    assert out["ddr_root"] == "Script"
    assert '<fmxmlsnippet type="FMObjectList">' in out["snippet_xml"]
    assert "<Script " in out["snippet_xml"]
    # FileMaker's native Script clipboard nests <Step> directly under <Script>; no <StepList>.
    assert "<StepList" not in out["snippet_xml"]
    assert "<Step " in out["snippet_xml"]


def test_transform_table(split_dir: pathlib.Path):
    p = split_dir / "tables" / "customer.xml"
    out = transform_file_xml(p.read_text(encoding="utf-8"))
    assert out["fm_type"] == "Table"
    assert '<fmxmlsnippet type="BaseTable">' in out["snippet_xml"]


def test_transform_invalid_xml_raises():
    with pytest.raises(FileMakerClipboardError) as ei:
        transform_file_xml("not xml at all")
    assert ei.value.code == "INVALID_XML"


def test_transform_unsupported_root_raises():
    with pytest.raises(FileMakerClipboardError) as ei:
        transform_file_xml('<Layout id="1" name="x"/>')
    assert ei.value.code == "UNSUPPORTED_ELEMENT_TYPE"


def test_guards_pass_for_script(split_dir: pathlib.Path):
    p = next((split_dir / "scripts").rglob("*.xml"))
    report = run_guards(p, p.read_text(encoding="utf-8"))
    assert report.ok, report.errors
    assert report.root_tag == "Script"
    assert report.root_id is not None
    assert report.root_name is not None


def test_guards_fail_on_wrong_root_for_dir(split_dir: pathlib.Path):
    # A Layout-shape file under tables/ should fail the path-vs-root check
    fake = split_dir / "tables" / "fake.xml"
    fake.write_text('<Layout id="1" name="X"/>', encoding="utf-8")
    report = run_guards(fake, fake.read_text(encoding="utf-8"))
    assert not report.ok
    assert any("does not match expected" in e for e in report.errors)


def test_guards_fail_on_missing_attrs(tmp_path: pathlib.Path):
    p = tmp_path / "scripts" / "x.xml"
    p.parent.mkdir(parents=True)
    p.write_text("<Script/>", encoding="utf-8")
    report = run_guards(p, p.read_text(encoding="utf-8"))
    assert not report.ok
    assert any("'id'" in e for e in report.errors)
    assert any("'name'" in e for e in report.errors)


def test_guards_fail_on_malformed_xml(tmp_path: pathlib.Path):
    p = tmp_path / "scripts" / "x.xml"
    p.parent.mkdir(parents=True)
    p.write_text("<Script id='1' name='x'>", encoding="utf-8")  # unterminated
    report = run_guards(p, p.read_text(encoding="utf-8"))
    assert not report.ok
    assert any("parse error" in e.lower() for e in report.errors)


def test_guards_warn_on_layout_unsupported_in_v1(split_dir: pathlib.Path):
    # A Layout file is well-formed but not in the v1 transform set; expect a warning.
    p = next((split_dir / "layouts").rglob("*.xml"))
    report = run_guards(p, p.read_text(encoding="utf-8"))
    assert report.ok  # no hard errors
    assert any("not in v1 clipboard-supported" in w for w in report.warnings)


def test_parse_step_spec_basic():
    assert parse_step_spec("5") == [5]
    assert parse_step_spec("1-3") == [1, 2, 3]
    assert parse_step_spec("5,8,11") == [5, 8, 11]
    assert parse_step_spec("1-3,5,8-9") == [1, 2, 3, 5, 8, 9]
    # de-dupe + sort
    assert parse_step_spec("3,1,2,2") == [1, 2, 3]


@pytest.mark.parametrize("bad", ["", " ", "0", "-1", "3-1", "abc", "1-x"])
def test_parse_step_spec_rejects_garbage(bad: str):
    with pytest.raises(FileMakerClipboardError) as ei:
        parse_step_spec(bad)
    assert ei.value.code == "INVALID_STEP_SPEC"


def _add_customer_script(split_dir: pathlib.Path) -> pathlib.Path:
    # The "Add Customer" script has 5 steps in mini.xml.
    for p in (split_dir / "scripts").rglob("*.xml"):
        if "Add Customer" in p.read_text(encoding="utf-8")[:200]:
            return p
    raise AssertionError("Add Customer script not found in split fixture")


def test_extract_steps_single(split_dir: pathlib.Path):
    p = _add_customer_script(split_dir)
    out = extract_steps_as_snippet(p.read_text(encoding="utf-8"), [1])
    assert out["fm_type"] == "ScriptStep"
    assert out["selected_indices"] == [1]
    assert out["step_count"] == 5
    assert '<fmxmlsnippet type="FMObjectList">' in out["snippet_xml"]
    assert out["snippet_xml"].count("<Step ") == 1
    # Round-trip detection should classify this as ScriptStep
    from fmddr.clipboard.snippet import detect_fm_type_from_xml

    assert detect_fm_type_from_xml(out["snippet_xml"]) == "ScriptStep"


def test_extract_steps_range(split_dir: pathlib.Path):
    p = _add_customer_script(split_dir)
    out = extract_steps_as_snippet(p.read_text(encoding="utf-8"), [2, 3, 4])
    assert out["snippet_xml"].count("<Step ") == 3
    # Step 3 in fixture is "Set Field" — verify ordering preserved
    assert "Set Field" in out["snippet_xml"]
    assert "Perform Script" in out["snippet_xml"]


def test_extract_steps_all(split_dir: pathlib.Path):
    p = _add_customer_script(split_dir)
    out = extract_steps_as_snippet(p.read_text(encoding="utf-8"), None)
    assert out["fm_type"] == "ScriptStep"
    assert out["selected_indices"] == [1, 2, 3, 4, 5]
    assert out["snippet_xml"].count("<Step ") == 5


def test_extract_steps_out_of_range(split_dir: pathlib.Path):
    p = _add_customer_script(split_dir)
    with pytest.raises(FileMakerClipboardError) as ei:
        extract_steps_as_snippet(p.read_text(encoding="utf-8"), [1, 99])
    assert ei.value.code == "INVALID_STEP_SPEC"


def test_extract_steps_wrong_root(split_dir: pathlib.Path):
    p = split_dir / "tables" / "customer.xml"
    with pytest.raises(FileMakerClipboardError) as ei:
        extract_steps_as_snippet(p.read_text(encoding="utf-8"), [1])
    assert ei.value.code == "UNSUPPORTED_ELEMENT_TYPE"


def test_snippet_round_trip_detection(split_dir: pathlib.Path):
    """A snippet produced by transform should be recognized by detect_fm_type_from_xml."""
    from fmddr.clipboard.snippet import detect_fm_type_from_xml

    p = split_dir / "tables" / "customer.xml"
    out = transform_file_xml(p.read_text(encoding="utf-8"))
    assert detect_fm_type_from_xml(out["snippet_xml"]) == "Table"
