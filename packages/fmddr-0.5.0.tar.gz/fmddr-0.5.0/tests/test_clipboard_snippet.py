"""Pure-Python tests for snippet helpers — no platform calls."""
from __future__ import annotations

import pytest

from fmddr.clipboard.snippet import (
    FileMakerClipboardError,
    assert_valid_fm_xml,
    detect_fm_type_from_xml,
    detect_from_ddr_root,
    fm_type_from_format,
    parse_root_tag,
    resolve_write_element_type,
    wrap_as_snippet,
)


SCRIPT_STEP = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<fmxmlsnippet type="FMObjectList">\n'
    '  <Step enable="True" id="68" name="Show Custom Dialog" />\n'
    "</fmxmlsnippet>"
)
SCRIPT_SNIPPET = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<fmxmlsnippet type="FMObjectList">\n'
    '  <Script id="1" name="Test"><Step enable="True" id="68" name="Show Custom Dialog" /></Script>\n'
    "</fmxmlsnippet>"
)
FIELD_SNIPPET = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<fmxmlsnippet type="FieldObj"><Field id="1" name="Name" /></fmxmlsnippet>'
)


def test_detect_script_step():
    assert detect_fm_type_from_xml(SCRIPT_STEP) == "ScriptStep"


def test_detect_script():
    assert detect_fm_type_from_xml(SCRIPT_SNIPPET) == "Script"


def test_detect_field():
    assert detect_fm_type_from_xml(FIELD_SNIPPET) == "Field"


def test_detect_unknown_for_non_fm():
    assert detect_fm_type_from_xml("<root />") == "Unknown"


def test_assert_valid_rejects_empty():
    with pytest.raises(FileMakerClipboardError) as ei:
        assert_valid_fm_xml("")
    assert ei.value.code == "INVALID_XML"


def test_assert_valid_rejects_non_snippet():
    with pytest.raises(FileMakerClipboardError) as ei:
        assert_valid_fm_xml("<root />")
    assert ei.value.code == "INVALID_XML"


def test_assert_valid_accepts_snippet():
    assert_valid_fm_xml(SCRIPT_SNIPPET)


def test_wrap_as_snippet_for_script():
    payload = '<Script id="1" name="x"><Step enable="True" id="89" name="# (comment)"/></Script>'
    out = wrap_as_snippet(payload, "Script")
    assert out.startswith('<?xml version="1.0"')
    assert '<fmxmlsnippet type="FMObjectList">' in out
    assert payload in out


def test_wrap_strips_existing_xml_decl():
    payload = '<?xml version="1.0" encoding="UTF-8"?>\n<Script id="1" name="x"/>'
    out = wrap_as_snippet(payload, "Script")
    assert out.count("<?xml") == 1


def test_wrap_unsupported_type_raises():
    with pytest.raises(FileMakerClipboardError) as ei:
        wrap_as_snippet("<x/>", "CustomMenu")  # mapped to None
    assert ei.value.code == "UNSUPPORTED_ELEMENT_TYPE"


def test_resolve_explicit_wins():
    assert resolve_write_element_type(detected="Script", requested="Table") == "Table"


def test_resolve_falls_back_to_detected():
    assert resolve_write_element_type(detected="Script", requested=None) == "Script"


def test_resolve_unknown_explicit_raises():
    with pytest.raises(FileMakerClipboardError):
        resolve_write_element_type(detected="Unknown", requested="Bogus")


def test_resolve_no_signal_raises():
    with pytest.raises(FileMakerClipboardError) as ei:
        resolve_write_element_type(detected="Unknown", requested=None)
    assert "Unable to infer" in str(ei.value)


def test_fm_type_from_format_mac():
    assert fm_type_from_format("dyn.ah62d4rv4gk8zuxnxkq", platform="darwin") == "Script"
    assert fm_type_from_format("dyn.unknown", platform="darwin") == "Unknown"


def test_fm_type_from_format_win():
    assert fm_type_from_format("Mac-XMSC", platform="win32") == "Script"
    assert fm_type_from_format("Mac-XMTB", platform="win32") == "Table"


def test_detect_from_ddr_root():
    assert detect_from_ddr_root("Script") == "Script"
    assert detect_from_ddr_root("BaseTable") == "Table"
    assert detect_from_ddr_root("CustomFunction") == "CustomFunction"
    assert detect_from_ddr_root("Layout") is None


def test_parse_root_tag():
    assert parse_root_tag('<Script id="1" name="x"/>') == "Script"


def test_parse_root_tag_invalid():
    with pytest.raises(FileMakerClipboardError) as ei:
        parse_root_tag("not xml")
    assert ei.value.code == "INVALID_XML"


# ---------------------------------------------------------------------------
# CLI: `fmddr copy --snippet <file>` — bypasses split-tree guards/transform.
# ---------------------------------------------------------------------------


def _invoke_copy_snippet(tmp_path, xml_text, *extra_args):
    import json as _json
    from typer.testing import CliRunner
    from fmddr.cli import app
    from fmddr import clipboard as clip_mod

    captured: dict = {}

    def fake_set_fm_xml(xml: str, element_type: str) -> None:
        captured["xml"] = xml
        captured["element_type"] = element_type

    src = tmp_path / "snippet.xml"
    src.write_text(xml_text, encoding="utf-8")

    runner = CliRunner()
    # Patch the symbol the CLI imported by name.
    import fmddr.cli as cli_mod  # noqa
    monkey_targets = [(clip_mod, "set_fm_xml")]
    originals = [(mod, name, getattr(mod, name)) for mod, name in monkey_targets]
    for mod, name in monkey_targets:
        setattr(mod, name, fake_set_fm_xml)
    try:
        r = runner.invoke(
            app,
            ["copy", "--snippet", str(src), "--no-notify", "-o", "json", *extra_args],
        )
    finally:
        for mod, name, val in originals:
            setattr(mod, name, val)
    return r, captured, _json


def test_copy_snippet_script_step_happy_path(tmp_path):
    r, captured, json_ = _invoke_copy_snippet(tmp_path, SCRIPT_STEP)
    assert r.exit_code == 0, r.output
    payload = json_.loads(r.output)
    assert payload["kind"] == "copy"
    assert payload["result"]["ok"] is True
    assert payload["result"]["fm_type"] == "ScriptStep"
    assert payload["result"]["ddr_root"] is None
    assert payload["result"]["warnings"] == []
    assert captured["element_type"] == "ScriptStep"
    assert "<fmxmlsnippet" in captured["xml"]


def test_copy_snippet_detects_script(tmp_path):
    r, captured, json_ = _invoke_copy_snippet(tmp_path, SCRIPT_SNIPPET)
    assert r.exit_code == 0, r.output
    assert captured["element_type"] == "Script"


def test_copy_snippet_detects_field(tmp_path):
    r, captured, json_ = _invoke_copy_snippet(tmp_path, FIELD_SNIPPET)
    assert r.exit_code == 0, r.output
    assert captured["element_type"] == "Field"


def test_copy_snippet_type_override_wins(tmp_path):
    # Detection would say "ScriptStep" — explicit --type takes precedence.
    r, captured, _ = _invoke_copy_snippet(tmp_path, SCRIPT_STEP, "--type", "CustomFunction")
    assert r.exit_code == 0, r.output
    assert captured["element_type"] == "CustomFunction"


def test_copy_snippet_rejects_non_snippet_xml(tmp_path):
    from typer.testing import CliRunner
    from fmddr.cli import app

    src = tmp_path / "bogus.xml"
    src.write_text("<Script id='1' name='x'/>", encoding="utf-8")
    r = CliRunner().invoke(app, ["copy", "--snippet", str(src), "--no-notify", "-o", "json"])
    # Non-snippet input → set_fm_xml's assert_valid_fm_xml path bails with INVALID_XML.
    # But detection runs first and yields "Unknown", and --type is missing,
    # so resolve_write_element_type raises UNSUPPORTED_ELEMENT_TYPE.
    assert r.exit_code == 70


def test_copy_snippet_steps_mutually_exclusive(tmp_path):
    from typer.testing import CliRunner
    from fmddr.cli import app

    src = tmp_path / "snippet.xml"
    src.write_text(SCRIPT_STEP, encoding="utf-8")
    r = CliRunner().invoke(
        app,
        ["copy", "--snippet", str(src), "--steps", "1", "--no-notify", "-o", "json"],
    )
    assert r.exit_code == 64
    assert "mutually exclusive" in r.output or "mutually exclusive" in (r.stderr or "")
