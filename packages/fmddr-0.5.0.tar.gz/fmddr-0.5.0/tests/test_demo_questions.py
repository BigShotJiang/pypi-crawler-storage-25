"""Demo: 13 FMPerception-style questions, run against the mini fixture.

This file doubles as both a regression test and live documentation. Each
test mirrors a real impact-analysis question an agent or developer would
ask while refactoring a FileMaker monolith. When this file passes, the
library answers all of them — and the test names tell you what the
library is good for.

Run with `-s` to see the formatted answers:
    pytest tests/test_demo_questions.py -s
"""
from __future__ import annotations

import json
import pathlib
import sqlite3
import sys

import pytest

FIXTURE = pathlib.Path(__file__).parent / "fixtures" / "mini.xml"


@pytest.fixture(scope="module")
def db(tmp_path_factory) -> pathlib.Path:
    from fmddr.index.build import build_index
    db_path = tmp_path_factory.mktemp("demo") / "mini.fmddr.db"
    build_index(FIXTURE, db_path, quiet=True)
    return db_path


@pytest.fixture
def conn(db: pathlib.Path):
    c = sqlite3.connect(db)
    c.row_factory = sqlite3.Row
    yield c
    c.close()


def _show(question: str, answer) -> None:
    """Pretty-print Q&A so `pytest -s` reads like a demo."""
    sys.stdout.write("\n" + "=" * 72 + "\n")
    sys.stdout.write(f"Q: {question}\n")
    sys.stdout.write("-" * 72 + "\n")
    sys.stdout.write(json.dumps(answer, indent=2, default=str) + "\n")


# ============================================================================
# 1. What tables exist, and how big are they?
# ============================================================================

def test_q01_what_tables_exist(conn):
    from fmddr.query import tables as q_tables
    answer = q_tables.list_tables(conn)
    _show("What tables exist, and how many fields each?", answer)
    names = sorted(t["name"] for t in answer)
    assert names == ["Customer", "Order"]
    assert next(t for t in answer if t["name"] == "Customer")["fields"] == 4


# ============================================================================
# 2. What fields live on the Customer table?
# ============================================================================

def test_q02_fields_on_customer(conn):
    from fmddr.query import tables as q_tables
    answer = q_tables.table_fields(conn, 1)
    _show("What fields live on the Customer table?", answer)
    names = sorted(f["name"] for f in answer)
    assert names == ["Greeting", "Name", "NameLength", "__UID"]


# ============================================================================
# 3. Which Customer fields are unstored calculations?
# ============================================================================

def test_q03_unstored_calcs_on_customer(conn):
    from fmddr.query import tables as q_tables
    answer = q_tables.table_fields(conn, 1, only_unstored=True)
    _show("Which Customer fields are unstored calcs?", answer)
    assert [f["name"] for f in answer] == ["NameLength"]


# ============================================================================
# 4. Where is Customer::Name used, anywhere in the system?
# ============================================================================

def test_q04_where_is_customer_name_used(conn):
    from fmddr.query import fields as q_fields
    answer = q_fields.field_where(conn, 100102)
    _show("Where is Customer::Name used? (counts by owner_kind)", answer)
    by_kind = {r["owner_kind"]: r["count"] for r in answer}
    # Used by 2 calc fields (NameLength, Greeting) + at least 2 script steps.
    assert by_kind["field_calc"] == 2
    assert by_kind["script_step"] >= 2


# ============================================================================
# 5. Which scripts (and which steps) reference Customer::Name?
# ============================================================================

def test_q05_scripts_referencing_name(conn):
    from fmddr.query import fields as q_fields
    answer = q_fields.field_script_refs(conn, 100102)
    _show("Which scripts and steps reference Customer::Name?", answer)
    pairs = sorted((r["script_name"], r["step_index"]) for r in answer)
    assert pairs == [("Add Customer", 2), ("Greet Customer", 0)]


# ============================================================================
# 6. Which other fields' calcs depend on Customer::Name?
# ============================================================================

def test_q06_field_calc_dependents(conn):
    from fmddr.query import fields as q_fields
    answer = q_fields.field_field_refs(conn, 100102)
    _show("Which other fields' calcs name Customer::Name?", answer)
    assert sorted(f["name"] for f in answer) == ["Greeting", "NameLength"]


# ============================================================================
# 7. Which scripts call other scripts? (Add Customer's outgoing call)
# ============================================================================

def test_q07_what_does_add_customer_call(conn):
    from fmddr.query import scripts as q_scripts
    answer = q_scripts.script_calls(conn, 900)
    _show("What scripts does 'Add Customer' call?", answer)
    assert [r["name"] for r in answer] == ["Greet Customer"]


# ============================================================================
# 8. Who calls the 'Greet Customer' script?
# ============================================================================

def test_q08_who_calls_greet_customer(conn):
    from fmddr.query import scripts as q_scripts
    answer = q_scripts.script_called_by(conn, 901)
    _show("Who calls 'Greet Customer'?", answer)
    assert any(r["script_name"] == "Add Customer" for r in answer)


# ============================================================================
# 9. Which steps perform risky ExecuteSQL calls? (the audit question)
# ============================================================================

def test_q09_risky_execute_sql_steps(conn):
    from fmddr.query import scripts as q_scripts
    answer = q_scripts.risky_steps(conn, has_flag="execute_sql")
    _show("Which steps run ExecuteSQL? (audit risk)", answer)
    assert len(answer) == 1
    assert answer[0]["script_name"] == "Add Customer"


# ============================================================================
# 10. Where is the custom function 'Hello' called from?
#     (the FMPerception "DateRange → Portal" inverse drill)
# ============================================================================

def test_q10_cf_called_by(conn):
    from fmddr.query import cf as q_cf
    cf = q_cf.resolve(conn, "Hello")
    answer = q_cf.cf_called_by(conn, cf["id"])
    _show("Where is custom function Hello() called from?", answer)
    kinds = sorted({r["caller_kind"] for r in answer})
    assert "script_step" in kinds and "field_calc" in kinds


# ============================================================================
# 11. What's the impact of removing Customer::Name?
# ============================================================================

def test_q11_impact_of_removing_name(conn):
    from fmddr.query import impact as q_impact
    answer = q_impact.impact_field(conn, 100102)
    _show("Impact of removing Customer::Name?", answer)
    assert 900 in answer["direct_scripts"]  # Add Customer
    assert 901 in answer["direct_scripts"]  # Greet Customer
    assert sorted(answer["direct_fields"]) == [100103, 100104]  # NameLength, Greeting


# ============================================================================
# 12. What scripts and fields are unused (dead code)?
# ============================================================================

def test_q12_dead_code(conn):
    from fmddr.query import impact as q_impact
    unused_scripts = q_impact.unused(conn, "script")
    unused_fields = q_impact.unused(conn, "field")
    _show("Unused scripts (dead code candidates)", unused_scripts)
    _show("Unused fields (dead code candidates)", unused_fields)
    # Customer::Name and Greet Customer are referenced; they are NOT unused.
    assert 901 not in {s["id"] for s in unused_scripts}
    assert 100102 not in {f["id"] for f in unused_fields}


# ============================================================================
# 13. FTS search: which objects mention 'Customer'?
# ============================================================================

def test_q13_fts_search(conn):
    from fmddr.query import search as q_search
    answer = q_search.search_names(conn, "Customer*", limit=20)
    _show("FTS search for 'Customer*'", answer)
    kinds = sorted({r["kind"] for r in answer})
    assert "base_table" in kinds
    assert "script" in kinds
    assert "layout" in kinds


# ============================================================================
# 14. Relationship graph: what's the path between Customer TO and Order TO?
# ============================================================================

def test_q14_to_path(conn):
    from fmddr.query import graph as q_graph
    path = q_graph.to_path(conn, 1001, 1002)
    _show("Shortest TO path: Customer → Order", path)
    assert path is not None
    assert [n["name"] for n in path] == ["Customer", "Order"]


# ============================================================================
# 15. Script chain (the call-graph diagram, FMPerception-style)
# ============================================================================

def test_q15_script_chain_mermaid(conn):
    from fmddr.query import impact as q_impact
    edges = q_impact.script_chain(conn, 900, depth=3)
    diagram = q_impact.chain_to_mermaid(edges)
    _show("Add Customer's call chain (Mermaid)", diagram)
    assert "flowchart LR" in diagram
    assert "Add Customer" in diagram
    assert "Greet Customer" in diagram


# ============================================================================
# 16. Per-step detail (the FMP step-detail pane)
# ============================================================================

def test_q16_step_show_and_refs(conn):
    from fmddr.query import scripts as q_scripts
    # Add Customer step 1 is the ExecuteSQL one.
    detail = q_scripts.step_show(conn, 900, 1)
    refs = q_scripts.step_refs(conn, 900, 1)
    _show("Add Customer:1 (full step detail)", detail)
    _show("Add Customer:1 (everything this step references)", refs)
    assert detail["has_execute_sql"] == 1
    # The chunk-walked FieldRef inside this step's calc
    assert any(f["name"] == "__UID" for f in refs["fields"])

    # Step 3 is the Perform Script step → script_refs populated.
    refs3 = q_scripts.step_refs(conn, 900, 3)
    assert any(s["name"] == "Greet Customer" for s in refs3["scripts"])


# ============================================================================
# 17. Layout fields (what fields appear on the Customer Detail layout?)
# ============================================================================

def test_q17_layout_fields_and_objects(conn):
    from fmddr.query import layouts as q_layouts
    objs = q_layouts.layout_objects(conn, 500)
    _show("Objects on layout 'Customer Detail'", objs)
    # The fixture's layout is minimal but layout_objects table is populated;
    # may be empty if no <Object> elements were defined — still must not error.
    assert isinstance(objs, list)


# ============================================================================
# 18. Script elements + calcs (FMPerception "all elements" + "calculations")
# ============================================================================

def test_q18_script_elements_and_calcs(conn):
    from fmddr.query import scripts as q_scripts
    elems = q_scripts.script_elements(conn, 900)
    calcs = q_scripts.script_calcs(conn, 900)
    _show("All elements referenced by Add Customer", elems)
    _show("Every step's text in Add Customer", calcs)

    kinds = {e["kind"] for e in elems}
    assert "field" in kinds
    assert "script" in kinds      # Greet Customer
    assert len(calcs) == 5        # 5 steps in Add Customer


# ============================================================================
# 19. CF calls + CF fields (custom function inspection)
# ============================================================================

def test_q19_cf_calls_and_fields(conn):
    from fmddr.query import cf as q_cf
    cf = q_cf.resolve(conn, "Hello")
    calls = q_cf.cf_calls(conn, cf["id"])
    fields = q_cf.cf_fields(conn, cf["id"])
    _show("Other CFs called by Hello()", calls)
    _show("Fields referenced inside Hello()", fields)
    # Hello() body in fixture has no FieldRef chunks (NoRef only) — empty is OK.
    assert isinstance(calls, list)
    assert isinstance(fields, list)


# ============================================================================
# 20. Orphan refs (broken pointers — FM allows them to exist)
# ============================================================================

def test_q20_orphans(conn):
    from fmddr.query import impact as q_impact
    answer = q_impact.orphans(conn)
    _show("Orphan references (broken pointers)", answer)
    # In a clean fixture there should be no orphans.
    assert isinstance(answer, dict)


# ============================================================================
# 21. Cleanup candidates (regex sweep for BACKUP/COPY/OLD/etc.)
# ============================================================================

def test_q21_cleanup_candidates(conn):
    from fmddr.query import scripts as q_scripts
    answer = q_scripts.cleanup_candidates(conn)
    _show("Cleanup candidates (debt names)", answer)
    # Fixture has none, but the structure is the contract.
    assert set(answer.keys()) == {"scripts", "layouts", "fields"}


# ============================================================================
# 22. Relationship list + predicates (the schema graph)
# ============================================================================

def test_q22_relationship_predicates(conn):
    from fmddr.query import graph as q_graph
    rels = q_graph.list_relationships(conn)
    _show("Relationships in the file", rels)
    assert len(rels) == 1
    preds = q_graph.predicates_for(conn, 901)
    _show("Predicates of relationship 901", preds)
    assert preds[0]["operator"] == "Equal"
    assert preds[0]["left_table"] == "Customer"
    assert preds[0]["right_table"] == "Order"
