"""Optional smoke tests against a real, multi-file FileMaker DDR.

These tests run only when you point them at a local DDR — they are too big
to commit to the repo. Use either:

    FMDDR_REAL_SUMMARY=/path/to/Summary.xml pytest tests/test_real_ddr.py

…or drop the files at the default path `~/Desktop/pf/Summary.xml`.

The synthetic fixture in `tests/test_multifile.py` covers the same code
paths and runs unconditionally; this file is for higher-fidelity smoke
testing on a real production DDR.

Asserted counts come from the Summary.xml header for the original
"Profile FLX" + "Employee Directory" reference set; if you point the env
var at a different DDR, expect failures and override the count constants
or use `--lf`/`-k` to skip them.
"""
from __future__ import annotations

import os
import pathlib
import sqlite3

import pytest


def _resolve_real_summary() -> pathlib.Path | None:
    env = os.environ.get("FMDDR_REAL_SUMMARY")
    if env:
        p = pathlib.Path(env).expanduser()
        return p if p.exists() else None
    default = pathlib.Path.home() / "Desktop" / "pf" / "Summary.xml"
    return default if default.exists() else None


SUMMARY = _resolve_real_summary()

pytestmark = pytest.mark.skipif(
    SUMMARY is None,
    reason=(
        "real DDR not available. Set FMDDR_REAL_SUMMARY=/path/to/Summary.xml "
        "or place one at ~/Desktop/pf/Summary.xml to run this suite."
    ),
)

# Counts from the reference DDR's Summary.xml header.
EXPECTED_PER_FILE = {
    "Employee Directory.fmp12": {
        "base_tables": 17, "fields": 403, "scripts": 92, "layouts": 40,
        "tos": 47, "relationships": 36, "custom_functions": 191, "value_lists": 22,
    },
    "Profile FLX.fmp12": {
        "base_tables": 257, "fields": 10403, "scripts": 1877, "layouts": 873,
        "tos": 3083, "relationships": 2758, "custom_functions": 123, "value_lists": 503,
    },
}


@pytest.fixture(scope="module")
def summary_db(tmp_path_factory) -> pathlib.Path:
    from fmddr.index.build import build_index_from_summary
    db = tmp_path_factory.mktemp("real") / "summary.fmddr.db"
    build_index_from_summary(SUMMARY, db, quiet=True)  # type: ignore[arg-type]
    return db


def test_per_file_counts_match_summary_header(summary_db: pathlib.Path):
    conn = sqlite3.connect(summary_db)
    conn.row_factory = sqlite3.Row
    actual = {row["name"]: dict(row) for row in conn.execute(
        "SELECT f.name, "
        "  (SELECT COUNT(*) FROM base_table       WHERE file_id = f.id) AS base_tables, "
        "  (SELECT COUNT(*) FROM field            WHERE file_id = f.id) AS fields, "
        "  (SELECT COUNT(*) FROM script           WHERE file_id = f.id) AS scripts, "
        "  (SELECT COUNT(*) FROM layout           WHERE file_id = f.id) AS layouts, "
        "  (SELECT COUNT(*) FROM table_occurrence WHERE file_id = f.id) AS tos, "
        "  (SELECT COUNT(*) FROM relationship     WHERE file_id = f.id) AS relationships, "
        "  (SELECT COUNT(*) FROM custom_function  WHERE file_id = f.id) AS custom_functions, "
        "  (SELECT COUNT(*) FROM value_list       WHERE file_id = f.id) AS value_lists "
        "FROM file f"
    )}
    for fname, expected in EXPECTED_PER_FILE.items():
        if fname not in actual:
            pytest.skip(f"this DDR doesn't include {fname}; counts table is for the reference set")
        for k, v in expected.items():
            assert actual[fname][k] == v, f"{fname}.{k}: expected {v}, got {actual[fname][k]}"


def test_field_reference_graph_resolves(summary_db: pathlib.Path):
    """End-to-end: field synthesis + chunk-walked refs land on real rows."""
    conn = sqlite3.connect(summary_db)
    n_refs = conn.execute("SELECT COUNT(*) FROM field_ref").fetchone()[0]
    n_orphan_refs = conn.execute(
        "SELECT COUNT(*) FROM field_ref fr "
        "WHERE NOT EXISTS (SELECT 1 FROM field f WHERE f.id = fr.field_id)"
    ).fetchone()[0]
    assert n_refs > 1000, "expected a non-trivial reference graph on a real DDR"
    assert n_orphan_refs == 0, "every field_ref must point at an existing field"
