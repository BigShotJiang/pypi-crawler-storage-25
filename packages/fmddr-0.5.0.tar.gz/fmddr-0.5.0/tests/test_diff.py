"""Tests for `fmddr snapshot` and `fmddr diff`.

Strategy: build the mini fixture into a baseline DB, then build a mutated copy
of the fixture into a current DB, and assert the diff payload reports the
expected adds/removes/modifies/renames.
"""
from __future__ import annotations

import json
import pathlib
import sqlite3

import pytest
from typer.testing import CliRunner

FIXTURE = pathlib.Path(__file__).parent / "fixtures" / "mini.xml"


def _build(db_path: pathlib.Path, xml_path: pathlib.Path) -> None:
    from fmddr.index.build import build_index
    build_index(xml_path, db_path, quiet=True)


def _mutate_xml(src: pathlib.Path, dest: pathlib.Path, *, mutations: dict) -> None:
    text = src.read_text()
    for old, new in mutations.items():
        if old not in text:
            raise AssertionError(f"mutation source not found: {old!r}")
        text = text.replace(old, new, 1)
    dest.write_text(text)


# --------------------------------------------------------------------- snapshot

def test_snapshot_writes_labeled_copy(tmp_path: pathlib.Path):
    from fmddr.snapshot import take_snapshot
    db = tmp_path / "mini.fmddr.db"
    _build(db, FIXTURE)

    out_dir = tmp_path / "snaps"
    dest = take_snapshot(db, "baseline", out_dir)
    assert dest == out_dir / "baseline.fmddr.db"
    assert dest.exists()

    conn = sqlite3.connect(dest)
    conn.row_factory = sqlite3.Row
    meta = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM meta")}
    assert meta["snapshot_label"] == "baseline"
    assert meta["snapshot_taken_at"].endswith("Z")
    # Original DB still queryable through the copy.
    assert conn.execute("SELECT COUNT(*) FROM script").fetchone()[0] == 2


def test_snapshot_refuses_overwrite_without_force(tmp_path: pathlib.Path):
    from fmddr.snapshot import take_snapshot
    db = tmp_path / "mini.fmddr.db"
    _build(db, FIXTURE)
    out_dir = tmp_path / "snaps"
    take_snapshot(db, "v1", out_dir)
    with pytest.raises(FileExistsError):
        take_snapshot(db, "v1", out_dir)
    # --force is allowed.
    take_snapshot(db, "v1", out_dir, force=True)


def test_snapshot_rejects_invalid_label(tmp_path: pathlib.Path):
    from fmddr.snapshot import take_snapshot
    db = tmp_path / "mini.fmddr.db"
    _build(db, FIXTURE)
    with pytest.raises(ValueError):
        take_snapshot(db, "bad/label", tmp_path / "snaps")


# ------------------------------------------------------------------------- diff

def _diff(old_db: pathlib.Path, new_db: pathlib.Path, **kwargs) -> dict:
    from fmddr.diff import compute_diff
    old = sqlite3.connect(old_db)
    old.row_factory = sqlite3.Row
    new = sqlite3.connect(new_db)
    new.row_factory = sqlite3.Row
    return compute_diff(old, new, **kwargs)


def test_diff_no_changes_when_dbs_identical(tmp_path: pathlib.Path):
    a = tmp_path / "a.fmddr.db"
    b = tmp_path / "b.fmddr.db"
    _build(a, FIXTURE)
    _build(b, FIXTURE)
    payload = _diff(a, b)
    assert payload["summary"]["total_changes"] == 0
    assert payload["entities"] == {}


def test_diff_field_modified_classifies_as_shape(tmp_path: pathlib.Path):
    """Change Customer::Name's data_type — should diff as shape."""
    a = tmp_path / "a.fmddr.db"
    b = tmp_path / "b.fmddr.db"
    _build(a, FIXTURE)
    mutated = tmp_path / "mutated.xml"
    _mutate_xml(
        FIXTURE, mutated,
        mutations={
            'Field id="102" dataType="Text" fieldType="Normal" name="Name"':
                'Field id="102" dataType="Number" fieldType="Normal" name="Name"',
        },
    )
    _build(b, mutated)
    payload = _diff(a, b)
    field_changes = payload["entities"]["field"]
    assert field_changes["added"] == []
    assert field_changes["removed"] == []
    mods = field_changes["modified"]
    name_mods = [m for m in mods if m["key"].endswith("::Customer::Name")]
    assert len(name_mods) == 1
    m = name_mods[0]
    assert "shape" in m["tags"]
    assert m["delta"]["data_type"] == ["Text", "Number"]
    # Impact is bundled by default and Customer::Name is referenced widely.
    assert "impact" in m
    assert m["impact"]  # non-empty


def test_diff_script_added_and_step_changes(tmp_path: pathlib.Path):
    """Disable a step in 'Add Customer' and rename 'Greet Customer' to 'Welcome Customer'."""
    a = tmp_path / "a.fmddr.db"
    b = tmp_path / "b.fmddr.db"
    _build(a, FIXTURE)
    mutated = tmp_path / "mutated.xml"
    _mutate_xml(
        FIXTURE, mutated,
        mutations={
            # Toggle the second step's enable from True to False
            '<Step enable="True" id="141" name="Set Variable">\n              <StepText>Set Variable [ $sql':
            '<Step enable="False" id="141" name="Set Variable">\n              <StepText>Set Variable [ $sql',
            # Rename the second script (target the script definition, not the inner ref)
            'Script id="901" name="Greet Customer" includeInMenu':
            'Script id="901" name="Welcome Customer" includeInMenu',
        },
    )
    _build(b, mutated)
    payload = _diff(a, b)

    scripts = payload["entities"]["script"]
    # Add Customer should appear as modified with a step_change
    add_cust = [m for m in scripts["modified"] if m["key"].endswith("/Add Customer")]
    assert len(add_cust) == 1
    sc = add_cust[0]
    assert sc["step_changes"], "expected at least one step_changes entry"
    assert "behavior" in sc["tags"]

    # Greet → Welcome: with rename detection ON, this is a rename pair (steps unchanged).
    renames = scripts["renamed"]
    assert any(
        r["from_key"].endswith("/Greet Customer") and r["to_key"].endswith("/Welcome Customer")
        for r in renames
    )


def test_diff_rename_detect_can_be_disabled(tmp_path: pathlib.Path):
    a = tmp_path / "a.fmddr.db"
    b = tmp_path / "b.fmddr.db"
    _build(a, FIXTURE)
    mutated = tmp_path / "mutated.xml"
    _mutate_xml(
        FIXTURE, mutated,
        mutations={'Script id="901" name="Greet Customer" includeInMenu':
            'Script id="901" name="Welcome Customer" includeInMenu'},
    )
    _build(b, mutated)
    payload = _diff(a, b, detect_renames=False)
    scripts = payload["entities"]["script"]
    assert scripts["renamed"] == []
    assert any(it["key"].endswith("/Greet Customer") for it in scripts["removed"])
    assert any(it["key"].endswith("/Welcome Customer") for it in scripts["added"])


def test_diff_added_and_removed_field(tmp_path: pathlib.Path):
    """Add a new field to Order; result should include it under field.added."""
    a = tmp_path / "a.fmddr.db"
    b = tmp_path / "b.fmddr.db"
    _build(a, FIXTURE)
    mutated = tmp_path / "mutated.xml"
    extra = (
        '<Field id="202" dataType="Text" fieldType="Normal" name="Notes">'
        '<Comment/><AutoEnter allowEditing="True" calculation="False"><ConstantData/></AutoEnter>'
        '<Validation type="OnlyDuringDataEntry"/>'
        '<Storage index="None" global="False" maxRepetition="1"/></Field>'
    )
    _mutate_xml(
        FIXTURE, mutated,
        mutations={
            '</Field>\n        </FieldCatalog>\n      </BaseTable>\n    </BaseTableCatalog>':
            '</Field>' + extra + '</FieldCatalog></BaseTable></BaseTableCatalog>',
        },
    )
    _build(b, mutated)
    payload = _diff(a, b)
    fields = payload["entities"]["field"]
    assert any(it["key"].endswith("::Order::Notes") for it in fields["added"])


# -------------------------------------------------------------------- CLI tests

def test_cli_snapshot_and_diff(tmp_path: pathlib.Path):
    from fmddr.cli import app
    runner = CliRunner()

    db = tmp_path / "mini.fmddr.db"
    _build(db, FIXTURE)

    # snapshot baseline
    r = runner.invoke(app, ["snapshot", "baseline", "--db", str(db),
                            "--out", str(tmp_path / "snaps"), "--quiet"])
    assert r.exit_code == 0, r.output
    assert (tmp_path / "snaps" / "baseline.fmddr.db").exists()

    # snapshot a mutated build as v2
    mutated = tmp_path / "mutated.xml"
    _mutate_xml(
        FIXTURE, mutated,
        mutations={'Field id="102" dataType="Text" fieldType="Normal" name="Name"':
                   'Field id="102" dataType="Number" fieldType="Normal" name="Name"'},
    )
    db2 = tmp_path / "mini2.fmddr.db"
    _build(db2, mutated)
    r = runner.invoke(app, ["snapshot", "v2", "--db", str(db2),
                            "--out", str(tmp_path / "snaps"), "--quiet"])
    assert r.exit_code == 0, r.output

    # diff: changes present → exit 1, JSON parses, schema_version present
    r = runner.invoke(app, [
        "diff",
        str(tmp_path / "snaps" / "baseline.fmddr.db"),
        str(tmp_path / "snaps" / "v2.fmddr.db"),
        "--format", "json",
    ])
    assert r.exit_code == 1, r.output
    payload = json.loads(r.output)
    assert payload["kind"] == "diff"
    assert payload["schema_version"] == 1
    assert payload["summary"]["total_changes"] >= 1

    # diff against itself: no changes → exit 0
    r = runner.invoke(app, [
        "diff",
        str(tmp_path / "snaps" / "baseline.fmddr.db"),
        str(tmp_path / "snaps" / "baseline.fmddr.db"),
        "--format", "json",
    ])
    assert r.exit_code == 0, r.output
    payload = json.loads(r.output)
    assert payload["summary"]["total_changes"] == 0


def test_cli_diff_deterministic(tmp_path: pathlib.Path):
    """Running the diff twice should produce byte-identical JSON output."""
    from fmddr.cli import app
    runner = CliRunner()

    a = tmp_path / "a.fmddr.db"
    b = tmp_path / "b.fmddr.db"
    _build(a, FIXTURE)
    mutated = tmp_path / "mutated.xml"
    _mutate_xml(
        FIXTURE, mutated,
        mutations={'Field id="102" dataType="Text" fieldType="Normal" name="Name"':
                   'Field id="102" dataType="Number" fieldType="Normal" name="Name"'},
    )
    _build(b, mutated)
    out1 = runner.invoke(app, ["diff", str(a), str(b), "--format", "json"]).output
    out2 = runner.invoke(app, ["diff", str(a), str(b), "--format", "json"]).output
    assert out1 == out2


def test_cli_diff_md_format(tmp_path: pathlib.Path):
    from fmddr.cli import app
    runner = CliRunner()

    a = tmp_path / "a.fmddr.db"
    b = tmp_path / "b.fmddr.db"
    _build(a, FIXTURE)
    mutated = tmp_path / "mutated.xml"
    _mutate_xml(
        FIXTURE, mutated,
        mutations={'Field id="102" dataType="Text" fieldType="Normal" name="Name"':
                   'Field id="102" dataType="Number" fieldType="Normal" name="Name"'},
    )
    _build(b, mutated)
    r = runner.invoke(app, ["diff", str(a), str(b), "--format", "md"])
    assert r.exit_code == 1
    assert "# fmddr diff" in r.output
    assert "## field" in r.output
