# fmddr docs site

Astro + Starlight. Sources for the public docs.

```sh
cd docs
npm install
npm run dev          # http://localhost:4321
npm run build        # static site → docs/dist/
npm run preview      # preview the built site
```

Content lives in `src/content/docs/`. Edit a `.md` / `.mdx` file and the dev
server hot-reloads.

## Deploy

`docs/dist/` is a fully-static site — drop it on Cloudflare Pages, Netlify,
GitHub Pages, S3, or any static host. No server runtime required.

For GitHub Pages from the repo root:

```sh
cd docs && npm run build
# Copy docs/dist/ to gh-pages branch, or use the pages-deploy action.
```
