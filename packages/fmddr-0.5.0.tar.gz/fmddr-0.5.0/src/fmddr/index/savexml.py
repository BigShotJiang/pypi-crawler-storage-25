"""Build a fmddr index from an FMSaveAsXML (whole-file clone) export.

FMSaveAsXML is the format you get from FileMaker's "Save a Copy as XML" /
"FMSaveAsXML" tooling — a single UTF-16 XML document representing one
.fmp12 file in its entirety. It is structurally distinct from a DDR
(`<FMPReport>`) and from a clipboard snippet (`<fmxmlsnippet>`):

  <FMSaveAsXML File="..." Has_DDR_INFO="False">
    <Structure membercount="2">
      <AddAction>
        <BaseTableCatalog> ... <BaseTable id name comment/> ... </>
        <FieldsForTables>
          <FieldCatalog>
            <BaseTableReference id name UUID/>
            <ObjectList>
              <Field id name fieldtype datatype comment>...</Field> ...
        <ScriptCatalog> ... <Script id name/> ... </>
        <StepsForScripts>
          <Script>
            <ScriptReference id name UUID/>
            <ObjectList>
              <Step hash index id name enable>...</Step> ...
        <CustomFunctionsCatalog>
          <ObjectList>
            <CustomFunction id name access><Display/><ObjectList>
              <Parameter name/> ... </ObjectList></CustomFunction>
        <CalcsForCustomFunctions>
          <ObjectList>
            <CustomFunctionCalc>
              <CustomFunctionReference id name UUID/>
              <Calculation><Text/></Calculation></CustomFunctionCalc>
        <LayoutCatalog> <Layout id name width>...</Layout> </>
        <TableOccurrenceCatalog>
          <TableOccurrence id name type View ...>
            <BaseTableSourceReference type>
              <BaseTableReference id name UUID/>     # for type=BaseTableReference
            </BaseTableSourceReference>
            <Color red green blue alpha/>
            ...
        <RelationshipCatalog>
          <Relationship id>
            <LeftTable type cascadeCreate cascadeDelete>
              <TableOccurrenceReference id name UUID/></LeftTable>
            <RightTable .../>
            <JoinPredicateList>
              <JoinPredicate type>
                <LeftField><FieldReference id name UUID>
                  <TableOccurrenceReference id name UUID/></FieldReference>
                </LeftField> <RightField .../>
        <ValueListCatalog> <ValueList id name>...</ValueList> </>

`Has_DDR_INFO="False"` means there is no resolved cross-reference graph,
so the index built from this format has `meta.partial = "true"` and the
``orphans`` / ``impact`` commands are no-ops against it. Diffing two
FMSaveAsXML indexes is the primary supported use case.

Two convenient signals embedded in the format make diff cheap:
- every ``<Step>`` carries ``hash="..."`` (FM-computed content hash), so
  step-level "modified" detection just compares hashes.
- every ``<LayoutObject>`` carries ``hash="..."`` too, but the layout
  differ uses ``raw_xml_hash`` over the whole layout — fine for v1.
"""
from __future__ import annotations

import hashlib
import io
import pathlib
import re
import sqlite3
import time
import xml.etree.ElementTree as ET

from .build import (
    SCHEMA_VERSION,
    _Buffers,
    _flush,
    _init_db,
    _resolve_staging_and_finalize,
    _truthy,
    file_id_offset,
    synth_field_id,
)
from ..parser.calc import CFRef, FieldRef, parse_calc
from ..parser.stream import load_utf8

# XML 1.0 forbids most C0 control bytes (only \t \n \r are allowed below 0x20).
# FileMaker's exporter occasionally emits stray control bytes (e.g. \x03)
# inside CDATA, which expat rejects. Strip them up front.
_CTRL_BYTES = re.compile(rb"[\x00-\x08\x0B\x0C\x0E-\x1F]")


def _calc_text_and_to(elem: ET.Element) -> tuple[str | None, str | None]:
    """Find a `<Calculation>` somewhere under `elem` (any depth) and return
    `(text, default_to_name)`.

    SaveAsXML stores each calc with a sibling `<TableOccurrenceReference
    name="...">` that names the TO providing the calc's default field
    context. For an auto-enter calc, the path is `AutoEnter > Calculated
    > Calculation > {TableOccurrenceReference, Text}`. For a calculated
    field, it's `Field > Calculation > {TableOccurrenceReference, Text}`.
    For a validation calc, `Validation > Calculated > Calculation > ...`.
    """
    if elem is None:
        return None, None
    # Search at most one Calculation per call. Walk descendants in document
    # order; the first <Calculation> with a <Text> child wins.
    for calc in elem.iter("Calculation"):
        text = calc.find("Text")
        if text is None or not text.text:
            continue
        to_ref = calc.find("TableOccurrenceReference")
        to_name = to_ref.get("name") if to_ref is not None else None
        return text.text, to_name
    return None, None


def _calc_text(elem: ET.Element) -> str | None:
    """Back-compat shim; returns just the text body."""
    text, _ = _calc_text_and_to(elem)
    return text


def _direct_calc_text(elem: ET.Element) -> str | None:
    """Back-compat shim for calculated-field bodies."""
    text, _ = _calc_text_and_to(elem)
    return text


def _step_signature(step: ET.Element) -> str:
    """A stable string capturing what's interesting about a step for diff.

    FileMaker stamps a content `hash` attr on every step. Combine that with
    the step name (human-readable type) so diff output is meaningful even
    when only the hash differs.
    """
    h = step.get("hash") or ""
    name = step.get("name") or ""
    return f"{name} [{h}]"


# ----------------------------------------------------------------------
# Structured reference extraction (Phase A — no calc parsing).
#
# SaveAsXML stores explicit refs as `<*Reference id name UUID>` elements
# (typically with a child `<TableOccurrenceReference name>` for fields).
# These walkers stage rows into the same buffer the DDR ingester uses, so
# the post-pass `_resolve_staging_and_finalize` resolves names → ids the
# same way for both formats.
# ----------------------------------------------------------------------

def _stage_field_ref_from_savexml_fr(
    fr: ET.Element,
    *,
    owner_kind: str,
    owner_id: int,
    owner_sub: int | None,
    buf: "_Buffers",
    file_id: int,
) -> None:
    """Stage one `<FieldReference id ...><TableOccurrenceReference name .../></>`.

    SaveAsXML's FieldReference is a structured wrapper; the enclosed
    TableOccurrenceReference's `name` is what the resolver matches against
    `table_occurrence.name` to recover the BaseTable raw id.
    """
    raw_fid = fr.get("id")
    if not raw_fid or not raw_fid.isdigit():
        return
    fid = int(raw_fid)
    if fid <= 0:
        return
    to_ref = fr.find("TableOccurrenceReference")
    to_name = to_ref.get("name") if to_ref is not None else None
    if not to_name:
        return
    rep_raw = fr.get("repetition")
    try:
        rep = int(rep_raw) if rep_raw else None
    except ValueError:
        rep = None
    buf.field_ref_staging.append(
        (fid, owner_kind, owner_id, owner_sub, to_name, rep, file_id)
    )


def _extract_step_refs(
    step: ET.Element,
    *,
    owner_kind: str,
    owner_id: int,
    owner_sub: int,
    buf: "_Buffers",
    file_id: int,
    offset: int,
) -> None:
    """Walk a SaveAsXML <Step> for structured refs and stage them.

    Captures:
      - <ScriptReference id ...>      → script_ref
      - <LayoutReference id ...>      → layout_ref
      - <FieldReference id ...>       → field_ref_staging

    `owner_kind`/`owner_id`/`owner_sub` typically describe the script step
    site (`script_step`, script_id, step_index) but are also reused for
    button action steps (`layout_button`) and menu item action steps
    (`custom_menu`).
    """
    for sr in step.iter("ScriptReference"):
        sid_raw = sr.get("id")
        if not sid_raw or not sid_raw.isdigit():
            continue
        sid = int(sid_raw)
        if sid <= 0:
            continue
        # `script_ref` schema: caller_kind, caller_id, caller_sub, callee_id, parameter_calc.
        # For non-script_step callers the parameter_calc is left None.
        param_calc = None
        if owner_kind == "script_step":
            # Step's own ParameterValues > Calculation provides the parameter calc.
            calc_text_el = step.find(".//ParameterValues/Parameter[@type='Calculation']/Calculation/Calculation/Text")
            if calc_text_el is not None and calc_text_el.text:
                param_calc = calc_text_el.text
        buf.script_ref.append((owner_kind, owner_id, owner_sub, sid + offset, param_calc))

    for lr in step.iter("LayoutReference"):
        lid_raw = lr.get("id")
        if not lid_raw or not lid_raw.isdigit():
            continue
        lid = int(lid_raw)
        if lid <= 0:
            continue
        buf.layout_ref.append((owner_kind, owner_id, owner_sub, lid + offset))

    for fr in step.iter("FieldReference"):
        _stage_field_ref_from_savexml_fr(
            fr, owner_kind=owner_kind, owner_id=owner_id, owner_sub=owner_sub,
            buf=buf, file_id=file_id,
        )


def _extract_layout_refs(
    layout: ET.Element,
    *,
    layout_id: int,
    buf: "_Buffers",
    file_id: int,
    offset: int,
    calc_sites: list | None = None,
) -> tuple[int | None, str | None]:
    """Walk a SaveAsXML <Layout> for structured refs and stage them.

    Returns (primary_to_id, theme_name) so the layout row can be updated
    with the layout's TO/theme context.

    Captures:
      - Each <LayoutObject> → `layout_object` row (id, type, bounds, name)
      - FieldObj field placements: Field/FieldReference + TableOccurrenceReference
      - Drop-down value list bindings: ValueListReference inside FieldObj
      - Layout-level ScriptTriggers → script_ref(layout_trigger)
      - Button object action steps → script_ref(layout_button) + nested layout/field refs
      - LayoutThemeReference → returned for the layout row
      - Layout's primary TableOccurrenceReference → returned for the layout row
    """
    # Primary TO + theme.
    primary_to_raw: int | None = None
    primary_to_id: int | None = None
    direct_to = layout.find("TableOccurrenceReference")
    if direct_to is not None:
        rid = direct_to.get("id")
        if rid and rid.isdigit():
            primary_to_raw = int(rid)
            primary_to_id = primary_to_raw + offset
    theme_name: str | None = None
    theme_ref = layout.find("LayoutThemeReference")
    if theme_ref is not None:
        theme_name = theme_ref.get("name") or None

    # Walk LayoutObjects: emit layout_object rows + extract refs anchored at
    # owner_sub = LayoutObject.id (FM-stable numeric key).
    for obj in layout.iter("LayoutObject"):
        ok_raw = obj.get("id")
        if not ok_raw or not ok_raw.isdigit():
            continue
        okey = int(ok_raw)
        obj_type = obj.get("type") or ""
        bt = bl = bb = br = None
        bounds = obj.find("Bounds")
        if bounds is not None:
            try:
                bt = float(bounds.get("top") or 0)
                bl = float(bounds.get("left") or 0)
                bb = float(bounds.get("bottom") or 0)
                br = float(bounds.get("right") or 0)
            except ValueError:
                bt = bl = bb = br = None
        obj_name = obj.get("name") or None
        buf.layout_object.append((
            layout_id, okey, None, obj_type, bt, bl, bb, br, obj_name, None,
        ))

        # FieldObj/EditBoxObj/etc. → Field placements (FieldReference under <Field>).
        for fr in obj.iter("FieldReference"):
            _stage_field_ref_from_savexml_fr(
                fr,
                owner_kind="layout_object", owner_id=layout_id, owner_sub=okey,
                buf=buf, file_id=file_id,
            )

        # Drop-down value list binding (FieldObj > ValueListReference, etc.).
        for vlr in obj.iter("ValueListReference"):
            vid_raw = vlr.get("id")
            if not vid_raw or not vid_raw.isdigit():
                continue
            vid = int(vid_raw)
            if vid <= 0:
                continue
            buf.value_list_ref.append((
                "layout_object", layout_id, okey, vid + offset,
            ))

        # Button object action steps → script_ref(layout_button) + field/layout
        # refs from the action step's payload.
        if obj_type in ("Button", "Button Bar Segment"):
            for action_step in obj.iter("Step"):
                _extract_step_refs(
                    action_step,
                    owner_kind="layout_button",
                    owner_id=layout_id,
                    owner_sub=okey,
                    buf=buf, file_id=file_id, offset=offset,
                )
                if calc_sites is not None:
                    for calc_text_el in action_step.iter("Text"):
                        if calc_text_el.text:
                            calc_sites.append((
                                "layout_button", layout_id, okey,
                                calc_text_el.text, None,
                            ))

        # Layout-object calc sites: hide-when, conditional formatting,
        # web viewer URL, tooltip. We harvest *every* <Calculation><Text>
        # under this object; downstream resolution is the same regardless
        # of which kind of calc it was.
        if calc_sites is not None:
            # Layout primary TO is the default for unqualified field refs
            # in any object's calc unless the calc carries its own TO ref.
            layout_default_to = direct_to.get("name") if direct_to is not None else None
            for calc_el in obj.iter("Calculation"):
                txt = calc_el.find("Text")
                if txt is not None and txt.text:
                    to_ref = calc_el.find("TableOccurrenceReference")
                    calc_to = to_ref.get("name") if to_ref is not None else layout_default_to
                    calc_sites.append((
                        "layout_object", layout_id, okey, txt.text, calc_to,
                    ))

    # Layout-level script triggers (anywhere in the layout subtree —
    # Layout, ObjectList, individual objects can each carry triggers).
    for triggers in layout.iter("ScriptTriggers"):
        for st in triggers.iter("ScriptTrigger"):
            for sr in st.findall("ScriptReference"):
                sid_raw = sr.get("id")
                if not sid_raw or not sid_raw.isdigit():
                    continue
                sid = int(sid_raw)
                if sid <= 0:
                    continue
                event_name = st.get("action") or ""
                # caller_sub: a stable hash of action name keeps multiple
                # triggers on the same layout distinguishable.
                buf.script_ref.append((
                    "layout_trigger", layout_id, hash(event_name) & 0xFFFF,
                    sid + offset, None,
                ))

    return primary_to_id, theme_name


def _extract_value_list_options(
    vl: ET.Element,
    *,
    vl_raw_id: int,
    vl_id: int,
    buf: "_Buffers",
    file_id: int,
) -> int | None:
    """Process one <ValueList> inside <OptionsForValueLists>.

    Returns a staged (raw_field_id, to_name) tuple slot's *raw* field id so
    the post-pass can also update value_list.field_id. SaveAsXML's
    OptionsForValueLists carries the actual source: Custom values, FromField
    PrimaryField/SecondaryField FieldReferences, or External pointers.
    """
    src_el = vl.find("Source")
    src_value = (src_el.get("value") if src_el is not None else None) or "Custom"
    if src_value != "FromField":
        return None
    primary = vl.find("Field/PrimaryField/FieldReference")
    if primary is None:
        return None
    raw_fid = primary.get("id")
    if not raw_fid or not raw_fid.isdigit():
        return None
    fid = int(raw_fid)
    if fid <= 0:
        return None
    to_ref = primary.find("TableOccurrenceReference")
    to_name = to_ref.get("name") if to_ref is not None else None
    if not to_name:
        return None
    buf.field_ref_staging.append(
        (fid, "value_list", vl_id, None, to_name, None, file_id)
    )
    # SecondaryField (sort/display field) is also a usage edge.
    secondary = vl.find("Field/SecondaryField/FieldReference")
    if secondary is not None:
        sec_raw = secondary.get("id")
        if sec_raw and sec_raw.isdigit() and int(sec_raw) > 0:
            sec_to = secondary.find("TableOccurrenceReference")
            sec_to_name = sec_to.get("name") if sec_to is not None else None
            if sec_to_name:
                buf.field_ref_staging.append(
                    (int(sec_raw), "value_list", vl_id, 1, sec_to_name, None, file_id)
                )
    return fid


def _resolve_calc_edges(
    conn: "sqlite3.Connection",
    file_id: int,
    calc_sites: list[tuple[str, int, int | None, str, str | None]],
) -> tuple[int, int]:
    """Phase B post-pass: parse every collected calc body, emit field_ref +
    custom_function_ref rows.

    `calc_sites` is a list of `(owner_kind, owner_id, owner_sub, text,
    default_to)` tuples collected during the streaming parse. We resolve
    here, after the entity tables are populated, because:
      - field_ref needs `field.id`, which depends on the BaseTable id and
        the TO→BT mapping (TableOccurrenceCatalog comes after most calcs);
      - custom_function_ref needs `custom_function.id`.

    Returns (n_field_refs_written, n_cf_refs_written).
    """
    # Build name lookups, scoped to this file_id.
    to_to_bt_id: dict[str, int] = {}
    to_id_by_name: dict[str, int] = {}
    for to_id, name, bt_id in conn.execute(
        "SELECT id, name, base_table_id FROM table_occurrence WHERE file_id = ?",
        (file_id,),
    ):
        to_id_by_name[name] = to_id
        if bt_id is not None:
            to_to_bt_id[name] = bt_id

    field_id_by_bt_name: dict[tuple[int, str], int] = {}
    field_names_by_bt: dict[int, set[str]] = {}
    for bt_id, name, fid in conn.execute(
        "SELECT base_table_id, name, id FROM field WHERE file_id = ?", (file_id,)
    ):
        field_id_by_bt_name[(bt_id, name)] = fid
        field_names_by_bt.setdefault(bt_id, set()).add(name)
    # Frozen view per BT for parser reuse.
    field_names_frozen: dict[int, frozenset[str]] = {
        k: frozenset(v) for k, v in field_names_by_bt.items()
    }

    cf_id_by_name: dict[str, int] = {}
    for name, cf_id in conn.execute(
        "SELECT name, id FROM custom_function WHERE file_id = ?", (file_id,)
    ):
        cf_id_by_name[name] = cf_id

    cf_set = frozenset(cf_id_by_name.keys())

    field_ref_rows: list[tuple] = []
    cf_ref_rows: list[tuple] = []

    for owner_kind, owner_id, owner_sub, text, default_to in calc_sites:
        if not text:
            continue
        # Resolve unqualified-field context from default_to (if known).
        unqual_names: frozenset[str] | None = None
        if default_to:
            bt_for_default = to_to_bt_id.get(default_to)
            if bt_for_default is not None:
                unqual_names = field_names_frozen.get(bt_for_default)

        for tok in parse_calc(
            text,
            default_to=default_to,
            unqualified_field_names=unqual_names,
            custom_functions=cf_set,
        ):
            if isinstance(tok, FieldRef):
                bt_id = to_to_bt_id.get(tok.to)
                if bt_id is None:
                    continue
                field_id = field_id_by_bt_name.get((bt_id, tok.name))
                if field_id is None:
                    continue
                via_to = to_id_by_name.get(tok.to)
                field_ref_rows.append(
                    (field_id, owner_kind, owner_id, owner_sub, via_to, tok.repetition)
                )
            elif isinstance(tok, CFRef):
                cf_id = cf_id_by_name.get(tok.name)
                if cf_id is None:
                    continue
                cf_ref_rows.append((owner_kind, owner_id, owner_sub, cf_id))

    if field_ref_rows:
        conn.executemany(
            "INSERT INTO field_ref(field_id,owner_kind,owner_id,owner_sub,via_to_id,repetition) "
            "VALUES (?,?,?,?,?,?)",
            field_ref_rows,
        )
    if cf_ref_rows:
        conn.executemany(
            "INSERT INTO custom_function_ref(caller_kind,caller_id,caller_sub,function_id) "
            "VALUES (?,?,?,?)",
            cf_ref_rows,
        )
    return len(field_ref_rows), len(cf_ref_rows)


def build_index_from_savexml(
    src: pathlib.Path,
    db_path: pathlib.Path,
    *,
    keep_xml: bool = False,
    quiet: bool = False,
) -> dict:
    """Stream-ingest one FMSaveAsXML file into a fresh index DB."""
    if not quiet:
        size_mb = src.stat().st_size / 1e6
        print(f"Reading {src.name} ({size_mb:.1f} MB)...", flush=True)
    t0 = time.time()
    raw = load_utf8(src)
    data = _CTRL_BYTES.sub(b"", raw)
    sha = hashlib.sha256(data).hexdigest()
    if not quiet:
        print(f"  decoded + cleaned to {len(data)/1e6:.1f} MB UTF-8 "
              f"in {time.time()-t0:.1f}s", flush=True)

    file_id = 1
    O = file_id_offset(file_id)
    counts = {
        "tables": 0, "fields": 0, "scripts": 0, "steps": 0, "layouts": 0,
        "tos": 0, "relationships": 0, "custom_functions": 0, "value_lists": 0,
    }
    buf = _Buffers()

    fm_root_attrs: dict[str, str] = {}

    # Section flags — set on `start`, cleared on `end`.
    in_struct_add = False
    in_basetable_cat = False
    in_fields_for_tables = False
    in_field_catalog = False
    current_fc_bt_raw: int | None = None  # base_table raw id for current FieldCatalog
    in_script_cat = False
    in_steps_for_scripts = False
    in_steps_script = False
    current_steps_script_id: int | None = None  # raw FM id; set from ScriptReference
    in_cf_cat = False
    in_calcs_for_cfs = False
    cf_params_by_id: dict[int, list[str]] = {}     # CF raw id → ["who", ...]
    cf_display_by_id: dict[int, str] = {}          # CF raw id → "Hello ( who )"
    in_layout_cat = False
    in_to_cat = False
    in_to: bool = False
    current_to_bt_raw: int | None = None
    in_rel_cat = False
    in_vl_cat = False
    in_options_vl = False
    in_options_vl_item = False
    current_options_vl_id: int | None = None  # raw VL id from inner ValueListReference
    in_menu_cat = False
    in_menu = False
    current_menu_id: int | None = None
    current_menu_item_idx: int = 0

    # Pending relationship predicates (resolved post-pass via TO → BT lookup).
    rel_predicates_staged: list[tuple] = []  # (rel_id, raw_left_field_id, left_to_name, op, raw_right_field_id, right_to_name)
    rel_meta_staged: list[tuple] = []        # (rel_id, left_to_id_synth, right_to_id_synth)
    # Raw field id staged per VL for value_list.field_id post-pass write.
    # Keys are synthesized vl_id, values are (raw_fid, to_name).
    vl_primary_field_staged: dict[int, tuple[int, str]] = {}
    # Calc bodies collected during parse, resolved post-parse via _resolve_calc_edges.
    # Each entry: (owner_kind, owner_id, owner_sub, calc_text, default_to_name).
    calc_sites: list[tuple[str, int, int | None, str, str | None]] = []

    parser = ET.iterparse(io.BytesIO(data), events=("start", "end"))
    t0 = time.time()
    for ev, elem in parser:
        tag = elem.tag

        if ev == "start":
            if tag == "FMSaveAsXML" and not fm_root_attrs:
                fm_root_attrs = dict(elem.attrib)
            elif tag == "AddAction":
                in_struct_add = True
            elif in_struct_add:
                if tag == "BaseTableCatalog":
                    in_basetable_cat = True
                elif tag == "FieldsForTables":
                    in_fields_for_tables = True
                elif tag == "FieldCatalog" and in_fields_for_tables:
                    in_field_catalog = True
                    current_fc_bt_raw = None
                elif tag == "ScriptCatalog":
                    in_script_cat = True
                elif tag == "StepsForScripts":
                    in_steps_for_scripts = True
                elif tag == "Script" and in_steps_for_scripts:
                    in_steps_script = True
                    current_steps_script_id = None
                elif tag == "CustomFunctionsCatalog":
                    in_cf_cat = True
                elif tag == "CalcsForCustomFunctions":
                    in_calcs_for_cfs = True
                elif tag == "LayoutCatalog":
                    in_layout_cat = True
                elif tag == "TableOccurrenceCatalog":
                    in_to_cat = True
                elif tag == "TableOccurrence" and in_to_cat:
                    in_to = True
                    current_to_bt_raw = None
                elif tag == "RelationshipCatalog":
                    in_rel_cat = True
                elif tag == "ValueListCatalog":
                    in_vl_cat = True
                elif tag == "OptionsForValueLists":
                    in_options_vl = True
                elif tag == "ValueList" and in_options_vl:
                    in_options_vl_item = True
                    current_options_vl_id = None
                elif tag == "CustomMenuCatalog":
                    in_menu_cat = True
                elif tag == "CustomMenu" and in_menu_cat:
                    in_menu = True
                    rid = elem.get("id")
                    current_menu_id = (int(rid) + O) if (rid and rid.isdigit()) else None
                    current_menu_item_idx = 0
            continue

        # event == "end"
        try:
            # ---------------- BaseTables ----------------
            if tag == "BaseTable" and in_basetable_cat:
                raw_id = elem.get("id")
                if raw_id and raw_id.isdigit():
                    bt_raw = int(raw_id)
                    bt_id = bt_raw + O
                    name = elem.get("name") or ""
                    comment = elem.get("comment") or None
                    if comment == "":
                        comment = None
                    buf.base_table.append((
                        bt_id, file_id, bt_raw, name,
                        0,  # records — not exposed in FMSaveAsXML
                        ET.tostring(elem, encoding="unicode") if keep_xml else None,
                    ))
                    counts["tables"] += 1
                elem.clear()

            elif tag == "BaseTableCatalog" and in_basetable_cat:
                in_basetable_cat = False
                elem.clear()

            # ---------------- Fields ----------------
            elif tag == "BaseTableReference" and in_field_catalog and current_fc_bt_raw is None:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    current_fc_bt_raw = int(rid)
                # do not clear — small element, parent will

            elif tag == "Field" and in_field_catalog and current_fc_bt_raw is not None:
                raw_fid = elem.get("id")
                if raw_fid and raw_fid.isdigit():
                    fid_raw = int(raw_fid)
                    fid = synth_field_id(file_id, current_fc_bt_raw, fid_raw)
                    name = elem.get("name") or ""
                    data_type = elem.get("datatype") or ""
                    field_type = elem.get("fieldtype") or ""
                    storage = elem.find("Storage")
                    is_global = _truthy(storage.get("global")) if storage is not None else 0
                    repetitions = 1
                    if storage is not None:
                        try:
                            repetitions = int(storage.get("maxRepetitions") or "1")
                        except ValueError:
                            repetitions = 1
                    is_unstored = 0
                    if field_type == "Calculated" and storage is not None:
                        is_unstored = 1 if storage.get("storeCalculationResults") == "False" else 0
                    comment = elem.get("comment") or None
                    if comment == "":
                        comment = None
                    auto_enter_calc, ae_to = _calc_text_and_to(elem.find("AutoEnter"))
                    if field_type == "Calculated":
                        calc_text, calc_to = _calc_text_and_to(elem)
                    else:
                        calc_text, calc_to = None, None
                    validation_calc, val_to = _calc_text_and_to(elem.find("Validation"))
                    buf.field.append((
                        fid, file_id, fid_raw,
                        current_fc_bt_raw + O,  # base_table_id (synthesized)
                        name, data_type, field_type,
                        is_global, is_unstored, auto_enter_calc, calc_text, comment,
                        repetitions,
                        ET.tostring(elem, encoding="unicode") if keep_xml else None,
                    ))
                    counts["fields"] += 1
                    if calc_text:
                        calc_sites.append(("field_calc", fid, None, calc_text, calc_to))
                    if auto_enter_calc:
                        calc_sites.append(("field_autoenter", fid, None, auto_enter_calc, ae_to))
                    if validation_calc:
                        calc_sites.append(("field_validation", fid, None, validation_calc, val_to))
                elem.clear()

            elif tag == "FieldCatalog" and in_field_catalog:
                in_field_catalog = False
                current_fc_bt_raw = None
                elem.clear()

            elif tag == "FieldsForTables" and in_fields_for_tables:
                in_fields_for_tables = False
                elem.clear()

            # ---------------- Script headers ----------------
            elif tag == "Script" and in_script_cat and not in_steps_for_scripts:
                raw_id = elem.get("id")
                if raw_id and raw_id.isdigit():
                    sid_raw = int(raw_id)
                    sid = sid_raw + O
                    buf.script.append((
                        sid, file_id, elem.get("name") or "",
                        None,                                  # folder
                        _truthy(elem.get("includeInMenu")),
                        _truthy(elem.get("runFullAccess")),
                        ET.tostring(elem, encoding="unicode") if keep_xml else None,
                    ))
                    counts["scripts"] += 1
                elem.clear()

            elif tag == "ScriptCatalog" and in_script_cat:
                in_script_cat = False
                elem.clear()

            # ---------------- Script steps ----------------
            elif tag == "ScriptReference" and in_steps_script and current_steps_script_id is None:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    current_steps_script_id = int(rid)

            elif tag == "Step" and in_steps_script and current_steps_script_id is not None:
                # Hash-stamped step. Use FM hash + name as our step_text so the
                # diff layer's per-step comparison detects any internal change.
                idx_attr = elem.get("index")
                try:
                    idx = int(idx_attr) if idx_attr is not None else 0
                except ValueError:
                    idx = 0
                step_type_id = 0
                try:
                    step_type_id = int(elem.get("id") or "0")
                except ValueError:
                    step_type_id = 0
                step_type_name = elem.get("name") or ""
                enabled = _truthy(elem.get("enable", "True"))
                step_text = _step_signature(elem)
                # `var_name`: pull from <Parameter type="Variable"><Name value="..."/>
                var_name: str | None = None
                for nm in elem.iter("Name"):
                    v = nm.get("value")
                    if v:
                        var_name = v
                        break
                # Risky-step flags from any nested <Calculation><Text>… text.
                blob = ""
                for txt in elem.iter("Text"):
                    if txt.text:
                        blob += txt.text + "\n"
                has_get_param = 1 if "Get ( ScriptParameter )" in blob or "Get(ScriptParameter)" in blob else 0
                has_get_result = 1 if "Get ( ScriptResult )" in blob or "Get(ScriptResult)" in blob else 0
                has_evaluate = 1 if "Evaluate (" in blob or "Evaluate(" in blob else 0
                has_execute_sql = 1 if "ExecuteSQL (" in blob or "ExecuteSQL(" in blob else 0
                buf.step.append((
                    current_steps_script_id + O, idx, idx + 1,
                    step_type_id, step_type_name, enabled,
                    step_text, var_name,
                    has_get_param, has_get_result, has_evaluate, has_execute_sql,
                    0, 0,
                ))
                counts["steps"] += 1
                _extract_step_refs(
                    elem,
                    owner_kind="script_step",
                    owner_id=current_steps_script_id + O,
                    owner_sub=idx,
                    buf=buf, file_id=file_id, offset=O,
                )
                # Step calc payloads: every <Calculation><Text> inside the
                # step (Set Field's value, If's predicate, Set Variable's
                # value, etc.) is a calc-ref site. Each calc carries a
                # sibling <TableOccurrenceReference> giving its default
                # field-context TO.
                for calc_el in elem.iter("Calculation"):
                    txt = calc_el.find("Text")
                    if txt is not None and txt.text:
                        to_ref = calc_el.find("TableOccurrenceReference")
                        default_to = to_ref.get("name") if to_ref is not None else None
                        calc_sites.append((
                            "script_step",
                            current_steps_script_id + O, idx,
                            txt.text, default_to,
                        ))
                elem.clear()

            elif tag == "Script" and in_steps_script:
                in_steps_script = False
                current_steps_script_id = None
                elem.clear()

            elif tag == "StepsForScripts" and in_steps_for_scripts:
                in_steps_for_scripts = False
                elem.clear()

            # ---------------- Custom functions ----------------
            elif tag == "CustomFunction" and in_cf_cat:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    cf_raw = int(rid)
                    name = elem.get("name") or ""
                    # Parameters: ObjectList/Parameter[@name].
                    params = []
                    for p in elem.iter("Parameter"):
                        pn = p.get("name")
                        if pn:
                            params.append(pn)
                    cf_params_by_id[cf_raw] = params
                    disp = elem.find("Display")
                    if disp is not None and disp.text:
                        cf_display_by_id[cf_raw] = disp.text.strip()
                    # Body filled in later from CalcsForCustomFunctions; for
                    # now stage with body=None — overwritten below via INSERT
                    # OR REPLACE.
                    buf.cf.append((
                        cf_raw + O, file_id, name,
                        "; ".join(params) if params else None,
                        None,                                  # body — populated later
                        ET.tostring(elem, encoding="unicode") if keep_xml else None,
                    ))
                    counts["custom_functions"] += 1
                elem.clear()

            elif tag == "CustomFunctionCalc" and in_calcs_for_cfs:
                ref = elem.find("CustomFunctionReference")
                rid = ref.get("id") if ref is not None else None
                if rid and rid.isdigit():
                    cf_raw = int(rid)
                    body = _calc_text(elem)
                    name = (ref.get("name") if ref is not None else "") or ""
                    params = cf_params_by_id.get(cf_raw, [])
                    # Re-emit the CF row with the body filled in. Schema is
                    # INSERT OR REPLACE, so the second write wins.
                    buf.cf.append((
                        cf_raw + O, file_id, name,
                        "; ".join(params) if params else None,
                        body,
                        None,
                    ))
                    if body:
                        calc_sites.append(("custom_function", cf_raw + O, None, body, None))
                elem.clear()

            elif tag == "CustomFunctionsCatalog" and in_cf_cat:
                in_cf_cat = False
                elem.clear()

            elif tag == "CalcsForCustomFunctions" and in_calcs_for_cfs:
                in_calcs_for_cfs = False
                elem.clear()

            # ---------------- Layouts ----------------
            elif tag == "Layout" and in_layout_cat:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    lid_raw = int(rid)
                    lid = lid_raw + O
                    name = elem.get("name") or ""
                    width = None
                    try:
                        width = int(elem.get("width") or 0) or None
                    except ValueError:
                        width = None
                    primary_to_id, theme_name = _extract_layout_refs(
                        elem, layout_id=lid, buf=buf, file_id=file_id, offset=O,
                        calc_sites=calc_sites,
                    )
                    buf.layout.append((
                        lid, file_id, name,
                        None,         # folder — FMSaveAsXML doesn't expose layout folders inline
                        None,         # base_table_id — resolved post-pass via TO lookup
                        primary_to_id,
                        theme_name,
                        width,
                        ET.tostring(elem, encoding="unicode"),
                    ))
                    counts["layouts"] += 1
                elem.clear()

            elif tag == "LayoutCatalog" and in_layout_cat:
                in_layout_cat = False
                elem.clear()

            # ---------------- Table occurrences ----------------
            elif tag == "BaseTableReference" and in_to and current_to_bt_raw is None:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    current_to_bt_raw = int(rid)

            elif tag == "TableOccurrence" and in_to:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    to_raw = int(rid)
                    name = elem.get("name") or ""
                    color_el = elem.find("Color")
                    color = None
                    if color_el is not None:
                        try:
                            r = int(round(float(color_el.get("red", "0"))))
                            g = int(round(float(color_el.get("green", "0"))))
                            b = int(round(float(color_el.get("blue", "0"))))
                            color = f"#{r:02X}{g:02X}{b:02X}"
                        except ValueError:
                            color = None
                    bt_id_synth = (current_to_bt_raw + O) if current_to_bt_raw else None
                    buf.to.append((
                        to_raw + O, file_id, name, bt_id_synth,
                        None,    # file_ref_id
                        color,
                        None,    # folder
                    ))
                    counts["tos"] += 1
                in_to = False
                current_to_bt_raw = None
                elem.clear()

            elif tag == "TableOccurrenceCatalog" and in_to_cat:
                in_to_cat = False
                elem.clear()

            # ---------------- Relationships ----------------
            elif tag == "Relationship" and in_rel_cat:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    rel_raw = int(rid)
                    rel_id = rel_raw + O
                    left_t = elem.find("LeftTable")
                    right_t = elem.find("RightTable")
                    left_to_ref = left_t.find("TableOccurrenceReference") if left_t is not None else None
                    right_to_ref = right_t.find("TableOccurrenceReference") if right_t is not None else None
                    left_to_id = None
                    right_to_id = None
                    if left_to_ref is not None and (left_to_ref.get("id") or "").isdigit():
                        left_to_id = int(left_to_ref.get("id")) + O
                    if right_to_ref is not None and (right_to_ref.get("id") or "").isdigit():
                        right_to_id = int(right_to_ref.get("id")) + O
                    allow_create_left = _truthy(left_t.get("cascadeCreate")) if left_t is not None else 0
                    allow_create_right = _truthy(right_t.get("cascadeCreate")) if right_t is not None else 0
                    allow_delete_left = _truthy(left_t.get("cascadeDelete")) if left_t is not None else 0
                    allow_delete_right = _truthy(right_t.get("cascadeDelete")) if right_t is not None else 0
                    buf.rel.append((
                        rel_id, file_id, left_to_id, right_to_id,
                        allow_create_left, allow_create_right,
                        allow_delete_left, allow_delete_right,
                        0, 0,   # sort_left / sort_right not modeled in v1
                    ))
                    counts["relationships"] += 1
                    # Stage predicates — resolution to synthesized field ids
                    # needs the TO→BT mapping, finalized after the parse.
                    for jp in elem.iter("JoinPredicate"):
                        op = jp.get("type") or ""
                        lf = jp.find("LeftField/FieldReference")
                        rf = jp.find("RightField/FieldReference")
                        if lf is None or rf is None:
                            continue
                        lf_id = lf.get("id"); rf_id = rf.get("id")
                        lf_to = lf.find("TableOccurrenceReference")
                        rf_to = rf.find("TableOccurrenceReference")
                        lf_to_name = lf_to.get("name") if lf_to is not None else None
                        rf_to_name = rf_to.get("name") if rf_to is not None else None
                        if (lf_id or "").isdigit() and (rf_id or "").isdigit():
                            rel_predicates_staged.append((
                                rel_id, int(lf_id), lf_to_name, op, int(rf_id), rf_to_name,
                            ))
                            # Mirror DDR's relationship_predicate field_ref edges so
                            # `where-used` and `unused field` work the same way for
                            # fields used in join predicates.
                            if lf_to_name:
                                buf.field_ref_staging.append(
                                    (int(lf_id), "relationship_predicate", rel_id, 0,
                                     lf_to_name, None, file_id)
                                )
                            if rf_to_name:
                                buf.field_ref_staging.append(
                                    (int(rf_id), "relationship_predicate", rel_id, 1,
                                     rf_to_name, None, file_id)
                                )
                elem.clear()

            elif tag == "RelationshipCatalog" and in_rel_cat:
                in_rel_cat = False
                elem.clear()

            # ---------------- Value lists ----------------
            elif tag == "ValueList" and in_vl_cat:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    vl_raw = int(rid)
                    name = elem.get("name") or ""
                    # FMSaveAsXML stores `<Source value="Custom|FromField|External" />`.
                    src_attr = "Custom"
                    src_el = elem.find("Source")
                    if src_el is not None and src_el.get("value"):
                        src_attr = src_el.get("value")
                    buf.vl.append((
                        vl_raw + O, file_id, name, src_attr,
                        None,    # field_id — populated in post-pass from OptionsForValueLists
                        ET.tostring(elem, encoding="unicode"),
                    ))
                    counts["value_lists"] += 1
                elem.clear()

            elif tag == "ValueListCatalog" and in_vl_cat:
                in_vl_cat = False
                elem.clear()

            # ---------------- OptionsForValueLists (FromField source) ----------------
            elif tag == "ValueListReference" and in_options_vl_item and current_options_vl_id is None:
                rid = elem.get("id")
                if rid and rid.isdigit():
                    current_options_vl_id = int(rid)

            elif tag == "ValueList" and in_options_vl and in_options_vl_item:
                if current_options_vl_id is not None:
                    vl_id_synth = current_options_vl_id + O
                    raw_fid = _extract_value_list_options(
                        elem, vl_raw_id=current_options_vl_id, vl_id=vl_id_synth,
                        buf=buf, file_id=file_id,
                    )
                    if raw_fid is not None:
                        primary = elem.find("Field/PrimaryField/FieldReference")
                        to_ref = primary.find("TableOccurrenceReference") if primary is not None else None
                        to_name = to_ref.get("name") if to_ref is not None else None
                        if to_name:
                            vl_primary_field_staged[vl_id_synth] = (raw_fid, to_name)
                in_options_vl_item = False
                current_options_vl_id = None
                elem.clear()

            elif tag == "OptionsForValueLists" and in_options_vl:
                in_options_vl = False
                elem.clear()

            # ---------------- Custom menus → script refs ----------------
            elif tag == "Step" and in_menu and current_menu_id is not None:
                # Each <action><Step .../></action> inside CustomMenuItem fires a script.
                _extract_step_refs(
                    elem,
                    owner_kind="custom_menu",
                    owner_id=current_menu_id,
                    owner_sub=current_menu_item_idx,
                    buf=buf, file_id=file_id, offset=O,
                )
                # Don't clear — parent CustomMenuItem block will.

            elif tag == "CustomMenuItem" and in_menu:
                current_menu_item_idx += 1
                elem.clear()

            elif tag == "CustomMenu" and in_menu:
                in_menu = False
                current_menu_id = None
                current_menu_item_idx = 0
                elem.clear()

            elif tag == "CustomMenuCatalog" and in_menu_cat:
                in_menu_cat = False
                elem.clear()

            # ---------------- Section closers ----------------
            elif tag == "AddAction" and in_struct_add:
                in_struct_add = False
                elem.clear()
        finally:
            pass

    if not quiet:
        print(f"  parsed in {time.time()-t0:.1f}s — "
              f"tables={counts['tables']} fields={counts['fields']} "
              f"scripts={counts['scripts']} steps={counts['steps']} "
              f"cfs={counts['custom_functions']} layouts={counts['layouts']} "
              f"tos={counts['tos']} rels={counts['relationships']} "
              f"vls={counts['value_lists']}", flush=True)

    # ----- Write to DB -----
    fm_file_name = fm_root_attrs.get("File") or src.stem
    fm_version = fm_root_attrs.get("Source") or fm_root_attrs.get("version") or ""

    conn = _init_db(db_path)
    try:
        conn.execute(
            "INSERT INTO file(id,name,path,link,fm_version,sha256,bytes,indexed_at) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (
                file_id, fm_file_name, str(src), None,
                fm_version, sha, len(data),
                time.strftime("%Y-%m-%dT%H:%M:%S"),
            ),
        )
        _flush(conn, buf)

        # Resolve relationship predicates: synthesize field ids using TO→BT.
        to_to_bt_raw: dict[str, int] = {}
        for r in conn.execute(
            "SELECT to_.name, bt.raw_id "
            "FROM table_occurrence to_ "
            "LEFT JOIN base_table bt ON bt.id = to_.base_table_id "
            "WHERE to_.file_id = ?", (file_id,)
        ):
            if r[1] is not None:
                to_to_bt_raw[r[0]] = r[1]

        pred_rows = []
        for rel_id, lf_id, lf_to_name, op, rf_id, rf_to_name in rel_predicates_staged:
            l_bt = to_to_bt_raw.get(lf_to_name or "")
            r_bt = to_to_bt_raw.get(rf_to_name or "")
            if l_bt is not None and r_bt is not None:
                pred_rows.append((
                    rel_id,
                    synth_field_id(file_id, l_bt, lf_id),
                    synth_field_id(file_id, r_bt, rf_id),
                    op,
                ))
        if pred_rows:
            conn.executemany(
                "INSERT INTO join_predicate(relationship_id,left_field_id,right_field_id,operator) "
                "VALUES (?,?,?,?)",
                pred_rows,
            )

        # Resolve all staged field_ref / cf_ref rows into the final ref tables.
        _resolve_staging_and_finalize(conn, [file_id])

        # Phase B: parse every collected calc body and emit ref rows.
        n_calc_field_refs, n_calc_cf_refs = _resolve_calc_edges(
            conn, file_id, calc_sites,
        )
        if not quiet:
            print(
                f"  resolved calc edges: {n_calc_field_refs} field_ref rows, "
                f"{n_calc_cf_refs} custom_function_ref rows from "
                f"{len(calc_sites)} calc sites",
                flush=True,
            )

        # Populate value_list.field_id from each VL's PrimaryField (FromField source).
        vl_field_updates: list[tuple[int, int]] = []
        for vl_id_synth, (raw_fid, to_name) in vl_primary_field_staged.items():
            bt_raw = to_to_bt_raw.get(to_name)
            if bt_raw is None:
                continue
            field_id = synth_field_id(file_id, bt_raw, raw_fid)
            # Only set if the field actually exists (skip broken FK).
            row = conn.execute("SELECT 1 FROM field WHERE id = ?", (field_id,)).fetchone()
            if row is not None:
                vl_field_updates.append((field_id, vl_id_synth))
        if vl_field_updates:
            conn.executemany(
                "UPDATE value_list SET field_id = ? WHERE id = ?",
                vl_field_updates,
            )

        # Resolve layout.base_table_id from each layout's primary TO.
        conn.execute(
            "UPDATE layout SET base_table_id = ("
            "  SELECT to_.base_table_id FROM table_occurrence to_ "
            "  WHERE to_.id = layout.table_occurrence_id"
            ") WHERE table_occurrence_id IS NOT NULL"
        )

        conn.executemany(
            "INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)",
            [
                ("schema_version", SCHEMA_VERSION),
                ("ddr_path", str(src)),
                ("ddr_kind", "savexml"),
                ("ddr_sha256", sha),
                ("source_utf8_bytes", str(len(data))),
                ("indexed_at", time.strftime("%Y-%m-%dT%H:%M:%S")),
                ("fm_version", fm_version),
                ("fm_file_name", fm_file_name),
                ("source", "savexml"),
                # Phase A + B: structured + calc-derived edges resolved. Some
                # references are inherently dynamic (Evaluate, GetField with
                # computed args, dynamic Perform Script By Name) and can't be
                # resolved on either input format — DDR doesn't resolve them
                # either, so this is parity, not regression.
                ("partial", "false"),
                ("savexml_uuid", fm_root_attrs.get("UUID") or ""),
                ("savexml_locale", fm_root_attrs.get("locale") or ""),
                ("savexml_has_ddr_info", fm_root_attrs.get("Has_DDR_INFO") or ""),
                *[(f"counts.{k}", str(v)) for k, v in counts.items()],
            ],
        )
        conn.commit()
        conn.executescript("PRAGMA optimize;")
        conn.execute("VACUUM")
    finally:
        conn.close()

    if not quiet:
        print(f"Index written: {db_path}", flush=True)
    return counts
