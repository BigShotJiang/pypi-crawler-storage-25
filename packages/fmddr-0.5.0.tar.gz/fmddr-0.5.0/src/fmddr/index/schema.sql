-- fmddr SQLite schema. Bumping requires a migration in migrations.py.
-- Schema version is recorded in the `meta` table.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- One row per FileMaker file ingested into this index.
-- For single-file DDRs there is exactly one row with id=1. For a multi-file
-- DDR (FMPReport type="Summary"), one row per linked file. Entity rows in the
-- per-object tables carry `file_id` so cross-file queries can disambiguate;
-- additionally, when more than one file is present, ids of file 2+ are shifted
-- by `(file_id - 1) * 10_000_000_000` to keep INTEGER PRIMARY KEY unique.
-- See `src/fmddr/index/build.py` (FILE_ID_STRIDE, BT_STRIDE, synth_field_id).
CREATE TABLE IF NOT EXISTS file (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    path        TEXT,
    link        TEXT,
    fm_version  TEXT,
    sha256      TEXT,
    bytes       INTEGER,
    indexed_at  TEXT
);

CREATE TABLE IF NOT EXISTS base_table (
    id      INTEGER PRIMARY KEY,         -- file_offset + raw_id
    file_id INTEGER NOT NULL DEFAULT 1 REFERENCES file(id),
    raw_id  INTEGER NOT NULL,            -- the FileMaker BaseTable id (collides across files)
    name    TEXT NOT NULL,
    records INTEGER NOT NULL DEFAULT 0,
    raw_xml TEXT
);
CREATE INDEX IF NOT EXISTS ix_base_table_file ON base_table(file_id);
CREATE INDEX IF NOT EXISTS ix_base_table_name ON base_table(name);

CREATE TABLE IF NOT EXISTS field (
    id              INTEGER PRIMARY KEY,   -- synth_field_id(file, bt_raw, raw)
    file_id         INTEGER NOT NULL DEFAULT 1 REFERENCES file(id),
    raw_id          INTEGER NOT NULL,      -- the FileMaker Field id (resets per BaseTable)
    base_table_id   INTEGER NOT NULL REFERENCES base_table(id),
    name            TEXT NOT NULL,
    data_type       TEXT NOT NULL,
    field_type      TEXT NOT NULL,
    is_global       INTEGER NOT NULL DEFAULT 0,
    is_unstored     INTEGER NOT NULL DEFAULT 0,
    auto_enter_calc TEXT,
    calc_text       TEXT,
    comment         TEXT,
    repetitions     INTEGER NOT NULL DEFAULT 1,
    raw_xml         TEXT
);
CREATE INDEX IF NOT EXISTS ix_field_table_name ON field(base_table_id, name);
CREATE INDEX IF NOT EXISTS ix_field_name       ON field(name);

CREATE TABLE IF NOT EXISTS table_occurrence (
    id            INTEGER PRIMARY KEY,
    file_id       INTEGER NOT NULL DEFAULT 1 REFERENCES file(id),
    name          TEXT NOT NULL,
    base_table_id INTEGER REFERENCES base_table(id),
    file_ref_id   INTEGER,
    color         TEXT,
    folder        TEXT
);
CREATE INDEX IF NOT EXISTS ix_to_name ON table_occurrence(name);
CREATE INDEX IF NOT EXISTS ix_to_base ON table_occurrence(base_table_id);

CREATE TABLE IF NOT EXISTS relationship (
    id                  INTEGER PRIMARY KEY,
    file_id             INTEGER NOT NULL DEFAULT 1 REFERENCES file(id),
    left_to_id          INTEGER NOT NULL REFERENCES table_occurrence(id),
    right_to_id         INTEGER NOT NULL REFERENCES table_occurrence(id),
    allow_create_left   INTEGER, allow_create_right INTEGER,
    allow_delete_left   INTEGER, allow_delete_right INTEGER,
    sort_left           INTEGER, sort_right          INTEGER
);
CREATE INDEX IF NOT EXISTS ix_rel_left  ON relationship(left_to_id);
CREATE INDEX IF NOT EXISTS ix_rel_right ON relationship(right_to_id);

CREATE TABLE IF NOT EXISTS join_predicate (
    relationship_id INTEGER NOT NULL REFERENCES relationship(id),
    left_field_id   INTEGER REFERENCES field(id),
    right_field_id  INTEGER REFERENCES field(id),
    operator        TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS script (
    id              INTEGER PRIMARY KEY,
    file_id         INTEGER NOT NULL DEFAULT 1 REFERENCES file(id),
    name            TEXT NOT NULL,
    folder          TEXT,
    include_in_menu INTEGER NOT NULL DEFAULT 0,
    full_access     INTEGER NOT NULL DEFAULT 0,
    raw_xml         TEXT
);
CREATE INDEX IF NOT EXISTS ix_script_name        ON script(name);
CREATE INDEX IF NOT EXISTS ix_script_folder_name ON script(folder, name);

CREATE TABLE IF NOT EXISTS script_step (
    script_id      INTEGER NOT NULL REFERENCES script(id),
    step_index     INTEGER NOT NULL,
    fm_line        INTEGER,
    step_type_id   INTEGER NOT NULL,
    step_type_name TEXT NOT NULL,
    enabled        INTEGER NOT NULL DEFAULT 1,
    step_text      TEXT,
    var_name       TEXT,
    has_get_script_parameter INTEGER NOT NULL DEFAULT 0,
    has_get_script_result    INTEGER NOT NULL DEFAULT 0,
    has_evaluate             INTEGER NOT NULL DEFAULT 0,
    has_execute_sql          INTEGER NOT NULL DEFAULT 0,
    is_plugin_step           INTEGER NOT NULL DEFAULT 0,
    is_ssl_disabled          INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (script_id, step_index)
);
CREATE INDEX IF NOT EXISTS ix_step_type  ON script_step(step_type_name);
CREATE INDEX IF NOT EXISTS ix_step_flags ON script_step(has_execute_sql, has_evaluate, has_get_script_parameter);

CREATE TABLE IF NOT EXISTS layout (
    id                  INTEGER PRIMARY KEY,
    file_id             INTEGER NOT NULL DEFAULT 1 REFERENCES file(id),
    name                TEXT NOT NULL,
    folder              TEXT,
    base_table_id       INTEGER REFERENCES base_table(id),
    table_occurrence_id INTEGER REFERENCES table_occurrence(id),
    theme               TEXT,
    width               INTEGER,
    raw_xml             TEXT
);
CREATE INDEX IF NOT EXISTS ix_layout_name        ON layout(name);
CREATE INDEX IF NOT EXISTS ix_layout_folder_name ON layout(folder, name);

CREATE TABLE IF NOT EXISTS layout_object (
    layout_id    INTEGER NOT NULL REFERENCES layout(id),
    object_key   INTEGER NOT NULL,
    parent_key   INTEGER,
    object_type  TEXT NOT NULL,
    bounds_top REAL, bounds_left REAL, bounds_bottom REAL, bounds_right REAL,
    name         TEXT,
    payload_json TEXT,
    PRIMARY KEY (layout_id, object_key)
);
CREATE INDEX IF NOT EXISTS ix_lo_layout_type ON layout_object(layout_id, object_type);

CREATE TABLE IF NOT EXISTS value_list (
    id INTEGER PRIMARY KEY,
    file_id INTEGER NOT NULL DEFAULT 1 REFERENCES file(id),
    name TEXT NOT NULL, source TEXT NOT NULL,
    field_id INTEGER REFERENCES field(id), raw_xml TEXT
);
CREATE TABLE IF NOT EXISTS custom_function (
    id INTEGER PRIMARY KEY,
    file_id INTEGER NOT NULL DEFAULT 1 REFERENCES file(id),
    name TEXT NOT NULL,
    parameters TEXT, body TEXT, raw_xml TEXT
);
CREATE TABLE IF NOT EXISTS theme         (id INTEGER PRIMARY KEY, name TEXT NOT NULL, raw_xml TEXT);
CREATE TABLE IF NOT EXISTS custom_menu   (id INTEGER PRIMARY KEY, name TEXT NOT NULL, raw_xml TEXT);
CREATE TABLE IF NOT EXISTS account       (id INTEGER PRIMARY KEY, name TEXT NOT NULL, privilege_set TEXT, auth TEXT, active INTEGER);
CREATE TABLE IF NOT EXISTS privilege_set (id INTEGER PRIMARY KEY, name TEXT NOT NULL, raw_xml TEXT);
CREATE TABLE IF NOT EXISTS file_reference(id INTEGER PRIMARY KEY, name TEXT NOT NULL, path TEXT);

-- Reference graph (populated in build-sequence steps 6+).
CREATE TABLE IF NOT EXISTS field_ref (
    field_id   INTEGER NOT NULL REFERENCES field(id),
    owner_kind TEXT NOT NULL,
    owner_id   INTEGER NOT NULL,
    owner_sub  INTEGER,
    via_to_id  INTEGER REFERENCES table_occurrence(id),
    repetition INTEGER
);
CREATE INDEX IF NOT EXISTS ix_fr_field ON field_ref(field_id);
CREATE INDEX IF NOT EXISTS ix_fr_owner ON field_ref(owner_kind, owner_id);

CREATE TABLE IF NOT EXISTS script_ref (
    caller_kind    TEXT NOT NULL,
    caller_id      INTEGER NOT NULL,
    caller_sub     INTEGER,
    callee_id      INTEGER NOT NULL REFERENCES script(id),
    parameter_calc TEXT
);
CREATE INDEX IF NOT EXISTS ix_sr_callee ON script_ref(callee_id);
CREATE INDEX IF NOT EXISTS ix_sr_caller ON script_ref(caller_kind, caller_id);

CREATE TABLE IF NOT EXISTS layout_ref (
    caller_kind TEXT NOT NULL,
    caller_id   INTEGER NOT NULL,
    caller_sub  INTEGER,
    layout_id   INTEGER NOT NULL REFERENCES layout(id)
);
CREATE INDEX IF NOT EXISTS ix_lr_layout ON layout_ref(layout_id);

CREATE TABLE IF NOT EXISTS table_ref (
    caller_kind         TEXT NOT NULL,
    caller_id           INTEGER NOT NULL,
    caller_sub          INTEGER,
    base_table_id       INTEGER REFERENCES base_table(id),
    table_occurrence_id INTEGER REFERENCES table_occurrence(id)
);
CREATE INDEX IF NOT EXISTS ix_tr_bt ON table_ref(base_table_id);
CREATE INDEX IF NOT EXISTS ix_tr_to ON table_ref(table_occurrence_id);

CREATE TABLE IF NOT EXISTS custom_function_ref (
    caller_kind TEXT NOT NULL,
    caller_id   INTEGER NOT NULL,
    caller_sub  INTEGER,
    function_id INTEGER NOT NULL REFERENCES custom_function(id)
);
CREATE INDEX IF NOT EXISTS ix_cfr_callee ON custom_function_ref(function_id);

CREATE TABLE IF NOT EXISTS value_list_ref (
    caller_kind   TEXT NOT NULL,
    caller_id     INTEGER NOT NULL,
    caller_sub    INTEGER,
    value_list_id INTEGER NOT NULL REFERENCES value_list(id)
);
CREATE INDEX IF NOT EXISTS ix_vlr_callee ON value_list_ref(value_list_id);

-- Build-time staging tables. Populated during streaming parse; resolved into
-- field_ref / custom_function_ref at the end of the build (TOs and CFs aren't
-- known yet when calcs in earlier catalogs are walked). Truncated post-resolve
-- but kept (empty) so the schema is the same shape as a fresh build.
CREATE TABLE IF NOT EXISTS _staging_field_ref (
    field_id     INTEGER NOT NULL,
    owner_kind   TEXT NOT NULL,
    owner_id     INTEGER NOT NULL,
    owner_sub    INTEGER,
    via_to_name  TEXT,
    repetition   INTEGER,
    file_id      INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS _staging_cf_ref (
    caller_kind   TEXT NOT NULL,
    caller_id     INTEGER NOT NULL,
    caller_sub    INTEGER,
    function_name TEXT NOT NULL,
    file_id       INTEGER NOT NULL DEFAULT 1
);

-- Full-text search over object names. Powers `fmddr search "<query>"`.
CREATE VIRTUAL TABLE IF NOT EXISTS name_fts USING fts5(
    kind   UNINDEXED,
    id     UNINDEXED,
    name,
    folder,
    comment
);
