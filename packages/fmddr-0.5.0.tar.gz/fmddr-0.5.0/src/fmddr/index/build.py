"""Streaming-build the SQLite index from a DDR XML.

Implements steps 2–8 of the build sequence:
- Header rows for base_table, field, script, layout
- Full field columns (data type, storage flags, autoenter calc, calc text)
- script_step rows with derived has_* flags
- table_occurrence + relationship + join_predicate from RelationshipGraph
- custom_function and value_list catalog rows
- The reference graph: field_ref, script_ref, layout_ref, custom_function_ref,
  via the uniform chunk walker (parser.refs)

Order of catalogs in a FileMaker DDR is roughly:
    BaseTableCatalog → RelationshipGraph → ValueListCatalog →
    CustomFunctionCatalog → … → ScriptCatalog → LayoutCatalog
Field calcs in BaseTableCatalog are walked before TOs and CFs are known, so
those refs are staged into `_staging_field_ref` / `_staging_cf_ref` and resolved
after the streaming pass via a JOIN on table_occurrence / custom_function.

Multi-file DDRs (FMPReport type="Summary") are ingested via
`build_index_from_summary`, which calls the per-file path repeatedly with
distinct `file_id` values. The first file uses no id offset; subsequent files
shift their entity ids by `(file_id - 1) * FILE_ID_STRIDE` so that single
INTEGER PRIMARY KEYs stay unique across files. Reference resolution stays
scoped to the current file via a per-file TO-name lookup.
"""
from __future__ import annotations

import hashlib
import io
import pathlib
import re
import sqlite3
import time
import xml.etree.ElementTree as ET
from importlib import resources

from ..parser.refs import iter_cf_refs, iter_field_refs
from ..parser.stream import load_utf8

SCHEMA_VERSION = "2"
INSERT_BATCH = 5000

# Per-file id offset. FileMaker IDs comfortably fit in 7 digits; 1e10 leaves
# room for the per-base-table field synthesis (BT_STRIDE * max_bt_raw) and
# stays well under SQLite's INTEGER cap.
FILE_ID_STRIDE = 10_000_000_000

# Field IDs in FileMaker reset per base table — `<Field id="1">` exists in
# every BaseTable. To give each field a globally unique INTEGER PRIMARY KEY,
# we synthesize: file_offset + (bt_raw_id * BT_STRIDE) + raw_field_id.
# 1e5 supports up to 99,999 fields per base table — a hard cap FileMaker
# itself doesn't allow you to hit.
BT_STRIDE = 100_000


def synth_field_id(file_id: int, bt_raw_id: int, raw_field_id: int) -> int:
    """Stable, globally unique synthetic field id."""
    return file_id_offset(file_id) + bt_raw_id * BT_STRIDE + raw_field_id

_RE_GET_SCRIPT_PARAMETER = re.compile(r"\bGet\s*\(\s*ScriptParameter\s*\)", re.IGNORECASE)
_RE_GET_SCRIPT_RESULT    = re.compile(r"\bGet\s*\(\s*ScriptResult\s*\)", re.IGNORECASE)
_RE_EVALUATE             = re.compile(r"\bEvaluate\s*\(", re.IGNORECASE)
_RE_EXECUTE_SQL          = re.compile(r"\bExecuteSQL\s*\(", re.IGNORECASE)


def _load_schema_sql() -> str:
    return resources.files("fmddr.index").joinpath("schema.sql").read_text()


def _connect(db_path: pathlib.Path) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.executescript("PRAGMA journal_mode=MEMORY; PRAGMA synchronous=OFF; PRAGMA temp_store=MEMORY;")
    return conn


def _truthy(v: str | None) -> int:
    return 1 if (v or "").strip().lower() in ("true", "1", "yes") else 0


def _all_calc_text(elem: ET.Element) -> str:
    parts: list[str] = []
    for c in elem.iter("Calculation"):
        if c.text:
            parts.append(c.text)
    return "\n".join(parts)


def file_id_offset(file_id: int) -> int:
    """Entity-id offset for a given file_id. file_id=1 → 0 (no shift)."""
    return (file_id - 1) * FILE_ID_STRIDE


# ----------------------------------------------------------------------
# Buffered writer — keeps memory bounded via periodic flush.
# ----------------------------------------------------------------------

class _Buffers:
    __slots__ = (
        "base_table", "field", "script", "step", "layout",
        "to", "rel", "predicate", "cf", "vl",
        "field_ref_staging", "cf_ref_staging",
        "script_ref", "layout_ref", "layout_object",
        "value_list_ref",
    )

    def __init__(self) -> None:
        self.base_table: list[tuple] = []
        self.field: list[tuple] = []
        self.script: list[tuple] = []
        self.step: list[tuple] = []
        self.layout: list[tuple] = []
        self.to: list[tuple] = []
        self.rel: list[tuple] = []
        self.predicate: list[tuple] = []
        self.cf: list[tuple] = []
        self.vl: list[tuple] = []
        self.field_ref_staging: list[tuple] = []
        self.cf_ref_staging: list[tuple] = []
        self.script_ref: list[tuple] = []
        self.layout_ref: list[tuple] = []
        self.layout_object: list[tuple] = []
        self.value_list_ref: list[tuple] = []

    def total(self) -> int:
        return (
            len(self.field) + len(self.step) + len(self.layout)
            + len(self.field_ref_staging) + len(self.cf_ref_staging)
            + len(self.script_ref) + len(self.layout_ref)
            + len(self.layout_object) + len(self.value_list_ref)
        )


_INSERTS: dict[str, str] = {
    "base_table": "INSERT OR REPLACE INTO base_table(id,file_id,raw_id,name,records,raw_xml) VALUES (?,?,?,?,?,?)",
    "field": (
        "INSERT OR REPLACE INTO field"
        "(id,file_id,raw_id,base_table_id,name,data_type,field_type,is_global,is_unstored,"
        "auto_enter_calc,calc_text,comment,repetitions,raw_xml) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    ),
    "script": (
        "INSERT OR REPLACE INTO script(id,file_id,name,folder,include_in_menu,full_access,raw_xml) "
        "VALUES (?,?,?,?,?,?,?)"
    ),
    "step": (
        "INSERT OR REPLACE INTO script_step"
        "(script_id,step_index,fm_line,step_type_id,step_type_name,enabled,"
        "step_text,var_name,has_get_script_parameter,has_get_script_result,"
        "has_evaluate,has_execute_sql,is_plugin_step,is_ssl_disabled) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    ),
    "layout": (
        "INSERT OR REPLACE INTO layout"
        "(id,file_id,name,folder,base_table_id,table_occurrence_id,theme,width,raw_xml) "
        "VALUES (?,?,?,?,?,?,?,?,?)"
    ),
    "to": (
        "INSERT OR REPLACE INTO table_occurrence(id,file_id,name,base_table_id,file_ref_id,color,folder) "
        "VALUES (?,?,?,?,?,?,?)"
    ),
    "rel": (
        "INSERT OR REPLACE INTO relationship(id,file_id,left_to_id,right_to_id,"
        "allow_create_left,allow_create_right,allow_delete_left,allow_delete_right,"
        "sort_left,sort_right) VALUES (?,?,?,?,?,?,?,?,?,?)"
    ),
    "predicate": (
        "INSERT INTO join_predicate(relationship_id,left_field_id,right_field_id,operator) "
        "VALUES (?,?,?,?)"
    ),
    "cf": (
        "INSERT OR REPLACE INTO custom_function(id,file_id,name,parameters,body,raw_xml) "
        "VALUES (?,?,?,?,?,?)"
    ),
    "vl": (
        "INSERT OR REPLACE INTO value_list(id,file_id,name,source,field_id,raw_xml) "
        "VALUES (?,?,?,?,?,?)"
    ),
    "field_ref_staging": (
        "INSERT INTO _staging_field_ref"
        "(field_id,owner_kind,owner_id,owner_sub,via_to_name,repetition,file_id) "
        "VALUES (?,?,?,?,?,?,?)"
    ),
    "cf_ref_staging": (
        "INSERT INTO _staging_cf_ref(caller_kind,caller_id,caller_sub,function_name,file_id) "
        "VALUES (?,?,?,?,?)"
    ),
    "script_ref": (
        "INSERT INTO script_ref(caller_kind,caller_id,caller_sub,callee_id,parameter_calc) "
        "VALUES (?,?,?,?,?)"
    ),
    "layout_ref": (
        "INSERT INTO layout_ref(caller_kind,caller_id,caller_sub,layout_id) "
        "VALUES (?,?,?,?)"
    ),
    "layout_object": (
        "INSERT OR REPLACE INTO layout_object"
        "(layout_id,object_key,parent_key,object_type,bounds_top,bounds_left,"
        "bounds_bottom,bounds_right,name,payload_json) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)"
    ),
    "value_list_ref": (
        "INSERT INTO value_list_ref(caller_kind,caller_id,caller_sub,value_list_id) "
        "VALUES (?,?,?,?)"
    ),
}


def _flush(conn: sqlite3.Connection, buf: _Buffers) -> None:
    for attr, sql in _INSERTS.items():
        rows = getattr(buf, attr)
        if rows:
            conn.executemany(sql, rows)
            rows.clear()


# ----------------------------------------------------------------------
# Streaming ingest of one File element
# ----------------------------------------------------------------------

def _ingest_one_file(
    data: bytes,
    *,
    conn: sqlite3.Connection,
    file_id: int,
    keep_xml: bool,
    counts: dict,
) -> dict[str, str]:
    """Stream-parse one DDR XML and write its rows. Returns FMPReport attrs."""
    O = file_id_offset(file_id)

    def shift(x):
        """Apply id offset to a non-zero positive int (None passthrough)."""
        if x is None:
            return None
        return x + O

    stream = io.BytesIO(data)
    parser = ET.iterparse(stream, events=("start", "end"))

    tag_stack: list[str] = []
    folder_stack: list[str] = []
    in_script_cat = in_layout_cat = in_basetable_cat = False
    in_relgraph = in_cfcat = in_vlcat = False

    fmp_report_attrs: dict[str, str] = {}
    current_table_id: int | None = None        # synthesized BT id
    current_table_raw_id: int | None = None    # raw FM BaseTable id
    current_field_id: int | None = None

    buf = _Buffers()
    # name → (to_id, base_table_raw_id_or_None). Built lazily once relationships
    # or value-lists need to resolve `<Field table="..." />` references.
    # bt_raw is None for TOs that point at an external data source — we still
    # need to know the TO exists so relationships against it parse, but we
    # can't synthesize local field ids for it.
    to_by_name: dict[str, tuple[int, int | None]] | None = None

    def _ensure_to_lookup() -> dict[str, tuple[int, int | None]]:
        nonlocal to_by_name
        if to_by_name is None:
            if buf.to:
                _flush(conn, buf)
            to_by_name = {}
            for to_id, name, bt_id in conn.execute(
                "SELECT to_.id, to_.name, bt.raw_id "
                "FROM table_occurrence to_ "
                "LEFT JOIN base_table bt ON bt.id = to_.base_table_id "
                "WHERE to_.file_id = ?", (file_id,)
            ):
                to_by_name[name] = (to_id, bt_id)
        return to_by_name

    for event, elem in parser:
        tag = elem.tag

        if event == "start":
            tag_stack.append(tag)
            if tag == "FMPReport" and not fmp_report_attrs:
                fmp_report_attrs = dict(elem.attrib)
            elif tag == "ScriptCatalog":
                in_script_cat = True
            elif tag == "LayoutCatalog":
                in_layout_cat = True
            elif tag == "BaseTableCatalog":
                in_basetable_cat = True
            elif tag == "RelationshipGraph":
                in_relgraph = True
            elif tag == "CustomFunctionCatalog":
                in_cfcat = True
            elif tag == "ValueListCatalog":
                in_vlcat = True
            elif tag == "BaseTable" and in_basetable_cat:
                current_table_raw_id = int(elem.get("id", "0"))
                current_table_id = shift(current_table_raw_id)
            elif tag == "Field" and in_basetable_cat and current_table_raw_id is not None:
                fid_raw = elem.get("id")
                current_field_id = (
                    synth_field_id(file_id, current_table_raw_id, int(fid_raw))
                    if fid_raw and fid_raw.isdigit() else None
                )
            elif tag == "Group":
                if in_script_cat or in_layout_cat:
                    folder_stack.append(elem.get("name", "unnamed"))
            continue

        # event == "end"
        parent = tag_stack[-2] if len(tag_stack) >= 2 else None

        if tag == "Field" and current_table_id is not None and parent == "FieldCatalog":
            row = _extract_field(elem, current_table_id, current_table_raw_id,
                                 file_id, O, keep_xml)
            buf.field.append(row)
            fid = row[0]

            if row[6] == "Calculated":
                for c in elem.findall("Calculation"):
                    _stage_chunks_in(c, owner_kind="field_calc", owner_id=fid, owner_sub=None,
                                     buf=buf, file_id=file_id, offset=O)
                for dc in elem.findall("DisplayCalculation"):
                    _stage_chunks_in(dc, owner_kind="field_calc", owner_id=fid, owner_sub=None,
                                     buf=buf, file_id=file_id, offset=O)

            ae = elem.find("AutoEnter")
            if ae is not None:
                _stage_chunks_in(ae, owner_kind="field_autoenter", owner_id=fid, owner_sub=None,
                                 buf=buf, file_id=file_id, offset=O)

            val = elem.find("Validation")
            if val is not None:
                _stage_chunks_in(val, owner_kind="field_validation", owner_id=fid, owner_sub=None,
                                 buf=buf, file_id=file_id, offset=O)

            counts["fields"] += 1
            current_field_id = None
            elem.clear()

        elif tag == "BaseTable" and parent == "BaseTableCatalog" and in_basetable_cat:
            bt_raw = int(elem.get("id", "0"))
            buf.base_table.append((
                shift(bt_raw),
                file_id,
                bt_raw,
                elem.get("name", ""),
                int(elem.get("records", "0")),
                ET.tostring(elem, encoding="unicode") if keep_xml else None,
            ))
            counts["tables"] += 1
            current_table_id = None
            current_table_raw_id = None
            elem.clear()

        elif tag == "Script" and in_script_cat and parent in ("ScriptCatalog", "Group"):
            sid = shift(int(elem.get("id", "0")))
            buf.script.append((
                sid,
                file_id,
                elem.get("name", ""),
                "/".join(folder_stack) or None,
                _truthy(elem.get("includeInMenu")),
                _truthy(elem.get("runFullAccess")),
                ET.tostring(elem, encoding="unicode") if keep_xml else None,
            ))
            counts["scripts"] += 1
            counts["steps"] += _extract_steps(elem, sid, buf, file_id=file_id, offset=O)
            elem.clear()

        elif tag == "Layout" and in_layout_cat and parent in ("LayoutCatalog", "Group"):
            lid = shift(int(elem.get("id", "0")))
            buf.layout.append((
                lid,
                file_id,
                elem.get("name", ""),
                "/".join(folder_stack) or None,
                None, None, None, None,
                ET.tostring(elem, encoding="unicode") if keep_xml else None,
            ))
            counts["layouts"] += 1

            for obj in elem.iter("Object"):
                obj_key = obj.get("key")
                if not obj_key or not obj_key.isdigit():
                    continue
                okey = int(obj_key)
                obj_type = obj.get("type", "")
                bounds = obj.find("Bounds")
                bt = bl = bb = br = None
                if bounds is not None:
                    try:
                        bt = float(bounds.get("top", "") or 0)
                        bl = float(bounds.get("left", "") or 0)
                        bb = float(bounds.get("bottom", "") or 0)
                        br = float(bounds.get("right", "") or 0)
                    except ValueError:
                        bt = bl = bb = br = None
                obj_name = obj.get("name") or None
                buf.layout_object.append((
                    lid, okey, None, obj_type, bt, bl, bb, br, obj_name, None,
                ))
                for f in obj.iterfind(".//DDRInfo/Field"):
                    fid_raw = f.get("id")
                    if fid_raw and fid_raw.isdigit() and int(fid_raw) > 0:
                        rep_raw = f.get("repetition")
                        try:
                            rep = int(rep_raw) if rep_raw else None
                        except ValueError:
                            rep = None
                        buf.field_ref_staging.append((
                            int(fid_raw), "layout_object", lid, okey,
                            f.get("table") or None, rep, file_id,
                        ))

            _stage_chunks_in(elem, owner_kind="layout_object", owner_id=lid, owner_sub=None,
                             buf=buf, file_id=file_id, offset=O)

            for triggers in elem.iter("ScriptTriggers"):
                for st in triggers.findall("Trigger"):
                    event_name = st.get("event") or ""
                    for s_el in st.findall("Script"):
                        sid_raw = s_el.get("id")
                        if sid_raw and sid_raw.isdigit():
                            buf.script_ref.append((
                                "layout_trigger", lid, hash(event_name) & 0xFFFF,
                                shift(int(sid_raw)), None,
                            ))

            button_idx = 0
            for bo in elem.iter("ButtonObj"):
                for step in bo.iter("Step"):
                    for s_el in step.findall("Script"):
                        sid_raw = s_el.get("id")
                        if sid_raw and sid_raw.isdigit():
                            buf.script_ref.append((
                                "layout_button", lid, button_idx,
                                shift(int(sid_raw)), None,
                            ))
                            button_idx += 1
            elem.clear()

        elif tag == "Table" and in_relgraph:
            row = _extract_to(elem, file_id, O)
            if row is not None:
                buf.to.append(row)
                counts["tos"] += 1
            elem.clear()

        elif tag == "Relationship" and in_relgraph:
            _extract_relationship(elem, buf, _ensure_to_lookup(), file_id=file_id, offset=O)
            counts["relationships"] += 1
            elem.clear()

        elif tag == "CustomFunction" and in_cfcat:
            _extract_cf(elem, buf, keep_xml, file_id=file_id, offset=O)
            counts["custom_functions"] += 1
            elem.clear()

        elif tag == "ValueList" and in_vlcat:
            _extract_vl(elem, buf, keep_xml, file_id=file_id, offset=O,
                        to_lookup=_ensure_to_lookup())
            counts["value_lists"] += 1
            elem.clear()

        elif tag in ("BaseTableCatalog", "LayoutCatalog", "ScriptCatalog",
                     "RelationshipGraph", "CustomFunctionCatalog", "ValueListCatalog") \
                and parent == "File":
            if tag == "BaseTableCatalog":
                in_basetable_cat = False
            elif tag == "LayoutCatalog":
                in_layout_cat = False
            elif tag == "ScriptCatalog":
                in_script_cat = False
            elif tag == "RelationshipGraph":
                in_relgraph = False
            elif tag == "CustomFunctionCatalog":
                in_cfcat = False
            elif tag == "ValueListCatalog":
                in_vlcat = False
            elem.clear()

        elif tag == "Group" and (in_script_cat or in_layout_cat):
            if folder_stack:
                folder_stack.pop()

        tag_stack.pop()

        if buf.total() >= INSERT_BATCH:
            _flush(conn, buf)

    _flush(conn, buf)
    return fmp_report_attrs


# ----------------------------------------------------------------------
# Element extractors
# ----------------------------------------------------------------------

def _extract_field(elem: ET.Element, base_table_id: int, base_table_raw_id: int,
                   file_id: int, offset: int, keep_xml: bool) -> tuple:
    raw_fid = int(elem.get("id", "0"))
    fid = synth_field_id(file_id, base_table_raw_id, raw_fid)
    name = elem.get("name", "")
    data_type = elem.get("dataType", "")
    field_type = elem.get("fieldType", "")
    storage = elem.find("Storage")
    is_global = _truthy(storage.get("global")) if storage is not None else 0
    is_unstored = 0
    if field_type == "Calculated" and storage is not None:
        is_unstored = 1 if storage.get("storeCalculationResults") == "False" else 0
    repetitions = int((storage.get("maxRepetition") if storage is not None else "1") or "1")
    comment_el = elem.find("Comment")
    comment = (comment_el.text or "").strip() if comment_el is not None else None
    if comment == "":
        comment = None

    auto_enter_calc = None
    ae = elem.find("AutoEnter")
    if ae is not None:
        ae_calc = ae.find("Calculation")
        if ae_calc is not None and ae_calc.text:
            auto_enter_calc = ae_calc.text

    calc_text = None
    if field_type == "Calculated":
        for c in elem.findall("Calculation"):
            if c.text:
                calc_text = c.text
                break

    raw_xml = ET.tostring(elem, encoding="unicode") if keep_xml else None
    return (
        fid, file_id, raw_fid, base_table_id, name, data_type, field_type,
        is_global, is_unstored, auto_enter_calc, calc_text, comment,
        repetitions, raw_xml,
    )


def _stage_chunks_in(
    container: ET.Element,
    *,
    owner_kind: str,
    owner_id: int,
    owner_sub: int | None,
    buf: _Buffers,
    file_id: int,
    offset: int,
) -> None:
    """Walk every Chunk inside `container` and stage field_ref / cf_ref rows.

    field_id stays raw at staging time — it gets synthesized at resolution
    time via TO→BaseTable lookup, since `<Field table="..." />` only carries
    a TO name, and the TO catalog isn't fully populated until later.
    """
    for raw_fid, table, _name in iter_field_refs(container):
        buf.field_ref_staging.append(
            (raw_fid, owner_kind, owner_id, owner_sub, table, None, file_id)
        )
    for cf_name in iter_cf_refs(container):
        buf.cf_ref_staging.append((owner_kind, owner_id, owner_sub, cf_name, file_id))


def _extract_steps(script_elem: ET.Element, script_id: int, buf: _Buffers,
                   *, file_id: int, offset: int) -> int:
    step_list = script_elem.find("StepList")
    if step_list is None:
        return 0
    n = 0
    for idx, step in enumerate(step_list.findall("Step")):
        step_type_id = int(step.get("id", "0"))
        step_type_name = step.get("name", "")
        enabled = _truthy(step.get("enable", "True"))
        step_text_el = step.find("StepText")
        step_text = step_text_el.text if step_text_el is not None else None
        name_el = step.find("Name")
        var_name = name_el.text if name_el is not None else None

        calc_text = _all_calc_text(step)
        buf.step.append((
            script_id, idx, idx + 1,
            step_type_id, step_type_name, enabled,
            step_text, var_name,
            1 if _RE_GET_SCRIPT_PARAMETER.search(calc_text) else 0,
            1 if _RE_GET_SCRIPT_RESULT.search(calc_text)    else 0,
            1 if _RE_EVALUATE.search(calc_text)             else 0,
            1 if _RE_EXECUTE_SQL.search(calc_text)          else 0,
            0, 0,
        ))

        _stage_chunks_in(step, owner_kind="script_step", owner_id=script_id,
                         owner_sub=idx, buf=buf, file_id=file_id, offset=offset)

        for s in step.findall("Script"):
            sid = s.get("id")
            if sid:
                try:
                    buf.script_ref.append((
                        "script_step", script_id, idx, int(sid) + offset,
                        (step.findtext("Calculation") or None),
                    ))
                except ValueError:
                    pass

        for ly in step.findall("Layout"):
            lid = ly.get("id")
            if lid:
                try:
                    buf.layout_ref.append(("script_step", script_id, idx, int(lid) + offset))
                except ValueError:
                    pass

        for f in step.findall("Field"):
            fid = f.get("id")
            if fid:
                try:
                    buf.field_ref_staging.append((
                        int(fid), "script_step", script_id, idx,
                        f.get("table"), None, file_id,
                    ))
                except ValueError:
                    pass

        n += 1
    return n


def _extract_to(elem: ET.Element, file_id: int, offset: int) -> tuple | None:
    tid = elem.get("id")
    if not tid:
        return None
    try:
        toid = int(tid) + offset
    except ValueError:
        return None
    bt_id = elem.get("baseTableId")
    try:
        bt_id_int = (int(bt_id) + offset) if bt_id else None
    except ValueError:
        bt_id_int = None
    return (
        toid, file_id, elem.get("name", ""), bt_id_int,
        None,  # file_ref_id
        elem.get("color"),
        None,  # folder
    )


def _extract_relationship(elem: ET.Element, buf: _Buffers,
                          to_by_name: dict[str, tuple[int, int | None]],
                          *, file_id: int, offset: int) -> None:
    rid = elem.get("id")
    if not rid:
        return
    try:
        rel_id = int(rid) + offset
    except ValueError:
        return
    left_el = elem.find("LeftTable")
    right_el = elem.find("RightTable")
    if left_el is None or right_el is None:
        return
    left = to_by_name.get(left_el.get("name", ""))
    right = to_by_name.get(right_el.get("name", ""))
    if left is None or right is None:
        return
    left_to_id, _left_bt_raw = left
    right_to_id, _right_bt_raw = right
    buf.rel.append((
        rel_id, file_id, left_to_id, right_to_id,
        _truthy(left_el.get("cascadeCreate")), _truthy(right_el.get("cascadeCreate")),
        _truthy(left_el.get("cascadeDelete")), _truthy(right_el.get("cascadeDelete")),
        None, None,
    ))
    pred_list = elem.find("JoinPredicateList")
    if pred_list is None:
        return
    for jp in pred_list.findall("JoinPredicate"):
        op = jp.get("type", "Equal")
        lf = jp.find("LeftField/Field")
        rf = jp.find("RightField/Field")

        def _resolve(side_el, side_idx: int) -> int | None:
            """Return synthesized field id, or None when the TO points at an
            external data source (no local BT to synthesize against). The
            relationship + predicate row are still recorded — only the
            field_id FK is left NULL."""
            if side_el is None:
                return None
            raw = side_el.get("id")
            tname = side_el.get("table")
            if not raw or not tname:
                return None
            try:
                raw_int = int(raw)
            except ValueError:
                return None
            entry = to_by_name.get(tname)
            if entry is None:
                return None
            _to_id, bt_raw = entry
            if bt_raw is None:
                return None
            synth = synth_field_id(file_id, bt_raw, raw_int)
            buf.field_ref_staging.append((
                raw_int, "relationship_predicate", rel_id, side_idx,
                tname, None, file_id,
            ))
            return synth

        lfid = _resolve(lf, 0)
        rfid = _resolve(rf, 1)
        buf.predicate.append((rel_id, lfid, rfid, op))


def _extract_cf(elem: ET.Element, buf: _Buffers, keep_xml: bool,
                *, file_id: int, offset: int) -> None:
    cid = elem.get("id")
    if not cid:
        return
    try:
        cf_id = int(cid) + offset
    except ValueError:
        return
    name = elem.get("name", "")
    params = elem.get("parameters")
    body_el = elem.find("Calculation")
    body = body_el.text if body_el is not None else None
    raw_xml = ET.tostring(elem, encoding="unicode") if keep_xml else None
    buf.cf.append((cf_id, file_id, name, params, body, raw_xml))
    _stage_chunks_in(elem, owner_kind="custom_function", owner_id=cf_id,
                     owner_sub=None, buf=buf, file_id=file_id, offset=offset)


def _extract_vl(elem: ET.Element, buf: _Buffers, keep_xml: bool,
                *, file_id: int, offset: int,
                to_lookup: dict[str, tuple[int, int]]) -> None:
    vid = elem.get("id")
    if not vid:
        return
    try:
        vl_id = int(vid) + offset
    except ValueError:
        return
    name = elem.get("name", "")
    src = "Custom"
    field_id = None
    use_values = elem.find("UseValues")
    if use_values is not None:
        src = "FromField"
        f = use_values.find("Field")
        if f is not None and f.get("id"):
            try:
                raw_field = int(f.get("id"))
                tname = f.get("table") or ""
                entry = to_lookup.get(tname)
                if entry is not None:
                    _to_id, bt_raw = entry
                    field_id = synth_field_id(file_id, bt_raw, raw_field)
                buf.field_ref_staging.append((
                    raw_field, "value_list", vl_id, None, tname or None, None, file_id,
                ))
            except ValueError:
                pass
    raw_xml = ET.tostring(elem, encoding="unicode") if keep_xml else None
    buf.vl.append((vl_id, file_id, name, src, field_id, raw_xml))


# ----------------------------------------------------------------------
# Per-file build orchestration
# ----------------------------------------------------------------------

def _init_db(db_path: pathlib.Path) -> sqlite3.Connection:
    if db_path.exists():
        db_path.unlink()
    conn = _connect(db_path)
    conn.executescript(_load_schema_sql())
    conn.execute("PRAGMA foreign_keys = OFF")
    return conn


def _resolve_staging_and_finalize(conn: sqlite3.Connection, file_ids: list[int]) -> None:
    """Resolve staging tables → field_ref / custom_function_ref, scoped per-file.

    TO-name and CF-name lookups must stay within the same file_id, since the
    same name (e.g. base table "Customer") may exist in multiple ingested
    files with different ids.
    """
    conn.execute("CREATE INDEX IF NOT EXISTS ix_to_name_resolve ON table_occurrence(name, file_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_cf_name_resolve ON custom_function(name, file_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_sfr_file ON _staging_field_ref(file_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS ix_scr_file ON _staging_cf_ref(file_id)")

    # Resolve raw field_id → synthesized field.id by joining the staged
    # via_to_name through table_occurrence to base_table (whose raw_id is the
    # multiplier in synth_field_id). Any row whose synthesized id has no
    # matching field is dropped (broken FM reference) — `orphans` will surface it.
    conn.execute(
        f"""
        INSERT INTO field_ref(field_id,owner_kind,owner_id,owner_sub,via_to_id,repetition)
        SELECT
          (s.file_id - 1) * {FILE_ID_STRIDE}
            + bt.raw_id * {BT_STRIDE}
            + s.field_id                                              AS synth_field_id,
          s.owner_kind, s.owner_id, s.owner_sub,
          to_.id, s.repetition
        FROM _staging_field_ref s
        LEFT JOIN table_occurrence to_
               ON to_.name = s.via_to_name AND to_.file_id = s.file_id
        LEFT JOIN base_table bt
               ON bt.id = to_.base_table_id
        WHERE bt.raw_id IS NOT NULL
          AND EXISTS (
              SELECT 1 FROM field f
              WHERE f.id = (s.file_id - 1) * {FILE_ID_STRIDE}
                          + bt.raw_id * {BT_STRIDE}
                          + s.field_id
          )
        """
    )
    conn.execute(
        "INSERT INTO custom_function_ref(caller_kind,caller_id,caller_sub,function_id) "
        "SELECT s.caller_kind, s.caller_id, s.caller_sub, cf.id "
        "FROM _staging_cf_ref s "
        "JOIN custom_function cf ON cf.name = s.function_name AND cf.file_id = s.file_id"
    )
    conn.execute("DELETE FROM _staging_field_ref")
    conn.execute("DELETE FROM _staging_cf_ref")

    # Repopulate name_fts from scratch.
    conn.execute("DELETE FROM name_fts")
    conn.executescript(
        """
        INSERT INTO name_fts(kind,id,name,folder,comment)
            SELECT 'base_table', id, name, NULL, NULL FROM base_table;
        INSERT INTO name_fts(kind,id,name,folder,comment)
            SELECT 'field', f.id, f.name, bt.name, f.comment
            FROM field f JOIN base_table bt ON bt.id = f.base_table_id;
        INSERT INTO name_fts(kind,id,name,folder,comment)
            SELECT 'script', id, name, folder, NULL FROM script;
        INSERT INTO name_fts(kind,id,name,folder,comment)
            SELECT 'layout', id, name, folder, NULL FROM layout;
        INSERT INTO name_fts(kind,id,name,folder,comment)
            SELECT 'custom_function', id, name, NULL, NULL FROM custom_function;
        INSERT INTO name_fts(kind,id,name,folder,comment)
            SELECT 'value_list', id, name, NULL, NULL FROM value_list;
        INSERT INTO name_fts(kind,id,name,folder,comment)
            SELECT 'table_occurrence', id, name, NULL, NULL FROM table_occurrence;
        """
    )


def _ingest_file_into_db(
    src: pathlib.Path,
    *,
    conn: sqlite3.Connection,
    file_id: int,
    keep_xml: bool,
    quiet: bool,
    file_link: str | None = None,
) -> tuple[dict, dict[str, str], int]:
    """Stream-ingest one DDR file into an open connection. Returns
    (counts, fmp_report_attrs, source_utf8_bytes). Caller is responsible
    for committing and resolving staging tables."""
    if not quiet:
        print(f"Reading {src.name} ({src.stat().st_size/1e6:.1f} MB)...", flush=True)
    t0 = time.time()
    data = load_utf8(src)
    sha = hashlib.sha256(data).hexdigest()
    if not quiet:
        print(f"  decoded to {len(data)/1e6:.1f} MB UTF-8 in {time.time()-t0:.1f}s", flush=True)

    # Find File element name + path attrs without reparsing the whole stream:
    # iterparse below will surface them via fmp_report_attrs and File start.
    counts = {"tables": 0, "fields": 0, "scripts": 0, "steps": 0, "layouts": 0,
              "tos": 0, "relationships": 0, "custom_functions": 0, "value_lists": 0}
    file_name = ""
    file_path = ""

    # Peek at the File element to grab its attrs (one shallow pre-pass).
    peek_stream = io.BytesIO(data)
    peek_parser = ET.iterparse(peek_stream, events=("start",))
    for _ev, el in peek_parser:
        if el.tag == "File":
            file_name = el.get("name", "")
            file_path = el.get("path", "") or ""
            break
        if el.tag == "FMPReport":
            continue
        # Bail out early — we only care about FMPReport > File.
        if el.tag not in ("FMPReport", "File"):
            break

    t0 = time.time()
    fmp_report_attrs = _ingest_one_file(
        data, conn=conn, file_id=file_id, keep_xml=keep_xml, counts=counts,
    )
    if not quiet:
        print(f"  indexed in {time.time()-t0:.1f}s", flush=True)

    # Record file row. The link column stores the cross-file pointer (Summary).
    conn.execute(
        "INSERT OR REPLACE INTO file(id,name,path,link,fm_version,sha256,bytes,indexed_at) "
        "VALUES (?,?,?,?,?,?,?,?)",
        (
            file_id,
            file_name or src.name,
            file_path or str(src),
            file_link,
            fmp_report_attrs.get("version") or None,
            sha,
            len(data),
            time.strftime("%Y-%m-%dT%H:%M:%S"),
        ),
    )
    return counts, fmp_report_attrs, len(data)


# ----------------------------------------------------------------------
# Public entry points
# ----------------------------------------------------------------------

def build_index(
    src: pathlib.Path,
    db_path: pathlib.Path,
    *,
    keep_xml: bool = False,
    quiet: bool = False,
) -> dict:
    """Build an index from a single DDR XML (FMPReport type='Report')."""
    conn = _init_db(db_path)
    counts, fmp_report_attrs, n_bytes = _ingest_file_into_db(
        src, conn=conn, file_id=1, keep_xml=keep_xml, quiet=quiet,
    )

    _resolve_staging_and_finalize(conn, [1])

    sha_row = conn.execute("SELECT sha256, name FROM file WHERE id = 1").fetchone()
    conn.executemany(
        "INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)",
        [
            ("schema_version", SCHEMA_VERSION),
            ("ddr_path", str(src)),
            ("ddr_kind", "report"),
            ("ddr_sha256", sha_row[0] if sha_row else ""),
            ("source_utf8_bytes", str(n_bytes)),
            ("indexed_at", time.strftime("%Y-%m-%dT%H:%M:%S")),
            ("fm_version", fmp_report_attrs.get("version", "")),
            ("fm_file_name", sha_row[1] if sha_row else ""),
            ("source", "ddr"),
            *[(f"counts.{k}", str(v)) for k, v in counts.items()],
        ],
    )
    conn.commit()
    conn.executescript("PRAGMA optimize;")
    conn.execute("VACUUM")
    conn.close()
    return counts


def build_index_from_summary(
    summary_src: pathlib.Path,
    db_path: pathlib.Path,
    *,
    keep_xml: bool = False,
    quiet: bool = False,
) -> dict:
    """Build an index from a Summary.xml that links to multiple DDR files.

    All linked files are ingested into the same database. Each file gets a
    distinct `file_id`; entity ids of file 2+ are shifted to keep the global
    INTEGER PRIMARY KEY space unique.
    """
    summary_data = load_utf8(summary_src)
    root = ET.fromstring(summary_data)
    if root.tag != "FMPReport":
        raise ValueError(f"{summary_src} is not an FMPReport (got <{root.tag}>)")
    if (root.get("type") or "").lower() != "summary":
        raise ValueError(
            f"{summary_src} is FMPReport type={root.get('type')!r}, expected 'Summary'"
        )

    file_elems = root.findall("File")
    if not file_elems:
        raise ValueError(f"{summary_src} has no <File> entries")

    conn = _init_db(db_path)
    aggregate = {"tables": 0, "fields": 0, "scripts": 0, "steps": 0, "layouts": 0,
                 "tos": 0, "relationships": 0, "custom_functions": 0, "value_lists": 0}
    total_bytes = 0
    file_ids: list[int] = []
    versions: set[str] = set()

    for i, fel in enumerate(file_elems, start=1):
        link = fel.get("link") or fel.get("name") or ""
        # Resolve `link` against the summary's directory. Summary.xml uses
        # relative paths like ".//Profile FLX_fmp12.xml".
        link_path = (summary_src.parent / link.lstrip("./").lstrip("/")).resolve()
        if not link_path.exists():
            # Fall back to a sibling lookup by basename.
            cand = summary_src.parent / pathlib.Path(link).name
            if cand.exists():
                link_path = cand.resolve()
            else:
                if not quiet:
                    print(f"  WARN: skipping {fel.get('name')!r} — link not found at {link!r}",
                          flush=True)
                continue

        if not quiet:
            print(f"[file {i}] {fel.get('name', link_path.name)}", flush=True)
        counts, attrs, n_bytes = _ingest_file_into_db(
            link_path, conn=conn, file_id=i, keep_xml=keep_xml,
            quiet=quiet, file_link=link,
        )
        for k in aggregate:
            aggregate[k] += counts[k]
        total_bytes += n_bytes
        file_ids.append(i)
        v = attrs.get("version")
        if v:
            versions.add(v)

    if not file_ids:
        raise RuntimeError("Summary referenced files, but none could be loaded")

    _resolve_staging_and_finalize(conn, file_ids)

    summary_root_attrs = dict(root.attrib)
    primary_name = conn.execute(
        "SELECT name FROM file ORDER BY id LIMIT 1"
    ).fetchone()[0]
    summary_sha = hashlib.sha256(summary_data).hexdigest()
    conn.executemany(
        "INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)",
        [
            ("schema_version", SCHEMA_VERSION),
            ("ddr_path", str(summary_src)),
            ("ddr_kind", "summary"),
            ("ddr_sha256", summary_sha),
            ("source_utf8_bytes", str(total_bytes)),
            ("indexed_at", time.strftime("%Y-%m-%dT%H:%M:%S")),
            ("fm_version", ",".join(sorted(versions)) or summary_root_attrs.get("version", "")),
            ("fm_file_name", primary_name),
            ("file_count", str(len(file_ids))),
            ("source", "ddr"),
            *[(f"counts.{k}", str(v)) for k, v in aggregate.items()],
        ],
    )
    conn.commit()
    conn.executescript("PRAGMA optimize;")
    conn.execute("VACUUM")
    conn.close()
    return aggregate
