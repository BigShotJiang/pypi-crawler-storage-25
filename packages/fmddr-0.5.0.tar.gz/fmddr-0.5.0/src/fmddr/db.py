"""DB connection helpers + meta envelope info."""
from __future__ import annotations

import os
import pathlib
import sqlite3


def find_db(explicit: pathlib.Path | None) -> pathlib.Path:
    """Resolve the DB path: --db flag → $FMDDR_DB → unique *.fmddr.db in CWD."""
    if explicit is not None:
        return explicit
    env = os.environ.get("FMDDR_DB")
    if env:
        return pathlib.Path(env)
    candidates = list(pathlib.Path.cwd().glob("*.fmddr.db"))
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) == 0:
        raise FileNotFoundError(
            "No fmddr DB found. Build one with `fmddr index <ddr.xml>` "
            "or pass --db <path>."
        )
    raise FileNotFoundError(
        f"Multiple .fmddr.db files in CWD ({len(candidates)}); pass --db <path>."
    )


def connect(db_path: pathlib.Path) -> sqlite3.Connection:
    if not db_path.exists():
        raise FileNotFoundError(f"DB not found: {db_path}")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def meta(conn: sqlite3.Connection) -> dict[str, str]:
    return {row["key"]: row["value"] for row in conn.execute("SELECT key,value FROM meta")}


def ddr_envelope(conn: sqlite3.Connection) -> dict:
    m = meta(conn)
    return {
        "path": m.get("ddr_path"),
        "sha256": m.get("ddr_sha256"),
        "indexed_at": m.get("indexed_at"),
    }
