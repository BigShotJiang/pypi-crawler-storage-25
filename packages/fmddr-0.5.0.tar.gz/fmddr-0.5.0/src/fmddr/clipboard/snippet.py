"""<fmxmlsnippet> wrap/detect/validate — pure logic, no platform calls.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET

XML_DECL = '<?xml version="1.0" encoding="UTF-8"?>\n'

KNOWN_FM_ELEMENT_TYPES = (
    "ScriptStep",
    "Script",
    "LayoutObject",
    "Field",
    "CustomFunction",
    "Table",
    "ValueList",
    "CustomMenu",
    "Theme",
)

# macOS uniform type identifiers — keys are dyn UTIs, values are FM element type names.
MAC_FORMAT_MAP: dict[str, str] = {
    "dyn.ah62d4rv4gk8zuxnxnq": "ScriptStep",
    "dyn.ah62d4rv4gk8zuxnxkq": "Script",
    "dyn.ah62d4rv4gk8zuxnqgk": "LayoutObject",
    "dyn.ah62d4rv4gk8zuxngku": "Field",
    "dyn.ah62d4rv4gk8zuxngm2": "CustomFunction",
    "dyn.ah62d4rv4gk8zuxnykk": "Table",
}

WIN_FORMAT_MAP: dict[str, str] = {
    "Mac-XMSS": "ScriptStep",
    "Mac-XMSC": "Script",
    "Mac-XML2": "LayoutObject",
    "Mac-XMFD": "Field",
    "Mac-XMFN": "CustomFunction",
    "Mac-XMTB": "Table",
    "Mac-XMVL": "ValueList",
    "Mac-XMGR": "CustomMenu",
    "Mac-XMLT": "Theme",
}

FM_TYPE_TO_MAC: dict[str, str | None] = {
    "ScriptStep": "dyn.ah62d4rv4gk8zuxnxnq",
    "Script": "dyn.ah62d4rv4gk8zuxnxkq",
    "LayoutObject": "dyn.ah62d4rv4gk8zuxnqgk",
    "Field": "dyn.ah62d4rv4gk8zuxngku",
    "CustomFunction": "dyn.ah62d4rv4gk8zuxngm2",
    "Table": "dyn.ah62d4rv4gk8zuxnykk",
    "ValueList": None,
    "CustomMenu": None,
    "Theme": None,
}

# fmxmlsnippet type attribute values (different vocabulary than element type).
# Note: FileMaker writes a copied Script as `<fmxmlsnippet type="FMObjectList">`
# wrapping a `<Script>` element whose `<Step>` children are direct (no <StepList>).
SNIPPET_TYPE_FOR: dict[str, str] = {
    "Script": "FMObjectList",
    "ScriptStep": "FMObjectList",
    "LayoutObject": "FMObjectList",
    "Field": "FieldObj",
    "Table": "BaseTable",
    "CustomFunction": "CustomFunction",
    "ValueList": "ValueListCatalog",
}


class FileMakerClipboardError(Exception):
    """Raised when clipboard ops fail in a known way (mirrors TS error codes)."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code  # INVALID_XML | MISSING_FORMAT | UNSUPPORTED_PLATFORM | UNSUPPORTED_ELEMENT_TYPE


def assert_valid_fm_xml(xml: str) -> None:
    trimmed = xml.strip()
    if not trimmed:
        raise FileMakerClipboardError("INVALID_XML", "FileMaker clipboard XML cannot be empty.")
    if not re.search(r"<fmxmlsnippet\b", trimmed, re.IGNORECASE):
        raise FileMakerClipboardError(
            "INVALID_XML",
            'Expected FileMaker clipboard XML with a root "<fmxmlsnippet>" element.',
        )


def detect_fm_type_from_xml(xml: str) -> str:
    """Return one of KNOWN_FM_ELEMENT_TYPES or 'Unknown'."""
    if not re.search(r"<fmxmlsnippet\b", xml, re.IGNORECASE):
        return "Unknown"
    m = re.search(r'<fmxmlsnippet[^>]+type="([^"]+)"', xml, re.IGNORECASE)
    root_type = m.group(1) if m else ""
    # A full Script snippet contains a <Script> element wrapping its steps.
    # DDR-shape uses <StepList>; FileMaker-native nests <Step> directly under <Script>.
    if re.search(r"<Script\b[^/]*>", xml) and (
        re.search(r"<StepList\b", xml) or re.search(r"<Step\b", xml)
    ):
        return "Script"
    if re.search(r"<Step\b", xml):
        return "ScriptStep"
    if root_type == "FMObjectList" and re.search(r"<Object\b", xml):
        return "LayoutObject"
    if root_type == "BaseTable":
        return "Table"
    if root_type == "FieldObj":
        return "Field"
    if root_type == "CustomFunction":
        return "CustomFunction"
    if root_type == "ValueListCatalog":
        return "ValueList"
    return "Unknown"


def fm_type_from_format(raw: str, *, platform: str) -> str:
    table = MAC_FORMAT_MAP if platform == "darwin" else WIN_FORMAT_MAP
    return table.get(raw, "Unknown")


def detect_from_ddr_root(root_tag: str) -> str | None:
    """DDR-side root tag → FM element type. None if unsupported."""
    return {
        "Script": "Script",
        "BaseTable": "Table",
        "CustomFunction": "CustomFunction",
    }.get(root_tag)


def wrap_as_snippet(payload_xml: str, fm_type: str) -> str:
    """Wrap a payload element in <fmxmlsnippet type="...">."""
    snippet_type = SNIPPET_TYPE_FOR.get(fm_type)
    if snippet_type is None:
        raise FileMakerClipboardError(
            "UNSUPPORTED_ELEMENT_TYPE",
            f'No snippet type mapping for FM element type "{fm_type}".',
        )
    body = payload_xml.strip()
    if body.startswith("<?xml"):
        body = body.split("?>", 1)[1].lstrip()
    return (
        f'{XML_DECL}<fmxmlsnippet type="{snippet_type}">\n'
        f"{body}\n"
        f"</fmxmlsnippet>\n"
    )


def resolve_write_element_type(*, detected: str, requested: str | None) -> str:
    """Explicit > detected > error. Mirrors proofkit utils.ts:38-54."""
    if requested:
        if requested not in KNOWN_FM_ELEMENT_TYPES:
            raise FileMakerClipboardError(
                "UNSUPPORTED_ELEMENT_TYPE",
                f'Unknown element type "{requested}". Known: {", ".join(KNOWN_FM_ELEMENT_TYPES)}.',
            )
        return requested
    if detected != "Unknown":
        return detected
    raise FileMakerClipboardError(
        "UNSUPPORTED_ELEMENT_TYPE",
        "Unable to infer FileMaker element type from XML. Provide elementType explicitly.",
    )


def parse_root_tag(xml: str) -> str:
    """Return the root element tag, or raise INVALID_XML."""
    try:
        root = ET.fromstring(xml)
    except ET.ParseError as e:
        raise FileMakerClipboardError("INVALID_XML", f"XML parse error: {e}") from e
    return root.tag
