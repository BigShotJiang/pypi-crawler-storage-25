"""FileMaker clipboard read/write — public API.

Port of `proofkit-private/packages/filemaker-clipboard`. macOS only in v1;
non-Darwin hosts raise UNSUPPORTED_PLATFORM.
"""
from __future__ import annotations

import sys

from .snippet import (
    FM_TYPE_TO_MAC,
    KNOWN_FM_ELEMENT_TYPES,
    MAC_FORMAT_MAP,
    SNIPPET_TYPE_FOR,
    FileMakerClipboardError,
    assert_valid_fm_xml,
    detect_fm_type_from_xml,
    detect_from_ddr_root,
    fm_type_from_format,
    parse_root_tag,
    resolve_write_element_type,
    wrap_as_snippet,
)


def _assert_supported_platform() -> None:
    if sys.platform != "darwin":
        raise FileMakerClipboardError(
            "UNSUPPORTED_PLATFORM",
            f"Unsupported platform: {sys.platform}. v1 supports macOS only.",
        )


def list_clipboard_formats() -> list[dict]:
    """Return [{raw, fmType}] for every type currently on the system clipboard."""
    _assert_supported_platform()
    from . import platform_mac

    return [
        {"raw": raw, "fmType": fm_type_from_format(raw, platform="darwin")}
        for raw in platform_mac.list_formats()
    ]


def list_fm_formats() -> list[dict]:
    return [f for f in list_clipboard_formats() if f["fmType"] != "Unknown"]


def get_fm_xml(element_type: str) -> dict:
    """Read the clipboard payload for `element_type`. Returns {xml, format}."""
    _assert_supported_platform()
    if element_type not in KNOWN_FM_ELEMENT_TYPES:
        raise FileMakerClipboardError(
            "UNSUPPORTED_ELEMENT_TYPE",
            f'Unknown element type "{element_type}".',
        )
    from . import platform_mac

    formats = list_clipboard_formats()
    match = next((f for f in formats if f["fmType"] == element_type), None)
    if match is None:
        available = [f["fmType"] for f in formats if f["fmType"] != "Unknown"]
        avail_str = ", ".join(available) if available else "none. Copy something from FileMaker first."
        raise FileMakerClipboardError(
            "MISSING_FORMAT",
            f'No "{element_type}" format found on the clipboard. Available: {avail_str}',
        )
    xml = platform_mac.get_text(match["raw"])
    return {"xml": xml, "format": match}


def get_first_fm_xml() -> dict:
    _assert_supported_platform()
    from . import platform_mac

    fm_formats = list_fm_formats()
    if not fm_formats:
        raise FileMakerClipboardError(
            "MISSING_FORMAT",
            "No FileMaker content found on the clipboard. Copy a supported FileMaker object first.",
        )
    first = fm_formats[0]
    return {"xml": platform_mac.get_text(first["raw"]), "format": first}


def set_fm_xml(xml: str, element_type: str) -> None:
    """Push `xml` (already an <fmxmlsnippet>) onto the clipboard as `element_type`."""
    assert_valid_fm_xml(xml)
    _assert_supported_platform()
    if element_type not in KNOWN_FM_ELEMENT_TYPES:
        raise FileMakerClipboardError(
            "UNSUPPORTED_ELEMENT_TYPE",
            f'Unknown element type "{element_type}".',
        )
    fmt = FM_TYPE_TO_MAC.get(element_type)
    if not fmt:
        raise FileMakerClipboardError(
            "UNSUPPORTED_ELEMENT_TYPE",
            f'No macOS clipboard format for "{element_type}".',
        )
    from . import platform_mac

    platform_mac.set_text(xml, fmt)


def notify(title: str, message: str, *, subtitle: str | None = None) -> None:
    """Best-effort desktop notification on success. No-op on non-Darwin."""
    if sys.platform != "darwin":
        return
    from . import platform_mac

    platform_mac.notify(title, message, subtitle=subtitle)


__all__ = [
    "FileMakerClipboardError",
    "KNOWN_FM_ELEMENT_TYPES",
    "MAC_FORMAT_MAP",
    "SNIPPET_TYPE_FOR",
    "assert_valid_fm_xml",
    "detect_fm_type_from_xml",
    "detect_from_ddr_root",
    "get_first_fm_xml",
    "get_fm_xml",
    "list_clipboard_formats",
    "list_fm_formats",
    "notify",
    "parse_root_tag",
    "resolve_write_element_type",
    "set_fm_xml",
    "wrap_as_snippet",
]
