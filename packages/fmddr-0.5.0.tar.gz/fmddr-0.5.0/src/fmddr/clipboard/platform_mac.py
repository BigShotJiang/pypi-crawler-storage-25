"""macOS NSPasteboard via osascript. Ported from proofkit-private index.ts:167-248."""
from __future__ import annotations

import pathlib
import subprocess
import tempfile

from .snippet import FileMakerClipboardError, MAC_FORMAT_MAP, FM_TYPE_TO_MAC


def _run_applescript(script: str, timeout: float = 8.0) -> str:
    try:
        result = subprocess.run(
            ["osascript", "-l", "AppleScript"],
            input=script,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError as e:
        raise FileMakerClipboardError(
            "UNSUPPORTED_PLATFORM", "osascript not found — macOS only."
        ) from e
    if result.returncode != 0:
        raise RuntimeError(f"osascript error: {(result.stderr or '').strip()}")
    return (result.stdout or "").strip()


def list_formats() -> list[str]:
    script = """
use framework "AppKit"
use scripting additions
set pasteboard to current application's NSPasteboard's generalPasteboard()
set pasteboardTypes to pasteboard's types() as list
return pasteboardTypes
""".strip()
    try:
        out = _run_applescript(script)
    except RuntimeError:
        return []
    if not out:
        return []
    return [s.strip() for s in out.split(", ") if s.strip()]


def get_text(format_type: str) -> str:
    is_utf16 = "utf16" in format_type
    encoding = "2415919360" if is_utf16 else "4"
    safe = format_type.replace("\\", "\\\\").replace('"', '\\"')
    script = f"""
use framework "AppKit"
use scripting additions
set pasteboard to current application's NSPasteboard's generalPasteboard()
set pasteboardData to pasteboard's dataForType:"{safe}"
if pasteboardData is missing value then return ""
set pasteboardText to current application's NSString's alloc()'s initWithData:pasteboardData encoding:{encoding}
if pasteboardText is missing value then return ""
return pasteboardText as text
""".strip()
    try:
        return _run_applescript(script)
    except RuntimeError:
        return ""


def set_text(xml: str, format_type: str) -> None:
    """Write `xml` to the macOS pasteboard under `format_type`.

    Uses a temp file (proofkit pattern) so the XML never has to be escaped
    through AppleScript string syntax.
    """
    with tempfile.TemporaryDirectory(prefix="fmddr-clipboard-") as tmpdir:
        path = pathlib.Path(tmpdir) / "clipboard.xml"
        path.write_text(xml, encoding="utf-8")
        safe_path = str(path).replace("\\", "\\\\").replace('"', '\\"')
        safe_format = format_type.replace("\\", "\\\\").replace('"', '\\"')
        script = f"""
use framework "Foundation"
use framework "AppKit"
use scripting additions
set xmlPath to "{safe_path}"
set xmlUrl to current application's NSURL's fileURLWithPath:xmlPath
set xmlData to current application's NSData's dataWithContentsOfURL:xmlUrl
set pasteboard to current application's NSPasteboard's generalPasteboard()
pasteboard's declareTypes:{{"{safe_format}"}} owner:(missing value)
pasteboard's setData:xmlData forType:"{safe_format}"
return "ok"
""".strip()
        _run_applescript(script)


def notify(title: str, message: str, *, subtitle: str | None = None) -> None:
    """Best-effort macOS notification via `osascript display notification`. Never raises."""
    def _esc(s: str) -> str:
        return s.replace("\\", "\\\\").replace('"', '\\"')

    parts = [f'display notification "{_esc(message)}" with title "{_esc(title)}"']
    if subtitle:
        parts.append(f'subtitle "{_esc(subtitle)}"')
    script = " ".join(parts)
    try:
        subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            timeout=3.0,
            check=False,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass


__all__ = ["list_formats", "get_text", "set_text", "notify"]
