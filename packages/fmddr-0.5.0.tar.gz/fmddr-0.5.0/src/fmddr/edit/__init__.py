"""Pre-clipboard write guards for split-tree DDR XML."""
