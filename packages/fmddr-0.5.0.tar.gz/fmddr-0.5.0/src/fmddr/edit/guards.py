"""Strict pre-write guards. Hard-block schema violations; warn on ID drift.

These run before `fmddr copy` pushes anything to the clipboard, and stand
alone behind `fmddr validate`.
"""
from __future__ import annotations

import pathlib
import xml.etree.ElementTree as ET

from ..clipboard.snippet import FileMakerClipboardError


# Map split-tree subdirectory → required DDR root tag.
EXPECTED_ROOT_BY_DIR: dict[str, str] = {
    "scripts": "Script",
    "tables": "BaseTable",
    "layouts": "Layout",
}


class GuardReport:
    """Outcome of running guards. `errors` blocks; `warnings` informs."""

    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.root_tag: str | None = None
        self.root_id: str | None = None
        self.root_name: str | None = None

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict:
        return {
            "ok": self.ok,
            "errors": self.errors,
            "warnings": self.warnings,
            "root_tag": self.root_tag,
            "root_id": self.root_id,
            "root_name": self.root_name,
        }


def _expected_root_for_path(path: pathlib.Path) -> str | None:
    """Look up the expected root tag based on which split-tree subdir the file is in."""
    for part in path.parts:
        if part in EXPECTED_ROOT_BY_DIR:
            return EXPECTED_ROOT_BY_DIR[part]
    return None


def run_guards(path: pathlib.Path, xml: str) -> GuardReport:
    """Validate `xml` against fmddr's strict-write rules.

    Hard errors:
      - malformed XML
      - root tag missing required attrs (id, name)
      - root tag does not match the expected root for the path's split-tree subdir
    Warnings:
      - root tag not in the v1 clipboard-supported set (Script/BaseTable/CustomFunction)
    """
    report = GuardReport()
    try:
        root = ET.fromstring(xml)
    except ET.ParseError as e:
        report.errors.append(f"XML parse error: {e}")
        return report

    report.root_tag = root.tag
    report.root_id = root.get("id")
    report.root_name = root.get("name")

    expected = _expected_root_for_path(path)
    if expected and root.tag != expected:
        report.errors.append(
            f"root <{root.tag}> does not match expected <{expected}> for files under '{expected.lower()}s/'"
        )

    if not root.get("id"):
        report.errors.append(f"root <{root.tag}> missing required 'id' attribute")
    if not root.get("name"):
        report.errors.append(f"root <{root.tag}> missing required 'name' attribute")

    from ..transform.ddr_to_snippet import SUPPORTED_ROOTS

    if root.tag not in SUPPORTED_ROOTS:
        report.warnings.append(
            f"root <{root.tag}> is not in v1 clipboard-supported set {sorted(SUPPORTED_ROOTS)} — "
            "transform will reject it"
        )

    return report


def guard_or_raise(path: pathlib.Path, xml: str) -> GuardReport:
    """Run guards and raise INVALID_XML on any error. Returns the report on success."""
    report = run_guards(path, xml)
    if not report.ok:
        raise FileMakerClipboardError(
            "INVALID_XML",
            "; ".join(report.errors),
        )
    return report
