"""Stable output envelope + multi-format rendering.

Every command emits the same shape regardless of format. The envelope is the
agent contract; rendering is presentation only.
"""
from __future__ import annotations

import csv
import io
import json
import sys
from typing import Any


ENVELOPE_VERSION = 1


def envelope(
    *,
    kind: str,
    ddr: dict,
    result: list[dict] | dict,
    query: dict | None = None,
    truncated: bool = False,
) -> dict:
    if isinstance(result, list):
        result_count = len(result)
    else:
        result_count = 1
    return {
        "kind": kind,
        "version": ENVELOPE_VERSION,
        "ddr": ddr,
        "query": query or {},
        "result": result,
        "result_count": result_count,
        "truncated": truncated,
    }


def pick_default_format() -> str:
    return "table" if sys.stdout.isatty() else "json"


def render(env: dict, fmt: str) -> None:
    if fmt == "json":
        sys.stdout.write(json.dumps(env, indent=2, default=str) + "\n")
        return
    if fmt == "jsonl":
        result = env["result"]
        if isinstance(result, list):
            for row in result:
                sys.stdout.write(json.dumps(row, default=str) + "\n")
        else:
            sys.stdout.write(json.dumps(result, default=str) + "\n")
        return
    if fmt in ("csv", "tsv"):
        _render_csv(env["result"], delim="\t" if fmt == "tsv" else ",")
        return
    if fmt == "markdown":
        _render_markdown(env)
        return
    # default: table (Rich)
    _render_table(env)


def _flatten(rows: list[dict]) -> tuple[list[str], list[dict]]:
    if not rows:
        return [], []
    keys: list[str] = []
    seen: set[str] = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                keys.append(k)
    return keys, rows


def _render_csv(result: Any, *, delim: str) -> None:
    rows = result if isinstance(result, list) else [result]
    keys, rows = _flatten(rows)
    writer = csv.DictWriter(sys.stdout, fieldnames=keys, delimiter=delim, extrasaction="ignore")
    writer.writeheader()
    for r in rows:
        writer.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in keys})


def _render_markdown(env: dict) -> None:
    rows = env["result"] if isinstance(env["result"], list) else [env["result"]]
    keys, rows = _flatten(rows)
    if not keys:
        sys.stdout.write(f"_(empty result for {env['kind']})_\n")
        return
    sys.stdout.write("| " + " | ".join(keys) + " |\n")
    sys.stdout.write("|" + "|".join("---" for _ in keys) + "|\n")
    for r in rows:
        sys.stdout.write("| " + " | ".join(_md_cell(r.get(k)) for k in keys) + " |\n")


def _md_cell(v: Any) -> str:
    if v is None:
        return ""
    s = str(v).replace("|", "\\|").replace("\n", " ")
    return s


def _render_table(env: dict) -> None:
    try:
        from rich.console import Console
        from rich.table import Table
    except ImportError:  # pragma: no cover
        return _render_markdown(env)

    console = Console()
    rows = env["result"] if isinstance(env["result"], list) else [env["result"]]
    keys, rows = _flatten(rows)
    if not rows:
        console.print(f"[dim](empty result for {env['kind']})[/dim]")
        return
    table = Table(title=env["kind"], show_lines=False)
    for k in keys:
        table.add_column(k, overflow="fold")
    for r in rows:
        table.add_row(*[("" if r.get(k) is None else str(r.get(k))) for k in keys])
    console.print(table)
    if env.get("truncated"):
        console.print("[yellow]…truncated[/yellow]")
