"""Custom function queries."""
from __future__ import annotations

import sqlite3


class NotFound(Exception):
    pass


def list_cfs(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT id, name, parameters FROM custom_function ORDER BY name"
    ).fetchall()
    return [dict(r) for r in rows]


def resolve(conn: sqlite3.Connection, token: str) -> dict:
    t = token.strip().lstrip("#")
    if t.isdigit():
        row = conn.execute("SELECT * FROM custom_function WHERE id = ?", (int(t),)).fetchone()
        if row is None:
            raise NotFound(f"No custom function with id {t}")
        return dict(row)
    row = conn.execute("SELECT * FROM custom_function WHERE name = ?", (token,)).fetchone()
    if row is None:
        raise NotFound(f"No custom function named {token!r}")
    return dict(row)


def cf_calls(conn: sqlite3.Connection, function_id: int) -> list[dict]:
    """Other custom functions this CF calls."""
    rows = conn.execute(
        "SELECT DISTINCT cf.id, cf.name FROM custom_function_ref cfr "
        "JOIN custom_function cf ON cf.id = cfr.function_id "
        "WHERE cfr.caller_kind = 'custom_function' AND cfr.caller_id = ? "
        "ORDER BY cf.name",
        (function_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def cf_fields(conn: sqlite3.Connection, function_id: int) -> list[dict]:
    """Fields referenced inside this CF body."""
    rows = conn.execute(
        "SELECT DISTINCT f.id, f.name, bt.name AS table_name "
        "FROM field_ref fr JOIN field f ON f.id = fr.field_id "
        "JOIN base_table bt ON bt.id = f.base_table_id "
        "WHERE fr.owner_kind = 'custom_function' AND fr.owner_id = ? "
        "ORDER BY bt.name, f.name",
        (function_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def cf_called_by(conn: sqlite3.Connection, function_id: int) -> list[dict]:
    """Everywhere this CF is referenced — fields, script steps, layout objects, other CFs, …"""
    rows = conn.execute(
        "SELECT cfr.caller_kind, cfr.caller_id, cfr.caller_sub, "
        "       s.id AS script_id, s.name AS script_name, s.folder AS script_folder, "
        "       ss.step_index, ss.step_type_name, ss.step_text, "
        "       l.id AS layout_id, l.name AS layout_name, "
        "       f.id AS owner_field_id, f.name AS owner_field_name, "
        "       bt.name AS owner_field_table, "
        "       cf2.id AS owner_cf_id, cf2.name AS owner_cf_name "
        "FROM custom_function_ref cfr "
        "LEFT JOIN script s ON cfr.caller_kind='script_step' AND s.id = cfr.caller_id "
        "LEFT JOIN script_step ss ON cfr.caller_kind='script_step' "
        "                         AND ss.script_id = cfr.caller_id AND ss.step_index = cfr.caller_sub "
        "LEFT JOIN layout l ON cfr.caller_kind='layout_object' AND l.id = cfr.caller_id "
        "LEFT JOIN field f ON cfr.caller_kind IN ('field_calc','field_autoenter','field_validation') "
        "                  AND f.id = cfr.caller_id "
        "LEFT JOIN base_table bt ON bt.id = f.base_table_id "
        "LEFT JOIN custom_function cf2 ON cfr.caller_kind='custom_function' AND cf2.id = cfr.caller_id "
        "WHERE cfr.function_id = ? "
        "ORDER BY cfr.caller_kind, cfr.caller_id",
        (function_id,),
    ).fetchall()
    return [dict(r) for r in rows]
