"""Layout queries (header level for now; objects/refs in later build steps)."""
from __future__ import annotations

import sqlite3


def list_layouts(
    conn: sqlite3.Connection,
    *,
    folder: str | None = None,
) -> list[dict]:
    sql = "SELECT id, name, folder FROM layout"
    args: list = []
    if folder is not None:
        sql += " WHERE folder = ?"
        args.append(folder)
    sql += " ORDER BY folder, name"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def layout_objects(
    conn: sqlite3.Connection, layout_id: int, *, object_type: str | None = None
) -> list[dict]:
    sql = (
        "SELECT object_key, object_type, name, "
        "       bounds_top, bounds_left, bounds_bottom, bounds_right "
        "FROM layout_object WHERE layout_id = ?"
    )
    args: list = [layout_id]
    if object_type:
        sql += " AND object_type = ?"
        args.append(object_type)
    sql += " ORDER BY object_key"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def layout_fields(conn: sqlite3.Connection, layout_id: int) -> list[dict]:
    """Distinct fields shown on this layout."""
    rows = conn.execute(
        "SELECT DISTINCT f.id, f.name, bt.name AS table_name "
        "FROM field_ref fr "
        "JOIN field f ON f.id = fr.field_id "
        "JOIN base_table bt ON bt.id = f.base_table_id "
        "WHERE fr.owner_kind = 'layout_object' AND fr.owner_id = ? "
        "ORDER BY bt.name, f.name",
        (layout_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def layout_scripts(conn: sqlite3.Connection, layout_id: int) -> list[dict]:
    """Scripts referenced by this layout (buttons + ScriptTriggers)."""
    rows = conn.execute(
        "SELECT DISTINCT s.id, s.name, s.folder, sr.caller_kind "
        "FROM script_ref sr JOIN script s ON s.id = sr.callee_id "
        "WHERE sr.caller_kind IN ('layout_trigger','layout_button') "
        "  AND sr.caller_id = ? "
        "ORDER BY s.folder, s.name",
        (layout_id,),
    ).fetchall()
    return [dict(r) for r in rows]
