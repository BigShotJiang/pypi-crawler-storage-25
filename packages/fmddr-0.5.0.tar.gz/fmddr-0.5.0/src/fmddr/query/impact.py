"""Higher-order queries: impact, unused, orphans, script call chain.

These ride on the reference graph populated in build steps 6–8.
"""
from __future__ import annotations

import sqlite3


# ---------------------------------------------------------------------- impact

def impact_field(conn: sqlite3.Connection, field_id: int) -> dict:
    """Everything that breaks if this field is removed.

    Direct: anything that names the field via field_ref.
    Transitive: scripts that call those scripts, fields whose calcs reference
    the affected fields, etc. Result is a flat dict keyed by impact category.
    """
    direct_scripts = {r[0] for r in conn.execute(
        "SELECT DISTINCT owner_id FROM field_ref "
        "WHERE field_id=? AND owner_kind='script_step'", (field_id,)
    )}
    direct_layouts = {r[0] for r in conn.execute(
        "SELECT DISTINCT owner_id FROM field_ref "
        "WHERE field_id=? AND owner_kind='layout_object'", (field_id,)
    )}
    direct_fields = {r[0] for r in conn.execute(
        "SELECT DISTINCT owner_id FROM field_ref "
        "WHERE field_id=? AND owner_kind IN "
        "  ('field_calc','field_autoenter','field_validation')",
        (field_id,)
    )}
    direct_cfs = {r[0] for r in conn.execute(
        "SELECT DISTINCT owner_id FROM field_ref "
        "WHERE field_id=? AND owner_kind='custom_function'", (field_id,)
    )}
    direct_relationships = {r[0] for r in conn.execute(
        "SELECT DISTINCT owner_id FROM field_ref "
        "WHERE field_id=? AND owner_kind='relationship_predicate'", (field_id,)
    )}
    direct_value_lists = {r[0] for r in conn.execute(
        "SELECT DISTINCT owner_id FROM field_ref "
        "WHERE field_id=? AND owner_kind='value_list'", (field_id,)
    )}

    # Scripts that call any of the directly-affected scripts (one hop).
    transitive_scripts: set[int] = set()
    if direct_scripts:
        placeholders = ",".join("?" for _ in direct_scripts)
        rows = conn.execute(
            f"SELECT DISTINCT caller_id FROM script_ref "
            f"WHERE caller_kind='script_step' AND callee_id IN ({placeholders})",
            tuple(direct_scripts),
        ).fetchall()
        transitive_scripts = {r[0] for r in rows} - direct_scripts

    return {
        "direct_scripts": sorted(direct_scripts),
        "direct_layouts": sorted(direct_layouts),
        "direct_fields": sorted(direct_fields),
        "direct_custom_functions": sorted(direct_cfs),
        "direct_relationships": sorted(direct_relationships),
        "direct_value_lists": sorted(direct_value_lists),
        "transitive_scripts": sorted(transitive_scripts),
    }


def impact_script(conn: sqlite3.Connection, script_id: int, depth: int = 3) -> dict:
    """Recursive script callers up to `depth` hops away."""
    callers: set[int] = set()
    frontier = {script_id}
    for _ in range(depth):
        if not frontier:
            break
        ph = ",".join("?" for _ in frontier)
        rows = conn.execute(
            f"SELECT DISTINCT caller_id FROM script_ref "
            f"WHERE caller_kind='script_step' AND callee_id IN ({ph})",
            tuple(frontier),
        ).fetchall()
        next_frontier = {r[0] for r in rows} - callers - {script_id}
        callers |= next_frontier
        frontier = next_frontier
    return {"transitive_callers": sorted(callers), "depth": depth}


# ---------------------------------------------------------------------- unused

_UNUSED_QUERIES = {
    "field": (
        "SELECT f.id, f.name, bt.name AS table_name "
        "FROM field f JOIN base_table bt ON bt.id = f.base_table_id "
        "WHERE NOT EXISTS (SELECT 1 FROM field_ref fr WHERE fr.field_id = f.id) "
        "ORDER BY bt.name, f.name"
    ),
    "script": (
        "SELECT s.id, s.name, s.folder FROM script s "
        "WHERE NOT EXISTS (SELECT 1 FROM script_ref sr WHERE sr.callee_id = s.id) "
        "ORDER BY s.folder, s.name"
    ),
    "layout": (
        "SELECT l.id, l.name, l.folder FROM layout l "
        "WHERE NOT EXISTS (SELECT 1 FROM layout_ref lr WHERE lr.layout_id = l.id) "
        "ORDER BY l.folder, l.name"
    ),
    "custom_function": (
        "SELECT cf.id, cf.name FROM custom_function cf "
        "WHERE NOT EXISTS (SELECT 1 FROM custom_function_ref cfr WHERE cfr.function_id = cf.id) "
        "ORDER BY cf.name"
    ),
    "value_list": (
        "SELECT vl.id, vl.name, vl.source FROM value_list vl "
        "WHERE NOT EXISTS (SELECT 1 FROM value_list_ref vlr WHERE vlr.value_list_id = vl.id) "
        "ORDER BY vl.name"
    ),
    "table_occurrence": (
        "SELECT toc.id, toc.name, bt.name AS base_table FROM table_occurrence toc "
        "LEFT JOIN base_table bt ON bt.id = toc.base_table_id "
        "WHERE NOT EXISTS ("
        "    SELECT 1 FROM relationship r "
        "    WHERE r.left_to_id = toc.id OR r.right_to_id = toc.id"
        ") AND NOT EXISTS ("
        "    SELECT 1 FROM layout l WHERE l.table_occurrence_id = toc.id"
        ") "
        "ORDER BY toc.name"
    ),
}


def unused(conn: sqlite3.Connection, kind: str) -> list[dict]:
    sql = _UNUSED_QUERIES.get(kind)
    if sql is None:
        raise ValueError(f"Unknown kind: {kind}. Choose from {list(_UNUSED_QUERIES)}")
    return [dict(r) for r in conn.execute(sql).fetchall()]


# --------------------------------------------------------------------- orphans

def orphans(conn: sqlite3.Connection) -> dict:
    """Refs whose target rows don't exist (FM allows broken references)."""
    return {
        "field_ref": [
            dict(r) for r in conn.execute(
                "SELECT fr.field_id, fr.owner_kind, fr.owner_id FROM field_ref fr "
                "LEFT JOIN field f ON f.id = fr.field_id WHERE f.id IS NULL"
            ).fetchall()
        ],
        "script_ref": [
            dict(r) for r in conn.execute(
                "SELECT sr.callee_id, sr.caller_kind, sr.caller_id FROM script_ref sr "
                "LEFT JOIN script s ON s.id = sr.callee_id WHERE s.id IS NULL"
            ).fetchall()
        ],
        "layout_ref": [
            dict(r) for r in conn.execute(
                "SELECT lr.layout_id, lr.caller_kind, lr.caller_id FROM layout_ref lr "
                "LEFT JOIN layout l ON l.id = lr.layout_id WHERE l.id IS NULL"
            ).fetchall()
        ],
    }


# --------------------------------------------------------------------- chain

def script_chain(
    conn: sqlite3.Connection, script_id: int, *, depth: int = 5
) -> list[dict]:
    """BFS the script call graph from `script_id` up to `depth` hops.

    Returns a list of edges: {from_id, from_name, to_id, to_name, depth}.
    """
    edges: list[dict] = []
    seen: set[int] = {script_id}
    frontier = [script_id]
    for d in range(1, depth + 1):
        if not frontier:
            break
        ph = ",".join("?" for _ in frontier)
        rows = conn.execute(
            f"SELECT sr.caller_id, s1.name AS from_name, sr.callee_id, s2.name AS to_name "
            f"FROM script_ref sr "
            f"JOIN script s1 ON s1.id = sr.caller_id "
            f"JOIN script s2 ON s2.id = sr.callee_id "
            f"WHERE sr.caller_kind='script_step' AND sr.caller_id IN ({ph})",
            tuple(frontier),
        ).fetchall()
        next_frontier: list[int] = []
        for r in rows:
            edges.append({
                "from_id": r[0], "from_name": r[1],
                "to_id": r[2], "to_name": r[3],
                "depth": d,
            })
            if r[2] not in seen:
                seen.add(r[2])
                next_frontier.append(r[2])
        frontier = next_frontier
    return edges


def chain_to_mermaid(edges: list[dict]) -> str:
    """Render the BFS edge list as a Mermaid flowchart."""
    if not edges:
        return "flowchart LR\n  empty[No outgoing calls]\n"
    nodes: dict[int, str] = {}
    for e in edges:
        nodes[e["from_id"]] = e["from_name"]
        nodes[e["to_id"]] = e["to_name"]
    out = ["flowchart LR"]
    for nid, nname in nodes.items():
        safe = nname.replace('"', "'")
        out.append(f'  s{nid}["{safe}"]')
    for e in edges:
        out.append(f'  s{e["from_id"]} --> s{e["to_id"]}')
    return "\n".join(out) + "\n"


def chain_to_dot(edges: list[dict]) -> str:
    if not edges:
        return 'digraph chain { empty [label="No outgoing calls"]; }\n'
    nodes: dict[int, str] = {}
    for e in edges:
        nodes[e["from_id"]] = e["from_name"]
        nodes[e["to_id"]] = e["to_name"]
    lines = ["digraph chain {", "  rankdir=LR;"]
    for nid, nname in nodes.items():
        safe = nname.replace('"', "'")
        lines.append(f'  s{nid} [label="{safe}"];')
    for e in edges:
        lines.append(f"  s{e['from_id']} -> s{e['to_id']};")
    lines.append("}")
    return "\n".join(lines) + "\n"
