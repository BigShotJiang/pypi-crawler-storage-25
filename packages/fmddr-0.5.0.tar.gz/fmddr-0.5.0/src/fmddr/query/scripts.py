"""Script + step queries."""
from __future__ import annotations

import sqlite3
from collections import deque


def list_scripts(
    conn: sqlite3.Connection,
    *,
    folder: str | None = None,
    name_substring: str | None = None,
) -> list[dict]:
    sql = "SELECT id, name, folder, include_in_menu, full_access FROM script WHERE 1=1"
    args: list = []
    if folder is not None:
        sql += " AND folder = ?"
        args.append(folder)
    if name_substring:
        sql += " AND name LIKE ?"
        args.append(f"%{name_substring}%")
    sql += " ORDER BY folder, name"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def script_steps(
    conn: sqlite3.Connection,
    script_id: int,
    *,
    step_type: str | None = None,
    has_flag: str | None = None,
    include_disabled: bool = True,
) -> list[dict]:
    sql = (
        "SELECT script_id, step_index, fm_line, step_type_id, step_type_name, enabled, "
        "       step_text, var_name, has_get_script_parameter, has_get_script_result, "
        "       has_evaluate, has_execute_sql "
        "FROM script_step WHERE script_id = ?"
    )
    args: list = [script_id]
    if step_type:
        sql += " AND step_type_name = ?"
        args.append(step_type)
    if has_flag:
        col = {
            "execute_sql": "has_execute_sql",
            "evaluate": "has_evaluate",
            "get_script_parameter": "has_get_script_parameter",
            "get_script_result": "has_get_script_result",
        }.get(has_flag)
        if col is None:
            raise ValueError(f"Unknown step flag: {has_flag}")
        sql += f" AND {col} = 1"
    if not include_disabled:
        sql += " AND enabled = 1"
    sql += " ORDER BY step_index"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def script_calls(conn: sqlite3.Connection, script_id: int) -> list[dict]:
    """Scripts this script calls (Perform Script steps + future button refs)."""
    rows = conn.execute(
        "SELECT DISTINCT s.id, s.name, s.folder, sr.caller_sub AS step_index "
        "FROM script_ref sr JOIN script s ON s.id = sr.callee_id "
        "WHERE sr.caller_kind = 'script_step' AND sr.caller_id = ? "
        "ORDER BY sr.caller_sub",
        (script_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def script_called_by(conn: sqlite3.Connection, script_id: int) -> list[dict]:
    """Scripts (and other callers) that invoke this script."""
    rows = conn.execute(
        "SELECT DISTINCT sr.caller_kind, "
        "       s.id AS script_id, s.name AS script_name, s.folder, "
        "       sr.caller_sub AS step_index, ss.step_text "
        "FROM script_ref sr "
        "LEFT JOIN script s ON sr.caller_kind='script_step' AND s.id = sr.caller_id "
        "LEFT JOIN script_step ss ON sr.caller_kind='script_step' "
        "                         AND ss.script_id = sr.caller_id AND ss.step_index = sr.caller_sub "
        "WHERE sr.callee_id = ? "
        "ORDER BY s.folder, s.name, sr.caller_sub",
        (script_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def script_elements(conn: sqlite3.Connection, script_id: int) -> list[dict]:
    """All distinct elements referenced anywhere in the script:
    fields, scripts called, layouts navigated to, custom functions used.
    """
    out: list[dict] = []
    for r in conn.execute(
        "SELECT DISTINCT 'field' AS kind, f.id, f.name AS name, bt.name AS context "
        "FROM field_ref fr JOIN field f ON f.id=fr.field_id "
        "JOIN base_table bt ON bt.id=f.base_table_id "
        "WHERE fr.owner_kind='script_step' AND fr.owner_id=?",
        (script_id,)
    ).fetchall():
        out.append(dict(r))
    for r in conn.execute(
        "SELECT DISTINCT 'script' AS kind, s.id, s.name AS name, s.folder AS context "
        "FROM script_ref sr JOIN script s ON s.id=sr.callee_id "
        "WHERE sr.caller_kind='script_step' AND sr.caller_id=?",
        (script_id,)
    ).fetchall():
        out.append(dict(r))
    for r in conn.execute(
        "SELECT DISTINCT 'layout' AS kind, l.id, l.name AS name, l.folder AS context "
        "FROM layout_ref lr JOIN layout l ON l.id=lr.layout_id "
        "WHERE lr.caller_kind='script_step' AND lr.caller_id=?",
        (script_id,)
    ).fetchall():
        out.append(dict(r))
    for r in conn.execute(
        "SELECT DISTINCT 'custom_function' AS kind, cf.id, cf.name AS name, NULL AS context "
        "FROM custom_function_ref cfr JOIN custom_function cf ON cf.id=cfr.function_id "
        "WHERE cfr.caller_kind='script_step' AND cfr.caller_id=?",
        (script_id,)
    ).fetchall():
        out.append(dict(r))
    return out


def script_calcs(conn: sqlite3.Connection, script_id: int) -> list[dict]:
    """Every step text in the script (the 'Calculations' fan-out)."""
    rows = conn.execute(
        "SELECT step_index, fm_line, step_type_name, step_text, var_name "
        "FROM script_step WHERE script_id = ? ORDER BY step_index",
        (script_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def step_show(conn: sqlite3.Connection, script_id: int, step_index: int) -> dict | None:
    row = conn.execute(
        "SELECT * FROM script_step WHERE script_id=? AND step_index=?",
        (script_id, step_index),
    ).fetchone()
    return dict(row) if row else None


def step_refs(conn: sqlite3.Connection, script_id: int, step_index: int) -> dict:
    """Everything this single step references."""
    fields = [dict(r) for r in conn.execute(
        "SELECT f.id, f.name, bt.name AS table_name, fr.via_to_id, "
        "       toc.name AS via_to_name "
        "FROM field_ref fr JOIN field f ON f.id=fr.field_id "
        "JOIN base_table bt ON bt.id=f.base_table_id "
        "LEFT JOIN table_occurrence toc ON toc.id=fr.via_to_id "
        "WHERE fr.owner_kind='script_step' AND fr.owner_id=? AND fr.owner_sub=?",
        (script_id, step_index)
    ).fetchall()]
    scripts = [dict(r) for r in conn.execute(
        "SELECT s.id, s.name, s.folder FROM script_ref sr JOIN script s ON s.id=sr.callee_id "
        "WHERE sr.caller_kind='script_step' AND sr.caller_id=? AND sr.caller_sub=?",
        (script_id, step_index)
    ).fetchall()]
    layouts = [dict(r) for r in conn.execute(
        "SELECT l.id, l.name, l.folder FROM layout_ref lr JOIN layout l ON l.id=lr.layout_id "
        "WHERE lr.caller_kind='script_step' AND lr.caller_id=? AND lr.caller_sub=?",
        (script_id, step_index)
    ).fetchall()]
    cfs = [dict(r) for r in conn.execute(
        "SELECT DISTINCT cf.id, cf.name FROM custom_function_ref cfr "
        "JOIN custom_function cf ON cf.id=cfr.function_id "
        "WHERE cfr.caller_kind='script_step' AND cfr.caller_id=? AND cfr.caller_sub=?",
        (script_id, step_index)
    ).fetchall()]
    return {"fields": fields, "scripts": scripts, "layouts": layouts, "custom_functions": cfs}


def cleanup_candidates(conn: sqlite3.Connection) -> dict:
    """Scripts/layouts/fields whose names hit DEBT_RE — same regex pipeline.py used.

    BACKUP, COPY, DEPRECATED, DELETE, ORIG, OLD, TEST, OBS, v1, DRAFT, TEMP,
    b4, UNUSED, REMOVE — case-insensitive. Useful as a starting list when
    auditing a long-lived monolith.
    """
    pat = (
        "%BACKUP%|%COPY%|%DEPRECATED%|%DELETE%|%ORIG%|%OLD%|%TEST%|%OBS%|"
        "%v1%|%DRAFT%|%TEMP%|%b4%|%UNUSED%|%REMOVE%"
    )
    # SQLite LIKE is case-insensitive for ASCII by default; we OR a list of
    # patterns. Easier: do the regex in Python over the candidate set.
    import re
    rx = re.compile(
        r"\bBACKUP\b|\bCOPY\b|\bDEPRECATED\b|\bDELETE\b|\bORIG\b|\bOLD\b|"
        r"\bTEST\b|\bOBS\b|\bv1\b|\bDRAFT\b|\bTEMP\b|\bb4\b|\bUNUSED\b|\bREMOVE\b",
        re.IGNORECASE,
    )
    out: dict[str, list[dict]] = {"scripts": [], "layouts": [], "fields": []}
    for r in conn.execute("SELECT id, name, folder FROM script"):
        if rx.search(r[1]):
            out["scripts"].append({"id": r[0], "name": r[1], "folder": r[2]})
    for r in conn.execute("SELECT id, name, folder FROM layout"):
        if rx.search(r[1]):
            out["layouts"].append({"id": r[0], "name": r[1], "folder": r[2]})
    for r in conn.execute(
        "SELECT f.id, f.name, bt.name FROM field f "
        "JOIN base_table bt ON bt.id=f.base_table_id"
    ):
        if rx.search(r[1]):
            out["fields"].append({"id": r[0], "name": r[1], "table": r[2]})
    return out


def script_fields(conn: sqlite3.Connection, script_id: int) -> list[dict]:
    """Distinct fields referenced anywhere in the script."""
    rows = conn.execute(
        "SELECT DISTINCT f.id, f.name, bt.name AS table_name "
        "FROM field_ref fr "
        "JOIN field f ON f.id = fr.field_id "
        "JOIN base_table bt ON bt.id = f.base_table_id "
        "WHERE fr.owner_kind = 'script_step' AND fr.owner_id = ? "
        "ORDER BY bt.name, f.name",
        (script_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def risky_steps(
    conn: sqlite3.Connection,
    *,
    has_flag: str = "execute_sql",
    limit: int | None = None,
) -> list[dict]:
    col = {
        "execute_sql": "has_execute_sql",
        "evaluate": "has_evaluate",
        "get_script_parameter": "has_get_script_parameter",
        "get_script_result": "has_get_script_result",
    }.get(has_flag)
    if col is None:
        raise ValueError(f"Unknown step flag: {has_flag}")
    sql = (
        f"SELECT s.id AS script_id, s.name AS script_name, s.folder, "
        f"       ss.step_index, ss.step_type_name, ss.step_text "
        f"FROM script_step ss JOIN script s ON s.id = ss.script_id "
        f"WHERE ss.{col} = 1 ORDER BY s.folder, s.name, ss.step_index"
    )
    if limit:
        sql += f" LIMIT {int(limit)}"
    return [dict(r) for r in conn.execute(sql).fetchall()]


def globals_set_not_cleared(conn: sqlite3.Connection) -> list[dict]:
    """Scripts that set a $$global variable but never clear it within the same script."""
    sql = """
    WITH sets AS (
        SELECT script_id, var_name
        FROM script_step
        WHERE step_type_name = 'Set Variable' AND var_name LIKE '$$%'
    ),
    clears AS (
        SELECT script_id, var_name
        FROM script_step
        WHERE step_type_name = 'Set Variable' AND var_name LIKE '$$%'
          AND (step_text LIKE '%; Value:"" ]'
               OR step_text LIKE '%; Value: "" ]'
               OR step_text LIKE '%; Value:]'
               OR step_text LIKE '%; Value: ]')
    )
    SELECT DISTINCT s.id AS script_id, s.name AS script_name, s.folder,
           sets.var_name
    FROM sets
    JOIN script s ON s.id = sets.script_id
    WHERE NOT EXISTS (
        SELECT 1 FROM clears
        WHERE clears.script_id = sets.script_id
          AND clears.var_name  = sets.var_name
    )
    ORDER BY s.folder, s.name, sets.var_name
    """
    return [dict(r) for r in conn.execute(sql).fetchall()]


def globals_solution_wide(conn: sqlite3.Connection) -> list[dict]:
    """Solution-wide $$global lifecycle: for every distinct $$var name, report
    how many scripts set it, how many scripts clear it, and which scripts are
    the setters — sorted by vars that are never cleared anywhere first.

    A var with clear_script_count = 0 is never cleaned up anywhere in the solution.
    """
    sql = """
    WITH _clear_pat AS (
        -- reusable clearing-pattern check
        SELECT var_name
        FROM script_step
        WHERE step_type_name = 'Set Variable' AND var_name LIKE '$$%'
          AND (step_text LIKE '%; Value:"" ]'
               OR step_text LIKE '%; Value: "" ]'
               OR step_text LIKE '%; Value:]'
               OR step_text LIKE '%; Value: ]')
    ),
    setter_scripts AS (
        SELECT ss.var_name, s.id AS script_id, s.name AS script_name, s.folder
        FROM script_step ss
        JOIN script s ON s.id = ss.script_id
        WHERE ss.step_type_name = 'Set Variable' AND ss.var_name LIKE '$$%'
          AND NOT (ss.step_text LIKE '%; Value:"" ]'
               OR ss.step_text LIKE '%; Value: "" ]'
               OR ss.step_text LIKE '%; Value:]'
               OR ss.step_text LIKE '%; Value: ]')
    ),
    var_summary AS (
        SELECT var_name,
               COUNT(DISTINCT script_id)                          AS set_script_count,
               (SELECT COUNT(DISTINCT script_id)
                FROM script_step ss2
                WHERE ss2.var_name = setter_scripts.var_name
                  AND ss2.step_type_name = 'Set Variable'
                  AND (ss2.step_text LIKE '%; Value:"" ]'
                    OR ss2.step_text LIKE '%; Value: "" ]'
                    OR ss2.step_text LIKE '%; Value:]'
                    OR ss2.step_text LIKE '%; Value: ]'))         AS clear_script_count
        FROM setter_scripts
        GROUP BY var_name
    )
    SELECT vs.var_name,
           vs.set_script_count,
           vs.clear_script_count,
           GROUP_CONCAT(
               CASE WHEN ss.folder IS NOT NULL
                    THEN ss.folder || '/' || ss.script_name
                    ELSE ss.script_name END,
               ' | '
           ) AS setter_scripts
    FROM var_summary vs
    JOIN setter_scripts ss USING (var_name)
    GROUP BY vs.var_name, vs.set_script_count, vs.clear_script_count
    ORDER BY vs.clear_script_count ASC, vs.set_script_count DESC, vs.var_name
    """
    return [dict(r) for r in conn.execute(sql).fetchall()]


def globals_callee_uncleared(
    conn: sqlite3.Connection,
    script_id: int,
    *,
    max_depth: int = 10,
) -> list[dict]:
    """For a given script, find $$globals it sets that are never cleared within
    its transitive callee tree (all scripts it directly or indirectly calls).

    Returns one row per (var_name, cleared_in_callee) — vars not cleared
    anywhere in the callee tree have cleared_by=None.
    """
    # Collect the full callee set via BFS
    visited: set[int] = set()
    queue: deque[tuple[int, int]] = deque([(script_id, 0)])
    while queue:
        sid, depth = queue.popleft()
        if sid in visited:
            continue
        visited.add(sid)
        if depth >= max_depth:
            continue
        for row in conn.execute(
            "SELECT DISTINCT callee_id FROM script_ref "
            "WHERE caller_kind='script_step' AND caller_id=?",
            (sid,),
        ).fetchall():
            cid = row[0]
            if cid not in visited:
                queue.append((cid, depth + 1))

    callee_ids = list(visited)
    placeholders = ",".join("?" * len(callee_ids))

    # $$vars this script sets (excluding clears)
    set_rows = conn.execute(
        "SELECT DISTINCT var_name FROM script_step "
        "WHERE script_id=? AND step_type_name='Set Variable' AND var_name LIKE '$$%' "
        "AND NOT (step_text LIKE '%; Value:\"\" ]' OR step_text LIKE '%; Value: \"\" ]' "
        "         OR step_text LIKE '%; Value:]' OR step_text LIKE '%; Value: ]')",
        (script_id,),
    ).fetchall()
    set_vars = {r[0] for r in set_rows}

    if not set_vars or not callee_ids:
        return []

    # Which of those vars are cleared somewhere in the callee tree?
    var_placeholders = ",".join("?" * len(set_vars))
    clear_rows = conn.execute(
        f"SELECT DISTINCT ss.var_name, s.id AS cleared_in_script_id, s.name AS cleared_in_script "
        f"FROM script_step ss JOIN script s ON s.id=ss.script_id "
        f"WHERE ss.script_id IN ({placeholders}) "
        f"  AND ss.var_name IN ({var_placeholders}) "
        f"  AND ss.step_type_name='Set Variable' "
        f"  AND (ss.step_text LIKE '%; Value:\"\" ]' OR ss.step_text LIKE '%; Value: \"\" ]' "
        f"       OR ss.step_text LIKE '%; Value:]' OR ss.step_text LIKE '%; Value: ]')",
        callee_ids + list(set_vars),
    ).fetchall()
    cleared: dict[str, list[dict]] = {}
    for r in clear_rows:
        cleared.setdefault(r["var_name"], []).append(
            {"script_id": r["cleared_in_script_id"], "script_name": r["cleared_in_script"]}
        )

    root_row = conn.execute("SELECT name, folder FROM script WHERE id=?", (script_id,)).fetchone()
    root_name = root_row["name"] if root_row else str(script_id)

    results = []
    for var in sorted(set_vars):
        if var in cleared:
            for entry in cleared[var]:
                results.append({
                    "script_id": script_id,
                    "script_name": root_name,
                    "var_name": var,
                    "cleared": True,
                    "cleared_in_script_id": entry["script_id"],
                    "cleared_in_script": entry["script_name"],
                })
        else:
            results.append({
                "script_id": script_id,
                "script_name": root_name,
                "var_name": var,
                "cleared": False,
                "cleared_in_script_id": None,
                "cleared_in_script": None,
            })
    return results


def script_chain_mermaid(
    conn: sqlite3.Connection,
    script_id: int,
    *,
    max_depth: int = 5,
    direction: str = "down",
) -> str:
    """Return a Mermaid flowchart string for the call chain around a script.

    direction: "down"  — callees only (default)
               "up"    — callers only
               "both"  — full neighbourhood
    max_depth limits BFS expansion from the root node.
    Cycles are broken by not re-expanding already-visited nodes.
    """
    if direction not in ("down", "up", "both"):
        raise ValueError(f"direction must be 'down', 'up', or 'both', got {direction!r}")

    nodes: dict[int, tuple[str, str | None]] = {}   # id -> (name, folder)
    edges: list[tuple[int, int]] = []               # (caller_id, callee_id)
    edge_set: set[tuple[int, int]] = set()
    visited: set[int] = set()
    queue: deque[tuple[int, int]] = deque([(script_id, 0)])

    def _load_node(sid: int) -> None:
        if sid in nodes:
            return
        row = conn.execute(
            "SELECT name, folder FROM script WHERE id = ?", (sid,)
        ).fetchone()
        if row:
            nodes[sid] = (row["name"], row["folder"])
        else:
            nodes[sid] = (f"script:{sid}", None)

    def _add_edge(src: int, dst: int) -> None:
        if (src, dst) not in edge_set:
            edge_set.add((src, dst))
            edges.append((src, dst))

    while queue:
        sid, depth = queue.popleft()
        if sid in visited:
            continue
        visited.add(sid)
        _load_node(sid)

        if depth >= max_depth:
            continue

        if direction in ("down", "both"):
            for row in conn.execute(
                "SELECT DISTINCT s.id, s.name, s.folder "
                "FROM script_ref sr JOIN script s ON s.id = sr.callee_id "
                "WHERE sr.caller_kind = 'script_step' AND sr.caller_id = ? "
                "ORDER BY sr.caller_sub",
                (sid,),
            ).fetchall():
                cid = row["id"]
                _load_node(cid)
                _add_edge(sid, cid)
                if cid not in visited:
                    queue.append((cid, depth + 1))

        if direction in ("up", "both"):
            for row in conn.execute(
                "SELECT DISTINCT s.id, s.name, s.folder "
                "FROM script_ref sr JOIN script s ON s.id = sr.caller_id "
                "WHERE sr.caller_kind = 'script_step' AND sr.callee_id = ?",
                (sid,),
            ).fetchall():
                cid = row["id"]
                _load_node(cid)
                _add_edge(cid, sid)
                if cid not in visited:
                    queue.append((cid, depth + 1))

    def _mermaid_label(name: str, folder: str | None) -> str:
        label = name.replace('"', "#quot;")
        if folder:
            label += f"\\n({folder.replace(chr(34), '#quot;')})"
        return label

    lines = ["flowchart TD"]
    for sid, (name, folder) in nodes.items():
        marker = "((( )))" if sid == script_id else ""  # root gets stadium shape
        if sid == script_id:
            lines.append(f'    S{sid}(["**{_mermaid_label(name, folder)}**"])')
        else:
            lines.append(f'    S{sid}["{_mermaid_label(name, folder)}"]')
    lines.append("")
    for src, dst in edges:
        lines.append(f"    S{src} --> S{dst}")
    return "\n".join(lines)
