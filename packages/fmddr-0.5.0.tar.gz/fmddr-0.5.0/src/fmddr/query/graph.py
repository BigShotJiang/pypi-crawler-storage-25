"""Relationship graph queries — TOs, relationships, predicates, paths."""
from __future__ import annotations

import sqlite3
from collections import defaultdict, deque


def list_tos(
    conn: sqlite3.Connection, *, base_table_id: int | None = None
) -> list[dict]:
    sql = (
        "SELECT toc.id, toc.name, toc.color, "
        "       toc.base_table_id, bt.name AS base_table_name "
        "FROM table_occurrence toc "
        "LEFT JOIN base_table bt ON bt.id = toc.base_table_id"
    )
    args: list = []
    if base_table_id is not None:
        sql += " WHERE toc.base_table_id = ?"
        args.append(base_table_id)
    sql += " ORDER BY toc.name"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def list_relationships(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT r.id, "
        "       lt.name AS left_to, rt.name AS right_to, "
        "       (SELECT COUNT(*) FROM join_predicate jp WHERE jp.relationship_id=r.id) AS predicate_count "
        "FROM relationship r "
        "JOIN table_occurrence lt ON lt.id = r.left_to_id "
        "JOIN table_occurrence rt ON rt.id = r.right_to_id "
        "ORDER BY lt.name, rt.name"
    ).fetchall()
    return [dict(r) for r in rows]


def predicates_for(conn: sqlite3.Connection, relationship_id: int) -> list[dict]:
    rows = conn.execute(
        "SELECT jp.operator, "
        "       lf.name AS left_field, lbt.name AS left_table, "
        "       rf.name AS right_field, rbt.name AS right_table "
        "FROM join_predicate jp "
        "LEFT JOIN field lf ON lf.id = jp.left_field_id "
        "LEFT JOIN base_table lbt ON lbt.id = lf.base_table_id "
        "LEFT JOIN field rf ON rf.id = jp.right_field_id "
        "LEFT JOIN base_table rbt ON rbt.id = rf.base_table_id "
        "WHERE jp.relationship_id = ?",
        (relationship_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def to_path(
    conn: sqlite3.Connection, from_to_id: int, to_to_id: int, *, max_hops: int = 6
) -> list[dict] | None:
    """Shortest TO→TO path through relationships. Undirected. Returns the
    list of TO ids/names along the path, or None if unreachable.
    """
    adj: dict[int, set[int]] = defaultdict(set)
    for left, right in conn.execute("SELECT left_to_id, right_to_id FROM relationship"):
        adj[left].add(right)
        adj[right].add(left)
    if from_to_id not in adj and from_to_id != to_to_id:
        return None
    seen = {from_to_id}
    parent: dict[int, int] = {}
    q = deque([(from_to_id, 0)])
    while q:
        cur, d = q.popleft()
        if cur == to_to_id:
            # reconstruct
            path = [cur]
            while path[-1] in parent:
                path.append(parent[path[-1]])
            path.reverse()
            names = {
                r[0]: r[1]
                for r in conn.execute(
                    "SELECT id,name FROM table_occurrence WHERE id IN ("
                    + ",".join("?" for _ in path) + ")",
                    tuple(path),
                )
            }
            return [{"id": tid, "name": names.get(tid)} for tid in path]
        if d >= max_hops:
            continue
        for n in adj[cur]:
            if n not in seen:
                seen.add(n)
                parent[n] = cur
                q.append((n, d + 1))
    return None
