"""Field reference queries — the FMPerception drill paths."""
from __future__ import annotations

import sqlite3


def field_references(
    conn: sqlite3.Connection, field_id: int, *, kind: str | None = None
) -> list[dict]:
    """All references to this field, grouped per row by owner_kind.

    Returns a denormalized list with enough context to identify the owner
    (script + step, layout + object, table + field, etc.).
    """
    sql = (
        "SELECT fr.owner_kind, fr.owner_id, fr.owner_sub, fr.via_to_id, "
        "       toc.name AS via_to_name, "
        "       s.id AS script_id, s.name AS script_name, s.folder AS script_folder, "
        "       ss.step_text, ss.step_type_name, ss.fm_line, "
        "       l.id AS layout_id, l.name AS layout_name, l.folder AS layout_folder, "
        "       ofield.id AS owner_field_id, ofield.name AS owner_field_name, "
        "       obt.name AS owner_field_table, "
        "       cf.id AS owner_cf_id, cf.name AS owner_cf_name, "
        "       vl.id AS owner_vl_id, vl.name AS owner_vl_name "
        "FROM field_ref fr "
        "LEFT JOIN table_occurrence toc ON toc.id = fr.via_to_id "
        "LEFT JOIN script s   ON fr.owner_kind='script_step' AND s.id = fr.owner_id "
        "LEFT JOIN script_step ss ON fr.owner_kind='script_step' "
        "                          AND ss.script_id = fr.owner_id AND ss.step_index = fr.owner_sub "
        "LEFT JOIN layout l   ON fr.owner_kind='layout_object' AND l.id = fr.owner_id "
        "LEFT JOIN field ofield ON fr.owner_kind IN ('field_calc','field_autoenter','field_validation') "
        "                       AND ofield.id = fr.owner_id "
        "LEFT JOIN base_table obt ON obt.id = ofield.base_table_id "
        "LEFT JOIN custom_function cf ON fr.owner_kind='custom_function' AND cf.id = fr.owner_id "
        "LEFT JOIN value_list vl ON fr.owner_kind='value_list' AND vl.id = fr.owner_id "
        "WHERE fr.field_id = ?"
    )
    args: list = [field_id]
    if kind:
        sql += " AND fr.owner_kind = ?"
        args.append(kind)
    sql += " ORDER BY fr.owner_kind, fr.owner_id, fr.owner_sub"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def field_script_refs(conn: sqlite3.Connection, field_id: int) -> list[dict]:
    """Step-level rows: one per (script, step) that references the field."""
    rows = conn.execute(
        "SELECT DISTINCT s.id AS script_id, s.name AS script_name, s.folder, "
        "       ss.step_index, ss.fm_line, ss.step_type_name, ss.step_text, "
        "       fr.via_to_id, toc.name AS via_to_name "
        "FROM field_ref fr "
        "JOIN script_step ss ON ss.script_id = fr.owner_id AND ss.step_index = fr.owner_sub "
        "JOIN script s ON s.id = ss.script_id "
        "LEFT JOIN table_occurrence toc ON toc.id = fr.via_to_id "
        "WHERE fr.owner_kind = 'script_step' AND fr.field_id = ? "
        "ORDER BY s.folder, s.name, ss.step_index",
        (field_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def field_on_layouts(conn: sqlite3.Connection, field_id: int) -> list[dict]:
    """Distinct layouts that reference this field via any object."""
    rows = conn.execute(
        "SELECT DISTINCT l.id, l.name, l.folder "
        "FROM field_ref fr "
        "JOIN layout l ON l.id = fr.owner_id "
        "WHERE fr.owner_kind = 'layout_object' AND fr.field_id = ? "
        "ORDER BY l.folder, l.name",
        (field_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def field_field_refs(conn: sqlite3.Connection, field_id: int) -> list[dict]:
    """Other fields whose calc/autoenter/validation names this field."""
    rows = conn.execute(
        "SELECT DISTINCT f.id, f.name, bt.name AS table_name, fr.owner_kind "
        "FROM field_ref fr "
        "JOIN field f ON f.id = fr.owner_id "
        "JOIN base_table bt ON bt.id = f.base_table_id "
        "WHERE fr.field_id = ? "
        "  AND fr.owner_kind IN ('field_calc','field_autoenter','field_validation') "
        "ORDER BY bt.name, f.name",
        (field_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def field_where(conn: sqlite3.Connection, field_id: int) -> list[dict]:
    """Superset summary, grouped by owner_kind."""
    rows = conn.execute(
        "SELECT owner_kind, COUNT(*) AS count "
        "FROM field_ref WHERE field_id = ? "
        "GROUP BY owner_kind ORDER BY owner_kind",
        (field_id,),
    ).fetchall()
    return [dict(r) for r in rows]
