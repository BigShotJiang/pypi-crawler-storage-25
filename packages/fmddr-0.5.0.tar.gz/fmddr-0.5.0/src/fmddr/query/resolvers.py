"""name|id → (kind, id) resolution with ambiguity handling.

Exit codes (mirrored in cli.py):
    1  not found
    2  ambiguous
"""
from __future__ import annotations

import sqlite3


class NotFound(Exception):
    pass


class Ambiguous(Exception):
    def __init__(self, message: str, candidates: list[dict]) -> None:
        super().__init__(message)
        self.candidates = candidates


def _maybe_id(token: str) -> int | None:
    t = token.strip().lstrip("#")
    if t.isdigit():
        return int(t)
    return None


def resolve_table(conn: sqlite3.Connection, token: str) -> dict:
    tid = _maybe_id(token)
    if tid is not None:
        row = conn.execute(
            "SELECT id,name,records FROM base_table WHERE id = ?", (tid,)
        ).fetchone()
        if row is None:
            raise NotFound(f"No base table with id {tid}")
        return dict(row)
    rows = conn.execute(
        "SELECT id,name,records FROM base_table WHERE name = ?", (token,)
    ).fetchall()
    if not rows:
        raise NotFound(f"No base table named {token!r}")
    if len(rows) > 1:
        raise Ambiguous(f"{len(rows)} tables named {token!r}", [dict(r) for r in rows])
    return dict(rows[0])


def resolve_field(conn: sqlite3.Connection, token: str) -> dict:
    """Accepts: numeric id, "Table::Field", or bare field name (must be unique)."""
    fid = _maybe_id(token)
    if fid is not None:
        row = conn.execute(
            "SELECT f.*, bt.name AS table_name FROM field f "
            "JOIN base_table bt ON bt.id = f.base_table_id WHERE f.id = ?",
            (fid,),
        ).fetchone()
        if row is None:
            raise NotFound(f"No field with id {fid}")
        return dict(row)

    if "::" in token:
        table_name, field_name = token.split("::", 1)
        row = conn.execute(
            "SELECT f.*, bt.name AS table_name FROM field f "
            "JOIN base_table bt ON bt.id = f.base_table_id "
            "WHERE bt.name = ? AND f.name = ?",
            (table_name, field_name),
        ).fetchone()
        if row is None:
            raise NotFound(f"No field {field_name!r} on table {table_name!r}")
        return dict(row)

    rows = conn.execute(
        "SELECT f.*, bt.name AS table_name FROM field f "
        "JOIN base_table bt ON bt.id = f.base_table_id WHERE f.name = ?",
        (token,),
    ).fetchall()
    if not rows:
        raise NotFound(f"No field named {token!r}")
    if len(rows) > 1:
        raise Ambiguous(
            f"{len(rows)} fields named {token!r} — qualify with Table::Field",
            [{"id": r["id"], "table": r["table_name"], "name": r["name"]} for r in rows],
        )
    return dict(rows[0])


def resolve_script(conn: sqlite3.Connection, token: str) -> dict:
    sid = _maybe_id(token)
    if sid is not None:
        row = conn.execute("SELECT * FROM script WHERE id = ?", (sid,)).fetchone()
        if row is None:
            raise NotFound(f"No script with id {sid}")
        return dict(row)
    # Optional folder/name path form.
    if "/" in token:
        folder, name = token.rsplit("/", 1)
        rows = conn.execute(
            "SELECT * FROM script WHERE folder = ? AND name = ?", (folder, name)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM script WHERE name = ?", (token,)).fetchall()
    if not rows:
        raise NotFound(f"No script named {token!r}")
    if len(rows) > 1:
        raise Ambiguous(
            f"{len(rows)} scripts named {token!r} — qualify with folder/name",
            [{"id": r["id"], "folder": r["folder"], "name": r["name"]} for r in rows],
        )
    return dict(rows[0])


def resolve_layout(conn: sqlite3.Connection, token: str) -> dict:
    lid = _maybe_id(token)
    if lid is not None:
        row = conn.execute("SELECT * FROM layout WHERE id = ?", (lid,)).fetchone()
        if row is None:
            raise NotFound(f"No layout with id {lid}")
        return dict(row)
    rows = conn.execute("SELECT * FROM layout WHERE name = ?", (token,)).fetchall()
    if not rows:
        raise NotFound(f"No layout named {token!r}")
    if len(rows) > 1:
        raise Ambiguous(
            f"{len(rows)} layouts named {token!r} — qualify with folder/name or id",
            [{"id": r["id"], "folder": r["folder"], "name": r["name"]} for r in rows],
        )
    return dict(rows[0])
