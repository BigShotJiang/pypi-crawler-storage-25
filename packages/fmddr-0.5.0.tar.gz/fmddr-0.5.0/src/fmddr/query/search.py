"""FTS-backed name + script-text search."""
from __future__ import annotations

import re
import sqlite3


def search_names(
    conn: sqlite3.Connection, query: str, *, kind: str | None = None, limit: int = 50
) -> list[dict]:
    """FTS5 over object names. `query` is FTS5 syntax (`foo*`, `"exact"`)."""
    sql = "SELECT kind, id, name, folder, comment FROM name_fts WHERE name_fts MATCH ?"
    args: list = [query]
    if kind:
        sql += " AND kind = ?"
        args.append(kind)
    sql += f" LIMIT {int(limit)}"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def script_grep(
    conn: sqlite3.Connection, script_id: int, pattern: str
) -> list[dict]:
    """Regex-search every step's text + calc bodies in a script."""
    rx = re.compile(pattern, re.IGNORECASE)
    rows = conn.execute(
        "SELECT step_index, fm_line, step_type_name, step_text "
        "FROM script_step WHERE script_id = ? ORDER BY step_index",
        (script_id,),
    ).fetchall()
    out: list[dict] = []
    for r in rows:
        text = r["step_text"] or ""
        if rx.search(text):
            out.append({
                "step_index": r["step_index"],
                "fm_line": r["fm_line"],
                "step_type": r["step_type_name"],
                "step_text": text,
            })
    return out
