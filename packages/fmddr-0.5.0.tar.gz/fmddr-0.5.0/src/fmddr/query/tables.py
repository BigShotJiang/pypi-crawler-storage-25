"""Table + field queries."""
from __future__ import annotations

import sqlite3


def list_tables(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT bt.id, bt.name, bt.records, "
        "       (SELECT COUNT(*) FROM field f WHERE f.base_table_id = bt.id) AS fields "
        "FROM base_table bt ORDER BY bt.name"
    ).fetchall()
    return [dict(r) for r in rows]


def get_table(conn: sqlite3.Connection, base_table_id: int) -> dict:
    row = conn.execute(
        "SELECT bt.id, bt.name, bt.records, "
        "       (SELECT COUNT(*) FROM field f WHERE f.base_table_id = bt.id) AS fields, "
        "       (SELECT COUNT(*) FROM field f WHERE f.base_table_id = bt.id "
        "         AND f.field_type = 'Calculated') AS calc_fields, "
        "       (SELECT COUNT(*) FROM field f WHERE f.base_table_id = bt.id "
        "         AND f.is_unstored = 1) AS unstored_calc "
        "FROM base_table bt WHERE bt.id = ?",
        (base_table_id,),
    ).fetchone()
    return dict(row) if row else {}


def table_fields(
    conn: sqlite3.Connection,
    base_table_id: int,
    *,
    field_type: str | None = None,
    only_unstored: bool = False,
) -> list[dict]:
    sql = (
        "SELECT id, name, data_type, field_type, is_global, is_unstored, "
        "       repetitions, comment "
        "FROM field WHERE base_table_id = ?"
    )
    args: list = [base_table_id]
    if field_type:
        sql += " AND field_type = ?"
        args.append(field_type)
    if only_unstored:
        sql += " AND is_unstored = 1"
    sql += " ORDER BY name"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]
