"""Per-entity-type modified-payload computation + change tags.

Tags help CI consumers triage:
- ``shape``    — schema-breaking (field type, relationship predicates, CF parameters)
- ``behavior`` — logic change (calc text, script steps, CF body, layout body)
- ``cosmetic`` — comment/color/folder/theme only
"""
from __future__ import annotations


def _delta(old: dict, new: dict, keys: tuple[str, ...]) -> dict:
    return {k: [old.get(k), new.get(k)] for k in keys if old.get(k) != new.get(k)}


def diff_base_table(old: dict, new: dict) -> dict | None:
    delta = _delta(old, new, ("name", "records"))
    if not delta:
        return None
    tags = ["shape"] if "name" in delta else ["cosmetic"]
    return {"delta": delta, "tags": tags}


_FIELD_SHAPE = {"data_type", "field_type", "is_global", "repetitions"}
_FIELD_BEHAVIOR = {"calc_text", "auto_enter_calc", "is_unstored"}
_FIELD_COSMETIC = {"comment"}


def diff_field(old: dict, new: dict) -> dict | None:
    delta = _delta(old, new, (
        "name", "table", "data_type", "field_type", "is_global", "is_unstored",
        "auto_enter_calc", "calc_text", "comment", "repetitions",
    ))
    if not delta:
        return None
    tags: set[str] = set()
    if any(k in _FIELD_SHAPE for k in delta) or "table" in delta:
        tags.add("shape")
    if any(k in _FIELD_BEHAVIOR for k in delta):
        tags.add("behavior")
    if not tags and all(k in _FIELD_COSMETIC or k == "name" for k in delta):
        tags.add("cosmetic")
    return {"delta": delta, "tags": sorted(tags) or ["cosmetic"]}


def diff_table_occurrence(old: dict, new: dict) -> dict | None:
    delta = _delta(old, new, ("name", "base_table", "file_ref_id", "color", "folder"))
    if not delta:
        return None
    tags = []
    if "base_table" in delta or "file_ref_id" in delta:
        tags.append("shape")
    if not tags:
        tags.append("cosmetic")
    return {"delta": delta, "tags": tags}


def diff_relationship(old: dict, new: dict) -> dict | None:
    delta = _delta(old, new, (
        "left_to", "right_to", "predicates",
        "allow_create_left", "allow_create_right",
        "allow_delete_left", "allow_delete_right",
        "sort_left", "sort_right",
    ))
    if not delta:
        return None
    tags = []
    if "predicates" in delta or "left_to" in delta or "right_to" in delta:
        tags.append("shape")
    if any(k.startswith("allow_") or k.startswith("sort_") for k in delta):
        tags.append("behavior")
    return {"delta": delta, "tags": sorted(tags) or ["cosmetic"]}


def diff_script(old: dict, new: dict) -> dict | None:
    prop_delta = _delta(old, new, ("name", "folder", "include_in_menu", "full_access"))
    o_steps = old.get("steps") or []
    n_steps = new.get("steps") or []
    o_by_idx = {s["step_index"]: s for s in o_steps}
    n_by_idx = {s["step_index"]: s for s in n_steps}
    step_changes: list[dict] = []
    for idx in sorted(set(o_by_idx) | set(n_by_idx)):
        o, n = o_by_idx.get(idx), n_by_idx.get(idx)
        if o is None:
            step_changes.append({"step_index": idx, "change": "added", "step": n})
        elif n is None:
            step_changes.append({"step_index": idx, "change": "removed", "step": o})
        elif (
            o.get("step_type_name") != n.get("step_type_name")
            or o.get("step_text") != n.get("step_text")
            or o.get("enabled") != n.get("enabled")
        ):
            step_changes.append({"step_index": idx, "change": "modified", "old": o, "new": n})
    if not prop_delta and not step_changes:
        return None
    tags: set[str] = set()
    if step_changes or "include_in_menu" in prop_delta or "full_access" in prop_delta:
        tags.add("behavior")
    if "folder" in prop_delta or "name" in prop_delta:
        tags.add("cosmetic")
    return {
        "delta": prop_delta,
        "step_changes": step_changes,
        "step_count": [len(o_steps), len(n_steps)],
        "tags": sorted(tags) or ["behavior"],
    }


def diff_layout(old: dict, new: dict) -> dict | None:
    delta = _delta(old, new, ("name", "folder", "theme", "width", "raw_xml_hash"))
    if not delta:
        return None
    tags: list[str] = []
    if "raw_xml_hash" in delta:
        tags.append("behavior")
    if "folder" in delta or "name" in delta or "theme" in delta:
        tags.append("cosmetic")
    return {"delta": delta, "tags": sorted(set(tags))}


def diff_custom_function(old: dict, new: dict) -> dict | None:
    delta = _delta(old, new, ("name", "parameters", "body"))
    if not delta:
        return None
    tags: list[str] = []
    if "parameters" in delta:
        tags.append("shape")
    if "body" in delta:
        tags.append("behavior")
    if not tags:
        tags.append("cosmetic")
    return {"delta": delta, "tags": sorted(set(tags))}


def diff_value_list(old: dict, new: dict) -> dict | None:
    delta = _delta(old, new, ("name", "source", "field_id", "raw_xml_hash"))
    if not delta:
        return None
    tags = ["shape"] if "source" in delta or "field_id" in delta else ["behavior"]
    return {"delta": delta, "tags": tags}


DIFFERS = {
    "base_table": diff_base_table,
    "field": diff_field,
    "table_occurrence": diff_table_occurrence,
    "relationship": diff_relationship,
    "script": diff_script,
    "layout": diff_layout,
    "custom_function": diff_custom_function,
    "value_list": diff_value_list,
}
