"""Structured diff between two fmddr index DBs.

Output schema is stable and ordered for CI consumers:

    {
      "schema_version": 1,
      "summary": {
        "total_changes": N,
        "by_kind":  {"added": N, "removed": N, "renamed": N, "modified": N},
        "by_tag":   {"shape": N, "behavior": N, "cosmetic": N, "refs": N},
        "by_entity_type": {"<kind>": {"added": N, ...}, ...}
      },
      "entities": {
        "<kind>": {
          "added":    [{"key", "id", "name"}, ...],
          "removed":  [{"key", "id", "name", "impact"?}, ...],
          "renamed":  [{"from_key", "to_key", "id"}, ...],
          "modified": [{"key", "id", "delta", "tags", "impact"?, ...}, ...]
        }
      }
    }
"""
from __future__ import annotations

import sqlite3

from . import entity_diff, impact, match

ENTITY_TYPES = (
    "base_table",
    "field",
    "table_occurrence",
    "relationship",
    "script",
    "layout",
    "custom_function",
    "value_list",
)

SCHEMA_VERSION = 1


def compute_diff(
    old_conn: sqlite3.Connection,
    new_conn: sqlite3.Connection,
    *,
    detect_renames: bool = True,
    include_impact: bool = True,
) -> dict:
    entities: dict[str, dict] = {}
    by_kind = {"added": 0, "removed": 0, "renamed": 0, "modified": 0}
    by_tag: dict[str, int] = {"shape": 0, "behavior": 0, "cosmetic": 0, "refs": 0}
    by_entity_type: dict[str, dict] = {}

    for kind in ENTITY_TYPES:
        fetcher = match.FETCHERS[kind]
        old = fetcher(old_conn)
        new = fetcher(new_conn)

        added_keys = sorted(set(new) - set(old))
        removed_keys = sorted(set(old) - set(new))
        common_keys = sorted(set(old) & set(new))

        renamed_pairs: list[tuple[str, str]] = []
        if detect_renames and removed_keys and added_keys:
            renamed_pairs = match.detect_renames(
                {k: old[k] for k in removed_keys},
                {k: new[k] for k in added_keys},
                kind,
            )
            renamed_old = {p[0] for p in renamed_pairs}
            renamed_new = {p[1] for p in renamed_pairs}
            added_keys = [k for k in added_keys if k not in renamed_new]
            removed_keys = [k for k in removed_keys if k not in renamed_old]

        differ = entity_diff.DIFFERS.get(kind)
        modified: list[dict] = []
        for key in common_keys:
            if differ is None:
                continue
            d = differ(old[key], new[key])
            if d is None:
                continue
            entry = {"key": key, "id": new[key].get("id"), **d}
            if include_impact and kind in impact.IMPACT_FNS:
                imp = impact.IMPACT_FNS[kind](new_conn, new[key]["id"])
                if imp:
                    entry["impact"] = imp
            modified.append(entry)

        added = [
            {"key": k, "id": new[k].get("id"), "name": new[k].get("name")}
            for k in added_keys
        ]
        removed_list: list[dict] = []
        for k in removed_keys:
            entry = {"key": k, "id": old[k].get("id"), "name": old[k].get("name")}
            if include_impact and kind in impact.IMPACT_FNS:
                imp = impact.IMPACT_FNS[kind](old_conn, old[k]["id"])
                if imp:
                    entry["impact"] = imp
            removed_list.append(entry)

        renamed = [
            {"from_key": ok, "to_key": nk, "id": new[nk].get("id")}
            for ok, nk in sorted(renamed_pairs)
        ]

        if added or removed_list or renamed or modified:
            entities[kind] = {
                "added": added,
                "removed": removed_list,
                "renamed": renamed,
                "modified": modified,
            }

        bucket = {
            "added": len(added),
            "removed": len(removed_list),
            "renamed": len(renamed),
            "modified": len(modified),
        }
        if any(bucket.values()):
            by_entity_type[kind] = bucket
        for k, v in bucket.items():
            by_kind[k] += v
        for m in modified:
            for tag in m.get("tags", []):
                by_tag[tag] = by_tag.get(tag, 0) + 1

    return {
        "schema_version": SCHEMA_VERSION,
        "summary": {
            "total_changes": sum(by_kind.values()),
            "by_kind": by_kind,
            "by_tag": by_tag,
            "by_entity_type": by_entity_type,
        },
        "entities": entities,
    }


__all__ = ["compute_diff", "SCHEMA_VERSION", "ENTITY_TYPES"]
