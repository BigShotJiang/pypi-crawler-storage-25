"""Per-change blast-radius rollup.

For each modified/removed entity that has a reference graph (field, script,
custom_function, layout, table_occurrence, value_list), join the corresponding
ref table and emit names of the dependent entities.
"""
from __future__ import annotations

import sqlite3


def _names(conn: sqlite3.Connection, table: str, ids: set[int]) -> list[dict]:
    if not ids:
        return []
    ph = ",".join("?" * len(ids))
    return [
        {"id": r["id"], "name": r["name"]}
        for r in conn.execute(
            f"SELECT id, name FROM {table} WHERE id IN ({ph}) ORDER BY name",
            tuple(ids),
        )
    ]


def _by_kind(rows) -> dict[str, set[int]]:
    out: dict[str, set[int]] = {}
    for r in rows:
        out.setdefault(r[0], set()).add(r[1])
    return out


def impact_field(conn: sqlite3.Connection, field_id: int) -> dict:
    rows = conn.execute(
        "SELECT owner_kind, owner_id FROM field_ref WHERE field_id=?", (field_id,)
    ).fetchall()
    bk = _by_kind((r["owner_kind"], r["owner_id"]) for r in rows)
    out: dict[str, list] = {}
    if "script_step" in bk:
        out["scripts"] = _names(conn, "script", bk["script_step"])
    if "layout_object" in bk:
        out["layouts"] = _names(conn, "layout", bk["layout_object"])
    if "relationship_predicate" in bk:
        rids = bk["relationship_predicate"]
        ph = ",".join("?" * len(rids))
        out["relationships"] = [
            {
                "id": r["id"],
                "left_to": r["left_to"],
                "right_to": r["right_to"],
            }
            for r in conn.execute(
                f"SELECT r.id, lt.name AS left_to, rt.name AS right_to "
                f"FROM relationship r "
                f"JOIN table_occurrence lt ON lt.id=r.left_to_id "
                f"JOIN table_occurrence rt ON rt.id=r.right_to_id "
                f"WHERE r.id IN ({ph}) ORDER BY r.id",
                tuple(rids),
            )
        ]
    if "custom_function" in bk:
        out["custom_functions"] = _names(conn, "custom_function", bk["custom_function"])
    if "value_list" in bk:
        out["value_lists"] = _names(conn, "value_list", bk["value_list"])
    fields = (
        bk.get("field_calc", set())
        | bk.get("field_autoenter", set())
        | bk.get("field_validation", set())
    )
    if fields:
        out["fields"] = _names(conn, "field", fields)
    return out


def impact_script(conn: sqlite3.Connection, script_id: int) -> dict:
    rows = conn.execute(
        "SELECT DISTINCT caller_kind, caller_id FROM script_ref WHERE callee_id=?",
        (script_id,),
    ).fetchall()
    bk = _by_kind((r["caller_kind"], r["caller_id"]) for r in rows)
    out: dict[str, list] = {}
    if "script_step" in bk:
        out["scripts"] = _names(conn, "script", bk["script_step"])
    layouts = bk.get("layout_trigger", set()) | bk.get("layout_button", set())
    if layouts:
        out["layouts"] = _names(conn, "layout", layouts)
    return out


def impact_custom_function(conn: sqlite3.Connection, cf_id: int) -> dict:
    rows = conn.execute(
        "SELECT caller_kind, caller_id FROM custom_function_ref WHERE function_id=?",
        (cf_id,),
    ).fetchall()
    bk = _by_kind((r["caller_kind"], r["caller_id"]) for r in rows)
    out: dict[str, list] = {}
    if "script_step" in bk:
        out["scripts"] = _names(conn, "script", bk["script_step"])
    fields = bk.get("field_calc", set()) | bk.get("field_autoenter", set())
    if fields:
        out["fields"] = _names(conn, "field", fields)
    if "custom_function" in bk:
        out["custom_functions"] = _names(conn, "custom_function", bk["custom_function"])
    return out


def impact_layout(conn: sqlite3.Connection, layout_id: int) -> dict:
    rows = conn.execute(
        "SELECT caller_kind, caller_id FROM layout_ref WHERE layout_id=?", (layout_id,)
    ).fetchall()
    bk = _by_kind((r["caller_kind"], r["caller_id"]) for r in rows)
    out: dict[str, list] = {}
    if "script_step" in bk:
        out["scripts"] = _names(conn, "script", bk["script_step"])
    return out


def impact_table_occurrence(conn: sqlite3.Connection, to_id: int) -> dict:
    rows = conn.execute(
        "SELECT caller_kind, caller_id FROM table_ref WHERE table_occurrence_id=?",
        (to_id,),
    ).fetchall()
    bk = _by_kind((r["caller_kind"], r["caller_id"]) for r in rows)
    out: dict[str, list] = {}
    if "script_step" in bk:
        out["scripts"] = _names(conn, "script", bk["script_step"])
    if "layout_object" in bk:
        out["layouts"] = _names(conn, "layout", bk["layout_object"])
    return out


def impact_value_list(conn: sqlite3.Connection, vl_id: int) -> dict:
    rows = conn.execute(
        "SELECT caller_kind, caller_id FROM value_list_ref WHERE value_list_id=?",
        (vl_id,),
    ).fetchall()
    bk = _by_kind((r["caller_kind"], r["caller_id"]) for r in rows)
    out: dict[str, list] = {}
    if "script_step" in bk:
        out["scripts"] = _names(conn, "script", bk["script_step"])
    if "layout_object" in bk:
        out["layouts"] = _names(conn, "layout", bk["layout_object"])
    return out


IMPACT_FNS = {
    "field": impact_field,
    "script": impact_script,
    "custom_function": impact_custom_function,
    "layout": impact_layout,
    "table_occurrence": impact_table_occurrence,
    "value_list": impact_value_list,
}
