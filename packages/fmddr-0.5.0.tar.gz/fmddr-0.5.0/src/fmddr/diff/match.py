"""Cross-snapshot identity keys + content fetchers + rename detection.

Raw FileMaker IDs aren't stable across re-indexes, so each entity is keyed by a
qualified text path that survives re-indexing (file name, table name, folder,
entity name). The fetchers return dicts keyed by that path with the columns the
diff layer needs.
"""
from __future__ import annotations

import hashlib
import sqlite3


def _hash(s: str | None) -> str:
    return hashlib.sha256((s or "").encode("utf-8")).hexdigest()


def _file_names(conn: sqlite3.Connection) -> dict[int, str]:
    return {r["id"]: r["name"] for r in conn.execute("SELECT id, name FROM file")}


def fetch_base_tables(conn: sqlite3.Connection) -> dict[str, dict]:
    files = _file_names(conn)
    out: dict[str, dict] = {}
    for r in conn.execute("SELECT id, file_id, name, records FROM base_table"):
        fn = files.get(r["file_id"], "?")
        key = f"{fn}::{r['name']}"
        out[key] = {"key": key, "id": r["id"], "name": r["name"], "records": r["records"]}
    return out


def fetch_fields(conn: sqlite3.Connection) -> dict[str, dict]:
    files = _file_names(conn)
    bts = {r["id"]: r["name"] for r in conn.execute("SELECT id, name FROM base_table")}
    out: dict[str, dict] = {}
    for r in conn.execute(
        "SELECT id, file_id, base_table_id, name, data_type, field_type, "
        "is_global, is_unstored, auto_enter_calc, calc_text, comment, repetitions "
        "FROM field"
    ):
        fn = files.get(r["file_id"], "?")
        bt = bts.get(r["base_table_id"], "?")
        key = f"{fn}::{bt}::{r['name']}"
        out[key] = {
            "key": key,
            "id": r["id"],
            "name": r["name"],
            "table": bt,
            "data_type": r["data_type"],
            "field_type": r["field_type"],
            "is_global": r["is_global"],
            "is_unstored": r["is_unstored"],
            "auto_enter_calc": r["auto_enter_calc"],
            "calc_text": r["calc_text"],
            "comment": r["comment"],
            "repetitions": r["repetitions"],
        }
    return out


def fetch_table_occurrences(conn: sqlite3.Connection) -> dict[str, dict]:
    files = _file_names(conn)
    bts = {r["id"]: r["name"] for r in conn.execute("SELECT id, name FROM base_table")}
    out: dict[str, dict] = {}
    for r in conn.execute(
        "SELECT id, file_id, name, base_table_id, file_ref_id, color, folder "
        "FROM table_occurrence"
    ):
        fn = files.get(r["file_id"], "?")
        key = f"{fn}::{r['name']}"
        out[key] = {
            "key": key,
            "id": r["id"],
            "name": r["name"],
            "base_table": bts.get(r["base_table_id"]),
            "file_ref_id": r["file_ref_id"],
            "color": r["color"],
            "folder": r["folder"],
        }
    return out


def fetch_relationships(conn: sqlite3.Connection) -> dict[str, dict]:
    files = _file_names(conn)
    tos = {r["id"]: r["name"] for r in conn.execute("SELECT id, name FROM table_occurrence")}
    fields = {r["id"]: r["name"] for r in conn.execute("SELECT id, name FROM field")}
    out: dict[str, dict] = {}
    for r in conn.execute(
        "SELECT id, file_id, left_to_id, right_to_id, "
        "allow_create_left, allow_create_right, "
        "allow_delete_left, allow_delete_right, sort_left, sort_right "
        "FROM relationship"
    ):
        fn = files.get(r["file_id"], "?")
        left = tos.get(r["left_to_id"], "?")
        right = tos.get(r["right_to_id"], "?")
        key = f"{fn}::{left}->{right}"
        preds = sorted(
            (
                fields.get(jp["left_field_id"]),
                jp["operator"],
                fields.get(jp["right_field_id"]),
            )
            for jp in conn.execute(
                "SELECT left_field_id, operator, right_field_id "
                "FROM join_predicate WHERE relationship_id=?",
                (r["id"],),
            )
        )
        out[key] = {
            "key": key,
            "id": r["id"],
            "left_to": left,
            "right_to": right,
            "allow_create_left": r["allow_create_left"],
            "allow_create_right": r["allow_create_right"],
            "allow_delete_left": r["allow_delete_left"],
            "allow_delete_right": r["allow_delete_right"],
            "sort_left": r["sort_left"],
            "sort_right": r["sort_right"],
            "predicates": preds,
        }
    return out


def fetch_scripts(conn: sqlite3.Connection) -> dict[str, dict]:
    files = _file_names(conn)
    out: dict[str, dict] = {}
    for r in conn.execute(
        "SELECT id, file_id, name, folder, include_in_menu, full_access FROM script"
    ):
        fn = files.get(r["file_id"], "?")
        key = f"{fn}::{r['folder'] or ''}/{r['name']}"
        steps = [
            {
                "step_index": s["step_index"],
                "step_type_name": s["step_type_name"],
                "enabled": s["enabled"],
                "step_text": s["step_text"],
            }
            for s in conn.execute(
                "SELECT step_index, step_type_name, enabled, step_text "
                "FROM script_step WHERE script_id=? ORDER BY step_index",
                (r["id"],),
            )
        ]
        joined = "\n".join((s["step_text"] or "") for s in steps)
        out[key] = {
            "key": key,
            "id": r["id"],
            "name": r["name"],
            "folder": r["folder"],
            "include_in_menu": r["include_in_menu"],
            "full_access": r["full_access"],
            "steps": steps,
            "step_text_hash": _hash(joined),
        }
    return out


def fetch_layouts(conn: sqlite3.Connection) -> dict[str, dict]:
    files = _file_names(conn)
    out: dict[str, dict] = {}
    for r in conn.execute(
        "SELECT id, file_id, name, folder, theme, width, raw_xml FROM layout"
    ):
        fn = files.get(r["file_id"], "?")
        key = f"{fn}::{r['folder'] or ''}/{r['name']}"
        out[key] = {
            "key": key,
            "id": r["id"],
            "name": r["name"],
            "folder": r["folder"],
            "theme": r["theme"],
            "width": r["width"],
            "raw_xml_hash": _hash(r["raw_xml"]),
        }
    return out


def fetch_custom_functions(conn: sqlite3.Connection) -> dict[str, dict]:
    files = _file_names(conn)
    out: dict[str, dict] = {}
    for r in conn.execute(
        "SELECT id, file_id, name, parameters, body FROM custom_function"
    ):
        fn = files.get(r["file_id"], "?")
        key = f"{fn}::{r['name']}"
        out[key] = {
            "key": key,
            "id": r["id"],
            "name": r["name"],
            "parameters": r["parameters"],
            "body": r["body"],
        }
    return out


def fetch_value_lists(conn: sqlite3.Connection) -> dict[str, dict]:
    files = _file_names(conn)
    out: dict[str, dict] = {}
    for r in conn.execute(
        "SELECT id, file_id, name, source, field_id, raw_xml FROM value_list"
    ):
        fn = files.get(r["file_id"], "?")
        key = f"{fn}::{r['name']}"
        out[key] = {
            "key": key,
            "id": r["id"],
            "name": r["name"],
            "source": r["source"],
            "field_id": r["field_id"],
            "raw_xml_hash": _hash(r["raw_xml"]),
        }
    return out


FETCHERS = {
    "base_table": fetch_base_tables,
    "field": fetch_fields,
    "table_occurrence": fetch_table_occurrences,
    "relationship": fetch_relationships,
    "script": fetch_scripts,
    "layout": fetch_layouts,
    "custom_function": fetch_custom_functions,
    "value_list": fetch_value_lists,
}


# Fingerprint columns used to pair removed/added entries as renames. Only the
# kinds with a meaningful body fingerprint participate; layouts/value_lists/TOs
# are too coarse for a reliable v1 heuristic.
_RENAME_FINGERPRINT = {
    "script": ("step_text_hash",),
    "field": ("table", "data_type", "field_type", "calc_text", "auto_enter_calc"),
    "custom_function": ("parameters", "body"),
}


def detect_renames(
    removed: dict[str, dict],
    added: dict[str, dict],
    kind: str,
) -> list[tuple[str, str]]:
    """Pair `(removed_key, added_key)` when their content fingerprints match.

    v1 is conservative: only exact fingerprint matches pair. Multiple removed
    entries with the same fingerprint pair to the first available added entry
    (deterministic by sorted key order).
    """
    cols = _RENAME_FINGERPRINT.get(kind)
    if not cols or not removed or not added:
        return []

    def fp(d: dict) -> tuple:
        return tuple(d.get(c) for c in cols)

    by_fp_added: dict[tuple, list[str]] = {}
    for k in sorted(added):
        by_fp_added.setdefault(fp(added[k]), []).append(k)
    pairs: list[tuple[str, str]] = []
    used: set[str] = set()
    for k in sorted(removed):
        cands = by_fp_added.get(fp(removed[k]), [])
        for c in cands:
            if c not in used:
                pairs.append((k, c))
                used.add(c)
                break
    return pairs
