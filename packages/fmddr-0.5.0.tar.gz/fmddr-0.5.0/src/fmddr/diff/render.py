"""Render a diff payload as JSON, markdown, or terminal text."""
from __future__ import annotations

import json
import sys


def render(diff: dict, fmt: str, *, old_meta: dict, new_meta: dict) -> None:
    if fmt == "json":
        payload = {
            "kind": "diff",
            "schema_version": diff["schema_version"],
            "old": old_meta,
            "new": new_meta,
            "summary": diff["summary"],
            "entities": diff["entities"],
        }
        sys.stdout.write(json.dumps(payload, indent=2, default=str, sort_keys=True) + "\n")
    elif fmt == "md":
        _render_md(diff, old_meta, new_meta)
    else:
        _render_text(diff, old_meta, new_meta)


def _short(v, n: int = 80) -> str:
    if v is None:
        return "∅"
    s = str(v).replace("\n", " ⏎ ")
    return s if len(s) <= n else s[: n - 1] + "…"


def _render_md(diff: dict, old_meta: dict, new_meta: dict) -> None:
    s = diff["summary"]
    bk = s["by_kind"]
    out = [
        "# fmddr diff",
        "",
        f"- old: `{old_meta.get('snapshot_label') or old_meta.get('path')}`",
        f"- new: `{new_meta.get('snapshot_label') or new_meta.get('path')}`",
        f"- total changes: **{s['total_changes']}** "
        f"(added {bk['added']}, removed {bk['removed']}, "
        f"renamed {bk['renamed']}, modified {bk['modified']})",
        "",
    ]
    for kind, buckets in diff["entities"].items():
        out.append(f"## {kind}")
        for bucket in ("added", "removed", "renamed", "modified"):
            items = buckets.get(bucket, [])
            if not items:
                continue
            out.append(f"### {bucket} ({len(items)})")
            for it in items:
                if bucket == "renamed":
                    out.append(f"- `{it['from_key']}` → `{it['to_key']}`")
                elif bucket == "modified":
                    tags = ",".join(it.get("tags", []))
                    out.append(f"- `{it['key']}` [{tags}]")
                    for k, pair in it.get("delta", {}).items():
                        a, b = pair
                        out.append(f"  - {k}: `{_short(a)}` → `{_short(b)}`")
                    sc = it.get("step_changes")
                    if sc:
                        out.append(f"  - {len(sc)} step change(s)")
                else:
                    out.append(f"- `{it['key']}`")
        out.append("")
    sys.stdout.write("\n".join(out) + "\n")


def _render_text(diff: dict, old_meta: dict, new_meta: dict) -> None:
    s = diff["summary"]
    bk = s["by_kind"]
    sys.stdout.write(
        f"fmddr diff: {s['total_changes']} changes "
        f"(+{bk['added']} -{bk['removed']} ~{bk['modified']} ↻{bk['renamed']})\n"
    )
    for kind, buckets in diff["entities"].items():
        sys.stdout.write(f"\n[{kind}]\n")
        for it in buckets.get("added", []):
            sys.stdout.write(f"  + {it['key']}\n")
        for it in buckets.get("removed", []):
            sys.stdout.write(f"  - {it['key']}\n")
        for it in buckets.get("renamed", []):
            sys.stdout.write(f"  ↻ {it['from_key']} → {it['to_key']}\n")
        for it in buckets.get("modified", []):
            sys.stdout.write(f"  ~ {it['key']} [{','.join(it.get('tags', []))}]\n")
            for prop, pair in it.get("delta", {}).items():
                a, b = pair
                sys.stdout.write(f"      {prop}: {_short(a)} → {_short(b)}\n")
            sc = it.get("step_changes")
            if sc:
                sys.stdout.write(f"      ({len(sc)} step change(s))\n")
