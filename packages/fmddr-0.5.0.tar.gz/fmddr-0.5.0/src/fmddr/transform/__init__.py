"""Transform DDR-shape XML to FileMaker clipboard-shape XML."""
