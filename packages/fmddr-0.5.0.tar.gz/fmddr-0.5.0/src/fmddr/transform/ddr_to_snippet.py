"""DDR-shape per-object XML  →  FileMaker clipboard <fmxmlsnippet>.

Supported v1 root tags: Script, BaseTable, CustomFunction.
Partial selection: a subset of <Step> children of a Script (ScriptStep snippet).
Single Field and LayoutObject selections are deferred.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET

from ..clipboard.snippet import (
    FileMakerClipboardError,
    detect_from_ddr_root,
    wrap_as_snippet,
)


SUPPORTED_ROOTS = {"Script", "BaseTable", "CustomFunction"}


def _flatten_step_list(script_el: ET.Element) -> None:
    """Replace <Script><StepList><Step/>...</StepList></Script> with <Script><Step/>...</Script>.

    Mutates `script_el` in place. No-op if there is no <StepList>.
    """
    step_list = script_el.find("StepList")
    if step_list is None:
        return
    idx = list(script_el).index(step_list)
    steps = list(step_list)
    script_el.remove(step_list)
    for offset, step in enumerate(steps):
        script_el.insert(idx + offset, step)


def transform_file_xml(xml: str) -> dict:
    """Convert a per-object DDR XML to a FileMaker clipboard snippet.

    Returns {snippet_xml, fm_type, ddr_root, warnings}. Raises FileMakerClipboardError
    on schema problems.
    """
    try:
        root = ET.fromstring(xml)
    except ET.ParseError as e:
        raise FileMakerClipboardError("INVALID_XML", f"XML parse error: {e}") from e

    root_tag = root.tag
    if root_tag not in SUPPORTED_ROOTS:
        raise FileMakerClipboardError(
            "UNSUPPORTED_ELEMENT_TYPE",
            f'DDR root <{root_tag}> not supported in v1. Supported: {sorted(SUPPORTED_ROOTS)}.',
        )

    fm_type = detect_from_ddr_root(root_tag)
    assert fm_type is not None  # SUPPORTED_ROOTS guarantees a mapping

    warnings: list[str] = []
    if fm_type == "Script":
        # FileMaker's native Script clipboard format nests <Step> directly
        # under <Script>; the DDR wraps them in <StepList>. Unwrap.
        _flatten_step_list(root)
    payload = ET.tostring(root, encoding="unicode")
    snippet = wrap_as_snippet(payload, fm_type)
    return {
        "snippet_xml": snippet,
        "fm_type": fm_type,
        "ddr_root": root_tag,
        "warnings": warnings,
    }


def parse_step_spec(spec: str) -> list[int]:
    """Parse a step selector like "5-12,15,18-19" into a sorted, de-duped 1-based list.

    Indices refer to raw <Step> order within the script's <StepList>, matching
    the convention used by `fmddr step show "<Script>:<index>"`.
    """
    if not spec or not spec.strip():
        raise FileMakerClipboardError("INVALID_STEP_SPEC", "Step selector is empty.")

    out: set[int] = set()
    for chunk in spec.split(","):
        token = chunk.strip()
        if not token:
            continue
        if "-" in token:
            lo_s, hi_s = token.split("-", 1)
            try:
                lo, hi = int(lo_s), int(hi_s)
            except ValueError as e:
                raise FileMakerClipboardError(
                    "INVALID_STEP_SPEC", f'Bad range "{token}" — expected integers.'
                ) from e
            if lo < 1 or hi < 1 or hi < lo:
                raise FileMakerClipboardError(
                    "INVALID_STEP_SPEC",
                    f'Bad range "{token}" — must be 1-based with lo <= hi.',
                )
            out.update(range(lo, hi + 1))
        else:
            try:
                n = int(token)
            except ValueError as e:
                raise FileMakerClipboardError(
                    "INVALID_STEP_SPEC", f'Bad index "{token}" — expected integer.'
                ) from e
            if n < 1:
                raise FileMakerClipboardError(
                    "INVALID_STEP_SPEC", f'Bad index "{token}" — must be >= 1.'
                )
            out.add(n)
    if not out:
        raise FileMakerClipboardError("INVALID_STEP_SPEC", "Step selector resolved to no indices.")
    return sorted(out)


def extract_steps_as_snippet(xml: str, indices: list[int] | None) -> dict:
    """Extract specified <Step> children of a <Script>'s <StepList> and wrap as ScriptStep.

    `indices` is 1-based, matching `fmddr step show "<Script>:<index>"`.
    Pass `None` to select every step in the script.
    Raises FileMakerClipboardError on parse, root, or out-of-range problems.
    """
    try:
        root = ET.fromstring(xml)
    except ET.ParseError as e:
        raise FileMakerClipboardError("INVALID_XML", f"XML parse error: {e}") from e

    if root.tag != "Script":
        raise FileMakerClipboardError(
            "UNSUPPORTED_ELEMENT_TYPE",
            f'--steps requires a <Script> file; got <{root.tag}>.',
        )

    step_list = root.find("StepList")
    if step_list is None:
        raise FileMakerClipboardError(
            "INVALID_XML", "Script has no <StepList> element."
        )

    steps = list(step_list.findall("Step"))
    total = len(steps)
    if total == 0:
        raise FileMakerClipboardError("INVALID_XML", "Script <StepList> contains no <Step> elements.")

    if indices is None:
        indices = list(range(1, total + 1))
    else:
        out_of_range = [i for i in indices if i > total]
        if out_of_range:
            raise FileMakerClipboardError(
                "INVALID_STEP_SPEC",
                f"Step indices out of range (script has {total} steps): {out_of_range}",
            )

    selected = [steps[i - 1] for i in indices]
    payload = "\n".join(ET.tostring(s, encoding="unicode") for s in selected)
    snippet = wrap_as_snippet(payload, "ScriptStep")
    return {
        "snippet_xml": snippet,
        "fm_type": "ScriptStep",
        "ddr_root": "Script",
        "step_count": total,
        "selected_indices": indices,
        "warnings": [],
    }
