"""Snapshot a fmddr index DB with a label.

A snapshot is a copy of an existing `.fmddr.db` with `snapshot_label` and
`snapshot_taken_at` stamped into its `meta` table so the label travels with
the file. Snapshots remain regular index DBs and can be queried directly.
"""
from __future__ import annotations

import datetime as _dt
import pathlib
import shutil
import sqlite3


def take_snapshot(
    db: pathlib.Path,
    label: str,
    out_dir: pathlib.Path,
    *,
    force: bool = False,
) -> pathlib.Path:
    if not db.exists():
        raise FileNotFoundError(f"DB not found: {db}")
    if not label or "/" in label or "\\" in label:
        raise ValueError(f"invalid snapshot label: {label!r}")
    out_dir.mkdir(parents=True, exist_ok=True)
    dest = out_dir / f"{label}.fmddr.db"
    if dest.exists() and not force:
        raise FileExistsError(f"snapshot already exists: {dest} (use --force to overwrite)")
    shutil.copyfile(db, dest)
    taken_at = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    conn = sqlite3.connect(dest)
    try:
        conn.executemany(
            "INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)",
            [("snapshot_label", label), ("snapshot_taken_at", taken_at)],
        )
        conn.commit()
    finally:
        conn.close()
    return dest
