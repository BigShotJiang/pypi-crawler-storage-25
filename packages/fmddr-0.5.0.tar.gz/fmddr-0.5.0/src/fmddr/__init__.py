"""fmddr — query a FileMaker DDR."""
__version__ = "0.5.0"
