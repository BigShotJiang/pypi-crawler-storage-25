"""Streaming DDR parser primitives — UTF-16 decode and iterparse driver.

Ported from `pipeline.py:load_utf8`. The XML produced by FileMaker is UTF-16 LE
with a BOM; `lxml.iterparse` and stdlib `xml.etree.iterparse` both want UTF-8
(or a stream that declares its own encoding). Decoding once up-front and
streaming the resulting bytes is faster and bounded in memory.
"""
from __future__ import annotations

import pathlib


def load_utf8(path: pathlib.Path) -> bytes:
    """Read a FileMaker DDR XML file and return UTF-8 bytes.

    Strips the UTF-16 LE BOM if present.
    """
    raw = path.read_bytes()
    if raw.startswith(b"\xff\xfe"):
        raw = raw[2:]
        return raw.decode("utf-16-le").encode("utf-8")
    if raw.startswith(b"\xfe\xff"):
        raw = raw[2:]
        return raw.decode("utf-16-be").encode("utf-8")
    # Some DDRs are already UTF-8 (or ASCII). Trust the file.
    return raw
