"""The uniform "anywhere a calc lives" chunk walker.

FileMaker's DDR helpfully types every calculation token in `<DisplayCalculation>`:

    <Chunk type="FieldRef"><Field table="<TO>" id="<fid>" name="<fname>"/></Chunk>
    <Chunk type="CustomFunctionRef">FunctionName</Chunk>
    <Chunk type="FunctionRef">BuiltInName</Chunk>
    <Chunk type="NoRef">literal text</Chunk>

We never parse FM calc syntax ourselves — we walk these chunks. Any container
that holds a `<Calculation>` (field calc, AutoEnter, Validation, script step,
custom function body, layout-object filter/conditional/tooltip, …) feeds the
same walker, tagged with the appropriate `owner_kind`.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from typing import Iterator


def iter_field_refs(elem: ET.Element) -> Iterator[tuple[int, str | None, str | None]]:
    """Yield (field_id, via_to_name, field_name) for every FieldRef chunk inside `elem`.

    Walks the entire subtree; safe to call on a step, field, or whole script.
    """
    for chunk in elem.iter("Chunk"):
        if chunk.get("type") != "FieldRef":
            continue
        f = chunk.find("Field")
        if f is None:
            continue
        fid_raw = f.get("id")
        if not fid_raw:
            continue
        try:
            fid = int(fid_raw)
        except ValueError:
            continue
        yield fid, f.get("table"), f.get("name")


def iter_cf_refs(elem: ET.Element) -> Iterator[str]:
    """Yield CF names for every CustomFunctionRef chunk. CF names resolve to ids
    in a post-pass, since CFs may not yet be parsed when this walker runs.
    """
    for chunk in elem.iter("Chunk"):
        if chunk.get("type") == "CustomFunctionRef" and chunk.text:
            yield chunk.text.strip()
