"""FileMaker calculation expression parser.

Tokenizes an FM calc body (the text inside `<Calculation><Text>...</Text>`)
into a flat list of typed references. Equivalents of DDR's pre-resolved
`<Chunk type="...">` tree, harvested from raw calc text — so SaveAsXML
ingest can produce the same `field_ref` / `custom_function_ref` graph
the DDR ingest does.

Scope (what we extract):
- **Field refs**: `TO::Field`, `TO::Field[rep]`. TO names match a known
  `TableOccurrence.name`; field names match a `Field.name` within the
  TO's underlying BaseTable. Repetitions are best-effort (literal int).
- **Custom function calls**: `Name(` where `Name` is in the supplied
  custom-function name set.
- **Dynamic regions**: any `Evaluate(...)`, `GetField(...)`,
  `GetFieldName(...)`, `LookupNext(...)` etc. — the contents are masked
  out so we don't emit unresolved refs from them. The calls themselves
  surface as `Dynamic` markers so callers can choose to record them.

Out of scope (intentional):
- Unqualified field refs (no `TO::` prefix). FM stored calcs rarely use
  these and resolving them needs callsite TO context — the cost/benefit
  isn't favorable for v1.
- Operator precedence / type checking / control flow. We just harvest
  references.
- Plug-in functions. Their args may reference fields, but the call is
  opaque — we surface the call as `FunctionRef(unknown=True)`.

Output forms:
- `parse_calc(text, ...)` — list of typed dataclass tokens.
- `chunks_from_calc(text, ...)` — list of synthetic `<Chunk>` `ET.Element`s
  matching DDR's shape, so the existing `iter_field_refs` /
  `iter_cf_refs` walkers consume them unchanged.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass


# ----------------------------------------------------------------------
# Token types
# ----------------------------------------------------------------------

@dataclass(frozen=True)
class FieldRef:
    """A field reference of the form `TO::Field` or `TO::Field[rep]`."""
    to: str
    name: str
    repetition: int | None = None


@dataclass(frozen=True)
class CFRef:
    """A call to a custom function (resolved against the known CF set)."""
    name: str


@dataclass(frozen=True)
class FunctionRef:
    """A built-in or unknown (likely plug-in) function call."""
    name: str
    builtin: bool


@dataclass(frozen=True)
class Dynamic:
    """A region whose refs we cannot resolve (Evaluate, GetField, etc.)."""
    function: str
    inner_text: str


Token = FieldRef | CFRef | FunctionRef | Dynamic


# ----------------------------------------------------------------------
# Lexer-level masking: strings, comments, and dynamic regions
# ----------------------------------------------------------------------

# FM calc strings: "..." with "" as escaped quote. DOTALL so multi-line
# strings (yes, FM allows literal newlines inside "...") match.
_STRING_RE = re.compile(r'"(?:[^"]|"")*"', re.DOTALL)
_LINE_COMMENT_RE = re.compile(r'//[^\n]*')
_BLOCK_COMMENT_RE = re.compile(r'/\*.*?\*/', re.DOTALL)

# Functions whose argument lists may contain field-ref-like text that
# isn't a true ref (it's a *string* arg or a constructed name). Mask the
# call's contents so we don't extract phantom refs from them, but record
# the call itself as a Dynamic marker.
_DYNAMIC_FUNCTIONS: frozenset[str] = frozenset({
    "Evaluate",
    "EvaluationError",
    "GetField",
    "GetFieldName",
    "GetLayoutName",
    "GetScriptName",
    "GetValueListName",
    "LookupNext",
    "Lookup",
})


def _replace_with_spaces(match: "re.Match[str]") -> str:
    """Replace a regex match with same-length spaces. Preserves indices."""
    return " " * len(match.group(0))


def _strip_strings_and_comments(text: str) -> str:
    """Mask out strings + comments with same-length spaces.

    Order matters: block comments first (can contain `"`), then line
    comments, then strings. (FM doesn't allow comments inside strings,
    so this ordering is safe.)
    """
    text = _BLOCK_COMMENT_RE.sub(_replace_with_spaces, text)
    text = _LINE_COMMENT_RE.sub(_replace_with_spaces, text)
    text = _STRING_RE.sub(_replace_with_spaces, text)
    return text


def _mask_dynamic_regions(text: str) -> tuple[str, list[Dynamic]]:
    """Find every Dynamic-function call and mask its argument list.

    Returns (masked_text, list_of_Dynamic). Uses paren depth so nested
    calls (e.g. `Evaluate(GetField($x))`) are masked as a single region.
    """
    out: list[str] = []
    dynamics: list[Dynamic] = []
    i = 0
    n = len(text)
    # Pre-compile the leading-identifier pattern.
    ident_call_re = re.compile(r"\b([A-Za-z_][\w]*)\s*\(")
    while i < n:
        m = ident_call_re.match(text, i)
        if not m:
            out.append(text[i])
            i += 1
            continue
        name = m.group(1)
        if name not in _DYNAMIC_FUNCTIONS:
            # Not a dynamic call — emit verbatim, advance past the
            # identifier (but not the `(` — keep it for normal lex).
            out.append(text[i:m.end(1)])
            i = m.end(1)
            continue
        # Dynamic call. Walk parens from the `(` to find the match.
        paren_start = m.end() - 1  # index of '('
        depth = 1
        j = paren_start + 1
        while j < n and depth > 0:
            ch = text[j]
            if ch == '"':
                # Skip string literal — find matching close quote.
                j += 1
                while j < n:
                    if text[j] == '"':
                        if j + 1 < n and text[j + 1] == '"':
                            j += 2
                            continue
                        j += 1
                        break
                    j += 1
                continue
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    j += 1
                    break
            j += 1
        # Record the dynamic region's inner text (without the outer parens).
        inner = text[paren_start + 1: j - 1] if j > paren_start + 1 else ""
        dynamics.append(Dynamic(function=name, inner_text=inner))
        # Emit the function name verbatim, but mask the parenthesized arg list
        # with spaces so other regexes don't see anything inside.
        out.append(name)
        out.append(" " * (j - m.end(1)))
        i = j
    return "".join(out), dynamics


# ----------------------------------------------------------------------
# Pattern matchers (run on string-and-dynamic-masked text)
# ----------------------------------------------------------------------

# A FieldRef: `Identifier::Identifier` with optional `[n]` repetition.
# Identifiers can include spaces, underscores, digits, and a few
# punctuation chars FM permits in names (`<` `>` `-`); we *do not*
# accept `(` `)` `[` `]` `:` `,` `;` `=` `+` `*` `/` etc. — those are
# operator territory.
#
# We use a permissive run for the TO part bounded by `::` and a similar
# run for the field part bounded by an operator/punctuation/end.
_NAME_CHARS = r"\w \-<>\."  # word chars + space, hyphen, angle-brackets, dot
_FIELD_REF_RE = re.compile(
    rf"(?<![\w:])"
    rf"([A-Za-z_][{_NAME_CHARS}]*?)"   # TO name (non-greedy)
    rf"\s*::\s*"
    rf"([A-Za-z_<][{_NAME_CHARS}]*?)"   # field name
    rf"(?=\s*\[|\s*[\)\(\,\;\&\|\+\-\*\/\=\<\>\!\^\%\?\:]|\s*$)",
    re.UNICODE | re.MULTILINE,
)
_REPETITION_RE = re.compile(r"\s*\[\s*(\d+)\s*\]")

# A function call: identifier followed by `(`. We only match identifiers
# that begin with an ASCII letter or underscore (FM built-ins and CFs do).
_FUNCTION_CALL_RE = re.compile(r"(?<![\w:])([A-Za-z_][\w]*)\s*\(", re.UNICODE)


# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------

def _build_unqualified_pattern(names: frozenset[str]) -> "re.Pattern[str] | None":
    """Build a single alternation regex matching any name as a whole token.

    Sorted longest-first so multi-word names ("Name Last Comma") win over
    their prefixes ("Name Last"). Bounded by lookaround so we don't match
    inside a longer identifier.
    """
    if not names:
        return None
    # Skip empty / whitespace-only and names containing characters our regex
    # boundary can't reliably express (newlines).
    cleaned = [n for n in names if n and "\n" not in n]
    if not cleaned:
        return None
    cleaned.sort(key=len, reverse=True)
    alternation = "|".join(re.escape(n) for n in cleaned)
    return re.compile(
        r"(?<![\w:])(?:" + alternation + r")(?![\w])",
        re.UNICODE,
    )


def parse_calc(
    text: str,
    *,
    default_to: str | None = None,
    unqualified_field_names: frozenset[str] | set[str] | None = None,
    custom_functions: frozenset[str] | set[str] | None = None,
    builtins: frozenset[str] | set[str] | None = None,
) -> list[Token]:
    """Tokenize a calc body, return a flat list of refs.

    Parameters
    ----------
    text : the raw calc text (UTF-8). Usually the value of
        `<Calculation><Text>...</Text></Calculation>`.
    default_to : if set, unqualified field-name matches are emitted as
        `FieldRef(to=default_to, name=...)`. If unset, unqualified refs
        are skipped (qualified `TO::Field` are still extracted).
    unqualified_field_names : set of field names that may legitimately
        appear bare in this calc's context (typically all fields of the
        BaseTable underlying `default_to`). Required for unqualified
        resolution.
    custom_functions : known custom-function names → `CFRef`.
    builtins : known FM built-in function names → `FunctionRef(builtin=True)`.

    Returns a flat list of `FieldRef | CFRef | FunctionRef | Dynamic`,
    in source order.
    """
    if not text:
        return []
    cf_set = frozenset(custom_functions or ())
    builtin_set = frozenset(builtins or ())
    unqual_set = frozenset(unqualified_field_names or ())

    # 1. Mask strings and comments (preserves indices for downstream regex).
    masked = _strip_strings_and_comments(text)
    # 2. Find dynamic-function calls and mask their argument lists.
    masked, dynamics = _mask_dynamic_regions(masked)

    # 3. Collect field refs, function calls.
    found: list[tuple[int, Token]] = []
    matched_spans: list[tuple[int, int]] = []  # consumed spans (qualified refs + fn calls)

    for m in _FIELD_REF_RE.finditer(masked):
        to_name = m.group(1).strip()
        fname = m.group(2).strip()
        if not to_name or not fname:
            continue
        rep: int | None = None
        rep_m = _REPETITION_RE.match(masked, m.end())
        if rep_m:
            try:
                rep = int(rep_m.group(1))
            except ValueError:
                rep = None
        end = rep_m.end() if rep_m else m.end()
        found.append((m.start(), FieldRef(to=to_name, name=fname, repetition=rep)))
        matched_spans.append((m.start(), end))

    for m in _FUNCTION_CALL_RE.finditer(masked):
        name = m.group(1)
        if any(s <= m.start() < e for s, e in matched_spans):
            continue
        matched_spans.append((m.start(), m.end()))
        if name in _DYNAMIC_FUNCTIONS:
            continue
        if name in cf_set:
            found.append((m.start(), CFRef(name=name)))
        else:
            found.append((m.start(), FunctionRef(name=name, builtin=name in builtin_set)))

    # 4. Unqualified field refs (only if context provided). Mask out spans
    #    consumed by qualified refs / function calls so we don't re-match
    #    "Field" inside "TO::Field" or "Get(Field)".
    if default_to and unqual_set:
        # Build a working buffer with consumed regions blanked.
        buf = list(masked)
        for s, e in matched_spans:
            for i in range(s, min(e, len(buf))):
                buf[i] = " "
        residual = "".join(buf)
        pattern = _build_unqualified_pattern(unqual_set)
        if pattern is not None:
            for m in pattern.finditer(residual):
                rep_m = _REPETITION_RE.match(residual, m.end())
                rep_val: int | None = None
                if rep_m:
                    try:
                        rep_val = int(rep_m.group(1))
                    except ValueError:
                        rep_val = None
                found.append((
                    m.start(),
                    FieldRef(to=default_to, name=m.group(0), repetition=rep_val),
                ))

    # Append Dynamics last (positions weren't tracked precisely during masking).
    found.extend((10**9, d) for d in dynamics)

    found.sort(key=lambda x: x[0])
    return [tok for _, tok in found]


def chunks_from_calc(
    text: str,
    *,
    default_to: str | None = None,
    custom_functions: frozenset[str] | set[str] | None = None,
    builtins: frozenset[str] | set[str] | None = None,
) -> list[ET.Element]:
    """Render parse_calc output as DDR-shaped `<Chunk>` elements.

    Each FieldRef → `<Chunk type="FieldRef"><Field id="0" table=.. name=../></Chunk>`.
    The `id="0"` sentinel signals "look me up by `(table, name)`" to the
    SaveAsXML staging resolver — the existing DDR `iter_field_refs`
    walker treats id=0 as falsy and skips, so this output is *not*
    consumed by `_stage_chunks_in`; callers should use the typed
    `parse_calc` API and stage rows themselves with name resolution.

    Provided for completeness / debugging.
    """
    chunks = []
    for tok in parse_calc(text, custom_functions=custom_functions, builtins=builtins):
        if isinstance(tok, FieldRef):
            ch = ET.Element("Chunk", {"type": "FieldRef"})
            f = ET.SubElement(ch, "Field", {
                "id": "0",
                "table": tok.to or (default_to or ""),
                "name": tok.name,
            })
            if tok.repetition is not None:
                f.set("repetition", str(tok.repetition))
            chunks.append(ch)
        elif isinstance(tok, CFRef):
            ch = ET.Element("Chunk", {"type": "CustomFunctionRef"})
            ch.text = tok.name
            chunks.append(ch)
        elif isinstance(tok, FunctionRef):
            ch = ET.Element("Chunk", {"type": "FunctionRef"})
            ch.text = tok.name
            chunks.append(ch)
        elif isinstance(tok, Dynamic):
            ch = ET.Element("Chunk", {"type": "Dynamic", "function": tok.function})
            chunks.append(ch)
    return chunks
