# fmddr — Claude Code skills

Four agent skills for working with [`fmddr`](https://github.com/proofsh/fmddr)
from Claude Code:

| Skill           | Triggers on                                                               | Purpose                                                        |
| --------------- | ------------------------------------------------------------------------- | -------------------------------------------------------------- |
| `fmddr-setup`   | "set up fmddr", "install fmddr", "index my DDR", fmddr not found in PATH  | Install fmddr and build the index for a solution               |
| `fmddr`         | FileMaker / DDR / fmp12 / Profile.xml / "where is X used" / refactor talk | Recognize when to reach for `fmddr` and use it correctly       |
| `fmddr-issue`   | "report a bug", "file an issue", "feature request" — for fmddr            | Open a high-quality issue at proofsh/fmddr (with severity)     |
| `fmddr-release` | "release fmddr", "cut a patch", "publish to PyPI"                         | End-to-end release flow: bump, changelog, build, tag, publish  |

**Typical first-time flow:**
1. `npx fmddr-skills` — installs all four skills
2. In a Claude Code session: "set up fmddr for my DDR" → `fmddr-setup` activates
3. Now any FileMaker question → `fmddr` activates automatically

## Install

### npx (no git required)

```sh
npx fmddr-skills                   # install all four skills (personal)
npx fmddr-skills fmddr fmddr-setup # install specific skills only
npx fmddr-skills --project         # project-scoped (.claude/skills/)
```

### Manual — personal (one user, all projects)

```sh
mkdir -p ~/.claude/skills
cp -R skills/fmddr         ~/.claude/skills/
cp -R skills/fmddr-setup   ~/.claude/skills/
cp -R skills/fmddr-issue   ~/.claude/skills/
cp -R skills/fmddr-release ~/.claude/skills/
```

### Manual — project-scoped (this repo only)

```sh
mkdir -p .claude/skills
cp -R skills/fmddr         .claude/skills/
cp -R skills/fmddr-setup   .claude/skills/
cp -R skills/fmddr-issue   .claude/skills/
cp -R skills/fmddr-release .claude/skills/
```

Project skills override personal skills with the same name.

## Verify

In a Claude Code session, type `/` and look for the skills, or ask
"is the fmddr skill loaded?" — Claude will list available skills.

## Layout

```
skills/
├── package.json          ← npm package (fmddr-skills)
├── bin/
│   └── install.js        ← npx entry point
├── fmddr-setup/
│   └── SKILL.md
├── fmddr/
│   └── SKILL.md
├── fmddr-issue/
│   ├── SKILL.md
│   └── templates/
│       ├── bug-report.md
│       └── feature-request.md
└── fmddr-release/
    └── SKILL.md
```

## Updating

```sh
npx fmddr-skills@latest           # via npm (when a new version is published)

# or from a local clone:
cd /path/to/fmddr && git pull
npx --prefix skills . fmddr-skills
```
