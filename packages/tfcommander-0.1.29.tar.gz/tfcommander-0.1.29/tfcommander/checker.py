import socket
import ssl
import sys
import warnings
from typing import Optional

import requests
from colorama import Fore, Style, init

# Initialize colorama for cross-platform colored output
init(autoreset=True)

# Suppress InsecureRequestWarning since we intentionally skip SSL verification
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

DEFAULT_TIMEOUT = 10


class CheckResult:
    """Represents the result of a single check"""

    def __init__(self, name: str, passed: bool, message: str, details: str = ""):
        self.name = name
        self.passed = passed
        self.message = message
        self.details = details


def _print_check_result_inline(results: list[CheckResult]) -> None:
    """Print all check results in a single line flow"""
    parts = []
    for i, result in enumerate(results):
        status_symbol = f"{Fore.GREEN}✓{Style.RESET_ALL}" if result.passed else f"{Fore.RED}✗{Style.RESET_ALL}"
        parts.append(f"{status_symbol} {Fore.CYAN}{result.name}{Style.RESET_ALL}")
        if i < len(results) - 1:
            parts.append(f"{Fore.BLUE}→{Style.RESET_ALL}")

    print("\n" + " ".join(parts) + "\n")

    # Print details for each check
    for result in results:
        status_symbol = f"{Fore.GREEN}✓{Style.RESET_ALL}" if result.passed else f"{Fore.RED}✗{Style.RESET_ALL}"
        print(f"{status_symbol} {Fore.CYAN}{result.name}{Style.RESET_ALL}: {result.message}")
        if result.details:
            print(f"  {Fore.YELLOW}{result.details}{Style.RESET_ALL}")


def _check_dns(domain: str) -> CheckResult:
    """Check if domain resolves via DNS"""
    try:
        addr_info = socket.getaddrinfo(domain, None)
        if addr_info:
            ip = addr_info[0][4][0]
            return CheckResult(
                name="DNS Resolution",
                passed=True,
                message="DNS resolves correctly",
                details=f"{domain} → {ip}"
            )
        else:
            return CheckResult(
                name="DNS Resolution",
                passed=False,
                message="No DNS records found",
                details=domain
            )
    except socket.gaierror as e:
        return CheckResult(
            name="DNS Resolution",
            passed=False,
            message=f"DNS lookup failed: {e}",
            details=domain
        )


def _check_host_reachable(domain: str, port: int = 443) -> CheckResult:
    """Check if host is reachable on given port"""
    try:
        addr_info = socket.getaddrinfo(domain, port)
        if not addr_info:
            return CheckResult(
                name="Host Reachability",
                passed=False,
                message="Cannot resolve host",
                details=f"{domain}:{port}"
            )

        ip = addr_info[0][4][0]
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(DEFAULT_TIMEOUT)

        try:
            sock.connect((ip, port))
            sock.close()
            return CheckResult(
                name="Host Reachability",
                passed=True,
                message="Host is reachable",
                details=f"{ip}:{port}"
            )
        except (socket.timeout, socket.error) as e:
            return CheckResult(
                name="Host Reachability",
                passed=False,
                message=f"Connection failed: {e}",
                details=f"{ip}:{port}"
            )
    except Exception as e:
        return CheckResult(
            name="Host Reachability",
            passed=False,
            message=f"Error: {e}",
            details=f"{domain}:{port}"
        )


def _check_ssl_certificate(domain: str) -> CheckResult:
    """Check if SSL certificate is valid"""
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=DEFAULT_TIMEOUT) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                return CheckResult(
                    name="SSL Certificate",
                    passed=True,
                    message="Valid certificate",
                    details=f"Issued to: {cert.get('subject', [[('commonName', domain)]])[0][0][1]}"
                )
    except ssl.SSLCertVerificationError as e:
        return CheckResult(
            name="SSL Certificate",
            passed=False,
            message="Certificate verification failed",
            details=str(e)
        )
    except ssl.SSLError as e:
        return CheckResult(
            name="SSL Certificate",
            passed=False,
            message="SSL error",
            details=str(e)
        )
    except Exception as e:
        return CheckResult(
            name="SSL Certificate",
            passed=False,
            message="Certificate check failed",
            details=str(e)
        )


def _check_traefik_header(domain: str) -> CheckResult:
    """Check if Traefik proxy header is present"""
    try:
        # Try HTTPS first
        url = f"https://{domain}"
        resp = requests.get(url, timeout=DEFAULT_TIMEOUT, allow_redirects=True, verify=False)

        traefik_header = resp.headers.get("X-Traefik")
        if traefik_header:
            return CheckResult(
                name="Traefik Proxy",
                passed=True,
                message="Traefik header present",
                details=f"X-Traefik: {traefik_header}"
            )
        else:
            return CheckResult(
                name="Traefik Proxy",
                passed=False,
                message="X-Traefik header not found",
                details="Response headers missing Traefik identifier"
            )
    except requests.exceptions.SSLError:
        # Try HTTP if HTTPS fails
        try:
            url = f"http://{domain}"
            resp = requests.get(url, timeout=DEFAULT_TIMEOUT, allow_redirects=True)
            traefik_header = resp.headers.get("X-Traefik")
            if traefik_header:
                return CheckResult(
                    name="Traefik Proxy",
                    passed=True,
                    message="Traefik header present (HTTP)",
                    details=f"X-Traefik: {traefik_header}"
                )
            else:
                return CheckResult(
                    name="Traefik Proxy",
                    passed=False,
                    message="X-Traefik header not found",
                    details="Response headers missing Traefik identifier"
                )
        except requests.exceptions.RequestException as e:
            return CheckResult(
                name="Traefik Proxy",
                passed=False,
                message=f"HTTP request failed: {e}",
                details=url
            )
    except requests.exceptions.RequestException as e:
        return CheckResult(
            name="Traefik Proxy",
            passed=False,
            message=f"Request failed: {e}",
            details=url
        )


def _check_backend_response(domain: str) -> CheckResult:
    """Check if backend service responds with 2xx status"""
    try:
        # Try HTTPS first
        url = f"https://{domain}"
        resp = requests.get(url, timeout=DEFAULT_TIMEOUT, allow_redirects=True, verify=False)

        if 200 <= resp.status_code < 300:
            return CheckResult(
                name="Backend Service",
                passed=True,
                message="Backend responding",
                details=f"HTTP {resp.status_code} {resp.reason}"
            )
        else:
            return CheckResult(
                name="Backend Service",
                passed=False,
                message="Backend returned non-2xx status",
                details=f"HTTP {resp.status_code} {resp.reason}"
            )
    except requests.exceptions.SSLError:
        # Try HTTP if HTTPS fails
        try:
            url = f"http://{domain}"
            resp = requests.get(url, timeout=DEFAULT_TIMEOUT, allow_redirects=True)
            if 200 <= resp.status_code < 300:
                return CheckResult(
                    name="Backend Service",
                    passed=True,
                    message="Backend responding (HTTP)",
                    details=f"HTTP {resp.status_code} {resp.reason}"
                )
            else:
                return CheckResult(
                    name="Backend Service",
                    passed=False,
                    message="Backend returned non-2xx status",
                    details=f"HTTP {resp.status_code} {resp.reason}"
                )
        except requests.exceptions.RequestException as e:
            return CheckResult(
                name="Backend Service",
                passed=False,
                message=f"Request failed: {e}",
                details=url
            )
    except requests.exceptions.RequestException as e:
        return CheckResult(
            name="Backend Service",
            passed=False,
            message=f"Request failed: {e}",
            details=url
        )


def check_service(domain: str) -> None:
    """
    Check the complete routing path for a service from DNS to backend.

    Performs the following checks:
    1. DNS resolution
    2. Host reachability (TCP connection)
    3. SSL certificate validation
    4. Traefik proxy header presence
    5. Backend service response (HTTP 2xx)

    Args:
        domain: The domain name to check (e.g., 'api.example.com')
    """
    print(f"\n{Fore.CYAN}{'═' * 70}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}Checking service: {Fore.WHITE}{domain}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'═' * 70}{Style.RESET_ALL}")

    # Run all checks
    results = []
    results.append(_check_dns(domain))
    results.append(_check_host_reachable(domain))
    results.append(_check_ssl_certificate(domain))
    results.append(_check_traefik_header(domain))
    results.append(_check_backend_response(domain))

    # Print results inline
    _print_check_result_inline(results)

    # Overall status
    all_passed = all(r.passed for r in results)
    print(f"\n{Fore.CYAN}{'═' * 70}{Style.RESET_ALL}")
    if all_passed:
        print(f"{Fore.GREEN}✓ ALL CHECKS PASSED{Style.RESET_ALL}")
    else:
        failed_count = sum(1 for r in results if not r.passed)
        print(f"{Fore.RED}✗ {failed_count} CHECK(S) FAILED{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'═' * 70}{Style.RESET_ALL}\n")

    # Exit with appropriate code
    sys.exit(0 if all_passed else 1)
