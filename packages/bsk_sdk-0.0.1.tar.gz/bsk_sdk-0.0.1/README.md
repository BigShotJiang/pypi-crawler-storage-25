# bsk-sdk

Temporary `0.0.1` placeholder package to reserve the `bsk-sdk` name on PyPI ahead of the planned v1 release.

## Status

This release is intentionally minimal and not feature complete.
