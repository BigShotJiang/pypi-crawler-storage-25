__version__ = "0.1.13"

__all__ = [
    "__version__",
    "Model",
    "fields",
    "setup",
    "use_storage",
    "config",
    "DataTable",
    "datatable",
    "df",
    "ui",
    "db",
    "pipeline",
    "Pipeline",
    "BasePipeline",
    "BaseStep",
    "FunctionStep",
    "PipelineContext",
    "PipelineStatus",
    "StepOutcome",
    "ConfigStore",
    "default_config",
    "load_config",
    "save_config",
    "resolve_config_path",
    "get_accounts",
    "get_account",
    "upsert_account",
    "delete_account",
    "DatabaseConnector",
    "db_connector",
    "from_sql",
    "from_mysql_db",
    "from_maria_db",
    "from_oracle_db",
    "from_postgres_db",
    "from_sqlite_db",
    "from_faker",
    "from_factory",
    "Tester",
]


def __getattr__(name):
    """Lazy import optional public helpers."""
    if name in {"Model", "fields", "setup", "use_storage"}:
        from .erp import Model, fields, setup, use_storage

        return {
            "Model": Model,
            "fields": fields,
            "setup": setup,
            "use_storage": use_storage,
        }[name]
    if name == "datatable":
        from importlib import import_module

        return import_module(".datatable", __name__)
    if name == "ui":
        from importlib import import_module

        return import_module(".ui", __name__)
    if name == "pipeline":
        from importlib import import_module

        return import_module(".pipeline", __name__)
    if name == "db":
        from importlib import import_module

        return import_module(".db", __name__)
    if name == "config":
        from importlib import import_module

        return import_module(".config", __name__)
    if name == "tester":
        from importlib import import_module

        return import_module(".tester", __name__)
    if name in {
        "Pipeline",
        "BasePipeline",
        "BaseStep",
        "FunctionStep",
        "PipelineContext",
        "PipelineStatus",
        "StepOutcome",
    }:
        from .pipeline import (
            BasePipeline,
            BaseStep,
            FunctionStep,
            Pipeline,
            PipelineContext,
            PipelineStatus,
            StepOutcome,
        )

        return {
            "Pipeline": Pipeline,
            "BasePipeline": BasePipeline,
            "BaseStep": BaseStep,
            "FunctionStep": FunctionStep,
            "PipelineContext": PipelineContext,
            "PipelineStatus": PipelineStatus,
            "StepOutcome": StepOutcome,
        }[name]
    if name in {"DataTable", "df"}:
        from .datatable import DataTable

        return DataTable
    if name in {
        "ConfigStore",
        "default_config",
        "load_config",
        "save_config",
        "resolve_config_path",
        "get_accounts",
        "get_account",
        "upsert_account",
        "delete_account",
    }:
        from .config import (
            ConfigStore,
            default_config,
            delete_account,
            get_account,
            get_accounts,
            load_config,
            resolve_config_path,
            save_config,
            upsert_account,
        )

        return {
            "ConfigStore": ConfigStore,
            "default_config": default_config,
            "load_config": load_config,
            "save_config": save_config,
            "resolve_config_path": resolve_config_path,
            "get_accounts": get_accounts,
            "get_account": get_account,
            "upsert_account": upsert_account,
            "delete_account": delete_account,
        }[name]
    if name in {
        "DatabaseConnector",
        "db_connector",
        "from_sql",
        "from_mysql_db",
        "from_maria_db",
        "from_oracle_db",
        "from_postgres_db",
        "from_sqlite_db",
        "from_faker",
        "from_factory",
    }:
        from .datatable import (
            DatabaseConnector,
            db_connector,
            from_factory,
            from_faker,
            from_maria_db,
            from_mysql_db,
            from_oracle_db,
            from_postgres_db,
            from_sql,
            from_sqlite_db,
        )

        return {
            "DatabaseConnector": DatabaseConnector,
            "db_connector": db_connector,
            "from_sql": from_sql,
            "from_mysql_db": from_mysql_db,
            "from_maria_db": from_maria_db,
            "from_oracle_db": from_oracle_db,
            "from_postgres_db": from_postgres_db,
            "from_sqlite_db": from_sqlite_db,
            "from_faker": from_faker,
            "from_factory": from_factory,
        }[name]
    if name == "Tester":
        from .tester import Tester

        return Tester
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
