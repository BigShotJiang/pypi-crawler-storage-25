"""jupyterlab-anticheat — blocks copy-paste in code cells during exams."""

try:
    from ._version import __version__
except ImportError:
    import importlib.metadata
    try:
        __version__ = importlib.metadata.version("jupyterlab_anticheat")
    except importlib.metadata.PackageNotFoundError:
        __version__ = "unknown"


def _jupyter_labextension_paths():
    """Return metadata describing where to find the frontend extension."""
    return [{"src": "labextension", "dest": "jupyterlab-anticheat"}]
