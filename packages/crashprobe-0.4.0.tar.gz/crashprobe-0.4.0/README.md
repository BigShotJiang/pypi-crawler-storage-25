# 🛡️Crashprobe - makes errors simple, understandable, and beautiful, and generates HTML/TXT reports about them. 

![Python](https://img.shields.io/badge/python-3.6%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)

Examples:

Crashprobe HTML report example:

![Crashprobe HTML report example](https://i.ibb.co/9m1f8sLN/screen.png)

Crashprobe TXT report example:

![Crashprobe TXT report example](https://i.ibb.co/pBcSTZfW/2026-03-17-121622.png)

A library that intercepts errors and creates beautiful, detailed HTML reports.
## 📦Installation
```bash
pip install crashprobe
```
## 🚀Quick Start
```python
import crashprobe
crashprobe.start()
print(1/0) # ZeroDivisionError - watch the magic!
```
## ✨Crashprobe Features
- No dependencies
- Beautiful, easy-to-read dark theme in reports
- System information
- Very easy to use
- Copy report button
- Useful links with error information
- Support for text reports (TXT)
- Ability to disable auto-opening of the browser
- Reports are saved in a separate folder for each file
- Catches errors in threads – automatically works with `threading` (no extra code required).
## 📃Usage
Library import:
```python
import crashprobe
```
Start the error catcher. If the program crashes with an error, the library will intercept it, generate an HTML report, automatically open it, and save it in the nameOfYourFile_crash_dir folder:
```python
crashprobe.start()
```
The generated page is saved in the automatically created nameOfYourFile_crash_dir folder as a file named crash_Y-M-D_H-M-S.
**Read the details below 👇🏻**

Stop the error catcher:
```python
crashprobe.stop()
```

### ⚙️crashprobe.start() - Method Settings
The crashprobe.start() method accepts two optional arguments to customize the format and display of error reports.

#### Report arguments
| Parameter | Type | Default | Values | Description |
| :--- | :--- | :--- | :--- | :--- |
| `auto_open` | `bool` | `True` | `True`, `False` | This parameter allows you to configure automatic report opening once the error is captured. | 
| `file_format` | `str` | `"html"` | `"html"`, `"txt"` | Specifies the file format for the generated report.(Case-insensitive) |
| `hide_secrets` | `list` | `[]` | `["your_secret_var", "password"]` | Allows you to replace the variable value in the report with * to hide passwords, secrets, tokens, and so on. |
#### Report contents
- HTML page: beautiful dark theme, emoji, as well as the error title, error text, exact date and time, path to the file containing the error, the line containing the error and its closest links, **values ​​and types of local variables**, system information and Python version, links to Google and the Python documentation for information about the error, and a copy report button.

- TXT file: error title, error text, exact date and time, path to the file containing the error, the line containing the error and its closest links, **values and types of local variables**, system information, and Python version, links to Google and the Python documentation for information about the error.

Example (All defaults): 
```python
import crashprobe
crashprobe.start()
def example(x, y):
    one = x
    two = y
    return x / y
print(example(1, "Hello"))
```
The library will create a folder named [name_of_your_file]_crash_dir to store reports. The display behavior depends on your settings:
| `file_format` | `auto_open` | Resulting action |
| :--- | :--- | :--- |
| `"html"` | `True` | Opens the report on your **web browser** |
| `"html"` | `False` | **Saves only** (no automatic display) |
| `"txt"` | `True` | Prints the report content to the **console** |
| `"txt"` | `False` | **Saves only** (no console output) |

Example: 
```python
import crashprobe
crashprobe.start(auto_open = False, file_format = 'html', hide_secrets=["x"])
def example(x, y):
    one = x
    two = y
    return x / y
print(example(1, "Hello"))
```
### 🛑 Stopping the error catcher
If you need to temporarily disable crashprobe (for example, to see the standard Python traceback or to avoid conflicts with another error handler), call `crashprobe.stop()`. After that, uncaught exceptions will be handled by the default Python exception hook.

Example: 
```python
import crashprobe
crashprobe.start()
def example(x, y):
    one = x
    two = y
    return x / y
crashprobe.stop()
print(example(1, "Hello")) # Exception will be handled by the default Python exception hook
```

## ❔Why is it convenient?
To get started, you only need to write two lines of code, and in the event of an error, you get a beautiful HTML report instead of a console message. 

Without crashprobe:

![Before crashprobe](https://i.ibb.co/cKQ0QPYZ/screen-before.png)

With crashprobe:

![With crashprobe](https://i.ibb.co/9m1f8sLN/screen.png)

## ❔Whats new in 0.4.0?
- Thread support – Crashprobe now catches unhandled exceptions in any thread.
- Thread info in reports – thread name and ID are displayed in the System section.
- Improved documentation.

## 👦🏻 About the developer
My name is Andrey Egupov, I'm 11 years old. I've been programming for several years. I started in Scratch, now I write in Python, JavaScript, and I'm working with Arduino.
I got tired of seeing red error messages and having to print variable values, so I decided to create a truly useful tool that would help me and others!

## 📄 License
MIT © 2026 Andrey Egupov (11-year-old-developer)