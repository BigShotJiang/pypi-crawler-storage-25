"""Sonarr client dispatcher."""

from __future__ import annotations

from typing import Any


def SonarrClient(*, api_version: int = 3, **kwargs: Any) -> Any:
    if api_version == 3:
        from arr_py_client.sonarr.v3.client import SonarrClientV3

        return SonarrClientV3(**kwargs)
    msg = f"Unsupported Sonarr api_version: {api_version}"
    raise ValueError(msg)


def AsyncSonarrClient(*, api_version: int = 3, **kwargs: Any) -> Any:
    if api_version == 3:
        from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3

        return AsyncSonarrClientV3(**kwargs)
    msg = f"Unsupported Sonarr api_version: {api_version}"
    raise ValueError(msg)


__all__ = ["AsyncSonarrClient", "SonarrClient"]
