"""Sonarr v3 client implementations (sync + async)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client._common.client_base import (
    build_async_transport,
    build_sync_transport,
    wire_resources,
)
from arr_py_client._common.settings import SonarrSettings
from arr_py_client.sonarr.v3.resources._auto import (
    ASYNC_RESOURCES as _AUTO_ASYNC_RESOURCES,
)
from arr_py_client.sonarr.v3.resources._auto import (
    SYNC_RESOURCES as _AUTO_SYNC_RESOURCES,
)
from arr_py_client.sonarr.v3.resources._auto._attrs import (
    SonarrV3AsyncResourceAttrs,
    SonarrV3SyncResourceAttrs,
)
from arr_py_client.sonarr.v3.resources.auto_tagging import (
    AsyncAutoTaggingResource,
    AutoTaggingResource,
)
from arr_py_client.sonarr.v3.resources.calendar import (
    AsyncCalendarResource,
    CalendarResource,
)
from arr_py_client.sonarr.v3.resources.commands import (
    AsyncCommandsResource,
    CommandsResource,
)
from arr_py_client.sonarr.v3.resources.custom_formats import (
    AsyncCustomFormatsResource,
    CustomFormatsResource,
)
from arr_py_client.sonarr.v3.resources.delay_profiles import (
    AsyncDelayProfilesResource,
    DelayProfilesResource,
)
from arr_py_client.sonarr.v3.resources.download_clients import (
    AsyncDownloadClientsResource,
    DownloadClientsResource,
)
from arr_py_client.sonarr.v3.resources.episodes import (
    AsyncEpisodesResource,
    EpisodesResource,
)
from arr_py_client.sonarr.v3.resources.history import (
    AsyncHistoryResource,
    HistoryResource,
)
from arr_py_client.sonarr.v3.resources.import_lists import (
    AsyncImportListsResource,
    ImportListsResource,
)
from arr_py_client.sonarr.v3.resources.indexers import (
    AsyncIndexersResource,
    IndexersResource,
)
from arr_py_client.sonarr.v3.resources.library import (
    AsyncLibraryResource,
    LibraryResource,
)
from arr_py_client.sonarr.v3.resources.manual_import import (
    AsyncManualImportResource,
    ManualImportResource,
)
from arr_py_client.sonarr.v3.resources.media_cover import (
    AsyncMediaCoverResource,
    MediaCoverResource,
)
from arr_py_client.sonarr.v3.resources.notifications import (
    AsyncNotificationsResource,
    NotificationsResource,
)
from arr_py_client.sonarr.v3.resources.parse import (
    AsyncParseResource,
    ParseResource,
)
from arr_py_client.sonarr.v3.resources.ping import (
    AsyncPingResource,
    PingResource,
)
from arr_py_client.sonarr.v3.resources.quality_profiles import (
    AsyncQualityProfilesResource,
    QualityProfilesResource,
)
from arr_py_client.sonarr.v3.resources.queue import (
    AsyncQueueResource,
    QueueResource,
)
from arr_py_client.sonarr.v3.resources.release_profiles import (
    AsyncReleaseProfilesResource,
    ReleaseProfilesResource,
)
from arr_py_client.sonarr.v3.resources.releases import (
    AsyncReleasesResource,
    ReleasesResource,
)
from arr_py_client.sonarr.v3.resources.rename import (
    AsyncRenameResource,
    RenameResource,
)
from arr_py_client.sonarr.v3.resources.root_folders import (
    AsyncRootFoldersResource,
    RootFoldersResource,
)
from arr_py_client.sonarr.v3.resources.series import (
    AsyncSeriesResource,
    SeriesResource,
)
from arr_py_client.sonarr.v3.resources.system import (
    AsyncSystemResource,
    SystemResource,
)
from arr_py_client.sonarr.v3.resources.tags import (
    AsyncTagsResource,
    TagsResource,
)
from arr_py_client.sonarr.v3.resources.wanted import (
    AsyncWantedResource,
    WantedResource,
)

if TYPE_CHECKING:
    import httpx

    from arr_py_client._common.retry import RetryPolicy
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


_APP_NAME = "Sonarr"
_API_VERSION = 3

_CURATED_SYNC: dict[str, type] = {
    "series": SeriesResource,
    "auto_tagging": AutoTaggingResource,
    "episodes": EpisodesResource,
    "queue": QueueResource,
    "history": HistoryResource,
    "tags": TagsResource,
    "system": SystemResource,
    "commands": CommandsResource,
    "custom_formats": CustomFormatsResource,
    "calendar": CalendarResource,
    "indexers": IndexersResource,
    "download_clients": DownloadClientsResource,
    "quality_profiles": QualityProfilesResource,
    "root_folders": RootFoldersResource,
    "notifications": NotificationsResource,
    "media_cover": MediaCoverResource,
    "parse": ParseResource,
    "ping": PingResource,
    "wanted": WantedResource,
    "library": LibraryResource,
    "releases": ReleasesResource,
    "import_lists": ImportListsResource,
    "delay_profiles": DelayProfilesResource,
    "release_profiles": ReleaseProfilesResource,
    "manual_import": ManualImportResource,
    "rename": RenameResource,
}

_CURATED_ASYNC: dict[str, type] = {
    "series": AsyncSeriesResource,
    "auto_tagging": AsyncAutoTaggingResource,
    "episodes": AsyncEpisodesResource,
    "queue": AsyncQueueResource,
    "history": AsyncHistoryResource,
    "tags": AsyncTagsResource,
    "system": AsyncSystemResource,
    "commands": AsyncCommandsResource,
    "custom_formats": AsyncCustomFormatsResource,
    "calendar": AsyncCalendarResource,
    "indexers": AsyncIndexersResource,
    "download_clients": AsyncDownloadClientsResource,
    "quality_profiles": AsyncQualityProfilesResource,
    "root_folders": AsyncRootFoldersResource,
    "notifications": AsyncNotificationsResource,
    "media_cover": AsyncMediaCoverResource,
    "parse": AsyncParseResource,
    "ping": AsyncPingResource,
    "wanted": AsyncWantedResource,
    "library": AsyncLibraryResource,
    "releases": AsyncReleasesResource,
    "import_lists": AsyncImportListsResource,
    "delay_profiles": AsyncDelayProfilesResource,
    "release_profiles": AsyncReleaseProfilesResource,
    "manual_import": AsyncManualImportResource,
    "rename": AsyncRenameResource,
}


class SonarrClientV3(SonarrV3SyncResourceAttrs):
    """Synchronous Sonarr v3 client."""

    transport: SyncTransport
    series: SeriesResource
    auto_tagging: AutoTaggingResource
    episodes: EpisodesResource
    queue: QueueResource
    history: HistoryResource
    tags: TagsResource
    system: SystemResource
    commands: CommandsResource
    custom_formats: CustomFormatsResource
    calendar: CalendarResource
    indexers: IndexersResource
    download_clients: DownloadClientsResource
    quality_profiles: QualityProfilesResource
    root_folders: RootFoldersResource
    notifications: NotificationsResource
    media_cover: MediaCoverResource
    parse: ParseResource
    ping: PingResource
    wanted: WantedResource
    library: LibraryResource
    releases: ReleasesResource
    import_lists: ImportListsResource
    delay_profiles: DelayProfilesResource
    release_profiles: ReleaseProfilesResource
    manual_import: ManualImportResource
    rename: RenameResource

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float | None = 30.0,
        url_base: str | None = None,
        verify: bool | str = True,
        retry: RetryPolicy | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        super().__init__()
        self.transport = build_sync_transport(
            settings_cls=SonarrSettings,
            app_name=_APP_NAME,
            api_version=_API_VERSION,
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            url_base=url_base,
            verify=verify,
            retry=retry,
            http_client=http_client,
        )
        wire_resources(self, self.transport, _AUTO_SYNC_RESOURCES)
        wire_resources(self, self.transport, _CURATED_SYNC)

    def close(self) -> None:
        self.transport.close()

    def __enter__(self) -> SonarrClientV3:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"SonarrClientV3(base_url={self.transport.base_url!r}, api_version=3)"


class AsyncSonarrClientV3(SonarrV3AsyncResourceAttrs):
    """Asynchronous Sonarr v3 client."""

    transport: AsyncTransport
    series: AsyncSeriesResource
    auto_tagging: AsyncAutoTaggingResource
    episodes: AsyncEpisodesResource
    queue: AsyncQueueResource
    history: AsyncHistoryResource
    tags: AsyncTagsResource
    system: AsyncSystemResource
    commands: AsyncCommandsResource
    custom_formats: AsyncCustomFormatsResource
    calendar: AsyncCalendarResource
    indexers: AsyncIndexersResource
    download_clients: AsyncDownloadClientsResource
    quality_profiles: AsyncQualityProfilesResource
    root_folders: AsyncRootFoldersResource
    notifications: AsyncNotificationsResource
    media_cover: AsyncMediaCoverResource
    parse: AsyncParseResource
    ping: AsyncPingResource
    wanted: AsyncWantedResource
    library: AsyncLibraryResource
    releases: AsyncReleasesResource
    import_lists: AsyncImportListsResource
    delay_profiles: AsyncDelayProfilesResource
    release_profiles: AsyncReleaseProfilesResource
    manual_import: AsyncManualImportResource
    rename: AsyncRenameResource

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float | None = 30.0,
        url_base: str | None = None,
        verify: bool | str = True,
        retry: RetryPolicy | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__()
        self.transport = build_async_transport(
            settings_cls=SonarrSettings,
            app_name=_APP_NAME,
            api_version=_API_VERSION,
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            url_base=url_base,
            verify=verify,
            retry=retry,
            http_client=http_client,
        )
        wire_resources(self, self.transport, _AUTO_ASYNC_RESOURCES)
        wire_resources(self, self.transport, _CURATED_ASYNC)

    async def aclose(self) -> None:
        await self.transport.aclose()

    async def __aenter__(self) -> AsyncSonarrClientV3:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()

    def __repr__(self) -> str:
        return (
            f"AsyncSonarrClientV3(base_url={self.transport.base_url!r}, api_version=3)"
        )
