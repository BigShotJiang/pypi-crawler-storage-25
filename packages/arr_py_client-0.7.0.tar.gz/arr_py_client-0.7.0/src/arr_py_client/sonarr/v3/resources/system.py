"""System resource for Sonarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.system import (
    AsyncSystemResource as _AutoAsyncSystemResource,
)
from arr_py_client.sonarr.v3.resources._auto.system import (
    SystemResource as _AutoSystemResource,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class SystemResource(_AutoSystemResource):
    """Sync Sonarr system resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def status(self) -> _models.SystemResource:
        return _ops.list_system_status(self._transport)


class AsyncSystemResource(_AutoAsyncSystemResource):
    """Async Sonarr system resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def status(self) -> _models.SystemResource:
        return await _ops.list_system_status_async(self._transport)
