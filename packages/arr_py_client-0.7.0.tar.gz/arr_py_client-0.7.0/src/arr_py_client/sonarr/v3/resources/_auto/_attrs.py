"""Generated typed attribute declarations for the client classes."""

from __future__ import annotations

from arr_py_client.sonarr.v3.resources._auto import (
    ApiInfoResource,
    AuthenticationResource,
    AutoTaggingResource,
    BackupResource,
    BlocklistResource,
    CalendarResource,
    CalendarFeedResource,
    CommandResource,
    CustomFilterResource,
    CustomFormatResource,
    CutoffResource,
    DelayProfileResource,
    DiskSpaceResource,
    DownloadClientResource,
    DownloadClientConfigResource,
    EpisodeResource,
    EpisodeFileResource,
    FileSystemResource,
    HealthResource,
    HistoryResource,
    HostConfigResource,
    ImportListResource,
    ImportListConfigResource,
    ImportListExclusionResource,
    IndexerResource,
    IndexerConfigResource,
    IndexerFlagResource,
    LanguageResource,
    LanguageProfileResource,
    LanguageProfileSchemaResource,
    LocalizationResource,
    LogResource,
    LogFileResource,
    ManualImportResource,
    MediaCoverResource,
    MediaManagementConfigResource,
    MetadataResource,
    MissingResource,
    NamingConfigResource,
    NotificationResource,
    ParseResource,
    PingResource,
    QualityDefinitionResource,
    QualityProfileResource,
    QualityProfileSchemaResource,
    QueueResource,
    QueueActionResource,
    QueueDetailsResource,
    QueueStatusResource,
    ReleaseResource,
    ReleaseProfileResource,
    ReleasePushResource,
    RemotePathMappingResource,
    RenameEpisodeResource,
    RootFolderResource,
    SeasonPassResource,
    SeriesResource,
    SeriesEditorResource,
    SeriesFolderResource,
    SeriesImportResource,
    SeriesLookupResource,
    StaticResourceResource,
    SystemResource,
    TagResource,
    TagDetailsResource,
    TaskResource,
    UiConfigResource,
    UpdateResource,
    UpdateLogFileResource,
    AsyncApiInfoResource,
    AsyncAuthenticationResource,
    AsyncAutoTaggingResource,
    AsyncBackupResource,
    AsyncBlocklistResource,
    AsyncCalendarResource,
    AsyncCalendarFeedResource,
    AsyncCommandResource,
    AsyncCustomFilterResource,
    AsyncCustomFormatResource,
    AsyncCutoffResource,
    AsyncDelayProfileResource,
    AsyncDiskSpaceResource,
    AsyncDownloadClientResource,
    AsyncDownloadClientConfigResource,
    AsyncEpisodeResource,
    AsyncEpisodeFileResource,
    AsyncFileSystemResource,
    AsyncHealthResource,
    AsyncHistoryResource,
    AsyncHostConfigResource,
    AsyncImportListResource,
    AsyncImportListConfigResource,
    AsyncImportListExclusionResource,
    AsyncIndexerResource,
    AsyncIndexerConfigResource,
    AsyncIndexerFlagResource,
    AsyncLanguageResource,
    AsyncLanguageProfileResource,
    AsyncLanguageProfileSchemaResource,
    AsyncLocalizationResource,
    AsyncLogResource,
    AsyncLogFileResource,
    AsyncManualImportResource,
    AsyncMediaCoverResource,
    AsyncMediaManagementConfigResource,
    AsyncMetadataResource,
    AsyncMissingResource,
    AsyncNamingConfigResource,
    AsyncNotificationResource,
    AsyncParseResource,
    AsyncPingResource,
    AsyncQualityDefinitionResource,
    AsyncQualityProfileResource,
    AsyncQualityProfileSchemaResource,
    AsyncQueueResource,
    AsyncQueueActionResource,
    AsyncQueueDetailsResource,
    AsyncQueueStatusResource,
    AsyncReleaseResource,
    AsyncReleaseProfileResource,
    AsyncReleasePushResource,
    AsyncRemotePathMappingResource,
    AsyncRenameEpisodeResource,
    AsyncRootFolderResource,
    AsyncSeasonPassResource,
    AsyncSeriesResource,
    AsyncSeriesEditorResource,
    AsyncSeriesFolderResource,
    AsyncSeriesImportResource,
    AsyncSeriesLookupResource,
    AsyncStaticResourceResource,
    AsyncSystemResource,
    AsyncTagResource,
    AsyncTagDetailsResource,
    AsyncTaskResource,
    AsyncUiConfigResource,
    AsyncUpdateResource,
    AsyncUpdateLogFileResource,
)


class SonarrV3SyncResourceAttrs:
    api_info: ApiInfoResource
    authentication: AuthenticationResource
    auto_tagging: AutoTaggingResource
    backup: BackupResource
    blocklist: BlocklistResource
    calendar: CalendarResource
    calendar_feed: CalendarFeedResource
    command: CommandResource
    custom_filter: CustomFilterResource
    custom_format: CustomFormatResource
    cutoff: CutoffResource
    delay_profile: DelayProfileResource
    disk_space: DiskSpaceResource
    download_client: DownloadClientResource
    download_client_config: DownloadClientConfigResource
    episode: EpisodeResource
    episode_file: EpisodeFileResource
    file_system: FileSystemResource
    health: HealthResource
    history: HistoryResource
    host_config: HostConfigResource
    import_list: ImportListResource
    import_list_config: ImportListConfigResource
    import_list_exclusion: ImportListExclusionResource
    indexer: IndexerResource
    indexer_config: IndexerConfigResource
    indexer_flag: IndexerFlagResource
    language: LanguageResource
    language_profile: LanguageProfileResource
    language_profile_schema: LanguageProfileSchemaResource
    localization: LocalizationResource
    log: LogResource
    log_file: LogFileResource
    manual_import: ManualImportResource
    media_cover: MediaCoverResource
    media_management_config: MediaManagementConfigResource
    metadata: MetadataResource
    missing: MissingResource
    naming_config: NamingConfigResource
    notification: NotificationResource
    parse: ParseResource
    ping: PingResource
    quality_definition: QualityDefinitionResource
    quality_profile: QualityProfileResource
    quality_profile_schema: QualityProfileSchemaResource
    queue: QueueResource
    queue_action: QueueActionResource
    queue_details: QueueDetailsResource
    queue_status: QueueStatusResource
    release: ReleaseResource
    release_profile: ReleaseProfileResource
    release_push: ReleasePushResource
    remote_path_mapping: RemotePathMappingResource
    rename_episode: RenameEpisodeResource
    root_folder: RootFolderResource
    season_pass: SeasonPassResource
    series: SeriesResource
    series_editor: SeriesEditorResource
    series_folder: SeriesFolderResource
    series_import: SeriesImportResource
    series_lookup: SeriesLookupResource
    static_resource: StaticResourceResource
    system: SystemResource
    tag: TagResource
    tag_details: TagDetailsResource
    task: TaskResource
    ui_config: UiConfigResource
    update: UpdateResource
    update_log_file: UpdateLogFileResource


class SonarrV3AsyncResourceAttrs:
    api_info: AsyncApiInfoResource
    authentication: AsyncAuthenticationResource
    auto_tagging: AsyncAutoTaggingResource
    backup: AsyncBackupResource
    blocklist: AsyncBlocklistResource
    calendar: AsyncCalendarResource
    calendar_feed: AsyncCalendarFeedResource
    command: AsyncCommandResource
    custom_filter: AsyncCustomFilterResource
    custom_format: AsyncCustomFormatResource
    cutoff: AsyncCutoffResource
    delay_profile: AsyncDelayProfileResource
    disk_space: AsyncDiskSpaceResource
    download_client: AsyncDownloadClientResource
    download_client_config: AsyncDownloadClientConfigResource
    episode: AsyncEpisodeResource
    episode_file: AsyncEpisodeFileResource
    file_system: AsyncFileSystemResource
    health: AsyncHealthResource
    history: AsyncHistoryResource
    host_config: AsyncHostConfigResource
    import_list: AsyncImportListResource
    import_list_config: AsyncImportListConfigResource
    import_list_exclusion: AsyncImportListExclusionResource
    indexer: AsyncIndexerResource
    indexer_config: AsyncIndexerConfigResource
    indexer_flag: AsyncIndexerFlagResource
    language: AsyncLanguageResource
    language_profile: AsyncLanguageProfileResource
    language_profile_schema: AsyncLanguageProfileSchemaResource
    localization: AsyncLocalizationResource
    log: AsyncLogResource
    log_file: AsyncLogFileResource
    manual_import: AsyncManualImportResource
    media_cover: AsyncMediaCoverResource
    media_management_config: AsyncMediaManagementConfigResource
    metadata: AsyncMetadataResource
    missing: AsyncMissingResource
    naming_config: AsyncNamingConfigResource
    notification: AsyncNotificationResource
    parse: AsyncParseResource
    ping: AsyncPingResource
    quality_definition: AsyncQualityDefinitionResource
    quality_profile: AsyncQualityProfileResource
    quality_profile_schema: AsyncQualityProfileSchemaResource
    queue: AsyncQueueResource
    queue_action: AsyncQueueActionResource
    queue_details: AsyncQueueDetailsResource
    queue_status: AsyncQueueStatusResource
    release: AsyncReleaseResource
    release_profile: AsyncReleaseProfileResource
    release_push: AsyncReleasePushResource
    remote_path_mapping: AsyncRemotePathMappingResource
    rename_episode: AsyncRenameEpisodeResource
    root_folder: AsyncRootFolderResource
    season_pass: AsyncSeasonPassResource
    series: AsyncSeriesResource
    series_editor: AsyncSeriesEditorResource
    series_folder: AsyncSeriesFolderResource
    series_import: AsyncSeriesImportResource
    series_lookup: AsyncSeriesLookupResource
    static_resource: AsyncStaticResourceResource
    system: AsyncSystemResource
    tag: AsyncTagResource
    tag_details: AsyncTagDetailsResource
    task: AsyncTaskResource
    ui_config: AsyncUiConfigResource
    update: AsyncUpdateResource
    update_log_file: AsyncUpdateLogFileResource
