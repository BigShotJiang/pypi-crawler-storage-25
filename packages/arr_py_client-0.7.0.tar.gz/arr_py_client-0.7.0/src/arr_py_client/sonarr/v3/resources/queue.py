"""Queue resource for Sonarr v3 (with pagination + cleanup helpers)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

from arr_py_client._common.janitor import (
    DEFAULT_POLICIES,
    JanitorAction,
    JanitorPolicy,
    JanitorReport,
    plan_actions,
)
from arr_py_client._common.pagination import aiter_pages, iter_pages
from arr_py_client._common.queue import is_stuck as _is_stuck
from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.queue import (
    AsyncQueueResource as _AutoAsyncQueueResource,
)
from arr_py_client.sonarr.v3.resources._auto.queue import (
    QueueResource as _AutoQueueResource,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Iterator, Sequence
    from typing import Any

    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _as_page_dict(paging: object) -> dict[str, Any]:
    records = cast("list[Any]", getattr(paging, "records", []) or [])
    return {"records": records}


@dataclass(frozen=True)
class NukeResult:
    """Outcome of a queue cleanup call.

    Attributes:
        ids: Queue record ids that were removed (or would have been when
            ``dry_run=True``).
        blocklisted: Whether the removed releases were blocklisted.
        redownload: Whether the server will re-search automatically.
        dry_run: ``True`` when no mutations were sent.
    """

    ids: list[int]
    blocklisted: bool
    redownload: bool
    dry_run: bool


class QueueResource(_AutoQueueResource):
    """Sync Sonarr queue resource (curated facade with pagination)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        sort_key: str | None = None,
        include_series: bool | None = None,
    ) -> _models.QueueResourcePagingResource:
        return _ops.list_queue(  # pyright: ignore[reportUnknownMemberType]
            self._transport,
            page=page,
            page_size=page_size,
            sort_key=sort_key,
            include_series=include_series,
        )

    def iter_all(
        self,
        *,
        page_size: int = 50,
        include_series: bool | None = None,
    ) -> Iterator[_models.QueueResource]:
        def fetch(page: int, size: int) -> dict[str, Any]:
            paging = _ops.list_queue(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=size,
                include_series=include_series,
            )
            return _as_page_dict(paging)

        yield from iter_pages(fetch, page_size=page_size)

    def stuck(self) -> list[_models.QueueResource]:
        """Return queue entries with warning/error/failed status.

        Combines three signals: ``status``, ``trackedDownloadStatus``, and
        ``trackedDownloadState`` — any one indicating trouble marks the item
        as stuck.
        """
        return [item for item in self.iter_all(page_size=100) if _is_stuck(item)]

    def nuke_and_redownload(
        self,
        *,
        ids: list[int],
        remove_from_client: bool = True,
        blocklist: bool = True,
        search: bool = True,
        dry_run: bool = False,
    ) -> NukeResult:
        """Remove queue items, optionally blocklist, optionally trigger re-search.

        ``search=True`` maps to ``skipRedownload=False`` — the server will
        automatically re-search after removal. When ``dry_run=True`` no
        mutation is sent; the returned ``ids`` are what *would* be removed.
        """
        if not ids:
            return NukeResult(
                ids=[], blocklisted=blocklist, redownload=search, dry_run=dry_run
            )
        if not dry_run:
            _ops.delete_queue_bulk(
                self._transport,
                remove_from_client=remove_from_client,
                blocklist=blocklist,
                skip_redownload=not search,
                body=_models.QueueBulkResource(ids=list(ids)),
            )
        return NukeResult(
            ids=list(ids),
            blocklisted=blocklist,
            redownload=search,
            dry_run=dry_run,
        )

    def clear_stuck(
        self,
        *,
        blocklist: bool = True,
        search: bool = True,
        dry_run: bool = False,
    ) -> NukeResult:
        """Find stuck items and :meth:`nuke_and_redownload` them."""
        items = self.stuck()
        ids = [
            i for i in (getattr(item, "id", None) for item in items) if i is not None
        ]
        return self.nuke_and_redownload(
            ids=list(ids),
            blocklist=blocklist,
            search=search,
            dry_run=dry_run,
        )

    def janitor(
        self,
        *,
        policies: Sequence[JanitorPolicy] | None = None,
        protected_trackers: Sequence[str] = (),
        dry_run: bool = True,
        journal: Any | None = None,
    ) -> JanitorReport:
        """See :meth:`arr_py_client.radarr.v3.resources.queue.QueueResource.janitor`."""
        effective: Sequence[JanitorPolicy] = (
            policies if policies is not None else DEFAULT_POLICIES
        )
        items = list(self.iter_all(page_size=100))
        matches = plan_actions(items, effective, protected_trackers=protected_trackers)
        report = JanitorReport(matches=matches, dry_run=dry_run)
        report.protected_skips = sum(
            1 for m in matches if m.action == JanitorAction.IGNORE
        )
        if dry_run:
            return report

        blocklist_ids = [
            m.item_id
            for m in matches
            if m.action == JanitorAction.BLOCKLIST_AND_RESEARCH
        ]
        remove_no_block = [
            m.item_id for m in matches if m.action == JanitorAction.REMOVE_NO_BLOCKLIST
        ]
        remove_ids = [m.item_id for m in matches if m.action == JanitorAction.REMOVE]

        if blocklist_ids:
            _ops.delete_queue_bulk(
                self._transport,
                remove_from_client=True,
                blocklist=True,
                skip_redownload=False,
                body=_models.QueueBulkResource(ids=list(blocklist_ids)),
            )
            report.executed_blocklist_ids = list(blocklist_ids)
        if remove_no_block:
            _ops.delete_queue_bulk(
                self._transport,
                remove_from_client=True,
                blocklist=False,
                skip_redownload=True,
                body=_models.QueueBulkResource(ids=list(remove_no_block)),
            )
            report.executed_remove_ids.extend(remove_no_block)
        if remove_ids:
            _ops.delete_queue_bulk(
                self._transport,
                remove_from_client=False,
                blocklist=False,
                skip_redownload=True,
                body=_models.QueueBulkResource(ids=list(remove_ids)),
            )
            report.executed_remove_ids.extend(remove_ids)
        if journal is not None and not dry_run:
            journal.append(
                "queue.janitor",
                app="sonarr",
                ok=True,
                details={
                    "total_matches": len(matches),
                    "blocklisted_count": len(report.executed_blocklist_ids),
                    "removed_count": len(report.executed_remove_ids),
                    "protected_skips": report.protected_skips,
                },
            )
        return report


class AsyncQueueResource(_AutoAsyncQueueResource):
    """Async Sonarr queue resource (curated facade with pagination)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        sort_key: str | None = None,
        include_series: bool | None = None,
    ) -> _models.QueueResourcePagingResource:
        return await _ops.list_queue_async(  # pyright: ignore[reportUnknownMemberType]
            self._transport,
            page=page,
            page_size=page_size,
            sort_key=sort_key,
            include_series=include_series,
        )

    async def aiter_all(
        self,
        *,
        page_size: int = 50,
        include_series: bool | None = None,
    ) -> AsyncIterator[_models.QueueResource]:
        async def fetch(page: int, size: int) -> dict[str, Any]:
            paging = await _ops.list_queue_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=size,
                include_series=include_series,
            )
            return _as_page_dict(paging)

        async for rec in aiter_pages(fetch, page_size=page_size):
            yield rec

    async def stuck(self) -> list[_models.QueueResource]:
        """Return queue entries with warning/error/failed status."""
        return [item async for item in self.aiter_all(page_size=100) if _is_stuck(item)]

    async def nuke_and_redownload(
        self,
        *,
        ids: list[int],
        remove_from_client: bool = True,
        blocklist: bool = True,
        search: bool = True,
        dry_run: bool = False,
    ) -> NukeResult:
        """Async twin of :meth:`QueueResource.nuke_and_redownload`."""
        if not ids:
            return NukeResult(
                ids=[], blocklisted=blocklist, redownload=search, dry_run=dry_run
            )
        if not dry_run:
            await _ops.delete_queue_bulk_async(
                self._transport,
                remove_from_client=remove_from_client,
                blocklist=blocklist,
                skip_redownload=not search,
                body=_models.QueueBulkResource(ids=list(ids)),
            )
        return NukeResult(
            ids=list(ids),
            blocklisted=blocklist,
            redownload=search,
            dry_run=dry_run,
        )

    async def clear_stuck(
        self,
        *,
        blocklist: bool = True,
        search: bool = True,
        dry_run: bool = False,
    ) -> NukeResult:
        """Find stuck items and :meth:`nuke_and_redownload` them."""
        items = await self.stuck()
        ids = [
            i for i in (getattr(item, "id", None) for item in items) if i is not None
        ]
        return await self.nuke_and_redownload(
            ids=list(ids),
            blocklist=blocklist,
            search=search,
            dry_run=dry_run,
        )

    async def janitor(
        self,
        *,
        policies: Sequence[JanitorPolicy] | None = None,
        protected_trackers: Sequence[str] = (),
        dry_run: bool = True,
        journal: Any | None = None,
    ) -> JanitorReport:
        """Async twin of :meth:`QueueResource.janitor`."""
        effective: Sequence[JanitorPolicy] = (
            policies if policies is not None else DEFAULT_POLICIES
        )
        items = [item async for item in self.aiter_all(page_size=100)]
        matches = plan_actions(items, effective, protected_trackers=protected_trackers)
        report = JanitorReport(matches=matches, dry_run=dry_run)
        report.protected_skips = sum(
            1 for m in matches if m.action == JanitorAction.IGNORE
        )
        if dry_run:
            return report

        blocklist_ids = [
            m.item_id
            for m in matches
            if m.action == JanitorAction.BLOCKLIST_AND_RESEARCH
        ]
        remove_no_block = [
            m.item_id for m in matches if m.action == JanitorAction.REMOVE_NO_BLOCKLIST
        ]
        remove_ids = [m.item_id for m in matches if m.action == JanitorAction.REMOVE]

        if blocklist_ids:
            await _ops.delete_queue_bulk_async(
                self._transport,
                remove_from_client=True,
                blocklist=True,
                skip_redownload=False,
                body=_models.QueueBulkResource(ids=list(blocklist_ids)),
            )
            report.executed_blocklist_ids = list(blocklist_ids)
        if remove_no_block:
            await _ops.delete_queue_bulk_async(
                self._transport,
                remove_from_client=True,
                blocklist=False,
                skip_redownload=True,
                body=_models.QueueBulkResource(ids=list(remove_no_block)),
            )
            report.executed_remove_ids.extend(remove_no_block)
        if remove_ids:
            await _ops.delete_queue_bulk_async(
                self._transport,
                remove_from_client=False,
                blocklist=False,
                skip_redownload=True,
                body=_models.QueueBulkResource(ids=list(remove_ids)),
            )
            report.executed_remove_ids.extend(remove_ids)
        if journal is not None and not dry_run:
            journal.append(
                "queue.janitor",
                app="sonarr",
                ok=True,
                details={
                    "total_matches": len(matches),
                    "blocklisted_count": len(report.executed_blocklist_ids),
                    "removed_count": len(report.executed_remove_ids),
                    "protected_skips": report.protected_skips,
                },
            )
        return report
