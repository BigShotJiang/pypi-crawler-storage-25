"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Series."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class SeriesResource:
    """Sync wrapper for the ``Series`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        tvdb_id: int | None = None,
        include_season_images: bool | None = None,
    ) -> list[models.SeriesResource]:
        return cast(
            "list[models.SeriesResource]",
            _ops.list_series(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                tvdb_id=tvdb_id,
                include_season_images=include_season_images,
            ),
        )

    def create(
        self,
        *,
        body: models.SeriesResource | None = None,
    ) -> models.SeriesResource:
        return cast(
            "models.SeriesResource",
            _ops.create_series(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
        *,
        include_season_images: bool | None = None,
    ) -> models.SeriesResource:
        return cast(
            "models.SeriesResource",
            _ops.get_series_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                include_season_images=include_season_images,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        move_files: bool | None = None,
        body: models.SeriesResource | None = None,
    ) -> models.SeriesResource:
        return cast(
            "models.SeriesResource",
            _ops.update_series_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                move_files=move_files,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
        *,
        delete_files: bool | None = None,
        add_import_list_exclusion: bool | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_series_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                delete_files=delete_files,
                add_import_list_exclusion=add_import_list_exclusion,
            ),
        )


class AsyncSeriesResource:
    """Async wrapper for the ``Series`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        tvdb_id: int | None = None,
        include_season_images: bool | None = None,
    ) -> list[models.SeriesResource]:
        return cast(
            "list[models.SeriesResource]",
            await _ops.list_series_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                tvdb_id=tvdb_id,
                include_season_images=include_season_images,
            ),
        )

    async def create(
        self,
        *,
        body: models.SeriesResource | None = None,
    ) -> models.SeriesResource:
        return cast(
            "models.SeriesResource",
            await _ops.create_series_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
        *,
        include_season_images: bool | None = None,
    ) -> models.SeriesResource:
        return cast(
            "models.SeriesResource",
            await _ops.get_series_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                include_season_images=include_season_images,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        move_files: bool | None = None,
        body: models.SeriesResource | None = None,
    ) -> models.SeriesResource:
        return cast(
            "models.SeriesResource",
            await _ops.update_series_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                move_files=move_files,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
        *,
        delete_files: bool | None = None,
        add_import_list_exclusion: bool | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_series_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                delete_files=delete_files,
                add_import_list_exclusion=add_import_list_exclusion,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
