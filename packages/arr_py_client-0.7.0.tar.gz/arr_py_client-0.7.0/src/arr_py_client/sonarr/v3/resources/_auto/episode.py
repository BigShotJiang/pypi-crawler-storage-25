"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Episode."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class EpisodeResource:
    """Sync wrapper for the ``Episode`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
        episode_ids: list[int] | None = None,
        episode_file_id: int | None = None,
        include_series: bool | None = None,
        include_episode_file: bool | None = None,
        include_images: bool | None = None,
    ) -> list[models.EpisodeResource]:
        return cast(
            "list[models.EpisodeResource]",
            _ops.list_episode(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                season_number=season_number,
                episode_ids=episode_ids,
                episode_file_id=episode_file_id,
                include_series=include_series,
                include_episode_file=include_episode_file,
                include_images=include_images,
            ),
        )

    def update_by_id(
        self,
        id: int,
        *,
        body: models.EpisodeResource | None = None,
    ) -> models.EpisodeResource:
        return cast(
            "models.EpisodeResource",
            _ops.update_episode_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.EpisodeResource:
        return cast(
            "models.EpisodeResource",
            _ops.get_episode_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_monitor(
        self,
        *,
        include_images: bool | None = None,
        body: models.EpisodesMonitoredResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.update_episode_monitor(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                include_images=include_images,
                body=body,
            ),
        )


class AsyncEpisodeResource:
    """Async wrapper for the ``Episode`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
        episode_ids: list[int] | None = None,
        episode_file_id: int | None = None,
        include_series: bool | None = None,
        include_episode_file: bool | None = None,
        include_images: bool | None = None,
    ) -> list[models.EpisodeResource]:
        return cast(
            "list[models.EpisodeResource]",
            await _ops.list_episode_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                season_number=season_number,
                episode_ids=episode_ids,
                episode_file_id=episode_file_id,
                include_series=include_series,
                include_episode_file=include_episode_file,
                include_images=include_images,
            ),
        )

    async def update_by_id(
        self,
        id: int,
        *,
        body: models.EpisodeResource | None = None,
    ) -> models.EpisodeResource:
        return cast(
            "models.EpisodeResource",
            await _ops.update_episode_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.EpisodeResource:
        return cast(
            "models.EpisodeResource",
            await _ops.get_episode_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_monitor(
        self,
        *,
        include_images: bool | None = None,
        body: models.EpisodesMonitoredResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.update_episode_monitor_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                include_images=include_images,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
