"""Wanted (missing + cutoff-unmet) resource for Sonarr v3.

Wraps ``GET /api/v3/wanted/missing`` and ``/wanted/cutoff``. Sonarr returns
episodes (not series), with optional ``includeSeries`` / ``includeImages``
expansions that inline the parent series record onto each episode.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client._common.pagination import aiter_pages, iter_pages
from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Iterator
    from typing import Any

    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _as_page_dict(paging: object) -> dict[str, Any]:
    raw = getattr(paging, "records", None)
    records: list[Any] = list(raw) if raw is not None else []
    return {"records": records}


class WantedResource:
    """Sync Sonarr wanted resource (missing + cutoff-unmet episodes)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def missing(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        sort_key: str | None = None,
        monitored: bool | None = None,
        include_series: bool | None = None,
    ) -> _models.EpisodeResourcePagingResource:
        """One page of episodes without a file."""
        return _ops.list_wanted_missing(  # pyright: ignore[reportUnknownMemberType]
            self._transport,
            page=page,
            page_size=page_size,
            sort_key=sort_key,
            monitored=monitored,
            include_series=include_series,
        )

    def iter_missing(
        self,
        *,
        page_size: int = 50,
        monitored: bool | None = None,
        include_series: bool | None = None,
    ) -> Iterator[_models.EpisodeResource]:
        """Yield every missing episode across pages."""

        def fetch(page: int, size: int) -> dict[str, Any]:
            return _as_page_dict(
                _ops.list_wanted_missing(  # pyright: ignore[reportUnknownMemberType]
                    self._transport,
                    page=page,
                    page_size=size,
                    monitored=monitored,
                    include_series=include_series,
                )
            )

        yield from iter_pages(fetch, page_size=page_size)

    def cutoff_unmet(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        sort_key: str | None = None,
        monitored: bool | None = None,
        include_series: bool | None = None,
    ) -> _models.EpisodeResourcePagingResource:
        """One page of episodes whose current file is below the quality cutoff."""
        return _ops.list_wanted_cutoff(  # pyright: ignore[reportUnknownMemberType]
            self._transport,
            page=page,
            page_size=page_size,
            sort_key=sort_key,
            monitored=monitored,
            include_series=include_series,
        )

    def iter_cutoff_unmet(
        self,
        *,
        page_size: int = 50,
        monitored: bool | None = None,
        include_series: bool | None = None,
    ) -> Iterator[_models.EpisodeResource]:
        """Yield every cutoff-unmet episode across pages."""

        def fetch(page: int, size: int) -> dict[str, Any]:
            return _as_page_dict(
                _ops.list_wanted_cutoff(  # pyright: ignore[reportUnknownMemberType]
                    self._transport,
                    page=page,
                    page_size=size,
                    monitored=monitored,
                    include_series=include_series,
                )
            )

        yield from iter_pages(fetch, page_size=page_size)


class AsyncWantedResource:
    """Async Sonarr wanted resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def missing(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        sort_key: str | None = None,
        monitored: bool | None = None,
        include_series: bool | None = None,
    ) -> _models.EpisodeResourcePagingResource:
        return await _ops.list_wanted_missing_async(  # pyright: ignore[reportUnknownMemberType]
            self._transport,
            page=page,
            page_size=page_size,
            sort_key=sort_key,
            monitored=monitored,
            include_series=include_series,
        )

    async def aiter_missing(
        self,
        *,
        page_size: int = 50,
        monitored: bool | None = None,
        include_series: bool | None = None,
    ) -> AsyncIterator[_models.EpisodeResource]:
        async def fetch(page: int, size: int) -> dict[str, Any]:
            return _as_page_dict(
                await _ops.list_wanted_missing_async(  # pyright: ignore[reportUnknownMemberType]
                    self._transport,
                    page=page,
                    page_size=size,
                    monitored=monitored,
                    include_series=include_series,
                )
            )

        async for rec in aiter_pages(fetch, page_size=page_size):
            yield rec

    async def cutoff_unmet(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        sort_key: str | None = None,
        monitored: bool | None = None,
        include_series: bool | None = None,
    ) -> _models.EpisodeResourcePagingResource:
        return await _ops.list_wanted_cutoff_async(  # pyright: ignore[reportUnknownMemberType]
            self._transport,
            page=page,
            page_size=page_size,
            sort_key=sort_key,
            monitored=monitored,
            include_series=include_series,
        )

    async def aiter_cutoff_unmet(
        self,
        *,
        page_size: int = 50,
        monitored: bool | None = None,
        include_series: bool | None = None,
    ) -> AsyncIterator[_models.EpisodeResource]:
        async def fetch(page: int, size: int) -> dict[str, Any]:
            return _as_page_dict(
                await _ops.list_wanted_cutoff_async(  # pyright: ignore[reportUnknownMemberType]
                    self._transport,
                    page=page,
                    page_size=size,
                    monitored=monitored,
                    include_series=include_series,
                )
            )

        async for rec in aiter_pages(fetch, page_size=page_size):
            yield rec
