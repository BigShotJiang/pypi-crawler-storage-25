"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: ImportListExclusion."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ImportListExclusionResource:
    """Sync wrapper for the ``ImportListExclusion`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.ImportListExclusionResource]:
        return cast(
            "list[models.ImportListExclusionResource]",
            _ops.list_importlistexclusion(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create(
        self,
        *,
        body: models.ImportListExclusionResource | None = None,
    ) -> models.ImportListExclusionResource:
        return cast(
            "models.ImportListExclusionResource",
            _ops.create_importlistexclusion(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_paged(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
    ) -> models.ImportListExclusionResourcePagingResource:
        return cast(
            "models.ImportListExclusionResourcePagingResource",
            _ops.list_importlistexclusion_paged(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.ImportListExclusionResource | None = None,
    ) -> models.ImportListExclusionResource:
        return cast(
            "models.ImportListExclusionResource",
            _ops.update_importlistexclusion_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_importlistexclusion_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.ImportListExclusionResource:
        return cast(
            "models.ImportListExclusionResource",
            _ops.get_importlistexclusion_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def delete_bulk(
        self,
        *,
        body: models.ImportListExclusionBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_importlistexclusion_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


class AsyncImportListExclusionResource:
    """Async wrapper for the ``ImportListExclusion`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.ImportListExclusionResource]:
        return cast(
            "list[models.ImportListExclusionResource]",
            await _ops.list_importlistexclusion_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create(
        self,
        *,
        body: models.ImportListExclusionResource | None = None,
    ) -> models.ImportListExclusionResource:
        return cast(
            "models.ImportListExclusionResource",
            await _ops.create_importlistexclusion_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_paged(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
    ) -> models.ImportListExclusionResourcePagingResource:
        return cast(
            "models.ImportListExclusionResourcePagingResource",
            await _ops.list_importlistexclusion_paged_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.ImportListExclusionResource | None = None,
    ) -> models.ImportListExclusionResource:
        return cast(
            "models.ImportListExclusionResource",
            await _ops.update_importlistexclusion_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_importlistexclusion_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.ImportListExclusionResource:
        return cast(
            "models.ImportListExclusionResource",
            await _ops.get_importlistexclusion_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def delete_bulk(
        self,
        *,
        body: models.ImportListExclusionBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_importlistexclusion_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
