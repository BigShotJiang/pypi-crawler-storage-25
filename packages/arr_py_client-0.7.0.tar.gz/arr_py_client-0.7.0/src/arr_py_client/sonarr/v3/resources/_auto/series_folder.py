"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: SeriesFolder."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class SeriesFolderResource:
    """Sync wrapper for the ``SeriesFolder`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.list_series_folder_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncSeriesFolderResource:
    """Async wrapper for the ``SeriesFolder`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.list_series_folder_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
