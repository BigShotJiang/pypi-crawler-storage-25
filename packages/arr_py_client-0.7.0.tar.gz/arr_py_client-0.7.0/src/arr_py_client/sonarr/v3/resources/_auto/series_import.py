"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: SeriesImport."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class SeriesImportResource:
    """Sync wrapper for the ``SeriesImport`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_series_import(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncSeriesImportResource:
    """Async wrapper for the ``SeriesImport`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_series_import_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
