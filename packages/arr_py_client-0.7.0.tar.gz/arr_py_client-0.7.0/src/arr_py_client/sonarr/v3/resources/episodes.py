"""Episodes resource for Sonarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class EpisodesResource:
    """Sync Sonarr episodes resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
        include_images: bool | None = None,
    ) -> list[_models.EpisodeResource]:
        return cast(
            "list[_models.EpisodeResource]",
            _ops.list_episode(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                season_number=season_number,
                include_images=include_images,
            ),
        )

    def get(self, *, id: int) -> _models.EpisodeResource:  # noqa: A002
        return _ops.get_episode_by_id(self._transport, id)


class AsyncEpisodesResource:
    """Async Sonarr episodes resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
        include_images: bool | None = None,
    ) -> list[_models.EpisodeResource]:
        return cast(
            "list[_models.EpisodeResource]",
            await _ops.list_episode_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                season_number=season_number,
                include_images=include_images,
            ),
        )

    async def get(self, *, id: int) -> _models.EpisodeResource:  # noqa: A002
        return await _ops.get_episode_by_id_async(self._transport, id)
