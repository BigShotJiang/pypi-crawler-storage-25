"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: RenameEpisode."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class RenameEpisodeResource:
    """Sync wrapper for the ``RenameEpisode`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
    ) -> list[models.RenameEpisodeResource]:
        return cast(
            "list[models.RenameEpisodeResource]",
            _ops.list_rename(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                season_number=season_number,
            ),
        )


class AsyncRenameEpisodeResource:
    """Async wrapper for the ``RenameEpisode`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
    ) -> list[models.RenameEpisodeResource]:
        return cast(
            "list[models.RenameEpisodeResource]",
            await _ops.list_rename_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                season_number=season_number,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
