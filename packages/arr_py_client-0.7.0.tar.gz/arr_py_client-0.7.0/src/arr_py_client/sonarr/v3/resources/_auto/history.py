"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: History."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class HistoryResource:
    """Sync wrapper for the ``History`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
        event_type: list[int] | None = None,
        episode_id: int | None = None,
        download_id: str | None = None,
        series_ids: list[int] | None = None,
        languages: list[int] | None = None,
        quality: list[int] | None = None,
    ) -> models.HistoryResourcePagingResource:
        return cast(
            "models.HistoryResourcePagingResource",
            _ops.list_history(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                include_series=include_series,
                include_episode=include_episode,
                event_type=event_type,
                episode_id=episode_id,
                download_id=download_id,
                series_ids=series_ids,
                languages=languages,
                quality=quality,
            ),
        )

    def list_since(
        self,
        *,
        date: str | None = None,
        event_type: models.EpisodeHistoryEventType | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
    ) -> list[models.HistoryResource]:
        return cast(
            "list[models.HistoryResource]",
            _ops.list_history_since(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                date=date,
                event_type=event_type,
                include_series=include_series,
                include_episode=include_episode,
            ),
        )

    def list_series(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
        event_type: models.EpisodeHistoryEventType | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
    ) -> list[models.HistoryResource]:
        return cast(
            "list[models.HistoryResource]",
            _ops.list_history_series(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                season_number=season_number,
                event_type=event_type,
                include_series=include_series,
                include_episode=include_episode,
            ),
        )

    def post_failed_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.post_history_failed_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncHistoryResource:
    """Async wrapper for the ``History`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
        event_type: list[int] | None = None,
        episode_id: int | None = None,
        download_id: str | None = None,
        series_ids: list[int] | None = None,
        languages: list[int] | None = None,
        quality: list[int] | None = None,
    ) -> models.HistoryResourcePagingResource:
        return cast(
            "models.HistoryResourcePagingResource",
            await _ops.list_history_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                include_series=include_series,
                include_episode=include_episode,
                event_type=event_type,
                episode_id=episode_id,
                download_id=download_id,
                series_ids=series_ids,
                languages=languages,
                quality=quality,
            ),
        )

    async def list_since(
        self,
        *,
        date: str | None = None,
        event_type: models.EpisodeHistoryEventType | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
    ) -> list[models.HistoryResource]:
        return cast(
            "list[models.HistoryResource]",
            await _ops.list_history_since_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                date=date,
                event_type=event_type,
                include_series=include_series,
                include_episode=include_episode,
            ),
        )

    async def list_series(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
        event_type: models.EpisodeHistoryEventType | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
    ) -> list[models.HistoryResource]:
        return cast(
            "list[models.HistoryResource]",
            await _ops.list_history_series_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                season_number=season_number,
                event_type=event_type,
                include_series=include_series,
                include_episode=include_episode,
            ),
        )

    async def post_failed_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.post_history_failed_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
