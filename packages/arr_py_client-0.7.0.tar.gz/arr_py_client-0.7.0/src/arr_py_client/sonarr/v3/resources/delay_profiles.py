"""Delay profiles resource for Sonarr v3.

Delay profiles introduce a waiting period before a download is grabbed,
giving time for a better release to appear. Ordering matters — the first
matching profile by priority wins, and ``reorder()`` edits the ordering.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.delay_profile import (
    AsyncDelayProfileResource as _AutoAsync,
)
from arr_py_client.sonarr.v3.resources._auto.delay_profile import (
    DelayProfileResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class DelayProfilesResource(_AutoSync):
    """Sync Sonarr delay-profiles resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.DelayProfileResource]:
        return cast(
            "list[_models.DelayProfileResource]",
            _ops.list_delayprofile(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.DelayProfileResource:  # noqa: A002
        return _ops.get_delayprofile_by_id(self._transport, id)

    def create(
        self, *, body: _models.DelayProfileResource
    ) -> _models.DelayProfileResource:
        return _ops.create_delayprofile(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.DelayProfileResource,
    ) -> _models.DelayProfileResource:
        return _ops.update_delayprofile_by_id(self._transport, str(id), body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_delayprofile_by_id(self._transport, id)

    def reorder(
        self,
        *,
        id: int,  # noqa: A002
        after: int | None = None,
    ) -> list[_models.DelayProfileResource]:
        """Move profile ``id`` to immediately after profile ``after``.

        Passing ``after=None`` moves it to the top (above everything else).
        """
        return cast(
            "list[_models.DelayProfileResource]",
            _ops.update_delayprofile_reorder_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport, id, after=after
            ),
        )


class AsyncDelayProfilesResource(_AutoAsync):
    """Async Sonarr delay-profiles resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.DelayProfileResource]:
        return cast(
            "list[_models.DelayProfileResource]",
            await _ops.list_delayprofile_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.DelayProfileResource:  # noqa: A002
        return await _ops.get_delayprofile_by_id_async(self._transport, id)

    async def create(
        self, *, body: _models.DelayProfileResource
    ) -> _models.DelayProfileResource:
        return await _ops.create_delayprofile_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.DelayProfileResource,
    ) -> _models.DelayProfileResource:
        return await _ops.update_delayprofile_by_id_async(
            self._transport, str(id), body=body
        )

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_delayprofile_by_id_async(self._transport, id)

    async def reorder(
        self,
        *,
        id: int,  # noqa: A002
        after: int | None = None,
    ) -> list[_models.DelayProfileResource]:
        return cast(
            "list[_models.DelayProfileResource]",
            await _ops.update_delayprofile_reorder_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport, id, after=after
            ),
        )
