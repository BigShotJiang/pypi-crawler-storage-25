"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Missing."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class MissingResource:
    """Sync wrapper for the ``Missing`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        include_series: bool | None = None,
        include_images: bool | None = None,
        monitored: bool | None = None,
    ) -> models.EpisodeResourcePagingResource:
        return cast(
            "models.EpisodeResourcePagingResource",
            _ops.list_wanted_missing(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                include_series=include_series,
                include_images=include_images,
                monitored=monitored,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.EpisodeResource:
        return cast(
            "models.EpisodeResource",
            _ops.get_wanted_missing_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncMissingResource:
    """Async wrapper for the ``Missing`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        include_series: bool | None = None,
        include_images: bool | None = None,
        monitored: bool | None = None,
    ) -> models.EpisodeResourcePagingResource:
        return cast(
            "models.EpisodeResourcePagingResource",
            await _ops.list_wanted_missing_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                include_series=include_series,
                include_images=include_images,
                monitored=monitored,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.EpisodeResource:
        return cast(
            "models.EpisodeResource",
            await _ops.get_wanted_missing_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
