"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: LanguageProfile."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class LanguageProfileResource:
    """Sync wrapper for the ``LanguageProfile`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.LanguageProfileResource | None = None,
    ) -> models.LanguageProfileResource:
        return cast(
            "models.LanguageProfileResource",
            _ops.create_languageprofile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
    ) -> list[models.LanguageProfileResource]:
        return cast(
            "list[models.LanguageProfileResource]",
            _ops.list_languageprofile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_languageprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.LanguageProfileResource | None = None,
    ) -> models.LanguageProfileResource:
        return cast(
            "models.LanguageProfileResource",
            _ops.update_languageprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.LanguageProfileResource:
        return cast(
            "models.LanguageProfileResource",
            _ops.get_languageprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncLanguageProfileResource:
    """Async wrapper for the ``LanguageProfile`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.LanguageProfileResource | None = None,
    ) -> models.LanguageProfileResource:
        return cast(
            "models.LanguageProfileResource",
            await _ops.create_languageprofile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
    ) -> list[models.LanguageProfileResource]:
        return cast(
            "list[models.LanguageProfileResource]",
            await _ops.list_languageprofile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_languageprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.LanguageProfileResource | None = None,
    ) -> models.LanguageProfileResource:
        return cast(
            "models.LanguageProfileResource",
            await _ops.update_languageprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.LanguageProfileResource:
        return cast(
            "models.LanguageProfileResource",
            await _ops.get_languageprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
