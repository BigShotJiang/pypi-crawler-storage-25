"""Tags resource for Sonarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class TagsResource:
    """Sync Sonarr tags resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list(self) -> list[_models.TagResource]:
        return cast(
            "list[_models.TagResource]",
            _ops.list_tag(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.TagResource:  # noqa: A002
        return _ops.get_tag_by_id(self._transport, id)

    def create(self, *, body: _models.TagResource) -> _models.TagResource:
        return _ops.create_tag(self._transport, body=body)

    def update(self, *, id: int, body: _models.TagResource) -> _models.TagResource:  # noqa: A002
        return _ops.update_tag_by_id(self._transport, str(id), body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_tag_by_id(self._transport, id)

    def details(self) -> list[_models.TagDetailsResource]:
        return cast(
            "list[_models.TagDetailsResource]",
            _ops.list_tag_detail(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )


class AsyncTagsResource:
    """Async Sonarr tags resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list(self) -> list[_models.TagResource]:
        return cast(
            "list[_models.TagResource]",
            await _ops.list_tag_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.TagResource:  # noqa: A002
        return await _ops.get_tag_by_id_async(self._transport, id)

    async def create(self, *, body: _models.TagResource) -> _models.TagResource:
        return await _ops.create_tag_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.TagResource,
    ) -> _models.TagResource:
        return await _ops.update_tag_by_id_async(self._transport, str(id), body=body)

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_tag_by_id_async(self._transport, id)

    async def details(self) -> list[_models.TagDetailsResource]:
        return cast(
            "list[_models.TagDetailsResource]",
            await _ops.list_tag_detail_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
