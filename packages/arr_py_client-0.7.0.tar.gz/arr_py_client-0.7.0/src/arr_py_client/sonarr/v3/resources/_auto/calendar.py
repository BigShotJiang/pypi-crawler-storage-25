"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Calendar."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class CalendarResource:
    """Sync wrapper for the ``Calendar`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        start: str | None = None,
        end: str | None = None,
        unmonitored: bool | None = None,
        include_series: bool | None = None,
        include_episode_file: bool | None = None,
        include_episode_images: bool | None = None,
        tags: str | None = None,
    ) -> list[models.EpisodeResource]:
        return cast(
            "list[models.EpisodeResource]",
            _ops.list_calendar(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                start=start,
                end=end,
                unmonitored=unmonitored,
                include_series=include_series,
                include_episode_file=include_episode_file,
                include_episode_images=include_episode_images,
                tags=tags,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.EpisodeResource:
        return cast(
            "models.EpisodeResource",
            _ops.get_calendar_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncCalendarResource:
    """Async wrapper for the ``Calendar`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        start: str | None = None,
        end: str | None = None,
        unmonitored: bool | None = None,
        include_series: bool | None = None,
        include_episode_file: bool | None = None,
        include_episode_images: bool | None = None,
        tags: str | None = None,
    ) -> list[models.EpisodeResource]:
        return cast(
            "list[models.EpisodeResource]",
            await _ops.list_calendar_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                start=start,
                end=end,
                unmonitored=unmonitored,
                include_series=include_series,
                include_episode_file=include_episode_file,
                include_episode_images=include_episode_images,
                tags=tags,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.EpisodeResource:
        return cast(
            "models.EpisodeResource",
            await _ops.get_calendar_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
