"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: QueueDetails."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class QueueDetailsResource:
    """Sync wrapper for the ``QueueDetails`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        series_id: int | None = None,
        episode_ids: list[int] | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
    ) -> list[models.QueueResource]:
        return cast(
            "list[models.QueueResource]",
            _ops.list_queue_details(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                episode_ids=episode_ids,
                include_series=include_series,
                include_episode=include_episode,
            ),
        )


class AsyncQueueDetailsResource:
    """Async wrapper for the ``QueueDetails`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        series_id: int | None = None,
        episode_ids: list[int] | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
    ) -> list[models.QueueResource]:
        return cast(
            "list[models.QueueResource]",
            await _ops.list_queue_details_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                episode_ids=episode_ids,
                include_series=include_series,
                include_episode=include_episode,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
