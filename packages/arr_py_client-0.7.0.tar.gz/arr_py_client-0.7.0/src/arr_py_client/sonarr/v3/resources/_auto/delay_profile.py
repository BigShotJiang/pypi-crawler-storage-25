"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: DelayProfile."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class DelayProfileResource:
    """Sync wrapper for the ``DelayProfile`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.DelayProfileResource | None = None,
    ) -> models.DelayProfileResource:
        return cast(
            "models.DelayProfileResource",
            _ops.create_delayprofile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
    ) -> list[models.DelayProfileResource]:
        return cast(
            "list[models.DelayProfileResource]",
            _ops.list_delayprofile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_delayprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.DelayProfileResource | None = None,
    ) -> models.DelayProfileResource:
        return cast(
            "models.DelayProfileResource",
            _ops.update_delayprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.DelayProfileResource:
        return cast(
            "models.DelayProfileResource",
            _ops.get_delayprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_reorder_by_id(
        self,
        id: int,
        *,
        after: int | None = None,
    ) -> list[models.DelayProfileResource]:
        return cast(
            "list[models.DelayProfileResource]",
            _ops.update_delayprofile_reorder_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                after=after,
            ),
        )


class AsyncDelayProfileResource:
    """Async wrapper for the ``DelayProfile`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.DelayProfileResource | None = None,
    ) -> models.DelayProfileResource:
        return cast(
            "models.DelayProfileResource",
            await _ops.create_delayprofile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
    ) -> list[models.DelayProfileResource]:
        return cast(
            "list[models.DelayProfileResource]",
            await _ops.list_delayprofile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_delayprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.DelayProfileResource | None = None,
    ) -> models.DelayProfileResource:
        return cast(
            "models.DelayProfileResource",
            await _ops.update_delayprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.DelayProfileResource:
        return cast(
            "models.DelayProfileResource",
            await _ops.get_delayprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_reorder_by_id(
        self,
        id: int,
        *,
        after: int | None = None,
    ) -> list[models.DelayProfileResource]:
        return cast(
            "list[models.DelayProfileResource]",
            await _ops.update_delayprofile_reorder_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                after=after,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
