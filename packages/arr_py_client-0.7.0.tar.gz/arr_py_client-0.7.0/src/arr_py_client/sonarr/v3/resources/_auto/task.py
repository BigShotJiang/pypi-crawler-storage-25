"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Task."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class TaskResource:
    """Sync wrapper for the ``Task`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.TaskResource]:
        return cast(
            "list[models.TaskResource]",
            _ops.list_system_task(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.TaskResource:
        return cast(
            "models.TaskResource",
            _ops.get_system_task_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncTaskResource:
    """Async wrapper for the ``Task`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.TaskResource]:
        return cast(
            "list[models.TaskResource]",
            await _ops.list_system_task_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.TaskResource:
        return cast(
            "models.TaskResource",
            await _ops.get_system_task_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
