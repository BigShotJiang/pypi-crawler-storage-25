"""Import lists management for Sonarr v3.

CRUD + schema + test wrappers over ``/api/v3/importlist``. Sonarr doesn't
expose a consolidated "all fetched items" endpoint (unlike Radarr).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ImportListsResource:
    """Sync Sonarr import lists resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list(self) -> list[_models.ImportListResource]:
        return cast(
            "list[_models.ImportListResource]",
            _ops.list_importlist(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.ImportListResource:  # noqa: A002
        return _ops.get_importlist_by_id(self._transport, id)

    def create(self, *, body: _models.ImportListResource) -> _models.ImportListResource:
        return _ops.create_importlist(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.ImportListResource,
    ) -> _models.ImportListResource:
        return _ops.update_importlist_by_id(self._transport, id, body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_importlist_by_id(self._transport, id)

    def schema(self) -> list[_models.ImportListResource]:
        return cast(
            "list[_models.ImportListResource]",
            _ops.list_importlist_schema(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def test(self, *, body: _models.ImportListResource) -> None:
        _ops.create_importlist_test(self._transport, body=body)


class AsyncImportListsResource:
    """Async Sonarr import lists resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list(self) -> list[_models.ImportListResource]:
        return cast(
            "list[_models.ImportListResource]",
            await _ops.list_importlist_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.ImportListResource:  # noqa: A002
        return await _ops.get_importlist_by_id_async(self._transport, id)

    async def create(
        self, *, body: _models.ImportListResource
    ) -> _models.ImportListResource:
        return await _ops.create_importlist_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.ImportListResource,
    ) -> _models.ImportListResource:
        return await _ops.update_importlist_by_id_async(self._transport, id, body=body)

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_importlist_by_id_async(self._transport, id)

    async def schema(self) -> list[_models.ImportListResource]:
        return cast(
            "list[_models.ImportListResource]",
            await _ops.list_importlist_schema_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def test(self, *, body: _models.ImportListResource) -> None:
        await _ops.create_importlist_test_async(self._transport, body=body)
