"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: SeriesLookup."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class SeriesLookupResource:
    """Sync wrapper for the ``SeriesLookup`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        term: str | None = None,
    ) -> list[models.SeriesResource]:
        return cast(
            "list[models.SeriesResource]",
            _ops.list_series_lookup(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                term=term,
            ),
        )


class AsyncSeriesLookupResource:
    """Async wrapper for the ``SeriesLookup`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        term: str | None = None,
    ) -> list[models.SeriesResource]:
        return cast(
            "list[models.SeriesResource]",
            await _ops.list_series_lookup_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                term=term,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
