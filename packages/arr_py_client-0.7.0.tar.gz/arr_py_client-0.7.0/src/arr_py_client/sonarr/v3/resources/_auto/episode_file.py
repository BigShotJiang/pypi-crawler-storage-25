"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: EpisodeFile."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class EpisodeFileResource:
    """Sync wrapper for the ``EpisodeFile`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        series_id: int | None = None,
        episode_file_ids: list[int] | None = None,
    ) -> list[models.EpisodeFileResource]:
        return cast(
            "list[models.EpisodeFileResource]",
            _ops.list_episodefile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                episode_file_ids=episode_file_ids,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.EpisodeFileResource | None = None,
    ) -> models.EpisodeFileResource:
        return cast(
            "models.EpisodeFileResource",
            _ops.update_episodefile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_episodefile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.EpisodeFileResource:
        return cast(
            "models.EpisodeFileResource",
            _ops.get_episodefile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_editor(
        self,
        *,
        body: models.EpisodeFileListResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.update_episodefile_editor(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def delete_bulk(
        self,
        *,
        body: models.EpisodeFileListResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_episodefile_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def update_bulk(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.update_episodefile_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncEpisodeFileResource:
    """Async wrapper for the ``EpisodeFile`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        series_id: int | None = None,
        episode_file_ids: list[int] | None = None,
    ) -> list[models.EpisodeFileResource]:
        return cast(
            "list[models.EpisodeFileResource]",
            await _ops.list_episodefile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                episode_file_ids=episode_file_ids,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.EpisodeFileResource | None = None,
    ) -> models.EpisodeFileResource:
        return cast(
            "models.EpisodeFileResource",
            await _ops.update_episodefile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_episodefile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.EpisodeFileResource:
        return cast(
            "models.EpisodeFileResource",
            await _ops.get_episodefile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_editor(
        self,
        *,
        body: models.EpisodeFileListResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.update_episodefile_editor_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def delete_bulk(
        self,
        *,
        body: models.EpisodeFileListResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_episodefile_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def update_bulk(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.update_episodefile_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
