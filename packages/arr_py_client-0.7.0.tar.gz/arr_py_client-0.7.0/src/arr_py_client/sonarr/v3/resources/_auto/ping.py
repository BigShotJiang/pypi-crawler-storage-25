"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Ping."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class PingResource:
    """Sync wrapper for the ``Ping`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> models.PingResource:
        return cast(
            "models.PingResource",
            _ops.list_ping(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncPingResource:
    """Async wrapper for the ``Ping`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> models.PingResource:
        return cast(
            "models.PingResource",
            await _ops.list_ping_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
