"""Release profiles resource for Sonarr v3.

Release profiles hold must-contain / must-not-contain term lists and
preferred-term scoring used when evaluating release titles. They're a
complementary tuning surface to custom formats — simpler, title-string-only,
and applied per-tag.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.release_profile import (
    AsyncReleaseProfileResource as _AutoAsync,
)
from arr_py_client.sonarr.v3.resources._auto.release_profile import (
    ReleaseProfileResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ReleaseProfilesResource(_AutoSync):
    """Sync Sonarr release-profiles resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.ReleaseProfileResource]:
        return cast(
            "list[_models.ReleaseProfileResource]",
            _ops.list_releaseprofile(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.ReleaseProfileResource:  # noqa: A002
        return _ops.get_releaseprofile_by_id(self._transport, id)

    def create(
        self, *, body: _models.ReleaseProfileResource
    ) -> _models.ReleaseProfileResource:
        return _ops.create_releaseprofile(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.ReleaseProfileResource,
    ) -> _models.ReleaseProfileResource:
        return _ops.update_releaseprofile_by_id(self._transport, str(id), body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_releaseprofile_by_id(self._transport, id)


class AsyncReleaseProfilesResource(_AutoAsync):
    """Async Sonarr release-profiles resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.ReleaseProfileResource]:
        return cast(
            "list[_models.ReleaseProfileResource]",
            await _ops.list_releaseprofile_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.ReleaseProfileResource:  # noqa: A002
        return await _ops.get_releaseprofile_by_id_async(self._transport, id)

    async def create(
        self, *, body: _models.ReleaseProfileResource
    ) -> _models.ReleaseProfileResource:
        return await _ops.create_releaseprofile_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.ReleaseProfileResource,
    ) -> _models.ReleaseProfileResource:
        return await _ops.update_releaseprofile_by_id_async(
            self._transport, str(id), body=body
        )

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_releaseprofile_by_id_async(self._transport, id)
