"""Manual release search + grab for Sonarr v3.

Sonarr extends Radarr's release search with ``episodeId=`` / ``seasonNumber=``
selectors, letting callers target a single episode or the whole season.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client._common.release_explain import (
    ReleaseExplanation,
    build_explanation,
)
from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _score(
    release: _models.ReleaseResource, prefer_codec: str | None
) -> tuple[int, int, int, int]:
    """See Radarr twin. Default: (seeders desc, quality desc, codec match, size asc)."""
    seeders = getattr(release, "seeders", None) or 0
    quality_obj = getattr(release, "quality", None)
    quality_weight = 0
    if quality_obj is not None:
        q = getattr(quality_obj, "quality", None)
        if q is not None:
            quality_weight = int(getattr(q, "resolution", 0) or 0)
    codec_match = 0
    if prefer_codec:
        title = str(getattr(release, "title", "") or "").lower()
        if prefer_codec.lower() in title:
            codec_match = 1
    size = int(getattr(release, "size", None) or 0)
    return (-seeders, -quality_weight, -codec_match, size)


class ReleasesResource:
    """Sync Sonarr manual release search resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def search(
        self,
        *,
        series_id: int | None = None,
        episode_id: int | None = None,
        season_number: int | None = None,
    ) -> list[_models.ReleaseResource]:
        """Query indexers. Provide one of series/episode/season filters."""
        return cast(
            "list[_models.ReleaseResource]",
            _ops.list_release(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                episode_id=episode_id,
                season_number=season_number,
            ),
        )

    def best(
        self,
        *,
        series_id: int | None = None,
        episode_id: int | None = None,
        season_number: int | None = None,
        min_seeders: int | None = None,
        prefer_codec: str | None = None,
    ) -> _models.ReleaseResource | None:
        candidates = self.search(
            series_id=series_id,
            episode_id=episode_id,
            season_number=season_number,
        )
        if min_seeders is not None:
            candidates = [
                c
                for c in candidates
                if (getattr(c, "seeders", None) or 0) >= min_seeders
            ]
        if not candidates:
            return None
        candidates.sort(key=lambda r: _score(r, prefer_codec))
        return candidates[0]

    def grab(self, *, guid: str, indexer_id: int) -> None:
        body = _models.ReleaseResource.model_validate(
            {"guid": guid, "indexerId": indexer_id}
        )
        _ops.create_release(self._transport, body=body)

    def explain(
        self,
        *,
        series_id: int | None = None,
        episode_id: int | None = None,
        season_number: int | None = None,
    ) -> ReleaseExplanation:
        """Search indexers + annotate each release with accept/reject + reasons.

        See :meth:`arr_py_client.radarr.v3.resources.releases.ReleasesResource.explain`.
        Exactly one of ``series_id`` / ``episode_id`` / ``season_number`` should
        be provided, matching the underlying ``/release`` selector semantics.
        """
        item_id = episode_id or series_id
        item_title: str | None = None
        if series_id is not None:
            try:
                series = _ops.get_series_by_id(self._transport, series_id)
                item_title = getattr(series, "title", None)
            except Exception:  # noqa: S110 - best-effort title lookup
                pass
        raw = cast(
            "list[object]",
            _ops.list_release(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                episode_id=episode_id,
                season_number=season_number,
            ),
        )
        return build_explanation(
            item_id=item_id,
            item_title=item_title,
            current_quality=None,
            current_custom_format_score=None,
            raw_releases=raw,
        )


class AsyncReleasesResource:
    """Async Sonarr manual release search resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def search(
        self,
        *,
        series_id: int | None = None,
        episode_id: int | None = None,
        season_number: int | None = None,
    ) -> list[_models.ReleaseResource]:
        return cast(
            "list[_models.ReleaseResource]",
            await _ops.list_release_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                episode_id=episode_id,
                season_number=season_number,
            ),
        )

    async def best(
        self,
        *,
        series_id: int | None = None,
        episode_id: int | None = None,
        season_number: int | None = None,
        min_seeders: int | None = None,
        prefer_codec: str | None = None,
    ) -> _models.ReleaseResource | None:
        candidates = await self.search(
            series_id=series_id,
            episode_id=episode_id,
            season_number=season_number,
        )
        if min_seeders is not None:
            candidates = [
                c
                for c in candidates
                if (getattr(c, "seeders", None) or 0) >= min_seeders
            ]
        if not candidates:
            return None
        candidates.sort(key=lambda r: _score(r, prefer_codec))
        return candidates[0]

    async def grab(self, *, guid: str, indexer_id: int) -> None:
        body = _models.ReleaseResource.model_validate(
            {"guid": guid, "indexerId": indexer_id}
        )
        await _ops.create_release_async(self._transport, body=body)

    async def explain(
        self,
        *,
        series_id: int | None = None,
        episode_id: int | None = None,
        season_number: int | None = None,
    ) -> ReleaseExplanation:
        """Async twin of :meth:`ReleasesResource.explain`."""
        item_id = episode_id or series_id
        item_title: str | None = None
        if series_id is not None:
            try:
                series = await _ops.get_series_by_id_async(self._transport, series_id)
                item_title = getattr(series, "title", None)
            except Exception:  # noqa: S110 - best-effort title lookup
                pass
        raw = cast(
            "list[object]",
            await _ops.list_release_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                series_id=series_id,
                episode_id=episode_id,
                season_number=season_number,
            ),
        )
        return build_explanation(
            item_id=item_id,
            item_title=item_title,
            current_quality=None,
            current_custom_format_score=None,
            raw_releases=raw,
        )
