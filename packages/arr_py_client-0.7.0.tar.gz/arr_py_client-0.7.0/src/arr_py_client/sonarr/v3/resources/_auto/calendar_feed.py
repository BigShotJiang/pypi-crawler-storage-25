"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: CalendarFeed."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class CalendarFeedResource:
    """Sync wrapper for the ``CalendarFeed`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        past_days: int | None = None,
        future_days: int | None = None,
        tags: str | None = None,
        unmonitored: bool | None = None,
        premieres_only: bool | None = None,
        as_all_day: bool | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.list_feed_v3_calendar_sonarr_ics(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                past_days=past_days,
                future_days=future_days,
                tags=tags,
                unmonitored=unmonitored,
                premieres_only=premieres_only,
                as_all_day=as_all_day,
            ),
        )


class AsyncCalendarFeedResource:
    """Async wrapper for the ``CalendarFeed`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        past_days: int | None = None,
        future_days: int | None = None,
        tags: str | None = None,
        unmonitored: bool | None = None,
        premieres_only: bool | None = None,
        as_all_day: bool | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.list_feed_v3_calendar_sonarr_ics_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                past_days=past_days,
                future_days=future_days,
                tags=tags,
                unmonitored=unmonitored,
                premieres_only=premieres_only,
                as_all_day=as_all_day,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
