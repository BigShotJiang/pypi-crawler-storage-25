"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Command."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class CommandResource:
    """Sync wrapper for the ``Command`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.CommandResource | None = None,
    ) -> models.CommandResource:
        return cast(
            "models.CommandResource",
            _ops.create_command(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
    ) -> list[models.CommandResource]:
        return cast(
            "list[models.CommandResource]",
            _ops.list_command(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_command_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.CommandResource:
        return cast(
            "models.CommandResource",
            _ops.get_command_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncCommandResource:
    """Async wrapper for the ``Command`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.CommandResource | None = None,
    ) -> models.CommandResource:
        return cast(
            "models.CommandResource",
            await _ops.create_command_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
    ) -> list[models.CommandResource]:
        return cast(
            "list[models.CommandResource]",
            await _ops.list_command_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_command_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.CommandResource:
        return cast(
            "models.CommandResource",
            await _ops.get_command_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
