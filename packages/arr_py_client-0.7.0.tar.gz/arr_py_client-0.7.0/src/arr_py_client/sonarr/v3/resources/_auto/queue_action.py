"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: QueueAction."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class QueueActionResource:
    """Sync wrapper for the ``QueueAction`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def post_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.post_queue_grab_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def create_bulk(
        self,
        *,
        body: models.QueueBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.create_queue_grab_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


class AsyncQueueActionResource:
    """Async wrapper for the ``QueueAction`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def post_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.post_queue_grab_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def create_bulk(
        self,
        *,
        body: models.QueueBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.create_queue_grab_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
