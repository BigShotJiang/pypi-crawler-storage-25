"""Calendar resource for Sonarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.calendar import (
    AsyncCalendarResource as _AutoAsyncCalendarResource,
)
from arr_py_client.sonarr.v3.resources._auto.calendar import (
    CalendarResource as _AutoCalendarResource,
)

if TYPE_CHECKING:
    from datetime import datetime

    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _fmt(dt: datetime | str | None) -> str | None:
    if dt is None:
        return None
    if isinstance(dt, str):
        return dt
    return dt.isoformat()


class CalendarResource(_AutoCalendarResource):
    """Sync Sonarr calendar resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(
        self,
        *,
        start: datetime | str | None = None,
        end: datetime | str | None = None,
        unmonitored: bool | None = None,
        include_series: bool | None = None,
    ) -> list[_models.EpisodeResource]:
        return cast(
            "list[_models.EpisodeResource]",
            _ops.list_calendar(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                start=_fmt(start),
                end=_fmt(end),
                unmonitored=unmonitored,
                include_series=include_series,
            ),
        )


class AsyncCalendarResource(_AutoAsyncCalendarResource):
    """Async Sonarr calendar resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(
        self,
        *,
        start: datetime | str | None = None,
        end: datetime | str | None = None,
        unmonitored: bool | None = None,
        include_series: bool | None = None,
    ) -> list[_models.EpisodeResource]:
        return cast(
            "list[_models.EpisodeResource]",
            await _ops.list_calendar_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                start=_fmt(start),
                end=_fmt(end),
                unmonitored=unmonitored,
                include_series=include_series,
            ),
        )
