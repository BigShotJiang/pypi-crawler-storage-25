"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: AutoTagging."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class AutoTaggingResource:
    """Sync wrapper for the ``AutoTagging`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.AutoTaggingResource | None = None,
    ) -> models.AutoTaggingResource:
        return cast(
            "models.AutoTaggingResource",
            _ops.create_autotagging(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
    ) -> list[models.AutoTaggingResource]:
        return cast(
            "list[models.AutoTaggingResource]",
            _ops.list_autotagging(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.AutoTaggingResource | None = None,
    ) -> models.AutoTaggingResource:
        return cast(
            "models.AutoTaggingResource",
            _ops.update_autotagging_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_autotagging_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.AutoTaggingResource:
        return cast(
            "models.AutoTaggingResource",
            _ops.get_autotagging_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_schema(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list_autotagging_schema(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncAutoTaggingResource:
    """Async wrapper for the ``AutoTagging`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.AutoTaggingResource | None = None,
    ) -> models.AutoTaggingResource:
        return cast(
            "models.AutoTaggingResource",
            await _ops.create_autotagging_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
    ) -> list[models.AutoTaggingResource]:
        return cast(
            "list[models.AutoTaggingResource]",
            await _ops.list_autotagging_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.AutoTaggingResource | None = None,
    ) -> models.AutoTaggingResource:
        return cast(
            "models.AutoTaggingResource",
            await _ops.update_autotagging_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_autotagging_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.AutoTaggingResource:
        return cast(
            "models.AutoTaggingResource",
            await _ops.get_autotagging_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_schema(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_autotagging_schema_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
