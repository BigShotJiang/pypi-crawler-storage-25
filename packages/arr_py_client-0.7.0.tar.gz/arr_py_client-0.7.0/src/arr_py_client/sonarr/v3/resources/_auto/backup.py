"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Backup."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class BackupResource:
    """Sync wrapper for the ``Backup`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.BackupResource]:
        return cast(
            "list[models.BackupResource]",
            _ops.list_system_backup(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_system_backup_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def post_restore_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.post_system_backup_restore_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def create_restore_upload(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_system_backup_restore_upload(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncBackupResource:
    """Async wrapper for the ``Backup`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.BackupResource]:
        return cast(
            "list[models.BackupResource]",
            await _ops.list_system_backup_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_system_backup_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def post_restore_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.post_system_backup_restore_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def create_restore_upload(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_system_backup_restore_upload_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
