"""Series resource for Sonarr v3 (curated facade)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, cast

from arr_py_client._common.errors import ArrAlreadyExistsError, ArrNotFoundError
from arr_py_client._common.resolvers import (
    resolve_by_name_or_id,
    resolve_root_folder_path,
    resolve_tag_ids,
)
from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.series import (
    AsyncSeriesResource as _AutoAsyncSeriesResource,
)
from arr_py_client.sonarr.v3.resources._auto.series import (
    SeriesResource as _AutoSeriesResource,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Iterator

    from arr_py_client._common.transport import AsyncTransport, SyncTransport

IfExists = Literal["skip", "update", "error"]


def _matches_filter(
    series: _models.SeriesResource,
    *,
    tag: int | None,
    monitored: bool | None,
    year: int | tuple[int, int] | None,
    quality_profile_id: int | None,
) -> bool:
    if monitored is not None and bool(series.monitored) != monitored:
        return False
    if tag is not None and tag not in (series.tags or []):
        return False
    if (
        quality_profile_id is not None
        and series.quality_profile_id != quality_profile_id
    ):
        return False
    if year is not None and series.year is not None:
        if isinstance(year, int):
            if series.year != year:
                return False
        else:
            lo, hi = year
            if not (lo <= series.year <= hi):
                return False
    return True


@dataclass(frozen=True)
class TagResult:
    """Outcome of a bulk tag operation (Sonarr). See Radarr twin."""

    added: list[int]
    removed: list[int]
    created: list[int]


class SeriesResource(_AutoSeriesResource):
    """Sync Sonarr series resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.SeriesResource]:
        return cast(
            "list[_models.SeriesResource]",
            _ops.list_series(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.SeriesResource:  # noqa: A002
        return _ops.get_series_by_id(self._transport, id)

    def get_or_none(self, *, id: int) -> _models.SeriesResource | None:  # noqa: A002
        try:
            return self.get(id=id)
        except ArrNotFoundError:
            return None

    def create(  # pyright: ignore[reportIncompatibleMethodOverride]
        self, *, body: _models.SeriesResource
    ) -> _models.SeriesResource:
        return _ops.create_series(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.SeriesResource,
    ) -> _models.SeriesResource:
        return _ops.update_series_by_id(self._transport, str(id), body=body)

    def delete(
        self,
        *,
        id: int,  # noqa: A002
        delete_files: bool | None = None,
        add_import_list_exclusion: bool | None = None,
    ) -> None:
        _ops.delete_series_by_id(
            self._transport,
            id,
            delete_files=delete_files,
            add_import_list_exclusion=add_import_list_exclusion,
        )

    def lookup(self, *, term: str) -> list[_models.SeriesResource]:
        """Full-text lookup against TVDB via Sonarr's proxy."""
        response = self._transport.request(
            "GET", "/series/lookup", params={"term": term}
        )
        payload = cast("list[Any] | dict[str, Any]", response.json())
        items = payload if isinstance(payload, list) else [payload]
        return [_models.SeriesResource.model_validate(item) for item in items]

    def lookup_by_tvdb(self, *, tvdb_id: int) -> list[_models.SeriesResource]:
        """Lookup a series by TVDB id."""
        return self.lookup(term=f"tvdb:{tvdb_id}")

    def add(
        self,
        *,
        # identity (exactly one required)
        tvdb_id: int | None = None,
        title: str | None = None,
        # quality (exactly one)
        quality_profile_id: int | None = None,
        quality: str | int | None = None,
        # root folder (exactly one, or auto if only one configured)
        root_folder_path: str | None = None,
        root_folder: str | None = None,
        # optional
        tags: list[str | int] | None = None,
        create_missing_tags: bool = True,
        monitored: bool = True,
        season_folder: bool = True,
        search_on_add: bool = True,
        language_profile_id: int | None = None,
        if_exists: IfExists = "error",
    ) -> _models.SeriesResource:
        """Look up a series and add it to Sonarr in one call.

        Either ``tvdb_id`` or ``title`` must be given (title performs a TVDB
        lookup and uses the top match). ``quality`` accepts a name or id;
        ``root_folder`` accepts a path (auto-picks if only one is configured).
        ``tags`` accepts labels or ids; unknown labels are created when
        ``create_missing_tags=True``.

        ``if_exists`` controls duplicate handling when a series with the same
        ``tvdb_id`` already exists: ``"error"`` (default) raises
        :class:`ArrAlreadyExistsError`; ``"skip"`` returns the existing series;
        ``"update"`` PUTs the resolved fields onto it.
        """
        lookup = self._lookup_for_add(tvdb_id=tvdb_id, title=title)
        effective_tvdb = lookup.tvdb_id or tvdb_id
        if if_exists != "error":
            existing = self._existing_by_tvdb(effective_tvdb)
            if existing is not None:
                return self._handle_existing(
                    existing,
                    if_exists=if_exists,
                    quality_profile_id=quality_profile_id,
                    quality=quality,
                    root_folder_path=root_folder_path,
                    root_folder=root_folder,
                    tags=tags,
                    create_missing_tags=create_missing_tags,
                    monitored=monitored,
                )

        resolved_qp = self._resolve_quality(quality_profile_id, quality)
        resolved_rf = self._resolve_root_folder(root_folder_path, root_folder)
        resolved_tags = self._resolve_tags(tags, create_missing=create_missing_tags)

        lookup.quality_profile_id = resolved_qp
        lookup.root_folder_path = resolved_rf
        lookup.monitored = monitored
        lookup.season_folder = season_folder
        if language_profile_id is not None:
            lookup.language_profile_id = language_profile_id
        lookup.add_options = _models.AddSeriesOptions(
            search_for_missing_episodes=search_on_add
        )
        if resolved_tags is not None:
            lookup.tags = resolved_tags
        return _ops.create_series(self._transport, body=lookup)

    # ---- helpers for .add() ----

    def _lookup_for_add(
        self, *, tvdb_id: int | None, title: str | None
    ) -> _models.SeriesResource:
        if (tvdb_id is None) == (title is None):
            msg = "add() requires exactly one of tvdb_id= or title="
            raise ValueError(msg)
        if tvdb_id is not None:
            results = self.lookup_by_tvdb(tvdb_id=tvdb_id)
            if not results:
                msg = f"no series found for tvdb_id={tvdb_id}"
                raise ValueError(msg)
            return results[0]
        assert title is not None  # noqa: S101  # narrowed by check above
        results = self.lookup(term=title)
        if not results:
            msg = f"no Sonarr TVDB match found for title={title!r}"
            raise ValueError(msg)
        return results[0]

    def _existing_by_tvdb(self, tvdb_id: int | None) -> _models.SeriesResource | None:
        if tvdb_id is None:
            return None
        for series in self.list():
            if getattr(series, "tvdb_id", None) == tvdb_id and getattr(
                series, "id", None
            ):
                return series
        return None

    def _handle_existing(
        self,
        existing: _models.SeriesResource,
        *,
        if_exists: IfExists,
        quality_profile_id: int | None,
        quality: str | int | None,
        root_folder_path: str | None,
        root_folder: str | None,
        tags: list[str | int] | None,
        create_missing_tags: bool,
        monitored: bool,
    ) -> _models.SeriesResource:
        if if_exists == "error":
            raise ArrAlreadyExistsError(
                field="tvdb_id", existing_id=getattr(existing, "id", None)
            )
        if if_exists == "skip":
            return existing
        if quality_profile_id is not None or quality is not None:
            existing.quality_profile_id = self._resolve_quality(
                quality_profile_id, quality
            )
        if root_folder_path is not None or root_folder is not None:
            existing.root_folder_path = self._resolve_root_folder(
                root_folder_path, root_folder
            )
        if tags is not None:
            resolved = self._resolve_tags(tags, create_missing=create_missing_tags)
            if resolved is not None:
                existing.tags = resolved
        existing.monitored = monitored
        existing_id = getattr(existing, "id", None)
        assert existing_id is not None  # noqa: S101  # from list() filter
        return _ops.update_series_by_id(
            self._transport, str(existing_id), body=existing
        )

    def _resolve_quality(
        self, quality_profile_id: int | None, quality: str | int | None
    ) -> int:
        if quality_profile_id is not None and quality is not None:
            msg = "pass exactly one of quality_profile_id= or quality="
            raise ValueError(msg)
        if quality_profile_id is not None:
            return quality_profile_id
        if quality is None:
            msg = "add() requires quality_profile_id= or quality="
            raise ValueError(msg)
        profiles = cast(
            "list[_models.QualityProfileResource]",
            _ops.list_qualityprofile(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_by_name_or_id(
            items=profiles, ref=quality, field="quality_profile"
        )

    def _resolve_root_folder(
        self, root_folder_path: str | None, root_folder: str | None
    ) -> str:
        if root_folder_path is not None and root_folder is not None:
            msg = "pass exactly one of root_folder_path= or root_folder="
            raise ValueError(msg)
        if root_folder_path is not None:
            return root_folder_path
        folders = cast(
            "list[_models.RootFolderResource]",
            _ops.list_rootfolder(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_root_folder_path(items=folders, ref=root_folder)

    def _resolve_tags(
        self, tags: list[str | int] | None, *, create_missing: bool
    ) -> list[int] | None:
        if tags is None:
            return None
        existing_tags = cast(
            "list[_models.TagResource]",
            _ops.list_tag(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

        def factory(label: str) -> _models.TagResource:
            return _ops.create_tag(
                self._transport, body=_models.TagResource(id=0, label=label)
            )

        return resolve_tag_ids(
            tags=existing_tags,
            refs=tags,
            create_missing=factory if create_missing else None,
        )

    def delete_many(
        self,
        *,
        ids: list[int],
        delete_files: bool = False,
        add_import_list_exclusion: bool = False,
    ) -> None:
        """Delete many series in one call via Sonarr's ``series/editor`` endpoint."""
        body = _models.SeriesEditorResource(
            series_ids=list(ids),
            delete_files=delete_files,
            add_import_list_exclusion=add_import_list_exclusion,
        )
        _ops.delete_series_editor(self._transport, body=body)

    def update_many(self, *, body: _models.SeriesEditorResource) -> None:
        """Bulk-edit fields across many series via ``series/editor``.

        For a name-style ergonomic wrapper, see :meth:`bulk_edit`.
        """
        _ops.update_series_editor(self._transport, body=body)

    def bulk_edit(
        self,
        *,
        ids: list[int],
        monitored: bool | None = None,
        quality: str | int | None = None,
        quality_profile_id: int | None = None,
        root_folder: str | None = None,
        root_folder_path: str | None = None,
        tags: list[str | int] | None = None,
        apply_tags: Literal["add", "remove", "replace"] = "add",
        season_folder: bool | None = None,
        series_type: Literal["standard", "daily", "anime"] | None = None,
        move_files: bool | None = None,
        create_missing_tags: bool = True,
        journal: Any | None = None,
    ) -> None:
        """Ergonomic bulk-edit: pass names, we resolve ids + POST ``series/editor``.

        Mirrors :meth:`add`'s convention for ``quality``, ``root_folder``,
        ``tags``. Any arg left ``None`` is omitted, so only fields you set are
        touched. ``apply_tags`` controls how ``tags`` combines with each
        series's existing tags.

        Pass ``journal=`` for persistent audit logging.
        """
        if not ids:
            msg = "bulk_edit requires at least one id"
            raise ValueError(msg)
        qp_id: int | None
        if quality_profile_id is not None or quality is not None:
            qp_id = self._resolve_quality(quality_profile_id, quality)
        else:
            qp_id = None
        rf_path: str | None
        if root_folder_path is not None or root_folder is not None:
            rf_path = self._resolve_root_folder(root_folder_path, root_folder)
        else:
            rf_path = None
        tag_ids = self._resolve_tags(tags, create_missing=create_missing_tags)
        body = _models.SeriesEditorResource(
            series_ids=list(ids),
            monitored=monitored,
            quality_profile_id=qp_id,
            root_folder_path=rf_path,
            tags=tag_ids,
            apply_tags=_models.ApplyTags(apply_tags) if tag_ids is not None else None,
            season_folder=season_folder,
            series_type=_models.SeriesTypes(series_type) if series_type else None,
            move_files=move_files,
        )
        _ops.update_series_editor(self._transport, body=body)
        if journal is not None:
            journal.append(
                "series.bulk_edit",
                app="sonarr",
                ok=True,
                details={
                    "count": len(ids),
                    "ids": list(ids),
                    "fields_touched": sorted(
                        k
                        for k, v in {
                            "monitored": monitored,
                            "quality_profile_id": qp_id,
                            "root_folder_path": rf_path,
                            "tags": tag_ids,
                            "season_folder": season_folder,
                            "series_type": series_type,
                            "move_files": move_files,
                        }.items()
                        if v is not None
                    ),
                },
            )

    # ---- pagination + filtering ----

    def iter_all(self) -> Iterator[_models.SeriesResource]:
        """Yield every series (Sonarr returns the full list in one call)."""
        yield from self.list()

    def page(self, *, page: int = 1, size: int = 50) -> list[_models.SeriesResource]:
        if page < 1 or size < 1:
            msg = "page and size must be >= 1"
            raise ValueError(msg)
        start = (page - 1) * size
        return self.list()[start : start + size]

    def filter(
        self,
        *,
        tag: str | int | None = None,
        monitored: bool | None = None,
        year: int | tuple[int, int] | None = None,
        quality_profile: str | int | None = None,
    ) -> Iterator[_models.SeriesResource]:
        tag_id = self._resolve_tag_ref(tag) if tag is not None else None
        qp_id = (
            self._resolve_quality(None, quality_profile)
            if quality_profile is not None
            else None
        )
        for series in self.list():
            if _matches_filter(
                series,
                tag=tag_id,
                monitored=monitored,
                year=year,
                quality_profile_id=qp_id,
            ):
                yield series

    def _resolve_tag_ref(self, tag: str | int) -> int:
        existing = cast(
            "list[_models.TagResource]",
            _ops.list_tag(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_by_name_or_id(
            items=existing, ref=tag, field="tag", name_attr="label"
        )

    # ---- bulk tagging ----

    def tag(
        self,
        *,
        ids: list[int],
        add: list[str | int] | None = None,
        remove: list[str | int] | None = None,
        create_missing: bool = True,
    ) -> TagResult:
        """Bulk add/remove tags across series via ``series/editor``."""
        if not ids:
            return TagResult(added=[], removed=[], created=[])
        add_refs = list(add or [])
        remove_refs = list(remove or [])
        if not add_refs and not remove_refs:
            return TagResult(added=[], removed=[], created=[])

        existing_tags = cast(
            "list[_models.TagResource]",
            _ops.list_tag(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        known_labels = {
            str(getattr(t, "label", "")).strip().lower()
            for t in existing_tags
            if getattr(t, "label", None)
        }

        def factory(label: str) -> _models.TagResource:
            return _ops.create_tag(
                self._transport, body=_models.TagResource(id=0, label=label)
            )

        created_ids: list[int] = []
        if add_refs:
            before_known = known_labels.copy()
            add_ids = resolve_tag_ids(
                tags=existing_tags,
                refs=add_refs,
                create_missing=factory if create_missing else None,
            )
            for ref, resolved_id in zip(add_refs, add_ids, strict=False):
                if (
                    isinstance(ref, str)
                    and ref.strip().lower() not in before_known
                    and resolved_id not in created_ids
                ):
                    created_ids.append(resolved_id)
        else:
            add_ids = []
        remove_ids = (
            resolve_tag_ids(tags=existing_tags, refs=remove_refs, create_missing=None)
            if remove_refs
            else []
        )

        if add_ids:
            _ops.update_series_editor(
                self._transport,
                body=_models.SeriesEditorResource(
                    series_ids=list(ids),
                    tags=add_ids,
                    apply_tags=_models.ApplyTags.add,
                ),
            )
        if remove_ids:
            _ops.update_series_editor(
                self._transport,
                body=_models.SeriesEditorResource(
                    series_ids=list(ids),
                    tags=remove_ids,
                    apply_tags=_models.ApplyTags.remove,
                ),
            )
        return TagResult(added=add_ids, removed=remove_ids, created=created_ids)


class AsyncSeriesResource(_AutoAsyncSeriesResource):
    """Async Sonarr series resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.SeriesResource]:
        return cast(
            "list[_models.SeriesResource]",
            await _ops.list_series_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.SeriesResource:  # noqa: A002
        return await _ops.get_series_by_id_async(self._transport, id)

    async def get_or_none(self, *, id: int) -> _models.SeriesResource | None:  # noqa: A002
        try:
            return await self.get(id=id)
        except ArrNotFoundError:
            return None

    async def create(  # pyright: ignore[reportIncompatibleMethodOverride]
        self, *, body: _models.SeriesResource
    ) -> _models.SeriesResource:
        return await _ops.create_series_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.SeriesResource,
    ) -> _models.SeriesResource:
        return await _ops.update_series_by_id_async(self._transport, str(id), body=body)

    async def delete(
        self,
        *,
        id: int,  # noqa: A002
        delete_files: bool | None = None,
        add_import_list_exclusion: bool | None = None,
    ) -> None:
        await _ops.delete_series_by_id_async(
            self._transport,
            id,
            delete_files=delete_files,
            add_import_list_exclusion=add_import_list_exclusion,
        )

    async def lookup(self, *, term: str) -> list[_models.SeriesResource]:
        response = await self._transport.request(
            "GET", "/series/lookup", params={"term": term}
        )
        payload = cast("list[Any] | dict[str, Any]", response.json())
        items = payload if isinstance(payload, list) else [payload]
        return [_models.SeriesResource.model_validate(item) for item in items]

    async def lookup_by_tvdb(self, *, tvdb_id: int) -> list[_models.SeriesResource]:
        return await self.lookup(term=f"tvdb:{tvdb_id}")

    async def add(
        self,
        *,
        tvdb_id: int | None = None,
        title: str | None = None,
        quality_profile_id: int | None = None,
        quality: str | int | None = None,
        root_folder_path: str | None = None,
        root_folder: str | None = None,
        tags: list[str | int] | None = None,
        create_missing_tags: bool = True,
        monitored: bool = True,
        season_folder: bool = True,
        search_on_add: bool = True,
        language_profile_id: int | None = None,
        if_exists: IfExists = "error",
    ) -> _models.SeriesResource:
        """Async twin of :meth:`SeriesResource.add`. See that docstring."""
        lookup = await self._lookup_for_add(tvdb_id=tvdb_id, title=title)
        effective_tvdb = lookup.tvdb_id or tvdb_id
        if if_exists != "error":
            existing = await self._existing_by_tvdb(effective_tvdb)
            if existing is not None:
                return await self._handle_existing(
                    existing,
                    if_exists=if_exists,
                    quality_profile_id=quality_profile_id,
                    quality=quality,
                    root_folder_path=root_folder_path,
                    root_folder=root_folder,
                    tags=tags,
                    create_missing_tags=create_missing_tags,
                    monitored=monitored,
                )

        resolved_qp = await self._resolve_quality(quality_profile_id, quality)
        resolved_rf = await self._resolve_root_folder(root_folder_path, root_folder)
        resolved_tags = await self._resolve_tags(
            tags, create_missing=create_missing_tags
        )

        lookup.quality_profile_id = resolved_qp
        lookup.root_folder_path = resolved_rf
        lookup.monitored = monitored
        lookup.season_folder = season_folder
        if language_profile_id is not None:
            lookup.language_profile_id = language_profile_id
        lookup.add_options = _models.AddSeriesOptions(
            search_for_missing_episodes=search_on_add
        )
        if resolved_tags is not None:
            lookup.tags = resolved_tags
        return await _ops.create_series_async(self._transport, body=lookup)

    # ---- async helpers for .add() ----

    async def _lookup_for_add(
        self, *, tvdb_id: int | None, title: str | None
    ) -> _models.SeriesResource:
        if (tvdb_id is None) == (title is None):
            msg = "add() requires exactly one of tvdb_id= or title="
            raise ValueError(msg)
        if tvdb_id is not None:
            results = await self.lookup_by_tvdb(tvdb_id=tvdb_id)
            if not results:
                msg = f"no series found for tvdb_id={tvdb_id}"
                raise ValueError(msg)
            return results[0]
        assert title is not None  # noqa: S101  # narrowed by check above
        results = await self.lookup(term=title)
        if not results:
            msg = f"no Sonarr TVDB match found for title={title!r}"
            raise ValueError(msg)
        return results[0]

    async def _existing_by_tvdb(
        self, tvdb_id: int | None
    ) -> _models.SeriesResource | None:
        if tvdb_id is None:
            return None
        for series in await self.list():
            if getattr(series, "tvdb_id", None) == tvdb_id and getattr(
                series, "id", None
            ):
                return series
        return None

    async def _handle_existing(
        self,
        existing: _models.SeriesResource,
        *,
        if_exists: IfExists,
        quality_profile_id: int | None,
        quality: str | int | None,
        root_folder_path: str | None,
        root_folder: str | None,
        tags: list[str | int] | None,
        create_missing_tags: bool,
        monitored: bool,
    ) -> _models.SeriesResource:
        if if_exists == "error":
            raise ArrAlreadyExistsError(
                field="tvdb_id", existing_id=getattr(existing, "id", None)
            )
        if if_exists == "skip":
            return existing
        if quality_profile_id is not None or quality is not None:
            existing.quality_profile_id = await self._resolve_quality(
                quality_profile_id, quality
            )
        if root_folder_path is not None or root_folder is not None:
            existing.root_folder_path = await self._resolve_root_folder(
                root_folder_path, root_folder
            )
        if tags is not None:
            resolved = await self._resolve_tags(
                tags, create_missing=create_missing_tags
            )
            if resolved is not None:
                existing.tags = resolved
        existing.monitored = monitored
        existing_id = getattr(existing, "id", None)
        assert existing_id is not None  # noqa: S101  # from list() filter
        return await _ops.update_series_by_id_async(
            self._transport, str(existing_id), body=existing
        )

    async def _resolve_quality(
        self, quality_profile_id: int | None, quality: str | int | None
    ) -> int:
        if quality_profile_id is not None and quality is not None:
            msg = "pass exactly one of quality_profile_id= or quality="
            raise ValueError(msg)
        if quality_profile_id is not None:
            return quality_profile_id
        if quality is None:
            msg = "add() requires quality_profile_id= or quality="
            raise ValueError(msg)
        profiles = cast(
            "list[_models.QualityProfileResource]",
            await _ops.list_qualityprofile_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_by_name_or_id(
            items=profiles, ref=quality, field="quality_profile"
        )

    async def _resolve_root_folder(
        self, root_folder_path: str | None, root_folder: str | None
    ) -> str:
        if root_folder_path is not None and root_folder is not None:
            msg = "pass exactly one of root_folder_path= or root_folder="
            raise ValueError(msg)
        if root_folder_path is not None:
            return root_folder_path
        folders = cast(
            "list[_models.RootFolderResource]",
            await _ops.list_rootfolder_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        return resolve_root_folder_path(items=folders, ref=root_folder)

    async def _resolve_tags(
        self, tags: list[str | int] | None, *, create_missing: bool
    ) -> list[int] | None:
        if tags is None:
            return None
        existing_tags = cast(
            "list[_models.TagResource]",
            await _ops.list_tag_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        if create_missing:
            by_label = {
                str(getattr(t, "label", "")).strip().lower(): t
                for t in existing_tags
                if getattr(t, "label", None)
            }
            for ref in tags:
                if isinstance(ref, str) and ref.strip().lower() not in by_label:
                    created = await _ops.create_tag_async(
                        self._transport,
                        body=_models.TagResource(id=0, label=ref),
                    )
                    existing_tags.append(created)
                    by_label[ref.strip().lower()] = created
        return resolve_tag_ids(tags=existing_tags, refs=tags, create_missing=None)

    async def delete_many(
        self,
        *,
        ids: list[int],
        delete_files: bool = False,
        add_import_list_exclusion: bool = False,
    ) -> None:
        """Delete many series in one call via Sonarr's ``series/editor`` endpoint."""
        body = _models.SeriesEditorResource(
            series_ids=list(ids),
            delete_files=delete_files,
            add_import_list_exclusion=add_import_list_exclusion,
        )
        await _ops.delete_series_editor_async(self._transport, body=body)

    async def update_many(self, *, body: _models.SeriesEditorResource) -> None:
        """Bulk-edit fields across many series via ``series/editor``."""
        await _ops.update_series_editor_async(self._transport, body=body)

    async def bulk_edit(
        self,
        *,
        ids: list[int],
        monitored: bool | None = None,
        quality: str | int | None = None,
        quality_profile_id: int | None = None,
        root_folder: str | None = None,
        root_folder_path: str | None = None,
        tags: list[str | int] | None = None,
        apply_tags: Literal["add", "remove", "replace"] = "add",
        season_folder: bool | None = None,
        series_type: Literal["standard", "daily", "anime"] | None = None,
        move_files: bool | None = None,
        create_missing_tags: bool = True,
        journal: Any | None = None,
    ) -> None:
        """Async twin of :meth:`SeriesResource.bulk_edit`."""
        if not ids:
            msg = "bulk_edit requires at least one id"
            raise ValueError(msg)
        qp_id: int | None
        if quality_profile_id is not None or quality is not None:
            qp_id = await self._resolve_quality(quality_profile_id, quality)
        else:
            qp_id = None
        rf_path: str | None
        if root_folder_path is not None or root_folder is not None:
            rf_path = await self._resolve_root_folder(root_folder_path, root_folder)
        else:
            rf_path = None
        tag_ids = await self._resolve_tags(tags, create_missing=create_missing_tags)
        body = _models.SeriesEditorResource(
            series_ids=list(ids),
            monitored=monitored,
            quality_profile_id=qp_id,
            root_folder_path=rf_path,
            tags=tag_ids,
            apply_tags=_models.ApplyTags(apply_tags) if tag_ids is not None else None,
            season_folder=season_folder,
            series_type=_models.SeriesTypes(series_type) if series_type else None,
            move_files=move_files,
        )
        await _ops.update_series_editor_async(self._transport, body=body)
        if journal is not None:
            journal.append(
                "series.bulk_edit",
                app="sonarr",
                ok=True,
                details={
                    "count": len(ids),
                    "ids": list(ids),
                    "fields_touched": sorted(
                        k
                        for k, v in {
                            "monitored": monitored,
                            "quality_profile_id": qp_id,
                            "root_folder_path": rf_path,
                            "tags": tag_ids,
                            "season_folder": season_folder,
                            "series_type": series_type,
                            "move_files": move_files,
                        }.items()
                        if v is not None
                    ),
                },
            )

    # ---- pagination + filtering ----

    async def aiter_all(self) -> AsyncIterator[_models.SeriesResource]:
        for series in await self.list():
            yield series

    async def page(
        self, *, page: int = 1, size: int = 50
    ) -> list[_models.SeriesResource]:
        if page < 1 or size < 1:
            msg = "page and size must be >= 1"
            raise ValueError(msg)
        start = (page - 1) * size
        return (await self.list())[start : start + size]

    async def filter(
        self,
        *,
        tag: str | int | None = None,
        monitored: bool | None = None,
        year: int | tuple[int, int] | None = None,
        quality_profile: str | int | None = None,
    ) -> list[_models.SeriesResource]:
        tag_id: int | None = None
        if tag is not None:
            existing = cast(
                "list[_models.TagResource]",
                await _ops.list_tag_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
            )
            tag_id = resolve_by_name_or_id(
                items=existing, ref=tag, field="tag", name_attr="label"
            )
        qp_id = None
        if quality_profile is not None:
            qp_id = await self._resolve_quality(None, quality_profile)
        return [
            s
            for s in await self.list()
            if _matches_filter(
                s,
                tag=tag_id,
                monitored=monitored,
                year=year,
                quality_profile_id=qp_id,
            )
        ]

    # ---- bulk tagging ----

    async def tag(
        self,
        *,
        ids: list[int],
        add: list[str | int] | None = None,
        remove: list[str | int] | None = None,
        create_missing: bool = True,
    ) -> TagResult:
        """Async twin of :meth:`SeriesResource.tag`."""
        if not ids:
            return TagResult(added=[], removed=[], created=[])
        add_refs = list(add or [])
        remove_refs = list(remove or [])
        if not add_refs and not remove_refs:
            return TagResult(added=[], removed=[], created=[])

        existing_tags = cast(
            "list[_models.TagResource]",
            await _ops.list_tag_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )
        known_labels = {
            str(getattr(t, "label", "")).strip().lower()
            for t in existing_tags
            if getattr(t, "label", None)
        }
        created_ids: list[int] = []
        if add_refs and create_missing:
            for ref in add_refs:
                if isinstance(ref, str) and ref.strip().lower() not in known_labels:
                    created = await _ops.create_tag_async(
                        self._transport,
                        body=_models.TagResource(id=0, label=ref),
                    )
                    existing_tags.append(created)
                    known_labels.add(ref.strip().lower())
                    cid = getattr(created, "id", None)
                    if isinstance(cid, int) and cid not in created_ids:
                        created_ids.append(cid)
        add_ids = (
            resolve_tag_ids(tags=existing_tags, refs=add_refs, create_missing=None)
            if add_refs
            else []
        )
        remove_ids = (
            resolve_tag_ids(tags=existing_tags, refs=remove_refs, create_missing=None)
            if remove_refs
            else []
        )

        if add_ids:
            await _ops.update_series_editor_async(
                self._transport,
                body=_models.SeriesEditorResource(
                    series_ids=list(ids),
                    tags=add_ids,
                    apply_tags=_models.ApplyTags.add,
                ),
            )
        if remove_ids:
            await _ops.update_series_editor_async(
                self._transport,
                body=_models.SeriesEditorResource(
                    series_ids=list(ids),
                    tags=remove_ids,
                    apply_tags=_models.ApplyTags.remove,
                ),
            )
        return TagResult(added=add_ids, removed=remove_ids, created=created_ids)
