"""Commands resource for Sonarr v3 with a ``wait_for`` helper + typed named commands."""

from __future__ import annotations

import asyncio
import time
from enum import StrEnum
from typing import TYPE_CHECKING, Any, cast

import anyio

from arr_py_client._common.errors import ArrTimeoutError
from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


_TERMINAL_STATUSES = frozenset({"completed", "failed", "aborted", "cancelled"})


class KnownCommand(StrEnum):
    """Commonly-used Sonarr command names.

    This is not exhaustive — Sonarr exposes commands from C# source that
    aren't in the OpenAPI spec. Use :meth:`CommandsResource.post` with a raw
    string if the command you need isn't listed here.
    """

    SERIES_SEARCH = "SeriesSearch"
    EPISODE_SEARCH = "EpisodeSearch"
    SEASON_SEARCH = "SeasonSearch"
    REFRESH_SERIES = "RefreshSeries"
    RENAME_SERIES = "RenameSeries"
    RSS_SYNC = "RssSync"
    BACKUP = "Backup"
    CLEAN_UP_RECYCLE_BIN = "CleanUpRecycleBin"
    MISSING_EPISODE_SEARCH = "MissingEpisodeSearch"
    CUTOFF_UNMET_EPISODE_SEARCH = "CutoffUnmetEpisodeSearch"
    APPLICATION_UPDATE = "ApplicationUpdate"
    MANUAL_IMPORT = "ManualImport"


def _status(cmd: object) -> str:
    raw = getattr(cmd, "status", None)
    return str(raw).lower() if raw is not None else ""


class CommandsResource:
    """Sync Sonarr commands resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list(self) -> list[_models.CommandResource]:
        return cast(
            "list[_models.CommandResource]",
            _ops.list_command(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.CommandResource:  # noqa: A002
        return _ops.get_command_by_id(self._transport, id)

    def post(self, *, name: str, **body: Any) -> _models.CommandResource:
        """Send a Sonarr command (e.g. ``"SeriesSearch"``, ``"RefreshSeries"``)."""
        payload: dict[str, Any] = {"name": name, **body}
        response = self._transport.request("POST", "/command", json=payload)
        return _models.CommandResource.model_validate(response.json())

    def wait_for(
        self,
        id: int,  # noqa: A002
        *,
        poll_interval: float = 2.0,
        timeout: float | None = 120.0,
    ) -> _models.CommandResource:
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            cmd = self.get(id=id)
            if _status(cmd) in _TERMINAL_STATUSES:
                return cmd
            if deadline is not None and time.monotonic() >= deadline:
                msg = f"command {id} did not reach terminal state within {timeout}s"
                raise ArrTimeoutError(msg)
            time.sleep(poll_interval)

    # ---- typed named commands ----

    def series_search(self, *, ids: list[int]) -> _models.CommandResource:
        """Search indexers for all episodes of the given series."""
        return self.post(name=KnownCommand.SERIES_SEARCH, seriesIds=list(ids))

    def episode_search(self, *, ids: list[int]) -> _models.CommandResource:
        """Search indexers for a list of episodes."""
        return self.post(name=KnownCommand.EPISODE_SEARCH, episodeIds=list(ids))

    def season_search(
        self, *, series_id: int, season_number: int
    ) -> _models.CommandResource:
        return self.post(
            name=KnownCommand.SEASON_SEARCH,
            seriesId=series_id,
            seasonNumber=season_number,
        )

    def refresh_series(
        self, *, ids: list[int] | None = None
    ) -> _models.CommandResource:
        """Refresh series metadata. ``None`` refreshes everything."""
        if ids is None:
            return self.post(name=KnownCommand.REFRESH_SERIES)
        return self.post(name=KnownCommand.REFRESH_SERIES, seriesIds=list(ids))

    def rss_sync(self) -> _models.CommandResource:
        return self.post(name=KnownCommand.RSS_SYNC)

    def backup(self) -> _models.CommandResource:
        return self.post(name=KnownCommand.BACKUP)

    def missing_episode_search(self) -> _models.CommandResource:
        return self.post(name=KnownCommand.MISSING_EPISODE_SEARCH)

    def cutoff_unmet_episode_search(self) -> _models.CommandResource:
        return self.post(name=KnownCommand.CUTOFF_UNMET_EPISODE_SEARCH)


class AsyncCommandsResource:
    """Async Sonarr commands resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list(self) -> list[_models.CommandResource]:
        return cast(
            "list[_models.CommandResource]",
            await _ops.list_command_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.CommandResource:  # noqa: A002
        return await _ops.get_command_by_id_async(self._transport, id)

    async def post(self, *, name: str, **body: Any) -> _models.CommandResource:
        payload: dict[str, Any] = {"name": name, **body}
        response = await self._transport.request("POST", "/command", json=payload)
        return _models.CommandResource.model_validate(response.json())

    async def wait_for(
        self,
        id: int,  # noqa: A002
        *,
        poll_interval: float = 2.0,
        timeout: float | None = 120.0,
    ) -> _models.CommandResource:
        loop = asyncio.get_running_loop()
        deadline = None if timeout is None else loop.time() + timeout
        while True:
            cmd = await self.get(id=id)
            if _status(cmd) in _TERMINAL_STATUSES:
                return cmd
            if deadline is not None and loop.time() >= deadline:
                msg = f"command {id} did not reach terminal state within {timeout}s"
                raise ArrTimeoutError(msg)
            await anyio.sleep(poll_interval)

    # ---- typed named commands ----

    async def series_search(self, *, ids: list[int]) -> _models.CommandResource:
        return await self.post(name=KnownCommand.SERIES_SEARCH, seriesIds=list(ids))

    async def episode_search(self, *, ids: list[int]) -> _models.CommandResource:
        return await self.post(name=KnownCommand.EPISODE_SEARCH, episodeIds=list(ids))

    async def season_search(
        self, *, series_id: int, season_number: int
    ) -> _models.CommandResource:
        return await self.post(
            name=KnownCommand.SEASON_SEARCH,
            seriesId=series_id,
            seasonNumber=season_number,
        )

    async def refresh_series(
        self, *, ids: list[int] | None = None
    ) -> _models.CommandResource:
        if ids is None:
            return await self.post(name=KnownCommand.REFRESH_SERIES)
        return await self.post(name=KnownCommand.REFRESH_SERIES, seriesIds=list(ids))

    async def rss_sync(self) -> _models.CommandResource:
        return await self.post(name=KnownCommand.RSS_SYNC)

    async def backup(self) -> _models.CommandResource:
        return await self.post(name=KnownCommand.BACKUP)

    async def missing_episode_search(self) -> _models.CommandResource:
        return await self.post(name=KnownCommand.MISSING_EPISODE_SEARCH)

    async def cutoff_unmet_episode_search(self) -> _models.CommandResource:
        return await self.post(name=KnownCommand.CUTOFF_UNMET_EPISODE_SEARCH)
