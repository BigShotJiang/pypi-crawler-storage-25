"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: ManualImport."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ManualImportResource:
    """Sync wrapper for the ``ManualImport`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        folder: str | None = None,
        download_id: str | None = None,
        series_id: int | None = None,
        season_number: int | None = None,
        filter_existing_files: bool | None = None,
    ) -> list[models.ManualImportResource]:
        return cast(
            "list[models.ManualImportResource]",
            _ops.list_manualimport(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                folder=folder,
                download_id=download_id,
                series_id=series_id,
                season_number=season_number,
                filter_existing_files=filter_existing_files,
            ),
        )

    def create(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_manualimport(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncManualImportResource:
    """Async wrapper for the ``ManualImport`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        folder: str | None = None,
        download_id: str | None = None,
        series_id: int | None = None,
        season_number: int | None = None,
        filter_existing_files: bool | None = None,
    ) -> list[models.ManualImportResource]:
        return cast(
            "list[models.ManualImportResource]",
            await _ops.list_manualimport_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                folder=folder,
                download_id=download_id,
                series_id=series_id,
                season_number=season_number,
                filter_existing_files=filter_existing_files,
            ),
        )

    async def create(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_manualimport_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
