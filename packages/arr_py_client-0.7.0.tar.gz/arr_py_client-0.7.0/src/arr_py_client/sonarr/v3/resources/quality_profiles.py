"""Quality profiles resource for Sonarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.quality_profile import (
    AsyncQualityProfileResource as _AutoAsync,
)
from arr_py_client.sonarr.v3.resources._auto.quality_profile import (
    QualityProfileResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class QualityProfilesResource(_AutoSync):
    """Sync Sonarr quality profiles resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.QualityProfileResource]:
        return cast(
            "list[_models.QualityProfileResource]",
            _ops.list_qualityprofile(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.QualityProfileResource:  # noqa: A002
        return _ops.get_qualityprofile_by_id(self._transport, id)

    def create(
        self, *, body: _models.QualityProfileResource
    ) -> _models.QualityProfileResource:
        return _ops.create_qualityprofile(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.QualityProfileResource,
    ) -> _models.QualityProfileResource:
        return _ops.update_qualityprofile_by_id(self._transport, str(id), body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_qualityprofile_by_id(self._transport, id)

    def schema(self) -> _models.QualityProfileResource:
        return _ops.list_qualityprofile_schema(self._transport)


class AsyncQualityProfilesResource(_AutoAsync):
    """Async Sonarr quality profiles resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.QualityProfileResource]:
        return cast(
            "list[_models.QualityProfileResource]",
            await _ops.list_qualityprofile_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.QualityProfileResource:  # noqa: A002
        return await _ops.get_qualityprofile_by_id_async(self._transport, id)

    async def create(
        self, *, body: _models.QualityProfileResource
    ) -> _models.QualityProfileResource:
        return await _ops.create_qualityprofile_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.QualityProfileResource,
    ) -> _models.QualityProfileResource:
        return await _ops.update_qualityprofile_by_id_async(
            self._transport, str(id), body=body
        )

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_qualityprofile_by_id_async(self._transport, id)

    async def schema(self) -> _models.QualityProfileResource:
        return await _ops.list_qualityprofile_schema_async(self._transport)
