"""Rename workflow for Sonarr v3.

Preview + execute for the "rename files according to the current naming
policy" operation. Two steps:

1. ``candidates(series_id=.., season_number=..)`` — GET ``/rename`` returns
   the list of episode files that would be renamed, with old and new paths.
2. ``execute(series_ids=...)`` — fires the ``RenameSeries`` command. Returns
   the command resource; pair with :meth:`~arr_py_client.sonarr.v3.resources.
   commands.CommandsResource.wait_for` to block.

If only specific files should be renamed, use ``execute(series_id=..+files=...)``
to fire the ``RenameFiles`` command with a scoped file-id list instead.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _rename_command(
    *,
    series_ids: list[int] | None,
    series_id: int | None,
    files: list[int] | None,
) -> dict[str, Any]:
    if series_id is not None and files is not None:
        return {"name": "RenameFiles", "seriesId": series_id, "files": files}
    if series_ids is None:
        msg = (
            "execute() requires either series_ids=[...] (RenameSeries) "
            "or series_id=..+files=[...] (RenameFiles)"
        )
        raise ValueError(msg)
    return {"name": "RenameSeries", "seriesIds": series_ids}


class RenameResource:
    """Sync Sonarr rename workflow (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def candidates(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
    ) -> list[_models.RenameEpisodeResource]:
        """List episode files that would be renamed for a series/season."""
        return cast(
            "list[_models.RenameEpisodeResource]",
            _ops.list_rename(  # pyright: ignore[reportUnknownMemberType]
                self._transport, series_id=series_id, season_number=season_number
            ),
        )

    def execute(
        self,
        *,
        series_ids: list[int] | None = None,
        series_id: int | None = None,
        files: list[int] | None = None,
    ) -> _models.CommandResource:
        """Fire a rename command.

        Pass ``series_ids=[...]`` for a full-series rename (``RenameSeries``),
        or ``series_id=..+files=[...]`` for a specific-file rename (``RenameFiles``).
        """
        payload = _rename_command(
            series_ids=series_ids, series_id=series_id, files=files
        )
        response = self._transport.request("POST", "/command", json=payload)
        return _models.CommandResource.model_validate(response.json())


class AsyncRenameResource:
    """Async Sonarr rename workflow (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def candidates(
        self,
        *,
        series_id: int | None = None,
        season_number: int | None = None,
    ) -> list[_models.RenameEpisodeResource]:
        return cast(
            "list[_models.RenameEpisodeResource]",
            await _ops.list_rename_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport, series_id=series_id, season_number=season_number
            ),
        )

    async def execute(
        self,
        *,
        series_ids: list[int] | None = None,
        series_id: int | None = None,
        files: list[int] | None = None,
    ) -> _models.CommandResource:
        payload = _rename_command(
            series_ids=series_ids, series_id=series_id, files=files
        )
        response = await self._transport.request("POST", "/command", json=payload)
        return _models.CommandResource.model_validate(response.json())
