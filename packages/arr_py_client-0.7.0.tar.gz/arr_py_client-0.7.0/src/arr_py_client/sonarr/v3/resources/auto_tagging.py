"""Auto-tagging resource for Sonarr v3.

Auto-tagging lets the server apply tags to series automatically based on
specification rules (genre, quality profile, year, etc). This is a core
"rule-based routing" surface — custom formats decide *what* gets grabbed,
auto-tagging decides *how the series gets classified* once matched.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.auto_tagging import (
    AsyncAutoTaggingResource as _AutoAsync,
)
from arr_py_client.sonarr.v3.resources._auto.auto_tagging import (
    AutoTaggingResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class AutoTaggingResource(_AutoSync):
    """Sync Sonarr auto-tagging resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.AutoTaggingResource]:
        return cast(
            "list[_models.AutoTaggingResource]",
            _ops.list_autotagging(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.AutoTaggingResource:  # noqa: A002
        return _ops.get_autotagging_by_id(self._transport, id)

    def create(
        self, *, body: _models.AutoTaggingResource
    ) -> _models.AutoTaggingResource:
        return _ops.create_autotagging(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.AutoTaggingResource,
    ) -> _models.AutoTaggingResource:
        return _ops.update_autotagging_by_id(self._transport, str(id), body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_autotagging_by_id(self._transport, id)

    def schema(self) -> Any:
        """Return the server-side spec schema (shape is undocumented; kept Any)."""
        return _ops.list_autotagging_schema(self._transport)  # pyright: ignore[reportUnknownMemberType]


class AsyncAutoTaggingResource(_AutoAsync):
    """Async Sonarr auto-tagging resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.AutoTaggingResource]:
        return cast(
            "list[_models.AutoTaggingResource]",
            await _ops.list_autotagging_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.AutoTaggingResource:  # noqa: A002
        return await _ops.get_autotagging_by_id_async(self._transport, id)

    async def create(
        self, *, body: _models.AutoTaggingResource
    ) -> _models.AutoTaggingResource:
        return await _ops.create_autotagging_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.AutoTaggingResource,
    ) -> _models.AutoTaggingResource:
        return await _ops.update_autotagging_by_id_async(
            self._transport, str(id), body=body
        )

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_autotagging_by_id_async(self._transport, id)

    async def schema(self) -> Any:
        return await _ops.list_autotagging_schema_async(self._transport)  # pyright: ignore[reportUnknownMemberType]
