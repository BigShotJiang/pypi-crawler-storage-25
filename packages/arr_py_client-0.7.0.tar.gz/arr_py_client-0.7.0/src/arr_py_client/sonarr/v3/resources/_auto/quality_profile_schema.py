"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: QualityProfileSchema."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class QualityProfileSchemaResource:
    """Sync wrapper for the ``QualityProfileSchema`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> models.QualityProfileResource:
        return cast(
            "models.QualityProfileResource",
            _ops.list_qualityprofile_schema(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncQualityProfileSchemaResource:
    """Async wrapper for the ``QualityProfileSchema`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> models.QualityProfileResource:
        return cast(
            "models.QualityProfileResource",
            await _ops.list_qualityprofile_schema_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
