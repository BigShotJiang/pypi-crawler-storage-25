"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: ReleasePush."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ReleasePushResource:
    """Sync wrapper for the ``ReleasePush`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.ReleaseResource | None = None,
    ) -> list[models.ReleaseResource]:
        return cast(
            "list[models.ReleaseResource]",
            _ops.create_release_push(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


class AsyncReleasePushResource:
    """Async wrapper for the ``ReleasePush`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.ReleaseResource | None = None,
    ) -> list[models.ReleaseResource]:
        return cast(
            "list[models.ReleaseResource]",
            await _ops.create_release_push_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
