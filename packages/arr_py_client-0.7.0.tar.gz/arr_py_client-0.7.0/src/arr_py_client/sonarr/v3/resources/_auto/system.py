"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: System."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class SystemResource:
    """Sync wrapper for the ``System`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_status(
        self,
    ) -> models.SystemResource:
        return cast(
            "models.SystemResource",
            _ops.list_system_status(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def list_routes(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list_system_routes(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def list_routes_duplicate(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list_system_routes_duplicate(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create_shutdown(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_system_shutdown(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create_restart(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_system_restart(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncSystemResource:
    """Async wrapper for the ``System`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_status(
        self,
    ) -> models.SystemResource:
        return cast(
            "models.SystemResource",
            await _ops.list_system_status_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def list_routes(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_system_routes_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def list_routes_duplicate(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_system_routes_duplicate_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create_shutdown(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_system_shutdown_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create_restart(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_system_restart_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
