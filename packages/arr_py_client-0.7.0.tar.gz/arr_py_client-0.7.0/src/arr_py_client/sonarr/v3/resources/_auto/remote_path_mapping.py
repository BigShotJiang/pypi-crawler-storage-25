"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: RemotePathMapping."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class RemotePathMappingResource:
    """Sync wrapper for the ``RemotePathMapping`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.RemotePathMappingResource | None = None,
    ) -> models.RemotePathMappingResource:
        return cast(
            "models.RemotePathMappingResource",
            _ops.create_remotepathmapping(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
    ) -> list[models.RemotePathMappingResource]:
        return cast(
            "list[models.RemotePathMappingResource]",
            _ops.list_remotepathmapping(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_remotepathmapping_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.RemotePathMappingResource | None = None,
    ) -> models.RemotePathMappingResource:
        return cast(
            "models.RemotePathMappingResource",
            _ops.update_remotepathmapping_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.RemotePathMappingResource:
        return cast(
            "models.RemotePathMappingResource",
            _ops.get_remotepathmapping_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncRemotePathMappingResource:
    """Async wrapper for the ``RemotePathMapping`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.RemotePathMappingResource | None = None,
    ) -> models.RemotePathMappingResource:
        return cast(
            "models.RemotePathMappingResource",
            await _ops.create_remotepathmapping_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
    ) -> list[models.RemotePathMappingResource]:
        return cast(
            "list[models.RemotePathMappingResource]",
            await _ops.list_remotepathmapping_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_remotepathmapping_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.RemotePathMappingResource | None = None,
    ) -> models.RemotePathMappingResource:
        return cast(
            "models.RemotePathMappingResource",
            await _ops.update_remotepathmapping_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.RemotePathMappingResource:
        return cast(
            "models.RemotePathMappingResource",
            await _ops.get_remotepathmapping_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
