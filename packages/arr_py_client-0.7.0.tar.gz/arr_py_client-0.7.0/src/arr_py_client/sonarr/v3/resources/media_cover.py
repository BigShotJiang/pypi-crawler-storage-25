"""Media cover (binary) resource for Sonarr v3."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


@dataclass(frozen=True)
class MediaCoverImage:
    content: bytes
    content_type: str


class MediaCoverResource:
    """Sync Sonarr media cover resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def get(
        self,
        *,
        series_id: int,
        filename: str,
        timeout: float | None = 60.0,
    ) -> MediaCoverImage:
        response = self._transport.request(
            "GET",
            f"/mediacover/{series_id}/{filename}",
            timeout=timeout,
        )
        return MediaCoverImage(
            content=response.content,
            content_type=response.headers.get(
                "content-type", "application/octet-stream"
            ),
        )


class AsyncMediaCoverResource:
    """Async Sonarr media cover resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def get(
        self,
        *,
        series_id: int,
        filename: str,
        timeout: float | None = 60.0,
    ) -> MediaCoverImage:
        response = await self._transport.request(
            "GET",
            f"/mediacover/{series_id}/{filename}",
            timeout=timeout,
        )
        return MediaCoverImage(
            content=response.content,
            content_type=response.headers.get(
                "content-type", "application/octet-stream"
            ),
        )
