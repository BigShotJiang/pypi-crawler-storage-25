"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: SeriesEditor."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class SeriesEditorResource:
    """Sync wrapper for the ``SeriesEditor`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def update(
        self,
        *,
        body: models.SeriesEditorResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.update_series_editor(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def delete(
        self,
        *,
        body: models.SeriesEditorResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_series_editor(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


class AsyncSeriesEditorResource:
    """Async wrapper for the ``SeriesEditor`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def update(
        self,
        *,
        body: models.SeriesEditorResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.update_series_editor_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def delete(
        self,
        *,
        body: models.SeriesEditorResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_series_editor_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
