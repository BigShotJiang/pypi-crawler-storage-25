"""Release-name parse resource for Sonarr v3.

Thin facade over ``/api/v3/parse?title=...``. The server runs its release-name
parser on the given title and returns the structured breakdown (series match,
episodes, quality, release group, languages, etc.) — the same logic the grab
pipeline uses. Useful for tests, debuggers, and the MCP surface.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client.sonarr.v3._generated import models as _models
from arr_py_client.sonarr.v3._generated import operations as _ops
from arr_py_client.sonarr.v3.resources._auto.parse import (
    AsyncParseResource as _AutoAsync,
)
from arr_py_client.sonarr.v3.resources._auto.parse import (
    ParseResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ParseResource(_AutoSync):
    """Sync Sonarr parse resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def title(self, title: str) -> _models.ParseResource:
        """Parse a release title into its structured components."""
        return _ops.list_parse(self._transport, title=title)


class AsyncParseResource(_AutoAsync):
    """Async Sonarr parse resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def title(self, title: str) -> _models.ParseResource:
        """Parse a release title into its structured components."""
        return await _ops.list_parse_async(self._transport, title=title)
