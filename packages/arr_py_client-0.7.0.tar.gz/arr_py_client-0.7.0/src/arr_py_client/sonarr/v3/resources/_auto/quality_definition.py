"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: QualityDefinition."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class QualityDefinitionResource:
    """Sync wrapper for the ``QualityDefinition`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def update_by_id(
        self,
        id: str,
        *,
        body: models.QualityDefinitionResource | None = None,
    ) -> models.QualityDefinitionResource:
        return cast(
            "models.QualityDefinitionResource",
            _ops.update_qualitydefinition_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.QualityDefinitionResource:
        return cast(
            "models.QualityDefinitionResource",
            _ops.get_qualitydefinition_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_(
        self,
    ) -> list[models.QualityDefinitionResource]:
        return cast(
            "list[models.QualityDefinitionResource]",
            _ops.list_qualitydefinition(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def update_update(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.update_qualitydefinition_update(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def list_limits(
        self,
    ) -> models.QualityDefinitionLimitsResource:
        return cast(
            "models.QualityDefinitionLimitsResource",
            _ops.list_qualitydefinition_limits(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncQualityDefinitionResource:
    """Async wrapper for the ``QualityDefinition`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.QualityDefinitionResource | None = None,
    ) -> models.QualityDefinitionResource:
        return cast(
            "models.QualityDefinitionResource",
            await _ops.update_qualitydefinition_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.QualityDefinitionResource:
        return cast(
            "models.QualityDefinitionResource",
            await _ops.get_qualitydefinition_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_(
        self,
    ) -> list[models.QualityDefinitionResource]:
        return cast(
            "list[models.QualityDefinitionResource]",
            await _ops.list_qualitydefinition_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def update_update(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.update_qualitydefinition_update_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def list_limits(
        self,
    ) -> models.QualityDefinitionLimitsResource:
        return cast(
            "models.QualityDefinitionLimitsResource",
            await _ops.list_qualitydefinition_limits_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
