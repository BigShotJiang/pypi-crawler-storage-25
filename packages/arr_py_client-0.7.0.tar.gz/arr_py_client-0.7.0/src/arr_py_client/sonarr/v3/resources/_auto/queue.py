"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Queue."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class QueueResource:
    """Sync wrapper for the ``Queue`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def delete_by_id(
        self,
        id: int,
        *,
        remove_from_client: bool | None = None,
        blocklist: bool | None = None,
        skip_redownload: bool | None = None,
        change_category: bool | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_queue_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                remove_from_client=remove_from_client,
                blocklist=blocklist,
                skip_redownload=skip_redownload,
                change_category=change_category,
            ),
        )

    def delete_bulk(
        self,
        *,
        remove_from_client: bool | None = None,
        blocklist: bool | None = None,
        skip_redownload: bool | None = None,
        change_category: bool | None = None,
        body: models.QueueBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_queue_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                remove_from_client=remove_from_client,
                blocklist=blocklist,
                skip_redownload=skip_redownload,
                change_category=change_category,
                body=body,
            ),
        )

    def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        include_unknown_series_items: bool | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
        series_ids: list[int] | None = None,
        protocol: models.DownloadProtocol | None = None,
        languages: list[int] | None = None,
        quality: list[int] | None = None,
        status: list[models.QueueStatus] | None = None,
    ) -> models.QueueResourcePagingResource:
        return cast(
            "models.QueueResourcePagingResource",
            _ops.list_queue(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                include_unknown_series_items=include_unknown_series_items,
                include_series=include_series,
                include_episode=include_episode,
                series_ids=series_ids,
                protocol=protocol,
                languages=languages,
                quality=quality,
                status=status,
            ),
        )


class AsyncQueueResource:
    """Async wrapper for the ``Queue`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def delete_by_id(
        self,
        id: int,
        *,
        remove_from_client: bool | None = None,
        blocklist: bool | None = None,
        skip_redownload: bool | None = None,
        change_category: bool | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_queue_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                remove_from_client=remove_from_client,
                blocklist=blocklist,
                skip_redownload=skip_redownload,
                change_category=change_category,
            ),
        )

    async def delete_bulk(
        self,
        *,
        remove_from_client: bool | None = None,
        blocklist: bool | None = None,
        skip_redownload: bool | None = None,
        change_category: bool | None = None,
        body: models.QueueBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_queue_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                remove_from_client=remove_from_client,
                blocklist=blocklist,
                skip_redownload=skip_redownload,
                change_category=change_category,
                body=body,
            ),
        )

    async def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        include_unknown_series_items: bool | None = None,
        include_series: bool | None = None,
        include_episode: bool | None = None,
        series_ids: list[int] | None = None,
        protocol: models.DownloadProtocol | None = None,
        languages: list[int] | None = None,
        quality: list[int] | None = None,
        status: list[models.QueueStatus] | None = None,
    ) -> models.QueueResourcePagingResource:
        return cast(
            "models.QueueResourcePagingResource",
            await _ops.list_queue_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                include_unknown_series_items=include_unknown_series_items,
                include_series=include_series,
                include_episode=include_episode,
                series_ids=series_ids,
                protocol=protocol,
                languages=languages,
                quality=quality,
                status=status,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
