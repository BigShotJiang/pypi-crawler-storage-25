"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: DownloadClientConfig."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class DownloadClientConfigResource:
    """Sync wrapper for the ``DownloadClientConfig`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> models.DownloadClientConfigResource:
        return cast(
            "models.DownloadClientConfigResource",
            _ops.list_config_downloadclient(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.DownloadClientConfigResource | None = None,
    ) -> models.DownloadClientConfigResource:
        return cast(
            "models.DownloadClientConfigResource",
            _ops.update_config_downloadclient_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.DownloadClientConfigResource:
        return cast(
            "models.DownloadClientConfigResource",
            _ops.get_config_downloadclient_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncDownloadClientConfigResource:
    """Async wrapper for the ``DownloadClientConfig`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> models.DownloadClientConfigResource:
        return cast(
            "models.DownloadClientConfigResource",
            await _ops.list_config_downloadclient_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.DownloadClientConfigResource | None = None,
    ) -> models.DownloadClientConfigResource:
        return cast(
            "models.DownloadClientConfigResource",
            await _ops.update_config_downloadclient_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.DownloadClientConfigResource:
        return cast(
            "models.DownloadClientConfigResource",
            await _ops.get_config_downloadclient_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
