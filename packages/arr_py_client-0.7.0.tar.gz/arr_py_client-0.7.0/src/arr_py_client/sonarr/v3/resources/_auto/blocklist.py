"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Blocklist."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.sonarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class BlocklistResource:
    """Sync wrapper for the ``Blocklist`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        series_ids: list[int] | None = None,
        protocols: list[models.DownloadProtocol] | None = None,
    ) -> models.BlocklistResourcePagingResource:
        return cast(
            "models.BlocklistResourcePagingResource",
            _ops.list_blocklist(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                series_ids=series_ids,
                protocols=protocols,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_blocklist_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def delete_bulk(
        self,
        *,
        body: models.BlocklistBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_blocklist_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


class AsyncBlocklistResource:
    """Async wrapper for the ``Blocklist`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        series_ids: list[int] | None = None,
        protocols: list[models.DownloadProtocol] | None = None,
    ) -> models.BlocklistResourcePagingResource:
        return cast(
            "models.BlocklistResourcePagingResource",
            await _ops.list_blocklist_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                series_ids=series_ids,
                protocols=protocols,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_blocklist_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def delete_bulk(
        self,
        *,
        body: models.BlocklistBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_blocklist_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
