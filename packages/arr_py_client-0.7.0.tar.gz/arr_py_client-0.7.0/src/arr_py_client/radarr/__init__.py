"""Radarr client dispatcher."""

from __future__ import annotations

from typing import Any


def RadarrClient(*, api_version: int = 3, **kwargs: Any) -> Any:
    if api_version == 3:
        from arr_py_client.radarr.v3.client import RadarrClientV3

        return RadarrClientV3(**kwargs)
    msg = f"Unsupported Radarr api_version: {api_version}"
    raise ValueError(msg)


def AsyncRadarrClient(*, api_version: int = 3, **kwargs: Any) -> Any:
    if api_version == 3:
        from arr_py_client.radarr.v3.client import AsyncRadarrClientV3

        return AsyncRadarrClientV3(**kwargs)
    msg = f"Unsupported Radarr api_version: {api_version}"
    raise ValueError(msg)


__all__ = ["AsyncRadarrClient", "RadarrClient"]
