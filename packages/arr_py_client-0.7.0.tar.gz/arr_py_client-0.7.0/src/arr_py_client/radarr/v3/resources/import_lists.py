"""Import lists (Trakt/IMDB/Letterboxd/etc.) management for Radarr v3.

Curated facade over ``/api/v3/importlist``:
- ``.list()`` / ``.get()`` / ``.create()`` / ``.update()`` / ``.delete()``
- ``.schema()`` — types available on the server (driver for "what lists can I
  create?")
- ``.test(body)`` — server-side validation before create.
- ``.fetched_items()`` — Radarr-only: movies from all active lists.

Bodies for ``create()`` accept raw ``ImportListResource`` instances; the config
for each list type is server-specific — callers should introspect via
:meth:`schema` or the Radarr UI.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ImportListsResource:
    """Sync Radarr import lists resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list(self) -> list[_models.ImportListResource]:
        return cast(
            "list[_models.ImportListResource]",
            _ops.list_importlist(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.ImportListResource:  # noqa: A002
        return _ops.get_importlist_by_id(self._transport, id)

    def create(self, *, body: _models.ImportListResource) -> _models.ImportListResource:
        return _ops.create_importlist(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.ImportListResource,
    ) -> _models.ImportListResource:
        return _ops.update_importlist_by_id(self._transport, id, body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_importlist_by_id(self._transport, id)

    def schema(self) -> list[_models.ImportListResource]:
        return cast(
            "list[_models.ImportListResource]",
            _ops.list_importlist_schema(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def test(self, *, body: _models.ImportListResource) -> None:
        """Server-side validate an import-list config without saving it."""
        _ops.create_importlist_test(self._transport, body=body)

    def fetched_items(
        self,
        *,
        include_recommendations: bool | None = None,
        include_trending: bool | None = None,
        include_popular: bool | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch all movies currently produced by active Radarr import lists.

        Returns raw dicts because Radarr's spec doesn't type this endpoint.
        Typical fields: ``tmdbId``, ``imdbId``, ``title``, ``year``, ``listId``.
        """
        params: dict[str, Any] = {}
        if include_recommendations is not None:
            params["includeRecommendations"] = include_recommendations
        if include_trending is not None:
            params["includeTrending"] = include_trending
        if include_popular is not None:
            params["includePopular"] = include_popular
        response = self._transport.request(
            "GET", "/importlist/movie", params=params or None
        )
        return cast("list[dict[str, Any]]", response.json())


class AsyncImportListsResource:
    """Async Radarr import lists resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list(self) -> list[_models.ImportListResource]:
        return cast(
            "list[_models.ImportListResource]",
            await _ops.list_importlist_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.ImportListResource:  # noqa: A002
        return await _ops.get_importlist_by_id_async(self._transport, id)

    async def create(
        self, *, body: _models.ImportListResource
    ) -> _models.ImportListResource:
        return await _ops.create_importlist_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.ImportListResource,
    ) -> _models.ImportListResource:
        return await _ops.update_importlist_by_id_async(self._transport, id, body=body)

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_importlist_by_id_async(self._transport, id)

    async def schema(self) -> list[_models.ImportListResource]:
        return cast(
            "list[_models.ImportListResource]",
            await _ops.list_importlist_schema_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def test(self, *, body: _models.ImportListResource) -> None:
        await _ops.create_importlist_test_async(self._transport, body=body)

    async def fetched_items(
        self,
        *,
        include_recommendations: bool | None = None,
        include_trending: bool | None = None,
        include_popular: bool | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {}
        if include_recommendations is not None:
            params["includeRecommendations"] = include_recommendations
        if include_trending is not None:
            params["includeTrending"] = include_trending
        if include_popular is not None:
            params["includePopular"] = include_popular
        response = await self._transport.request(
            "GET", "/importlist/movie", params=params or None
        )
        return cast("list[dict[str, Any]]", response.json())
