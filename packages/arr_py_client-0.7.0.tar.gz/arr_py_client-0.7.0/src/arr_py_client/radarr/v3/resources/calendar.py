"""Calendar resource for Radarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops
from arr_py_client.radarr.v3.resources._auto.calendar import (
    AsyncCalendarResource as _AutoAsyncCalendarResource,
)
from arr_py_client.radarr.v3.resources._auto.calendar import (
    CalendarResource as _AutoCalendarResource,
)

if TYPE_CHECKING:
    from datetime import datetime

    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _fmt(dt: datetime | str | None) -> str | None:
    if dt is None:
        return None
    if isinstance(dt, str):
        return dt
    return dt.isoformat()


class CalendarResource(_AutoCalendarResource):
    """Sync Radarr calendar resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(
        self,
        *,
        start: datetime | str | None = None,
        end: datetime | str | None = None,
        unmonitored: bool | None = None,
        tags: str | None = None,
    ) -> list[_models.MovieResource]:
        return cast(
            "list[_models.MovieResource]",
            _ops.list_calendar(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                start=_fmt(start),
                end=_fmt(end),
                unmonitored=unmonitored,
                tags=tags,
            ),
        )


class AsyncCalendarResource(_AutoAsyncCalendarResource):
    """Async Radarr calendar resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(
        self,
        *,
        start: datetime | str | None = None,
        end: datetime | str | None = None,
        unmonitored: bool | None = None,
        tags: str | None = None,
    ) -> list[_models.MovieResource]:
        return cast(
            "list[_models.MovieResource]",
            await _ops.list_calendar_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                start=_fmt(start),
                end=_fmt(end),
                unmonitored=unmonitored,
                tags=tags,
            ),
        )
