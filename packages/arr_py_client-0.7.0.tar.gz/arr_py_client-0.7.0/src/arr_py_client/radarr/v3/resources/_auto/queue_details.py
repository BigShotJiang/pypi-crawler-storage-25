"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: QueueDetails."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class QueueDetailsResource:
    """Sync wrapper for the ``QueueDetails`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        movie_id: int | None = None,
        include_movie: bool | None = None,
    ) -> list[models.QueueResource]:
        return cast(
            "list[models.QueueResource]",
            _ops.list_queue_details(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
                include_movie=include_movie,
            ),
        )


class AsyncQueueDetailsResource:
    """Async wrapper for the ``QueueDetails`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        movie_id: int | None = None,
        include_movie: bool | None = None,
    ) -> list[models.QueueResource]:
        return cast(
            "list[models.QueueResource]",
            await _ops.list_queue_details_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
                include_movie=include_movie,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
