"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: MediaCover."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class MediaCoverResource:
    """Sync wrapper for the ``MediaCover`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def get(
        self,
        movie_id: int,
        filename: str,
    ) -> None:
        return cast(
            "None",
            _ops.get_mediacover_by_movie_id_and_filename(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id,
                filename,
            ),
        )


class AsyncMediaCoverResource:
    """Async wrapper for the ``MediaCover`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def get(
        self,
        movie_id: int,
        filename: str,
    ) -> None:
        return cast(
            "None",
            await _ops.get_mediacover_by_movie_id_and_filename_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id,
                filename,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
