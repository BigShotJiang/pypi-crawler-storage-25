"""Custom formats resource for Radarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops
from arr_py_client.radarr.v3.resources._auto.custom_format import (
    AsyncCustomFormatResource as _AutoAsync,
)
from arr_py_client.radarr.v3.resources._auto.custom_format import (
    CustomFormatResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class CustomFormatsResource(_AutoSync):
    """Sync Radarr custom formats resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.CustomFormatResource]:
        return cast(
            "list[_models.CustomFormatResource]",
            _ops.list_customformat(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.CustomFormatResource:  # noqa: A002
        return _ops.get_customformat_by_id(self._transport, id)

    def create(
        self, *, body: _models.CustomFormatResource
    ) -> _models.CustomFormatResource:
        return _ops.create_customformat(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.CustomFormatResource,
    ) -> _models.CustomFormatResource:
        return _ops.update_customformat_by_id(self._transport, str(id), body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_customformat_by_id(self._transport, id)

    # Note: ``/customformat/schema`` is undocumented in the spec (response shape
    # is unspecified). Use ``client.transport.request("GET", "/customformat/schema")``
    # if you need it.


class AsyncCustomFormatsResource(_AutoAsync):
    """Async Radarr custom formats resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.CustomFormatResource]:
        return cast(
            "list[_models.CustomFormatResource]",
            await _ops.list_customformat_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.CustomFormatResource:  # noqa: A002
        return await _ops.get_customformat_by_id_async(self._transport, id)

    async def create(
        self, *, body: _models.CustomFormatResource
    ) -> _models.CustomFormatResource:
        return await _ops.create_customformat_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.CustomFormatResource,
    ) -> _models.CustomFormatResource:
        return await _ops.update_customformat_by_id_async(
            self._transport, str(id), body=body
        )

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_customformat_by_id_async(self._transport, id)

    # See sync class note re: ``/customformat/schema`` shape.
