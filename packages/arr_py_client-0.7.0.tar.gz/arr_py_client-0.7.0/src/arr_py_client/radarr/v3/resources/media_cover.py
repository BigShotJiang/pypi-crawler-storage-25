"""Media cover (binary) resource for Radarr v3.

Skips the auto-generated wrapper because that one assumes JSON; instead, hits
the transport directly and returns raw bytes plus content-type.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


@dataclass(frozen=True)
class MediaCoverImage:
    """Raw image bytes plus the response ``Content-Type``."""

    content: bytes
    content_type: str


class MediaCoverResource:
    """Sync Radarr media cover (poster/banner/fanart) resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def get(
        self,
        *,
        movie_id: int,
        filename: str,
        timeout: float | None = 60.0,
    ) -> MediaCoverImage:
        """Fetch a cover image (poster.jpg, fanart.jpg, etc.) for a movie."""
        response = self._transport.request(
            "GET",
            f"/mediacover/{movie_id}/{filename}",
            timeout=timeout,
        )
        return MediaCoverImage(
            content=response.content,
            content_type=response.headers.get(
                "content-type", "application/octet-stream"
            ),
        )


class AsyncMediaCoverResource:
    """Async Radarr media cover resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def get(
        self,
        *,
        movie_id: int,
        filename: str,
        timeout: float | None = 60.0,
    ) -> MediaCoverImage:
        response = await self._transport.request(
            "GET",
            f"/mediacover/{movie_id}/{filename}",
            timeout=timeout,
        )
        return MediaCoverImage(
            content=response.content,
            content_type=response.headers.get(
                "content-type", "application/octet-stream"
            ),
        )
