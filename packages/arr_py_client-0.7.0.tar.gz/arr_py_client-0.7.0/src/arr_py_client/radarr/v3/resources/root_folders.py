"""Root folders resource for Radarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops
from arr_py_client.radarr.v3.resources._auto.root_folder import (
    AsyncRootFolderResource as _AutoAsync,
)
from arr_py_client.radarr.v3.resources._auto.root_folder import (
    RootFolderResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class RootFoldersResource(_AutoSync):
    """Sync Radarr root folders resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.RootFolderResource]:
        return cast(
            "list[_models.RootFolderResource]",
            _ops.list_rootfolder(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.RootFolderResource:  # noqa: A002
        return _ops.get_rootfolder_by_id(self._transport, id)

    def create(self, *, body: _models.RootFolderResource) -> _models.RootFolderResource:
        return _ops.create_rootfolder(self._transport, body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_rootfolder_by_id(self._transport, id)


class AsyncRootFoldersResource(_AutoAsync):
    """Async Radarr root folders resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.RootFolderResource]:
        return cast(
            "list[_models.RootFolderResource]",
            await _ops.list_rootfolder_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.RootFolderResource:  # noqa: A002
        return await _ops.get_rootfolder_by_id_async(self._transport, id)

    async def create(
        self, *, body: _models.RootFolderResource
    ) -> _models.RootFolderResource:
        return await _ops.create_rootfolder_async(self._transport, body=body)

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_rootfolder_by_id_async(self._transport, id)
