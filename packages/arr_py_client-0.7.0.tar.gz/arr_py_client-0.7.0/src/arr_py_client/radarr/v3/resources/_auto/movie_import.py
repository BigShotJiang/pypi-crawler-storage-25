"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: MovieImport."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class MovieImportResource:
    """Sync wrapper for the ``MovieImport`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
    ) -> list[models.MovieResource]:
        return cast(
            "list[models.MovieResource]",
            _ops.create_movie_import(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncMovieImportResource:
    """Async wrapper for the ``MovieImport`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
    ) -> list[models.MovieResource]:
        return cast(
            "list[models.MovieResource]",
            await _ops.create_movie_import_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
