"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: ExtraFile."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ExtraFileResource:
    """Sync wrapper for the ``ExtraFile`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        movie_id: int | None = None,
    ) -> list[models.ExtraFileResource]:
        return cast(
            "list[models.ExtraFileResource]",
            _ops.list_extrafile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
            ),
        )


class AsyncExtraFileResource:
    """Async wrapper for the ``ExtraFile`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        movie_id: int | None = None,
    ) -> list[models.ExtraFileResource]:
        return cast(
            "list[models.ExtraFileResource]",
            await _ops.list_extrafile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
