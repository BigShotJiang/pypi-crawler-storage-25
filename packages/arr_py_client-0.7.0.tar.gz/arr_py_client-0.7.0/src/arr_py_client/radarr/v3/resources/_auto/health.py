"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Health."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class HealthResource:
    """Sync wrapper for the ``Health`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.HealthResource]:
        return cast(
            "list[models.HealthResource]",
            _ops.list_health(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncHealthResource:
    """Async wrapper for the ``Health`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.HealthResource]:
        return cast(
            "list[models.HealthResource]",
            await _ops.list_health_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
