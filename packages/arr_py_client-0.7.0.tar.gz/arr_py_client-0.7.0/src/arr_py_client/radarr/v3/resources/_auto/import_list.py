"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: ImportList."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ImportListResource:
    """Sync wrapper for the ``ImportList`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.ImportListResource]:
        return cast(
            "list[models.ImportListResource]",
            _ops.list_importlist(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create(
        self,
        *,
        force_save: bool | None = None,
        body: models.ImportListResource | None = None,
    ) -> models.ImportListResource:
        return cast(
            "models.ImportListResource",
            _ops.create_importlist(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_save=force_save,
                body=body,
            ),
        )

    def update_by_id(
        self,
        id: int,
        *,
        force_save: bool | None = None,
        body: models.ImportListResource | None = None,
    ) -> models.ImportListResource:
        return cast(
            "models.ImportListResource",
            _ops.update_importlist_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                force_save=force_save,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_importlist_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.ImportListResource:
        return cast(
            "models.ImportListResource",
            _ops.get_importlist_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_bulk(
        self,
        *,
        body: models.ImportListBulkResource | None = None,
    ) -> models.ImportListResource:
        return cast(
            "models.ImportListResource",
            _ops.update_importlist_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def delete_bulk(
        self,
        *,
        body: models.ImportListBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_importlist_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_schema(
        self,
    ) -> list[models.ImportListResource]:
        return cast(
            "list[models.ImportListResource]",
            _ops.list_importlist_schema(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create_test(
        self,
        *,
        force_test: bool | None = None,
        body: models.ImportListResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.create_importlist_test(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_test=force_test,
                body=body,
            ),
        )

    def create_testall(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_importlist_testall(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def post_action_by_name(
        self,
        name: str,
        *,
        body: models.ImportListResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.post_importlist_action_by_name(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                name,
                body=body,
            ),
        )


class AsyncImportListResource:
    """Async wrapper for the ``ImportList`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.ImportListResource]:
        return cast(
            "list[models.ImportListResource]",
            await _ops.list_importlist_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create(
        self,
        *,
        force_save: bool | None = None,
        body: models.ImportListResource | None = None,
    ) -> models.ImportListResource:
        return cast(
            "models.ImportListResource",
            await _ops.create_importlist_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_save=force_save,
                body=body,
            ),
        )

    async def update_by_id(
        self,
        id: int,
        *,
        force_save: bool | None = None,
        body: models.ImportListResource | None = None,
    ) -> models.ImportListResource:
        return cast(
            "models.ImportListResource",
            await _ops.update_importlist_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                force_save=force_save,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_importlist_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.ImportListResource:
        return cast(
            "models.ImportListResource",
            await _ops.get_importlist_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_bulk(
        self,
        *,
        body: models.ImportListBulkResource | None = None,
    ) -> models.ImportListResource:
        return cast(
            "models.ImportListResource",
            await _ops.update_importlist_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def delete_bulk(
        self,
        *,
        body: models.ImportListBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_importlist_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_schema(
        self,
    ) -> list[models.ImportListResource]:
        return cast(
            "list[models.ImportListResource]",
            await _ops.list_importlist_schema_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create_test(
        self,
        *,
        force_test: bool | None = None,
        body: models.ImportListResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.create_importlist_test_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_test=force_test,
                body=body,
            ),
        )

    async def create_testall(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_importlist_testall_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def post_action_by_name(
        self,
        name: str,
        *,
        body: models.ImportListResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.post_importlist_action_by_name_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                name,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
