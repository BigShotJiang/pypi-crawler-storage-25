"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Localization."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class LocalizationResource:
    """Sync wrapper for the ``Localization`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list_localization(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def list_language(
        self,
    ) -> models.LocalizationLanguageResource:
        return cast(
            "models.LocalizationLanguageResource",
            _ops.list_localization_language(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncLocalizationResource:
    """Async wrapper for the ``Localization`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_localization_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def list_language(
        self,
    ) -> models.LocalizationLanguageResource:
        return cast(
            "models.LocalizationLanguageResource",
            await _ops.list_localization_language_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
