"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: RenameMovie."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class RenameMovieResource:
    """Sync wrapper for the ``RenameMovie`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        movie_id: list[int] | None = None,
    ) -> list[models.RenameMovieResource]:
        return cast(
            "list[models.RenameMovieResource]",
            _ops.list_rename(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
            ),
        )


class AsyncRenameMovieResource:
    """Async wrapper for the ``RenameMovie`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        movie_id: list[int] | None = None,
    ) -> list[models.RenameMovieResource]:
        return cast(
            "list[models.RenameMovieResource]",
            await _ops.list_rename_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
