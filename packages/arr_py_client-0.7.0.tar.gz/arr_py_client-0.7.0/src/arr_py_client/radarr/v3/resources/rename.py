"""Rename workflow for Radarr v3.

Preview + execute for the "rename files according to the current naming
policy" operation. Two steps:

1. ``candidates(movie_ids=...)`` — GET ``/rename`` returns the list of files
   that would be renamed, with old and new paths.
2. ``execute(movie_ids=...)`` — fires the ``RenameMovie`` command. Returns
   the command resource; pair with :meth:`~arr_py_client.radarr.v3.resources.
   commands.CommandsResource.wait_for` to block.

If only specific files should be renamed, use ``execute(movie_id=..., files=...)``
to fire the ``RenameFiles`` command with a scoped file-id list instead.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _rename_command(
    *,
    movie_ids: list[int] | None,
    movie_id: int | None,
    files: list[int] | None,
) -> dict[str, Any]:
    if movie_id is not None and files is not None:
        return {"name": "RenameFiles", "movieId": movie_id, "files": files}
    if movie_ids is None:
        msg = (
            "execute() requires either movie_ids=[...] (RenameMovie) "
            "or movie_id=..+files=[...] (RenameFiles)"
        )
        raise ValueError(msg)
    return {"name": "RenameMovie", "movieIds": movie_ids}


class RenameResource:
    """Sync Radarr rename workflow (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def candidates(
        self, *, movie_ids: list[int] | None = None
    ) -> list[_models.RenameMovieResource]:
        """List files that would be renamed for the given movies."""
        return cast(
            "list[_models.RenameMovieResource]",
            _ops.list_rename(self._transport, movie_id=movie_ids),  # pyright: ignore[reportUnknownMemberType]
        )

    def execute(
        self,
        *,
        movie_ids: list[int] | None = None,
        movie_id: int | None = None,
        files: list[int] | None = None,
    ) -> _models.CommandResource:
        """Fire a rename command.

        Pass ``movie_ids=[...]`` for a full-movie rename (``RenameMovie``),
        or ``movie_id=..+files=[...]`` for a specific-file rename (``RenameFiles``).
        """
        payload = _rename_command(movie_ids=movie_ids, movie_id=movie_id, files=files)
        response = self._transport.request("POST", "/command", json=payload)
        return _models.CommandResource.model_validate(response.json())


class AsyncRenameResource:
    """Async Radarr rename workflow (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def candidates(
        self, *, movie_ids: list[int] | None = None
    ) -> list[_models.RenameMovieResource]:
        return cast(
            "list[_models.RenameMovieResource]",
            await _ops.list_rename_async(self._transport, movie_id=movie_ids),  # pyright: ignore[reportUnknownMemberType]
        )

    async def execute(
        self,
        *,
        movie_ids: list[int] | None = None,
        movie_id: int | None = None,
        files: list[int] | None = None,
    ) -> _models.CommandResource:
        payload = _rename_command(movie_ids=movie_ids, movie_id=movie_id, files=files)
        response = await self._transport.request("POST", "/command", json=payload)
        return _models.CommandResource.model_validate(response.json())
