"""Ping / health-check resource for Radarr v3.

Radarr exposes ``/ping`` outside the ``/api/v3`` prefix; this resource calls it
via ``transport.request(..., absolute=True)`` rather than the auto-generated
wrapper (which would incorrectly hit ``/api/v3/ping``).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3.resources._auto.ping import (
    AsyncPingResource as _AutoAsync,
)
from arr_py_client.radarr.v3.resources._auto.ping import (
    PingResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class PingResource(_AutoSync):
    """Sync Radarr ping resource; callable as ``client.ping()`` for a bool health check."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def __call__(self) -> bool:
        """Return ``True`` if the server is reachable, else raise the usual ``ArrError``."""
        self._transport.request("GET", "/ping", absolute=True, timeout=5.0)
        return True

    def list_(self) -> _models.PingResource:
        """Fetch the full ``PingResource`` payload (status + version)."""
        response = self._transport.request("GET", "/ping", absolute=True)
        return _models.PingResource.model_validate(response.json())


class AsyncPingResource(_AutoAsync):
    """Async Radarr ping resource; callable as ``await client.ping()``."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def __call__(self) -> _PingAwaitable:
        return _PingAwaitable(self)

    async def list_(self) -> _models.PingResource:
        response = await self._transport.request("GET", "/ping", absolute=True)
        return _models.PingResource.model_validate(response.json())


class _PingAwaitable:
    """Makes ``await client.ping()`` work while keeping ``client.ping.list_()`` subresource form."""

    def __init__(self, resource: AsyncPingResource) -> None:
        super().__init__()
        self._resource = resource

    def __await__(self):
        return self._check().__await__()

    async def _check(self) -> bool:
        await self._resource._transport.request(  # pyright: ignore[reportPrivateUsage]
            "GET", "/ping", absolute=True, timeout=5.0
        )
        return True
