"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: TagDetails."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class TagDetailsResource:
    """Sync wrapper for the ``TagDetails`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.TagDetailsResource]:
        return cast(
            "list[models.TagDetailsResource]",
            _ops.list_tag_detail(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.TagDetailsResource:
        return cast(
            "models.TagDetailsResource",
            _ops.get_tag_detail_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncTagDetailsResource:
    """Async wrapper for the ``TagDetails`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.TagDetailsResource]:
        return cast(
            "list[models.TagDetailsResource]",
            await _ops.list_tag_detail_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.TagDetailsResource:
        return cast(
            "models.TagDetailsResource",
            await _ops.get_tag_detail_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
