"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Log."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class LogResource:
    """Sync wrapper for the ``Log`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        level: str | None = None,
    ) -> models.LogResourcePagingResource:
        return cast(
            "models.LogResourcePagingResource",
            _ops.list_log(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                level=level,
            ),
        )


class AsyncLogResource:
    """Async wrapper for the ``Log`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        level: str | None = None,
    ) -> models.LogResourcePagingResource:
        return cast(
            "models.LogResourcePagingResource",
            await _ops.list_log_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                level=level,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
