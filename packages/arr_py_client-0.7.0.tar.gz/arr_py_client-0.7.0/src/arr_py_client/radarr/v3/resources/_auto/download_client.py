"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: DownloadClient."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class DownloadClientResource:
    """Sync wrapper for the ``DownloadClient`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.DownloadClientResource]:
        return cast(
            "list[models.DownloadClientResource]",
            _ops.list_downloadclient(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create(
        self,
        *,
        force_save: bool | None = None,
        body: models.DownloadClientResource | None = None,
    ) -> models.DownloadClientResource:
        return cast(
            "models.DownloadClientResource",
            _ops.create_downloadclient(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_save=force_save,
                body=body,
            ),
        )

    def update_by_id(
        self,
        id: int,
        *,
        force_save: bool | None = None,
        body: models.DownloadClientResource | None = None,
    ) -> models.DownloadClientResource:
        return cast(
            "models.DownloadClientResource",
            _ops.update_downloadclient_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                force_save=force_save,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_downloadclient_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.DownloadClientResource:
        return cast(
            "models.DownloadClientResource",
            _ops.get_downloadclient_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_bulk(
        self,
        *,
        body: models.DownloadClientBulkResource | None = None,
    ) -> models.DownloadClientResource:
        return cast(
            "models.DownloadClientResource",
            _ops.update_downloadclient_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def delete_bulk(
        self,
        *,
        body: models.DownloadClientBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_downloadclient_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_schema(
        self,
    ) -> list[models.DownloadClientResource]:
        return cast(
            "list[models.DownloadClientResource]",
            _ops.list_downloadclient_schema(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create_test(
        self,
        *,
        force_test: bool | None = None,
        body: models.DownloadClientResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.create_downloadclient_test(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_test=force_test,
                body=body,
            ),
        )

    def create_testall(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_downloadclient_testall(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def post_action_by_name(
        self,
        name: str,
        *,
        body: models.DownloadClientResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.post_downloadclient_action_by_name(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                name,
                body=body,
            ),
        )


class AsyncDownloadClientResource:
    """Async wrapper for the ``DownloadClient`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.DownloadClientResource]:
        return cast(
            "list[models.DownloadClientResource]",
            await _ops.list_downloadclient_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create(
        self,
        *,
        force_save: bool | None = None,
        body: models.DownloadClientResource | None = None,
    ) -> models.DownloadClientResource:
        return cast(
            "models.DownloadClientResource",
            await _ops.create_downloadclient_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_save=force_save,
                body=body,
            ),
        )

    async def update_by_id(
        self,
        id: int,
        *,
        force_save: bool | None = None,
        body: models.DownloadClientResource | None = None,
    ) -> models.DownloadClientResource:
        return cast(
            "models.DownloadClientResource",
            await _ops.update_downloadclient_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                force_save=force_save,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_downloadclient_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.DownloadClientResource:
        return cast(
            "models.DownloadClientResource",
            await _ops.get_downloadclient_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_bulk(
        self,
        *,
        body: models.DownloadClientBulkResource | None = None,
    ) -> models.DownloadClientResource:
        return cast(
            "models.DownloadClientResource",
            await _ops.update_downloadclient_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def delete_bulk(
        self,
        *,
        body: models.DownloadClientBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_downloadclient_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_schema(
        self,
    ) -> list[models.DownloadClientResource]:
        return cast(
            "list[models.DownloadClientResource]",
            await _ops.list_downloadclient_schema_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create_test(
        self,
        *,
        force_test: bool | None = None,
        body: models.DownloadClientResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.create_downloadclient_test_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_test=force_test,
                body=body,
            ),
        )

    async def create_testall(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_downloadclient_testall_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def post_action_by_name(
        self,
        name: str,
        *,
        body: models.DownloadClientResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.post_downloadclient_action_by_name_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                name,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
