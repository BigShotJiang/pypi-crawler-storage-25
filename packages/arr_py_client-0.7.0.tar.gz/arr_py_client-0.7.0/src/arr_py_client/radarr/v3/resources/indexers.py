"""Indexers resource for Radarr v3."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops
from arr_py_client.radarr.v3.resources._auto.indexer import (
    AsyncIndexerResource as _AutoAsyncIndexerResource,
)
from arr_py_client.radarr.v3.resources._auto.indexer import (
    IndexerResource as _AutoIndexerResource,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class IndexersResource(_AutoIndexerResource):
    """Sync Radarr indexers resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.IndexerResource]:
        return cast(
            "list[_models.IndexerResource]",
            _ops.list_indexer(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.IndexerResource:  # noqa: A002
        return _ops.get_indexer_by_id(self._transport, id)

    def create(self, *, body: _models.IndexerResource) -> _models.IndexerResource:
        return _ops.create_indexer(self._transport, body=body)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.IndexerResource,
    ) -> _models.IndexerResource:
        return _ops.update_indexer_by_id(self._transport, id, body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_indexer_by_id(self._transport, id)

    def schema(self) -> list[_models.IndexerResource]:
        return cast(
            "list[_models.IndexerResource]",
            _ops.list_indexer_schema(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def test(self, *, body: _models.IndexerResource) -> Any:
        return _ops.create_indexer_test(self._transport, body=body)

    def test_all(self) -> Any:
        return _ops.create_indexer_testall(self._transport)


class AsyncIndexersResource(_AutoAsyncIndexerResource):
    """Async Radarr indexers resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.IndexerResource]:
        return cast(
            "list[_models.IndexerResource]",
            await _ops.list_indexer_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.IndexerResource:  # noqa: A002
        return await _ops.get_indexer_by_id_async(self._transport, id)

    async def create(self, *, body: _models.IndexerResource) -> _models.IndexerResource:
        return await _ops.create_indexer_async(self._transport, body=body)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.IndexerResource,
    ) -> _models.IndexerResource:
        return await _ops.update_indexer_by_id_async(self._transport, id, body=body)

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_indexer_by_id_async(self._transport, id)

    async def schema(self) -> list[_models.IndexerResource]:
        return cast(
            "list[_models.IndexerResource]",
            await _ops.list_indexer_schema_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def test(self, *, body: _models.IndexerResource) -> Any:
        return await _ops.create_indexer_test_async(self._transport, body=body)

    async def test_all(self) -> Any:
        return await _ops.create_indexer_testall_async(self._transport)
