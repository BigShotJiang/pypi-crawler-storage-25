"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Release."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ReleaseResource:
    """Sync wrapper for the ``Release`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.ReleaseResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.create_release(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
        *,
        movie_id: int | None = None,
    ) -> list[models.ReleaseResource]:
        return cast(
            "list[models.ReleaseResource]",
            _ops.list_release(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
            ),
        )


class AsyncReleaseResource:
    """Async wrapper for the ``Release`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.ReleaseResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.create_release_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
        *,
        movie_id: int | None = None,
    ) -> list[models.ReleaseResource]:
        return cast(
            "list[models.ReleaseResource]",
            await _ops.list_release_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
