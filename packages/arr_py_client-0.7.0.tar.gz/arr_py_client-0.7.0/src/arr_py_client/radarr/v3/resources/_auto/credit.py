"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Credit."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class CreditResource:
    """Sync wrapper for the ``Credit`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        movie_id: int | None = None,
        movie_metadata_id: int | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.list_credit(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
                movie_metadata_id=movie_metadata_id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.CreditResource:
        return cast(
            "models.CreditResource",
            _ops.get_credit_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncCreditResource:
    """Async wrapper for the ``Credit`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        movie_id: int | None = None,
        movie_metadata_id: int | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.list_credit_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
                movie_metadata_id=movie_metadata_id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.CreditResource:
        return cast(
            "models.CreditResource",
            await _ops.get_credit_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
