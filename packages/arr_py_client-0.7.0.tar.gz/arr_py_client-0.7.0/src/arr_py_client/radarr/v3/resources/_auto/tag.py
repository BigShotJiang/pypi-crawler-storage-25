"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Tag."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class TagResource:
    """Sync wrapper for the ``Tag`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.TagResource]:
        return cast(
            "list[models.TagResource]",
            _ops.list_tag(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create(
        self,
        *,
        body: models.TagResource | None = None,
    ) -> models.TagResource:
        return cast(
            "models.TagResource",
            _ops.create_tag(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.TagResource | None = None,
    ) -> models.TagResource:
        return cast(
            "models.TagResource",
            _ops.update_tag_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_tag_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.TagResource:
        return cast(
            "models.TagResource",
            _ops.get_tag_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncTagResource:
    """Async wrapper for the ``Tag`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.TagResource]:
        return cast(
            "list[models.TagResource]",
            await _ops.list_tag_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create(
        self,
        *,
        body: models.TagResource | None = None,
    ) -> models.TagResource:
        return cast(
            "models.TagResource",
            await _ops.create_tag_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.TagResource | None = None,
    ) -> models.TagResource:
        return cast(
            "models.TagResource",
            await _ops.update_tag_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_tag_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.TagResource:
        return cast(
            "models.TagResource",
            await _ops.get_tag_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
