"""Commands resource for Radarr v3 with a ``wait_for`` helper + typed named commands."""

from __future__ import annotations

import asyncio
import time
from enum import StrEnum
from typing import TYPE_CHECKING, Any, cast

import anyio

from arr_py_client._common.errors import ArrTimeoutError
from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


_TERMINAL_STATUSES = frozenset({"completed", "failed", "aborted", "cancelled"})


class KnownCommand(StrEnum):
    """Commonly-used Radarr command names.

    Not exhaustive — use :meth:`CommandsResource.post` with a raw string for
    commands not listed here.
    """

    MOVIES_SEARCH = "MoviesSearch"
    REFRESH_MOVIE = "RefreshMovie"
    RENAME_MOVIE = "RenameMovie"
    RSS_SYNC = "RssSync"
    BACKUP = "Backup"
    CLEAN_UP_RECYCLE_BIN = "CleanUpRecycleBin"
    MISSING_MOVIES_SEARCH = "MissingMoviesSearch"
    CUTOFF_UNMET_MOVIES_SEARCH = "CutoffUnmetMoviesSearch"
    APPLICATION_UPDATE = "ApplicationUpdate"
    MANUAL_IMPORT = "ManualImport"
    DOWNLOADED_MOVIES_SCAN = "DownloadedMoviesScan"


def _status(cmd: object) -> str:
    raw = getattr(cmd, "status", None)
    return str(raw).lower() if raw is not None else ""


class CommandsResource:
    """Sync Radarr commands resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list(self) -> list[_models.CommandResource]:
        return cast(
            "list[_models.CommandResource]",
            _ops.list_command(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    def get(self, *, id: int) -> _models.CommandResource:  # noqa: A002
        return _ops.get_command_by_id(self._transport, id)

    def post(self, *, name: str, **body: Any) -> _models.CommandResource:
        """Send a command by name (e.g. ``"MoviesSearch"``, ``"RefreshMovie"``).

        Any extra kwargs become fields on the command payload.
        """
        payload: dict[str, Any] = {"name": name, **body}
        response = self._transport.request("POST", "/command", json=payload)
        return _models.CommandResource.model_validate(response.json())

    def cancel(self, *, id: int) -> None:  # noqa: A002
        _ops.delete_command_by_id(self._transport, id)

    def wait_for(
        self,
        id: int,  # noqa: A002
        *,
        poll_interval: float = 2.0,
        timeout: float | None = 120.0,
    ) -> _models.CommandResource:
        """Block until the command reaches a terminal state.

        Returns the final ``CommandResource``. Raises :class:`ArrTimeoutError`
        if ``timeout`` elapses before the command finishes.
        """
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            cmd = self.get(id=id)
            if _status(cmd) in _TERMINAL_STATUSES:
                return cmd
            if deadline is not None and time.monotonic() >= deadline:
                msg = f"command {id} did not reach terminal state within {timeout}s"
                raise ArrTimeoutError(msg)
            time.sleep(poll_interval)

    # ---- typed named commands ----

    def movies_search(self, *, ids: list[int]) -> _models.CommandResource:
        """Search indexers for a list of movies."""
        return self.post(name=KnownCommand.MOVIES_SEARCH, movieIds=list(ids))

    def refresh_movie(self, *, ids: list[int] | None = None) -> _models.CommandResource:
        """Refresh movie metadata. ``None`` refreshes all."""
        if ids is None:
            return self.post(name=KnownCommand.REFRESH_MOVIE)
        return self.post(name=KnownCommand.REFRESH_MOVIE, movieIds=list(ids))

    def rss_sync(self) -> _models.CommandResource:
        return self.post(name=KnownCommand.RSS_SYNC)

    def backup(self) -> _models.CommandResource:
        return self.post(name=KnownCommand.BACKUP)

    def missing_movies_search(self) -> _models.CommandResource:
        return self.post(name=KnownCommand.MISSING_MOVIES_SEARCH)

    def cutoff_unmet_movies_search(self) -> _models.CommandResource:
        return self.post(name=KnownCommand.CUTOFF_UNMET_MOVIES_SEARCH)


class AsyncCommandsResource:
    """Async Radarr commands resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list(self) -> list[_models.CommandResource]:
        return cast(
            "list[_models.CommandResource]",
            await _ops.list_command_async(self._transport),  # pyright: ignore[reportUnknownMemberType]
        )

    async def get(self, *, id: int) -> _models.CommandResource:  # noqa: A002
        return await _ops.get_command_by_id_async(self._transport, id)

    async def post(self, *, name: str, **body: Any) -> _models.CommandResource:
        payload: dict[str, Any] = {"name": name, **body}
        response = await self._transport.request("POST", "/command", json=payload)
        return _models.CommandResource.model_validate(response.json())

    async def cancel(self, *, id: int) -> None:  # noqa: A002
        await _ops.delete_command_by_id_async(self._transport, id)

    async def wait_for(
        self,
        id: int,  # noqa: A002
        *,
        poll_interval: float = 2.0,
        timeout: float | None = 120.0,
    ) -> _models.CommandResource:
        loop = asyncio.get_running_loop()
        deadline = None if timeout is None else loop.time() + timeout
        while True:
            cmd = await self.get(id=id)
            if _status(cmd) in _TERMINAL_STATUSES:
                return cmd
            if deadline is not None and loop.time() >= deadline:
                msg = f"command {id} did not reach terminal state within {timeout}s"
                raise ArrTimeoutError(msg)
            await anyio.sleep(poll_interval)

    # ---- typed named commands ----

    async def movies_search(self, *, ids: list[int]) -> _models.CommandResource:
        return await self.post(name=KnownCommand.MOVIES_SEARCH, movieIds=list(ids))

    async def refresh_movie(
        self, *, ids: list[int] | None = None
    ) -> _models.CommandResource:
        if ids is None:
            return await self.post(name=KnownCommand.REFRESH_MOVIE)
        return await self.post(name=KnownCommand.REFRESH_MOVIE, movieIds=list(ids))

    async def rss_sync(self) -> _models.CommandResource:
        return await self.post(name=KnownCommand.RSS_SYNC)

    async def backup(self) -> _models.CommandResource:
        return await self.post(name=KnownCommand.BACKUP)

    async def missing_movies_search(self) -> _models.CommandResource:
        return await self.post(name=KnownCommand.MISSING_MOVIES_SEARCH)

    async def cutoff_unmet_movies_search(self) -> _models.CommandResource:
        return await self.post(name=KnownCommand.CUTOFF_UNMET_MOVIES_SEARCH)
