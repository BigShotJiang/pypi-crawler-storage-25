"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: DiskSpace."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class DiskSpaceResource:
    """Sync wrapper for the ``DiskSpace`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.DiskSpaceResource]:
        return cast(
            "list[models.DiskSpaceResource]",
            _ops.list_diskspace(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncDiskSpaceResource:
    """Async wrapper for the ``DiskSpace`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.DiskSpaceResource]:
        return cast(
            "list[models.DiskSpaceResource]",
            await _ops.list_diskspace_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
