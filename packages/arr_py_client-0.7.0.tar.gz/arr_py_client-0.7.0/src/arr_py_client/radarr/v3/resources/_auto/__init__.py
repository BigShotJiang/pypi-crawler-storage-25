"""Auto-generated resource wrappers for radarr."""

from __future__ import annotations

from arr_py_client.radarr.v3.resources._auto.alternative_title import (
    AsyncAlternativeTitleResource,
    AlternativeTitleResource,
)
from arr_py_client.radarr.v3.resources._auto.api_info import (
    AsyncApiInfoResource,
    ApiInfoResource,
)
from arr_py_client.radarr.v3.resources._auto.authentication import (
    AsyncAuthenticationResource,
    AuthenticationResource,
)
from arr_py_client.radarr.v3.resources._auto.auto_tagging import (
    AsyncAutoTaggingResource,
    AutoTaggingResource,
)
from arr_py_client.radarr.v3.resources._auto.backup import (
    AsyncBackupResource,
    BackupResource,
)
from arr_py_client.radarr.v3.resources._auto.blocklist import (
    AsyncBlocklistResource,
    BlocklistResource,
)
from arr_py_client.radarr.v3.resources._auto.calendar import (
    AsyncCalendarResource,
    CalendarResource,
)
from arr_py_client.radarr.v3.resources._auto.calendar_feed import (
    AsyncCalendarFeedResource,
    CalendarFeedResource,
)
from arr_py_client.radarr.v3.resources._auto.collection import (
    AsyncCollectionResource,
    CollectionResource,
)
from arr_py_client.radarr.v3.resources._auto.command import (
    AsyncCommandResource,
    CommandResource,
)
from arr_py_client.radarr.v3.resources._auto.credit import (
    AsyncCreditResource,
    CreditResource,
)
from arr_py_client.radarr.v3.resources._auto.custom_filter import (
    AsyncCustomFilterResource,
    CustomFilterResource,
)
from arr_py_client.radarr.v3.resources._auto.custom_format import (
    AsyncCustomFormatResource,
    CustomFormatResource,
)
from arr_py_client.radarr.v3.resources._auto.cutoff import (
    AsyncCutoffResource,
    CutoffResource,
)
from arr_py_client.radarr.v3.resources._auto.delay_profile import (
    AsyncDelayProfileResource,
    DelayProfileResource,
)
from arr_py_client.radarr.v3.resources._auto.disk_space import (
    AsyncDiskSpaceResource,
    DiskSpaceResource,
)
from arr_py_client.radarr.v3.resources._auto.download_client import (
    AsyncDownloadClientResource,
    DownloadClientResource,
)
from arr_py_client.radarr.v3.resources._auto.download_client_config import (
    AsyncDownloadClientConfigResource,
    DownloadClientConfigResource,
)
from arr_py_client.radarr.v3.resources._auto.extra_file import (
    AsyncExtraFileResource,
    ExtraFileResource,
)
from arr_py_client.radarr.v3.resources._auto.file_system import (
    AsyncFileSystemResource,
    FileSystemResource,
)
from arr_py_client.radarr.v3.resources._auto.health import (
    AsyncHealthResource,
    HealthResource,
)
from arr_py_client.radarr.v3.resources._auto.history import (
    AsyncHistoryResource,
    HistoryResource,
)
from arr_py_client.radarr.v3.resources._auto.host_config import (
    AsyncHostConfigResource,
    HostConfigResource,
)
from arr_py_client.radarr.v3.resources._auto.import_list import (
    AsyncImportListResource,
    ImportListResource,
)
from arr_py_client.radarr.v3.resources._auto.import_list_config import (
    AsyncImportListConfigResource,
    ImportListConfigResource,
)
from arr_py_client.radarr.v3.resources._auto.import_list_exclusion import (
    AsyncImportListExclusionResource,
    ImportListExclusionResource,
)
from arr_py_client.radarr.v3.resources._auto.import_list_movies import (
    AsyncImportListMoviesResource,
    ImportListMoviesResource,
)
from arr_py_client.radarr.v3.resources._auto.indexer import (
    AsyncIndexerResource,
    IndexerResource,
)
from arr_py_client.radarr.v3.resources._auto.indexer_config import (
    AsyncIndexerConfigResource,
    IndexerConfigResource,
)
from arr_py_client.radarr.v3.resources._auto.indexer_flag import (
    AsyncIndexerFlagResource,
    IndexerFlagResource,
)
from arr_py_client.radarr.v3.resources._auto.language import (
    AsyncLanguageResource,
    LanguageResource,
)
from arr_py_client.radarr.v3.resources._auto.localization import (
    AsyncLocalizationResource,
    LocalizationResource,
)
from arr_py_client.radarr.v3.resources._auto.log import AsyncLogResource, LogResource
from arr_py_client.radarr.v3.resources._auto.log_file import (
    AsyncLogFileResource,
    LogFileResource,
)
from arr_py_client.radarr.v3.resources._auto.manual_import import (
    AsyncManualImportResource,
    ManualImportResource,
)
from arr_py_client.radarr.v3.resources._auto.media_cover import (
    AsyncMediaCoverResource,
    MediaCoverResource,
)
from arr_py_client.radarr.v3.resources._auto.media_management_config import (
    AsyncMediaManagementConfigResource,
    MediaManagementConfigResource,
)
from arr_py_client.radarr.v3.resources._auto.metadata import (
    AsyncMetadataResource,
    MetadataResource,
)
from arr_py_client.radarr.v3.resources._auto.metadata_config import (
    AsyncMetadataConfigResource,
    MetadataConfigResource,
)
from arr_py_client.radarr.v3.resources._auto.missing import (
    AsyncMissingResource,
    MissingResource,
)
from arr_py_client.radarr.v3.resources._auto.movie import (
    AsyncMovieResource,
    MovieResource,
)
from arr_py_client.radarr.v3.resources._auto.movie_editor import (
    AsyncMovieEditorResource,
    MovieEditorResource,
)
from arr_py_client.radarr.v3.resources._auto.movie_file import (
    AsyncMovieFileResource,
    MovieFileResource,
)
from arr_py_client.radarr.v3.resources._auto.movie_folder import (
    AsyncMovieFolderResource,
    MovieFolderResource,
)
from arr_py_client.radarr.v3.resources._auto.movie_import import (
    AsyncMovieImportResource,
    MovieImportResource,
)
from arr_py_client.radarr.v3.resources._auto.movie_lookup import (
    AsyncMovieLookupResource,
    MovieLookupResource,
)
from arr_py_client.radarr.v3.resources._auto.naming_config import (
    AsyncNamingConfigResource,
    NamingConfigResource,
)
from arr_py_client.radarr.v3.resources._auto.notification import (
    AsyncNotificationResource,
    NotificationResource,
)
from arr_py_client.radarr.v3.resources._auto.parse import (
    AsyncParseResource,
    ParseResource,
)
from arr_py_client.radarr.v3.resources._auto.ping import AsyncPingResource, PingResource
from arr_py_client.radarr.v3.resources._auto.quality_definition import (
    AsyncQualityDefinitionResource,
    QualityDefinitionResource,
)
from arr_py_client.radarr.v3.resources._auto.quality_profile import (
    AsyncQualityProfileResource,
    QualityProfileResource,
)
from arr_py_client.radarr.v3.resources._auto.quality_profile_schema import (
    AsyncQualityProfileSchemaResource,
    QualityProfileSchemaResource,
)
from arr_py_client.radarr.v3.resources._auto.queue import (
    AsyncQueueResource,
    QueueResource,
)
from arr_py_client.radarr.v3.resources._auto.queue_action import (
    AsyncQueueActionResource,
    QueueActionResource,
)
from arr_py_client.radarr.v3.resources._auto.queue_details import (
    AsyncQueueDetailsResource,
    QueueDetailsResource,
)
from arr_py_client.radarr.v3.resources._auto.queue_status import (
    AsyncQueueStatusResource,
    QueueStatusResource,
)
from arr_py_client.radarr.v3.resources._auto.release import (
    AsyncReleaseResource,
    ReleaseResource,
)
from arr_py_client.radarr.v3.resources._auto.release_profile import (
    AsyncReleaseProfileResource,
    ReleaseProfileResource,
)
from arr_py_client.radarr.v3.resources._auto.release_push import (
    AsyncReleasePushResource,
    ReleasePushResource,
)
from arr_py_client.radarr.v3.resources._auto.remote_path_mapping import (
    AsyncRemotePathMappingResource,
    RemotePathMappingResource,
)
from arr_py_client.radarr.v3.resources._auto.rename_movie import (
    AsyncRenameMovieResource,
    RenameMovieResource,
)
from arr_py_client.radarr.v3.resources._auto.root_folder import (
    AsyncRootFolderResource,
    RootFolderResource,
)
from arr_py_client.radarr.v3.resources._auto.static_resource import (
    AsyncStaticResourceResource,
    StaticResourceResource,
)
from arr_py_client.radarr.v3.resources._auto.system import (
    AsyncSystemResource,
    SystemResource,
)
from arr_py_client.radarr.v3.resources._auto.tag import AsyncTagResource, TagResource
from arr_py_client.radarr.v3.resources._auto.tag_details import (
    AsyncTagDetailsResource,
    TagDetailsResource,
)
from arr_py_client.radarr.v3.resources._auto.task import AsyncTaskResource, TaskResource
from arr_py_client.radarr.v3.resources._auto.ui_config import (
    AsyncUiConfigResource,
    UiConfigResource,
)
from arr_py_client.radarr.v3.resources._auto.update import (
    AsyncUpdateResource,
    UpdateResource,
)
from arr_py_client.radarr.v3.resources._auto.update_log_file import (
    AsyncUpdateLogFileResource,
    UpdateLogFileResource,
)

__all__ = [
    "AlternativeTitleResource",
    "ApiInfoResource",
    "AsyncAlternativeTitleResource",
    "AsyncApiInfoResource",
    "AsyncAuthenticationResource",
    "AsyncAutoTaggingResource",
    "AsyncBackupResource",
    "AsyncBlocklistResource",
    "AsyncCalendarFeedResource",
    "AsyncCalendarResource",
    "AsyncCollectionResource",
    "AsyncCommandResource",
    "AsyncCreditResource",
    "AsyncCustomFilterResource",
    "AsyncCustomFormatResource",
    "AsyncCutoffResource",
    "AsyncDelayProfileResource",
    "AsyncDiskSpaceResource",
    "AsyncDownloadClientConfigResource",
    "AsyncDownloadClientResource",
    "AsyncExtraFileResource",
    "AsyncFileSystemResource",
    "AsyncHealthResource",
    "AsyncHistoryResource",
    "AsyncHostConfigResource",
    "AsyncImportListConfigResource",
    "AsyncImportListExclusionResource",
    "AsyncImportListMoviesResource",
    "AsyncImportListResource",
    "AsyncIndexerConfigResource",
    "AsyncIndexerFlagResource",
    "AsyncIndexerResource",
    "AsyncLanguageResource",
    "AsyncLocalizationResource",
    "AsyncLogFileResource",
    "AsyncLogResource",
    "AsyncManualImportResource",
    "AsyncMediaCoverResource",
    "AsyncMediaManagementConfigResource",
    "AsyncMetadataConfigResource",
    "AsyncMetadataResource",
    "AsyncMissingResource",
    "AsyncMovieEditorResource",
    "AsyncMovieFileResource",
    "AsyncMovieFolderResource",
    "AsyncMovieImportResource",
    "AsyncMovieLookupResource",
    "AsyncMovieResource",
    "AsyncNamingConfigResource",
    "AsyncNotificationResource",
    "AsyncParseResource",
    "AsyncPingResource",
    "AsyncQualityDefinitionResource",
    "AsyncQualityProfileResource",
    "AsyncQualityProfileSchemaResource",
    "AsyncQueueActionResource",
    "AsyncQueueDetailsResource",
    "AsyncQueueResource",
    "AsyncQueueStatusResource",
    "AsyncReleaseProfileResource",
    "AsyncReleasePushResource",
    "AsyncReleaseResource",
    "AsyncRemotePathMappingResource",
    "AsyncRenameMovieResource",
    "AsyncRootFolderResource",
    "AsyncStaticResourceResource",
    "AsyncSystemResource",
    "AsyncTagDetailsResource",
    "AsyncTagResource",
    "AsyncTaskResource",
    "AsyncUiConfigResource",
    "AsyncUpdateLogFileResource",
    "AsyncUpdateResource",
    "AuthenticationResource",
    "AutoTaggingResource",
    "BackupResource",
    "BlocklistResource",
    "CalendarFeedResource",
    "CalendarResource",
    "CollectionResource",
    "CommandResource",
    "CreditResource",
    "CustomFilterResource",
    "CustomFormatResource",
    "CutoffResource",
    "DelayProfileResource",
    "DiskSpaceResource",
    "DownloadClientConfigResource",
    "DownloadClientResource",
    "ExtraFileResource",
    "FileSystemResource",
    "HealthResource",
    "HistoryResource",
    "HostConfigResource",
    "ImportListConfigResource",
    "ImportListExclusionResource",
    "ImportListMoviesResource",
    "ImportListResource",
    "IndexerConfigResource",
    "IndexerFlagResource",
    "IndexerResource",
    "LanguageResource",
    "LocalizationResource",
    "LogFileResource",
    "LogResource",
    "ManualImportResource",
    "MediaCoverResource",
    "MediaManagementConfigResource",
    "MetadataConfigResource",
    "MetadataResource",
    "MissingResource",
    "MovieEditorResource",
    "MovieFileResource",
    "MovieFolderResource",
    "MovieImportResource",
    "MovieLookupResource",
    "MovieResource",
    "NamingConfigResource",
    "NotificationResource",
    "ParseResource",
    "PingResource",
    "QualityDefinitionResource",
    "QualityProfileResource",
    "QualityProfileSchemaResource",
    "QueueActionResource",
    "QueueDetailsResource",
    "QueueResource",
    "QueueStatusResource",
    "ReleaseProfileResource",
    "ReleasePushResource",
    "ReleaseResource",
    "RemotePathMappingResource",
    "RenameMovieResource",
    "RootFolderResource",
    "StaticResourceResource",
    "SystemResource",
    "TagDetailsResource",
    "TagResource",
    "TaskResource",
    "UiConfigResource",
    "UpdateLogFileResource",
    "UpdateResource",
]

SYNC_RESOURCES = {
    "alternative_title": AlternativeTitleResource,
    "api_info": ApiInfoResource,
    "authentication": AuthenticationResource,
    "auto_tagging": AutoTaggingResource,
    "backup": BackupResource,
    "blocklist": BlocklistResource,
    "calendar": CalendarResource,
    "calendar_feed": CalendarFeedResource,
    "collection": CollectionResource,
    "command": CommandResource,
    "credit": CreditResource,
    "custom_filter": CustomFilterResource,
    "custom_format": CustomFormatResource,
    "cutoff": CutoffResource,
    "delay_profile": DelayProfileResource,
    "disk_space": DiskSpaceResource,
    "download_client": DownloadClientResource,
    "download_client_config": DownloadClientConfigResource,
    "extra_file": ExtraFileResource,
    "file_system": FileSystemResource,
    "health": HealthResource,
    "history": HistoryResource,
    "host_config": HostConfigResource,
    "import_list": ImportListResource,
    "import_list_config": ImportListConfigResource,
    "import_list_exclusion": ImportListExclusionResource,
    "import_list_movies": ImportListMoviesResource,
    "indexer": IndexerResource,
    "indexer_config": IndexerConfigResource,
    "indexer_flag": IndexerFlagResource,
    "language": LanguageResource,
    "localization": LocalizationResource,
    "log": LogResource,
    "log_file": LogFileResource,
    "manual_import": ManualImportResource,
    "media_cover": MediaCoverResource,
    "media_management_config": MediaManagementConfigResource,
    "metadata": MetadataResource,
    "metadata_config": MetadataConfigResource,
    "missing": MissingResource,
    "movie": MovieResource,
    "movie_editor": MovieEditorResource,
    "movie_file": MovieFileResource,
    "movie_folder": MovieFolderResource,
    "movie_import": MovieImportResource,
    "movie_lookup": MovieLookupResource,
    "naming_config": NamingConfigResource,
    "notification": NotificationResource,
    "parse": ParseResource,
    "ping": PingResource,
    "quality_definition": QualityDefinitionResource,
    "quality_profile": QualityProfileResource,
    "quality_profile_schema": QualityProfileSchemaResource,
    "queue": QueueResource,
    "queue_action": QueueActionResource,
    "queue_details": QueueDetailsResource,
    "queue_status": QueueStatusResource,
    "release": ReleaseResource,
    "release_profile": ReleaseProfileResource,
    "release_push": ReleasePushResource,
    "remote_path_mapping": RemotePathMappingResource,
    "rename_movie": RenameMovieResource,
    "root_folder": RootFolderResource,
    "static_resource": StaticResourceResource,
    "system": SystemResource,
    "tag": TagResource,
    "tag_details": TagDetailsResource,
    "task": TaskResource,
    "ui_config": UiConfigResource,
    "update": UpdateResource,
    "update_log_file": UpdateLogFileResource,
}

ASYNC_RESOURCES = {
    "alternative_title": AsyncAlternativeTitleResource,
    "api_info": AsyncApiInfoResource,
    "authentication": AsyncAuthenticationResource,
    "auto_tagging": AsyncAutoTaggingResource,
    "backup": AsyncBackupResource,
    "blocklist": AsyncBlocklistResource,
    "calendar": AsyncCalendarResource,
    "calendar_feed": AsyncCalendarFeedResource,
    "collection": AsyncCollectionResource,
    "command": AsyncCommandResource,
    "credit": AsyncCreditResource,
    "custom_filter": AsyncCustomFilterResource,
    "custom_format": AsyncCustomFormatResource,
    "cutoff": AsyncCutoffResource,
    "delay_profile": AsyncDelayProfileResource,
    "disk_space": AsyncDiskSpaceResource,
    "download_client": AsyncDownloadClientResource,
    "download_client_config": AsyncDownloadClientConfigResource,
    "extra_file": AsyncExtraFileResource,
    "file_system": AsyncFileSystemResource,
    "health": AsyncHealthResource,
    "history": AsyncHistoryResource,
    "host_config": AsyncHostConfigResource,
    "import_list": AsyncImportListResource,
    "import_list_config": AsyncImportListConfigResource,
    "import_list_exclusion": AsyncImportListExclusionResource,
    "import_list_movies": AsyncImportListMoviesResource,
    "indexer": AsyncIndexerResource,
    "indexer_config": AsyncIndexerConfigResource,
    "indexer_flag": AsyncIndexerFlagResource,
    "language": AsyncLanguageResource,
    "localization": AsyncLocalizationResource,
    "log": AsyncLogResource,
    "log_file": AsyncLogFileResource,
    "manual_import": AsyncManualImportResource,
    "media_cover": AsyncMediaCoverResource,
    "media_management_config": AsyncMediaManagementConfigResource,
    "metadata": AsyncMetadataResource,
    "metadata_config": AsyncMetadataConfigResource,
    "missing": AsyncMissingResource,
    "movie": AsyncMovieResource,
    "movie_editor": AsyncMovieEditorResource,
    "movie_file": AsyncMovieFileResource,
    "movie_folder": AsyncMovieFolderResource,
    "movie_import": AsyncMovieImportResource,
    "movie_lookup": AsyncMovieLookupResource,
    "naming_config": AsyncNamingConfigResource,
    "notification": AsyncNotificationResource,
    "parse": AsyncParseResource,
    "ping": AsyncPingResource,
    "quality_definition": AsyncQualityDefinitionResource,
    "quality_profile": AsyncQualityProfileResource,
    "quality_profile_schema": AsyncQualityProfileSchemaResource,
    "queue": AsyncQueueResource,
    "queue_action": AsyncQueueActionResource,
    "queue_details": AsyncQueueDetailsResource,
    "queue_status": AsyncQueueStatusResource,
    "release": AsyncReleaseResource,
    "release_profile": AsyncReleaseProfileResource,
    "release_push": AsyncReleasePushResource,
    "remote_path_mapping": AsyncRemotePathMappingResource,
    "rename_movie": AsyncRenameMovieResource,
    "root_folder": AsyncRootFolderResource,
    "static_resource": AsyncStaticResourceResource,
    "system": AsyncSystemResource,
    "tag": AsyncTagResource,
    "tag_details": AsyncTagDetailsResource,
    "task": AsyncTaskResource,
    "ui_config": AsyncUiConfigResource,
    "update": AsyncUpdateResource,
    "update_log_file": AsyncUpdateLogFileResource,
}
