"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: NamingConfig."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class NamingConfigResource:
    """Sync wrapper for the ``NamingConfig`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> models.NamingConfigResource:
        return cast(
            "models.NamingConfigResource",
            _ops.list_config_naming(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.NamingConfigResource | None = None,
    ) -> models.NamingConfigResource:
        return cast(
            "models.NamingConfigResource",
            _ops.update_config_naming_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.NamingConfigResource:
        return cast(
            "models.NamingConfigResource",
            _ops.get_config_naming_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_examples(
        self,
        *,
        rename_movies: bool | None = None,
        replace_illegal_characters: bool | None = None,
        colon_replacement_format: models.ColonReplacementFormat | None = None,
        standard_movie_format: str | None = None,
        movie_folder_format: str | None = None,
        id: int | None = None,
        resource_name: str | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.list_config_naming_examples(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                rename_movies=rename_movies,
                replace_illegal_characters=replace_illegal_characters,
                colon_replacement_format=colon_replacement_format,
                standard_movie_format=standard_movie_format,
                movie_folder_format=movie_folder_format,
                id=id,
                resource_name=resource_name,
            ),
        )


class AsyncNamingConfigResource:
    """Async wrapper for the ``NamingConfig`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> models.NamingConfigResource:
        return cast(
            "models.NamingConfigResource",
            await _ops.list_config_naming_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.NamingConfigResource | None = None,
    ) -> models.NamingConfigResource:
        return cast(
            "models.NamingConfigResource",
            await _ops.update_config_naming_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.NamingConfigResource:
        return cast(
            "models.NamingConfigResource",
            await _ops.get_config_naming_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_examples(
        self,
        *,
        rename_movies: bool | None = None,
        replace_illegal_characters: bool | None = None,
        colon_replacement_format: models.ColonReplacementFormat | None = None,
        standard_movie_format: str | None = None,
        movie_folder_format: str | None = None,
        id: int | None = None,
        resource_name: str | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.list_config_naming_examples_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                rename_movies=rename_movies,
                replace_illegal_characters=replace_illegal_characters,
                colon_replacement_format=colon_replacement_format,
                standard_movie_format=standard_movie_format,
                movie_folder_format=movie_folder_format,
                id=id,
                resource_name=resource_name,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
