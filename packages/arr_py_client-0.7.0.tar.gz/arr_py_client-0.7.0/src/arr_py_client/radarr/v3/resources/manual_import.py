"""Manual-import workflow for Radarr v3.

The manual-import flow is what Radarr uses when an automatic import fails or
when a user points at a folder/download-id by hand. Two steps:

1. ``candidates(...)`` — ask the server to scan a folder or download-id and
   produce a list of import candidates (with proposed movie, quality, score,
   and rejection reasons if any).
2. ``execute(items, import_mode=...)`` — confirm those (possibly edited)
   candidates and ask the server to import them.

The auto-generated ``create()`` method posts an empty body and is not useful;
use :meth:`execute` instead.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal, cast

from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops
from arr_py_client.radarr.v3.resources._auto.manual_import import (
    AsyncManualImportResource as _AutoAsync,
)
from arr_py_client.radarr.v3.resources._auto.manual_import import (
    ManualImportResource as _AutoSync,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from arr_py_client._common.transport import AsyncTransport, SyncTransport


ImportMode = Literal["auto", "copy", "move", "hardlink"]


def _dump(item: _models.ManualImportResource | dict[str, Any]) -> dict[str, Any]:
    if isinstance(item, dict):
        return item
    return item.model_dump(by_alias=True, exclude_none=True)


class ManualImportResource(_AutoSync):
    """Sync Radarr manual-import resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def candidates(
        self,
        *,
        folder: str | None = None,
        download_id: str | None = None,
        movie_id: int | None = None,
        filter_existing_files: bool | None = True,
    ) -> list[_models.ManualImportResource]:
        """List importable items at a folder or download-id.

        Exactly one of ``folder`` or ``download_id`` is usually set.
        ``filter_existing_files=True`` hides items already in the library.
        """
        return cast(
            "list[_models.ManualImportResource]",
            _ops.list_manualimport(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                folder=folder,
                download_id=download_id,
                movie_id=movie_id,
                filter_existing_files=filter_existing_files,
            ),
        )

    def execute(
        self,
        *,
        items: Sequence[_models.ManualImportResource | dict[str, Any]],
        import_mode: ImportMode = "auto",
    ) -> list[_models.CommandResource]:
        """Confirm and import a list of candidates produced by :meth:`candidates`.

        Each item must have at least ``path``, ``movie.id`` (or ``movieId``),
        ``quality``, and ``languages``. ``import_mode`` controls the on-disk
        action: ``"auto"`` follows the server's configured default.
        """
        # Spec doesn't document the POST body, so we build it ourselves. The
        # server expects a top-level array, plus the import mode on each item.
        payload: list[dict[str, Any]] = []
        for item in items:
            body = _dump(item)
            body.setdefault("importMode", import_mode)
            payload.append(body)
        response = self._transport.request("POST", "/manualimport", json=payload)
        data = response.json()
        if isinstance(data, list):
            return [_models.CommandResource.model_validate(d) for d in data]  # pyright: ignore[reportUnknownVariableType]
        return []


class AsyncManualImportResource(_AutoAsync):
    """Async Radarr manual-import resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def candidates(
        self,
        *,
        folder: str | None = None,
        download_id: str | None = None,
        movie_id: int | None = None,
        filter_existing_files: bool | None = True,
    ) -> list[_models.ManualImportResource]:
        return cast(
            "list[_models.ManualImportResource]",
            await _ops.list_manualimport_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                folder=folder,
                download_id=download_id,
                movie_id=movie_id,
                filter_existing_files=filter_existing_files,
            ),
        )

    async def execute(
        self,
        *,
        items: Sequence[_models.ManualImportResource | dict[str, Any]],
        import_mode: ImportMode = "auto",
    ) -> list[_models.CommandResource]:
        payload: list[dict[str, Any]] = []
        for item in items:
            body = _dump(item)
            body.setdefault("importMode", import_mode)
            payload.append(body)
        response = await self._transport.request("POST", "/manualimport", json=payload)
        data = response.json()
        if isinstance(data, list):
            return [_models.CommandResource.model_validate(d) for d in data]  # pyright: ignore[reportUnknownVariableType]
        return []
