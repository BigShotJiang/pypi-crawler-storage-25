"""History resource for Radarr v3 (with pagination)."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client._common.pagination import aiter_pages, iter_pages
from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops
from arr_py_client.radarr.v3.resources._auto.history import (
    AsyncHistoryResource as _AutoAsyncHistoryResource,
)
from arr_py_client.radarr.v3.resources._auto.history import (
    HistoryResource as _AutoHistoryResource,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Iterator
    from typing import Any

    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _as_page_dict(paging: object) -> dict[str, Any]:
    records = cast("list[Any]", getattr(paging, "records", []) or [])
    return {"records": records}


class HistoryResource(_AutoHistoryResource):
    """Sync Radarr history resource (curated facade with pagination)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        sort_key: str | None = None,
        include_movie: bool | None = None,
    ) -> _models.HistoryResourcePagingResource:
        return _ops.list_history(  # pyright: ignore[reportUnknownMemberType]
            self._transport,
            page=page,
            page_size=page_size,
            sort_key=sort_key,
            include_movie=include_movie,
        )

    def iter_all(
        self,
        *,
        page_size: int = 50,
        include_movie: bool | None = None,
    ) -> Iterator[_models.HistoryResource]:
        def fetch(page: int, size: int) -> dict[str, Any]:
            paging = _ops.list_history(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=size,
                include_movie=include_movie,
            )
            return _as_page_dict(paging)

        yield from iter_pages(fetch, page_size=page_size)

    def for_movie(
        self, *, movie_id: int, include_movie: bool | None = None
    ) -> list[_models.HistoryResource]:
        """Full history for a single movie (not paged)."""
        return cast(
            "list[_models.HistoryResource]",
            _ops.list_history_movie(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
                include_movie=include_movie,
            ),
        )


class AsyncHistoryResource(_AutoAsyncHistoryResource):
    """Async Radarr history resource (curated facade with pagination)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        sort_key: str | None = None,
        include_movie: bool | None = None,
    ) -> _models.HistoryResourcePagingResource:
        return await _ops.list_history_async(  # pyright: ignore[reportUnknownMemberType]
            self._transport,
            page=page,
            page_size=page_size,
            sort_key=sort_key,
            include_movie=include_movie,
        )

    async def aiter_all(
        self,
        *,
        page_size: int = 50,
        include_movie: bool | None = None,
    ) -> AsyncIterator[_models.HistoryResource]:
        async def fetch(page: int, size: int) -> dict[str, Any]:
            paging = await _ops.list_history_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=size,
                include_movie=include_movie,
            )
            return _as_page_dict(paging)

        async for rec in aiter_pages(fetch, page_size=page_size):
            yield rec

    async def for_movie(
        self, *, movie_id: int, include_movie: bool | None = None
    ) -> list[_models.HistoryResource]:
        return cast(
            "list[_models.HistoryResource]",
            await _ops.list_history_movie_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
                include_movie=include_movie,
            ),
        )
