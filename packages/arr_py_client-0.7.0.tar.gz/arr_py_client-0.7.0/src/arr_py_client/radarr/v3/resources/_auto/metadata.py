"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Metadata."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class MetadataResource:
    """Sync wrapper for the ``Metadata`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.MetadataResource]:
        return cast(
            "list[models.MetadataResource]",
            _ops.list_metadata(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create(
        self,
        *,
        force_save: bool | None = None,
        body: models.MetadataResource | None = None,
    ) -> models.MetadataResource:
        return cast(
            "models.MetadataResource",
            _ops.create_metadata(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_save=force_save,
                body=body,
            ),
        )

    def update_by_id(
        self,
        id: int,
        *,
        force_save: bool | None = None,
        body: models.MetadataResource | None = None,
    ) -> models.MetadataResource:
        return cast(
            "models.MetadataResource",
            _ops.update_metadata_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                force_save=force_save,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_metadata_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.MetadataResource:
        return cast(
            "models.MetadataResource",
            _ops.get_metadata_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_schema(
        self,
    ) -> list[models.MetadataResource]:
        return cast(
            "list[models.MetadataResource]",
            _ops.list_metadata_schema(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create_test(
        self,
        *,
        force_test: bool | None = None,
        body: models.MetadataResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.create_metadata_test(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_test=force_test,
                body=body,
            ),
        )

    def create_testall(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_metadata_testall(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def post_action_by_name(
        self,
        name: str,
        *,
        body: models.MetadataResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.post_metadata_action_by_name(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                name,
                body=body,
            ),
        )


class AsyncMetadataResource:
    """Async wrapper for the ``Metadata`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.MetadataResource]:
        return cast(
            "list[models.MetadataResource]",
            await _ops.list_metadata_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create(
        self,
        *,
        force_save: bool | None = None,
        body: models.MetadataResource | None = None,
    ) -> models.MetadataResource:
        return cast(
            "models.MetadataResource",
            await _ops.create_metadata_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_save=force_save,
                body=body,
            ),
        )

    async def update_by_id(
        self,
        id: int,
        *,
        force_save: bool | None = None,
        body: models.MetadataResource | None = None,
    ) -> models.MetadataResource:
        return cast(
            "models.MetadataResource",
            await _ops.update_metadata_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                force_save=force_save,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_metadata_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.MetadataResource:
        return cast(
            "models.MetadataResource",
            await _ops.get_metadata_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_schema(
        self,
    ) -> list[models.MetadataResource]:
        return cast(
            "list[models.MetadataResource]",
            await _ops.list_metadata_schema_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create_test(
        self,
        *,
        force_test: bool | None = None,
        body: models.MetadataResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.create_metadata_test_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_test=force_test,
                body=body,
            ),
        )

    async def create_testall(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_metadata_testall_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def post_action_by_name(
        self,
        name: str,
        *,
        body: models.MetadataResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.post_metadata_action_by_name_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                name,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
