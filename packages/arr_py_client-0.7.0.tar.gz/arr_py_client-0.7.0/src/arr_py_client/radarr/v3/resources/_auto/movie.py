"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Movie."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class MovieResource:
    """Sync wrapper for the ``Movie`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        tmdb_id: int | None = None,
        exclude_local_covers: bool | None = None,
        language_id: int | None = None,
    ) -> list[models.MovieResource]:
        return cast(
            "list[models.MovieResource]",
            _ops.list_movie(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                tmdb_id=tmdb_id,
                exclude_local_covers=exclude_local_covers,
                language_id=language_id,
            ),
        )

    def create(
        self,
        *,
        body: models.MovieResource | None = None,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            _ops.create_movie(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        move_files: bool | None = None,
        body: models.MovieResource | None = None,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            _ops.update_movie_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                move_files=move_files,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
        *,
        delete_files: bool | None = None,
        add_import_exclusion: bool | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_movie_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                delete_files=delete_files,
                add_import_exclusion=add_import_exclusion,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            _ops.get_movie_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncMovieResource:
    """Async wrapper for the ``Movie`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        tmdb_id: int | None = None,
        exclude_local_covers: bool | None = None,
        language_id: int | None = None,
    ) -> list[models.MovieResource]:
        return cast(
            "list[models.MovieResource]",
            await _ops.list_movie_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                tmdb_id=tmdb_id,
                exclude_local_covers=exclude_local_covers,
                language_id=language_id,
            ),
        )

    async def create(
        self,
        *,
        body: models.MovieResource | None = None,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            await _ops.create_movie_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        move_files: bool | None = None,
        body: models.MovieResource | None = None,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            await _ops.update_movie_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                move_files=move_files,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
        *,
        delete_files: bool | None = None,
        add_import_exclusion: bool | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_movie_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                delete_files=delete_files,
                add_import_exclusion=add_import_exclusion,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            await _ops.get_movie_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
