"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: MovieLookup."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class MovieLookupResource:
    """Sync wrapper for the ``MovieLookup`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_tmdb(
        self,
        *,
        tmdb_id: int | None = None,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            _ops.list_movie_lookup_tmdb(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                tmdb_id=tmdb_id,
            ),
        )

    def list_imdb(
        self,
        *,
        imdb_id: str | None = None,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            _ops.list_movie_lookup_imdb(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                imdb_id=imdb_id,
            ),
        )

    def list_(
        self,
        *,
        term: str | None = None,
    ) -> list[models.MovieResource]:
        return cast(
            "list[models.MovieResource]",
            _ops.list_movie_lookup(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                term=term,
            ),
        )


class AsyncMovieLookupResource:
    """Async wrapper for the ``MovieLookup`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_tmdb(
        self,
        *,
        tmdb_id: int | None = None,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            await _ops.list_movie_lookup_tmdb_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                tmdb_id=tmdb_id,
            ),
        )

    async def list_imdb(
        self,
        *,
        imdb_id: str | None = None,
    ) -> models.MovieResource:
        return cast(
            "models.MovieResource",
            await _ops.list_movie_lookup_imdb_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                imdb_id=imdb_id,
            ),
        )

    async def list_(
        self,
        *,
        term: str | None = None,
    ) -> list[models.MovieResource]:
        return cast(
            "list[models.MovieResource]",
            await _ops.list_movie_lookup_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                term=term,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
