"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: FileSystem."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class FileSystemResource:
    """Sync wrapper for the ``FileSystem`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        path: str | None = None,
        include_files: bool | None = None,
        allow_folders_without_trailing_slashes: bool | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.list_filesystem(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path=path,
                include_files=include_files,
                allow_folders_without_trailing_slashes=allow_folders_without_trailing_slashes,
            ),
        )

    def list_type(
        self,
        *,
        path: str | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.list_filesystem_type(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path=path,
            ),
        )

    def list_mediafiles(
        self,
        *,
        path: str | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.list_filesystem_mediafiles(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path=path,
            ),
        )


class AsyncFileSystemResource:
    """Async wrapper for the ``FileSystem`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        path: str | None = None,
        include_files: bool | None = None,
        allow_folders_without_trailing_slashes: bool | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.list_filesystem_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path=path,
                include_files=include_files,
                allow_folders_without_trailing_slashes=allow_folders_without_trailing_slashes,
            ),
        )

    async def list_type(
        self,
        *,
        path: str | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.list_filesystem_type_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path=path,
            ),
        )

    async def list_mediafiles(
        self,
        *,
        path: str | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.list_filesystem_mediafiles_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path=path,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
