"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: CustomFormat."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class CustomFormatResource:
    """Sync wrapper for the ``CustomFormat`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.CustomFormatResource]:
        return cast(
            "list[models.CustomFormatResource]",
            _ops.list_customformat(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create(
        self,
        *,
        body: models.CustomFormatResource | None = None,
    ) -> models.CustomFormatResource:
        return cast(
            "models.CustomFormatResource",
            _ops.create_customformat(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.CustomFormatResource | None = None,
    ) -> models.CustomFormatResource:
        return cast(
            "models.CustomFormatResource",
            _ops.update_customformat_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_customformat_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.CustomFormatResource:
        return cast(
            "models.CustomFormatResource",
            _ops.get_customformat_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_bulk(
        self,
        *,
        body: models.CustomFormatBulkResource | None = None,
    ) -> models.CustomFormatResource:
        return cast(
            "models.CustomFormatResource",
            _ops.update_customformat_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def delete_bulk(
        self,
        *,
        body: models.CustomFormatBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_customformat_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_schema(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list_customformat_schema(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncCustomFormatResource:
    """Async wrapper for the ``CustomFormat`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.CustomFormatResource]:
        return cast(
            "list[models.CustomFormatResource]",
            await _ops.list_customformat_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create(
        self,
        *,
        body: models.CustomFormatResource | None = None,
    ) -> models.CustomFormatResource:
        return cast(
            "models.CustomFormatResource",
            await _ops.create_customformat_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.CustomFormatResource | None = None,
    ) -> models.CustomFormatResource:
        return cast(
            "models.CustomFormatResource",
            await _ops.update_customformat_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_customformat_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.CustomFormatResource:
        return cast(
            "models.CustomFormatResource",
            await _ops.get_customformat_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_bulk(
        self,
        *,
        body: models.CustomFormatBulkResource | None = None,
    ) -> models.CustomFormatResource:
        return cast(
            "models.CustomFormatResource",
            await _ops.update_customformat_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def delete_bulk(
        self,
        *,
        body: models.CustomFormatBulkResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_customformat_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_schema(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_customformat_schema_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
