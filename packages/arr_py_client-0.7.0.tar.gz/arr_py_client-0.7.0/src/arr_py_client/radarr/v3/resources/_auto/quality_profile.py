"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: QualityProfile."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class QualityProfileResource:
    """Sync wrapper for the ``QualityProfile`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.QualityProfileResource | None = None,
    ) -> models.QualityProfileResource:
        return cast(
            "models.QualityProfileResource",
            _ops.create_qualityprofile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
    ) -> list[models.QualityProfileResource]:
        return cast(
            "list[models.QualityProfileResource]",
            _ops.list_qualityprofile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_qualityprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.QualityProfileResource | None = None,
    ) -> models.QualityProfileResource:
        return cast(
            "models.QualityProfileResource",
            _ops.update_qualityprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.QualityProfileResource:
        return cast(
            "models.QualityProfileResource",
            _ops.get_qualityprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncQualityProfileResource:
    """Async wrapper for the ``QualityProfile`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.QualityProfileResource | None = None,
    ) -> models.QualityProfileResource:
        return cast(
            "models.QualityProfileResource",
            await _ops.create_qualityprofile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
    ) -> list[models.QualityProfileResource]:
        return cast(
            "list[models.QualityProfileResource]",
            await _ops.list_qualityprofile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_qualityprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.QualityProfileResource | None = None,
    ) -> models.QualityProfileResource:
        return cast(
            "models.QualityProfileResource",
            await _ops.update_qualityprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.QualityProfileResource:
        return cast(
            "models.QualityProfileResource",
            await _ops.get_qualityprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
