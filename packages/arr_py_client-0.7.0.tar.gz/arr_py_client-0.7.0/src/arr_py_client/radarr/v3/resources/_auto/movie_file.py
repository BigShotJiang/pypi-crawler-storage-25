"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: MovieFile."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class MovieFileResource:
    """Sync wrapper for the ``MovieFile`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        movie_id: list[int] | None = None,
        movie_file_ids: list[int] | None = None,
    ) -> list[models.MovieFileResource]:
        return cast(
            "list[models.MovieFileResource]",
            _ops.list_moviefile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
                movie_file_ids=movie_file_ids,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.MovieFileResource | None = None,
    ) -> models.MovieFileResource:
        return cast(
            "models.MovieFileResource",
            _ops.update_moviefile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_moviefile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.MovieFileResource:
        return cast(
            "models.MovieFileResource",
            _ops.get_moviefile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_editor(
        self,
        *,
        body: models.MovieFileListResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.update_moviefile_editor(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def delete_bulk(
        self,
        *,
        body: models.MovieFileListResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.delete_moviefile_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def update_bulk(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.update_moviefile_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncMovieFileResource:
    """Async wrapper for the ``MovieFile`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        movie_id: list[int] | None = None,
        movie_file_ids: list[int] | None = None,
    ) -> list[models.MovieFileResource]:
        return cast(
            "list[models.MovieFileResource]",
            await _ops.list_moviefile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                movie_id=movie_id,
                movie_file_ids=movie_file_ids,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.MovieFileResource | None = None,
    ) -> models.MovieFileResource:
        return cast(
            "models.MovieFileResource",
            await _ops.update_moviefile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_moviefile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.MovieFileResource:
        return cast(
            "models.MovieFileResource",
            await _ops.get_moviefile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_editor(
        self,
        *,
        body: models.MovieFileListResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.update_moviefile_editor_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def delete_bulk(
        self,
        *,
        body: models.MovieFileListResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_moviefile_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def update_bulk(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.update_moviefile_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
