"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Parse."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ParseResource:
    """Sync wrapper for the ``Parse`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        title: str | None = None,
    ) -> models.ParseResource:
        return cast(
            "models.ParseResource",
            _ops.list_parse(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                title=title,
            ),
        )


class AsyncParseResource:
    """Async wrapper for the ``Parse`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        title: str | None = None,
    ) -> models.ParseResource:
        return cast(
            "models.ParseResource",
            await _ops.list_parse_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                title=title,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
