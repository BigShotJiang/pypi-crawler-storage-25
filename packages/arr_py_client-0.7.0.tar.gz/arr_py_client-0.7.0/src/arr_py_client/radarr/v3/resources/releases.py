"""Manual release search + grab for Radarr v3.

``GET /release?movieId=X`` returns candidate releases from the configured
indexers. ``POST /release`` grabs a specific one (by guid + indexerId).

Use :meth:`ReleasesResource.best` to delegate candidate scoring to the client;
``.search()`` returns raw candidates for callers that want to filter/display.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from arr_py_client._common.release_explain import (
    ReleaseExplanation,
    build_explanation,
)
from arr_py_client.radarr.v3._generated import models as _models
from arr_py_client.radarr.v3._generated import operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


def _score(
    release: _models.ReleaseResource, prefer_codec: str | None
) -> tuple[int, int, int, int]:
    """Default release score: (seeders desc, quality weight desc, codec match, size asc).

    Returns a tuple suitable for ``sorted(..., key=..., reverse=False)`` — we
    negate fields we want descending.
    """
    seeders = getattr(release, "seeders", None) or 0
    quality_obj = getattr(release, "quality", None)
    quality_weight = 0
    if quality_obj is not None:
        q = getattr(quality_obj, "quality", None)
        if q is not None:
            quality_weight = int(getattr(q, "resolution", 0) or 0)
    codec_match = 0
    if prefer_codec:
        title = str(getattr(release, "title", "") or "").lower()
        if prefer_codec.lower() in title:
            codec_match = 1
    size = int(getattr(release, "size", None) or 0)
    return (-seeders, -quality_weight, -codec_match, size)


class ReleasesResource:
    """Sync Radarr manual release search resource."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def search(self, *, movie_id: int) -> list[_models.ReleaseResource]:
        """Query indexers for releases matching ``movie_id``."""
        return cast(
            "list[_models.ReleaseResource]",
            _ops.list_release(self._transport, movie_id=movie_id),  # pyright: ignore[reportUnknownMemberType]
        )

    def best(
        self,
        *,
        movie_id: int,
        min_seeders: int | None = None,
        prefer_codec: str | None = None,
    ) -> _models.ReleaseResource | None:
        """Search + return the top-scoring release, or ``None`` if no candidates."""
        candidates = self.search(movie_id=movie_id)
        if min_seeders is not None:
            candidates = [
                c
                for c in candidates
                if (getattr(c, "seeders", None) or 0) >= min_seeders
            ]
        if not candidates:
            return None
        candidates.sort(key=lambda r: _score(r, prefer_codec))
        return candidates[0]

    def grab(self, *, guid: str, indexer_id: int) -> None:
        """Grab a specific release by ``(guid, indexer_id)``.

        Returns nothing — the underlying endpoint is fire-and-forget. The
        release is now in the queue; poll ``client.queue`` to track progress.
        """
        body = _models.ReleaseResource.model_validate(
            {"guid": guid, "indexerId": indexer_id}
        )
        _ops.create_release(self._transport, body=body)

    def explain(self, *, movie_id: int) -> ReleaseExplanation:
        """Search indexers + annotate each release with accept/reject + reasons.

        Returns a :class:`ReleaseExplanation` answering the question "why
        didn't it grab the better version?" — every candidate is ranked with
        its custom-format score, quality weight, and the server's rejection
        reasons (cutoff met, CF score too low, already imported, etc.).
        """
        current_quality: str | None = None
        current_cf_score: int | None = None
        movie_title: str | None = None
        try:
            movie = _ops.get_movie_by_id(self._transport, movie_id)
            movie_title = getattr(movie, "title", None)
            movie_file = getattr(movie, "movie_file", None)
            if movie_file is not None:
                quality_obj = getattr(movie_file, "quality", None)
                if quality_obj is not None:
                    q = getattr(quality_obj, "quality", None)
                    if q is not None:
                        current_quality = getattr(q, "name", None)
                current_cf_score = getattr(movie_file, "custom_format_score", None)
        except Exception:  # noqa: S110 - movie lookup is best-effort
            pass
        raw = cast(
            "list[object]",
            _ops.list_release(self._transport, movie_id=movie_id),  # pyright: ignore[reportUnknownMemberType]
        )
        return build_explanation(
            item_id=movie_id,
            item_title=movie_title,
            current_quality=current_quality,
            current_custom_format_score=current_cf_score,
            raw_releases=raw,
        )


class AsyncReleasesResource:
    """Async Radarr manual release search resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def search(self, *, movie_id: int) -> list[_models.ReleaseResource]:
        return cast(
            "list[_models.ReleaseResource]",
            await _ops.list_release_async(self._transport, movie_id=movie_id),  # pyright: ignore[reportUnknownMemberType]
        )

    async def best(
        self,
        *,
        movie_id: int,
        min_seeders: int | None = None,
        prefer_codec: str | None = None,
    ) -> _models.ReleaseResource | None:
        candidates = await self.search(movie_id=movie_id)
        if min_seeders is not None:
            candidates = [
                c
                for c in candidates
                if (getattr(c, "seeders", None) or 0) >= min_seeders
            ]
        if not candidates:
            return None
        candidates.sort(key=lambda r: _score(r, prefer_codec))
        return candidates[0]

    async def grab(self, *, guid: str, indexer_id: int) -> None:
        body = _models.ReleaseResource.model_validate(
            {"guid": guid, "indexerId": indexer_id}
        )
        await _ops.create_release_async(self._transport, body=body)

    async def explain(self, *, movie_id: int) -> ReleaseExplanation:
        """Async twin of :meth:`ReleasesResource.explain`."""
        current_quality: str | None = None
        current_cf_score: int | None = None
        movie_title: str | None = None
        try:
            movie = await _ops.get_movie_by_id_async(self._transport, movie_id)
            movie_title = getattr(movie, "title", None)
            movie_file = getattr(movie, "movie_file", None)
            if movie_file is not None:
                quality_obj = getattr(movie_file, "quality", None)
                if quality_obj is not None:
                    q = getattr(quality_obj, "quality", None)
                    if q is not None:
                        current_quality = getattr(q, "name", None)
                current_cf_score = getattr(movie_file, "custom_format_score", None)
        except Exception:  # noqa: S110 - movie lookup is best-effort
            pass
        raw = cast(
            "list[object]",
            await _ops.list_release_async(self._transport, movie_id=movie_id),  # pyright: ignore[reportUnknownMemberType]
        )
        return build_explanation(
            item_id=movie_id,
            item_title=movie_title,
            current_quality=current_quality,
            current_custom_format_score=current_cf_score,
            raw_releases=raw,
        )
