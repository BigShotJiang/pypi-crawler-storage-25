"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Collection."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class CollectionResource:
    """Sync wrapper for the ``Collection`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        tmdb_id: int | None = None,
    ) -> list[models.CollectionResource]:
        return cast(
            "list[models.CollectionResource]",
            _ops.list_collection(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                tmdb_id=tmdb_id,
            ),
        )

    def update(
        self,
        *,
        body: models.CollectionUpdateResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.update_collection(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.CollectionResource | None = None,
    ) -> models.CollectionResource:
        return cast(
            "models.CollectionResource",
            _ops.update_collection_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.CollectionResource:
        return cast(
            "models.CollectionResource",
            _ops.get_collection_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncCollectionResource:
    """Async wrapper for the ``Collection`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        tmdb_id: int | None = None,
    ) -> list[models.CollectionResource]:
        return cast(
            "list[models.CollectionResource]",
            await _ops.list_collection_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                tmdb_id=tmdb_id,
            ),
        )

    async def update(
        self,
        *,
        body: models.CollectionUpdateResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.update_collection_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.CollectionResource | None = None,
    ) -> models.CollectionResource:
        return cast(
            "models.CollectionResource",
            await _ops.update_collection_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.CollectionResource:
        return cast(
            "models.CollectionResource",
            await _ops.get_collection_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
