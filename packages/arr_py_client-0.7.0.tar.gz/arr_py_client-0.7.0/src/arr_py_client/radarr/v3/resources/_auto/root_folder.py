"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: RootFolder."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class RootFolderResource:
    """Sync wrapper for the ``RootFolder`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.RootFolderResource | None = None,
    ) -> models.RootFolderResource:
        return cast(
            "models.RootFolderResource",
            _ops.create_rootfolder(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
    ) -> list[models.RootFolderResource]:
        return cast(
            "list[models.RootFolderResource]",
            _ops.list_rootfolder(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_rootfolder_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.RootFolderResource:
        return cast(
            "models.RootFolderResource",
            _ops.get_rootfolder_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


class AsyncRootFolderResource:
    """Async wrapper for the ``RootFolder`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.RootFolderResource | None = None,
    ) -> models.RootFolderResource:
        return cast(
            "models.RootFolderResource",
            await _ops.create_rootfolder_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
    ) -> list[models.RootFolderResource]:
        return cast(
            "list[models.RootFolderResource]",
            await _ops.list_rootfolder_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_rootfolder_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.RootFolderResource:
        return cast(
            "models.RootFolderResource",
            await _ops.get_rootfolder_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
