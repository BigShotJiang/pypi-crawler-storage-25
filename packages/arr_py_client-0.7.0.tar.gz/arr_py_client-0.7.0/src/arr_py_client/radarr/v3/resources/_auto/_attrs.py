"""Generated typed attribute declarations for the client classes."""

from __future__ import annotations

from arr_py_client.radarr.v3.resources._auto import (
    AlternativeTitleResource,
    ApiInfoResource,
    AuthenticationResource,
    AutoTaggingResource,
    BackupResource,
    BlocklistResource,
    CalendarResource,
    CalendarFeedResource,
    CollectionResource,
    CommandResource,
    CreditResource,
    CustomFilterResource,
    CustomFormatResource,
    CutoffResource,
    DelayProfileResource,
    DiskSpaceResource,
    DownloadClientResource,
    DownloadClientConfigResource,
    ExtraFileResource,
    FileSystemResource,
    HealthResource,
    HistoryResource,
    HostConfigResource,
    ImportListResource,
    ImportListConfigResource,
    ImportListExclusionResource,
    ImportListMoviesResource,
    IndexerResource,
    IndexerConfigResource,
    IndexerFlagResource,
    LanguageResource,
    LocalizationResource,
    LogResource,
    LogFileResource,
    ManualImportResource,
    MediaCoverResource,
    MediaManagementConfigResource,
    MetadataResource,
    MetadataConfigResource,
    MissingResource,
    MovieResource,
    MovieEditorResource,
    MovieFileResource,
    MovieFolderResource,
    MovieImportResource,
    MovieLookupResource,
    NamingConfigResource,
    NotificationResource,
    ParseResource,
    PingResource,
    QualityDefinitionResource,
    QualityProfileResource,
    QualityProfileSchemaResource,
    QueueResource,
    QueueActionResource,
    QueueDetailsResource,
    QueueStatusResource,
    ReleaseResource,
    ReleaseProfileResource,
    ReleasePushResource,
    RemotePathMappingResource,
    RenameMovieResource,
    RootFolderResource,
    StaticResourceResource,
    SystemResource,
    TagResource,
    TagDetailsResource,
    TaskResource,
    UiConfigResource,
    UpdateResource,
    UpdateLogFileResource,
    AsyncAlternativeTitleResource,
    AsyncApiInfoResource,
    AsyncAuthenticationResource,
    AsyncAutoTaggingResource,
    AsyncBackupResource,
    AsyncBlocklistResource,
    AsyncCalendarResource,
    AsyncCalendarFeedResource,
    AsyncCollectionResource,
    AsyncCommandResource,
    AsyncCreditResource,
    AsyncCustomFilterResource,
    AsyncCustomFormatResource,
    AsyncCutoffResource,
    AsyncDelayProfileResource,
    AsyncDiskSpaceResource,
    AsyncDownloadClientResource,
    AsyncDownloadClientConfigResource,
    AsyncExtraFileResource,
    AsyncFileSystemResource,
    AsyncHealthResource,
    AsyncHistoryResource,
    AsyncHostConfigResource,
    AsyncImportListResource,
    AsyncImportListConfigResource,
    AsyncImportListExclusionResource,
    AsyncImportListMoviesResource,
    AsyncIndexerResource,
    AsyncIndexerConfigResource,
    AsyncIndexerFlagResource,
    AsyncLanguageResource,
    AsyncLocalizationResource,
    AsyncLogResource,
    AsyncLogFileResource,
    AsyncManualImportResource,
    AsyncMediaCoverResource,
    AsyncMediaManagementConfigResource,
    AsyncMetadataResource,
    AsyncMetadataConfigResource,
    AsyncMissingResource,
    AsyncMovieResource,
    AsyncMovieEditorResource,
    AsyncMovieFileResource,
    AsyncMovieFolderResource,
    AsyncMovieImportResource,
    AsyncMovieLookupResource,
    AsyncNamingConfigResource,
    AsyncNotificationResource,
    AsyncParseResource,
    AsyncPingResource,
    AsyncQualityDefinitionResource,
    AsyncQualityProfileResource,
    AsyncQualityProfileSchemaResource,
    AsyncQueueResource,
    AsyncQueueActionResource,
    AsyncQueueDetailsResource,
    AsyncQueueStatusResource,
    AsyncReleaseResource,
    AsyncReleaseProfileResource,
    AsyncReleasePushResource,
    AsyncRemotePathMappingResource,
    AsyncRenameMovieResource,
    AsyncRootFolderResource,
    AsyncStaticResourceResource,
    AsyncSystemResource,
    AsyncTagResource,
    AsyncTagDetailsResource,
    AsyncTaskResource,
    AsyncUiConfigResource,
    AsyncUpdateResource,
    AsyncUpdateLogFileResource,
)


class RadarrV3SyncResourceAttrs:
    alternative_title: AlternativeTitleResource
    api_info: ApiInfoResource
    authentication: AuthenticationResource
    auto_tagging: AutoTaggingResource
    backup: BackupResource
    blocklist: BlocklistResource
    calendar: CalendarResource
    calendar_feed: CalendarFeedResource
    collection: CollectionResource
    command: CommandResource
    credit: CreditResource
    custom_filter: CustomFilterResource
    custom_format: CustomFormatResource
    cutoff: CutoffResource
    delay_profile: DelayProfileResource
    disk_space: DiskSpaceResource
    download_client: DownloadClientResource
    download_client_config: DownloadClientConfigResource
    extra_file: ExtraFileResource
    file_system: FileSystemResource
    health: HealthResource
    history: HistoryResource
    host_config: HostConfigResource
    import_list: ImportListResource
    import_list_config: ImportListConfigResource
    import_list_exclusion: ImportListExclusionResource
    import_list_movies: ImportListMoviesResource
    indexer: IndexerResource
    indexer_config: IndexerConfigResource
    indexer_flag: IndexerFlagResource
    language: LanguageResource
    localization: LocalizationResource
    log: LogResource
    log_file: LogFileResource
    manual_import: ManualImportResource
    media_cover: MediaCoverResource
    media_management_config: MediaManagementConfigResource
    metadata: MetadataResource
    metadata_config: MetadataConfigResource
    missing: MissingResource
    movie: MovieResource
    movie_editor: MovieEditorResource
    movie_file: MovieFileResource
    movie_folder: MovieFolderResource
    movie_import: MovieImportResource
    movie_lookup: MovieLookupResource
    naming_config: NamingConfigResource
    notification: NotificationResource
    parse: ParseResource
    ping: PingResource
    quality_definition: QualityDefinitionResource
    quality_profile: QualityProfileResource
    quality_profile_schema: QualityProfileSchemaResource
    queue: QueueResource
    queue_action: QueueActionResource
    queue_details: QueueDetailsResource
    queue_status: QueueStatusResource
    release: ReleaseResource
    release_profile: ReleaseProfileResource
    release_push: ReleasePushResource
    remote_path_mapping: RemotePathMappingResource
    rename_movie: RenameMovieResource
    root_folder: RootFolderResource
    static_resource: StaticResourceResource
    system: SystemResource
    tag: TagResource
    tag_details: TagDetailsResource
    task: TaskResource
    ui_config: UiConfigResource
    update: UpdateResource
    update_log_file: UpdateLogFileResource


class RadarrV3AsyncResourceAttrs:
    alternative_title: AsyncAlternativeTitleResource
    api_info: AsyncApiInfoResource
    authentication: AsyncAuthenticationResource
    auto_tagging: AsyncAutoTaggingResource
    backup: AsyncBackupResource
    blocklist: AsyncBlocklistResource
    calendar: AsyncCalendarResource
    calendar_feed: AsyncCalendarFeedResource
    collection: AsyncCollectionResource
    command: AsyncCommandResource
    credit: AsyncCreditResource
    custom_filter: AsyncCustomFilterResource
    custom_format: AsyncCustomFormatResource
    cutoff: AsyncCutoffResource
    delay_profile: AsyncDelayProfileResource
    disk_space: AsyncDiskSpaceResource
    download_client: AsyncDownloadClientResource
    download_client_config: AsyncDownloadClientConfigResource
    extra_file: AsyncExtraFileResource
    file_system: AsyncFileSystemResource
    health: AsyncHealthResource
    history: AsyncHistoryResource
    host_config: AsyncHostConfigResource
    import_list: AsyncImportListResource
    import_list_config: AsyncImportListConfigResource
    import_list_exclusion: AsyncImportListExclusionResource
    import_list_movies: AsyncImportListMoviesResource
    indexer: AsyncIndexerResource
    indexer_config: AsyncIndexerConfigResource
    indexer_flag: AsyncIndexerFlagResource
    language: AsyncLanguageResource
    localization: AsyncLocalizationResource
    log: AsyncLogResource
    log_file: AsyncLogFileResource
    manual_import: AsyncManualImportResource
    media_cover: AsyncMediaCoverResource
    media_management_config: AsyncMediaManagementConfigResource
    metadata: AsyncMetadataResource
    metadata_config: AsyncMetadataConfigResource
    missing: AsyncMissingResource
    movie: AsyncMovieResource
    movie_editor: AsyncMovieEditorResource
    movie_file: AsyncMovieFileResource
    movie_folder: AsyncMovieFolderResource
    movie_import: AsyncMovieImportResource
    movie_lookup: AsyncMovieLookupResource
    naming_config: AsyncNamingConfigResource
    notification: AsyncNotificationResource
    parse: AsyncParseResource
    ping: AsyncPingResource
    quality_definition: AsyncQualityDefinitionResource
    quality_profile: AsyncQualityProfileResource
    quality_profile_schema: AsyncQualityProfileSchemaResource
    queue: AsyncQueueResource
    queue_action: AsyncQueueActionResource
    queue_details: AsyncQueueDetailsResource
    queue_status: AsyncQueueStatusResource
    release: AsyncReleaseResource
    release_profile: AsyncReleaseProfileResource
    release_push: AsyncReleasePushResource
    remote_path_mapping: AsyncRemotePathMappingResource
    rename_movie: AsyncRenameMovieResource
    root_folder: AsyncRootFolderResource
    static_resource: AsyncStaticResourceResource
    system: AsyncSystemResource
    tag: AsyncTagResource
    tag_details: AsyncTagDetailsResource
    task: AsyncTaskResource
    ui_config: AsyncUiConfigResource
    update: AsyncUpdateResource
    update_log_file: AsyncUpdateLogFileResource
