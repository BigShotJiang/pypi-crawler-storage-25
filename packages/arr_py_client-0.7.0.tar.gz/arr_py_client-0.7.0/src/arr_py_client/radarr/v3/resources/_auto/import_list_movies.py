"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: ImportListMovies."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ImportListMoviesResource:
    """Sync wrapper for the ``ImportListMovies`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        include_recommendations: bool | None = None,
        include_trending: bool | None = None,
        include_popular: bool | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.list_importlist_movie(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                include_recommendations=include_recommendations,
                include_trending=include_trending,
                include_popular=include_popular,
            ),
        )

    def create(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_importlist_movie(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncImportListMoviesResource:
    """Async wrapper for the ``ImportListMovies`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        include_recommendations: bool | None = None,
        include_trending: bool | None = None,
        include_popular: bool | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.list_importlist_movie_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                include_recommendations=include_recommendations,
                include_trending=include_trending,
                include_popular=include_popular,
            ),
        )

    async def create(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_importlist_movie_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
