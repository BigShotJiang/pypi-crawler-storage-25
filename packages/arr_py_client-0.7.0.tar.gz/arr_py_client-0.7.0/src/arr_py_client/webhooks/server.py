"""HTTP receiver helpers for Radarr/Sonarr webhooks.

Radarr and Sonarr push JSON to a user-configured URL. You need an HTTP
server to receive those POSTs, parse the body into a typed event, and
dispatch to your handler. This module provides two thin receiver helpers:

- :func:`wsgi_app` — zero-dep WSGI app; runs under any WSGI server
  (gunicorn, waitress, Werkzeug's built-in dev server, python -m wsgiref).
- :func:`fastapi_router` — a :class:`fastapi.APIRouter` with one POST route,
  pluggable into an existing FastAPI app. Requires ``fastapi``; install
  with ``pip install arr-py-client[webhooks]``.

Both helpers accept either a sync ``(event) -> None`` handler or an async
``async (event) -> None`` handler. Handler exceptions are caught and
surfaced as 500s so one bad payload doesn't kill the process.
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable, Iterable
from typing import Any, cast

from arr_py_client.webhooks.events import ArrEvent, parse_event

_log = logging.getLogger(__name__)

# A handler takes an event and returns either ``None`` (sync) or an awaitable
# that yields ``None`` (async). Using ``Callable`` rather than a Protocol keeps
# the type permissive — ``list.append`` and other positional-only callables
# satisfy it without juggling Protocol __call__ signatures.
Handler = Callable[[ArrEvent], None] | Callable[[ArrEvent], Awaitable[None]]


def _parse_body(body: bytes) -> ArrEvent | None:
    try:
        payload: Any = json.loads(body)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    return parse_event(cast("dict[str, Any]", payload))


def _invoke_sync(handler: Handler, event: ArrEvent) -> None:
    """Call a sync-or-async handler from a sync context.

    If the handler is async, we spin up a one-shot event loop for the call.
    Raises whatever the handler raises.
    """
    result = handler(event)
    if result is None:
        return
    if asyncio.iscoroutine(result):
        asyncio.run(result)


def wsgi_app(handler: Handler) -> Callable[..., Iterable[bytes]]:
    """Return a minimal WSGI callable that dispatches to ``handler``.

    Reply codes:
    - 204 on successful handler invocation,
    - 400 on malformed JSON,
    - 405 on non-POST,
    - 500 if the handler raised.
    """

    def app(
        environ: dict[str, Any],
        start_response: Callable[..., Any],
    ) -> Iterable[bytes]:
        method = environ.get("REQUEST_METHOD", "GET").upper()
        if method != "POST":
            start_response("405 Method Not Allowed", [("Allow", "POST")])
            return [b""]

        try:
            length = int(environ.get("CONTENT_LENGTH") or 0)
        except (TypeError, ValueError):
            length = 0
        body = environ["wsgi.input"].read(length) if length else b""
        event = _parse_body(body)
        if event is None:
            start_response("400 Bad Request", [("Content-Type", "application/json")])
            return [b'{"error":"invalid_json_body"}']

        try:
            _invoke_sync(handler, event)
        except Exception:
            _log.exception("webhook handler raised")
            start_response(
                "500 Internal Server Error", [("Content-Type", "application/json")]
            )
            return [b'{"error":"handler_error"}']

        start_response("204 No Content", [])
        return [b""]

    return app


def fastapi_router(handler: Handler, *, path: str = "/") -> Any:
    """Return a :class:`fastapi.APIRouter` with one POST route at ``path``.

    The returned router is idiomatic FastAPI — ``app.include_router(router,
    prefix="/webhooks/arr")`` wires it into your existing app. Requires the
    ``webhooks`` extra: ``pip install arr-py-client[webhooks]``.
    """
    try:
        from fastapi import APIRouter, HTTPException, Request
    except ImportError as exc:  # pragma: no cover - exercised by ImportError test
        msg = (
            "fastapi is required for fastapi_router(); install with "
            "``pip install arr-py-client[webhooks]``"
        )
        raise ImportError(msg) from exc

    router = APIRouter()

    # ``Request`` is imported at runtime inside this function, but the
    # module-wide ``from __future__ import annotations`` stringifies all
    # annotations — so a bare ``request: Request`` can't be resolved by
    # ``get_type_hints()`` at dependency-injection time. Annotate as ``Any``
    # for the type-checker and patch the concrete ``Request`` into
    # ``__annotations__`` below so FastAPI sees it when it resolves the route.
    async def _receive(request: Any) -> None:
        body = await request.body()
        event = _parse_body(body)
        if event is None:
            raise HTTPException(status_code=400, detail="invalid_json_body")
        try:
            result = handler(event)
            if asyncio.iscoroutine(result):
                await result
        except Exception as exc:
            _log.exception("webhook handler raised")
            raise HTTPException(status_code=500, detail="handler_error") from exc

    _receive.__annotations__["request"] = Request
    router.add_api_route(path, _receive, methods=["POST"], status_code=204)
    return router
