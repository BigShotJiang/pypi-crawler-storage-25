"""Load a config-sync desired-state from a file (YAML / JSON / TOML).

YAML is the canonical format (matches Recyclarr/Profilarr conventions);
JSON and TOML are supported for stdlib-only setups. YAML loading requires
the ``config`` extra: ``pip install arr-py-client[config]``.

Returns a plain ``dict`` suitable to pass straight to
:func:`arr_py_client.config_sync.plan`. Structural validation is done by
:class:`DesiredState` — unknown top-level keys raise early so typos don't
silently become no-ops.

Example
-------

.. code-block:: python

    from arr_py_client.config_sync import load, plan

    desired = load("config.yaml")
    plan_ = plan(client, desired)
    print(plan_.summary())
"""

from __future__ import annotations

import json
import tomllib
from pathlib import Path
from typing import Any, cast

from pydantic import BaseModel, ConfigDict, Field

# Supported resource keys must stay in sync with
# ``arr_py_client.config_sync.core.SUPPORTED_RESOURCES``. The loader enforces
# the schema early so a typo in the config file blows up before we hit the
# network.


class DesiredState(BaseModel):
    """Pydantic schema for the top-level desired-state document.

    Fields correspond 1:1 to resource keys understood by
    :func:`arr_py_client.config_sync.plan`. Unknown keys raise a
    ``ValidationError`` so mis-spellings are caught at load time.
    """

    model_config = ConfigDict(extra="forbid")

    tags: list[str] | None = Field(default=None)
    custom_formats: list[dict[str, Any]] | None = Field(default=None)
    quality_profiles: list[dict[str, Any]] | None = Field(default=None)
    # Radarr+Sonarr: per-quality min/preferred/max size thresholds. UPDATE-only
    # (server seeds them at install time; no create/delete).
    quality_definitions: list[dict[str, Any]] | None = Field(default=None)
    root_folders: list[dict[str, Any]] | None = Field(default=None)
    download_clients: list[dict[str, Any]] | None = Field(default=None)
    indexers: list[dict[str, Any]] | None = Field(default=None)
    notifications: list[dict[str, Any]] | None = Field(default=None)
    # Prowlarr-only: registered downstream apps (Radarr/Sonarr/Lidarr/…).
    applications: list[dict[str, Any]] | None = Field(default=None)
    # Radarr+Sonarr: must-contain / must-not-contain term scoring, per-tag.
    release_profiles: list[dict[str, Any]] | None = Field(default=None)
    # Radarr+Sonarr: spec-driven tag application (genre, quality, year, …).
    auto_tagging: list[dict[str, Any]] | None = Field(default=None)
    # Naming is a singleton — one mapping, not a list.
    naming: dict[str, Any] | None = Field(default=None)

    def to_desired(self) -> dict[str, Any]:
        """Dump to the dict shape that :func:`plan` consumes.

        Name-keyed resources (custom_formats, quality_profiles,
        download_clients, indexers, notifications) must be emitted as
        ``{name: body}`` maps since that's what :func:`plan` expects. The
        file format keeps them as lists (more ergonomic) and we pivot here.
        """
        raw: dict[str, Any] = self.model_dump(exclude_none=True)
        for key in (
            "custom_formats",
            "quality_profiles",
            "quality_definitions",
            "download_clients",
            "indexers",
            "notifications",
            "applications",
            "release_profiles",
            "auto_tagging",
        ):
            items = raw.get(key)
            if isinstance(items, list):
                items_cast = cast("list[Any]", items)
                pivoted: dict[str, dict[str, Any]] = {}
                for item in items_cast:
                    if not isinstance(item, dict):
                        continue
                    item_dict = cast("dict[str, Any]", item)
                    name = item_dict.get("name")
                    if name is not None:
                        pivoted[str(name)] = item_dict
                raw[key] = pivoted
        return raw


def _load_yaml(text: str) -> Any:
    try:
        import yaml  # type: ignore[import-not-found]
    except ImportError as exc:  # pragma: no cover — exercised only when PyYAML missing
        msg = (
            "PyYAML is required to load YAML config files. Install with "
            "``pip install arr-py-client[config]``, or supply a JSON/TOML "
            "config instead."
        )
        raise ImportError(msg) from exc
    return yaml.safe_load(text)


def _load_json(text: str) -> Any:
    return json.loads(text)


def _load_toml(text: str) -> Any:
    return tomllib.loads(text)


_SUFFIX_LOADERS: dict[str, Any] = {
    ".yaml": _load_yaml,
    ".yml": _load_yaml,
    ".json": _load_json,
    ".toml": _load_toml,
}


def load(path: str | Path) -> dict[str, Any]:
    """Load ``path`` and return a validated desired-state dict.

    Dispatches on file extension: ``.yaml`` / ``.yml`` → PyYAML,
    ``.json`` → stdlib, ``.toml`` → stdlib ``tomllib``. Raises:

    - :class:`FileNotFoundError` if ``path`` does not exist.
    - :class:`ValueError` if the extension is unsupported or the root is not
      a mapping.
    - :class:`pydantic.ValidationError` if the document has unknown top-level
      keys or wrongly-typed values.
    - :class:`ImportError` if YAML is requested without PyYAML installed.
    """
    p = Path(path)
    if not p.is_file():
        msg = f"config file not found: {p}"
        raise FileNotFoundError(msg)
    suffix = p.suffix.lower()
    loader = _SUFFIX_LOADERS.get(suffix)
    if loader is None:
        msg = (
            f"unsupported config file extension {suffix!r}; "
            f"expected one of {sorted(_SUFFIX_LOADERS)}"
        )
        raise ValueError(msg)
    raw: Any = loader(p.read_text(encoding="utf-8"))
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        msg = f"config root must be a mapping, got {type(raw).__name__}"
        raise ValueError(msg)
    # Re-validate via pydantic so unknown keys / wrong types fail fast.
    state = DesiredState.model_validate(raw)
    return state.to_desired()
