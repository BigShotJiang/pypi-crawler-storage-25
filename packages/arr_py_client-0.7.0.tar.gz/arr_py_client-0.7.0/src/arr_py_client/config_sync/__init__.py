"""Declarative config sync for Radarr/Sonarr (Recyclarr/Profilarr-shaped).

Users write the desired state of their server — tags, custom formats,
quality-profile CF-score maps — as a plain Python dict (usually loaded from
YAML/JSON/TOML). This module diffs desired-vs-actual and returns a
:class:`SyncPlan`; callers then :func:`apply` (or dry-run) it.

Scope: ``tags``, ``custom_formats``, ``quality_profiles``,
``quality_definitions``, ``release_profiles``, ``auto_tagging``,
``root_folders``, ``download_clients``, ``indexers``, ``notifications``,
``naming``, and (Prowlarr-only) ``applications``. Resources that don't apply
to a given brand are silently skipped via an ``hasattr(client, resource)``
guard, so one desired-state document can target any brand.

The module is brand-neutral: it duck-types the client's resource interface
via attribute lookup, so a Radarr or Sonarr client works with the same
``plan()`` / ``apply()`` entry points.

Example
-------

.. code-block:: python

    import yaml
    from arr_py_client.radarr.v3 import RadarrClientV3
    from arr_py_client.config_sync import plan, apply

    with RadarrClientV3() as client:
        desired = yaml.safe_load(open("config.yaml"))
        p = plan(client, desired)
        print(p.summary())
        report = apply(client, p, dry_run=False)
"""

from __future__ import annotations

from arr_py_client.config_sync.core import (
    SyncChange,
    SyncPlan,
    SyncReport,
    apply,
    apply_async,
    diff,
    diff_async,
    dump,
    dump_async,
    plan,
    plan_async,
)
from arr_py_client.config_sync.loader import DesiredState, load

__all__ = [
    "DesiredState",
    "SyncChange",
    "SyncPlan",
    "SyncReport",
    "apply",
    "apply_async",
    "diff",
    "diff_async",
    "dump",
    "dump_async",
    "load",
    "plan",
    "plan_async",
]
