"""Brand-neutral helpers for queue diagnosis.

Both Radarr and Sonarr queue records expose the same three status fields:
``status``, ``trackedDownloadStatus``, ``trackedDownloadState``. The logic
for flagging a record as "stuck" is identical across brands, so it lives
here.
"""

from __future__ import annotations

STUCK_QUEUE_STATUSES = frozenset({"warning", "failed"})
STUCK_TRACKED_STATUSES = frozenset({"warning", "error"})
STUCK_TRACKED_STATES = frozenset({"failed", "failedPending", "importBlocked"})


def enum_value(raw: object) -> str:
    """Normalize pydantic enum/str fields to their wire-format string value.

    ``str(Enum.member) == "EnumClass.member"`` in pydantic's default stringify;
    this helper returns just the trailing name.
    """
    if raw is None:
        return ""
    text = str(raw)
    return text.rsplit(".", 1)[-1]


def is_stuck(item: object) -> bool:
    """Classify a queue entry as stuck if any status field indicates trouble."""
    if enum_value(getattr(item, "status", None)) in STUCK_QUEUE_STATUSES:
        return True
    if (
        enum_value(getattr(item, "tracked_download_status", None))
        in STUCK_TRACKED_STATUSES
    ):
        return True
    return (
        enum_value(getattr(item, "tracked_download_state", None))
        in STUCK_TRACKED_STATES
    )
