"""Environment-backed settings for Radarr and Sonarr clients."""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class ArrSettings(BaseSettings):
    """Base ``BaseSettings`` with the two fields every arr client needs.

    Subclasses set ``env_prefix`` via ``model_config`` to scope env loading.
    Concrete subclasses (e.g. :class:`RadarrSettings`) are produced by
    :func:`_make_settings_cls`.
    """

    base_url: str
    api_key: str


def _make_settings_cls(name: str, env_prefix: str) -> type[ArrSettings]:
    """Build an :class:`ArrSettings` subclass scoped to an ``<APP>_`` env prefix."""

    class _ConcreteArrSettings(ArrSettings):
        model_config = SettingsConfigDict(
            env_prefix=env_prefix,
            env_file=".env",
            env_file_encoding="utf-8",
            extra="ignore",
        )

    _ConcreteArrSettings.__name__ = name
    _ConcreteArrSettings.__qualname__ = name
    _ConcreteArrSettings.__doc__ = (
        f"Connection settings for {name.removesuffix('Settings')}, "
        f"loaded from env / .env with `{env_prefix}` prefix."
    )
    return _ConcreteArrSettings


RadarrSettings = _make_settings_cls("RadarrSettings", "RADARR_")
SonarrSettings = _make_settings_cls("SonarrSettings", "SONARR_")
ProwlarrSettings = _make_settings_cls("ProwlarrSettings", "PROWLARR_")
