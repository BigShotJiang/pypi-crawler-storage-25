"""Shared pydantic base model for arr-py-client."""

from __future__ import annotations

from pydantic import AliasGenerator, BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class ArrBaseModel(BaseModel):
    """Base class for all request and response models.

    Field names are snake_case in Python and camelCase on the wire. Unknown
    fields coming back from the server are ignored so newly-added upstream
    fields do not raise until we regenerate the models.
    """

    model_config = ConfigDict(
        alias_generator=AliasGenerator(alias=to_camel, serialization_alias=to_camel),
        populate_by_name=True,
        extra="ignore",
        use_enum_values=False,
        validate_assignment=False,
    )
