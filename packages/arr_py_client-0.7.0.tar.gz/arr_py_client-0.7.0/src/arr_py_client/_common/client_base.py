"""Shared construction helpers for the per-brand arr clients.

Each brand (Sonarr, Radarr) has sync + async client classes. The wiring is
identical across brands modulo: settings class, app name for error messages,
and which auto + curated resources are attached. These helpers collapse that
duplication.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client._common.errors import ArrConfigError
from arr_py_client._common.retry import RetryPolicy
from arr_py_client._common.transport import AsyncTransport, SyncTransport

if TYPE_CHECKING:
    import httpx

    from arr_py_client._common.settings import ArrSettings


def resolve_arr_config(
    *,
    settings_cls: type[ArrSettings],
    app_name: str,
    base_url: str | None,
    api_key: str | None,
) -> tuple[str, str]:
    """Resolve ``base_url`` / ``api_key`` from kwargs or environment.

    Raises :class:`ArrConfigError` with an actionable message if neither source
    produced a valid value.
    """
    overrides: dict[str, Any] = {}
    if base_url is not None:
        overrides["base_url"] = base_url
    if api_key is not None:
        overrides["api_key"] = api_key
    try:
        settings = settings_cls(**overrides)
    except Exception as exc:
        upper = app_name.upper()
        msg = (
            f"{app_name} connection not configured: provide base_url/api_key as "
            f"kwargs or set {upper}_BASE_URL and {upper}_API_KEY in env/.env."
        )
        raise ArrConfigError(msg) from exc
    return settings.base_url, settings.api_key


def build_sync_transport(
    *,
    settings_cls: type[ArrSettings],
    app_name: str,
    api_version: int,
    base_url: str | None,
    api_key: str | None,
    timeout: float | None,
    url_base: str | None,
    verify: bool | str,
    retry: RetryPolicy | None,
    http_client: httpx.Client | None,
) -> SyncTransport:
    """Build a :class:`SyncTransport` from kwargs or environment config."""
    resolved_base, resolved_key = resolve_arr_config(
        settings_cls=settings_cls,
        app_name=app_name,
        base_url=base_url,
        api_key=api_key,
    )
    return SyncTransport(
        base_url=resolved_base,
        api_key=resolved_key,
        api_version=api_version,
        url_base=url_base,
        timeout=timeout,
        verify=verify,
        retry=retry if retry is not None else RetryPolicy.default(),
        http_client=http_client,
    )


def build_async_transport(
    *,
    settings_cls: type[ArrSettings],
    app_name: str,
    api_version: int,
    base_url: str | None,
    api_key: str | None,
    timeout: float | None,
    url_base: str | None,
    verify: bool | str,
    retry: RetryPolicy | None,
    http_client: httpx.AsyncClient | None,
) -> AsyncTransport:
    """Build an :class:`AsyncTransport` from kwargs or environment config."""
    resolved_base, resolved_key = resolve_arr_config(
        settings_cls=settings_cls,
        app_name=app_name,
        base_url=base_url,
        api_key=api_key,
    )
    return AsyncTransport(
        base_url=resolved_base,
        api_key=resolved_key,
        api_version=api_version,
        url_base=url_base,
        timeout=timeout,
        verify=verify,
        retry=retry if retry is not None else RetryPolicy.default(),
        http_client=http_client,
    )


def wire_resources(
    client: object,
    transport: SyncTransport | AsyncTransport,
    registry: dict[str, type],
) -> None:
    """Instantiate every class in ``registry`` with ``transport`` and attach it.

    ``registry`` maps attribute name → resource class. Identical shape for both
    sync and async (the per-brand ``_auto`` modules each expose one of each).
    Later calls with overlapping keys *override* earlier ones, which is how
    curated facades replace their auto-generated equivalents.
    """
    for attr, cls in registry.items():
        setattr(client, attr, cls(transport))
