"""Shared dataclasses for ``LibraryResource.health_summary()``.

These dashboard-oriented shapes are brand-agnostic. The per-brand
``LibraryResource`` populates them by fanning out to the brand's own resource
methods.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class DiskSummary:
    """Free/total space for a single disk, plus the computed ratio."""

    path: str
    label: str | None
    free_bytes: int | None
    total_bytes: int | None

    @property
    def free_percent(self) -> float | None:
        if self.free_bytes is None or self.total_bytes is None or self.total_bytes <= 0:
            return None
        return round(100.0 * self.free_bytes / self.total_bytes, 2)


@dataclass(frozen=True)
class HealthWarning:
    """One entry from ``GET /health``."""

    source: str | None
    type: str | None
    message: str | None
    wiki_url: str | None


@dataclass(frozen=True)
class QueueSummary:
    """Aggregate queue counts. Totals are sampled from the first page."""

    total: int
    stalled: int


@dataclass(frozen=True)
class DiffResult:
    """Outcome of comparing a target id-set against the library.

    ``present_ids`` are the TMDB/TVDB ids already in the library. ``missing_ids``
    are the ones in the target set but not in the library. ``extra_ids`` are in
    the library but not in the target set (useful for "library is a superset
    of this collection" audits).
    """

    present_ids: list[int]
    missing_ids: list[int]
    extra_ids: list[int]


@dataclass(frozen=True)
class LibraryHealth:
    """One-call dashboard primitive: everything an operator needs at a glance.

    Missing sub-sections (because a sub-call failed) end up in ``errors``
    rather than raising — callers get a partial view instead of a 500.
    """

    app: str
    version: str | None
    healthy: bool
    library_count: int | None
    warnings: list[HealthWarning]
    disks: list[DiskSummary]
    queue: QueueSummary
    errors: list[str] = field(default_factory=list)
