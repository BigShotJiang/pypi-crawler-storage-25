"""Schema-drift check: regenerate into a tempdir and diff against committed output."""

from __future__ import annotations

import argparse
import difflib
import sys
import tempfile
from pathlib import Path


def diff_directories(a: Path, b: Path) -> str:
    """Return a unified diff across all files in either directory.

    Empty string if identical.
    """
    all_files: set[str] = set()
    for root in (a, b):
        for path in root.rglob("*"):
            if path.is_file():
                all_files.add(path.relative_to(root).as_posix())
    parts: list[str] = []
    for rel in sorted(all_files):
        left_path = a / rel
        right_path = b / rel
        left = (
            left_path.read_text(encoding="utf-8").splitlines()
            if left_path.exists()
            else []
        )
        right = (
            right_path.read_text(encoding="utf-8").splitlines()
            if right_path.exists()
            else []
        )
        if left == right:
            continue
        parts.append(
            "\n".join(
                difflib.unified_diff(
                    left,
                    right,
                    fromfile=f"committed/{rel}",
                    tofile=f"regenerated/{rel}",
                    lineterm="",
                ),
            ),
        )
    return "\n".join(p for p in parts if p)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--app", required=True, choices=["radarr", "sonarr", "prowlarr"]
    )
    parser.add_argument("--api-version", type=int, default=3)
    parser.add_argument("--spec-path", type=Path, required=True)
    parser.add_argument("--report-path", type=Path, default=None)
    args = parser.parse_args()

    from arr_py_client._common.codegen.generate import (
        parse_operations,
        render_models,
        render_operations,
    )

    committed = (
        Path("src/arr_py_client") / args.app / f"v{args.api_version}" / "_generated"
    )
    with tempfile.TemporaryDirectory() as td:
        regen = Path(td)
        render_models(spec_path=args.spec_path, output_path=regen / "models.py")
        ops = parse_operations(args.spec_path)
        render_operations(
            operations=ops,
            output_path=regen / "operations.py",
            app=args.app,
            api_version=args.api_version,
            spec_tag="drift-check",
        )
        (regen / "__init__.py").touch()
        diff = diff_directories(committed, regen)

    if diff:
        if args.report_path:
            args.report_path.write_text(diff, encoding="utf-8")
        sys.stdout.write(diff + "\n")
        return 1
    sys.stdout.write("No drift detected.\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
