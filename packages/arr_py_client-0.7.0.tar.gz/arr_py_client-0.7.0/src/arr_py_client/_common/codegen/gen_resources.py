"""Auto-generate hand-curated resource wrappers from parsed operations.

For each OpenAPI ``tag``, group operations and emit a ``Resource`` /
``AsyncResource`` class in ``radarr/v3/resources/<tag_snake>.py``.

This is invoked from the CLI after ``parse_operations`` and ``render_operations``
have written ``_generated/operations.py``.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape

from arr_py_client._common.codegen.generate import camel_to_snake

if TYPE_CHECKING:
    from collections.abc import Iterable

    from arr_py_client._common.codegen.generate import Operation


_TEMPLATES_DIR = Path(__file__).parent / "templates"
_TEMPLATE_NAME = "resource.py.j2"

_PY_KEYWORDS = {
    "False",
    "None",
    "True",
    "and",
    "as",
    "assert",
    "async",
    "await",
    "break",
    "class",
    "continue",
    "def",
    "del",
    "elif",
    "else",
    "except",
    "finally",
    "for",
    "from",
    "global",
    "if",
    "import",
    "in",
    "is",
    "lambda",
    "nonlocal",
    "not",
    "or",
    "pass",
    "raise",
    "return",
    "try",
    "while",
    "with",
    "yield",
}


@dataclass(frozen=True)
class ResourceMethod:
    name: str
    op_sync: str
    op_async: str
    return_type: str
    return_model: str
    has_path_params: bool
    path_param_args: list[tuple[str, str]]
    has_query_params: bool
    query_param_kwargs: list[tuple[str, str]]
    has_body: bool
    body_type: str | None


@dataclass(frozen=True)
class ResourceGroup:
    tag: str
    module_name: str
    class_name: str
    async_class_name: str
    methods: list[ResourceMethod]


def _safe_method_name(name: str) -> str:
    if name in _PY_KEYWORDS or name in {
        "id",
        "type",
        "list",
        "input",
        "filter",
        "format",
    }:
        return name + "_"
    return name


_VERBS = ("list", "get", "create", "update", "delete", "post", "patch")


def _split_verb(op_name: str) -> tuple[str, str]:
    for verb in _VERBS:
        prefix = f"{verb}_"
        if op_name.startswith(prefix):
            return verb, op_name[len(prefix) :]
        if op_name == verb:
            return verb, ""
    return op_name, ""


def _common_word_prefix(tails: list[str]) -> str:
    if not tails:
        return ""
    word_lists = [t.split("_") for t in tails if t]
    if not word_lists:
        return ""
    common: list[str] = []
    for parts in zip(*word_lists, strict=False):
        first = parts[0]
        if all(p == first for p in parts):
            common.append(first)
        else:
            break
    return "_".join(common)


def group_operations_by_tag(operations: Iterable[Operation]) -> list[ResourceGroup]:
    by_tag: dict[str, list[Operation]] = {}
    for op in operations:
        by_tag.setdefault(op.tag, []).append(op)

    groups: list[ResourceGroup] = []
    used_module_names: set[str] = set()
    for tag, ops in sorted(by_tag.items()):
        tag_snake = camel_to_snake(tag)
        module_name = tag_snake
        suffix = 1
        while module_name in used_module_names:
            suffix += 1
            module_name = f"{tag_snake}_{suffix}"
        used_module_names.add(module_name)

        class_name = (
            "".join(part.capitalize() for part in tag_snake.split("_")) + "Resource"
        )
        async_class_name = "Async" + class_name

        verb_tails = [_split_verb(op.name_sync) for op in ops]
        common_noun = _common_word_prefix([t for _, t in verb_tails])

        seen_method_names: set[str] = set()
        methods: list[ResourceMethod] = []
        for op, (verb, tail) in zip(ops, verb_tails, strict=False):
            stripped = tail
            if common_noun:
                if stripped == common_noun:
                    stripped = ""
                elif stripped.startswith(common_noun + "_"):
                    stripped = stripped[len(common_noun) + 1 :]
            base = verb if not stripped else f"{verb}_{stripped}"
            base = _safe_method_name(base.strip("_") or verb)
            method_name = base
            i = 1
            while method_name in seen_method_names:
                i += 1
                method_name = f"{base}_{i}"
            seen_method_names.add(method_name)

            methods.append(
                ResourceMethod(
                    name=method_name,
                    op_sync=op.name_sync,
                    op_async=op.name_async,
                    return_type=op.return_type,
                    return_model=op.return_model,
                    has_path_params=bool(op.path_params),
                    path_param_args=[(p.name, p.type) for p in op.path_params],
                    has_query_params=bool(op.query_params),
                    query_param_kwargs=[(p.name, p.type) for p in op.query_params],
                    has_body=op.body_type is not None,
                    body_type=op.body_type,
                ),
            )

        groups.append(
            ResourceGroup(
                tag=tag,
                module_name=module_name,
                class_name=class_name,
                async_class_name=async_class_name,
                methods=methods,
            ),
        )
    return groups


def render_resources(
    *,
    groups: list[ResourceGroup],
    output_dir: Path,
    app: str,
    api_version: int = 3,
) -> None:
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATES_DIR)),
        undefined=StrictUndefined,
        trim_blocks=False,
        lstrip_blocks=False,
        autoescape=select_autoescape(disabled_extensions=("j2",)),
    )
    template = env.get_template(_TEMPLATE_NAME)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "__init__.py").write_text(
        _render_init(groups, app, api_version), encoding="utf-8"
    )
    for group in groups:
        rendered = template.render(group=group, app=app, api_version=api_version)
        (output_dir / f"{group.module_name}.py").write_text(rendered, encoding="utf-8")
    attrs_path = output_dir / "_attrs.py"
    attrs_path.write_text(_render_attrs(groups, app, api_version), encoding="utf-8")


def _render_attrs(groups: list[ResourceGroup], app: str, api_version: int) -> str:
    sync_imports = ", ".join(g.class_name for g in groups)
    async_imports = ", ".join(g.async_class_name for g in groups)
    cls_app = app.capitalize()
    version_tag = f"V{api_version}"
    lines = [
        '"""Generated typed attribute declarations for the client classes."""',
        "",
        "from __future__ import annotations",
        "",
        f"from arr_py_client.{app}.v{api_version}.resources._auto import (",
        f"    {sync_imports},",
        f"    {async_imports},",
        ")",
        "",
        f"class {cls_app}{version_tag}SyncResourceAttrs:",
    ]
    for g in groups:
        lines.append(f"    {g.module_name}: {g.class_name}")
    lines.append("")
    lines.append(f"class {cls_app}{version_tag}AsyncResourceAttrs:")
    for g in groups:
        lines.append(f"    {g.module_name}: {g.async_class_name}")
    lines.append("")
    return "\n".join(lines)


def _render_init(groups: list[ResourceGroup], app: str, api_version: int) -> str:
    docstring = f"Auto-generated resource wrappers for {app}."
    lines = [
        f'"""{docstring}"""',
        "",
        "from __future__ import annotations",
        "",
    ]
    for g in groups:
        module = f"arr_py_client.{app}.v{api_version}.resources._auto.{g.module_name}"
        lines.append(f"from {module} import {g.async_class_name}, {g.class_name}")
    lines.append("")
    names = sorted({n for g in groups for n in (g.class_name, g.async_class_name)})
    lines.append("__all__ = [")
    for n in names:
        lines.append(f'    "{n}",')
    lines.append("]")
    lines.append("")
    lines.append("SYNC_RESOURCES = {")
    for g in groups:
        lines.append(f'    "{g.module_name}": {g.class_name},')
    lines.append("}")
    lines.append("")
    lines.append("ASYNC_RESOURCES = {")
    for g in groups:
        lines.append(f'    "{g.module_name}": {g.async_class_name},')
    lines.append("}")
    lines.append("")
    return "\n".join(lines)
