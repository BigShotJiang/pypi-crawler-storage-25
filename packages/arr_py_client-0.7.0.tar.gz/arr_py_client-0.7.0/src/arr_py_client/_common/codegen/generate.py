"""Code-generation pipeline for arr-py-client.

Two entry points:

- ``render_models(spec_path, output_path)`` delegates to ``datamodel-code-generator``.
- ``render_operations(operations, output_path, ...)`` Jinja template-driven
  operation stubs.

Called from the CLI at ``python -m arr_py_client._common.codegen.generate``.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape

_TEMPLATES_DIR = Path(__file__).parent / "templates"
_TEMPLATE_NAME = "operation_stub.py.j2"


@dataclass(frozen=True)
class Param:
    name: str
    name_camel: str
    type: str
    default: str = "None"


@dataclass(frozen=True)
class Operation:
    operation_id: str
    http_method: str
    path_template: str
    tag: str
    summary: str
    name_sync: str
    name_async: str
    path_params: list[Param] = field(default_factory=list)
    query_params: list[Param] = field(default_factory=list)
    body_type: str | None = None
    return_type: str = "None"
    return_model: str = ""


_TYPE_MAP = {
    "integer": "int",
    "number": "float",
    "string": "str",
    "boolean": "bool",
}

_HTTP_METHODS = {"GET", "POST", "PUT", "DELETE", "PATCH"}


def camel_to_snake(name: str) -> str:
    out: list[str] = []
    for i, c in enumerate(name):
        if c.isupper() and i > 0 and not name[i - 1].isupper():
            out.append("_")
        out.append(c.lower())
    return "".join(out)


def _resolve_schema_type(schema: dict[str, Any]) -> str:
    if "$ref" in schema:
        ref = cast("str", schema["$ref"])
        return "models." + ref.split("/")[-1]
    t = schema.get("type")
    if t == "array":
        inner = cast("dict[str, Any]", schema.get("items", {}))
        return f"list[{_resolve_schema_type(inner)}]"
    if isinstance(t, str) and t in _TYPE_MAP:
        return _TYPE_MAP[t]
    return "Any"


_PATH_PARAM_RE = re.compile(r"\{([^}]+)\}")


def _strip_api_prefix(path: str) -> str:
    for prefix in ("/api/v3/", "/api/v2/", "/api/v1/", "/api/"):
        if path.startswith(prefix):
            return path[len(prefix) :]
    return path.lstrip("/")


def _sanitize_ident(name: str) -> str:
    """Make ``name`` a valid Python identifier fragment (lowercase, _, digits)."""
    out = re.sub(r"[^a-z0-9_]+", "_", camel_to_snake(name)).strip("_")
    return out or "x"


def _derive_operation_name(method: str, path: str, operation_id: str | None) -> str:
    """Build a unique snake_case operation name from method+path.

    If the spec provides ``operationId``, prefer that (sanitized). Otherwise derive
    a name like ``list_movie``, ``get_movie_by_id``, ``create_movie``,
    ``update_movie``, ``delete_movie``, ``post_movie_refresh_by_id``.
    """
    if operation_id:
        sanitized = re.sub(r"[^A-Za-z0-9_]+", "_", operation_id)
        return camel_to_snake(sanitized).strip("_") or "op"

    stripped = _strip_api_prefix(path)
    segments = [s for s in stripped.split("/") if s]
    parts: list[tuple[str, bool]] = []
    for seg in segments:
        m = _PATH_PARAM_RE.fullmatch(seg)
        if m:
            parts.append((_sanitize_ident(m.group(1)), True))
        else:
            parts.append((_sanitize_ident(seg), False))

    method_upper = method.upper()
    has_trailing_param = bool(parts) and parts[-1][1]

    if method_upper == "GET":
        verb = "get" if has_trailing_param else "list"
    elif method_upper == "POST":
        verb = "create" if not has_trailing_param else "post"
    elif method_upper == "PUT":
        verb = "update"
    elif method_upper == "DELETE":
        verb = "delete"
    elif method_upper == "PATCH":
        verb = "patch"
    else:
        verb = method_upper.lower()

    main_segments: list[str] = []
    by_parts: list[str] = []
    for name, is_param in parts:
        if is_param:
            by_parts.append(name)
        else:
            main_segments.append(name)

    main = "_".join(main_segments)
    by_suffix = "_by_" + "_and_".join(by_parts) if by_parts else ""

    if main:
        return f"{verb}_{main}{by_suffix}"
    return f"{verb}{by_suffix}"


def _safe_param_name(raw: str) -> str:
    name = camel_to_snake(raw)
    name = re.sub(r"[^a-z0-9_]", "_", name)
    if name and name[0].isdigit():
        name = "_" + name
    return name


def parse_operations(spec_path: Path) -> list[Operation]:
    spec = cast("dict[str, Any]", json.loads(spec_path.read_text(encoding="utf-8")))
    out: list[Operation] = []
    used_names: set[str] = set()
    paths = cast("dict[str, dict[str, Any]]", spec.get("paths", {}))
    for path, path_item in paths.items():
        for method, op_spec_raw in path_item.items():
            if method.upper() not in _HTTP_METHODS:
                continue
            op_spec = cast("dict[str, Any]", op_spec_raw)
            raw_op_id = cast("str | None", op_spec.get("operationId"))
            tags = cast("list[str]", op_spec.get("tags") or ["default"])
            tag = tags[0]
            summary_raw = cast("str | None", op_spec.get("summary"))

            base_name = _derive_operation_name(method, path, raw_op_id)
            name_sync = base_name
            counter = 1
            while name_sync in used_names:
                counter += 1
                name_sync = f"{base_name}_{counter}"
            used_names.add(name_sync)
            name_async = f"{name_sync}_async"

            op_id = raw_op_id or name_sync
            summary = summary_raw or name_sync

            parameters = cast("list[dict[str, Any]]", op_spec.get("parameters", []))
            path_params: list[Param] = []
            seen_path_params: set[str] = set()
            for raw_seg in re.findall(r"\{([^}]+)\}", path):
                if raw_seg in seen_path_params:
                    continue
                seen_path_params.add(raw_seg)
                schema: dict[str, Any] = {}
                for p in parameters:
                    if p.get("in") == "path" and p.get("name") == raw_seg:
                        schema = cast("dict[str, Any]", p.get("schema", {}))
                        break
                path_params.append(
                    Param(
                        name=_safe_param_name(raw_seg),
                        name_camel=raw_seg,
                        type=_resolve_schema_type(schema) if schema else "Any",
                    ),
                )
            query_params = [
                Param(
                    name=_safe_param_name(cast("str", p["name"])),
                    name_camel=cast("str", p["name"]),
                    type=f"{_resolve_schema_type(cast('dict[str, Any]', p.get('schema', {})))} | None",
                    default="None",
                )
                for p in parameters
                if p.get("in") == "query"
            ]
            body_type: str | None = None
            request_body = cast("dict[str, Any]", op_spec.get("requestBody", {}))
            body_schema = (
                cast("dict[str, Any]", request_body.get("content", {}))
                .get("application/json", {})
                .get("schema")
            )
            if body_schema:
                resolved = _resolve_schema_type(cast("dict[str, Any]", body_schema))
                if resolved.startswith("models."):
                    body_type = resolved
            return_type = "None"
            return_model = ""
            responses = cast("dict[str, dict[str, Any]]", op_spec.get("responses", {}))
            for code in ("200", "201", "202"):
                if code in responses:
                    schema = (
                        cast("dict[str, Any]", responses[code].get("content", {}))
                        .get("application/json", {})
                        .get("schema")
                    )
                    if schema:
                        candidate = _resolve_schema_type(schema)
                        if candidate.startswith("models."):
                            return_type = candidate
                            return_model = candidate.split(".", 1)[1]
                        elif candidate.startswith("list[models."):
                            return_type = candidate
                            return_model = candidate.removeprefix(
                                "list[models."
                            ).removesuffix("]")
                    break
            transport_path = path
            for prefix in ("/api/v3", "/api/v2", "/api/v1", "/api"):
                if transport_path.startswith(prefix + "/"):
                    transport_path = transport_path[len(prefix) :]
                    break
            out.append(
                Operation(
                    operation_id=op_id,
                    http_method=method.upper(),
                    path_template=transport_path,
                    tag=tag,
                    summary=summary,
                    name_sync=name_sync,
                    name_async=name_async,
                    path_params=path_params,
                    query_params=query_params,
                    body_type=body_type,
                    return_type=return_type,
                    return_model=return_model,
                ),
            )
    return out


def render_operations(
    *,
    operations: list[Operation],
    output_path: Path,
    app: str,
    api_version: int,
    spec_tag: str,
) -> None:
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATES_DIR)),
        undefined=StrictUndefined,
        trim_blocks=False,
        lstrip_blocks=False,
        autoescape=select_autoescape(disabled_extensions=("j2",)),
    )
    template = env.get_template(_TEMPLATE_NAME)
    rendered = template.render(
        operations=operations,
        app=app,
        api_version=api_version,
        spec_tag=spec_tag,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(rendered, encoding="utf-8")


def render_models(*, spec_path: Path, output_path: Path) -> None:
    """Invoke datamodel-code-generator as a subprocess.

    Post-processing strips any per-class ``model_config = ConfigDict(extra='forbid')``
    blocks the generator emits — upstream specs routinely omit fields the
    live server returns, so we defer to :class:`ArrBaseModel`'s
    ``extra="ignore"`` policy. (Radarr/Sonarr specs don't trigger this; the
    Prowlarr v1 spec does.)
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "uv",
        "run",
        "datamodel-codegen",
        "--input",
        str(spec_path),
        "--input-file-type",
        "openapi",
        "--output-model-type",
        "pydantic_v2.BaseModel",
        "--base-class",
        "arr_py_client._common.models.ArrBaseModel",
        "--snake-case-field",
        "--use-annotated",
        "--use-standard-collections",
        "--target-python-version",
        "3.11",
        "--output",
        str(output_path),
    ]
    subprocess.run(cmd, check=True)  # noqa: S603
    _strip_extra_forbid(output_path)


_FORBID_BLOCK = re.compile(
    r"    model_config = ConfigDict\(\n        extra='forbid',\n    \)\n",
    re.MULTILINE,
)

# After stripping the forbid block, a class whose only body was that block
# is left empty — which is a SyntaxError. Replace with ``pass`` so the class
# inherits :class:`ArrBaseModel` configuration cleanly.
_EMPTY_CLASS_BLOCK = re.compile(
    r"(class \w+\([^)]*\):\n)\n\n(class )",
    re.MULTILINE,
)


def _strip_extra_forbid(output_path: Path) -> None:
    """Remove ``extra='forbid'`` from generated class configs, in place."""
    source = output_path.read_text(encoding="utf-8")
    scrubbed = _FORBID_BLOCK.sub("", source)
    # Run repeatedly until stable — consecutive empty classes need multiple passes.
    for _ in range(5):
        new = _EMPTY_CLASS_BLOCK.sub(r"\1    pass\n\n\n\2", scrubbed)
        if new == scrubbed:
            break
        scrubbed = new
    if scrubbed != source:
        output_path.write_text(scrubbed, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--app", required=True, choices=["radarr", "sonarr", "prowlarr"]
    )
    parser.add_argument("--api-version", type=int, default=3)
    parser.add_argument("--spec-tag", required=True)
    parser.add_argument("--spec-path", type=Path, required=True)
    parser.add_argument(
        "--skip-resources",
        action="store_true",
        help="Generate only models + operations, not resource wrappers.",
    )
    args = parser.parse_args()

    app_root = Path("src/arr_py_client") / args.app / f"v{args.api_version}"
    out_dir = app_root / "_generated"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "__init__.py").touch()

    render_models(spec_path=args.spec_path, output_path=out_dir / "models.py")
    ops = parse_operations(args.spec_path)
    render_operations(
        operations=ops,
        output_path=out_dir / "operations.py",
        app=args.app,
        api_version=args.api_version,
        spec_tag=args.spec_tag,
    )

    if not args.skip_resources:
        from arr_py_client._common.codegen.gen_resources import (
            group_operations_by_tag,
            render_resources,
        )

        resources_dir = app_root / "resources" / "_auto"
        groups = group_operations_by_tag(ops)
        render_resources(
            groups=groups,
            output_dir=resources_dir,
            app=args.app,
            api_version=args.api_version,
        )


if __name__ == "__main__":
    main()
