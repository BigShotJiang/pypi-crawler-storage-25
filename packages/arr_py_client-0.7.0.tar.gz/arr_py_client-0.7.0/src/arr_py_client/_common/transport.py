"""HTTP transport base for arr-py-client (sync + async)."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import anyio
import httpx

from arr_py_client import __version__
from arr_py_client._common import errors

if TYPE_CHECKING:
    from arr_py_client._common.retry import RetryPolicy


_USER_AGENT = f"arr-py-client/{__version__}"
_SENTINEL: object = object()


def _retry_after_seconds(response: httpx.Response) -> float | None:
    """Parse the ``Retry-After`` header. Returns ``None`` if absent or unparsable.

    Supports the integer-seconds form. HTTP-date form is intentionally not
    supported (rare in practice for Radarr/Sonarr).
    """
    raw = response.headers.get("retry-after")
    if not raw:
        return None
    try:
        return max(0.0, float(raw))
    except ValueError:
        return None


def _retry_delay(
    response: httpx.Response,
    *,
    retry: RetryPolicy,
    method: str,
    attempt: int,
) -> float | None:
    """Return seconds to sleep before retrying, or ``None`` to stop retrying.

    Honors ``Retry-After`` when present (capped at ``retry.backoff_max``);
    otherwise uses ``retry.compute_backoff``.
    """
    if not retry.should_retry(
        method=method, status_code=response.status_code, attempt=attempt
    ):
        return None
    hint = _retry_after_seconds(response)
    if hint is not None:
        return min(hint, retry.backoff_max)
    return retry.compute_backoff(attempt)


@dataclass
class TransportConfig:
    """Non-I/O configuration shared by sync and async transports."""

    base_url: str
    api_key: str
    api_version: int
    url_base: str | None
    timeout: float | None
    verify: bool | str
    retry: RetryPolicy | None


class _TransportBase:
    """Shared helpers that do not touch the network."""

    _config: TransportConfig

    def __init__(self, *, config: TransportConfig) -> None:
        super().__init__()
        self._config = config

    @property
    def base_url(self) -> str:
        return self._config.base_url

    @property
    def api_version(self) -> int:
        return self._config.api_version

    def _full_url(self, path: str, *, absolute: bool = False) -> str:
        base = self._config.base_url.rstrip("/")
        url_base = (self._config.url_base or "").strip("/")
        if absolute:
            prefix = f"{base}/{url_base}" if url_base else base
        else:
            version_prefix = f"/api/v{self._config.api_version}"
            prefix = (
                f"{base}/{url_base}{version_prefix}"
                if url_base
                else f"{base}{version_prefix}"
            )
        suffix = path if path.startswith("/") else f"/{path}"
        return f"{prefix}{suffix}"

    def _headers(self) -> dict[str, str]:
        return {
            "X-Api-Key": self._config.api_key,
            "Accept": "application/json",
            "User-Agent": _USER_AGENT,
        }

    def _maybe_raise(self, response: httpx.Response) -> None:
        if 200 <= response.status_code < 300:
            return
        raise errors.ArrAPIError.from_response(response)


class SyncTransport(_TransportBase):
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        api_version: int,
        url_base: str | None,
        timeout: float | None,
        verify: bool | str,
        retry: RetryPolicy | None,
        http_client: httpx.Client | None = None,
    ) -> None:
        super().__init__(
            config=TransportConfig(
                base_url=base_url,
                api_key=api_key,
                api_version=api_version,
                url_base=url_base,
                timeout=timeout,
                verify=verify,
                retry=retry,
            ),
        )
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(timeout=timeout, verify=verify)

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        timeout: float | None | object = _SENTINEL,
        absolute: bool = False,
    ) -> httpx.Response:
        url = self._full_url(path, absolute=absolute)
        headers = self._headers()
        retry = self._config.retry
        attempt = 0
        client_timeout = httpx.USE_CLIENT_DEFAULT if timeout is _SENTINEL else timeout
        while True:
            try:
                response = self._client.request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=json,
                    timeout=client_timeout,  # type: ignore[arg-type]
                )
            except httpx.TimeoutException as exc:
                raise errors.ArrTimeoutError(str(exc)) from exc
            except httpx.ConnectError as exc:
                raise errors.ArrConnectionError(str(exc)) from exc
            if retry is not None:
                delay = _retry_delay(
                    response, retry=retry, method=method, attempt=attempt
                )
                if delay is not None:
                    time.sleep(delay)
                    attempt += 1
                    continue
            self._maybe_raise(response)
            return response

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> SyncTransport:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()


class AsyncTransport(_TransportBase):
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        api_version: int,
        url_base: str | None,
        timeout: float | None,
        verify: bool | str,
        retry: RetryPolicy | None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        super().__init__(
            config=TransportConfig(
                base_url=base_url,
                api_key=api_key,
                api_version=api_version,
                url_base=url_base,
                timeout=timeout,
                verify=verify,
                retry=retry,
            ),
        )
        self._owns_client = http_client is None
        self._client = http_client or httpx.AsyncClient(timeout=timeout, verify=verify)

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        timeout: float | None | object = _SENTINEL,
        absolute: bool = False,
    ) -> httpx.Response:
        url = self._full_url(path, absolute=absolute)
        headers = self._headers()
        retry = self._config.retry
        attempt = 0
        client_timeout = httpx.USE_CLIENT_DEFAULT if timeout is _SENTINEL else timeout
        while True:
            try:
                response = await self._client.request(
                    method,
                    url,
                    headers=headers,
                    params=params,
                    json=json,
                    timeout=client_timeout,  # type: ignore[arg-type]
                )
            except httpx.TimeoutException as exc:
                raise errors.ArrTimeoutError(str(exc)) from exc
            except httpx.ConnectError as exc:
                raise errors.ArrConnectionError(str(exc)) from exc
            if retry is not None:
                delay = _retry_delay(
                    response, retry=retry, method=method, attempt=attempt
                )
                if delay is not None:
                    await anyio.sleep(delay)
                    attempt += 1
                    continue
            self._maybe_raise(response)
            return response

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> AsyncTransport:
        return self

    async def __aexit__(self, *_exc: object) -> None:
        await self.aclose()
