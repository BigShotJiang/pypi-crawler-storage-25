"""Exception hierarchy for arr-py-client."""

from __future__ import annotations

from dataclasses import dataclass
from json import JSONDecodeError
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    import httpx


class ArrError(Exception):
    """Base exception for all arr-py-client errors."""


class ArrConfigError(ArrError):
    """Raised when client construction fails due to missing or invalid configuration."""


class ArrConnectionError(ArrError):
    """Raised when the client cannot reach the server."""


class ArrResolveError(ArrError):
    """Raised when a name cannot be resolved to a server-side id.

    Attributes:
        field: The logical field that was being resolved (e.g. ``"quality_profile"``).
        attempted: The value the caller passed that didn't match.
        valid_options: The list of valid names observed server-side.
    """

    field: str
    attempted: object
    valid_options: list[str]

    def __init__(
        self, *, field: str, attempted: object, valid_options: list[str]
    ) -> None:
        self.field = field
        self.attempted = attempted
        self.valid_options = valid_options
        preview = ", ".join(repr(v) for v in valid_options[:10])
        extra = (
            "" if len(valid_options) <= 10 else f" (+{len(valid_options) - 10} more)"
        )
        msg = (
            f"could not resolve {field}={attempted!r}; "
            f"valid options: [{preview}{extra}]"
        )
        super().__init__(msg)


class ArrAlreadyExistsError(ArrError):
    """Raised by idempotent-add helpers when ``if_exists='error'`` and the resource exists.

    Attributes:
        field: Which uniqueness key matched (e.g. ``"tmdb_id"``, ``"tvdb_id"``).
        existing_id: The id of the already-present resource (if known).
    """

    field: str
    existing_id: int | None

    def __init__(self, *, field: str, existing_id: int | None = None) -> None:
        self.field = field
        self.existing_id = existing_id
        suffix = f" (id={existing_id})" if existing_id is not None else ""
        super().__init__(f"resource already exists by {field}{suffix}")


class ArrTimeoutError(ArrError):
    """Raised when a request exceeds the configured timeout."""


@dataclass(frozen=True)
class ValidationErrorDetail:
    property_name: str
    error_message: str
    severity: str


class ArrAPIError(ArrError):
    """Raised for any non-2xx response from the server."""

    status_code: int
    response: httpx.Response
    request: httpx.Request
    response_body: Any

    def __init__(self, response: httpx.Response) -> None:
        self.response = response
        self.request = response.request
        self.status_code = response.status_code
        self.response_body = _parse_body(response)
        message = f"{self.__class__.__name__}: {response.status_code} {response.reason_phrase} {response.request.method} {response.request.url}"
        super().__init__(message)

    @classmethod
    def from_response(cls, response: httpx.Response) -> ArrAPIError:
        status = response.status_code
        if status in (401, 403):
            return ArrAuthError(response)
        if status == 404:
            return ArrNotFoundError(response)
        if status in (400, 422):
            return ArrValidationError(response)
        if status == 429:
            return ArrRateLimitError(response)
        if 500 <= status < 600:
            return ArrServerError(response)
        return cls(response)


class ArrAuthError(ArrAPIError):
    """401/403."""


class ArrNotFoundError(ArrAPIError):
    """404."""


class ArrRateLimitError(ArrAPIError):
    """429."""


class ArrServerError(ArrAPIError):
    """5xx."""


class ArrValidationError(ArrAPIError):
    """400/422. Parses the *arr validation response shape into typed details."""

    validation_errors: list[ValidationErrorDetail]

    def __init__(self, response: httpx.Response) -> None:
        super().__init__(response)
        self.validation_errors = _parse_validation_errors(self.response_body)
        if self.validation_errors:
            details = "; ".join(
                f"{d.property_name}: {d.error_message}" for d in self.validation_errors
            )
            existing = self.args[0] if self.args else ""
            self.args = (f"{existing} [{details}]",)


def _parse_body(response: httpx.Response) -> Any:
    if not response.content:
        return None
    try:
        return response.json()
    except (JSONDecodeError, ValueError, UnicodeDecodeError):
        return response.content


def _parse_validation_errors(body: Any) -> list[ValidationErrorDetail]:
    if not isinstance(body, list):
        return []
    out: list[ValidationErrorDetail] = []
    for raw in cast("list[Any]", body):
        if not isinstance(raw, dict):
            continue
        item = cast("dict[str, Any]", raw)
        out.append(
            ValidationErrorDetail(
                property_name=str(item.get("propertyName", "")),
                error_message=str(item.get("errorMessage", "")),
                severity=str(item.get("severity", "")),
            ),
        )
    return out
