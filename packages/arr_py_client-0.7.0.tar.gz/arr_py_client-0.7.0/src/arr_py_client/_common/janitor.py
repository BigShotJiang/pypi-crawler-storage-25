"""Policy-based queue janitor.

Users end up writing custom scripts against Radarr/Sonarr's queue for the
same half-dozen failure modes: stalled downloads, import-blocked items,
0-seed torrents, oversized grabs, ghosted cross-seed injections. This module
turns that into a pluggable policy engine.

A :class:`JanitorPolicy` is a frozen dataclass with a ``name``, an
:class:`JanitorAction`, and a ``matches(item) -> bool`` predicate. Callers
pass a list of policies to the brand-specific ``queue.janitor(...)`` method;
the engine walks queue items, first-match-wins, and (unless ``dry_run``)
executes the matched action via the existing ``nuke_and_redownload`` /
``delete`` paths.

Protected-tracker logic: items seeded on a tracker in ``protected_trackers``
are downgraded from ``BLOCKLIST_AND_RESEARCH`` to ``IGNORE`` — private
trackers are intolerant of removal and re-grab churn. This protects the
tracker reputation ratio.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING, Protocol, cast, runtime_checkable

if TYPE_CHECKING:
    from collections.abc import Iterable, Sequence

from arr_py_client._common.queue import enum_value, is_stuck


class JanitorAction(StrEnum):
    BLOCKLIST_AND_RESEARCH = "blocklist_and_research"
    REMOVE = "remove"
    REMOVE_NO_BLOCKLIST = "remove_no_blocklist"
    IGNORE = "ignore"


@runtime_checkable
class JanitorPolicy(Protocol):
    """Pluggable policy interface.

    A policy has a stable ``name`` (used in reports + CLI/YAML), a default
    ``action`` to take on match, and a predicate ``matches(item) -> bool``.
    Items are pydantic ``QueueResource`` instances for either brand — we rely
    only on duck-typed attribute access.
    """

    # Declared as properties so frozen-dataclass implementations (which expose
    # their fields as read-only attributes) satisfy the protocol.
    @property
    def name(self) -> str: ...
    @property
    def action(self) -> JanitorAction: ...
    def matches(self, item: object) -> bool: ...


@dataclass(frozen=True)
class StuckPolicy:
    """Matches via :func:`arr_py_client._common.queue.is_stuck`."""

    name: str = "stuck"
    action: JanitorAction = JanitorAction.BLOCKLIST_AND_RESEARCH

    def matches(self, item: object) -> bool:
        return is_stuck(item)


@dataclass(frozen=True)
class StalledPolicy:
    """Item's ``trackedDownloadState == "stalled"`` and it's been in-queue
    for at least ``min_age_hours``."""

    min_age_hours: float = 6.0
    name: str = "stalled"
    action: JanitorAction = JanitorAction.BLOCKLIST_AND_RESEARCH

    def matches(self, item: object) -> bool:
        state = enum_value(getattr(item, "tracked_download_state", None)).lower()
        if state != "stalled":
            return False
        added = getattr(item, "added", None)
        if added is None:
            # No timestamp — trust the stall signal on its own.
            return True
        age = _age_in_hours(added)
        return age is None or age >= self.min_age_hours


@dataclass(frozen=True)
class ImportBlockedPolicy:
    """Item finished downloading but cannot be imported (missing series/movie,
    failed parse, needs manual decision)."""

    name: str = "import_blocked"
    action: JanitorAction = JanitorAction.BLOCKLIST_AND_RESEARCH

    def matches(self, item: object) -> bool:
        state = enum_value(getattr(item, "tracked_download_state", None)).lower()
        return state in {"importblocked", "importpending", "importfailed"}


@dataclass(frozen=True)
class ManualInteractionPolicy:
    """Item requires human action (``OnManualInteractionRequired`` territory)."""

    name: str = "manual_interaction_required"
    action: JanitorAction = JanitorAction.IGNORE

    def matches(self, item: object) -> bool:
        state = enum_value(getattr(item, "tracked_download_state", None)).lower()
        return state == "manualinteractionrequired"


@dataclass(frozen=True)
class SizeOverPolicy:
    """Item's ``size`` exceeds ``max_bytes``. Default action: remove without
    blocklisting, so the same release isn't permanently banned."""

    max_bytes: int
    name: str = "size_over"
    action: JanitorAction = JanitorAction.REMOVE_NO_BLOCKLIST

    def matches(self, item: object) -> bool:
        size = getattr(item, "size", None)
        if size is None:
            return False
        try:
            return int(size) > self.max_bytes
        except (TypeError, ValueError):
            return False


@dataclass(frozen=True)
class StatusMessagesContainPolicy:
    """Any ``statusMessages[*].messages[*]`` contains ``needle`` (case-insensitive).

    Useful for catching cross-seed ghosts ("No files found are eligible...")
    or ambiguous-match cases ("Unknown movie") without hardcoding them in
    client code.
    """

    needle: str
    name: str = "status_contains"
    action: JanitorAction = JanitorAction.BLOCKLIST_AND_RESEARCH

    def matches(self, item: object) -> bool:
        raw_messages = cast(
            "list[object] | None", getattr(item, "status_messages", None)
        )
        needle = self.needle.lower()
        for block in raw_messages or []:
            raw_lines = cast("list[object] | None", getattr(block, "messages", None))
            for line in raw_lines or []:
                if needle in str(line).lower():
                    return True
        return False


@dataclass(frozen=True)
class JanitorMatch:
    """One queue-item / policy match."""

    item_id: int
    item_title: str | None
    policy_name: str
    action: JanitorAction
    indexer: str | None = None


@dataclass
class JanitorReport:
    """Result of a janitor run. ``matches`` is all matched items; ``executed_*``
    reflect what was actually done (empty in ``dry_run``)."""

    matches: list[JanitorMatch] = field(default_factory=list)
    dry_run: bool = True
    executed_blocklist_ids: list[int] = field(default_factory=list)
    executed_remove_ids: list[int] = field(default_factory=list)
    protected_skips: int = 0

    @property
    def total_matches(self) -> int:
        """Count of :attr:`matches` (executed or not)."""
        return len(self.matches)


def _age_in_hours(added: object) -> float | None:
    if isinstance(added, _dt.datetime):
        now = _dt.datetime.now(tz=added.tzinfo) if added.tzinfo else _dt.datetime.now()
        return (now - added).total_seconds() / 3600.0
    if isinstance(added, str):
        try:
            parsed = _dt.datetime.fromisoformat(added.replace("Z", "+00:00"))
        except ValueError:
            return None
        now = (
            _dt.datetime.now(tz=parsed.tzinfo) if parsed.tzinfo else _dt.datetime.now()
        )
        return (now - parsed).total_seconds() / 3600.0
    return None


def _indexer_of(item: object) -> str | None:
    value = getattr(item, "indexer", None)
    return str(value) if value is not None else None


def _title_of(item: object) -> str | None:
    value = getattr(item, "title", None)
    return str(value) if value is not None else None


def _item_id(item: object) -> int | None:
    value = getattr(item, "id", None)
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def plan_actions(
    items: Iterable[object],
    policies: Sequence[JanitorPolicy],
    *,
    protected_trackers: Sequence[str] = (),
) -> list[JanitorMatch]:
    """First-match-wins planner. Downgrades blocklist actions on protected trackers."""
    protected = {t.lower() for t in protected_trackers}
    out: list[JanitorMatch] = []
    for item in items:
        item_id = _item_id(item)
        if item_id is None:
            continue
        for policy in policies:
            if not policy.matches(item):
                continue
            action = policy.action
            indexer = _indexer_of(item)
            if (
                action == JanitorAction.BLOCKLIST_AND_RESEARCH
                and indexer is not None
                and indexer.lower() in protected
            ):
                action = JanitorAction.IGNORE
            out.append(
                JanitorMatch(
                    item_id=item_id,
                    item_title=_title_of(item),
                    policy_name=policy.name,
                    action=action,
                    indexer=indexer,
                )
            )
            break
    return out


DEFAULT_POLICIES: tuple[JanitorPolicy, ...] = (
    ManualInteractionPolicy(),
    ImportBlockedPolicy(),
    StalledPolicy(),
    StuckPolicy(),
)


class POLICIES:
    """Named, pre-assembled policy bundles.

    Each attribute is a tuple of :class:`JanitorPolicy` ready to pass as
    ``policies=`` to ``client.queue.janitor(...)``. Pick the one whose
    opinions match your stack, or build your own from the individual policy
    classes above.
    """

    #: Report-only: every match is downgraded to ``IGNORE`` so nothing is
    #: removed or blocklisted. Useful for first-run exploration, dashboards,
    #: or paranoid operators who want to eyeball every action before enabling
    #: a writing bundle.
    conservative: tuple[JanitorPolicy, ...] = (
        ManualInteractionPolicy(),
        ImportBlockedPolicy(action=JanitorAction.IGNORE),
        StalledPolicy(action=JanitorAction.IGNORE),
        StuckPolicy(action=JanitorAction.IGNORE),
    )

    #: Current-default bundle: manual-interaction items are left alone,
    #: stuck / stalled / import-blocked items are blocklisted and
    #: re-searched. Equivalent to :data:`DEFAULT_POLICIES`.
    default: tuple[JanitorPolicy, ...] = DEFAULT_POLICIES

    #: Default bundle plus a ``SizeOverPolicy`` that removes (without
    #: blocklisting) anything over 100 GiB. The size threshold is a
    #: conservative cutoff for "obviously junk" grabs; override if your
    #: library legitimately includes larger files.
    aggressive: tuple[JanitorPolicy, ...] = (
        ManualInteractionPolicy(),
        ImportBlockedPolicy(),
        StalledPolicy(),
        StuckPolicy(),
        SizeOverPolicy(max_bytes=100 * 1024**3),
    )

    #: Same match rules as :attr:`default`, but every action is
    #: ``REMOVE_NO_BLOCKLIST`` so the *release* isn't permanently banned —
    #: it can re-appear on a future RSS/search pass. Pair with
    #: ``protected_trackers=(...)`` when calling ``janitor()`` if you run
    #: private trackers.
    ratio_preserving: tuple[JanitorPolicy, ...] = (
        ManualInteractionPolicy(),
        ImportBlockedPolicy(action=JanitorAction.REMOVE_NO_BLOCKLIST),
        StalledPolicy(action=JanitorAction.REMOVE_NO_BLOCKLIST),
        StuckPolicy(action=JanitorAction.REMOVE_NO_BLOCKLIST),
    )
