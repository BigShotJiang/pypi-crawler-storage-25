"""Name → id resolvers shared by Radarr and Sonarr curated facades.

The two brands use distinct generated model classes for tags, quality profiles,
root folders, etc. These helpers work via duck typing (``.id``, ``.name``,
``.label``, ``.path``) so a single implementation serves both.

All resolvers raise :class:`ArrResolveError` with ``valid_options=[...]`` on
miss, so callers — and MCP tools in particular — can surface actionable
error messages to users.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client._common.errors import ArrResolveError

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable


def resolve_by_name_or_id(
    *,
    items: Iterable[Any],
    ref: str | int,
    field: str,
    name_attr: str = "name",
) -> int:
    """Resolve ``ref`` (name or id) against ``items`` to an int id.

    - If ``ref`` is an ``int``: validate it matches an item's ``.id`` and return it.
    - If ``ref`` is a ``str``: match case-insensitively against the ``name_attr``
      and return the item's ``.id``. Raises :class:`ArrResolveError` on miss.

    ``name_attr`` varies per resource: quality profiles use ``"name"``, tags use
    ``"label"``, root folders use ``"path"``.
    """
    item_list = list(items)
    if isinstance(ref, int):
        for item in item_list:
            if getattr(item, "id", None) == ref:
                return ref
        options = [
            str(getattr(it, name_attr, None))
            for it in item_list
            if getattr(it, name_attr, None) is not None
        ]
        raise ArrResolveError(field=field, attempted=ref, valid_options=options)

    needle = ref.strip().lower()
    for item in item_list:
        value = getattr(item, name_attr, None)
        if isinstance(value, str) and value.strip().lower() == needle:
            item_id = getattr(item, "id", None)
            if isinstance(item_id, int):
                return item_id
    options = [
        str(getattr(it, name_attr, None))
        for it in item_list
        if getattr(it, name_attr, None) is not None
    ]
    raise ArrResolveError(field=field, attempted=ref, valid_options=options)


def resolve_root_folder_path(
    *,
    items: Iterable[Any],
    ref: str | None,
) -> str:
    """Resolve ``ref`` (a path, or ``None`` to auto-pick) against root folders.

    - If ``ref`` is given: verify it matches one of the configured paths (exact
      match, trailing slashes stripped). Returns the canonical path as
      configured on the server.
    - If ``ref`` is ``None`` and exactly one root folder is configured: return
      its path. Otherwise raises :class:`ArrResolveError` asking the caller to
      be explicit.
    """
    item_list = list(items)
    paths: list[str] = [
        str(getattr(it, "path", None))
        for it in item_list
        if getattr(it, "path", None) is not None
    ]
    if ref is None:
        if len(paths) == 1:
            return paths[0]
        raise ArrResolveError(
            field="root_folder",
            attempted=None,
            valid_options=paths,
        )
    needle = ref.rstrip("/")
    for path in paths:
        if path.rstrip("/") == needle:
            return path
    raise ArrResolveError(field="root_folder", attempted=ref, valid_options=paths)


def resolve_tag_ids(
    *,
    tags: Iterable[Any],
    refs: Iterable[str | int],
    create_missing: Callable[[str], Any] | None = None,
) -> list[int]:
    """Resolve a list of tag refs (names or ids) to a list of ids.

    - Existing names are matched case-insensitively against ``.label``.
    - Int refs are passed through after validating they match a known tag.
    - When ``create_missing`` is provided, unknown names are created by calling
      ``create_missing(name)`` and the new tag's ``.id`` is used. When absent,
      unknown names raise :class:`ArrResolveError`.

    Returns a de-duplicated list of ids, preserving first-seen order.
    """
    existing = list(tags)
    by_id: dict[int, Any] = {
        int(getattr(t, "id", -1)): t for t in existing if getattr(t, "id", None)
    }
    by_label: dict[str, Any] = {
        str(getattr(t, "label", "")).strip().lower(): t
        for t in existing
        if getattr(t, "label", None)
    }
    out: list[int] = []
    seen: set[int] = set()
    for ref in refs:
        if isinstance(ref, int):
            if ref not in by_id:
                raise ArrResolveError(
                    field="tag",
                    attempted=ref,
                    valid_options=list(by_label.keys()),
                )
            tag_id = ref
        else:
            key = ref.strip().lower()
            found = by_label.get(key)
            if found is not None:
                tag_id = int(getattr(found, "id", 0))
            elif create_missing is not None:
                created = create_missing(ref)
                created_id = getattr(created, "id", None)
                if not isinstance(created_id, int):
                    raise ArrResolveError(
                        field="tag", attempted=ref, valid_options=list(by_label.keys())
                    )
                tag_id = created_id
                # Make newly-created tag visible to later refs in the same call.
                by_id[tag_id] = created
                by_label[key] = created
            else:
                raise ArrResolveError(
                    field="tag",
                    attempted=ref,
                    valid_options=list(by_label.keys()),
                )
        if tag_id not in seen:
            seen.add(tag_id)
            out.append(tag_id)
    return out
