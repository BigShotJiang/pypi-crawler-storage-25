"""Pagination iterators and offset/limit math for paged endpoints.

``iter_pages`` / ``aiter_pages`` operate on a fetch callable returning a dict
in the standard Radarr/Sonarr paged shape:
``{"page": int, "pageSize": int, "totalRecords": int, "records": list}``.

``align_offset_to_page`` converts caller-friendly ``(offset, limit)`` into the
page-based ``(page, page_size, aligned_offset)`` triplet that the upstream API
actually accepts. Rounds offset down to the nearest page boundary.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Awaitable, Callable, Iterator


def align_offset_to_page(offset: int, limit: int) -> tuple[int, int, int]:
    """Convert ``(offset, limit)`` to ``(page, page_size, aligned_offset)``.

    Offsets are rounded down to the nearest page boundary because the upstream
    Radarr/Sonarr API is strictly page-based.
    """
    if limit <= 0:
        msg = "limit must be > 0"
        raise ValueError(msg)
    if offset < 0:
        msg = "offset must be >= 0"
        raise ValueError(msg)
    page = (offset // limit) + 1
    aligned = (offset // limit) * limit
    return page, limit, aligned


_PageFetcher = "Callable[[int, int], dict[str, Any]]"
_AsyncPageFetcher = "Callable[[int, int], Awaitable[dict[str, Any]]]"


def iter_pages(
    fetch: Callable[[int, int], dict[str, Any]], *, page_size: int = 50
) -> Iterator[Any]:
    """Yield records from every page until a short or empty page is returned."""
    page = 1
    while True:
        payload = fetch(page, page_size)
        records = payload.get("records", [])
        if not records:
            return
        yield from records
        if len(records) < page_size:
            return
        page += 1


async def aiter_pages(
    fetch: Callable[[int, int], Awaitable[dict[str, Any]]],
    *,
    page_size: int = 50,
) -> AsyncIterator[Any]:
    """Async analogue of ``iter_pages``."""
    page = 1
    while True:
        payload = await fetch(page, page_size)
        records = payload.get("records", [])
        if not records:
            return
        for record in records:
            yield record
        if len(records) < page_size:
            return
        page += 1
