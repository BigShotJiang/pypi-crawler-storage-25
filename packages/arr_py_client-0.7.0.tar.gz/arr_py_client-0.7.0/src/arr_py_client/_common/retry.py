"""Retry policy for arr-py-client HTTP requests."""

from __future__ import annotations

import secrets
from dataclasses import dataclass, field


@dataclass(frozen=True)
class RetryPolicy:
    """Configuration for request retries.

    Attributes:
        attempts: Total attempts including the first try. ``1`` disables retries.
        backoff_base: Base delay in seconds; actual delay is full-jittered.
        backoff_max: Maximum delay in seconds; caps exponential growth.
        retry_on_methods: HTTP methods eligible for retry. Default is idempotent GET only.
        retry_on_statuses: Response statuses that trigger a retry.
    """

    attempts: int = 3
    backoff_base: float = 1.0
    backoff_max: float = 30.0
    retry_on_methods: tuple[str, ...] = field(default_factory=lambda: ("GET",))
    retry_on_statuses: tuple[int, ...] = field(
        default_factory=lambda: (429, 500, 502, 503, 504)
    )

    @classmethod
    def default(cls) -> RetryPolicy:
        return cls()

    def should_retry(self, *, method: str, status_code: int, attempt: int) -> bool:
        if attempt >= self.attempts - 1:
            return False
        if method.upper() not in self.retry_on_methods:
            return False
        return status_code in self.retry_on_statuses

    def compute_backoff(self, attempt: int) -> float:
        ceiling = min(self.backoff_max, self.backoff_base * (2**attempt))
        return secrets.SystemRandom().uniform(0.0, ceiling)
