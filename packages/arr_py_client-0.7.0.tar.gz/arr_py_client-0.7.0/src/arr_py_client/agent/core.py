"""Agent runtime: one pass per :meth:`Agent.tick`.

The agent is stateless between ticks. Cadence (`rule.every`) and budget are
re-derived from the journal each pass, so restarts, crashes, and out-of-band
journal edits all Just Work.

Per-tick sequence:

1. Read last-run timestamps for every rule from the journal.
2. For each enabled rule whose last run is older than ``rule.every``:
   a. Pre-flight :meth:`Budget.check` against the journal.
   b. If allowed, call ``rule.action(ctx)`` and collect the
      :class:`RuleReport`.
   c. Append one ``agent.rule.<name>`` marker entry so the next tick can
      compute cadence correctly.
3. Return an :class:`AgentReport` covering all rules (including skipped /
   not-due ones), with timestamps so schedulers can decide when to wake up
   again.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from arr_py_client.agent.rules import RuleContext, RuleReport

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from arr_py_client.agent.budget import Budget
    from arr_py_client.agent.rules import Rule
    from arr_py_client.journal import Journal


_RULE_MARKER_PREFIX = "agent.rule."


@dataclass(frozen=True)
class RuleStatus:
    """Snapshot of one rule's scheduling state — no side effects."""

    rule_name: str
    enabled: bool
    every_seconds: float
    last_run_at: _dt.datetime | None
    next_due_at: _dt.datetime | None
    due_now: bool


@dataclass
class AgentReport:
    """Outcome of one :meth:`Agent.tick` invocation."""

    started_at: _dt.datetime
    ended_at: _dt.datetime
    dry_run: bool
    rules: list[RuleReport] = field(default_factory=list)

    @property
    def ran_count(self) -> int:
        """Rules that actually executed (not just evaluated for cadence)."""
        return sum(1 for r in self.rules if r.ran)

    @property
    def skipped_count(self) -> int:
        """Rules that were evaluated but did not execute (cadence, budget, etc.)."""
        return sum(1 for r in self.rules if not r.ran)

    def summary(self) -> str:
        """Human-readable one-line recap suitable for logs or chat output."""
        dr = " [dry_run]" if self.dry_run else ""
        return (
            f"Agent tick{dr}: {self.ran_count} ran, {self.skipped_count} skipped, "
            f"{sum(1 for r in self.rules if not r.ok)} errors"
        )


class Agent:
    """Declarative rule runner.

    Instantiate once (usually at process startup), then call :meth:`tick`
    on whatever schedule your platform provides (systemd timer, cron,
    Kubernetes CronJob). ``tick`` is safe to call more often than the
    shortest rule's cadence — rules that aren't due yet are skipped.
    """

    def __init__(
        self,
        *,
        clients: Mapping[str, Any],
        journal: Journal,
        rules: Sequence[Rule],
        budget: Budget | None = None,
    ) -> None:
        self.clients = dict(clients)
        self.journal = journal
        self.rules = list(rules)
        # Import here to avoid a mandatory dep on budget.py when users
        # subclass Agent with their own constructor.
        from arr_py_client.agent.budget import Budget as _Budget

        self.budget = budget if budget is not None else _Budget()
        self._validate_rules()

    def _validate_rules(self) -> None:
        seen: set[str] = set()
        for rule in self.rules:
            if rule.name in seen:
                msg = f"duplicate rule name: {rule.name!r}"
                raise ValueError(msg)
            seen.add(rule.name)

    # ---- cadence / status -----------------------------------------------

    def _last_run_at(self, rule_name: str) -> _dt.datetime | None:
        """Most-recent ``agent.rule.<name>`` timestamp, or ``None`` if unseen."""
        marker = f"{_RULE_MARKER_PREFIX}{rule_name}"
        latest: _dt.datetime | None = None
        for entry in self.journal.iter(action=marker):
            if entry.action != marker:
                continue
            if latest is None or entry.timestamp > latest:
                latest = entry.timestamp
        return latest

    def _is_due(
        self,
        rule: Rule,
        *,
        now: _dt.datetime,
    ) -> tuple[bool, _dt.datetime | None]:
        last = self._last_run_at(rule.name)
        if last is None:
            return True, None
        return (now - last) >= rule.every, last

    def status(self, *, now: _dt.datetime | None = None) -> list[RuleStatus]:
        """Return a snapshot of every rule's scheduling state. No side effects."""
        now = now or _dt.datetime.now(tz=_dt.UTC)
        out: list[RuleStatus] = []
        for rule in self.rules:
            last = self._last_run_at(rule.name)
            next_due = (last + rule.every) if last is not None else now
            due, _ = self._is_due(rule, now=now)
            out.append(
                RuleStatus(
                    rule_name=rule.name,
                    enabled=rule.enabled,
                    every_seconds=rule.every.total_seconds(),
                    last_run_at=last,
                    next_due_at=next_due,
                    due_now=due and rule.enabled,
                )
            )
        return out

    # ---- execution -------------------------------------------------------

    async def tick(
        self,
        *,
        dry_run: bool = False,
        now: _dt.datetime | None = None,
    ) -> AgentReport:
        """Run one pass. Returns an :class:`AgentReport`.

        ``dry_run=True`` forces every rule into preview mode *and* skips the
        ``agent.rule.<name>`` marker write — nothing in the journal changes,
        so cadence stays intact for the real tick. Use :meth:`preview` for
        one-rule dry runs.
        """
        started = now or _dt.datetime.now(tz=_dt.UTC)
        reports: list[RuleReport] = []
        for rule in self.rules:
            if not rule.enabled:
                reports.append(
                    RuleReport(
                        rule_name=rule.name,
                        ran=False,
                        skipped_reason="disabled",
                    )
                )
                continue
            due, last_run = self._is_due(rule, now=started)
            if not due:
                wait = rule.every - (started - (last_run or started))
                reports.append(
                    RuleReport(
                        rule_name=rule.name,
                        ran=False,
                        skipped_reason=(
                            f"not due ({int(wait.total_seconds())}s remaining)"
                        ),
                    )
                )
                continue
            check = self.budget.check(self.journal, now=started)
            if not check.allowed:
                reports.append(
                    RuleReport(
                        rule_name=rule.name,
                        ran=False,
                        skipped_reason=f"budget: {check.reason}",
                    )
                )
                continue
            ctx = RuleContext(
                clients=self.clients,
                journal=self.journal,
                budget_check=check,
                dry_run=dry_run,
                now=started,
            )
            try:
                report = await rule.action(ctx)
            except Exception as exc:
                report = RuleReport(
                    rule_name=rule.name,
                    ran=True,
                    ok=False,
                    action="agent.error",
                    summary=f"rule raised: {exc}",
                    details={"exception": type(exc).__name__, "message": str(exc)},
                )
            reports.append(report)
            # Write the marker only on a real tick — dry-run ticks preserve
            # cadence so the next live tick sees them as still-due.
            if not dry_run and report.ran:
                self.journal.append(
                    f"{_RULE_MARKER_PREFIX}{rule.name}",
                    ok=report.ok,
                    details={
                        "action": report.action,
                        "summary": report.summary,
                        **report.details,
                    },
                )
        ended = _dt.datetime.now(tz=_dt.UTC)
        return AgentReport(
            started_at=started, ended_at=ended, dry_run=dry_run, rules=reports
        )

    async def preview(self, rule_name: str) -> RuleReport:
        """Force one rule to run in dry-run mode, bypassing cadence + budget.

        Useful for "what would this rule do right now?" from a CLI or chat.
        The rule's own ``dry_run`` kwarg is ORed with the context's — so a
        ``Rule.janitor(dry_run=False, ...)`` still previews cleanly.
        """
        for rule in self.rules:
            if rule.name != rule_name:
                continue
            ctx = RuleContext(
                clients=self.clients,
                journal=self.journal,
                budget_check=self.budget.check(self.journal),
                dry_run=True,
                now=_dt.datetime.now(tz=_dt.UTC),
            )
            try:
                return await rule.action(ctx)
            except Exception as exc:
                return RuleReport(
                    rule_name=rule_name,
                    ran=True,
                    ok=False,
                    action="agent.error",
                    summary=f"rule raised: {exc}",
                    details={"exception": type(exc).__name__, "message": str(exc)},
                )
        msg = f"no rule named {rule_name!r}"
        raise KeyError(msg)
