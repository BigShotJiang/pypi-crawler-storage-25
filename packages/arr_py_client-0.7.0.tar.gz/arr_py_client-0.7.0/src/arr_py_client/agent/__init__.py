"""Declarative operator agent — tick-driven rule runner with shared budget.

The agent is the natural consumer of the ``journal`` + ``dump`` + ``trash``
foundations: every mutating primitive in this library can be automated, but
scheduling them ad-hoc via cron leads to a forest of scripts that don't
share a budget, don't know about each other, and don't leave an audit trail.

``arr_py_client.agent`` collapses that into one declarative surface:

.. code-block:: python

    from datetime import timedelta
    from arr_py_client import RadarrClient, SonarrClient
    from arr_py_client.agent import Agent, Budget, Rule
    from arr_py_client.journal import Journal

    with RadarrClient() as r, SonarrClient() as s:
        agent = Agent(
            clients={"radarr": r, "sonarr": s},
            journal=Journal.default(),
            budget=Budget(
                max_deletions_per_hour=20,
                max_searches_per_hour=50,
            ),
            rules=[
                Rule.janitor("clean-radarr", every=timedelta(minutes=30),
                             app="radarr", bundle="default"),
                Rule.backfill("backfill-sonarr", every=timedelta(hours=6),
                              app="sonarr", source="missing",
                              max_items=40, pause_if_queue_over=10),
            ],
        )
        report = agent.tick()

Design
------

- **Tick-driven, not a daemon.** ``agent.tick()`` runs one pass. Users schedule
  it via systemd, cron, Kubernetes CronJob — whatever. No signal handling,
  no crash-recovery, no memory leaks.

- **Journal is the source of truth.** Rule cadence (``every=``) is computed
  from the last ``agent.rule.<name>`` entry in the journal. No separate
  state file.

- **Budget is cross-rule.** The :class:`Budget` applies to the *sum* of all
  rules' mutations in a time window, so one rule going rogue can't starve
  the others. Pre-flight-checked before each rule runs.

- **Every rule is deterministic.** Rules compose the existing typed
  primitives (``queue.janitor``, ``library.backfill``, ``config_sync.apply``,
  ``trash.fetch_desired_state``) — no LLM, no nondeterminism. Bring your own
  LLM through MCP if you want one.
"""

from __future__ import annotations

from arr_py_client.agent.budget import Budget, BudgetCheck
from arr_py_client.agent.core import Agent, AgentReport, RuleReport, RuleStatus
from arr_py_client.agent.rules import Rule

__all__ = [
    "Agent",
    "AgentReport",
    "Budget",
    "BudgetCheck",
    "Rule",
    "RuleReport",
    "RuleStatus",
]
