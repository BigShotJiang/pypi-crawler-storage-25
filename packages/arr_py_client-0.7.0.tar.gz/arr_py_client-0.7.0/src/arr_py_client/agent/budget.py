"""Cross-rule budget enforcement.

A :class:`Budget` holds global caps on mutations — deletions, searches,
error rate — and :meth:`Budget.check` scans the journal to see whether a
proposed action would exceed them. The check is pre-flight: runs *before*
the rule executes so we don't mutate and then regret.

Mutation counts are derived from existing journal entries:

- ``queue.janitor`` → ``len(details.executed_blocklist_ids) +
  len(details.executed_remove_ids)`` counts as deletions
- ``library.backfill`` → ``details.searched_count`` counts as searches
- ``movies.bulk_edit`` / ``series.bulk_edit`` → ``details.count`` counts as
  deletions (bulk mutations, treated as risk-equivalent)

Users who need finer control can subclass or pass custom scorers, but the
90% case is "stop deleting things if I've already deleted too many today."
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from arr_py_client.journal import Journal, JournalEntry


_DELETION_ACTIONS = frozenset({"queue.janitor", "movies.bulk_edit", "series.bulk_edit"})
_SEARCH_ACTIONS = frozenset({"library.backfill"})


def _count_deletions(entry: JournalEntry) -> int:
    """Extract the deletion-like count from a journal entry."""
    if entry.action not in _DELETION_ACTIONS:
        return 0
    details = entry.details
    if entry.action == "queue.janitor":
        blocklist = cast("list[Any]", details.get("executed_blocklist_ids") or [])
        remove = cast("list[Any]", details.get("executed_remove_ids") or [])
        return len(blocklist) + len(remove)
    # bulk_edit counts the number of items touched.
    raw_count = details.get("count", 0)
    try:
        return int(raw_count)
    except (TypeError, ValueError):
        return 0


def _count_searches(entry: JournalEntry) -> int:
    """Extract the search-like count from a journal entry."""
    if entry.action not in _SEARCH_ACTIONS:
        return 0
    raw_count = entry.details.get("searched_count", 0)
    try:
        return int(raw_count)
    except (TypeError, ValueError):
        return 0


def _count_errors(entries: list[JournalEntry]) -> tuple[int, int]:
    """Return ``(error_entries, total_entries)`` for error-rate calculation."""
    total = len(entries)
    errs = sum(1 for e in entries if not e.ok)
    return errs, total


@dataclass(frozen=True)
class BudgetCheck:
    """Outcome of a pre-flight budget evaluation."""

    allowed: bool
    reason: str | None = None
    deletions_last_hour: int = 0
    deletions_last_day: int = 0
    searches_last_hour: int = 0
    error_rate_last_hour: float = 0.0


@dataclass(frozen=True)
class Budget:
    """Caps on cross-rule mutations, checked against the journal.

    Set a field to ``None`` to disable that cap. The defaults (``None``
    everywhere) mean no budget is enforced — useful for testing, but in
    production you almost certainly want at least ``max_deletions_per_hour``
    set.

    ``pause_if_error_rate_over`` is a float in [0.0, 1.0]; it halts new rule
    runs if recent journal entries show a failure rate above the threshold.
    Great for "don't pile more on if Radarr is returning 500s."
    """

    max_deletions_per_hour: int | None = None
    max_deletions_per_day: int | None = None
    max_searches_per_hour: int | None = None
    pause_if_error_rate_over: float | None = None
    #: Minimum journal entries in the error-rate window before the rate is
    #: considered meaningful — avoids pausing on one flaky call at startup.
    error_rate_min_samples: int = 5

    def check(
        self,
        journal: Journal,
        *,
        now: _dt.datetime | None = None,
    ) -> BudgetCheck:
        """Scan recent journal entries and return whether the next rule may run.

        ``now`` defaults to ``datetime.now(tz=UTC)``; override for
        deterministic tests.
        """
        now = now or _dt.datetime.now(tz=_dt.UTC)
        hour_ago = now - _dt.timedelta(hours=1)
        day_ago = now - _dt.timedelta(days=1)

        last_hour = journal.list(since=hour_ago)
        last_day = journal.list(since=day_ago)

        deletions_hr = sum(_count_deletions(e) for e in last_hour)
        deletions_day = sum(_count_deletions(e) for e in last_day)
        searches_hr = sum(_count_searches(e) for e in last_hour)
        errs, total = _count_errors(last_hour)
        error_rate = (errs / total) if total >= self.error_rate_min_samples else 0.0

        if (
            self.max_deletions_per_hour is not None
            and deletions_hr >= self.max_deletions_per_hour
        ):
            return BudgetCheck(
                allowed=False,
                reason=(
                    f"max_deletions_per_hour={self.max_deletions_per_hour} "
                    f"reached ({deletions_hr})"
                ),
                deletions_last_hour=deletions_hr,
                deletions_last_day=deletions_day,
                searches_last_hour=searches_hr,
                error_rate_last_hour=error_rate,
            )
        if (
            self.max_deletions_per_day is not None
            and deletions_day >= self.max_deletions_per_day
        ):
            return BudgetCheck(
                allowed=False,
                reason=(
                    f"max_deletions_per_day={self.max_deletions_per_day} "
                    f"reached ({deletions_day})"
                ),
                deletions_last_hour=deletions_hr,
                deletions_last_day=deletions_day,
                searches_last_hour=searches_hr,
                error_rate_last_hour=error_rate,
            )
        if (
            self.max_searches_per_hour is not None
            and searches_hr >= self.max_searches_per_hour
        ):
            return BudgetCheck(
                allowed=False,
                reason=(
                    f"max_searches_per_hour={self.max_searches_per_hour} "
                    f"reached ({searches_hr})"
                ),
                deletions_last_hour=deletions_hr,
                deletions_last_day=deletions_day,
                searches_last_hour=searches_hr,
                error_rate_last_hour=error_rate,
            )
        if (
            self.pause_if_error_rate_over is not None
            and error_rate > self.pause_if_error_rate_over
        ):
            return BudgetCheck(
                allowed=False,
                reason=(
                    f"error_rate {error_rate:.2f} > threshold "
                    f"{self.pause_if_error_rate_over:.2f}"
                ),
                deletions_last_hour=deletions_hr,
                deletions_last_day=deletions_day,
                searches_last_hour=searches_hr,
                error_rate_last_hour=error_rate,
            )
        return BudgetCheck(
            allowed=True,
            deletions_last_hour=deletions_hr,
            deletions_last_day=deletions_day,
            searches_last_hour=searches_hr,
            error_rate_last_hour=error_rate,
        )
