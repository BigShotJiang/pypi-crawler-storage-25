"""Rule factories for the operator agent.

A :class:`Rule` is a name + cadence + an async callable that receives a
:class:`RuleContext` and returns a :class:`RuleReport`. Most users never
construct a ``Rule`` directly — they use one of the factory classmethods
(:meth:`Rule.janitor`, :meth:`Rule.backfill`, :meth:`Rule.config_sync`,
:meth:`Rule.trash_sync`) which wrap the corresponding primitive with the
right arguments.

For advanced use, :meth:`Rule.custom` accepts any async callable —
``async def my_rule(ctx: RuleContext) -> RuleReport`` — so you can build
one-off logic without subclassing. The context gives you the client map,
the journal, and the active budget check so your rule can short-circuit
the same way built-in rules do.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    import datetime as _dt
    from collections.abc import Awaitable, Callable, Iterable, Mapping

    from arr_py_client.agent.budget import BudgetCheck
    from arr_py_client.journal import Journal


AppName = Literal["radarr", "sonarr", "prowlarr"]


@dataclass(frozen=True)
class RuleReport:
    """Outcome of one rule invocation."""

    rule_name: str
    ran: bool
    ok: bool = True
    skipped_reason: str | None = None
    summary: str = ""
    action: str = ""
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class RuleContext:
    """Runtime context passed to a :class:`Rule`'s action."""

    clients: Mapping[str, Any]
    journal: Journal | None
    budget_check: BudgetCheck
    dry_run: bool
    now: _dt.datetime


@dataclass(frozen=True)
class Rule:
    """One scheduled operator action.

    Rules are compared by ``name`` — it must be unique within an agent.
    The ``action`` callable receives a :class:`RuleContext` and should
    return a :class:`RuleReport`; the agent handles journaling the
    ``agent.rule.<name>`` marker entry.
    """

    name: str
    every: _dt.timedelta
    action: Callable[[RuleContext], Awaitable[RuleReport]]
    enabled: bool = True
    apps: tuple[AppName, ...] = ()

    # ---- factory classmethods --------------------------------------------

    @classmethod
    def janitor(
        cls,
        name: str,
        *,
        every: _dt.timedelta,
        app: AppName,
        bundle: Literal[
            "default", "conservative", "aggressive", "ratio_preserving"
        ] = "default",
        dry_run: bool = False,
        protected_trackers: Iterable[str] = (),
        enabled: bool = True,
    ) -> Rule:
        """Run the policy-based queue janitor against ``app``.

        ``bundle`` selects a named policy set (see
        :class:`arr_py_client.POLICIES`). Defaults to ``dry_run=False`` —
        the agent itself defaults to dry-run at the :meth:`Agent.tick` level,
        so set this ``True`` only if you want to force preview-mode even
        when the agent is running live.
        """
        protected = tuple(protected_trackers)

        async def _run(ctx: RuleContext) -> RuleReport:
            from arr_py_client import POLICIES

            client = ctx.clients.get(app)
            if client is None:
                return RuleReport(
                    rule_name=name,
                    ran=False,
                    ok=False,
                    skipped_reason=f"{app} client not configured",
                    action="agent.janitor",
                )
            policies = getattr(POLICIES, bundle)
            effective_dry = ctx.dry_run or dry_run
            report = await client.queue.janitor(
                policies=policies,
                dry_run=effective_dry,
                protected_trackers=protected,
                journal=ctx.journal,
            )
            return RuleReport(
                rule_name=name,
                ran=True,
                ok=True,
                action="agent.janitor",
                summary=(
                    f"{report.total_matches} matches, "
                    f"{len(report.executed_blocklist_ids)} blocklisted, "
                    f"{len(report.executed_remove_ids)} removed"
                ),
                details={
                    "app": app,
                    "bundle": bundle,
                    "dry_run": effective_dry,
                    "total_matches": report.total_matches,
                    "executed_blocklist_ids": list(report.executed_blocklist_ids),
                    "executed_remove_ids": list(report.executed_remove_ids),
                    "protected_skips": report.protected_skips,
                },
            )

        return cls(
            name=name,
            every=every,
            action=_run,
            enabled=enabled,
            apps=(app,),
        )

    @classmethod
    def backfill(
        cls,
        name: str,
        *,
        every: _dt.timedelta,
        app: AppName,
        source: Literal["missing", "cutoff_unmet", "both"] = "missing",
        batch_size: int | None = None,
        delay_between_batches: float = 30.0,
        max_items: int | None = None,
        pause_if_queue_over: int | None = None,
        monitored_only: bool = True,
        dry_run: bool = False,
        enabled: bool = True,
    ) -> Rule:
        """Safe rate-limited search loop over missing / cutoff-unmet items."""
        effective_batch = batch_size

        async def _run(ctx: RuleContext) -> RuleReport:
            client = ctx.clients.get(app)
            if client is None:
                return RuleReport(
                    rule_name=name,
                    ran=False,
                    ok=False,
                    skipped_reason=f"{app} client not configured",
                    action="agent.backfill",
                )
            # Default batch size: 5 for Radarr, 20 for Sonarr — matches the
            # default used by the composed MCP tool.
            bs = (
                effective_batch
                if effective_batch is not None
                else (5 if app == "radarr" else 20)
            )
            effective_dry = ctx.dry_run or dry_run
            report = await client.library.backfill(
                source=source,
                batch_size=bs,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=effective_dry,
                journal=ctx.journal,
            )
            return RuleReport(
                rule_name=name,
                ran=True,
                ok=True,
                action="agent.backfill",
                summary=(
                    f"{report.searched_count} searched in "
                    f"{report.batches_sent} batches ({report.stopped_reason.value})"
                ),
                details={
                    "app": app,
                    "source": source,
                    "dry_run": effective_dry,
                    "searched_count": report.searched_count,
                    "batches_sent": report.batches_sent,
                    "stopped_reason": report.stopped_reason.value,
                },
            )

        return cls(
            name=name,
            every=every,
            action=_run,
            enabled=enabled,
            apps=(app,),
        )

    @classmethod
    def config_sync(
        cls,
        name: str,
        *,
        every: _dt.timedelta,
        app: AppName,
        desired: Mapping[str, Any],
        strict: bool = False,
        dry_run: bool = False,
        enabled: bool = True,
    ) -> Rule:
        """Reconcile ``app`` to ``desired`` on every tick.

        ``desired`` is the same dict shape accepted by
        :func:`arr_py_client.config_sync.plan` — load it from a YAML file via
        :func:`arr_py_client.config_sync.load`.
        """

        async def _run(ctx: RuleContext) -> RuleReport:
            from arr_py_client.config_sync import apply_async, plan_async

            client = ctx.clients.get(app)
            if client is None:
                return RuleReport(
                    rule_name=name,
                    ran=False,
                    ok=False,
                    skipped_reason=f"{app} client not configured",
                    action="agent.config_sync",
                )
            plan_ = await plan_async(client, desired, strict=strict)
            effective_dry = ctx.dry_run or dry_run
            if plan_.is_noop:
                return RuleReport(
                    rule_name=name,
                    ran=True,
                    ok=True,
                    action="agent.config_sync",
                    summary="no changes",
                    details={"app": app, "dry_run": effective_dry, "applied": 0},
                )
            report = await apply_async(
                client, plan_, dry_run=effective_dry, journal=ctx.journal
            )
            return RuleReport(
                rule_name=name,
                ran=True,
                ok=not report.errors,
                action="agent.config_sync",
                summary=(
                    f"{len(report.applied)} applied, "
                    f"{len(report.skipped)} skipped, "
                    f"{len(report.errors)} errors"
                ),
                details={
                    "app": app,
                    "dry_run": effective_dry,
                    "plan_summary": plan_.summary(),
                    "applied": len(report.applied),
                    "errors": len(report.errors),
                },
            )

        return cls(
            name=name,
            every=every,
            action=_run,
            enabled=enabled,
            apps=(app,),
        )

    @classmethod
    def trash_sync(
        cls,
        name: str,
        *,
        every: _dt.timedelta,
        app: Literal["radarr", "sonarr"],
        ref: str,
        custom_formats: Iterable[str] | None = None,
        release_profiles: Iterable[str] | None = None,
        quality_definitions: str | None = None,
        dry_run: bool = False,
        enabled: bool = True,
    ) -> Rule:
        """Fetch TRaSH-Guides bundles on a cadence and apply them.

        **Pin ``ref``** to a release tag — ``"master"`` will drift every
        tick and undo your local tweaks. This is the one foot-gun worth a
        docstring reminder.
        """

        async def _run(ctx: RuleContext) -> RuleReport:
            from arr_py_client.config_sync import apply_async, plan_async
            from arr_py_client.trash import fetch_desired_state

            client = ctx.clients.get(app)
            if client is None:
                return RuleReport(
                    rule_name=name,
                    ran=False,
                    ok=False,
                    skipped_reason=f"{app} client not configured",
                    action="agent.trash_sync",
                )
            try:
                desired = fetch_desired_state(
                    app,
                    custom_formats=list(custom_formats) if custom_formats else None,
                    release_profiles=(
                        list(release_profiles) if release_profiles else None
                    ),
                    quality_definitions=quality_definitions,
                    ref=ref,
                )
            except Exception as exc:
                return RuleReport(
                    rule_name=name,
                    ran=True,
                    ok=False,
                    action="agent.trash_sync",
                    summary=f"fetch failed: {exc}",
                    details={"app": app, "ref": ref, "error": str(exc)},
                )
            plan_ = await plan_async(client, desired)
            effective_dry = ctx.dry_run or dry_run
            if plan_.is_noop:
                return RuleReport(
                    rule_name=name,
                    ran=True,
                    ok=True,
                    action="agent.trash_sync",
                    summary="no changes",
                    details={"app": app, "ref": ref, "dry_run": effective_dry},
                )
            report = await apply_async(
                client, plan_, dry_run=effective_dry, journal=ctx.journal
            )
            return RuleReport(
                rule_name=name,
                ran=True,
                ok=not report.errors,
                action="agent.trash_sync",
                summary=(f"{len(report.applied)} applied, {len(report.errors)} errors"),
                details={
                    "app": app,
                    "ref": ref,
                    "dry_run": effective_dry,
                    "plan_summary": plan_.summary(),
                    "applied": len(report.applied),
                    "errors": len(report.errors),
                },
            )

        return cls(
            name=name,
            every=every,
            action=_run,
            enabled=enabled,
            apps=(app,),
        )

    @classmethod
    def custom(
        cls,
        name: str,
        *,
        every: _dt.timedelta,
        action: Callable[[RuleContext], Awaitable[RuleReport]],
        apps: tuple[AppName, ...] = (),
        enabled: bool = True,
    ) -> Rule:
        """Wrap an arbitrary async callable as a Rule.

        The callable receives a :class:`RuleContext` and must return a
        :class:`RuleReport`. The agent journals the returned report under
        ``agent.rule.<name>``; the rule is responsible for any other
        journaling via ``ctx.journal``.
        """
        return cls(
            name=name,
            every=every,
            action=action,
            enabled=enabled,
            apps=apps,
        )
