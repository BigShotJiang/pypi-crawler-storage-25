"""TRaSH-Guides importer — pull custom formats + quality definitions from upstream.

TRaSH-Guides (https://github.com/TRaSH-Guides/Guides) is the community-maintained
catalog of Radarr/Sonarr custom formats, quality profile presets, and naming
conventions. It's the single most common reason operators reach for Recyclarr.
This module is our first-class equivalent: fetch TRaSH JSON directly and
produce a desired-state dict that slots into :func:`arr_py_client.config_sync.plan`.

Example
-------

.. code-block:: python

    from arr_py_client import RadarrClient
    from arr_py_client.config_sync import plan, apply
    from arr_py_client.trash import fetch_desired_state

    desired = fetch_desired_state("radarr", custom_formats=["x265", "hdr10"])

    with RadarrClient() as client:
        report = apply(client, plan(client, desired), dry_run=False)

Design notes
------------

- **Network-driven, not bundled**: TRaSH is MIT-licensed, but bundling it
  would mean shipping stale JSON every release. The importer fetches on
  demand from ``raw.githubusercontent.com`` and optionally caches to disk.
- **Pinnable**: ``ref=`` accepts a branch (``"master"``), a tag (e.g.
  ``"v2024.1.1"``), or a commit SHA. Pin for reproducibility.
- **Mockable**: a ``fetcher=`` kwarg overrides the HTTP call, so tests run
  without network. Matches the ``make_fake_*`` ergonomics used elsewhere.
- **Safe by default**: strips ``trash_*`` metadata fields so the emitted
  body is ready for ``plan()`` consumption without a post-process pass.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, cast

import httpx

if TYPE_CHECKING:
    from collections.abc import Iterable


App = Literal["radarr", "sonarr"]

_RAW_BASE = "https://raw.githubusercontent.com/TRaSH-Guides/Guides"
_API_BASE = "https://api.github.com/repos/TRaSH-Guides/Guides"


def _default_fetch(url: str) -> Any:
    """Fetch JSON from a URL. Uses httpx (already a core dep)."""
    response = httpx.get(url, timeout=15.0, follow_redirects=True)
    response.raise_for_status()
    return response.json()


def _cache_load(cache_dir: Path, key: str) -> Any | None:
    path = cache_dir / key
    if path.is_file():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
    return None


def _cache_store(cache_dir: Path, key: str, payload: Any) -> None:
    path = cache_dir / key
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _fetch_json(
    url: str,
    *,
    cache_dir: Path | None,
    cache_key: str,
    fetcher: Any | None,
) -> Any:
    if cache_dir is not None:
        cached = _cache_load(cache_dir, cache_key)
        if cached is not None:
            return cached
    payload = (fetcher or _default_fetch)(url)
    if cache_dir is not None:
        _cache_store(cache_dir, cache_key, payload)
    return payload


# ---------------------------------------------------------- normalization ---


# Fields TRaSH adds that Radarr/Sonarr don't accept on ``/customformat``.
_TRASH_META_FIELDS: frozenset[str] = frozenset(
    {"trash_id", "trash_score", "trash_description", "trash_scores", "trash_regex"}
)


def normalize_custom_format(payload: dict[str, Any]) -> dict[str, Any]:
    """Strip TRaSH-specific fields from a custom format payload.

    The output is a body acceptable to ``plan({"custom_formats": {name: body}})``.
    Specifications are kept as-is — they already match Radarr/Sonarr's schema.
    """
    return {
        k: v
        for k, v in payload.items()
        if k not in _TRASH_META_FIELDS and not k.startswith("trash_")
    }


def normalize_quality_definition(payload: dict[str, Any]) -> dict[str, Any]:
    """Strip TRaSH-specific fields from a quality-size payload.

    Upstream shape is ``{"type": "movie", "qualities": [{"quality": "Bluray-2160p",
    "min": 94.0, "preferred": 125.0, "max": 187.9}, ...]}``. Leaves it as-is
    minus the ``trash_*`` metadata — callers that want a config_sync-shaped
    dict should use :func:`quality_definition_to_desired`.
    """
    return {
        k: v
        for k, v in payload.items()
        if k not in _TRASH_META_FIELDS and not k.startswith("trash_")
    }


def quality_definition_to_desired(payload: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Convert a TRaSH quality-size payload into a name-keyed desired-state dict.

    Maps TRaSH field names (``min`` / ``preferred`` / ``max``) to the server's
    alias keys (``minSize`` / ``preferredSize`` / ``maxSize``) and keys each
    entry by its ``quality`` name (e.g. ``"Bluray-2160p"``) so it drops into
    :func:`arr_py_client.config_sync.plan`'s ``quality_definitions`` slot.
    """
    raw = payload.get("qualities")
    if not isinstance(raw, list):
        msg = f"expected 'qualities' to be a list, got {type(raw).__name__}"
        raise ValueError(msg)
    out: dict[str, dict[str, Any]] = {}
    for entry in cast("list[Any]", raw):
        if not isinstance(entry, dict):
            continue
        item = cast("dict[str, Any]", entry)
        name = item.get("quality")
        if name is None:
            continue
        body: dict[str, Any] = {}
        if "min" in item:
            body["minSize"] = item["min"]
        if "preferred" in item:
            body["preferredSize"] = item["preferred"]
        if "max" in item:
            body["maxSize"] = item["max"]
        if body:
            out[str(name)] = body
    return out


# ------------------------------------------------------------ networked ---


def _fetch_single_resource(
    app: App,
    subpath: str,
    slug: str,
    *,
    ref: str,
    cache_dir: str | Path | None,
    fetcher: Any | None,
    kind: str,
) -> dict[str, Any]:
    """Shared fetch-and-validate for single-resource TRaSH paths (cf, rp)."""
    rel = f"docs/json/{app}/{subpath}/{slug}.json"
    url = f"{_RAW_BASE}/{ref}/{rel}"
    cache_key = f"{ref}/{rel}"
    payload = _fetch_json(
        url,
        cache_dir=Path(cache_dir).expanduser() if cache_dir else None,
        cache_key=cache_key,
        fetcher=fetcher,
    )
    if not isinstance(payload, dict):
        msg = f"expected {kind} object, got {type(payload).__name__}"
        raise ValueError(msg)
    return cast("dict[str, Any]", payload)


def fetch_custom_format(
    app: App,
    slug: str,
    *,
    ref: str = "master",
    cache_dir: str | Path | None = None,
    fetcher: Any | None = None,
) -> dict[str, Any]:
    """Fetch one TRaSH custom format by file slug (filename without .json).

    Example: ``fetch_custom_format("radarr", "x265-no-hdr-no-remux")``.
    Pin ``ref`` to a branch, tag, or SHA for reproducibility; defaults to
    ``"master"`` which tracks HEAD and will drift.
    """
    payload = _fetch_single_resource(
        app,
        "cf",
        slug,
        ref=ref,
        cache_dir=cache_dir,
        fetcher=fetcher,
        kind="custom-format",
    )
    return normalize_custom_format(payload)


def fetch_release_profile(
    app: App,
    slug: str,
    *,
    ref: str = "master",
    cache_dir: str | Path | None = None,
    fetcher: Any | None = None,
) -> dict[str, Any]:
    """Fetch one TRaSH release profile. **Sonarr-only**: Radarr has no rp directory.

    TRaSH ships release profiles only for Sonarr — the whole concept is
    Sonarr-specific (Radarr uses custom formats for the same role). Passing
    ``app="radarr"`` will raise a 404 from the upstream repo; use custom
    formats there instead.
    """
    payload = _fetch_single_resource(
        app,
        "rp",
        slug,
        ref=ref,
        cache_dir=cache_dir,
        fetcher=fetcher,
        kind="release-profile",
    )
    # Release-profile payloads from TRaSH have the same trash_* metadata
    # pattern as custom formats, so the same normalizer applies.
    return normalize_custom_format(payload)


def _list_slugs(
    app: App,
    subpath: str,
    *,
    ref: str,
    fetcher: Any | None,
) -> list[str]:
    """Shared directory-listing helper via the GitHub contents API."""
    url = f"{_API_BASE}/contents/docs/json/{app}/{subpath}?ref={ref}"
    listing = (fetcher or _default_fetch)(url)
    if not isinstance(listing, list):
        msg = f"expected directory listing, got {type(listing).__name__}"
        raise ValueError(msg)
    slugs: list[str] = []
    for raw_item in cast("list[Any]", listing):
        if not isinstance(raw_item, dict):
            continue
        item = cast("dict[str, Any]", raw_item)
        if item.get("type") != "file":
            continue
        name = str(item.get("name") or "")
        if name.endswith(".json"):
            slugs.append(name[:-5])
    return sorted(slugs)


def list_custom_formats(
    app: App,
    *,
    ref: str = "master",
    fetcher: Any | None = None,
) -> list[str]:
    """Return slugs (filename stems) of every TRaSH custom format for ``app``.

    Uses the GitHub contents API — rate-limited to 60 req/hour unauthenticated.
    Cache the result for reuse within one session.
    """
    return _list_slugs(app, "cf", ref=ref, fetcher=fetcher)


def list_release_profiles(
    app: App,
    *,
    ref: str = "master",
    fetcher: Any | None = None,
) -> list[str]:
    """Return slugs of every TRaSH release profile. Sonarr-only upstream."""
    return _list_slugs(app, "rp", ref=ref, fetcher=fetcher)


def fetch_quality_definition(
    app: App,
    slug: str,
    *,
    ref: str = "master",
    cache_dir: str | Path | None = None,
    fetcher: Any | None = None,
) -> dict[str, Any]:
    """Fetch one TRaSH quality-size file by slug (e.g. ``"movie"``, ``"anime"``).

    Unlike custom formats, each TRaSH quality-size file covers the **entire**
    quality table in one JSON blob — there's one file per preset (``movie``,
    ``anime``, ``sqp-streaming`` for Radarr; ``series``, ``anime`` for
    Sonarr). The returned payload is TRaSH's native shape (``qualities: [...]``);
    use :func:`quality_definition_to_desired` to flatten it for ``plan()``.
    """
    payload = _fetch_single_resource(
        app,
        "quality-size",
        slug,
        ref=ref,
        cache_dir=cache_dir,
        fetcher=fetcher,
        kind="quality-size",
    )
    return normalize_quality_definition(payload)


def list_quality_definitions(
    app: App,
    *,
    ref: str = "master",
    fetcher: Any | None = None,
) -> list[str]:
    """Return slugs of every TRaSH quality-size preset for ``app``.

    Radarr: ``["anime", "movie", "sqp-streaming"]`` (as of 2026-04). Sonarr:
    ``["anime", "series"]``. Uses the GitHub contents API (60 req/hour
    unauthenticated).
    """
    return _list_slugs(app, "quality-size", ref=ref, fetcher=fetcher)


def fetch_desired_state(
    app: App,
    *,
    custom_formats: Iterable[str] | None = None,
    release_profiles: Iterable[str] | None = None,
    quality_definitions: str | None = None,
    ref: str = "master",
    cache_dir: str | Path | None = None,
    fetcher: Any | None = None,
) -> dict[str, Any]:
    """Bundle multiple TRaSH resources into a desired-state dict for ``plan()``.

    ``custom_formats`` and ``release_profiles`` are iterables of slugs; items
    are fetched, normalized (``trash_*`` fields stripped), and keyed by
    ``name``.

    ``quality_definitions`` is a **single** slug (e.g. ``"movie"``,
    ``"anime"``) — each TRaSH quality-size file covers a whole preset, so
    applying two would have the second clobber the first. Pick one.

    ``release_profiles`` is Sonarr-only upstream; requesting them against
    ``app="radarr"`` will fail with a 404 from the TRaSH repo.
    """
    out: dict[str, Any] = {}
    if custom_formats:
        cfs: dict[str, dict[str, Any]] = {}
        for slug in custom_formats:
            cf = fetch_custom_format(
                app, slug, ref=ref, cache_dir=cache_dir, fetcher=fetcher
            )
            name = str(cf.get("name") or slug)
            cfs[name] = cf
        out["custom_formats"] = cfs
    if release_profiles:
        rps: dict[str, dict[str, Any]] = {}
        for slug in release_profiles:
            rp = fetch_release_profile(
                app, slug, ref=ref, cache_dir=cache_dir, fetcher=fetcher
            )
            name = str(rp.get("name") or slug)
            rps[name] = rp
        out["release_profiles"] = rps
    if quality_definitions is not None:
        qd_payload = fetch_quality_definition(
            app, quality_definitions, ref=ref, cache_dir=cache_dir, fetcher=fetcher
        )
        out["quality_definitions"] = quality_definition_to_desired(qd_payload)
    return out


__all__ = [
    "App",
    "fetch_custom_format",
    "fetch_desired_state",
    "fetch_quality_definition",
    "fetch_release_profile",
    "list_custom_formats",
    "list_quality_definitions",
    "list_release_profiles",
    "normalize_custom_format",
    "normalize_quality_definition",
    "quality_definition_to_desired",
]
