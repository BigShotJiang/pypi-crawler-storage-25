"""``arr-py`` CLI — thin argparse wrapper around the client surfaces.

Designed to be a zero-dep companion (argparse only, no typer/click) so the
wheel stays small. Subcommands mirror the Python API — every CLI action calls
exactly one client method so the two surfaces can't drift.

Run ``arr-py --help`` for usage.
"""

from arr_py_client.cli.main import main

__all__ = ["main"]
