"""Persistent action journal / audit log.

Every mutating workflow (``config_sync.apply``, ``queue.janitor``,
``library.backfill``, MCP tool calls) can opt into journaling by passing a
:class:`Journal` instance. Each invocation appends one JSONL record with the
timestamp, a dotted action name, the app, an ok flag, and a detail dict.

Why this exists — it's the load-bearing prerequisite for letting an LLM (or
any automation) drive the stack autonomously. Without an append-only record
of "what did we change, and when," there's no way to audit, correlate with
Radarr/Sonarr events, or roll back. The format is deliberately boring
(JSONL, one line per event) so you can ``tail -f`` it, grep it, pipe it
into any ELK/Loki/whatever pipeline without first exporting from a
proprietary format.

Usage
-----

.. code-block:: python

    from arr_py_client import RadarrClient
    from arr_py_client.config_sync import plan, apply, load
    from arr_py_client.journal import Journal

    journal = Journal.default()  # writes to ~/.arr-py-client/journal.jsonl
    with RadarrClient() as client:
        report = apply(client, plan(client, load("config.yaml")),
                       dry_run=False, journal=journal)

    # Read back
    for entry in journal.iter(action="config_sync.apply"):
        print(entry.timestamp, entry.app, entry.ok, entry.details)

Design notes
------------

- **Format**: JSONL (one JSON object per line), UTF-8, LF-terminated. Durable
  writes: each ``append()`` opens the file in append mode, writes, flushes,
  closes. Good enough for the write volumes this library generates (tens of
  events/day in typical operator use).
- **No rotation**: do it yourself (logrotate, cron, whatever). Files stay
  small in practice.
- **No schema migration**: records are forward-compatible — unknown fields
  on read round-trip in ``details``.
"""

from __future__ import annotations

import datetime as _dt
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from collections.abc import Iterator


_DEFAULT_PATH_ENV = "ARR_PY_JOURNAL_PATH"
_DEFAULT_FALLBACK = "~/.arr-py-client/journal.jsonl"


@dataclass(frozen=True)
class JournalEntry:
    """One journal record. Immutable; constructed by :meth:`Journal.iter`."""

    timestamp: _dt.datetime
    action: str
    app: str | None
    ok: bool
    details: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_json(cls, obj: dict[str, Any]) -> JournalEntry:
        """Parse a single decoded JSON dict into a :class:`JournalEntry`.

        Unknown extra keys are preserved verbatim in ``details`` so
        forward-compatible fields round-trip safely.
        """
        ts_raw = obj.get("timestamp")
        ts = (
            _dt.datetime.fromisoformat(str(ts_raw).replace("Z", "+00:00"))
            if ts_raw
            else _dt.datetime.now(tz=_dt.UTC)
        )
        details: dict[str, Any] = dict(obj.get("details") or {})
        known = {"timestamp", "action", "app", "ok", "details"}
        for key, value in obj.items():
            if key not in known:
                details.setdefault(key, value)
        return cls(
            timestamp=ts,
            action=str(obj.get("action", "")),
            app=(str(obj["app"]) if obj.get("app") is not None else None),
            ok=bool(obj.get("ok", True)),
            details=details,
        )

    def to_json(self) -> dict[str, Any]:
        """Serialize back to a JSON-ready dict (inverse of :meth:`from_json`)."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "action": self.action,
            "app": self.app,
            "ok": self.ok,
            "details": dict(self.details),
        }


class Journal:
    """Append-only JSONL audit log.

    Construct directly via :class:`Journal(path=...)`, or via
    :meth:`Journal.default` to honor the ``ARR_PY_JOURNAL_PATH`` environment
    variable (falling back to ``~/.arr-py-client/journal.jsonl``).
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).expanduser()

    @classmethod
    def default(cls) -> Journal:
        """Construct a Journal at ``$ARR_PY_JOURNAL_PATH`` or the fallback path."""
        return cls(os.environ.get(_DEFAULT_PATH_ENV, _DEFAULT_FALLBACK))

    def append(
        self,
        action: str,
        *,
        app: str | None = None,
        ok: bool = True,
        details: dict[str, Any] | None = None,
        timestamp: _dt.datetime | None = None,
    ) -> JournalEntry:
        """Write one entry to the journal. Creates parent dirs if missing."""
        entry = JournalEntry(
            timestamp=timestamp or _dt.datetime.now(tz=_dt.UTC),
            action=action,
            app=app,
            ok=ok,
            details=dict(details or {}),
        )
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry.to_json(), separators=(",", ":")) + "\n")
        return entry

    def iter(
        self,
        *,
        since: _dt.datetime | None = None,
        until: _dt.datetime | None = None,
        action: str | None = None,
        app: str | None = None,
        limit: int | None = None,
    ) -> Iterator[JournalEntry]:
        """Yield filtered entries in write order.

        ``action`` is a prefix match so e.g. ``action="config_sync"`` catches
        both ``config_sync.apply`` and ``config_sync.plan``. All filters
        combine with AND.
        """
        if not self.path.exists():
            return
        yielded = 0
        with self.path.open(encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    raw = json.loads(line)
                except json.JSONDecodeError:
                    # Tolerate junk lines rather than blowing up mid-iterate.
                    continue
                if not isinstance(raw, dict):
                    continue
                entry = JournalEntry.from_json(cast("dict[str, Any]", raw))
                if since is not None and entry.timestamp < since:
                    continue
                if until is not None and entry.timestamp > until:
                    continue
                if action is not None and not entry.action.startswith(action):
                    continue
                if app is not None and entry.app != app:
                    continue
                yield entry
                yielded += 1
                if limit is not None and yielded >= limit:
                    return

    def list(self, **kwargs: Any) -> list[JournalEntry]:
        """Eager-list variant of :meth:`iter`."""
        return list(self.iter(**kwargs))

    def count(self, **kwargs: Any) -> int:
        """Count matching entries without materializing the list."""
        return sum(1 for _ in self.iter(**kwargs))

    def truncate(self) -> None:
        """Delete the journal file. Irreversible."""
        if self.path.exists():
            self.path.unlink()


__all__ = ["Journal", "JournalEntry"]
