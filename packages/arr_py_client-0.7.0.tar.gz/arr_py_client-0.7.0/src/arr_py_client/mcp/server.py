"""Build an MCP server exposing curated Radarr/Sonarr/Prowlarr operations as tools.

Every list/get tool returns ``{"data": ..., "_meta": {fields_mode, resource[, hint]}}``.
``fields`` accepts ``"summary"`` (default for lists) | ``"all"`` (default for
single-record gets) | comma-separated subset like ``"id,title,year"``.

When ``fields="summary"``, the ``_meta.hint`` tells the calling LLM how to ask
for more — either ``fields='all'`` or via :func:`arr_describe_fields`.

Paged tools take ``limit`` (max records to return, default 20) and ``offset``
(records to skip, default 0). They return ``_meta.total`` and
``_meta.next_offset`` (``None`` when there are no more rows). ``offset`` is
rounded down to the nearest ``limit`` boundary because the upstream API is
page-based.

Tool implementations live in :mod:`arr_py_client.mcp.tools`, split by group:
one module per brand (``radarr``, ``sonarr``, ``prowlarr``) plus ``composed``
(cross-brand ``arr_*`` tools) and ``describe`` (reference/metadata tools).
This module is only the orchestrator — :func:`build_server` stitches them
together and :func:`make_clients` constructs async clients from env.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from mcp.server.fastmcp import FastMCP

from arr_py_client import AsyncProwlarrClient, AsyncRadarrClient, AsyncSonarrClient
from arr_py_client.mcp.tools import (
    attach_composed_tools,
    attach_describe_tool,
    attach_prowlarr_tools,
    attach_radarr_tools,
    attach_sonarr_tools,
)

if TYPE_CHECKING:
    from arr_py_client.agent import Agent
    from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1
    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3
    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3


def build_server(
    *,
    radarr: AsyncRadarrClientV3 | None = None,
    sonarr: AsyncSonarrClientV3 | None = None,
    prowlarr: AsyncProwlarrClientV1 | None = None,
    journal: Any | None = None,
    agent: Agent | None = None,
    name: str = "arr-py-client",
) -> FastMCP:
    """Build a FastMCP server with the requested clients attached as tools.

    At least one of ``radarr``, ``sonarr``, or ``prowlarr`` must be supplied.

    Pass ``journal=`` (:class:`arr_py_client.journal.Journal`) to enable
    persistent audit logging of every mutating composed tool
    (``arr_sync_apply``, ``arr_janitor_run``, ``arr_bulk_edit``, etc.). The
    ``arr_journal_list`` tool reads from the same Journal. If omitted, the
    journal falls back to :meth:`Journal.default` which honors
    ``$ARR_PY_JOURNAL_PATH``.

    Pass ``agent=`` (:class:`arr_py_client.agent.Agent`) to expose read-only
    agent-introspection tools (``arr_agent_status``, ``arr_agent_preview``).
    The agent's own clients and journal are used — the MCP server doesn't
    drive its rules. If you want the agent to tick on MCP call, wrap
    ``agent.tick()`` in your own tool.
    """
    if radarr is None and sonarr is None and prowlarr is None:
        msg = "build_server requires at least one of radarr=, sonarr=, or prowlarr="
        raise ValueError(msg)
    server = FastMCP(name)
    if radarr is not None:
        attach_radarr_tools(server, radarr)
    if sonarr is not None:
        attach_sonarr_tools(server, sonarr)
    if prowlarr is not None:
        attach_prowlarr_tools(server, prowlarr)
    attach_composed_tools(
        server, radarr=radarr, sonarr=sonarr, prowlarr=prowlarr, journal=journal
    )
    attach_describe_tool(server, journal=journal, agent=agent)
    return server


def make_clients(
    *,
    want_radarr: bool,
    want_sonarr: bool,
    want_prowlarr: bool = False,
) -> tuple[
    AsyncRadarrClientV3 | None,
    AsyncSonarrClientV3 | None,
    AsyncProwlarrClientV1 | None,
]:
    """Construct async clients from environment settings."""
    r: AsyncRadarrClientV3 | None = None
    s: AsyncSonarrClientV3 | None = None
    p: AsyncProwlarrClientV1 | None = None
    if want_radarr:
        r = AsyncRadarrClient()
    if want_sonarr:
        s = AsyncSonarrClient()
    if want_prowlarr:
        p = AsyncProwlarrClient()
    return r, s, p
