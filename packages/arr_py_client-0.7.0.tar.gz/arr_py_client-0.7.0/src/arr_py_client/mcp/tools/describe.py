"""Reference/metadata + journal + agent-introspection tools.

Reference tools (``arr_describe_fields``, ``arr_list_resources``)
intentionally omit ``_meta.action_hints`` — they return schema metadata, not
data to pivot on. The hint-uniformity test excludes them by name.

``arr_journal_list`` reads from the Journal wired into ``build_server``, or
:meth:`Journal.default` if none was supplied (which honors
``$ARR_PY_JOURNAL_PATH``).

Agent tools (``arr_agent_status``, ``arr_agent_preview``) are exposed only
when ``build_server(agent=...)`` wires an :class:`arr_py_client.agent.Agent`
instance. They're deliberately read-only — no ``arr_agent_tick`` — so an LLM
prompt-injection attack through this surface can't trigger mutations
outside the rules the operator already declared.
"""

# pyright: reportUnusedFunction=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client.mcp.projection import RESOURCE_REGISTRY, describe

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.agent import Agent


def attach_describe_tool(
    server: FastMCP,
    *,
    journal: Any | None = None,
    agent: Agent | None = None,
) -> None:
    @server.tool()
    async def arr_describe_fields(resource: str) -> dict[str, Any]:
        """Return ``{resource, all, summary}`` field names for a resource model.

        ``resource`` is the dotted name like ``"radarr.movie"``, ``"sonarr.series"``,
        ``"radarr.queue"``. Call this when you need to pass a custom comma-list to
        another tool's ``fields=`` arg. Use :func:`arr_list_resources` to discover
        valid resource names.
        """
        return describe(resource)

    @server.tool()
    async def arr_list_resources() -> list[str]:
        """List all dotted-name resource identifiers known to ``arr_describe_fields``."""
        return sorted(RESOURCE_REGISTRY.keys())

    @server.tool()
    async def arr_journal_list(
        action: str | None = None,
        app: str | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """List recent audit-log entries from the action journal.

        The journal records every mutating composed tool (``arr_sync_apply``,
        ``arr_janitor_run``, ``arr_bulk_edit``) when a ``Journal`` is wired
        into ``build_server()`` or ``$ARR_PY_JOURNAL_PATH`` is set.
        ``action`` is a prefix match (``"config_sync"`` catches both
        ``config_sync.apply`` and future ``config_sync.plan`` entries); ``app``
        narrows to one brand. Entries return in write order (oldest first).
        """
        from arr_py_client.journal import Journal

        j = journal if journal is not None else Journal.default()
        entries = j.list(action=action, app=app, limit=limit)
        return {
            "data": [e.to_json() for e in entries],
            "_meta": {
                "count": len(entries),
                "path": str(j.path),
            },
        }

    if agent is None:
        return

    @server.tool()
    async def arr_agent_status() -> dict[str, Any]:
        """Snapshot of every agent rule: last-run, next-due, enabled state.

        Read-only: no side effects, no budget side-check, no tick. Use this
        to answer "when does my janitor run next" or "why hasn't the
        backfill fired" without touching the server.
        """
        statuses = agent.status()
        return {
            "data": [
                {
                    "rule_name": s.rule_name,
                    "enabled": s.enabled,
                    "every_seconds": s.every_seconds,
                    "last_run_at": (
                        s.last_run_at.isoformat() if s.last_run_at else None
                    ),
                    "next_due_at": (
                        s.next_due_at.isoformat() if s.next_due_at else None
                    ),
                    "due_now": s.due_now,
                }
                for s in statuses
            ],
            "_meta": {"count": len(statuses)},
        }

    @server.tool()
    async def arr_agent_preview(rule_name: str) -> dict[str, Any]:
        """Dry-run one rule and return what it would do. No mutations.

        Bypasses cadence and budget so operators can ask "what would the
        janitor remove right now?" even if the rule isn't due yet. The
        underlying primitives (``queue.janitor``, ``library.backfill``, …)
        all honor ``dry_run=True``, so the call is safe.
        """
        try:
            report = await agent.preview(rule_name)
        except KeyError as exc:
            return {
                "ok": False,
                "error": str(exc),
                "_meta": {
                    "action_hints": ["arr_agent_status()"],
                },
            }
        return {
            "ok": report.ok,
            "rule_name": report.rule_name,
            "ran": report.ran,
            "action": report.action,
            "summary": report.summary,
            "details": report.details,
            "skipped_reason": report.skipped_reason,
            "_meta": {
                "action_hints": [
                    "arr_agent_status()",
                    "arr_journal_list(action='agent')",
                ],
            },
        }
