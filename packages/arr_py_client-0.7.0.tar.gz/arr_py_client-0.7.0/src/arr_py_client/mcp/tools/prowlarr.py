"""Prowlarr brand-specific MCP tools (8 tools, ``prowlarr_*`` prefix)."""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client._common.pagination import align_offset_to_page
from arr_py_client.mcp.tools._shared import run_paged, wrap

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1


def attach_prowlarr_tools(server: FastMCP, client: AsyncProwlarrClientV1) -> None:
    @server.tool()
    async def prowlarr_ping() -> dict[str, Any]:
        """Verify Prowlarr is reachable."""
        await client.ping()
        return {"ok": True}

    @server.tool()
    async def prowlarr_system_status(fields: str = "summary") -> dict[str, Any]:
        """Get Prowlarr system status. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.system.list_status(),
            fields=fields,
            resource="prowlarr.system",
            hints=["arr_health()"],
        )

    @server.tool()
    async def prowlarr_indexers_list(fields: str = "summary") -> dict[str, Any]:
        """List every configured Prowlarr indexer. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.indexers.list(),
            fields=fields,
            resource="prowlarr.indexer",
            hints=[
                "prowlarr_indexer_test_all()",
                "prowlarr_apps_list()",
            ],
        )

    @server.tool()
    async def prowlarr_indexer_test_all() -> dict[str, Any]:
        """Fire Prowlarr's "test all indexers" action (returns once complete)."""
        await client.indexers.test_all()
        return {
            "ok": True,
            "_meta": {"action_hints": ["prowlarr_indexers_list()"]},
        }

    @server.tool()
    async def prowlarr_apps_list(fields: str = "summary") -> dict[str, Any]:
        """List registered applications (downstream Radarr/Sonarr/Lidarr/…). ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.applications.list(),
            fields=fields,
            resource="prowlarr.application",
            hints=["prowlarr_app_test_all()"],
        )

    @server.tool()
    async def prowlarr_app_test_all() -> dict[str, Any]:
        """Test connectivity/auth to every registered application."""
        await client.applications.test_all()
        return {
            "ok": True,
            "_meta": {"action_hints": ["prowlarr_apps_list()"]},
        }

    @server.tool()
    async def prowlarr_history_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Prowlarr history (search + grab events). ``fields``: ``summary`` | ``all`` | comma-list."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.history.list_(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="prowlarr.history",
            hints=["prowlarr_system_status()"],
        )

    @server.tool()
    async def prowlarr_logs_list(
        limit: int = 20,
        offset: int = 0,
        level: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """One page of Prowlarr's system log. ``level``: ``Info|Warn|Error|Fatal|Debug|Trace``."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.log.list_(page=page, page_size=size, level=level),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="prowlarr.log",
            hints=["prowlarr_system_status()"],
        )
