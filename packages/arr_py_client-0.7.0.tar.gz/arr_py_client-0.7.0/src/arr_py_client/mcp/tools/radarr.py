"""Radarr brand-specific MCP tools (18 tools, ``radarr_*`` prefix)."""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client._common.pagination import align_offset_to_page
from arr_py_client.mcp.tools._shared import (
    release_body,
    run_paged,
    wrap,
)

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3


def attach_radarr_tools(server: FastMCP, client: AsyncRadarrClientV3) -> None:
    @server.tool()
    async def radarr_ping() -> dict[str, Any]:
        """Verify Radarr is reachable. Returns ``{"ok": true}`` on success."""
        await client.ping()
        return {"ok": True}

    @server.tool()
    async def radarr_system_status(fields: str = "summary") -> dict[str, Any]:
        """Get Radarr system status. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.system.list_status(),
            fields=fields,
            resource="radarr.system",
            hints=["arr_health()", "radarr_log_list(level='Error')"],
        )

    @server.tool()
    async def radarr_movies_list(fields: str = "summary") -> dict[str, Any]:
        """List every movie. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.movies.list(),
            fields=fields,
            resource="radarr.movie",
            hints=[
                "radarr_movies_get(movie_id=...)",
                "arr_find_release(title=..., app='radarr')",
            ],
        )

    @server.tool()
    async def radarr_movies_get(movie_id: int, fields: str = "all") -> dict[str, Any]:
        """Get one Radarr movie by id. ``fields`` defaults to ``all``."""
        return wrap(
            await client.movies.get(id=movie_id),
            fields=fields,
            resource="radarr.movie",
            hints=[
                "arr_find_release(title=..., app='radarr')",
                f"radarr_command_post(name='MoviesSearch', body={{'movieIds':[{movie_id}]}})",
            ],
        )

    @server.tool()
    async def radarr_movies_lookup(
        term: str, fields: str = "summary"
    ) -> dict[str, Any]:
        """Search TMDB via Radarr's lookup proxy."""
        return wrap(
            await client.movies.lookup(term=term),
            fields=fields,
            resource="radarr.movie",
            hints=["arr_add(title=..., app='radarr')"],
        )

    @server.tool()
    async def radarr_queue_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of the Radarr queue. ``offset`` is page-boundary aligned."""
        page, size, aligned = align_offset_to_page(offset, limit)
        result = await run_paged(
            client.queue.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.queue",
        )
        result["_meta"]["action_hints"] = [
            "arr_cleanup_queue(app='radarr', dry_run=True)",
            "radarr_blocklist_list()",
        ]
        return result

    @server.tool()
    async def radarr_history_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Radarr history. ``offset`` is page-boundary aligned."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.history.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.history",
            hints=[
                "radarr_blocklist_list()",
                "arr_cleanup_queue(app='radarr', dry_run=True)",
            ],
        )

    @server.tool()
    async def radarr_command_post(
        name: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Send a Radarr command (e.g. ``"MoviesSearch"``, ``"RefreshMovie"``)."""
        result = await client.commands.post(name=name, **(body or {}))
        return wrap(
            result,
            fields="all",
            resource="radarr.command",
            hints=["radarr_system_status()", "radarr_log_list(level='Error')"],
        )

    @server.tool()
    async def radarr_tags_list(fields: str = "summary") -> dict[str, Any]:
        """List Radarr tags."""
        return wrap(
            await client.tags.list(),
            fields=fields,
            resource="radarr.tag",
            hints=["radarr_movies_list(fields='id,title,tags')"],
        )

    @server.tool()
    async def radarr_blocklist_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Radarr's blocklist."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.blocklist.list_(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.blocklist",
            hints=["radarr_blocklist_delete(blocklist_id=...)"],
        )

    @server.tool()
    async def radarr_blocklist_delete(blocklist_id: int) -> dict[str, Any]:
        """Remove a single blocklist entry."""
        await client.blocklist.delete_by_id(blocklist_id)
        return {"ok": True}

    @server.tool()
    async def radarr_log_list(
        limit: int = 20,
        offset: int = 0,
        level: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """One page of Radarr's system log. ``level``: ``Info|Warn|Error|Fatal|Debug|Trace``."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.log.list_(page=page, page_size=size, level=level),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.log",
            hints=["radarr_system_status()", "arr_health()"],
        )

    @server.tool()
    async def radarr_backup_list(fields: str = "summary") -> dict[str, Any]:
        """List Radarr backups."""
        return wrap(
            await client.backup.list_(),
            fields=fields,
            resource="radarr.backup",
            hints=["radarr_backup_restore(backup_id=...)"],
        )

    @server.tool()
    async def radarr_backup_restore(backup_id: int) -> dict[str, Any]:
        """Restore a Radarr backup by id (Radarr will restart)."""
        await client.backup.post_restore_by_id(backup_id)
        return {"ok": True}

    @server.tool()
    async def radarr_manual_import_list(
        folder: str | None = None,
        download_id: str | None = None,
        movie_id: int | None = None,
        filter_existing_files: bool | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """Inspect importable files. Pass ``folder`` *or* ``download_id``."""
        result = await client.manual_import.list_(
            folder=folder,
            download_id=download_id,
            movie_id=movie_id,
            filter_existing_files=filter_existing_files,
        )
        return wrap(
            result,
            fields=fields,
            resource="radarr.manual_import",
            hints=["radarr_command_post(name='DownloadedMoviesScan')"],
        )

    @server.tool()
    async def radarr_rename_list(
        movie_ids: list[int] | None = None, fields: str = "summary"
    ) -> dict[str, Any]:
        """Preview rename suggestions for given movies (``None`` = entire library)."""
        result = await client.rename_movie.list_(movie_id=movie_ids)
        return wrap(
            result,
            fields=fields,
            resource="radarr.rename",
            hints=["radarr_command_post(name='RenameMovie', body={'movieIds':[...]})"],
        )

    @server.tool()
    async def radarr_release_push(
        title: str,
        download_url: str,
        protocol: str = "torrent",
        publish_date: str | None = None,
        size: int | None = None,
        indexer: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """Push a release to Radarr's grabber. ``protocol``: ``torrent`` or ``usenet``."""
        from arr_py_client.radarr.v3._generated import models as r_models

        body = release_body(
            r_models,
            title=title,
            downloadUrl=download_url,
            protocol=protocol,
            publishDate=publish_date,
            size=size,
            indexer=indexer,
        )
        return wrap(
            await client.release_push.create(body=body),
            fields=fields,
            resource="radarr.release",
            hints=["radarr_queue_list()", "radarr_history_list()"],
        )

    @server.tool()
    async def radarr_download_clients_list(fields: str = "summary") -> dict[str, Any]:
        """List configured Radarr download clients."""
        return wrap(
            await client.download_clients.list(),
            fields=fields,
            resource="radarr.download_client",
            hints=["arr_health()"],
        )
