"""Sonarr brand-specific MCP tools (18 tools, ``sonarr_*`` prefix)."""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client._common.pagination import align_offset_to_page
from arr_py_client.mcp.tools._shared import (
    release_body,
    run_paged,
    wrap,
)

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3


def attach_sonarr_tools(server: FastMCP, client: AsyncSonarrClientV3) -> None:
    @server.tool()
    async def sonarr_ping() -> dict[str, Any]:
        """Verify Sonarr is reachable."""
        await client.ping()
        return {"ok": True}

    @server.tool()
    async def sonarr_system_status(fields: str = "summary") -> dict[str, Any]:
        """Get Sonarr system status. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.system.list_status(),
            fields=fields,
            resource="sonarr.system",
            hints=["arr_health()", "sonarr_log_list(level='Error')"],
        )

    @server.tool()
    async def sonarr_series_list(fields: str = "summary") -> dict[str, Any]:
        """List every series. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.series.list(),
            fields=fields,
            resource="sonarr.series",
            hints=[
                "sonarr_series_get(series_id=...)",
                "arr_find_release(title=..., app='sonarr')",
            ],
        )

    @server.tool()
    async def sonarr_series_get(series_id: int, fields: str = "all") -> dict[str, Any]:
        """Get one Sonarr series by id. ``fields`` defaults to ``all``."""
        return wrap(
            await client.series.get(id=series_id),
            fields=fields,
            resource="sonarr.series",
            hints=[
                f"sonarr_episodes_list(series_id={series_id})",
                "arr_find_release(title=..., app='sonarr')",
            ],
        )

    @server.tool()
    async def sonarr_series_lookup(
        term: str, fields: str = "summary"
    ) -> dict[str, Any]:
        """Search TVDB via Sonarr's lookup proxy. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.series.lookup(term=term),
            fields=fields,
            resource="sonarr.series",
            hints=["arr_add(title=..., app='sonarr')"],
        )

    @server.tool()
    async def sonarr_episodes_list(
        series_id: int, fields: str = "summary"
    ) -> dict[str, Any]:
        """List episodes for a series. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.episodes.list(series_id=series_id),
            fields=fields,
            resource="sonarr.episode",
            hints=[
                "arr_find_release(title=..., app='sonarr', episode_id=...)",
                "arr_explain_grab(title=..., app='sonarr', episode_id=...)",
            ],
        )

    @server.tool()
    async def sonarr_queue_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of the Sonarr queue. ``offset`` is page-boundary aligned."""
        page, size, aligned = align_offset_to_page(offset, limit)
        result = await run_paged(
            client.queue.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.queue",
        )
        result["_meta"]["action_hints"] = [
            "arr_cleanup_queue(app='sonarr', dry_run=True)",
            "sonarr_blocklist_list()",
        ]
        return result

    @server.tool()
    async def sonarr_history_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Sonarr history. ``offset`` is page-boundary aligned. ``fields``: ``summary`` | ``all`` | comma-list."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.history.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.history",
            hints=[
                "sonarr_blocklist_list()",
                "arr_cleanup_queue(app='sonarr', dry_run=True)",
            ],
        )

    @server.tool()
    async def sonarr_command_post(
        name: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Send a Sonarr command (e.g. ``"SeriesSearch"``, ``"RefreshSeries"``)."""
        result = await client.commands.post(name=name, **(body or {}))
        return wrap(
            result,
            fields="all",
            resource="sonarr.command",
            hints=["sonarr_system_status()", "sonarr_log_list(level='Error')"],
        )

    @server.tool()
    async def sonarr_blocklist_list(
        limit: int = 20, offset: int = 0, fields: str = "summary"
    ) -> dict[str, Any]:
        """One page of Sonarr's blocklist. ``fields``: ``summary`` | ``all`` | comma-list."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.blocklist.list_(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.blocklist",
            hints=["sonarr_command_post(name='ClearBlocklist')"],
        )

    @server.tool()
    async def sonarr_log_list(
        limit: int = 20,
        offset: int = 0,
        level: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """One page of Sonarr's system log. ``level``: ``Info|Warn|Error|Fatal|Debug|Trace``."""
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.log.list_(page=page, page_size=size, level=level),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.log",
            hints=["sonarr_system_status()", "arr_health()"],
        )

    @server.tool()
    async def sonarr_backup_list(fields: str = "summary") -> dict[str, Any]:
        """List Sonarr backups. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.backup.list_(),
            fields=fields,
            resource="sonarr.backup",
            hints=["sonarr_backup_restore(backup_id=...)"],
        )

    @server.tool()
    async def sonarr_backup_restore(backup_id: int) -> dict[str, Any]:
        """Restore a Sonarr backup by id (Sonarr will restart)."""
        await client.backup.post_restore_by_id(backup_id)
        return {"ok": True}

    @server.tool()
    async def sonarr_manual_import_list(
        folder: str | None = None,
        download_id: str | None = None,
        series_id: int | None = None,
        filter_existing_files: bool | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """Inspect importable files. Pass ``folder`` *or* ``download_id``."""
        result = await client.manual_import.list_(
            folder=folder,
            download_id=download_id,
            series_id=series_id,
            filter_existing_files=filter_existing_files,
        )
        return wrap(
            result,
            fields=fields,
            resource="sonarr.manual_import",
            hints=["sonarr_command_post(name='DownloadedEpisodesScan')"],
        )

    @server.tool()
    async def sonarr_rename_list(
        series_id: int, season_number: int | None = None, fields: str = "summary"
    ) -> dict[str, Any]:
        """Preview rename suggestions for a series. ``season_number`` scopes to one season."""
        result = await client.rename_episode.list_(
            series_id=series_id, season_number=season_number
        )
        return wrap(
            result,
            fields=fields,
            resource="sonarr.rename",
            hints=[
                f"sonarr_command_post(name='RenameSeries', body={{'seriesIds':[{series_id}]}})",
            ],
        )

    @server.tool()
    async def sonarr_release_push(
        title: str,
        download_url: str,
        protocol: str = "torrent",
        publish_date: str | None = None,
        size: int | None = None,
        indexer: str | None = None,
        fields: str = "summary",
    ) -> dict[str, Any]:
        """Push a release to Sonarr's grabber. ``protocol``: ``torrent`` or ``usenet``."""
        from arr_py_client.sonarr.v3._generated import models as s_models

        body = release_body(
            s_models,
            title=title,
            downloadUrl=download_url,
            protocol=protocol,
            publishDate=publish_date,
            size=size,
            indexer=indexer,
        )
        return wrap(
            await client.release_push.create(body=body),
            fields=fields,
            resource="sonarr.release",
            hints=["sonarr_queue_list()", "sonarr_history_list()"],
        )

    @server.tool()
    async def sonarr_download_clients_list(fields: str = "summary") -> dict[str, Any]:
        """List configured Sonarr download clients. ``fields``: ``summary`` | ``all`` | comma-list."""
        return wrap(
            await client.download_clients.list(),
            fields=fields,
            resource="sonarr.download_client",
            hints=["arr_health()"],
        )
