"""Shared helpers used by every tool-attach module in ``mcp.tools``.

``wrap`` / ``paged_wrap`` / ``run_paged`` produce the standard MCP response
envelope used by data tools; ``error`` produces the composed-tool error
shape. ``release_body`` is a tiny pydantic-builder shortcut used by the
brand ``release_push`` tools.
"""

# pyright: reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol

from arr_py_client.mcp.projection import envelope, project

if TYPE_CHECKING:
    from collections.abc import Awaitable


class Paging(Protocol):
    records: list[Any] | None
    total_records: int | None


def wrap(
    value: Any,
    *,
    fields: str,
    resource: str,
    hints: list[str] | None = None,
) -> dict[str, Any]:
    """Project + envelope shorthand.

    When ``hints`` is non-empty, they're attached as
    ``_meta.action_hints`` — strings the calling LLM can evaluate as its
    next most-likely tool calls.
    """
    out = envelope(project(value, fields), fields=fields, resource=resource)
    if hints:
        out["_meta"]["action_hints"] = list(hints)
    return out


def paged_wrap(
    records: list[Any],
    *,
    total: int | None,
    offset: int,
    limit: int,
    fields: str,
    resource: str,
    hints: list[str] | None = None,
) -> dict[str, Any]:
    """Wrap a page of records with pagination metadata in ``_meta``.

    ``next_offset`` is ``None`` when the cursor has reached the end of the
    collection. ``total`` may be ``None`` if upstream did not report it.
    """
    out = wrap(records, fields=fields, resource=resource, hints=hints)
    out["_meta"]["total"] = total
    out["_meta"]["offset"] = offset
    out["_meta"]["limit"] = limit
    end = offset + len(records)
    has_more = total is not None and end < total
    out["_meta"]["next_offset"] = end if has_more else None
    return out


async def run_paged(
    paging_awaitable: Awaitable[Paging],
    *,
    aligned: int,
    size: int,
    fields: str,
    resource: str,
    hints: list[str] | None = None,
) -> dict[str, Any]:
    """Await a paging call and wrap the result with pagination metadata."""
    paging = await paging_awaitable
    records = list(paging.records or [])
    return paged_wrap(
        records,
        total=paging.total_records,
        offset=aligned,
        limit=size,
        fields=fields,
        resource=resource,
        hints=hints,
    )


def release_body(models: Any, **fields: Any) -> Any:
    """Build a validated ``ReleaseResource`` from flat kwargs.

    ``models`` is the brand-specific generated ``models`` module; the field
    names follow the upstream camelCase schema.
    """
    return models.ReleaseResource.model_validate(fields)


def error(message: str, *, hints: list[str] | None = None) -> dict[str, Any]:
    """Composed-tool error response with recovery hints in ``_meta``.

    Error paths benefit from ``action_hints`` more than happy paths do — they
    give the LLM caller an obvious next step instead of surfacing a dead-end.
    """
    return {
        "ok": False,
        "error": message,
        "_meta": {"action_hints": list(hints or [])},
    }
