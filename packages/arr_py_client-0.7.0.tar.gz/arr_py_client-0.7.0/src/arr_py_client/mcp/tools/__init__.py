"""Per-group tool-attach helpers consumed by :func:`arr_py_client.mcp.build_server`.

Each module owns one tool group:

- :mod:`~.radarr` — 18 ``radarr_*`` brand tools
- :mod:`~.sonarr` — 18 ``sonarr_*`` brand tools
- :mod:`~.prowlarr` — 8 ``prowlarr_*`` brand tools
- :mod:`~.composed` — 11 cross-brand ``arr_*`` composed tools
- :mod:`~.describe` — 2 reference/metadata tools

``_shared`` holds the envelope helpers (``_wrap``, ``_paged_wrap``,
``_run_paged``) and the composed-tool error builder (``_error``).
"""

from __future__ import annotations

from arr_py_client.mcp.tools.composed import attach_composed_tools
from arr_py_client.mcp.tools.describe import attach_describe_tool
from arr_py_client.mcp.tools.prowlarr import attach_prowlarr_tools
from arr_py_client.mcp.tools.radarr import attach_radarr_tools
from arr_py_client.mcp.tools.sonarr import attach_sonarr_tools

__all__ = [
    "attach_composed_tools",
    "attach_describe_tool",
    "attach_prowlarr_tools",
    "attach_radarr_tools",
    "attach_sonarr_tools",
]
