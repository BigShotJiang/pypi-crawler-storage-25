"""Cross-brand composed MCP tools (``arr_*`` prefix).

These collapse multi-step workflows into one tool call and return structured
payloads with ``_meta.action_hints`` — the next most useful tool calls from
here — so LLMs can chain operations without guessing.
"""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

from dataclasses import asdict
from typing import TYPE_CHECKING, Any, Literal, cast

from arr_py_client.mcp.projection import project
from arr_py_client.mcp.tools._shared import error

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1
    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3
    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3


def _library_health_dict(summary: Any) -> dict[str, Any]:
    """Flatten a ``LibraryHealth`` into a JSON-ready dict for MCP payloads."""
    out = asdict(summary)
    # Flatten dataclass nested fields so LLMs don't have to navigate a tree.
    out["disks"] = [
        {
            **d,
            "free_percent": (
                round(100.0 * d["free_bytes"] / d["total_bytes"], 2)
                if d.get("free_bytes") is not None
                and d.get("total_bytes")
                and d["total_bytes"] > 0
                else None
            ),
        }
        for d in out.get("disks", [])
    ]
    return out


def attach_composed_tools(
    server: FastMCP,
    *,
    radarr: AsyncRadarrClientV3 | None,
    sonarr: AsyncSonarrClientV3 | None,
    prowlarr: AsyncProwlarrClientV1 | None = None,
    journal: Any | None = None,
) -> None:
    """Register the high-level, chat-friendly composed tools."""

    @server.tool()
    async def arr_add(
        title: str,
        app: Literal["auto", "radarr", "sonarr"] = "auto",
        quality: str | None = None,
        folder: str | None = None,
        tags: list[str] | None = None,
        monitored: bool = True,
        search_on_add: bool = True,
        if_exists: Literal["skip", "update", "error"] = "skip",
    ) -> dict[str, Any]:
        """Add a movie or series to Radarr/Sonarr by title, with name-based options.

        ``app="auto"`` uses whichever brand's lookup returns a match (Radarr
        first). ``quality`` accepts a profile name like ``"HD-1080p"`` or
        ``"4K-HDR"``. ``folder`` is a root-folder path; if omitted and only
        one is configured, it's auto-picked. ``tags`` accepts labels; missing
        ones are created. ``if_exists`` defaults to ``"skip"`` for chat safety
        — re-running the tool won't 409.
        """
        chosen_app: str | None = None
        resource: dict[str, Any] | None = None
        already_existed = False

        async def try_radarr() -> tuple[bool, dict[str, Any] | None]:
            if radarr is None:
                return False, None
            results = await radarr.movies.lookup(term=title)
            if not results:
                return False, None
            movie = await radarr.movies.add(
                title=title,
                quality=quality,
                root_folder=folder,
                tags=list(tags) if tags is not None else None,
                monitored=monitored,
                search_on_add=search_on_add,
                if_exists=if_exists,
            )
            return True, project(movie, "all")

        async def try_sonarr() -> tuple[bool, dict[str, Any] | None]:
            if sonarr is None:
                return False, None
            results = await sonarr.series.lookup(term=title)
            if not results:
                return False, None
            series = await sonarr.series.add(
                title=title,
                quality=quality,
                root_folder=folder,
                tags=list(tags) if tags is not None else None,
                monitored=monitored,
                search_on_add=search_on_add,
                if_exists=if_exists,
            )
            return True, project(series, "all")

        attempts: list[tuple[str, Any]] = []
        if app in ("auto", "radarr"):
            attempts.append(("radarr", try_radarr))
        if app in ("auto", "sonarr"):
            attempts.append(("sonarr", try_sonarr))

        errors: list[str] = []
        for brand, fn in attempts:
            try:
                hit, data = await fn()
            except Exception as exc:
                errors.append(f"{brand}: {exc}")
                continue
            if hit:
                chosen_app = brand
                resource = data
                # ``if_exists='skip'`` doesn't expose whether the row was new;
                # callers can compare ``resource.id`` against prior state.
                break

        if chosen_app is None:
            return {
                "ok": False,
                "error": f"no lookup match for {title!r}",
                "errors": errors,
                "_meta": {
                    "action_hints": [
                        "arr_list_resources()",
                        "radarr_movies_lookup(term=...)",
                        "sonarr_series_lookup(term=...)",
                    ]
                },
            }

        return {
            "ok": True,
            "app": chosen_app,
            "already_existed": already_existed,
            "data": resource,
            "_meta": {
                "action_hints": [
                    f"{chosen_app}_command_post(name='RescanMovie' | 'RescanSeries')",
                    "arr_health()",
                ],
            },
        }

    @server.tool()
    async def arr_health(
        app: Literal["both", "radarr", "sonarr", "all"] = "both",
    ) -> dict[str, Any]:
        """One-shot cross-app health dashboard.

        ``both`` covers Radarr + Sonarr (v0.4 behavior). ``all`` additionally
        includes Prowlarr — indexer + application test summary rather than
        library health, since Prowlarr has no library. Clients not configured
        at build time are silently skipped.
        """
        out: dict[str, Any] = {}
        hints: list[str] = []
        include_radarr = app in ("both", "all", "radarr")
        include_sonarr = app in ("both", "all", "sonarr")
        include_prowlarr = app in ("all",)
        if include_radarr and radarr is not None:
            summary = await radarr.library.health_summary()
            out["radarr"] = _library_health_dict(summary)
            if summary.queue.stalled > 0:
                hints.append("arr_cleanup_queue(app='radarr', dry_run=True)")
            if not summary.healthy:
                hints.append("radarr_system_status(fields='all')")
        if include_sonarr and sonarr is not None:
            summary = await sonarr.library.health_summary()
            out["sonarr"] = _library_health_dict(summary)
            if summary.queue.stalled > 0:
                hints.append("arr_cleanup_queue(app='sonarr', dry_run=True)")
            if not summary.healthy:
                hints.append("sonarr_system_status(fields='all')")
        if include_prowlarr and prowlarr is not None:
            status = await prowlarr.system.list_status()
            indexers = await prowlarr.indexers.list()
            apps = await prowlarr.applications.list()
            out["prowlarr"] = {
                "version": getattr(status, "version", None),
                "indexer_count": len(indexers),
                "application_count": len(apps),
            }
            hints.append("prowlarr_indexer_test_all()")
        out["_meta"] = {"action_hints": hints}
        return out

    @server.tool()
    async def arr_upcoming(
        days: int = 7,
        app: Literal["both", "radarr", "sonarr"] = "both",
    ) -> dict[str, Any]:
        """Upcoming (or recently aired) calendar items across one or both apps.

        ``days > 0`` returns things airing in the next N days; ``days < 0``
        returns things that aired in the last |N| days. Pulls via the
        ``/calendar`` endpoint with brand-specific filters.
        """
        from datetime import UTC, datetime, timedelta

        now = datetime.now(UTC)
        start = now if days > 0 else now + timedelta(days=days)
        end = now + timedelta(days=days) if days > 0 else now
        items: dict[str, Any] = {}
        if app in ("both", "radarr") and radarr is not None:
            radarr_items = await radarr.calendar.list(start=start, end=end)
            items["radarr"] = [project(m, "summary") for m in radarr_items]
        if app in ("both", "sonarr") and sonarr is not None:
            sonarr_items = await sonarr.calendar.list(start=start, end=end)
            items["sonarr"] = [project(e, "summary") for e in sonarr_items]
        return {
            "data": items,
            "_meta": {
                "window_days": days,
                "action_hints": [
                    "arr_health()",
                    "arr_find_release(title=..., app=...)",
                ],
            },
        }

    @server.tool()
    async def arr_find_release(
        title: str,
        app: Literal["radarr", "sonarr"],
        min_seeders: int | None = None,
        prefer_codec: str | None = None,
        limit: int = 10,
        indexers: list[int] | None = None,
        include_prowlarr: bool = False,
    ) -> dict[str, Any]:
        """Look up a title, then query indexers for candidate releases.

        Resolves ``title`` → library id via the app's lookup, then calls
        ``releases.search()`` and returns up to ``limit`` candidates sorted by
        (seeders desc, quality desc, codec match, size asc). Pass ``guid`` +
        ``indexer_id`` from a candidate to :func:`arr_grab_release`.

        ``indexers``: restrict results to these indexer ids (applied to
        Radarr/Sonarr results client-side, passed server-side to Prowlarr).
        ``include_prowlarr=True``: additionally query Prowlarr's ``/search``
        endpoint and merge results, deduped by ``guid``. Useful when one
        Prowlarr instance serves many indexers not individually mirrored
        in the brand app.
        """
        if app == "radarr":
            if radarr is None:
                return error(
                    "radarr not configured",
                    hints=["arr_health(app='all')"],
                )
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return error(
                    f"no movie lookup match for {title!r}",
                    hints=["radarr_movies_lookup(term=...)"],
                )
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == hits[0].tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return error(
                    "movie not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='radarr')"],
                )
            # cast to Any so the fan-out path can append Prowlarr releases
            # (different pydantic model, identical runtime shape).
            candidates = cast(
                "list[Any]", list(await radarr.releases.search(movie_id=target.id))
            )
        else:
            if sonarr is None:
                return error(
                    "sonarr not configured",
                    hints=["arr_health(app='all')"],
                )
            hits_s = await sonarr.series.lookup(term=title)
            if not hits_s or not hits_s[0].tvdb_id:
                return error(
                    f"no series lookup match for {title!r}",
                    hints=["sonarr_series_lookup(term=...)"],
                )
            resolved_s = await sonarr.series.list()
            target_s = next(
                (s for s in resolved_s if s.tvdb_id == hits_s[0].tvdb_id and s.id),
                None,
            )
            if target_s is None or target_s.id is None:
                return error(
                    "series not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='sonarr')"],
                )
            candidates = cast(
                "list[Any]",
                list(await sonarr.releases.search(series_id=target_s.id)),
            )

        # Subset filter on brand results (client-side — their endpoints don't
        # accept an indexer filter).
        if indexers is not None:
            indexer_ids = set(indexers)
            candidates = [
                c for c in candidates if getattr(c, "indexer_id", None) in indexer_ids
            ]

        # Optional fan-out to Prowlarr: merge extra candidates, dedupe by guid.
        prowlarr_added = 0
        if include_prowlarr and prowlarr is not None:
            prowlarr_raw = await prowlarr.search.list_(
                query=title, indexer_ids=list(indexers) if indexers else None
            )
            known_guids = {str(getattr(c, "guid", "") or "") for c in candidates} - {""}
            for item in prowlarr_raw:
                guid = str(getattr(item, "guid", "") or "")
                if guid and guid in known_guids:
                    continue
                candidates.append(item)
                if guid:
                    known_guids.add(guid)
                prowlarr_added += 1

        if min_seeders is not None:
            candidates = [
                c
                for c in candidates
                if (getattr(c, "seeders", None) or 0) >= min_seeders
            ]

        def _k(r: Any) -> tuple[int, int, int]:
            seeders = int(getattr(r, "seeders", None) or 0)
            title_str = str(getattr(r, "title", "") or "").lower()
            codec = 1 if prefer_codec and prefer_codec.lower() in title_str else 0
            size = int(getattr(r, "size", None) or 0)
            return (-seeders, -codec, size)

        candidates.sort(key=_k)
        trimmed = candidates[:limit]
        return {
            "ok": True,
            "app": app,
            "candidates": [project(c, "summary") for c in trimmed],
            "_meta": {
                "count": len(trimmed),
                "prowlarr_added": prowlarr_added,
                "indexers_filter": list(indexers) if indexers else None,
                "action_hints": [
                    "arr_grab_release(guid=..., indexer_id=..., app=...)",
                ],
            },
        }

    @server.tool()
    async def arr_grab_release(
        guid: str,
        indexer_id: int,
        app: Literal["radarr", "sonarr"],
    ) -> dict[str, Any]:
        """Grab a specific release from :func:`arr_find_release`'s candidates.

        The release lands in the queue; poll via ``radarr_queue_list`` /
        ``sonarr_queue_list`` to track import progress.
        """
        if app == "radarr":
            if radarr is None:
                return error(
                    "radarr not configured",
                    hints=["arr_health(app='all')"],
                )
            await radarr.releases.grab(guid=guid, indexer_id=indexer_id)
        else:
            if sonarr is None:
                return error(
                    "sonarr not configured",
                    hints=["arr_health(app='all')"],
                )
            await sonarr.releases.grab(guid=guid, indexer_id=indexer_id)
        return {
            "ok": True,
            "app": app,
            "_meta": {
                "action_hints": [
                    f"{app}_queue_list()",
                    "arr_health()",
                ]
            },
        }

    @server.tool()
    async def arr_cleanup_queue(
        app: Literal["radarr", "sonarr"],
        dry_run: bool = True,
        blocklist: bool = True,
        search: bool = True,
    ) -> dict[str, Any]:
        """Find stuck downloads and (optionally) nuke + blocklist + re-search.

        **Defaults to ``dry_run=True``** for chat safety. Re-invoke with
        ``dry_run=False`` once the user confirms the plan.
        """
        if app == "radarr":
            if radarr is None:
                return error(
                    "radarr not configured",
                    hints=["arr_health(app='all')"],
                )
            result = await radarr.queue.clear_stuck(
                blocklist=blocklist, search=search, dry_run=dry_run
            )
        else:
            if sonarr is None:
                return error(
                    "sonarr not configured",
                    hints=["arr_health(app='all')"],
                )
            result = await sonarr.queue.clear_stuck(
                blocklist=blocklist, search=search, dry_run=dry_run
            )
        hints: list[str] = []
        if dry_run and result.ids:
            hints.append(f"arr_cleanup_queue(app={app!r}, dry_run=False)")
        if not result.ids:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "dry_run": result.dry_run,
            "ids": result.ids,
            "count": len(result.ids),
            "blocklisted": result.blocklisted,
            "redownload": result.redownload,
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_janitor_run(
        app: Literal["radarr", "sonarr"],
        dry_run: bool = True,
        protected_trackers: list[str] | None = None,
        bundle: Literal[
            "default", "conservative", "aggressive", "ratio_preserving"
        ] = "default",
    ) -> dict[str, Any]:
        """Policy-based queue cleanup. More flexible than :func:`arr_cleanup_queue`.

        ``bundle`` selects a named policy set (see :class:`POLICIES`):
        ``conservative`` (report-only), ``default`` (manual→ignore,
        stuck/stalled/import-blocked → blocklist+research), ``aggressive``
        (adds a >100 GiB size cap), ``ratio_preserving`` (remove without
        blocklisting so releases can reappear). Items on
        ``protected_trackers`` are additionally downgraded to IGNORE.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        from arr_py_client import POLICIES

        protected = tuple(protected_trackers or ())
        policies = getattr(POLICIES, bundle)
        if app == "radarr":
            if radarr is None:
                return error(
                    "radarr not configured",
                    hints=["arr_health(app='all')"],
                )
            report = await radarr.queue.janitor(
                policies=policies,
                dry_run=dry_run,
                protected_trackers=protected,
                journal=journal,
            )
        else:
            if sonarr is None:
                return error(
                    "sonarr not configured",
                    hints=["arr_health(app='all')"],
                )
            report = await sonarr.queue.janitor(
                policies=policies,
                dry_run=dry_run,
                protected_trackers=protected,
                journal=journal,
            )
        hints: list[str] = []
        if dry_run and report.total_matches:
            hints.append(f"arr_janitor_run(app={app!r}, dry_run=False)")
        if not report.total_matches:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "dry_run": report.dry_run,
            "total_matches": report.total_matches,
            "protected_skips": report.protected_skips,
            "executed_blocklist_ids": report.executed_blocklist_ids,
            "executed_remove_ids": report.executed_remove_ids,
            "matches": [
                {
                    "id": m.item_id,
                    "title": m.item_title,
                    "policy": m.policy_name,
                    "action": m.action.value,
                    "indexer": m.indexer,
                }
                for m in report.matches
            ],
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_explain_grab(
        title: str,
        app: Literal["radarr", "sonarr"],
        episode_id: int | None = None,
        season_number: int | None = None,
    ) -> dict[str, Any]:
        """Answer "why didn't it grab the better version?" for a library item.

        Resolves ``title`` → library id, fetches all current indexer releases,
        annotates each with accept/reject + reasons, and returns a ranked
        table plus a human-readable ``summary``. For Sonarr, pass
        ``episode_id`` or ``season_number`` to scope the explanation.
        """
        if app == "radarr":
            if radarr is None:
                return error(
                    "radarr not configured",
                    hints=["arr_health(app='all')"],
                )
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return error(
                    f"no movie lookup match for {title!r}",
                    hints=["radarr_movies_lookup(term=...)"],
                )
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == hits[0].tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return error(
                    "movie not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='radarr')"],
                )
            explanation = await radarr.releases.explain(movie_id=target.id)
        else:
            if sonarr is None:
                return error(
                    "sonarr not configured",
                    hints=["arr_health(app='all')"],
                )
            hits_s = await sonarr.series.lookup(term=title)
            if not hits_s or not hits_s[0].tvdb_id:
                return error(
                    f"no series lookup match for {title!r}",
                    hints=["sonarr_series_lookup(term=...)"],
                )
            resolved_s = await sonarr.series.list()
            target_s = next(
                (s for s in resolved_s if s.tvdb_id == hits_s[0].tvdb_id and s.id),
                None,
            )
            if target_s is None or target_s.id is None:
                return error(
                    "series not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='sonarr')"],
                )
            explanation = await sonarr.releases.explain(
                series_id=target_s.id,
                episode_id=episode_id,
                season_number=season_number,
            )
        hints = (
            [f"arr_grab_release(guid=..., indexer_id=..., app={app!r})"]
            if explanation.accepted
            else ["arr_health()"]
        )
        return {
            "ok": True,
            "app": app,
            "item_id": explanation.item_id,
            "item_title": explanation.item_title,
            "current_quality": explanation.current_quality,
            "current_custom_format_score": explanation.current_custom_format_score,
            "summary": explanation.summary(),
            "advice": explanation.advice(),
            "verdicts": [
                {
                    "title": v.title,
                    "indexer": v.indexer,
                    "quality": v.quality,
                    "quality_weight": v.quality_weight,
                    "custom_format_score": v.custom_format_score,
                    "size": v.size,
                    "seeders": v.seeders,
                    "age_hours": v.age_hours,
                    "languages": v.languages,
                    "release_group": v.release_group,
                    "status": v.status,
                    "rejections": v.rejections,
                    "guid": v.guid,
                    "indexer_id": v.indexer_id,
                }
                for v in explanation.verdicts
            ],
            "_meta": {
                "accepted_count": len(explanation.accepted),
                "rejected_count": len(explanation.rejected),
                "action_hints": hints,
            },
        }

    @server.tool()
    async def arr_backfill(
        app: Literal["radarr", "sonarr"],
        source: Literal["missing", "cutoff_unmet", "both"] = "missing",
        batch_size: int | None = None,
        delay_between_batches: float = 30.0,
        max_items: int | None = None,
        pause_if_queue_over: int | None = None,
        monitored_only: bool = True,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Rate-limited safe missing-content search loop (Huntarr-shaped).

        Walks ``/wanted/missing`` (or ``/cutoff``, or both), batches IDs, and
        fires ``MoviesSearch`` (Radarr) / ``EpisodeSearch`` (Sonarr) with a
        delay between batches. ``pause_if_queue_over=N`` short-circuits when
        the download queue already has more than N items.

        **Defaults to ``dry_run=True``** for chat safety — re-invoke with
        ``dry_run=False`` to actually fire search commands. Default
        ``batch_size`` is 5 (Radarr) / 20 (Sonarr) per brand convention.
        """
        effective_batch = (
            batch_size if batch_size is not None else (5 if app == "radarr" else 20)
        )
        if app == "radarr":
            if radarr is None:
                return error(
                    "radarr not configured",
                    hints=["arr_health(app='all')"],
                )
            report = await radarr.library.backfill(
                source=source,
                batch_size=effective_batch,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=dry_run,
                journal=journal,
            )
        else:
            if sonarr is None:
                return error(
                    "sonarr not configured",
                    hints=["arr_health(app='all')"],
                )
            report = await sonarr.library.backfill(
                source=source,
                batch_size=effective_batch,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=dry_run,
                journal=journal,
            )
        from arr_py_client._common.backfill import estimate as _estimate

        hints: list[str] = []
        if dry_run and report.searched_count:
            hints.append(f"arr_backfill(app={app!r}, dry_run=False)")
        if report.stopped_reason == "queue_saturated":
            hints.append(f"{app}_queue_list()")
        est = _estimate(
            report.searched_count,
            batch_size=effective_batch,
            delay_between_batches=delay_between_batches,
        )
        return {
            "ok": True,
            "app": app,
            "source": report.source,
            "dry_run": report.dry_run,
            "searched_count": report.searched_count,
            "batches_sent": report.batches_sent,
            "stopped_reason": report.stopped_reason.value,
            "queue_checks": report.queue_checks,
            "searched_ids": report.searched_ids,
            "_meta": {
                "action_hints": hints,
                "estimate": {
                    "batches": est.batches,
                    "duration_seconds": int(est.duration.total_seconds()),
                    "eta_iso": est.eta.isoformat(),
                    "summary": est.summary(),
                },
            },
        }

    @server.tool()
    async def arr_sync_plan(
        app: Literal["radarr", "sonarr"],
        desired: dict[str, Any],
        strict: bool = False,
    ) -> dict[str, Any]:
        """Preview config-sync changes: diff ``desired`` against the live server.

        ``desired`` keys (all optional): ``tags`` (list of names),
        ``custom_formats`` (map name → spec), ``quality_profiles`` (map name
        → profile). ``strict=True`` adds DELETE actions for items on the
        server but not in ``desired`` — always preview before applying.

        Returns a list of planned actions with no mutations. Pair with
        :func:`arr_sync_apply` to execute.
        """
        from arr_py_client.config_sync import plan_async as _plan_async

        client = radarr if app == "radarr" else sonarr
        if client is None:
            return error(
                f"{app} not configured",
                hints=["arr_health(app='all')"],
            )
        plan_ = await _plan_async(client, desired, strict=strict)
        hints: list[str] = []
        if plan_.changes:
            hints.append(f"arr_sync_apply(app={app!r}, desired=..., dry_run=False)")
        else:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "strict": plan_.strict,
            "is_noop": plan_.is_noop,
            "summary": plan_.summary(),
            "changes": [
                {
                    "resource": c.resource,
                    "name": c.name,
                    "action": c.action,
                    "existing_id": c.existing_id,
                    "detail": c.detail,
                }
                for c in plan_.changes
            ],
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_sync_apply(
        app: Literal["radarr", "sonarr"],
        desired: dict[str, Any],
        strict: bool = False,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Plan + apply a config-sync desired state. **Defaults to ``dry_run=True``.**

        Runs :func:`arr_sync_plan` internally, then applies every change
        (unless ``dry_run``). Per-change errors are captured in the report
        rather than aborting — one broken custom-format doesn't block the
        others.
        """
        from arr_py_client.config_sync import apply_async as _apply_async
        from arr_py_client.config_sync import plan_async as _plan_async

        client = radarr if app == "radarr" else sonarr
        if client is None:
            return error(
                f"{app} not configured",
                hints=["arr_health(app='all')"],
            )
        plan_ = await _plan_async(client, desired, strict=strict)
        report = await _apply_async(client, plan_, dry_run=dry_run, journal=journal)
        hints: list[str] = []
        if dry_run and plan_.changes:
            hints.append(f"arr_sync_apply(app={app!r}, desired=..., dry_run=False)")
        if report.errors:
            hints.append("arr_list_resources()")
        return {
            "ok": not report.errors,
            "app": app,
            "dry_run": report.dry_run,
            "summary": plan_.summary(),
            "applied_count": len(report.applied),
            "skipped_count": len(report.skipped),
            "error_count": len(report.errors),
            "applied": [
                {"resource": c.resource, "name": c.name, "action": c.action}
                for c in report.applied
            ],
            "errors": [
                {
                    "resource": c.resource,
                    "name": c.name,
                    "action": c.action,
                    "error": err,
                }
                for c, err in report.errors
            ],
            "_meta": {"action_hints": hints},
        }

    @server.tool()
    async def arr_sync_dump(
        app: Literal["radarr", "sonarr", "prowlarr"],
        include: list[str] | None = None,
    ) -> dict[str, Any]:
        """Serialize live server state into the dict shape ``arr_sync_plan`` consumes.

        Round-trip: ``arr_sync_dump()`` → edit → ``arr_sync_apply()``. Useful
        for bootstrapping a config.yaml from a prod server, or for
        side-by-side comparisons. ``include`` narrows the scope (e.g.
        ``["tags", "quality_profiles"]``); ``None`` dumps every supported
        resource the brand exposes.
        """
        from arr_py_client.config_sync import dump_async as _dump_async

        client = radarr if app == "radarr" else sonarr if app == "sonarr" else prowlarr
        if client is None:
            return error(
                f"{app} not configured",
                hints=["arr_health(app='all')"],
            )
        # ``include`` is ``list[str]`` from the MCP wire format; the function
        # expects the ``Resource`` literal type. Unknown names fall through as
        # silently-skipped scope entries inside ``dump_async``.
        scope = cast("list[Any] | None", list(include) if include else None)
        dumped = await _dump_async(client, include=scope)
        counts: dict[str, int] = {}
        for k, v in dumped.items():
            if isinstance(v, list):
                counts[k] = len(cast("list[Any]", v))
            elif isinstance(v, dict):
                counts[k] = len(cast("dict[str, Any]", v))
            else:
                counts[k] = 1
        return {
            "ok": True,
            "app": app,
            "data": dumped,
            "_meta": {
                "resource_counts": counts,
                "action_hints": [
                    f"arr_sync_plan(app={app!r}, desired=<dumped>)",
                ],
            },
        }

    @server.tool()
    async def arr_bulk_edit(
        app: Literal["radarr", "sonarr"],
        ids: list[int],
        monitored: bool | None = None,
        quality: str | None = None,
        root_folder: str | None = None,
        tags: list[str] | None = None,
        apply_tags: Literal["add", "remove", "replace"] = "add",
        move_files: bool | None = None,
        season_folder: bool | None = None,
        series_type: Literal["standard", "daily", "anime"] | None = None,
    ) -> dict[str, Any]:
        """Bulk-edit many movies/series in one call.

        Resolves ``quality`` / ``root_folder`` / ``tags`` by name. Any arg left
        ``None`` is omitted, so only fields you set are touched. ``apply_tags``
        controls how the ``tags`` list combines with each item's existing tags;
        default ``"add"`` appends without clobbering. ``season_folder`` /
        ``series_type`` are Sonarr-only and silently ignored for Radarr.
        """
        if not ids:
            return error(
                "ids must be non-empty",
                hints=[f"{app}_{'movies' if app == 'radarr' else 'series'}_list()"],
            )
        if app == "radarr":
            if radarr is None:
                return error(
                    "radarr not configured",
                    hints=["arr_health(app='all')"],
                )
            await radarr.movies.bulk_edit(
                ids=list(ids),
                monitored=monitored,
                quality=quality,
                root_folder=root_folder,
                tags=list(tags) if tags is not None else None,
                apply_tags=apply_tags,
                move_files=move_files,
                journal=journal,
            )
        else:
            if sonarr is None:
                return error(
                    "sonarr not configured",
                    hints=["arr_health(app='all')"],
                )
            await sonarr.series.bulk_edit(
                ids=list(ids),
                monitored=monitored,
                quality=quality,
                root_folder=root_folder,
                tags=list(tags) if tags is not None else None,
                apply_tags=apply_tags,
                move_files=move_files,
                season_folder=season_folder,
                series_type=series_type,
                journal=journal,
            )
        return {
            "ok": True,
            "app": app,
            "ids": list(ids),
            "count": len(ids),
            "_meta": {
                "action_hints": [
                    f"{app}_{'movies' if app == 'radarr' else 'series'}_list(fields='id,title,tags,monitored')",
                ],
            },
        }

    @server.tool()
    async def arr_trash_import(
        app: Literal["radarr", "sonarr"],
        custom_formats: list[str] | None = None,
        release_profiles: list[str] | None = None,
        quality_definitions: str | None = None,
        ref: str = "master",
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Pull TRaSH-Guides custom formats, release profiles, and/or quality sizes.

        Fetches each slug from
        ``github.com/TRaSH-Guides/Guides/docs/json/{app}/{cf|rp|quality-size}/<slug>.json``,
        normalizes (strips ``trash_*`` metadata), builds a desired-state dict,
        runs ``arr_sync_plan`` against it. With ``dry_run=False`` it also
        applies. ``ref`` accepts a branch, tag, or SHA — pin it for
        reproducibility.

        ``release_profiles`` is Sonarr-only upstream; requesting them against
        ``app="radarr"`` will fail the fetch. ``quality_definitions`` is a
        **single** slug (e.g. ``"movie"``, ``"anime"``) since each file covers
        the whole quality table.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        from arr_py_client.config_sync import apply_async as _apply_async
        from arr_py_client.config_sync import plan_async as _plan_async
        from arr_py_client.trash import fetch_desired_state

        client = radarr if app == "radarr" else sonarr
        if client is None:
            return error(
                f"{app} not configured",
                hints=["arr_health(app='all')"],
            )
        if not custom_formats and not release_profiles and not quality_definitions:
            return error(
                "pass at least one of custom_formats=, release_profiles=, or quality_definitions=",
                hints=[
                    f"arr_trash_import(app={app!r}, custom_formats=[...])",
                    f"arr_trash_import(app={app!r}, release_profiles=[...])",
                    f"arr_trash_import(app={app!r}, quality_definitions='movie')",
                ],
            )
        try:
            desired = fetch_desired_state(
                app,
                custom_formats=custom_formats,
                release_profiles=release_profiles,
                quality_definitions=quality_definitions,
                ref=ref,
            )
        except Exception as exc:
            return error(
                f"trash fetch failed: {exc}",
                hints=[f"arr_trash_import(app={app!r}, custom_formats=[...])"],
            )
        plan_ = await _plan_async(client, desired)
        hints: list[str] = []
        if dry_run and plan_.changes:
            hints.append(
                f"arr_trash_import(app={app!r}, custom_formats={custom_formats!r}, release_profiles={release_profiles!r}, quality_definitions={quality_definitions!r}, ref={ref!r}, dry_run=False)"
            )
        if not plan_.changes:
            hints.append("arr_health()")
        applied_count = 0
        error_count = 0
        if not dry_run and plan_.changes:
            report = await _apply_async(client, plan_, dry_run=False, journal=journal)
            applied_count = len(report.applied)
            error_count = len(report.errors)
        return {
            "ok": error_count == 0,
            "app": app,
            "ref": ref,
            "dry_run": dry_run,
            "fetched_custom_formats": len(desired.get("custom_formats") or {}),
            "fetched_release_profiles": len(desired.get("release_profiles") or {}),
            "fetched_quality_definitions": len(
                desired.get("quality_definitions") or {}
            ),
            "plan_summary": plan_.summary(),
            "applied_count": applied_count,
            "error_count": error_count,
            "_meta": {"action_hints": hints},
        }
