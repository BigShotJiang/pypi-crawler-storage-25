"""CLI entry point for the arr-py-client MCP server."""

from __future__ import annotations

import argparse
import os
import sys

from arr_py_client.mcp.server import build_server, make_clients


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="arr-py-mcp",
        description=(
            "Run an MCP server exposing Radarr, Sonarr, and/or Prowlarr as tools."
        ),
    )
    parser.add_argument(
        "--radarr-only",
        action="store_true",
        help="Expose only Radarr tools.",
    )
    parser.add_argument(
        "--sonarr-only",
        action="store_true",
        help="Expose only Sonarr tools.",
    )
    parser.add_argument(
        "--prowlarr-only",
        action="store_true",
        help="Expose only Prowlarr tools.",
    )
    parser.add_argument(
        "--with-prowlarr",
        action="store_true",
        help="Also expose Prowlarr tools alongside Radarr/Sonarr.",
    )
    parser.add_argument(
        "--transport",
        choices=("stdio", "sse"),
        default="stdio",
        help="MCP transport (default: stdio for client integrations).",
    )
    args = parser.parse_args()

    onlies = [args.radarr_only, args.sonarr_only, args.prowlarr_only]
    if sum(1 for flag in onlies if flag) > 1:
        sys.stderr.write(
            "--radarr-only, --sonarr-only, and --prowlarr-only are mutually exclusive.\n"
        )
        return 2

    if args.prowlarr_only:
        want_radarr, want_sonarr, want_prowlarr = False, False, True
    elif args.radarr_only:
        want_radarr, want_sonarr = True, False
        want_prowlarr = args.with_prowlarr
    elif args.sonarr_only:
        want_radarr, want_sonarr = False, True
        want_prowlarr = args.with_prowlarr
    else:
        want_radarr, want_sonarr = True, True
        # Default-on for prowlarr when env is configured, otherwise opt-in.
        want_prowlarr = args.with_prowlarr or bool(os.environ.get("PROWLARR_BASE_URL"))

    radarr, sonarr, prowlarr = make_clients(
        want_radarr=want_radarr,
        want_sonarr=want_sonarr,
        want_prowlarr=want_prowlarr,
    )
    server = build_server(radarr=radarr, sonarr=sonarr, prowlarr=prowlarr)
    server.run(transport=args.transport)
    return 0


if __name__ == "__main__":
    sys.exit(main())
