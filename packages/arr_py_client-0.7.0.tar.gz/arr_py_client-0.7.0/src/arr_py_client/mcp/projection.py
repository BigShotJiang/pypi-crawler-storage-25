"""Field projection for MCP tool responses.

Keeps tool output compact so LLM clients don't blow their context window on
wide pydantic models. Three modes per call:

- ``"summary"`` (default for list endpoints): a curated thin set per resource.
- ``"all"`` (default for ``get(id)`` style endpoints): the full ``model_dump``.
- comma-separated list, e.g. ``"id,title,year,overview"``: arbitrary subset.

Discovery: ``arr_describe_fields(resource)`` returns ``{"all": [...], "summary": [...]}``
so the model can pick custom field sets without us baking 50-name lists into
every tool's docstring.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.radarr.v3._generated import models as r_models
from arr_py_client.sonarr.v3._generated import models as s_models

if TYPE_CHECKING:
    from pydantic import BaseModel


# Curated thin defaults per resource. Field names are snake_case (the pydantic
# model attribute names), not the camelCase wire format. See
# ``arr_describe_fields`` for the full set.
SUMMARY_FIELDS: dict[type, set[str]] = {
    r_models.MovieResource: {
        "id",
        "title",
        "year",
        "monitored",
        "has_file",
        "size_on_disk",
        "tmdb_id",
        "imdb_id",
        "status",
    },
    r_models.TagResource: {"id", "label"},
    r_models.QueueResource: {
        "id",
        "movie_id",
        "title",
        "status",
        "tracked_download_status",
        "size",
        "sizeleft",
    },
    r_models.HistoryResource: {
        "id",
        "movie_id",
        "event_type",
        "date",
        "source_title",
    },
    r_models.CommandResource: {
        "id",
        "name",
        "status",
        "message",
        "started",
        "ended",
    },
    r_models.SystemResource: {
        "version",
        "branch",
        "build_time",
        "app_name",
        "instance_name",
    },
    r_models.HealthResource: {"source", "type", "message", "wiki_url"},
    r_models.IndexerResource: {
        "id",
        "name",
        "implementation",
        "enable_rss",
        "priority",
        "tags",
    },
    r_models.DownloadClientResource: {
        "id",
        "name",
        "implementation",
        "enable",
        "priority",
    },
    r_models.QualityProfileResource: {"id", "name", "cutoff", "upgrade_allowed"},
    r_models.RootFolderResource: {"id", "path", "accessible", "free_space"},
    r_models.NotificationResource: {
        "id",
        "name",
        "implementation",
        "tags",
    },
    r_models.CustomFormatResource: {"id", "name"},
    r_models.BlocklistResource: {
        "id",
        "movie_id",
        "source_title",
        "date",
        "indexer",
        "protocol",
        "message",
    },
    r_models.LogResource: {"id", "time", "level", "logger", "message"},
    r_models.BackupResource: {"id", "name", "type", "size", "time"},
    r_models.ManualImportResource: {
        "id",
        "path",
        "relative_path",
        "name",
        "size",
        "movie_file_id",
        "release_group",
    },
    r_models.RenameMovieResource: {
        "id",
        "movie_id",
        "movie_file_id",
        "existing_path",
        "new_path",
    },
    r_models.ReleaseResource: {
        "id",
        "guid",
        "title",
        "size",
        "indexer",
        "protocol",
        "approved",
        "rejected",
        "age",
    },
    s_models.SeriesResource: {
        "id",
        "title",
        "year",
        "monitored",
        "tvdb_id",
        "imdb_id",
        "status",
        "season_count",
        "ended",
    },
    s_models.EpisodeResource: {
        "id",
        "series_id",
        "season_number",
        "episode_number",
        "title",
        "monitored",
        "has_file",
        "air_date_utc",
    },
    s_models.TagResource: {"id", "label"},
    s_models.QueueResource: {
        "id",
        "series_id",
        "episode_id",
        "title",
        "status",
        "tracked_download_status",
        "size",
        "sizeleft",
    },
    s_models.HistoryResource: {
        "id",
        "series_id",
        "episode_id",
        "event_type",
        "date",
        "source_title",
    },
    s_models.CommandResource: {
        "id",
        "name",
        "status",
        "message",
        "started",
        "ended",
    },
    s_models.SystemResource: {
        "version",
        "branch",
        "build_time",
        "app_name",
        "instance_name",
    },
    s_models.HealthResource: {"source", "type", "message", "wiki_url"},
    s_models.IndexerResource: {
        "id",
        "name",
        "implementation",
        "enable_rss",
        "priority",
        "tags",
    },
    s_models.DownloadClientResource: {
        "id",
        "name",
        "implementation",
        "enable",
        "priority",
    },
    s_models.QualityProfileResource: {"id", "name", "cutoff", "upgrade_allowed"},
    s_models.RootFolderResource: {"id", "path", "accessible", "free_space"},
    s_models.NotificationResource: {
        "id",
        "name",
        "implementation",
        "tags",
    },
    s_models.BlocklistResource: {
        "id",
        "series_id",
        "source_title",
        "date",
        "indexer",
        "protocol",
        "message",
    },
    s_models.LogResource: {"id", "time", "level", "logger", "message"},
    s_models.BackupResource: {"id", "name", "type", "size", "time"},
    s_models.ManualImportResource: {
        "id",
        "path",
        "relative_path",
        "name",
        "size",
        "episode_file_id",
        "release_group",
    },
    s_models.RenameEpisodeResource: {
        "id",
        "series_id",
        "season_number",
        "episode_numbers",
        "episode_file_id",
        "existing_path",
        "new_path",
    },
    s_models.ReleaseResource: {
        "id",
        "guid",
        "title",
        "size",
        "indexer",
        "protocol",
        "approved",
        "rejected",
        "age",
    },
}


# Stable string identifiers for ``arr_describe_fields(resource=...)``.
RESOURCE_REGISTRY: dict[str, type] = {
    "radarr.movie": r_models.MovieResource,
    "radarr.tag": r_models.TagResource,
    "radarr.queue": r_models.QueueResource,
    "radarr.history": r_models.HistoryResource,
    "radarr.command": r_models.CommandResource,
    "radarr.system": r_models.SystemResource,
    "radarr.health": r_models.HealthResource,
    "radarr.indexer": r_models.IndexerResource,
    "radarr.download_client": r_models.DownloadClientResource,
    "radarr.quality_profile": r_models.QualityProfileResource,
    "radarr.root_folder": r_models.RootFolderResource,
    "radarr.notification": r_models.NotificationResource,
    "radarr.custom_format": r_models.CustomFormatResource,
    "radarr.blocklist": r_models.BlocklistResource,
    "radarr.log": r_models.LogResource,
    "radarr.backup": r_models.BackupResource,
    "radarr.manual_import": r_models.ManualImportResource,
    "radarr.rename": r_models.RenameMovieResource,
    "radarr.release": r_models.ReleaseResource,
    "sonarr.series": s_models.SeriesResource,
    "sonarr.episode": s_models.EpisodeResource,
    "sonarr.tag": s_models.TagResource,
    "sonarr.queue": s_models.QueueResource,
    "sonarr.history": s_models.HistoryResource,
    "sonarr.command": s_models.CommandResource,
    "sonarr.system": s_models.SystemResource,
    "sonarr.health": s_models.HealthResource,
    "sonarr.indexer": s_models.IndexerResource,
    "sonarr.download_client": s_models.DownloadClientResource,
    "sonarr.quality_profile": s_models.QualityProfileResource,
    "sonarr.root_folder": s_models.RootFolderResource,
    "sonarr.notification": s_models.NotificationResource,
    "sonarr.blocklist": s_models.BlocklistResource,
    "sonarr.log": s_models.LogResource,
    "sonarr.backup": s_models.BackupResource,
    "sonarr.manual_import": s_models.ManualImportResource,
    "sonarr.rename": s_models.RenameEpisodeResource,
    "sonarr.release": s_models.ReleaseResource,
}


def _parse_spec(fields: str) -> tuple[str, set[str] | None]:
    """Returns ``(mode, explicit_set_or_None)``."""
    if fields == "summary" or fields == "all":
        return fields, None
    explicit = {f.strip() for f in fields.split(",") if f.strip()}
    return "explicit", explicit


def project(value: Any, fields: str = "summary") -> Any:
    """Project a pydantic model (or list of) to a JSON-friendly dict.

    Output keys are snake_case (the model's Python attribute names). Use
    :func:`arr_describe_fields` to discover available names for a given
    resource.
    """
    if isinstance(value, list):
        items = cast("list[Any]", value)
        return [project(item, fields) for item in items]
    from pydantic import BaseModel as _BaseModel

    if not isinstance(value, _BaseModel):
        return value
    model: BaseModel = value

    mode, explicit = _parse_spec(fields)
    if mode == "all":
        return model.model_dump(by_alias=False, exclude_none=True)
    keep: set[str]
    if mode == "summary":
        keep = SUMMARY_FIELDS.get(
            type(model),
            set(cast("dict[str, Any]", type(model).model_fields).keys()),
        )
    else:
        keep = explicit if explicit is not None else set()

    full = model.model_dump(by_alias=False, exclude_none=True)
    return {k: v for k, v in full.items() if k in keep}


def envelope(data: Any, *, fields: str, resource: str) -> dict[str, Any]:
    """Wrap a projected response with a ``_meta`` discoverability hint.

    Shape: ``{"data": <data>, "_meta": {fields_mode, resource[, hint]}}``.
    The hint only appears in summary mode to keep responses small in the
    common ``fields="all"`` case.
    """
    mode, _ = _parse_spec(fields)
    meta: dict[str, Any] = {"fields_mode": mode, "resource": resource}
    if mode == "summary":
        meta["hint"] = (
            f"Showing summary fields only. For the full record call again with "
            f"fields='all'; to pick specific fields call "
            f"arr_describe_fields(resource='{resource}') first then pass "
            f"fields='comma,separated,list'."
        )
    return {"data": data, "_meta": meta}


def describe(resource: str) -> dict[str, list[str] | str]:
    """Return ``{all, summary, resource}`` for a registered resource name."""
    model_cls = RESOURCE_REGISTRY.get(resource)
    if model_cls is None:
        names = sorted(RESOURCE_REGISTRY)
        msg = f"unknown resource {resource!r}; known: {names}"
        raise ValueError(msg)
    all_fields = sorted(cast("dict[str, Any]", model_cls.model_fields).keys())
    summary = sorted(SUMMARY_FIELDS.get(model_cls, set()))
    return {"resource": resource, "all": all_fields, "summary": summary}
