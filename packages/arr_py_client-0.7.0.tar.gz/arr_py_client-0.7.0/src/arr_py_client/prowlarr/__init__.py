"""Prowlarr client dispatcher."""

from __future__ import annotations

from typing import Any


def ProwlarrClient(*, api_version: int = 1, **kwargs: Any) -> Any:
    if api_version == 1:
        from arr_py_client.prowlarr.v1.client import ProwlarrClientV1

        return ProwlarrClientV1(**kwargs)
    msg = f"Unsupported Prowlarr api_version: {api_version}"
    raise ValueError(msg)


def AsyncProwlarrClient(*, api_version: int = 1, **kwargs: Any) -> Any:
    if api_version == 1:
        from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1

        return AsyncProwlarrClientV1(**kwargs)
    msg = f"Unsupported Prowlarr api_version: {api_version}"
    raise ValueError(msg)


__all__ = ["AsyncProwlarrClient", "ProwlarrClient"]
