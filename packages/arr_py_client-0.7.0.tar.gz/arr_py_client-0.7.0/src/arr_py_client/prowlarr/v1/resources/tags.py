"""Curated Prowlarr tags facade (mirrors the Radarr/Sonarr ``tags`` surface)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client.prowlarr.v1._generated import models as _models
from arr_py_client.prowlarr.v1.resources._auto.tag import (
    AsyncTagResource as _AutoAsync,
)
from arr_py_client.prowlarr.v1.resources._auto.tag import (
    TagResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class TagsResource(_AutoSync):
    """Sync Prowlarr tags resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.TagResource]:
        return self.list_()

    def get(self, *, id: int) -> _models.TagResource:  # noqa: A002
        return self.get_by_id(id)

    def create_by_label(self, label: str) -> _models.TagResource:
        """Create a tag by its user-facing label (the common one-liner)."""
        return self.create(body=_models.TagResource(label=label))

    def delete(self, *, id: int) -> None:  # noqa: A002
        self.delete_by_id(id)


class AsyncTagsResource(_AutoAsync):
    """Async Prowlarr tags resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.TagResource]:
        return await self.list_()

    async def get(self, *, id: int) -> _models.TagResource:  # noqa: A002
        return await self.get_by_id(id)

    async def create_by_label(self, label: str) -> _models.TagResource:
        return await self.create(body=_models.TagResource(label=label))

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await self.delete_by_id(id)
