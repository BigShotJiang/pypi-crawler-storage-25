"""Curated Prowlarr indexers facade.

Prowlarr's indexer surface is the point of the whole application: it's
where you manage the Newznab/Torznab sources that Radarr/Sonarr/Lidarr
then consume via the ``applications`` surface. Wraps the auto-generated
resource and exposes the handful of convenience methods users actually
reach for — ``list``, ``get``, ``create``, ``update``, ``delete``,
``schema``, ``test``, ``test_all``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client.prowlarr.v1._generated import models as _models  # noqa: TC001
from arr_py_client.prowlarr.v1.resources._auto.indexer import (
    AsyncIndexerResource as _AutoAsync,
)
from arr_py_client.prowlarr.v1.resources._auto.indexer import (
    IndexerResource as _AutoSync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class IndexersResource(_AutoSync):
    """Sync Prowlarr indexers resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.IndexerResource]:
        """List every configured indexer."""
        return self.list_()

    def get(self, *, id: int) -> _models.IndexerResource:  # noqa: A002
        """Get one indexer by id."""
        return self.get_by_id(id)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.IndexerResource,
        force_save: bool = False,
    ) -> _models.IndexerResource:
        """Update an indexer. ``force_save`` bypasses pre-save validation."""
        return self.update_by_id(str(id), force_save=force_save, body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        """Delete an indexer by id."""
        self.delete_by_id(id)

    def schema(self) -> list[_models.IndexerResource]:
        """Return the schema for every indexer implementation."""
        return self.list_schema()

    def test(self, *, body: _models.IndexerResource) -> None:
        """Test a single indexer configuration."""
        self.create_test(body=body)

    def test_all(self) -> None:
        """Test every configured indexer."""
        self.create_testall()


class AsyncIndexersResource(_AutoAsync):
    """Async Prowlarr indexers resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.IndexerResource]:
        return await self.list_()

    async def get(self, *, id: int) -> _models.IndexerResource:  # noqa: A002
        return await self.get_by_id(id)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.IndexerResource,
        force_save: bool = False,
    ) -> _models.IndexerResource:
        return await self.update_by_id(str(id), force_save=force_save, body=body)

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await self.delete_by_id(id)

    async def schema(self) -> list[_models.IndexerResource]:
        return await self.list_schema()

    async def test(self, *, body: _models.IndexerResource) -> None:
        await self.create_test(body=body)

    async def test_all(self) -> None:
        await self.create_testall()
