"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: StaticResource."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class StaticResourceResource:
    """Sync wrapper for the ``StaticResource`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_login(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list_login(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def get_content_by_path(
        self,
        path: str,
    ) -> None:
        return cast(
            "None",
            _ops.get_content_by_path(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path,
            ),
        )

    def list_(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def get_by_path(
        self,
        path: str,
    ) -> None:
        return cast(
            "None",
            _ops.get_by_path(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path,
            ),
        )


class AsyncStaticResourceResource:
    """Async wrapper for the ``StaticResource`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_login(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_login_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def get_content_by_path(
        self,
        path: str,
    ) -> None:
        return cast(
            "None",
            await _ops.get_content_by_path_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path,
            ),
        )

    async def list_(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def get_by_path(
        self,
        path: str,
    ) -> None:
        return cast(
            "None",
            await _ops.get_by_path_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                path,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
