"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: DevelopmentConfig."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class DevelopmentConfigResource:
    """Sync wrapper for the ``DevelopmentConfig`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def update_by_id(
        self,
        id: str,
        *,
        body: models.DevelopmentConfigResource | None = None,
    ) -> models.DevelopmentConfigResource:
        return cast(
            "models.DevelopmentConfigResource",
            _ops.update_config_development_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.DevelopmentConfigResource:
        return cast(
            "models.DevelopmentConfigResource",
            _ops.get_config_development_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_(
        self,
    ) -> models.DevelopmentConfigResource:
        return cast(
            "models.DevelopmentConfigResource",
            _ops.list_config_development(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncDevelopmentConfigResource:
    """Async wrapper for the ``DevelopmentConfig`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.DevelopmentConfigResource | None = None,
    ) -> models.DevelopmentConfigResource:
        return cast(
            "models.DevelopmentConfigResource",
            await _ops.update_config_development_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.DevelopmentConfigResource:
        return cast(
            "models.DevelopmentConfigResource",
            await _ops.get_config_development_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_(
        self,
    ) -> models.DevelopmentConfigResource:
        return cast(
            "models.DevelopmentConfigResource",
            await _ops.list_config_development_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
