"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: AppProfile."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class AppProfileResource:
    """Sync wrapper for the ``AppProfile`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.AppProfileResource | None = None,
    ) -> models.AppProfileResource:
        return cast(
            "models.AppProfileResource",
            _ops.create_appprofile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
    ) -> list[models.AppProfileResource]:
        return cast(
            "list[models.AppProfileResource]",
            _ops.list_appprofile(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_appprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.AppProfileResource | None = None,
    ) -> models.AppProfileResource:
        return cast(
            "models.AppProfileResource",
            _ops.update_appprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.AppProfileResource:
        return cast(
            "models.AppProfileResource",
            _ops.get_appprofile_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_schema(
        self,
    ) -> models.AppProfileResource:
        return cast(
            "models.AppProfileResource",
            _ops.list_appprofile_schema(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncAppProfileResource:
    """Async wrapper for the ``AppProfile`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.AppProfileResource | None = None,
    ) -> models.AppProfileResource:
        return cast(
            "models.AppProfileResource",
            await _ops.create_appprofile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
    ) -> list[models.AppProfileResource]:
        return cast(
            "list[models.AppProfileResource]",
            await _ops.list_appprofile_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_appprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.AppProfileResource | None = None,
    ) -> models.AppProfileResource:
        return cast(
            "models.AppProfileResource",
            await _ops.update_appprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.AppProfileResource:
        return cast(
            "models.AppProfileResource",
            await _ops.get_appprofile_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_schema(
        self,
    ) -> models.AppProfileResource:
        return cast(
            "models.AppProfileResource",
            await _ops.list_appprofile_schema_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
