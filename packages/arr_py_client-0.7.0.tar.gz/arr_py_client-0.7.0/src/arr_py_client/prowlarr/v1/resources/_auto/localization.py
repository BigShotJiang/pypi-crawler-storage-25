"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Localization."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class LocalizationResource:
    """Sync wrapper for the ``Localization`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list_localization(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def list_options(
        self,
    ) -> list[models.LocalizationOption]:
        return cast(
            "list[models.LocalizationOption]",
            _ops.list_localization_options(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncLocalizationResource:
    """Async wrapper for the ``Localization`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_localization_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def list_options(
        self,
    ) -> list[models.LocalizationOption]:
        return cast(
            "list[models.LocalizationOption]",
            await _ops.list_localization_options_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
