"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: ApiInfo."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ApiInfoResource:
    """Sync wrapper for the ``ApiInfo`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> models.ApiInfoResource:
        return cast(
            "models.ApiInfoResource",
            _ops.list_api(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncApiInfoResource:
    """Async wrapper for the ``ApiInfo`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> models.ApiInfoResource:
        return cast(
            "models.ApiInfoResource",
            await _ops.list_api_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
