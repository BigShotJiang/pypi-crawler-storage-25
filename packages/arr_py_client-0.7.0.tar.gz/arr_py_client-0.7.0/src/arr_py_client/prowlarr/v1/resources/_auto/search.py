"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Search."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class SearchResource:
    """Sync wrapper for the ``Search`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create(
        self,
        *,
        body: models.ReleaseResource | None = None,
    ) -> models.ReleaseResource:
        return cast(
            "models.ReleaseResource",
            _ops.create_search(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    def list_(
        self,
        *,
        query: str | None = None,
        type: str | None = None,
        indexer_ids: list[int] | None = None,
        categories: list[int] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[models.ReleaseResource]:
        return cast(
            "list[models.ReleaseResource]",
            _ops.list_search(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                query=query,
                type=type,
                indexer_ids=indexer_ids,
                categories=categories,
                limit=limit,
                offset=offset,
            ),
        )

    def create_bulk(
        self,
    ) -> models.ReleaseResource:
        return cast(
            "models.ReleaseResource",
            _ops.create_search_bulk(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncSearchResource:
    """Async wrapper for the ``Search`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create(
        self,
        *,
        body: models.ReleaseResource | None = None,
    ) -> models.ReleaseResource:
        return cast(
            "models.ReleaseResource",
            await _ops.create_search_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )

    async def list_(
        self,
        *,
        query: str | None = None,
        type: str | None = None,
        indexer_ids: list[int] | None = None,
        categories: list[int] | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[models.ReleaseResource]:
        return cast(
            "list[models.ReleaseResource]",
            await _ops.list_search_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                query=query,
                type=type,
                indexer_ids=indexer_ids,
                categories=categories,
                limit=limit,
                offset=offset,
            ),
        )

    async def create_bulk(
        self,
    ) -> models.ReleaseResource:
        return cast(
            "models.ReleaseResource",
            await _ops.create_search_bulk_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
