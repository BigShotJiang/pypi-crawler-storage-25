"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: IndexerStats."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class IndexerStatsResource:
    """Sync wrapper for the ``IndexerStats`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        indexers: str | None = None,
        protocols: str | None = None,
        tags: str | None = None,
    ) -> models.IndexerStatsResource:
        return cast(
            "models.IndexerStatsResource",
            _ops.list_indexerstats(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                start_date=start_date,
                end_date=end_date,
                indexers=indexers,
                protocols=protocols,
                tags=tags,
            ),
        )


class AsyncIndexerStatsResource:
    """Async wrapper for the ``IndexerStats`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        indexers: str | None = None,
        protocols: str | None = None,
        tags: str | None = None,
    ) -> models.IndexerStatsResource:
        return cast(
            "models.IndexerStatsResource",
            await _ops.list_indexerstats_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                start_date=start_date,
                end_date=end_date,
                indexers=indexers,
                protocols=protocols,
                tags=tags,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
