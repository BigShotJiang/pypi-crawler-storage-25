"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: IndexerProxy."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class IndexerProxyResource:
    """Sync wrapper for the ``IndexerProxy`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def get_by_id(
        self,
        id: int,
    ) -> models.IndexerProxyResource:
        return cast(
            "models.IndexerProxyResource",
            _ops.get_indexerproxy_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        force_save: bool | None = None,
        body: models.IndexerProxyResource | None = None,
    ) -> models.IndexerProxyResource:
        return cast(
            "models.IndexerProxyResource",
            _ops.update_indexerproxy_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                force_save=force_save,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_indexerproxy_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_(
        self,
    ) -> list[models.IndexerProxyResource]:
        return cast(
            "list[models.IndexerProxyResource]",
            _ops.list_indexerproxy(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create(
        self,
        *,
        force_save: bool | None = None,
        body: models.IndexerProxyResource | None = None,
    ) -> models.IndexerProxyResource:
        return cast(
            "models.IndexerProxyResource",
            _ops.create_indexerproxy(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_save=force_save,
                body=body,
            ),
        )

    def list_schema(
        self,
    ) -> list[models.IndexerProxyResource]:
        return cast(
            "list[models.IndexerProxyResource]",
            _ops.list_indexerproxy_schema(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create_test(
        self,
        *,
        force_test: bool | None = None,
        body: models.IndexerProxyResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.create_indexerproxy_test(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_test=force_test,
                body=body,
            ),
        )

    def create_testall(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.create_indexerproxy_testall(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def post_action_by_name(
        self,
        name: str,
        *,
        body: models.IndexerProxyResource | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.post_indexerproxy_action_by_name(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                name,
                body=body,
            ),
        )


class AsyncIndexerProxyResource:
    """Async wrapper for the ``IndexerProxy`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def get_by_id(
        self,
        id: int,
    ) -> models.IndexerProxyResource:
        return cast(
            "models.IndexerProxyResource",
            await _ops.get_indexerproxy_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        force_save: bool | None = None,
        body: models.IndexerProxyResource | None = None,
    ) -> models.IndexerProxyResource:
        return cast(
            "models.IndexerProxyResource",
            await _ops.update_indexerproxy_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                force_save=force_save,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_indexerproxy_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_(
        self,
    ) -> list[models.IndexerProxyResource]:
        return cast(
            "list[models.IndexerProxyResource]",
            await _ops.list_indexerproxy_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create(
        self,
        *,
        force_save: bool | None = None,
        body: models.IndexerProxyResource | None = None,
    ) -> models.IndexerProxyResource:
        return cast(
            "models.IndexerProxyResource",
            await _ops.create_indexerproxy_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_save=force_save,
                body=body,
            ),
        )

    async def list_schema(
        self,
    ) -> list[models.IndexerProxyResource]:
        return cast(
            "list[models.IndexerProxyResource]",
            await _ops.list_indexerproxy_schema_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create_test(
        self,
        *,
        force_test: bool | None = None,
        body: models.IndexerProxyResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.create_indexerproxy_test_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                force_test=force_test,
                body=body,
            ),
        )

    async def create_testall(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.create_indexerproxy_testall_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def post_action_by_name(
        self,
        name: str,
        *,
        body: models.IndexerProxyResource | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.post_indexerproxy_action_by_name_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                name,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
