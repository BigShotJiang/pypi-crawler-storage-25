"""Auto-generated resource wrappers for prowlarr."""

from __future__ import annotations

from arr_py_client.prowlarr.v1.resources._auto.api_info import (
    AsyncApiInfoResource,
    ApiInfoResource,
)
from arr_py_client.prowlarr.v1.resources._auto.app_profile import (
    AsyncAppProfileResource,
    AppProfileResource,
)
from arr_py_client.prowlarr.v1.resources._auto.application import (
    AsyncApplicationResource,
    ApplicationResource,
)
from arr_py_client.prowlarr.v1.resources._auto.authentication import (
    AsyncAuthenticationResource,
    AuthenticationResource,
)
from arr_py_client.prowlarr.v1.resources._auto.backup import (
    AsyncBackupResource,
    BackupResource,
)
from arr_py_client.prowlarr.v1.resources._auto.command import (
    AsyncCommandResource,
    CommandResource,
)
from arr_py_client.prowlarr.v1.resources._auto.custom_filter import (
    AsyncCustomFilterResource,
    CustomFilterResource,
)
from arr_py_client.prowlarr.v1.resources._auto.development_config import (
    AsyncDevelopmentConfigResource,
    DevelopmentConfigResource,
)
from arr_py_client.prowlarr.v1.resources._auto.download_client import (
    AsyncDownloadClientResource,
    DownloadClientResource,
)
from arr_py_client.prowlarr.v1.resources._auto.download_client_config import (
    AsyncDownloadClientConfigResource,
    DownloadClientConfigResource,
)
from arr_py_client.prowlarr.v1.resources._auto.file_system import (
    AsyncFileSystemResource,
    FileSystemResource,
)
from arr_py_client.prowlarr.v1.resources._auto.health import (
    AsyncHealthResource,
    HealthResource,
)
from arr_py_client.prowlarr.v1.resources._auto.history import (
    AsyncHistoryResource,
    HistoryResource,
)
from arr_py_client.prowlarr.v1.resources._auto.host_config import (
    AsyncHostConfigResource,
    HostConfigResource,
)
from arr_py_client.prowlarr.v1.resources._auto.indexer import (
    AsyncIndexerResource,
    IndexerResource,
)
from arr_py_client.prowlarr.v1.resources._auto.indexer_default_categories import (
    AsyncIndexerDefaultCategoriesResource,
    IndexerDefaultCategoriesResource,
)
from arr_py_client.prowlarr.v1.resources._auto.indexer_proxy import (
    AsyncIndexerProxyResource,
    IndexerProxyResource,
)
from arr_py_client.prowlarr.v1.resources._auto.indexer_stats import (
    AsyncIndexerStatsResource,
    IndexerStatsResource,
)
from arr_py_client.prowlarr.v1.resources._auto.indexer_status import (
    AsyncIndexerStatusResource,
    IndexerStatusResource,
)
from arr_py_client.prowlarr.v1.resources._auto.localization import (
    AsyncLocalizationResource,
    LocalizationResource,
)
from arr_py_client.prowlarr.v1.resources._auto.log import AsyncLogResource, LogResource
from arr_py_client.prowlarr.v1.resources._auto.log_file import (
    AsyncLogFileResource,
    LogFileResource,
)
from arr_py_client.prowlarr.v1.resources._auto.newznab import (
    AsyncNewznabResource,
    NewznabResource,
)
from arr_py_client.prowlarr.v1.resources._auto.notification import (
    AsyncNotificationResource,
    NotificationResource,
)
from arr_py_client.prowlarr.v1.resources._auto.ping import (
    AsyncPingResource,
    PingResource,
)
from arr_py_client.prowlarr.v1.resources._auto.search import (
    AsyncSearchResource,
    SearchResource,
)
from arr_py_client.prowlarr.v1.resources._auto.static_resource import (
    AsyncStaticResourceResource,
    StaticResourceResource,
)
from arr_py_client.prowlarr.v1.resources._auto.system import (
    AsyncSystemResource,
    SystemResource,
)
from arr_py_client.prowlarr.v1.resources._auto.tag import AsyncTagResource, TagResource
from arr_py_client.prowlarr.v1.resources._auto.tag_details import (
    AsyncTagDetailsResource,
    TagDetailsResource,
)
from arr_py_client.prowlarr.v1.resources._auto.task import (
    AsyncTaskResource,
    TaskResource,
)
from arr_py_client.prowlarr.v1.resources._auto.ui_config import (
    AsyncUiConfigResource,
    UiConfigResource,
)
from arr_py_client.prowlarr.v1.resources._auto.update import (
    AsyncUpdateResource,
    UpdateResource,
)
from arr_py_client.prowlarr.v1.resources._auto.update_log_file import (
    AsyncUpdateLogFileResource,
    UpdateLogFileResource,
)

__all__ = [
    "ApiInfoResource",
    "AppProfileResource",
    "ApplicationResource",
    "AsyncApiInfoResource",
    "AsyncAppProfileResource",
    "AsyncApplicationResource",
    "AsyncAuthenticationResource",
    "AsyncBackupResource",
    "AsyncCommandResource",
    "AsyncCustomFilterResource",
    "AsyncDevelopmentConfigResource",
    "AsyncDownloadClientConfigResource",
    "AsyncDownloadClientResource",
    "AsyncFileSystemResource",
    "AsyncHealthResource",
    "AsyncHistoryResource",
    "AsyncHostConfigResource",
    "AsyncIndexerDefaultCategoriesResource",
    "AsyncIndexerProxyResource",
    "AsyncIndexerResource",
    "AsyncIndexerStatsResource",
    "AsyncIndexerStatusResource",
    "AsyncLocalizationResource",
    "AsyncLogFileResource",
    "AsyncLogResource",
    "AsyncNewznabResource",
    "AsyncNotificationResource",
    "AsyncPingResource",
    "AsyncSearchResource",
    "AsyncStaticResourceResource",
    "AsyncSystemResource",
    "AsyncTagDetailsResource",
    "AsyncTagResource",
    "AsyncTaskResource",
    "AsyncUiConfigResource",
    "AsyncUpdateLogFileResource",
    "AsyncUpdateResource",
    "AuthenticationResource",
    "BackupResource",
    "CommandResource",
    "CustomFilterResource",
    "DevelopmentConfigResource",
    "DownloadClientConfigResource",
    "DownloadClientResource",
    "FileSystemResource",
    "HealthResource",
    "HistoryResource",
    "HostConfigResource",
    "IndexerDefaultCategoriesResource",
    "IndexerProxyResource",
    "IndexerResource",
    "IndexerStatsResource",
    "IndexerStatusResource",
    "LocalizationResource",
    "LogFileResource",
    "LogResource",
    "NewznabResource",
    "NotificationResource",
    "PingResource",
    "SearchResource",
    "StaticResourceResource",
    "SystemResource",
    "TagDetailsResource",
    "TagResource",
    "TaskResource",
    "UiConfigResource",
    "UpdateLogFileResource",
    "UpdateResource",
]

SYNC_RESOURCES = {
    "api_info": ApiInfoResource,
    "app_profile": AppProfileResource,
    "application": ApplicationResource,
    "authentication": AuthenticationResource,
    "backup": BackupResource,
    "command": CommandResource,
    "custom_filter": CustomFilterResource,
    "development_config": DevelopmentConfigResource,
    "download_client": DownloadClientResource,
    "download_client_config": DownloadClientConfigResource,
    "file_system": FileSystemResource,
    "health": HealthResource,
    "history": HistoryResource,
    "host_config": HostConfigResource,
    "indexer": IndexerResource,
    "indexer_default_categories": IndexerDefaultCategoriesResource,
    "indexer_proxy": IndexerProxyResource,
    "indexer_stats": IndexerStatsResource,
    "indexer_status": IndexerStatusResource,
    "localization": LocalizationResource,
    "log": LogResource,
    "log_file": LogFileResource,
    "newznab": NewznabResource,
    "notification": NotificationResource,
    "ping": PingResource,
    "search": SearchResource,
    "static_resource": StaticResourceResource,
    "system": SystemResource,
    "tag": TagResource,
    "tag_details": TagDetailsResource,
    "task": TaskResource,
    "ui_config": UiConfigResource,
    "update": UpdateResource,
    "update_log_file": UpdateLogFileResource,
}

ASYNC_RESOURCES = {
    "api_info": AsyncApiInfoResource,
    "app_profile": AsyncAppProfileResource,
    "application": AsyncApplicationResource,
    "authentication": AsyncAuthenticationResource,
    "backup": AsyncBackupResource,
    "command": AsyncCommandResource,
    "custom_filter": AsyncCustomFilterResource,
    "development_config": AsyncDevelopmentConfigResource,
    "download_client": AsyncDownloadClientResource,
    "download_client_config": AsyncDownloadClientConfigResource,
    "file_system": AsyncFileSystemResource,
    "health": AsyncHealthResource,
    "history": AsyncHistoryResource,
    "host_config": AsyncHostConfigResource,
    "indexer": AsyncIndexerResource,
    "indexer_default_categories": AsyncIndexerDefaultCategoriesResource,
    "indexer_proxy": AsyncIndexerProxyResource,
    "indexer_stats": AsyncIndexerStatsResource,
    "indexer_status": AsyncIndexerStatusResource,
    "localization": AsyncLocalizationResource,
    "log": AsyncLogResource,
    "log_file": AsyncLogFileResource,
    "newznab": AsyncNewznabResource,
    "notification": AsyncNotificationResource,
    "ping": AsyncPingResource,
    "search": AsyncSearchResource,
    "static_resource": AsyncStaticResourceResource,
    "system": AsyncSystemResource,
    "tag": AsyncTagResource,
    "tag_details": AsyncTagDetailsResource,
    "task": AsyncTaskResource,
    "ui_config": AsyncUiConfigResource,
    "update": AsyncUpdateResource,
    "update_log_file": AsyncUpdateLogFileResource,
}
