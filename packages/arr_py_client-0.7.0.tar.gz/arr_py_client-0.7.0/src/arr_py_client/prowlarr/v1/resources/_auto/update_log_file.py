"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: UpdateLogFile."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class UpdateLogFileResource:
    """Sync wrapper for the ``UpdateLogFile`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
    ) -> list[models.LogFileResource]:
        return cast(
            "list[models.LogFileResource]",
            _ops.list_log_file_update(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def get_by_filename(
        self,
        filename: str,
    ) -> None:
        return cast(
            "None",
            _ops.get_log_file_update_by_filename(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                filename,
            ),
        )


class AsyncUpdateLogFileResource:
    """Async wrapper for the ``UpdateLogFile`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
    ) -> list[models.LogFileResource]:
        return cast(
            "list[models.LogFileResource]",
            await _ops.list_log_file_update_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def get_by_filename(
        self,
        filename: str,
    ) -> None:
        return cast(
            "None",
            await _ops.get_log_file_update_by_filename_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                filename,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
