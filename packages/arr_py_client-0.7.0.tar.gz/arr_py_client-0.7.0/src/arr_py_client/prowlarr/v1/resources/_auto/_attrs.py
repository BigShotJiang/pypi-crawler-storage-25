"""Generated typed attribute declarations for the client classes."""

from __future__ import annotations

from arr_py_client.prowlarr.v1.resources._auto import (
    ApiInfoResource,
    AppProfileResource,
    ApplicationResource,
    AuthenticationResource,
    BackupResource,
    CommandResource,
    CustomFilterResource,
    DevelopmentConfigResource,
    DownloadClientResource,
    DownloadClientConfigResource,
    FileSystemResource,
    HealthResource,
    HistoryResource,
    HostConfigResource,
    IndexerResource,
    IndexerDefaultCategoriesResource,
    IndexerProxyResource,
    IndexerStatsResource,
    IndexerStatusResource,
    LocalizationResource,
    LogResource,
    LogFileResource,
    NewznabResource,
    NotificationResource,
    PingResource,
    SearchResource,
    StaticResourceResource,
    SystemResource,
    TagResource,
    TagDetailsResource,
    TaskResource,
    UiConfigResource,
    UpdateResource,
    UpdateLogFileResource,
    AsyncApiInfoResource,
    AsyncAppProfileResource,
    AsyncApplicationResource,
    AsyncAuthenticationResource,
    AsyncBackupResource,
    AsyncCommandResource,
    AsyncCustomFilterResource,
    AsyncDevelopmentConfigResource,
    AsyncDownloadClientResource,
    AsyncDownloadClientConfigResource,
    AsyncFileSystemResource,
    AsyncHealthResource,
    AsyncHistoryResource,
    AsyncHostConfigResource,
    AsyncIndexerResource,
    AsyncIndexerDefaultCategoriesResource,
    AsyncIndexerProxyResource,
    AsyncIndexerStatsResource,
    AsyncIndexerStatusResource,
    AsyncLocalizationResource,
    AsyncLogResource,
    AsyncLogFileResource,
    AsyncNewznabResource,
    AsyncNotificationResource,
    AsyncPingResource,
    AsyncSearchResource,
    AsyncStaticResourceResource,
    AsyncSystemResource,
    AsyncTagResource,
    AsyncTagDetailsResource,
    AsyncTaskResource,
    AsyncUiConfigResource,
    AsyncUpdateResource,
    AsyncUpdateLogFileResource,
)


class ProwlarrV1SyncResourceAttrs:
    api_info: ApiInfoResource
    app_profile: AppProfileResource
    application: ApplicationResource
    authentication: AuthenticationResource
    backup: BackupResource
    command: CommandResource
    custom_filter: CustomFilterResource
    development_config: DevelopmentConfigResource
    download_client: DownloadClientResource
    download_client_config: DownloadClientConfigResource
    file_system: FileSystemResource
    health: HealthResource
    history: HistoryResource
    host_config: HostConfigResource
    indexer: IndexerResource
    indexer_default_categories: IndexerDefaultCategoriesResource
    indexer_proxy: IndexerProxyResource
    indexer_stats: IndexerStatsResource
    indexer_status: IndexerStatusResource
    localization: LocalizationResource
    log: LogResource
    log_file: LogFileResource
    newznab: NewznabResource
    notification: NotificationResource
    ping: PingResource
    search: SearchResource
    static_resource: StaticResourceResource
    system: SystemResource
    tag: TagResource
    tag_details: TagDetailsResource
    task: TaskResource
    ui_config: UiConfigResource
    update: UpdateResource
    update_log_file: UpdateLogFileResource


class ProwlarrV1AsyncResourceAttrs:
    api_info: AsyncApiInfoResource
    app_profile: AsyncAppProfileResource
    application: AsyncApplicationResource
    authentication: AsyncAuthenticationResource
    backup: AsyncBackupResource
    command: AsyncCommandResource
    custom_filter: AsyncCustomFilterResource
    development_config: AsyncDevelopmentConfigResource
    download_client: AsyncDownloadClientResource
    download_client_config: AsyncDownloadClientConfigResource
    file_system: AsyncFileSystemResource
    health: AsyncHealthResource
    history: AsyncHistoryResource
    host_config: AsyncHostConfigResource
    indexer: AsyncIndexerResource
    indexer_default_categories: AsyncIndexerDefaultCategoriesResource
    indexer_proxy: AsyncIndexerProxyResource
    indexer_stats: AsyncIndexerStatsResource
    indexer_status: AsyncIndexerStatusResource
    localization: AsyncLocalizationResource
    log: AsyncLogResource
    log_file: AsyncLogFileResource
    newznab: AsyncNewznabResource
    notification: AsyncNotificationResource
    ping: AsyncPingResource
    search: AsyncSearchResource
    static_resource: AsyncStaticResourceResource
    system: AsyncSystemResource
    tag: AsyncTagResource
    tag_details: AsyncTagDetailsResource
    task: AsyncTaskResource
    ui_config: AsyncUiConfigResource
    update: AsyncUpdateResource
    update_log_file: AsyncUpdateLogFileResource
