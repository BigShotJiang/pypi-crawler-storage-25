"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: History."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class HistoryResource:
    """Sync wrapper for the ``History`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        event_type: list[int] | None = None,
        successful: bool | None = None,
        download_id: str | None = None,
        indexer_ids: list[int] | None = None,
    ) -> models.HistoryResourcePagingResource:
        return cast(
            "models.HistoryResourcePagingResource",
            _ops.list_history(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                event_type=event_type,
                successful=successful,
                download_id=download_id,
                indexer_ids=indexer_ids,
            ),
        )

    def list_since(
        self,
        *,
        date: str | None = None,
        event_type: models.HistoryEventType | None = None,
    ) -> list[models.HistoryResource]:
        return cast(
            "list[models.HistoryResource]",
            _ops.list_history_since(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                date=date,
                event_type=event_type,
            ),
        )

    def list_indexer(
        self,
        *,
        indexer_id: int | None = None,
        event_type: models.HistoryEventType | None = None,
        limit: int | None = None,
    ) -> list[models.HistoryResource]:
        return cast(
            "list[models.HistoryResource]",
            _ops.list_history_indexer(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                indexer_id=indexer_id,
                event_type=event_type,
                limit=limit,
            ),
        )


class AsyncHistoryResource:
    """Async wrapper for the ``History`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def list_(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_key: str | None = None,
        sort_direction: models.SortDirection | None = None,
        event_type: list[int] | None = None,
        successful: bool | None = None,
        download_id: str | None = None,
        indexer_ids: list[int] | None = None,
    ) -> models.HistoryResourcePagingResource:
        return cast(
            "models.HistoryResourcePagingResource",
            await _ops.list_history_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                page=page,
                page_size=page_size,
                sort_key=sort_key,
                sort_direction=sort_direction,
                event_type=event_type,
                successful=successful,
                download_id=download_id,
                indexer_ids=indexer_ids,
            ),
        )

    async def list_since(
        self,
        *,
        date: str | None = None,
        event_type: models.HistoryEventType | None = None,
    ) -> list[models.HistoryResource]:
        return cast(
            "list[models.HistoryResource]",
            await _ops.list_history_since_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                date=date,
                event_type=event_type,
            ),
        )

    async def list_indexer(
        self,
        *,
        indexer_id: int | None = None,
        event_type: models.HistoryEventType | None = None,
        limit: int | None = None,
    ) -> list[models.HistoryResource]:
        return cast(
            "list[models.HistoryResource]",
            await _ops.list_history_indexer_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                indexer_id=indexer_id,
                event_type=event_type,
                limit=limit,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
