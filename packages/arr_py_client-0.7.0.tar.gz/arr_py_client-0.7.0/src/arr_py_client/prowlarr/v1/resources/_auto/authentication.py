"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: Authentication."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class AuthenticationResource:
    """Sync wrapper for the ``Authentication`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def create_login(
        self,
        *,
        return_url: str | None = None,
    ) -> None:
        return cast(
            "None",
            _ops.create_login(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                return_url=return_url,
            ),
        )

    def list_logout(
        self,
    ) -> None:
        return cast(
            "None",
            _ops.list_logout(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncAuthenticationResource:
    """Async wrapper for the ``Authentication`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def create_login(
        self,
        *,
        return_url: str | None = None,
    ) -> None:
        return cast(
            "None",
            await _ops.create_login_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                return_url=return_url,
            ),
        )

    async def list_logout(
        self,
    ) -> None:
        return cast(
            "None",
            await _ops.list_logout_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
