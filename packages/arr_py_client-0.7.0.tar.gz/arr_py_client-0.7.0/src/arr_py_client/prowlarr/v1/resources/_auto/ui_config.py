"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: UiConfig."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class UiConfigResource:
    """Sync wrapper for the ``UiConfig`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def update_by_id(
        self,
        id: str,
        *,
        body: models.UiConfigResource | None = None,
    ) -> models.UiConfigResource:
        return cast(
            "models.UiConfigResource",
            _ops.update_config_ui_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def get_by_id(
        self,
        id: int,
    ) -> models.UiConfigResource:
        return cast(
            "models.UiConfigResource",
            _ops.get_config_ui_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_(
        self,
    ) -> models.UiConfigResource:
        return cast(
            "models.UiConfigResource",
            _ops.list_config_ui(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


class AsyncUiConfigResource:
    """Async wrapper for the ``UiConfig`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.UiConfigResource | None = None,
    ) -> models.UiConfigResource:
        return cast(
            "models.UiConfigResource",
            await _ops.update_config_ui_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def get_by_id(
        self,
        id: int,
    ) -> models.UiConfigResource:
        return cast(
            "models.UiConfigResource",
            await _ops.get_config_ui_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_(
        self,
    ) -> models.UiConfigResource:
        return cast(
            "models.UiConfigResource",
            await _ops.list_config_ui_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
