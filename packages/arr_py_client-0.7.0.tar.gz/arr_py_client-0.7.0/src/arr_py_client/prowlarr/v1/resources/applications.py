"""Curated Prowlarr applications facade.

Applications are the other `*arr` instances (Radarr, Sonarr, Lidarr, …)
Prowlarr is registered with. Prowlarr pushes its indexer list and
configuration *into* each application via this surface, so
``applications.test(id)`` is the load-bearing health check — it verifies
Prowlarr can reach and authenticate against the downstream app.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from arr_py_client.prowlarr.v1._generated import models as _models  # noqa: TC001
from arr_py_client.prowlarr.v1.resources._auto.application import (
    ApplicationResource as _AutoSync,
)
from arr_py_client.prowlarr.v1.resources._auto.application import (
    AsyncApplicationResource as _AutoAsync,
)

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class ApplicationsResource(_AutoSync):
    """Sync Prowlarr applications resource (curated facade)."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    def list(self) -> list[_models.ApplicationResource]:
        return self.list_()

    def get(self, *, id: int) -> _models.ApplicationResource:  # noqa: A002
        return self.get_by_id(id)

    def create(
        self, *, body: _models.ApplicationResource, force_save: bool = False
    ) -> _models.ApplicationResource:
        return super().create(body=body, force_save=force_save)

    def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.ApplicationResource,
        force_save: bool = False,
    ) -> _models.ApplicationResource:
        return self.update_by_id(str(id), force_save=force_save, body=body)

    def delete(self, *, id: int) -> None:  # noqa: A002
        self.delete_by_id(id)

    def schema(self) -> list[_models.ApplicationResource]:
        return self.list_schema()

    def test(self, *, body: _models.ApplicationResource) -> None:
        self.create_test(body=body)

    def test_all(self) -> None:
        self.create_testall()


class AsyncApplicationsResource(_AutoAsync):
    """Async Prowlarr applications resource (curated facade)."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__(transport)
        self._transport = transport

    async def list(self) -> list[_models.ApplicationResource]:
        return await self.list_()

    async def get(self, *, id: int) -> _models.ApplicationResource:  # noqa: A002
        return await self.get_by_id(id)

    async def create(
        self, *, body: _models.ApplicationResource, force_save: bool = False
    ) -> _models.ApplicationResource:
        return await super().create(body=body, force_save=force_save)

    async def update(
        self,
        *,
        id: int,  # noqa: A002
        body: _models.ApplicationResource,
        force_save: bool = False,
    ) -> _models.ApplicationResource:
        return await self.update_by_id(str(id), force_save=force_save, body=body)

    async def delete(self, *, id: int) -> None:  # noqa: A002
        await self.delete_by_id(id)

    async def schema(self) -> list[_models.ApplicationResource]:
        return await self.list_schema()

    async def test(self, *, body: _models.ApplicationResource) -> None:
        await self.create_test(body=body)

    async def test_all(self) -> None:
        await self.create_testall()
