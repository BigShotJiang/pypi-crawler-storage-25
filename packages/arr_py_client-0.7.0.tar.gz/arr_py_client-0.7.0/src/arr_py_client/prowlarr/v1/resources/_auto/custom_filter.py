"""Auto-generated resource wrapper. DO NOT EDIT. Source tag: CustomFilter."""

# pyright: reportUnnecessaryCast=false, reportUnusedImport=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

from arr_py_client.prowlarr.v1._generated import models, operations as _ops

if TYPE_CHECKING:
    from arr_py_client._common.transport import AsyncTransport, SyncTransport


class CustomFilterResource:
    """Sync wrapper for the ``CustomFilter`` resource group."""

    def __init__(self, transport: SyncTransport) -> None:
        super().__init__()
        self._transport = transport

    def get_by_id(
        self,
        id: int,
    ) -> models.CustomFilterResource:
        return cast(
            "models.CustomFilterResource",
            _ops.get_customfilter_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def update_by_id(
        self,
        id: str,
        *,
        body: models.CustomFilterResource | None = None,
    ) -> models.CustomFilterResource:
        return cast(
            "models.CustomFilterResource",
            _ops.update_customfilter_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            _ops.delete_customfilter_by_id(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    def list_(
        self,
    ) -> list[models.CustomFilterResource]:
        return cast(
            "list[models.CustomFilterResource]",
            _ops.list_customfilter(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    def create(
        self,
        *,
        body: models.CustomFilterResource | None = None,
    ) -> models.CustomFilterResource:
        return cast(
            "models.CustomFilterResource",
            _ops.create_customfilter(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


class AsyncCustomFilterResource:
    """Async wrapper for the ``CustomFilter`` resource group."""

    def __init__(self, transport: AsyncTransport) -> None:
        super().__init__()
        self._transport = transport

    async def get_by_id(
        self,
        id: int,
    ) -> models.CustomFilterResource:
        return cast(
            "models.CustomFilterResource",
            await _ops.get_customfilter_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def update_by_id(
        self,
        id: str,
        *,
        body: models.CustomFilterResource | None = None,
    ) -> models.CustomFilterResource:
        return cast(
            "models.CustomFilterResource",
            await _ops.update_customfilter_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
                body=body,
            ),
        )

    async def delete_by_id(
        self,
        id: int,
    ) -> None:
        return cast(
            "None",
            await _ops.delete_customfilter_by_id_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                id,
            ),
        )

    async def list_(
        self,
    ) -> list[models.CustomFilterResource]:
        return cast(
            "list[models.CustomFilterResource]",
            await _ops.list_customfilter_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
            ),
        )

    async def create(
        self,
        *,
        body: models.CustomFilterResource | None = None,
    ) -> models.CustomFilterResource:
        return cast(
            "models.CustomFilterResource",
            await _ops.create_customfilter_async(  # pyright: ignore[reportUnknownMemberType]
                self._transport,
                body=body,
            ),
        )


_ = (Any,)  # suppress unused-import lint when no Any in any signature
