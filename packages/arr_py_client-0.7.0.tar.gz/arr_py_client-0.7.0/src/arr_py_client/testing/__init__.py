"""Test helpers users can depend on when building on arr-py-client.

Not a conftest — import these directly from your own test modules.

:func:`make_fake_radarr` / :func:`make_fake_sonarr` return real brand clients
backed by an in-memory ``respx`` router preloaded with canned responses.
Because they wrap the *real* transport and curated resources, test behavior
matches production behavior — no divergent fake implementations to drift.

:func:`replay` is a decorator that records live responses to JSON on first run
and plays them back on subsequent runs. Point it at a fixture path and pass
the ``REPLAY_REREC=1`` env var to force re-recording.
"""

from __future__ import annotations

from arr_py_client.testing.fakes import (
    FakeClientContext,
    make_fake_prowlarr,
    make_fake_radarr,
    make_fake_sonarr,
)
from arr_py_client.testing.replay import replay

__all__ = [
    "FakeClientContext",
    "make_fake_prowlarr",
    "make_fake_radarr",
    "make_fake_sonarr",
    "replay",
]
