"""Record-on-miss / replay-on-hit decorator for arr-py-client tests.

Point ``@replay("path/to/fixture.json")`` at a JSON file:

- If the file is absent, the decorated test hits the real upstream and saves
  the ``(method, url, status, json_body)`` of each captured request.
- If the file exists, the decorated test runs inside a ``respx`` mock that
  replays the saved responses. Unmatched requests raise.

Set ``REPLAY_REREC=1`` to force re-recording even when the file exists.

Use via:

.. code-block:: python

    @replay("fixtures/dune_add.json")
    def test_dune_add() -> None:
        with RadarrClient() as c:
            c.movies.add(tmdb_id=438631, ...)
"""

# pyright: reportUnknownMemberType=false, reportUnknownArgumentType=false

from __future__ import annotations

import json
import os
from functools import wraps
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import httpx
import respx

if TYPE_CHECKING:
    from collections.abc import Callable


def _record_response(path: str) -> Callable[[httpx.Request], httpx.Response]:
    """Return a respx pass-through handler that logs responses to disk."""
    recorded: list[dict[str, Any]] = []
    real_transport = httpx.HTTPTransport()

    def handler(request: httpx.Request) -> httpx.Response:
        response = real_transport.handle_request(request)
        try:
            body = json.loads(response.content or b"null")
        except Exception:
            body = None
        recorded.append(
            {
                "method": request.method,
                "url": str(request.url),
                "status": response.status_code,
                "json": body,
            }
        )
        # Persist after every call so a crash mid-test still yields partial
        # fixtures (debugging aid).
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(recorded, indent=2), encoding="utf-8")
        return response

    return handler


def _install_playback(router: respx.MockRouter, entries: list[dict[str, Any]]) -> None:
    """Register each saved response as a respx route."""
    for entry in entries:
        method = cast("str", entry["method"])
        url = cast("str", entry["url"])
        status = cast("int", entry["status"])
        body = entry.get("json")
        route = router.route(method=method, url=url)
        route.respond(status, json=body)


def replay(fixture_path: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator: record on first run, replay on subsequent runs."""
    force_rerec = os.environ.get("REPLAY_REREC") == "1"
    path = Path(fixture_path)

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if path.exists() and not force_rerec:
                with respx.mock(assert_all_called=False) as router:
                    entries = cast(
                        "list[dict[str, Any]]",
                        json.loads(path.read_text(encoding="utf-8")),
                    )
                    _install_playback(router, entries)
                    return func(*args, **kwargs)
            # Record pass: register a catch-all pass-through that saves to disk.
            with respx.mock(assert_all_called=False) as router:
                router.route().mock(side_effect=_record_response(str(path)))
                return func(*args, **kwargs)

        return wrapper

    return decorator
