"""In-memory fake Radarr/Sonarr clients backed by a respx router.

These aren't reimplementations — they're real clients whose transport is
directed at a respx mock server preloaded with whatever state you provide.
This ensures fake behavior matches the real code path (pydantic model parsing,
transport retries, etc.).
"""

# pyright: reportUnknownMemberType=false

from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

import respx

from arr_py_client import ProwlarrClient, RadarrClient, SonarrClient

if TYPE_CHECKING:
    from collections.abc import Generator


class FakeClientContext:
    """Holds a live brand client + its respx router for assertion access.

    Use via the ``make_fake_radarr`` / ``make_fake_sonarr`` context managers.
    """

    def __init__(
        self,
        client: Any,
        router: respx.MockRouter,
    ) -> None:
        super().__init__()
        self.client = client
        self.router = router


def _default_paging(records: list[Any]) -> dict[str, Any]:
    return {
        "page": 1,
        "pageSize": max(len(records), 1),
        "sortKey": "",
        "sortDirection": "ascending",
        "totalRecords": len(records),
        "records": records,
    }


def _seed_router(
    router: respx.MockRouter,
    base: str,
    *,
    movies: list[dict[str, Any]] | None,
    series: list[dict[str, Any]] | None,
    queue: list[dict[str, Any]] | None,
    tags: list[dict[str, Any]] | None,
    health: list[dict[str, Any]] | None,
    diskspace: list[dict[str, Any]] | None,
    version: str,
) -> None:
    if movies is not None:
        router.get(f"{base}/api/v3/movie").respond(200, json=movies)
    if series is not None:
        router.get(f"{base}/api/v3/series").respond(200, json=series)
    router.get(f"{base}/api/v3/queue").respond(200, json=_default_paging(queue or []))
    router.get(f"{base}/api/v3/tag").respond(200, json=tags or [])
    router.get(f"{base}/api/v3/health").respond(200, json=health or [])
    router.get(f"{base}/api/v3/diskspace").respond(200, json=diskspace or [])
    router.get(f"{base}/api/v3/system/status").respond(200, json={"version": version})


@contextmanager
def make_fake_radarr(
    *,
    base_url: str = "http://fake.radarr",
    api_key: str = "fake",
    movies: list[dict[str, Any]] | None = None,
    queue: list[dict[str, Any]] | None = None,
    tags: list[dict[str, Any]] | None = None,
    health: list[dict[str, Any]] | None = None,
    diskspace: list[dict[str, Any]] | None = None,
    version: str = "6.1.1.10360",
) -> Generator[FakeClientContext, None, None]:
    """Spin up a synchronous fake RadarrClient with pre-seeded responses.

    Unmocked requests raise ``respx.AllMockedAssertionError`` (consistent with
    ``@respx.mock``). Extend the context's router mid-test to add more routes.
    """
    with respx.mock(assert_all_called=False) as router:
        _seed_router(
            router,
            base_url,
            movies=movies,
            series=None,
            queue=queue,
            tags=tags,
            health=health,
            diskspace=diskspace,
            version=version,
        )
        client = RadarrClient(base_url=base_url, api_key=api_key)
        try:
            yield FakeClientContext(client=client, router=router)
        finally:
            client.close()


@contextmanager
def make_fake_sonarr(
    *,
    base_url: str = "http://fake.sonarr",
    api_key: str = "fake",
    series: list[dict[str, Any]] | None = None,
    queue: list[dict[str, Any]] | None = None,
    tags: list[dict[str, Any]] | None = None,
    health: list[dict[str, Any]] | None = None,
    diskspace: list[dict[str, Any]] | None = None,
    version: str = "4.0.17.2952",
) -> Generator[FakeClientContext, None, None]:
    """Spin up a synchronous fake SonarrClient with pre-seeded responses."""
    with respx.mock(assert_all_called=False) as router:
        _seed_router(
            router,
            base_url,
            movies=None,
            series=series,
            queue=queue,
            tags=tags,
            health=health,
            diskspace=diskspace,
            version=version,
        )
        client = SonarrClient(base_url=base_url, api_key=api_key)
        try:
            yield FakeClientContext(client=client, router=router)
        finally:
            client.close()


def _seed_prowlarr_router(
    router: respx.MockRouter,
    base: str,
    *,
    indexers: list[dict[str, Any]] | None,
    applications: list[dict[str, Any]] | None,
    tags: list[dict[str, Any]] | None,
    health: list[dict[str, Any]] | None,
    version: str,
) -> None:
    router.get(f"{base}/api/v1/indexer").respond(200, json=indexers or [])
    router.get(f"{base}/api/v1/applications").respond(200, json=applications or [])
    router.get(f"{base}/api/v1/tag").respond(200, json=tags or [])
    router.get(f"{base}/api/v1/health").respond(200, json=health or [])
    router.get(f"{base}/api/v1/system/status").respond(200, json={"version": version})


@contextmanager
def make_fake_prowlarr(
    *,
    base_url: str = "http://fake.prowlarr",
    api_key: str = "fake",
    indexers: list[dict[str, Any]] | None = None,
    applications: list[dict[str, Any]] | None = None,
    tags: list[dict[str, Any]] | None = None,
    health: list[dict[str, Any]] | None = None,
    version: str = "2.3.5.5327",
) -> Generator[FakeClientContext, None, None]:
    """Spin up a synchronous fake ProwlarrClient with pre-seeded responses.

    Prowlarr's fake surface is smaller than Radarr/Sonarr's (no queue, no
    library), so the pre-seeded endpoints focus on what Prowlarr actually
    exposes: indexers, applications, tags, health, and system status.
    """
    with respx.mock(assert_all_called=False) as router:
        _seed_prowlarr_router(
            router,
            base_url,
            indexers=indexers,
            applications=applications,
            tags=tags,
            health=health,
            version=version,
        )
        client = ProwlarrClient(base_url=base_url, api_key=api_key)
        try:
            yield FakeClientContext(client=client, router=router)
        finally:
            client.close()
