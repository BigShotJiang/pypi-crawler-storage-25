"""QuizMD validator — checks .quiz.md content for errors and warnings.

Diagnostics carry a machine-readable ``code`` (e.g. ``invalid_quiz_type``,
``missing_question_topic``, ``prompt_in_fence``) so consumers — the neuroneo
backend, a future CLI — can branch on the kind of problem without matching on
the human-readable message. Messages are written to tell an author EXACTLY
what to change.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from pylearnspec.quizmd.parser import VALID_QUESTION_TYPES, parse_quiz


@dataclass
class Diagnostic:
    level: Literal["error", "warning"]
    message: str
    question: int | None = None
    code: str | None = None

    def to_dict(self) -> dict:
        d: dict = {"level": self.level, "message": self.message}
        if self.question is not None:
            d["question"] = self.question
        if self.code is not None:
            d["code"] = self.code
        return d


def validate_quiz(content: str, *, strict: bool = False) -> list[Diagnostic]:
    """Validate a .quiz.md string and return a list of diagnostics.

    In lenient mode (default), missing title/lang are warnings.
    In strict mode, they are errors.
    """
    diagnostics: list[Diagnostic] = []

    # Try parsing — catch YAML errors
    try:
        quiz = parse_quiz(content)
    except Exception as e:
        diagnostics.append(Diagnostic(level="error", message=f"Parse error: {e}", code="parse_error"))
        return diagnostics

    # Check frontmatter
    severity: Literal["error", "warning"] = "error" if strict else "warning"

    # In QuizMD v0.3, title is optional (inferred from H1). We still warn if
    # neither is present, because every quiz needs *some* title.
    if not quiz.title:
        diagnostics.append(Diagnostic(
            level=severity,
            message=(
                "Missing quiz title. Add a top-level '# <Quiz title>' heading "
                "(or a 'title:' field in the frontmatter)."
            ),
            code="missing_title",
        ))

    if not quiz.frontmatter.get("lang"):
        diagnostics.append(Diagnostic(
            level=severity,
            message=(
                "Missing 'lang' in frontmatter. Add a frontmatter block with "
                "the content language, e.g. 'lang: en' (or 'lang: fr')."
            ),
            code="missing_lang",
        ))

    # QuizMD v0.3: media:slug rules
    has_media_ref = any(r.kind == "media" for r in quiz.refs)
    for mref in quiz.media_refs:
        if not has_media_ref:
            diagnostics.append(Diagnostic(
                level=severity,
                message=(
                    f"media:{mref.slug} used without a matching !ref MediaMD. "
                    f"Add a '!ref <path-to>.media.md' directive that defines the "
                    f"'{mref.slug}' slug."
                ),
                code="media_ref_missing",
            ))
        if not mref.fallback_url:
            diagnostics.append(Diagnostic(
                level=severity,
                message=(
                    f"media:{mref.slug} without a fallback URL. Provide one inline as the "
                    f"image title, e.g. '![alt](media:{mref.slug} \"https://example.com/"
                    f"image.png\")', so the media renders even when the MediaMD source is "
                    f"unavailable."
                ),
                code="media_fallback_missing",
            ))

    # Check questions
    for q in quiz.questions:
        n = q.number

        # 1. Invalid declared type (e.g. Bloom's taxonomy levels like
        #    "remember"/"apply"/"analyze"). The parser exposes the raw,
        #    unvalidated value via declared_type.
        if q.declared_type and q.declared_type not in VALID_QUESTION_TYPES:
            diagnostics.append(Diagnostic(
                level="error",
                message=(
                    f"Q{n}: invalid quiz type '{q.declared_type}'. Valid "
                    f"declarative types are match, order, multi. For a standard "
                    f"multiple-choice or true/false question, write the prompt as a "
                    f"paragraph and the choices as '- [ ]'/'- [x]' bullets OUTSIDE any "
                    f"```quiz fence (no type: needed). "
                    f"(If you meant a Bloom's level, use 'bloom: {q.declared_type}' "
                    f"instead of 'type:'.)"
                ),
                question=n,
                code="invalid_quiz_type",
            ))

        # 2. Missing question topic on the heading.
        if not q.title.strip():
            diagnostics.append(Diagnostic(
                level=severity,
                message=(
                    f"Q{n}: missing question topic. Put a short topic on the heading "
                    f"line: '## Q{n} · <topic>'. The question prompt goes in a paragraph "
                    f"below, the answers as '- [ ]'/'- [x]' bullets."
                ),
                question=n,
                code="missing_question_topic",
            ))

        # 3. Prompt trapped inside the ```quiz fence (the `? prompt`
        #    anti-pattern). The fence is for YAML metadata only.
        if q.prompt_in_fence:
            diagnostics.append(Diagnostic(
                level="error",
                message=(
                    f"Q{n}: the question prompt is inside a ```quiz fence. The fence is "
                    f"for YAML metadata only — write the prompt as plain text on the "
                    f"heading ('## Q{n} · <topic>') and/or a paragraph below it, and put "
                    f"the choices as '- [ ]'/'- [x]' bullets OUTSIDE the fence."
                ),
                question=n,
                code="prompt_in_fence",
            ))

        # 4. No correct answer marked for MCQ / multi.
        if q.q_type in ("mcq", "tf", "multi"):
            correct_count = sum(1 for c in q.choices if c.correct)
            if correct_count == 0:
                diagnostics.append(Diagnostic(
                    level="error" if strict else "warning",
                    message=(
                        f"Q{n}: no correct answer marked. Mark the correct choice(s) by "
                        f"changing '- [ ]' to '- [x]'."
                    ),
                    question=n,
                    code="no_correct_answer",
                ))

        # 5. Open question without an expected answer.
        if q.q_type == "open" and not q.open_answer and not q.match_pairs and not q.order_items:
            diagnostics.append(Diagnostic(
                level="warning",
                message=(
                    f"Q{n}: open question without an expected answer. Add an "
                    f"'**Answer:** <expected answer>' line so responses can be checked."
                ),
                question=n,
                code="open_without_answer",
            ))

    return diagnostics
