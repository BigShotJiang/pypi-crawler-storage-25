"""Data models for QuizMD parsed output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Choice:
    text: str
    correct: bool
    feedback: str = ""


@dataclass
class MatchPair:
    left: str
    right: str


@dataclass
class Question:
    number: int
    id: str = ""
    title: str = ""
    body: str = ""
    q_type: str = ""  # mcq, multi, open, tf, match, order
    # Raw, unvalidated `type:` value declared in the ```quiz fence (if any).
    # The validator uses this to flag invented/invalid types (e.g. Bloom's
    # taxonomy levels like "remember"). Empty when the type was inferred.
    declared_type: str = ""
    # True when a `? prompt` line appears INSIDE the ```quiz fence — the
    # anti-pattern where an MCQ prompt is trapped in the fence instead of
    # living in a paragraph below the heading. Set by the parser.
    prompt_in_fence: bool = False
    choices: list[Choice] = field(default_factory=list)
    open_answer: str = ""
    match_pairs: list[MatchPair] = field(default_factory=list)
    order_items: list[str] = field(default_factory=list)
    feedback: str = ""
    meta: dict[str, Any] = field(default_factory=dict)
    source_file: str = ""
    source_title: str = ""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "number": self.number,
            "id": self.id or f"q{self.number}",
            "title": self.title,
            "q_type": self.q_type,
            "choices": [{"text": c.text, "correct": c.correct} for c in self.choices],
            "open_answer": self.open_answer,
            "feedback": self.feedback,
            "meta": self.meta,
            "source_file": self.source_file,
            "source_title": self.source_title,
        }
        if self.match_pairs:
            d["match_pairs"] = [{"left": p.left, "right": p.right} for p in self.match_pairs]
        if self.order_items:
            d["order_items"] = self.order_items
        if self.body:
            d["body"] = self.body
        if self.declared_type:
            d["declared_type"] = self.declared_type
        if self.prompt_in_fence:
            d["prompt_in_fence"] = True
        return d


@dataclass
class Quiz:
    title: str = ""
    level: str = "0"
    frontmatter: dict[str, Any] = field(default_factory=dict)
    questions: list[Question] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    # QuizMD v0.3 additions
    refs: list[Any] = field(default_factory=list)        # list[RefDirective]
    media_refs: list[Any] = field(default_factory=list)  # list[MediaRef]

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "level": self.level,
            "frontmatter": self.frontmatter,
            "questions": [q.to_dict() for q in self.questions],
            "imports": self.imports,
            "refs": [r.to_dict() for r in self.refs],
            "media_refs": [m.to_dict() for m in self.media_refs],
        }
