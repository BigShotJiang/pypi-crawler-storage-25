"""Wikilink extraction and manipulation."""
from __future__ import annotations

import re

# Matches ``[[target]]`` or ``[[target|display]]`` — stops at ``]``, ``|``, ``#``
WIKILINK_RE = re.compile(r"\[\[([^\]|#]+)(?:\|([^\]]*))?\]\]")


def extract_wikilinks(content: str) -> list[str]:
    """Return all ``[[target]]`` link targets, ignoring ``|display`` aliases."""
    return [m.group(1).strip() for m in WIKILINK_RE.finditer(content)]


def has_bracket_unsafe_chars(text: str) -> bool:
    """Check if text contains characters that break wikilink parsing."""
    return any(c in text for c in ("[", "]", "|"))
