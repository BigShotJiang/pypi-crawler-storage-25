"""Parse and write YAML frontmatter in markdown files."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import frontmatter


def parse_note(path: Path) -> tuple[dict[str, Any], str]:
    """Parse a markdown file into (frontmatter_dict, body_text).

    Uses python-frontmatter (not regex split) so ``---`` inside the
    body doesn't corrupt parsing.
    """
    post = frontmatter.load(str(path))
    return dict(post.metadata), post.content


def write_note(path: Path, metadata: dict[str, Any], body: str) -> None:
    """Write a markdown file with YAML frontmatter, creating parent dirs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    post = frontmatter.Post(body, **metadata)
    path.write_text(frontmatter.dumps(post), encoding="utf-8")


def update_frontmatter(path: Path, updates: dict[str, Any]) -> None:
    """Merge ``updates`` into the existing frontmatter, preserving body."""
    meta, body = parse_note(path)
    meta.update(updates)
    write_note(path, meta, body)
