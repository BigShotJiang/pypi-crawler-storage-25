"""Vault utilities — paths, frontmatter, wikilinks."""
from llm_wiki.vault.frontmatter import parse_note, write_note
from llm_wiki.vault.paths import Vault
from llm_wiki.vault.wikilinks import WIKILINK_RE, extract_wikilinks

__all__ = [
    "Vault",
    "parse_note",
    "write_note",
    "extract_wikilinks",
    "WIKILINK_RE",
]
