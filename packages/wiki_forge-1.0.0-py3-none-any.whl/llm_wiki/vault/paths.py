"""Vault directory layout helpers."""
from __future__ import annotations

import json
from pathlib import Path


class Vault:
    """Represents a wiki vault on disk with standard structure:

    ::

        root/
        ├── raw/           # Immutable source files
        └── wiki/
            ├── sources/   # LLM-generated source summaries
            ├── entities/  # Person/company/product pages
            ├── concepts/  # Idea/framework pages
            ├── syntheses/ # Saved query answers
            ├── overview.md
            ├── index.md
            └── log.md
    """

    SKIP_FILES = frozenset({"index.md", "log.md", "lint-report.md"})

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root).expanduser().resolve()

    # ── Directories ──────────────────────────────────────────────

    @property
    def raw(self) -> Path:
        return self.root / "raw"

    @property
    def wiki(self) -> Path:
        return self.root / "wiki"

    @property
    def sources(self) -> Path:
        return self.wiki / "sources"

    @property
    def entities(self) -> Path:
        return self.wiki / "entities"

    @property
    def concepts(self) -> Path:
        return self.wiki / "concepts"

    @property
    def syntheses(self) -> Path:
        return self.wiki / "syntheses"

    # ── Meta files ───────────────────────────────────────────────

    @property
    def overview(self) -> Path:
        return self.wiki / "overview.md"

    @property
    def index(self) -> Path:
        return self.wiki / "index.md"

    @property
    def log(self) -> Path:
        return self.wiki / "log.md"

    @property
    def ingest_state(self) -> Path:
        """JSON file storing {source_key: sha256_hex} for --update mode."""
        return self.root / ".ingest-state.json"

    # ── Ingest state helpers ──────────────────────────────────────

    def load_ingest_state(self) -> dict[str, str]:
        """Load persisted source hashes. Returns {} if file doesn't exist."""
        if not self.ingest_state.exists():
            return {}
        try:
            return json.loads(self.ingest_state.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def save_ingest_hash(self, source_key: str, sha256_hex: str) -> None:
        """Persist the hash for a source file after successful ingestion."""
        state = self.load_ingest_state()
        state[source_key] = sha256_hex
        self.ingest_state.write_text(json.dumps(state, indent=2), encoding="utf-8")

    def is_source_unchanged(self, source_key: str, sha256_hex: str) -> bool:
        """Return True if this source was already ingested with the same hash."""
        return self.load_ingest_state().get(source_key) == sha256_hex

    # ── Operations ───────────────────────────────────────────────

    def init_dirs(self) -> None:
        """Create the standard vault directory layout."""
        for d in (self.raw, self.sources, self.entities, self.concepts, self.syntheses):
            d.mkdir(parents=True, exist_ok=True)

    def all_pages(self) -> list[Path]:
        """Return all content pages (excluding meta files)."""
        if not self.wiki.exists():
            return []
        return [p for p in self.wiki.rglob("*.md") if p.name not in self.SKIP_FILES]

    def source_pages(self) -> list[Path]:
        return sorted(self.sources.glob("*.md")) if self.sources.exists() else []

    def entity_pages(self) -> list[Path]:
        return sorted(self.entities.glob("*.md")) if self.entities.exists() else []

    def concept_pages(self) -> list[Path]:
        return sorted(self.concepts.glob("*.md")) if self.concepts.exists() else []

    def __repr__(self) -> str:
        return f"Vault(root={self.root!r})"
