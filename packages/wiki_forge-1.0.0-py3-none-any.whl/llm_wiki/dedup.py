"""4-tier fuzzy matching for concept/entity page deduplication."""
from __future__ import annotations

import re
import unicodedata
from datetime import date
from pathlib import Path


def strip_accents(text: str) -> str:
    """Remove Unicode diacritical marks (NFD decomposition + strip combining)."""
    nfd = unicodedata.normalize("NFD", text)
    return "".join(c for c in nfd if unicodedata.category(c) != "Mn")


def fuzzy_key(name: str) -> str:
    """Normalized key for fuzzy matching.

    - Lowercase
    - Strip accents
    - Collapse separators to spaces
    - Singularize simple trailing ``s``
    """
    key = strip_accents(name.lower())
    key = re.sub(r"[\s\-_/&.,()]+", " ", key).strip()
    if key.endswith("s") and len(key) > 3 and not key.endswith("ss"):
        key = key[:-1]
    return key


def compact_key(name: str) -> str:
    """Like :func:`fuzzy_key` but with no separators at all.

    Enables matching ``MembershipTiers`` ↔ ``Membership Tiers``.
    """
    key = strip_accents(name.lower())
    key = re.sub(r"[\s\-_/&.,()]+", "", key).strip()
    if key.endswith("s") and len(key) > 3 and not key.endswith("ss"):
        key = key[:-1]
    return key


def find_existing_page(
    wiki_root: Path,
    target_path: str,
    *,
    fuzzy_threshold: float = 0.7,
    substring_min_len: int = 6,
) -> Path | None:
    """Find an existing page that matches ``target_path``.

    Searches BOTH ``entities/`` and ``concepts/`` to prevent stem
    collisions (e.g. ``entities/SkyJoy.md`` and ``concepts/SkyJoy.md``).

    Strategies (in order):
    1. Exact path match
    2. Fuzzy key match (lowercase + stripped accents)
    3. Compact key match (no separators — camelCase ↔ spaced)
    4. Substring match (one compact name contains the other)
    5. Token overlap (Jaccard similarity ≥ ``fuzzy_threshold``)

    Returns the matching Path, or None if no match is found.
    """
    target = wiki_root / target_path
    if target.exists():
        return target

    search_dirs = [wiki_root / "entities", wiki_root / "concepts"]
    candidates: list[Path] = []
    for d in search_dirs:
        if d.exists():
            candidates.extend(d.glob("*.md"))

    if not candidates:
        return None

    t_stem = target.stem
    t_key = fuzzy_key(t_stem)
    t_compact = compact_key(t_stem)
    t_tokens = set(t_key.split())

    best_match: Path | None = None
    best_score = 0.0

    for existing in candidates:
        e_key = fuzzy_key(existing.stem)
        e_compact = compact_key(existing.stem)

        # 2. Fuzzy key exact match
        if e_key == t_key:
            return existing

        # 3. Compact key exact match
        if e_compact == t_compact:
            return existing

        # 4. Substring match (avoid trivial short matches)
        if len(t_compact) >= substring_min_len and (
            t_compact in e_compact or e_compact in t_compact
        ):
            return existing

        # 5. Token overlap (Jaccard)
        e_tokens = set(e_key.split())
        if e_tokens and t_tokens:
            overlap = len(t_tokens & e_tokens) / len(t_tokens | e_tokens)
            if overlap > best_score:
                best_score = overlap
                best_match = existing

    if best_score >= fuzzy_threshold:
        return best_match
    return None


def merge_page_content(existing_path: Path, new_content: str) -> str:
    """Merge new content into an existing page.

    Strategy: keep existing body, append new body under
    ``## Additional Context`` section. Updates ``last_updated`` in
    frontmatter.
    """
    existing = existing_path.read_text(encoding="utf-8")

    # Extract new body (skip frontmatter if present)
    new_body_match = re.search(r"^---[\s\S]*?---\s*(.*)", new_content, re.DOTALL)
    new_body = new_body_match.group(1) if new_body_match else new_content

    # Skip if new body is already mostly in existing
    snippet = new_body.strip()[:200]
    if snippet and snippet in existing:
        return existing

    # Update last_updated in frontmatter
    today = date.today().isoformat()
    existing = re.sub(
        r"^(last_updated:\s*).*$",
        f"\\g<1>{today}",
        existing,
        count=1,
        flags=re.MULTILINE,
    )

    # Append to Additional Context section
    if "## Additional Context" not in existing:
        existing = existing.rstrip() + f"\n\n## Additional Context\n\n{new_body.strip()}\n"
    else:
        existing = existing.rstrip() + f"\n\n{new_body.strip()}\n"

    return existing
