"""Async Anthropic Claude API client."""
from __future__ import annotations

import asyncio
import logging

import httpx

from llm_wiki.exceptions import LLMError
from llm_wiki.llm.base import LLMProvider, LLMResponse

log = logging.getLogger(__name__)

ANTHROPIC_BASE = "https://api.anthropic.com/v1"
DEFAULT_MODEL = "claude-sonnet-4-5-20250514"


class AnthropicClient(LLMProvider):
    """Async Anthropic Claude client with retry on 429/503/529."""

    def __init__(
        self,
        api_key: str,
        *,
        timeout: float = 300.0,
        max_retries: int = 3,
        default_model: str = DEFAULT_MODEL,
    ) -> None:
        if not api_key:
            raise ValueError("Anthropic API key required")
        self.api_key = api_key
        self.max_retries = max_retries
        self.default_model = default_model
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
        )

    async def generate(
        self,
        prompt: str,
        *,
        system: str = "",
        model: str | None = None,
        max_tokens: int = 8192,
        response_format: str | None = None,
    ) -> LLMResponse:
        model_name = model or self.default_model

        messages: list[dict] = [{"role": "user", "content": prompt}]

        payload: dict = {
            "model": model_name,
            "messages": messages,
            "max_tokens": max_tokens,
        }
        if system:
            payload["system"] = system

        url = f"{ANTHROPIC_BASE}/messages"

        last_err: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                resp = await self._client.post(url, json=payload)
                resp.raise_for_status()
                data = resp.json()
                return self._parse_response(data)
            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if status in (429, 503, 529) and attempt < self.max_retries - 1:
                    backoff = 2 ** attempt
                    log.warning("Anthropic %d, retrying in %ds (attempt %d)", status, backoff, attempt + 1)
                    await asyncio.sleep(backoff)
                    last_err = e
                    continue
                raise LLMError(f"Anthropic HTTP {status}: {e.response.text[:500]}") from e
            except httpx.ConnectError as e:
                last_err = e
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                    continue
                raise LLMError(f"Anthropic connection failed: {e}") from e

        raise LLMError(f"Anthropic failed after {self.max_retries} retries: {last_err}")

    def _parse_response(self, data: dict) -> LLMResponse:
        try:
            # Anthropic returns content as array of blocks
            content_blocks = data["content"]
            text = "".join(
                block["text"] for block in content_blocks
                if block.get("type") == "text"
            )
        except (KeyError, IndexError) as e:
            raise LLMError(f"Unexpected Anthropic response: {data}") from e

        usage = data.get("usage", {})
        return LLMResponse(
            text=text,
            input_tokens=usage.get("input_tokens", 0),
            output_tokens=usage.get("output_tokens", 0),
        )

    async def close(self) -> None:
        await self._client.aclose()
