"""Async Gemini API client using httpx."""
from __future__ import annotations

import asyncio
import logging

import httpx

from llm_wiki.exceptions import LLMError
from llm_wiki.llm.base import LLMProvider, LLMResponse

log = logging.getLogger(__name__)

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta"
DEFAULT_MODEL = "gemini-2.5-flash-lite"


class GeminiClient(LLMProvider):
    """Async Google Gemini client with retry on 429/503."""

    def __init__(
        self,
        api_key: str,
        *,
        timeout: float = 300.0,
        max_retries: int = 3,
        default_model: str = DEFAULT_MODEL,
    ) -> None:
        if not api_key:
            raise ValueError("Gemini API key required")
        self.api_key = api_key
        self.max_retries = max_retries
        self.default_model = default_model
        self._client = httpx.AsyncClient(timeout=timeout)

    async def generate(
        self,
        prompt: str,
        *,
        system: str = "",
        model: str | None = None,
        max_tokens: int = 8192,
        response_format: str | None = None,
    ) -> LLMResponse:
        model_name = model or self.default_model

        # Build Gemini contents — system becomes a pseudo-user turn
        contents: list[dict] = []
        if system:
            contents.append(
                {"role": "user", "parts": [{"text": f"[SYSTEM INSTRUCTIONS]\n{system}\n[/SYSTEM]"}]}
            )
            contents.append(
                {"role": "model", "parts": [{"text": "Understood. I will follow the instructions."}]}
            )
        contents.append({"role": "user", "parts": [{"text": prompt}]})

        gen_config: dict = {"maxOutputTokens": max_tokens}
        if response_format == "json":
            gen_config["responseMimeType"] = "application/json"

        url = f"{GEMINI_BASE}/models/{model_name}:generateContent?key={self.api_key}"
        payload = {"contents": contents, "generationConfig": gen_config}

        last_err: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                resp = await self._client.post(url, json=payload)
                resp.raise_for_status()
                data = resp.json()
                return self._parse_response(data)
            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if status in (429, 503) and attempt < self.max_retries - 1:
                    backoff = 2**attempt
                    log.warning("Gemini %d, retrying in %ds (attempt %d)", status, backoff, attempt + 1)
                    await asyncio.sleep(backoff)
                    last_err = e
                    continue
                raise LLMError(
                    f"Gemini HTTP {status}: {e.response.text[:500]}"
                ) from e
            except httpx.ConnectError as e:
                last_err = e
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2**attempt)
                    continue
                raise LLMError(f"Gemini connection failed: {e}") from e

        raise LLMError(f"Gemini failed after {self.max_retries} retries: {last_err}")

    def _parse_response(self, data: dict) -> LLMResponse:
        try:
            text = data["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError) as e:
            raise LLMError(f"Unexpected Gemini response shape: {data}") from e

        usage = data.get("usageMetadata", {})
        return LLMResponse(
            text=text,
            input_tokens=usage.get("promptTokenCount", 0),
            output_tokens=usage.get("candidatesTokenCount", 0),
        )

    async def close(self) -> None:
        await self._client.aclose()
