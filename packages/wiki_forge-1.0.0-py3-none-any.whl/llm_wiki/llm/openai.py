"""Async OpenAI-compatible API client (works with OpenAI, Ollama, vLLM, etc.)."""
from __future__ import annotations

import asyncio
import logging

import httpx

from llm_wiki.exceptions import LLMError
from llm_wiki.llm.base import LLMProvider, LLMResponse

log = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://api.openai.com/v1"
DEFAULT_MODEL = "gpt-4.1-mini"


class OpenAIClient(LLMProvider):
    """Async OpenAI client with retry on 429/503.

    Also works with any OpenAI-compatible endpoint (Ollama, vLLM, LiteLLM, etc.)
    by passing a custom ``base_url``.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 300.0,
        max_retries: int = 3,
        default_model: str = DEFAULT_MODEL,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.max_retries = max_retries
        self.default_model = default_model
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )

    async def generate(
        self,
        prompt: str,
        *,
        system: str = "",
        model: str | None = None,
        max_tokens: int = 8192,
        response_format: str | None = None,
    ) -> LLMResponse:
        model_name = model or self.default_model

        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload: dict = {
            "model": model_name,
            "messages": messages,
            "max_tokens": max_tokens,
        }
        if response_format == "json":
            payload["response_format"] = {"type": "json_object"}

        url = f"{self.base_url}/chat/completions"

        last_err: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                resp = await self._client.post(url, json=payload)
                resp.raise_for_status()
                data = resp.json()
                return self._parse_response(data)
            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if status in (429, 503) and attempt < self.max_retries - 1:
                    backoff = 2 ** attempt
                    log.warning("OpenAI %d, retrying in %ds (attempt %d)", status, backoff, attempt + 1)
                    await asyncio.sleep(backoff)
                    last_err = e
                    continue
                raise LLMError(f"OpenAI HTTP {status}: {e.response.text[:500]}") from e
            except httpx.ConnectError as e:
                last_err = e
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(2 ** attempt)
                    continue
                raise LLMError(f"OpenAI connection failed: {e}") from e

        raise LLMError(f"OpenAI failed after {self.max_retries} retries: {last_err}")

    def _parse_response(self, data: dict) -> LLMResponse:
        try:
            text = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            raise LLMError(f"Unexpected OpenAI response: {data}") from e

        usage = data.get("usage", {})
        return LLMResponse(
            text=text or "",
            input_tokens=usage.get("prompt_tokens", 0),
            output_tokens=usage.get("completion_tokens", 0),
        )

    async def close(self) -> None:
        await self._client.aclose()
