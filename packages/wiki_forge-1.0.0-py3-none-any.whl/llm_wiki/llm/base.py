"""LLM provider abstract base class."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class LLMResponse:
    """Response from an LLM call."""

    text: str
    input_tokens: int = 0
    output_tokens: int = 0


class LLMProvider(ABC):
    """Abstract interface for LLM providers."""

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        *,
        system: str = "",
        model: str | None = None,
        max_tokens: int = 8192,
        response_format: str | None = None,
    ) -> LLMResponse:
        """Generate a response from the LLM.

        Args:
            prompt: User prompt.
            system: Optional system instructions.
            model: Model name (uses default if None).
            max_tokens: Maximum output tokens.
            response_format: If ``"json"``, request structured JSON output.
        """

    @abstractmethod
    async def close(self) -> None:
        """Close the underlying HTTP client."""

    async def __aenter__(self) -> LLMProvider:
        return self

    async def __aexit__(self, *_) -> None:
        await self.close()
