"""Factory for creating LLM provider instances from config."""
from __future__ import annotations

from llm_wiki.config import Settings
from llm_wiki.llm.base import LLMProvider


def create_llm(settings: Settings) -> LLMProvider:
    """Create an LLM provider based on settings.provider.

    Supported providers:
        - ``gemini`` (default): Google Gemini API
        - ``openai``: OpenAI API (also works with Ollama, vLLM, LiteLLM)
        - ``anthropic``: Anthropic Claude API

    Environment variables:
        - ``GEMINI_API_KEY`` for Gemini
        - ``OPENAI_API_KEY`` for OpenAI
        - ``ANTHROPIC_API_KEY`` for Anthropic
        - ``OPENAI_BASE_URL`` for custom OpenAI-compatible endpoints
    """
    provider = settings.provider.lower().strip()

    if provider == "gemini":
        from llm_wiki.llm.gemini import GeminiClient
        if not settings.gemini_api_key:
            raise ValueError("GEMINI_API_KEY not set")
        return GeminiClient(
            api_key=settings.gemini_api_key,
            timeout=settings.llm_timeout,
            max_retries=settings.llm_max_retries,
        )

    if provider == "openai":
        from llm_wiki.llm.openai import OpenAIClient
        if not settings.openai_api_key:
            raise ValueError("OPENAI_API_KEY not set")
        return OpenAIClient(
            api_key=settings.openai_api_key,
            base_url=settings.openai_base_url,
            timeout=settings.llm_timeout,
            max_retries=settings.llm_max_retries,
        )

    if provider == "anthropic":
        from llm_wiki.llm.anthropic import AnthropicClient
        if not settings.anthropic_api_key:
            raise ValueError("ANTHROPIC_API_KEY not set")
        return AnthropicClient(
            api_key=settings.anthropic_api_key,
            timeout=settings.llm_timeout,
            max_retries=settings.llm_max_retries,
        )

    raise ValueError(
        f"Unknown LLM provider: {provider!r}. "
        f"Supported: gemini, openai, anthropic"
    )
