"""Robust 3-tier JSON parser for LLM outputs.

Strategies in order:

1. **Direct parse** — ``json.loads(text)`` on the outermost object
2. **Escape bare newlines** — fix unescaped ``\\n``/``\\r``/``\\t`` inside strings
3. **Incremental field decode** — use ``json.JSONDecoder.raw_decode`` on each
   known top-level field individually, so a single malformed field doesn't
   nuke the whole response.
"""
from __future__ import annotations

import json
import re

from llm_wiki.exceptions import JSONParseError

# Fields known to appear in IngestResult — used for Tier 3 recovery
_INGEST_FIELDS = (
    "title",
    "slug",
    "source_page",
    "index_entry",
    "overview_update",
    "entity_pages",
    "concept_pages",
    "contradictions",
    "log_entry",
)


def parse_llm_json(text: str, *, known_keys: tuple[str, ...] = _INGEST_FIELDS) -> dict:
    """Parse JSON from LLM output with 3-tier recovery.

    Raises :class:`JSONParseError` if all strategies fail.
    """
    cleaned = _strip_code_fences(text)
    match = re.search(r"\{[\s\S]*\}", cleaned)
    if not match:
        raise JSONParseError("No JSON object found in response")
    raw = match.group()

    # Tier 1: direct parse
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # Tier 2: escape bare control chars inside strings
    fixed = _escape_bare_controls(raw)
    try:
        return json.loads(fixed)
    except json.JSONDecodeError:
        pass

    # Tier 3: incremental field extraction
    result = _incremental_decode(raw, fixed, known_keys)
    if not result:
        raise JSONParseError("Failed to extract any fields from JSON response")
    return result


def _strip_code_fences(text: str) -> str:
    """Remove ```json ... ``` fences."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*\n?", "", text)
    text = re.sub(r"\n?```\s*$", "", text)
    return text


def _escape_bare_controls(raw: str) -> str:
    """Escape bare newlines/tabs inside double-quoted strings."""
    out: list[str] = []
    in_string = False
    escape = False
    for c in raw:
        if escape:
            out.append(c)
            escape = False
            continue
        if c == "\\":
            out.append(c)
            escape = True
            continue
        if c == '"':
            in_string = not in_string
            out.append(c)
            continue
        if in_string and c == "\n":
            out.append("\\n")
            continue
        if in_string and c == "\r":
            out.append("\\r")
            continue
        if in_string and c == "\t":
            out.append("\\t")
            continue
        out.append(c)
    return "".join(out)


def _incremental_decode(raw: str, fixed: str, keys: tuple[str, ...]) -> dict:
    """Try to decode each known top-level key individually."""
    result: dict = {}
    decoder = json.JSONDecoder()

    for key in keys:
        pattern = r'"' + re.escape(key) + r'"\s*:\s*'
        m = re.search(pattern, raw)
        if not m:
            continue
        start = m.end()

        # Try both raw and fixed versions
        for src in (raw, fixed):
            try:
                value, _ = decoder.raw_decode(src[start:])
                result[key] = value
                break
            except json.JSONDecodeError:
                continue

    return result
