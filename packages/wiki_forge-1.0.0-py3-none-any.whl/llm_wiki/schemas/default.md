# LLM Wiki Schema

## Directory Layout

```
raw/          Immutable source documents — never modify
wiki/
  index.md    Catalog of all pages
  log.md      Append-only operation log
  overview.md Living synthesis
  sources/    One summary page per source (kebab-case.md)
  entities/   People, companies, products (TitleCase.md)
  concepts/   Ideas, frameworks, methods (TitleCase.md)
  syntheses/  Saved query answers
```

## Page Format

```yaml
---
title: "Page Title"
type: source | entity | concept | synthesis
tags: []
sources: []
last_updated: YYYY-MM-DD
---
```

Use `[[PageName]]` wikilinks to link between pages.

## Source Page Template

```markdown
---
title: "Source Title"
type: source
tags: []
date: YYYY-MM-DD
source_file: raw/...
---

## Summary
2–4 sentence summary.

## Key Claims
- Claim 1

## Connections
- [[EntityName]] — how they relate
- [[ConceptName]] — how it connects
```

## Naming Conventions

- Source slugs: `kebab-case`
- Entity pages: `TitleCase.md`
- Concept pages: `TitleCase.md`
