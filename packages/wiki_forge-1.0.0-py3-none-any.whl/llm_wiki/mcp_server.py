"""MCP (Model Context Protocol) server for llm-wiki.

Exposes four tools to AI assistants (Claude Desktop, Cursor, etc.):

  query_wiki   — LLM-powered Q&A synthesised from wiki pages (server LLM call)
  get_context  — Raw pages context for local synthesis (ZERO server LLM cost)
  search_pages — Fast BM25 keyword search, returns ranked page list
  read_page    — Read raw markdown of any wiki page by path

Transport: stdio (standard for MCP — the host launches this as a subprocess).

Usage in claude_desktop_config.json:
    {
      "mcpServers": {
        "llm-wiki": {
          "command": "llm-wiki",
          "args": ["mcp", "--vault", "/path/to/vault"]
        }
      }
    }
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from llm_wiki.config import Settings
from llm_wiki.pipeline.search import WikiSearchIndex
from llm_wiki.vault.paths import Vault

log = logging.getLogger(__name__)


def _build_index(vault: Vault) -> WikiSearchIndex:
    idx = WikiSearchIndex()
    idx.build(vault)
    log.debug("MCP: BM25 index built (%d pages)", len(idx._pages))
    return idx


def _discover_sibling_vaults(default_vault: Path) -> dict[str, Vault]:
    """Find all valid vaults: sibling folders + global registry.

    Sources (merged, deduped by name):
    1. Sibling folders of default_vault with `wiki/` subdirectory
    2. Global registry at ~/.llm-wiki/registry.json
    """
    vaults: dict[str, Vault] = {}

    # Source 1: sibling folders
    parent = default_vault.parent
    if parent.is_dir():
        for child in sorted(parent.iterdir()):
            if not child.is_dir() or child.name.startswith("."):
                continue
            if (child / "wiki").is_dir():
                vaults[child.name] = Vault(child)

    # Source 2: global registry (~/.llm-wiki/registry.json)
    registry_path = Path.home() / ".llm-wiki" / "registry.json"
    if registry_path.exists():
        try:
            import json
            reg = json.loads(registry_path.read_text(encoding="utf-8"))
            for path_str, info in reg.items():
                p = Path(path_str)
                name = info.get("name", p.name)
                if name not in vaults and p.is_dir() and (p / "wiki").is_dir():
                    vaults[name] = Vault(p)
                    log.debug("MCP: discovered vault from registry: %s → %s", name, p)
        except Exception as e:
            log.warning("MCP: failed to load registry: %s", e)

    # Ensure default is always present
    if default_vault.name not in vaults:
        vaults[default_vault.name] = Vault(default_vault)

    # Ensure default vault is included
    if default_vault.name not in vaults:
        vaults[default_vault.name] = Vault(default_vault)
    return vaults


def build_mcp_server(vault_root: Path, settings: Settings):
    """Build MCP Server with all tools registered. Returns (server, vault, bm25).

    Used by both stdio transport (run_mcp_server) and SSE transport (in server.py).

    Multi-vault: auto-discovers sibling vaults (parent folder). Tools accept
    optional `vault` parameter to target a specific vault; default is the one
    passed via --vault at startup.
    """
    import mcp.types as types
    from mcp.server import Server

    default_vault = Vault(vault_root)
    all_vaults = _discover_sibling_vaults(vault_root)
    default_name = vault_root.name

    # BM25 indices — lazy-built per vault on first use
    bm25_cache: dict[str, WikiSearchIndex] = {default_name: _build_index(default_vault)}

    def _resolve_vault(name: str | None) -> tuple[Vault, WikiSearchIndex]:
        """Return (vault, bm25) for given name (or default if None)."""
        key = name or default_name
        v = all_vaults.get(key)
        if v is None:
            # Fallback to default if unknown
            key = default_name
            v = default_vault
        if key not in bm25_cache:
            bm25_cache[key] = _build_index(v)
        return v, bm25_cache[key]

    # Backwards-compat: expose default vault/bm25 for existing callers
    vault = default_vault
    bm25 = bm25_cache[default_name]

    server = Server("llm-wiki")

    vault_names = list(all_vaults.keys())
    vault_enum_desc = (
        f"Vault name (one of: {', '.join(vault_names)}). "
        f"Default: '{default_name}' if omitted."
    )

    @server.list_tools()
    async def list_tools() -> list[types.Tool]:
        return [
            types.Tool(
                name="list_vaults",
                description=(
                    "List all available wiki vaults (projects/workspaces). "
                    f"Currently {len(all_vaults)} vault(s). "
                    "Use this first to discover which project to query."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
            types.Tool(
                name="query_wiki",
                description=(
                    "Answer a question using the wiki knowledge base. "
                    "Returns a synthesised markdown answer with [[wikilink]] citations. "
                    "Use for any conceptual or factual question about the project or codebase."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "question": {
                            "type": "string",
                            "description": "The question to answer (any language)",
                        },
                        "vault": {
                            "type": "string",
                            "description": vault_enum_desc,
                            "enum": vault_names,
                        },
                    },
                    "required": ["question"],
                },
            ),
            types.Tool(
                name="get_context",
                description=(
                    "Retrieve relevant wiki pages as raw markdown context (NO server LLM call). "
                    "Use this when you want to synthesise the answer yourself using your own reasoning. "
                    "Preferred over query_wiki for: multi-step reasoning, custom analysis, "
                    "zero server-side LLM cost, higher-quality synthesis by your (Claude) model.\n\n"
                    "Pipeline: BM25 + page-name match + graph expansion + re-rank — all local, free. "
                    "Returns top-k pages with full markdown content + citations info."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "question": {
                            "type": "string",
                            "description": "The question or topic to find context for (any language)",
                        },
                        "top_k": {
                            "type": "integer",
                            "description": "Max pages to return (default 8, max 20)",
                            "default": 8,
                        },
                        "vault": {
                            "type": "string",
                            "description": vault_enum_desc,
                            "enum": vault_names,
                        },
                    },
                    "required": ["question"],
                },
            ),
            types.Tool(
                name="search_pages",
                description=(
                    "Search wiki pages by keyword using BM25. "
                    "Returns a JSON list of {name, path, score, snippet}. "
                    "Use to discover relevant pages before reading them."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search keywords",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max results (default 10)",
                            "default": 10,
                        },
                        "vault": {
                            "type": "string",
                            "description": vault_enum_desc,
                            "enum": vault_names,
                        },
                    },
                    "required": ["query"],
                },
            ),
            types.Tool(
                name="read_page",
                description=(
                    "Read the raw markdown content of a specific wiki page. "
                    "Use the 'path' field returned by search_pages."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": (
                                "Path relative to the vault root, "
                                "e.g. 'wiki/outputs/code/tms-backend/ai-core.md'"
                            ),
                        },
                        "vault": {
                            "type": "string",
                            "description": vault_enum_desc,
                            "enum": vault_names,
                        },
                    },
                    "required": ["path"],
                },
            ),
        ]

    # ── Tool handlers ──────────────────────────────────────────────────────────

    @server.call_tool()
    async def call_tool(
        name: str, arguments: dict
    ) -> list[types.TextContent]:

        if name == "list_vaults":
            return _handle_list_vaults(all_vaults, default_name, types)

        # Resolve target vault for data-access tools
        v, b = _resolve_vault(arguments.get("vault"))

        if name == "query_wiki":
            return await _handle_query(arguments, v, b, settings, types)

        if name == "get_context":
            return _handle_get_context(arguments, v, b, types)

        if name == "search_pages":
            return _handle_search(arguments, v, b, types)

        if name == "read_page":
            return _handle_read(arguments, v, types)

        return [types.TextContent(type="text", text=f"Unknown tool: {name}")]

    return server, vault, bm25


async def run_mcp_server(vault_root: Path, settings: Settings) -> None:
    """Entry point — build index then serve over stdio until the host disconnects."""
    try:
        from mcp.server.stdio import stdio_server
    except ImportError as exc:
        raise SystemExit(
            "mcp package not installed. Run:  pip install 'llm-wiki[mcp]'"
        ) from exc

    server, _, _ = build_mcp_server(vault_root, settings)

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


# ── Handler helpers ────────────────────────────────────────────────────────────

def _handle_list_vaults(all_vaults, default_name, types):
    """Return JSON list of available vaults with page counts."""
    items = []
    for name, v in all_vaults.items():
        try:
            page_count = sum(1 for _ in v.all_pages())
        except Exception:
            page_count = 0
        items.append({
            "name": name,
            "is_default": name == default_name,
            "page_count": page_count,
            "path": str(v.root),
        })
    return [
        types.TextContent(
            type="text",
            text=json.dumps(items, ensure_ascii=False, indent=2),
        )
    ]


async def _handle_query(arguments, vault, bm25, settings, types):
    from llm_wiki.llm.gemini import GeminiClient
    from llm_wiki.pipeline.query import query_wiki

    question = arguments.get("question", "").strip()
    if not question:
        return [types.TextContent(type="text", text="(empty question)")]

    llm = GeminiClient(api_key=settings.gemini_api_key)
    try:
        result = await query_wiki(
            question, vault, llm, settings, _bm25_index=bm25
        )
    finally:
        await llm.close()

    text = result.answer
    if result.sources:
        lines = "\n".join(
            f"- {p.relative_to(vault.root)}" for p in result.sources
        )
        text += f"\n\n---\n**Sources ({len(result.sources)}):**\n{lines}"

    return [types.TextContent(type="text", text=text)]


def _handle_get_context(arguments, vault, bm25, types):
    """Return top-k pages as raw markdown context (no LLM call).

    Uses the same hybrid retrieval pipeline as query_wiki but skips LLM synthesis.
    The caller (Claude/Cursor) synthesises the answer locally.
    """
    from llm_wiki.pipeline.query import _find_relevant_pages

    question = arguments.get("question", "").strip()
    if not question:
        return [types.TextContent(type="text", text="(empty question)")]

    top_k = max(1, min(int(arguments.get("top_k", 8)), 20))

    # Hybrid retrieval: BM25 + page-name match + graph expansion + re-rank
    pages = _find_relevant_pages(question, vault, max_pages=top_k, _bm25_index=bm25)

    if not pages:
        return [
            types.TextContent(
                type="text",
                text=f"No relevant pages found for: {question}",
            )
        ]

    # Build context with all page content
    blocks: list[str] = [f"# Context for: {question}\n\nFound {len(pages)} relevant pages:\n"]

    for i, page in enumerate(pages, 1):
        rel = page.relative_to(vault.root).as_posix()
        stem = page.stem
        try:
            content = page.read_text(encoding="utf-8")
        except Exception as e:
            content = f"(error reading: {e})"

        blocks.append(
            f"\n---\n"
            f"## [{i}] {stem}\n"
            f"**Path**: `{rel}`\n"
            f"**Wikilink**: `[[{stem}]]`\n\n"
            f"{content}\n"
        )

    blocks.append(
        "\n---\n"
        "## Synthesis guidelines\n"
        "- Write the answer in the user's language\n"
        "- Cite sources using `[[wikilink]]` format (stem without .md)\n"
        "- If pages contradict, mention the conflict\n"
        "- If question is unclear or context insufficient, say so"
    )

    return [types.TextContent(type="text", text="\n".join(blocks))]


def _handle_search(arguments, vault, bm25, types):
    query = arguments.get("query", "").strip()
    limit = int(arguments.get("limit", 10))
    hits = bm25.search(query, limit=limit)
    results = [
        {
            "name": h.path.stem,
            "path": str(h.path.relative_to(vault.root)),
            "score": round(h.score, 3),
            "snippet": h.snippet,
        }
        for h in hits
    ]
    return [
        types.TextContent(
            type="text",
            text=json.dumps(results, ensure_ascii=False, indent=2),
        )
    ]


def _handle_read(arguments, vault, types):
    rel = arguments.get("path", "").strip()
    if not rel:
        return [types.TextContent(type="text", text="(no path provided)")]

    page = vault.root / rel
    if not page.exists():
        # Try under wiki/ prefix as a convenience
        page2 = vault.wiki / rel
        if page2.exists():
            page = page2
        else:
            return [types.TextContent(type="text", text=f"Page not found: {rel}")]

    content = page.read_text(encoding="utf-8")
    return [types.TextContent(type="text", text=content)]
