"""Pydantic models for llm-wiki."""
from __future__ import annotations

from datetime import date
from pathlib import Path

from pydantic import BaseModel, Field


class Concept(BaseModel):
    """A concept extracted from a source during ingest."""

    name: str
    aliases: list[str] = Field(default_factory=list)
    description: str = ""


class Entity(BaseModel):
    """An entity (person, company, product) mentioned in sources."""

    name: str
    type: str = "entity"
    aliases: list[str] = Field(default_factory=list)


class EntityPage(BaseModel):
    """An entity wiki page to be written."""

    path: str  # e.g. "entities/SkyJoy.md"
    content: str


class ConceptPage(BaseModel):
    """A concept wiki page to be written."""

    path: str  # e.g. "concepts/SkyPoint.md"
    content: str


class IngestResult(BaseModel):
    """Result of a single ingest operation — matches Gemini JSON output."""

    title: str
    slug: str
    source_page: str = ""
    index_entry: str = ""
    overview_update: str | None = None
    entity_pages: list[EntityPage] = Field(default_factory=list)
    concept_pages: list[ConceptPage] = Field(default_factory=list)
    contradictions: list[str] = Field(default_factory=list)
    log_entry: str = ""
    # Metadata (filled in by the pipeline, not by the LLM)
    input_tokens: int = 0
    output_tokens: int = 0
    skipped: bool = False  # True when --update mode skipped an unchanged source


class ReviewItem(BaseModel):
    """An item flagged by LLM during ingest that needs human review."""

    review_type: str  # contradiction, duplicate, missing-page, suggestion
    title: str
    detail: str
    source_file: str = ""
    affected_pages: list[str] = Field(default_factory=list)
    status: str = "open"  # open, approved, dismissed
    created: str = ""


class WikiPage(BaseModel):
    """A wiki page loaded from disk."""

    model_config = {"arbitrary_types_allowed": True}

    path: Path
    title: str
    type: str  # "source" | "entity" | "concept" | "synthesis"
    content: str
    frontmatter: dict = Field(default_factory=dict)
    last_updated: date | None = None
