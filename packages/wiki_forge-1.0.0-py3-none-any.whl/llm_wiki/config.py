"""Settings for llm-wiki — loaded from env vars via pydantic-settings."""
from __future__ import annotations

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """llm-wiki configuration.

    Environment variables are loaded with prefix ``LLM_WIKI_``, except
    API keys which use the standard provider names (``GEMINI_API_KEY``,
    ``ANTHROPIC_API_KEY``).
    """

    model_config = SettingsConfigDict(
        env_prefix="LLM_WIKI_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── LLM provider ─────────────────────────────────────────────
    provider: str = "gemini"  # gemini | openai | anthropic
    gemini_api_key: str = Field(default="", validation_alias="GEMINI_API_KEY")
    openai_api_key: str = Field(default="", validation_alias="OPENAI_API_KEY")
    openai_base_url: str = Field(default="https://api.openai.com/v1", validation_alias="OPENAI_BASE_URL")
    anthropic_api_key: str = Field(default="", validation_alias="ANTHROPIC_API_KEY")

    # ── Model selection (overridable per task) ───────────────────
    fast_model: str = "gemini-2.5-flash-lite"
    heavy_model: str = "gemini-2.5-flash-lite"

    # ── Ingest settings ──────────────────────────────────────────
    max_source_chars: int = 20000
    max_tokens_ingest: int = 32768
    llm_timeout: float = 300.0
    llm_max_retries: int = 3

    # ── Vault paths ──────────────────────────────────────────────
    vault_root: Path = Field(default_factory=Path.cwd)
    raw_dir_name: str = "raw"
    wiki_dir_name: str = "wiki"

    # ── Dedup parameters ─────────────────────────────────────────
    fuzzy_threshold: float = 0.7
    compact_substring_min_len: int = 6

    # ── Code-to-Doc settings ─────────────────────────────────────
    code_extensions: list[str] = Field(
        default_factory=lambda: [".py", ".md", ".js", ".jsx", ".ts", ".tsx", ".go", ".java", ".rs"]
    )
    code_max_file_size_bytes: int = 500 * 1024   # 500 KB
    code_max_source_chars: int = 8000
    code_concurrency: int = 5
    code_output_subdir: str = "wiki/outputs/code"
    code_parent_threshold: int = 20   # generate parent pages when modules >= this

    # ── CGC (CodeGraphContext) integration ──────────────────────
    cgc_enabled: bool = False                    # --cgc flag activates this
    cgc_db_path: str = ""                        # override KuzuDB storage path
    cgc_max_source_chars: int = 16000            # higher source budget when CGC active
    cgc_max_call_edges: int = 50                 # more edges per direction than default 20
    cgc_auto_index: bool = True                  # auto-index repo if no CGC index exists

    # ── Logging ──────────────────────────────────────────────────
    log_level: str = "INFO"

    # ── Properties ───────────────────────────────────────────────
    @property
    def raw_path(self) -> Path:
        return self.vault_root / self.raw_dir_name

    @property
    def wiki_path(self) -> Path:
        return self.vault_root / self.wiki_dir_name
