"""Optional CodeGraphContext (CGC) integration bridge.

Provides enriched call graphs, class hierarchies, function signatures,
and operational parameter extraction when CGC is installed and indexed.
Falls back gracefully when CGC is unavailable.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
from pathlib import Path

from llm_wiki.code.models import CallEdge, ModuleCallGraph

log = logging.getLogger(__name__)

# Patterns for operational parameter detection
_OP_PARAM_PATTERNS = re.compile(
    r"(?i)(timeout|cron|schedule|interval|retry|retries|max_|min_|"
    r"port|host|redis|celery|settings|config|ttl|cooldown|"
    r"batch|concurren|threshold|limit|delay|period|frequency|"
    r"worker|queue|pool_size|backoff)",
)


class CGCBridge:
    """Bridge between llm-wiki and CodeGraphContext.

    All CGC interactions go through this class. Safe to instantiate even
    when codegraphcontext is not installed — methods return empty/fallback data.

    Error handling strategy:
    - __init__: ImportError → available=False (expected). Other errors → warning + disabled.
    - ensure_indexed: failure → returns False + logs warning with actionable message.
    - query methods: failure → returns empty data + logs warning. Never raises.
    - warnings property: accumulated warnings for CLI display after pipeline completes.
    """

    def __init__(self, repo_path: Path, db_path: Path | None = None) -> None:
        self.repo_path = repo_path
        self.db_path = db_path
        self._available = False
        self._db_manager = None
        self._code_finder = None
        self._init_error: str | None = None
        self._warnings: list[str] = []

        try:
            from codegraphcontext.core import get_database_manager
            from codegraphcontext.tools.code_finder import CodeFinder

            # Force KuzuDB with explicit path for isolation
            if db_path:
                os.environ.setdefault("CGC_RUNTIME_DB_TYPE", "kuzudb")
                from codegraphcontext.core.database_kuzu import KuzuDBManager
                self._db_manager = KuzuDBManager(db_path=str(db_path))
            else:
                self._db_manager = get_database_manager()

            self._code_finder = CodeFinder(self._db_manager)
            self._available = True
            log.info("CGC bridge initialized (db: %s)", type(self._db_manager).__name__)
        except ImportError:
            self._init_error = (
                "codegraphcontext not installed. "
                "Install with: pip install codegraphcontext kuzu"
            )
            log.info("CGC: %s", self._init_error)
        except Exception as exc:
            self._init_error = f"CGC init failed: {exc}"
            log.warning(
                "CGC bridge init failed: %s. "
                "Try: pip install --upgrade codegraphcontext kuzu",
                exc,
            )

    @property
    def available(self) -> bool:
        return self._available

    @property
    def init_error(self) -> str | None:
        """Human-readable error if CGC is not available."""
        return self._init_error

    @property
    def warnings(self) -> list[str]:
        """Accumulated warnings from CGC operations during this session."""
        return list(self._warnings)

    def _warn(self, msg: str) -> None:
        """Record a warning for later display to user."""
        self._warnings.append(msg)
        log.warning("CGC: %s", msg)

    async def ensure_indexed(self, on_progress=None) -> bool:
        """Index the repo if no CGC index exists. Returns True when ready.

        Args:
            on_progress: Optional callback ``(current, total, message)`` for
                streaming indexing progress to the frontend.
        """
        if not self._available or not self._db_manager:
            return False

        # Check if THIS repo is already indexed (match by path)
        try:
            repo_str = str(self.repo_path)
            driver = self._db_manager.get_driver()
            with driver.session() as session:
                # Check for files from this specific repo
                result = session.run(
                    "MATCH (f:File) RETURN count(f) AS cnt LIMIT 1"
                )
                records = list(result)
                file_count = records[0].get("cnt", 0) if records else 0

                if file_count > 0:
                    # Verify files actually belong to this repo
                    sample = session.run(
                        "MATCH (f:File) RETURN f.path AS p LIMIT 1"
                    )
                    sample_records = list(sample)
                    if sample_records:
                        sample_path = sample_records[0].get("p", "")
                        if repo_str in sample_path:
                            log.info("CGC index exists for %s (%d files) — skipping re-index",
                                     self.repo_path.name, file_count)
                            return True
                        else:
                            log.info("CGC index is for different repo (%s) — will re-index",
                                     sample_path[:60])
        except Exception as exc:
            log.debug("CGC index check failed (will attempt fresh index): %s", exc)

        # Build index using patched pipeline (fixes CGC KuzuDB full_import_name bug)
        try:
            log.info("CGC indexing repo: %s (this may take 1-3 minutes)", self.repo_path)
            await self._run_patched_index(on_progress=on_progress)
            log.info("CGC indexing complete")
            # Marker writing is handled by the server (api_cgc_index)
            return True
        except RuntimeError as exc:
            if "no running event loop" in str(exc).lower() or "no current event loop" in str(exc).lower():
                self._warn(
                    "CGC indexing requires async context. "
                    "Pre-index manually: cgc index <repo_path>"
                )
            else:
                self._warn(f"CGC indexing failed: {exc}")
            return False
        except Exception as exc:
            self._warn(f"CGC indexing failed: {exc}. Try: cgc index {self.repo_path}")
            return False

    async def _run_patched_index(self, on_progress=None) -> None:
        """Run CGC indexing with Rust-accelerated parsing when available.

        Uses the Rust engine (parse_and_prescan + resolve) for ~5-18x speedup.
        Falls back to Python pipeline if Rust engine is not installed.

        The entire pipeline runs inside ``run_in_executor`` on a single thread
        to avoid KuzuDB concurrent-access deadlocks (KuzuDB allows only one
        writer connection per process).

        Args:
            on_progress: Optional callback ``(current, total, message)`` for
                streaming indexing progress to the frontend.
        """
        from codegraphcontext.tools.indexing.discovery import discover_files_to_index

        files, _ = discover_files_to_index(self.repo_path)
        source_files = [f for f in files if isinstance(f, Path) and f.is_file()]
        total_files = len(source_files)

        if on_progress:
            on_progress(0, total_files, f"Scanning {total_files} files...")

        # Check Rust availability (import only, no DB access)
        rust_available = False
        rust_imports = {}
        try:
            from codegraphcontext.tools.indexing.engine import (
                RUST_AVAILABLE,
                _RUST_SUPPORTED_LANGS,
                _rust_parse_and_prescan,
                _rust_resolve_calls,
                _rust_resolve_inheritance,
            )
            rust_available = RUST_AVAILABLE
            rust_imports = {
                "langs": _RUST_SUPPORTED_LANGS,
                "parse": _rust_parse_and_prescan,
                "calls": _rust_resolve_calls,
                "inherit": _rust_resolve_inheritance,
            }
        except ImportError:
            pass

        if rust_available:
            log.info("CGC using Rust-accelerated indexing engine")
        else:
            log.info("CGC using Python indexing pipeline")

        # Run entire pipeline in executor (single thread = no KuzuDB lock conflict)
        loop = asyncio.get_running_loop()

        def _sync_full_index():
            """All DB work on one thread: create builder → parse → write → resolve."""
            from codegraphcontext.core.jobs import JobManager
            from codegraphcontext.tools.graph_builder import GraphBuilder

            # Clear existing data via raw connection (same conn used by Parquet)
            try:
                driver = self._db_manager.get_driver()
                raw_conn = self._db_manager.get_raw_connection()
                if raw_conn:
                    for label in ("Function", "Class", "Variable", "File",
                                  "Module", "Repository", "Directory",
                                  "Parameter", "Enum", "Interface", "Struct",
                                  "Trait", "Macro", "Union", "Record",
                                  "Annotation", "Property"):
                        try:
                            raw_conn.execute(f"MATCH (n:{label}) DETACH DELETE n")
                        except Exception:
                            pass
                    log.info("CGC cleared previous index data")
            except Exception as exc:
                log.debug("CGC clear failed (fresh DB): %s", exc)

            job_manager = JobManager()
            builder = GraphBuilder(self._db_manager, job_manager, None)
            writer = builder._writer

            writer.add_repository_to_graph(self.repo_path, False)

            if rust_available:
                self._index_rust(
                    builder, writer, source_files, total_files, on_progress,
                    rust_imports,
                )
            else:
                self._index_python(
                    builder, writer, source_files, total_files, on_progress,
                )

        await loop.run_in_executor(None, _sync_full_index)

    def _index_rust(
        self, builder, writer, source_files, total_files, on_progress,
        rust_imports,
    ) -> None:
        """Rust-accelerated indexing (called from executor thread)."""
        import time

        parse_and_prescan = rust_imports["parse"]
        resolve_calls = rust_imports["calls"]
        resolve_inheritance = rust_imports["inherit"]
        supported_langs = rust_imports["langs"]

        if on_progress:
            on_progress(0, total_files, "Rust parallel parsing + pre-scan...")

        rust_specs = []
        fallback_files = []
        for f in source_files:
            lang = builder.parsers.get(f.suffix)
            if lang and lang in supported_langs and f.suffix != ".ipynb":
                rust_specs.append((str(f), lang, False))
            elif lang:
                fallback_files.append(f)

        t0 = time.time()
        rust_results, imports_map = parse_and_prescan(rust_specs)
        log.info("Rust parsed %d files in %.1fs (%d symbols)",
                 len(rust_specs), time.time() - t0, len(imports_map))

        # Collect all valid file data (patch imports)
        repo_path_str = str(self.repo_path)
        all_data: list[dict] = []

        for data in rust_results:
            if "error" not in data:
                data["repo_path"] = repo_path_str
                for imp in data.get("imports", []):
                    if "full_import_name" not in imp:
                        imp["full_import_name"] = imp.get("source", imp.get("name", ""))
                all_data.append(data)

        for f in fallback_files:
            data = builder.parse_file(self.repo_path, f, False)
            if "error" not in data:
                for imp in data.get("imports", []):
                    if "full_import_name" not in imp:
                        imp["full_import_name"] = imp.get("source", imp.get("name", ""))
                all_data.append(data)

        # Resolve call graph + inheritance (Rust, very fast)
        if on_progress:
            on_progress(total_files // 2, total_files, "Resolving call graph...")

        try:
            groups = resolve_calls(all_data, imports_map, False)
            total_calls = sum(len(g) for g in groups)
            log.info("CGC resolved %d call edges (Rust)", total_calls)
        except Exception as exc:
            self._warn(f"CGC call resolution failed: {exc}")
            groups = ([], [], [], [], [], [])

        try:
            inheritance, csharp = resolve_inheritance(all_data, imports_map)
        except Exception as exc:
            log.debug("CGC inheritance resolution failed: %s", exc)
            inheritance, csharp = [], []

        # Bulk write via Parquet COPY FROM (~11x faster than MERGE)
        if on_progress:
            on_progress(total_files * 3 // 4, total_files, "Writing to graph (Parquet bulk)...")

        t1 = time.time()
        try:
            from codegraphcontext.tools.indexing.persistence.parquet_loader import bulk_load_parquet
            driver = self._db_manager.get_driver()
            raw_conn = self._db_manager.get_raw_connection()
            counts = bulk_load_parquet(
                raw_conn, all_data, repo_path_str, groups, inheritance,
                on_progress=on_progress,
            )
            log.info("CGC Parquet bulk-loaded in %.1fs: %s", time.time() - t1, counts)
        except Exception as exc:
            log.warning("CGC Parquet bulk load failed, falling back to MERGE: %s", exc)
            # Fallback to MERGE writer
            writer.add_repository_to_graph(self.repo_path, False)
            try:
                writer.add_files_batch_to_graph(
                    all_data, self.repo_path.name, imports_map, repo_path_str,
                )
                writer.write_function_call_groups(*groups)
            except Exception:
                for data in all_data:
                    try:
                        writer.add_file_to_graph(data, self.repo_path.name, imports_map, repo_path_str)
                    except Exception:
                        pass

        log.info("CGC indexed %d/%d files", len(all_data), total_files)

    def _index_python(
        self, builder, writer, source_files, total_files, on_progress,
    ) -> None:
        """Python indexing pipeline fallback (called from executor thread)."""
        import time
        from codegraphcontext.tools.indexing.pre_scan import pre_scan_for_imports
        from codegraphcontext.tools.indexing.resolution.calls import build_function_call_groups
        from codegraphcontext.tools.indexing.resolution.inheritance import (
            build_inheritance_and_csharp_files,
        )

        if on_progress:
            on_progress(0, total_files, "Pre-scanning imports...")

        imports_map = pre_scan_for_imports(
            source_files, builder.parsers.keys(), builder.get_parser,
        )

        if on_progress:
            on_progress(0, total_files, "Parsing files...")

        all_data: list[dict] = []
        for i, f in enumerate(source_files):
            data = builder.parse_file(self.repo_path, f, False)
            if "error" not in data:
                for imp in data.get("imports", []):
                    if "full_import_name" not in imp:
                        imp["full_import_name"] = imp.get("source", imp.get("name", ""))
                all_data.append(data)

            if on_progress and i % 20 == 0 and i > 0:
                on_progress(i, total_files, f"Parsing files... ({i}/{total_files})")

        # Batch write all files at once
        t0 = time.time()
        try:
            written = writer.add_files_batch_to_graph(
                all_data, self.repo_path.name, imports_map, str(self.repo_path),
                on_progress=on_progress,
            )
            log.info("CGC batch-wrote %d files in %.1fs", written, time.time() - t0)
        except Exception as exc:
            log.warning("CGC batch write failed, falling back to per-file: %s", exc)
            for data in all_data:
                try:
                    writer.add_file_to_graph(data, self.repo_path.name, imports_map, str(self.repo_path))
                except Exception:
                    pass

        log.info("CGC indexed %d/%d files", len(all_data), len(source_files))

        if on_progress:
            on_progress(total_files, total_files, "Resolving call graph...")

        try:
            file_class_lookup = writer.get_repo_class_lookup(self.repo_path)
            groups = build_function_call_groups(all_data, imports_map, file_class_lookup)
            writer.write_function_call_groups(*groups)
            total_calls = sum(len(g) for g in groups)
            log.info("CGC resolved %d call edges", total_calls)
        except Exception as exc:
            self._warn(f"CGC call resolution failed: {exc}")

        try:
            inheritance, csharp = build_inheritance_and_csharp_files(all_data, imports_map)
            writer.write_inheritance_links(inheritance, csharp, imports_map)
        except Exception as exc:
            log.debug("CGC inheritance resolution failed: %s", exc)

    def get_call_graph_for_module(
        self,
        module_files: list[str],
        all_module_map: dict[str, str],
    ) -> ModuleCallGraph:
        """Query CGC for CALLS edges involving files in this module.

        Args:
            module_files: Relative file paths belonging to this module.
            all_module_map: Maps rel_path → module_slug for all modules.

        Returns:
            ModuleCallGraph with intra/outgoing/incoming edges.
        """
        if not self._available or not self._db_manager:
            return ModuleCallGraph()

        repo_str = str(self.repo_path)
        abs_paths = [os.path.join(repo_str, p) for p in module_files]
        abs_set = set(abs_paths)

        try:
            driver = self._db_manager.get_driver()
            with driver.session() as session:
                result = session.run(
                    "MATCH (caller:Function)-[c:CALLS]->(callee:Function) "
                    "RETURN caller.name AS cn, caller.path AS cp, "
                    "callee.name AS en, callee.path AS ep"
                )
                records = list(result)
        except Exception as exc:
            self._warn(f"Call graph query failed for {len(module_files)} files: {exc}")
            return ModuleCallGraph()

        graph = ModuleCallGraph()
        seen: set[tuple[str, str, str, str]] = set()

        for rec in records:
            caller_abs = rec.get("cp", "")
            callee_abs = rec.get("ep", "")
            caller_in = caller_abs in abs_set
            callee_in = callee_abs in abs_set

            if not caller_in and not callee_in:
                continue

            # Convert to relative paths
            caller_rel = os.path.relpath(caller_abs, repo_str) if caller_abs else ""
            callee_rel = os.path.relpath(callee_abs, repo_str) if callee_abs else ""

            edge_key = (caller_rel, rec.get("cn", ""), callee_rel, rec.get("en", ""))
            if edge_key in seen:
                continue
            seen.add(edge_key)

            edge = CallEdge(
                from_file=caller_rel,
                from_name=rec.get("cn", ""),
                to_file=callee_rel,
                to_name=rec.get("en", ""),
            )

            if caller_in and callee_in:
                graph.intra.append(edge)
            elif caller_in:
                graph.outgoing.append(edge)
            else:
                graph.incoming.append(edge)

        return graph

    def get_class_hierarchies(self, class_names: list[str]) -> list[dict]:
        """Get class hierarchy data for given class names.

        Returns list of dicts with keys: class_name, parent_classes, child_classes, methods.
        """
        if not self._available or not self._code_finder:
            return []

        results: list[dict] = []
        failed = 0
        for name in class_names:
            try:
                hierarchy = self._code_finder.find_class_hierarchy(
                    name, repo_path=str(self.repo_path),
                )
                if hierarchy and (hierarchy.get("parent_classes") or hierarchy.get("child_classes")):
                    results.append(hierarchy)
            except Exception:
                failed += 1

        if failed > 0:
            log.debug("CGC class hierarchy: %d found, %d failed lookups", len(results), failed)
        return results

    def get_symbol_signatures(self, file_paths: list[str]) -> dict[str, list[dict]]:
        """Get function signatures with args, decorators, docstrings for given files.

        Returns {rel_path: [{name, args, decorators, line_number, docstring}]}.
        """
        if not self._available or not self._db_manager:
            return {}

        repo_str = str(self.repo_path)
        abs_paths = [os.path.join(repo_str, p) for p in file_paths]

        try:
            driver = self._db_manager.get_driver()
            with driver.session() as session:
                result = session.run(
                    "MATCH (f:File)-[:CONTAINS]->(func:Function) "
                    "RETURN func.name AS name, func.path AS path, "
                    "func.line_number AS line, func.docstring AS doc, "
                    "func.args AS args, func.decorators AS decs"
                )
                records = list(result)
        except Exception as exc:
            self._warn(f"Symbol signatures query failed: {exc}")
            return {}

        sigs: dict[str, list[dict]] = {}
        abs_set = set(abs_paths)
        for rec in records:
            abs_path = rec.get("path", "")
            if abs_path not in abs_set:
                continue
            rel_path = os.path.relpath(abs_path, repo_str)
            entry = {
                "name": rec.get("name", ""),
                "line_number": rec.get("line", 0),
                "args": rec.get("args") or [],
                "decorators": [d for d in (rec.get("decs") or []) if d],
                "docstring": (rec.get("doc") or "")[:200],
            }
            sigs.setdefault(rel_path, []).append(entry)

        return sigs

    def get_operational_params(self, file_paths: list[str]) -> list[dict]:
        """Extract variables/constants that look like operational parameters.

        Filters Variable and Class nodes by name patterns (TIMEOUT, CRON, MAX_, etc.).
        Returns list of {name, value, path, line_number}.
        """
        if not self._available or not self._db_manager:
            return []

        repo_str = str(self.repo_path)
        abs_paths = [os.path.join(repo_str, p) for p in file_paths]
        abs_set = set(abs_paths)

        params: list[dict] = []

        try:
            driver = self._db_manager.get_driver()
            with driver.session() as session:
                # Query Variables
                result = session.run(
                    "MATCH (v:Variable) "
                    "RETURN v.name AS name, v.value AS val, "
                    "v.path AS path, v.line_number AS line, v.context AS ctx"
                )
                for rec in list(result):
                    abs_path = rec.get("path", "")
                    if abs_path not in abs_set:
                        continue
                    name = rec.get("name", "")
                    if not _OP_PARAM_PATTERNS.search(name):
                        continue
                    params.append({
                        "name": name,
                        "value": rec.get("val", ""),
                        "path": os.path.relpath(abs_path, repo_str),
                        "line_number": rec.get("line", 0),
                    })

                # Query Class source for config-like classes
                result = session.run(
                    "MATCH (c:Class) RETURN c.name AS name, c.source AS src, "
                    "c.path AS path, c.line_number AS line"
                )
                for rec in list(result):
                    abs_path = rec.get("path", "")
                    if abs_path not in abs_set:
                        continue
                    src = rec.get("src", "") or ""
                    name = rec.get("name", "")
                    # Include if class source mentions operational keywords
                    if _OP_PARAM_PATTERNS.search(name) or _OP_PARAM_PATTERNS.search(src[:500]):
                        params.append({
                            "name": f"class {name}",
                            "value": src[:2000],
                            "path": os.path.relpath(abs_path, repo_str),
                            "line_number": rec.get("line", 0),
                        })

        except Exception as exc:
            self._warn(f"Operational params query failed: {exc}")

        return params

    def get_all_stats(self) -> dict:
        """Return aggregate counts from the CGC graph.

        Returns dict with keys: files, functions, classes, variables, call_edges, modules.
        Returns empty dict on failure (never raises).
        """
        if not self._available or not self._db_manager:
            return {}

        stats: dict = {}
        try:
            driver = self._db_manager.get_driver()
            with driver.session() as session:
                for label, key in [
                    ("File", "files"),
                    ("Function", "functions"),
                    ("Class", "classes"),
                    ("Variable", "variables"),
                    ("Module", "modules"),
                ]:
                    result = session.run(f"MATCH (n:{label}) RETURN count(n) AS cnt")
                    records = list(result)
                    stats[key] = records[0].get("cnt", 0) if records else 0

                # Call edges
                result = session.run(
                    "MATCH ()-[r:CALLS]->() RETURN count(r) AS cnt"
                )
                records = list(result)
                stats["call_edges"] = records[0].get("cnt", 0) if records else 0

        except Exception as exc:
            self._warn(f"Stats query failed: {exc}")

        return stats

    def get_top_connected(self, limit: int = 10) -> list[dict]:
        """Return the most-connected functions (by total caller + callee count).

        Returns list of {name, path, callers, callees, total}.
        Returns empty list on failure (never raises).
        """
        if not self._available or not self._db_manager:
            return []

        try:
            driver = self._db_manager.get_driver()
            repo_str = str(self.repo_path)
            results: dict[str, dict] = {}

            with driver.session() as session:
                # Count callees per function (any target type)
                callees = session.run(
                    "MATCH (f:Function)-[:CALLS]->() "
                    "RETURN f.name AS name, f.path AS path, count(*) AS cnt"
                )
                for rec in list(callees):
                    key = f"{rec.get('name', '')}@{rec.get('path', '')}"
                    if key not in results:
                        abs_path = rec.get("path", "")
                        rel = os.path.relpath(abs_path, repo_str) if abs_path else ""
                        results[key] = {"name": rec.get("name", ""), "path": rel, "callers": 0, "callees": 0}
                    results[key]["callees"] = rec.get("cnt", 0)

                # Count callers per function (any source type)
                callers = session.run(
                    "MATCH ()-[:CALLS]->(f:Function) "
                    "RETURN f.name AS name, f.path AS path, count(*) AS cnt"
                )
                for rec in list(callers):
                    key = f"{rec.get('name', '')}@{rec.get('path', '')}"
                    if key not in results:
                        abs_path = rec.get("path", "")
                        rel = os.path.relpath(abs_path, repo_str) if abs_path else ""
                        results[key] = {"name": rec.get("name", ""), "path": rel, "callers": 0, "callees": 0}
                    results[key]["callers"] = rec.get("cnt", 0)

            # Sort by total connections
            ranked = sorted(
                results.values(),
                key=lambda x: x["callers"] + x["callees"],
                reverse=True,
            )
            for item in ranked:
                item["total"] = item["callers"] + item["callees"]

            return ranked[:limit]

        except Exception as exc:
            self._warn(f"Top connected query failed: {exc}")
            return []

    def close(self) -> None:
        """Clean up database connections."""
        if self._db_manager:
            try:
                self._db_manager.close()
            except Exception as exc:
                log.debug("CGC close error (ignored): %s", exc)
            self._db_manager = None
            self._code_finder = None
