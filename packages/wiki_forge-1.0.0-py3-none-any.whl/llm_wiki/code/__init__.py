"""Code-to-Doc: analyse a codebase and generate wiki documentation."""
