"""Scan a repository and extract file metadata for Code-to-Doc."""
from __future__ import annotations

import ast
import fnmatch
import hashlib
import json
import logging
import re
from pathlib import Path

from llm_wiki.code.models import CallEdge, CodeFileMeta, ModuleCallGraph

log = logging.getLogger(__name__)

# Directories and patterns to always skip
_SKIP_DIRS: frozenset[str] = frozenset(
    {
        # General VCS / tooling
        ".git", ".hg", ".svn",
        # Python
        "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
        "venv", ".venv", "env", ".env", "site-packages", ".tox", "eggs", ".eggs",
        # JavaScript / Node
        "node_modules", ".next", ".nuxt", ".turbo", "coverage", ".nyc_output",
        # Java / JVM
        "target",
        # Go
        "vendor",
        # Rust
        # "target" already covered above
        # Build output (general)
        "dist", "build", "htmlcov", "out",
    }
)

_SKIP_SUFFIXES: frozenset[str] = frozenset({
    # Python bytecode
    ".pyc", ".pyo", ".pyd",
    # JS/TS compiled output
    ".js.map", ".d.ts",
    # Java compiled
    ".class",
    # Rust compiled
    ".rlib",
})


# ── .gitignore support ────────────────────────────────────────────────────────

def _parse_gitignore(gitignore_path: Path) -> list[str]:
    """Return non-comment, non-empty patterns from a .gitignore file."""
    patterns: list[str] = []
    try:
        for line in gitignore_path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                patterns.append(line)
    except OSError:
        pass
    return patterns


def _collect_gitignore_patterns(repo_path: Path) -> list[tuple[Path, list[str]]]:
    """Find all .gitignore files under *repo_path* and return (dir, patterns) pairs."""
    result: list[tuple[Path, list[str]]] = []
    for gi_file in sorted(repo_path.rglob(".gitignore")):
        patterns = _parse_gitignore(gi_file)
        if patterns:
            result.append((gi_file.parent, patterns))
    return result


def _is_gitignored(
    file_path: Path,
    repo_path: Path,
    gitignore_rules: list[tuple[Path, list[str]]],
) -> bool:
    """Return True if *file_path* matches any collected .gitignore rule."""
    rel = file_path.relative_to(repo_path).as_posix()
    rel_parts = rel.split("/")

    for gi_dir, patterns in gitignore_rules:
        # Only apply patterns from a .gitignore to files under that directory
        try:
            rel_from_gi = file_path.relative_to(gi_dir).as_posix()
        except ValueError:
            continue

        for pattern in patterns:
            # Trailing slash means directory-only pattern
            dir_only = pattern.endswith("/")
            pat = pattern.rstrip("/")

            # Anchored pattern (contains slash not at end): match from gitignore dir
            if "/" in pat:
                if fnmatch.fnmatch(rel_from_gi, pat):
                    return True
                if dir_only and any(
                    fnmatch.fnmatch("/".join(rel_from_gi.split("/")[: i + 1]), pat)
                    for i in range(len(rel_from_gi.split("/")))
                ):
                    return True
            else:
                # Un-anchored: match against any path component or full rel path
                name = file_path.name
                if fnmatch.fnmatch(name, pat):
                    return True
                # Also check if any directory component matches (for dir-only patterns)
                if dir_only:
                    for part in rel_parts[:-1]:
                        if fnmatch.fnmatch(part, pat):
                            return True
                # Match against the full relative path from gitignore dir
                if fnmatch.fnmatch(rel_from_gi, pat):
                    return True

    return False

_MAX_FILE_SIZE = 500 * 1024  # 500 KB


def extract_python_symbols(content: str) -> list[str]:
    """Return top-level public function and class names from Python source."""
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return []

    symbols: list[str] = []
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if not node.name.startswith("_"):
                symbols.append(node.name)
    return symbols


def extract_markdown_symbols(content: str) -> list[str]:
    """Return H1 and H2 headings as symbols from Markdown content."""
    symbols: list[str] = []
    for line in content.splitlines():
        m = re.match(r"^#{1,2}\s+(.+)", line)
        if m:
            symbols.append(m.group(1).strip())
    return symbols


# ── JS / TypeScript ───────────────────────────────────────────────────────────

# Matches exported functions, classes, consts, interfaces, enums, types
_JS_EXPORT_RE = re.compile(
    r"^export\s+(?:default\s+)?(?:async\s+)?(?:function\s*\*?\s*|class\s+)(\w+)"  # function/class
    r"|^export\s+(?:const|let|var)\s+(\w+)\s*(?::[^=]+)?="                          # const/let/var
    r"|^export\s+(?:interface|enum|type)\s+(\w+)",                                  # interface/enum/type
    re.MULTILINE,
)


def extract_js_symbols(content: str) -> list[str]:
    """Return exported symbol names from JavaScript/TypeScript source."""
    symbols: list[str] = []
    for m in _JS_EXPORT_RE.finditer(content):
        name = m.group(1) or m.group(2) or m.group(3)
        if name:
            symbols.append(name)
    return symbols


# ── Go ────────────────────────────────────────────────────────────────────────

# Only exported identifiers (start with uppercase)
_GO_FUNC_RE = re.compile(r"^func\s+(?:\([^)]+\)\s+)?([A-Z]\w*)\s*[(\[]", re.MULTILINE)
_GO_TYPE_RE = re.compile(r"^type\s+([A-Z]\w*)\s+(?:struct|interface)", re.MULTILINE)
_GO_VAR_RE  = re.compile(r"^(?:var|const)\s+([A-Z]\w*)\s", re.MULTILINE)


def extract_go_symbols(content: str) -> list[str]:
    """Return exported identifier names from Go source."""
    symbols: list[str] = []
    for m in _GO_FUNC_RE.finditer(content):
        symbols.append(m.group(1))
    for m in _GO_TYPE_RE.finditer(content):
        symbols.append(m.group(1))
    for m in _GO_VAR_RE.finditer(content):
        symbols.append(m.group(1))
    return symbols


# ── Java ──────────────────────────────────────────────────────────────────────

_JAVA_TYPE_RE = re.compile(
    r"(?:^|\s)(?:public|protected)\s+(?:(?:abstract|final|static)\s+)*"
    r"(?:class|interface|enum|record)\s+(\w+)",
    re.MULTILINE,
)
_JAVA_METHOD_RE = re.compile(
    r"(?:^|\s)(?:public|protected)\s+(?:(?:static|final|synchronized|abstract)\s+)*"
    r"(?:[\w<>\[\],\s]+?)\s+(\w+)\s*\(",
    re.MULTILINE,
)
_JAVA_SKIP_KEYWORDS = frozenset(
    {"class", "interface", "enum", "record", "if", "while", "for", "switch", "catch", "new"}
)


def extract_java_symbols(content: str) -> list[str]:
    """Return public class/interface/method names from Java source."""
    symbols: list[str] = []
    for m in _JAVA_TYPE_RE.finditer(content):
        symbols.append(m.group(1))
    for m in _JAVA_METHOD_RE.finditer(content):
        name = m.group(1)
        if name not in _JAVA_SKIP_KEYWORDS:
            symbols.append(name)
    return symbols


# ── Rust ──────────────────────────────────────────────────────────────────────

_RUST_PUB_RE = re.compile(
    r"^pub(?:\([^)]+\))?\s+(?:async\s+)?(?:fn|struct|enum|trait|type|const)\s+(\w+)",
    re.MULTILINE,
)


def extract_rust_symbols(content: str) -> list[str]:
    """Return public item names from Rust source."""
    return [m.group(1) for m in _RUST_PUB_RE.finditer(content)]


# ── Dispatch table ────────────────────────────────────────────────────────────

_SYMBOL_EXTRACTORS = {
    ".py":  extract_python_symbols,
    ".md":  extract_markdown_symbols,
    ".js":  extract_js_symbols,
    ".jsx": extract_js_symbols,
    ".ts":  extract_js_symbols,
    ".tsx": extract_js_symbols,
    ".mjs": extract_js_symbols,
    ".cjs": extract_js_symbols,
    ".go":  extract_go_symbols,
    ".java": extract_java_symbols,
    ".rs":  extract_rust_symbols,
}


def _file_hash(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()[:16]


def scan_repo(
    repo_path: Path,
    extensions: list[str] | None = None,
    max_file_size: int = _MAX_FILE_SIZE,
    respect_gitignore: bool = True,
) -> list[CodeFileMeta]:
    """Walk *repo_path* and return metadata for every matching source file.

    Args:
        repo_path: Root directory of the repository.
        extensions: File suffixes to include (default: ``.py`` and ``.md``).
        max_file_size: Files larger than this (bytes) are skipped.
        respect_gitignore: If True (default), read all ``.gitignore`` files
            under *repo_path* and skip matched paths.

    Returns:
        List of :class:`CodeFileMeta`, sorted by relative path.
    """
    if extensions is None:
        extensions = list(_SYMBOL_EXTRACTORS.keys())
    ext_set = {e if e.startswith(".") else f".{e}" for e in extensions}

    gitignore_rules: list[tuple[Path, list[str]]] = []
    if respect_gitignore:
        gitignore_rules = _collect_gitignore_patterns(repo_path)
        total_patterns = sum(len(p) for _, p in gitignore_rules)
        log.debug(
            "Loaded %d .gitignore file(s) with %d patterns",
            len(gitignore_rules),
            total_patterns,
        )

    results: list[CodeFileMeta] = []

    for file_path in sorted(repo_path.rglob("*")):
        # Skip directories, skip-listed names, and unwanted suffixes
        if not file_path.is_file():
            continue
        if any(part in _SKIP_DIRS for part in file_path.parts):
            continue
        if file_path.suffix in _SKIP_SUFFIXES:
            continue
        if file_path.suffix not in ext_set:
            continue
        if respect_gitignore and _is_gitignored(file_path, repo_path, gitignore_rules):
            log.debug("gitignored: %s", file_path.relative_to(repo_path))
            continue

        size = file_path.stat().st_size
        if size > max_file_size:
            log.debug("Skipping large file (%d bytes): %s", size, file_path)
            continue

        try:
            content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            log.warning("Cannot read %s: %s", file_path, exc)
            continue

        rel = file_path.relative_to(repo_path).as_posix()

        extractor = _SYMBOL_EXTRACTORS.get(file_path.suffix, lambda _: [])
        symbols = extractor(content)

        results.append(
            CodeFileMeta(
                path=rel,
                content=content,
                symbols=symbols,
                size_bytes=size,
                file_hash=_file_hash(content),
            )
        )

    return results


# ── Call graph extraction ─────────────────────────────────────────────────────

def _extract_python_calls(content: str) -> list[str]:
    """Return names of all top-level function/method calls in Python source."""
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return []
    calls: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                calls.append(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                calls.append(node.func.attr)
    return calls


def _extract_python_imports(content: str) -> list[str]:
    """Return all imported names from Python source (flat names only)."""
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return []
    names: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                names.append(alias.asname or alias.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                names.append(alias.asname or alias.name.split(".")[0])
    return names


def build_call_graph(
    files: list[CodeFileMeta],
    module_file_map: dict[str, str],   # rel_path → module_slug
) -> dict[str, ModuleCallGraph]:
    """Build intra/outgoing/incoming call edges for each module.

    Algorithm:
    1. Build symbol → (file, module_slug) index from all exported symbols.
    2. For each Python file, extract call sites.
    3. Match call names against symbol index → emit CallEdge.
    4. Classify as intra (same module) or inter (different module).

    Args:
        files: All scanned files.
        module_file_map: Maps each file rel_path to its module slug.

    Returns:
        dict mapping module_slug → ModuleCallGraph
    """
    # symbol_name → list[(file_path, module_slug)] — may have duplicates
    symbol_index: dict[str, list[tuple[str, str]]] = {}
    for f in files:
        mod = module_file_map.get(f.path, "")
        for sym in f.symbols:
            symbol_index.setdefault(sym, []).append((f.path, mod))

    graphs: dict[str, ModuleCallGraph] = {}

    for f in files:
        if not f.path.endswith(".py"):
            continue
        caller_mod = module_file_map.get(f.path, "")
        if not caller_mod:
            continue
        if caller_mod not in graphs:
            graphs[caller_mod] = ModuleCallGraph()

        call_names = _extract_python_calls(f.content)
        seen: set[tuple[str, str, str, str]] = set()

        for name in call_names:
            targets = symbol_index.get(name, [])
            for to_file, to_mod in targets:
                edge_key = (f.path, name, to_file, name)
                if edge_key in seen:
                    continue
                seen.add(edge_key)

                edge = CallEdge(
                    from_file=f.path,
                    from_name=name,
                    to_file=to_file,
                    to_name=name,
                )

                if to_mod == caller_mod:
                    graphs[caller_mod].intra.append(edge)
                else:
                    graphs[caller_mod].outgoing.append(edge)
                    # Register incoming on the target module
                    if to_mod not in graphs:
                        graphs[to_mod] = ModuleCallGraph()
                    graphs[to_mod].incoming.append(edge)

    return graphs


# ── Hash cache ────────────────────────────────────────────────────────────────

def load_hash_cache(cache_path: Path) -> dict[str, str]:
    """Load ``{rel_path: file_hash}`` mapping from JSON cache file."""
    if not cache_path.exists():
        return {}
    try:
        return json.loads(cache_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_hash_cache(cache_path: Path, cache: dict[str, str]) -> None:
    """Persist hash cache to disk."""
    cache_path.write_text(json.dumps(cache, indent=2), encoding="utf-8")
