"""Data models for the Code-to-Doc pipeline."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field


def slugify(name: str) -> str:
    """Convert a module name to a kebab-case slug.

    >>> slugify("Authentication Layer")
    'authentication-layer'
    >>> slugify("API / Routes")
    'api-routes'
    """
    nfkd = unicodedata.normalize("NFKD", name)
    ascii_str = nfkd.encode("ascii", "ignore").decode()
    lowered = ascii_str.lower()
    cleaned = re.sub(r"[^a-z0-9]+", "-", lowered).strip("-")
    return cleaned or "module"


@dataclass
class CodeFileMeta:
    """Metadata for a single source file discovered in the repo."""

    path: str           # relative path from repo root (forward slashes)
    content: str        # full source text
    symbols: list[str]  # exported function/class/heading names
    size_bytes: int
    file_hash: str      # first 16 hex chars of sha256


@dataclass
class ModuleGroup:
    """A logical documentation module grouping one or more files."""

    name: str               # human-readable, e.g. "Authentication"
    slug: str               # kebab-case, e.g. "authentication"
    files: list[CodeFileMeta] = field(default_factory=list)

    @classmethod
    def from_name(cls, name: str, files: list[CodeFileMeta] | None = None) -> "ModuleGroup":
        return cls(name=name, slug=slugify(name), files=files or [])


@dataclass
class ParentGroup:
    """A parent group aggregating multiple ModuleGroups into a hierarchy level."""

    name: str               # human-readable, e.g. "Pipeline"
    slug: str               # kebab-case, e.g. "pipeline"
    children: list[str] = field(default_factory=list)   # child module slugs

    @classmethod
    def from_name(cls, name: str, children: list[str] | None = None) -> "ParentGroup":
        return cls(name=name, slug=slugify(name), children=children or [])


@dataclass
class CallEdge:
    """A directed call or import relationship between two symbols."""

    from_file: str   # relative path
    from_name: str   # caller symbol name
    to_file: str     # relative path (empty string = external)
    to_name: str     # callee symbol name


@dataclass
class ModuleCallGraph:
    """Pre-computed call edges for one module, grouped by direction."""

    intra: list[CallEdge] = field(default_factory=list)      # calls within module
    outgoing: list[CallEdge] = field(default_factory=list)   # calls to other modules
    incoming: list[CallEdge] = field(default_factory=list)   # calls from other modules


@dataclass
class CodeIngestResult:
    """Final output of a full Code-to-Doc run."""

    repo_path: str
    modules: list[ModuleGroup]
    overview_doc: str
    module_docs: dict[str, str]      # slug → markdown content
    token_usage: dict[str, int]      # phase → total tokens (input + output)
    skipped_files: list[str] = field(default_factory=list)
    parent_groups: list[ParentGroup] = field(default_factory=list)
    parent_docs: dict[str, str] = field(default_factory=dict)  # parent_slug → markdown
