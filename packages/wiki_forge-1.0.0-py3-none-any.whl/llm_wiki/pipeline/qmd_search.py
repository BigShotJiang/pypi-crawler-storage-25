"""QMD hybrid search integration — BM25 + Vector + RRF + LLM re-ranking.

Runs QMD via CLI subprocess (npx tsx) since QMD is a Node.js project.
Falls back gracefully if QMD not available.
"""
from __future__ import annotations

import json
import logging
import subprocess
import shutil
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)

# QMD project location (adjust if different)
_QMD_PROJECT = Path("/Users/thanhhuynh/Documents/GitHub/finos/research-git-wiki/example/qmd")
_NODE_PATH = "/Users/thanhhuynh/.nvm/versions/node/v22.22.0/bin"


@dataclass
class QMDResult:
    path: str
    score: float
    snippet: str = ""
    docid: str = ""


class QMDSearcher:
    """Search via QMD CLI (BM25 + Vector + RRF)."""

    def __init__(self, vault_path: Path, qmd_project: Path | None = None):
        self.vault_path = vault_path
        self.qmd_project = qmd_project or _QMD_PROJECT
        self._available: bool | None = None

    def search(self, query: str, limit: int = 10, mode: str = "search") -> list[QMDResult]:
        """Search using QMD CLI. mode: 'search' (BM25), 'vsearch' (vector), 'query' (hybrid)."""
        if not self.is_available():
            return []

        try:
            cmd = [
                f"{_NODE_PATH}/npx",
                "--prefix", str(self.qmd_project),
                "tsx",
                str(self.qmd_project / "src" / "cli" / "qmd.ts"),
                mode,
                query,
                "-n", str(limit),
                "--json",
            ]

            env = {
                "PATH": f"{_NODE_PATH}:/usr/bin:/bin:/usr/local/bin",
                "HOME": str(Path.home()),
                "NODE_PATH": str(self.qmd_project / "node_modules"),
            }

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
                cwd=str(self.vault_path),
                env=env,
            )

            if result.returncode != 0:
                stderr = result.stderr[:300] if result.stderr else ""
                log.warning("QMD CLI failed (exit %d): %s", result.returncode, stderr)
                return []

            # Parse JSON output
            stdout = result.stdout.strip()
            if not stdout:
                return []

            data = json.loads(stdout)
            results = []
            items = data if isinstance(data, list) else data.get("results", [])
            for item in items:
                # Extract path from qmd:// URI
                path = item.get("file", item.get("path", ""))
                if path.startswith("qmd://"):
                    path = path[6:]  # strip qmd://

                results.append(QMDResult(
                    path=path,
                    score=item.get("score", 0.0),
                    snippet=item.get("snippet", ""),
                    docid=item.get("docid", ""),
                ))

            log.info("QMD %s: %d results for '%s' (top: %.2f)",
                     mode, len(results), query[:50],
                     results[0].score if results else 0)
            return results

        except subprocess.TimeoutExpired:
            log.warning("QMD CLI timeout (60s)")
            return []
        except json.JSONDecodeError as e:
            log.warning("QMD CLI JSON parse error: %s", e)
            return []
        except Exception as e:
            log.warning("QMD CLI error: %s", e)
            return []

    def is_available(self) -> bool:
        """Check if QMD is installed and indexed."""
        if self._available is not None:
            return self._available

        # Check QMD project exists
        if not (self.qmd_project / "src" / "cli" / "qmd.ts").exists():
            log.info("QMD project not found at %s", self.qmd_project)
            self._available = False
            return False

        # Check npx exists
        if not shutil.which("npx", path=_NODE_PATH):
            log.info("npx not found in %s", _NODE_PATH)
            self._available = False
            return False

        # Check QMD has index
        try:
            cmd = [
                f"{_NODE_PATH}/npx",
                "--prefix", str(self.qmd_project),
                "tsx",
                str(self.qmd_project / "src" / "cli" / "qmd.ts"),
                "status",
            ]
            env = {
                "PATH": f"{_NODE_PATH}:/usr/bin:/bin:/usr/local/bin",
                "HOME": str(Path.home()),
            }
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15, env=env)
            if "0 files indexed" in result.stdout:
                log.info("QMD has no indexed files")
                self._available = False
                return False

            self._available = True
            log.info("QMD search backend: available (indexed)")
            return True
        except Exception as e:
            log.info("QMD status check failed: %s", e)
            self._available = False
            return False
