"""Pipeline operations: ingest, query, lint."""
from llm_wiki.pipeline.ingest import ingest_source
from llm_wiki.pipeline.lint import lint_vault
from llm_wiki.pipeline.query import query_wiki

__all__ = ["ingest_source", "query_wiki", "lint_vault"]
