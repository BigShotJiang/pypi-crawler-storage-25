"""Code-to-Doc pipeline: scan repo → GROUPING → MODULE_DOC × N → OVERVIEW."""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from llm_wiki.code.extractor import build_call_graph, load_hash_cache, save_hash_cache, scan_repo
from llm_wiki.code.models import CodeFileMeta, CodeIngestResult, ModuleCallGraph, ModuleGroup, ParentGroup
from llm_wiki.code.cgc_bridge import CGCBridge
from llm_wiki.code.prompts import (
    GROUPING_SYSTEM,
    GROUPING_USER,
    MODULE_SYSTEM,
    MODULE_USER,
    MODULE_USER_CGC,
    OVERVIEW_SYSTEM,
    OVERVIEW_USER,
    PARENT_DOC_SYSTEM,
    PARENT_DOC_USER,
    PARENT_GROUPING_SYSTEM,
    PARENT_GROUPING_USER,
    format_call_edges,
    format_directory_tree,
    format_file_list,
    format_module_source,
    format_symbol_list,
    strip_json_fences,
)
from llm_wiki.config import Settings
from llm_wiki.llm.base import LLMProvider

log = logging.getLogger(__name__)

_DEFAULT_CONCURRENCY = 5


# ── Phase 1: GROUPING ─────────────────────────────────────────────────────────

_GROUPING_COMPACT_THRESHOLD = 80   # switch to path-only list above this count


async def _run_grouping(
    files: list[CodeFileMeta],
    llm: LLMProvider,
    settings: Settings,
) -> dict[str, list[str]]:
    """Ask the LLM to group files into logical modules.

    Returns ``{module_name: [rel_path, ...]}``.

    For large repos (> _GROUPING_COMPACT_THRESHOLD files) we send only file
    paths — no symbol lists — to keep the prompt within the output token budget.
    max_tokens scales with file count so the JSON is never cut off.
    """
    all_paths = [f.path for f in files]

    if len(files) > _GROUPING_COMPACT_THRESHOLD:
        # Compact mode: paths only + top-3 symbols per file to save tokens
        lines = []
        for f in files:
            syms = ", ".join(f.symbols[:3]) if f.symbols else ""
            lines.append(f"- {f.path}" + (f" ({syms})" if syms else ""))
        file_list_str = "\n".join(lines)
        log.debug("GROUPING compact mode: %d files", len(files))
    else:
        file_list_str = format_file_list(files)

    prompt = GROUPING_USER.format(
        file_list=file_list_str,
        directory_tree=format_directory_tree(all_paths),
    )

    # Scale max_tokens: each file needs ~10 output chars in the JSON
    max_tokens = max(4096, min(len(files) * 30, 16384))

    resp = await llm.generate(
        prompt,
        system=GROUPING_SYSTEM,
        model=settings.fast_model,
        max_tokens=max_tokens,
        response_format="json",
    )
    raw = strip_json_fences(resp.text)
    try:
        grouping: dict[str, list[str]] = json.loads(raw)
    except json.JSONDecodeError:
        log.warning("GROUPING: JSON parse failed, placing all files in one module")
        grouping = {"Codebase": all_paths}

    token_total = resp.input_tokens + resp.output_tokens
    log.info("GROUPING done — %d modules, %d tokens", len(grouping), token_total)
    return grouping, resp.input_tokens + resp.output_tokens


# ── Phase 2: MODULE_DOC ───────────────────────────────────────────────────────


def _format_class_hierarchies(hierarchies: list[dict]) -> str:
    """Format CGC class hierarchy data for prompt inclusion."""
    lines: list[str] = []
    for h in hierarchies:
        lines.append(f"**{h.get('class_name', '?')}**")
        parents = h.get("parent_classes") or []
        if parents:
            names = ", ".join(p.get("parent_class", "?") for p in parents)
            lines.append(f"  Extends: {names}")
        children = h.get("child_classes") or []
        if children:
            names = ", ".join(c.get("child_class", "?") for c in children)
            lines.append(f"  Subclasses: {names}")
        methods = h.get("methods") or []
        if methods:
            names = ", ".join(m.get("method_name", "?") for m in methods[:10])
            lines.append(f"  Methods: {names}")
    return "\n".join(lines) or "(none)"


def _format_signatures(signatures: dict[str, list[dict]]) -> str:
    """Format CGC function signatures for prompt inclusion."""
    lines: list[str] = []
    for file_path, funcs in signatures.items():
        for f in funcs[:15]:
            args = ", ".join(f.get("args") or [])
            decs = f.get("decorators") or []
            dec_str = f"  @{', '.join(decs)}" if decs else ""
            lines.append(
                f"  {f.get('name', '?')}({args}){dec_str}"
                f"  [{file_path}:{f.get('line_number', '?')}]"
            )
    return "\n".join(lines[:40]) or "(none)"


def _format_operational_params(params: list[dict]) -> str:
    """Format operational parameters for prompt inclusion."""
    lines: list[str] = []
    for p in params[:30]:
        val = str(p.get("value", "") or "")
        if len(val) > 200:
            val = val[:200] + "..."
        lines.append(
            f"  {p.get('name', '?')} = {val}"
            f"  [{p.get('path', '')}:{p.get('line_number', '?')}]"
        )
    return "\n".join(lines) or "(none)"


async def _run_module_doc(
    group: ModuleGroup,
    all_groups: list,
    call_graph: dict[str, ModuleCallGraph],
    llm: LLMProvider,
    settings: Settings,
    sem: asyncio.Semaphore,
    cgc: CGCBridge | None = None,
) -> tuple[str, str, int]:
    """Generate documentation for one module. Returns (slug, markdown, tokens)."""
    async with sem:
        # Source budget: higher when CGC is active
        if cgc and cgc.available:
            max_src = getattr(settings, "cgc_max_source_chars", 16000)
            max_edges = getattr(settings, "cgc_max_call_edges", 50)
        else:
            max_src = getattr(settings, "code_max_source_chars", 8000)
            max_edges = 20

        other_modules = "\n".join(
            f"- {g.name} ([[{g.slug}]])"
            for g in all_groups
            if g.slug != group.slug
        )
        cg = call_graph.get(group.slug, ModuleCallGraph())

        # CGC-enriched sections
        cgc_class_hierarchy = ""
        cgc_signatures = ""
        cgc_operational_params = ""

        if cgc and cgc.available:
            file_paths = [f.path for f in group.files]

            # Class hierarchies
            class_names = [s for f in group.files for s in f.symbols if s[0:1].isupper()]
            if class_names:
                hierarchies = cgc.get_class_hierarchies(class_names[:20])
                if hierarchies:
                    cgc_class_hierarchy = _format_class_hierarchies(hierarchies)

            # Function signatures
            signatures = cgc.get_symbol_signatures(file_paths)
            if signatures:
                cgc_signatures = _format_signatures(signatures)

            # Operational parameters
            op_params = cgc.get_operational_params(file_paths)
            if op_params:
                cgc_operational_params = _format_operational_params(op_params)

        # Choose prompt template
        use_cgc_prompt = bool(cgc_class_hierarchy or cgc_signatures or cgc_operational_params)

        if use_cgc_prompt:
            prompt = MODULE_USER_CGC.format(
                module_name=group.name,
                file_list=format_file_list(group.files),
                symbol_list=format_symbol_list(group.files),
                function_signatures=cgc_signatures or "(none)",
                class_hierarchy=cgc_class_hierarchy or "(none)",
                source_code=format_module_source(group.files, max_chars=max_src),
                intra_calls=format_call_edges(cg.intra, max=max_edges),
                outgoing_calls=format_call_edges(cg.outgoing, max=max_edges),
                incoming_calls=format_call_edges(cg.incoming, max=max_edges),
                operational_params=cgc_operational_params or "(none)",
                other_modules=other_modules or "(none)",
            )
        else:
            prompt = MODULE_USER.format(
                module_name=group.name,
                file_list=format_file_list(group.files),
                symbol_list=format_symbol_list(group.files),
                source_code=format_module_source(group.files, max_chars=max_src),
                intra_calls=format_call_edges(cg.intra),
                outgoing_calls=format_call_edges(cg.outgoing),
                incoming_calls=format_call_edges(cg.incoming),
                other_modules=other_modules or "(none)",
            )

        resp = await llm.generate(
            prompt,
            system=MODULE_SYSTEM,
            model=settings.fast_model,
            max_tokens=getattr(settings, "max_tokens_ingest", 8192),
        )
        tokens = resp.input_tokens + resp.output_tokens
        mode = "CGC" if use_cgc_prompt else "std"
        log.info("MODULE_DOC [%s] done — %d tokens (%s)", group.name, tokens, mode)
        return group.slug, resp.text.strip(), tokens


# ── Phase 2.5: PARENT HIERARCHY ───────────────────────────────────────────────

async def _run_parent_grouping(
    groups: list[ModuleGroup],
    llm: LLMProvider,
    settings: Settings,
) -> tuple[dict[str, list[str]], int]:
    """Ask LLM to group modules into parent categories.

    Returns ``({parent_name: [slug, ...]}, tokens)``.
    """
    module_list = "\n".join(f"- {g.slug}: {g.name}" for g in groups)
    prompt = PARENT_GROUPING_USER.format(n_modules=len(groups), module_list=module_list)
    resp = await llm.generate(
        prompt,
        system=PARENT_GROUPING_SYSTEM,
        model=settings.fast_model,
        max_tokens=2048,
        response_format="json",
    )
    raw = strip_json_fences(resp.text)
    tokens = resp.input_tokens + resp.output_tokens
    try:
        result: dict[str, list[str]] = json.loads(raw)
        log.info("PARENT_GROUPING done — %d parents, %d tokens", len(result), tokens)
        return result, tokens
    except json.JSONDecodeError:
        log.warning("PARENT_GROUPING: JSON parse failed, skipping hierarchy")
        return {}, tokens


async def _run_parent_doc(
    parent_name: str,
    child_groups: list[ModuleGroup],
    module_docs: dict[str, str],
    llm: LLMProvider,
    settings: Settings,
    sem: asyncio.Semaphore,
) -> tuple[str, str, int]:
    """Generate a parent overview page. Returns (parent_slug, markdown, tokens)."""
    from llm_wiki.code.models import slugify

    parent_slug = slugify(parent_name)
    async with sem:
        summaries = []
        for g in child_groups:
            doc = module_docs.get(g.slug, "")
            preview = doc[:300].strip()
            if len(doc) > 300:
                preview += "..."
            summaries.append(f"### [[{g.slug}]] — {g.name}\n\n{preview}")

        prompt = PARENT_DOC_USER.format(
            parent_name=parent_name,
            child_summaries="\n\n".join(summaries),
        )
        resp = await llm.generate(
            prompt,
            system=PARENT_DOC_SYSTEM,
            model=settings.fast_model,
            max_tokens=2048,
        )
        tokens = resp.input_tokens + resp.output_tokens
        log.info("PARENT_DOC [%s] done — %d tokens", parent_name, tokens)
        return parent_slug, resp.text.strip(), tokens


def _write_parent_doc(
    output_dir: Path,
    parent_name: str,
    parent_slug: str,
    content: str,
    child_slugs: list[str],
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    out_file = output_dir / f"parent-{parent_slug}.md"
    children_yaml = "\n".join(f"  - {s}" for s in child_slugs)
    frontmatter = (
        f"---\n"
        f"title: \"{parent_name}\"\n"
        f"type: code-parent\n"
        f"children:\n{children_yaml}\n"
        f"generated_at: {_now_iso()}\n"
        f"---\n\n"
    )
    out_file.write_text(frontmatter + content, encoding="utf-8")
    log.info("Wrote parent doc: %s", out_file)


# ── Phase 3: OVERVIEW ─────────────────────────────────────────────────────────

async def _run_overview(
    project_name: str,
    groups: list[ModuleGroup],
    module_docs: dict[str, str],
    all_paths: list[str],
    llm: LLMProvider,
    settings: Settings,
) -> tuple[str, int]:
    """Generate the top-level overview page. Returns (markdown, tokens)."""
    summaries_parts = []
    for g in groups:
        doc = module_docs.get(g.slug, "")
        # Keep only first 500 chars of each module doc as summary
        preview = doc[:500].strip()
        if len(doc) > 500:
            preview += "..."
        summaries_parts.append(f"### [{g.name}]({g.slug}.md)\n\n{preview}")

    summaries = "\n\n".join(summaries_parts)

    prompt = OVERVIEW_USER.format(
        project_name=project_name,
        module_summaries=summaries,
        directory_tree=format_directory_tree(all_paths),
    )
    resp = await llm.generate(
        prompt,
        system=OVERVIEW_SYSTEM,
        model=settings.fast_model,
        max_tokens=getattr(settings, "max_tokens_ingest", 8192),
    )
    tokens = resp.input_tokens + resp.output_tokens
    log.info("OVERVIEW done — %d tokens", tokens)
    return resp.text.strip(), tokens


# ── Vault writing ─────────────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def _write_module_doc(output_dir: Path, group: ModuleGroup, content: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    out_file = output_dir / f"{group.slug}.md"
    source_list = "\n".join(f"  - {f.path}" for f in group.files)
    frontmatter = (
        f"---\n"
        f"title: \"{group.name}\"\n"
        f"type: code-module\n"
        f"source_files:\n{source_list}\n"
        f"generated_at: {_now_iso()}\n"
        f"---\n\n"
    )
    out_file.write_text(frontmatter + content, encoding="utf-8")
    log.info("Wrote module doc: %s", out_file)


def _write_overview(output_dir: Path, project_name: str, content: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    out_file = output_dir / "overview.md"
    frontmatter = (
        f"---\n"
        f"title: \"{project_name} — Code Overview\"\n"
        f"type: code-overview\n"
        f"generated_at: {_now_iso()}\n"
        f"---\n\n"
    )
    out_file.write_text(frontmatter + content, encoding="utf-8")
    log.info("Wrote overview: %s", out_file)


# ── Main entry point ──────────────────────────────────────────────────────────

async def ingest_code(
    repo_path: Path,
    vault_root: Path,
    llm: LLMProvider,
    settings: Settings,
    *,
    update: bool = False,
    extensions: list[str] | None = None,
    output_subdir: str = "wiki/outputs/code",
    dry_run: bool = False,
    project_name: str | None = None,
    on_progress: callable | None = None,
    include_dirs: list[str] | None = None,
) -> CodeIngestResult:
    """Run the full Code-to-Doc pipeline.

    Args:
        repo_path: Root directory of the source repository to analyse.
        vault_root: Root of the llm-wiki vault where output will be written.
        llm: LLM provider instance.
        settings: llm-wiki settings.
        update: If True, skip files whose hash has not changed since last run.
        extensions: File extensions to scan (default: .py, .md).
        output_subdir: Subdirectory inside *vault_root* for output files.
        dry_run: If True, print plan but write nothing.
        on_progress: Optional callback ``(phase: str, data: dict) -> None``
            called at each pipeline phase boundary for progress tracking.
        include_dirs: If set, only include files under these top-level directories.
            Used by the web UI module selection to skip unwanted dirs (e.g. tests, migrations).

    Returns:
        :class:`CodeIngestResult` summarising the run.
    """
    def _progress(phase: str, **data):
        if on_progress:
            on_progress(phase, data)
    project_name = project_name or repo_path.resolve().name
    output_dir = vault_root / output_subdir
    cache_path = vault_root / ".gitwiki_code_cache.json"

    max_file_size = getattr(settings, "code_max_file_size_bytes", 500 * 1024)

    # ── Step 1: Scan repo ────────────────────────────────────────────────────
    log.info("Scanning repo: %s", repo_path)
    all_files = scan_repo(repo_path, extensions=extensions, max_file_size=max_file_size)
    log.info("Found %d source files", len(all_files))

    # Filter by selected directories (web UI module selection)
    if include_dirs:
        before = len(all_files)
        include_set = set(include_dirs)
        all_files = [
            f for f in all_files
            if any(
                part in include_set
                for part in Path(f.path).relative_to(repo_path).parts[:2]
            )
        ]
        log.info("Filtered to %d files (from %d) by include_dirs: %s",
                 len(all_files), before, include_dirs)

    if not all_files:
        log.warning("No source files found in %s", repo_path)
        return CodeIngestResult(
            repo_path=str(repo_path),
            modules=[],
            overview_doc="",
            module_docs={},
            token_usage={},
        )

    # ── Step 2: --update filter ──────────────────────────────────────────────
    skipped_paths: list[str] = []
    changed_paths: set[str] = set()
    if update:
        cache = load_hash_cache(cache_path)
        for f in all_files:
            if cache.get(f.path) == f.file_hash:
                skipped_paths.append(f.path)
            else:
                changed_paths.add(f.path)
        log.info("Update mode: %d changed, %d unchanged", len(changed_paths), len(skipped_paths))
    else:
        changed_paths = {f.path for f in all_files}

    # Short-circuit: if ALL files unchanged, skip entire pipeline
    if update and not changed_paths:
        log.info("All %d files unchanged — skipping pipeline entirely", len(all_files))
        # Count existing docs
        existing_docs = list(output_dir.glob("*.md")) if output_dir.exists() else []
        return CodeIngestResult(
            repo_path=str(repo_path),
            modules=[],
            overview_doc="",
            module_docs={},
            token_usage={"total": 0},
            skipped_files=skipped_paths,
        )

    all_paths = [f.path for f in all_files]

    # ── Step 2b: CGC initialization (optional) ──────────────────────────────
    cgc: CGCBridge | None = None
    if getattr(settings, "cgc_enabled", False):
        cgc_db = (
            Path(settings.cgc_db_path) if settings.cgc_db_path
            else vault_root / ".cgc_index" / "kuzudb"
        )
        # If cgc_db_path was explicitly set (e.g. from web UI api_cgc_process),
        # the index was already built — skip auto_index to avoid double indexing.
        pre_indexed = bool(settings.cgc_db_path)
        cgc = CGCBridge(repo_path, db_path=cgc_db)
        if cgc.available:
            if not pre_indexed and getattr(settings, "cgc_auto_index", True):
                indexed = await cgc.ensure_indexed()
                if indexed:
                    log.info("CGC index: ready")
                else:
                    log.warning("CGC index failed — falling back to built-in extractor")
                    cgc = None
            else:
                log.info("CGC index: ready (pre-indexed)")
        else:
            log.warning(
                "CGC requested but unavailable: %s",
                cgc.init_error or "unknown error",
            )
            cgc = None

    # ── Step 3: GROUPING (always uses ALL files for stable module structure)
    _progress("grouping", message=f"Grouping {len(all_files)} files into modules...")
    log.info("Phase 1: GROUPING (%d files)", len(all_files))
    file_index = {f.path: f for f in all_files}
    grouping_map, grouping_tokens = await _run_grouping(all_files, llm, settings)

    groups: list[ModuleGroup] = []
    for module_name, paths in grouping_map.items():
        group_files = [file_index[p] for p in paths if p in file_index]
        if group_files:
            groups.append(ModuleGroup.from_name(module_name, group_files))

    if not groups:
        log.warning("GROUPING returned no valid groups; aborting")
        return CodeIngestResult(
            repo_path=str(repo_path),
            modules=[],
            overview_doc="",
            module_docs={},
            token_usage={"grouping": grouping_tokens},
            skipped_files=skipped_paths,
        )

    # ── Step 3b: Build call graph ────────────────────────────────────────────
    log.info("Building call graph (%d files)", len(all_files))
    module_file_map: dict[str, str] = {}
    for g in groups:
        for f in g.files:
            module_file_map[f.path] = g.slug

    if cgc and cgc.available:
        # CGC call graph: all languages, Tree-sitter AST
        call_graph: dict[str, ModuleCallGraph] = {}
        for g in groups:
            file_paths = [f.path for f in g.files]
            call_graph[g.slug] = cgc.get_call_graph_for_module(file_paths, module_file_map)
        log.info("CGC call graph: %d modules", len(call_graph))
    else:
        # Fallback: Python-only built-in
        call_graph = build_call_graph(all_files, module_file_map)

    total_edges = sum(
        len(cg.intra) + len(cg.outgoing)
        for cg in call_graph.values()
    )
    log.info("Call graph: %d modules, %d edges", len(call_graph), total_edges)

    if dry_run:
        log.info("[dry-run] Would generate docs for %d modules", len(groups))
        for g in groups:
            log.info("  Module: %s (%d files)", g.name, len(g.files))
        return CodeIngestResult(
            repo_path=str(repo_path),
            modules=groups,
            overview_doc="",
            module_docs={},
            token_usage={"grouping": grouping_tokens},
            skipped_files=skipped_paths,
        )

    # ── Step 4: MODULE_DOC (parallel, skip unchanged modules) ──────────────
    concurrency = getattr(settings, "code_concurrency", _DEFAULT_CONCURRENCY)
    sem = asyncio.Semaphore(concurrency)

    module_docs: dict[str, str] = {}
    module_tokens = 0
    skipped_modules = 0

    # Separate modules into changed vs unchanged
    groups_to_generate: list[ModuleGroup] = []
    for g in groups:
        module_has_changes = any(f.path in changed_paths for f in g.files)
        existing_doc = output_dir / f"{g.slug}.md"

        if update and not module_has_changes and existing_doc.exists():
            # All files unchanged + doc exists → reuse existing doc
            module_docs[g.slug] = existing_doc.read_text(encoding="utf-8")
            skipped_modules += 1
        else:
            groups_to_generate.append(g)

    if skipped_modules:
        log.info("Phase 2: MODULE_DOC — %d to generate, %d skipped (unchanged)",
                 len(groups_to_generate), skipped_modules)
    else:
        log.info("Phase 2: MODULE_DOC (%d modules)", len(groups_to_generate))

    if groups_to_generate:
        _progress("module_doc", message=f"Generating docs for {len(groups_to_generate)} modules...",
                  total=len(groups_to_generate), current=0)
        tasks = [_run_module_doc(g, groups, call_graph, llm, settings, sem, cgc=cgc) for g in groups_to_generate]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for i, (group, result) in enumerate(zip(groups_to_generate, results)):
            if isinstance(result, Exception):
                log.warning("MODULE_DOC [%s] failed: %s", group.name, result)
                module_docs[group.slug] = f"# {group.name}\n\n*(documentation generation failed)*"
            else:
                slug, doc, tokens = result
                module_docs[slug] = doc
                module_tokens += tokens
            _progress("module_doc", current=i + 1, total=len(groups_to_generate), module=group.name)

    # Write module docs to vault (only changed ones)
    for group in groups_to_generate:
        doc = module_docs.get(group.slug, "")
        _write_module_doc(output_dir, group, doc)

    # ── Step 4b: PARENT HIERARCHY (when modules >= threshold) ───────────────
    parent_groups: list[ParentGroup] = []
    parent_docs: dict[str, str] = {}
    parent_tokens = 0
    threshold = getattr(settings, "code_parent_threshold", 20)

    if len(groups) >= threshold:
        log.info("Phase 2.5: PARENT HIERARCHY (%d modules >= threshold %d)", len(groups), threshold)
        parent_map, pg_tokens = await _run_parent_grouping(groups, llm, settings)
        parent_tokens += pg_tokens

        if parent_map:
            # Build slug → group lookup
            slug_to_group = {g.slug: g for g in groups}

            # Build ParentGroup objects (validate that child slugs exist)
            valid_parents: list[tuple[str, list[ModuleGroup]]] = []
            for pname, child_slugs in parent_map.items():
                child_groups_for_parent = [slug_to_group[s] for s in child_slugs if s in slug_to_group]
                if len(child_groups_for_parent) >= 2:
                    valid_parents.append((pname, child_groups_for_parent))

            # Generate parent docs in parallel
            parent_tasks = [
                _run_parent_doc(pname, children, module_docs, llm, settings, sem)
                for pname, children in valid_parents
            ]
            parent_results = await asyncio.gather(*parent_tasks, return_exceptions=True)

            for (pname, children), result in zip(valid_parents, parent_results):
                if isinstance(result, Exception):
                    log.warning("PARENT_DOC [%s] failed: %s", pname, result)
                    continue
                pslug, pdoc, ptokens = result
                parent_docs[pslug] = pdoc
                parent_tokens += ptokens
                child_slugs = [g.slug for g in children]
                parent_groups.append(ParentGroup.from_name(pname, child_slugs))
                _write_parent_doc(output_dir, pname, pslug, pdoc, child_slugs)

            log.info("PARENT HIERARCHY done — %d parent pages written", len(parent_groups))

    # ── Step 5: OVERVIEW ────────────────────────────────────────────────────
    _progress("overview", message="Generating project overview...")
    log.info("Phase 3: OVERVIEW")
    overview_doc, overview_tokens = await _run_overview(
        project_name, groups, module_docs, all_paths, llm, settings
    )
    _write_overview(output_dir, project_name, overview_doc)

    # ── Step 6: Update hash cache ────────────────────────────────────────────
    new_cache = {f.path: f.file_hash for f in all_files}
    save_hash_cache(cache_path, new_cache)

    # ── Cleanup CGC ────────────────────────────────────────────────────────
    cgc_warnings: list[str] = []
    if cgc:
        cgc_warnings = cgc.warnings
        if cgc_warnings:
            log.warning("CGC completed with %d warning(s):", len(cgc_warnings))
            for w in cgc_warnings:
                log.warning("  - %s", w)
        cgc.close()

    token_usage = {
        "grouping": grouping_tokens,
        "module_docs": module_tokens,
        "parent_hierarchy": parent_tokens,
        "overview": overview_tokens,
        "total": grouping_tokens + module_tokens + parent_tokens + overview_tokens,
        "cgc_active": bool(cgc),
        "cgc_warnings": cgc_warnings,
    }
    log.info(
        "Code-to-Doc complete: %d modules, %d parents, %d total tokens",
        len(groups),
        len(parent_groups),
        token_usage["total"],
    )
    _progress("done", modules=len(groups), tokens=token_usage["total"])

    return CodeIngestResult(
        repo_path=str(repo_path),
        modules=groups,
        overview_doc=overview_doc,
        module_docs=module_docs,
        token_usage=token_usage,
        skipped_files=skipped_paths,
        parent_groups=parent_groups,
        parent_docs=parent_docs,
    )
