"""4-Signal Wiki Graph for retrieval re-ranking.

Builds a lightweight in-memory graph from wiki pages (wikilinks + frontmatter)
and scores pairwise relevance using four signals:

  1. Direct wikilink  (weight 3.0) — A links to B or B links to A
  2. Source overlap    (weight 4.0) — A and B share the same source file
  3. Common neighbors  (weight 1.5) — Adamic-Adar: shared neighbors, penalise hubs
  4. Type affinity     (weight 1.0) — concept↔entity score higher than same-type

Usage:
    graph = WikiGraph()
    graph.build(vault)
    related = graph.get_related("eKYC", limit=5)
    score = graph.relevance("eKYC", "SDK")
"""
from __future__ import annotations

import logging
import math
import re
from dataclasses import dataclass, field
from pathlib import Path

from llm_wiki.vault.paths import Vault
from llm_wiki.vault.wikilinks import extract_wikilinks

log = logging.getLogger(__name__)

# ── Weights ──────────────────────────────────────────────────────────────

WEIGHT_DIRECT_LINK = 3.0
WEIGHT_SOURCE_OVERLAP = 4.0
WEIGHT_COMMON_NEIGHBOR = 1.5
WEIGHT_TYPE_AFFINITY = 1.0

# Cross-type affinity matrix (higher = more useful to see together)
_TYPE_AFFINITY: dict[str, dict[str, float]] = {
    "entity": {"concept": 1.2, "entity": 0.8, "source": 1.0, "synthesis": 1.0, "code": 0.6},
    "concept": {"entity": 1.2, "concept": 0.8, "source": 1.0, "synthesis": 1.2, "code": 0.8},
    "source": {"entity": 1.0, "concept": 1.0, "source": 0.5, "synthesis": 1.0, "code": 0.6},
    "synthesis": {"concept": 1.2, "entity": 1.0, "source": 1.0, "synthesis": 0.8, "code": 0.8},
    "code": {"entity": 0.6, "concept": 0.8, "source": 0.6, "synthesis": 0.8, "code": 0.5},
}


# ── Data structures ──────────────────────────────────────────────────────

@dataclass
class GraphNode:
    """A wiki page in the graph."""
    id: str          # stem (filename without .md)
    path: Path
    page_type: str   # entity, concept, source, synthesis, code, other
    sources: list[str] = field(default_factory=list)  # frontmatter sources
    out_links: set[str] = field(default_factory=set)   # stems this page links to
    in_links: set[str] = field(default_factory=set)    # stems that link to this page


@dataclass
class WikiGraph:
    """In-memory wiki graph for retrieval re-ranking."""

    nodes: dict[str, GraphNode] = field(default_factory=dict)

    def build(self, vault: Vault) -> None:
        """Build graph from all vault pages. Call on startup / after ingest."""
        self.nodes.clear()
        pages = vault.all_pages()
        if not pages:
            return

        # First pass: create nodes
        for page in pages:
            node_id = page.stem.lower()
            try:
                content = page.read_text(encoding="utf-8")
            except OSError:
                continue

            page_type = _extract_type(content, page)
            sources = _extract_sources(content)
            raw_links = extract_wikilinks(content)

            self.nodes[node_id] = GraphNode(
                id=node_id,
                path=page,
                page_type=page_type,
                sources=sources,
                out_links={link.lower() for link in raw_links},
            )

        # Second pass: resolve links + build in_links
        all_ids = set(self.nodes.keys())
        for node in self.nodes.values():
            resolved = set()
            for link in node.out_links:
                target = _resolve_target(link, all_ids)
                if target and target != node.id:
                    resolved.add(target)
            node.out_links = resolved
            for target_id in resolved:
                if target_id in self.nodes:
                    self.nodes[target_id].in_links.add(node.id)

        log.debug("Wiki graph built: %d nodes, %d edges",
                  len(self.nodes),
                  sum(len(n.out_links) for n in self.nodes.values()))

    def relevance(self, id_a: str, id_b: str) -> float:
        """Calculate pairwise relevance score between two nodes."""
        a = self.nodes.get(id_a.lower())
        b = self.nodes.get(id_b.lower())
        if not a or not b or a.id == b.id:
            return 0.0

        # Signal 1: Direct links
        forward = 1.0 if b.id in a.out_links else 0.0
        backward = 1.0 if a.id in b.out_links else 0.0
        direct = (forward + backward) * WEIGHT_DIRECT_LINK

        # Signal 2: Source overlap
        sources_a = set(a.sources)
        shared = sum(1 for s in b.sources if s in sources_a)
        source_score = shared * WEIGHT_SOURCE_OVERLAP

        # Signal 3: Common neighbors (Adamic-Adar)
        neighbors_a = a.out_links | a.in_links
        neighbors_b = b.out_links | b.in_links
        adamic_adar = 0.0
        for common in neighbors_a & neighbors_b:
            neighbor = self.nodes.get(common)
            if neighbor:
                degree = len(neighbor.out_links) + len(neighbor.in_links)
                adamic_adar += 1.0 / math.log(max(degree, 2))
        neighbor_score = adamic_adar * WEIGHT_COMMON_NEIGHBOR

        # Signal 4: Type affinity
        affinity_map = _TYPE_AFFINITY.get(a.page_type, {})
        type_score = affinity_map.get(b.page_type, 0.5) * WEIGHT_TYPE_AFFINITY

        return direct + source_score + neighbor_score + type_score

    def get_related(self, node_id: str, limit: int = 5) -> list[tuple[str, float]]:
        """Get top related nodes by relevance score."""
        node_id = node_id.lower()
        if node_id not in self.nodes:
            return []

        scored = []
        for other_id in self.nodes:
            if other_id == node_id:
                continue
            score = self.relevance(node_id, other_id)
            if score > 0:
                scored.append((other_id, score))

        scored.sort(key=lambda x: -x[1])
        return scored[:limit]

    def expand_candidates(
        self,
        seed_ids: list[str],
        max_expand: int = 10,
    ) -> list[tuple[str, float]]:
        """Expand seed nodes via graph neighbors, scored by relevance.

        Used to augment BM25 results with graph-connected pages that
        BM25 may have missed (e.g. pages without keyword overlap but
        strongly connected via wikilinks or shared sources).
        """
        seed_set = {s.lower() for s in seed_ids}
        candidates: dict[str, float] = {}

        for seed_id in seed_set:
            node = self.nodes.get(seed_id)
            if not node:
                continue
            # Explore 1-hop neighbors
            for neighbor_id in node.out_links | node.in_links:
                if neighbor_id in seed_set:
                    continue
                score = self.relevance(seed_id, neighbor_id)
                if neighbor_id in candidates:
                    candidates[neighbor_id] = max(candidates[neighbor_id], score)
                else:
                    candidates[neighbor_id] = score

        ranked = sorted(candidates.items(), key=lambda x: -x[1])
        return ranked[:max_expand]


# ── Helpers ──────────────────────────────────────────────────────────────

def _extract_type(content: str, page: Path) -> str:
    """Extract page type from frontmatter or path."""
    m = re.search(r"^type:\s*[\"']?(.+?)[\"']?\s*$", content, re.MULTILINE | re.IGNORECASE)
    if m:
        return m.group(1).strip().lower()
    # Infer from directory
    parts = page.parts
    if "entities" in parts:
        return "entity"
    if "concepts" in parts:
        return "concept"
    if "sources" in parts:
        return "source"
    if "syntheses" in parts:
        return "synthesis"
    if "code" in parts and "outputs" in parts:
        return "code"
    return "other"


def _extract_sources(content: str) -> list[str]:
    """Extract sources list from YAML frontmatter."""
    # Inline: sources: ["a.pdf", "b.pdf"]
    m = re.search(r'^sources:\s*\[([^\]]*)\]', content, re.MULTILINE)
    if m:
        items = m.group(1).split(",")
        return [i.strip().strip("\"'") for i in items if i.strip()]
    # Block:
    #   sources:
    #     - a.pdf
    m = re.search(r'^sources:\s*\n((?:\s+-\s+.+\n?)*)', content, re.MULTILINE)
    if m:
        return [
            line.strip().lstrip("- ").strip("\"'")
            for line in m.group(1).split("\n")
            if line.strip().startswith("-")
        ]
    return []


def _resolve_target(raw: str, all_ids: set[str]) -> str | None:
    """Resolve a wikilink target to a node ID."""
    if raw in all_ids:
        return raw
    normalized = raw.replace(" ", "-").replace("_", "-")
    if normalized in all_ids:
        return normalized
    # Try without hyphens
    no_sep = raw.replace("-", " ").replace("_", " ")
    for nid in all_ids:
        if nid.replace("-", " ").replace("_", " ") == no_sep:
            return nid
    return None
