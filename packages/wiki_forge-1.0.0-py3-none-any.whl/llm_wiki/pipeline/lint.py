"""Structural + semantic lint for wiki vaults.

Structural (no LLM):
- Orphan pages: no inbound wikilinks
- Broken wikilinks: targets don't exist
- Missing entity pages: mentioned 3+ times but no page exists

Semantic (LLM-powered):
- Contradictions between pages
- Stale / outdated information
- Missing pages for heavily referenced concepts
- Suggestions for improvement
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from llm_wiki.vault.paths import Vault
from llm_wiki.vault.wikilinks import extract_wikilinks

log = logging.getLogger(__name__)


@dataclass
class LintReport:
    """Structural lint result."""

    pages_scanned: int = 0
    orphans: list[Path] = field(default_factory=list)
    broken_links: list[tuple[Path, str]] = field(default_factory=list)
    missing_entities: list[tuple[str, int]] = field(default_factory=list)  # (name, count)

    @property
    def health_score(self) -> float:
        """0-100 score based on issues per page."""
        if self.pages_scanned == 0:
            return 100.0
        issues = len(self.orphans) + len(self.broken_links) + len(self.missing_entities)
        return max(0.0, 100.0 * (1 - issues / self.pages_scanned))

    def summary(self) -> str:
        return (
            f"Scanned {self.pages_scanned} pages — "
            f"{len(self.orphans)} orphans, "
            f"{len(self.broken_links)} broken links, "
            f"{len(self.missing_entities)} missing entities "
            f"(health: {self.health_score:.1f}/100)"
        )


def lint_vault(vault: Vault) -> LintReport:
    """Run structural lint on a vault.

    Pure Python — no LLM required.
    """
    report = LintReport()
    pages = vault.all_pages()
    if not pages:
        return report

    report.pages_scanned = len(pages)

    # Group pages by stem.lower() — handles stem collisions (e.g.
    # sources/skyjoy.md and concepts/SkyJoy.md both match [[SkyJoy]])
    stems_lower: dict[str, list[Path]] = defaultdict(list)
    for p in pages:
        stems_lower[p.stem.lower()].append(p)

    inbound: dict[Path, int] = defaultdict(int)
    mention_counts: dict[str, int] = defaultdict(int)

    for page in pages:
        try:
            content = page.read_text(encoding="utf-8")
        except Exception as e:
            log.warning("Failed to read %s: %s", page, e)
            continue

        for link in extract_wikilinks(content):
            target_key = link.strip().lower()
            if target_key in stems_lower:
                # Credit inbound to ALL pages with matching stem
                for target in stems_lower[target_key]:
                    inbound[target] += 1
            else:
                report.broken_links.append((page, link))
                mention_counts[link] += 1

    # Orphans (exclude overview.md by convention)
    for page in pages:
        if page.name == "overview.md":
            continue
        if inbound.get(page, 0) == 0:
            report.orphans.append(page)

    # Missing entities: mentioned 3+ times
    for name, count in mention_counts.items():
        if count >= 3:
            report.missing_entities.append((name, count))

    log.info(report.summary())
    return report


# ── Semantic lint (LLM-powered) ──────────────────────────────────────────

@dataclass
class SemanticIssue:
    """A single semantic issue found by LLM analysis."""

    issue_type: str  # contradiction, stale, missing-page, suggestion
    severity: str  # warning, info
    title: str
    detail: str
    affected_pages: list[str] = field(default_factory=list)


@dataclass
class SemanticLintReport:
    """Result of LLM-powered semantic lint."""

    pages_scanned: int = 0
    issues: list[SemanticIssue] = field(default_factory=list)
    input_tokens: int = 0
    output_tokens: int = 0

    def summary(self) -> str:
        by_type: dict[str, int] = defaultdict(int)
        for i in self.issues:
            by_type[i.issue_type] += 1
        parts = [f"{v} {k}" for k, v in sorted(by_type.items())]
        return (
            f"Semantic lint: {self.pages_scanned} pages, "
            f"{len(self.issues)} issues ({', '.join(parts) if parts else 'none'})"
        )


_LINT_BLOCK_RE = re.compile(
    r"---LINT:\s*([^\n|]+?)\s*\|\s*([^\n|]+?)\s*\|\s*([^\n-]+?)\s*---\n"
    r"([\s\S]*?)"
    r"---END LINT---",
)

SEMANTIC_LINT_SYSTEM = (
    "You are a wiki quality analyst. Review wiki page summaries and identify "
    "genuine issues. Output ONLY ---LINT--- blocks, no other text."
)


def _build_semantic_prompt(summaries: list[str]) -> str:
    return f"""Review the following wiki page summaries and identify issues.

## Language Rule
Match the language of the wiki content.

For each issue, output exactly this format:

---LINT: type | severity | Short title---
Description of the issue.
PAGES: page1.md, page2.md
---END LINT---

Types:
- contradiction: two or more pages make conflicting claims
- stale: information that appears outdated or superseded
- missing-page: an important concept is heavily referenced but has no dedicated page
- suggestion: a question or source worth adding to the wiki

Severities:
- warning: should be addressed
- info: nice to have

Only report genuine issues. Do not invent problems.

## Wiki Pages

{chr(10).join(summaries)}
"""


async def semantic_lint(
    vault: Vault,
    llm: "LLMProvider",  # noqa: F821
    model: str | None = None,
) -> SemanticLintReport:
    """Run LLM-powered semantic analysis on the wiki.

    Sends a compact summary (frontmatter + first 500 chars) of each page
    to the LLM, which identifies contradictions, stale info, missing pages,
    and suggestions.
    """
    from llm_wiki.llm.base import LLMProvider  # avoid circular

    report = SemanticLintReport()
    pages = vault.all_pages()
    if not pages:
        return report

    # Build compact summaries
    summaries: list[str] = []
    for p in pages:
        if p.name == "log.md":
            continue
        try:
            content = p.read_text(encoding="utf-8")
        except OSError:
            continue
        preview = content[:500] + ("..." if len(content) > 500 else "")
        rel = p.relative_to(vault.root)
        summaries.append(f"### {rel}\n{preview}")

    report.pages_scanned = len(summaries)
    if not summaries:
        return report

    log.info("Running semantic lint on %d pages...", len(summaries))

    prompt = _build_semantic_prompt(summaries)
    response = await llm.generate(
        prompt,
        system=SEMANTIC_LINT_SYSTEM,
        model=model,
        max_tokens=4096,
    )

    report.input_tokens = response.input_tokens
    report.output_tokens = response.output_tokens

    # Parse ---LINT--- blocks
    for match in _LINT_BLOCK_RE.finditer(response.text):
        issue_type = match.group(1).strip().lower()
        severity = match.group(2).strip().lower()
        title = match.group(3).strip()
        body = match.group(4).strip()

        # Extract PAGES line
        pages_match = re.search(r"^PAGES:\s*(.+)$", body, re.MULTILINE)
        affected = []
        if pages_match:
            affected = [p.strip() for p in pages_match.group(1).split(",")]

        detail = re.sub(r"^PAGES:.*$", "", body, flags=re.MULTILINE).strip()

        report.issues.append(SemanticIssue(
            issue_type=issue_type,
            severity="warning" if severity == "warning" else "info",
            title=title,
            detail=f"[{issue_type}] {detail}",
            affected_pages=affected,
        ))

    log.info(report.summary())
    return report
