"""Unified Multi-Repo Wiki — merge multiple vault/repos into one knowledge base.

Problem:
  Each repo has its own vault → isolated knowledge silos.
  Questions like "How does auth work end-to-end?" need knowledge from
  both backend (FastAPI auth) and frontend (React auth) repos.

Solution:
  1. Each repo ingested independently (via CI/CD or CLI)
  2. `unify` merges all project wikis into ONE unified vault
  3. Cross-project wikilinks auto-created
  4. Shared concepts/entities deduplicated
  5. Unified overview generated

Usage:
    llm-wiki unify \\
      --project tms-backend:vault-backend \\
      --project tms-frontend:vault-frontend \\
      --project confluence:vault-confluence \\
      --output unified-wiki

Architecture:
    unified-wiki/
    ├── wiki/
    │   ├── overview.md              ← unified overview (LLM-generated)
    │   ├── index.md                 ← master index across all projects
    │   ├── projects/
    │   │   ├── tms-backend/         ← code docs from backend
    │   │   │   ├── overview.md
    │   │   │   ├── api-endpoints.md
    │   │   │   └── ...
    │   │   ├── tms-frontend/        ← code docs from frontend
    │   │   │   ├── overview.md
    │   │   │   ├── authentication.md
    │   │   │   └── ...
    │   │   └── confluence/          ← business docs
    │   │       ├── ekyc-overview.md
    │   │       └── ...
    │   ├── concepts/                ← SHARED across projects (deduplicated)
    │   │   ├── Authentication.md    ← mentions both FE and BE
    │   │   ├── eKYC.md
    │   │   └── ...
    │   ├── entities/                ← SHARED (deduplicated)
    │   │   ├── FastAPI.md
    │   │   ├── React.md
    │   │   └── ...
    │   └── sources/                 ← from confluence ingest
    │       └── ...
    └── .reviews.json                ← cross-project reviews
"""
from __future__ import annotations

import logging
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from llm_wiki.dedup import find_existing_page, merge_page_content
from llm_wiki.llm.base import LLMProvider
from llm_wiki.vault.paths import Vault

log = logging.getLogger(__name__)


@dataclass
class ProjectSource:
    """A project to merge into the unified wiki."""
    name: str          # e.g. "tms-backend"
    vault_path: Path   # path to project vault


@dataclass
class UnifyResult:
    """Result of unification."""
    projects_merged: int = 0
    pages_copied: int = 0
    pages_deduplicated: int = 0
    cross_links_added: int = 0
    overview_generated: bool = False
    output_path: Path | None = None


async def unify_vaults(
    projects: list[ProjectSource],
    output_path: Path,
    llm: LLMProvider | None = None,
    model: str | None = None,
) -> UnifyResult:
    """Merge multiple project vaults into one unified wiki.

    Steps:
      1. Create unified vault structure
      2. Copy code docs into projects/{name}/
      3. Merge concepts/entities with deduplication
      4. Copy sources
      5. Build unified index
      6. Generate unified overview (if LLM provided)
      7. Add cross-project annotations
    """
    result = UnifyResult(output_path=output_path)

    # ── Step 1: Create unified vault ─────────────────────────────────
    unified = Vault(output_path)
    unified.init_dirs()
    projects_dir = unified.wiki / "projects"
    projects_dir.mkdir(parents=True, exist_ok=True)

    all_project_names: list[str] = []
    project_overviews: dict[str, str] = {}

    for proj in projects:
        src_vault = Vault(proj.vault_path)
        if not src_vault.wiki.exists():
            log.warning("Vault %s has no wiki/ dir, skipping", proj.name)
            continue

        all_project_names.append(proj.name)
        log.info("Merging project: %s from %s", proj.name, proj.vault_path)

        # ── Step 2: Copy code docs to projects/{name}/ ───────────────
        code_dir = src_vault.wiki / "outputs" / "code"
        if code_dir.exists():
            dest = projects_dir / proj.name
            dest.mkdir(parents=True, exist_ok=True)
            for md in code_dir.glob("*.md"):
                content = md.read_text(encoding="utf-8")
                # Add project tag to frontmatter
                content = _add_project_tag(content, proj.name)
                (dest / md.name).write_text(content, encoding="utf-8")
                result.pages_copied += 1

            # Save project overview
            proj_overview = code_dir / "overview.md"
            if proj_overview.exists():
                project_overviews[proj.name] = proj_overview.read_text(encoding="utf-8")

        # ── Step 3: Merge concepts (deduplicate) ─────────────────────
        src_concepts = src_vault.wiki / "concepts"
        if src_concepts.exists():
            for md in src_concepts.glob("*.md"):
                content = md.read_text(encoding="utf-8")
                content = _add_project_tag(content, proj.name)
                existing = find_existing_page(unified.wiki, f"concepts/{md.name}")
                if existing:
                    merged = merge_page_content(existing, content)
                    existing.write_text(merged, encoding="utf-8")
                    result.pages_deduplicated += 1
                    log.debug("Merged concept: %s (from %s)", md.stem, proj.name)
                else:
                    dest = unified.wiki / "concepts" / md.name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_text(content, encoding="utf-8")
                    result.pages_copied += 1

        # ── Step 4: Merge entities (deduplicate) ─────────────────────
        src_entities = src_vault.wiki / "entities"
        if src_entities.exists():
            for md in src_entities.glob("*.md"):
                content = md.read_text(encoding="utf-8")
                content = _add_project_tag(content, proj.name)
                existing = find_existing_page(unified.wiki, f"entities/{md.name}")
                if existing:
                    merged = merge_page_content(existing, content)
                    existing.write_text(merged, encoding="utf-8")
                    result.pages_deduplicated += 1
                else:
                    dest = unified.wiki / "entities" / md.name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_text(content, encoding="utf-8")
                    result.pages_copied += 1

        # ── Step 5: Copy sources ─────────────────────────────────────
        src_sources = src_vault.wiki / "sources"
        if src_sources.exists():
            for md in src_sources.glob("*.md"):
                content = md.read_text(encoding="utf-8")
                content = _add_project_tag(content, proj.name)
                dest = unified.wiki / "sources" / md.name
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_text(content, encoding="utf-8")
                result.pages_copied += 1

        # Copy vault overview if exists (non-code)
        if src_vault.overview.exists() and proj.name not in project_overviews:
            project_overviews[proj.name] = src_vault.overview.read_text(encoding="utf-8")

        result.projects_merged += 1

    # ── Step 6: Build unified index ──────────────────────────────────
    index_content = _build_unified_index(unified, all_project_names)
    unified.index.write_text(index_content, encoding="utf-8")

    # ── Step 7: Generate unified overview ────────────────────────────
    if llm and project_overviews:
        log.info("Generating unified overview from %d project overviews", len(project_overviews))
        overview = await _generate_unified_overview(
            all_project_names, project_overviews, llm, model
        )
        unified.overview.write_text(overview, encoding="utf-8")
        result.overview_generated = True
    else:
        # Simple overview without LLM
        overview_lines = [
            "---\ntitle: Unified Wiki Overview\ntype: synthesis\n---\n",
            f"# Unified Wiki\n\nThis wiki combines knowledge from {len(all_project_names)} projects:\n",
        ]
        for name in all_project_names:
            overview_lines.append(f"- **{name}** — see [[projects/{name}/overview]]\n")
        unified.overview.write_text("\n".join(overview_lines), encoding="utf-8")

    # ── Step 8: Add cross-project link annotations ───────────────────
    cross_links = _add_cross_project_links(unified, all_project_names)
    result.cross_links_added = cross_links

    log.info(
        "Unification complete: %d projects, %d pages copied, %d deduplicated, %d cross-links",
        result.projects_merged, result.pages_copied,
        result.pages_deduplicated, result.cross_links_added,
    )
    return result


def _add_project_tag(content: str, project_name: str) -> str:
    """Add project tag to frontmatter if not present."""
    if "project:" in content:
        return content
    # Find closing --- of frontmatter (must be on its own line)
    if content.startswith("---"):
        # Find \n--- which marks the end of frontmatter
        close_idx = content.find("\n---", 3)
        if close_idx != -1:
            # Insert before the closing \n---
            insert_at = close_idx + 1  # after the \n
            return content[:insert_at] + f"project: {project_name}\n" + content[insert_at:]
    # No frontmatter — wrap content
    return f"---\nproject: {project_name}\n---\n\n{content}"


def _build_unified_index(vault: Vault, project_names: list[str]) -> str:
    """Build a unified index.md across all projects."""
    lines = ["# Unified Wiki Index\n"]

    # Projects section
    lines.append("## Projects\n")
    for name in sorted(project_names):
        proj_dir = vault.wiki / "projects" / name
        if proj_dir.exists():
            pages = sorted(proj_dir.glob("*.md"))
            lines.append(f"### {name} ({len(pages)} pages)\n")
            for p in pages[:10]:
                lines.append(f"- [{p.stem}](projects/{name}/{p.name})\n")
            if len(pages) > 10:
                lines.append(f"- ... and {len(pages) - 10} more\n")

    # Concepts section
    concepts_dir = vault.wiki / "concepts"
    if concepts_dir.exists():
        concepts = sorted(concepts_dir.glob("*.md"))
        lines.append(f"\n## Concepts ({len(concepts)})\n")
        for p in concepts:
            lines.append(f"- [{p.stem}](concepts/{p.name})\n")

    # Entities section
    entities_dir = vault.wiki / "entities"
    if entities_dir.exists():
        entities = sorted(entities_dir.glob("*.md"))
        lines.append(f"\n## Entities ({len(entities)})\n")
        for p in entities:
            lines.append(f"- [{p.stem}](entities/{p.name})\n")

    # Sources section
    sources_dir = vault.wiki / "sources"
    if sources_dir.exists():
        sources = sorted(sources_dir.glob("*.md"))
        lines.append(f"\n## Sources ({len(sources)})\n")
        for p in sources[:20]:
            lines.append(f"- [{p.stem}](sources/{p.name})\n")

    return "".join(lines)


def _add_cross_project_links(vault: Vault, project_names: list[str]) -> int:
    """Scan all pages and add cross-project annotations where pages share names."""
    # Build a map: concept/entity name → which projects mention it
    name_to_projects: dict[str, list[str]] = {}

    for name in project_names:
        proj_dir = vault.wiki / "projects" / name
        if not proj_dir.exists():
            continue
        for md in proj_dir.glob("*.md"):
            try:
                content = md.read_text(encoding="utf-8")
            except OSError:
                continue
            # Find [[wikilinks]] in project pages
            for match in re.finditer(r"\[\[([^\]|]+?)(?:\|[^\]]+?)?\]\]", content):
                link_name = match.group(1).strip().lower()
                if link_name not in name_to_projects:
                    name_to_projects[link_name] = []
                if name not in name_to_projects[link_name]:
                    name_to_projects[link_name].append(name)

    # Add "See also" sections to concepts/entities mentioned by multiple projects
    cross_links = 0
    for page_dir in [vault.wiki / "concepts", vault.wiki / "entities"]:
        if not page_dir.exists():
            continue
        for md in page_dir.glob("*.md"):
            stem_lower = md.stem.lower()
            projects_mentioning = name_to_projects.get(stem_lower, [])
            if len(projects_mentioning) <= 1:
                continue

            content = md.read_text(encoding="utf-8")
            if "## Cross-Project References" in content:
                continue  # already annotated

            cross_section = "\n\n## Cross-Project References\n"
            cross_section += f"This topic is referenced in {len(projects_mentioning)} projects:\n"
            for proj in projects_mentioning:
                cross_section += f"- **{proj}** — see [[projects/{proj}/overview]]\n"

            content += cross_section
            md.write_text(content, encoding="utf-8")
            cross_links += 1

    return cross_links


async def _generate_unified_overview(
    project_names: list[str],
    project_overviews: dict[str, str],
    llm: LLMProvider,
    model: str | None,
) -> str:
    """Generate a unified overview from all project overviews."""
    overviews_text = ""
    for name, content in project_overviews.items():
        # Truncate each overview
        body = re.sub(r"^---.*?---\s*", "", content, flags=re.DOTALL).strip()
        overviews_text += f"\n### {name}\n{body[:2000]}\n"

    prompt = f"""You are creating a unified wiki overview that summarizes ALL projects in an organization.

## Language Rule (CRITICAL)
Match the dominant language of the project overviews below. If most are in Vietnamese, write in Vietnamese.

## Project Overviews
{overviews_text}

Write a comprehensive overview (300-500 words) that:
1. Describes what this organization builds overall
2. Lists each project and its role in the system
3. Highlights connections between projects (e.g., frontend↔backend, docs↔code)
4. Uses [[project-name]] wikilinks to reference each project

Format:
---
title: Unified Wiki Overview
type: synthesis
projects: [{', '.join(project_names)}]
---

# [Organization] — System Overview

(your overview here)
"""
    try:
        resp = await llm.generate(prompt, model=model, max_tokens=2000)
        return resp.text
    except Exception as e:
        log.warning("Failed to generate unified overview: %s", e)
        return (
            f"---\ntitle: Unified Wiki Overview\ntype: synthesis\n---\n\n"
            f"# System Overview\n\nThis wiki combines {len(project_names)} projects: "
            f"{', '.join(project_names)}.\n"
        )
