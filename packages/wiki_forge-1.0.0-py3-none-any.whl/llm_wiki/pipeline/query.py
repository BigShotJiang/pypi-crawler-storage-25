"""Query the wiki for answers, with optional save-back to syntheses/."""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from llm_wiki.config import Settings
from llm_wiki.llm.base import LLMProvider
from llm_wiki.vault.paths import Vault

log = logging.getLogger(__name__)


QUERY_SYSTEM = (
    "You are querying an LLM Wiki. Synthesize answers from the provided pages. "
    "Use [[PageName]] wikilinks to cite sources inline. "
    "The PageName is the exact filename stem (no path, no .md extension) of the wiki page."
)


@dataclass
class QueryResult:
    """Result of a wiki query."""

    answer: str
    sources: list[Path]
    input_tokens: int = 0
    output_tokens: int = 0


def _page_search_text(page: Path) -> str:
    """Extract searchable text from a page: stem + frontmatter title + first heading + full body."""
    text = page.stem.lower().replace("-", " ").replace("_", " ")
    try:
        raw = page.read_text(encoding="utf-8")
    except OSError:
        return text

    # Extract frontmatter title: title: "..." or title: ...
    fm_title = re.search(r"^title:\s*[\"']?(.+?)[\"']?\s*$", raw, re.MULTILINE | re.IGNORECASE)
    if fm_title:
        text += " " + fm_title.group(1).lower()

    # First H1 heading
    h1 = re.search(r"^#\s+(.+)$", raw, re.MULTILINE)
    if h1:
        text += " " + h1.group(1).lower()

    # Full body text (after frontmatter), up to 8000 chars to keep scoring fast
    body = re.sub(r"^---.*?---\s*", "", raw, flags=re.DOTALL).strip()
    text += " " + body[:8000].lower()

    return text


def _score_page(question_words: list[str], search_text: str) -> int:
    """Score a page by how many question words appear in its search text."""
    score = 0
    for w in question_words:
        if w in search_text:
            score += 1
        # partial match: stem of the word (first 5 chars) to handle Vietnamese/plurals
        elif len(w) >= 5 and w[:5] in search_text:
            score += 1
    return score


_LAYER_PRIORITY = {"concepts": 3, "entities": 2, "sources": 1}

# Patterns that suggest the question is about code implementation
_CODE_QUESTION_RE = re.compile(
    r"[a-z_]{3,}\(|"          # function call: scan_repo(
    r"\b[a-z][a-z0-9_]{2,}\b" # snake_case identifier
    r"(?=.*[_])",              # must contain underscore
    re.IGNORECASE,
)


def _layer_priority(page: Path) -> int:
    """Higher = more distilled knowledge (concepts > entities > sources > code > other).

    Code docs are deprioritized (-1) so Confluence/concept pages always win
    when both match equally. Code only surfaces when no concept pages match.
    """
    # code docs live under outputs/code/ (any depth)
    parts = page.parts
    if "code" in parts and "outputs" in parts:
        return -1
    return _LAYER_PRIORITY.get(page.parent.name, 0)


_OPERATIONAL_QUESTION_RE = re.compile(
    r"(?i)(thời gian|bao lâu|interval|schedule|cron|timeout|retry|"
    r"how often|how long|frequency|polling|quét|scan|config|"
    r"cấu hình|thiết lập|worker|background|queue|batch|"
    r"every \d|mỗi \d|chu kỳ|cycle|periodic)"
)


def _is_code_question(question: str) -> bool:
    """Heuristic: does the question look like it's asking about code?"""
    # snake_case pattern
    if re.search(r"[a-z_]{2,}_[a-z_]{2,}", question):
        return True
    # Operational/config questions need code docs too
    if _OPERATIONAL_QUESTION_RE.search(question):
        return True
    return False


def _find_relevant_pages(
    question: str,
    vault: Vault,
    max_pages: int = 12,
    _bm25_index=None,
    _wiki_graph=None,
    _qmd_searcher=None,
) -> list[Path]:
    """Hybrid retrieval: BM25 + QMD semantic + Graph expansion + re-ranking.

    Pipeline:
      1. BM25 keyword search (over-fetch 3× candidates)
      1b. QMD hybrid search (if available): BM25+Vector+RRF+Reranker
      2. Page-name exact match: force-include pages matching query terms
      3. Graph expansion: add 1-hop neighbors of hits
      4. Re-rank all candidates by: BM25 + QMD + graph relevance + layer priority
      5. Fallbacks for code-only vaults and zero-hit queries

    Args:
        _bm25_index: Optional pre-built WikiSearchIndex.
        _wiki_graph: Optional pre-built WikiGraph for graph-based re-ranking.
    """
    from llm_wiki.pipeline.search import WikiSearchIndex

    code_question = _is_code_question(question)

    # Build or reuse BM25 index
    if _bm25_index is None:
        idx = WikiSearchIndex()
        idx.build(vault)
    else:
        idx = _bm25_index

    hits = idx.search(question, limit=max_pages * 3)   # over-fetch, then re-rank

    # QMD scores (disabled — kept for future GPU-enabled environments)
    qmd_scores: dict[str, float] = {}

    # ── Page-name exact match: if query contains a page stem, force-include it
    question_lower = question.lower()
    # Remove Vietnamese diacritics-insensitive tokens for matching
    question_no_space = question_lower.replace(" ", "")
    question_words = set(re.findall(r"[a-z0-9]{3,}", question_lower))
    name_match_pages: dict[str, Path] = {}
    for page in vault.all_pages():
        stem_lower = page.stem.lower()
        if len(stem_lower) < 3:
            continue  # skip very short stems (CA, GH, etc.)
        stem_normalized = stem_lower.replace("-", " ").replace("_", " ")
        stem_words = set(stem_normalized.split())
        if (stem_lower in question_lower                            # exact: "edocai" in query
            or stem_normalized in question_lower                    # "dashboard overview" in query
            or stem_lower.replace("-", "") in question_no_space     # "dashboardoverview" in compressed
            or (question_words & stem_words)):                      # word overlap: "dashboard" in stem words
            name_match_pages[stem_lower] = page

    # ── BM25 scores ──────────────────────────────────────────────────
    bm25_paths: dict[str, float] = {}  # stem.lower() → bm25 score
    for hit in hits:
        bm25_paths[hit.path.stem.lower()] = hit.score

    # Add name-matched pages — score higher than any BM25 hit
    max_bm25 = max(bm25_paths.values()) if bm25_paths else 1.0
    for stem, path in name_match_pages.items():
        name_boost = max_bm25 + 10.0  # always rank above BM25-only hits
        bm25_paths[stem] = max(bm25_paths.get(stem, 0.0), name_boost)

    # ── Graph expansion: add connected pages that BM25 missed ────────
    graph_bonus: dict[str, float] = {}  # stem.lower() → graph relevance
    if _wiki_graph is not None and _wiki_graph.nodes:
        seed_ids = list(bm25_paths.keys())[:15]
        expanded = _wiki_graph.expand_candidates(seed_ids, max_expand=max_pages * 2)
        for node_id, rel_score in expanded:
            if node_id not in bm25_paths:
                graph_bonus[node_id] = rel_score

        # Compute graph relevance between ALL BM25 hits and top seeds
        if seed_ids:
            for top_seed in seed_ids[:3]:
                for stem in bm25_paths:
                    if stem != top_seed:
                        score = _wiki_graph.relevance(top_seed, stem)
                        if stem not in graph_bonus or score > graph_bonus[stem]:
                            graph_bonus[stem] = score

    # ── Build unified candidate list ────────────────────────────────
    stem_to_path: dict[str, Path] = {}
    for hit in hits:
        stem_to_path[hit.path.stem.lower()] = hit.path
    for stem, path in name_match_pages.items():
        stem_to_path[stem] = path
    if _wiki_graph:
        for node_id, node in _wiki_graph.nodes.items():
            if node_id not in stem_to_path:
                stem_to_path[node_id] = node.path

    reranked: list[tuple[float, Path]] = []

    name_matched_stems = set(name_match_pages.keys())

    # Add QMD-only results to stem_to_path
    for stem in qmd_scores:
        if stem not in stem_to_path:
            # Find page by stem
            for page in vault.all_pages():
                if page.stem.lower() == stem:
                    stem_to_path[stem] = page
                    break

    all_candidates = set(bm25_paths.keys()) | set(graph_bonus.keys()) | set(qmd_scores.keys())
    for stem in all_candidates:
        path = stem_to_path.get(stem)
        if not path or path == vault.overview:
            continue
        priority = _layer_priority(path)
        # Skip code docs for non-code questions — UNLESS name-matched
        is_name_matched = stem in name_matched_stems
        if priority == -1 and not code_question and not is_name_matched:
            continue

        bm25_score = bm25_paths.get(stem, 0.0)
        graph_score = graph_bonus.get(stem, 0.0)
        qmd_score = qmd_scores.get(stem, 0.0)

        # Boost pages containing operational parameters when question is operational
        op_boost = 0.0
        if _OPERATIONAL_QUESTION_RE.search(question):
            try:
                content = path.read_text(encoding="utf-8")[:5000].lower()
                op_keywords = ["cron(", "timeout", "schedule", "interval", "max_jobs",
                               "worker", "minute=", "hour=", "retry", "operational parameters"]
                op_hits = sum(1 for kw in op_keywords if kw in content)
                if op_hits >= 2:
                    op_boost = op_hits * 3.0  # significant boost
            except OSError:
                pass

        # Combined: BM25 + QMD semantic + graph + layer priority + operational boost
        # QMD scores are 0-1 normalized, scale up to match BM25 range
        combined = bm25_score + qmd_score * 20.0 + graph_score * 0.5 + priority * 0.1 + op_boost
        reranked.append((-combined, path))

    # Fallback A: vault is code-only and all hits were filtered by priority
    if not reranked and hits:
        log.debug("Code-only vault: including code pages for non-code question")
        for hit in hits:
            if hit.path == vault.overview:
                continue
            combined = hit.score + _layer_priority(hit.path) * 0.1
            reranked.append((-combined, hit.path))

    reranked.sort()

    # Fallback B: BM25 found nothing (query tokens not in docs — e.g. Vietnamese stop words)
    if not reranked:
        log.debug("BM25 returned no hits — using overview/parent pages as fallback")
        all_pages = list(vault.all_pages())
        def _fallback_rank(p: Path) -> int:
            if p.stem == "overview":
                return 0
            if p.stem.startswith("parent-"):
                return 1
            return 2
        for p in sorted(all_pages, key=_fallback_rank):
            if p != vault.overview:
                reranked.append((0.0, p))

    relevant: list[Path] = []

    # Always include overview first
    if vault.overview.exists():
        relevant.append(vault.overview)

    for _, page in reranked:
        relevant.append(page)
        if len(relevant) >= max_pages:
            break

    return relevant


async def query_wiki(
    question: str,
    vault: Vault,
    llm: LLMProvider,
    settings: Settings,
    *,
    save: bool = False,
    _bm25_index=None,
    _wiki_graph=None,
    _qmd_searcher=None,
) -> QueryResult:
    """Answer a question using wiki pages as context.

    If ``save=True``, file the answer under ``wiki/syntheses/``.
    """
    pages = _find_relevant_pages(
        question, vault,
        _bm25_index=_bm25_index,
        _wiki_graph=_wiki_graph,
        _qmd_searcher=_qmd_searcher,
    )
    if not pages:
        return QueryResult(answer="(wiki is empty)", sources=[])

    pages_context = ""
    for p in pages:
        rel = p.relative_to(vault.root)
        pages_context += f"\n\n### {rel}\n{p.read_text(encoding='utf-8')}"

    # Build a map of rel-path → stem so we can tell the LLM the exact link names
    page_names = "\n".join(
        f"  - [[{p.stem}]] ({p.relative_to(vault.root)})"
        for p in pages
        if p != vault.overview
    )

    prompt = (
        f"Wiki pages:{pages_context}\n\n"
        f"Question: {question}\n\n"
        f"IMPORTANT: Respond in the SAME language as the question above. "
        f"If the question is in Vietnamese, answer in Vietnamese. "
        f"If the question is in English, answer in English.\n\n"
        f"Write a well-structured markdown answer. "
        f"Cite sources inline using [[PageName]] wikilinks where PageName is the exact stem "
        f"(filename without path or .md) from the list below.\n\n"
        f"Available page names for citation:\n{page_names}\n\n"
        f"End with a ## Sources section that lists every page you cited as a [[PageName]] wikilink "
        f"(one per line, use the exact stems above — no bare [] brackets)."
    )

    response = await llm.generate(
        prompt,
        system=QUERY_SYSTEM,
        model=settings.heavy_model,
        max_tokens=4096,
    )

    # Strip bare [] / [ ] artefacts (empty markdown refs, task checkboxes)
    # and remove the bullet line if nothing remains after stripping
    cleaned = re.sub(r"\[[ ]?\]", "", response.text)
    cleaned = re.sub(r"^-\s*\n", "", cleaned, flags=re.MULTILINE)

    result = QueryResult(
        answer=cleaned,
        sources=pages,
        input_tokens=response.input_tokens,
        output_tokens=response.output_tokens,
    )

    if save:
        today = date.today().isoformat()
        slug = re.sub(r"[^a-z0-9]+", "-", question.lower()).strip("-")[:80]
        path = vault.syntheses / f"{today}-{slug}.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        fm = (
            f"---\ntitle: {question[:100]!r}\ntype: synthesis\n"
            f"last_updated: {today}\n---\n\n"
        )
        path.write_text(fm + result.answer, encoding="utf-8")
        log.info("Saved synthesis to %s", path)

    return result
