"""Post-ingest wikilink enrichment — LLM adds [[wikilinks]] to existing pages.

After ingesting new sources, some pages may reference entities/concepts that
exist in the wiki but aren't linked. This module scans pages and uses LLM to
add missing [[wikilinks]], increasing graph density and improving retrieval.

Usage:
    enriched = await enrich_wikilinks(vault, llm, settings)
    print(f"Enriched {enriched} pages")
"""
from __future__ import annotations

import logging
import re
from pathlib import Path

from llm_wiki.llm.base import LLMProvider, LLMResponse
from llm_wiki.vault.paths import Vault
from llm_wiki.vault.wikilinks import extract_wikilinks

log = logging.getLogger(__name__)

ENRICH_SYSTEM = (
    "You are a wiki link enrichment assistant. Your task is to add [[wikilinks]] "
    "to existing wiki pages where entities or concepts are mentioned but not linked."
)


def _build_enrich_prompt(page_content: str, available_pages: list[str]) -> str:
    page_list = "\n".join(f"  - [[{name}]]" for name in sorted(available_pages)[:200])
    return f"""Add [[wikilinks]] to the following wiki page content where appropriate.

## Rules
1. ONLY add links to pages that exist in the Available Pages list below
2. Do NOT remove or change any existing [[wikilinks]]
3. Do NOT change the meaning, structure, or language of the content
4. Do NOT add links inside headings (#), frontmatter (---), or code blocks
5. Link each page name at most ONCE (first mention only)
6. Preserve ALL frontmatter exactly as-is
7. Return the COMPLETE page content with added wikilinks

## Available Pages (only link to these)
{page_list}

## Page Content
{page_content}

Return the complete enriched page content:"""


async def enrich_page(
    page: Path,
    available_stems: list[str],
    llm: LLMProvider,
    model: str | None = None,
) -> bool:
    """Enrich a single page with wikilinks. Returns True if page was modified."""
    try:
        content = page.read_text(encoding="utf-8")
    except OSError:
        return False

    # Skip if page is very short or already heavily linked
    existing_links = set(extract_wikilinks(content))
    body = re.sub(r"^---.*?---\s*", "", content, flags=re.DOTALL).strip()
    if len(body) < 100:
        return False

    # Find available pages NOT already linked
    unlinked = [
        stem for stem in available_stems
        if stem.lower() not in {l.lower() for l in existing_links}
        and stem.lower() != page.stem.lower()
    ]
    if not unlinked:
        return False

    # Check if any unlinked page names appear in the text
    body_lower = body.lower()
    candidates = [s for s in unlinked if s.lower().replace("-", " ") in body_lower or s.lower() in body_lower]
    if not candidates:
        return False

    prompt = _build_enrich_prompt(content, candidates)
    try:
        response = await llm.generate(
            prompt,
            system=ENRICH_SYSTEM,
            model=model,
            max_tokens=len(content) * 2,  # enough room for additions
        )
    except Exception as e:
        log.warning("Enrich failed for %s: %s", page.name, e)
        return False

    enriched = response.text.strip()

    # Sanity check: enriched should be at least 50% of original
    if len(enriched) < len(content) * 0.5:
        log.warning("Enriched content too short for %s, skipping", page.name)
        return False

    # Check that new links were actually added
    new_links = set(extract_wikilinks(enriched))
    added = new_links - existing_links
    if not added:
        return False

    # Write back
    page.write_text(enriched, encoding="utf-8")
    log.info("Enriched %s: +%d wikilinks (%s)", page.name, len(added), ", ".join(sorted(added)[:5]))
    return True


async def enrich_wikilinks(
    vault: Vault,
    llm: LLMProvider,
    model: str | None = None,
    max_pages: int = 50,
) -> int:
    """Scan vault pages and add missing [[wikilinks]] via LLM.

    Returns number of pages enriched.
    """
    pages = vault.all_pages()
    if not pages:
        return 0

    available_stems = [p.stem for p in pages]
    enriched_count = 0

    # Process pages that are likely to benefit (entities/concepts first)
    def _priority(p: Path) -> int:
        if "entities" in p.parts:
            return 0
        if "concepts" in p.parts:
            return 1
        if "sources" in p.parts:
            return 2
        return 3

    for page in sorted(pages, key=_priority)[:max_pages]:
        if page.name in ("index.md", "log.md", "overview.md"):
            continue
        if await enrich_page(page, available_stems, llm, model):
            enriched_count += 1

    log.info("Wikilink enrichment complete: %d/%d pages enriched", enriched_count, len(pages))
    return enriched_count
