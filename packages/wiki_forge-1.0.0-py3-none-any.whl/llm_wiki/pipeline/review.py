"""Review system — LLM flags items during ingest for human judgment.

Items are persisted to ``vault/.reviews.json`` and served via API.
Users can approve or dismiss items through the UI or CLI.
"""
from __future__ import annotations

import json
import logging
import uuid
from datetime import date
from pathlib import Path

from llm_wiki.models import ReviewItem

log = logging.getLogger(__name__)


class ReviewStore:
    """Persistent review item store backed by a JSON file."""

    def __init__(self, vault_root: Path) -> None:
        self._path = vault_root / ".reviews.json"
        self._items: list[ReviewItem] = []
        self._load()

    def _load(self) -> None:
        if self._path.exists():
            try:
                data = json.loads(self._path.read_text(encoding="utf-8"))
                self._items = [ReviewItem(**item) for item in data]
            except Exception as e:
                log.warning("Failed to load reviews: %s", e)
                self._items = []

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        data = [item.model_dump() for item in self._items]
        self._path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def add(self, item: ReviewItem) -> str:
        """Add a review item. Returns its generated ID (stored in title for simplicity)."""
        if not item.created:
            item.created = date.today().isoformat()
        self._items.append(item)
        self._save()
        log.info("Review item added: [%s] %s", item.review_type, item.title)
        return item.title

    def add_many(self, items: list[ReviewItem]) -> int:
        """Add multiple review items at once."""
        today = date.today().isoformat()
        for item in items:
            if not item.created:
                item.created = today
            self._items.append(item)
        if items:
            self._save()
            log.info("Added %d review items", len(items))
        return len(items)

    def all(self, status: str | None = None) -> list[ReviewItem]:
        """Get all items, optionally filtered by status."""
        if status:
            return [i for i in self._items if i.status == status]
        return list(self._items)

    def update_status(self, title: str, new_status: str) -> bool:
        """Update status of an item by title. Returns True if found."""
        for item in self._items:
            if item.title == title:
                item.status = new_status
                self._save()
                return True
        return False

    def dismiss_all(self) -> int:
        """Dismiss all open items."""
        count = 0
        for item in self._items:
            if item.status == "open":
                item.status = "dismissed"
                count += 1
        if count:
            self._save()
        return count

    @property
    def open_count(self) -> int:
        return sum(1 for i in self._items if i.status == "open")

    @property
    def total_count(self) -> int:
        return len(self._items)


def extract_review_items_from_contradictions(
    contradictions: list[str],
    source_file: str,
) -> list[ReviewItem]:
    """Convert contradiction strings from ingest result into ReviewItems."""
    items = []
    for text in contradictions:
        if not text or text.strip() == "":
            continue
        items.append(ReviewItem(
            review_type="contradiction",
            title=f"Contradiction in {source_file}",
            detail=text,
            source_file=source_file,
        ))
    return items
