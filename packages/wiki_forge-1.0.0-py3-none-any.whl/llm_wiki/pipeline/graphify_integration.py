"""Graphify integration — enrich WikiGraph with INFERRED edges + community detection.

Runs graphify on wiki vault, reads graph.json output, merges discoveries
into our WikiGraph for better retrieval and visualization.

Usage:
    report = run_graphify(vault_path)
    enriched_graph = merge_graphify(wiki_graph, report)

Or via CLI:
    llm-wiki graphify --vault demo-unified
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)


@dataclass
class GraphifyNode:
    id: str
    label: str
    node_type: str = ""
    community: int = 0


@dataclass
class GraphifyEdge:
    source: str
    target: str
    edge_type: str = ""  # EXTRACTED | INFERRED | AMBIGUOUS
    confidence: float = 1.0
    label: str = ""


@dataclass
class GraphifyReport:
    """Parsed graphify output."""
    nodes: list[GraphifyNode] = field(default_factory=list)
    edges: list[GraphifyEdge] = field(default_factory=list)
    communities: dict[int, list[str]] = field(default_factory=dict)  # community_id → node_ids
    god_nodes: list[str] = field(default_factory=list)
    surprising_connections: list[dict] = field(default_factory=list)
    raw_path: Path | None = None

    @property
    def inferred_edges(self) -> list[GraphifyEdge]:
        return [e for e in self.edges if e.edge_type == "INFERRED"]

    @property
    def extracted_edges(self) -> list[GraphifyEdge]:
        return [e for e in self.edges if e.edge_type == "EXTRACTED"]


def load_graphify_output(output_dir: Path) -> GraphifyReport | None:
    """Load graph.json from graphify output directory."""
    graph_json = output_dir / "graph.json"
    if not graph_json.exists():
        log.warning("No graph.json found at %s", output_dir)
        return None

    try:
        data = json.loads(graph_json.read_text(encoding="utf-8"))
    except Exception as e:
        log.warning("Failed to parse graph.json: %s", e)
        return None

    report = GraphifyReport(raw_path=graph_json)

    # Parse NetworkX JSON format
    # Nodes
    for node_data in data.get("nodes", []):
        node_id = node_data.get("id", "")
        report.nodes.append(GraphifyNode(
            id=node_id,
            label=node_data.get("label", node_id),
            node_type=node_data.get("type", ""),
            community=node_data.get("community", 0),
        ))

    # Edges (links in NetworkX JSON)
    for edge_data in data.get("links", data.get("edges", [])):
        report.edges.append(GraphifyEdge(
            source=edge_data.get("source", ""),
            target=edge_data.get("target", ""),
            edge_type=edge_data.get("edge_type", "EXTRACTED"),
            confidence=edge_data.get("confidence_score", edge_data.get("confidence", 1.0)),
            label=edge_data.get("label", ""),
        ))

    # Communities
    for node in report.nodes:
        comm = node.community
        if comm not in report.communities:
            report.communities[comm] = []
        report.communities[comm].append(node.id)

    # God nodes (top connected)
    node_degree: dict[str, int] = {}
    for edge in report.edges:
        node_degree[edge.source] = node_degree.get(edge.source, 0) + 1
        node_degree[edge.target] = node_degree.get(edge.target, 0) + 1
    report.god_nodes = sorted(node_degree, key=lambda x: -node_degree[x])[:10]

    # Parse GRAPH_REPORT.md for surprising connections
    report_md = output_dir / "GRAPH_REPORT.md"
    if report_md.exists():
        try:
            content = report_md.read_text(encoding="utf-8")
            # Extract surprising connections section
            import re
            surprise_section = re.search(
                r"## Surprising Connections\n(.*?)(?=\n## |\Z)",
                content, re.DOTALL
            )
            if surprise_section:
                for line in surprise_section.group(1).split("\n"):
                    if "→" in line or "↔" in line:
                        report.surprising_connections.append({"text": line.strip()})
        except Exception:
            pass

    log.info(
        "Graphify loaded: %d nodes, %d edges (%d INFERRED), %d communities, %d god nodes",
        len(report.nodes), len(report.edges), len(report.inferred_edges),
        len(report.communities), len(report.god_nodes),
    )
    return report


def merge_into_wiki_graph(wiki_graph_data: dict, graphify_report: GraphifyReport) -> dict:
    """Merge graphify discoveries into wiki-graph API response.

    Adds:
    - INFERRED edges (with confidence < 1.0)
    - Community assignments from Leiden
    - God node markers
    """
    existing_node_ids = {n["id"] for n in wiki_graph_data.get("nodes", [])}
    existing_edges = {
        (e["source"], e["target"])
        for e in wiki_graph_data.get("edges", [])
    }

    # Build graphify node_id → wiki node_id mapping (fuzzy)
    gf_to_wiki: dict[str, str] = {}
    for gf_node in graphify_report.nodes:
        gf_lower = gf_node.id.lower().replace(" ", "-").replace("_", "-")
        # Exact match
        if gf_lower in existing_node_ids:
            gf_to_wiki[gf_node.id] = gf_lower
            continue
        # Fuzzy match
        for wiki_id in existing_node_ids:
            if wiki_id.replace("-", "") == gf_lower.replace("-", ""):
                gf_to_wiki[gf_node.id] = wiki_id
                break

    # Add INFERRED edges
    added_edges = 0
    for edge in graphify_report.inferred_edges:
        src = gf_to_wiki.get(edge.source)
        tgt = gf_to_wiki.get(edge.target)
        if not src or not tgt or src == tgt:
            continue
        if (src, tgt) in existing_edges or (tgt, src) in existing_edges:
            continue

        wiki_graph_data.setdefault("edges", []).append({
            "source": src,
            "target": tgt,
            "weight": edge.confidence,
            "edge_type": "INFERRED",
            "label": edge.label,
        })
        existing_edges.add((src, tgt))
        added_edges += 1

    # Apply community assignments from Leiden
    wiki_node_communities: dict[str, int] = {}
    for gf_node in graphify_report.nodes:
        wiki_id = gf_to_wiki.get(gf_node.id)
        if wiki_id:
            wiki_node_communities[wiki_id] = gf_node.community

    for node in wiki_graph_data.get("nodes", []):
        if node["id"] in wiki_node_communities:
            node["community"] = wiki_node_communities[node["id"]]
        # Mark god nodes
        gf_id_for_wiki = None
        for gf_id, wiki_id in gf_to_wiki.items():
            if wiki_id == node["id"]:
                gf_id_for_wiki = gf_id
                break
        if gf_id_for_wiki and gf_id_for_wiki in graphify_report.god_nodes:
            node["is_god_node"] = True

    # Add communities info
    wiki_graph_data["communities"] = [
        {"id": cid, "node_count": len(nodes), "nodes": nodes[:5]}
        for cid, nodes in sorted(graphify_report.communities.items())
    ]
    wiki_graph_data["god_nodes"] = [
        gf_to_wiki.get(g, g) for g in graphify_report.god_nodes
        if gf_to_wiki.get(g) in existing_node_ids
    ]
    wiki_graph_data["surprising_connections"] = graphify_report.surprising_connections

    log.info("Merged: +%d INFERRED edges, %d communities, %d god nodes",
             added_edges, len(graphify_report.communities), len(wiki_graph_data["god_nodes"]))

    return wiki_graph_data


def run_graphify_on_vault(vault_wiki_path: Path) -> GraphifyReport | None:
    """Run graphify CLI on wiki vault and return parsed report."""
    import subprocess

    graphify_dir = Path("/Users/thanhhuynh/Documents/GitHub/finos/research-git-wiki/example/graphify")
    output_dir = vault_wiki_path.parent / "graphify-out"

    if not graphify_dir.exists():
        log.warning("Graphify not found at %s", graphify_dir)
        return None

    # Check for existing output first
    if (output_dir / "graph.json").exists():
        log.info("Using existing graphify output at %s", output_dir)
        return load_graphify_output(output_dir)

    log.info("Running graphify on %s...", vault_wiki_path)
    # Note: graphify is typically run via Claude Code skill, not subprocess
    # For now, just load existing output
    return None
