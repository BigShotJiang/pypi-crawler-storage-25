"""BM25 search index for llm-wiki vault pages.

Replaces the simple keyword-count scoring with Okapi BM25, the same
algorithm used by Elasticsearch and most production search systems.

Usage:
    index = WikiSearchIndex()
    index.build(vault)
    results = index.search("scan_repo skip directories", limit=10)
"""
from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)

# Unicode-aware tokenizer: splits on non-word chars, preserves snake_case parts
_TOKEN_RE = re.compile(r"[\w\u00C0-\u024F\u1E00-\u1EFF]+")

# CJK Unicode ranges (Chinese, Japanese Kanji, Korean Hanja)
_CJK_RE = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf]")

# Vietnamese compound words (common 2-syllable terms that should stay together)
_VI_COMPOUNDS = {
    "ứng viên", "phỏng vấn", "tuyển dụng", "nhân sự", "quản lý",
    "đăng nhập", "đăng ký", "hệ thống", "chức năng", "dữ liệu",
    "công nghệ", "phần mềm", "kỹ thuật", "xác minh", "danh tính",
    "chuyển khoản", "tài khoản", "khách hàng", "sản phẩm", "dự án",
    "báo cáo", "thống kê", "tìm kiếm", "cơ sở", "cập nhật",
    "thông tin", "người dùng", "giao diện", "cấu hình", "triển khai",
}


def _tokenize(text: str) -> list[str]:
    """Lowercase + split text into tokens.

    Handles:
    - snake_case: ``scan_repo`` → [``scan``, ``repo``, ``scan_repo``]
    - Vietnamese diacriticals: ``bỏ qua`` → [``bỏ``, ``qua``]
    - Vietnamese compounds: ``ứng viên`` kept as single token + split parts
    - CJK characters: bigram splitting for Chinese/Japanese/Korean
    - CamelCase kept as-is (users can search by exact name)
    """
    lower = text.lower()
    tokens = []

    # Vietnamese compound words: emit as single token
    for compound in _VI_COMPOUNDS:
        if compound in lower:
            tokens.append(compound.replace(" ", "_"))

    for raw in _TOKEN_RE.findall(lower):
        tokens.append(raw)

        # Sub-tokens for snake_case identifiers
        if "_" in raw:
            tokens.extend(p for p in raw.split("_") if len(p) > 1)

        # CJK bigrams: "默会知识" → ["默会", "会知", "知识"]
        if _CJK_RE.search(raw) and len(raw) > 1:
            chars = list(raw)
            for i in range(len(chars) - 1):
                if _CJK_RE.match(chars[i]) and _CJK_RE.match(chars[i + 1]):
                    tokens.append(chars[i] + chars[i + 1])

    return tokens


def _page_text(page: Path) -> str:
    """Extract searchable text from a vault page."""
    try:
        raw = page.read_text(encoding="utf-8")
    except OSError:
        return page.stem

    # stem (filename without extension) — highest signal, repeated for boosting
    stem_text = page.stem.replace("-", " ").replace("_", " ")
    text = f"{stem_text} {stem_text} {stem_text} {page.stem}"

    # frontmatter title
    m = re.search(r"^title:\s*[\"']?(.+?)[\"']?\s*$", raw, re.MULTILINE | re.IGNORECASE)
    if m:
        text += " " + m.group(1)

    # first H1
    h1 = re.search(r"^#\s+(.+)$", raw, re.MULTILINE)
    if h1:
        text += " " + h1.group(1)

    # full body (strip frontmatter, up to 10k chars)
    body = re.sub(r"^---.*?---\s*", "", raw, flags=re.DOTALL).strip()
    text += " " + body[:10_000]

    return text


@dataclass
class SearchResult:
    path: Path
    score: float
    rel_path: str          # relative to vault.wiki
    snippet: str = ""


@dataclass
class WikiSearchIndex:
    """BM25Okapi index over all vault pages.

    Call ``build(vault)`` once on startup (or after ingest), then
    ``search(query)`` for retrieval.
    """

    _pages: list[Path] = field(default_factory=list, repr=False)
    _index: object = field(default=None, repr=False)   # BM25Okapi instance
    _wiki_root: Path | None = field(default=None, repr=False)

    def build(self, vault) -> None:
        """Index all pages in *vault*. Call after every ingest."""
        from rank_bm25 import BM25Okapi

        pages = list(vault.all_pages())
        if not pages:
            self._pages = []
            self._index = None
            return

        corpus = [_tokenize(_page_text(p)) for p in pages]
        self._pages = pages
        self._index = BM25Okapi(corpus)
        self._wiki_root = vault.wiki
        log.debug("BM25 index built: %d pages", len(pages))

    def search(self, query: str, limit: int = 10) -> list[SearchResult]:
        """Return top-*limit* pages ranked by BM25 score."""
        if self._index is None or not self._pages:
            return []

        tokens = _tokenize(query)
        if not tokens:
            return []

        scores: list[float] = self._index.get_scores(tokens).tolist()

        ranked = sorted(
            ((score, page) for score, page in zip(scores, self._pages) if score > 0),
            key=lambda x: -x[0],
        )

        results = []
        for score, page in ranked[:limit]:
            rel = str(page.relative_to(self._wiki_root)) if self._wiki_root else page.name
            try:
                raw = page.read_text(encoding="utf-8")
                body = re.sub(r"^---.*?---\s*", "", raw, flags=re.DOTALL).strip()
                snippet = body[:160].replace("\n", " ")
            except OSError:
                snippet = ""
            results.append(SearchResult(path=page, score=score, rel_path=rel, snippet=snippet))

        return results

    def invalidate(self, changed_page: Path, vault) -> None:
        """Rebuild the index after a single page changes.

        For small vaults a full rebuild is fast enough; for large vaults
        this could be optimised to update only the changed document.
        """
        self.build(vault)
