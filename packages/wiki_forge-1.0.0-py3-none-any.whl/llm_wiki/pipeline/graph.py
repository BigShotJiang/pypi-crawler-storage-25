"""Build and export a wikilink graph from a vault.

No LLM calls — purely parses existing [[wikilinks]] from wiki pages.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from llm_wiki.vault.paths import Vault
from llm_wiki.vault.wikilinks import WIKILINK_RE

# Layer config: name → {color, order}
LAYER_CONFIG: dict[str, dict] = {
    "concepts":   {"color": "#4f8ef7", "label": "Concepts"},
    "entities":   {"color": "#f7924f", "label": "Entities"},
    "sources":    {"color": "#8e8e8e", "label": "Sources"},
    "syntheses":  {"color": "#a855f7", "label": "Syntheses"},
    "overview":   {"color": "#22c55e", "label": "Overview"},
}
DEFAULT_COLOR = "#cbd5e1"


@dataclass
class GraphData:
    nodes: list[dict] = field(default_factory=list)
    edges: list[dict] = field(default_factory=list)

    @property
    def node_count(self) -> int:
        return len(self.nodes)

    @property
    def edge_count(self) -> int:
        return len(self.edges)


def _layer(page: Path, vault: Vault) -> str:
    """Determine the layer name of a wiki page."""
    try:
        rel = page.relative_to(vault.wiki)
        return rel.parts[0] if len(rel.parts) > 1 else "overview"
    except ValueError:
        return "other"


def _extract_title(page: Path) -> str:
    """Extract frontmatter title or H1, falling back to stem."""
    try:
        raw = page.read_text(encoding="utf-8")
    except OSError:
        return page.stem
    fm = re.search(r"^title:\s*[\"']?(.+?)[\"']?\s*$", raw, re.MULTILINE | re.IGNORECASE)
    if fm:
        return fm.group(1).strip()
    h1 = re.search(r"^#\s+(.+)$", raw, re.MULTILINE)
    if h1:
        return h1.group(1).strip()
    return page.stem


def build_graph(vault: Vault) -> GraphData:
    """Parse all wiki pages and build nodes + edges from [[wikilinks]].

    Returns a :class:`GraphData` with:
    - nodes: id (stem), label (title), layer, color
    - edges: source stem → target stem (only if target exists in vault)
    """
    all_pages = vault.all_pages()
    # Build stem → page map for fast lookup
    stem_map: dict[str, Path] = {p.stem: p for p in all_pages}
    # Also map lowercase stem for case-insensitive matching
    stem_lower: dict[str, str] = {k.lower(): k for k in stem_map}

    # Count inbound links for node sizing
    inbound: dict[str, int] = {stem: 0 for stem in stem_map}

    # Collect edges per page
    edge_set: set[tuple[str, str]] = set()

    for page in all_pages:
        try:
            content = page.read_text(encoding="utf-8")
        except OSError:
            continue
        for m in WIKILINK_RE.finditer(content):
            target_raw = m.group(1).strip()
            # Resolve target: exact → lowercase → not found
            target_stem = (
                target_raw
                if target_raw in stem_map
                else stem_lower.get(target_raw.lower())
            )
            if target_stem and target_stem != page.stem:
                edge_set.add((page.stem, target_stem))
                inbound[target_stem] = inbound.get(target_stem, 0) + 1

    # Build node list
    nodes: list[dict] = []
    for stem, page in stem_map.items():
        layer = _layer(page, vault)
        cfg = LAYER_CONFIG.get(layer, {})
        nodes.append({
            "id": stem,
            "label": _extract_title(page),
            "layer": layer,
            "color": cfg.get("color", DEFAULT_COLOR),
            "inbound": inbound.get(stem, 0),
            # Node radius scaled by connectivity (min 4, max 20)
            "radius": min(20, max(4, 4 + inbound.get(stem, 0) ** 0.6)),
        })

    edges: list[dict] = [{"source": s, "target": t} for s, t in edge_set]

    return GraphData(nodes=nodes, edges=edges)


# ── HTML template ─────────────────────────────────────────────────────────

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{vault_name} — Wiki Graph</title>
<script src="https://d3js.org/d3.v7.min.js"></script>
<style>
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ background: #0f1117; color: #e2e8f0; font-family: -apple-system, sans-serif; overflow: hidden; }}
#toolbar {{
  position: fixed; top: 0; left: 0; right: 0; z-index: 10;
  display: flex; align-items: center; gap: 12px; padding: 10px 16px;
  background: rgba(15,17,23,0.92); backdrop-filter: blur(8px);
  border-bottom: 1px solid #1e293b;
}}
#toolbar h1 {{ font-size: 14px; font-weight: 600; color: #94a3b8; white-space: nowrap; }}
#search {{
  flex: 1; max-width: 260px; padding: 5px 10px; border-radius: 6px;
  border: 1px solid #334155; background: #1e293b; color: #e2e8f0;
  font-size: 13px; outline: none;
}}
#search:focus {{ border-color: #4f8ef7; }}
.filter-btn {{
  padding: 4px 10px; border-radius: 20px; border: 1px solid;
  font-size: 12px; cursor: pointer; transition: opacity .15s;
}}
.filter-btn.off {{ opacity: 0.3; }}
#stats {{ margin-left: auto; font-size: 12px; color: #475569; white-space: nowrap; }}
#tooltip {{
  position: fixed; pointer-events: none; display: none;
  background: #1e293b; border: 1px solid #334155; border-radius: 8px;
  padding: 8px 12px; font-size: 13px; color: #e2e8f0;
  max-width: 260px; z-index: 20; line-height: 1.5;
}}
svg {{ display: block; }}
.node {{ cursor: pointer; transition: opacity .1s; }}
.node:hover circle {{ stroke: #fff; stroke-width: 2px; }}
.link {{ stroke: #334155; stroke-opacity: 0.5; }}
.link.highlighted {{ stroke: #4f8ef7; stroke-opacity: 0.9; }}
.node.dimmed {{ opacity: 0.15; }}
.link.dimmed {{ opacity: 0.05; }}
</style>
</head>
<body>
<div id="toolbar">
  <h1>📊 {vault_name}</h1>
  <input id="search" placeholder="Search pages…" autocomplete="off">
  {filter_buttons}
  <span id="stats">{node_count} nodes · {edge_count} edges</span>
</div>
<div id="tooltip"></div>
<svg id="graph"></svg>

<script>
const RAW = {graph_json};

const layerCfg = {layer_cfg_json};

// ── State ──────────────────────────────────────────────────────────────
const hidden = new Set();
let searchTerm = "";

// ── Setup SVG ──────────────────────────────────────────────────────────
const svg = d3.select("#graph");
const W = window.innerWidth, H = window.innerHeight;
svg.attr("width", W).attr("height", H);

const g = svg.append("g");
svg.call(d3.zoom().scaleExtent([0.1, 8])
  .on("zoom", e => g.attr("transform", e.transform)));

// ── Simulation ─────────────────────────────────────────────────────────
const sim = d3.forceSimulation()
  .force("link", d3.forceLink().id(d => d.id).distance(60).strength(0.4))
  .force("charge", d3.forceManyBody().strength(-120))
  .force("center", d3.forceCenter(W / 2, H / 2))
  .force("collision", d3.forceCollide(d => d.radius + 2));

// ── Draw ───────────────────────────────────────────────────────────────
let link = g.append("g").selectAll(".link");
let node = g.append("g").selectAll(".node");

function redraw() {{
  const visibleIds = new Set(
    RAW.nodes
      .filter(n => !hidden.has(n.layer))
      .filter(n => !searchTerm || n.label.toLowerCase().includes(searchTerm) || n.id.toLowerCase().includes(searchTerm))
      .map(n => n.id)
  );

  const nodes = RAW.nodes.filter(n => visibleIds.has(n.id));
  const links = RAW.edges.filter(e => visibleIds.has(e.source.id || e.source) && visibleIds.has(e.target.id || e.target));

  link = link.data(links, d => d.source + "->" + d.target)
    .join("line").attr("class", "link").attr("stroke-width", 1);

  node = node.data(nodes, d => d.id)
    .join(enter => {{
      const g = enter.append("g").attr("class", "node")
        .call(d3.drag()
          .on("start", (e,d) => {{ if(!e.active) sim.alphaTarget(.3).restart(); d.fx=d.x; d.fy=d.y; }})
          .on("drag",  (e,d) => {{ d.fx=e.x; d.fy=e.y; }})
          .on("end",   (e,d) => {{ if(!e.active) sim.alphaTarget(0); d.fx=null; d.fy=null; }}))
        .on("mouseover", (e, d) => {{
          const tip = document.getElementById("tooltip");
          tip.style.display = "block";
          tip.style.left = (e.clientX + 12) + "px";
          tip.style.top  = (e.clientY - 10) + "px";
          tip.innerHTML  = `<strong>${{d.label}}</strong><br><span style="color:#64748b">${{d.layer}} · ${{d.inbound}} inbound</span>`;
          // highlight neighbours
          const neighbors = new Set([d.id, ...links.filter(l => (l.source.id||l.source)===d.id||(l.target.id||l.target)===d.id).flatMap(l => [l.source.id||l.source, l.target.id||l.target])]);
          node.classed("dimmed", n => !neighbors.has(n.id));
          link.classed("dimmed", l => (l.source.id||l.source)!==d.id && (l.target.id||l.target)!==d.id)
              .classed("highlighted", l => (l.source.id||l.source)===d.id || (l.target.id||l.target)===d.id);
        }})
        .on("mouseout", () => {{
          document.getElementById("tooltip").style.display = "none";
          node.classed("dimmed", false);
          link.classed("dimmed", false).classed("highlighted", false);
        }});
      g.append("circle");
      g.append("text");
      return g;
    }});

  node.select("circle")
    .attr("r", d => d.radius)
    .attr("fill", d => d.color)
    .attr("fill-opacity", 0.85);

  node.select("text")
    .text(d => d.label.length > 22 ? d.label.slice(0,20)+"…" : d.label)
    .attr("x", d => d.radius + 4)
    .attr("y", 4)
    .attr("fill", "#cbd5e1")
    .attr("font-size", "11px")
    .style("pointer-events", "none");

  sim.nodes(nodes).on("tick", () => {{
    link.attr("x1", d=>d.source.x).attr("y1", d=>d.source.y)
        .attr("x2", d=>d.target.x).attr("y2", d=>d.target.y);
    node.attr("transform", d => `translate(${{d.x}},${{d.y}})`);
  }});
  sim.force("link").links(links);
  sim.alpha(0.5).restart();
}}

// ── Filter buttons ─────────────────────────────────────────────────────
document.querySelectorAll(".filter-btn").forEach(btn => {{
  btn.addEventListener("click", () => {{
    const layer = btn.dataset.layer;
    if (hidden.has(layer)) {{ hidden.delete(layer); btn.classList.remove("off"); }}
    else {{ hidden.add(layer); btn.classList.add("off"); }}
    redraw();
  }});
}});

// ── Search ─────────────────────────────────────────────────────────────
document.getElementById("search").addEventListener("input", e => {{
  searchTerm = e.target.value.toLowerCase().trim();
  redraw();
}});

window.addEventListener("resize", () => {{
  svg.attr("width", window.innerWidth).attr("height", window.innerHeight);
  sim.force("center", d3.forceCenter(window.innerWidth/2, window.innerHeight/2)).alpha(0.3).restart();
}});

redraw();
</script>
</body>
</html>
"""


def export_graph_html(vault: Vault, output: Path | None = None) -> Path:
    """Build the graph and write a self-contained HTML file.

    Args:
        vault: The vault to visualise.
        output: Output path. Defaults to ``vault.wiki / "graph.html"``.

    Returns:
        Path to the written HTML file.
    """
    graph = build_graph(vault)

    # Filter buttons HTML
    buttons_html = ""
    for layer, cfg in LAYER_CONFIG.items():
        count = sum(1 for n in graph.nodes if n["layer"] == layer)
        if count == 0:
            continue
        buttons_html += (
            f'<button class="filter-btn" data-layer="{layer}" '
            f'style="color:{cfg["color"]};border-color:{cfg["color"]}">'
            f'{cfg["label"]} ({count})</button>'
        )

    layer_cfg_json = json.dumps(LAYER_CONFIG)
    graph_json = json.dumps({"nodes": graph.nodes, "edges": graph.edges})

    vault_name = vault.root.name
    html = _HTML_TEMPLATE.format(
        vault_name=vault_name,
        filter_buttons=buttons_html,
        node_count=graph.node_count,
        edge_count=graph.edge_count,
        graph_json=graph_json,
        layer_cfg_json=layer_cfg_json,
    )

    out = output or (vault.wiki / "graph.html")
    out.write_text(html, encoding="utf-8")
    return out
