"""Ingest a source file into the wiki (2-step chain-of-thought LLM pipeline).

Step 1 — Analysis: LLM reads the source and produces a structured analysis
  (key entities, concepts, arguments, connections, contradictions).
Step 2 — Generation: LLM uses the analysis + existing wiki state to generate
  wiki pages with higher quality cross-references and deduplication.
"""
from __future__ import annotations

import hashlib
import logging
from datetime import date
from pathlib import Path

from llm_wiki.config import Settings
from llm_wiki.dedup import find_existing_page, merge_page_content
from llm_wiki.exceptions import VaultError
from llm_wiki.json_parser import parse_llm_json
from llm_wiki.llm.base import LLMProvider
from llm_wiki.models import IngestResult
from llm_wiki.vault.paths import Vault

log = logging.getLogger(__name__)


# Load schema lazily (bundled with package)
def _load_schema() -> str:
    schema_path = Path(__file__).parent.parent / "schemas" / "default.md"
    if schema_path.exists():
        return schema_path.read_text(encoding="utf-8")
    return ""


INGEST_SYSTEM = (
    "You are maintaining an LLM Wiki. Process source documents and integrate "
    "their knowledge into a structured wiki with sources, entities, and concepts."
)

# ── Step 1: Analysis prompt ──────────────────────────────────────────────

ANALYSIS_SYSTEM = (
    "You are an expert research analyst. Read the source document and produce "
    "a structured analysis. Be thorough but concise."
)


def _build_analysis_prompt(
    source_name: str,
    source_content: str,
    wiki_context: str,
    existing_entities: list[str],
    existing_concepts: list[str],
) -> str:
    entity_list = ", ".join(existing_entities[:50]) if existing_entities else "(none)"
    concept_list = ", ".join(existing_concepts[:50]) if existing_concepts else "(none)"
    return f"""Analyze this source document and produce a structured analysis.

## Language Rule (CRITICAL)
ALWAYS match the language of the source document. If the source is in Vietnamese, write ALL wiki pages in Vietnamese. If in English, write in English. If mixed (Vietnamese + English), prefer Vietnamese for descriptions and keep English only for technical terms. Wiki page titles, content, and descriptions should all be in the SAME language as the source material.

## Source File: {source_name}
=== SOURCE START ===
{source_content}
=== SOURCE END ===

## Current Wiki State
{wiki_context if wiki_context else "(wiki is empty — first source)"}

## Existing Pages
Entities: {entity_list}
Concepts: {concept_list}

Produce your analysis covering:

### Key Entities
List people, organizations, products, tools. For each: name, role (central/peripheral), whether it matches an existing entity page above.

### Key Concepts
List theories, methods, techniques. For each: name, brief definition, whether it matches an existing concept page above.

### Main Arguments & Findings
Core claims, evidence, strength of evidence.

### Connections to Existing Wiki
What existing pages does this relate to? Does it strengthen, challenge, or extend them?

### Contradictions & Tensions
Conflicts with existing wiki content? Internal caveats?

### Recommendations
What wiki pages should be created or updated? What to emphasize vs de-emphasize?
"""


def _build_generation_prompt(
    source_name: str,
    source_content: str,
    analysis: str,
    schema: str,
    wiki_context: str,
    existing_entities: list[str],
    existing_concepts: list[str],
    today: str,
) -> str:
    dedup_hint = ""
    if existing_entities or existing_concepts:
        dedup_hint = f"""
EXISTING ENTITY PAGES (REUSE these exact names, don't create duplicates):
{", ".join(existing_entities) if existing_entities else "(none)"}

EXISTING CONCEPT PAGES (REUSE these exact names, don't create duplicates):
{", ".join(existing_concepts) if existing_concepts else "(none)"}

CRITICAL: If the source mentions a concept/entity matching any existing page
above (even approximately), use that EXACT existing filename. Don't create
"SkyPoints" if "SkyPoint" exists, or "Membership" vs "Membership Tiers".
"""

    return f"""You are maintaining an LLM Wiki. Based on the analysis below, generate wiki pages.

## Language Rule (CRITICAL)
ALWAYS match the language of the source document. If the source is in Vietnamese, write ALL wiki pages in Vietnamese. If in English, write in English. If mixed (Vietnamese + English), prefer Vietnamese for descriptions and keep English only for technical terms. Wiki page titles, content, and descriptions should all be in the SAME language as the source material.

Schema and conventions:
{schema}

Current wiki state (index + recent pages):
{wiki_context if wiki_context else "(wiki is empty — first source)"}
{dedup_hint}

## Source Analysis (from Step 1)
{analysis}

## Original Source (file: {source_name}):
=== SOURCE START ===
{source_content}
=== SOURCE END ===

Today's date: {today}

Follow the analysis recommendations on what entities/concepts to create or update.
Use [[wikilink]] syntax for cross-references between pages.

Return ONLY a valid JSON object with ALL these fields:
{{
  "title": "Human-readable title",
  "slug": "kebab-case-slug",
  "source_page": "full markdown content for sources/<slug>.md",
  "index_entry": "- [Title](sources/slug.md) — summary",
  "overview_update": "full updated overview.md content, or null",
  "entity_pages": [
    {{"path": "entities/EntityName.md", "content": "full markdown"}}
  ],
  "concept_pages": [
    {{"path": "concepts/ConceptName.md", "content": "full markdown"}}
  ],
  "contradictions": ["describe any contradiction, or empty list"],
  "review_items": [
    {{
      "type": "contradiction | duplicate | missing-page | suggestion",
      "title": "Short descriptive title",
      "detail": "What needs human attention and why",
      "affected_pages": ["EntityName.md", "ConceptName.md"]
    }}
  ],
  "log_entry": "## [{today}] ingest | <title>\\n\\nAdded source. Key claims: ..."
}}

IMPORTANT: All 10 fields are REQUIRED. Use empty strings/arrays/null for missing data.

Review item types:
- contradiction: new source conflicts with existing wiki content
- duplicate: an entity/concept might already exist under different name
- missing-page: an important concept is referenced but has no dedicated page
- suggestion: ideas for further research or connections worth exploring
Only create reviews for things that genuinely need human input.
"""


def _build_wiki_context(vault: Vault, source_text: str = "") -> str:
    """Build a compact wiki-state summary for the LLM prompt.

    When *source_text* is provided, entity/concept pages whose filename
    appears in the source are included so the LLM can detect contradictions
    (e.g. role changes, version conflicts).
    """
    parts = []
    if vault.index.exists():
        parts.append(f"## wiki/index.md\n{vault.index.read_text(encoding='utf-8')}")
    if vault.overview.exists():
        parts.append(f"## wiki/overview.md\n{vault.overview.read_text(encoding='utf-8')}")

    # Include a few recent source pages for contradiction detection
    if vault.sources.exists():
        recent = sorted(
            vault.sources.glob("*.md"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )[:5]
        for p in recent:
            parts.append(f"## {p.relative_to(vault.root)}\n{p.read_text(encoding='utf-8')}")

    # Include entity/concept pages mentioned in the new source text
    # so LLM can detect contradictions (e.g. "CEO" vs "CTO")
    if source_text:
        source_lower = source_text.lower()
        related_pages: list[Path] = []
        for folder in (vault.entities, vault.concepts):
            if not folder.exists():
                continue
            for p in folder.glob("*.md"):
                # Match entity name (filename without .md) in source text
                entity_name = p.stem.lower()
                if len(entity_name) >= 3 and entity_name in source_lower:
                    related_pages.append(p)

        # Sort by relevance (name length desc = more specific first), limit 10
        related_pages.sort(key=lambda p: len(p.stem), reverse=True)
        for p in related_pages[:10]:
            content = p.read_text(encoding="utf-8")
            # Truncate long pages to save tokens
            if len(content) > 1500:
                content = content[:1500] + "\n... (truncated)"
            parts.append(
                f"## EXISTING: {p.relative_to(vault.root)}\n{content}"
            )
        if related_pages:
            log.info(
                "Contradiction check: included %d related entity/concept pages",
                min(len(related_pages), 10),
            )

    return "\n\n---\n\n".join(parts)


def _update_index(vault: Vault, new_entry: str, section: str = "Sources") -> None:
    if not vault.index.exists():
        vault.index.parent.mkdir(parents=True, exist_ok=True)
        vault.index.write_text(
            "# Wiki Index\n\n## Overview\n- [Overview](overview.md)\n\n"
            "## Sources\n\n## Entities\n\n## Concepts\n\n## Syntheses\n",
            encoding="utf-8",
        )
    content = vault.index.read_text(encoding="utf-8")
    header = f"## {section}"
    if header in content:
        content = content.replace(header + "\n", f"{header}\n{new_entry}\n")
    else:
        content += f"\n{header}\n{new_entry}\n"
    vault.index.write_text(content, encoding="utf-8")


def _append_log(vault: Vault, entry: str) -> None:
    existing = vault.log.read_text(encoding="utf-8") if vault.log.exists() else ""
    vault.log.parent.mkdir(parents=True, exist_ok=True)
    vault.log.write_text(entry.strip() + "\n\n" + existing, encoding="utf-8")


def _write_page_with_dedup(
    vault: Vault,
    target_rel_path: str,
    content: str,
    settings: Settings,
) -> Path:
    """Write a page, merging into an existing fuzzy-matched page if found."""
    existing = find_existing_page(
        vault.wiki,
        target_rel_path,
        fuzzy_threshold=settings.fuzzy_threshold,
        substring_min_len=settings.compact_substring_min_len,
    )
    if existing:
        merged = merge_page_content(existing, content)
        existing.write_text(merged, encoding="utf-8")
        log.info("Merged into: %s", existing.relative_to(vault.root))
        return existing

    target = vault.wiki / target_rel_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    log.info("Wrote: %s", target.relative_to(vault.root))
    return target


async def ingest_source(
    source: Path,
    vault: Vault,
    llm: LLMProvider,
    settings: Settings,
    *,
    update: bool = False,
) -> IngestResult:
    """Ingest a single source file into the wiki via 1-shot LLM call.

    Writes source page + entity pages + concept pages (with fuzzy dedup),
    updates index and overview, appends to log.

    Args:
        update: If True, skip ingestion when the source file hash is unchanged
                since last ingest (uses vault/.ingest-state.json).

    Raises :class:`VaultError` if the source file doesn't exist,
    :class:`JSONParseError` on bad LLM response.
    """
    if not source.exists():
        raise VaultError(f"Source file not found: {source}")

    content = source.read_text(encoding="utf-8")
    today = date.today().isoformat()
    source_hash = hashlib.sha256(content.encode()).hexdigest()[:16]

    # --update mode: skip if hash unchanged
    source_key = str(source.resolve())
    if update and vault.is_source_unchanged(source_key, source_hash):
        log.info("Skipping %s (unchanged, hash: %s)", source.name, source_hash)
        return IngestResult(
            title=source.stem,
            slug=source.stem,
            skipped=True,
        )

    log.info("Ingesting %s (hash: %s)", source.name, source_hash)

    # Truncate if too large
    if len(content) > settings.max_source_chars:
        log.warning(
            "Source %s truncated from %d to %d chars",
            source.name,
            len(content),
            settings.max_source_chars,
        )
        content = content[: settings.max_source_chars] + "\n\n[...truncated...]"

    wiki_context = _build_wiki_context(vault, source_text=content)
    schema = _load_schema()

    existing_entities = [p.stem for p in vault.entity_pages()]
    existing_concepts = [p.stem for p in vault.concept_pages()]

    source_rel = source.relative_to(vault.root) if source.is_relative_to(vault.root) else source.name

    # ── Step 1: Analysis ─────────────────────────────────────────────
    log.info("Step 1/2: Analyzing %s", source.name)
    analysis_prompt = _build_analysis_prompt(
        source_name=str(source_rel),
        source_content=content,
        wiki_context=wiki_context,
        existing_entities=sorted(existing_entities),
        existing_concepts=sorted(existing_concepts),
    )
    analysis_response = await llm.generate(
        analysis_prompt,
        system=ANALYSIS_SYSTEM,
        model=settings.heavy_model,
        max_tokens=2048,
    )
    analysis = analysis_response.text
    log.info("  Analysis done (%d tokens in, %d out)",
             analysis_response.input_tokens, analysis_response.output_tokens)

    # ── Step 2: Generation ───────────────────────────────────────────
    log.info("Step 2/2: Generating wiki pages for %s", source.name)
    prompt = _build_generation_prompt(
        source_name=str(source_rel),
        source_content=content,
        analysis=analysis,
        schema=schema,
        wiki_context=wiki_context,
        existing_entities=sorted(existing_entities),
        existing_concepts=sorted(existing_concepts),
        today=today,
    )

    # Call LLM
    response = await llm.generate(
        prompt,
        system=INGEST_SYSTEM,
        model=settings.heavy_model,
        max_tokens=settings.max_tokens_ingest,
        response_format="json",
    )

    data = parse_llm_json(response.text)
    total_in = analysis_response.input_tokens + response.input_tokens
    total_out = analysis_response.output_tokens + response.output_tokens

    result = IngestResult(
        title=data.get("title", source.stem),
        slug=data.get("slug") or source.stem,
        source_page=data.get("source_page") or f"# {source.stem}\n\n(empty)",
        index_entry=data.get("index_entry") or f"- [{source.stem}](sources/{source.stem}.md)",
        overview_update=data.get("overview_update"),
        entity_pages=data.get("entity_pages") or [],
        concept_pages=data.get("concept_pages") or [],
        contradictions=data.get("contradictions") or [],
        log_entry=data.get("log_entry") or f"## [{today}] ingest | {source.stem}",
        input_tokens=total_in,
        output_tokens=total_out,
    )

    # Write source page
    vault.sources.mkdir(parents=True, exist_ok=True)
    (vault.sources / f"{result.slug}.md").write_text(result.source_page, encoding="utf-8")

    # Write entity pages with dedup
    for page in result.entity_pages:
        path = page.path if isinstance(page, dict) else page.path
        content_page = page.content if isinstance(page, dict) else page.content
        if path and content_page:
            _write_page_with_dedup(vault, path, content_page, settings)

    # Write concept pages with dedup
    for page in result.concept_pages:
        path = page.path if isinstance(page, dict) else page.path
        content_page = page.content if isinstance(page, dict) else page.content
        if path and content_page:
            _write_page_with_dedup(vault, path, content_page, settings)

    # Update overview
    if result.overview_update:
        vault.overview.parent.mkdir(parents=True, exist_ok=True)
        vault.overview.write_text(result.overview_update, encoding="utf-8")

    # Update index
    _update_index(vault, result.index_entry, section="Sources")

    # Append log
    _append_log(vault, result.log_entry)

    # Persist hash for --update mode
    vault.save_ingest_hash(source_key, source_hash)

    # ── Capture review items (rich LLM-generated + legacy contradictions) ──
    try:
        from llm_wiki.pipeline.review import ReviewStore, extract_review_items_from_contradictions
        from llm_wiki.models import ReviewItem
        store = ReviewStore(vault.root)
        all_review_items: list[ReviewItem] = []

        # Rich review items from LLM (new format)
        raw_reviews = data.get("review_items") or []
        for r in raw_reviews:
            if isinstance(r, dict) and r.get("title"):
                all_review_items.append(ReviewItem(
                    review_type=r.get("type", "suggestion"),
                    title=r.get("title", ""),
                    detail=r.get("detail", ""),
                    source_file=source.name,
                    affected_pages=r.get("affected_pages", []),
                ))

        # Legacy contradictions (backward compat)
        if result.contradictions:
            all_review_items.extend(
                extract_review_items_from_contradictions(result.contradictions, source.name)
            )

        if all_review_items:
            store.add_many(all_review_items)
    except Exception as e:
        log.warning("Failed to save review items: %s", e)

    log.info("Done ingesting: %s", result.title)
    return result
