"""Code-Doc Drift Detection — find ALL types of contradictions.

Detects 7 categories of drift:
1. CODE_CHANGED    — code changed but wiki page not re-generated
2. DOC_STALE       — docs/ changed but wiki sources/ not re-ingested
3. WIKI_CONFLICT   — two wiki pages contradict each other
4. DELETED_REF     — wiki references code/files that no longer exist
5. MISSING_DOC     — new code files without any wiki coverage
6. CONFIG_DRIFT    — env vars, deps, or config changed but wiki outdated
7. CROSS_REPO      — (future) FE/BE docs contradict each other

Usage:
    report = await detect_drift(vault, repo_path, llm, model)
    # or lightweight (no LLM):
    report = detect_drift_structural(vault, repo_path)
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

from llm_wiki.code.extractor import load_hash_cache, scan_repo
from llm_wiki.llm.base import LLMProvider
from llm_wiki.models import ReviewItem
from llm_wiki.pipeline.review import ReviewStore
from llm_wiki.vault.paths import Vault
from llm_wiki.vault.wikilinks import extract_wikilinks

log = logging.getLogger(__name__)

# Config/dependency files to watch
_CONFIG_PATTERNS = [
    "requirements.txt", "pyproject.toml", "package.json", "Cargo.toml",
    "go.mod", "Dockerfile", "docker-compose.yml", ".env.example",
    "*.toml", "*.ini", "*.yaml", "*.yml",
]


@dataclass
class DriftItem:
    drift_type: str  # code_changed | doc_stale | wiki_conflict | deleted_ref | missing_doc | config_drift
    severity: str = "warning"  # warning | info
    title: str = ""
    detail: str = ""
    code_files: list[str] = field(default_factory=list)
    wiki_pages: list[str] = field(default_factory=list)


@dataclass
class DriftReport:
    items: list[DriftItem] = field(default_factory=list)
    files_scanned: int = 0
    pages_checked: int = 0

    def summary(self) -> str:
        by_type: dict[str, int] = {}
        for i in self.items:
            by_type[i.drift_type] = by_type.get(i.drift_type, 0) + 1
        parts = [f"{v} {k}" for k, v in sorted(by_type.items())]
        return (
            f"Drift: {self.files_scanned} files, {self.pages_checked} wiki pages → "
            f"{len(self.items)} issues ({', '.join(parts) if parts else 'clean'})"
        )


# ── Structural drift (no LLM, fast) ─────────────────────────────────────

def detect_drift_structural(
    vault: Vault,
    repo_path: Path,
    extensions: list[str] | None = None,
) -> DriftReport:
    """Fast drift detection without LLM. Checks hash changes + structural issues."""
    report = DriftReport()
    code_output = vault.wiki / "outputs" / "code"

    # ── Scan repo ────────────────────────────────────────────────────
    all_files = scan_repo(repo_path, extensions=extensions)
    report.files_scanned = len(all_files)
    current_paths = {f.path for f in all_files}

    # ── Load old hashes ──────────────────────────────────────────────
    cache_path = vault.root / ".code-hash-cache.json"
    old_hashes = load_hash_cache(cache_path)

    changed_files: list[str] = []
    new_files: list[str] = []
    deleted_files: list[str] = []

    for f in all_files:
        old = old_hashes.get(f.path)
        if old is None:
            new_files.append(f.path)
        elif old != f.file_hash:
            changed_files.append(f.path)

    for old_path in old_hashes:
        if old_path not in current_paths:
            deleted_files.append(old_path)

    # ── Case 1: CODE_CHANGED — code changed, wiki may be stale ──────
    if changed_files:
        report.items.append(DriftItem(
            drift_type="code_changed",
            severity="warning",
            title=f"{len(changed_files)} code files changed since last wiki update",
            detail="Run `llm-wiki ingest-code --update` to refresh wiki.\n"
                   + "\n".join(f"  - {f}" for f in changed_files[:15]),
            code_files=changed_files,
        ))

    # ── Case 4: DELETED_REF — wiki references deleted files ──────────
    if deleted_files and code_output.exists():
        # Check which wiki pages mention deleted files
        for page in code_output.glob("*.md"):
            try:
                content = page.read_text(encoding="utf-8")
            except OSError:
                continue
            refs_deleted = [f for f in deleted_files if f in content or f.split("/")[-1] in content]
            if refs_deleted:
                report.items.append(DriftItem(
                    drift_type="deleted_ref",
                    severity="warning",
                    title=f"{page.stem} references deleted files",
                    detail=f"Files no longer exist:\n" + "\n".join(f"  - {f}" for f in refs_deleted),
                    code_files=refs_deleted,
                    wiki_pages=[page.stem],
                ))

    # ── Case 5: MISSING_DOC — new files without wiki coverage ────────
    if new_files:
        report.items.append(DriftItem(
            drift_type="missing_doc",
            severity="info",
            title=f"{len(new_files)} new files without documentation",
            detail="New files since last ingest:\n" + "\n".join(f"  - {f}" for f in new_files[:20]),
            code_files=new_files[:20],
        ))

    # ── Case 2: DOC_STALE — docs/ files changed but not re-ingested ─
    docs_dir = repo_path / "docs"
    if docs_dir.exists():
        ingest_state = vault.load_ingest_state() if hasattr(vault, 'load_ingest_state') else {}
        for md in docs_dir.rglob("*.md"):
            md_key = str(md.resolve())
            import hashlib
            current_hash = hashlib.sha256(md.read_bytes()).hexdigest()[:16]
            old_hash = ingest_state.get(md_key)
            if old_hash and old_hash != current_hash:
                report.items.append(DriftItem(
                    drift_type="doc_stale",
                    severity="warning",
                    title=f"docs/{md.name} changed but wiki not updated",
                    detail=f"File {md.relative_to(repo_path)} has been modified. "
                           f"Run `llm-wiki ingest {md} --update` to refresh wiki.",
                    code_files=[str(md.relative_to(repo_path))],
                ))

    # ── Case 6: CONFIG_DRIFT — config/deps changed ──────────────────
    config_changed = [f for f in changed_files if _is_config_file(f)]
    if config_changed:
        report.items.append(DriftItem(
            drift_type="config_drift",
            severity="warning",
            title=f"{len(config_changed)} config/dependency files changed",
            detail="These changes may affect wiki accuracy:\n"
                   + "\n".join(f"  - {f}" for f in config_changed),
            code_files=config_changed,
        ))

    # ── Case 3: WIKI_CONFLICT — broken wikilinks (structural only) ──
    all_pages = vault.all_pages()
    report.pages_checked = len(all_pages)
    stems = {p.stem.lower() for p in all_pages}

    for page in all_pages:
        try:
            content = page.read_text(encoding="utf-8")
        except OSError:
            continue
        for link in extract_wikilinks(content):
            if link.lower() not in stems:
                report.items.append(DriftItem(
                    drift_type="deleted_ref",
                    severity="info",
                    title=f"Broken wikilink [[{link}]] in {page.stem}",
                    detail=f"Page {page.name} links to [[{link}]] but no such page exists.",
                    wiki_pages=[page.stem],
                ))

    log.info(report.summary())
    return report


def _is_config_file(path: str) -> bool:
    """Check if a file path is a config/dependency file."""
    name = path.split("/")[-1].lower()
    config_names = {
        "requirements.txt", "pyproject.toml", "package.json", "package-lock.json",
        "cargo.toml", "go.mod", "go.sum", "dockerfile", "docker-compose.yml",
        "docker-compose.yaml", ".env.example", ".env.sample", "makefile",
    }
    if name in config_names:
        return True
    if name.endswith((".toml", ".ini", ".yaml", ".yml", ".cfg")):
        return True
    return False


# ── Semantic drift (with LLM) ────────────────────────────────────────────

async def detect_drift(
    vault: Vault,
    repo_path: Path,
    llm: LLMProvider,
    model: str | None = None,
    extensions: list[str] | None = None,
) -> DriftReport:
    """Full drift detection: structural checks + LLM semantic analysis.

    Covers all 7 drift categories:
    1. code_changed    — code changed, wiki stale
    2. doc_stale       — docs/ changed, wiki sources/ not re-ingested
    3. wiki_conflict   — wiki pages contradict each other
    4. deleted_ref     — wiki references deleted code/files
    5. missing_doc     — new code without wiki coverage
    6. config_drift    — config/deps changed, wiki may be wrong
    7. contradiction   — LLM detects semantic contradiction code↔wiki
    """
    # Start with structural checks (no LLM cost)
    report = detect_drift_structural(vault, repo_path, extensions)

    code_output = vault.wiki / "outputs" / "code"
    if not code_output.exists():
        return report

    # Find changed files for LLM checks
    all_files = scan_repo(repo_path, extensions=extensions)
    cache_path = vault.root / ".code-hash-cache.json"
    old_hashes = load_hash_cache(cache_path)
    changed_set = {f.path for f in all_files if old_hashes.get(f.path) != f.file_hash}

    if not changed_set:
        return report

    # ── LLM semantic contradiction check ─────────────────────────────
    wiki_pages = [p for p in code_output.glob("*.md")
                  if p.stem != "overview" and not p.stem.startswith("parent-")]

    for page in wiki_pages:
        try:
            content = page.read_text(encoding="utf-8")
        except OSError:
            continue

        # Find changed files mentioned in this wiki page
        mentioned_changed = []
        for f in all_files:
            if f.path in changed_set and (f.path in content or f.path.split("/")[-1] in content):
                mentioned_changed.append(f.path)

        if not mentioned_changed:
            continue

        # LLM check
        drift_detail = await _check_contradiction(
            page.stem, content, mentioned_changed, repo_path, llm, model
        )
        if drift_detail:
            report.items.append(DriftItem(
                drift_type="contradiction",
                severity="warning",
                title=f"Semantic drift: {page.stem}",
                detail=drift_detail,
                code_files=mentioned_changed,
                wiki_pages=[page.stem],
            ))

    # ── LLM wiki-vs-wiki conflict check ──────────────────────────────
    wiki_conflicts = await _check_wiki_conflicts(vault, llm, model)
    report.items.extend(wiki_conflicts)

    # ── Save all items to review store ───────────────────────────────
    if report.items:
        try:
            store = ReviewStore(vault.root)
            review_items = [
                ReviewItem(
                    review_type=item.drift_type,
                    title=item.title,
                    detail=item.detail,
                    affected_pages=item.wiki_pages,
                )
                for item in report.items
                if item.severity == "warning"  # only save warnings
            ]
            if review_items:
                store.add_many(review_items)
        except Exception as e:
            log.warning("Failed to save drift items: %s", e)

    log.info(report.summary())
    return report


async def _check_contradiction(
    module_name: str,
    wiki_content: str,
    changed_files: list[str],
    repo_path: Path,
    llm: LLMProvider,
    model: str | None,
) -> str | None:
    """LLM: does changed code contradict wiki documentation?"""
    code_snippets: list[str] = []
    for fpath in changed_files[:5]:
        full_path = repo_path / fpath
        if full_path.exists():
            try:
                code = full_path.read_text(encoding="utf-8")[:3000]
                code_snippets.append(f"### {fpath}\n```\n{code}\n```")
            except OSError:
                continue

    if not code_snippets:
        return None

    prompt = f"""Compare this wiki documentation with the current code.
Identify ANY of these issues:
- Numbers/values that don't match (versions, limits, counts)
- Features described in wiki but removed from code
- New functionality in code not mentioned in wiki
- API endpoints/parameters that changed
- Config/env vars that changed

## Wiki Documentation: {module_name}
{wiki_content[:3000]}

## Current Code (recently changed)
{chr(10).join(code_snippets)}

If you find issues, describe each concisely (1-2 sentences per issue).
If the documentation is still accurate, respond with exactly: "NO_DRIFT"
"""
    try:
        resp = await llm.generate(prompt, model=model, max_tokens=500)
        result = resp.text.strip()
        if "NO_DRIFT" in result:
            return None
        return result
    except Exception as e:
        log.warning("Drift check LLM failed for %s: %s", module_name, e)
        return None


async def _check_wiki_conflicts(
    vault: Vault,
    llm: LLMProvider,
    model: str | None,
) -> list[DriftItem]:
    """LLM: do any wiki pages contradict each other? (Case 3)

    Sends compact summaries of all pages to LLM to find inter-page conflicts.
    """
    pages = vault.all_pages()
    if len(pages) < 3:
        return []

    # Build compact summaries (frontmatter + first 200 chars body)
    summaries: list[str] = []
    for p in pages:
        if p.name in ("log.md", "index.md"):
            continue
        try:
            content = p.read_text(encoding="utf-8")
        except OSError:
            continue
        # Extract key facts only
        body = re.sub(r"^---.*?---\s*", "", content, flags=re.DOTALL).strip()
        preview = body[:200] + "..." if len(body) > 200 else body
        summaries.append(f"### {p.stem}\n{preview}")

    if len(summaries) < 3:
        return []

    # Limit to 50 pages to stay within token budget
    prompt = f"""Review these wiki page summaries. Find pages that CONTRADICT each other.

Look for:
- Two pages stating different values for the same thing (versions, limits, dates)
- One page saying a feature exists while another says it was removed
- Inconsistent terminology or naming

ONLY report genuine contradictions. Do NOT report missing information.

## Pages
{chr(10).join(summaries[:50])}

For each contradiction found, output exactly:
CONFLICT: page1 vs page2 | description

If no contradictions found, respond with: "NO_CONFLICTS"
"""
    try:
        resp = await llm.generate(prompt, model=model, max_tokens=1000)
        result = resp.text.strip()
        if "NO_CONFLICTS" in result:
            return []

        items: list[DriftItem] = []
        for line in result.split("\n"):
            if line.strip().startswith("CONFLICT:"):
                rest = line.strip()[9:].strip()
                parts = rest.split("|", 1)
                pages_part = parts[0].strip() if parts else ""
                detail = parts[1].strip() if len(parts) > 1 else rest
                page_names = [p.strip() for p in pages_part.split(" vs ")]
                items.append(DriftItem(
                    drift_type="wiki_conflict",
                    severity="warning",
                    title=f"Wiki conflict: {pages_part}",
                    detail=detail,
                    wiki_pages=page_names,
                ))
        return items
    except Exception as e:
        log.warning("Wiki conflict check failed: %s", e)
        return []
