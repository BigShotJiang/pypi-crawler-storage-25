"""Linkback pass: rewrite plain-text mentions of orphan pages → wikilinks.

Many LLMs generate concept pages without backlinks from other pages.
This pass finds orphan pages, searches for plain-text mentions in the
rest of the vault, and wraps the first occurrence per page as
``[[ConceptName]]`` — preserving existing wikilinks and code blocks.
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from pathlib import Path

from llm_wiki.vault.paths import Vault
from llm_wiki.vault.wikilinks import WIKILINK_RE, extract_wikilinks

log = logging.getLogger(__name__)

# Match fenced code blocks (``` ... ```) and inline code (`...`)
_CODE_BLOCK_RE = re.compile(r"```[\s\S]*?```|`[^`\n]+`")

# Match markdown links: [text](url) — excludes wikilinks [[text]]
_MARKDOWN_LINK_RE = re.compile(r"(?<!\[)\[([^\]]+)\]\(([^)]+)\)")


def find_orphans(vault: Vault) -> list[Path]:
    """Return concept/entity pages with zero inbound wikilinks.

    Overview and source pages are excluded from orphan check — only
    entity and concept pages that should be discoverable via links.
    """
    pages = vault.all_pages()
    if not pages:
        return []

    stems_lower: dict[str, list[Path]] = defaultdict(list)
    for p in pages:
        stems_lower[p.stem.lower()].append(p)

    inbound: dict[Path, int] = defaultdict(int)
    for page in pages:
        try:
            content = page.read_text(encoding="utf-8")
        except Exception:
            continue
        for link in extract_wikilinks(content):
            key = link.strip().lower()
            if key in stems_lower:
                for target in stems_lower[key]:
                    inbound[target] += 1

    orphans: list[Path] = []
    for page in pages:
        if page.name == "overview.md":
            continue
        if page.parent.name == "sources":
            # Sources are expected to be linked via overview.md's All Sources
            # section — not from other concept pages
            continue
        if inbound.get(page, 0) == 0:
            orphans.append(page)

    return orphans


def _mask_protected_spans(content: str) -> tuple[str, list[tuple[int, int, str]]]:
    """Replace code blocks and wikilinks with placeholder chars.

    Returns (masked_content, spans) where spans is
    ``[(start, end, original_text), ...]`` for restoration.
    """
    spans: list[tuple[int, int, str]] = []
    masked_chars = list(content)

    # Mask code blocks first (longest protection)
    for match in _CODE_BLOCK_RE.finditer(content):
        start, end = match.span()
        spans.append((start, end, match.group(0)))
        for i in range(start, end):
            masked_chars[i] = "\x00"  # sentinel char

    # Mask wikilinks
    for match in WIKILINK_RE.finditer(content):
        start, end = match.span()
        # Skip if already inside a code block
        if masked_chars[start] == "\x00":
            continue
        spans.append((start, end, match.group(0)))
        for i in range(start, end):
            masked_chars[i] = "\x01"

    # Mask markdown links [text](url) — avoid writing [[ inside [...]
    for match in _MARKDOWN_LINK_RE.finditer(content):
        start, end = match.span()
        if masked_chars[start] in ("\x00", "\x01"):
            continue
        spans.append((start, end, match.group(0)))
        for i in range(start, end):
            masked_chars[i] = "\x02"

    return "".join(masked_chars), spans


def _find_first_unmasked_occurrence(
    content: str,
    masked: str,
    term: str,
) -> tuple[int, int] | None:
    """Find the first case-insensitive word-boundary match of ``term``
    in ``content`` whose characters are all unmasked."""
    pattern = r"\b" + re.escape(term) + r"\b"
    protected = {"\x00", "\x01", "\x02"}
    for match in re.finditer(pattern, content, re.IGNORECASE):
        start, end = match.span()
        # Check the masked version — all chars must be original (unmasked)
        if all(masked[i] not in protected for i in range(start, end)):
            return (start, end)
    return None


def linkback_page(
    page: Path,
    orphans: list[tuple[str, str]],
    *,
    apply: bool,
) -> int:
    """Rewrite plain-text mentions of orphans in ``page`` as wikilinks.

    Each orphan name is linked at most ONCE per page (first occurrence).

    Args:
        page: Page to process.
        orphans: List of ``(display_name, canonical_stem)`` tuples.
        apply: If True, write changes to disk.

    Returns: number of plain-text mentions rewritten.
    """
    content = page.read_text(encoding="utf-8")
    masked, _ = _mask_protected_spans(content)
    rewrites = 0

    # Sort orphans by length descending so longer names are matched first
    # (avoids partial matches like "Fixed Point" matching before "Fixed Point Ticket")
    for display, stem in sorted(orphans, key=lambda x: -len(x[0])):
        occ = _find_first_unmasked_occurrence(content, masked, display)
        if occ is None:
            continue
        start, end = occ
        matched_text = content[start:end]
        # Build replacement — use alias if canonical stem differs from matched text
        if stem == matched_text:
            replacement = f"[[{stem}]]"
        else:
            replacement = f"[[{stem}|{matched_text}]]"
        content = content[:start] + replacement + content[end:]
        # Re-mask content after mutation so subsequent orphans skip our new wikilink
        masked, _ = _mask_protected_spans(content)
        rewrites += 1

    if apply and rewrites > 0:
        page.write_text(content, encoding="utf-8")

    return rewrites


def linkback_vault(vault: Vault, *, apply: bool = False) -> dict[str, int]:
    """Run link-back pass on the vault.

    Returns stats: ``{orphans_before, orphans_after, rewrites}``.
    """
    orphans_before = find_orphans(vault)
    if not orphans_before:
        return {"orphans_before": 0, "orphans_after": 0, "rewrites": 0}

    # Build list of (display_name, canonical_stem) for each orphan
    orphan_info: list[tuple[str, str]] = [(p.stem, p.stem) for p in orphans_before]

    # Map stem → orphan path for self-link filtering
    orphan_stems: dict[str, Path] = {p.stem: p for p in orphans_before}

    total_rewrites = 0
    for page in vault.all_pages():
        if page.name == "log.md":
            continue
        # Exclude orphans whose stem matches the current page (avoid self-link)
        filtered = [
            (disp, stem)
            for (disp, stem) in orphan_info
            if orphan_stems.get(stem) != page
        ]
        if not filtered:
            continue
        total_rewrites += linkback_page(page, filtered, apply=apply)

    orphans_after = find_orphans(vault) if apply else orphans_before
    return {
        "orphans_before": len(orphans_before),
        "orphans_after": len(orphans_after),
        "rewrites": total_rewrites,
    }
