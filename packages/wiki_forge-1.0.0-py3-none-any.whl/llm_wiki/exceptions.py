"""Custom exceptions for llm-wiki."""


class LLMWikiError(Exception):
    """Base exception for llm-wiki."""


class LLMError(LLMWikiError):
    """LLM provider call failed."""


class JSONParseError(LLMWikiError):
    """Failed to parse LLM JSON response."""


class VaultError(LLMWikiError):
    """Vault operation failed."""
