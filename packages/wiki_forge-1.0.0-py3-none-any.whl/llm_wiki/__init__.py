"""Karpathy-style LLM Wiki compiler."""

from llm_wiki.config import Settings
from llm_wiki.exceptions import (
    JSONParseError,
    LLMError,
    LLMWikiError,
    VaultError,
)
from llm_wiki.llm.base import LLMProvider, LLMResponse
from llm_wiki.llm.gemini import GeminiClient
from llm_wiki.models import (
    Concept,
    ConceptPage,
    Entity,
    EntityPage,
    IngestResult,
    WikiPage,
)
from llm_wiki.linkback import find_orphans, linkback_vault
from llm_wiki.pipeline.ingest import ingest_source
from llm_wiki.pipeline.lint import lint_vault
from llm_wiki.pipeline.query import query_wiki
from llm_wiki.vault.paths import Vault

__version__ = "0.1.0"

__all__ = [
    "__version__",
    # Config
    "Settings",
    "Vault",
    # LLM
    "LLMProvider",
    "LLMResponse",
    "GeminiClient",
    # Models
    "Concept",
    "ConceptPage",
    "Entity",
    "EntityPage",
    "IngestResult",
    "WikiPage",
    # Pipeline
    "ingest_source",
    "query_wiki",
    "lint_vault",
    "linkback_vault",
    "find_orphans",
    # Exceptions
    "LLMWikiError",
    "LLMError",
    "JSONParseError",
    "VaultError",
]
