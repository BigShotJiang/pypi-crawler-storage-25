"""Post-process broken wikilinks in a vault.

Strategy:
1. Build an index of all existing pages (stem + frontmatter title)
2. For each ``[[link]]`` that doesn't match a stem exactly:
   - Try fuzzy match (4 strategies from :mod:`dedup`)
   - Rewrite to canonical ``[[stem|Display]]`` or strip to plain text
3. Auto-link orphan sources from ``overview.md`` via ``## All Sources`` section
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from pathlib import Path

import frontmatter

from llm_wiki.dedup import compact_key, fuzzy_key
from llm_wiki.vault.paths import Vault
from llm_wiki.vault.wikilinks import WIKILINK_RE, has_bracket_unsafe_chars

log = logging.getLogger(__name__)


def build_index(wiki_dir: Path) -> dict[str, str]:
    """Return ``{normalized_key → canonical_stem}`` for fuzzy matching.

    Each page contributes multiple keys (stem, title, normalized variants).
    """
    index: dict[str, str] = {}

    for md in wiki_dir.rglob("*.md"):
        if md.name in ("index.md", "log.md", "lint-report.md"):
            continue
        stem = md.stem

        keys: set[str] = {
            stem.lower(),
            fuzzy_key(stem),
            compact_key(stem),
        }

        # Also pull title from frontmatter
        try:
            post = frontmatter.load(str(md))
            title = post.metadata.get("title", "")
            if title and isinstance(title, str):
                keys.add(title.lower())
                keys.add(fuzzy_key(title))
                keys.add(compact_key(title))
        except Exception as e:
            log.debug("Failed to parse frontmatter for %s: %s", md, e)

        for key in keys:
            if key and key not in index:
                index[key] = stem

    return index


def find_match(
    link_text: str,
    index: dict[str, str],
    all_stems: list[str],
    *,
    substring_min_len: int = 6,
) -> str | None:
    """Try to resolve a broken wikilink to an existing page stem."""
    # 1. Exact lowercase
    if link_text.lower() in index:
        return index[link_text.lower()]

    # 2. Fuzzy key
    fk = fuzzy_key(link_text)
    if fk in index:
        return index[fk]

    # 3. Compact key
    ck = compact_key(link_text)
    if ck in index:
        return index[ck]

    # 4. Substring match (avoid trivial short matches)
    if len(ck) >= substring_min_len:
        for stem in all_stems:
            stem_ck = compact_key(stem)
            if ck in stem_ck or stem_ck in ck:
                # Avoid very lopsided matches
                longer = max(len(ck), len(stem_ck))
                if abs(len(ck) - len(stem_ck)) < longer * 0.5:
                    return stem

    return None


def fix_page(
    page: Path,
    stems_set: set[str],
    index: dict[str, str],
    all_stems: list[str],
    *,
    apply: bool,
) -> dict[str, int]:
    """Process one page, returning counts of ``fixed``/``stripped``/``kept``."""
    content = page.read_text(encoding="utf-8")
    counts = {"fixed": 0, "stripped": 0, "kept": 0}

    def replacer(match: re.Match) -> str:
        link = match.group(1).strip()
        display = match.group(2) or link

        # Strict: link.lower() must match a stem.lower() exactly
        if link.lower() in stems_set:
            counts["kept"] += 1
            return match.group(0)

        # Try fuzzy match to canonical stem
        matched = find_match(link, index, all_stems)
        if matched and matched.lower() in stems_set:
            counts["fixed"] += 1
            if matched == display:
                return f"[[{matched}]]"
            return f"[[{matched}|{display}]]"

        # No match — strip to plain text
        counts["stripped"] += 1
        return display

    new_content = WIKILINK_RE.sub(replacer, content)
    if apply and new_content != content:
        page.write_text(new_content, encoding="utf-8")
    return counts


def link_orphan_sources(vault: Vault, *, apply: bool) -> int:
    """Add a ``## All Sources`` section to ``overview.md``.

    Eliminates orphan sources (which by design have no inbound links).
    Returns the number of sources linked.
    """
    if not vault.overview.exists():
        return 0
    if not vault.sources.exists():
        return 0

    sources = sorted(vault.sources.glob("*.md"))
    if not sources:
        return 0

    content = vault.overview.read_text(encoding="utf-8")

    lines = ["## All Sources", ""]
    for s in sources:
        display = s.stem
        try:
            post = frontmatter.load(str(s))
            title = post.metadata.get("title", "")
            if title and isinstance(title, str) and not has_bracket_unsafe_chars(title):
                display = title.strip()
        except Exception:
            pass

        if display == s.stem:
            lines.append(f"- [[{s.stem}]]")
        else:
            lines.append(f"- [[{s.stem}|{display}]]")

    new_section = "\n".join(lines) + "\n"

    if "## All Sources" in content:
        content = re.sub(r"## All Sources\n[\s\S]*?(?=\n## |\Z)", new_section, content)
    else:
        content = content.rstrip() + "\n\n" + new_section

    if apply:
        vault.overview.write_text(content, encoding="utf-8")

    return len(sources)


def fix_vault(vault: Vault, *, apply: bool = False) -> dict[str, int]:
    """Fix all wikilinks in the vault.

    Returns totals across all files: ``{fixed, stripped, kept, sources_linked}``.
    """
    pages = vault.all_pages()
    index = build_index(vault.wiki)
    all_stems = list(set(index.values()))
    stems_set = {p.stem.lower() for p in pages}

    totals: dict[str, int] = defaultdict(int)

    for page in pages:
        counts = fix_page(page, stems_set, index, all_stems, apply=apply)
        for k, v in counts.items():
            totals[k] += v

    totals["sources_linked"] = link_orphan_sources(vault, apply=apply)
    return dict(totals)
