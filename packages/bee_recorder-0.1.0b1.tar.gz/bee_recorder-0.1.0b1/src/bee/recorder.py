"""Captura áudio do sistema via ffmpeg + PulseAudio.

Grava TODOS os sinks do sistema simultaneamente para garantir que o áudio
da reunião seja capturado independente de qual saída está em uso
(speakers, headphones, AirPods, HDMI, etc).
"""

import json
import os
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

from bee.config import RECORDINGS_DIR, SAMPLE_RATE, ensure_dirs


def _list_all_sinks() -> list[dict]:
    """Lista todos os sinks do PulseAudio com nome e descrição."""
    try:
        result = subprocess.run(
            ["pactl", "list", "short", "sinks"],
            capture_output=True, text=True, check=True,
        )
        sinks = []
        for line in result.stdout.strip().splitlines():
            parts = line.split("\t")
            if len(parts) >= 2:
                sinks.append({"index": parts[0], "name": parts[1]})
        return sinks
    except subprocess.CalledProcessError:
        return []


def _find_mic_source() -> str | None:
    try:
        result = subprocess.run(
            ["pactl", "get-default-source"],
            capture_output=True, text=True, check=True,
        )
        source = result.stdout.strip()
        if ".monitor" not in source:
            return source
    except subprocess.CalledProcessError:
        pass
    return None


def _start_capture(device: str, output_path: Path, log_path: Path) -> int:
    with open(log_path, "w") as log_file:
        proc = subprocess.Popen(
            [
                "ffmpeg", "-y",
                "-f", "pulse",
                "-i", device,
                "-ar", str(SAMPLE_RATE),
                "-ac", "1",
                str(output_path),
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=log_file,
            start_new_session=True,
        )
    return proc.pid


def _get_max_volume(audio_path: Path) -> float:
    """Retorna o volume máximo em dB de um arquivo de áudio."""
    result = subprocess.run(
        ["ffmpeg", "-i", str(audio_path), "-af", "volumedetect", "-f", "null", "/dev/null"],
        capture_output=True, text=True,
    )
    for line in result.stderr.splitlines():
        if "max_volume:" in line:
            try:
                return float(line.split("max_volume:")[1].strip().split()[0])
            except (ValueError, IndexError):
                pass
    return -91.0


_sink_watchers: dict[str, threading.Event] = {}
_live_transcribers: dict[str, threading.Event] = {}

LIVE_TRANSCRIPT_FILE = "live_transcript.json"


def _get_audio_duration(path: Path) -> float:
    try:
        result = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(path)],
            capture_output=True, text=True, timeout=10,
        )
        return float(result.stdout.strip())
    except (ValueError, subprocess.TimeoutExpired, subprocess.CalledProcessError):
        return 0.0


def _extract_audio_segment(src: Path, dst: Path, start: float, duration: float) -> bool:
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-ss", str(start), "-t", str(duration),
             "-i", str(src), "-ar", "16000", "-ac", "1", str(dst)],
            capture_output=True, timeout=60,
        )
        return dst.exists() and dst.stat().st_size > 1000
    except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
        return False


def _pick_largest_system_wav(rec_dir: Path, system_captures: list) -> Path | None:
    best_file, best_size = None, 0
    for cap in system_captures:
        f = rec_dir / f"system_{cap.get('index', 0)}.wav"
        if f.exists() and f.stat().st_size > best_size:
            best_size = f.stat().st_size
            best_file = f
    return best_file


def _load_live_transcript(rec_dir: Path) -> dict:
    path = rec_dir / LIVE_TRANSCRIPT_FILE
    if not path.exists():
        return {"segments": [], "mic_offset": 0.0, "system_offset": 0.0, "system_source": None}
    with open(path) as f:
        return json.load(f)


def _save_live_transcript(rec_dir: Path, data: dict):
    tmp = rec_dir / (LIVE_TRANSCRIPT_FILE + ".tmp")
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    tmp.replace(rec_dir / LIVE_TRANSCRIPT_FILE)


def _live_transcriber_loop(rec_dir: Path, stop_event: threading.Event):
    from bee.config import get_config
    chunk_duration = get_config().chunk_duration_seconds
    buffer = 10.0
    min_chunk = 60.0

    stop_event.wait(chunk_duration)

    while not stop_event.is_set():
        try:
            metadata = _read_metadata(rec_dir)
            if not metadata or metadata.get("status") != "recording":
                break

            live = _load_live_transcript(rec_dir)
            system_captures = metadata.get("system_captures", [])
            changed = False

            from bee.transcriber import transcribe

            mic_wav = rec_dir / "mic.wav"
            if mic_wav.exists():
                mic_offset = live.get("mic_offset", 0.0)
                available = _get_audio_duration(mic_wav) - mic_offset - buffer
                if available >= min_chunk:
                    tmp = rec_dir / "_chunk_mic.wav"
                    if _extract_audio_segment(mic_wav, tmp, mic_offset, available):
                        for s in transcribe(tmp):
                            live["segments"].append({
                                "start": s.start + mic_offset,
                                "end": s.end + mic_offset,
                                "text": s.text,
                                "source": "mic",
                            })
                        live["mic_offset"] = mic_offset + available
                        changed = True
                    tmp.unlink(missing_ok=True)

            sys_wav = _pick_largest_system_wav(rec_dir, system_captures)
            if sys_wav:
                sys_offset = live.get("system_offset", 0.0)
                available = _get_audio_duration(sys_wav) - sys_offset - buffer
                if available >= min_chunk:
                    tmp = rec_dir / "_chunk_sys.wav"
                    if _extract_audio_segment(sys_wav, tmp, sys_offset, available):
                        for s in transcribe(tmp):
                            live["segments"].append({
                                "start": s.start + sys_offset,
                                "end": s.end + sys_offset,
                                "text": s.text,
                                "source": "system",
                            })
                        live["system_offset"] = sys_offset + available
                        live["system_source"] = sys_wav.name
                        changed = True
                    tmp.unlink(missing_ok=True)

            if changed:
                _save_live_transcript(rec_dir, live)

        except Exception:
            pass

        stop_event.wait(chunk_duration)


def _sink_watcher_loop(rec_dir: Path, stop_event: threading.Event):
    """Monitora novos sinks (ex: AirPods conectando) e inicia captura automaticamente."""
    known_sinks: set[str] = {s["name"] for s in _list_all_sinks()}

    while not stop_event.is_set():
        stop_event.wait(5)
        if stop_event.is_set():
            break

        current_sinks = _list_all_sinks()
        current_names = {s["name"] for s in current_sinks}
        new_sinks = current_names - known_sinks

        if new_sinks:
            metadata = _read_metadata(rec_dir)
            if not metadata or metadata.get("status") != "recording":
                break

            system_captures = metadata.get("system_captures", [])
            next_idx = max((c.get("index", 0) for c in system_captures), default=-1) + 1

            for sink_name in new_sinks:
                monitor = f"{sink_name}.monitor"
                pid = _start_capture(
                    monitor,
                    rec_dir / f"system_{next_idx}.wav",
                    rec_dir / f"system_{next_idx}.log",
                )
                system_captures.append({
                    "sink": sink_name,
                    "monitor": monitor,
                    "pid": pid,
                    "index": next_idx,
                })
                next_idx += 1

            metadata["system_captures"] = system_captures
            _write_metadata(rec_dir, metadata)
            known_sinks = current_names


def start_recording(name: str | None = None, capture_mic: bool = True, monitor_override: str | None = None) -> dict:
    ensure_dirs()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    rec_id = name or timestamp
    rec_dir = RECORDINGS_DIR / rec_id
    rec_dir.mkdir(exist_ok=True)

    if monitor_override:
        system_captures = [{"sink": "override", "monitor": monitor_override, "index": 0}]
        pid = _start_capture(monitor_override, rec_dir / "system_0.wav", rec_dir / "system_0.log")
        system_captures[0]["pid"] = pid
    else:
        sinks = _list_all_sinks()
        system_captures = []
        for i, sink in enumerate(sinks):
            monitor = f"{sink['name']}.monitor"
            pid = _start_capture(monitor, rec_dir / f"system_{i}.wav", rec_dir / f"system_{i}.log")
            system_captures.append({
                "sink": sink["name"],
                "monitor": monitor,
                "pid": pid,
                "index": i,
            })

    mic_pid = None
    mic_source = _find_mic_source() if capture_mic else None
    if mic_source:
        mic_pid = _start_capture(mic_source, rec_dir / "mic.wav", rec_dir / "mic.log")

    time.sleep(0.5)

    any_alive = any(_pid_alive(cap["pid"]) for cap in system_captures)
    if not any_alive:
        logs = []
        for cap in system_captures:
            log_file = rec_dir / f"system_{cap.get('index', 0)}.log"
            if log_file.exists():
                logs.append(log_file.read_text())
        raise RuntimeError(f"ffmpeg falhou ao iniciar captura de áudio: {'; '.join(logs)}")

    metadata = {
        "id": rec_id,
        "started_at": datetime.now().isoformat(),
        "system_captures": system_captures,
        "mic_source": mic_source,
        "mic_pid": mic_pid,
        "status": "recording",
    }
    _write_metadata(rec_dir, metadata)

    if not monitor_override:
        stop_event = threading.Event()
        _sink_watchers[rec_id] = stop_event
        threading.Thread(target=_sink_watcher_loop, args=(rec_dir, stop_event), daemon=True).start()

    live_stop = threading.Event()
    _live_transcribers[rec_id] = live_stop
    threading.Thread(target=_live_transcriber_loop, args=(rec_dir, live_stop), daemon=True).start()

    return metadata


def stop_recording(rec_id: str) -> dict:
    rec_dir = RECORDINGS_DIR / rec_id
    metadata = _read_metadata(rec_dir)

    stop_event = _sink_watchers.pop(rec_id, None)
    if stop_event:
        stop_event.set()

    live_stop = _live_transcribers.pop(rec_id, None)
    if live_stop:
        live_stop.set()

    metadata = _read_metadata(rec_dir)

    all_pids = []

    system_captures = metadata.get("system_captures", [])
    if system_captures:
        for cap in system_captures:
            all_pids.append(cap["pid"])
    else:
        pid = metadata.get("system_pid")
        if pid:
            all_pids.append(pid)

    mic_pid = metadata.get("mic_pid")
    if mic_pid:
        all_pids.append(mic_pid)

    for pid in all_pids:
        try:
            os.kill(pid, 2)
        except ProcessLookupError:
            pass

    time.sleep(1.5)

    for pid in all_pids:
        if _pid_alive(pid):
            try:
                os.kill(pid, 9)
            except ProcessLookupError:
                pass

    metadata["stopped_at"] = datetime.now().isoformat()
    metadata["status"] = "stopped"

    system_wav = rec_dir / "system.wav"
    mic_wav = rec_dir / "mic.wav"

    if system_captures:
        best_file = None
        best_volume = -100.0
        best_sink = None

        for cap in system_captures:
            idx = cap.get("index", 0)
            f = rec_dir / f"system_{idx}.wav"
            if not f.exists() or f.stat().st_size < 1000:
                continue
            vol = _get_max_volume(f)
            if vol > best_volume:
                best_volume = vol
                best_file = f
                best_sink = cap.get("sink", "?")

        if best_file and best_volume > -70:
            metadata["best_system_source"] = best_file.name
            shutil.move(str(best_file), str(system_wav))
            metadata["monitor_source"] = f"{best_sink}.monitor"
        else:
            metadata["monitor_source"] = "(todos silenciosos)"

        for cap in system_captures:
            idx = cap.get("index", 0)
            for ext in ("wav", "log"):
                f = rec_dir / f"system_{idx}.{ext}"
                if f.exists() and f != system_wav:
                    f.unlink()
    else:
        if metadata.get("system_pid"):
            metadata["monitor_source"] = metadata.get("monitor_source", "?")

    has_system = system_wav.exists() and system_wav.stat().st_size > 1000
    has_mic = mic_wav.exists() and mic_wav.stat().st_size > 1000

    if has_mic:
        metadata["audio_file"] = "mic.wav"
    elif has_system:
        metadata["audio_file"] = "system.wav"

    _write_metadata(rec_dir, metadata)
    return metadata


def get_active_recording() -> dict | None:
    if not RECORDINGS_DIR.exists():
        return None
    for rec_dir in sorted(RECORDINGS_DIR.iterdir(), reverse=True):
        if not rec_dir.is_dir():
            continue
        meta = _read_metadata(rec_dir)
        if meta and meta.get("status") == "recording":
            system_captures = meta.get("system_captures", [])
            if system_captures:
                any_alive = any(_pid_alive(cap["pid"]) for cap in system_captures)
            else:
                any_alive = _pid_alive(meta.get("system_pid", 0))

            if any_alive:
                return meta
            meta["status"] = "orphaned"
            _write_metadata(rec_dir, meta)
    return None


def list_recordings() -> list[dict]:
    if not RECORDINGS_DIR.exists():
        return []
    recordings = []
    for rec_dir in sorted(RECORDINGS_DIR.iterdir()):
        if not rec_dir.is_dir():
            continue
        meta = _read_metadata(rec_dir)
        if meta:
            recordings.append(meta)
    return recordings


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _write_metadata(rec_dir: Path, metadata: dict):
    with open(rec_dir / "metadata.json", "w") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)


def _read_metadata(rec_dir: Path) -> dict | None:
    meta_file = rec_dir / "metadata.json"
    if not meta_file.exists():
        return None
    with open(meta_file) as f:
        return json.load(f)
