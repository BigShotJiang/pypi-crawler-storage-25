"""Diagnostic checks for Bee."""

import shutil
import subprocess
from pathlib import Path

from rich.console import Console

from bee.config import CONFIG_FILE, get_config, MODELS_DIR
from bee.models import get_model_status

console = Console()


def run_doctor() -> bool:
    console.print("\n[bold]Bee Doctor[/bold]\n")
    results = []

    results.append(_check_ffmpeg())
    results.append(_check_pulseaudio())
    results.append(_check_audio_inputs())
    results.append(_check_audio_outputs())
    results.append(_check_whisper_model())
    results.append(_check_diarization_model())
    results.append(_check_config())
    results.append(_check_data_dir())

    passed = sum(results)
    total = len(results)
    console.print(f"\n[bold]{passed}/{total} checks passed.[/bold]")

    if passed == total:
        console.print("[green]Everything looks good![/green]\n")
    else:
        console.print("[yellow]Some issues found. See above for fixes.[/yellow]\n")

    return all(results)


def _ok(msg: str):
    console.print(f"  [green]OK[/green]  {msg}")


def _fail(msg: str, fix: str | None = None):
    console.print(f"  [red]FAIL[/red]  {msg}")
    if fix:
        console.print(f"         [dim]{fix}[/dim]")


def _check_ffmpeg() -> bool:
    path = shutil.which("ffmpeg")
    if not path:
        _fail("ffmpeg not found", "sudo apt install ffmpeg")
        return False

    try:
        result = subprocess.run(
            ["ffmpeg", "-version"], capture_output=True, text=True, timeout=5
        )
        version = result.stdout.split("\n")[0] if result.stdout else "unknown"
        _ok(f"ffmpeg — {version}")
        return True
    except Exception:
        _fail("ffmpeg found but failed to run")
        return False


def _check_pulseaudio() -> bool:
    if not shutil.which("pactl"):
        _fail("pactl not found", "sudo apt install pulseaudio-utils")
        return False

    try:
        result = subprocess.run(
            ["pactl", "info"], capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            _fail("PulseAudio/PipeWire not running", "systemctl --user start pipewire-pulse")
            return False

        server = "PulseAudio/PipeWire"
        for line in result.stdout.splitlines():
            if "Server Name:" in line:
                server = line.split(":", 1)[1].strip()
                break
        _ok(f"Audio server — {server}")
        return True
    except Exception:
        _fail("Could not check PulseAudio")
        return False


def _check_audio_inputs() -> bool:
    try:
        result = subprocess.run(
            ["pactl", "list", "short", "sources"],
            capture_output=True, text=True, timeout=5,
        )
        sources = [
            line.split("\t")[1]
            for line in result.stdout.strip().splitlines()
            if "\t" in line and ".monitor" not in line.split("\t")[1]
        ]
        if sources:
            _ok(f"Audio inputs — {len(sources)} device(s)")
            return True
        _fail("No audio input devices found", "Check microphone connection")
        return False
    except Exception:
        _fail("Could not list audio inputs")
        return False


def _check_audio_outputs() -> bool:
    try:
        result = subprocess.run(
            ["pactl", "list", "short", "sinks"],
            capture_output=True, text=True, timeout=5,
        )
        sinks = result.stdout.strip().splitlines()
        if sinks:
            _ok(f"Audio outputs — {len(sinks)} sink(s)")
            return True
        _fail("No audio output devices found")
        return False
    except Exception:
        _fail("Could not list audio outputs")
        return False


def _check_whisper_model() -> bool:
    cfg = get_config()
    model = cfg.whisper_model
    status = get_model_status(model)
    if status == "installed":
        _ok(f"Whisper model '{model}' downloaded")
        return True
    _fail(
        f"Whisper model '{model}' not downloaded",
        f"bee models download {model}",
    )
    return False


def _check_diarization_model() -> bool:
    status = get_model_status("speechbrain/ecapa-tdnn")
    if status == "installed":
        _ok("Diarization model (ECAPA-TDNN) downloaded")
        return True
    _fail(
        "Diarization model not downloaded",
        "bee models download speechbrain/ecapa-tdnn",
    )
    return False


def _check_config() -> bool:
    if CONFIG_FILE.exists():
        _ok(f"Config file — {CONFIG_FILE}")
        return True
    _fail(f"No config file at {CONFIG_FILE}", "bee setup")
    return False


def _check_data_dir() -> bool:
    cfg = get_config()
    data_dir = cfg.recordings_dir.parent
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        test_file = data_dir / ".write_test"
        test_file.write_text("ok")
        test_file.unlink()
        _ok(f"Data directory writable — {data_dir}")
        return True
    except OSError as e:
        _fail(f"Data directory not writable: {data_dir}", str(e))
        return False
