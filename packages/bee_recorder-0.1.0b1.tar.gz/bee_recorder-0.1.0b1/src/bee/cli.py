"""CLI principal do Bee."""

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


@click.group()
def main():
    """Bee - Gravador de reuniões com transcrição e identificação de participantes."""
    pass


@main.command()
@click.option("--name", "-n", default=None, help="Nome da gravação (default: timestamp)")
@click.option("--no-mic", is_flag=True, help="Não capturar microfone (só áudio do sistema)")
@click.option("--monitor", "-m", default=None, help="PulseAudio source específico para captura (override)")
def start(name: str | None, no_mic: bool, monitor: str | None):
    """Inicia a gravação de uma reunião."""
    from bee.recorder import get_active_recording, start_recording

    active = get_active_recording()
    if active:
        console.print(f"[red]Já existe uma gravação ativa:[/red] {active['id']}")
        console.print("Use [bold]bee stop[/bold] para parar a gravação atual.")
        sys.exit(1)

    metadata = start_recording(name=name, capture_mic=not no_mic, monitor_override=monitor)

    captures = metadata.get("system_captures", [])
    if len(captures) > 1:
        monitor_info = f"Capturando {len(captures)} saídas de áudio simultaneamente"
    elif captures:
        monitor_info = f"Monitor: {captures[0].get('monitor', '?')}"
    else:
        monitor_info = f"Monitor: {metadata.get('monitor_source', '?')}"

    console.print(Panel(
        f"[green bold]Gravação iniciada![/green bold]\n\n"
        f"ID: [cyan]{metadata['id']}[/cyan]\n"
        f"{monitor_info}\n"
        f"Microfone: {metadata['mic_source'] or 'desativado'}\n"
        f"Watcher: monitorando novos dispositivos (ex: AirPods)\n\n"
        f"Use [bold]bee stop[/bold] para parar e processar.",
        title="Bee",
        border_style="green",
    ))


@main.command()
@click.option("--no-process", is_flag=True, help="Apenas parar, sem transcrever")
@click.option("--no-diarize", is_flag=True, help="Pular diarização (não identifica speakers)")
@click.option("--no-identify", is_flag=True, help="Não perguntar quem são os participantes")
def stop(no_process: bool, no_diarize: bool, no_identify: bool):
    """Para a gravação e processa (transcrição + identificação de participantes)."""
    from bee.recorder import get_active_recording, stop_recording

    active = get_active_recording()
    if not active:
        console.print("[yellow]Nenhuma gravação ativa encontrada.[/yellow]")
        sys.exit(1)

    rec_id = active["id"]
    console.print(f"Parando gravação [cyan]{rec_id}[/cyan]...")
    stop_recording(rec_id)
    console.print("[green]Gravação parada.[/green]\n")

    if no_process:
        console.print(f"Use [bold]bee process {rec_id}[/bold] para processar depois.")
        return

    from bee.pipeline import process_recording
    result = process_recording(rec_id, skip_diarization=no_diarize)
    _print_result(rec_id, result)

    if not no_identify and not no_diarize:
        _interactive_identify(rec_id)


@main.command()
@click.argument("rec_id")
@click.option("--no-diarize", is_flag=True, help="Pular diarização")
@click.option("--no-identify", is_flag=True, help="Não perguntar quem são os participantes")
def process(rec_id: str, no_diarize: bool, no_identify: bool):
    """Processa uma gravação existente (transcrição + identificação)."""
    from bee.pipeline import process_recording

    console.print(f"Processando gravação [cyan]{rec_id}[/cyan]...\n")
    result = process_recording(rec_id, skip_diarization=no_diarize)
    _print_result(rec_id, result)

    if not no_identify and not no_diarize:
        _interactive_identify(rec_id)


@main.command()
@click.argument("transcript_path", type=click.Path(exists=True, path_type=Path))
def summarize(transcript_path: Path):
    """Gera resumo de uma transcrição existente via Claude."""
    from bee.pipeline import summarize_transcript

    console.print(f"Gerando resumo de [cyan]{transcript_path.name}[/cyan]...\n")
    summary = summarize_transcript(transcript_path)

    from rich.markdown import Markdown
    console.print(Panel(Markdown(summary), title="Resumo", border_style="yellow"))

    summary_file = transcript_path.with_name(transcript_path.stem + "_resumo.md")
    console.print(f"\nSalvo em [cyan]{summary_file}[/cyan]")


@main.command(name="list")
def list_recordings():
    """Lista todas as gravações."""
    from bee.recorder import list_recordings as _list_recordings

    recordings = _list_recordings()
    if not recordings:
        console.print("[yellow]Nenhuma gravação encontrada.[/yellow]")
        return

    table = Table(title="Gravações")
    table.add_column("ID", style="cyan")
    table.add_column("Início", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Áudio")

    for rec in recordings:
        table.add_row(
            rec["id"],
            rec.get("started_at", "?")[:19].replace("T", " "),
            rec.get("status", "?"),
            rec.get("audio_file", "-"),
        )

    console.print(table)


@main.command()
@click.argument("rec_id")
@click.option("--transcript", "-t", is_flag=True, help="Mostrar transcrição completa")
@click.option("--summary", "-s", is_flag=True, help="Mostrar resumo")
def show(rec_id: str, transcript: bool, summary: bool):
    """Mostra detalhes de uma gravação."""
    from bee.config import RECORDINGS_DIR, TRANSCRIPTS_DIR

    rec_dir = RECORDINGS_DIR / rec_id
    if not rec_dir.exists():
        console.print(f"[red]Gravação não encontrada:[/red] {rec_id}")
        sys.exit(1)

    import json
    meta_file = rec_dir / "metadata.json"
    if meta_file.exists():
        metadata = json.loads(meta_file.read_text())
        console.print(Panel(
            "\n".join(f"[bold]{k}:[/bold] {v}" for k, v in metadata.items()),
            title=f"Gravação: {rec_id}",
            border_style="cyan",
        ))

    show_all = not transcript and not summary

    if transcript or show_all:
        transcript_file = TRANSCRIPTS_DIR / f"{rec_id}.md"
        if transcript_file.exists():
            from rich.markdown import Markdown
            console.print(Panel(
                Markdown(transcript_file.read_text(encoding="utf-8")),
                title="Transcrição",
                border_style="green",
            ))

    if summary or show_all:
        summary_file = TRANSCRIPTS_DIR / f"{rec_id}_resumo.md"
        if summary_file.exists():
            from rich.markdown import Markdown
            console.print(Panel(
                Markdown(summary_file.read_text(encoding="utf-8")),
                title="Resumo",
                border_style="yellow",
            ))


@main.command()
@click.argument("rec_id")
@click.argument("mappings", nargs=-1, required=True)
def label(rec_id: str, mappings: tuple[str, ...]):
    """Identifica os speakers com nomes reais.

    Uso: bee label <rec_id> SPEAKER_00=Paulo SPEAKER_01="João (Empresa)"

    Use 'bee speakers <rec_id>' para ver quem é quem antes de rotular.
    """
    from bee.pipeline import label_speakers

    labels = {}
    for m in mappings:
        if "=" not in m:
            console.print(f"[red]Formato inválido:[/red] {m} (use SPEAKER_XX=Nome)")
            sys.exit(1)
        key, value = m.split("=", 1)
        labels[key] = value

    console.print(f"Renomeando speakers em [cyan]{rec_id}[/cyan]...")
    for old, new in labels.items():
        console.print(f"  {old} -> [green]{new}[/green]")

    result = label_speakers(rec_id, labels)

    console.print(f"\n[green]Transcrição atualizada.[/green]")
    console.print(f"Speakers: {', '.join(result['speakers'])}")


@main.command()
@click.argument("rec_id")
def speakers(rec_id: str):
    """Mostra preview de cada speaker para facilitar identificação."""
    from bee.pipeline import get_speaker_previews

    previews = get_speaker_previews(rec_id)
    if not previews:
        console.print(f"[yellow]Nenhuma transcrição encontrada para {rec_id}.[/yellow]")
        sys.exit(1)

    console.print(f"\n[bold]Participantes detectados: {len(previews)}[/bold]\n")

    table = Table(title=f"Speakers - {rec_id}", show_lines=True)
    table.add_column("Speaker", style="cyan", width=14)
    table.add_column("Palavras", style="yellow", justify="right", width=8)
    table.add_column("Tempo", style="yellow", justify="right", width=8)
    table.add_column("Citações representativas", style="white")

    for speaker, info in previews.items():
        duration_str = f"{info['duration'] / 60:.1f} min"
        quotes = "\n".join(f'"{q}"' for q in info["quotes"][:3])
        table.add_row(speaker, str(info["word_count"]), duration_str, quotes or "(sem falas substanciais)")

    console.print(table)
    console.print(f"\nPara rotular: [bold]bee label {rec_id} SPEAKER_00=Nome SPEAKER_01=\"Nome (Empresa)\"[/bold]")


@main.command()
def watch():
    """Monitora a pasta de transcrições e gera resumo automaticamente."""
    from bee.watcher import start_watcher
    start_watcher()


@main.command()
def setup():
    """Run first-time setup wizard."""
    from bee.setup_wizard import run_setup
    run_setup()


@main.command()
def doctor():
    """Check system health and diagnose issues."""
    from bee.doctor import run_doctor
    ok = run_doctor()
    if not ok:
        sys.exit(1)


@main.group()
def models():
    """Manage AI models (download, list, info)."""
    pass


@models.command(name="list")
def models_list():
    """List available and installed models."""
    from bee.models import list_models

    all_models = list_models()
    table = Table(title="Models")
    table.add_column("Model", style="cyan")
    table.add_column("Type")
    table.add_column("Size", justify="right")
    table.add_column("RAM", justify="right")
    table.add_column("Quality")
    table.add_column("Status")

    for name, info in all_models.items():
        status = "[green]installed[/green]" if info["status"] == "installed" else "[dim]available[/dim]"
        size = f"{info.get('size_mb', '?')} MB"
        ram = f"{info.get('ram_mb', '?')} MB"
        quality = info.get("quality", info.get("description", ""))
        table.add_row(name, info["type"], size, ram, quality, status)

    console.print(table)


@models.command(name="download")
@click.argument("model_name")
def models_download(model_name: str):
    """Download a specific model."""
    from bee.models import download_model, get_model_status, WHISPER_MODELS, DIARIZATION_MODELS

    known = {**WHISPER_MODELS, **DIARIZATION_MODELS}
    if model_name not in known:
        console.print(f"[red]Unknown model:[/red] {model_name}")
        console.print(f"Available: {', '.join(known.keys())}")
        sys.exit(1)

    status = get_model_status(model_name)
    if status == "installed":
        console.print(f"[green]Model '{model_name}' is already installed.[/green]")
        return

    console.print(f"Downloading [cyan]{model_name}[/cyan]...")
    from rich.progress import Progress, SpinnerColumn, TextColumn
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        task = progress.add_task(f"Downloading {model_name}...", total=None)
        try:
            path = download_model(model_name)
            progress.update(task, description=f"[green]{model_name} ready[/green]")
            console.print(f"\nSaved to: [dim]{path}[/dim]")
        except Exception as e:
            progress.update(task, description=f"[red]Failed[/red]")
            console.print(f"[red]Error:[/red] {e}")
            sys.exit(1)


@models.command(name="usage")
def models_usage():
    """Show disk usage of downloaded models."""
    from bee.models import get_disk_usage

    usage = get_disk_usage()
    if not usage:
        console.print("[yellow]No models downloaded yet.[/yellow]")
        return

    table = Table(title="Model Disk Usage")
    table.add_column("Model", style="cyan")
    table.add_column("Size", justify="right")

    total = 0
    for name, size_bytes in usage.items():
        size_mb = size_bytes / (1024 * 1024)
        total += size_bytes
        table.add_row(name, f"{size_mb:.0f} MB")

    table.add_row("[bold]Total[/bold]", f"[bold]{total / (1024 * 1024):.0f} MB[/bold]")
    console.print(table)


def _print_result(rec_id: str, result: dict):
    json_path = result.get("json_path", "")
    md_path = result.get("md_path", "")

    console.print(Panel(
        f"[green bold]Processamento completo![/green bold]\n\n"
        f"Segmentos: {result['segments']}\n"
        f"Participantes detectados: {result['speakers']}\n\n"
        f"JSON (LLM): [cyan]{json_path}[/cyan]\n"
        f"Markdown:    [cyan]{md_path}[/cyan]",
        title="Bee",
        border_style="green",
    ))


def _interactive_identify(rec_id: str):
    """Mostra speakers com contexto e pergunta quem é quem."""
    from bee.pipeline import get_speaker_previews

    previews = get_speaker_previews(rec_id)
    if not previews:
        return

    console.print(f"\n[bold]Participantes detectados: {len(previews)}[/bold]\n")

    for speaker, info in previews.items():
        duration_min = info["duration"] / 60
        console.print(
            f"  [cyan bold]{speaker}[/cyan bold] — "
            f"{info['word_count']} palavras, {duration_min:.1f} min falando"
        )
        for quote in info["quotes"][:3]:
            console.print(f"    [dim]\"{quote}\"[/dim]")
        console.print()

    if not sys.stdin.isatty():
        console.print(f"Para identificar: [bold]bee label {rec_id} SPEAKER_00=Nome ...[/bold]")
        return

    try:
        if not click.confirm("Deseja identificar os participantes agora?", default=True):
            console.print(f"\nPara identificar depois: [bold]bee label {rec_id} SPEAKER_00=Nome[/bold]")
            return
    except (click.Abort, EOFError):
        console.print(f"\nPara identificar depois: [bold]bee label {rec_id} SPEAKER_00=Nome[/bold]")
        return

    console.print()
    labels = {}
    for speaker in previews:
        try:
            name = click.prompt(f"  {speaker} → Nome (enter para pular)", default="", show_default=False)
            if not name:
                continue
            company = click.prompt(f"  {speaker} → Empresa (enter para pular)", default="", show_default=False)
            display = f"{name} ({company})" if company else name
            labels[speaker] = display
        except (click.Abort, EOFError):
            break

    if labels:
        from bee.pipeline import label_speakers
        result = label_speakers(rec_id, labels)
        console.print(f"\n[green]Participantes identificados:[/green] {', '.join(result['speakers'])}")
        console.print(f"Transcrição atualizada em [cyan]{TRANSCRIPTS_DIR / f'{rec_id}.md'}[/cyan]")
    else:
        console.print(f"\nPara identificar depois: [bold]bee label {rec_id} SPEAKER_00=Nome[/bold]")


try:
    from bee.config import TRANSCRIPTS_DIR as TRANSCRIPTS_DIR
except ImportError:
    pass
