"""Optional summary generation via Claude Code CLI."""

import shutil
import subprocess
from pathlib import Path


SUMMARY_PROMPT = """Analise a transcrição desta reunião e gere um resumo estruturado em português.

O resumo deve conter:

## Participantes
Lista dos participantes identificados na reunião (use os labels de speaker se nomes reais não forem identificáveis).

## Resumo Geral
Um parágrafo resumindo o objetivo e resultado geral da reunião.

## Pontos Principais
Lista dos tópicos mais importantes discutidos, com detalhes relevantes.

## Decisões Tomadas
Lista de decisões que foram tomadas durante a reunião.

## Action Items
Lista de tarefas/ações que foram atribuídas, com responsável quando identificável.

## Próximos Passos
O que foi definido como próximos passos.

---

TRANSCRIÇÃO:

"""


def is_available() -> bool:
    return shutil.which("claude") is not None


def summarize(transcript_text: str, transcript_path: Path) -> str:
    if not is_available():
        raise RuntimeError("Claude CLI não encontrado. Instale o Claude Code CLI para gerar resumos.")

    prompt = SUMMARY_PROMPT + transcript_text

    result = subprocess.run(
        ["claude", "-p", prompt, "--output-format", "text"],
        capture_output=True,
        text=True,
        timeout=300,
    )

    if result.returncode != 0:
        raise RuntimeError(f"Claude CLI falhou: {result.stderr}")

    return result.stdout.strip()
