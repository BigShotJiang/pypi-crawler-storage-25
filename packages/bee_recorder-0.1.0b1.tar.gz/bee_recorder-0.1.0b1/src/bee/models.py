"""Model registry and download manager for Bee."""

import os
import shutil
from pathlib import Path

from bee.config import MODELS_DIR, get_config

WHISPER_MODELS = {
    "tiny": {"size_mb": 75, "ram_mb": 400, "speed": "~10x realtime", "quality": "Low"},
    "base": {"size_mb": 142, "ram_mb": 500, "speed": "~7x realtime", "quality": "Medium-Low"},
    "small": {"size_mb": 466, "ram_mb": 800, "speed": "~4x realtime", "quality": "Medium"},
    "medium": {"size_mb": 1500, "ram_mb": 1500, "speed": "~2x realtime", "quality": "High"},
    "large-v3": {"size_mb": 3000, "ram_mb": 3200, "speed": "~1x realtime", "quality": "Best"},
}

DIARIZATION_MODELS = {
    "speechbrain/ecapa-tdnn": {
        "size_mb": 80,
        "ram_mb": 500,
        "description": "Speaker embeddings for diarization",
    },
}

_WHISPER_CT2_PREFIX = "models--Systran--faster-whisper-"
_HF_CACHE = Path.home() / ".cache" / "huggingface" / "hub"


def _whisper_hf_dir(model_name: str) -> Path:
    return _HF_CACHE / f"{_WHISPER_CT2_PREFIX}{model_name}"


def _speechbrain_cache_dir() -> Path:
    return MODELS_DIR / "speechbrain-ecapa"


def get_model_status(model_name: str) -> str:
    if model_name in WHISPER_MODELS:
        cache_dir = _whisper_hf_dir(model_name)
        if cache_dir.exists() and any(cache_dir.iterdir()):
            return "installed"
        return "available"

    if model_name in DIARIZATION_MODELS:
        d = _speechbrain_cache_dir()
        if d.exists() and (d / "embedding_model.ckpt").exists():
            return "installed"
        return "available"

    return "unknown"


def list_models() -> dict:
    result = {}
    for name, info in WHISPER_MODELS.items():
        result[name] = {**info, "type": "whisper", "status": get_model_status(name)}
    for name, info in DIARIZATION_MODELS.items():
        result[name] = {**info, "type": "diarization", "status": get_model_status(name)}
    return result


def download_model(model_name: str, progress_callback=None) -> Path:
    if model_name in WHISPER_MODELS:
        return _download_whisper_model(model_name)
    if model_name in DIARIZATION_MODELS:
        return _download_diarization_model(model_name)
    raise ValueError(f"Unknown model: {model_name}")


def _download_whisper_model(model_name: str) -> Path:
    from faster_whisper.utils import download_model

    model_path = download_model(f"Systran/faster-whisper-{model_name}")
    return Path(model_path)


def _download_diarization_model(model_name: str) -> Path:
    from speechbrain.inference.speaker import EncoderClassifier

    savedir = _speechbrain_cache_dir()
    savedir.mkdir(parents=True, exist_ok=True)
    EncoderClassifier.from_hparams(
        source="speechbrain/spkrec-ecapa-voxceleb",
        savedir=str(savedir),
        run_opts={"device": "cpu"},
    )
    return savedir


def get_recommended_model() -> str:
    ram_gb = _get_available_ram_gb()
    has_gpu = _has_cuda_gpu()

    if has_gpu:
        if ram_gb >= 16:
            return "large-v3"
        if ram_gb >= 8:
            return "medium"
        return "small"

    if ram_gb >= 24:
        return "medium"
    if ram_gb >= 12:
        return "small"
    if ram_gb >= 6:
        return "base"
    return "tiny"


def _has_cuda_gpu() -> bool:
    try:
        import torch
        return torch.cuda.is_available()
    except Exception:
        return False


def get_disk_usage() -> dict:
    usage = {}
    for name in WHISPER_MODELS:
        cache_dir = _whisper_hf_dir(name)
        if cache_dir.exists():
            size = sum(f.stat().st_size for f in cache_dir.rglob("*") if f.is_file())
            usage[name] = size
    sb_dir = _speechbrain_cache_dir()
    if sb_dir.exists():
        size = sum(f.stat().st_size for f in sb_dir.rglob("*") if f.is_file())
        usage["speechbrain/ecapa-tdnn"] = size
    return usage


def _get_available_ram_gb() -> float:
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) / (1024 * 1024)
    except (OSError, ValueError):
        pass
    total = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    return total / (1024 ** 3)
