"""Speaker diarization usando SpeechBrain ECAPA-TDNN (local, sem token HF)."""

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from bee.config import MODELS_DIR
from bee.transcriber import Segment

_encoder = None
_SPEECHBRAIN_DIR = MODELS_DIR / "speechbrain-ecapa"


@dataclass
class DiarizedSegment:
    start: float
    end: float
    speaker: str
    text: str


def _get_encoder():
    global _encoder
    if _encoder is None:
        import torch
        from speechbrain.inference.speaker import EncoderClassifier

        device = "cuda" if torch.cuda.is_available() else "cpu"
        _SPEECHBRAIN_DIR.mkdir(parents=True, exist_ok=True)
        _encoder = EncoderClassifier.from_hparams(
            source="speechbrain/spkrec-ecapa-voxceleb",
            savedir=str(_SPEECHBRAIN_DIR),
            run_opts={"device": device},
        )
    return _encoder


def diarize(
    audio_path: Path,
    num_speakers: int | None = None,
    window_seconds: float = 1.5,
    hop_seconds: float = 0.75,
) -> list[tuple[float, float, str]]:
    """Identifica quem falou em cada trecho do áudio.

    Pipeline: VAD por energia → embeddings ECAPA-TDNN → clustering aglomerativo.
    """
    import soundfile as sf
    import torch
    import torchaudio.functional as TF

    encoder = _get_encoder()

    data, fs = sf.read(str(audio_path), dtype="float32", always_2d=True)
    signal = torch.from_numpy(data.T)
    if fs != 16000:
        signal = TF.resample(signal, fs, 16000)
        fs = 16000
    if signal.shape[0] > 1:
        signal = signal.mean(dim=0, keepdim=True)

    duration = signal.shape[1] / fs
    if duration < window_seconds:
        return [(0.0, duration, "SPEAKER_00")]

    window = int(window_seconds * fs)
    hop = int(hop_seconds * fs)

    global_rms = signal.pow(2).mean().sqrt().item()
    speech_threshold = max(0.003, global_rms * 0.3)

    bounds: list[tuple[float, float]] = []
    embeddings: list[np.ndarray] = []
    for start in range(0, signal.shape[1] - window + 1, hop):
        chunk = signal[:, start : start + window]
        rms = chunk.pow(2).mean().sqrt().item()
        if rms < speech_threshold:
            continue
        with torch.no_grad():
            emb = encoder.encode_batch(chunk).squeeze().cpu().numpy()
        bounds.append((start / fs, (start + window) / fs))
        embeddings.append(emb)

    if not embeddings:
        return [(0.0, duration, "SPEAKER_00")]
    if len(embeddings) == 1:
        return [(bounds[0][0], bounds[0][1], "SPEAKER_00")]

    matrix = np.array(embeddings)
    matrix = matrix / (np.linalg.norm(matrix, axis=1, keepdims=True) + 1e-9)

    labels = _cluster(matrix, num_speakers)

    raw = [(bounds[i][0], bounds[i][1], int(labels[i])) for i in range(len(bounds))]
    merged = _merge_consecutive(raw)
    return _normalize_speaker_labels(merged)


def _cluster(embeddings: np.ndarray, num_speakers: int | None) -> np.ndarray:
    from sklearn.cluster import AgglomerativeClustering

    n = len(embeddings)

    if num_speakers is not None:
        if num_speakers <= 1:
            return np.zeros(n, dtype=int)
        return AgglomerativeClustering(
            n_clusters=min(num_speakers, n),
            metric="cosine",
            linkage="average",
        ).fit(embeddings).labels_

    if n < 4:
        return np.zeros(n, dtype=int)

    from sklearn.metrics import silhouette_score

    best_score = -1.0
    best_labels = np.zeros(n, dtype=int)
    max_k = min(6, n - 1)

    for k in range(2, max_k + 1):
        try:
            labels = AgglomerativeClustering(
                n_clusters=k,
                metric="cosine",
                linkage="average",
            ).fit(embeddings).labels_
            score = silhouette_score(embeddings, labels, metric="cosine")
            if score > best_score:
                best_score = score
                best_labels = labels
        except Exception:
            continue

    if best_score < 0.1:
        return np.zeros(n, dtype=int)
    return best_labels


def _merge_consecutive(
    segments: list[tuple[float, float, int]],
    gap_tolerance: float = 0.75,
) -> list[tuple[float, float, str]]:
    if not segments:
        return []
    result = []
    cur_start, cur_end, cur_label = segments[0]
    for start, end, label in segments[1:]:
        if label == cur_label and start <= cur_end + gap_tolerance:
            cur_end = max(cur_end, end)
        else:
            result.append((cur_start, cur_end, f"SPEAKER_{cur_label:02d}"))
            cur_start, cur_end, cur_label = start, end, label
    result.append((cur_start, cur_end, f"SPEAKER_{cur_label:02d}"))
    return result


def _normalize_speaker_labels(
    segments: list[tuple[float, float, str]],
) -> list[tuple[float, float, str]]:
    label_map: dict[str, str] = {}
    counter = 0
    for _, _, speaker in segments:
        if speaker not in label_map:
            label_map[speaker] = f"SPEAKER_{counter:02d}"
            counter += 1
    return [(start, end, label_map[speaker]) for start, end, speaker in segments]


def merge_transcription_with_diarization(
    transcript_segments: list[Segment],
    speaker_segments: list[tuple[float, float, str]],
) -> list[DiarizedSegment]:
    result = []
    for seg in transcript_segments:
        seg_mid = (seg.start + seg.end) / 2
        speaker = _find_speaker_at(seg_mid, speaker_segments)
        result.append(DiarizedSegment(
            start=seg.start,
            end=seg.end,
            speaker=speaker,
            text=seg.text,
        ))
    return result


def _find_speaker_at(
    timestamp: float,
    speaker_segments: list[tuple[float, float, str]],
) -> str:
    best_speaker = "SPEAKER_00"
    best_dist = float("inf")
    for start, end, speaker in speaker_segments:
        if start <= timestamp <= end:
            return speaker
        dist = min(abs(timestamp - start), abs(timestamp - end))
        if dist < best_dist:
            best_dist = dist
            best_speaker = speaker
    return best_speaker
