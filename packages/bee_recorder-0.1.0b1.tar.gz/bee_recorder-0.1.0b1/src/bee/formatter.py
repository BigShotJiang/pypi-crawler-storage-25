"""Transcript output formatting — JSON (LLM-optimized) and Markdown (human-readable)."""

import json
from datetime import datetime
from pathlib import Path

from bee.diarizer import DiarizedSegment


def format_json(segments: list[DiarizedSegment], rec_id: str, language: str | None = None) -> str:
    speakers = sorted(set(s.speaker for s in segments), key=lambda sp: next(
        i for i, s in enumerate(segments) if s.speaker == sp
    ))
    duration = segments[-1].end if segments else 0.0

    data = {
        "metadata": {
            "recording_id": rec_id,
            "duration_seconds": round(duration, 1),
            "language_detected": language,
            "speakers": speakers,
            "speaker_count": len(speakers),
            "segment_count": len(segments),
            "created_at": datetime.now().isoformat(timespec="seconds"),
        },
        "segments": [
            {
                "start": round(s.start, 2),
                "end": round(s.end, 2),
                "speaker": s.speaker,
                "text": s.text,
            }
            for s in segments
        ],
    }

    return json.dumps(data, indent=2, ensure_ascii=False)


def format_markdown(segments: list[DiarizedSegment], rec_id: str) -> str:
    speakers = sorted(set(s.speaker for s in segments), key=lambda sp: next(
        i for i, s in enumerate(segments) if s.speaker == sp
    ))
    duration = segments[-1].end if segments else 0.0

    date_part = rec_id[:8] if len(rec_id) >= 8 and rec_id[:8].isdigit() else rec_id
    if len(date_part) == 8:
        date_str = f"{date_part[:4]}-{date_part[4:6]}-{date_part[6:8]}"
        time_part = rec_id[9:15] if len(rec_id) >= 15 else ""
        if time_part:
            date_str += f" {time_part[:2]}:{time_part[2:4]}"
    else:
        date_str = rec_id

    duration_str = _format_duration(duration)
    speaker_list = ", ".join(speakers)

    lines = [
        f"# Meeting Transcript — {date_str}",
        "",
        f"**Duration:** {duration_str} | **Speakers:** {speaker_list}",
        "",
        "---",
        "",
    ]

    current_speaker = None
    for seg in segments:
        timestamp = _format_time(seg.start)
        if seg.speaker != current_speaker:
            current_speaker = seg.speaker
            if lines[-1] != "":
                lines.append("")
            lines.append(f"**[{timestamp}] {seg.speaker}:**")
        lines.append(seg.text)

    return "\n".join(lines).rstrip() + "\n"


def save_transcript(
    segments: list[DiarizedSegment],
    rec_id: str,
    output_dir: Path,
    language: str | None = None,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)

    json_path = output_dir / f"{rec_id}.json"
    json_path.write_text(format_json(segments, rec_id, language), encoding="utf-8")

    md_path = output_dir / f"{rec_id}.md"
    md_path.write_text(format_markdown(segments, rec_id), encoding="utf-8")

    return {
        "json_path": str(json_path),
        "md_path": str(md_path),
    }


def _format_time(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def _format_duration(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    if h > 0:
        return f"{h}h {m:02d}min"
    return f"{m}min"
