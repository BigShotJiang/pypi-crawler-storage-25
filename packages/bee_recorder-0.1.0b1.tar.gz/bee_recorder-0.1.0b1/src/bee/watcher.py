"""Monitora a pasta de transcrições e gera resumos automaticamente."""

import subprocess
import sys
import time
from pathlib import Path

from rich.console import Console

from bee.config import TRANSCRIPTS_DIR, ensure_dirs

console = Console()


def start_watcher():
    """Monitora TRANSCRIPTS_DIR e gera resumo quando um novo .txt aparece."""
    ensure_dirs()

    console.print(f"Monitorando [cyan]{TRANSCRIPTS_DIR}[/cyan] para novas transcrições...")
    console.print("Pressione Ctrl+C para parar.\n")

    if _has_inotifywait():
        _watch_with_inotify()
    else:
        _watch_with_polling()


def _has_inotifywait() -> bool:
    try:
        subprocess.run(["which", "inotifywait"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def _watch_with_inotify():
    console.print("[dim]Usando inotifywait para monitoramento eficiente[/dim]\n")

    while True:
        try:
            result = subprocess.run(
                [
                    "inotifywait",
                    "-e", "close_write",
                    "-e", "moved_to",
                    "--format", "%f",
                    str(TRANSCRIPTS_DIR),
                ],
                capture_output=True,
                text=True,
            )
            filename = result.stdout.strip()
            if filename.endswith(".txt") and not filename.endswith("_resumo.txt"):
                _process_new_transcript(TRANSCRIPTS_DIR / filename)
        except KeyboardInterrupt:
            console.print("\n[yellow]Watcher parado.[/yellow]")
            break


def _watch_with_polling():
    console.print("[dim]Usando polling (instale inotify-tools para monitoramento mais eficiente)[/dim]\n")

    known_files: set[str] = set()
    for f in TRANSCRIPTS_DIR.glob("*.txt"):
        known_files.add(f.name)

    try:
        while True:
            current_files = {f.name for f in TRANSCRIPTS_DIR.glob("*.txt")}
            new_files = current_files - known_files

            for filename in sorted(new_files):
                if not filename.endswith("_resumo.txt"):
                    _process_new_transcript(TRANSCRIPTS_DIR / filename)

            known_files = current_files
            time.sleep(5)
    except KeyboardInterrupt:
        console.print("\n[yellow]Watcher parado.[/yellow]")


def _process_new_transcript(transcript_path: Path):
    summary_path = transcript_path.with_name(transcript_path.stem + "_resumo.md")
    if summary_path.exists():
        return

    console.print(f"Nova transcrição detectada: [cyan]{transcript_path.name}[/cyan]")
    console.print("Gerando resumo via Claude...\n")

    try:
        from bee.pipeline import summarize_transcript
        summary = summarize_transcript(transcript_path)
        console.print(f"[green]Resumo salvo:[/green] {summary_path.name}\n")
    except Exception as e:
        console.print(f"[red]Erro ao gerar resumo:[/red] {e}\n")
