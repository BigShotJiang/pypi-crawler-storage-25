"""Configuration for Bee meeting recorder."""

import os
from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib


def _xdg_path(env_var: str, default_suffix: str) -> Path:
    return Path(os.environ.get(env_var, Path.home() / default_suffix))


CONFIG_DIR = _xdg_path("XDG_CONFIG_HOME", ".config") / "bee"
CACHE_DIR = _xdg_path("XDG_CACHE_HOME", ".cache") / "bee"
MODELS_DIR = CACHE_DIR / "models"

CONFIG_FILE = CONFIG_DIR / "config.toml"

BEE_DIR = Path.home() / "Documents" / "bee"
RECORDINGS_DIR = BEE_DIR / "recordings"
TRANSCRIPTS_DIR = BEE_DIR / "transcripts"


@dataclass
class BeeConfig:
    whisper_model: str = "medium"
    whisper_device: str = "auto"
    whisper_language: str = "auto"
    sample_rate: int = 16000
    channels: int = 1
    chunk_duration_seconds: int = 300
    recordings_dir: Path = field(default_factory=lambda: RECORDINGS_DIR)
    transcripts_dir: Path = field(default_factory=lambda: TRANSCRIPTS_DIR)
    models_dir: Path = field(default_factory=lambda: MODELS_DIR)


_config: BeeConfig | None = None


def _load_toml() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    with open(CONFIG_FILE, "rb") as f:
        return tomllib.load(f)


def get_config() -> BeeConfig:
    global _config
    if _config is not None:
        return _config

    raw = _load_toml()
    whisper = raw.get("whisper", {})
    audio = raw.get("audio", {})
    paths = raw.get("paths", {})

    _config = BeeConfig(
        whisper_model=whisper.get("model", "medium"),
        whisper_device=whisper.get("device", "auto"),
        whisper_language=whisper.get("language", "auto"),
        sample_rate=audio.get("sample_rate", 16000),
        channels=audio.get("channels", 1),
        chunk_duration_seconds=audio.get("chunk_duration_seconds", 300),
        recordings_dir=Path(paths["recordings"]) if "recordings" in paths else RECORDINGS_DIR,
        transcripts_dir=Path(paths["transcripts"]) if "transcripts" in paths else TRANSCRIPTS_DIR,
        models_dir=Path(paths["models"]) if "models" in paths else MODELS_DIR,
    )
    return _config


def reset_config():
    global _config
    _config = None


# Backward-compatible module-level constants
def __getattr__(name: str):
    _compat = {
        "WHISPER_MODEL": lambda c: c.whisper_model,
        "WHISPER_DEVICE": lambda c: c.whisper_device,
        "WHISPER_LANGUAGE": lambda c: c.whisper_language,
        "SAMPLE_RATE": lambda c: c.sample_rate,
        "CHANNELS": lambda c: c.channels,
    }
    if name in _compat:
        return _compat[name](get_config())
    raise AttributeError(f"module 'bee.config' has no attribute {name!r}")


def ensure_dirs():
    cfg = get_config()
    cfg.recordings_dir.mkdir(parents=True, exist_ok=True)
    cfg.transcripts_dir.mkdir(parents=True, exist_ok=True)
    cfg.models_dir.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
