"""First-run setup wizard for Bee."""

import os
import shutil
import subprocess
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from bee.config import CONFIG_DIR, CONFIG_FILE, ensure_dirs
from bee.models import (
    WHISPER_MODELS,
    download_model,
    get_model_status,
    get_recommended_model,
)

console = Console()


def detect_hardware() -> dict:
    cpu = "Unknown"
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    cpu = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass

    ram_gb = 0.0
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    ram_gb = int(line.split()[1]) / (1024 * 1024)
                    break
    except (OSError, ValueError):
        pass

    cores = os.cpu_count() or 1

    gpu = "None"
    try:
        import torch
        if torch.cuda.is_available():
            gpu = torch.cuda.get_device_name(0)
    except Exception:
        pass

    return {"cpu": cpu, "ram_gb": round(ram_gb, 1), "gpu": gpu, "cores": cores}


def check_system_deps() -> dict:
    deps = {
        "ffmpeg": shutil.which("ffmpeg") is not None,
        "pactl": shutil.which("pactl") is not None,
    }

    deps["pulseaudio"] = False
    if deps["pactl"]:
        try:
            result = subprocess.run(
                ["pactl", "info"], capture_output=True, text=True, timeout=5
            )
            deps["pulseaudio"] = result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    return deps


def write_default_config(config_dict: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    lines = []
    whisper = config_dict.get("whisper", {})
    if whisper:
        lines.append("[whisper]")
        for k, v in whisper.items():
            lines.append(f'{k} = "{v}"' if isinstance(v, str) else f"{k} = {v}")
        lines.append("")

    audio = config_dict.get("audio", {})
    if audio:
        lines.append("[audio]")
        for k, v in audio.items():
            lines.append(f"{k} = {v}")
        lines.append("")

    CONFIG_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_setup() -> dict:
    console.print()

    hw = detect_hardware()
    deps = check_system_deps()
    recommended = get_recommended_model()
    model_info = WHISPER_MODELS[recommended]

    missing_deps = [name for name, ok in deps.items() if not ok]
    if missing_deps:
        console.print("[red bold]Missing system dependencies:[/red bold]")
        if not deps["ffmpeg"]:
            console.print("  ffmpeg — [dim]sudo apt install ffmpeg[/dim]")
        if not deps["pactl"] or not deps["pulseaudio"]:
            console.print("  PulseAudio — [dim]sudo apt install pulseaudio-utils[/dim]")
        console.print()

    gpu_str = f"[cyan]{hw['gpu']}[/cyan]" if hw["gpu"] != "None" else "[dim]none (CPU mode)[/dim]"
    model_status = get_model_status(recommended)
    download_note = "" if model_status == "installed" else f" [dim]({model_info['size_mb']} MB download)[/dim]"

    console.print(Panel(
        f"[bold]Hardware detected:[/bold]\n"
        f"  CPU:  [cyan]{hw['cpu']}[/cyan]\n"
        f"  RAM:  [cyan]{hw['ram_gb']} GB[/cyan]\n"
        f"  GPU:  {gpu_str}\n\n"
        f"[bold]Recommended config:[/bold]\n"
        f"  Whisper model:  [green]{recommended}[/green] ({model_info['quality']} quality, {model_info['speed']}){download_note}\n"
        f"  Language:        [green]auto-detect[/green]\n"
        f"  Diarization:     [green]SpeechBrain ECAPA-TDNN[/green]",
        title="Bee Setup",
        border_style="green",
    ))

    try:
        proceed = click.confirm("Install with recommended settings?", default=True)
    except (click.Abort, EOFError):
        proceed = False

    if not proceed:
        return _advanced_setup(hw, recommended)

    config_dict = {
        "whisper": {
            "model": recommended,
            "device": "cuda" if hw["gpu"] != "None" else "auto",
            "language": "auto",
        },
        "audio": {
            "sample_rate": 16000,
            "channels": 1,
        },
    }

    ensure_dirs()
    write_default_config(config_dict)
    console.print(f"\n[green]Config saved:[/green] {CONFIG_FILE}")

    _download_models(recommended)

    console.print(Panel(
        "[green bold]Ready![/green bold]\n\n"
        "Start recording:  [bold]bee start[/bold]\n"
        "Stop & transcribe: [bold]bee stop[/bold]\n"
        "Check health:      [bold]bee doctor[/bold]",
        title="Bee",
        border_style="green",
    ))

    return config_dict


def _advanced_setup(hw: dict, default_model: str) -> dict:
    console.print("\n[bold]Advanced setup[/bold]\n")

    model_table = Table(title="Available Whisper Models")
    model_table.add_column("Model", style="cyan")
    model_table.add_column("Size", justify="right")
    model_table.add_column("RAM", justify="right")
    model_table.add_column("Speed")
    model_table.add_column("Quality")
    model_table.add_column("Status")

    model_names = list(WHISPER_MODELS.keys())
    for name, info in WHISPER_MODELS.items():
        status = get_model_status(name)
        status_str = "[green]installed[/green]" if status == "installed" else "[dim]available[/dim]"
        rec = " [yellow]*[/yellow]" if name == default_model else ""
        model_table.add_row(
            f"{name}{rec}",
            f"{info['size_mb']} MB",
            f"{info['ram_mb']} MB",
            info["speed"],
            info["quality"],
            status_str,
        )
    console.print(model_table)

    try:
        chosen_model = click.prompt(
            f"\nWhisper model",
            default=default_model,
            type=click.Choice(model_names, case_sensitive=False),
        )
    except (click.Abort, EOFError):
        chosen_model = default_model

    try:
        language = click.prompt(
            "Language (auto = auto-detect, or: pt, en, es, ...)",
            default="auto",
        )
    except (click.Abort, EOFError):
        language = "auto"

    config_dict = {
        "whisper": {
            "model": chosen_model,
            "device": "cuda" if hw["gpu"] != "None" else "auto",
            "language": language,
        },
        "audio": {
            "sample_rate": 16000,
            "channels": 1,
        },
    }

    ensure_dirs()
    write_default_config(config_dict)
    console.print(f"\n[green]Config saved:[/green] {CONFIG_FILE}")

    _download_models(chosen_model)

    console.print(Panel(
        "[green bold]Ready![/green bold]\n\n"
        "Start recording:  [bold]bee start[/bold]\n"
        "Stop & transcribe: [bold]bee stop[/bold]\n"
        "Check health:      [bold]bee doctor[/bold]",
        title="Bee",
        border_style="green",
    ))

    return config_dict


def _download_models(whisper_model: str):
    from rich.progress import Progress, SpinnerColumn, TextColumn

    models_to_download = []
    if get_model_status(whisper_model) != "installed":
        models_to_download.append(("whisper", whisper_model))
    if get_model_status("speechbrain/ecapa-tdnn") != "installed":
        models_to_download.append(("diarization", "speechbrain/ecapa-tdnn"))

    if not models_to_download:
        console.print("[green]All models already downloaded.[/green]")
        return

    console.print()
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        for label, model_name in models_to_download:
            task = progress.add_task(f"Downloading {label} model...", total=None)
            try:
                download_model(model_name)
                progress.update(task, description=f"[green]{label} model ready[/green]")
            except Exception as e:
                progress.update(task, description=f"[red]{label} download failed: {e}[/red]")
