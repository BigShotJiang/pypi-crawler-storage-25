"""Pipeline de processamento: transcrição -> diarização -> identificação."""

import json
from pathlib import Path

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from bee.config import RECORDINGS_DIR, TRANSCRIPTS_DIR, ensure_dirs

console = Console()


def _make_segment(raw: dict):
    from bee.transcriber import Segment
    return Segment(
        start=raw["start"],
        end=raw["end"],
        text=raw["text"],
        source=raw.get("source", ""),
    )


def _load_live_transcript(rec_dir: Path) -> dict:
    path = rec_dir / "live_transcript.json"
    if not path.exists():
        return {"segments": [], "mic_offset": 0.0, "system_offset": 0.0, "system_source": None}
    with open(path) as f:
        return json.load(f)


def _transcribe_tail(audio_file: Path, offset: float, progress, task, label: str) -> list:
    """Transcreve apenas o trecho após offset. Retorna segments com timestamps absolutos."""
    from bee.transcriber import Segment, transcribe
    import subprocess

    total = 0.0
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(audio_file)],
            capture_output=True, text=True, timeout=10,
        )
        total = float(r.stdout.strip())
    except (ValueError, subprocess.TimeoutExpired):
        pass

    remaining = total - offset
    if remaining < 1.0:
        return []

    progress.update(task, description=f"Transcrevendo {label} (últimos {int(remaining)}s)...")

    tmp = audio_file.parent / f"_tail_{audio_file.stem}.wav"
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-ss", str(offset), "-i", str(audio_file),
             "-ar", "16000", "-ac", "1", str(tmp)],
            capture_output=True, timeout=60,
        )
        if not tmp.exists() or tmp.stat().st_size < 1000:
            return []
        segs = transcribe(tmp)
        for s in segs:
            s.start += offset
            s.end += offset
        return segs
    except (subprocess.TimeoutExpired, Exception):
        return []
    finally:
        tmp.unlink(missing_ok=True)


def process_recording(rec_id: str, skip_diarization: bool = False) -> dict:
    """Processa uma gravação: transcrição, diarização e salva JSON + Markdown."""
    ensure_dirs()
    rec_dir = RECORDINGS_DIR / rec_id
    metadata = _read_metadata(rec_dir)

    mic_file = rec_dir / "mic.wav"
    system_file = rec_dir / "system.wav"
    has_mic = mic_file.exists() and mic_file.stat().st_size > 1000
    has_system = system_file.exists() and system_file.stat().st_size > 1000

    if has_system:
        has_system = _has_audio_content(system_file)

    two_channel = has_mic and has_system

    if not has_mic and not has_system:
        audio_files = _resolve_audio_files(rec_dir, metadata)
        if not audio_files:
            raise FileNotFoundError(f"Nenhum arquivo de áudio encontrado em: {rec_dir}")

    live = _load_live_transcript(rec_dir)
    pre_segments = [
        _make_segment(s) for s in live.get("segments", [])
    ]
    mic_offset = live.get("mic_offset", 0.0)
    system_offset = live.get("system_offset", 0.0)

    # Se o sink que foi ao vivo não é o mesmo que stop selecionou, descarta pré-transcrição do sistema
    live_sys_source = live.get("system_source")
    best_sys_source = metadata.get("best_system_source")
    if live_sys_source and best_sys_source and live_sys_source != best_sys_source:
        pre_segments = [s for s in pre_segments if s.source == "mic"]
        system_offset = 0.0

    has_live = bool(pre_segments) or mic_offset > 0 or system_offset > 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:

        task = progress.add_task("Transcrevendo áudio com Whisper...", total=None)
        from bee.transcriber import transcribe

        all_segments = list(pre_segments)

        if has_live:
            progress.update(task, description="Continuando transcrição do ao vivo...")

        if two_channel:
            tail_mic = _transcribe_tail(mic_file, mic_offset, progress, task, "microfone")
            for s in tail_mic:
                s.source = "mic"
            all_segments.extend(tail_mic)

            tail_sys = _transcribe_tail(system_file, system_offset, progress, task, "sistema")
            for s in tail_sys:
                s.source = "system"
            all_segments.extend(tail_sys)
        else:
            if has_mic:
                audio_file, offset = mic_file, mic_offset
            elif has_system:
                audio_file, offset = system_file, system_offset
            else:
                audio_file = _resolve_audio_files(rec_dir, metadata)[0]
                offset = 0.0

            if not has_live:
                progress.update(task, description=f"Transcrevendo {audio_file.name}...")
                segs = transcribe(audio_file)
                for s in segs:
                    s.source = audio_file.stem
                all_segments.extend(segs)
            else:
                tail = _transcribe_tail(audio_file, offset, progress, task, audio_file.stem)
                for s in tail:
                    s.source = audio_file.stem
                all_segments.extend(tail)

            if not has_system:
                console.print("[yellow]Aviso: áudio do sistema está silencioso. Participantes remotos serão identificados pelo microfone (bleed).[/yellow]")

        all_segments.sort(key=lambda s: s.start)
        segments = _deduplicate_segments(all_segments)
        progress.update(task, description=f"Transcrição completa: {len(segments)} segmentos")
        progress.remove_task(task)

        if not skip_diarization:
            task = progress.add_task("Identificando participantes...", total=None)
            from bee.diarizer import DiarizedSegment, diarize, merge_transcription_with_diarization

            if two_channel:
                speaker_segments = diarize(system_file)

                mic_only = [s for s in segments if s.source == "mic"]
                sys_only = [s for s in segments if s.source == "system"]

                user_diarized = [
                    DiarizedSegment(start=s.start, end=s.end, speaker="EU", text=s.text)
                    for s in mic_only
                ]
                remote_diarized = merge_transcription_with_diarization(sys_only, speaker_segments)

                diarized = user_diarized + remote_diarized
                diarized.sort(key=lambda s: s.start)
            else:
                audio_file = has_mic and mic_file or (has_system and system_file) or _resolve_audio_files(rec_dir, metadata)[0]
                speaker_segments = diarize(audio_file)
                diarized = merge_transcription_with_diarization(segments, speaker_segments)

            progress.update(task, description=f"Identificação completa: {len(set(s.speaker for s in diarized))} participantes")
            progress.remove_task(task)
        else:
            from bee.diarizer import DiarizedSegment
            diarized = [
                DiarizedSegment(start=s.start, end=s.end, speaker="Speaker", text=s.text)
                for s in segments
            ]

        task = progress.add_task("Salvando transcrição...", total=None)
        from bee.formatter import save_transcript
        paths = save_transcript(diarized, rec_id, TRANSCRIPTS_DIR)
        progress.remove_task(task)

    metadata["status"] = "processed"
    metadata["transcript_json"] = paths["json_path"]
    metadata["transcript_md"] = paths["md_path"]
    _write_metadata(rec_dir, metadata)

    return {
        "segments": len(diarized),
        "speakers": len(set(s.speaker for s in diarized)),
        "json_path": paths["json_path"],
        "md_path": paths["md_path"],
    }


def get_speaker_previews(rec_id: str) -> dict[str, dict]:
    """Retorna info detalhada de cada speaker para facilitar identificação."""
    transcript_json = TRANSCRIPTS_DIR / f"{rec_id}.json"
    if not transcript_json.exists():
        return {}

    raw = json.loads(transcript_json.read_text(encoding="utf-8"))
    segments = raw["segments"] if isinstance(raw, dict) and "segments" in raw else raw
    speakers: dict[str, dict] = {}

    for seg in segments:
        speaker = seg["speaker"]
        if speaker not in speakers:
            speakers[speaker] = {
                "quotes": [],
                "word_count": 0,
                "duration": 0.0,
                "segment_count": 0,
            }
        info = speakers[speaker]
        info["segment_count"] += 1
        info["word_count"] += len(seg["text"].split())
        info["duration"] += seg["end"] - seg["start"]
        text = seg["text"].strip()
        if text and len(text.split()) >= 3:
            info["quotes"].append(text)

    for info in speakers.values():
        info["quotes"] = sorted(info["quotes"], key=len, reverse=True)[:5]

    return speakers


def label_speakers(rec_id: str, labels: dict[str, str]) -> dict:
    """Substitui labels de speakers (ex: SPEAKER_00 -> Paulo) na transcrição."""
    ensure_dirs()

    transcript_json = TRANSCRIPTS_DIR / f"{rec_id}.json"

    if not transcript_json.exists():
        raise FileNotFoundError(f"Transcrição não encontrada: {rec_id}")

    raw = json.loads(transcript_json.read_text(encoding="utf-8"))
    segments = raw["segments"] if isinstance(raw, dict) and "segments" in raw else raw
    for seg in segments:
        if seg["speaker"] in labels:
            seg["speaker"] = labels[seg["speaker"]]

    from bee.diarizer import DiarizedSegment
    from bee.formatter import save_transcript

    diarized = [
        DiarizedSegment(start=s["start"], end=s["end"], speaker=s["speaker"], text=s["text"])
        for s in segments
    ]

    language = raw.get("metadata", {}).get("language_detected") if isinstance(raw, dict) else None
    save_transcript(diarized, rec_id, TRANSCRIPTS_DIR, language)

    rec_dir = RECORDINGS_DIR / rec_id
    if rec_dir.exists():
        metadata = _read_metadata(rec_dir)
        metadata["speaker_labels"] = labels
        _write_metadata(rec_dir, metadata)

    return {
        "speakers": list(set(s["speaker"] for s in segments)),
    }


def summarize_transcript(transcript_path: Path) -> str:
    """Gera resumo de um arquivo de transcrição existente (requer Claude CLI)."""
    from bee.summarizer import is_available, summarize

    if not is_available():
        raise RuntimeError("Claude CLI não encontrado. Instale o Claude Code CLI para gerar resumos.")

    transcript_text = transcript_path.read_text(encoding="utf-8")
    summary = summarize(transcript_text, transcript_path)

    summary_file = transcript_path.with_name(
        transcript_path.stem + "_resumo.md"
    )
    summary_file.write_text(summary, encoding="utf-8")
    return summary


def _has_audio_content(audio_path: Path, threshold_db: float = -70.0) -> bool:
    """Checa se o arquivo de áudio tem conteúdo audível (não é silêncio)."""
    import subprocess
    result = subprocess.run(
        ["ffmpeg", "-i", str(audio_path), "-af", "volumedetect", "-f", "null", "/dev/null"],
        capture_output=True, text=True,
    )
    for line in result.stderr.splitlines():
        if "max_volume:" in line:
            try:
                db = float(line.split("max_volume:")[1].strip().split()[0])
                return db > threshold_db
            except (ValueError, IndexError):
                pass
    return False


def _resolve_audio_files(rec_dir: Path, metadata: dict) -> list[Path]:
    """Retorna lista de arquivos de áudio para transcrever."""
    files = []
    for name in ("mic.wav", "system.wav"):
        f = rec_dir / name
        if f.exists() and f.stat().st_size > 1000:
            files.append(f)
    if not files:
        combined = rec_dir / "combined.wav"
        if combined.exists():
            files.append(combined)
    return files


def _deduplicate_segments(segments: list) -> list:
    """Remove segmentos duplicados (sobreposição temporal com texto similar)."""
    if not segments:
        return segments
    result = [segments[0]]
    for seg in segments[1:]:
        prev = result[-1]
        overlap = max(0, min(prev.end, seg.end) - max(prev.start, seg.start))
        min_duration = min(prev.end - prev.start, seg.end - seg.start)
        if min_duration > 0 and overlap / min_duration > 0.5:
            if _text_similarity(prev.text, seg.text) > 0.6:
                if len(seg.text) > len(prev.text):
                    result[-1] = seg
                continue
            result.append(seg)
            continue
        result.append(seg)
    return result


def _text_similarity(a: str, b: str) -> float:
    """Similaridade simples entre dois textos baseada em palavras comuns."""
    words_a = set(a.lower().split())
    words_b = set(b.lower().split())
    if not words_a or not words_b:
        return 0.0
    intersection = words_a & words_b
    return len(intersection) / min(len(words_a), len(words_b))


def _read_metadata(rec_dir: Path) -> dict:
    meta_file = rec_dir / "metadata.json"
    if not meta_file.exists():
        raise FileNotFoundError(f"Gravação não encontrada: {rec_dir.name}")
    with open(meta_file) as f:
        return json.load(f)


def _write_metadata(rec_dir: Path, metadata: dict):
    with open(rec_dir / "metadata.json", "w") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
