"""Bee - Gravador de reuniões com transcrição e resumo."""
