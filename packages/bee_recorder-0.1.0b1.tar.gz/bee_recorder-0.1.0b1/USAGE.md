# Bee Recorder

Gravador de reuniões local-first com transcrição automática (Whisper) e identificação de participantes (SpeechBrain). Tudo roda na sua máquina — nenhum áudio sai pra cloud.

Captura simultaneamente o áudio do sistema (Google Meet, Teams, Zoom, Discord, etc.) e seu microfone, transcreve, separa quem falou o quê e gera transcrição em Markdown e JSON.

## Requisitos

- Linux com PulseAudio ou PipeWire (Ubuntu, Fedora, Debian, Arch, Mint, etc.)
- Python 3.10+
- ffmpeg
- pulseaudio-utils (para o `pactl`)

```bash
sudo apt install ffmpeg pulseaudio-utils python3 python3-venv     # Ubuntu/Debian
sudo dnf install ffmpeg-free pulseaudio-utils python3              # Fedora
sudo pacman -S ffmpeg libpulse python                              # Arch
```

## Instalação

```bash
pipx install bee-recorder
bee setup       # detecta hardware, baixa modelos (~1.6 GB)
bee doctor      # valida o ambiente
```

Ou com `pip` em um venv:

```bash
python3 -m venv ~/.venvs/bee && ~/.venvs/bee/bin/pip install bee-recorder
~/.venvs/bee/bin/bee setup
```

## Fluxo de uma reunião

### 1. Antes de entrar na reunião

```bash
bee start -n daily-2026-04-22
```

Dê um nome que faça sentido (daily, retro, planning, 1on1-lucas, etc).
Se não passar nome, ele usa o timestamp automaticamente.

Para gravar só o áudio do sistema (sem seu microfone):

```bash
bee start -n daily-2026-04-22 --no-mic
```

### 2. Entra na reunião normalmente

Google Meet, Teams, Zoom, Discord — qualquer um. O Bee captura tudo que entra e sai do áudio do sistema.

### 3. Quando a reunião acabar

```bash
bee stop
```

Ele vai:
- Parar a gravação
- Transcrever tudo com Whisper
- Identificar quem falou (diarização)
- Gerar resumo com Claude (pontos principais, decisões, action items)

Demora alguns minutos dependendo da duração da reunião.

Se quiser só parar e processar depois:

```bash
bee stop --no-process
bee process daily-2026-04-22    # processa quando quiser
```

### 4. Identificar os participantes

Depois do processamento, o Bee mostra uma tabela com preview de cada speaker. Para ver de novo:

```bash
bee speakers daily-2026-04-22
```

Rotule com os nomes reais:

```bash
bee label daily-2026-04-22 SPEAKER_00=Paulo SPEAKER_01=Lucas SPEAKER_02=Maria
```

Isso atualiza a transcrição e re-gera o resumo com os nomes corretos.

### 5. Consultar

```bash
bee show daily-2026-04-22       # transcrição + resumo
bee show daily-2026-04-22 -t    # só transcrição
bee show daily-2026-04-22 -s    # só resumo
bee list                        # lista todas as gravações
```

## Arquivos gerados

Tudo fica em `Projects/bee/transcripts/`:

| Arquivo | Conteúdo |
|---------|----------|
| `daily-2026-04-22.txt` | Transcrição completa com timestamps e speakers |
| `daily-2026-04-22.json` | Transcrição estruturada (para automações) |
| `daily-2026-04-22_resumo.md` | Resumo: participantes, pontos, decisões, action items |

## Comandos rápidos

| Comando | O que faz |
|---------|-----------|
| `bee start -n nome` | Inicia gravação |
| `bee stop` | Para + transcreve + diariza + resume |
| `bee stop --no-process` | Só para a gravação |
| `bee stop --no-summary` | Para + transcreve, sem resumo |
| `bee speakers id` | Preview de cada speaker |
| `bee label id SP_00=Nome` | Rotula speakers com nomes reais |
| `bee process id` | Processa uma gravação parada |
| `bee summarize arquivo.txt` | Gera resumo de qualquer transcrição |
| `bee show id` | Mostra transcrição e resumo |
| `bee list` | Lista todas as gravações |
| `bee watch` | Auto-resume transcrições novas na pasta |
