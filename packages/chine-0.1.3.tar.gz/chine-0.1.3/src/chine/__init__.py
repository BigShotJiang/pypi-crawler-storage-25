"""Chine - A static architecture checker for Python."""

from chine.checker import (
    ARCH001,
    ARCH002,
    ARCH003,
    CheckSpec,
    DependencyRule,
    ModuleInfo,
    ProjectGraph,
    Violation,
    build_project_graph,
    check_arch001,
    check_arch002,
    check_arch003,
    check_dependency_rule,
    check_directory,
    get_module_role,
)

__version__ = "0.1.1"

__all__ = [
    "CheckSpec",
    "DependencyRule",
    "ModuleInfo",
    "ProjectGraph",
    "Violation",
    "ARCH001",
    "ARCH002",
    "ARCH003",
    "build_project_graph",
    "check_arch001",
    "check_arch002",
    "check_arch003",
    "check_dependency_rule",
    "check_directory",
    "get_module_role",
]
