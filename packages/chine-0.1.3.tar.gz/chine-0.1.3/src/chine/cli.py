"""CLI for Chine - A static architecture checker for Python."""

from pathlib import Path

import click

from chine.checker import (
    SUPPORTED_ROLE_TAGS,
    build_project_graph,
    calculate_coverage_stats,
    check_project_graph,
)


@click.group()
@click.version_option()
def main() -> None:
    """Chine - A static architecture checker for Python.

    Validates architectural roles and dependencies in your Python codebase.
    """


@main.command()
@click.argument("path", type=click.Path(exists=True), default=".")
def check(path: str) -> None:
    """Check architectural violations in the specified path.

    Args:
        path: The path to check (default: current directory)
    """
    source_root = Path(path).resolve()
    click.echo(f"Checking architecture in {source_root}...")

    graph = build_project_graph(source_root)
    violations = check_project_graph(graph)
    coverage_stats = calculate_coverage_stats(graph)
    click.echo(
        "Role coverage: "
        f"{coverage_stats.declared_modules}/{coverage_stats.total_modules} "
        f"({coverage_stats.percentage:.1f}%)"
    )
    click.echo()

    if not violations:
        click.secho("✓ No architectural violations found!", fg="green")
        return

    click.secho(f"✗ Found {len(violations)} architectural violation(s):", fg="red")
    click.echo()

    for violation in violations:
        click.secho(f"{violation.rule_id}: ", fg="red", nl=False)
        click.echo(f"{violation.file_path}:{violation.line_number}")
        click.echo(f"  {violation.message}")
        click.echo()

    raise click.Abort()


@main.command("role-tags")
def role_tags() -> None:
    """Print all supported architecture role tags."""
    click.echo("Supported architecture role tags:")
    for role_tag, description in SUPPORTED_ROLE_TAGS:
        click.echo(f"- {role_tag}: {description}")


if __name__ == "__main__":
    main()
