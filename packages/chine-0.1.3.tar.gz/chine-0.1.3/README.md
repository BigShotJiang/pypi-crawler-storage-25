# chine

Chine is a static architecture checker for Python. It parses your code with `ast`, reads declared
architecture roles, and reports dependency violations without importing or executing your modules.

## What chine checks

Declare a role at module level:

```python
__architecture_role__ = "use_case"
```

Supported roles:

- `use_case`
- `domain_policy` (and `domain`)
- `adapter`

Current rules:

- `ARCH001`: use case modules must not import adapter modules
- `ARCH002`: domain/domain_policy modules must not import adapter modules
- `ARCH003`: domain/domain_policy modules must not import use case modules

Modules without `__architecture_role__` are treated as untyped (`Any`) for architecture checks.

## Installation

Install from PyPI:

```bash
pip install chine
```

Or with pipx:

```bash
pipx install chine
```

## End-user usage

Show CLI help:

```bash
chine --help
```

Check the current directory:

```bash
chine check
```

Check a specific path:

```bash
chine check src/
```

Show version:

```bash
chine --version
```

Show supported role tags:

```bash
chine role-tags
```

When no violations are found, chine exits successfully. If violations are found, it prints each
`ARCH` rule violation with file and line number and exits with a non-zero status.

## Development

```bash
uv sync --all-extras
uv run ruff check src/
uv run mypy src/
uv run pytest
```

## License

See LICENSE for details.
