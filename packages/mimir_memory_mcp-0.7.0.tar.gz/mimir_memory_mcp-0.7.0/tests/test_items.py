import json
from mimir_mcp.tools.session import boot_session_impl
from mimir_mcp.tools.items import (
    add_items_impl as add_items,
    update_item_impl as update_item,
    complete_items_impl as complete_items,
    archive_items_impl as archive_items,
    delete_items_impl as delete_items,
    convert_item_impl as convert_item,
)


# --- Helpers ---


def _boot_jimmy(db):
    """Boot a session for jimmy and return session_id."""
    boot_session_impl(db, "jimmy", ["jimmy", "household"])
    session = db.fetchone("SELECT id FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL")
    return session["id"]


def _boot_alex(db):
    """Boot a session for alex and return session_id."""
    boot_session_impl(db, "alex", ["alex", "household"])
    session = db.fetchone("SELECT id FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL")
    return session["id"]


# ============================================================
# add_items tests
# ============================================================


class TestAddItems:
    def test_add_single_item(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        items_input = [{"scope": "jimmy", "type": "task", "summary": "Buy groceries"}]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            items_input,
            session_id=session_id,
        )
        assert len(result) == 1
        item = result[0]
        assert item["summary"] == "Buy groceries"
        assert item["type"] == "task"
        assert item["scope"] == "jimmy"
        assert item["created_by"] == "jimmy"
        # Verify DB row
        row = seed_data.fetchone("SELECT * FROM items WHERE id = ?", (item["id"],))
        assert row is not None
        assert row["summary"] == "Buy groceries"
        # Verify history
        history = seed_data.fetchall("SELECT * FROM item_history WHERE item_id = ?", (item["id"],))
        assert len(history) == 1
        assert history[0]["event"] == "created"

    def test_add_multiple_items(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        items_input = [
            {"scope": "jimmy", "type": "task", "summary": "Task A"},
            {"scope": "household", "type": "task", "summary": "Task B"},
            {"scope": "jimmy", "type": "note", "summary": "Note C"},
        ]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            items_input,
            session_id=session_id,
        )
        assert len(result) == 3
        assert result[0]["summary"] == "Task A"
        assert result[1]["summary"] == "Task B"
        assert result[2]["summary"] == "Note C"

    def test_add_scope_enforcement(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        items_input = [{"scope": "alex", "type": "task", "summary": "Forbidden task"}]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            items_input,
            session_id=session_id,
        )
        assert "error" in result[0]

    def test_add_parent_validation(self, seed_data):
        """Parent must be in same scope as child."""
        session_id = _boot_jimmy(seed_data)
        # Create parent in jimmy scope
        parent_result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent"}],
            session_id=session_id,
        )
        parent_id = parent_result[0]["id"]
        # Try to create child in household scope under jimmy parent
        child_input = [
            {
                "scope": "household",
                "type": "task",
                "summary": "Mismatched child",
                "parent_id": parent_id,
            }
        ]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            child_input,
            session_id=session_id,
        )
        assert "error" in result[0]

    def test_add_parent_type_validation(self, seed_data):
        """Can't parent under fact/note/reminder."""
        session_id = _boot_jimmy(seed_data)
        parent_result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "fact", "summary": "A fact"}],
            session_id=session_id,
        )
        parent_id = parent_result[0]["id"]
        child_input = [
            {
                "scope": "jimmy",
                "type": "task",
                "summary": "Child under fact",
                "parent_id": parent_id,
            }
        ]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            child_input,
            session_id=session_id,
        )
        assert "error" in result[0]

    def test_add_default_status(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        items_input = [
            {"scope": "jimmy", "type": "task", "summary": "Task"},
            {"scope": "jimmy", "type": "fact", "summary": "Fact"},
            {"scope": "jimmy", "type": "project", "summary": "Project"},
            {"scope": "jimmy", "type": "reminder", "summary": "Reminder"},
            {"scope": "jimmy", "type": "note", "summary": "Note"},
            {"scope": "jimmy", "type": "idea", "summary": "Idea"},
        ]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            items_input,
            session_id=session_id,
        )
        assert result[0]["status"] == "not_started"  # task
        assert result[1]["status"] == "active"  # fact
        assert result[2]["status"] == "active"  # project
        assert result[3]["status"] == "active"  # reminder
        assert result[4]["status"] == "active"  # note
        assert result[5]["status"] == "active"  # idea

    def test_add_with_tags(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        items_input = [
            {
                "scope": "jimmy",
                "type": "task",
                "summary": "Grocery run",
                "tags": ["health", "shopping"],
            }
        ]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            items_input,
            session_id=session_id,
        )
        item_id = result[0]["id"]
        tags = seed_data.fetchall("SELECT tag_id FROM item_tags WHERE item_id = ?", (item_id,))
        tag_ids = [t["tag_id"] for t in tags]
        assert "health" in tag_ids
        assert "shopping" in tag_ids

    def test_add_with_metadata(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        meta = {"url": "https://example.com", "priority_score": 42}
        items_input = [
            {
                "scope": "jimmy",
                "type": "note",
                "summary": "With metadata",
                "metadata": meta,
            }
        ]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            items_input,
            session_id=session_id,
        )
        item_id = result[0]["id"]
        row = seed_data.fetchone("SELECT metadata FROM items WHERE id = ?", (item_id,))
        stored = json.loads(row["metadata"])
        assert stored["url"] == "https://example.com"
        assert stored["priority_score"] == 42

    def test_add_with_explicit_status(self, seed_data):
        """Explicit status overrides the default."""
        session_id = _boot_jimmy(seed_data)
        items_input = [
            {
                "scope": "jimmy",
                "type": "task",
                "summary": "Already started",
                "status": "in_progress",
            }
        ]
        result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            items_input,
            session_id=session_id,
        )
        assert result[0]["status"] == "in_progress"


# ============================================================
# update_item tests
# ============================================================


class TestUpdateItem:
    def test_update_basic_fields(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Original"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        result = update_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            {"summary": "Updated", "priority": "high", "due_date": "2026-04-01"},
            session_id=session_id,
        )
        assert result["summary"] == "Updated"
        assert result["priority"] == "high"
        assert result["due_date"] == "2026-04-01"

    def test_update_scope_enforcement(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Jimmy only"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        # Alex tries to update — only has alex and household scopes
        _boot_alex(seed_data)
        result = update_item(
            seed_data,
            "alex",
            ["alex", "household"],
            item_id,
            {"summary": "Hacked"},
        )
        assert "error" in result

    def test_update_scope_change_cascades(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        parent = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent"}],
            session_id=session_id,
        )
        parent_id = parent[0]["id"]
        child = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Child", "parent_id": parent_id}],
            session_id=session_id,
        )
        child_id = child[0]["id"]
        # Change scope from jimmy to household
        result = update_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            parent_id,
            {"scope": "household"},
            session_id=session_id,
        )
        assert result["scope"] == "household"
        # Child should also be household now
        child_row = seed_data.fetchone("SELECT scope FROM items WHERE id = ?", (child_id,))
        assert child_row["scope"] == "household"
        # Check correlation_id is shared across history entries
        history = seed_data.fetchall(
            "SELECT * FROM item_history WHERE correlation_id IS NOT NULL AND item_id IN (?, ?)",
            (parent_id, child_id),
        )
        assert len(history) >= 2
        correlation_ids = set(h["correlation_id"] for h in history)
        assert len(correlation_ids) == 1  # all share same correlation_id

    def test_update_records_structured_diff(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Before", "priority": "normal"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        update_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            {"summary": "After", "priority": "high"},
            session_id=session_id,
        )
        history = seed_data.fetchall(
            "SELECT * FROM item_history WHERE item_id = ? AND event = 'updated'",
            (item_id,),
        )
        assert len(history) == 1
        content = json.loads(history[0]["content"])
        fields_changed = {d["field"] for d in content}
        assert "summary" in fields_changed
        assert "priority" in fields_changed

    def test_update_tags(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Tagged", "tags": ["old_tag"]}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        update_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            {"tags": ["new_tag"]},
            session_id=session_id,
        )
        tags = seed_data.fetchall("SELECT tag_id FROM item_tags WHERE item_id = ?", (item_id,))
        tag_ids = [t["tag_id"] for t in tags]
        assert "new_tag" in tag_ids
        assert "old_tag" not in tag_ids

    def test_update_clear_fields(self, seed_data):
        """Empty string clears due_date and valid_until."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "task",
                    "summary": "Has dates",
                    "due_date": "2026-04-01",
                }
            ],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        update_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            {"due_date": "", "valid_until": ""},
            session_id=session_id,
        )
        row = seed_data.fetchone("SELECT due_date, valid_until FROM items WHERE id = ?", (item_id,))
        assert row["due_date"] is None
        assert row["valid_until"] is None


# ============================================================
# complete_items tests
# ============================================================


class TestCompleteItems:
    def test_complete_item(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "To complete"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        result = complete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [item_id],
            session_id=session_id,
        )
        assert "completed" in result.get("confirmation", "").lower() or result.get("count", 0) > 0
        row = seed_data.fetchone("SELECT status FROM items WHERE id = ?", (item_id,))
        assert row["status"] == "completed"
        # History recorded
        history = seed_data.fetchall(
            "SELECT * FROM item_history WHERE item_id = ? AND event = 'completed'",
            (item_id,),
        )
        assert len(history) == 1

    def test_complete_cascades_to_children(self, seed_data):
        """Completing parent ALSO completes children."""
        session_id = _boot_jimmy(seed_data)
        parent = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent"}],
            session_id=session_id,
        )
        parent_id = parent[0]["id"]
        child = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Child", "parent_id": parent_id}],
            session_id=session_id,
        )
        child_id = child[0]["id"]
        complete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [parent_id],
            session_id=session_id,
        )
        child_row = seed_data.fetchone("SELECT status FROM items WHERE id = ?", (child_id,))
        assert child_row["status"] == "completed"

    def test_complete_scope_enforcement(self, seed_data):
        """Can't complete an item outside your scopes."""
        session_id = _boot_jimmy(seed_data)
        # Create item in jimmy scope
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Jimmy task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        # Alex tries to complete it
        _boot_alex(seed_data)
        result = complete_items(
            seed_data,
            "alex",
            ["alex", "household"],
            [item_id],
        )
        assert "error" in result

    def test_deep_cascade_complete(self, seed_data):
        """Completing a root item cascades through 5 levels of children."""
        _boot_jimmy(seed_data)
        scopes = ["jimmy", "household"]

        # Create 5-level deep tree: root → L1 → L2 → L3 → L4
        root = add_items(
            seed_data,
            "jimmy",
            scopes,
            [{"scope": "jimmy", "type": "project", "summary": "Root project"}],
        )[0]
        l1 = add_items(
            seed_data,
            "jimmy",
            scopes,
            [{"scope": "jimmy", "type": "task", "summary": "Level 1", "parent_id": root["id"]}],
        )[0]
        l2 = add_items(
            seed_data,
            "jimmy",
            scopes,
            [{"scope": "jimmy", "type": "task", "summary": "Level 2", "parent_id": l1["id"]}],
        )[0]
        l3 = add_items(
            seed_data,
            "jimmy",
            scopes,
            [{"scope": "jimmy", "type": "task", "summary": "Level 3", "parent_id": l2["id"]}],
        )[0]
        l4 = add_items(
            seed_data,
            "jimmy",
            scopes,
            [{"scope": "jimmy", "type": "task", "summary": "Level 4", "parent_id": l3["id"]}],
        )[0]

        # Complete root — should cascade to all descendants
        result = complete_items(seed_data, "jimmy", scopes, [root["id"]])
        assert result["count"] == 5  # root + 4 levels

        # Verify all are completed
        for item_id in [root["id"], l1["id"], l2["id"], l3["id"], l4["id"]]:
            row = seed_data.fetchone("SELECT status FROM items WHERE id = ?", (item_id,))
            assert row["status"] == "completed", f"Item {item_id} should be completed"


# ============================================================
# archive_items tests
# ============================================================


class TestArchiveItems:
    def test_archive_cascades_to_children(self, seed_data):
        """Archiving parent cascades to all descendants with shared correlation_id."""
        session_id = _boot_jimmy(seed_data)
        parent = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent"}],
            session_id=session_id,
        )
        parent_id = parent[0]["id"]
        child = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Child", "parent_id": parent_id}],
            session_id=session_id,
        )
        child_id = child[0]["id"]
        grandchild = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Grandchild", "parent_id": child_id}],
            session_id=session_id,
        )
        grandchild_id = grandchild[0]["id"]
        archive_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [parent_id],
            session_id=session_id,
        )
        # All should be archived
        for iid in [parent_id, child_id, grandchild_id]:
            row = seed_data.fetchone("SELECT status FROM items WHERE id = ?", (iid,))
            assert row["status"] == "archived"
        # Check correlation_id shared
        history = seed_data.fetchall(
            "SELECT * FROM item_history WHERE correlation_id IS NOT NULL "
            "AND item_id IN (?, ?, ?) AND event = 'status_changed'",
            (parent_id, child_id, grandchild_id),
        )
        assert len(history) >= 3
        correlation_ids = set(h["correlation_id"] for h in history)
        assert len(correlation_ids) == 1

    def test_archive_returns_count(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "To archive"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        result = archive_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [item_id],
            session_id=session_id,
        )
        assert result.get("count", 0) >= 1

    def test_archive_scope_enforcement(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Jimmy task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        _boot_alex(seed_data)
        result = archive_items(
            seed_data,
            "alex",
            ["alex", "household"],
            [item_id],
        )
        assert "error" in result


# ============================================================
# delete_items tests
# ============================================================


class TestDeleteItems:
    def test_delete_admin_only(self, seed_data):
        """Non-admin rejected."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "household", "type": "task", "summary": "Shared task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        # Alex is not admin
        result = delete_items(
            seed_data,
            "alex",
            ["alex", "household"],
            [item_id],
            is_admin=False,
        )
        assert "error" in result
        # Item still exists
        row = seed_data.fetchone("SELECT * FROM items WHERE id = ?", (item_id,))
        assert row is not None

    def test_delete_soft_deletes_item(self, seed_data):
        """Admin soft-delete sets status to 'deleted'."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "To delete"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        result = delete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [item_id],
            is_admin=True,
        )
        assert result.get("count", 0) >= 1
        row = seed_data.fetchone("SELECT * FROM items WHERE id = ?", (item_id,))
        assert row is not None
        assert row["status"] == "deleted"

    def test_delete_cascades_to_children(self, seed_data):
        """Soft-delete cascades to children — both get status='deleted'."""
        session_id = _boot_jimmy(seed_data)
        parent = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent"}],
            session_id=session_id,
        )
        parent_id = parent[0]["id"]
        child = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Child", "parent_id": parent_id}],
            session_id=session_id,
        )
        child_id = child[0]["id"]
        delete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [parent_id],
            is_admin=True,
        )
        parent_row = seed_data.fetchone("SELECT status FROM items WHERE id = ?", (parent_id,))
        assert parent_row["status"] == "deleted"
        child_row = seed_data.fetchone("SELECT status FROM items WHERE id = ?", (child_id,))
        assert child_row["status"] == "deleted"

    def test_deleted_items_excluded_from_default_queries(self, seed_data):
        """Soft-deleted items are excluded from search_items and list_items by default."""
        from mimir_mcp.tools.search import (
            search_items_impl as search_items,
            list_items_impl as list_items,
        )

        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Deletable task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        delete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [item_id],
            is_admin=True,
        )
        # search_items should not find it
        results = search_items(seed_data, "jimmy", ["jimmy", "household"], query="Deletable")
        assert not any(r["id"] == item_id for r in results)
        # list_items should not find it
        results = list_items(seed_data, "jimmy", ["jimmy", "household"])
        assert not any(r["id"] == item_id for r in results)

    def test_deleted_items_found_with_explicit_status(self, seed_data):
        """Soft-deleted items can be found with explicit status='deleted' filter."""
        from mimir_mcp.tools.search import (
            search_items_impl as search_items,
            list_items_impl as list_items,
        )

        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Findable deleted task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        delete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [item_id],
            is_admin=True,
        )
        # search_items with status='deleted' should find it
        results = search_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            query="Findable deleted",
            status="deleted",
        )
        assert any(r["id"] == item_id for r in results)
        # list_items with status='deleted' should find it
        results = list_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            status="deleted",
        )
        assert any(r["id"] == item_id for r in results)


# ============================================================
# convert_item tests
# ============================================================


class TestConvertItem:
    def test_convert_type(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "idea", "summary": "An idea"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        result = convert_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            "project",
            session_id=session_id,
        )
        assert result["type"] == "project"
        # History recorded with 'converted' event
        history = seed_data.fetchall(
            "SELECT * FROM item_history WHERE item_id = ? AND event = 'converted'",
            (item_id,),
        )
        assert len(history) == 1
        content = json.loads(history[0]["content"])
        type_diff = [d for d in content if d["field"] == "type"]
        assert len(type_diff) == 1
        assert type_diff[0]["old"] == "idea"
        assert type_diff[0]["new"] == "project"

    def test_convert_rejects_leaf_with_children(self, seed_data):
        """Can't convert to fact/note/reminder if item has children."""
        session_id = _boot_jimmy(seed_data)
        parent = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent"}],
            session_id=session_id,
        )
        parent_id = parent[0]["id"]
        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Child", "parent_id": parent_id}],
            session_id=session_id,
        )
        for leaf_type in ("fact", "note", "reminder"):
            result = convert_item(
                seed_data,
                "jimmy",
                ["jimmy", "household"],
                parent_id,
                leaf_type,
                session_id=session_id,
            )
            assert "error" in result

    def test_convert_preserves_children_and_tags(self, seed_data):
        """Children and tags survive type conversion."""
        session_id = _boot_jimmy(seed_data)
        parent = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent", "tags": ["my_tag"]}],
            session_id=session_id,
        )
        parent_id = parent[0]["id"]
        child = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Child", "parent_id": parent_id}],
            session_id=session_id,
        )
        child_id = child[0]["id"]
        # Convert project to idea (both can have children)
        result = convert_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            parent_id,
            "task",
            session_id=session_id,
        )
        assert result["type"] == "task"
        # Child still exists
        child_row = seed_data.fetchone("SELECT * FROM items WHERE id = ?", (child_id,))
        assert child_row is not None
        # Tag still exists
        tags = seed_data.fetchall("SELECT tag_id FROM item_tags WHERE item_id = ?", (parent_id,))
        assert any(t["tag_id"] == "my_tag" for t in tags)

    def test_convert_resets_status_to_new_type_default(self, seed_data):
        """Converting an item resets status to the new type's default."""
        session_id = _boot_jimmy(seed_data)
        # task → idea: not_started should become active
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "A task", "status": "not_started"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        result = convert_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            "idea",
            session_id=session_id,
        )
        assert result["type"] == "idea"
        assert result["status"] == "active"

    def test_convert_resets_status_active_to_not_started(self, seed_data):
        """Converting from a type with default active to task resets status to not_started."""
        session_id = _boot_jimmy(seed_data)
        # fact → task: active should become not_started
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "fact", "summary": "A fact"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        assert created[0]["status"] == "active"
        result = convert_item(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            "task",
            session_id=session_id,
        )
        assert result["type"] == "task"
        assert result["status"] == "not_started"

    def test_convert_scope_enforcement(self, seed_data):
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Jimmy item"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]
        _boot_alex(seed_data)
        result = convert_item(
            seed_data,
            "alex",
            ["alex", "household"],
            item_id,
            "idea",
        )
        assert "error" in result
