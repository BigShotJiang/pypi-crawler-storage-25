import sqlite3
from pathlib import Path

import pytest

from mimir_mcp.db import init_db
from mimir_mcp.server import run_seed, auto_seed

MIGRATIONS_DIR = Path(__file__).parent.parent / "src" / "mimir_mcp" / "migrations"


def test_seed_loads_sql(tmp_path):
    """Seed command loads SQL file into database."""
    db_path = str(tmp_path / "test.db")

    seed_file = tmp_path / "seed.sql"
    seed_file.write_text(
        "INSERT INTO users (id, name, is_admin, api_key) "
        "VALUES ('testuser', 'Test User', FALSE, 'key-test');\n"
        "INSERT INTO scopes (id, name, description) "
        "VALUES ('testscope', 'Test', 'Test scope');\n"
        "INSERT INTO scope_members (scope_id, user_id) "
        "VALUES ('testscope', 'testuser');\n"
        "INSERT INTO activity_cursor (user_id, last_seen_history_id) "
        "VALUES ('testuser', 0);\n"
    )

    run_seed(db_path, str(seed_file))

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    row = conn.execute("SELECT * FROM users WHERE id = 'testuser'").fetchone()
    assert row is not None
    assert row["name"] == "Test User"
    assert row["api_key"] == "key-test"

    scope_row = conn.execute("SELECT * FROM scope_members WHERE user_id = 'testuser'").fetchone()
    assert scope_row is not None
    assert scope_row["scope_id"] == "testscope"
    conn.close()


def test_seed_nonexistent_file(tmp_path):
    """Seed command raises FileNotFoundError for missing file."""
    db_path = str(tmp_path / "test.db")

    with pytest.raises(FileNotFoundError, match="Seed file not found"):
        run_seed(db_path, str(tmp_path / "nonexistent.sql"))


def test_auto_seed_loads_on_empty_db(tmp_path):
    """auto_seed loads seed file when no users exist."""
    db = init_db(str(tmp_path / "test.db"), MIGRATIONS_DIR)
    seed_file = tmp_path / "seed.sql"
    seed_file.write_text(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES ('testuser', 'Test', FALSE, 'key-test');\n"
        "INSERT INTO scopes (id, name, description) VALUES ('testuser', 'Test', 'Test scope');\n"
        "INSERT INTO scope_members (scope_id, user_id) VALUES ('testuser', 'testuser');\n"
        "INSERT INTO activity_cursor (user_id, last_seen_history_id) VALUES ('testuser', 0);\n"
    )
    auto_seed(db, str(seed_file))
    row = db.fetchone("SELECT * FROM users WHERE id = 'testuser'")
    assert row is not None
    db.close()


def test_auto_seed_skips_when_users_exist(tmp_path):
    """auto_seed is a no-op when users already exist."""
    db = init_db(str(tmp_path / "test.db"), MIGRATIONS_DIR)
    db.execute(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES ('existing', 'Existing', FALSE, 'key-existing')"
    )
    db.commit()
    seed_file = tmp_path / "seed.sql"
    seed_file.write_text(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES ('new', 'New', FALSE, 'key-new');\n"
    )
    auto_seed(db, str(seed_file))
    row = db.fetchone("SELECT * FROM users WHERE id = 'new'")
    assert row is None  # should NOT have been loaded
    db.close()
