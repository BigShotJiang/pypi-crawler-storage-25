"""Tests for navigation & retrieval tools."""

from mimir_mcp.tools.session import boot_session_impl
from mimir_mcp.tools.items import add_items_impl as add_items
from mimir_mcp.tools.navigation import (
    get_details_impl as get_details,
    get_children_impl as get_children,
    get_history_impl as get_history,
    add_note_impl as add_note,
)


# --- Helpers ---


def _boot_jimmy(db):
    """Boot a session for jimmy and return session_id."""
    boot_session_impl(db, "jimmy", ["jimmy", "household"])
    session = db.fetchone("SELECT id FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL")
    return session["id"]


def _boot_alex(db):
    """Boot a session for alex and return session_id."""
    boot_session_impl(db, "alex", ["alex", "household"])
    session = db.fetchone("SELECT id FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL")
    return session["id"]


def _create_project_with_children(db, session_id):
    """Create a project with child tasks and return (project_id, child_ids)."""
    project = add_items(
        db,
        "jimmy",
        ["jimmy", "household"],
        [
            {
                "scope": "jimmy",
                "type": "project",
                "summary": "Test Project",
                "detail": "Detailed project description",
                "priority": "high",
            }
        ],
        session_id=session_id,
    )
    project_id = project[0]["id"]

    children = add_items(
        db,
        "jimmy",
        ["jimmy", "household"],
        [
            {
                "scope": "jimmy",
                "type": "task",
                "summary": "Task Alpha",
                "detail": "Details for Alpha",
                "parent_id": project_id,
            },
            {
                "scope": "jimmy",
                "type": "task",
                "summary": "Task Beta",
                "detail": "Details for Beta",
                "parent_id": project_id,
            },
            {
                "scope": "jimmy",
                "type": "note",
                "summary": "Project note",
                "detail": "Some note details",
                "parent_id": project_id,
            },
        ],
        session_id=session_id,
    )
    child_ids = [c["id"] for c in children]
    return project_id, child_ids


# ============================================================
# get_details tests
# ============================================================


class TestGetDetails:
    def test_get_details(self, seed_data):
        """Returns full L2 detail for requested items."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "task",
                    "summary": "Task One",
                    "detail": "Full details for task one",
                    "priority": "high",
                },
                {
                    "scope": "jimmy",
                    "type": "note",
                    "summary": "Note Two",
                    "detail": "Note details here",
                },
            ],
            session_id=session_id,
        )
        item_ids = [c["id"] for c in created]

        result = get_details(seed_data, "jimmy", ["jimmy", "household"], item_ids)

        assert len(result) == 2
        summaries = {r["summary"] for r in result}
        assert "Task One" in summaries
        assert "Note Two" in summaries
        # Check L2 detail is present
        for item in result:
            assert item["detail"] is not None
            if item["summary"] == "Task One":
                assert item["detail"] == "Full details for task one"
                assert item["priority"] == "high"
                assert item["type"] == "task"

    def test_get_details_scope_filtered(self, seed_data):
        """Only items in user's scopes are returned."""
        session_id = _boot_jimmy(seed_data)
        jimmy_item = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "task",
                    "summary": "Jimmy item",
                    "detail": "Jimmy details",
                }
            ],
            session_id=session_id,
        )

        # Create an item in alex's scope (via direct SQL to bypass scope check)
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, detail, created_by, updated_by) "
            "VALUES ('alex', 'task', 'not_started', 'Alex item', 'Alex details', 'alex', 'alex')"
        )
        seed_data.commit()
        alex_item = seed_data.fetchone("SELECT id FROM items WHERE summary = 'Alex item'")

        # Jimmy requests both items but only has access to jimmy + household
        result = get_details(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [jimmy_item[0]["id"], alex_item["id"]],
        )

        # Only jimmy's item should be returned
        assert len(result) == 1
        assert result[0]["summary"] == "Jimmy item"


# ============================================================
# get_children tests
# ============================================================


class TestGetChildren:
    def test_get_children_by_type(self, seed_data):
        """Children are grouped by type, L1 only by default."""
        session_id = _boot_jimmy(seed_data)
        project_id, child_ids = _create_project_with_children(seed_data, session_id)

        result = get_children(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            project_id,
        )

        assert "task" in result
        assert "note" in result
        assert len(result["task"]) == 2
        assert len(result["note"]) == 1
        # L2 should NOT be included by default
        for task in result["task"]:
            assert "summary" in task
            assert "detail" not in task

    def test_get_children_with_l2(self, seed_data):
        """include_detail=True adds detail to children."""
        session_id = _boot_jimmy(seed_data)
        project_id, child_ids = _create_project_with_children(seed_data, session_id)

        result = get_children(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            project_id,
            include_detail=True,
        )

        assert "task" in result
        for task in result["task"]:
            assert task["detail"] is not None

    def test_get_children_cascade(self, seed_data):
        """cascade=True returns recursive descendants."""
        session_id = _boot_jimmy(seed_data)
        project_id, child_ids = _create_project_with_children(seed_data, session_id)

        # Add grandchild under first child task
        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "task",
                    "summary": "Grandchild task",
                    "parent_id": child_ids[0],
                }
            ],
            session_id=session_id,
        )

        result = get_children(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            project_id,
            cascade=True,
        )

        # Flatten all items across types
        all_items = []
        for items_of_type in result.values():
            all_items.extend(items_of_type)

        # Should include direct children (3) + grandchild (1) = 4
        assert len(all_items) == 4
        summaries = {item["summary"] for item in all_items}
        assert "Grandchild task" in summaries

    def test_get_children_includes_child_counts(self, seed_data):
        """Children include child_count and completed_count for their own children."""
        session_id = _boot_jimmy(seed_data)
        from mimir_mcp.tools.items import complete_items_impl as complete_items

        # project -> task -> 2 subtasks (1 completed)
        project = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent"}],
            session_id=session_id,
        )
        project_id = project[0]["id"]

        task = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Middle Task", "parent_id": project_id}],
            session_id=session_id,
        )
        task_id = task[0]["id"]

        subtasks = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {"scope": "jimmy", "type": "task", "summary": "Sub 1", "parent_id": task_id},
                {"scope": "jimmy", "type": "task", "summary": "Sub 2", "parent_id": task_id},
            ],
            session_id=session_id,
        )

        complete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [subtasks[0]["id"]],
            session_id=session_id,
        )

        result = get_children(seed_data, "jimmy", ["jimmy", "household"], project_id)

        middle = result["task"][0]
        assert middle["summary"] == "Middle Task"
        assert middle["child_count"] == 2
        assert middle["completed_count"] == 1

    def test_get_children_parent_not_found(self, seed_data):
        """Returns error if parent doesn't exist."""
        _boot_jimmy(seed_data)

        result = get_children(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            99999,
        )

        assert "error" in result

    def test_get_children_scope_enforcement(self, seed_data):
        """Can't get children of an item outside user's scopes."""
        session_id = _boot_jimmy(seed_data)

        # Create item in jimmy's scope
        project = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Jimmy project"}],
            session_id=session_id,
        )
        project_id = project[0]["id"]

        # Alex tries to access jimmy's project children
        _boot_alex(seed_data)
        result = get_children(
            seed_data,
            "alex",
            ["alex", "household"],
            project_id,
        )

        assert "error" in result


# ============================================================
# get_history tests
# ============================================================


class TestGetHistory:
    def test_get_history(self, seed_data):
        """Returns history entries for an item."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Tracked task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]

        result = get_history(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
        )

        # Should have at least the 'created' event from add_items
        assert len(result) >= 1
        events = [h["event"] for h in result]
        assert "created" in events

    def test_get_history_with_limit(self, seed_data):
        """Limit parameter restricts number of entries."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Multi-history task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]

        # Add extra history entries
        from mimir_mcp import queries

        for i in range(5):
            queries.history_insert(
                seed_data,
                item_id,
                "context_added",
                f"Context {i}",
                "jimmy",
                session_id=session_id,
            )
        seed_data.commit()

        result = get_history(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            limit=3,
        )

        assert len(result) == 3

    def test_get_history_scope_enforcement(self, seed_data):
        """Can't get history for items outside user's scopes."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Jimmy task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]

        # Alex tries to get history
        _boot_alex(seed_data)
        result = get_history(
            seed_data,
            "alex",
            ["alex", "household"],
            item_id,
        )

        assert "error" in result

    def test_get_history_item_not_found(self, seed_data):
        """Returns error if item doesn't exist."""
        _boot_jimmy(seed_data)

        result = get_history(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            99999,
        )

        assert "error" in result


# ============================================================
# add_note tests
# ============================================================


class TestAddNote:
    def test_add_note(self, seed_data):
        """Creates a context_added history entry."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Task with context"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]

        result = add_note(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_id,
            "Important context note about this task",
            session_id=session_id,
        )

        assert "confirmation" in result

        # Verify the history entry was created
        history = seed_data.fetchall(
            "SELECT * FROM item_history WHERE item_id = ? AND event = 'context_added'",
            (item_id,),
        )
        assert len(history) == 1
        assert history[0]["content"] == "Important context note about this task"
        assert history[0]["actor"] == "jimmy"
        assert history[0]["session_id"] == session_id

    def test_add_note_scope_enforcement(self, seed_data):
        """Can't add context to items outside user's scopes."""
        session_id = _boot_jimmy(seed_data)
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Jimmy task"}],
            session_id=session_id,
        )
        item_id = created[0]["id"]

        # Alex tries to add context
        _boot_alex(seed_data)
        result = add_note(
            seed_data,
            "alex",
            ["alex", "household"],
            item_id,
            "Sneaky context",
        )

        assert "error" in result

    def test_add_note_item_not_found(self, seed_data):
        """Returns error if item doesn't exist."""
        _boot_jimmy(seed_data)

        result = add_note(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            99999,
            "Context for ghost item",
        )

        assert "error" in result


# ============================================================
# Cross-cutting scope enforcement
# ============================================================


class TestScopeEnforcement:
    def test_scope_enforcement_across_all_tools(self, seed_data):
        """Comprehensive test: all navigation tools reject items outside scopes."""
        session_id = _boot_jimmy(seed_data)

        # Create item in jimmy's private scope
        created = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "project",
                    "summary": "Private project",
                    "detail": "Private details",
                }
            ],
            session_id=session_id,
        )
        item_id = created[0]["id"]

        # Boot alex (only alex + household scopes)
        _boot_alex(seed_data)
        alex_scopes = ["alex", "household"]

        # get_details filters out the item
        details = get_details(seed_data, "alex", alex_scopes, [item_id])
        assert len(details) == 0

        # get_children returns error
        children = get_children(seed_data, "alex", alex_scopes, item_id)
        assert "error" in children

        # get_history returns error
        history = get_history(seed_data, "alex", alex_scopes, item_id)
        assert "error" in history

        # add_note returns error
        context = add_note(seed_data, "alex", alex_scopes, item_id, "test")
        assert "error" in context
