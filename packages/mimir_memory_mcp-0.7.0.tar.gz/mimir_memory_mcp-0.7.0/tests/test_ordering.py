"""Tests for item ordering tools."""

from mimir_mcp.tools.session import boot_session_impl
from mimir_mcp.tools.items import add_items_impl as add_items
from mimir_mcp.tools.ordering import reorder_items_impl as reorder_items


def _boot_jimmy(db):
    """Boot a session for jimmy and return session_id."""
    boot_session_impl(db, "jimmy", ["jimmy", "household"])
    session = db.fetchone("SELECT id FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL")
    return session["id"]


def _create_items(db, session_id, count, *, parent_id=None):
    """Create `count` items and return their IDs."""
    items_input = [
        {
            "scope": "jimmy",
            "type": "task",
            "summary": f"Item {i + 1}",
            **({"parent_id": parent_id} if parent_id else {}),
        }
        for i in range(count)
    ]
    results = add_items(
        db,
        "jimmy",
        ["jimmy", "household"],
        items_input,
        session_id=session_id,
    )
    return [r["id"] for r in results]


class TestReorderItems:
    def test_reorder_items(self, seed_data):
        """Positions are updated correctly."""
        session_id = _boot_jimmy(seed_data)
        ids = _create_items(seed_data, session_id, 3)

        entries = [
            {"item_id": ids[0], "position": 3.0},
            {"item_id": ids[1], "position": 1.0},
            {"item_id": ids[2], "position": 2.0},
        ]
        result = reorder_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            entries,
        )
        assert "error" not in result

        # Verify positions in DB
        for entry in entries:
            row = seed_data.fetchone("SELECT position FROM items WHERE id = ?", (entry["item_id"],))
            assert row["position"] == entry["position"]

    def test_reorder_rejects_different_parents(self, seed_data):
        """Items must all share the same parent (or all be top-level)."""
        session_id = _boot_jimmy(seed_data)
        # Create a parent and one child
        parent_result = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent"}],
            session_id=session_id,
        )
        parent_id = parent_result[0]["id"]
        child_ids = _create_items(seed_data, session_id, 1, parent_id=parent_id)
        # Create a top-level item
        top_ids = _create_items(seed_data, session_id, 1)

        # Try to reorder a child and a top-level item together
        entries = [
            {"item_id": child_ids[0], "position": 1.0},
            {"item_id": top_ids[0], "position": 2.0},
        ]
        result = reorder_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            entries,
        )
        assert "error" in result

    def test_reorder_normalizes_positions(self, seed_data):
        """When gap < 0.001, sibling positions are normalized to integers."""
        session_id = _boot_jimmy(seed_data)
        ids = _create_items(seed_data, session_id, 3)

        # Set positions very close together (gap < 0.001)
        entries = [
            {"item_id": ids[0], "position": 1.0},
            {"item_id": ids[1], "position": 1.0005},
            {"item_id": ids[2], "position": 1.001},
        ]
        result = reorder_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            entries,
        )
        assert "error" not in result

        # After normalization, positions should be 1.0, 2.0, 3.0
        rows = seed_data.fetchall(
            "SELECT id, position FROM items WHERE id IN (?, ?, ?) ORDER BY position",
            tuple(ids),
        )
        positions = [r["position"] for r in rows]
        assert positions == [1.0, 2.0, 3.0]

    def test_reorder_scope_enforcement(self, seed_data):
        """Cannot reorder items outside your scopes."""
        session_id = _boot_jimmy(seed_data)
        ids = _create_items(seed_data, session_id, 2)

        # Alex tries to reorder jimmy's items
        entries = [
            {"item_id": ids[0], "position": 2.0},
            {"item_id": ids[1], "position": 1.0},
        ]
        result = reorder_items(
            seed_data,
            "alex",
            ["alex", "household"],
            entries,
        )
        assert "error" in result

    def test_reorder_nonexistent_item(self, seed_data):
        """Returns error if an item does not exist."""
        entries = [
            {"item_id": 99999, "position": 1.0},
        ]
        result = reorder_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            entries,
        )
        assert "error" in result
