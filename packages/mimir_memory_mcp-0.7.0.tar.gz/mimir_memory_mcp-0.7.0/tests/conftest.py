import pytest
from pathlib import Path

from mimir_mcp.db import init_db


MIGRATIONS_DIR = Path(__file__).parent.parent / "src" / "mimir_mcp" / "migrations"

# ── Test constants ──────────────────────────────────────────────────────
TEST_USER_ADMIN = "jimmy"
TEST_USER_REGULAR = "alex"
TEST_API_KEY_ADMIN = "key-jimmy"
TEST_API_KEY_REGULAR = "key-alex"
TEST_SCOPE_PERSONAL_ADMIN = "jimmy"
TEST_SCOPE_PERSONAL_REGULAR = "alex"
TEST_SCOPE_SHARED = "household"


@pytest.fixture
def db(tmp_path):
    """Fresh database with schema applied. No seed data."""
    database = init_db(str(tmp_path / "test.db"), MIGRATIONS_DIR)
    yield database
    database.close()


@pytest.fixture
def initialized_db(db, monkeypatch):
    """Sets the module-level _db so get_db() works in tested code."""
    import mimir_mcp.db as db_module

    monkeypatch.setattr(db_module, "_db", db)
    return db


@pytest.fixture
def seed_data(db):
    """Seed standard test users, scopes, and memberships.

    Users: jimmy (admin), alex (regular)
    Scopes: jimmy (personal), alex (personal), household (shared)
    Both users are members of household.
    """
    db.execute(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES (?, ?, ?, ?)",
        (TEST_USER_ADMIN, "Jimmy", True, TEST_API_KEY_ADMIN),
    )
    db.execute(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES (?, ?, ?, ?)",
        (TEST_USER_REGULAR, "Alex", False, TEST_API_KEY_REGULAR),
    )
    db.execute(
        "INSERT INTO scopes VALUES (?, ?, ?)",
        (TEST_SCOPE_PERSONAL_ADMIN, "Jimmy", "Jimmy personal"),
    )
    db.execute(
        "INSERT INTO scopes VALUES (?, ?, ?)",
        (TEST_SCOPE_PERSONAL_REGULAR, "Alex", "Alex personal"),
    )
    db.execute(
        "INSERT INTO scopes VALUES (?, ?, ?)",
        (TEST_SCOPE_SHARED, "Household", "Shared household tasks"),
    )
    db.execute(
        "INSERT INTO scope_members VALUES (?, ?)", (TEST_SCOPE_PERSONAL_ADMIN, TEST_USER_ADMIN)
    )
    db.execute(
        "INSERT INTO scope_members VALUES (?, ?)", (TEST_SCOPE_PERSONAL_REGULAR, TEST_USER_REGULAR)
    )
    db.execute("INSERT INTO scope_members VALUES (?, ?)", (TEST_SCOPE_SHARED, TEST_USER_ADMIN))
    db.execute("INSERT INTO scope_members VALUES (?, ?)", (TEST_SCOPE_SHARED, TEST_USER_REGULAR))
    db.execute("INSERT INTO activity_cursor VALUES (?, ?)", (TEST_USER_ADMIN, 0))
    db.execute("INSERT INTO activity_cursor VALUES (?, ?)", (TEST_USER_REGULAR, 0))
    db.commit()
    return db
