"""Tests for scope management tools."""

from mimir_mcp.tools.scopes import (
    list_scopes_impl as list_scopes,
    create_scope_impl as create_scope,
    add_scope_member_impl as add_scope_member,
    remove_scope_member_impl as remove_scope_member,
)


class TestListScopes:
    def test_list_scopes(self, db, seed_data):
        """Returns caller's scopes with member info."""
        result = list_scopes(db, "jimmy")
        ids = {s["id"] for s in result}
        assert "jimmy" in ids
        assert "household" in ids
        # jimmy should NOT see alex's personal scope
        assert "alex" not in ids

    def test_list_scopes_other_user(self, db, seed_data):
        """Each user sees only their own scopes."""
        result = list_scopes(db, "alex")
        ids = {s["id"] for s in result}
        assert "alex" in ids
        assert "household" in ids
        assert "jimmy" not in ids

    def test_list_scopes_includes_members(self, db, seed_data):
        """Household scope shows both members."""
        result = list_scopes(db, "jimmy")
        household = next(s for s in result if s["id"] == "household")
        assert "jimmy" in household["members"]
        assert "alex" in household["members"]


class TestCreateScope:
    def test_create_scope(self, db, seed_data):
        """Admin creates scope and is added as first member."""
        result = create_scope(db, "jimmy", True, "work", "Work")
        assert result["id"] == "work"
        assert result["name"] == "Work"

        # Creator should be a member
        row = db.fetchone(
            "SELECT * FROM scope_members WHERE scope_id = ? AND user_id = ?",
            ("work", "jimmy"),
        )
        assert row is not None

    def test_create_scope_with_description(self, db, seed_data):
        """Scope created with optional description."""
        result = create_scope(db, "jimmy", True, "work", "Work", description="Work projects")
        assert result["description"] == "Work projects"

    def test_create_scope_non_admin_rejected(self, db, seed_data):
        """Non-admin cannot create scopes."""
        result = create_scope(db, "alex", False, "work", "Work")
        assert "error" in result

        # Scope should NOT have been created
        row = db.fetchone("SELECT * FROM scopes WHERE id = ?", ("work",))
        assert row is None

    def test_create_scope_duplicate_rejected(self, db, seed_data):
        """Duplicate scope_id fails gracefully."""
        # 'jimmy' scope already exists from seed_data
        result = create_scope(db, "jimmy", True, "jimmy", "Jimmy Duplicate")
        assert "error" in result


class TestAddScopeMember:
    def test_add_scope_member(self, db, seed_data):
        """Adds a user to an existing scope."""
        # Create a new scope first, then add alex
        create_scope(db, "jimmy", True, "work", "Work")
        result = add_scope_member(db, "jimmy", True, "work", "alex")
        assert "error" not in result

        # Verify membership
        row = db.fetchone(
            "SELECT * FROM scope_members WHERE scope_id = ? AND user_id = ?",
            ("work", "alex"),
        )
        assert row is not None

    def test_add_scope_member_creates_activity_cursor(self, db, seed_data):
        """Adding a member creates their activity_cursor if missing."""
        # Insert a new user without an activity_cursor
        db.execute(
            "INSERT INTO users (id, name, is_admin, api_key) VALUES (?, ?, ?, ?)",
            ("bob", "Bob", False, "key-bob"),
        )
        db.commit()

        create_scope(db, "jimmy", True, "work", "Work")
        add_scope_member(db, "jimmy", True, "work", "bob")

        cursor_row = db.fetchone("SELECT * FROM activity_cursor WHERE user_id = ?", ("bob",))
        assert cursor_row is not None
        assert cursor_row["last_seen_history_id"] == 0

    def test_add_scope_member_non_admin_rejected(self, db, seed_data):
        """Non-admin cannot add members."""
        result = add_scope_member(db, "alex", False, "household", "jimmy")
        assert "error" in result

    def test_add_scope_member_invalid_scope(self, db, seed_data):
        """Adding member to non-existent scope fails."""
        result = add_scope_member(db, "jimmy", True, "nonexistent", "alex")
        assert "error" in result


class TestRemoveScopeMember:
    def test_remove_scope_member(self, db, seed_data):
        """Removes a user from a scope."""
        # Verify alex is currently in household
        row = db.fetchone(
            "SELECT * FROM scope_members WHERE scope_id = ? AND user_id = ?",
            ("household", "alex"),
        )
        assert row is not None

        result = remove_scope_member(db, "jimmy", True, "household", "alex")
        assert "error" not in result

        # Verify membership removed
        row = db.fetchone(
            "SELECT * FROM scope_members WHERE scope_id = ? AND user_id = ?",
            ("household", "alex"),
        )
        assert row is None

    def test_remove_scope_member_items_remain(self, db, seed_data):
        """Removing a member preserves their items in the scope."""
        # Alex creates an item in the household scope
        db.execute(
            "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("household", "task", "not_started", "Buy groceries", "alex", "alex"),
        )
        db.commit()
        item = db.fetchone(
            "SELECT * FROM items WHERE scope = ? AND created_by = ?",
            ("household", "alex"),
        )
        assert item is not None
        item_id = item["id"]

        # Remove alex from household
        remove_scope_member(db, "jimmy", True, "household", "alex")

        # Item should still exist
        item_after = db.fetchone("SELECT * FROM items WHERE id = ?", (item_id,))
        assert item_after is not None
        assert item_after["summary"] == "Buy groceries"

    def test_remove_scope_member_non_admin_rejected(self, db, seed_data):
        """Non-admin cannot remove members."""
        result = remove_scope_member(db, "alex", False, "household", "jimmy")
        assert "error" in result

        # Membership should still exist
        row = db.fetchone(
            "SELECT * FROM scope_members WHERE scope_id = ? AND user_id = ?",
            ("household", "jimmy"),
        )
        assert row is not None
