"""Integration tests: full workflows exercising multiple tool modules together."""

from mimir_mcp.tools.session import boot_session_impl, end_session_impl as end_session
from mimir_mcp.tools.items import add_items_impl as add_items, complete_items_impl as complete_items
from mimir_mcp.tools.context import set_context_impl as set_context
from mimir_mcp.tools.search import search_items_impl as search_items
from mimir_mcp.tools.navigation import get_details_impl as get_details


def test_full_workflow(seed_data):
    """Boot -> create items -> focus -> update -> complete -> search -> end."""
    db = seed_data

    # Boot as jimmy
    boot = boot_session_impl(db, "jimmy", ["jimmy", "household"])
    assert boot["stale_sessions"] == 0
    assert len(boot["scopes"]) >= 2

    # Create a project with tasks
    created_projects = add_items(
        db,
        "jimmy",
        ["jimmy", "household"],
        [
            {
                "scope": "household",
                "type": "project",
                "summary": "Kitchen renovation",
            }
        ],
    )
    assert len(created_projects) == 1
    project_id = created_projects[0]["id"]

    created_tasks = add_items(
        db,
        "jimmy",
        ["jimmy", "household"],
        [
            {
                "scope": "household",
                "type": "task",
                "summary": "Get contractor quotes",
                "parent_id": project_id,
                "priority": "high",
            },
            {
                "scope": "household",
                "type": "task",
                "summary": "Choose paint colors",
                "parent_id": project_id,
            },
        ],
    )
    assert len(created_tasks) == 2

    # Focus on project
    ctx = set_context(db, "jimmy", ["jimmy", "household"], item_id=project_id)
    assert ctx["item"]["summary"] == "Kitchen renovation"
    assert len(ctx["children"]["task"]) == 2

    # Complete a task
    task_id = created_tasks[0]["id"]
    complete_items(db, "jimmy", ["jimmy", "household"], [task_id])
    details = get_details(db, "jimmy", ["jimmy", "household"], [task_id])
    assert len(details) == 1
    assert details[0]["status"] == "completed"

    # Search
    results = search_items(db, "jimmy", ["jimmy", "household"], query="kitchen")
    assert len(results) >= 1

    # Create a fact
    add_items(
        db,
        "jimmy",
        ["jimmy", "household"],
        [
            {
                "scope": "household",
                "type": "fact",
                "summary": "Kitchen is 4m x 3m",
                "source": "user_stated",
            }
        ],
    )

    # End session with learnings
    result = end_session(
        db,
        "jimmy",
        learnings=["Contractor A is cheapest but slow"],
    )
    assert "summary" in result

    # Verify learning was saved as fact
    fact = db.fetchone("SELECT * FROM items WHERE source = 'learned' AND type = 'fact'")
    assert fact is not None


def test_scope_isolation(seed_data):
    """Jimmy can't see Alex's personal items."""
    db = seed_data

    # Alex creates a personal item (boot first so there's a session)
    boot_session_impl(db, "alex", ["alex", "household"])
    add_items(
        db,
        "alex",
        ["alex", "household"],
        [
            {
                "scope": "alex",
                "type": "task",
                "summary": "Alex private task",
            }
        ],
    )
    end_session(db, "alex")

    # Jimmy boots -- should not see Alex's personal task
    boot = boot_session_impl(db, "jimmy", ["jimmy", "household"])
    all_summaries = [t["summary"] for t in boot["tasks"]]
    assert "Alex private task" not in all_summaries

    # Jimmy searches -- should not find it
    results = search_items(db, "jimmy", ["jimmy", "household"], query="Alex private")
    assert len(results) == 0


def test_shared_activity_visibility(seed_data):
    """Alex sees Jimmy's shared-scope changes."""
    db = seed_data

    # Jimmy boots and creates a shared item
    boot_session_impl(db, "jimmy", ["jimmy", "household"])
    add_items(
        db,
        "jimmy",
        ["jimmy", "household"],
        [
            {
                "scope": "household",
                "type": "task",
                "summary": "New code version ready for testing",
            }
        ],
    )
    end_session(db, "jimmy")

    # Alex boots -- should see Jimmy's shared activity
    boot = boot_session_impl(db, "alex", ["alex", "household"])
    activity_summaries = [a["summary"] for a in boot["recent_shared_activity"]]
    assert "New code version ready for testing" in activity_summaries
