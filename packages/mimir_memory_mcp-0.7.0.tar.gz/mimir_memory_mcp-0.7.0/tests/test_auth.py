from mimir_mcp.auth import (
    get_current_user,
    get_current_scopes,
    is_admin,
    resolve_user,
    set_auth_context,
)


def test_resolve_user_valid_key(seed_data):
    user_id, scopes, admin = resolve_user(seed_data, "key-jimmy")
    assert user_id == "jimmy"
    assert "jimmy" in scopes
    assert "household" in scopes
    assert "alex" not in scopes
    assert admin is True


def test_resolve_user_invalid_key(seed_data):
    result = resolve_user(seed_data, "invalid-key")
    assert result is None


def test_resolve_user_non_admin(seed_data):
    user_id, scopes, admin = resolve_user(seed_data, "key-alex")
    assert user_id == "alex"
    assert "alex" in scopes
    assert "household" in scopes
    assert "jimmy" not in scopes
    assert admin is False


def test_set_and_get_auth_context():
    set_auth_context("jimmy", ["jimmy", "household"], is_admin=True)
    assert get_current_user() == "jimmy"
    assert get_current_scopes() == ["jimmy", "household"]
    assert is_admin() is True


def test_auth_context_overwrite():
    set_auth_context("jimmy", ["jimmy"], is_admin=True)
    assert get_current_user() == "jimmy"
    set_auth_context("alex", ["alex", "household"], is_admin=False)
    assert get_current_user() == "alex"
    assert is_admin() is False
