# Mimir — Future Phase Backlog

Items deferred from the Hooks & Observability spec (2026-04-06). To be picked up after hooks implementation is stable.

---

## Langfuse Observability

Add Langfuse as a Docker service for LLM observability. Deploys on hermes-net alongside Mimir.

**What to track:**
- Tokens per hook invocation (estimated from payload sizes)
- Context injection volume per session (additionalContext string length)
- Mimir REST call latency and frequency
- PostToolUse call frequency and capture volume
- Mimir-enabled vs file-only session comparison (A/B)
- Hook failure rates and graceful degradation frequency
- UserPromptSubmit search hit rate (injection vs empty results)
- Session completeness (clean /end vs dirty SessionEnd fallback)
- PreCompact checkpoint success rate

**Integration:**
- Mimir side: Python Langfuse SDK, trace decorator on REST endpoints
- Hook side: curl to Langfuse ingestion API (fire-and-forget)
- Docker Compose: langfuse + postgres services on hermes-net

**Preferred platform:** Langfuse (over MLflow — purpose-built for LLM observability, self-hostable, native token/cost tracking)

---

## Vector Search

Add semantic search to Mimir for fuzzy queries ("how did we handle X?").

**Phase 1:** SQLite FTS5 on item summaries and details. No new dependencies.
**Phase 2:** Evaluate ChromaDB if FTS5 proves insufficient. Adds vector embeddings for similarity-based retrieval.

**Motivation:** Keyword search misses semantic matches. The UserPromptSubmit hook injects relevant memory per prompt — better search = better injection quality.

---

## Progressive Disclosure

Add a "compact" mode to `refresh_context` that returns item summaries without full details. Saves ~10x tokens when context budget is tight (post-compaction). Claude drills down with `get_details` when needed.

Inspired by claude-mem's 3-layer search pattern: search (index) → timeline (context) → get_observations (full details).

---

## Privacy Controls

Add `<private>` tag convention:
- Content wrapped in `<private>` tags is excluded from PostToolUse capture and UserPromptSubmit injection
- Mimir items with tag `private` are excluded from search results returned to hooks
- Scope-based privacy already exists (personal vs shared scopes); this adds content-level privacy

---

## Metrics & Cost Analysis

Fully logged token metrics to evaluate hook ROI:
- How much does PostToolUse cost in tokens (payload sizes)?
- How many tokens does context injection consume per session?
- How much does Mimir save vs file-only mode?
- What's the hook overhead vs the value it provides?

Build dashboards (via Langfuse) for cost/value analysis once observability is in place.
