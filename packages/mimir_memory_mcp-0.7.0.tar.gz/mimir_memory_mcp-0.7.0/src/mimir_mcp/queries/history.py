"""Domain queries — history insert/query."""

from __future__ import annotations

import json
from mimir_mcp.db import Database


def history_insert(
    db: Database,
    item_id: int,
    event: str,
    content,
    actor: str,
    *,
    session_id: int | None = None,
    correlation_id: str | None = None,
):
    """Insert a history entry. Content should be a list of diffs or a string."""
    content_str = json.dumps(content) if isinstance(content, (list, dict)) else content
    db.execute(
        "INSERT INTO item_history (item_id, event, content, actor, session_id, correlation_id) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (item_id, event, content_str, actor, session_id, correlation_id),
    )


def history_for_item(db: Database, item_id: int, *, since=None, until=None, limit=50):
    sql = "SELECT * FROM item_history WHERE item_id = ?"
    params = [item_id]
    if since:
        sql += " AND created_at >= ?"
        params.append(since)
    if until:
        sql += " AND created_at <= ?"
        params.append(until)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    return db.fetchall(sql, tuple(params))
