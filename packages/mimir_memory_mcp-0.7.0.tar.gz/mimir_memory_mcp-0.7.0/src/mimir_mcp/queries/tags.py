"""Domain queries — tag operations."""

from __future__ import annotations

from mimir_mcp.db import Database


def tags_in_use(db: Database, scopes: list[str]) -> dict[str, list[str]]:
    """Return tags currently in use, grouped by scope.

    Includes tags from items in all statuses (completed, archived, etc.)
    because historical tags are useful for consistent naming.
    """
    if not scopes:
        return {}
    sp = ",".join("?" for _ in scopes)
    rows = db.fetchall(
        f"SELECT DISTINCT i.scope, it.tag_id "
        f"FROM item_tags it "
        f"JOIN items i ON it.item_id = i.id "
        f"WHERE i.scope IN ({sp}) "
        f"ORDER BY i.scope, it.tag_id",
        tuple(scopes),
    )
    result: dict[str, list[str]] = {}
    for row in rows:
        result.setdefault(row["scope"], []).append(row["tag_id"])
    return result
