"""Domain queries — session lifecycle, activity cursor, users, scopes."""

from __future__ import annotations

from mimir_mcp.db import Database


def sessions_close_stale(db: Database, user_id: str) -> int:
    """Close stale sessions, return count closed."""
    stale = db.fetchall(
        "SELECT id FROM sessions WHERE user_id = ? AND ended_at IS NULL",
        (user_id,),
    )
    if stale:
        ids = [s["id"] for s in stale]
        placeholders = ",".join("?" for _ in ids)
        db.execute(
            f"UPDATE sessions SET ended_at = datetime('now'), summary = 'Auto-closed' "
            f"WHERE id IN ({placeholders})",
            tuple(ids),
        )
    return len(stale)


def sessions_create(db: Database, user_id: str) -> int:
    cursor = db.execute("INSERT INTO sessions (user_id) VALUES (?)", (user_id,))
    return cursor.lastrowid


def sessions_get_last_completed(db: Database, user_id: str):
    return db.fetchone(
        "SELECT * FROM sessions WHERE user_id = ? AND ended_at IS NOT NULL "
        "ORDER BY ended_at DESC LIMIT 1",
        (user_id,),
    )


def sessions_get_active(db: Database, user_id: str):
    return db.fetchone(
        "SELECT * FROM sessions WHERE user_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1",
        (user_id,),
    )


def sessions_end(db: Database, session_id: int, summary: str):
    db.execute(
        "UPDATE sessions SET ended_at = datetime('now'), summary = ? WHERE id = ?",
        (summary, session_id),
    )


def sessions_update_context(db: Database, session_id: int, item_id: int | None):
    """Update active_context_id on a session (NULL to clear)."""
    db.execute(
        "UPDATE sessions SET active_context_id = ? WHERE id = ?",
        (item_id, session_id),
    )


def items_session_activity(db: Database, session_id: int):
    """Items created or updated during this session (via history entries)."""
    return db.fetchall(
        "SELECT DISTINCT h.item_id, h.event, h.created_at, i.summary, i.type, i.scope "
        "FROM item_history h "
        "JOIN items i ON h.item_id = i.id "
        "WHERE h.session_id = ? "
        "ORDER BY h.created_at DESC",
        (session_id,),
    )


def activity_get_shared(db: Database, user_id: str, scopes: list[str]):
    """Get shared activity since user's cursor."""
    cursor = db.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = ?",
        (user_id,),
    )
    cursor_id = cursor["last_seen_history_id"] if cursor else 0
    sp = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT h.*, i.summary, i.scope FROM item_history h "
        f"JOIN items i ON h.item_id = i.id "
        f"WHERE h.id > ? AND h.actor != ? AND i.scope IN ({sp}) "
        f"ORDER BY h.created_at DESC LIMIT 50",
        (cursor_id, user_id, *scopes),
    )


def activity_advance_cursor(db: Database, user_id: str):
    """Advance cursor to the max of item_history IDs and item IDs."""
    max_history = db.fetchone("SELECT MAX(id) as m FROM item_history")
    max_item = db.fetchone("SELECT MAX(id) as m FROM items")
    h_id = max_history["m"] if max_history and max_history["m"] else 0
    i_id = max_item["m"] if max_item and max_item["m"] else 0
    new_cursor = max(h_id, i_id)
    db.execute(
        "UPDATE activity_cursor SET last_seen_history_id = ? WHERE user_id = ?",
        (new_cursor, user_id),
    )


def users_get(db: Database, user_id: str):
    return db.fetchone("SELECT * FROM users WHERE id = ?", (user_id,))


def scopes_for_user(db: Database, user_id: str) -> list:
    return db.fetchall(
        "SELECT s.*, GROUP_CONCAT(DISTINCT sm2.user_id) as member_ids "
        "FROM scopes s "
        "JOIN scope_members sm ON s.id = sm.scope_id "
        "JOIN scope_members sm2 ON s.id = sm2.scope_id "
        "WHERE sm.user_id = ? GROUP BY s.id",
        (user_id,),
    )
