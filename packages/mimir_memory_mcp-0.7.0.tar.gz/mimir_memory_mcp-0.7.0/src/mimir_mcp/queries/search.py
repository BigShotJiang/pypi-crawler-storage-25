"""Domain queries — FTS5 search."""

from __future__ import annotations

from mimir_mcp.db import Database


def search_fts(db: Database, query: str, scopes: list[str], **filters):
    """FTS5 search with scope + optional type/status/tag filters."""
    sp = ",".join("?" for _ in scopes)
    sql = (
        f"SELECT i.*, rank, GROUP_CONCAT(it.tag_id) as tags "
        f"FROM items_fts fts "
        f"JOIN items i ON fts.rowid = i.id "
        f"LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE items_fts MATCH ? AND i.scope IN ({sp}) "
    )
    params = [query, *scopes]
    if filters.get("type"):
        sql += "AND i.type = ? "
        params.append(filters["type"])
    if filters.get("status"):
        sql += "AND i.status = ? "
        params.append(filters["status"])
    else:
        sql += "AND i.status NOT IN ('completed', 'archived', 'deleted') "
    sql += "GROUP BY i.id ORDER BY rank LIMIT 50"
    return db.fetchall(sql, tuple(params))
