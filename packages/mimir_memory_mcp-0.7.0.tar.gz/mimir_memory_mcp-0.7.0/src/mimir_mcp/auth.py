from __future__ import annotations

from contextvars import ContextVar

from mimir_mcp.db import Database

_current_user_id: ContextVar[str] = ContextVar("current_user_id")
_current_user_scopes: ContextVar[list[str]] = ContextVar("current_user_scopes")
_current_user_is_admin: ContextVar[bool] = ContextVar("current_user_is_admin")


def get_current_user() -> str:
    return _current_user_id.get()


def get_current_scopes() -> list[str]:
    return _current_user_scopes.get()


def is_admin() -> bool:
    return _current_user_is_admin.get()


def set_auth_context(user_id: str, scopes: list[str], *, is_admin: bool = False) -> None:
    _current_user_id.set(user_id)
    _current_user_scopes.set(scopes)
    _current_user_is_admin.set(is_admin)


def resolve_user(db: Database, api_key: str) -> tuple[str, list[str], bool] | None:
    user = db.fetchone("SELECT id, is_admin FROM users WHERE api_key = ?", (api_key,))
    if not user:
        return None
    scopes = [
        row["scope_id"]
        for row in db.fetchall(
            "SELECT scope_id FROM scope_members WHERE user_id = ?", (user["id"],)
        )
    ]
    return user["id"], scopes, bool(user["is_admin"])
