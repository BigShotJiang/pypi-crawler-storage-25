from __future__ import annotations

import sqlite3
from pathlib import Path

# Module-level database singleton. This is not thread-safe for concurrent
# writes, but SQLite WAL mode serializes writes internally. Concurrent
# reads (from MCP + REST) are safe. If Mimir ever needs true concurrent
# write support, replace with connection-per-request pattern.
_db: Database | None = None


class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        return self.conn.execute(sql, params)

    def executemany(self, sql: str, params_seq) -> sqlite3.Cursor:
        return self.conn.executemany(sql, params_seq)

    def fetchone(self, sql: str, params: tuple = ()) -> sqlite3.Row | None:
        return self.conn.execute(sql, params).fetchone()

    def fetchall(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        return self.conn.execute(sql, params).fetchall()

    def fetchall_dict(self, sql: str, params: tuple = ()) -> list[dict]:
        """Fetch all rows as dicts."""
        return [dict(row) for row in self.conn.execute(sql, params).fetchall()]

    def fetchone_dict(self, sql: str, params: tuple = ()) -> dict | None:
        """Fetch one row as dict, or None."""
        row = self.conn.execute(sql, params).fetchone()
        return dict(row) if row else None

    def commit(self):
        self.conn.commit()

    def close(self):
        self.conn.close()

    def get_schema_version(self) -> int:
        try:
            row = self.fetchone("SELECT MAX(version) as v FROM schema_version")
            return row["v"] if row and row["v"] else 0
        except sqlite3.OperationalError:
            return 0

    def run_migrations(self, migrations_dir: Path | None = None):
        if migrations_dir is None:
            migrations_dir = Path(__file__).parent / "migrations"
        current = self.get_schema_version()
        migration_files = sorted(migrations_dir.glob("*.sql"))
        for f in migration_files:
            version = int(f.name.split("_")[0])
            if version > current:
                self.conn.executescript(f.read_text())
                # Runner owns version tracking so migration scripts don't have to
                self.conn.execute(
                    "INSERT OR IGNORE INTO schema_version (version) VALUES (?)",
                    (version,),
                )
                self.commit()


def get_db() -> Database:
    if _db is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    return _db


def init_db(db_path: str, migrations_dir: Path | None = None) -> Database:
    global _db
    _db = Database(db_path)
    _db.run_migrations(migrations_dir)
    # Re-assert after migrations (executescript may reset connection state)
    _db.conn.execute("PRAGMA foreign_keys = ON")
    return _db
