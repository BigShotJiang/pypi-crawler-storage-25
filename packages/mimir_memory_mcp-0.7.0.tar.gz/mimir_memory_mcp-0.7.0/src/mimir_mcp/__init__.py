"""Mimir — structured memory MCP server for AI assistants."""

__version__ = "0.4.0"

from mimir_mcp.server import create_server

__all__ = ["create_server", "__version__"]
