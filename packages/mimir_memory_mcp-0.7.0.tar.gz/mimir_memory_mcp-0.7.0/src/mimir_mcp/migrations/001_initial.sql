-- 001_initial.sql
-- Multi-user AI assistant platform schema

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- Access control
CREATE TABLE scopes (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT
);

CREATE TABLE users (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    profile     TEXT,
    is_admin    BOOLEAN DEFAULT FALSE,
    api_key     TEXT UNIQUE NOT NULL
);

CREATE TABLE scope_members (
    scope_id    TEXT REFERENCES scopes(id) ON DELETE CASCADE,
    user_id     TEXT REFERENCES users(id) ON DELETE CASCADE,
    PRIMARY KEY (scope_id, user_id)
);

-- Core items
CREATE TABLE items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    parent_id   INTEGER REFERENCES items(id) ON DELETE CASCADE,
    scope       TEXT NOT NULL REFERENCES scopes(id),
    type        TEXT NOT NULL CHECK (type IN ('task','project','fact','reminder','note','idea')),
    status      TEXT NOT NULL DEFAULT 'not_started'
                CHECK (status IN ('not_started','in_progress','blocked','completed','archived','active','expired','deleted')),
    priority    TEXT DEFAULT 'normal' CHECK (priority IN ('urgent','high','normal','low')),
    position    REAL,
    summary     TEXT NOT NULL,
    detail      TEXT,
    source      TEXT CHECK (source IN ('learned','user_stated','documented')),
    due_date    TEXT,
    valid_until TEXT,
    created_by  TEXT NOT NULL REFERENCES users(id),
    updated_by  TEXT NOT NULL REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    metadata    TEXT
);

-- Sessions (defined before item_history so the FK reference resolves)
CREATE TABLE sessions (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             TEXT NOT NULL REFERENCES users(id),
    active_context_id   INTEGER REFERENCES items(id),
    started_at          TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at            TEXT,
    summary             TEXT,
    log_path            TEXT
);

-- History (L3) — content stores structured JSON diffs, not free-text
-- Example: [{"field": "priority", "old": "normal", "new": "high"}]
CREATE TABLE item_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id         INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    event           TEXT NOT NULL CHECK (event IN (
                        'created','updated','status_changed','context_added','completed','converted','deleted'
                    )),
    content         TEXT NOT NULL,
    actor           TEXT,
    session_id      INTEGER REFERENCES sessions(id),
    correlation_id  TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Tags
CREATE TABLE tags (
    id          TEXT PRIMARY KEY,
    aliases     TEXT,
    category    TEXT
);

CREATE TABLE item_tags (
    item_id     INTEGER REFERENCES items(id) ON DELETE CASCADE,
    tag_id      TEXT NOT NULL,
    PRIMARY KEY (item_id, tag_id)
);

-- Shared activity tracking
CREATE TABLE activity_cursor (
    user_id                 TEXT PRIMARY KEY REFERENCES users(id),
    last_seen_history_id    INTEGER DEFAULT 0
);

-- Schema version tracking
CREATE TABLE schema_version (
    version     INTEGER PRIMARY KEY,
    applied_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Full-text search
CREATE VIRTUAL TABLE items_fts USING fts5(
    summary, detail, content='items', content_rowid='id',
    tokenize='porter unicode61'
);

CREATE TRIGGER items_fts_insert AFTER INSERT ON items BEGIN
    INSERT INTO items_fts(rowid, summary, detail)
        VALUES (NEW.id, NEW.summary, NEW.detail);
END;

CREATE TRIGGER items_fts_update AFTER UPDATE OF summary, detail ON items BEGIN
    INSERT INTO items_fts(items_fts, rowid, summary, detail)
        VALUES ('delete', OLD.id, OLD.summary, OLD.detail);
    INSERT INTO items_fts(rowid, summary, detail)
        VALUES (NEW.id, NEW.summary, NEW.detail);
END;

CREATE TRIGGER items_fts_delete AFTER DELETE ON items BEGIN
    INSERT INTO items_fts(items_fts, rowid, summary, detail)
        VALUES ('delete', OLD.id, OLD.summary, OLD.detail);
END;

-- Auto-maintained timestamps (WHEN guard prevents recursive trigger firing)
CREATE TRIGGER items_updated_at AFTER UPDATE ON items
WHEN NEW.updated_at = OLD.updated_at
BEGIN
    UPDATE items SET updated_at = datetime('now') WHERE id = NEW.id;
END;

-- Access enforcement triggers
CREATE TRIGGER enforce_insert_access
BEFORE INSERT ON items
BEGIN
    SELECT CASE
        WHEN NEW.scope NOT IN (
            SELECT scope_id FROM scope_members WHERE user_id = NEW.created_by
        )
        THEN RAISE(ABORT, 'User does not have access to this scope')
    END;
    SELECT CASE
        WHEN NEW.parent_id IS NOT NULL
            AND NEW.scope != (SELECT scope FROM items WHERE id = NEW.parent_id)
        THEN RAISE(ABORT, 'Child item must belong to same scope as parent')
    END;
    SELECT CASE
        WHEN NEW.parent_id IS NOT NULL
            AND (SELECT scope FROM items WHERE id = NEW.parent_id) NOT IN (
                SELECT scope_id FROM scope_members WHERE user_id = NEW.created_by
            )
        THEN RAISE(ABORT, 'User does not have access to parent item')
    END;
END;

CREATE TRIGGER enforce_update_access
BEFORE UPDATE ON items
BEGIN
    SELECT CASE
        WHEN OLD.scope NOT IN (
            SELECT scope_id FROM scope_members WHERE user_id = NEW.updated_by
        )
        THEN RAISE(ABORT, 'User does not have access to this item')
    END;
    SELECT CASE
        WHEN NEW.scope != OLD.scope
            AND NEW.scope NOT IN (
                SELECT scope_id FROM scope_members WHERE user_id = NEW.updated_by
            )
        THEN RAISE(ABORT, 'User does not have access to target scope')
    END;
END;

-- Indexes
CREATE INDEX idx_items_scope_parent_status ON items(scope, parent_id, status, type);
CREATE INDEX idx_items_parent ON items(parent_id);
CREATE INDEX idx_item_history_item_date ON item_history(item_id, created_at);
CREATE INDEX idx_item_history_session ON item_history(session_id);
CREATE INDEX idx_scope_members_user ON scope_members(user_id);
CREATE INDEX idx_item_tags_tag ON item_tags(tag_id);
CREATE INDEX idx_sessions_user ON sessions(user_id, ended_at);

INSERT INTO schema_version (version) VALUES (1);
