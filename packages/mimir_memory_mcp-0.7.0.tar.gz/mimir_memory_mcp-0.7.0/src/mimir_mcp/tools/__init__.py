from mimir_mcp.tools import (
    context,
    items,
    navigation,
    ordering,
    scopes,
    search,
    session,
)

__all__ = [
    "context",
    "items",
    "navigation",
    "ordering",
    "scopes",
    "search",
    "session",
]


def register_all_tools(mcp):
    """Register all tool modules with the MCP server."""
    session.register(mcp)
    context.register(mcp)
    items.register(mcp)
    navigation.register(mcp)
    search.register(mcp)
    ordering.register(mcp)
    scopes.register(mcp)
