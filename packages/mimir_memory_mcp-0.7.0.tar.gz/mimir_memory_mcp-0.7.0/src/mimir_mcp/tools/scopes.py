"""Scope management tools: list, create, add/remove members."""

from __future__ import annotations

import sqlite3
from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_user, is_admin
from mimir_mcp.db import Database, get_db


def list_scopes_impl(db: Database, user_id: str) -> list[dict]:
    """Return the caller's scopes with member info."""
    rows = queries.scopes_for_user(db, user_id)
    result = []
    for row in rows:
        members = row["member_ids"].split(",") if row["member_ids"] else []
        result.append(
            {
                "id": row["id"],
                "name": row["name"],
                "description": row["description"],
                "members": members,
            }
        )
    return result


def create_scope_impl(
    db: Database,
    user_id: str,
    is_admin: bool,
    scope_id: str,
    name: str,
    description: str | None = None,
) -> dict:
    """Create a new scope (admin only). Creator is added as the first member."""
    if not is_admin:
        return {"error": "Only admins can create scopes."}

    try:
        db.execute(
            "INSERT INTO scopes (id, name, description) VALUES (?, ?, ?)",
            (scope_id, name, description),
        )
        db.execute(
            "INSERT INTO scope_members (scope_id, user_id) VALUES (?, ?)",
            (scope_id, user_id),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return {"error": f"Scope '{scope_id}' already exists."}

    return {"id": scope_id, "name": name, "description": description}


def add_scope_member_impl(
    db: Database,
    user_id: str,
    is_admin: bool,
    scope_id: str,
    member_user_id: str,
) -> dict:
    """Add a user to a scope (admin only). Creates activity_cursor if needed."""
    if not is_admin:
        return {"error": "Only admins can add scope members."}

    # Validate scope exists
    scope = db.fetchone("SELECT * FROM scopes WHERE id = ?", (scope_id,))
    if not scope:
        return {"error": f"Scope '{scope_id}' does not exist."}

    try:
        db.execute(
            "INSERT INTO scope_members (scope_id, user_id) VALUES (?, ?)",
            (scope_id, member_user_id),
        )
    except sqlite3.IntegrityError:
        return {"error": f"User '{member_user_id}' is already a member of scope '{scope_id}'."}

    # Ensure activity_cursor exists for the new member
    existing = db.fetchone("SELECT * FROM activity_cursor WHERE user_id = ?", (member_user_id,))
    if not existing:
        db.execute(
            "INSERT INTO activity_cursor (user_id, last_seen_history_id) VALUES (?, 0)",
            (member_user_id,),
        )

    db.commit()
    return {"confirmation": f"User '{member_user_id}' added to scope '{scope_id}'."}


def remove_scope_member_impl(
    db: Database,
    user_id: str,
    is_admin: bool,
    scope_id: str,
    member_user_id: str,
) -> dict:
    """Remove a user from a scope (admin only). Items in the scope are preserved."""
    if not is_admin:
        return {"error": "Only admins can remove scope members."}

    db.execute(
        "DELETE FROM scope_members WHERE scope_id = ? AND user_id = ?",
        (scope_id, member_user_id),
    )
    db.commit()
    return {"confirmation": f"User '{member_user_id}' removed from scope '{scope_id}'."}


def register(mcp):
    """Register scope management MCP tools."""

    @mcp.tool
    def list_scopes() -> list[dict]:
        """List your accessible scopes with their members."""
        return list_scopes_impl(get_db(), get_current_user())

    @mcp.tool
    def create_scope(
        scope_id: Annotated[
            str,
            Field(
                description="Unique scope identifier (e.g., 'household', 'work-projects'). Lowercase letters, numbers, hyphens, and underscores only. Cannot be changed after creation."
            ),
        ],
        name: Annotated[
            str,
            Field(
                description="Human-readable display name for the scope (e.g., 'Household', 'Work Projects')."
            ),
        ],
        description: Annotated[
            str | None,
            Field(
                default=None,
                description="What this scope is used for. Shown when listing scopes. None (default) for no description.",
            ),
        ],
    ) -> dict:
        """Create a new scope. Admin only. You are added as the first member automatically."""
        return create_scope_impl(
            get_db(), get_current_user(), is_admin(), scope_id, name, description
        )

    @mcp.tool
    def add_scope_member(
        scope_id: Annotated[str, Field(description="ID of the scope to add the user to.")],
        member_user_id: Annotated[str, Field(description="User ID of the person to add.")],
    ) -> dict:
        """Add a user to a scope. Admin only."""
        return add_scope_member_impl(
            get_db(), get_current_user(), is_admin(), scope_id, member_user_id
        )

    @mcp.tool
    def remove_scope_member(
        scope_id: Annotated[str, Field(description="ID of the scope to remove the user from.")],
        member_user_id: Annotated[str, Field(description="User ID of the person to remove.")],
    ) -> dict:
        """Remove a user from a scope. Admin only. Items in the scope are preserved — only the user's access is removed."""
        return remove_scope_member_impl(
            get_db(), get_current_user(), is_admin(), scope_id, member_user_id
        )
