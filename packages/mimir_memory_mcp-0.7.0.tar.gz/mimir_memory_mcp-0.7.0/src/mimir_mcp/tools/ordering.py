"""Item ordering tools: reorder items within a parent group."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes, get_current_user
from mimir_mcp.db import Database, get_db
from mimir_mcp.models import ReorderEntry
from mimir_mcp.tools.helpers import validate_item_access


def reorder_items_impl(db: Database, user_id: str, scopes: list[str], entries: list[dict]) -> dict:
    """Reorder items by setting their positions.

    entries: list of {item_id, position} dicts.
    All items must exist, share the same parent (or all be top-level),
    and be within the user's accessible scopes.

    After updating, if any sibling positions are too close (gap < 0.001),
    normalizes all sibling positions to integers (1, 2, 3, ...).
    """
    if not entries:
        return {"confirmation": "Nothing to reorder"}

    # 1. Validate all items exist and collect parent_ids
    parent_ids = set()
    for entry in entries:
        item, err = validate_item_access(db, entry["item_id"], scopes)
        if err:
            return err
        parent_ids.add(item["parent_id"])

    # 2. Validate all items share the same parent
    if len(parent_ids) > 1:
        return {"error": "All items must share the same parent (or all be top-level)"}

    parent_id = parent_ids.pop()

    # 3. Update positions
    for entry in entries:
        queries.items_update(db, entry["item_id"], {"position": float(entry["position"])}, user_id)

    # 4. Check if normalization is needed
    _maybe_normalize_positions(db, user_id, scopes, parent_id)

    db.commit()
    return {"confirmation": f"Reordered {len(entries)} item(s)"}


def _maybe_normalize_positions(
    db: Database, user_id: str, scopes: list[str], parent_id: int | None
) -> None:
    """Normalize sibling positions to integers if any gap < 0.001."""
    sp = ",".join("?" for _ in scopes)
    if parent_id is None:
        siblings = db.fetchall(
            f"SELECT id, position FROM items WHERE parent_id IS NULL "
            f"AND scope IN ({sp}) ORDER BY position",
            tuple(scopes),
        )
    else:
        siblings = db.fetchall(
            f"SELECT id, position FROM items WHERE parent_id = ? "
            f"AND scope IN ({sp}) ORDER BY position",
            (parent_id, *scopes),
        )

    positions = [s["position"] for s in siblings if s["position"] is not None]
    if len(positions) >= 2:
        min_gap = min(positions[i + 1] - positions[i] for i in range(len(positions) - 1))
        if min_gap < 0.001:
            for i, s in enumerate(siblings):
                db.execute(
                    "UPDATE items SET position = ?, updated_by = ? WHERE id = ?",
                    (float(i + 1), user_id, s["id"]),
                )


def register(mcp):
    """Register ordering MCP tools."""

    @mcp.tool
    def reorder_items(
        entries: Annotated[
            list[ReorderEntry],
            Field(
                description="List of {item_id, position} pairs. All items must share the same parent (or all be top-level). Positions auto-normalize when gaps get too small."
            ),
        ],
    ) -> dict:
        """Set display positions for items within the same parent. Positions are decimal numbers — use values between existing items to insert without renumbering. Automatically renumbers if positions get too close together."""
        return reorder_items_impl(
            get_db(), get_current_user(), get_current_scopes(), [e.model_dump() for e in entries]
        )
