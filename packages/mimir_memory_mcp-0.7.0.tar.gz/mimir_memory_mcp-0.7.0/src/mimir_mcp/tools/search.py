"""Search & discovery tools: search_items, list_items, get_facts."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated, Literal

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes, get_current_user
from mimir_mcp.db import Database, get_db

ITEM_TYPE = Literal["task", "project", "fact", "reminder", "note", "idea"]
ITEM_STATUS = Literal[
    "not_started", "in_progress", "blocked", "completed", "archived", "active", "expired", "deleted"
]


def _apply_lazy_expiry(db: Database, items: list[dict], user_id: str):
    """Check valid_until on facts and lazily mark expired ones.

    After fetching facts in any read path, checks valid_until.
    If a fact's valid_until has passed, updates its status to 'expired'
    in both the in-memory dict and the database.
    The updated_by = user_id is needed because the enforce_update_access
    trigger validates that the updater has scope access.
    """
    now = datetime.now(timezone.utc).isoformat()
    for item in items:
        if (
            item.get("type") == "fact"
            and item.get("valid_until")
            and item["valid_until"] < now
            and item.get("status") != "expired"
        ):
            db.execute(
                "UPDATE items SET status = 'expired', updated_by = ? WHERE id = ?",
                (user_id, item["id"]),
            )
            item["status"] = "expired"


def search_items_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    query: str,
    *,
    type: str | None = None,
    status: str | None = None,
    tag: str | None = None,
) -> list[dict]:
    """FTS5 full-text search across items.

    Uses FTS5 index for ranked text search, filtered by scope and optional
    type/status/tag filters. Applies lazy expiry to any returned facts.

    When no explicit status filter is given, search_fts already excludes
    completed and archived items. Expired facts are additionally filtered
    out after lazy expiry is applied.

    When status='expired' is explicitly requested, we search for that status
    to find expired facts.
    """
    # Run the FTS query with filters
    rows = queries.search_fts(db, query, scopes, type=type, status=status)
    results = [dict(row) for row in rows]

    # Apply lazy expiry to any facts in the results
    _apply_lazy_expiry(db, results, user_id)
    db.commit()

    # If no explicit status filter was given, exclude expired facts
    # (they were just lazily expired and shouldn't show in default results)
    if not status:
        results = [r for r in results if r.get("status") != "expired"]

    return results


def list_items_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    *,
    type: str | None = None,
    status: str | None = None,
    parent_id: int | None = None,
    scope: str | None = None,
) -> list[dict]:
    """Structured listing sorted by priority then position.

    parent_id=None means top-level only (WHERE parent_id IS NULL).
    If parent_id is specified, list children of that parent.
    Scope enforcement: filter to user's scopes.
    Optional scope parameter further narrows to a single scope.
    """
    results = queries.items_list(
        db,
        scopes,
        type=type,
        status=status,
        parent_id=parent_id,
        scope=scope,
    )
    return [dict(row) for row in results]


def get_facts_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    *,
    tags: list[str] | None = None,
    item_ids: list[int] | None = None,
    include_children: bool = False,
    level: str = "summary",
) -> list[dict]:
    """Retrieve facts by tags or by parent items.

    - By tags: OR logic -- facts tagged with any of the given tags.
    - By item_ids: facts attached to (children of) specific items.
    - include_children=True: also include facts from all descendants of item_ids.
    - level='summary' returns summary only, level='detail' includes the detail field.
    - Applies lazy expiry to results.
    """
    results = []
    seen_ids = set()

    # Fetch by tags
    if tags:
        rows = queries.items_facts_by_tags(db, scopes, tags)
        for row in rows:
            d = dict(row)
            if d["id"] not in seen_ids:
                results.append(d)
                seen_ids.add(d["id"])

    # Fetch by item_ids (facts that are children of the given items)
    if item_ids:
        # Direct children facts
        rows = queries.items_facts_for_items(db, item_ids, scopes)
        for row in rows:
            d = dict(row)
            if d["id"] not in seen_ids:
                results.append(d)
                seen_ids.add(d["id"])

        # Recursive descendant facts
        if include_children:
            rows = queries.items_facts_for_descendants(db, item_ids, scopes)
            for row in rows:
                d = dict(row)
                if d["id"] not in seen_ids:
                    results.append(d)
                    seen_ids.add(d["id"])

    # Apply lazy expiry
    _apply_lazy_expiry(db, results, user_id)
    db.commit()

    # Exclude expired facts from results
    results = [r for r in results if r.get("status") != "expired"]

    # Apply level filtering
    if level == "summary":
        for r in results:
            r.pop("detail", None)

    return results


def register(mcp):
    """Register search MCP tools."""

    @mcp.tool(name="search_items")
    def search_items_tool(
        query: Annotated[
            str,
            Field(
                description="Full-text search query. Supports word stemming ('run' matches 'running'). Searches summary and detail fields."
            ),
        ],
        type: Annotated[
            ITEM_TYPE | None,
            Field(
                default=None,
                description="Filter results to this item type. None (default) returns all types.",
            ),
        ],
        status: Annotated[
            ITEM_STATUS | None,
            Field(
                default=None,
                description="Filter by status. None (default) excludes completed, archived, and deleted items. Pass a specific status to override (e.g., 'completed' to find finished items).",
            ),
        ],
        tag: Annotated[
            str | None,
            Field(
                default=None,
                description="Filter to items with this tag. Accepts a single tag. For multi-tag OR queries on facts, use get_facts instead. None (default) skips tag filtering.",
            ),
        ],
    ) -> list[dict]:
        """Full-text search across item summaries and details with word stemming (e.g., 'run' matches 'running'). Ranked by relevance. Excludes completed, archived, and deleted items by default — pass status to override. Returns up to 50 results. For structural browsing, use `list_items`."""
        return search_items_impl(
            get_db(),
            get_current_user(),
            get_current_scopes(),
            query,
            type=type,
            status=status,
            tag=tag,
        )

    @mcp.tool(name="list_items")
    def list_items_tool(
        type: Annotated[
            ITEM_TYPE | None,
            Field(
                default=None,
                description="Filter results to this item type. None (default) returns all types.",
            ),
        ],
        status: Annotated[
            ITEM_STATUS | None,
            Field(
                default=None,
                description="Filter by status. None (default) excludes completed and archived items. Pass a specific status to override (e.g., 'completed' to find finished items).",
            ),
        ],
        parent_id: Annotated[
            int | None,
            Field(
                default=None,
                description="List children of this item. None (default) returns top-level items only (items with no parent).",
            ),
        ],
        scope: Annotated[
            str | None,
            Field(
                default=None,
                description="Narrow results to a single scope ID (e.g., 'jimmy'). None (default) returns items from all active scopes.",
            ),
        ],
    ) -> list[dict]:
        """Browse items with filters. Returns top-level items by default with child_count and completed_count for each. Present the overview first — only drill into children via list_children when the user asks for details on a specific item. Pass parent_id to list children of a specific item. Filter by type, status, or scope. Sorted by priority then position. For text search, use `search_items`."""
        return list_items_impl(
            get_db(),
            get_current_user(),
            get_current_scopes(),
            type=type,
            status=status,
            parent_id=parent_id,
            scope=scope,
        )

    @mcp.tool(name="get_facts")
    def get_facts_tool(
        tags: Annotated[
            list[str] | None,
            Field(
                default=None,
                description="Return facts tagged with any of these tags (OR logic). None (default) skips tag filtering.",
            ),
        ],
        item_ids: Annotated[
            list[int] | None,
            Field(
                default=None,
                description="Return facts that are children of these items. None (default) skips parent filtering.",
            ),
        ],
        include_children: Annotated[
            bool,
            Field(
                default=False,
                description="When true, also return facts from all descendants of the specified item_ids, not just direct children. Default: false.",
            ),
        ],
        level: Annotated[
            Literal["summary", "detail"],
            Field(
                default="summary",
                description="'summary' (default) returns headlines only for fast context loading. 'detail' includes the full detail field — use when you need specifics.",
            ),
        ],
    ) -> list[dict]:
        """Use this when you need facts filtered by tag or by parent item. Boot and refresh responses return all facts as a flat list, so use get_facts for targeted tag lookup. Retrieve facts by tags or by parent item. Tags use OR logic — returns facts matching any given tag. Pass item_ids to get facts attached as children of specific items. At least one filter required; without either, returns nothing. Excludes expired facts. Pass level='detail' for extended descriptions."""
        return get_facts_impl(
            get_db(),
            get_current_user(),
            get_current_scopes(),
            tags=tags,
            item_ids=item_ids,
            include_children=include_children,
            level=level,
        )
