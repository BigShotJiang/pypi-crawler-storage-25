"""Shared helpers for MCP tool functions."""

from __future__ import annotations

from mimir_mcp import queries
from mimir_mcp.db import Database


def validate_item_access(
    db: Database, item_id: int, scopes: list[str]
) -> tuple[dict | None, dict | None]:
    """Fetch item and validate scope access.

    Returns (item_dict, None) on success or (None, error_dict) on failure.
    """
    row = queries.items_get_by_id(db, item_id)
    if not row:
        return None, {"error": f"Item {item_id} not found"}
    if row["scope"] not in scopes:
        return None, {"error": f"No access to item {item_id} in scope '{row['scope']}'"}
    return dict(row), None
