"""Navigation & retrieval tools: get_details, list_children, get_history, add_note."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes, get_current_user
from mimir_mcp.db import Database, get_db
from mimir_mcp.tools.helpers import validate_item_access


def get_details_impl(
    db: Database, user_id: str, scopes: list[str], item_ids: list[int]
) -> list[dict]:
    """Fetch full detail for multiple items, filtered by scope.

    Only returns items that exist and belong to one of the user's scopes.
    Each returned dict includes summary, detail, type, status, scope,
    priority, tags, due_date, and all other item fields.
    """
    results = []
    for item_id in item_ids:
        item, err = validate_item_access(db, item_id, scopes)
        if err or item is None:
            continue
        results.append(item)
    return results


def get_children_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    parent_id: int,
    *,
    include_detail: bool = False,
    cascade: bool = False,
) -> dict:
    """Get children of a parent item, grouped by type.

    Summary only by default; include_detail=True adds detail field.
    cascade=True returns recursive descendants.
    Validates parent item exists and is in user's scopes.

    Returns dict grouped by type: {"task": [...], "project": [...], etc.}
    """
    _, err = validate_item_access(db, parent_id, scopes)
    if err:
        return err

    # Fetch children (optionally recursive)
    children_rows = queries.items_get_children(db, parent_id, scopes, cascade=cascade)

    # Group by type
    grouped: dict[str, list[dict]] = {}
    for row in children_rows:
        child = dict(row)
        if not include_detail:
            child.pop("detail", None)
        child_type = child["type"]
        grouped.setdefault(child_type, []).append(child)

    return grouped


def get_history_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    item_id: int,
    *,
    since: str | None = None,
    until: str | None = None,
    limit: int = 50,
) -> list[dict] | dict:
    """Get history entries for an item.

    Validates item exists and is in user's scopes.
    Returns list of history entry dicts, or dict with 'error' key on failure.
    """
    _, err = validate_item_access(db, item_id, scopes)
    if err:
        return err

    rows = queries.history_for_item(db, item_id, since=since, until=until, limit=limit)
    return [dict(row) for row in rows]


def add_note_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    item_id: int,
    note: str,
    *,
    session_id: int | None = None,
) -> dict:
    """Create a history entry with event='context_added'.

    Validates item exists and is in user's scopes.
    Returns confirmation dict, or dict with 'error' key on failure.
    """
    _, err = validate_item_access(db, item_id, scopes)
    if err:
        return err

    queries.history_insert(
        db,
        item_id,
        "context_added",
        note,
        user_id,
        session_id=session_id,
    )
    db.commit()

    return {"confirmation": f"Note added to item {item_id}"}


def register(mcp):
    """Register navigation MCP tools."""

    @mcp.tool(name="get_details")
    def get_details(
        item_ids: Annotated[
            list[int],
            Field(
                description="IDs of items to fetch full detail for. Returns summary, detail, tags, metadata, timestamps — everything about each item. Items outside your active scopes are silently excluded."
            ),
        ],
    ) -> list[dict]:
        """Use this to expand an item summary's detail field. Boot and refresh responses return slim summaries without the detail field — call get_details to read the full detail. Fetch full detail for one or more items by ID, including extended description, metadata, and timestamps. A read-only lookup — does NOT change your focus. Items not found or outside your scopes are silently omitted. To navigate into an item and see its children, use set_context instead."""
        return get_details_impl(get_db(), get_current_user(), get_current_scopes(), item_ids)

    @mcp.tool(name="list_children")
    def list_children(
        parent_id: Annotated[
            int,
            Field(
                description="ID of the parent item to list children of. Results are grouped by type."
            ),
        ],
        include_detail: Annotated[
            bool,
            Field(
                default=False,
                description="Include the extended detail field in results. Default (False) returns summaries only.",
            ),
        ],
        cascade: Annotated[
            bool,
            Field(
                default=False,
                description="True to include all descendants recursively (children, grandchildren, etc.), not just direct children. Default: False.",
            ),
        ],
    ) -> dict:
        """List direct children of an item, grouped by type. Each child includes child_count and completed_count for its own children. Returns summaries by default — pass include_detail=True for extended descriptions. Pass cascade=True for all descendants recursively. For top-level items, use `list_items`."""
        return get_children_impl(
            get_db(),
            get_current_user(),
            get_current_scopes(),
            parent_id,
            include_detail=include_detail,
            cascade=cascade,
        )

    @mcp.tool(name="get_history")
    def get_history(
        item_id: Annotated[int, Field(description="ID of the item to fetch change history for.")],
        since: Annotated[
            str | None,
            Field(
                default=None,
                description="Only include entries from this timestamp onward (ISO 8601 datetime, e.g., '2025-06-01T00:00:00'). None (default) for no lower bound.",
            ),
        ],
        until: Annotated[
            str | None,
            Field(
                default=None,
                description="Only include entries up to this timestamp (ISO 8601 datetime). None (default) for no upper bound.",
            ),
        ],
        limit: Annotated[
            int,
            Field(
                default=50,
                description="Maximum number of history entries to return. Newest entries are returned first.",
            ),
        ],
    ) -> list[dict] | dict:
        """Get the change history for an item: who changed what, when, and how. Each entry shows the event type (created, updated, completed, etc.) and what changed. Supports time range filtering with since/until (ISO 8601). Default limit is 50 — override with the `limit` parameter."""
        return get_history_impl(
            get_db(),
            get_current_user(),
            get_current_scopes(),
            item_id,
            since=since,
            until=until,
            limit=limit,
        )

    @mcp.tool(name="add_note")
    def add_note(
        item_id: Annotated[int, Field(description="ID of the item to attach the note to.")],
        note: Annotated[
            str,
            Field(
                description="Free-text note recorded in the item's history (event='context_added'). Use for background, decisions, observations, or status updates."
            ),
        ],
    ) -> dict:
        """Append a note to an item's history without modifying the item itself. Use for recording context, decisions, or observations. The note appears in get_history results. To change an item's summary, detail, or other fields, use update_item instead."""
        return add_note_impl(get_db(), get_current_user(), get_current_scopes(), item_id, note)
