"""Context management tools: set_context, refresh_context."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes, get_current_user
from mimir_mcp.db import Database, get_db


def build_boot_summary(db: Database, user_id: str, scopes: list[str]) -> dict:
    """Build the boot-level summary (projects, tasks, reminders, ideas, facts)."""
    items = queries.items_top_level_active(db, scopes, exclude_types=("fact", "reminder"))
    projects = []
    tasks = []
    ideas = []
    for item in items:
        item_type = item["type"]
        slim = slim_item(item)
        if item_type == "project":
            projects.append(slim)
        elif item_type == "task":
            tasks.append(slim)
        elif item_type == "idea":
            ideas.append(slim)

    reminders_raw = queries.items_reminders_upcoming(db, scopes)
    reminders = [slim_item(r) for r in reminders_raw]

    facts_raw = queries.items_facts_by_scope(db, scopes)
    facts = serialize_facts_flat(facts_raw)

    return {
        "projects": projects,
        "tasks": tasks,
        "ideas": ideas,
        "reminders": reminders,
        "facts": facts,
    }


def serialize_facts_flat(facts_raw) -> list[dict]:
    """Flat list of facts with the slim boot shape: {id, summary, tags, source}.

    Tag-grouping was removed (v0.7.0) — use get_facts(tag=...) for tag-filtered retrieval.
    Full detail is not included — use get_details([fact_id]) when a summary points to
    something worth expanding.
    """
    out = []
    for fact in facts_raw:
        tags_str = fact["tags"] if "tags" in fact.keys() and fact["tags"] else ""
        tags = [t.strip() for t in tags_str.split(",") if t.strip()]
        out.append(
            {
                "id": fact["id"],
                "summary": fact["summary"],
                "tags": tags,
                "source": fact["source"],
            }
        )
    return out


def slim_item(row) -> dict:
    """Serialize an item for overview/navigation — only fields useful without drilling in.

    Optional fields (priority, tags, child_count, completed_count, due_date) are omitted
    when null/empty/zero. Consumers treat absence as the default. Use get_details for the
    full record.
    """
    out = {
        "id": row["id"],
        "summary": row["summary"],
        "scope": row["scope"],
        "status": row["status"],
    }
    priority = row["priority"] if "priority" in row.keys() else None
    if priority:
        out["priority"] = priority

    tags_str = row["tags"] if "tags" in row.keys() and row["tags"] else ""
    tags = [t.strip() for t in tags_str.split(",") if t.strip()]
    if tags:
        out["tags"] = tags

    child_count = row["child_count"] if "child_count" in row.keys() else 0
    if child_count:
        out["child_count"] = child_count

    completed_count = row["completed_count"] if "completed_count" in row.keys() else 0
    if completed_count:
        out["completed_count"] = completed_count

    due_date = row["due_date"] if "due_date" in row.keys() else None
    if due_date:
        out["due_date"] = due_date

    return out


def build_focused_view(db: Database, item_id: int, scopes: list[str]) -> dict:
    """Build the focused view for a specific item: detail + children + facts."""
    item_row = queries.items_get_by_id(db, item_id)
    item_detail = dict(item_row)

    # Children grouped by type (slim shape — focused item itself retains full detail)
    children_raw = queries.items_get_children(db, item_id, scopes)
    children: dict[str, list[dict]] = {}
    for child in children_raw:
        children.setdefault(child["type"], []).append(slim_item(child))

    # Facts (flat slim list)
    facts_raw = queries.items_facts_by_scope(db, scopes)
    facts = serialize_facts_flat(facts_raw)

    return {
        "item": item_detail,
        "children": children,
        "facts": facts,
    }


def set_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    """Focus on a specific item or clear focus back to boot-level view.

    With item_id: validates scope access, updates session, returns item detail + children + facts.
    Without item_id (None): clears focus, returns boot-level summary.
    Both include tags_in_use per scope for consistent tagging.
    """
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"error": "No active session found."}

    session_id = session["id"]

    if item_id is not None:
        # Validate item exists
        item_row = queries.items_get_by_id(db, item_id)
        if not item_row:
            return {"error": f"Item {item_id} not found."}

        # Validate item is in one of user's scopes
        if item_row["scope"] not in scopes:
            return {"error": f"Item {item_id} is not in your accessible scopes."}

        # Update session context
        queries.sessions_update_context(db, session_id, item_id)
        db.commit()

        result = build_focused_view(db, item_id, scopes)
    else:
        # Clear context
        queries.sessions_update_context(db, session_id, None)
        db.commit()

        result = build_boot_summary(db, user_id, scopes)

    # Include tags in use for the relevant scopes
    result["tags_in_use"] = queries.tags_in_use(db, scopes)
    return result


def refresh_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    """Refresh the current context view — stateless.

    With item_id=None: returns the top-level boot summary (ignores session.active_context_id).
    With item_id: validates scope access and returns the focused view for that item.
    Always includes scopes, session activity, shared activity, and tags_in_use.
    """
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"error": "No active session found."}

    session_id = session["id"]

    # Build base result — driven by the explicit item_id arg, NOT by session state
    if item_id is not None:
        item_row = queries.items_get_by_id(db, item_id)
        if not item_row:
            return {"error": f"Item {item_id} not found."}
        if item_row["scope"] not in scopes:
            return {"error": f"Item {item_id} is not in your accessible scopes."}
        result = build_focused_view(db, item_id, scopes)
    else:
        result = build_boot_summary(db, user_id, scopes)

    # Add scopes
    all_user_scopes = queries.scopes_for_user(db, user_id)
    scope_list = []
    for s in all_user_scopes:
        if s["id"] in scopes:
            scope_list.append(
                {
                    "id": s["id"],
                    "name": s["name"],
                    "description": s["description"],
                    "members": s["member_ids"],
                }
            )
    result["scopes"] = scope_list

    # Add session activity
    activity_raw = queries.items_session_activity(db, session_id)
    result["session_activity"] = [dict(a) for a in activity_raw]

    # Add shared activity
    shared_activity_raw = queries.activity_get_shared(db, user_id, scopes)
    result["recent_shared_activity"] = [dict(a) for a in shared_activity_raw]

    # Add tags in use
    result["tags_in_use"] = queries.tags_in_use(db, scopes)

    db.commit()

    return result


def register(mcp):
    """Register context MCP tools."""

    @mcp.tool(name="set_context")
    def set_context_tool(
        item_id: Annotated[
            int | None,
            Field(
                default=None,
                description="Item to focus on — returns its full detail, children, and relevant facts. Pass None to clear focus and return to the top-level overview.",
            ),
        ],
    ) -> dict:
        """Focus on a specific item or return to the top-level overview. With item_id: returns that item's full detail, its children (summaries), and facts (flat list of {id, summary, tags, source}). With item_id=None: clears focus and returns the top-level summary (projects, tasks, ideas, reminders, facts as slim summaries). Both include tags_in_use — existing tags per scope for consistent naming. Does NOT reload session or shared activity — use refresh_context for that. For a one-shot focused view that does NOT persist focus, use refresh_context(item_id=X) instead."""
        return set_context_impl(get_db(), get_current_user(), get_current_scopes(), item_id=item_id)

    @mcp.tool(name="refresh_context")
    def refresh_context_tool(
        item_id: Annotated[
            int | None,
            Field(
                default=None,
                description="Reload the focused view for this item. Pass None (default) for the top-level boot summary. Independent of any focus previously set via set_context.",
            ),
        ] = None,
    ) -> dict:
        """Reload your current state view. With no arguments, returns the top-level boot summary. With item_id, returns the focused view for that item — refresh_context is stateless and ignores any focus previously set via set_context, so pass item_id explicitly when you want a focused view. On success, includes scopes, session_activity, recent_shared_activity, and tags_in_use. Use when your conversation context has been compressed and you need to rebuild working memory. Unlike start_session, does not create a new session."""
        return refresh_context_impl(
            get_db(), get_current_user(), get_current_scopes(), item_id=item_id
        )
