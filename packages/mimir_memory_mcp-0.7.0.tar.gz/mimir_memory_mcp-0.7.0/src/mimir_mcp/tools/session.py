"""Session lifecycle tools: boot, end, checkpoint."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_user, get_current_scopes
from mimir_mcp.db import Database, get_db
from mimir_mcp.tools.context import build_boot_summary


def boot_session_impl(db: Database, user_id: str, scopes: list[str]) -> dict:
    """Start a new session. Returns structured boot data plus tags_in_use per scope."""
    # 1. Close stale sessions for this user
    stale_count = queries.sessions_close_stale(db, user_id)

    # 2. Get the last completed session (before creating a new one)
    last_session_row = queries.sessions_get_last_completed(db, user_id)
    last_session = None
    if last_session_row:
        last_session = {"summary": last_session_row["summary"]}

    # 3. Create new session
    queries.sessions_create(db, user_id)

    # 4. Fetch user profile
    user_row = queries.users_get(db, user_id)
    user = {"id": user_row["id"], "name": user_row["name"]}

    # 5. Fetch scopes with members (filtered to requested scopes)
    all_user_scopes = queries.scopes_for_user(db, user_id)
    scope_list = []
    for s in all_user_scopes:
        if s["id"] in scopes:
            scope_list.append(
                {
                    "id": s["id"],
                    "name": s["name"],
                    "description": s["description"],
                    "members": s["member_ids"],
                }
            )

    # 6-8. Fetch items, reminders, facts (delegated to shared helper)
    summary = build_boot_summary(db, user_id, scopes)

    # 9. Fetch shared activity (do NOT advance cursor -- crash safety)
    shared_activity_raw = queries.activity_get_shared(db, user_id, scopes)
    shared_activity = [dict(a) for a in shared_activity_raw]

    # Also fetch recently created/updated items by other users (covers items
    # that don't yet have explicit history entries)
    recent_items_by_others = queries.items_recent_by_others(db, user_id, scopes)
    # Merge into shared activity if not already represented
    existing_item_ids = {a.get("item_id") for a in shared_activity}
    for item in recent_items_by_others:
        if item["id"] not in existing_item_ids:
            shared_activity.append(
                {
                    "item_id": item["id"],
                    "actor": item["created_by"],
                    "event": "created",
                    "summary": item["summary"],
                    "scope": item["scope"],
                    "created_at": item["created_at"],
                }
            )

    # 10. Tags in use per scope
    tags_by_scope = queries.tags_in_use(db, scopes)

    # 11. Commit and return
    db.commit()

    return {
        "user": user,
        "scopes": scope_list,
        "last_session": last_session,
        "stale_sessions": stale_count,
        **summary,
        "recent_shared_activity": shared_activity,
        "tags_in_use": tags_by_scope,
    }


def end_session_impl(db: Database, user_id: str, *, learnings: list[str] | None = None) -> dict:
    """End the active session. Optionally record learnings as facts."""
    # 1. Get active session
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"summary": "No active session found."}

    session_id = session["id"]

    # 2. Record learnings as facts
    if learnings:
        for learning in learnings:
            fact_id = queries.items_insert_full(
                db,
                user_id,
                "fact",
                "active",
                learning,
                user_id,
                source="learned",
            )
            queries.history_insert(
                db,
                fact_id,
                "created",
                f"Learned: {learning}",
                user_id,
                session_id=session_id,
            )

    # 3. Generate summary
    summary = "Session ended"
    if learnings:
        summary += f" with {len(learnings)} learning(s) recorded"

    # 4. Close session
    queries.sessions_end(db, session_id, summary)

    # 5. Advance cursor
    queries.activity_advance_cursor(db, user_id)

    # 6. Commit
    db.commit()

    return {"summary": summary}


def checkpoint_session_impl(db: Database, user_id: str) -> dict:
    """Save progress mid-session by advancing the activity cursor."""
    # 1. Verify active session
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"confirmation": "No active session found."}

    # 2. Advance cursor
    queries.activity_advance_cursor(db, user_id)

    # 3. Commit
    db.commit()

    return {"confirmation": "Checkpoint saved. Activity cursor advanced."}


def register(mcp):
    """Register session MCP tools."""

    @mcp.tool
    def start_session(
        scopes: Annotated[
            list[str] | None,
            Field(
                default=None,
                description="Scope IDs to activate for this session. Defaults to all your scopes if omitted.",
            ),
        ] = None,
    ) -> dict:
        """Start a new session and return your full current state: projects, tasks, ideas, reminders, facts (flat list), recent changes by other users, and tags_in_use per scope. Call once at the beginning of every conversation. If your context is compacted mid-conversation, call refresh_context instead — do not call start_session again (it would create a new session). Closes any leftover sessions from previous conversations automatically."""
        resolved_scopes = scopes if scopes is not None else get_current_scopes()
        return boot_session_impl(get_db(), get_current_user(), resolved_scopes)

    @mcp.tool
    def end_session(
        learnings: Annotated[
            list[str] | None,
            Field(
                default=None,
                description="New facts discovered this session. Each string is saved as a persistent fact (type='fact', source='learned') in your personal scope. For facts in shared scopes or with custom fields, use add_items with type='fact' instead. Pass None or omit to end without saving facts.",
            ),
        ] = None,
    ) -> dict:
        """End the current session. Pass learnings to save new facts that should persist across sessions. Marks all shared activity as seen and closes the session. Unlike save_session, this is permanent."""
        return end_session_impl(get_db(), get_current_user(), learnings=learnings)

    @mcp.tool
    def save_session() -> dict:
        """Save progress mid-session without ending it. Marks shared activity as seen so you won't receive it again if the session is interrupted. Does not return data — use refresh_context to reload your current view."""
        return checkpoint_session_impl(get_db(), get_current_user())
