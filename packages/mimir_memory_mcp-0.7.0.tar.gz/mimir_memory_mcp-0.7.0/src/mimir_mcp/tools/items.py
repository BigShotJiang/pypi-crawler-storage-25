"""Item CRUD tools: add, update, complete, archive, delete, convert."""

from __future__ import annotations

import json
import uuid
from typing import Annotated, Literal

from pydantic import Field

from fastmcp.exceptions import ToolError

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes, get_current_user, is_admin
from mimir_mcp.db import Database, get_db
from mimir_mcp.models import ItemInput
from mimir_mcp.tools.helpers import validate_item_access


# Default status by item type
_DEFAULT_STATUS = {
    "task": "not_started",
    "fact": "active",
    "project": "active",
    "reminder": "active",
    "note": "active",
    "idea": "active",
}

# Types that can have children (container types)
_CONTAINER_TYPES = {"project", "task", "idea"}

# Types that cannot have children (leaf types)
_LEAF_TYPES = {"fact", "note", "reminder"}


def add_items_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    items_input: list[dict],
    *,
    session_id: int | None = None,
) -> list[dict]:
    """Create one or more items.

    For each item in items_input, validates scope access, parent constraints,
    sets defaults, inserts the item, tags, and history.

    Returns a list of created item dicts, or dicts with 'error' key on failure.
    """
    results = []
    for item_data in items_input:
        result = _add_single_item(db, user_id, scopes, item_data, session_id=session_id)
        results.append(result)
    db.commit()
    return results


def _add_single_item(
    db: Database, user_id: str, scopes: list[str], item_data: dict, *, session_id: int | None = None
) -> dict:
    """Add a single item with validation."""
    scope = item_data.get("scope")
    item_type = item_data.get("type")
    summary = item_data.get("summary")
    parent_id = item_data.get("parent_id")

    # 1. Validate scope access
    if scope not in scopes:
        return {"error": f"No access to scope '{scope}'"}

    # 2. Validate parent if set
    if parent_id is not None:
        parent = queries.items_get_by_id(db, parent_id)
        if not parent:
            return {"error": f"Parent item {parent_id} not found"}
        if parent["scope"] != scope:
            return {
                "error": f"Parent item {parent_id} is in scope '{parent['scope']}', not '{scope}'"
            }
        if parent["type"] in _LEAF_TYPES:
            return {"error": f"Cannot parent under {parent['type']} (only project/task/idea)"}

    # 3. Default status by type if not provided
    status = item_data.get("status") or _DEFAULT_STATUS.get(item_type, "active")

    # 4. Insert item
    metadata_raw = item_data.get("metadata")
    metadata_str = json.dumps(metadata_raw) if metadata_raw else None

    item_id = queries.items_insert_full(
        db,
        scope,
        item_type,
        status,
        summary,
        user_id,
        detail=item_data.get("detail"),
        parent_id=parent_id,
        priority=item_data.get("priority"),
        due_date=item_data.get("due_date"),
        valid_until=item_data.get("valid_until"),
        source=item_data.get("source"),
        metadata=metadata_str,
    )

    # 5. Insert tags
    tags = item_data.get("tags", [])
    if tags:
        queries.item_tags_insert(db, item_id, tags)

    # 6. Record history
    queries.history_insert(
        db,
        item_id,
        "created",
        summary,
        user_id,
        session_id=session_id,
    )

    # 7. Return created item
    row = queries.items_get_by_id(db, item_id)
    return dict(row)


def update_item_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    item_id: int,
    updates: dict,
    *,
    session_id: int | None = None,
) -> dict:
    """Update an existing item.

    Handles field updates, tag replacement, scope cascading to children,
    and structured diff history.
    """
    # Work on a copy to avoid mutating the caller's dict
    updates = dict(updates)

    if updates.get("status") == "completed":
        raise ToolError(
            "Cannot set status to 'completed' via update_item — use complete_items instead. "
            "complete_items cascades completion to child items."
        )

    # 1. Fetch existing item and validate scope access
    existing, err = validate_item_access(db, item_id, scopes)
    if err:
        return err

    # Extract tags separately (not a column in items table)
    new_tags = updates.pop("tags", None)

    # Handle empty-string clearing for date fields
    db_updates = {}
    for field, value in updates.items():
        if field in ("due_date", "valid_until") and value == "":
            db_updates[field] = None
        else:
            db_updates[field] = value

    # Check if scope is changing
    scope_changing = "scope" in db_updates and db_updates["scope"] != existing["scope"]

    correlation_id = None
    if scope_changing:
        new_scope = db_updates["scope"]
        if new_scope not in scopes:
            return {"error": f"No access to target scope '{new_scope}'"}
        correlation_id = str(uuid.uuid4())

    # 2. Build diff before applying updates
    if db_updates:
        diff = queries.build_diff(existing, db_updates)
    else:
        diff = []

    # 3. Apply updates to the item
    if db_updates:
        queries.items_update(db, item_id, db_updates, user_id)

    # 4. Record history if there were changes
    if diff:
        queries.history_insert(
            db,
            item_id,
            "updated",
            diff,
            user_id,
            session_id=session_id,
            correlation_id=correlation_id,
        )

    # 5. If scope changed, cascade to all children
    if scope_changing:
        new_scope = db_updates["scope"]
        child_ids = queries.items_get_children_ids(db, item_id, cascade=True)
        for child_id in child_ids:
            child_row = queries.items_get_by_id(db, child_id)
            if child_row:
                child_diff = queries.build_diff(child_row, {"scope": new_scope})
                if child_diff:
                    queries.items_update(db, child_id, {"scope": new_scope}, user_id)
                    queries.history_insert(
                        db,
                        child_id,
                        "updated",
                        child_diff,
                        user_id,
                        session_id=session_id,
                        correlation_id=correlation_id,
                    )

    # 6. Handle tag updates
    if new_tags is not None:
        queries.item_tags_clear(db, item_id)
        if new_tags:
            queries.item_tags_insert(db, item_id, new_tags)

    db.commit()

    # 7. Return updated item
    row = queries.items_get_by_id(db, item_id)
    return dict(row)


def complete_items_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    item_ids: list[int],
    *,
    session_id: int | None = None,
) -> dict:
    """Mark items as completed, cascading to all descendants.

    Uses a single correlation_id for all history entries in the cascade.
    """
    correlation_id = str(uuid.uuid4())
    total_completed = 0

    for item_id in item_ids:
        existing, err = validate_item_access(db, item_id, scopes)
        if err:
            return err
        if existing is None:
            continue

        # Complete the item and all descendants via query helper
        all_ids = queries.items_complete_with_descendants(db, item_id, user_id)

        # Record history for each completed item
        for completed_id in all_ids:
            row = queries.items_get_by_id(db, completed_id)
            if row:
                queries.history_insert(
                    db,
                    completed_id,
                    "completed",
                    "Item completed",
                    user_id,
                    session_id=session_id,
                    correlation_id=correlation_id,
                )
                total_completed += 1

    db.commit()
    return {"confirmation": f"Completed {total_completed} item(s)", "count": total_completed}


def archive_items_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    item_ids: list[int],
    *,
    session_id: int | None = None,
) -> dict:
    """Archive items and CASCADE to all descendants.

    Uses a single correlation_id for all history entries in the cascade.
    """
    correlation_id = str(uuid.uuid4())
    total_archived = 0

    for item_id in item_ids:
        existing, err = validate_item_access(db, item_id, scopes)
        if err:
            return err
        if existing is None:
            continue

        # Archive the item itself
        queries.items_update(db, item_id, {"status": "archived"}, user_id)
        queries.history_insert(
            db,
            item_id,
            "status_changed",
            [{"field": "status", "old": existing["status"], "new": "archived"}],
            user_id,
            session_id=session_id,
            correlation_id=correlation_id,
        )
        total_archived += 1

        # Cascade to all descendants
        child_ids = queries.items_get_children_ids(db, item_id, cascade=True)
        for child_id in child_ids:
            child_row = queries.items_get_by_id(db, child_id)
            if child_row and child_row["status"] != "archived":
                queries.items_update(db, child_id, {"status": "archived"}, user_id)
                queries.history_insert(
                    db,
                    child_id,
                    "status_changed",
                    [{"field": "status", "old": child_row["status"], "new": "archived"}],
                    user_id,
                    session_id=session_id,
                    correlation_id=correlation_id,
                )
                total_archived += 1

    db.commit()
    return {"confirmation": f"Archived {total_archived} item(s)", "count": total_archived}


def delete_items_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    item_ids: list[int],
    *,
    is_admin: bool = False,
    session_id: int | None = None,
) -> dict:
    """Soft-delete items and all descendants. ADMIN ONLY."""
    if not is_admin:
        return {"error": "Only admins can delete items"}

    correlation_id = str(uuid.uuid4())

    # Validate scope access for each item
    for item_id in item_ids:
        existing, err = validate_item_access(db, item_id, scopes)
        if err:
            return err

    # Soft-delete all items and their descendants
    total_deleted = queries.items_soft_delete(db, item_ids, user_id)

    # Record history for each deleted item
    for item_id in item_ids:
        existing = queries.items_get_by_id(db, item_id)
        if existing:
            queries.history_insert(
                db,
                item_id,
                "deleted",
                "Item soft-deleted",
                user_id,
                session_id=session_id,
                correlation_id=correlation_id,
            )
            # Also record history for descendants
            child_ids = queries.items_get_children_ids(db, item_id, cascade=True)
            for child_id in child_ids:
                queries.history_insert(
                    db,
                    child_id,
                    "deleted",
                    "Item soft-deleted (cascade)",
                    user_id,
                    session_id=session_id,
                    correlation_id=correlation_id,
                )

    db.commit()
    return {"confirmation": f"Deleted {total_deleted} item(s)", "count": total_deleted}


def convert_item_impl(
    db: Database,
    user_id: str,
    scopes: list[str],
    item_id: int,
    new_type: str,
    *,
    session_id: int | None = None,
) -> dict:
    """Change an item's type.

    Rejects conversion to leaf type (fact/note/reminder) if item has children.
    Preserves children, tags, and history.
    """
    existing, err = validate_item_access(db, item_id, scopes)
    if err:
        return err

    # Check for children if converting to leaf type
    if new_type in _LEAF_TYPES:
        children = queries.items_get_children_ids(db, item_id)
        if children:
            return {"error": f"Cannot convert to '{new_type}': item has {len(children)} child(ren)"}

    old_type = existing["type"]
    if old_type == new_type:
        row = queries.items_get_by_id(db, item_id)
        return dict(row)

    # Convert also resets status to the new type's default
    new_status = _DEFAULT_STATUS[new_type]
    updates = {"type": new_type, "status": new_status}
    diff = queries.build_diff(existing, updates)
    queries.items_update(db, item_id, updates, user_id)

    # Record history
    queries.history_insert(
        db,
        item_id,
        "converted",
        diff,
        user_id,
        session_id=session_id,
    )

    db.commit()
    row = queries.items_get_by_id(db, item_id)
    return dict(row)


def register(mcp):
    """Register item CRUD MCP tools."""

    @mcp.tool
    def add_items(
        items: Annotated[
            list[ItemInput],
            Field(description="Items to create. Each needs at minimum: scope, type, and summary."),
        ],
    ) -> list[dict]:
        """Create one or more items. Each item needs a scope, type (task/project/fact/reminder/note/idea), and summary at minimum. To nest under a parent, set parent_id — the parent must be a project, task, or idea in the same scope."""
        return add_items_impl(
            get_db(),
            get_current_user(),
            get_current_scopes(),
            [item.model_dump() for item in items],
        )

    @mcp.tool
    def update_item(
        item_id: Annotated[int, Field(description="ID of the item to update.")],
        updates: Annotated[
            dict,
            Field(
                description="Partial update — only include fields you want to modify. Omitted fields are left unchanged. Valid keys: summary, detail, status, priority, due_date, valid_until, scope, position, source, metadata, tags. Tags replace all existing tags (pass [] to clear). Pass '' for due_date or valid_until to clear them."
            ),
        ],
    ) -> dict:
        """Modify an existing item's fields. Pass only the fields to change — others are preserved. Changing `scope` moves all children automatically. Use `complete_items` to mark items done — this tool rejects `status='completed'`. Use `add_note` to record context without changing fields."""
        return update_item_impl(
            get_db(), get_current_user(), get_current_scopes(), item_id, updates
        )

    @mcp.tool
    def complete_items(
        item_ids: Annotated[
            list[int],
            Field(
                description="IDs of items to mark as completed. Cascades to all descendants — children, grandchildren, etc. are also completed."
            ),
        ],
    ) -> dict:
        """Mark items as completed, including all their descendants. Use when work is finished. To hide items you no longer need, use archive_items instead. To soft-delete items, use delete_items."""
        return complete_items_impl(get_db(), get_current_user(), get_current_scopes(), item_ids)

    @mcp.tool
    def archive_items(
        item_ids: Annotated[
            list[int],
            Field(
                description="IDs of items to archive. Cascades to all descendants — children, grandchildren, etc. are also archived."
            ),
        ],
    ) -> dict:
        """Archive items and all their descendants. Archived items stop appearing in search and list results but can be found with status='archived'. To mark work as successfully finished, use complete_items instead. To soft-delete items, use delete_items."""
        return archive_items_impl(get_db(), get_current_user(), get_current_scopes(), item_ids)

    @mcp.tool
    def delete_items(
        item_ids: Annotated[
            list[int],
            Field(
                description="IDs of items to soft-delete. Cascades to all descendants. Deleted items can be restored."
            ),
        ],
    ) -> dict:
        """Soft-delete items and all their descendants. Items are flagged as deleted and excluded from all queries. Admin only. To mark work as finished, use complete_items. To hide items reversibly, use archive_items."""
        return delete_items_impl(
            get_db(), get_current_user(), get_current_scopes(), item_ids, is_admin=is_admin()
        )

    @mcp.tool
    def convert_item(
        item_id: Annotated[
            int, Field(description="ID of the item to convert. Children and history are preserved.")
        ],
        new_type: Annotated[
            Literal["task", "project", "fact", "reminder", "note", "idea"],
            Field(
                description="Target type. Cannot convert to a leaf type (fact, note, reminder) if the item has children."
            ),
        ],
    ) -> dict:
        """Change an item's type (e.g., task to project, idea to task). The item's status resets to the new type's default. Items with children can only become types that support children (project, task, idea). Types that cannot have children: fact, note, reminder."""
        return convert_item_impl(
            get_db(), get_current_user(), get_current_scopes(), item_id, new_type
        )
