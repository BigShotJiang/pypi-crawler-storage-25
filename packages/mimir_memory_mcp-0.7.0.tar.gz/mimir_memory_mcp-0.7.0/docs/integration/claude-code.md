# Integrating Mimir with Claude Code

## Prerequisites

- Mimir running (locally or via Docker)
- A user provisioned with an API key (see README)

## Step 1: Add MCP Server

Add to your project's `.mcp.json` (or global MCP config):

```json
{
  "mcpServers": {
    "mimir": {
      "url": "http://localhost:8100/sse",
      "headers": {
        "x-api-key": "YOUR_API_KEY"
      }
    }
  }
}
```

## Step 2: Add CLAUDE.md Snippet

Add the following to your `CLAUDE.md` to ensure Claude uses Mimir for all state management:

```markdown
## Memory (Mimir)

You MUST use the Mimir MCP tools for all persistent state management.
Do not use local files for tracking tasks, facts, or session state when
Mimir is available.

### Session Lifecycle (required)
- ALWAYS call `start_session` at the start of every conversation
- ALWAYS call `session_end` when the conversation ends, recording any
  learnings as facts
- Call `save_session` periodically during long sessions

### Working with Items
- Create tasks, projects, facts, reminders, notes, and ideas via `add_items`
- Use `set_context` to focus on a specific item when working on it
- Use `search_items` and `list_items` to find relevant context before acting
- Record important information as facts — they persist across sessions

### Principles
- If you learned something worth remembering, store it as a fact
- If the user asks you to do something later, create a task or reminder
- Always check existing context before creating duplicates
```

## Step 3: Restart Claude Code

Restart your Claude Code session. You should see 25 Mimir tools available. Test with:

> "Boot a session and show me what tools are available"

## Scopes

Mimir uses scopes to control access. Each user has a personal scope and can be added to shared scopes. When calling `start_session`, pass the scopes you want to activate:

```
start_session(scopes=["myuser", "shared-team"])
```
