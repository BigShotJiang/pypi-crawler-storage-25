# Search & Tool Signature Improvements — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Rename schema/tools for LLM usability, add porter stemming to FTS5 search, implement cascade complete, soft delete, and include_children, rewrite all tool descriptions and parameter descriptions.

**Architecture:** No production data exists — all changes go directly into `001_initial.sql` and existing Python files. No migrations needed. Changes are grouped: schema first, then queries, then models, then tools, then tests.

**Tech Stack:** Python 3.11, SQLite FTS5, FastMCP, Pydantic v2

**Spec:** `docs/specs/2026-03-31-search-and-tool-signatures-design.md`

---

### Task 1: Schema — Column Renames, FTS5 Porter Stemming, Status CHECK

**Files:**
- Modify: `src/mimir_mcp/migrations/001_initial.sql`

- [ ] **Step 1: Rename columns in items table**

Replace `l1_summary` with `summary` and `l2_detail` with `detail` in the items table definition:

```sql
    summary     TEXT NOT NULL,
    detail      TEXT,
```

- [ ] **Step 2: Add 'deleted' to status CHECK constraint**

```sql
    status      TEXT NOT NULL DEFAULT 'not_started'
                CHECK (status IN ('not_started','in_progress','blocked','completed','archived','active','expired','deleted')),
```

- [ ] **Step 3: Update FTS5 virtual table with porter stemming**

```sql
CREATE VIRTUAL TABLE items_fts USING fts5(
    summary, detail, content='items', content_rowid='id',
    tokenize='porter unicode61'
);
```

- [ ] **Step 4: Update all FTS triggers to use new column names**

```sql
CREATE TRIGGER items_fts_insert AFTER INSERT ON items BEGIN
    INSERT INTO items_fts(rowid, summary, detail)
        VALUES (NEW.id, NEW.summary, NEW.detail);
END;

CREATE TRIGGER items_fts_update AFTER UPDATE OF summary, detail ON items BEGIN
    INSERT INTO items_fts(items_fts, rowid, summary, detail)
        VALUES ('delete', OLD.id, OLD.summary, OLD.detail);
    INSERT INTO items_fts(rowid, summary, detail)
        VALUES (NEW.id, NEW.summary, NEW.detail);
END;

CREATE TRIGGER items_fts_delete AFTER DELETE ON items BEGIN
    INSERT INTO items_fts(items_fts, rowid, summary, detail)
        VALUES ('delete', OLD.id, OLD.summary, OLD.detail);
END;
```

- [ ] **Step 5: Update auto-timestamp trigger** (no column changes needed — verify it still references correct columns)

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/migrations/001_initial.sql
git commit -m "schema: rename l1_summary/l2_detail, add porter stemming, add deleted status"
```

---

### Task 2: Queries — Rename Column References, Update Status Exclusions

**Files:**
- Modify: `src/mimir_mcp/queries.py`

- [ ] **Step 1: Global rename l1_summary → summary and l2_detail → detail**

Find and replace all occurrences in queries.py:
- `l1_summary` → `summary` (in SQL strings and Python dict access)
- `l2_detail` → `detail` (in SQL strings and Python dict access)

Affected functions: `items_insert`, `items_insert_full`, `items_update`, `items_get_by_id`, `items_top_level_active`, `items_facts_by_scope`, `items_get_children`, `search_fts`, `items_list`, `items_facts_by_tags`, `items_facts_for_items`, `items_recent_by_others`, `activity_get_shared`, `items_session_activity`, `build_diff`.

- [ ] **Step 2: Update all status exclusion patterns to include 'deleted'**

Every `NOT IN ('completed', 'archived')` becomes `NOT IN ('completed', 'archived', 'deleted')`. Locations:

- `items_top_level_active()`
- `items_reminders_upcoming()`
- `search_fts()` (default status filter)
- `items_list()` (default status filter)
- `items_facts_by_tags()`
- `items_facts_for_items()`

Also update `items_facts_by_scope()` which filters `status = 'active'` — this already excludes deleted, but verify.

- [ ] **Step 3: Add recursive descendant fact query for include_children**

Add new query function `items_facts_for_descendants()`:

```python
def items_facts_for_descendants(db: Database, item_ids: list[int], scopes: list[str]) -> list:
    """Retrieve facts that are descendants (any depth) of the given items."""
    id_placeholders = ",".join("?" * len(item_ids))
    sp = ",".join("?" * len(scopes))
    sql = f"""
        WITH RECURSIVE descendants(id) AS (
            SELECT id FROM items WHERE parent_id IN ({id_placeholders})
            UNION ALL
            SELECT i.id FROM items i JOIN descendants d ON i.parent_id = d.id
        )
        SELECT i.*, GROUP_CONCAT(it.tag_id) as tags
        FROM items i
        LEFT JOIN item_tags it ON i.id = it.item_id
        WHERE i.id IN (SELECT id FROM descendants)
          AND i.type = 'fact'
          AND i.scope IN ({sp})
          AND i.status NOT IN ('completed', 'archived', 'deleted')
        GROUP BY i.id
    """
    return db.fetchall(sql, (*item_ids, *scopes))
```

- [ ] **Step 4: Add soft-delete query function**

Add `items_soft_delete()` to replace the hard delete in `items_delete()`:

```python
def items_soft_delete(db: Database, item_ids: list[int], user_id: str) -> int:
    """Soft-delete items and all descendants by setting status to 'deleted'."""
    deleted_count = 0
    for item_id in item_ids:
        # Get all descendant IDs via recursive CTE
        child_ids = items_get_children_ids(db, item_id, cascade=True)
        all_ids = [item_id] + child_ids
        placeholders = ",".join("?" * len(all_ids))
        db.execute(
            f"UPDATE items SET status = 'deleted', updated_by = ? WHERE id IN ({placeholders})",
            (user_id, *all_ids),
        )
        deleted_count += len(all_ids)
    return deleted_count
```

- [ ] **Step 5: Add cascade complete query function**

Add `items_complete_with_descendants()`:

```python
def items_complete_with_descendants(db: Database, item_id: int, user_id: str) -> list[int]:
    """Complete an item and all its descendants. Returns list of completed IDs."""
    child_ids = items_get_children_ids(db, item_id, cascade=True)
    all_ids = [item_id] + child_ids
    placeholders = ",".join("?" * len(all_ids))
    db.execute(
        f"UPDATE items SET status = 'completed', updated_by = ? WHERE id IN ({placeholders}) AND status != 'completed'",
        (user_id, *all_ids),
    )
    return all_ids
```

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/queries.py
git commit -m "queries: rename columns, add deleted exclusions, add cascade/soft-delete/descendant queries"
```

---

### Task 3: Models — Rename Fields, Add Descriptions, Literal Types

**Files:**
- Modify: `src/mimir_mcp/models.py`

- [ ] **Step 1: Rename ItemInput fields and add descriptions**

Replace `l1_summary` with `summary`, `l2_detail` with `detail`. Update all Field descriptions per spec section 7. Add the `type` description that explains lifecycle behavior. Update `source` description. etc.

Key changes:
```python
class ItemInput(BaseModel):
    scope: Annotated[str, Field(description="Scope this item belongs to (e.g., 'jimmy', 'household'). Must be a scope you have access to.")]
    type: Annotated[Literal["task", "project", "fact", "reminder", "note", "idea"], Field(description="Determines behavior and lifecycle. Tasks/projects track work and have status flow (not_started -> in_progress -> completed). Facts store persistent knowledge (support expiration via valid_until). Reminders are time-triggered alerts. Notes capture freeform context. Ideas are lightweight proposals.")]
    summary: Annotated[str, Field(description="Short, self-contained headline (1-2 sentences). Must be fully understandable without the detail field. Shown in session summaries and search results. Good: 'Alex is allergic to shellfish'. Bad: 'allergy info'.")]
    detail: Annotated[str | None, Field(default=None, description="Extended description, background, or specifications that don't fit in summary. Loaded on demand — not shown in search results or session summaries. Can be multi-paragraph. Omit or pass None if summary is sufficient.")]
    parent_id: Annotated[int | None, Field(default=None, description="Nest under this item. Parent must be a project, task, or idea in the same scope. Omit or pass None for a top-level item.")]
    tags: Annotated[list[str] | None, Field(default=None, description="Tag IDs to attach. Use suggest_tags first to find existing tags and avoid duplicates. Omit or pass None for no tags.")]
    priority: Annotated[Literal["urgent", "high", "normal", "low"] | None, Field(default=None, description="Affects sort order in listings — items are sorted by priority then position. Omit or pass None to leave unset.")]
    status: Annotated[str | None, Field(default=None, description="Override the type-specific default status. Defaults by type: task='not_started', project/fact/reminder/note/idea='active'. Other valid values: 'in_progress', 'completed', 'archived'. Use when an item is already in progress or completed.")]
    due_date: Annotated[str | None, Field(default=None, description="When this item is due (ISO 8601 date or datetime, e.g., '2025-06-15' or '2025-06-15T14:00:00'). Omit or pass None if no deadline.")]
    valid_until: Annotated[str | None, Field(default=None, description="Expiration date (ISO 8601, e.g., '2025-06-15'). Only enforced for fact-type items — expired facts are automatically excluded from queries. Silently stored but has no effect on other item types. Omit or pass None for no expiration.")]
    position: Annotated[float | None, Field(default=None, description="Sort position among siblings under the same parent. Lower values appear first. Use decimal values to insert between existing items (e.g., 1.5 between positions 1 and 2). Omit to leave unpositioned.")]
    source: Annotated[Literal["learned", "user_stated", "documented"] | None, Field(default=None, description="Origin of a fact — 'learned' = inferred by the system, 'user_stated' = told directly by the user, 'documented' = sourced from a document or reference. Only meaningful for type='fact'. Silently stored but ignored for other types.")]
    metadata: Annotated[dict | None, Field(default=None, description="Arbitrary key-value JSON data for integrations or custom workflows (e.g., {'url': '...', 'priority_score': 42}). Stored as-is. Not indexed for search — use tags for filterable categorization.")]
```

- [ ] **Step 2: Update output models**

Rename `l1_summary` → `summary` in `ItemSummary`, `l2_detail` → `detail` in `ItemDetail`, and `l1_summary` → `summary` in `SharedActivityEntry`.

- [ ] **Step 3: Update ReorderEntry with descriptions**

```python
class ReorderEntry(BaseModel):
    item_id: Annotated[int, Field(description="ID of the item to reposition.")]
    position: Annotated[float, Field(description="New sort position. Lower values appear first. Use decimals to insert between existing positions (e.g., 1.5 between 1 and 2).")]
```

- [ ] **Step 4: Commit**

```bash
git add src/mimir_mcp/models.py
git commit -m "models: rename fields to summary/detail, add parameter descriptions, update Literal types"
```

---

### Task 4: Server Instructions

**Files:**
- Modify: `src/mimir_mcp/server.py`

- [ ] **Step 1: Update the FastMCP instructions string**

Replace the current minimal instructions with the full server instructions from the spec:

```python
mcp = FastMCP(
    name="Mimir",
    instructions=(
        "Mimir is a structured memory server for AI assistants. All data is "
        "scoped to the authenticated user.\n\n"
        "Items are the core unit of memory. Each item has a type (task, project, "
        "fact, reminder, note, idea), belongs to a scope, and has a summary "
        "(short headline) and optional detail (extended description). Items can "
        "form trees: projects, tasks, and ideas can have children; facts, notes, "
        "and reminders cannot.\n\n"
        "Scopes are access groups. Each user has a personal scope plus any "
        "shared scopes (e.g., 'household'). You only see items in scopes you "
        "belong to.\n\n"
        "Session lifecycle -- follow this order:\n"
        "1. Call start_session once at conversation start. Returns your full context.\n"
        "2. Call save_session periodically during long conversations to preserve "
        "your position in shared activity.\n"
        "3. Call end_session when the conversation ends. Pass any new facts "
        "learned as learnings.\n\n"
        "Context focus:\n"
        "- Use set_context to drill into a specific item (shows its detail and "
        "children) or clear focus to return to the top-level overview.\n"
        "- Use refresh_context to reload the current view with fresh data when "
        "your conversation context has been compressed.\n\n"
        "Finding items:\n"
        "- search_items: keyword search with stemming. Use when you have words to find.\n"
        "- list_items: filtered browse by type, status, scope, parent. Use when "
        "you want to browse structure.\n"
        "- get_facts: retrieve facts by tag or parent item. Use for targeted fact lookup."
    ),
)
```

- [ ] **Step 2: Update l1_summary reference in boot_session shared activity**

In `server.py` or `session.py`, the boot response builds shared activity entries with `"l1_summary"` key — rename to `"summary"`.

- [ ] **Step 3: Commit**

```bash
git add src/mimir_mcp/server.py
git commit -m "server: update instructions with three-layer guidance model"
```

---

### Task 5: Session Tools — Rename and Describe

**Files:**
- Modify: `src/mimir_mcp/tools/session.py`

- [ ] **Step 1: Rename tool registrations and update docstrings**

```python
@mcp.tool(name="start_session")
def start_session_tool(
    scopes: Annotated[list[str], Field(description="Scope IDs to activate for this session (e.g., 'jimmy', 'household'). Only items in active scopes are visible. Use list_scopes to see available scopes.")]
) -> dict:
    """Start a new session and return your full current state: projects, tasks, ideas, reminders, facts, and recent changes by other users. Call once at the beginning of every conversation. Closes any leftover sessions from previous conversations automatically."""
    return boot_session(get_db(), get_current_user(), scopes)

@mcp.tool(name="end_session")
def end_session_tool(
    learnings: Annotated[list[str] | None, Field(default=None, description="New facts discovered this session. Each string is saved as a persistent fact (type='fact', source='learned') in your personal scope. For facts in shared scopes or with custom fields, use add_items with type='fact' instead. Pass None or omit to end without saving facts.")]
) -> dict:
    """End the current session. Pass learnings to save new facts that should persist across sessions. Marks all shared activity as seen and closes the session. Unlike save_session, this is permanent."""
    return end_session(get_db(), get_current_user(), learnings=learnings)

@mcp.tool(name="save_session")
def save_session_tool() -> dict:
    """Save progress mid-session without ending it. Marks shared activity as seen so you won't receive it again if the session is interrupted. Does not return data — use refresh_context to reload your current view."""
    return checkpoint_session(get_db(), get_current_user())
```

- [ ] **Step 2: Update l1_summary references in boot_session function**

Rename any dict key references from `"l1_summary"` to `"summary"` in the shared activity building code.

- [ ] **Step 3: Rename internal function references from `l1_summary` to `summary`**

Update any references to `item["l1_summary"]` → `item["summary"]` throughout the file.

- [ ] **Step 4: Commit**

```bash
git add src/mimir_mcp/tools/session.py
git commit -m "tools/session: rename to start_session/end_session/save_session, update descriptions"
```

---

### Task 6: Context Tools — Update Descriptions and Column References

**Files:**
- Modify: `src/mimir_mcp/tools/context.py`

- [ ] **Step 1: Update tool docstrings**

```python
@mcp.tool(name="set_context")
def set_context_tool(
    item_id: Annotated[int | None, Field(default=None, description="Item to focus on — returns its full detail, children, and relevant facts. Pass None to clear focus and return to the top-level overview.")]
) -> dict:
    """Focus on a specific item or return to the top-level overview. With item_id: returns that item's full detail, its children (summaries), and facts. With item_id=None: clears focus and returns the top-level summary (projects, tasks, ideas, reminders, facts). Does NOT reload session or shared activity — use refresh_context for that."""

@mcp.tool(name="refresh_context")
def refresh_context_tool() -> dict:
    """Reload your full current state without changing focus. Returns everything set_context shows, plus scopes with members, changes made during this session, and recent changes by other users. Use when your conversation context has been compressed and you need to rebuild working memory. Unlike start_session, does not create a new session."""
```

- [ ] **Step 2: Rename l2_detail references in _build_focused_view and _build_boot_summary**

Any dict access using `"l2_detail"` or `"l1_summary"` keys updated to `"detail"` and `"summary"`.

- [ ] **Step 3: Commit**

```bash
git add src/mimir_mcp/tools/context.py
git commit -m "tools/context: update descriptions and rename column references"
```

---

### Task 7: Item Tools — Cascade Complete, Soft Delete, Descriptions

**Files:**
- Modify: `src/mimir_mcp/tools/items.py`

- [ ] **Step 1: Rename l1_summary/l2_detail references throughout**

Update all `"l1_summary"` → `"summary"` and `"l2_detail"` → `"detail"` in dict access and string references.

- [ ] **Step 2: Rewrite complete_items to cascade**

```python
def complete_items(db: Database, user_id: str, scopes: list[str], item_ids: list[int],
                   *, session_id: int | None = None) -> dict:
    """Mark items as completed, cascading to all descendants."""
    completed_count = 0
    correlation_id = str(uuid.uuid4()) if len(item_ids) > 1 else None

    for item_id in item_ids:
        existing = queries.items_get_by_id(db, item_id)
        if not existing:
            continue
        if existing["scope"] not in scopes:
            return {"error": f"No access to item {item_id} in scope '{existing['scope']}'"}

        all_ids = queries.items_complete_with_descendants(db, item_id, user_id)
        for cid in all_ids:
            queries.history_insert(
                db, cid, "completed", "Item completed", user_id,
                session_id=session_id, correlation_id=correlation_id,
            )
        completed_count += len(all_ids)

    db.commit()
    return {"confirmation": f"Completed {completed_count} item(s)", "count": completed_count}
```

- [ ] **Step 3: Rewrite delete_items as soft delete**

```python
def delete_items(db: Database, user_id: str, scopes: list[str], item_ids: list[int],
                 *, is_admin: bool = False, session_id: int | None = None) -> dict:
    """Soft-delete items and all descendants."""
    if not is_admin:
        return {"error": "Admin privileges required for delete"}

    deleted_count = 0
    for item_id in item_ids:
        existing = queries.items_get_by_id(db, item_id)
        if not existing:
            continue
        if existing["scope"] not in scopes:
            return {"error": f"No access to item {item_id} in scope '{existing['scope']}'"}

        count = queries.items_soft_delete(db, [item_id], user_id)
        deleted_count += count

    db.commit()
    return {"confirmation": f"Deleted {deleted_count} item(s)", "count": deleted_count}
```

- [ ] **Step 4: Update all tool registrations with new docstrings and parameter descriptions**

Update `@mcp.tool` decorated functions with:
- New docstrings from spec section 5
- `Annotated[type, Field(description=...)]` for all parameters from spec section 7
- Import `Annotated` from `typing` and `Field` from `pydantic`

- [ ] **Step 5: Update convert_item new_type to Literal**

```python
from typing import Literal

@mcp.tool
def convert_item(
    item_id: Annotated[int, Field(description="ID of the item to convert. Children and history are preserved.")],
    new_type: Annotated[Literal["task", "project", "fact", "reminder", "note", "idea"], Field(description="Target type. The item's status resets to the new type's default. Cannot convert to a leaf type (fact, note, reminder) if the item has children.")]
) -> dict:
```

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/tools/items.py
git commit -m "tools/items: cascade complete, soft delete, update descriptions and param types"
```

---

### Task 8: Search Tools — Literal Types, include_children, Level Rename

**Files:**
- Modify: `src/mimir_mcp/tools/search.py`

- [ ] **Step 1: Rename l1_summary/l2_detail references**

Update dict key access and the level parameter values: `"l1"` → `"summary"`, `"l2"` → `"detail"`.

- [ ] **Step 2: Implement include_children in get_facts**

```python
def get_facts(db: Database, user_id: str, scopes: list[str],
              *, tags: list[str] | None = None, item_ids: list[int] | None = None,
              include_children: bool = False, level: str = "summary") -> list[dict]:
    results = []
    seen_ids = set()

    if tags:
        rows = queries.items_facts_by_tags(db, scopes, tags)
        for row in rows:
            d = dict(row)
            if d["id"] not in seen_ids:
                results.append(d)
                seen_ids.add(d["id"])

    if item_ids:
        # Direct children facts
        rows = queries.items_facts_for_items(db, item_ids, scopes)
        for row in rows:
            d = dict(row)
            if d["id"] not in seen_ids:
                results.append(d)
                seen_ids.add(d["id"])

        # Recursive descendant facts (if include_children=True)
        if include_children:
            rows = queries.items_facts_for_descendants(db, item_ids, scopes)
            for row in rows:
                d = dict(row)
                if d["id"] not in seen_ids:
                    results.append(d)
                    seen_ids.add(d["id"])

    _apply_lazy_expiry(db, results, user_id)
    db.commit()

    results = [r for r in results if r.get("status") != "expired"]

    if level == "summary":
        for r in results:
            r.pop("detail", None)

    return results
```

- [ ] **Step 3: Update tool registrations with Literal types and descriptions**

```python
from typing import Annotated, Literal
from pydantic import Field

ITEM_TYPE = Literal["task", "project", "fact", "reminder", "note", "idea"]
ITEM_STATUS = Literal["not_started", "in_progress", "blocked", "completed", "archived", "active", "expired", "deleted"]

@mcp.tool
def search_items(
    query: Annotated[str, Field(description="Full-text search query. Supports word stemming ('run' matches 'running'). Searches summary and detail fields. For unfiltered browsing by type/status, use list_items instead.")],
    type: Annotated[ITEM_TYPE | None, Field(default=None, description="Filter results to this item type. None (default) returns all types.")],
    status: Annotated[ITEM_STATUS | None, Field(default=None, description="Filter by status. None (default) excludes completed, archived, and deleted items. Pass a specific status to override (e.g., 'completed' to find finished items).")],
    tag: Annotated[str | None, Field(default=None, description="Filter to items with this tag ID. Accepts a single tag. For multi-tag OR queries on facts, use get_facts instead. None (default) skips tag filtering.")]
) -> list[dict]:
    """Full-text search across item summaries and details with word stemming (e.g., 'run' matches 'running'). Ranked by relevance. Excludes completed, archived, and deleted items by default — pass status to override. Returns up to 50 results. Do NOT use for browsing by structure — use list_items for that."""

@mcp.tool
def list_items(
    type: Annotated[ITEM_TYPE | None, Field(default=None, description="Filter results to this item type. None (default) returns all types.")],
    status: Annotated[ITEM_STATUS | None, Field(default=None, description="Filter by status. None (default) excludes completed and archived items. Pass a specific status to override (e.g., 'completed' to find finished items).")],
    parent_id: Annotated[int | None, Field(default=None, description="List children of this item. None (default) returns top-level items only (items with no parent). For recursive descent or detail inclusion, use list_children instead.")],
    scope: Annotated[str | None, Field(default=None, description="Narrow results to a single scope ID (e.g., 'jimmy'). None (default) returns items from all active scopes.")]
) -> list[dict]:
    """Browse items with filters, without keyword search. Shows top-level items by default. Pass parent_id to list children of a specific item. Filter by type, status, or scope. Sorted by priority then position. Do NOT use for text search — use search_items for that."""

@mcp.tool
def get_facts(
    tags: Annotated[list[str] | None, Field(default=None, description="Return facts tagged with any of these tag IDs (OR logic). None (default) skips tag filtering.")],
    item_ids: Annotated[list[int] | None, Field(default=None, description="Return facts that are children of these items. None (default) skips parent filtering.")],
    include_children: Annotated[bool, Field(default=False, description="When true, also return facts from all descendants of the specified item_ids, not just direct children. Default: false.")],
    level: Annotated[Literal["summary", "detail"], Field(default="summary", description="'summary' (default) returns headlines only for fast context loading. 'detail' includes the full detail field — use when you need specifics.")]
) -> list[dict]:
    """Retrieve facts by tags or by parent item. Tags use OR logic — returns facts matching any given tag. Pass item_ids to get facts attached as children of specific items. At least one filter required; without either, returns nothing. Excludes expired facts. Pass level='detail' for extended descriptions."""
```

- [ ] **Step 4: Commit**

```bash
git add src/mimir_mcp/tools/search.py
git commit -m "tools/search: add Literal types, implement include_children, rename level values"
```

---

### Task 9: Navigation Tools — Rename get_children, add_context, Update Descriptions

**Files:**
- Modify: `src/mimir_mcp/tools/navigation.py`

- [ ] **Step 1: Rename l1_summary/l2_detail references**

Update dict key access: `"l2_detail"` → `"detail"`, `"l1_summary"` → `"summary"`.

- [ ] **Step 2: Rename tool registrations and parameters**

```python
@mcp.tool(name="get_details")
def get_details(
    item_ids: Annotated[list[int], Field(description="IDs of items to fetch full detail for. Returns summary, detail, tags, metadata, timestamps — everything about each item. Items outside your active scopes are silently excluded.")]
) -> list[dict]:
    """Fetch full detail for one or more items by ID, including extended description, metadata, and timestamps. A read-only lookup — does NOT change your focus. Items not found or outside your scopes are silently omitted. To navigate into an item and see its children, use set_context instead."""

@mcp.tool(name="list_children")
def list_children(
    parent_id: Annotated[int, Field(description="ID of the parent item to list children of. Results are grouped by type.")],
    include_detail: Annotated[bool, Field(default=False, description="Include the extended detail field in results. Default (False) returns summaries only.")],
    cascade: Annotated[bool, Field(default=False, description="True to include all descendants recursively (children, grandchildren, etc.), not just direct children. Default: False.")]
) -> dict:
    """List direct children of an item, grouped by type. Returns summaries by default — pass include_detail=True for extended descriptions. Pass cascade=True for all descendants recursively. Do NOT use for top-level items — use list_items for that."""
    return _get_children(get_db(), get_current_user(), get_current_scopes(), parent_id,
                         include_detail=include_detail, cascade=cascade)

@mcp.tool(name="get_history")
def get_history(
    item_id: Annotated[int, Field(description="ID of the item to fetch change history for.")],
    since: Annotated[str | None, Field(default=None, description="Only include entries from this timestamp onward (ISO 8601 datetime, e.g., '2025-06-01T00:00:00'). None (default) for no lower bound.")],
    until: Annotated[str | None, Field(default=None, description="Only include entries up to this timestamp (ISO 8601 datetime). None (default) for no upper bound.")],
    limit: Annotated[int, Field(default=50, description="Maximum number of history entries to return. Newest entries are returned first.")]
) -> list[dict] | dict:
    """Get the change history for an item: who changed what, when, and how. Each entry shows the event type (created, updated, completed, etc.) and what changed. Supports time range filtering with since/until (ISO 8601). Returns up to 50 entries."""

@mcp.tool(name="add_note")
def add_note(
    item_id: Annotated[int, Field(description="ID of the item to attach the note to.")],
    note: Annotated[str, Field(description="Free-text note recorded in the item's history (event='context_added'). Use for background, decisions, observations, or status updates.")]
) -> dict:
    """Append a note to an item's history without modifying the item itself. Use for recording context, decisions, or observations. The note appears in get_history results. To change an item's summary, detail, or other fields, use update_item instead."""
    return _add_context(get_db(), get_current_user(), get_current_scopes(), item_id, note)
```

- [ ] **Step 3: Update internal get_children function to use include_detail parameter name**

Rename `include_l2` parameter to `include_detail` in the module-level `get_children()` function. Update the dict pop from `"l2_detail"` to `"detail"`.

- [ ] **Step 4: Commit**

```bash
git add src/mimir_mcp/tools/navigation.py
git commit -m "tools/navigation: rename to list_children/add_note, update params and descriptions"
```

---

### Task 10: Remaining Tools — Ordering, Scopes, Tags

**Files:**
- Modify: `src/mimir_mcp/tools/ordering.py`
- Modify: `src/mimir_mcp/tools/scopes.py`
- Modify: `src/mimir_mcp/tools/tags.py`

- [ ] **Step 1: Update ordering tool descriptions and parameters**

```python
@mcp.tool
def reorder_items(
    entries: Annotated[list[ReorderEntry], Field(description="List of {item_id, position} pairs. All items must share the same parent (or all be top-level). Positions auto-normalize when gaps get too small.")]
) -> dict:
    """Set display positions for items within the same parent. Positions are decimal numbers — use values between existing items to insert without renumbering. Automatically renumbers if positions get too close together."""
```

- [ ] **Step 2: Update scope tool descriptions and parameters**

```python
@mcp.tool
def list_scopes() -> list[dict]:
    """List your accessible scopes with their members."""

@mcp.tool
def create_scope(
    scope_id: Annotated[str, Field(description="Unique scope identifier (e.g., 'household', 'work-projects'). Lowercase letters, numbers, hyphens, and underscores only. Cannot be changed after creation.")],
    name: Annotated[str, Field(description="Human-readable display name for the scope (e.g., 'Household', 'Work Projects').")],
    description: Annotated[str | None, Field(default=None, description="What this scope is used for. Shown when listing scopes. None (default) for no description.")]
) -> dict:
    """Create a new scope. Admin only. You are added as the first member automatically."""

@mcp.tool
def add_scope_member(
    scope_id: Annotated[str, Field(description="ID of the scope to add the user to.")],
    member_user_id: Annotated[str, Field(description="User ID of the person to add.")]
) -> dict:
    """Add a user to a scope. Admin only."""

@mcp.tool
def remove_scope_member(
    scope_id: Annotated[str, Field(description="ID of the scope to remove the user from.")],
    member_user_id: Annotated[str, Field(description="User ID of the person to remove.")]
) -> dict:
    """Remove a user from a scope. Admin only. Items in the scope are preserved — only the user's access is removed."""
```

- [ ] **Step 3: Update tag tool descriptions and parameters**

```python
@mcp.tool
def suggest_tags(
    query: Annotated[str, Field(description="Tag name prefix to search for. Matches against tag IDs and aliases (e.g., 'pri' matches 'priority', 'private').")]
) -> list[dict]:
    """Autocomplete tags by prefix. Matches tag names and aliases. Use before adding tags to find existing ones and avoid duplicates."""

@mcp.tool
def list_tags(
    categories: Annotated[list[str] | None, Field(default=None, description="Filter to tags in these category IDs. None (default) returns all tags across all categories.")]
) -> list[dict]:
    """List all available tags, optionally filtered by category."""
```

- [ ] **Step 4: Commit**

```bash
git add src/mimir_mcp/tools/ordering.py src/mimir_mcp/tools/scopes.py src/mimir_mcp/tools/tags.py
git commit -m "tools: update ordering, scopes, tags descriptions and param types"
```

---

### Task 11: Update Tests

**Files:**
- Modify: `tests/conftest.py`
- Modify: `tests/test_auth.py`
- Modify: `tests/test_db.py`
- Modify: `tests/test_items.py`
- Modify: `tests/test_search.py`
- Modify: `tests/test_session.py`
- Modify: `tests/test_context.py`
- Modify: `tests/test_navigation.py`
- Modify: `tests/test_ordering.py`
- Modify: `tests/test_scopes.py`
- Modify: `tests/test_tags.py` (if exists)

- [ ] **Step 1: Global rename in all test files**

Find and replace across all test files:
- `l1_summary` → `summary`
- `l2_detail` → `detail`
- `include_l2` → `include_detail`
- `level="l1"` → `level="summary"`
- `level="l2"` → `level="detail"`
- `context_text` → `note`

- [ ] **Step 2: Update complete_items tests for cascade behavior**

In `test_items.py`, update the `TestCompleteItems` class:
- Tests that assert children are NOT completed must now assert they ARE completed
- Add a test verifying deep cascade (grandchildren completed too)

- [ ] **Step 3: Update delete_items tests for soft delete**

In `test_items.py`, update the `TestDeleteItems` class:
- Replace assertions that items are gone (hard delete) with assertions that items have `status='deleted'`
- Add test verifying soft-deleted items are excluded from default queries
- Add test verifying soft-deleted items can be found with `status='deleted'`

- [ ] **Step 4: Add include_children tests for get_facts**

In `test_search.py`, add tests in `TestGetFacts`:

```python
def test_get_facts_include_children(self, db, seed_data):
    """Facts nested under grandchildren are returned when include_children=True."""
    # Create project -> task -> fact hierarchy
    project_id = queries.items_insert(db, scope="jimmy", type="project",
        status="active", summary="Parent project", created_by="jimmy")
    task_id = queries.items_insert(db, scope="jimmy", type="task",
        status="not_started", summary="Child task", created_by="jimmy",
        parent_id=project_id)
    fact_id = queries.items_insert(db, scope="jimmy", type="fact",
        status="active", summary="Deep fact", created_by="jimmy",
        parent_id=task_id)
    db.commit()

    # Without include_children — only direct children facts
    results = get_facts(db, "jimmy", ["jimmy"], item_ids=[project_id])
    assert not any(f["id"] == fact_id for f in results)

    # With include_children — finds descendant facts
    results = get_facts(db, "jimmy", ["jimmy"], item_ids=[project_id],
                        include_children=True)
    assert any(f["id"] == fact_id for f in results)
```

- [ ] **Step 5: Add porter stemming test**

In `test_search.py`, add:

```python
def test_search_porter_stemming(self, db, seed_data):
    """Porter stemming matches word variations."""
    queries.items_insert(db, scope="jimmy", type="fact",
        status="active", summary="House has 3 bedrooms", created_by="jimmy")
    db.commit()

    # Singular should match plural
    results = search_items(db, "jimmy", ["jimmy"], "bedroom")
    assert len(results) == 1
    assert "bedrooms" in results[0]["summary"]

    # Verb forms should match
    queries.items_insert(db, scope="jimmy", type="task",
        status="not_started", summary="Running the migration", created_by="jimmy")
    db.commit()

    results = search_items(db, "jimmy", ["jimmy"], "run")
    assert any("Running" in r["summary"] for r in results)
```

- [ ] **Step 6: Run full test suite**

```bash
cd /home/marvin/repositories/private/mimir
python -m pytest tests/ -v
```

Expected: All 144+ tests pass (plus new tests).

- [ ] **Step 7: Commit**

```bash
git add tests/
git commit -m "tests: update for renames, cascade complete, soft delete, include_children, stemming"
```

---

### Task 12: Final Verification

- [ ] **Step 1: Run full test suite one more time**

```bash
python -m pytest tests/ -v --tb=short
```

All tests must pass.

- [ ] **Step 2: Rebuild Docker image and verify Mimir starts**

```bash
cd /home/marvin/repositories/private/mimir
docker build -t mimir-mcp .
docker run --rm -e MIMIR_DB_PATH=/data/mimir.db -v /tmp/mimir-test:/data mimir-mcp &
sleep 3
curl -sf http://localhost:8100/sse -m 3 -o /dev/null -w "%{http_code}"
# Expected: 200
docker stop $(docker ps -q --filter ancestor=mimir-mcp)
rm -rf /tmp/mimir-test
```

- [ ] **Step 3: Verify FTS stemming works end-to-end**

```bash
docker run --rm -e MIMIR_DB_PATH=/data/mimir.db -v /tmp/mimir-test:/data mimir-mcp python3 -c "
from mimir_mcp.db import init_db
db = init_db('/data/mimir.db')

# Seed test data
db.execute(\"INSERT INTO scopes (id, name) VALUES ('test', 'Test')\")
db.execute(\"INSERT INTO users (id, name, is_admin, api_key) VALUES ('u1', 'User', 0, 'key1')\")
db.execute(\"INSERT INTO scope_members (scope_id, user_id) VALUES ('test', 'u1')\")
db.execute(\"INSERT INTO items (scope, type, status, summary, created_by, updated_by) VALUES ('test', 'fact', 'active', 'House has 3 bedrooms', 'u1', 'u1')\")
db.commit()

# Test stemming
results = db.fetchall(\"SELECT * FROM items_fts WHERE items_fts MATCH 'bedroom'\")
assert len(results) == 1, f'Expected 1 result for bedroom, got {len(results)}'
print('Porter stemming: PASS')
"
rm -rf /tmp/mimir-test
```

- [ ] **Step 4: Push**

```bash
git push origin master
```
