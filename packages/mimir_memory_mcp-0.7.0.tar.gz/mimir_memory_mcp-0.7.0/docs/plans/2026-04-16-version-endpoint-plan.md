# Version Endpoint — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- []`) syntax for tracking.

**Goal:** Add an unauthenticated `GET /version` endpoint that returns the running server's package version and API contract version, and emit the same info to stdout at startup.

**Architecture:** One module-level helper (`_get_package_version`) that reads `importlib.metadata`. One new Starlette route registered via `@mcp.custom_route` inside `create_server()`, reusing the existing `_api_response` helper so the `X-Mimir-API-Version` header comes for free. One `print()` call added to `main()` before `server.run()`.

**Tech Stack:** Python 3.11, FastMCP, Starlette, pytest, importlib.metadata (stdlib)

**Spec:** `docs/specs/2026-04-16-version-endpoint-design.md`

---

## File Structure

- **Modify** `src/mimir_mcp/server.py`:
  - Add module-level imports for `importlib.metadata`
  - Add module-level `_get_package_version()` helper
  - Register `/version` route inside `create_server()` alongside `/health`
  - Add startup `print()` in `main()` before `server.run()`
- **Modify** `tests/test_rest.py`:
  - Add `TestVersionEndpoint` class with three tests, using the existing `client` fixture

No new files. No Dockerfile changes. No migration.

---

### Task 1: Version endpoint with shape test

**Files:**
- Modify: `src/mimir_mcp/server.py`
- Test: `tests/test_rest.py`

- [ ] **Step 1: Write the failing shape test**

Add this class to `tests/test_rest.py` after `TestHealthEndpoint`:

```python
class TestVersionEndpoint:
    def test_version_returns_200_and_shape(self, client):
        resp = client.get("/version")
        assert resp.status_code == 200
        body = resp.json()
        assert "version" in body
        assert isinstance(body["version"], str)
        assert body["version"]  # non-empty
        assert body["api_version"] == "1"
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `pytest tests/test_rest.py::TestVersionEndpoint::test_version_returns_200_and_shape -v`

Expected: FAIL with 404 response (route does not exist yet).

- [ ] **Step 3: Add the helper at module level in `server.py`**

In `src/mimir_mcp/server.py`, add the stdlib import alongside the existing stdlib imports at the top of the file (after line 5, `from pathlib import Path`):

```python
from importlib.metadata import PackageNotFoundError, version as pkg_version
```

Then, after the `MIMIR_API_VERSION = "1"` constant (around line 19), add the helper function:

```python
def _get_package_version() -> str:
    """Return the installed package version, or 'unknown' if metadata is missing."""
    try:
        return pkg_version("mimir-memory-mcp")
    except PackageNotFoundError:
        return "unknown"
```

- [ ] **Step 4: Register the `/version` route in `create_server`**

In `src/mimir_mcp/server.py`, inside `create_server()`, add the `/version` route immediately after the `/health` route (currently defined around lines 138-144). Place it before `/api/session/checkpoint`:

```python
    @mcp.custom_route("/version", methods=["GET"])
    async def version_route(request: Request) -> JSONResponse:
        return _api_response({
            "version": _get_package_version(),
            "api_version": MIMIR_API_VERSION,
        })
```

- [ ] **Step 5: Run the test to verify it passes**

Run: `pytest tests/test_rest.py::TestVersionEndpoint::test_version_returns_200_and_shape -v`

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/mimir_mcp/server.py tests/test_rest.py
git commit -m "feat(server): add /version endpoint"
```

---

### Task 2: No-auth and response-header tests

**Files:**
- Test: `tests/test_rest.py`

These are guardrail tests — the behaviors should already be satisfied by Task 1's implementation (no auth was added; `_api_response` is already in use). The tests lock in those properties so regressions fail loudly.

- [ ] **Step 1: Add the no-auth test**

In `tests/test_rest.py`, inside the `TestVersionEndpoint` class, add:

```python
    def test_version_no_auth_required(self, client):
        # No x-api-key header — still returns 200
        resp = client.get("/version")
        assert resp.status_code == 200
```

- [ ] **Step 2: Add the response-header test**

In `tests/test_rest.py`, inside the `TestVersionEndpoint` class, add:

```python
    def test_version_includes_api_version_header(self, client):
        resp = client.get("/version")
        assert resp.headers.get("X-Mimir-API-Version") == "1"
```

- [ ] **Step 3: Run the full `TestVersionEndpoint` class**

Run: `pytest tests/test_rest.py::TestVersionEndpoint -v`

Expected: all three tests PASS.

- [ ] **Step 4: Commit**

```bash
git add tests/test_rest.py
git commit -m "test(rest): guard /version no-auth policy and api-version header"
```

---

### Task 3: Startup version log

**Files:**
- Modify: `src/mimir_mcp/server.py` (function `main`, around lines 208-211)

No new test — the spec explicitly excludes a startup-log test (capturing stdout during `main()` is over-engineered for an observational print).

- [ ] **Step 1: Modify `main()` to print the version before serving**

In `src/mimir_mcp/server.py`, replace the existing else branch of `main()`:

Before:
```python
    else:
        port = int(os.environ.get("MIMIR_PORT", "8100"))
        server = create_server()
        server.run(transport="sse", host="0.0.0.0", port=port)
```

After:
```python
    else:
        port = int(os.environ.get("MIMIR_PORT", "8100"))
        server = create_server()
        print(
            f"Mimir v{_get_package_version()} "
            f"(api_version={MIMIR_API_VERSION}) listening on :{port}"
        )
        server.run(transport="sse", host="0.0.0.0", port=port)
```

- [ ] **Step 2: Run the full test suite to confirm nothing broke**

Run: `pytest tests/test_rest.py -v`

Expected: all REST tests PASS (including the three `TestVersionEndpoint` tests).

- [ ] **Step 3: Manually verify the startup log**

Run a quick dry-import to confirm the module still loads:

```bash
python -c "from mimir_mcp.server import _get_package_version, MIMIR_API_VERSION; print(f'Mimir v{_get_package_version()} (api_version={MIMIR_API_VERSION}) listening on :8100')"
```

Expected output (roughly):
```
Mimir v0.5.0 (api_version=1) listening on :8100
```

- [ ] **Step 4: Commit**

```bash
git add src/mimir_mcp/server.py
git commit -m "feat(server): log version and api_version at startup"
```

---

## After this plan

Not part of the plan, but for the release workflow:

1. Bump `version` in `pyproject.toml` (0.5.0 → 0.6.0 — minor, because a new client-visible endpoint is added).
2. Tag and push: `git tag v0.6.0 && git push --tags`.
3. Rebuild and redeploy the mimir container so the endpoint is actually reachable at `http://mimir:8100/version`.
4. Verify from a Claude session: `curl -s http://mimir:8100/version` (or via the Bash tool).
