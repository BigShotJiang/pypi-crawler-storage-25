# AI Assistant MCP Server — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the MCP server that manages structured data (items, sessions, scopes, tags) for the multi-user AI assistant platform, with scope-based access control and tiered context loading.

**Architecture:** Python FastMCP server with SQLite database. API key authentication maps each container's requests to a user. All data access filtered by caller's scopes. Tools follow MCP protocol, consumed by Claude Code in user containers.

**Tech Stack:** Python 3.11+, FastMCP 3.x, SQLite (with FTS5 and WAL mode), pytest, conda

**Spec:** `docs/specs/2026-03-20-multi-user-assistant-design.md`

---

## File Structure

```
ai-assistant/
├── pyproject.toml
├── src/
│   └── assistant_mcp/
│       ├── __init__.py
│       ├── server.py              # FastMCP instance, middleware, startup
│       ├── auth.py                # API key auth middleware + context vars
│       ├── db.py                  # Database wrapper, migration runner
│       ├── models.py              # Pydantic request/response models
│       ├── format.py             # Markdown response formatter for MCP tools
│       ├── queries.py            # Centralized SQL queries by domain
│       └── tools/
│           ├── __init__.py        # register_all_tools() helper
│           ├── session.py         # session_boot, session_end, checkpoint
│           ├── context.py         # set_context, refresh_context
│           ├── items.py           # add_items, update_item, complete/archive/delete/convert
│           ├── navigation.py      # get_details, get_children, get_history, add_context
│           ├── search.py          # search_items, list_items, get_facts
│           ├── tags.py            # suggest_tags, list_tags
│           ├── ordering.py        # reorder_items
│           └── scopes.py          # list_scopes, create_scope, add/remove member
├── migrations/
│   └── 001_initial.sql            # Full schema DDL from spec
├── tests/
│   ├── conftest.py                # Fixtures: test DB, seed data, auth helpers
│   ├── test_db.py
│   ├── test_auth.py
│   ├── test_session.py
│   ├── test_context.py
│   ├── test_items.py
│   ├── test_navigation.py
│   ├── test_search.py
│   ├── test_tags.py
│   ├── test_ordering.py
│   └── test_scopes.py
└── docs/
    ├── plans/
    └── specs/
```

### Module responsibilities

| Module | Responsibility |
|--------|---------------|
| `server.py` | Creates FastMCP instance, registers middleware and tools, provides `create_server()` and CLI entry point |
| `auth.py` | `AuthMiddleware` class (API key → user + scopes), `get_current_user()` / `get_current_scopes()` / `is_admin()` via contextvars, `set_auth_context()` for tests |
| `db.py` | `Database` class wrapping `sqlite3`, migration runner, `get_db()` / `init_db()` module-level accessors |
| `models.py` | Pydantic models for all tool inputs/outputs: `ItemInput`, `ItemOutput`, `SessionBootResponse`, etc. |
| `queries.py` | All raw SQL lives here, organized by domain (`items_*`, `sessions_*`, `scopes_*`, `tags_*`). Tool modules call these functions instead of writing inline SQL. Makes SQL auditable in one place and localizes any future database migration to a single file. |
| `format.py` | Converts query results into markdown-formatted strings for MCP tool responses. Markdown is more token-efficient than JSON for the LLM consumer and matches the tiered loading design. |
| `tools/*.py` | Each module exposes a `register(mcp)` function that decorates and registers its tools on the FastMCP instance |

### Code pattern

Every tool module follows the same structure. SQL queries live in `queries.py`, business logic in tool modules as plain functions that accept `db, user_id, scopes`, and MCP responses are formatted via `format.py`:

```python
# queries.py (all SQL in one place)
def items_get_by_scope(db, scopes, *, status_exclude=("completed", "archived")):
    placeholders = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT * FROM items WHERE scope IN ({placeholders}) "
        f"AND status NOT IN ({','.join('?' for _ in status_exclude)})",
        (*scopes, *status_exclude),
    )

# format.py (markdown responses)
def format_item_list(items, *, header="## Items"):
    if not items:
        return f"{header}\n\nNo items."
    lines = [header, ""]
    for item in items:
        priority = f" [{item['priority']}]" if item.get("priority", "normal") != "normal" else ""
        lines.append(f"- **#{item['id']}** {item['l1_summary']}{priority} ({item['status']})")
    return "\n".join(lines)

# tools/example.py (business logic + thin MCP wrapper)
from assistant_mcp.db import get_db
from assistant_mcp.auth import get_current_user, get_current_scopes
from assistant_mcp import queries, format

def do_something(db, user_id, scopes, param):
    """Pure business logic — testable without MCP."""
    results = queries.items_get_by_scope(db, scopes)
    # ... enforce rules, transform data
    return format.format_item_list(results)

def register(mcp):
    @mcp.tool
    def something(param: str) -> str:
        """MCP tool description for the AI to read."""
        return do_something(get_db(), get_current_user(), get_current_scopes(), param)
```

Tests call `do_something()` directly with a test db and seeded data.

### Error handling pattern

Business logic functions raise `ValueError` for client errors (bad input, scope violations, type mismatches) and let database errors propagate naturally. The `AuthMiddleware` in `server.py` catches `ValueError` and converts it to `ToolError` for the MCP protocol. Tests assert `pytest.raises(ValueError)` for expected failures.

```python
# In business logic:
def do_something(db, user_id, scopes, item_id):
    item = db.fetchone("SELECT * FROM items WHERE id = ?", (item_id,))
    if not item:
        raise ValueError(f"Item {item_id} not found")
    if item["scope"] not in scopes:
        raise ValueError(f"No access to item {item_id}")
    ...
```

### Scope list query pattern

SQLite does not support `IN (?)` with a Python list. All queries filtering by scopes must dynamically construct placeholders:

```python
placeholders = ",".join("?" for _ in scopes)
db.fetchall(
    f"SELECT * FROM items WHERE scope IN ({placeholders})",
    tuple(scopes),
)
```

This pattern applies everywhere `:scopes` appears in the pseudocode examples above.

---

## Task 1: Project Setup & Database Schema

**Files:**
- Create: `pyproject.toml`
- Create: `src/assistant_mcp/__init__.py`
- Create: `src/assistant_mcp/db.py`
- Create: `migrations/001_initial.sql`
- Create: `tests/conftest.py`
- Create: `tests/test_db.py`

### Steps

- [ ] **Step 1: Initialize git repo and conda env**

```bash
cd ~/repositories/private/ai-assistant
git init
conda create -n ai-assistant python=3.11 -y
conda activate ai-assistant
```

- [ ] **Step 2: Create pyproject.toml**

```toml
[project]
name = "assistant-mcp"
version = "0.1.0"
description = "Multi-user AI assistant MCP server"
requires-python = ">=3.11"
dependencies = [
    "fastmcp>=3.0",
    "pydantic>=2.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.24",
    "ruff>=0.8",
]

[project.scripts]
assistant-mcp = "assistant_mcp.server:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/assistant_mcp"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]

[tool.ruff]
target-version = "py311"
line-length = 100
```

- [ ] **Step 3: Install dependencies**

```bash
pip install -e ".[dev]"
```

- [ ] **Step 4: Create `.gitignore`**

```
__pycache__/
*.pyc
*.egg-info/
.pytest_cache/
dist/
build/
*.db
.ruff_cache/
```

- [ ] **Step 5: Create directory structure**

```bash
mkdir -p src/assistant_mcp/tools tests migrations
touch src/assistant_mcp/__init__.py
touch src/assistant_mcp/tools/__init__.py
```

- [ ] **Step 5: Write the migration — `migrations/001_initial.sql`**

Full schema from spec Section 3. This is the single source of truth for the database schema.

```sql
-- 001_initial.sql
-- Multi-user AI assistant platform schema

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- Access control
CREATE TABLE scopes (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT
);

CREATE TABLE users (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    profile     TEXT,
    is_admin    BOOLEAN DEFAULT FALSE,
    api_key     TEXT UNIQUE NOT NULL
);

CREATE TABLE scope_members (
    scope_id    TEXT REFERENCES scopes(id) ON DELETE CASCADE,
    user_id     TEXT REFERENCES users(id) ON DELETE CASCADE,
    PRIMARY KEY (scope_id, user_id)
);

-- Core items
CREATE TABLE items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    parent_id   INTEGER REFERENCES items(id) ON DELETE CASCADE,
    scope       TEXT NOT NULL REFERENCES scopes(id),
    type        TEXT NOT NULL CHECK (type IN ('task','project','fact','reminder','note','idea')),
    status      TEXT NOT NULL DEFAULT 'not_started'
                CHECK (status IN ('not_started','in_progress','blocked','completed','archived','active','expired')),
    priority    TEXT DEFAULT 'normal' CHECK (priority IN ('urgent','high','normal','low')),
    position    REAL,
    l1_summary  TEXT NOT NULL,
    l2_detail   TEXT,
    source      TEXT CHECK (source IN ('learned','user_stated','documented')),
    due_date    TEXT,
    valid_until TEXT,
    created_by  TEXT NOT NULL REFERENCES users(id),
    updated_by  TEXT NOT NULL REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    metadata    TEXT    -- JSON for extensible per-item-type fields (NULL by default, zero cost)
);

-- History (L3) — content stores structured JSON diffs, not free-text
-- Example: [{"field": "priority", "old": "normal", "new": "high"}]
CREATE TABLE item_history (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id         INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
    event           TEXT NOT NULL CHECK (event IN (
                        'created','updated','status_changed','context_added','completed','converted'
                    )),
    content         TEXT NOT NULL,
    actor           TEXT,
    session_id      INTEGER REFERENCES sessions(id),
    correlation_id  TEXT,   -- groups related changes (e.g. cascade operations share one ID)
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Tags
CREATE TABLE tags (
    id          TEXT PRIMARY KEY,
    aliases     TEXT,
    category    TEXT
);

CREATE TABLE item_tags (
    item_id     INTEGER REFERENCES items(id) ON DELETE CASCADE,
    tag_id      TEXT REFERENCES tags(id),
    PRIMARY KEY (item_id, tag_id)
);

-- Sessions
CREATE TABLE sessions (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             TEXT NOT NULL REFERENCES users(id),
    active_context_id   INTEGER REFERENCES items(id),
    started_at          TEXT NOT NULL DEFAULT (datetime('now')),
    ended_at            TEXT,
    summary             TEXT,
    log_path            TEXT
);

-- Shared activity tracking
CREATE TABLE activity_cursor (
    user_id                 TEXT PRIMARY KEY REFERENCES users(id),
    last_seen_history_id    INTEGER DEFAULT 0
);

-- Schema version tracking
CREATE TABLE schema_version (
    version     INTEGER PRIMARY KEY,
    applied_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Full-text search
CREATE VIRTUAL TABLE items_fts USING fts5(
    l1_summary, l2_detail, content='items', content_rowid='id'
);

CREATE TRIGGER items_fts_insert AFTER INSERT ON items BEGIN
    INSERT INTO items_fts(rowid, l1_summary, l2_detail)
        VALUES (NEW.id, NEW.l1_summary, NEW.l2_detail);
END;

CREATE TRIGGER items_fts_update AFTER UPDATE OF l1_summary, l2_detail ON items BEGIN
    INSERT INTO items_fts(items_fts, rowid, l1_summary, l2_detail)
        VALUES ('delete', OLD.id, OLD.l1_summary, OLD.l2_detail);
    INSERT INTO items_fts(rowid, l1_summary, l2_detail)
        VALUES (NEW.id, NEW.l1_summary, NEW.l2_detail);
END;

CREATE TRIGGER items_fts_delete AFTER DELETE ON items BEGIN
    INSERT INTO items_fts(items_fts, rowid, l1_summary, l2_detail)
        VALUES ('delete', OLD.id, OLD.l1_summary, OLD.l2_detail);
END;

-- Auto-maintained timestamps (WHEN guard prevents recursive trigger firing)
CREATE TRIGGER items_updated_at AFTER UPDATE ON items
WHEN NEW.updated_at = OLD.updated_at
BEGIN
    UPDATE items SET updated_at = datetime('now') WHERE id = NEW.id;
END;

-- Access enforcement triggers
CREATE TRIGGER enforce_insert_access
BEFORE INSERT ON items
BEGIN
    SELECT CASE
        WHEN NEW.scope NOT IN (
            SELECT scope_id FROM scope_members WHERE user_id = NEW.created_by
        )
        THEN RAISE(ABORT, 'User does not have access to this scope')
    END;
    SELECT CASE
        WHEN NEW.parent_id IS NOT NULL
            AND NEW.scope != (SELECT scope FROM items WHERE id = NEW.parent_id)
        THEN RAISE(ABORT, 'Child item must belong to same scope as parent')
    END;
    SELECT CASE
        WHEN NEW.parent_id IS NOT NULL
            AND (SELECT scope FROM items WHERE id = NEW.parent_id) NOT IN (
                SELECT scope_id FROM scope_members WHERE user_id = NEW.created_by
            )
        THEN RAISE(ABORT, 'User does not have access to parent item')
    END;
END;

CREATE TRIGGER enforce_update_access
BEFORE UPDATE ON items
BEGIN
    SELECT CASE
        WHEN OLD.scope NOT IN (
            SELECT scope_id FROM scope_members WHERE user_id = NEW.updated_by
        )
        THEN RAISE(ABORT, 'User does not have access to this item')
    END;
    SELECT CASE
        WHEN NEW.scope != OLD.scope
            AND NEW.scope NOT IN (
                SELECT scope_id FROM scope_members WHERE user_id = NEW.updated_by
            )
        THEN RAISE(ABORT, 'User does not have access to target scope')
    END;
END;

-- Indexes
CREATE INDEX idx_items_scope_parent_status ON items(scope, parent_id, status, type);
CREATE INDEX idx_items_parent ON items(parent_id);
CREATE INDEX idx_item_history_item_date ON item_history(item_id, created_at);
CREATE INDEX idx_item_history_session ON item_history(session_id);
CREATE INDEX idx_scope_members_user ON scope_members(user_id);
CREATE INDEX idx_item_tags_tag ON item_tags(tag_id);
CREATE INDEX idx_sessions_user ON sessions(user_id, ended_at);

INSERT INTO schema_version (version) VALUES (1);
```

- [ ] **Step 6: Write `src/assistant_mcp/db.py`**

```python
from __future__ import annotations

import sqlite3
from pathlib import Path

_db: Database | None = None


class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        return self.conn.execute(sql, params)

    def executemany(self, sql: str, params_seq) -> sqlite3.Cursor:
        return self.conn.executemany(sql, params_seq)

    def fetchone(self, sql: str, params: tuple = ()) -> sqlite3.Row | None:
        return self.conn.execute(sql, params).fetchone()

    def fetchall(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        return self.conn.execute(sql, params).fetchall()

    def commit(self):
        self.conn.commit()

    def close(self):
        self.conn.close()

    def get_schema_version(self) -> int:
        try:
            row = self.fetchone("SELECT MAX(version) as v FROM schema_version")
            return row["v"] if row and row["v"] else 0
        except sqlite3.OperationalError:
            return 0

    def run_migrations(self, migrations_dir: Path | None = None):
        if migrations_dir is None:
            migrations_dir = Path(__file__).parent.parent.parent / "migrations"
        current = self.get_schema_version()
        migration_files = sorted(migrations_dir.glob("*.sql"))
        for f in migration_files:
            version = int(f.name.split("_")[0])
            if version > current:
                self.conn.executescript(f.read_text())
                self.commit()


def get_db() -> Database:
    if _db is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    return _db


def init_db(db_path: str, migrations_dir: Path | None = None) -> Database:
    global _db
    _db = Database(db_path)
    _db.run_migrations(migrations_dir)
    # Re-assert after migrations (executescript may reset connection state)
    _db.conn.execute("PRAGMA foreign_keys = ON")
    return _db
```

- [ ] **Step 7: Write test fixtures — `tests/conftest.py`**

```python
import pytest
from pathlib import Path

from assistant_mcp.db import Database


MIGRATIONS_DIR = Path(__file__).parent.parent / "migrations"


@pytest.fixture
def db(tmp_path):
    """Fresh database with schema applied."""
    database = Database(str(tmp_path / "test.db"))
    database.run_migrations(MIGRATIONS_DIR)
    yield database
    database.close()


@pytest.fixture
def seed_data(db):
    """Seed test users, scopes, and memberships."""
    db.execute(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES (?, ?, ?, ?)",
        ("jimmy", "Jimmy", True, "key-jimmy"),
    )
    db.execute(
        "INSERT INTO users (id, name, is_admin, api_key) VALUES (?, ?, ?, ?)",
        ("alex", "Alex", False, "key-alex"),
    )
    db.execute("INSERT INTO scopes VALUES (?, ?, ?)", ("jimmy", "Jimmy", "Jimmy personal"))
    db.execute("INSERT INTO scopes VALUES (?, ?, ?)", ("alex", "Alex", "Alex personal"))
    db.execute(
        "INSERT INTO scopes VALUES (?, ?, ?)",
        ("household", "Household", "Shared household tasks"),
    )
    db.execute("INSERT INTO scope_members VALUES (?, ?)", ("jimmy", "jimmy"))
    db.execute("INSERT INTO scope_members VALUES (?, ?)", ("alex", "alex"))
    db.execute("INSERT INTO scope_members VALUES (?, ?)", ("household", "jimmy"))
    db.execute("INSERT INTO scope_members VALUES (?, ?)", ("household", "alex"))
    db.execute("INSERT INTO activity_cursor VALUES (?, ?)", ("jimmy", 0))
    db.execute("INSERT INTO activity_cursor VALUES (?, ?)", ("alex", 0))
    db.commit()
    return db
```

- [ ] **Step 8: Write the failing tests — `tests/test_db.py`**

```python
from pathlib import Path

from assistant_mcp.db import Database

MIGRATIONS_DIR = Path(__file__).parent.parent / "migrations"


def test_migration_creates_tables(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    tables = [
        row[0]
        for row in db.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        )
    ]
    expected = [
        "activity_cursor", "item_history", "item_tags", "items",
        "schema_version", "scope_members", "scopes", "sessions", "tags", "users",
    ]
    for t in expected:
        assert t in tables, f"Missing table: {t}"
    db.close()


def test_schema_version_is_1(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    assert db.get_schema_version() == 1
    db.close()


def test_foreign_keys_enabled(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    result = db.fetchone("PRAGMA foreign_keys")
    assert result[0] == 1
    db.close()


def test_migration_is_idempotent(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    db.run_migrations(MIGRATIONS_DIR)
    assert db.get_schema_version() == 1
    db.close()


def test_fts5_index_exists(tmp_path):
    db = Database(str(tmp_path / "test.db"))
    db.run_migrations(MIGRATIONS_DIR)
    tables = [
        row[0]
        for row in db.fetchall(
            "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%fts%'"
        )
    ]
    assert "items_fts" in tables
    db.close()


# --- C6: SQL access enforcement trigger tests ---

def test_insert_trigger_rejects_wrong_scope(seed_data):
    """enforce_insert_access rejects items in scopes the user doesn't belong to."""
    import sqlite3
    with pytest.raises(sqlite3.IntegrityError, match="does not have access to this scope"):
        seed_data.execute(
            "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("alex", "task", "not_started", "Sneaky task", "jimmy", "jimmy"),
        )


def test_insert_trigger_rejects_cross_scope_parent(seed_data):
    """Child must belong to same scope as parent."""
    import sqlite3
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "project", "not_started", "Parent", "jimmy", "jimmy"),
    )
    parent_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.commit()
    with pytest.raises(sqlite3.IntegrityError, match="same scope as parent"):
        seed_data.execute(
            "INSERT INTO items (parent_id, scope, type, status, l1_summary, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (parent_id, "jimmy", "task", "not_started", "Wrong scope child", "jimmy", "jimmy"),
        )


def test_update_trigger_rejects_wrong_scope(seed_data):
    """enforce_update_access rejects updates by users outside the item's scope."""
    import sqlite3
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("jimmy", "task", "not_started", "Jimmy's task", "jimmy", "jimmy"),
    )
    seed_data.commit()
    item_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    with pytest.raises(sqlite3.IntegrityError, match="does not have access"):
        seed_data.execute(
            "UPDATE items SET l1_summary = 'Hacked', updated_by = 'alex' WHERE id = ?",
            (item_id,),
        )


# --- C7: FTS5 sync trigger tests ---

def test_fts5_insert_sync(seed_data):
    """Inserting an item makes it searchable via FTS5."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Alex is allergic to shellfish", "jimmy", "jimmy"),
    )
    seed_data.commit()
    results = seed_data.fetchall(
        "SELECT rowid FROM items_fts WHERE items_fts MATCH 'shellfish'"
    )
    assert len(results) == 1


def test_fts5_update_sync(seed_data):
    """Updating l1_summary updates the FTS5 index."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Old summary text", "jimmy", "jimmy"),
    )
    seed_data.commit()
    item_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute(
        "UPDATE items SET l1_summary = 'New summary about dolphins', updated_by = 'jimmy' "
        "WHERE id = ?",
        (item_id,),
    )
    seed_data.commit()
    old = seed_data.fetchall("SELECT rowid FROM items_fts WHERE items_fts MATCH 'Old'")
    new = seed_data.fetchall("SELECT rowid FROM items_fts WHERE items_fts MATCH 'dolphins'")
    assert len(old) == 0
    assert len(new) == 1


def test_fts5_delete_sync(seed_data):
    """Deleting an item removes it from FTS5 index."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Temporary fact about penguins", "jimmy", "jimmy"),
    )
    seed_data.commit()
    item_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("DELETE FROM items WHERE id = ?", (item_id,))
    seed_data.commit()
    results = seed_data.fetchall(
        "SELECT rowid FROM items_fts WHERE items_fts MATCH 'penguins'"
    )
    assert len(results) == 0
```

- [ ] **Step 9: Run tests to verify they pass**

```bash
cd ~/repositories/private/ai-assistant
pytest tests/test_db.py -v
```

Expected: all 11 tests PASS.

- [ ] **Step 10: Commit**

```bash
git add pyproject.toml src/ migrations/ tests/ docs/
git commit -m "feat: project setup with database schema and migration runner"
```

---

## Task 2: Authentication Middleware

**Files:**
- Create: `src/assistant_mcp/auth.py`
- Create: `tests/test_auth.py`

### Steps

- [ ] **Step 1: Write the failing tests — `tests/test_auth.py`**

```python
import pytest

from assistant_mcp.auth import (
    get_current_user,
    get_current_scopes,
    is_admin,
    resolve_user,
    set_auth_context,
)


def test_resolve_user_valid_key(seed_data):
    user_id, scopes, admin = resolve_user(seed_data, "key-jimmy")
    assert user_id == "jimmy"
    assert "jimmy" in scopes
    assert "household" in scopes
    assert "alex" not in scopes
    assert admin is True


def test_resolve_user_invalid_key(seed_data):
    result = resolve_user(seed_data, "invalid-key")
    assert result is None


def test_resolve_user_non_admin(seed_data):
    user_id, scopes, admin = resolve_user(seed_data, "key-alex")
    assert user_id == "alex"
    assert "alex" in scopes
    assert "household" in scopes
    assert "jimmy" not in scopes
    assert admin is False


def test_set_and_get_auth_context():
    set_auth_context("jimmy", ["jimmy", "household"], is_admin=True)
    assert get_current_user() == "jimmy"
    assert get_current_scopes() == ["jimmy", "household"]
    assert is_admin() is True


def test_auth_context_overwrite():
    set_auth_context("jimmy", ["jimmy"], is_admin=True)
    assert get_current_user() == "jimmy"
    set_auth_context("alex", ["alex", "household"], is_admin=False)
    assert get_current_user() == "alex"
    assert is_admin() is False
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_auth.py -v
```

Expected: FAIL (module not found).

- [ ] **Step 3: Implement `src/assistant_mcp/auth.py`**

```python
from __future__ import annotations

from contextvars import ContextVar

from assistant_mcp.db import Database

_current_user_id: ContextVar[str] = ContextVar("current_user_id")
_current_user_scopes: ContextVar[list[str]] = ContextVar("current_user_scopes")
_current_user_is_admin: ContextVar[bool] = ContextVar("current_user_is_admin")


def get_current_user() -> str:
    return _current_user_id.get()


def get_current_scopes() -> list[str]:
    return _current_user_scopes.get()


def is_admin() -> bool:
    return _current_user_is_admin.get()


def set_auth_context(user_id: str, scopes: list[str], *, is_admin: bool = False):
    _current_user_id.set(user_id)
    _current_user_scopes.set(scopes)
    _current_user_is_admin.set(is_admin)


def resolve_user(db: Database, api_key: str) -> tuple[str, list[str], bool] | None:
    user = db.fetchone("SELECT id, is_admin FROM users WHERE api_key = ?", (api_key,))
    if not user:
        return None
    scopes = [
        row["scope_id"]
        for row in db.fetchall(
            "SELECT scope_id FROM scope_members WHERE user_id = ?", (user["id"],)
        )
    ]
    return user["id"], scopes, bool(user["is_admin"])
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_auth.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/assistant_mcp/auth.py tests/test_auth.py
git commit -m "feat: auth module with API key resolution and context vars"
```

---

## Task 3: Pydantic Models

**Files:**
- Create: `src/assistant_mcp/models.py`

No separate test file — models are validated through usage in tool tests.

### Steps

- [ ] **Step 1: Write `src/assistant_mcp/models.py`**

```python
from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, Field


# --- Input models ---

class ItemInput(BaseModel):
    scope: Annotated[str, Field(
        description="Access scope this item belongs to. Must be one of your "
        "accessible scopes (e.g. 'jimmy', 'household')."
    )]
    type: Annotated[Literal["task", "project", "fact", "reminder", "note", "idea"], Field(
        description="Item type. 'task' = actionable work, 'project' = collection of "
        "related work, 'fact' = something to remember, 'reminder' = time-sensitive "
        "alert, 'note' = free-form info, 'idea' = something to explore."
    )]
    l1_summary: Annotated[str, Field(
        description="Short, self-contained headline (1-2 sentences). Must be fully "
        "understandable without l2_detail. Shown in boot summaries and search results. "
        "Good: 'Alex is allergic to shellfish'. Bad: 'allergy info'."
    )]
    l2_detail: Annotated[str | None, Field(
        default=None,
        description="Extended details loaded on demand. Can be multi-paragraph."
    )]
    parent_id: Annotated[int | None, Field(
        default=None,
        description="Parent item ID. Parent must be project/task/idea in same scope."
    )]
    tags: Annotated[list[str] | None, Field(
        default=None,
        description="Tag IDs. Use suggest_tags() first to avoid duplicates."
    )]
    priority: Annotated[
        Literal["urgent", "high", "normal", "low"] | None,
        Field(default=None, description="Priority level. Default: 'normal'.")
    ]
    status: Annotated[str | None, Field(
        default=None,
        description="Override default status. Use when item is already in progress."
    )]
    due_date: Annotated[str | None, Field(
        default=None, description="ISO 8601 date or datetime."
    )]
    valid_until: Annotated[str | None, Field(
        default=None,
        description="ISO 8601 date. Facts past this date stop surfacing in queries."
    )]
    position: Annotated[float | None, Field(
        default=None, description="Sort position among siblings. Fractional indexing."
    )]
    source: Annotated[
        Literal["learned", "user_stated", "documented"] | None,
        Field(default=None, description="How fact was obtained. Only for type='fact'.")
    ]
    metadata: Annotated[dict | None, Field(
        default=None,
        description="Extensible JSON for item-type-specific fields. Stored as-is."
    )]


class ReorderEntry(BaseModel):
    item_id: int
    position: float


# --- Output models ---

class ScopeOutput(BaseModel):
    id: str
    name: str
    description: str | None = None
    members: list[dict] | None = None


class ItemSummary(BaseModel):
    id: int
    type: str
    scope: str
    status: str
    priority: str | None = None
    l1_summary: str
    tags: list[str] = []
    due_date: str | None = None
    position: float | None = None


class ItemDetail(ItemSummary):
    l2_detail: str | None = None
    source: str | None = None
    valid_until: str | None = None
    metadata: dict | None = None
    created_by: str | None = None
    updated_by: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class HistoryEntry(BaseModel):
    event: str
    content: str  # JSON structured diff, e.g. [{"field": "priority", "old": "normal", "new": "high"}]
    actor: str | None = None
    session_id: int | None = None
    correlation_id: str | None = None
    created_at: str | None = None


class SharedActivityEntry(BaseModel):
    item_id: int
    l1_summary: str
    event: str
    actor: str
    created_at: str


class SessionBootResponse(BaseModel):
    user: dict
    scopes: list[ScopeOutput]
    last_session: dict | None = None
    stale_sessions: int = 0
    projects: list[ItemSummary] = []
    tasks: list[ItemSummary] = []
    reminders: list[ItemSummary] = []
    ideas: list[ItemSummary] = []
    global_facts: dict[str, list[dict]] = {}
    recent_shared_activity: list[SharedActivityEntry] = []
```

- [ ] **Step 2: Verify models import correctly**

```bash
python -c "from assistant_mcp.models import ItemInput, SessionBootResponse; print('OK')"
```

Expected: `OK`

- [ ] **Step 3: Commit**

```bash
git add src/assistant_mcp/models.py
git commit -m "feat: pydantic models for MCP tool inputs and outputs"
```

---

## Task 4: Query Layer, Formatter & Diff Helpers

**Files:**
- Create: `src/assistant_mcp/queries.py`
- Create: `src/assistant_mcp/format.py`
- Create: `tests/test_format.py`

### Steps

- [ ] **Step 1: Write `src/assistant_mcp/queries.py`**

Centralize all SQL queries as named functions. Organized by domain with a consistent naming convention (`{domain}_{operation}`). Each function takes `db` plus parameters and returns raw rows or scalars.

```python
"""Centralized SQL queries. All raw SQL lives here."""
from __future__ import annotations

import json
from assistant_mcp.db import Database


# --- Scope queries ---

def scopes_for_user(db: Database, user_id: str) -> list:
    return db.fetchall(
        "SELECT s.*, GROUP_CONCAT(DISTINCT sm2.user_id) as member_ids "
        "FROM scopes s "
        "JOIN scope_members sm ON s.id = sm.scope_id "
        "JOIN scope_members sm2 ON s.id = sm2.scope_id "
        "WHERE sm.user_id = ? GROUP BY s.id",
        (user_id,),
    )


# --- Session queries ---

def sessions_close_stale(db: Database, user_id: str) -> int:
    """Close stale sessions, return count closed."""
    stale = db.fetchall(
        "SELECT id FROM sessions WHERE user_id = ? AND ended_at IS NULL",
        (user_id,),
    )
    if stale:
        ids = [s["id"] for s in stale]
        placeholders = ",".join("?" for _ in ids)
        db.execute(
            f"UPDATE sessions SET ended_at = datetime('now'), summary = 'Auto-closed' "
            f"WHERE id IN ({placeholders})",
            tuple(ids),
        )
    return len(stale)


def sessions_create(db: Database, user_id: str) -> int:
    cursor = db.execute("INSERT INTO sessions (user_id) VALUES (?)", (user_id,))
    return cursor.lastrowid


def sessions_get_last_completed(db: Database, user_id: str):
    return db.fetchone(
        "SELECT * FROM sessions WHERE user_id = ? AND ended_at IS NOT NULL "
        "ORDER BY ended_at DESC LIMIT 1",
        (user_id,),
    )


def sessions_get_active(db: Database, user_id: str):
    return db.fetchone(
        "SELECT * FROM sessions WHERE user_id = ? AND ended_at IS NULL "
        "ORDER BY id DESC LIMIT 1",
        (user_id,),
    )


# --- Item queries ---

def items_top_level_active(db: Database, scopes: list[str], *, exclude_types=(), exclude_statuses=("completed", "archived")):
    """Boot query: top-level active items across scopes."""
    sp = ",".join("?" for _ in scopes)
    tp = ",".join("?" for _ in exclude_types) if exclude_types else None
    stp = ",".join("?" for _ in exclude_statuses)
    sql = (
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags "
        f"FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.scope IN ({sp}) AND i.parent_id IS NULL "
        f"AND i.status NOT IN ({stp}) "
    )
    params = list(scopes) + list(exclude_statuses)
    if exclude_types:
        sql += f"AND i.type NOT IN ({tp}) "
        params.extend(exclude_types)
    sql += "GROUP BY i.id ORDER BY i.priority, i.position"
    return db.fetchall(sql, tuple(params))


def items_facts_by_scope(db: Database, scopes: list[str]):
    """Global facts index for boot, grouped by tag."""
    sp = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags "
        f"FROM items i LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.scope IN ({sp}) AND i.type = 'fact' "
        f"AND i.status = 'active' "
        f"AND (i.valid_until IS NULL OR i.valid_until > datetime('now')) "
        f"GROUP BY i.id",
        tuple(scopes),
    )


def items_get_children(db: Database, parent_id: int, scopes: list[str], *, cascade: bool = False):
    sp = ",".join("?" for _ in scopes)
    if cascade:
        return db.fetchall(
            f"WITH RECURSIVE subtree(id, depth) AS ( "
            f"  SELECT id, 1 FROM items WHERE parent_id = ? "
            f"  UNION ALL "
            f"  SELECT i.id, s.depth + 1 FROM items i JOIN subtree s ON i.parent_id = s.id "
            f"  WHERE s.depth < 10 "
            f") "
            f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags FROM items i "
            f"LEFT JOIN item_tags it ON i.id = it.item_id "
            f"WHERE i.id IN (SELECT id FROM subtree) AND i.scope IN ({sp}) "
            f"GROUP BY i.id ORDER BY i.type, i.position",
            (parent_id, *scopes),
        )
    return db.fetchall(
        f"SELECT i.*, GROUP_CONCAT(it.tag_id) as tags FROM items i "
        f"LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE i.parent_id = ? AND i.scope IN ({sp}) "
        f"GROUP BY i.id ORDER BY i.type, i.position",
        (parent_id, *scopes),
    )


# --- History queries ---

def history_insert(db: Database, item_id: int, event: str, content, actor: str,
                   *, session_id: int | None = None, correlation_id: str | None = None):
    """Insert a history entry. Content should be a list of diffs or a string."""
    content_str = json.dumps(content) if isinstance(content, (list, dict)) else content
    db.execute(
        "INSERT INTO item_history (item_id, event, content, actor, session_id, correlation_id) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (item_id, event, content_str, actor, session_id, correlation_id),
    )


def history_for_item(db: Database, item_id: int, *, since=None, until=None, limit=50):
    sql = "SELECT * FROM item_history WHERE item_id = ?"
    params = [item_id]
    if since:
        sql += " AND created_at >= ?"
        params.append(since)
    if until:
        sql += " AND created_at <= ?"
        params.append(until)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    return db.fetchall(sql, tuple(params))


# --- Activity cursor queries ---

def activity_get_shared(db: Database, user_id: str, scopes: list[str]):
    """Get shared activity since user's cursor."""
    cursor = db.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = ?",
        (user_id,),
    )
    cursor_id = cursor["last_seen_history_id"] if cursor else 0
    sp = ",".join("?" for _ in scopes)
    return db.fetchall(
        f"SELECT h.*, i.l1_summary, i.scope FROM item_history h "
        f"JOIN items i ON h.item_id = i.id "
        f"WHERE h.id > ? AND h.actor != ? AND i.scope IN ({sp}) "
        f"ORDER BY h.created_at DESC LIMIT 50",
        (cursor_id, user_id, *scopes),
    )


def activity_advance_cursor(db: Database, user_id: str):
    max_id = db.fetchone("SELECT MAX(id) as m FROM item_history")
    new_cursor = max_id["m"] if max_id and max_id["m"] else 0
    db.execute(
        "UPDATE activity_cursor SET last_seen_history_id = ? WHERE user_id = ?",
        (new_cursor, user_id),
    )


# --- Search queries ---

def search_fts(db: Database, query: str, scopes: list[str], **filters):
    """FTS5 search with scope + optional type/status/tag filters."""
    sp = ",".join("?" for _ in scopes)
    sql = (
        f"SELECT i.*, rank, GROUP_CONCAT(it.tag_id) as tags "
        f"FROM items_fts fts "
        f"JOIN items i ON fts.rowid = i.id "
        f"LEFT JOIN item_tags it ON i.id = it.item_id "
        f"WHERE items_fts MATCH ? AND i.scope IN ({sp}) "
    )
    params = [query, *scopes]
    if filters.get("type"):
        sql += "AND i.type = ? "
        params.append(filters["type"])
    if filters.get("status"):
        sql += "AND i.status = ? "
        params.append(filters["status"])
    else:
        sql += "AND i.status NOT IN ('completed', 'archived') "
    sql += "GROUP BY i.id ORDER BY rank LIMIT 50"
    return db.fetchall(sql, tuple(params))
```

This module will grow as tools are implemented. Each tool task adds the queries it needs here.

- [ ] **Step 2: Write `src/assistant_mcp/format.py`**

Markdown formatter for MCP tool responses. Produces token-efficient output for the LLM consumer.

```python
"""Markdown response formatter for MCP tools.

MCP tool responses are consumed by an LLM (Claude). Markdown is more
token-efficient than JSON for narrative data and matches how the AI
naturally reads and reasons about context.
"""
from __future__ import annotations

import json


def format_boot(data: dict) -> str:
    """Format session_boot response as markdown."""
    lines = [f"# Session Boot — {data['user']['name']}", ""]

    if data.get("stale_sessions"):
        lines.append(f"**Note:** Auto-closed {data['stale_sessions']} stale session(s).\n")

    if data.get("last_session"):
        lines.append(f"**Last session:** {data['last_session'].get('summary', 'No summary')}\n")

    # Scopes
    lines.append("## Your Scopes")
    for scope in data.get("scopes", []):
        members = scope.get("members", "")
        lines.append(f"- **{scope['name']}** (`{scope['id']}`) — members: {members}")
    lines.append("")

    # Items by type
    for section, key in [("Projects", "projects"), ("Tasks", "tasks"),
                         ("Reminders", "reminders"), ("Ideas", "ideas")]:
        items = data.get(key, [])
        if items:
            lines.append(f"## {section}")
            lines.extend(_format_item_lines(items))
            lines.append("")

    # Facts
    facts = data.get("global_facts", {})
    if facts:
        lines.append("## Facts")
        for tag, tag_facts in facts.items():
            lines.append(f"### {tag}")
            for f in tag_facts:
                lines.append(f"- {f['l1_summary']}")
        lines.append("")

    # Shared activity
    activity = data.get("recent_shared_activity", [])
    if activity:
        lines.append("## Recent Shared Activity")
        for a in activity:
            lines.append(f"- **{a['actor']}** {a['event']}: {a['l1_summary']} ({a['created_at']})")
        lines.append("")

    return "\n".join(lines)


def format_items(items: list[dict], *, header: str = "## Items") -> str:
    """Format a list of items as markdown."""
    if not items:
        return f"{header}\n\nNo items."
    lines = [header, ""]
    lines.extend(_format_item_lines(items))
    return "\n".join(lines)


def format_item_detail(item: dict) -> str:
    """Format a single item with full L2 detail."""
    lines = [f"# {item['l1_summary']}", ""]
    lines.append(f"**Type:** {item['type']} | **Status:** {item['status']} | "
                 f"**Scope:** {item['scope']}")
    if item.get("priority", "normal") != "normal":
        lines.append(f"**Priority:** {item['priority']}")
    if item.get("tags"):
        lines.append(f"**Tags:** {', '.join(item['tags']) if isinstance(item['tags'], list) else item['tags']}")
    if item.get("due_date"):
        lines.append(f"**Due:** {item['due_date']}")
    lines.append("")
    if item.get("l2_detail"):
        lines.append(item["l2_detail"])
        lines.append("")
    if item.get("metadata"):
        lines.append(f"**Metadata:** {json.dumps(item['metadata'])}")
    return "\n".join(lines)


def format_history(entries: list[dict]) -> str:
    """Format item history entries."""
    if not entries:
        return "No history entries."
    lines = ["## History", ""]
    for e in entries:
        actor = e.get("actor", "unknown")
        lines.append(f"- **{e['event']}** by {actor} ({e['created_at']})")
        content = e.get("content", "")
        try:
            diffs = json.loads(content)
            if isinstance(diffs, list):
                for d in diffs:
                    lines.append(f"  - {d['field']}: `{d.get('old', '')}` → `{d.get('new', '')}`")
            else:
                lines.append(f"  - {content}")
        except (json.JSONDecodeError, TypeError):
            lines.append(f"  - {content}")
    return "\n".join(lines)


def _format_item_lines(items: list[dict]) -> list[str]:
    """Helper to format items as bullet lines."""
    lines = []
    for item in items:
        priority = ""
        if item.get("priority", "normal") != "normal":
            priority = f" [{item['priority']}]"
        tags = ""
        if item.get("tags"):
            tag_list = item["tags"] if isinstance(item["tags"], list) else item["tags"].split(",")
            tags = f" #{' #'.join(t for t in tag_list if t)}"
        due = f" (due: {item['due_date']})" if item.get("due_date") else ""
        lines.append(f"- **#{item['id']}** {item['l1_summary']}{priority}{due}{tags}")
    return lines
```

- [ ] **Step 3: Write the failing tests — `tests/test_format.py`**

```python
from assistant_mcp.format import format_items, format_item_detail, format_history


def test_format_items_empty():
    result = format_items([])
    assert "No items" in result


def test_format_items_basic():
    items = [
        {"id": 1, "l1_summary": "Buy groceries", "status": "not_started", "priority": "high"},
        {"id": 2, "l1_summary": "Fix sink", "status": "in_progress", "priority": "normal"},
    ]
    result = format_items(items)
    assert "#1" in result
    assert "Buy groceries" in result
    assert "[high]" in result
    assert "[normal]" not in result  # normal priority not shown


def test_format_item_detail():
    item = {
        "id": 1, "l1_summary": "Buy groceries", "type": "task",
        "status": "not_started", "scope": "household", "priority": "high",
        "tags": ["groceries", "household"], "l2_detail": "Get potatoes and fish.",
    }
    result = format_item_detail(item)
    assert "Buy groceries" in result
    assert "Get potatoes and fish" in result
    assert "groceries" in result


def test_format_history_structured_diffs():
    entries = [
        {
            "event": "updated", "actor": "jimmy",
            "content": '[{"field": "priority", "old": "normal", "new": "high"}]',
            "created_at": "2026-03-22 10:00:00",
        }
    ]
    result = format_history(entries)
    assert "priority" in result
    assert "normal" in result
    assert "high" in result


def test_format_history_plain_text_content():
    entries = [
        {
            "event": "context_added", "actor": "jimmy",
            "content": "User noted: kitchen is 4m x 3m",
            "created_at": "2026-03-22 10:00:00",
        }
    ]
    result = format_history(entries)
    assert "kitchen is 4m x 3m" in result
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_format.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 5: Add structured diff helper to queries.py**

Add a `build_diff()` helper used by all update operations to create structured JSON diffs:

```python
# Add to queries.py:

def build_diff(old_row, updates: dict) -> list[dict]:
    """Build a structured diff between old row and new values.

    Returns a list of {"field": ..., "old": ..., "new": ...} entries
    for fields that actually changed.
    """
    diffs = []
    for field, new_val in updates.items():
        old_val = old_row[field] if field in old_row.keys() else None
        if str(old_val) != str(new_val):
            diffs.append({"field": field, "old": old_val, "new": new_val})
    return diffs
```

- [ ] **Step 6: Commit**

```bash
git add src/assistant_mcp/queries.py src/assistant_mcp/format.py tests/test_format.py
git commit -m "feat: centralized query layer, markdown formatter, and structured diff helpers"
```

---

## Task 5: Session Lifecycle Tools

**Files:**
- Create: `src/assistant_mcp/tools/session.py`
- Update: `src/assistant_mcp/queries.py` (add any new session queries)
- Create: `tests/test_session.py`

**Enhancement notes:**
- Use `queries.*` for all SQL (add new query functions to queries.py as needed)
- Use `format.format_boot()` for the boot response
- Write history entries via `queries.history_insert()` with `session_id` from the active session
- Use `queries.build_diff()` for any structured diffs

### Steps

- [ ] **Step 1: Write the failing tests — `tests/test_session.py`**

Key test cases:

```python
import pytest
from assistant_mcp.tools.session import boot_session, end_session, checkpoint_session


def test_boot_creates_session(seed_data):
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert result["user"]["name"] == "Jimmy"
    assert len(result["scopes"]) >= 2
    assert result["stale_sessions"] == 0
    session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    assert session is not None


def test_boot_returns_scopes(seed_data):
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    scope_ids = [s["id"] for s in result["scopes"]]
    assert "jimmy" in scope_ids
    assert "household" in scope_ids
    assert "alex" not in scope_ids


def test_boot_auto_closes_stale_sessions(seed_data):
    seed_data.execute(
        "INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",)
    )
    seed_data.commit()
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert result["stale_sessions"] == 1
    stale = seed_data.fetchall(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NOT NULL"
    )
    assert len(stale) == 1


def test_boot_does_not_close_other_users_sessions(seed_data):
    seed_data.execute(
        "INSERT INTO sessions (user_id) VALUES (?)", ("alex",)
    )
    seed_data.commit()
    boot_session(seed_data, "jimmy", ["jimmy", "household"])
    alex_open = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL"
    )
    assert alex_open is not None


def test_boot_returns_last_session_summary(seed_data):
    seed_data.execute(
        "INSERT INTO sessions (user_id, ended_at, summary) VALUES (?, datetime('now'), ?)",
        ("jimmy", "Worked on groceries"),
    )
    seed_data.commit()
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert result["last_session"]["summary"] == "Worked on groceries"


def test_boot_returns_items_by_type(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Buy groceries", "jimmy", "jimmy"),
    )
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("jimmy", "project", "in_progress", "Provider Ops", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["tasks"]) == 1
    assert result["tasks"][0]["l1_summary"] == "Buy groceries"
    assert len(result["projects"]) == 1


def test_boot_excludes_completed_items(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("jimmy", "task", "completed", "Done task", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["tasks"]) == 0


def test_boot_returns_global_facts(seed_data):
    seed_data.execute("INSERT INTO tags (id, category) VALUES (?, ?)", ("health", "health"))
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Alex is allergic to shellfish", "jimmy", "jimmy"),
    )
    fact_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (fact_id, "health"))
    seed_data.commit()
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert "health" in result["global_facts"]


def test_end_session(seed_data):
    boot_session(seed_data, "jimmy", ["jimmy", "household"])
    result = end_session(seed_data, "jimmy", learnings=["Jaya Grocer has best fish"])
    assert "summary" in result
    session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NOT NULL"
    )
    assert session is not None
    fact = seed_data.fetchone(
        "SELECT * FROM items WHERE type = 'fact' AND source = 'learned'"
    )
    assert fact is not None
    assert "Jaya Grocer" in fact["l1_summary"]


def test_checkpoint(seed_data):
    boot_session(seed_data, "jimmy", ["jimmy", "household"])
    result = checkpoint_session(seed_data, "jimmy")
    assert "confirmation" in result


# --- C8: Activity cursor advancement tests ---

def test_boot_does_not_advance_cursor(seed_data):
    """Cursor stays at 0 after boot — events resurface if session crashes."""
    # Alex creates a shared item (generates history)
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task", "alex", "alex"),
    )
    seed_data.commit()
    boot_session(seed_data, "jimmy", ["jimmy", "household"])
    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] == 0


def test_checkpoint_advances_cursor(seed_data):
    """Cursor advances at checkpoint."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task", "alex", "alex"),
    )
    seed_data.commit()
    boot_session(seed_data, "jimmy", ["jimmy", "household"])
    checkpoint_session(seed_data, "jimmy")
    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] > 0


def test_end_session_advances_cursor(seed_data):
    """Cursor advances at session end."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task", "alex", "alex"),
    )
    seed_data.commit()
    boot_session(seed_data, "jimmy", ["jimmy", "household"])
    end_session(seed_data, "jimmy")
    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] > 0


def test_crashed_session_resurfaces_events(seed_data):
    """If session ends without checkpoint/end, events reappear on next boot."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task by alex", "alex", "alex"),
    )
    seed_data.commit()
    # First boot — sees the event but cursor not advanced
    boot1 = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert len(boot1["recent_shared_activity"]) > 0
    # Simulate crash: no checkpoint or end_session
    # Second boot — should still see the event
    boot2 = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert len(boot2["recent_shared_activity"]) > 0


# --- C9: Reminder boot filtering tests ---

def test_boot_includes_reminders_due_within_7_days(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, due_date, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, datetime('now', '+3 days'), ?, ?)",
        ("household", "reminder", "active", "Dentist appointment", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 1


def test_boot_excludes_reminders_due_beyond_7_days(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, due_date, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, datetime('now', '+14 days'), ?, ?)",
        ("household", "reminder", "active", "Far future reminder", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 0


def test_boot_excludes_reminders_without_due_date(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "reminder", "active", "Undated reminder", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 0
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_session.py -v
```

Expected: FAIL (module not found).

- [ ] **Step 3: Implement `src/assistant_mcp/tools/session.py`**

Implement `boot_session()`, `end_session()`, `checkpoint_session()` as plain functions. Each takes `db, user_id, scopes` and returns a dict.

Key logic for `boot_session()` — use `queries.*` for all SQL:
1. `queries.sessions_close_stale(db, user_id)` → count
2. `queries.sessions_create(db, user_id)` → session_id
3. Fetch user profile
4. `queries.scopes_for_user(db, user_id)` → scopes
5. `queries.sessions_get_last_completed(db, user_id)` → last summary
6. `queries.items_top_level_active(db, scopes, exclude_types=("fact",))` → items
7. `queries.items_facts_by_scope(db, scopes)` → facts
8. `queries.activity_get_shared(db, user_id, scopes)` → activity
9. Build response dict → `format.format_boot(data)` → return markdown string

Key logic for `end_session()` — use `queries.*` for all SQL:
1. Save learnings as facts (type='fact', source='learned')
2. Record history for each learned fact via `queries.history_insert()` with `session_id`
3. Generate summary from session activity
4. Update session: `ended_at`, `summary`, `log_path`
5. `queries.activity_advance_cursor(db, user_id)`

Add `register(mcp)` function with full MCP tool descriptions from spec Section 5.

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_session.py -v
```

Expected: all tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/assistant_mcp/tools/session.py tests/test_session.py
git commit -m "feat: session lifecycle tools (boot, end, checkpoint)"
```

---

## Task 6: Context Management Tools

**Files:**
- Create: `src/assistant_mcp/tools/context.py`
- Create: `tests/test_context.py`

### Steps

- [ ] **Step 1: Write the failing tests — `tests/test_context.py`**

Key test cases:
- `test_set_context_focuses_item` — sets active_context_id, returns item L2 + children
- `test_set_context_returns_children_grouped_by_type`
- `test_set_context_returns_global_facts`
- `test_clear_context` — set_context(None) clears focus, returns boot-level summary
- `test_refresh_context_restores_focus` — after set_context(), refresh returns same focus
- `test_refresh_context_with_no_focus` — returns boot summary
- `test_refresh_context_returns_session_activity` — items created/updated in session
- `test_refresh_context_returns_scopes`
- `test_scope_enforcement` — can't set_context on item outside scopes

- [ ] **Step 2: Run tests to verify they fail**

- [ ] **Step 3: Implement `src/assistant_mcp/tools/context.py`**

`set_context(db, user_id, scopes, item_id=None)`:
- With item_id: validate scope access, update `sessions.active_context_id`, return item detail + children + item_facts + global_facts
- Without item_id: clear `active_context_id`, return boot-level summary

`refresh_context(db, user_id, scopes)`:
- Find active session: `SELECT * FROM sessions WHERE user_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1`
- If `active_context_id` set: return focused item + children + facts
- Return boot summary + scopes + session activity + shared activity

- [ ] **Step 4: Run tests, verify pass**

- [ ] **Step 5: Commit**

```bash
git add src/assistant_mcp/tools/context.py tests/test_context.py
git commit -m "feat: context management tools (set_context, refresh_context)"
```

---

## Task 7: Item CRUD Tools

**Files:**
- Create: `src/assistant_mcp/tools/items.py`
- Update: `src/assistant_mcp/queries.py` (add item CRUD queries)
- Create: `tests/test_items.py`

**Enhancement notes:**
- Use `queries.build_diff()` to generate structured JSON diffs for all update operations
- Write history via `queries.history_insert()` with `session_id` and `correlation_id` (for cascade ops)
- Store `metadata` JSON on insert/update if provided (pass through as-is)
- Use `format.format_items()` for list responses, `format.format_item_detail()` for single items
- Generate a `correlation_id` (UUID) for cascade operations (archive, scope change) so all affected items share one ID in their history entries

This is the largest task — 6 endpoints. Test in sub-groups.

### Steps

- [ ] **Step 1: Write tests for `add_items`**

Key cases:
- Create single item with all fields
- Create multiple items in batch
- Scope enforcement: reject item in scope user doesn't have
- Parent validation: child must be in same scope as parent
- Parent type validation: can't parent under a fact/note/reminder
- Default status by type: task→not_started, fact→active
- L3 history created on insert
- Tag association
- Tag validation warnings for unknown tags

- [ ] **Step 2: Run tests to verify they fail**

- [ ] **Step 3: Implement `add_items` in `tools/items.py`**

For each item:
1. Validate scope access
2. Validate parent (if set): exists, same scope, is project/task/idea
3. Determine default status from type if not provided
4. Insert into items table (use `created_by = user_id`, `updated_by = user_id`), include `metadata` JSON if provided
5. Insert tags into item_tags
6. `queries.history_insert(db, item_id, "created", l1_summary, user_id, session_id=active_session_id)`
7. Return created items formatted via `format.format_items()`

- [ ] **Step 4: Run tests, verify pass**

- [ ] **Step 5: Write tests for `update_item`**

Key cases:
- Update l1_summary, l2_detail, status, priority, due_date, tags, metadata
- Scope enforcement: can't update item outside scopes
- Scope change: cascades to children (all children share one `correlation_id` in history)
- L3 records structured diff via `queries.build_diff(old_row, updates)` → JSON list of `{"field", "old", "new"}`
- Clear fields with empty string (due_date, valid_until)

- [ ] **Step 6: Implement `update_item`, run tests, verify pass**

- [ ] **Step 7: Write tests for `complete_items`, `archive_items`, `delete_items`, `convert_item`**

Key cases:
- Complete: sets status='completed', L3 snapshot, does NOT cascade
- Complete parent with children: allowed, children unchanged
- Archive: sets status='archived', cascades to children
- Delete: admin only, hard delete, rejects non-admin
- Convert: changes type, preserves children/tags/history, rejects conversion to leaf type (fact/note/reminder) if item has children

- [ ] **Step 8: Implement remaining endpoints, run tests, verify pass**

- [ ] **Step 9: Commit**

```bash
git add src/assistant_mcp/tools/items.py tests/test_items.py
git commit -m "feat: item CRUD tools (add, update, complete, archive, delete, convert)"
```

---

## Task 8: Navigation & Retrieval Tools

**Files:**
- Create: `src/assistant_mcp/tools/navigation.py`
- Create: `tests/test_navigation.py`

### Steps

- [ ] **Step 1: Write tests**

Key cases:
- `get_details`: returns full L2 for multiple items, scope-filtered
- `get_children`: returns children grouped by type, L1 only by default
- `get_children` with `include_l2=True`: includes detail
- `get_children` with `cascade=True`: recursive descendants
- `get_history`: returns L3 entries, respects since/until/limit
- `add_context`: creates L3 entry with event='context_added'
- Scope enforcement on all endpoints

- [ ] **Step 2: Implement `tools/navigation.py`**

`get_children` with cascade uses recursive CTE:
```sql
WITH RECURSIVE descendants AS (
    SELECT id FROM items WHERE parent_id IN (:parent_ids)
    UNION ALL
    SELECT i.id FROM items i JOIN descendants d ON i.parent_id = d.id
)
SELECT * FROM items WHERE id IN (SELECT id FROM descendants)
    AND scope IN (:scopes)
ORDER BY type, position
```

- [ ] **Step 3: Run tests, verify pass**

- [ ] **Step 4: Commit**

```bash
git add src/assistant_mcp/tools/navigation.py tests/test_navigation.py
git commit -m "feat: navigation tools (get_details, get_children, get_history, add_context)"
```

---

## Task 9: Search & Discovery Tools

**Files:**
- Create: `src/assistant_mcp/tools/search.py`
- Create: `tests/test_search.py`

### Steps

- [ ] **Step 1: Write tests**

Key cases:
- `search_items` with free text query: returns FTS5-ranked results
- `search_items` with tag filter (AND logic)
- `search_items` with type, status, scope, date range filters
- `search_items` with status='expired': finds facts past valid_until
- `list_items`: returns structured listing, sorted by priority then position
- `list_items` with parent_id=None for top-level only
- `get_facts` by tags (OR logic)
- `get_facts` by item_ids (attached facts)
- `get_facts` with include_children=True
- `get_facts` with level='l1' vs 'l2'
- Scope enforcement on all endpoints
- Lazy expiry test (C10):

```python
def test_lazy_fact_expiry(seed_data):
    """Facts past valid_until are lazily marked expired on read."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, valid_until, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, datetime('now', '-1 day'), ?, ?)",
        ("household", "fact", "active", "Expired fact", "jimmy", "jimmy"),
    )
    seed_data.commit()
    results = search_items(seed_data, "jimmy", ["jimmy", "household"], query="Expired")
    assert len(results) == 0  # expired facts excluded from default search
    results = search_items(
        seed_data, "jimmy", ["jimmy", "household"], query="Expired", status="expired"
    )
    assert len(results) == 1
    assert results[0]["status"] == "expired"
    # Verify DB was updated
    item = seed_data.fetchone("SELECT status FROM items WHERE l1_summary = 'Expired fact'")
    assert item["status"] == "expired"


def test_expired_facts_excluded_from_boot(seed_data):
    """Boot query excludes facts past valid_until."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, l1_summary, valid_until, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, datetime('now', '-1 day'), ?, ?)",
        ("household", "fact", "active", "Old expired fact", "jimmy", "jimmy"),
    )
    seed_data.commit()
    from assistant_mcp.tools.session import boot_session
    result = boot_session(seed_data, "jimmy", ["jimmy", "household"])
    all_fact_summaries = []
    for facts in result["global_facts"].values():
        all_fact_summaries.extend(f["l1_summary"] for f in facts)
    assert "Old expired fact" not in all_fact_summaries
```

- [ ] **Step 2: Implement `tools/search.py`**

FTS5 query for `search_items`:
```sql
SELECT i.*, rank
FROM items_fts fts
JOIN items i ON fts.rowid = i.id
WHERE items_fts MATCH :query
    AND i.scope IN (:scopes)
ORDER BY rank
```

Lazy expiry in all read paths (uses caller's user_id as updated_by
to satisfy the enforce_update_access trigger):
```python
# After fetching facts, check valid_until
for item in results:
    if item["valid_until"] and item["valid_until"] < now:
        db.execute(
            "UPDATE items SET status = 'expired', updated_by = ? WHERE id = ?",
            (user_id, item["id"]),
        )
        item["status"] = "expired"
```

- [ ] **Step 3: Run tests, verify pass**

- [ ] **Step 4: Commit**

```bash
git add src/assistant_mcp/tools/search.py tests/test_search.py
git commit -m "feat: search and discovery tools (search_items, list_items, get_facts)"
```

---

## Task 10: Tag Management & Ordering Tools

**Files:**
- Create: `src/assistant_mcp/tools/tags.py`
- Create: `src/assistant_mcp/tools/ordering.py`
- Create: `tests/test_tags.py`
- Create: `tests/test_ordering.py`

### Steps

- [ ] **Step 1: Write tests for tags**

Key cases:
- `suggest_tags`: matches by name and aliases (JSON array)
- `suggest_tags`: fuzzy/prefix matching
- `list_tags`: returns all tags
- `list_tags` with categories filter

- [ ] **Step 2: Implement `tools/tags.py`**

`suggest_tags` matches against both `tags.id` and entries in `tags.aliases` (JSON array). Use `LIKE` for prefix matching and parse aliases with `json_each()`:

```sql
SELECT DISTINCT t.* FROM tags t
LEFT JOIN json_each(t.aliases) a ON 1=1
WHERE t.id LIKE :pattern OR a.value LIKE :pattern
```

- [ ] **Step 3: Run tag tests, verify pass**

- [ ] **Step 4: Write tests for ordering**

Key cases:
- `reorder_items`: updates positions for items with same parent
- Rejects items with different parents
- Position normalization when difference < 0.001

- [ ] **Step 5: Implement `tools/ordering.py`**

Normalization check:
```python
siblings = db.fetchall(
    "SELECT id, position FROM items WHERE parent_id IS ? AND scope IN (:scopes) ORDER BY position",
    (parent_id,)
)
positions = [s["position"] for s in siblings if s["position"] is not None]
if len(positions) >= 2:
    min_gap = min(positions[i+1] - positions[i] for i in range(len(positions) - 1))
    if min_gap < 0.001:
        for i, s in enumerate(siblings):
            db.execute("UPDATE items SET position = ?, updated_by = ? WHERE id = ?",
                       (float(i + 1), user_id, s["id"]))
```

- [ ] **Step 6: Run ordering tests, verify pass**

- [ ] **Step 7: Commit**

```bash
git add src/assistant_mcp/tools/tags.py src/assistant_mcp/tools/ordering.py \
        tests/test_tags.py tests/test_ordering.py
git commit -m "feat: tag management and ordering tools"
```

---

## Task 11: Scope Management Tools

**Files:**
- Create: `src/assistant_mcp/tools/scopes.py`
- Create: `tests/test_scopes.py`

### Steps

- [ ] **Step 1: Write tests**

Key cases:
- `list_scopes`: returns caller's scopes with members
- `create_scope`: admin only, creates scope
- `create_scope`: non-admin rejected
- `add_scope_member`: adds user to scope
- `remove_scope_member`: removes user, items remain
- Duplicate scope creation rejected

- [ ] **Step 2: Implement `tools/scopes.py`**

`list_scopes` query:
```sql
SELECT s.*, GROUP_CONCAT(DISTINCT sm2.user_id) as member_ids
FROM scopes s
JOIN scope_members sm ON s.id = sm.scope_id
JOIN scope_members sm2 ON s.id = sm2.scope_id
WHERE sm.user_id = :caller
GROUP BY s.id
```

Admin check for mutating operations:
```python
def create_scope(db, user_id, scopes, is_admin, scope_id, name, description=None):
    if not is_admin:
        raise ValueError("Only admins can create scopes")
    ...
```

- [ ] **Step 3: Run tests, verify pass**

- [ ] **Step 4: Commit**

```bash
git add src/assistant_mcp/tools/scopes.py tests/test_scopes.py
git commit -m "feat: scope management tools (list, create, add/remove member)"
```

---

## Task 12: Server Wiring & Integration Test

**Files:**
- Create: `src/assistant_mcp/server.py`
- Update: `src/assistant_mcp/tools/__init__.py`
- Create: `tests/test_integration.py`

### Steps

- [ ] **Step 1: Write `src/assistant_mcp/tools/__init__.py`**

```python
from assistant_mcp.tools import (
    context,
    items,
    navigation,
    ordering,
    scopes,
    search,
    session,
    tags,
)


def register_all_tools(mcp):
    session.register(mcp)
    context.register(mcp)
    items.register(mcp)
    navigation.register(mcp)
    search.register(mcp)
    tags.register(mcp)
    ordering.register(mcp)
    scopes.register(mcp)
```

- [ ] **Step 2: Write `src/assistant_mcp/server.py`**

```python
import os

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import get_http_headers
from fastmcp.server.middleware import Middleware, MiddlewareContext

from assistant_mcp.auth import resolve_user, set_auth_context
from assistant_mcp.db import get_db, init_db
from assistant_mcp.tools import register_all_tools


class AuthMiddleware(Middleware):
    async def on_call_tool(self, context: MiddlewareContext, call_next):
        headers = get_http_headers() or {}
        api_key = headers.get("x-api-key")
        if not api_key:
            raise ToolError("Missing x-api-key header")

        result = resolve_user(get_db(), api_key)
        if result is None:
            raise ToolError("Invalid API key")

        user_id, scopes, admin = result
        set_auth_context(user_id, scopes, is_admin=admin)
        return await call_next(context)


def create_server(db_path: str | None = None) -> FastMCP:
    if db_path is None:
        db_path = os.environ.get("ASSISTANT_DB_PATH", "/data/assistant.db")

    init_db(db_path)

    mcp = FastMCP(
        name="AI Assistant",
        instructions=(
            "Multi-user AI assistant MCP server. All operations are scoped "
            "to the authenticated user. Use session_boot() to start, "
            "session_end() to finish."
        ),
    )
    mcp.add_middleware(AuthMiddleware())
    register_all_tools(mcp)
    return mcp


def main():
    port = int(os.environ.get("ASSISTANT_MCP_PORT", "8100"))
    server = create_server()
    server.run(transport="sse", host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
```

- [ ] **Step 3: Write integration test — `tests/test_integration.py`**

End-to-end workflow test calling business logic functions in sequence:

```python
from assistant_mcp.tools.session import boot_session, end_session
from assistant_mcp.tools.items import add_items, complete_items, update_item
from assistant_mcp.tools.context import set_context
from assistant_mcp.tools.search import search_items
from assistant_mcp.tools.navigation import get_details, get_children


def test_full_workflow(seed_data):
    """Boot → create items → focus → update → complete → search → end."""
    db = seed_data

    # Boot as jimmy
    boot = boot_session(db, "jimmy", ["jimmy", "household"])
    assert boot["stale_sessions"] == 0
    assert len(boot["scopes"]) >= 2

    # Create a project with tasks
    created = add_items(db, "jimmy", ["jimmy", "household"], [
        {
            "scope": "household",
            "type": "project",
            "l1_summary": "Kitchen renovation",
        }
    ])
    project_id = created["items"][0]["id"]

    created = add_items(db, "jimmy", ["jimmy", "household"], [
        {
            "scope": "household",
            "type": "task",
            "l1_summary": "Get contractor quotes",
            "parent_id": project_id,
            "priority": "high",
        },
        {
            "scope": "household",
            "type": "task",
            "l1_summary": "Choose paint colors",
            "parent_id": project_id,
        },
    ])

    # Focus on project
    ctx = set_context(db, "jimmy", ["jimmy", "household"], project_id)
    assert ctx["item"]["l1_summary"] == "Kitchen renovation"
    assert len(ctx["children"]["tasks"]) == 2

    # Complete a task
    task_id = created["items"][0]["id"]
    complete_items(db, "jimmy", ["jimmy", "household"], [task_id])
    details = get_details(db, "jimmy", ["jimmy", "household"], [task_id])
    assert details["items"][0]["status"] == "completed"

    # Search
    results = search_items(db, "jimmy", ["jimmy", "household"], query="kitchen")
    assert len(results) >= 1

    # Create a fact
    add_items(db, "jimmy", ["jimmy", "household"], [
        {
            "scope": "household",
            "type": "fact",
            "l1_summary": "Kitchen is 4m x 3m",
            "source": "user_stated",
        }
    ])

    # End session with learnings
    result = end_session(
        db, "jimmy",
        learnings=["Contractor A is cheapest but slow"],
    )
    assert "summary" in result

    # Verify learning was saved as fact
    fact = db.fetchone(
        "SELECT * FROM items WHERE source = 'learned' AND type = 'fact'"
    )
    assert fact is not None


def test_scope_isolation(seed_data):
    """Jimmy can't see Alex's personal items."""
    db = seed_data

    # Alex creates a personal item
    add_items(db, "alex", ["alex", "household"], [
        {
            "scope": "alex",
            "type": "task",
            "l1_summary": "Alex private task",
        }
    ])

    # Jimmy boots — should not see Alex's personal task
    boot = boot_session(db, "jimmy", ["jimmy", "household"])
    all_summaries = [t["l1_summary"] for t in boot["tasks"]]
    assert "Alex private task" not in all_summaries

    # Jimmy searches — should not find it
    results = search_items(db, "jimmy", ["jimmy", "household"], query="Alex private")
    assert len(results) == 0


def test_shared_activity_visibility(seed_data):
    """Alex sees Jimmy's shared-scope changes."""
    db = seed_data

    # Jimmy boots and creates a shared item
    boot_session(db, "jimmy", ["jimmy", "household"])
    add_items(db, "jimmy", ["jimmy", "household"], [
        {
            "scope": "household",
            "type": "task",
            "l1_summary": "New code version ready for testing",
        }
    ])
    end_session(db, "jimmy")

    # Alex boots — should see Jimmy's shared activity
    boot = boot_session(db, "alex", ["alex", "household"])
    activity_summaries = [a["l1_summary"] for a in boot["recent_shared_activity"]]
    assert "New code version ready for testing" in activity_summaries
```

- [ ] **Step 4: Run all tests**

```bash
pytest tests/ -v
```

Expected: all tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/assistant_mcp/server.py src/assistant_mcp/tools/__init__.py tests/test_integration.py
git commit -m "feat: server wiring with auth middleware and integration tests"
```

---

## Task 13: Manual Smoke Test

**Files:** None (verification only)

### Steps

- [ ] **Step 1: Start the server**

```bash
cd ~/repositories/private/ai-assistant
export ASSISTANT_DB_PATH=/tmp/test-assistant.db
export ASSISTANT_MCP_PORT=8100

# Seed test data
python -c "
from assistant_mcp.db import init_db
db = init_db('/tmp/test-assistant.db')
db.execute(\"INSERT INTO users VALUES ('jimmy', 'Jimmy', NULL, 1, 'test-key-1')\")
db.execute(\"INSERT INTO scopes VALUES ('jimmy', 'Jimmy', 'Personal')\")
db.execute(\"INSERT INTO scope_members VALUES ('jimmy', 'jimmy')\")
db.execute(\"INSERT INTO activity_cursor VALUES ('jimmy', 0)\")
db.commit()
print('Seeded.')
"

assistant-mcp
```

Expected: Server starts on port 8100.

- [ ] **Step 2: Test with curl**

```bash
# session_boot
curl -X POST http://localhost:8100/mcp \
  -H "Content-Type: application/json" \
  -H "x-api-key: test-key-1" \
  -d '{"method": "tools/call", "params": {"name": "session_boot", "arguments": {}}}'
```

Verify response contains user info, scopes, empty item lists.

- [ ] **Step 3: Clean up**

```bash
rm /tmp/test-assistant.db
```

- [ ] **Step 4: Final commit with any fixes**

```bash
git add -A
git commit -m "chore: smoke test fixes and cleanup"
```
