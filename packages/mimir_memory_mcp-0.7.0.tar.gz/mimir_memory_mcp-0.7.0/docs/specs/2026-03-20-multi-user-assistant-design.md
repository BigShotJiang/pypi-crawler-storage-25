# Multi-User AI Assistant Platform — Design Spec

**Date:** 2026-03-20
**Status:** Draft
**Author:** Jimmy + MARVIN

---

## 1. Overview

A multi-user AI assistant platform that replaces MARVIN. Each user gets an isolated container running Claude Code, connected to a shared MCP server that manages structured data and enforces scope-based access boundaries.

**Users:** Jimmy (developer, admin) and Alex (non-technical) to start. Designed for N users.

**Key requirements:**
- Strict OS-level isolation between users — containers enforce boundaries
- Shared spaces only through explicit scopes (e.g., `household`)
- Hybrid storage: SQLite for structured data (tasks, facts, projects), files for narratives (session logs, documents)
- Tiered context loading (L1/L2/L3) to minimize token usage
- Interface-agnostic: SSH first, Telegram and web chat as future phases
- Safety in depth: containers, scope filtering, SQL triggers, Ark rules, CLAUDE.md guidance

---

## 2. System Architecture

```
┌──────────────────────────────────────────────────────────┐
│                        Host (VPS)                        │
│                                                          │
│  ┌───────────────────┐    ┌───────────────────┐         │
│  │ jimmy-assistant    │    │ alex-assistant     │         │
│  │ ┌───────────────┐ │    │ ┌───────────────┐ │         │
│  │ │ Claude Code    │ │    │ │ Claude Code    │ │         │
│  │ │ + MCP client   │ │    │ │ + MCP client   │ │         │
│  │ └───────┬───────┘ │    │ └───────┬───────┘ │         │
│  │         │         │    │         │         │         │
│  │  /home/jimmy/     │    │  /home/alex/      │         │
│  │   assistant/      │    │   assistant/      │         │
│  │   .claude/        │    │   .claude/        │         │
│  └─────────┬─────────┘    └─────────┬─────────┘         │
│            │                        │                    │
│            └────────┬───────────────┘                    │
│                     │ MCP (HTTP/SSE)                     │
│            ┌────────▼────────────┐                       │
│            │   assistant-mcp     │                       │
│            │  ┌────────────────┐ │                       │
│            │  │ assistant.db   │ │                       │
│            │  │                │ │                       │
│            │  │ scope-based    │ │                       │
│            │  │ row filtering  │ │                       │
│            │  └────────────────┘ │                       │
│            └─────────────────────┘                       │
│                                                          │
│  Volumes:                                                │
│   /data/jimmy/      ← jimmy container (rw)              │
│   /data/alex/       ← alex container (rw)               │
│   /data/shared/     ← both containers (rw)              │
│   /opt/assistant/   ← both containers (ro)              │
│    └─ core/  (from template repo: CLAUDE-base.md,       │
│              skills, Ark rules)                          │
└──────────────────────────────────────────────────────────┘
```

### Container isolation

Each user gets a Docker container with:
- Its own filesystem (cannot touch host system)
- Its own Claude Code installation and config
- Read-write access to only its own data volume
- Read-write access to the shared volume
- Read-only access to the core config volume
- Resource limits (CPU, memory, disk)
- Network: outbound HTTPS allowed (Anthropic API, web search, package managers). Containers share the same network policy.

All containers use the same full image (git, python, node, etc.). Behavioral differences between users are handled by Ark rules and CLAUDE.md, not by image restrictions. If a container breaks (bad installs, corrupted environment), rebuild in seconds — data survives in volumes.

### What lives where

| Data | Location | Why |
|---|---|---|
| Tasks, facts, projects, reminders, notes, ideas | MCP server (SQLite) | Structured, queryable, scope-filtered, safe from accidental loss |
| Session logs | Per-user volume (`/data/{user}/sessions/`) | Write-once narrative, human-readable |
| Documents and content | Per-user or shared volume | Free-form, human-editable |
| CLAUDE.md (base) | `/opt/assistant/core/` (read-only) | Shared personality, safety rules, session flow |
| CLAUDE.md (user overrides) | Per-user volume (`/data/{user}/assistant/`) | User profile, preferences, custom instructions |
| Claude Code config and memory | Per-user volume (`/data/{user}/.claude/`) | Naturally isolated |
| Ark safety rules | `/opt/assistant/core/rules/` (read-only) | Enforced, not editable by containers |

---

## 3. Data Model

### Access control

```sql
CREATE TABLE scopes (
  id              TEXT PRIMARY KEY,       -- 'jimmy', 'alex', 'household'
  name            TEXT NOT NULL,          -- 'Jimmy', 'Alex', 'Household'
  description     TEXT                    -- 'Shared household tasks and info'
);

CREATE TABLE users (
  id              TEXT PRIMARY KEY,       -- 'jimmy', 'alex'
  name            TEXT NOT NULL,          -- 'Jimmy', 'Alex' (display name, updatable via onboarding)
  profile         TEXT,                   -- JSON, see "users.profile vs CLAUDE-user.md" below
  is_admin        BOOLEAN DEFAULT FALSE,
  api_key         TEXT UNIQUE NOT NULL    -- per-user key for MCP auth, generated by setup
);

CREATE TABLE scope_members (
  scope_id        TEXT REFERENCES scopes(id) ON DELETE CASCADE,
  user_id         TEXT REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (scope_id, user_id)
);
-- All scope members have equal read/write access.
-- Scope-level roles (e.g., read-only members) are not supported in v1.
-- If needed later, add a `role` column to scope_members.
```

### `users.profile` vs `CLAUDE-user.md`

Two files store user-related data. They serve different consumers and must not overlap:

| | `users.profile` (database) | `CLAUDE-user.md` (file) |
|---|---|---|
| **Consumer** | MCP server logic | Claude Code (LLM prompting) |
| **Format** | JSON | Markdown |
| **Purpose** | Structured data the MCP server reads programmatically to make decisions | Prompt instructions that shape the AI's tone, personality, and behavior |
| **Updated by** | `apply.sh` (initial), onboarding skill (refinements) | Onboarding skill (generated), user can edit manually |
| **Loaded when** | Returned in `session_boot()` and `refresh_context()` responses | Concatenated into CLAUDE.md at container startup |

**`users.profile` contains** (JSON):

```json
{
  "role": "marketing",
  "background": "Non-technical, marketing professional",
  "ark_profile": "standard",
  "assistant_name": "Athena"
}
```

- `role` — user's role category, used by MCP for contextual defaults (e.g., which tags to suggest first)
- `background` — brief background, included in `session_boot()` so the AI has context
- `ark_profile` — which Ark rule set applies (`developer` or `standard`), set by admin during setup, not editable by user
- `assistant_name` — what the user calls the assistant, used by the AI for self-reference

**`CLAUDE-user.md` contains** (markdown appended to CLAUDE-base.md):

```markdown
## User Profile
Name: Alex
Assistant name: Athena
Role: Marketing, household administration
Current focus: Meal planning, house move, work deadlines

## Communication
Style: Casual — friendly and conversational
Detail: Quick and direct, no over-explaining
Behavior: Proactive — suggest things, flag issues, remind about deadlines

## Custom Instructions
(User-added notes, preferences, workflow tweaks)
```

- Communication style, detail level, proactive behavior — things that only matter to the LLM
- Custom instructions the user adds over time
- Current focus and context — narrative, not structured

**Rule:** If the MCP server needs to read it to make a decision, it goes in `users.profile`. If only the LLM needs it to shape responses, it goes in `CLAUDE-user.md`. If both need it (e.g., `assistant_name`), it lives in `users.profile` (source of truth) and is also written into `CLAUDE-user.md` during onboarding for prompt context.

### Core items

```sql
CREATE TABLE items (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_id       INTEGER REFERENCES items(id) ON DELETE CASCADE,
  scope           TEXT NOT NULL REFERENCES scopes(id),
  type            TEXT NOT NULL,           -- 'task'|'project'|'fact'|'reminder'|'note'|'idea'
  status          TEXT NOT NULL DEFAULT 'not_started',
                                           -- 'not_started'|'in_progress'|'blocked'
                                           -- 'completed'|'archived'|'active'
  priority        TEXT DEFAULT 'normal',   -- 'urgent'|'high'|'normal'|'low'
  position        REAL,                    -- ordering within same parent/scope
  l1_summary      TEXT NOT NULL,           -- always loaded at boot (top-level only)
  l2_detail       TEXT,                    -- loaded on demand
  source          TEXT,                    -- 'learned'|'user_stated'|'documented' (facts)
  due_date        TEXT,                    -- ISO 8601
  valid_until     TEXT,                    -- ISO 8601, for facts that expire
  created_by      TEXT NOT NULL REFERENCES users(id),
  updated_by      TEXT NOT NULL REFERENCES users(id),
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
```

### History (L3)

```sql
CREATE TABLE item_history (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id         INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
  event           TEXT NOT NULL,           -- 'created'|'updated'|'status_changed'
                                           -- 'context_added'|'completed'|'converted'
  content         TEXT NOT NULL,           -- what happened
  actor           TEXT,                    -- 'jimmy'|'alex'|'system'
  created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
```

### Tags

```sql
CREATE TABLE tags (
  id              TEXT PRIMARY KEY,        -- canonical: 'groceries'
  aliases         TEXT,                    -- JSON array: ['grocery', 'food-shopping']
  category        TEXT                     -- optional grouping: 'household', 'work'
);

CREATE TABLE item_tags (
  item_id         INTEGER REFERENCES items(id) ON DELETE CASCADE,
  tag_id          TEXT REFERENCES tags(id),
  PRIMARY KEY (item_id, tag_id)
);
```

### Sessions

```sql
CREATE TABLE sessions (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id         TEXT NOT NULL REFERENCES users(id),
  active_context_id INTEGER REFERENCES items(id),
  started_at      TEXT NOT NULL DEFAULT (datetime('now')),
  ended_at        TEXT,
  summary         TEXT,
  log_path        TEXT
);
```

### Shared activity tracking

```sql
CREATE TABLE activity_cursor (
  user_id              TEXT PRIMARY KEY REFERENCES users(id),
  last_seen_history_id INTEGER DEFAULT 0    -- high-water mark into item_history
);
```

Tracks which shared-scope events each user has been shown. On `session_boot()` and `refresh_context()`, the server queries `item_history` for entries with `id > last_seen_history_id` in shared scopes, from other users. The cursor advances at `checkpoint()` and `session_end()` (not at boot) — so if a session crashes before saving, unseen events resurface on the next boot.

Boot query for shared activity:

```sql
SELECT h.id, h.item_id, i.l1_summary, h.event, h.actor, h.created_at
FROM item_history h
JOIN items i ON h.item_id = i.id
WHERE h.id > (SELECT last_seen_history_id FROM activity_cursor WHERE user_id = :caller)
  AND i.scope IN (SELECT scope_id FROM scope_members WHERE user_id = :caller)
  AND i.scope != :caller           -- shared scopes only, exclude personal scope
  AND h.actor != :caller           -- only other users' actions
ORDER BY h.created_at DESC
```

Cursor update (at checkpoint/session_end):

```sql
UPDATE activity_cursor
SET last_seen_history_id = (SELECT MAX(id) FROM item_history)
WHERE user_id = :caller
```

### Full-text search

```sql
CREATE VIRTUAL TABLE items_fts USING fts5(
  l1_summary, l2_detail, content='items', content_rowid='id'
);

-- Keep FTS index in sync
CREATE TRIGGER items_fts_insert AFTER INSERT ON items BEGIN
  INSERT INTO items_fts(rowid, l1_summary, l2_detail)
    VALUES (NEW.id, NEW.l1_summary, NEW.l2_detail);
END;

CREATE TRIGGER items_fts_update AFTER UPDATE OF l1_summary, l2_detail ON items BEGIN
  INSERT INTO items_fts(items_fts, rowid, l1_summary, l2_detail)
    VALUES ('delete', OLD.id, OLD.l1_summary, OLD.l2_detail);
  INSERT INTO items_fts(rowid, l1_summary, l2_detail)
    VALUES (NEW.id, NEW.l1_summary, NEW.l2_detail);
END;

CREATE TRIGGER items_fts_delete AFTER DELETE ON items BEGIN
  INSERT INTO items_fts(items_fts, rowid, l1_summary, l2_detail)
    VALUES ('delete', OLD.id, OLD.l1_summary, OLD.l2_detail);
END;
```

### Auto-maintained timestamps

```sql
CREATE TRIGGER items_updated_at AFTER UPDATE ON items
WHEN NEW.updated_at = OLD.updated_at
BEGIN
  UPDATE items SET updated_at = datetime('now') WHERE id = NEW.id;
END;
```

This ensures `updated_at` is always current, which `search_items` `modified_since`/`modified_until` filters depend on.

### Indexes

```sql
CREATE INDEX idx_items_scope_parent_status ON items(scope, parent_id, status, type);
CREATE INDEX idx_items_parent ON items(parent_id);
CREATE INDEX idx_item_history_item_date ON item_history(item_id, created_at);
CREATE INDEX idx_scope_members_user ON scope_members(user_id);
CREATE INDEX idx_item_tags_tag ON item_tags(tag_id);
CREATE INDEX idx_sessions_user ON sessions(user_id, ended_at);
```

### SQL-level access enforcement

Database initialization must enable foreign keys:

```sql
PRAGMA foreign_keys = ON;
```

Triggers provide a backstop behind the MCP server's application-level access control.

```sql
-- INSERT: validate scope access, parent scope match, and parent accessibility
CREATE TRIGGER enforce_insert_access
BEFORE INSERT ON items
BEGIN
  -- User must have access to the item's scope
  SELECT CASE
    WHEN NEW.scope NOT IN (
      SELECT scope_id FROM scope_members WHERE user_id = NEW.created_by
    )
    THEN RAISE(ABORT, 'User does not have access to this scope')
  END;
  -- Child items must belong to the same scope as their parent
  SELECT CASE
    WHEN NEW.parent_id IS NOT NULL
      AND NEW.scope != (SELECT scope FROM items WHERE id = NEW.parent_id)
    THEN RAISE(ABORT, 'Child item must belong to same scope as parent')
  END;
  -- Parent must be accessible to the inserting user
  SELECT CASE
    WHEN NEW.parent_id IS NOT NULL
      AND (SELECT scope FROM items WHERE id = NEW.parent_id) NOT IN (
        SELECT scope_id FROM scope_members WHERE user_id = NEW.created_by
      )
    THEN RAISE(ABORT, 'User does not have access to parent item')
  END;
END;

-- UPDATE: validate user has access to the item's current scope
-- (fires on ALL updates, not just scope changes)
CREATE TRIGGER enforce_update_access
BEFORE UPDATE ON items
BEGIN
  -- User must have access to the item's current scope
  SELECT CASE
    WHEN OLD.scope NOT IN (
      SELECT scope_id FROM scope_members WHERE user_id = NEW.updated_by
    )
    THEN RAISE(ABORT, 'User does not have access to this item')
  END;
  -- If scope is changing, user must also have access to the new scope
  SELECT CASE
    WHEN NEW.scope != OLD.scope
      AND NEW.scope NOT IN (
        SELECT scope_id FROM scope_members WHERE user_id = NEW.updated_by
      )
    THEN RAISE(ABORT, 'User does not have access to target scope')
  END;
END;
```

### Type behaviors

| Type | Default status | Can be parent? | Can be child of? | Boot behavior |
|---|---|---|---|---|
| `project` | not_started | Yes | NULL only (top-level) | L1 with aggregated child summary |
| `task` | not_started | Yes | project, task | L1 if top-level, otherwise via drill-down |
| `fact` | active | No | project, task, idea, or top-level | Top-level fact L1s always in global facts index; L2 loaded by context/tags |
| `reminder` | active | No | project, task, or top-level | L1 if top-level and due within 7 days |
| `note` | active | No | project, task, idea, or top-level | Loaded via parent drill-down |
| `idea` | active | Yes | idea or top-level | L1 in separate boot section |

**Parent rule:** Only `project`, `task`, and `idea` can have children. Facts, reminders, and notes are always leaves.

**Scope rule:** Children must belong to the same scope as their parent. Scope changes cascade to all children.

---

## 4. Tiered Context Loading

### L1 — Headlines (always loaded at boot)

Top-level items only (`parent_id IS NULL`). Just enough to orient.

```
Projects:
  Provider Ops [jimmy, 1/3 done, blocked on Google Places API]
  Kitchen renovation [household, 5/20 done, next: contractor Fri]
Tasks:
  Buy groceries [household, due: today, HIGH]
  Reply to Harald [jimmy]
Reminders:
  Alex dentist tomorrow 2pm [household]
Ideas:
  Automated meditation YouTube channel [jimmy]
```

~200-500 tokens.

### L2 — Details (fetched on demand)

When the user engages with a specific item:

```
Buy groceries:
  Items: potatoes, cucumbers, bread, fish, olive oil, rice, soy sauce
  Store: Jaya Grocer
  Budget: RM 150
```

~100-300 tokens per item.

### L3 — Full history (rarely loaded)

When context or rationale matters:

```
2026-03-15: Switched from Village Grocer — produce quality declined
2026-03-10: Alex suggested trying Jaya Grocer for fish
```

Stored in `item_history` table. Auto-populated on every item mutation. Manually enriched via `add_context()`.

### Boot query

Two queries execute at boot. The first fetches active top-level items (excluding facts):

```sql
-- Boot query 1: active top-level items
SELECT i.*, GROUP_CONCAT(t.tag_id) as tags
FROM items i
LEFT JOIN item_tags it ON i.id = it.item_id
LEFT JOIN tags t ON it.tag_id = t.id
WHERE i.parent_id IS NULL
  AND i.scope IN (SELECT scope_id FROM scope_members WHERE user_id = :user)
  AND i.status NOT IN ('completed', 'archived')
  AND i.type IN ('task', 'project', 'reminder', 'idea')
  AND (i.type != 'reminder' OR i.due_date <= datetime('now', '+7 days'))
  -- Note: reminders without a due_date are excluded from boot (NULL comparison is falsy).
  -- Undated reminders surface only via set_context or search_items.
GROUP BY i.id
ORDER BY
  CASE i.priority
    WHEN 'urgent' THEN 0 WHEN 'high' THEN 1
    WHEN 'normal' THEN 2 WHEN 'low' THEN 3
  END,
  i.position
```

The second fetches all top-level facts (L1 only) for the global facts index:

```sql
-- Boot query 2: global facts index
SELECT i.id, i.l1_summary, GROUP_CONCAT(t.tag_id) as tags
FROM items i
LEFT JOIN item_tags it ON i.id = it.item_id
LEFT JOIN tags t ON it.tag_id = t.id
WHERE i.type = 'fact'
  AND i.parent_id IS NULL
  AND i.scope IN (SELECT scope_id FROM scope_members WHERE user_id = :user)
  AND i.status != 'archived'
  AND (i.valid_until IS NULL OR i.valid_until > datetime('now'))
GROUP BY i.id
```

Facts with `valid_until` in the past are automatically excluded from all queries (boot, get_facts, refresh_context, set_context). They remain in the database for historical reference but do not surface unless explicitly searched with `search_items(status='expired')`. The MCP server sets status to `expired` on read when `valid_until` has passed (lazy expiry).

### Global facts

Every `session_boot()`, `set_context()`, and `refresh_context()` response includes ALL non-expired top-level fact L1 summaries grouped by tag category. This ensures no fact is ever invisible, even after context compression.

```json
{
  "global_facts": {
    "health": [
      { "id": 12, "l1_summary": "Alex is allergic to shellfish" }
    ],
    "infrastructure": [
      { "id": 20, "l1_summary": "Provider Ops API only listens on localhost" }
    ]
  }
}
```

The assistant can then batch-fetch L2 for relevant categories via `get_facts(tags=['health', 'household'])`.

### Token comparison

| Scenario | Flat loading (MARVIN today) | Tiered loading |
|---|---|---|
| "What's on my plate?" | ~4,000+ tokens | ~300 tokens (L1 only) |
| "What groceries do we need?" | ~4,000+ tokens | ~400 tokens (L1 + L2 for groceries) |
| "Deploy book generator update" | ~4,000+ tokens | ~500 tokens (L1 + L2, no household noise) |

---

## 5. MCP Server API

**Transport:** HTTP/SSE. Shared MCP server, each container connects to it.

**Authentication:** Per-user `ASSISTANT_API_KEY` environment variable (set by host, not editable inside container). MCP server maps key to user, filters all operations by that user's scopes.

**Global access rule:** Every function validates the caller's scopes at the middleware layer before any handler runs. If an item's scope is not in the caller's accessible scopes, the operation is rejected.

**Session resolution:** All session-aware functions resolve the active session from the API key. No session_id parameter needed.

**Scope availability:** The caller's accessible scopes (with names, descriptions, and members) are included in `session_boot()` and `refresh_context()` responses. This means the assistant always knows which scopes exist from the first call, without needing a separate lookup. `list_scopes()` is available as a fallback after context compression.

### Session lifecycle

```
session_boot()
  Start a new assistant session. Call this at the beginning of every
  conversation. Creates a session record and returns everything needed
  to orient the conversation.

  Before creating the new session, auto-closes any abandoned previous
  sessions for this user (ended_at IS NULL) with a system-generated
  summary. Never touches other users' sessions.

  Returns:
    user:            { name, profile }
                     Display name and structured profile JSON (role,
                     background, ark_profile, assistant_name). See
                     "users.profile vs CLAUDE-user.md" in Section 3.
    scopes:          [{ id, name, description, members }]
                     The caller's accessible scopes. Use these when deciding
                     which scope to create items in. Each scope has an id
                     (e.g. 'household'), a human-readable name, a description
                     of its purpose, and a list of member users.
    last_session:    { date, summary }
                     Summary of the previous session for continuity. Use this
                     to greet the user with context about what they last
                     worked on.
    stale_sessions:  integer
                     Number of previous sessions that were auto-closed because
                     they were never properly ended (e.g. connection lost).
                     If > 0, mention to the user that a previous session was
                     not saved properly.
    projects:        [{ id, l1_summary, scope, status, priority, tags }]
                     L1 headlines of all active top-level projects.
    tasks:           [{ id, l1_summary, scope, status, priority, due_date, tags }]
                     L1 headlines of all active top-level tasks.
    reminders:       [{ id, l1_summary, scope, due_date }]
                     L1 headlines of reminders due within 7 days.
    ideas:           [{ id, l1_summary, scope, tags }]
                     L1 headlines of all active top-level ideas.
    global_facts:    { tag_category: [{ id, l1_summary }] }
                     All non-expired top-level facts grouped by tag category.
                     Scan these to identify facts relevant to the current
                     conversation, then fetch full details via get_facts().
    recent_shared_activity: [{ item_id, l1_summary, event, actor, created_at }]
                     Recent changes to shared-scope items made by other users.
                     Show relevant entries to the user so they stay informed
                     about what collaborators have been working on.

session_end(learnings?: string[])
  End the current session. Call this when the user is done working.
  Before calling, prompt the user: "Did we learn anything today that
  would be useful to remember for next time?"

  Parameters:
    learnings?:      string[]
                     Things worth remembering from this session. Each string
                     becomes a new fact (type='fact', source='learned') in the
                     scope most relevant to its content. Write each learning
                     as a self-contained statement that will make sense in a
                     future session without any surrounding context.
                     Good: "Alex prefers Jaya Grocer for fish — better quality
                     than Village Grocer"
                     Bad: "grocery store preference"

  Side effects:
    - Saves each learning as a fact
    - Generates session summary from conversation
    - Writes session log to /data/{user}/sessions/YYYY-MM-DD.md
    - Records ended_at timestamp
    - Advances shared activity cursor (events shown at boot are now
      marked as seen — they won't resurface on next boot)

  Returns: { summary: string }

checkpoint()
  Save a snapshot of the current session progress without ending it.
  Use this periodically during long sessions, when the user asks to
  save progress, or before risky operations. The snapshot is appended
  to the session log file on disk.

  Log path: /data/{user}/sessions/YYYY-MM-DD.md (derived from current
  date). Stored in sessions.log_path on first checkpoint or session_end.
  Multiple checkpoints and sessions on the same day append to the same
  file.

  Side effects:
    - Advances shared activity cursor (same as session_end)

  Returns: { confirmation: string }
```

### Context management

```
set_context(item_id?: integer)
  Focus the current session on a specific item, or clear the focus to
  return to the top-level overview. Call this when the user wants to
  work on a particular project, task, or idea. The server records the
  focused item so that refresh_context() can restore this focus after
  context window compression.

  Parameters:
    item_id?:        integer
                     The item to focus on. Pass an item ID to drill into
                     that item's details and children. Omit or pass null
                     to clear the focus and return to the top-level overview
                     (same shape as session_boot minus user/scopes).

  Returns (with item_id):
    item:            { full item with L2 detail }
    children:        { tasks, facts, notes, reminders, ideas }
                     Direct children grouped by type, L1 only.
    item_facts:      [{ id, l1_summary, l2_detail, tags }]
                     Facts attached as children of this item.
    global_facts:    { tag_category: [{ id, l1_summary }] }
                     All top-level facts by tag category (always included).

  Returns (without item_id):
    Boot-level summary (same shape as session_boot).

refresh_context()
  Restore the assistant's working context after context window
  compression or memory loss. Call this when you detect gaps in your
  conversation history, have lost track of what the user was working
  on, or need to re-orient after a long conversation. Takes no
  parameters — the server resolves the active session and any focused
  item automatically from the API key.

  Returns:
    scopes:          [{ id, name, description, members }]
                     The caller's accessible scopes (same as session_boot).
    boot:            { projects, tasks, reminders, ideas }
                     Current top-level L1 summaries.
    active_context:  { item, children, item_facts } or null
                     The currently focused item (if any) with its L2
                     detail, children, and attached facts.
    global_facts:    { tag_category: [{ id, l1_summary }] }
                     All top-level facts by tag category.
    session_activity: { created: [...], updated: [...], completed: [...] }
                     Items created, updated, or completed during this
                     session. Helps the assistant understand what has
                     already been done after context compression.
    recent_shared_activity: [{ item_id, l1_summary, event, actor, created_at }]
                     Recent shared-scope changes by other users (same as
                     session_boot).
```

### Item operations

```
add_items(items: Item[])
  Create one or more new items (tasks, projects, facts, reminders,
  notes, or ideas). Use this to record anything the user wants to
  track or remember.

  Parameters:
    items:           Item[] — array of items to create. Each item:

      scope:         string (required)
                     The access scope this item belongs to. Determines
                     which users can see and modify it. Must be one of
                     the caller's accessible scopes (returned by
                     session_boot). Example: 'jimmy' for personal items,
                     'household' for shared items.

      type:          string (required)
                     The item type. Determines default status and behavior.
                     'task' = actionable work (default: not_started).
                     'project' = collection of related work (default:
                     not_started). 'fact' = something to remember (default:
                     active). 'reminder' = time-sensitive alert (default:
                     active). 'note' = free-form information (default:
                     active). 'idea' = something to explore later (default:
                     active).

      l1_summary:    string (required)
                     A short, self-contained headline (1-2 sentences) that
                     captures the essential meaning of this item. This is
                     what appears in boot summaries, search results, and
                     the global facts index. It must be fully understandable
                     on its own without reading the l2_detail or any other
                     context.
                     Good: "Alex is allergic to shellfish"
                     Bad: "allergy info"
                     Good: "Buy groceries — potatoes, bread, fish from
                     Jaya Grocer"
                     Bad: "groceries"
                     For facts especially, the l1_summary should be written
                     so that someone seeing it for the first time can
                     understand what the fact is about and why it matters.

      l2_detail?:    string
                     Extended details, context, or structured content for
                     this item. Loaded on demand when the user focuses on
                     it. Can be multiple paragraphs, lists, or structured
                     text. Example for a grocery task: "Items: potatoes,
                     cucumbers, bread, fish, olive oil\nStore: Jaya Grocer
                     \nBudget: RM 150"

      parent_id?:    integer
                     Attach this item as a child of an existing item. The
                     parent must be a project, task, or idea (facts,
                     reminders, and notes cannot have children). The child
                     must belong to the same scope as its parent.

      tags?:         string[]
                     Tag IDs to categorize this item. Call suggest_tags()
                     first to find existing tags and avoid creating
                     duplicates. Tags enable filtering and grouping in
                     search results and the global facts index.

      priority?:     string
                     'urgent', 'high', 'normal' (default), or 'low'.
                     Affects sort order in boot summaries and list results.

      status?:       string
                     Override the default status for this type. Use when
                     an item is already in progress at creation time.
                     Valid: 'not_started', 'in_progress', 'blocked',
                     'active'.

      due_date?:     string
                     ISO 8601 date or datetime. For tasks and reminders.
                     Reminders only appear in boot summaries if due within
                     7 days.

      valid_until?:  string
                     ISO 8601 date after which this item should stop
                     surfacing in queries. Primarily for time-bound facts.
                     Example: "Renovation contractor available until
                     2026-04-30". Items past valid_until are lazily marked
                     as 'expired' and excluded from boot/refresh/search.

      position?:     number
                     Sort position among siblings (same parent and scope).
                     Uses fractional indexing. If omitted, the item is
                     appended at the end.

      source?:       string
                     How this information was obtained. Only meaningful
                     for facts. 'user_stated' = the user explicitly said
                     this. 'learned' = you inferred or noticed this during
                     conversation. 'documented' = sourced from an external
                     document or reference.

  Returns: { items: [{ id, ...created items }] }

  Side effects:
    - L3 history entry ('created') for each item
    - Tag validation: unrecognized tags trigger suggestions via
      suggest_tags(), returned in the response as warnings

update_item(item_id, ...)
  Modify an existing item's properties. Only pass the fields you want
  to change — omitted fields are not modified. Scope changes cascade
  to all children automatically.

  Parameters:
    item_id:         integer (required)
                     The item to update.

    l1_summary?:     string
                     Updated headline. Same writing rules as add_items:
                     must be self-contained and understandable without
                     L2 detail.

    l2_detail?:      string
                     Updated extended details.

    status?:         string
                     New status. Tasks/projects: 'not_started',
                     'in_progress', 'blocked', 'completed', 'archived'.
                     Facts/notes/ideas/reminders: 'active', 'archived'.

    priority?:       string
                     'urgent', 'high', 'normal', or 'low'.

    due_date?:       string
                     ISO 8601 date or datetime. Pass empty string to
                     clear.

    valid_until?:    string
                     ISO 8601 date. Pass empty string to clear.

    position?:       number
                     New sort position among siblings.

    scope?:          string
                     Move this item and all its children to a different
                     scope. You must have access to both the current and
                     target scope.

    tags?:           string[]
                     Replace all tags with this list. Pass empty array
                     to clear all tags.

  Returns: { item: { ...updated item } }

  Side effects:
    - L3 history entry recording what changed (field-level diff)

complete_items(item_ids: integer[])
  Mark one or more items as completed. Completion does NOT cascade to
  children — child items remain in their current status. Before
  completing a parent with incomplete children, inform the user about
  the remaining children so they can decide whether to complete,
  archive, or reassign them.

  Parameters:
    item_ids:        integer[] (required)
                     IDs of items to complete. All must be accessible in
                     the caller's scopes.

  Returns: { completed: [{ id, l1_summary }] }

  Side effects:
    - L3 snapshot for each item recording completion

archive_items(item_ids: integer[])
  Archive one or more items, removing them from active views. Unlike
  completion, archiving DOES cascade to all children. Archived items
  do not appear in boot summaries or default list results, but can be
  found via search_items(status='archived').

  Parameters:
    item_ids:        integer[] (required)
                     IDs of items to archive. All children will also be
                     archived.

  Returns: { archived: [{ id, l1_summary }] }

  Side effects:
    - L3 history entry for each item and cascaded children

delete_items(item_ids: integer[])
  Permanently delete items and all their children. Admin only —
  non-admin users should use archive_items instead. This is
  irreversible. All children, history entries, and tag associations
  are removed via cascading deletes.

  Parameters:
    item_ids:        integer[] (required)
                     IDs of items to permanently delete.

  Returns: { deleted: integer }
           Count of items deleted (including cascaded children).

  Side effects:
    - Audit log records the deletion (L3 not applicable — item is gone)

convert_item(item_id: integer, new_type: string)
  Change an item's type while preserving all its data (children, tags,
  L2 detail, L3 history). Use when the nature of an item evolves —
  for example, an idea that becomes a project, or a task that should
  be tracked as a note. Cannot convert to a leaf type (fact, reminder,
  note) if the item has children.

  Parameters:
    item_id:         integer (required)
                     The item to convert.

    new_type:        string (required)
                     Target type: 'task', 'project', 'fact', 'reminder',
                     'note', or 'idea'. If the item has children, only
                     'task', 'project', or 'idea' are valid targets.

  Returns: { item: { ...converted item } }

  Side effects:
    - L3 history: "Converted from {old_type} to {new_type}"
    - Status adjusted to the new type's default if the current status
      is not valid for the new type
```

### Navigation and retrieval

```
get_details(item_ids: integer[])
  Fetch full details (L2) for one or more items. Use this when the
  user asks about a specific item or you need more information than
  the L1 headline provides.

  Parameters:
    item_ids:        integer[] (required)
                     IDs of items to fetch. All must be in the caller's
                     accessible scopes.

  Returns: { items: [{ id, type, scope, status, priority, l1_summary,
    l2_detail, tags, due_date, valid_until, source, created_by,
    updated_by, created_at, updated_at }] }

get_children(item_ids, include_l2?, cascade?)
  Fetch the children of one or more items, grouped by type. Use this
  to drill into a project's tasks, an idea's sub-ideas, or a task's
  subtasks.

  Parameters:
    item_ids:        integer[] (required)
                     Parent item IDs to fetch children for.

    include_l2?:     boolean (default: false)
                     Include L2 detail for each child. When false, only
                     L1 summaries are returned.

    cascade?:        boolean (default: false)
                     Fetch all descendants recursively (entire subtree),
                     not just direct children. Uses recursive CTE
                     internally.

  Returns: { [item_id]: { tasks: [...], facts: [...], notes: [...],
    reminders: [...], ideas: [...] } }
  Items sorted by position within each type group.

get_history(item_ids, since?, until?, limit?)
  Fetch the L3 history log for one or more items. History is
  auto-populated on every item mutation and can be manually enriched
  via add_context(). Use this when the user asks "when did this
  change?", "what's the history of this?", or when you need context
  about past decisions.

  Parameters:
    item_ids:        integer[] (required)
                     Items to fetch history for.

    since?:          string
                     ISO 8601 datetime. Only return entries after this.

    until?:          string
                     ISO 8601 datetime. Only return entries before this.

    limit?:          integer
                     Maximum entries per item. Most recent first.

  Returns: { [item_id]: [{ event, content, actor, created_at }] }

add_context(item_id: integer, note: string)
  Add a manual note to an item's L3 history. Use this to record
  context, decisions, or observations that automatic mutation tracking
  does not capture. These notes help future sessions understand why
  things are the way they are.

  Parameters:
    item_id:         integer (required)
                     The item to add context to.

    note:            string (required)
                     A self-contained statement that will make sense when
                     read months later without any surrounding context.
                     Good: "Switched from Village Grocer — produce
                     quality declined since January"
                     Bad: "changed stores"

  Returns: { history_id: integer }

  Side effects:
    - Creates L3 entry with event='context_added'
```

### Search and discovery

```
search_items(query?, tags?, type?, status?, scope?, parent_id?,
             modified_since?, modified_until?, created_since?,
             created_until?)
  Search across all accessible items using free text, tags, and
  filters. Use this for open-ended questions like "what do we know
  about groceries?" or "show me everything tagged 'health'."

  Parameters:
    query?:          string
                     Free text search query. Matches against l1_summary
                     and l2_detail using SQLite FTS5. Supports FTS5
                     query syntax: AND, OR, NOT, phrase matching with
                     quotes. Example: "grocery OR food"

    tags?:           string[]
                     Filter to items matching ALL of these tags (AND).

    type?:           string
                     Filter by item type: 'task', 'project', 'fact',
                     'reminder', 'note', or 'idea'.

    status?:         string
                     Filter by status. Special value 'expired' returns
                     facts past their valid_until date.

    scope?:          string
                     Filter to a specific scope. Must be one of the
                     caller's accessible scopes.

    parent_id?:      integer
                     Filter to children of a specific item.

    modified_since?: string
                     ISO 8601 datetime. Items updated after this time.

    modified_until?: string
                     ISO 8601 datetime. Items updated before this time.

    created_since?:  string
                     ISO 8601 datetime. Items created after this time.

    created_until?:  string
                     ISO 8601 datetime. Items created before this time.

  Returns: [{ id, type, scope, status, l1_summary, tags,
    relevance_score }]
  Always filtered by caller's scopes.
  Ranked by FTS5 relevance score when using free-text query.

list_items(scope?, type?, status?, parent_id?)
  List all items matching the given filters. Unlike search_items, this
  does not perform free-text search — it returns structured listings.
  Use for "show me everything in the household scope", "list all
  archived tasks", or "what are my top-level projects?"

  Parameters:
    scope?:          string
                     Filter to a specific scope.

    type?:           string
                     Filter by item type.

    status?:         string
                     Filter by status. Default: all non-archived items.

    parent_id?:      integer
                     Filter to children of a specific item. Pass null
                     explicitly for top-level items only.

  Returns: [{ id, type, scope, status, priority, l1_summary, tags,
    due_date, position }]
  Always filtered by caller's scopes.
  Sorted by priority then position.

get_facts(tags?, item_ids?, include_children?, level?)
  Fetch facts by tag or by parent item. Use this after reviewing the
  global facts index (returned by session_boot / refresh_context) to
  load full L2 details for relevant fact categories. For example, if
  the user is discussing health topics, call get_facts(tags=['health'])
  to load all health-related fact details.

  Parameters:
    tags?:           string[]
                     Return facts matching ANY of these tags (OR).

    item_ids?:       integer[]
                     Return facts attached as children of these items.

    include_children?: boolean (default: false)
                     Also return facts attached to descendants (not just
                     direct children) of the specified items.

    level?:          'l1' | 'l2' (default: 'l2')
                     Detail level. 'l1' = headlines only (for scanning),
                     'l2' = full details (for working with facts).

  Returns: [{ id, scope, l1_summary, l2_detail?, tags, source,
    valid_until }]
  When both tags and item_ids provided, returns the union.
```

### Tag management

```
suggest_tags(text: string)
  Find existing tags that match or are similar to the given text. Call
  this before creating items with tags to avoid duplicating existing
  tags or using inconsistent naming. Returns matching tags including
  their aliases.

  Parameters:
    text:            string (required)
                     Text to match against existing tag names and aliases.
                     Can be a single word or phrase. Example:
                     suggest_tags("grocery") might return the existing
                     tag 'groceries' with alias ['grocery'].

  Returns: [{ id, aliases, category }]

list_tags(categories?: string[])
  List all available tags, optionally filtered by category. Use this
  to understand the existing tag taxonomy before categorizing items.
  Categories group related tags (e.g. 'household', 'work', 'health').

  Parameters:
    categories?:     string[]
                     Filter to tags in these categories. Omit to return
                     all tags.

  Returns: [{ id, aliases, category }]
```

### Ordering

```
reorder_items(items: { item_id: integer, position: number }[])
  Change the display order of items within the same parent. All items
  in the batch must share the same parent (or all be top-level). Uses
  fractional indexing — you can position an item between two others
  without renumbering all siblings. When positions become too dense
  (difference < 0.001), the server normalizes all sibling positions
  to whole numbers (1.0, 2.0, 3.0, ...) in a single transaction.

  Parameters:
    items:           [{ item_id: integer, position: number }] (required)
                     Items to reposition. Each entry specifies an item ID
                     and its new position value. All items must share the
                     same parent.

  Returns: { reordered: integer }
           Count of items repositioned.
```

### Scope management

```
list_scopes()
  List all scopes accessible to the current user. Scopes are also
  included in session_boot() and refresh_context() responses, so this
  is primarily a fallback for when scope information has been lost to
  context compression. Use this if you need to check available scopes
  before creating items but no longer have the boot data in context.

  Returns: [{ id, name, description, members: [{ user_id, name }] }]

create_scope(id, name, description?)
  Create a new shared scope. Admin only. A scope defines an access
  boundary — items in a scope are visible and editable by all scope
  members.

  Parameters:
    id:              string (required)
                     Unique scope identifier. Lowercase, no spaces.
                     Examples: 'household', 'kitchen-reno'.

    name:            string (required)
                     Human-readable scope name.
                     Examples: 'Household', 'Kitchen Renovation'.

    description?:    string
                     What this scope is for. Helps the assistant decide
                     which scope to use when creating items.

  Returns: { scope: { id, name, description } }

add_scope_member(scope_id: string, user_id: string)
  Grant a user read/write access to all items in a scope. Admin only.

  Returns: { confirmation: string }

remove_scope_member(scope_id: string, user_id: string)
  Revoke a user's access to a scope. Admin only. Does not delete
  items — they remain accessible to other scope members.

  Returns: { confirmation: string }
```

---

## 6. Safety Model

Four layers, from outermost to innermost:

```
┌─────────────────────────────────────────────────┐
│ Layer 1: Container Isolation                     │
│  OS-level. Containers can't touch each other's   │
│  volumes or the host system.                     │
│  ┌───────────────────────────────────────────┐  │
│  │ Layer 2: MCP Scope Enforcement             │  │
│  │  Every query filtered by caller's scopes.  │  │
│  │  SQL triggers as backstop.                 │  │
│  │  ┌─────────────────────────────────────┐  │  │
│  │  │ Layer 3: Ark Safety Rules            │  │  │
│  │  │  Pattern-matching on tool calls.     │  │  │
│  │  │  Zero token cost. Per-user profiles. │  │  │
│  │  │  ┌───────────────────────────────┐  │  │  │
│  │  │  │ Layer 4: CLAUDE.md Guidance    │  │  │  │
│  │  │  │  Soft rules. Confirmations.    │  │  │  │
│  │  │  └───────────────────────────────┘  │  │  │
│  │  └─────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
```

**Principle:** Outer layers enforce hard boundaries (code). Inner layers guide behavior (prompts). Never rely on an inner layer for what an outer layer can enforce.

### Ark rules

Rule files live on the read-only volume at `/opt/assistant/core/rules/`. Three rule types:

- `@rule` — pattern blacklist, blocks matching tool calls
- `@audit` — logs but does not block
- `@confirm` — requires user confirmation before executing

Rule sets are defined in Section 9 (User Profiles). Three files:

- `shared.rules` — all users: block secrets, block destructive fs, audit scope changes and deletions
- `developer.rules` — technical users: confirm file transfers and force pushes, audit sudo
- `standard.rules` — non-technical users: block file transfers and outbound SSH

### Integration

- MCP server tools: Ark intercepts inside the MCP server before handler execution.
- Claude Code tools (Bash, Read, Write, Edit): Ark runs as a PreToolUse hook in each container's Claude Code config.
- Rules are read-only: containers cannot modify them. Only the host admin (Jimmy) can edit.
- Audit logs written to `/data/{user}/audit/`.

### What each layer catches

| Threat | Layer |
|---|---|
| User A reads User B's files | Layer 1 (container isolation) |
| User A queries User B's tasks | Layer 2 (MCP scope filtering) |
| Non-technical user transfers files to a server | Layer 3 (Ark — blocked by standard.rules) |
| Non-technical user SSHs to a server | Layer 3 (Ark — blocked by standard.rules) |
| Any user accesses `.env` directly | Layer 3 (Ark — blocked by shared.rules) |
| Developer force-pushes without thinking | Layer 3 (Ark — confirmation by developer.rules) |
| Developer sends email without preview | Layer 4 (CLAUDE.md guidance) |
| Any user creates item in wrong scope | Layer 2 (SQL trigger) |

---

## 7. Session Lifecycle

### Phase 1: Boot

```
1. Claude Code launches
   -> Loads CLAUDE-base.md (read-only shared volume)
   -> Loads user CLAUDE.md overrides (user volume)
   -> Ark rules loaded for this user

2. Assistant calls session_boot()
   -> MCP server creates session record
   -> Returns: user profile, last session summary, L1 items, global facts

3. Assistant presents briefing:
   "Good morning Alex. Last time we worked on grocery planning.
    Today you have:
    - 1 project: Kitchen renovation (5/20 done)
    - 2 tasks: Buy groceries (due today), Send package to Sweden
    - 1 reminder: Dentist tomorrow 2pm
    What would you like to focus on?"
```

### Phase 2: Work

Natural conversation. The assistant uses MCP tools as needed.

- Fetches L2/L3 via `set_context()`, `get_details()`, `get_children()`
- Creates/updates items via `add_items()`, `update_item()`
- Saves facts proactively when learning something non-obvious (source='learned')
- Ark rules intercept dangerous operations silently
- MCP auto-populates L3 history on every item mutation
- `checkpoint()` available for mid-session saves

### Phase 3: End

```
1. Assistant prompts: "Did we learn anything today that would make
   it easier if we remembered for next time?"

2. Three paths:
   a) User provides learnings -> saved as facts
   b) User declines -> skip
   c) Assistant suggests learnings it noticed

3. session_end(learnings) called
   -> Facts created from learnings
   -> Session summary generated
   -> Session log written to /data/{user}/sessions/YYYY-MM-DD.md

4. "Session wrapped up. Today we:
    - Completed 2 tasks
    - Created 1 new project
    - Saved 3 learnings
    See you next time!"
```

### Context compression recovery

The MCP server is the source of truth, not the context window. When compression occurs:

1. Assistant detects gaps in its conversation history
2. Calls `refresh_context()` (zero parameters)
3. Server resolves active session and context automatically
4. Response includes: boot L1s, active context with L2 + children, all global fact L1s
5. Assistant re-fetches relevant fact L2s based on current conversation topic

All top-level fact L1 summaries are included in every refresh response, grouped by tag. The assistant decides which to fetch in full based on the current conversation topic.

### Cross-session continuity

- `session_boot()` returns last session summary for orientation
- All item state persists in the database
- Facts accumulated over time build a growing knowledge base
- Session logs provide narrative history for "what happened when" queries

---

## 8. Repository Structure

Two repositories, mirroring the MARVIN pattern (clean template + personalized instance):

### Template repository (clean, no personal data)

```
assistant/                           # git repo, clonable
  mcp-server/                        # MCP server source code
    src/
    migrations/                      # numbered SQL migration scripts
    package.json
  containers/
    Dockerfile                       # single image, all tools included
  core/
    CLAUDE-base.md                   # shared personality, safety, session flow
    rules/                           # Ark rule templates
      shared.rules
      developer.rules
      standard.rules
    skills/                          # shared skills
  setup/
    setup.yml.example                # example config
    apply.sh                         # generates infrastructure from config
    skill/                           # Claude Code skill for guided setup
      SKILL.md
  docker-compose.template.yml       # template, populated by apply.sh
  README.md
```

### Instance (generated by setup, optionally a git repo)

```
/data/                               # persistent data root
  setup.yml                          # personalized config (source of truth)
  docker-compose.yml                 # generated by apply.sh
  assistant.db                       # SQLite database
  backups/                           # automated backups
  jimmy/                             # jimmy's volume
    assistant/
      CLAUDE-user.md                 # generated by first-run onboarding
    sessions/
    content/
    .claude/
    audit/
  alex/                              # alex's volume
    assistant/
      CLAUDE-user.md                 # generated by first-run onboarding
    sessions/
    content/
    .claude/
    audit/
  shared/                            # shared volume
    content/
```

The template repo is cloned once. `setup.yml` and `/data/` are gitignored or live outside the repo. Updates to the template (new features, skills, rule improvements) are pulled via git without affecting personalized data.

---

## 9. User Profiles

All containers use the same image. Profiles control Ark safety rules and MCP tool availability — not what's installed.

| Profile | Ark Rules | MCP Tools | Use case |
|---|---|---|---|
| `developer` | Permissive: confirm production deploys, audit sudo | All | Technical users (Jimmy) |
| `standard` | Shared rules only (secrets, destructive ops, external comms) | Core + web search/fetch | Non-technical users (Alex) |

Both profiles inherit `shared.rules`. The `developer` profile adds deployment confirmations. The `standard` profile blocks operations that only developers should perform.

MCP tool differences are configured per-container (which MCP servers are enabled), not by Ark rules.

Rule sets:

```
# shared.rules — all users
@rule block-secrets
  pattern: Bash.*(\.env|credentials|\.pem|\.key|api.key|secret)
@rule block-destructive-fs
  pattern: Bash.*(rm\s+-rf\s+/|mkfs|dd\s+if=|format\s+)
@audit scope-changes
  pattern: update_item.*scope
@audit deletions
  pattern: archive_items|delete_items

# developer.rules — technical users
@confirm file-transfer
  pattern: Bash.*(rsync|scp)\s+
@confirm force-push
  pattern: Bash.*git\s+push.*--force
@audit sudo-usage
  pattern: Bash.*sudo\s+

# standard.rules — non-technical users
@rule block-file-transfer
  pattern: Bash.*(rsync|scp)\s+
  message: "Blocked: file transfer operations are not available"
@rule block-ssh-out
  pattern: Bash.*ssh\s+
  message: "Blocked: remote server access is not available"
```

---

## 10. Setup Process

Two-step setup: system-level (admin), then per-user onboarding (each user).

### Step 1: System setup (admin)

A Claude Code skill in the template repo guides the admin through generating `setup.yml`:

```
Skill: "Let's set up your assistant. First, the admin user — what's your name?"
Admin: "Jimmy"
Skill: "Are you a developer or a standard user?"
Admin: "Developer"
Skill: "Developer profile — you'll get confirmations on file transfers and
        force pushes, but nothing blocked. Want to adjust anything?"
Admin: "Looks good"
Skill: "Any other users?"
Admin: "My partner Alex, she's not technical"
Skill: "Standard profile for Alex — file transfers and outbound SSH blocked,
        everything else available. The container is disposable if anything breaks."
Admin: "Perfect"
Skill: "What shared spaces do you want between you?"
Admin: "Household"
Skill: "Here's your config:"
```

Generated `setup.yml`:

```yaml
system:
  name: household-assistant

users:
  jimmy:
    name: Jimmy
    role: admin
    profile: developer

  alex:
    name: Alex
    profile: standard

scopes:
  jimmy:
    members: [jimmy]
  alex:
    members: [alex]
  household:
    members: [jimmy, alex]
    description: "Shared household tasks and info"
```

```
Skill: "Look right? I'll generate the infrastructure now."
Admin: "Yes"
Skill: → Writes setup.yml → Runs apply.sh
        → Builds container images
        → Generates docker-compose.yml
        → Initializes database (users, scopes, scope_members)
        → Generates API keys
        → Configures SSH routing
        → Creates volume directories
        → Deploys Ark rules
        "System is up. Jimmy, you can connect now. When Alex connects
         for the first time, she'll be guided through her personal setup."
```

Adding a user later: the admin runs the setup skill again, adds the user to `setup.yml`, and re-runs `apply.sh`. Idempotent — existing users and data are not affected.

### Step 2: Per-user onboarding (first boot)

When a user connects for the first time, the assistant detects no `CLAUDE-user.md` exists and runs an interactive onboarding flow. The user's `name` and `id` are already set in the database from `setup.yml` — the onboarding personalizes how the assistant works with them, not who they are in the system.

**Onboarding questions:**

1. **Name confirmation** — "The admin set you up as 'Alex'. Is that what you'd like me to call you, or do you prefer something else?" Updates `users.name` if they want a different display name. Does not change `users.id` (used for all MCP logic).

2. **Assistant name** — "What would you like to call me?" Stored in CLAUDE-user.md. Default: "Assistant".

3. **About you** — "Tell me a bit about yourself — what you do, what you're working on, what's important to you right now. This helps me understand your context." Free-form. The assistant summarizes into structured fields (role, background, current focus).

4. **Goals** — "What are your main goals right now? These can be work goals, personal goals, or both." Multi-line. Each goal becomes an item (type='project' or type='idea') in the user's personal scope.

5. **Communication style** — "How would you like me to communicate with you?" Predefined options:
   - **Professional** — Clear, direct, business-like. No fluff, just answers.
   - **Casual** — Friendly and conversational. Like talking to a helpful colleague.
   - **Sarcastic** — Dry humor, mild existential commentary, competent pessimism. Gets things done, but wants you to know it's not thrilled about it.
   - **Custom** — "Describe how you'd like me to talk to you."

6. **Detail level** — "When explaining things, do you prefer:"
   - **Quick and direct** — Short answers, no over-explaining.
   - **Balanced** — Enough context to understand, but not exhaustive.
   - **Detailed** — Thorough explanations with reasoning and examples.

7. **Proactive behavior** — "How hands-on should I be?"
   - **Proactive** — I'll suggest things, remind you about deadlines, and flag issues without being asked.
   - **On request** — I'll help when you ask, but won't volunteer unsolicited advice.
   - **Balanced** — Proactive for time-sensitive things (reminders, deadlines), otherwise wait for you to ask.

**Personality presets** are stored in `/opt/assistant/core/personality-presets.yml` (read-only, part of the template repo) so they can be updated across all users without editing individual configs:

```yaml
presets:
  professional:
    label: "Professional"
    description: "Clear, direct, business-like. No fluff, just answers."
    prompt: |
      Communicate professionally. Be direct and concise. Lead with answers,
      not reasoning. Skip filler words and unnecessary transitions.

  casual:
    label: "Casual"
    description: "Friendly and conversational. Like talking to a helpful colleague."
    prompt: |
      Communicate in a friendly, conversational tone. Be warm but still
      helpful and focused. Like talking to a knowledgeable friend.

  sarcastic:
    label: "Sarcastic"
    description: "Dry humor, mild existential commentary, competent pessimism."
    prompt: |
      Communicate with dry humor and mild sarcasm. Competent but slightly
      world-weary. Get things done efficiently while providing occasional
      deadpan commentary. Never let the humor interfere with being helpful.
```

**Example flow:**

```
Assistant: "Hi! I'm your new assistant. The admin set you up as 'Alex' —
            is that what you'd like me to call you?"
Alex:      "Yes, Alex is fine"
Assistant: "Great. What would you like to call me?"
Alex:      "Athena"
Assistant: "Athena it is. Tell me a bit about yourself — what you do,
            what's on your plate right now, what matters to you. This
            helps me understand how to be most useful."
Alex:      "I work in marketing, I handle a lot of the household admin,
            and I'm trying to get more organized with meal planning"
Assistant: "Got it. What are your main goals right now? Work, personal,
            or both."
Alex:      "Get better at meal planning, organize the house move, keep
            up with work deadlines"
Assistant: "Nice. How would you like me to communicate?
            1. Professional — clear and direct
            2. Casual — friendly and conversational
            3. Sarcastic — dry humor, competent pessimism
            4. Custom — describe your own style"
Alex:      "2"
Assistant: "Casual it is. How much detail when I explain things?
            1. Quick and direct
            2. Balanced
            3. Detailed"
Alex:      "1"
Assistant: "And how hands-on should I be?
            1. Proactive — I'll suggest things and flag issues
            2. On request — I help when asked
            3. Balanced — proactive for deadlines, otherwise wait"
Alex:      "1"
Assistant: "All set! Here's what I've saved:"
```

Generates `CLAUDE-user.md`:

```markdown
## User Profile
Name: Alex
Assistant name: Athena
Role: Marketing, household administration
Current focus: Meal planning, house move, work deadlines

## Communication
Style: Casual — friendly and conversational
Detail: Quick and direct, no over-explaining
Behavior: Proactive — suggest things, flag issues, remind about deadlines
```

Creates initial items in MCP:
- Project: "Meal planning system" (scope: alex)
- Project: "House move" (scope: household)
- Idea: "Better work deadline tracking" (scope: alex)

---

## 11. Configuration

### Layered CLAUDE.md

```
/opt/assistant/core/               read-only volume (from template repo)
  CLAUDE-base.md                   personality, safety, session flow, MCP patterns

/data/jimmy/assistant/             jimmy's volume
  CLAUDE-user.md                   generated by first-run onboarding

/data/alex/assistant/              alex's volume
  CLAUDE-user.md                   generated by first-run onboarding
```

At container startup, an entrypoint script concatenates base + user overrides into a single file. This ensures the full configuration is loaded into context as one document — no include system or layered file resolution.

```bash
cat /opt/assistant/core/CLAUDE-base.md > /home/$USER/assistant/CLAUDE.md
cat /home/$USER/assistant/CLAUDE-user.md >> /home/$USER/assistant/CLAUDE.md
```

**Override precedence:** Order matters. Base goes first (shared personality, safety rules, session flow, MCP patterns), then user overrides append (profile, preferences, communication style). Claude Code treats later instructions as higher priority, so user-specific preferences naturally override base defaults where they conflict. For example, if CLAUDE-base.md sets a professional tone but a user's CLAUDE-user.md specifies casual and playful, the user's preference wins.

### What goes where

| Content | Location |
|---|---|
| Personality, tone, safety rules | CLAUDE-base.md |
| Session flow, MCP usage patterns | CLAUDE-base.md |
| Context management rules | CLAUDE-base.md |
| User profile, preferences | User CLAUDE.md (generated by onboarding) |
| Communication style | User CLAUDE.md |
| Available capabilities/tools | User CLAUDE.md (derived from profile) |
| Integration configs | User CLAUDE.md |

### Updating

Base config changes are pulled from the template repo and deployed to `/opt/assistant/core/`. Read-only mount makes changes immediately visible to all containers. If using concatenation, containers need restart or re-run of entrypoint.

---

## 12. Interface Layer

All interfaces route messages to Claude Code inside the correct user's container. Isolation, safety, and data access are enforced at container + MCP layers, not the interface.

```
   SSH           Telegram          Web Chat
    |                |                |
    v                v                v
  Interface Router: user -> container
    |                        |
    v                        v
jimmy-assistant        alex-assistant
    |                        |
    +------------------------+
                |
          assistant-mcp
```

### Phase 1: SSH (immediate)

Host SSH routes users to their containers:

```
# sshd config on host
Match User jimmy
  ForceCommand docker exec -it jimmy-assistant /usr/bin/fish

Match User alex
  ForceCommand docker exec -it alex-assistant /usr/bin/fish
```

Alex's laptop config:

```
Host marvin
  HostName assistant-server
  User alex
```

### Phase 2: Telegram bridge (future)

A routing service maps Telegram user IDs to containers. Not part of the initial implementation.

**Note:** The existing Telegram bridge design (`docs/plans/2026-03-09-telegram-bridge-design.md`) assumes a single-user MARVIN architecture with one Claude Code subprocess. It will need to be rearchitected for multi-user routing — not adapted, but redesigned with the container model in mind.

### Phase 3: Web chat (future)

Web app with authentication (login/JWT) routes messages to containers via WebSocket proxy.

### Interface responsibilities

| Responsibility | Interface | Container | MCP Server |
|---|---|---|---|
| User authentication | Yes | No | No |
| User to container routing | Yes | N/A | N/A |
| Scope enforcement | No | No | Yes |
| Ark safety rules | No | Yes (hooks) | Yes (interception) |
| Data access | No | Via MCP | Yes |
| Session management | No | Initiates | Tracks |

**Principle:** Interfaces are thin. Authenticate and route. Adding a new interface should be a routing exercise, not a security audit.

---

## 13. Design Decisions and Rationale

### Container isolation over Linux users
Linux users provide file-level isolation but share the host OS. A non-technical user's Claude Code could install packages, fill disk, or break shared environments. Containers provide disposable environments with resource limits. Rebuild in seconds if anything breaks.

### Single database with scopes over per-user databases
Scopes control access at the row level. One database is simpler to manage, backup, and query across. Cross-scope queries (boot loading private + shared) are natural. The MCP server enforces scope filtering; SQL triggers provide a backstop.

### Hybrid storage over pure files or pure database
Database for structured data (tasks, facts, projects) prevents accidental loss — individual records can't be overwritten by editing unrelated content. Files for narrative data (session logs, documents) — human-readable, write-once, git-friendly.

### Tiered loading over flat state
MARVIN loads ~4,000+ tokens of state every session regardless of need. L1/L2/L3 tiers load 300-500 tokens at boot, fetching details on demand. Saves tokens, keeps context focused, scales to many items.

### MCP server over file-based state
Enforces access control in code. Provides type-safe CRUD operations. Auto-populates history. Prevents the "Claude rewrote the file and lost data" failure mode. Interface-agnostic — works the same for SSH, Telegram, and web.

### Ark safety rules over prompt-only guidance
Regex-based pattern matching at zero token cost. Per-user profiles (restrictive for non-technical users, permissive for developers). Runs in code, not dependent on LLM compliance. Defense in depth on top of container isolation.

---

## 14. Backup and Migration

### Database backup
The SQLite database (`assistant.db`) is the single source of truth for all structured data. Backup strategy:

- **Automated daily backup:** Cron job on host runs `sqlite3 assistant.db ".backup /backups/assistant-$(date +%Y%m%d).db"`. Hot backup, no downtime.
- **Retention:** Keep 30 daily backups, 12 monthly backups.
- **Off-site:** Sync backup directory to cloud storage (Google Drive, S3, or similar).
- **Verification:** Weekly integrity check via `PRAGMA integrity_check`.

### Volume backup
Per-user volumes (`/data/{user}/`) contain session logs, documents, and Claude Code config. Backed up alongside the database via rsync or volume snapshots.

### Schema migrations
Schema changes managed via numbered migration scripts (`migrations/001_initial.sql`, `002_add_field.sql`, etc.). The MCP server checks current schema version on startup and applies pending migrations. No ORM — raw SQL migrations for transparency and control.

---

## Appendix A: Reference Projects

### Soul (n2-soul)
MCP server for persistent agent memory. Relevant ideas borrowed:
- Progressive context loading (L1/L2/L3)
- Structured memory types (brain/entity/core mapped to our fact/project/task)
- Ark safety interception pattern (regex-based, zero token cost)
- Session lifecycle (boot/work/end)
- Plain file storage for cloud sync compatibility

Soul solves multi-agent memory, not multi-user isolation. We adopt its memory patterns while building user boundaries that Soul does not have.

### MARVIN
The current single-user assistant being replaced. Patterns carried forward:
- Session flow (/start, /end, /update)
- Skill-based extensibility
- State tracking and goal management
- Google Workspace integration

Problems addressed by this design:
- Flat state loading (~4,000+ tokens every session)
- File-based state vulnerable to rewrite errors
- Single-user only
- No access control or safety enforcement beyond prompt instructions
