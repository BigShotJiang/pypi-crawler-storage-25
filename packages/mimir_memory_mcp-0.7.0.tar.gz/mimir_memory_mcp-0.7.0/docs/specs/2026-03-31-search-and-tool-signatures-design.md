# Mimir MCP — Search & Tool Signature Improvements

**Date:** 2026-03-31
**Status:** Approved

## Summary

Improve Mimir MCP in three areas: (1) FTS5 search with porter stemming so word variations match, (2) rename schema columns and tool signatures for LLM usability, (3) rewrite all tool descriptions and server instructions following MCP best practices. Additionally, make `complete_items` cascade to descendants (matching `archive_items`) and change `delete_items` from hard delete to soft delete.

## Motivation

During Hermes multi-user deployment testing, the Mimir MCP API was tested end-to-end. Two problems surfaced:

1. **Search doesn't stem.** FTS5 uses the default unicode61 tokenizer. "bedroom" doesn't match "bedrooms". This makes the memory system unreliable for natural language queries.

2. **Tool signatures confuse LLMs.** Field names like `l1_summary`, `l2_detail`, and tool names like `session_boot` are internal jargon. An LLM calling `add_items` for the first time used `title` instead of `l1_summary` — a direct signal that the API surface is unintuitive.

Research into MCP best practices (Anthropic docs, GitHub MCP Server patterns, FastMCP framework, LLM tool selection studies) identified a three-layer guidance model and specific improvements.

## Design

### 1. FTS5 Porter Stemming

**Change:** Recreate the FTS5 virtual table with the `porter unicode61` tokenizer.

**Current:**
```sql
CREATE VIRTUAL TABLE items_fts USING fts5(
    l1_summary, l2_detail, content='items', content_rowid='id'
);
```

**New (after column rename):**
```sql
CREATE VIRTUAL TABLE items_fts USING fts5(
    summary, detail, content='items', content_rowid='id',
    tokenize='porter unicode61'
);
```

Porter stemming reduces words to their root form: "bedrooms" matches "bedroom", "running" matches "run". Built into SQLite, zero dependencies. English-only for now.

Since there is no production data, modify `001_initial.sql` directly — no migration needed. The FTS triggers also update to use the new column names.

### 2. Schema Column Renames

No production data — modify `001_initial.sql` directly.

| Current | New | Rationale |
|---------|-----|-----------|
| `l1_summary` | `summary` | Self-explanatory, no internal jargon |
| `l2_detail` | `detail` | Natural companion to summary |

All references must be updated: schema, triggers, indexes, queries, models, tools, tests.

### 3. Tool Renames

| Current | New | Rationale |
|---------|-----|-----------|
| `session_boot` | `start_session` | Verb-first, matches end_session |
| `session_checkpoint` | `save_session` | Clearer intent |
| `add_context` | `add_note` | "context" is overloaded in LLM land |
| `get_children` | `list_children` | Consistent with list_items, list_scopes |

Parameter renames:
| Tool | Current param | New param |
|------|--------------|-----------|
| `add_note` | `context_text` | `note` |
| `list_children` | `include_l2` | `include_detail` |
| `get_facts` | `level="l1"/"l2"` | `level="summary"/"detail"` |

Tools that keep their names: `end_session` (was `session_end`, already registered as `session_end` — rename to `end_session`), `set_context`, `refresh_context`, `add_items`, `update_item`, `complete_items`, `archive_items`, `delete_items`, `convert_item`, `search_items`, `list_items`, `get_facts`, `get_details`, `get_history`, `list_scopes`, `create_scope`, `add_scope_member`, `remove_scope_member`, `reorder_items`, `suggest_tags`, `list_tags`.

### 4. Behavioral Changes

#### complete_items: Add cascade to descendants

**Current:** Does not cascade — only completes the specified items.
**New:** Cascades to all descendants, matching `archive_items` behavior.

**Rationale:** The inconsistency between complete (no cascade) and archive (cascade) is a footgun. An LLM will assume they behave the same way. The common case — completing a project means its tasks are done — should be the default.

#### delete_items: Soft delete instead of hard delete

**Current:** Hard delete via SQL DELETE with FK cascade.
**New:** Soft delete — sets status to 'deleted' on the item and all descendants.

**Schema change:** Add `'deleted'` to the status CHECK constraint:
```sql
CHECK (status IN ('not_started','in_progress','blocked','completed',
                  'archived','active','expired','deleted'))
```

**Query changes:** All default queries that exclude completed/archived must also exclude deleted. `search_items` and `list_items` default exclusion becomes `NOT IN ('completed', 'archived', 'deleted')`.

### 5. Three-Layer Description Model

Research consensus: tool descriptions work best in three layers, each with a distinct role.

| Layer | Purpose | Where |
|-------|---------|-------|
| Server instructions | Session lifecycle, tool ordering, workflows, what items/scopes are | `FastMCP(instructions=...)` in server.py |
| Tool descriptions | What + when + boundaries for each tool | `@mcp.tool` docstrings |
| Parameter descriptions | Format, constraints, non-obvious behavior | `Annotated[type, Field(description=...)]` |

#### Server Instructions

```
Mimir is a structured memory server for AI assistants. All data is
scoped to the authenticated user.

Items are the core unit of memory. Each item has a type (task, project,
fact, reminder, note, idea), belongs to a scope, and has a summary
(short headline) and optional detail (extended description). Items can
form trees: projects, tasks, and ideas can have children; facts, notes,
and reminders cannot.

Scopes are access groups. Each user has a personal scope plus any
shared scopes (e.g., "household"). You only see items in scopes you
belong to.

Session lifecycle — follow this order:
1. Call start_session once at conversation start. Returns your full
   context.
2. Call save_session periodically during long conversations to preserve
   your position in shared activity.
3. Call end_session when the conversation ends. Pass any new facts
   learned as learnings.

Context focus:
- Use set_context to drill into a specific item (shows its detail and
  children) or clear focus to return to the top-level overview.
- Use refresh_context to reload the current view with fresh data when
  your conversation context has been compressed.

Finding items:
- search_items: keyword search with stemming. Use when you have words
  to find.
- list_items: filtered browse by type, status, scope, parent. Use when
  you want to browse structure.
- get_facts: retrieve facts by tag or parent item. Use for targeted
  fact lookup.
```

#### Tool Descriptions

**Session:**

- **start_session:** "Start a new session and return your full current state: projects, tasks, ideas, reminders, facts, and recent changes by other users. Call once at the beginning of every conversation. Closes any leftover sessions from previous conversations automatically."

- **end_session:** "End the current session. Pass learnings to save new facts that should persist across sessions. Marks all shared activity as seen and closes the session. Unlike save_session, this is permanent."

- **save_session:** "Save progress mid-session without ending it. Marks shared activity as seen so you won't receive it again if the session is interrupted. Does not return data — use refresh_context to reload your current view."

**Context:**

- **set_context:** "Focus on a specific item or return to the top-level overview. With item_id: returns that item's full detail, its children (summaries), and facts. With item_id=None: clears focus and returns the top-level summary (projects, tasks, ideas, reminders, facts). Does NOT reload session or shared activity — use refresh_context for that."

- **refresh_context:** "Reload your full current state without changing focus. Returns everything set_context shows, plus scopes with members, changes made during this session, and recent changes by other users. Use when your conversation context has been compressed and you need to rebuild working memory. Unlike start_session, does not create a new session."

**Item CRUD:**

- **add_items:** "Create one or more items. Each item needs a scope, type (task/project/fact/reminder/note/idea), and summary at minimum. To nest under a parent, set parent_id — the parent must be a project, task, or idea in the same scope."

- **update_item:** "Modify an existing item's fields. Pass only the fields to change — others are preserved. Changing scope moves all children automatically. To add a note about an item without changing its fields, use add_note instead."

- **complete_items:** "Mark items as completed, including all their descendants. Use when work is finished. To hide items you no longer need, use archive_items instead. To permanently remove items, use delete_items."

- **archive_items:** "Archive items and all their descendants. Archived items stop appearing in search and list results but can be found with status='archived'. To mark work as successfully finished, use complete_items instead. To permanently remove items, use delete_items."

- **delete_items:** "Soft-delete items and all their descendants. Items are flagged as deleted and excluded from all queries. Admin only. To mark work as finished, use complete_items. To hide items reversibly, use archive_items."

- **convert_item:** "Change an item's type (e.g., task to project, idea to task). Items with children can only become types that support children (project, task, idea). Types that cannot have children: fact, note, reminder."

**Search:**

- **search_items:** "Full-text search across item summaries and details with word stemming (e.g., 'run' matches 'running'). Ranked by relevance. Excludes completed, archived, and deleted items by default — pass status to override. Returns up to 50 results. Do NOT use for browsing by structure — use list_items for that."

- **list_items:** "Browse items with filters, without keyword search. Shows top-level items by default. Pass parent_id to list children of a specific item. Filter by type, status, or scope. Sorted by priority then position. Do NOT use for text search — use search_items for that."

- **get_facts:** "Retrieve facts by tags or by parent item. Tags use OR logic — returns facts matching any given tag. Pass item_ids to get facts attached as children of specific items. At least one filter required; without either, returns nothing. Excludes expired facts. Pass level='detail' for extended descriptions."

**Navigation:**

- **get_details:** "Fetch full detail for one or more items by ID, including extended description, metadata, and timestamps. A read-only lookup — does NOT change your focus. Items not found or outside your scopes are silently omitted. To navigate into an item and see its children, use set_context instead."

- **list_children:** "List direct children of an item, grouped by type. Returns summaries by default — pass include_detail=True for extended descriptions. Pass cascade=True for all descendants recursively. Do NOT use for top-level items — use list_items for that."

- **get_history:** "Get the change history for an item: who changed what, when, and how. Each entry shows the event type (created, updated, completed, etc.) and what changed. Supports time range filtering with since/until (ISO 8601). Returns up to 50 entries."

- **add_note:** "Append a note to an item's history without modifying the item itself. Use for recording context, decisions, or observations. The note appears in get_history results. To change an item's summary, detail, or other fields, use update_item instead."

**Scopes:**

- **list_scopes:** "List your accessible scopes with their members."

- **create_scope:** "Create a new scope. Admin only. You are added as the first member automatically."

- **add_scope_member:** "Add a user to a scope. Admin only."

- **remove_scope_member:** "Remove a user from a scope. Admin only. Items in the scope are preserved — only the user's access is removed."

**Tags & Ordering:**

- **reorder_items:** "Set display positions for items within the same parent. Positions are decimal numbers — use values between existing items to insert without renumbering. Automatically renumbers if positions get too close together."

- **suggest_tags:** "Autocomplete tags by prefix. Matches tag names and aliases. Use before adding tags to find existing ones and avoid duplicates."

- **list_tags:** "List all available tags, optionally filtered by category."

### 6. Type Changes for Filter Parameters

Convert bare `str` filter parameters to `Literal` types so the JSON schema carries enum constraints, reducing description burden.

| Parameter | Current | New |
|-----------|---------|-----|
| `search_items.type` | `str \| None` | `Literal["task","project","fact","reminder","note","idea"] \| None` |
| `search_items.status` | `str \| None` | `Literal["not_started","in_progress","blocked","completed","archived","active","expired","deleted"] \| None` |
| `list_items.type` | `str \| None` | Same Literal as search_items.type |
| `list_items.status` | `str \| None` | Same Literal as search_items.status |
| `convert_item.new_type` | `str` | `Literal["task","project","fact","reminder","note","idea"]` |
| `get_facts.level` | `str` | `Literal["summary","detail"]` |

### 7. Parameter Descriptions

Every parameter gets a `Field(description=...)` via `Annotated`. Descriptions add meaning beyond what the JSON schema type/enum/default already shows. None/null semantics are explicit on every optional param. Format examples included for dates, dicts, and IDs.

#### start_session
- `scopes`: "Scope IDs to activate for this session (e.g., 'jimmy', 'household'). Only items in active scopes are visible. Use list_scopes to see available scopes."

#### end_session
- `learnings`: "New facts discovered this session. Each string is saved as a persistent fact (type='fact', source='learned') in your personal scope. For facts in shared scopes or with custom fields, use add_items with type='fact' instead. Pass None or omit to end without saving facts."

#### set_context
- `item_id`: "Item to focus on — returns its full detail, children, and relevant facts. Pass None to clear focus and return to the top-level overview."

#### add_items
- `items`: "Items to create. Each needs at minimum: scope, type, and summary."

#### ItemInput fields
- `scope`: "Scope this item belongs to (e.g., 'jimmy', 'household'). Must be a scope you have access to."
- `type`: "Determines behavior and lifecycle. Tasks/projects track work and have status flow (not_started -> in_progress -> completed). Facts store persistent knowledge (support expiration via valid_until). Reminders are time-triggered alerts. Notes capture freeform context. Ideas are lightweight proposals."
- `summary`: "Short, self-contained headline (1-2 sentences). Must be fully understandable without the detail field. Shown in session summaries and search results. Good: 'Alex is allergic to shellfish'. Bad: 'allergy info'."
- `detail`: "Extended description, background, or specifications that don't fit in summary. Loaded on demand — not shown in search results or session summaries. Can be multi-paragraph. Omit or pass None if summary is sufficient."
- `parent_id`: "Nest under this item. Parent must be a project, task, or idea in the same scope. Omit or pass None for a top-level item."
- `tags`: "Tag IDs to attach. Use suggest_tags first to find existing tags and avoid duplicates. Omit or pass None for no tags."
- `priority`: "Affects sort order in listings — items are sorted by priority then position. Omit or pass None to leave unset."
- `status`: "Override the type-specific default status. Defaults by type: task='not_started', project/fact/reminder/note/idea='active'. Other valid values: 'in_progress', 'completed', 'archived'. Use when an item is already in progress or completed."
- `due_date`: "When this item is due (ISO 8601 date or datetime, e.g., '2025-06-15' or '2025-06-15T14:00:00'). Omit or pass None if no deadline."
- `valid_until`: "Expiration date (ISO 8601, e.g., '2025-06-15'). Only enforced for fact-type items — expired facts are automatically excluded from queries. Silently stored but has no effect on other item types. Omit or pass None for no expiration."
- `position`: "Sort position among siblings under the same parent. Lower values appear first. Use decimal values to insert between existing items (e.g., 1.5 between positions 1 and 2). Omit to leave unpositioned."
- `source`: "Origin of a fact — 'learned' = inferred by the system, 'user_stated' = told directly by the user, 'documented' = sourced from a document or reference. Only meaningful for type='fact'. Silently stored but ignored for other types."
- `metadata`: "Arbitrary key-value JSON data for integrations or custom workflows (e.g., {'url': '...', 'priority_score': 42}). Stored as-is. Not indexed for search — use tags for filterable categorization."

#### update_item
- `item_id`: "ID of the item to update."
- `updates`: "Partial update — only include fields you want to modify. Omitted fields are left unchanged. Valid keys: summary, detail, status, priority, due_date, valid_until, scope, position, source, metadata, tags. Tags replace all existing tags (pass [] to clear). Pass '' for due_date or valid_until to clear them."

#### complete_items
- `item_ids`: "IDs of items to mark as completed. Cascades to all descendants — children, grandchildren, etc. are also completed."

#### archive_items
- `item_ids`: "IDs of items to archive. Cascades to all descendants — children, grandchildren, etc. are also archived."

#### delete_items
- `item_ids`: "IDs of items to soft-delete. Cascades to all descendants. Deleted items can be restored."

#### convert_item
- `item_id`: "ID of the item to convert. Children and history are preserved."
- `new_type`: "Target type. The item's status resets to the new type's default. Cannot convert to a leaf type (fact, note, reminder) if the item has children."

#### search_items
- `query`: "Full-text search query. Supports word stemming ('run' matches 'running'). Searches summary and detail fields. For unfiltered browsing by type/status, use list_items instead."
- `type`: "Filter results to this item type. None (default) returns all types."
- `status`: "Filter by status. None (default) excludes completed, archived, and deleted items. Pass a specific status to override (e.g., 'completed' to find finished items)."
- `tag`: "Filter to items with this tag ID. Accepts a single tag. For multi-tag OR queries on facts, use get_facts instead. None (default) skips tag filtering."

#### list_items
- `type`: "Filter results to this item type. None (default) returns all types."
- `status`: "Filter by status. None (default) excludes completed and archived items. Pass a specific status to override (e.g., 'completed' to find finished items)."
- `parent_id`: "List children of this item. None (default) returns top-level items only (items with no parent). For recursive descent or detail inclusion, use list_children instead."
- `scope`: "Narrow results to a single scope ID (e.g., 'jimmy'). None (default) returns items from all active scopes."

#### get_facts
- `tags`: "Return facts tagged with any of these tag IDs (OR logic). None (default) skips tag filtering."
- `item_ids`: "Return facts that are children of these items. None (default) skips parent filtering."
- `include_children`: "When true, also return facts from all descendants of the specified item_ids, not just direct children. Default: false."
- `level`: "'summary' (default) returns headlines only for fast context loading. 'detail' includes the full detail field — use when you need specifics."

#### get_details
- `item_ids`: "IDs of items to fetch full detail for. Returns summary, detail, tags, metadata, timestamps — everything about each item. Items outside your active scopes are silently excluded."

#### list_children
- `parent_id`: "ID of the parent item to list children of. Results are grouped by type."
- `include_detail`: "Include the extended detail field in results. Default (False) returns summaries only."
- `cascade`: "True to include all descendants recursively (children, grandchildren, etc.), not just direct children. Default: False."

#### get_history
- `item_id`: "ID of the item to fetch change history for."
- `since`: "Only include entries from this timestamp onward (ISO 8601 datetime, e.g., '2025-06-01T00:00:00'). None (default) for no lower bound."
- `until`: "Only include entries up to this timestamp (ISO 8601 datetime). None (default) for no upper bound."
- `limit`: "Maximum number of history entries to return. Newest entries are returned first."

#### add_note
- `item_id`: "ID of the item to attach the note to."
- `note`: "Free-text note recorded in the item's history (event='context_added'). Use for background, decisions, observations, or status updates."

#### reorder_items
- `entries`: "List of {item_id, position} pairs. All items must share the same parent (or all be top-level). Positions auto-normalize when gaps get too small."

#### ReorderEntry fields
- `item_id`: "ID of the item to reposition."
- `position`: "New sort position. Lower values appear first. Use decimals to insert between existing positions (e.g., 1.5 between 1 and 2)."

#### suggest_tags
- `query`: "Tag name prefix to search for. Matches against tag IDs and aliases (e.g., 'pri' matches 'priority', 'private')."

#### list_tags
- `categories`: "Filter to tags in these category IDs. None (default) returns all tags across all categories."

#### create_scope
- `scope_id`: "Unique scope identifier (e.g., 'household', 'work-projects'). Lowercase letters, numbers, hyphens, and underscores only. Cannot be changed after creation."
- `name`: "Human-readable display name for the scope (e.g., 'Household', 'Work Projects')."
- `description`: "What this scope is used for. Shown when listing scopes. None (default) for no description."

#### add_scope_member
- `scope_id`: "ID of the scope to add the user to."
- `member_user_id`: "User ID of the person to add."

#### remove_scope_member
- `scope_id`: "ID of the scope to remove the user from."
- `member_user_id`: "User ID of the person to remove."

### 8. Implement get_facts include_children

The `include_children` parameter exists in the `get_facts` function signature but is currently a no-op. Implement it: when `true` and `item_ids` is provided, return facts from all descendants of the specified items (using a recursive CTE), not just direct children.

## Scope

### In scope
- FTS5 porter stemming (modify 001_initial.sql)
- Column renames: l1_summary → summary, l2_detail → detail
- Tool renames: session_boot → start_session, session_end → end_session, session_checkpoint → save_session, add_context → add_note, get_children → list_children
- Parameter renames: context_text → note, include_l2 → include_detail, level values l1/l2 → summary/detail
- Behavioral: complete_items cascade, delete_items soft delete
- Status CHECK: add 'deleted'
- Default query exclusions: add 'deleted' alongside completed/archived
- Server instructions rewrite
- Tool description rewrite (all 25 tools)
- Parameter descriptions for all tools (Field(description=...) via Annotated)
- Type changes for filter parameters (Literal types)
- Implement get_facts include_children (recursive descendant fact retrieval)
- Update all Python code: models, queries, tools, server.py, auth.py
- Update all tests

### Out of scope
- Multilingual search (CJK tokenization)
- Production data migration (no production data exists)

## Files affected

| Area | Files |
|------|-------|
| Schema | `src/mimir_mcp/migrations/001_initial.sql` |
| Models | `src/mimir_mcp/models.py` |
| Queries | `src/mimir_mcp/queries.py` |
| Server | `src/mimir_mcp/server.py` |
| Tools | `src/mimir_mcp/tools/session.py`, `context.py`, `items.py`, `search.py`, `navigation.py`, `ordering.py`, `scopes.py`, `tags.py` |
| Tests | `tests/conftest.py`, `tests/test_*.py` (all test files) |
