# Mimir MCP — Version Endpoint

**Date:** 2026-04-16
**Status:** Approved

## Summary

Add an unauthenticated HTTP endpoint `GET /version` that returns the running server's package version and API contract version. Log the same information to stdout at startup.

## Motivation

There is currently no programmatic way to determine which version of Mimir is running on a given deployment. The `/health` endpoint reports only liveness (`{"status":"ok"}`). Package version is defined in `pyproject.toml` but not exposed at runtime. The `MIMIR_API_VERSION` constant is set on REST response headers but not queryable on its own.

This gap was discovered while investigating tool-name drift: the repo was at v0.5.0 while the deployed server still exposed pre-v0.4.0 tool names (`search_items_tool` vs. `search_items`). The only way to confirm this was cross-referencing source code against client-side tool names — investigation, not a direct code call.

The primary use case is deployment verification after pushing improvements: "did my new build actually land?"

## Design

### 1. Endpoint

New route in `src/mimir_mcp/server.py`, sitting alongside `/health` and `/api/*`:

```python
@mcp.custom_route("/version", methods=["GET"])
async def version_route(request: Request) -> JSONResponse:
    return _api_response({
        "version": _get_package_version(),
        "api_version": MIMIR_API_VERSION,
    })
```

Response:

```json
{"version": "0.5.0", "api_version": "1"}
```

- **Unauthenticated** (same policy as `/health`). The endpoint exposes only version strings — no data.
- Reuses existing `_api_response` helper, which attaches the `X-Mimir-API-Version: 1` header.
- Never raises: missing metadata returns `"unknown"` rather than 500.

### 2. Package-version helper

```python
from importlib.metadata import version as pkg_version, PackageNotFoundError

def _get_package_version() -> str:
    try:
        return pkg_version("mimir-memory-mcp")
    except PackageNotFoundError:
        return "unknown"
```

Reading through `importlib.metadata` keeps `pyproject.toml` as the single source of truth. No hardcoded version string in code.

### 3. Startup log

In `main()`, after `create_server()` and before `server.run()`:

```python
server = create_server()
print(f"Mimir v{_get_package_version()} (api_version={MIMIR_API_VERSION}) listening on :{port}")
server.run(transport="sse", host="0.0.0.0", port=port)
```

- `print()` matches the style already used by `auto_seed` (no logging framework in play).
- Placed in `main()` — not `create_server()` — so test fixtures that call `create_server()` directly do not emit the message.
- Output goes to container stdout, visible via `docker logs mimir`.

### 4. Testing

Add `TestVersionEndpoint` class to `tests/test_rest.py`, reusing the existing `client` fixture:

- **`test_version_returns_200_and_shape`** — `GET /version`, assert 200, assert response JSON contains `version` (non-empty string) and `api_version` (equals `"1"`).
- **`test_version_no_auth_required`** — `GET /version` with no `x-api-key` header, still returns 200.
- **`test_version_includes_api_version_header`** — assert `X-Mimir-API-Version: 1` is present on the response.

No startup-log test. Capturing stdout during `main()` is over-engineered for an observational print statement.

## Excluded (YAGNI)

- **`git_sha`** — considered, rejected. Requires Dockerfile `ARG`/`ENV`, a build-contract (`--build-arg GIT_SHA=...`), and a Makefile wrapper so callers do not forget. For the stated workflow (discipline around version bumps on release), `version` alone is sufficient. Can be added later as a minor follow-up if mid-development drift becomes a real problem.
- **Started-at timestamp** — changes on every restart, not every deploy. Adds noise without resolving the core question.
- **MCP tool wrapper** (e.g. `get_server_info`) — version verification is an out-of-band operational event, not an in-conversation need. An MCP tool would clutter the tool list for every future client session.
- **Endpoint authentication** — the response contains no user data; `/health` is already unauthenticated. Adding auth costs nothing functionally and buys nothing.
- **Response caching** — `importlib.metadata.version()` plus an env lookup is microseconds. Caching is premature optimization.
- **Structured logging** — out of scope. The codebase has no logging framework today; introducing one is a separate project.

## Open questions

None. All decisions resolved during brainstorming.
