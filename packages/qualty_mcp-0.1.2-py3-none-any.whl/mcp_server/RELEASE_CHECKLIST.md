# Qualty MCP Release Checklist

Use this before publishing to PyPI.

1. Bump version in `pyproject.toml`.
2. Build artifacts:
   - `python3 -m build`
3. Smoke-test wheel:
   - `pipx install --force dist/*.whl`
4. Verify CLI:
   - `qualty-mcp doctor`
5. Verify MCP startup:
   - `qualty-mcp`
6. Publish package to PyPI.
7. Re-test install from public index:
   - `pipx install --force qualty-mcp`

