"""
Qualty MCP — Review UI.

Spins up a temporary local HTTP server, opens the review page in the user's
browser, and blocks until they confirm or cancel.
"""

import http.server
import json
import socket
import threading
import webbrowser
from typing import Any

from .html_template import REVIEW_HTML


def build_review_html(tests: list[dict], profiles: list[dict], root_url: str | None) -> str:
    """Inject server-fetched data into the review page HTML."""
    enriched = []
    for t in tests:
        t2 = dict(t)
        if not t2.get("url") and root_url:
            t2["url"] = root_url
        enriched.append(t2)

    def _safe_js_json(value: Any) -> str:
        # Prevent user-provided content from breaking out of <script> tags.
        # This preserves valid JSON while neutralizing HTML parser boundaries.
        return json.dumps(value).replace("</", "<\\/")

    return (
        REVIEW_HTML
        .replace("__TESTS_JSON__",    _safe_js_json(enriched))
        .replace("__PROFILES_JSON__", _safe_js_json(profiles))
        .replace("__ROOT_URL_JSON__", _safe_js_json(root_url or ""))
        .replace("__PROJECT_NAME__", "Current Project")
    )


def run_review_server(
    tests: list[dict],
    profiles: list[dict],
    root_url: str | None,
    project_name: str | None = None,
    timeout: int = 300,
) -> list[dict]:
    """
    Open the review page and block until the user confirms or cancels.
    Returns the list of confirmed (and possibly edited) test dicts.
    Raises RuntimeError on timeout or cancellation.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        port = s.getsockname()[1]

    html_bytes = build_review_html(tests, profiles, root_url).replace(
        "__PROJECT_NAME__", project_name or "Current Project"
    ).encode("utf-8")
    state: dict[str, Any] = {
        "done":      threading.Event(),
        "tests":     None,
        "cancelled": False,
    }

    class _Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            if self.path in ("/", "/index.html"):
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(html_bytes)))
                self.end_headers()
                self.wfile.write(html_bytes)
            else:
                self.send_response(404)
                self.end_headers()

        def do_POST(self):  # noqa: N802
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)

            if self.path == "/confirm":
                try:
                    data = json.loads(body)
                    state["tests"] = data.get("tests", [])
                except Exception:
                    state["tests"] = []
            elif self.path == "/cancel":
                state["cancelled"] = True

            resp = json.dumps({"ok": True}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(resp)))
            self.end_headers()
            self.wfile.write(resp)
            state["done"].set()

        def log_message(self, *args):  # noqa: N802
            pass  # suppress access logs

    srv = http.server.HTTPServer(("localhost", port), _Handler)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()

    REVIEW_URL = f"http://localhost:{port}"
    print(f"[Qualty MCP] Review the generated tests in URL: {REVIEW_URL}", flush=True)
    webbrowser.open(REVIEW_URL)

    finished = state["done"].wait(timeout=timeout)
    srv.shutdown()

    if not finished:
        raise RuntimeError(
            f"Review timed out after {timeout}s (5 minutes) — no tests were created. "
            f"Please open the review URL and confirm your choices in URL {REVIEW_URL}, then call create_test again."
        )
    if state["cancelled"]:
        raise RuntimeError("Test creation cancelled by user.")

    return state["tests"] or []
