"""
Qualty MCP — Review page HTML template.

Design matches the Qualty design system:
  - Font: Geist / system-ui
  - Colors: black (#000), white (#fff), brand yellow (#ffdc39), grey-200 (#e8e8e8)
  - Border radius: 8px
  - Primary button: black bg / white text
"""

REVIEW_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Review Tests \u2014 Qualty</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#f5f5f5;
  --surface:#fff;
  --border:#e8e8e8;
  --text:#000;
  --muted:#6e6e6e;
  --subtle:#9ca3af;
  --brand:#ffdc39;
  --brand-dark:#fdc700;
  --error:#f43336;
  --error-bg:#ffe5e4;
  --success:#2eb760;
  --warn:#ffdc39;
  --warn-border:#f1c40f;
  --warn-bg:#fff8d6;
  --radius:8px
}
body{
  font-family:'Geist',system-ui,-apple-system,sans-serif;
  background:var(--bg);color:var(--text);line-height:1.5;
  font-size:14px;-webkit-font-smoothing:antialiased
}

/* ── Header ── */
.header{
  background:var(--surface);border-bottom:1px solid var(--border);
  padding:0 24px;height:56px;display:flex;align-items:center;gap:12px;
  position:sticky;top:0;z-index:20
}
.logo{
  display:flex;align-items:center;
  text-decoration:none
}
.logo-img{height:28px;width:auto;display:block}
.header-divider{width:1px;height:20px;background:var(--border)}
.header-sub{font-size:13px;color:var(--muted)}
.header-count{
  margin-left:auto;background:var(--text);color:#fff;
  padding:2px 10px;border-radius:99px;font-size:12px;font-weight:600
}

/* ── Main / Layout ── */
.main{max-width:1200px;margin:0 auto;padding:20px 16px 120px}
.layout{display:grid;grid-template-columns:280px minmax(0,1fr);gap:18px;align-items:start}
.sidebar{
  position:sticky;top:74px;max-height:calc(100vh - 170px);overflow:auto;
  background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:12px
}
.content{min-width:0}
.side-tools{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.filter-toggle{display:inline-flex;align-items:center;gap:6px;font-size:11px;color:var(--muted)}
.filter-toggle input{accent-color:#000}
.section-label{
  font-size:11px;font-weight:700;text-transform:uppercase;
  letter-spacing:.08em;color:var(--muted);margin-bottom:14px
}
.nav-empty{font-size:12px;color:var(--muted);padding:6px 2px}
.nav-item{
  border:1px solid var(--border);border-radius:var(--radius);padding:10px;margin-bottom:8px;
  background:#fff;cursor:pointer;transition:border-color .15s,box-shadow .15s
}
.nav-item:hover{border-color:#cfcfcf}
.nav-item.active{border-color:#000;box-shadow:0 0 0 2px rgba(255,220,57,.35)}
.nav-item.warn{border-color:var(--warn-border);background:var(--warn-bg)}
.nav-head{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.nav-num{
  width:18px;height:18px;border-radius:50%;border:1px solid var(--border);
  display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--muted);flex-shrink:0
}
.nav-title{
  font-size:12px;font-weight:600;color:var(--text);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1
}
.nav-preview{
  font-size:11px;color:var(--muted);line-height:1.4;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden
}
.tag-warn{
  display:inline-flex;align-items:center;
  font-size:10px;font-weight:700;letter-spacing:.02em;
  color:#5a4a00;background:var(--warn);border:1px solid var(--warn-border);
  border-radius:999px;padding:2px 7px;white-space:nowrap
}
.warn-note{
  border:1px solid var(--warn-border);background:var(--warn-bg);
  border-radius:var(--radius);padding:8px 10px;
  font-size:12px;color:#5a4a00;margin-bottom:12px
}
.nav-remove{
  border:none;background:none;color:var(--subtle);font-size:11px;cursor:pointer;padding:0 2px
}
.nav-remove:hover{color:var(--error)}

/* ── Card ── */
.card{
  background:var(--surface);border:1px solid var(--border);
  border-radius:var(--radius);padding:20px;margin-bottom:12px
}
.card.warn{border-color:var(--warn-border);background:var(--warn-bg)}
.card-hdr{display:flex;align-items:center;gap:10px;margin-bottom:20px}
.card-num{
  width:24px;height:24px;border-radius:50%;
  border:1px solid var(--border);background:var(--bg);
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:700;color:var(--muted);flex-shrink:0
}
.card-title{
  font-weight:600;font-size:14px;flex:1;min-width:0;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis
}
.btn-rm{
  background:none;border:none;cursor:pointer;color:var(--subtle);
  font-size:12px;padding:4px 8px;border-radius:6px;
  transition:all .15s;white-space:nowrap;font-family:inherit
}
.btn-rm:hover{color:var(--error);background:var(--error-bg)}

/* ── Fields ── */
.field{margin-bottom:14px}
.field:last-child{margin-bottom:0}
label{
  display:block;font-size:11px;font-weight:600;
  text-transform:uppercase;letter-spacing:.06em;
  color:var(--muted);margin-bottom:5px
}
input[type=text],input[type=password],textarea,select{
  width:100%;padding:8px 10px;
  border:1px solid var(--border);border-radius:var(--radius);
  font:inherit;font-size:13px;color:var(--text);background:var(--surface);
  outline:none;transition:border-color .15s,box-shadow .15s
}
input[type=text]:focus,input[type=password]:focus,textarea:focus,select:focus{
  border-color:var(--text);box-shadow:0 0 0 3px rgba(255,220,57,.35)
}
.url-err{border-color:var(--error)!important}
textarea{resize:vertical;min-height:72px;line-height:1.55}

/* ── URL row ── */
.url-row{display:flex;align-items:center;gap:8px}
.url-row input{flex:1}
.url-tag{font-size:12px;font-weight:600;white-space:nowrap}
.url-tag.ok{color:var(--success)}
.url-tag.bad{color:var(--error)}

/* ── 2-col grid ── */
.g2{display:grid;grid-template-columns:1fr 1fr;gap:14px}

/* ── Device checkboxes ── */
.checks{display:flex;flex-wrap:wrap;gap:10px}
.ck{
  display:flex;align-items:center;gap:8px;
  border:1px solid var(--border);border-radius:var(--radius);
  padding:8px 10px;background:var(--surface);min-width:180px
}
.ck input{accent-color:#000}
.ck-main{font-size:13px;font-weight:600}
.ck-sub{font-size:11px;color:var(--muted)}

/* ── Empty state ── */
.empty{
  text-align:center;padding:44px 20px;
  background:var(--surface);border:1px dashed var(--border);
  border-radius:var(--radius);color:var(--muted)
}
.empty strong{display:block;font-size:15px;color:var(--text);margin-bottom:4px}

/* ── Footer ── */
.footer{
  position:fixed;bottom:0;left:0;right:0;
  background:var(--surface);border-top:1px solid var(--border);
  padding:12px 24px;display:flex;justify-content:flex-end;gap:10px;z-index:20
}
.btn{
  padding:9px 18px;border-radius:var(--radius);
  font:inherit;font-size:13px;font-weight:600;
  cursor:pointer;border:none;transition:all .15s
}
.btn:active{transform:scale(.97)}
.btn-ghost{
  background:none;border:1px solid var(--border);color:var(--muted)
}
.btn-ghost:hover{border-color:var(--text);color:var(--text)}
.btn-primary{background:var(--text);color:#fff}
.btn-primary:hover{background:#333}
.btn-primary:disabled{background:#999;cursor:not-allowed;transform:none}

/* ── Done overlay ── */
#done{
  display:none;position:fixed;inset:0;background:var(--surface);z-index:100;
  flex-direction:column;align-items:center;justify-content:center;
  gap:14px;text-align:center;padding:24px
}
#done.show{display:flex}
.done-icon{font-size:48px;line-height:1}
.done-title{font-size:22px;font-weight:700;letter-spacing:-.3px}
.done-sub{font-size:13px;color:var(--muted);max-width:340px}
@media (max-width: 980px){
  .layout{grid-template-columns:1fr}
  .sidebar{position:static;max-height:none}
}
</style>
</head>
<body>
<div id="app">
  <header class="header">
    <a class="logo" href="#">
      <img class="logo-img" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOYAAAAzCAYAAACDmXQnAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAsJSURBVHgB7Z3/deS2Ece/dy//R6kgkwqsVHBwBb4OxFRwSgVLV3ByBaQr0LkCyhVIqYC8Ck6pQOYcl14sFsTMgKS0kvl5b56k5QCDXwMMsSD1Dnlc9FL08lMvtBfmsZdu/3P8/av3WbeX147r5bKXH/Y/uT3Iu97t5aGX3/c/O2zkQML1Dhvf+dTLt16eZginv++l6aXqpcTg6Jc4X9j5dsivO9e1wIYFQrpNW2x8hwfmlKPNdVa/sdn5CefBXIeM1a/AhgbCX9Qx3xl0eTW79/7uevmllxpDmDoyhnUXe/nYy5V3/dHTkyh7+RkvB5e9gq6sVrpefsQWiqUgpJ2v6+VfietFLx8S13/t5Q6vHB6g/kxFynQXOA3pRgjD/Ro7wA0Gxw9nxXu8zOr5GcuskJLssDEFYd6KWQvpC7xyCMcVqiI6HH7e4/Te8RqnYSAlbDmcNqhlIliCCs/jlJtzpiFsjpmkguyYOQOSG3Z0ZF6hnJdfgWOHbvA8PNdKGco1NkIIm2NOQjitUBPRi4WhOfLZy/MSzzt4PyFvcqkwhOIst8hri284713pl4CwOeYkPOhilQo3RMqIDn/mMNxDFhgciz+72efLg7jB0MBhuli+PHgJ60Cw7bxyHS6F/Aqc1k0aaGtsNL1WCJtjnjB+TTBVKRfoO8QdU8stjh3wwiuH7zDcGQWWd9AKeuexrmylMm9rm711CJtj/gk7AoeTU6tHg2EFDCHYG87HBWn9kLaYKEuFZRzUQec0HKLmrmgE3erpT0qvBS6vw9Bn3Cc8Rtq98O886ZYYxo2lboTNMb9DSDukS6QtoFtZUzRB2qsg/zZRtjn3ZxV0K+VchyHowuUykvYGh8EekxvoaYS8tG3p9nlZD19U0E2oBJtjhvWSyvUNclsWSLdVAzufrXm2kYJzISlhRDoZYxkwLpJ+F9GpJ2x9hh2CbhUjLMNHpb2QGvJg19IKeTkhPTtuA5sz5jgoweaYUr0s5fLrKuk76CGj/ZMVr0Z6hdAeVfsGGw3iHXCN406kfRlbzHPOAnJDLb0b3ChsuiBNDUNnClht++TsXEvORRO2SJHWp12oTFWQrzTGS+gpFPZdqlKpcOYjbOGLgx4HudH8shFON1cc9DSwdf4SOMhtFkYaNWyDKUVufy3tlKM0E/YI5+GYtbEcKW4tecXCq1ukw4wC+nDGEs5CkW8ZSXObac/aSUshTWxtoF9juXJKdXaRNITlDvLH5HrCpqWN2oXKUgX5OkUaBx1SGx7ZbgRFShhykAeNNZx1sDkl4bhTtI659P2DhRuFbf9WooZtMKXIqXOlSBf2uVU/hHAejgksE846hW03KmsGp8ZB+VqtMaikga7BCKcdUkCHZiNmra8uCoVt8vRr2AfTFOrB4aFxtCaSdnyovs2wS7A5ZoPld2VHpIm0hUxlyUNSDoVDRpcwXkyks4azLpJHEehwp99HyqflGnJ918IpbDtPv8bLOaamrCXSXCjyCMcIYZ4z1EL6Anoc7O0W0grp/wzn3yN+WCAF6zeYfuC3RvwZyivYVp87nD4rR8Hf7IT+RlDXy3+hRypPhw2GhOsdZMd8hNyef8f5cge5/C5xjccpIc2X8Rd2zDknWSrEZy2e+R6Dzy4Q3+kdT4183At510IH/4Tj8v4vuM76HTaWhvvyLiG/Yhn+gfNGqueHxDWHNHcIxi6vfk8zJeZwdUSviegRTs/CUqJ8pXctPEdbwkYJuW5robm/dZ5+jZcLZecyTr7SPV8TpCOcTyg71kNqO5pI21jKwivmb5iPi3z2EPlsfKOcT4fhFRvjCksYGny3//su0PdXTU7zy8Q1DZ1Ch7AOmmNvj3g9EA5PEY1nZvn+f3wfFA/MtTbSnosxckgxdY7cIZ3vl9gFzda9dbaeml3u9/oszV6szy+Wga1WKMsU1lVrSaQvmp8C/Rr2PphiiTqzzg55Z2WnpAlsEM5rxWSuYasDIO/AVymDnLhFXoNONVDOA8OaMoRPYLjEtRSksFViHaTBfB/o17APiBiEeY7psMztz2t1zPD2KSbh+JMmYRcaeR9Ugt849h/Y3xxGiId8OWEyp/lRKMP4Br4R1n30rml3mjvI4eIH6ODGbz3xJ4pdoOsgTx5fcX5wiMrO4/A2INjh8fIg6BTB36nx2CEy1t9HFGsMjvFv2HbbYsZvYN8lvcLQYB1Od1k7HL4S6YJ0/iRA0CM1slPm9xsOE5Svzw5Y4tg5ryAT3nO89FcJ7JTXyKPDMPiktn4t/Cxc/8n7XVoksvd4CPGnOGJhxYUi/XjagmdeXmUqDAPXX+4LHMKFCjrH8NOX0KM5ZKA9tFBCDllIYe8Jp3Vu8HKhbKFI44+DCkO7cj5TtxznEMqWyEMKZ/3bqQq2fl68MCw5z0PG8ucOuonkTYn0radrmdk19WLRhsep+wkuY6OwFduhk9LdQwcp7DujbW4/bnMpPHd4G47JSBum43hpMb/PRKQOYtkhHz//2I5pG8mfB0OFebOQZlda+xa7C8w/TB2bBGpF+TQ4hX3n6ZNCn6BD2gVvAn3C+TqmE/KuIEcaBRaihG5gcaEIdhyOG21qJeMOKRB/FKmCHYJu1WQdzcpJyP8KYWqw1Yq0DjKVMR/JmSztbT0ITkb9kGbBsseQwtlWsE9YCAfbIKug38GjIH9u1BJyx7BO7f1NyKOEvl47hR1Lfr4UE/lpVvUGaa6UZXBemiKzvDFayP3pQ0b9kEZIb/lqLUaJvD7W9JUJ7f1YrAG4IJUnfC/GMXabSFdCX8kC87bxrSFoi8PEE3Yuh7yfDXmNUiXKVxjyoEjddoZyOIPdEjo09tsgDRn1Q2qFTemFACmcIv8pKbAwc08JWYRtNQb9CvPCA0J+CKoJXaRBRomyXRrz40mvweFYnCWtM9iV7r0J+j5sI2kt+iGWsTr2H7dXCT3auoW2Foew7ismwgpcw55uh3w0x/TWqKdmY+m52t1l2K1wiFr4J/dbY7TbBnbJqB9SGO37ddFSrpy/iRxnyRWLo4whc4l59w6FsYxrOEOM8oXK8lx228AuGfVDcm+9KujRPHGS09fZlLAXKEca6F7OpVlxLHB+LWAu75xBSUKZYm9sWENcxO5zrNZtYJeM+jHKjHJUsNEgv46rUMJe6RyRVugK60DQbSAsJZovnAnzJowSsnO7iN25IX4LebOkjdTVoh8j53vlCjYsEaQ172wc1l9ZSpzO2E3w9w7rUWCZJyo0q47m9BRllMf/DlbaFHETdnOjiAaHaCDVBm2knk8G/SkI9k1EC5ZwdunITqTAcg7K+YzPbfIg4gFVBzqE03vBK6zLJab/JX2qLmMdLqDbKXTQUSjK0uD0nvsjDrcIMZF2WUvo+rpB/I3yU3ariK3GoC9RQPf8qDVfRjMmWm1m77A8DkPH/4DTJy06HF7KxD+/Rj7rEvk2+99rDI+nMSUOqyWn5ydjHrA+PNAvMf1Whm5fjsdIOu5EwjT8VoZr6KFIOS6ge6xtDm4v//Q++//e9hec9xsYwkcHRzrkUUNeGPipqBu8MfwNCBdcq3E8K83ZkX0O2IliszbP1A4brxHNikl4o/BsEwsH/N3KxU7srwxHFeP7cEq8/vfh/FVx0N2/NnjDOEwfIifoHj3a2MhlfJKJhY/y8SLxpJQCGxsbq0DQO2LWps/Ie2xsbKyN9CqSjY2NGRCeYbVkthVzY2M9Ogxf321sbKwIQb9SNnjDX49sbJwThLzTTmb+ho2NDQt3OD411GE44fQ7hhNPd1iAPwCa9vMPRmqa9wAAAABJRU5ErkJggg==" alt="Qualty">
    </a>
    <div class="header-divider"></div>
    <span class="header-sub">Review &amp; confirm MCP generated test before running</span>
    <span class="header-count" id="hdr-count">0 tests</span>
  </header>
  <div class="main">
    <div class="layout">
      <aside class="sidebar">
        <div class="side-tools">
          <div class="section-label" style="margin-bottom:0">Test Navigator</div>
          <label class="filter-toggle">
            <input type="checkbox" id="show-flagged-only">
            <span>Flagged only</span>
          </label>
        </div>
        <div id="nav"></div>
      </aside>
      <section class="content">
        <div class="section-label" id="section-label">Staged tests</div>
        <div id="cards"></div>
      </section>
    </div>
  </div>
  <footer class="footer">
    <button class="btn btn-ghost" id="cancel-btn" onclick="doCancel()">Cancel</button>
    <button class="btn btn-primary" id="confirm-btn" onclick="doConfirm()">Confirm &amp; Create</button>
  </footer>
</div>
<div id="done">
  <div class="done-icon" id="done-icon">\u2705</div>
  <div class="done-title" id="done-title">Tests created!</div>
  <div class="done-sub" id="done-sub">You can close this tab. The agent will continue.</div>
</div>
<script>
var TESTS=__TESTS_JSON__;
var PROFILES=__PROFILES_JSON__;
var ROOT_URL=__ROOT_URL_JSON__;
var PROJECT_NAME="__PROJECT_NAME__";

var DEVICES=["desktop","mobile"];
var DEV_LBL={desktop:"Desktop",mobile:"Mobile"};
var DEV_DIM={desktop:"1920×1080",mobile:"390×844"};
var showOnlyFlagged=false;

var state=TESTS.map(function(t,i){
  var flagged=Boolean(
    t.needs_manual_review ||
    t.manual_review_required ||
    t.requires_user_edit ||
    t.requires_manual_update ||
    t.review_flag
  );
  var note=t.manual_review_note || t.review_note || t.flag_reason || "";
  return{
    _id:i,name:t.name||"",url:t.url||ROOT_URL||"",
    description:(t.description!=null&&t.description!==undefined)?String(t.description):"",
    steps:(t.steps!=null&&t.steps!==undefined)?String(t.steps):"",
    expected_behavior:t.expected_behavior||"",
    devices:t.devices||["desktop"],
    saved_login_profile_id:t.saved_login_profile_id||null,
    username:t.username||"",
    password:t.password||"",
    network_backend_host:t.network_backend_host||"",
    stagehand_steps:t.stagehand_steps||"",
    needs_manual_review:flagged,
    manual_review_note:note
  };
});

function esc(s){
  return String(s==null?"":s)
    .replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function validUrl(u){try{new URL(u);return true;}catch(e){return false;}}

function renderAll(){
  var n=state.length;
  document.getElementById("hdr-count").textContent=n+" "+(n===1?"test":"tests");
  document.getElementById("section-label").textContent="Staged test for "+PROJECT_NAME;
  var btn=document.getElementById("confirm-btn");
  btn.textContent="Confirm & Create "+n+" "+(n===1?"test":"tests");
  btn.disabled=(n===0);
  var nav=document.getElementById("nav");
  var container=document.getElementById("cards");
  if(n===0){
    nav.innerHTML='<div class="nav-empty">No tests in this session.</div>';
    container.innerHTML='<div class="empty"><strong>No tests remaining</strong>All tests removed. Click Cancel to exit.</div>';
    return;
  }
  var navState=showOnlyFlagged?state.filter(function(t){return t.needs_manual_review;}):state;
  nav.innerHTML=navState.map(function(t,i){return navHtml(t,i);}).join("");
  container.innerHTML=state.map(function(t,i){return cardHtml(t,i);}).join("");
  navState.forEach(function(t){
    var row=document.getElementById("nav-item-"+t._id);
    if(row){
      row.addEventListener("click",function(){focusCard(t._id);});
    }
    var rmBtn=document.getElementById("nav-rm-"+t._id);
    if(rmBtn){
      rmBtn.addEventListener("click",function(e){
        e.stopPropagation();
        rm(t._id);
      });
    }
  });
  state.forEach(function(t,i){
    ["name","url","description","steps","expected_behavior","username","password","network_backend_host","stagehand_steps"].forEach(function(f){
      var el=document.getElementById(f+"-"+t._id);
      if(!el) return;
      el.addEventListener("input",function(e){
        state[i][f]=e.target.value;
        if(f==="name"){
          var ti=document.getElementById("ctitle-"+t._id);
          if(ti) ti.textContent=e.target.value||"Untitled";
        }
        if(f==="url") refreshUrl(t._id,i);
      });
    });
    var sel=document.getElementById("profile-"+t._id);
    if(sel) sel.addEventListener("change",function(e){
      state[i].saved_login_profile_id=e.target.value?parseInt(e.target.value,10):null;
    });
    DEVICES.forEach(function(d){
      var cb=document.getElementById("device-"+d+"-"+t._id);
      if(!cb) return;
      cb.addEventListener("change",function(e){
        var arr=(state[i].devices||[]).slice();
        if(e.target.checked){
          if(arr.indexOf(d)<0) arr.push(d);
        }else{
          arr=arr.filter(function(x){return x!==d;});
        }
        if(arr.length===0) arr=["desktop"];
        state[i].devices=arr;
      });
    });
    refreshUrl(t._id,i);
  });
  var flagFilter=document.getElementById("show-flagged-only");
  if(flagFilter){
    flagFilter.checked=showOnlyFlagged;
    flagFilter.onchange=function(e){
      showOnlyFlagged=!!e.target.checked;
      renderAll();
    };
  }
}

function previewText(s){
  var txt=(s||"").replace(/\\s+/g," ").trim();
  if(!txt) return "No description yet";
  return txt;
}

function navHtml(t,idx){
  return "<div class=\\"nav-item"+(t.needs_manual_review?" warn":"")+"\\" id=\\"nav-item-"+t._id+"\\">"
    +"<div class=\\"nav-head\\">"
    +"<div class=\\"nav-num\\">"+(idx+1)+"</div>"
    +"<div class=\\"nav-title\\">"+esc(t.name||"Untitled")+"</div>"
    +(t.needs_manual_review?'<span class=\\"tag-warn\\">Needs review</span>':"")
    +"<button class=\\"nav-remove\\" id=\\"nav-rm-"+t._id+"\\">Remove</button>"
    +"</div>"
    +"<div class=\\"nav-preview\\">"+esc(previewText(t.steps||t.description))+"</div>"
    +"</div>";
}

function focusCard(id){
  var card=document.getElementById("card-"+id);
  if(!card) return;
  card.scrollIntoView({behavior:"smooth",block:"start"});
  document.querySelectorAll(".nav-item").forEach(function(el){el.classList.remove("active");});
  var active=document.getElementById("nav-item-"+id);
  if(active) active.classList.add("active");
}

function refreshUrl(id,idx){
  var u=state[idx].url;
  var ok=validUrl(u);
  var inp=document.getElementById("url-"+id);
  var tag=document.getElementById("utag-"+id);
  if(inp){inp.className=ok?"":"url-err";}
  if(tag){tag.textContent=ok?"\u2713 valid":"\u26a0 invalid";tag.className="url-tag "+(ok?"ok":"bad");}
}

function cardHtml(t,idx){
  var profOpts=PROFILES.map(function(p){
    return "<option value=\\""+p.id+"\\""+( t.saved_login_profile_id==p.id?" selected":"")+">"
      +esc(p.name)+(p.completed_at?"":" (incomplete)")+"</option>";
  }).join("");
  var devChecks=DEVICES.map(function(d){
    var checked=((t.devices||[]).indexOf(d)>=0)?" checked":"";
    return "<label class=\\"ck\\">"
      +"<input type=\\"checkbox\\" id=\\"device-"+d+"-"+t._id+"\\""+checked+">"
      +"<span><div class=\\"ck-main\\">"+DEV_LBL[d]+"</div><div class=\\"ck-sub\\">"+DEV_DIM[d]+"</div></span>"
      +"</label>";
  }).join("");
  var isOk=validUrl(t.url);
  return "<div class=\\"card"+(t.needs_manual_review?" warn":"")+"\\" id=\\"card-"+t._id+"\\">"
    +"<div class=\\"card-hdr\\">"
    +"<div class=\\"card-num\\">"+(idx+1)+"</div>"
    +"<div class=\\"card-title\\" id=\\"ctitle-"+t._id+"\\">"+(esc(t.name)||"Untitled")+"</div>"
    +(t.needs_manual_review?'<span class=\\"tag-warn\\">Needs review</span>':"")
    +"<button class=\\"btn-rm\\" onclick=\\"rm("+t._id+")\\">\u2715 Remove</button>"
    +"</div>"
    +(t.needs_manual_review
      ?"<div class=\\"warn-note\\">Please review and update this test before running."
        +(t.manual_review_note?(" "+esc(t.manual_review_note)):"")
       +"</div>"
      :"")
    +"<div class=\\"field\\"><label>Test name</label>"
    +"<input type=\\"text\\" id=\\"name-"+t._id+"\\" value=\\""+esc(t.name)+"\\" placeholder=\\"e.g. Login with valid credentials\\"></div>"
    +"<div class=\\"field\\"><label>URL</label><div class=\\"url-row\\">"
    +"<input type=\\"text\\" id=\\"url-"+t._id+"\\" value=\\""+esc(t.url)+"\\" placeholder=\\"https://\u2026\\"" +(isOk?"":" class=\\"url-err\\"")+"> "
    +"<span class=\\"url-tag "+(isOk?"ok":"bad")+"\\" id=\\"utag-"+t._id+"\\">"+(isOk?"\u2713 valid":"\u26a0 invalid")+"</span>"
    +"</div></div>"
    +"<div class=\\"field\\"><label>Description</label>"
    +"<textarea id=\\"description-"+t._id+"\\" placeholder=\\"What this test covers and why it exists\u2026\\">"+esc(t.description)+"</textarea></div>"
    +"<div class=\\"field\\"><label>Steps</label>"
    +"<textarea id=\\"steps-"+t._id+"\\" placeholder=\\"Step-by-step instructions for the agent\u2026\\">"+esc(t.steps)+"</textarea></div>"
    +"<div class=\\"field\\"><label>Expected behavior</label>"
    +"<textarea id=\\"expected_behavior-"+t._id+"\\" placeholder=\\"What should be true when the test passes\u2026\\">"+esc(t.expected_behavior)+"</textarea></div>"
    +"<div class=\\"field\\"><label>Devices</label><div class=\\"checks\\">"+devChecks+"</div></div>"
    +"<div class=\\"field\\"><label>Saved login profile</label>"
    +"<select id=\\"profile-"+t._id+"\\"><option value=\\"\\">None</option>"+profOpts+"</select>"
    +"<div class=\\"ck-sub\\" style=\\"margin-top:4px\\">Run this test with a saved signed-in state from Project settings.</div></div>"
    +"<div class=\\"g2\\">"
    +"<div class=\\"field\\"><label>Username (optional)</label>"
    +"<input type=\\"text\\" id=\\"username-"+t._id+"\\" value=\\""+esc(t.username)+"\\" placeholder=\\"test@example.com\\"></div>"
    +"<div class=\\"field\\"><label>Password (optional)</label>"
    +"<input type=\\"password\\" id=\\"password-"+t._id+"\\" value=\\""+esc(t.password)+"\\" placeholder=\\"password\\"></div>"
    +"</div>"
    +"<div class=\\"field\\"><label>Network backend host (optional)</label>"
    +"<input type=\\"text\\" id=\\"network_backend_host-"+t._id+"\\" value=\\""+esc(t.network_backend_host)+"\\" placeholder=\\"api.example.com\\"></div>"
    +"</div>";
}

function rm(id){
  state=state.filter(function(t){return t._id!==id;});
  renderAll();
}

function showDone(icon,title,sub){
  document.getElementById("done-icon").textContent=icon;
  document.getElementById("done-title").textContent=title;
  document.getElementById("done-sub").textContent=sub;
  document.getElementById("done").className="show";
}

function doCancel(){
  document.getElementById("cancel-btn").disabled=true;
  fetch("/cancel",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"})
    .finally(function(){showDone("\u26d4","Cancelled","No tests were created. You can close this tab.");});
}

function doConfirm(){
  var errs=[];
  state.forEach(function(t,i){
    if(!(t.name||"").trim()) errs.push("Test "+(i+1)+": name is required");
    if(!validUrl(t.url))     errs.push("Test "+(i+1)+": URL is invalid");
    if(!(t.description||"").trim()) errs.push("Test "+(i+1)+": description is required");
    if(!(t.steps||"").trim()) errs.push("Test "+(i+1)+": steps are required");
    if(!(t.expected_behavior||"").trim()) errs.push("Test "+(i+1)+": expected behavior is required");
  });
  if(errs.length){alert("Please fix the following:\\n\\n"+errs.join("\\n"));return;}
  var btn=document.getElementById("confirm-btn");
  btn.disabled=true;
  btn.textContent="Creating\u2026";
  var payload=state.map(function(t){return{
    name:(t.name||"").trim(),url:t.url,
    description:(t.description||"").trim(),
    steps:(t.steps||"").trim(),
    expected_behavior:(t.expected_behavior||"").trim(),
    devices:t.devices||["desktop"],browsers:["chrome"],
    saved_login_profile_id:t.saved_login_profile_id||null,
    username:t.username||"",
    password:t.password||"",
    network_backend_host:t.network_backend_host||"",
    stagehand_steps:t.stagehand_steps||""
  };});
  fetch("/confirm",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tests:payload})})
    .then(function(r){return r.json();})
    .then(function(d){
      if(d.ok) showDone("\u2705","Tests submitted!","You can close this tab. The agent will continue.");
      else{btn.disabled=false;btn.textContent="Confirm & Create "+state.length+" test(s)";alert("Error: "+(d.error||"Unknown error"));}
    })
    .catch(function(){
      btn.disabled=false;btn.textContent="Confirm & Create "+state.length+" test(s)";
      alert("Network error. Please try again.");
    });
}

renderAll();
</script>
</body>
</html>
"""
