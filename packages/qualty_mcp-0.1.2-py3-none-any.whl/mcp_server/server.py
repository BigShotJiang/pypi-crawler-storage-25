#!/usr/bin/env python3
"""
Qualty MCP Server
=================

Exposes Qualty's end-to-end testing platform to coding agents via the
Model Context Protocol.

Tools:
  setup             — Verify and configure Qualty for this workspace
  get_context       — Show current configuration
  create_test       — Create one or more tests (with browser review UI)
  create_test_suite — Create a named group of tests
  run_tests         — Trigger test execution
  list_test_executions — List recent executions for the current project
  get_test_execution   — Full step + network detail for a specific execution
  list_saved_jobs   — List saved tests
  list_test_suites  — List test suites

Configuration (precedence: env var > ~/.qualty/credentials > .qualty.json):
  QUALTY_API_TOKEN          CI API token (starts with qlty_ci_...)
  QUALTY_BASE_URL           Base URL of the Qualty API
  QUALTY_DEFAULT_PROJECT_ID Fallback default project ID
"""

import asyncio
import json

import httpx
from mcp import types
from mcp.server import Server
from mcp.server.stdio import stdio_server

from .tools import TOOL_DEFINITIONS, HANDLERS

# ---------------------------------------------------------------------------
# MCP server
# ---------------------------------------------------------------------------

INSTRUCTIONS = """
## Qualty MCP 
These tools let you create tests, organise them into suites and sequences, trigger runs, and inspect results.

## Step 0 — Always call check_setup() first
Call check_setup() before anything else. It returns ready=true if configured, or
tells you exactly what's missing. If something is missing, call setup() to fix it.
Do not call any other tool until check_setup() returns ready=true.

## Creating tests
The purpose of these tests is to provide automated coverage across the
application. The user will explicitly pick one planning mode:
- quick_check (critical screens/actions),
- user_journeys (full end-to-end flows),
- full_coverage (broad coverage including edge cases/integrations).

### Required workflow: plan_tests → create_test
Always call plan_tests BEFORE create_test. User intent must be explicitly
confirmed by the user for the test plan; do not guess.

1. Call `plan_tests` (you can pass `intent` if the user already said something).
   - If it returns `status="needs_user_input"`, ask the user the listed
     questions and collect their answers. Do NOT call create_test yet.
   - Do NOT infer `test_plan` from the user's prompt,
     codebase signals, or previous sessions. These must be user-defined explicitly.
   - Then call `plan_tests` again with `test_plan` and any
     `must_cover_paths` / `release_context` the user gave.
2. When `plan_tests` returns `status="ready"`, read the codebase guided by
   the returned plan:
   - quick_check → critical screens and actions (~6-10 tests)
   - user_journeys → full end-to-end flows (~3-5 journeys)
   - full_coverage → everything above plus edge cases and integrations (~20+ tests)
3. Call `create_test` with tests aligned to the selected plan.

Try to be as detailed and specific as possible by looking into the codebase and identify:
- Core user-facing workflows to test.
- Areas prone to edge cases or silent failures that might not be covered by unit tests:
  integration, early termination of feature, load, etc.

### Login/manual setup flagging (IMPORTANT)
If a generated test includes a login wall, external auth, OTP, CAPTCHA, or any step that likely
requires user-provided credentials/profile setup in Qualty before execution, you MUST flag it.

When calling create_test, include:
- `needs_manual_review: true`
- `manual_review_note: "<clear reason and what user must update in Qualty>"`

Example reasons:
- "Requires real student .edu credentials in Username/Password before run."
- "Requires selecting a saved login profile from Project Settings."
- "Requires OAuth account setup before this flow can pass."

Do this proactively for any test that may fail without user edits in the review page.

## Test Sequence
A sequence is a list of test stages that must run one after another to simulate a real end-to-end workflow.
A stage is a group of individual tests that can run in parallel.
A sequence is the right tool when:
    • Order matters. (e.g. can't run a test without first creating it).
    • You want to model a complete user journey from start to finish.
    • You want to test different users interacting with the application at the same time.
    • You need automatic cleanup after a test so artefacts don't accumulate (e.g. create → run → delete)

# Test Suites
A test suite is a group of tests and/or sequences that can be linked to GitHub CI/CD for automatic PR checks.
Use this to group tests for a specific feature or process (e.g. "Smoke Tests", "Dashboard Test").
      
## Running tests and fetching results
Trigger a run with run_tests (individual tests, a suite, or a sequence). A single tests take around
2–3 minutes, sequences will take longer. Use get_test_execution with the returned execution_id to fetch full
results: step trace, screenshots, AI explanation, and network log. You can wait or fetch results later.

## Investigating test execution failures
    1. list_test_executions(status='failed', since='48h') → find broken runs
    2. get_test_execution(execution_id='<id>') → read full logs + network detail

## Quick reference
- **Plan tests** — plan_tests → (ask user) → plan_tests → create_test
- **Create tests** — read the codebase first, then create_test
- **Run tests** — list_saved_jobs → run_tests(job_ids)
- **Run a suite** — list_test_suites → run_tests(suite_id)
- **Run a sequence** — list_sequences → run_tests(sequence_id)
- **Create a suite** — list_saved_jobs → create_test_suite
- **Create a sequence** — list_saved_jobs → create_sequence
- **Update a test/suite** — list_saved_jobs / list_test_suites → update_test / update_test_suite
- **Investigate failures** — list_test_executions(status="failed") → get_test_execution

Always call check_setup() before any of the above. Use setup() only to save a token or project.
"""

server = Server("qualty", instructions=INSTRUCTIONS)


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return TOOL_DEFINITIONS


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    import asyncio
    handler = HANDLERS.get(name)
    try:
        if handler is None:
            result = {"error": f"Unknown tool: {name}"}
        elif name == "check_setup":
            result = await asyncio.to_thread(handler)
        else:
            result = await asyncio.to_thread(handler, arguments)
    except httpx.HTTPStatusError as exc:
        try:
            body = exc.response.json()
        except Exception:
            body = exc.response.text
        result = {
            "error": f"Qualty API returned HTTP {exc.response.status_code}",
            "detail": body,
        }
    except RuntimeError as exc:
        result = {"error": str(exc)}
    except Exception as exc:
        result = {"error": f"Unexpected error: {exc}"}

    return [types.TextContent(type="text", text=json.dumps(result, indent=2))]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    asyncio.run(main())
