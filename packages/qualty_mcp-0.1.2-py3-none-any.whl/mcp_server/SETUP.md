# Qualty MCP Server — Setup Guide

Connects your coding agent (Claude Code, Cursor, Windsurf, etc.) to the Qualty
E2E testing platform via the Model Context Protocol.

---

## Prerequisites

- Python 3.11+
- A Qualty account with at least one project

---

## 1. Install package

Recommended for clients:

```bash
pipx install qualty-mcp
```

For local development in this repo:

```bash
pipx install -e .
```

---

## 2. Initialize credentials and default project

```bash
qualty-mcp init
```

---

## 3. Add to your MCP client

### Claude Code (recommended)

Generate or install config automatically:

```bash
qualty-mcp print-claude-code-config
qualty-mcp install-claude-code
```

Equivalent `.mcp.json`:

```json
{
  "mcpServers": {
    "qualty": {
      "command": "qualty-mcp",
      "args": ["serve"],
      "env": {
        "QUALTY_BASE_URL": "https://api.qualty.dev"
      }
    }
  }
}
```

No absolute path is required once the package is installed.

### Cursor

Generate or install config automatically:

```bash
qualty-mcp print-cursor-config
qualty-mcp install-cursor
```

Equivalent `.mcp.json`:

```json
{
  "mcpServers": {
    "qualty": {
      "command": "qualty-mcp",
      "args": ["serve"],
      "env": {
        "QUALTY_BASE_URL": "https://api.qualty.dev"
      }
    }
  }
}
```

---

## 4. First-time configuration

On first use, the agent will call `check_setup()` automatically. If the token or
default project is missing, it will prompt you.

**Token missing** — run `qualty-mcp init` and provide your `qlty_ci_...` token.
It is saved to `~/.qualty/credentials` (permissions `600`).

**Project not set** — the agent lists your projects by name and asks you to pick
one. It then calls `setup(project_id="...")` and saves the selection to
`.qualty.json` in your project root.

Once both are saved, you won't be prompted again.

To switch projects later:

```bash
qualty-mcp list-projects
```

or:

```bash
qualty-mcp switch-project --project-id 123
qualty-mcp switch-project --project-name "My Project"
```

---

## Configuration reference

Settings are resolved in this order: **env var → `~/.qualty/credentials` → `.qualty.json`**

### Environment variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `QUALTY_API_TOKEN` | Yes | — | CI token from the Qualty dashboard |
| `QUALTY_BASE_URL` | No | `https://api.qualty.dev` | API base URL |
| `QUALTY_DEFAULT_PROJECT_ID` | No | — | Fallback project ID |

You can manage the base URL in `mcp_server/.env` instead of editing MCP config each time:

```bash
cp mcp_server/.env.example mcp_server/.env
```

Set:

```dotenv
QUALTY_BASE_URL=http://localhost:8000
```

Base URL resolution order:
`QUALTY_BASE_URL` env var > `mcp_server/.env` > `.qualty.json` `base_url` > default.

### `.qualty.json` (project-level config)

Created automatically by `setup()` in your project root. You can also edit it manually:

```json
{
  "default_project_id": "123",
  "default_root_url": "https://your-app.com",
  "default_devices": ["desktop"],
  "default_browsers": ["chrome"]
}
```

| Key | Description |
|---|---|
| `default_project_id` | Project tests are created under by default |
| `default_root_url` | Base URL used as the starting point for test URLs |
| `default_devices` | Default devices: `desktop`, `mobile` |
| `default_browsers` | Default browsers: `chrome`, `firefox`, `safari` |

### `~/.qualty/credentials`

Stores your API token globally (permissions: `600`). Set automatically when you
provide a token via `setup()`. You can also create it manually:

```json
{
  "api_token": "qlty_ci_your_token_here"
}
```

---

## Verifying your setup

Run:

```bash
qualty-mcp doctor
qualty-mcp status
```

or ask your agent: *"Check my Qualty setup"*.

`status` redacts the base URL by default. To print full value explicitly:

```bash
qualty-mcp status --show-base-url
```

---

## Release checklist

Before publishing a new version:

```bash
qualty-mcp release-checklist
```
