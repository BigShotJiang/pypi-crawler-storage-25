"""
Qualty MCP — HTTP helpers and project resolution.
"""

from typing import Any

import httpx

from .config import get_api_token, get_base_url


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

def _headers() -> dict[str, str]:
    token = get_api_token()
    if not token:
        raise RuntimeError("No API token configured. Run setup() to get started.")
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


def api(method: str, path: str, **kwargs) -> Any:
    """Make a synchronous HTTP request to the Qualty REST API."""
    url = f"{get_base_url()}/api/v1/{path.lstrip('/')}"
    with httpx.Client(timeout=30) as client:
        resp = client.request(method, url, headers=_headers(), **kwargs)
        resp.raise_for_status()
        return resp.json()


# ---------------------------------------------------------------------------
# Project resolution
# ---------------------------------------------------------------------------

def list_projects_raw() -> list[dict]:
    data = api("GET", "projects")
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("projects") or data.get("results") or []
    return []


def resolve_project_id(project_id: str | None, project_name: str | None) -> str:
    """
    Return a validated project_id or raise RuntimeError with a helpful message.

    Resolution order:
      1. Explicit project_id arg
      2. project_name arg → lookup
      3. Default from .qualty.json / env
      4. Fail with list of available projects
    """
    if project_id:
        return project_id

    if project_name:
        projects = list_projects_raw()
        matches = [p for p in projects if p.get("name", "").lower() == project_name.lower()]
        if len(matches) == 1:
            return str(matches[0]["id"])
        if len(matches) > 1:
            ids = [p["id"] for p in matches]
            raise RuntimeError(
                f"Multiple projects named '{project_name}': {ids}. "
                "Use project_id to disambiguate."
            )
        available = [p.get("name") for p in projects]
        raise RuntimeError(
            f"No project named '{project_name}'. Available: {available}. "
            "Run setup() to see all projects and set a default."
        )

    from .config import get_default_project_id
    default = get_default_project_id()
    if default:
        return default

    raise RuntimeError(
        "No default project configured. Run setup() to pick a project for this workspace."
    )
