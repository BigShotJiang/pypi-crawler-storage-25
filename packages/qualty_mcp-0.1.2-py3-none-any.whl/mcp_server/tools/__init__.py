"""
Qualty MCP — Tool definitions and dispatch.
this is whats prompted into the coding agent
"""

from mcp import types

from .setup import handle_setup
from .context import handle_check_setup
from .jobs import handle_list_saved_jobs, handle_create_test, handle_update_test, handle_plan_tests
from .suites import handle_list_test_suites, handle_create_test_suite, handle_update_test_suite
from .sequences import handle_list_sequences, handle_create_sequence
from .run_tests import handle_run_tests
from .run_local import handle_run_local
from .reports import handle_list_test_executions, handle_get_test_execution


# ---------------------------------------------------------------------------
# Tool definitions (schema exposed to the MCP client / coding agent)
# ---------------------------------------------------------------------------

TOOL_DEFINITIONS: list[types.Tool] = [

    # ── check_setup ───────────────────────────────────────────────────────
    types.Tool(
        name="check_setup",
        description=(
            "Check whether Qualty is configured and ready. "
            "Returns ready=true is configured or returns what is missing "
        ),
        inputSchema={"type": "object", "properties": {}, "required": []},
    ),

    # ── setup ─────────────────────────────────────────────────────────────
    types.Tool(
        name="setup",
        description=(
            "Save an API token or set a default project. "
            "Pass token to save an API token (qlty_ci_... format). "
            "Pass project_id to set the default project after the user has chosen from the list."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "token": {
                    "type": "string",
                    "description": "API token to save (qlty_ci_... format).",
                },
                "project_id": {
                    "type": "string",
                    "description": "Project ID to set as default.",
                },
            },
            "required": [],
        },
    ),
    # ── list_saved_jobs ───────────────────────────────────────────────────
    types.Tool(
        name="list_saved_jobs",
        description=(
            "List saved individual tests (jobs) in Qualty. "
            "Filter by project, suite, name, or specific IDs. "
            "Use this to find existing test IDs before running or grouping them into suites."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "Filter tests belonging to this project."},
                "project_name": {"type": "string", "description": "Filter by project name (alternative to project_id)."},
                "suite_id": {"type": "string", "description": "Filter tests belonging to this test suite."},
                "name": {"type": "string", "description": "Filter by exact test name."},
                "ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Fetch specific tests by their IDs.",
                },
            },
            "required": [],
        },
    ),

     # ── list_sequences ────────────────────────────────────────────────────
    types.Tool(
        name="list_sequences",
        description=(
            "List saved test sequences in Qualty. (ordered tests that must run one after another) "
            "Return the sequence IDs, names, and the tests inside each sequence."
            "Use this to find existing sequence IDs before running or updating a sequence."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_id": {
                    "type": "string",
                    "description": "Filter sequences belonging to this project.",
                },
            },
            "required": [],
        },
    ),

    # ── list_test_suites ──────────────────────────────────────────────────
    types.Tool(
        name="list_test_suites",
        description=(
            "List test suites in Qualty, scoped to the current project. "
            "Returns suite IDs, names, and the tests inside each suite. "
            "Use this to find a suite_id before running tests or adding tests to an existing suite."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "project_id": {
                    "type": "string",
                    "description": "Project to list suites for. Defaults to the configured default project.",
                },
            },
            "required": [],
        },
    ),

    # ── plan_tests ────────────────────────────────────────────────────────
    types.Tool(
        name="plan_tests",
        description=(
            "Conversational planning step before create_test. Captures the user's "
            "testing goal using user-friendly plans so the agent generates the right set of tests.\n\n"
            "Call this FIRST before create_test. If test_plan is "
            "missing, this tool returns status='needs_user_input' with the questions "
            "to ask the user. Once provided, returns status='ready' with "
            "generation_rules for the selected plan. "
            "Do not infer test plan; it must be explicitly user-defined."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "intent": {
                    "type": "string",
                    "description": "Free-text user goal that seeded this planning call (optional).",
                },
                "test_plan": {
                    "type": "string",
                    "enum": ["quick_check", "user_journeys", "full_coverage"],
                    "description": (
                        "quick_check = critical screens and actions (~6-10 tests). "
                        "user_journeys = full end-to-end flows (~3-5 journeys). "
                        "full_coverage = everything above plus edge cases and integrations (~20+ tests)."
                    ),
                },
                "must_cover_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Specific flows or pages the user explicitly named (optional).",
                },
                "release_context": {
                    "type": "string",
                    "description": (
                        "Context for this run, e.g. 'pre-deploy gate', 'weekly run', "
                        "'post-feature ship', 'general coverage' (optional)."
                    ),
                },
            },
            "required": [],
        },
    ),

    # ── create_test ───────────────────────────────────────────────────────
    types.Tool(
        name="create_test",
         description=(
                "Creates a new E2E test in the Qualty testing platform. "
                "Tests will be saved and can later be run on demand, added to a "
                "test suite for CI integration, or run through the Qualty MCP server.\n\n"
                "Call plan_tests first to capture the explicit user-selected plan "
                "(quick_check, user_journeys, or full_coverage)."
            ),
        inputSchema={  
            "type": "object",
            "properties": {
                "tests": {
                    "type": "array",
                    "description": "One or more test definitions to create.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": (
                                    "Short, descriptive test name. "
                                    "Examples: 'Login with username and password', 'Test Add to Cart Feature'."
                                ),
                            },
                            "url": {
                                "type": "string",
                                "description": (
                                    "Starting URL where the test should begin. "
                                    "Use the project's default_root_url from .qualty.json as the base "
                                    "(e.g. if default_root_url is 'https://app.example.com', use "
                                    "'https://app.example.com/login' or a specific page path). "
                                    "Always prefer the publicly hosted URL, never localhost."
                                ),
                            },
                            "steps": {
                                "type": "string",
                                "description": (
                                    "Step-by-step natural language instructions the test agent should follow. "
                                    "Example: '1. Fill in card number 4242 4242 4242 4242. "
                                    "2. Enter expiry 12/26 and CVC 123. "
                                    "3. Click the Pay button. "
                                    "4. Wait for the confirmation page'."

                                "Make sure to be as detailed as possible by looking into the codebase and providing "
                                "the complete action sequences to reach the expected behavior and specific elements to interact."
                                ),
                            },
                            "expected_behavior": {
                                "type": "string",
                                "description": (
                                    "Success criteria — what should be true when the test passes. "
                                    "Example: 'Order confirmation page is shown with a valid order number and "
                                    "a success message containing the user email'."
                                ),
                            },
                            "description": {
                                "type": "string",
                                "description": "Longer description of what this test covers and why it exists.",
                            },
                            "devices": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Devices to run on. Options: 'desktop', 'mobile'. Default: ['desktop'].",
                            },
                            "browsers": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Browsers to run on. Options: 'chrome', 'firefox', 'safari'. Default: ['chrome'].",
                            },
                        },
                        "required": ["name", "description", "steps", "expected_behavior"],
                    },
                },
            },
            "required": ["tests"],
        },
    ),

    # ── update_test ───────────────────────────────────────────────────────
    types.Tool(
        name="update_test",
        description=(
            "Update an existing saved test (job) in Qualty. "
            "Only the fields you provide will be changed — omitted fields are left as-is.\n\n"
            "Use list_saved_jobs to find the test_id before calling this."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "test_id": {
                    "type": "string",
                    "description": "ID of the test to update.",
                },
                "name": {
                    "type": "string",
                    "description": "New test name.",
                },
                "url": {
                    "type": "string",
                    "description": "New starting URL for the test.",
                },
                "steps": {
                    "type": "string",
                    "description": "New step-by-step natural language instructions.",
                },
                "expected_behavior": {
                    "type": "string",
                    "description": "New success criteria.",
                },
                "description": {
                    "type": "string",
                    "description": "New longer description of what this test covers.",
                },
                "devices": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Devices to run on. Options: 'desktop', 'mobile'.",
                },
                "browsers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Browsers to run on. Options: 'chrome', 'firefox', 'safari'.",
                },
            },
            "required": ["test_id"],
        },
    ),

    # ── create_sequence ───────────────────────────────────────────────────
    types.Tool(
        name="create_sequence",
        description=(
            "Create a test sequence in Qualty: an ordered pipeline of saved tests that execute "
            "one after another to simulate a real end-to-end workflow."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Sequence name. Example: 'Create → Run → Delete Test Workflow'.",
                },
                "description": {
                    "type": "string",
                    "description": "Description of what workflow this sequence simulates.",
                },
                "project_id": {
                    "type": "string",
                    "description": "Project this sequence belongs to. Uses the default project if omitted.",
                },
                "stop_on_failure": {
                    "type": "boolean",
                    "description": (
                        "If true (default), halt the sequence when any step fails. "
                        "Recommended: true — later steps often depend on earlier ones succeeding."
                    ),
                },
                "items": {
                    "type": "array",
                    "description": (
                        "Ordered list of tests to include in the sequence. "
                        "Each item specifies a job_id and a stage number. "
                        "Tests sharing the same stage run in parallel; stages execute sequentially. "
                        "Example: [{job_id: 'abc', stage: 1}, {job_id: 'def', stage: 2}] "
                        "runs 'abc' first, then 'def' after it completes."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "job_id": {
                                "type": "string",
                                "description": "ID of the saved test to run at this stage.",
                            },
                            "stage": {
                                "type": "integer",
                                "description": (
                                    "Stage number (1-based). Tests in the same stage run in parallel. "
                                    "Stages execute in ascending order: stage 1 first, then stage 2, etc."
                                ),
                            },
                        },
                        "required": ["job_id", "stage"],
                    },
                },
            },
            "required": ["name", "description", "items"],
        },
    ),

    # ── create_test_suite ─────────────────────────────────────────────────
    types.Tool(
        name="create_test_suite",
        description=(
            "Create a named test suite in Qualty — a group of tests and/or sequences that can be run together. "
            "Use this to organise related tests or sequences (e.g. 'Smoke Tests', 'Checkout Regression'). "
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Test Suite name. Examples: 'Checkout Smoke Tests', 'Auth Regression Suite'.",
                },
                "project_id": {
                    "type": "string",
                    "description": "Project this suite belongs to. Defaults to the configured default project.",
                },
                "job_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of individual test IDs (from create_test or list_saved_jobs) to include in the suite.",
                },
                "sequence_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of sequence IDs (from create_sequence or list_sequences) to include in the suite.",
                },
            },
            "required": ["name"],
        },
    ),

    # ── update_test_suite ─────────────────────────────────────────────────
    types.Tool(
        name="update_test_suite",
        description=(
            "Update an existing test suite in Qualty. "
            "Only the fields you provide will be changed — omitted fields are left as-is.\n"
            "Use list_test_suites to find the suite_id before calling this. "
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "suite_id": {
                    "type": "string",
                    "description": "ID of the test suite to update.",
                },
                "name": {
                    "type": "string",
                    "description": "New suite name.",
                },
                "description": {
                    "type": "string",
                    "description": "New suite description.",
                },
                "job_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Replacement list of individual test IDs. Replaces all current tests in the suite.",
                },
                "sequence_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Replacement list of sequence IDs. Replaces all current sequences in the suite.",
                },
            },
            "required": ["suite_id"],
        },
    ),

    # ── run_tests ─────────────────────────────────────────────────────────
    types.Tool(
        name="run_tests",
        description=(
            "Trigger test execution of a saved test, test suite or test sequence in Qualty. Supports three run modes:\n"
            "  • Individual tests — pass job_ids\n"
            "  • Test suite — pass suite_id (runs all jobs in the suite)\n"
            "  • Test sequence — pass sequence_id (runs tests serially, stage by stage)"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "job_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of specific test IDs to run.",
                },
                "suite_id": {
                    "type": "string",
                    "description": "Run all tests in this test suite. Use list_test_suites() to find IDs.",
                },
                "sequence_id": {
                    "type": "string",
                    "description": (
                        "Run a test sequence — tests execute serially, stage by stage. "
                        "Use list_sequences() to find IDs."
                    ),
                },
            },
            "required": [],
        },
    ),

    # ── run_local (hidden — not exposed until ready) ──────────────────────
    # types.Tool(
    #     name="run_local",
    #     description=(
    #         "Run saved tests against a locally hosted app using Qualty's localhost tunnel.\n\n"
    #         "USE THIS instead of run_tests when the target app is running on localhost.\n\n"
    #         "Qualty uses cloud browsers (BrowserBase) which cannot reach localhost directly. "
    #         "This tool verifies the Cloudflare tunnel is active for the project before "
    #         "triggering the run, so tests are routed through the public tunnel URL "
    #         "(e.g. https://p-abc123.qualty.dev) to reach your local server.\n\n"
    #         "SETUP REQUIRED (first time):\n"
    #         "  1. Open Qualty project settings → Localhost Mode.\n"
    #         "  2. Enter your local port and click Connect.\n"
    #         "  3. Run the provided cloudflared command in your terminal.\n"
    #         "  4. Your test URLs must use the tunnel URL as the base "
    #         "(e.g. https://p-abc123.qualty.dev/login, not http://localhost:3000/login).\n\n"
    #         "ASYNC BEHAVIOUR:\n"
    #         "Tests take 2-3 minutes. This tool triggers the run and returns execution IDs "
    #         "immediately — it does NOT block. Use get_test_execution(execution_id='...') "
    #         "to fetch results once complete. The response includes a check_after_seconds "
    #         "hint to tell you when to poll."
    #     ),
    #     inputSchema={
    #         "type": "object",
    #         "properties": {
    #             "job_ids": {
    #                 "type": "array",
    #                 "items": {"type": "string"},
    #                 "description": "Specific test IDs to run. Use list_saved_jobs to find them.",
    #             },
    #             "suite_id": {
    #                 "type": "string",
    #                 "description": "Run all tests in this suite.",
    #             },
    #             "project_id": {
    #                 "type": "string",
    #                 "description": "Project to run all tests for. Defaults to the configured default project.",
    #             },
    #         },
    #         "required": [],
    #     },
    # ),

    # ── list_test_executions ──────────────────────────────────────────────
    types.Tool(
        name="list_test_executions",
        description=(
            "List recent test execution runs for the current project.\n\n"
            "Returns a compact triage list that includes a one-line failure_summary for each run."
            "Use status/since/limit to narrow results. "
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": (
                        "Filter by execution status. "
                        "Use 'failed' to find broken runs. Other values: 'completed', 'running'. "
                        "Omit to return all statuses."
                    ),
                },
                "since": {
                    "type": "string",
                    "description": (
                        "Return only executions that started after this point. "
                        "Accepts relative values like '24h', '48h', '7d', "
                        "or an ISO-8601 timestamp."
                    ),
                },
                "limit": {
                    "type": "integer",
                    "description": "Max number of executions to return. Default 10, max 50.",
                },
            },
            "required": [],
        },
    ),

    # ── get_test_execution ────────────────────────────────────────────────
    types.Tool(
        name="get_test_execution",
        description=(
            "Get the full details of a specific test execution by ID. "
            "Use this to deeply investigate a specific run after finding it with list_test_executions."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "execution_id": {
                    "type": "string",
                    "description": "Execution ID from list_test_executions or returned by run_tests.",
                },
            },
            "required": ["execution_id"],
        },
    ),
]


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

HANDLERS = {
    "check_setup":       handle_check_setup,
    "setup":             handle_setup,
    "list_saved_jobs":   handle_list_saved_jobs,
    "list_test_suites":  handle_list_test_suites,
    "list_sequences":    handle_list_sequences,
    "create_sequence":   handle_create_sequence,
    "plan_tests":        handle_plan_tests,
    "create_test":       handle_create_test,
    "update_test":       handle_update_test,
    "create_test_suite": handle_create_test_suite,
    "update_test_suite": handle_update_test_suite,
    "run_tests":         handle_run_tests,
    # "run_local":       handle_run_local,  # hidden until ready
    "list_test_executions": handle_list_test_executions,
    "get_test_execution":   handle_get_test_execution,
}
