from .setup import handle_setup


def handle_check_setup() -> dict:
    """Read-only check: returns ready/needs_token/needs_project state."""
    return handle_setup({})
