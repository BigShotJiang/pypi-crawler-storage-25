from ..api import api, resolve_project_id
from ..config import get_default_project_id


def handle_run_local(args: dict) -> dict:
    project_id = args.get("project_id") or get_default_project_id()
    if not project_id:
        return {
            "success": False,
            "message": "No project configured. Run setup() first.",
        }

    # ── 1. Check tunnel status ─────────────────────────────────────────────
    try:
        status_data = api("GET", "localhost/status", params={"project_id": project_id})
    except Exception as exc:
        return {"success": False, "message": f"Could not fetch localhost status: {exc}"}

    localhost = status_data.get("localhost", {})
    tunnel_url = localhost.get("url")  # e.g. https://p-abc123.qualty.dev

    if localhost.get("status") != "connected":
        return {
            "success": False,
            "connected": False,
            "message": (
                "Localhost tunnel is not connected for this project. "
                "Connect it first, then re-run this tool."
            ),
            "how_to_connect": [
                "1. Open your project settings in the Qualty dashboard.",
                "2. Go to the 'Localhost Mode' section.",
                "3. Enter your local dev server port (e.g. 3000).",
                "4. Click Connect — you'll receive a cloudflared command to run in your terminal.",
                "5. Keep that terminal open while testing; it maintains the tunnel.",
                "6. Re-run run_local() once the tunnel is active.",
            ],
        }

    # ── 2. Build run payload ───────────────────────────────────────────────
    if not args.get("job_ids") and not args.get("suite_id") and not project_id:
        return {
            "success": False,
            "message": "Provide at least one selector: job_ids, suite_id, or project_id.",
        }

    payload: dict = {}
    if args.get("job_ids"):
        payload["job_ids"] = args["job_ids"]
    if args.get("suite_id"):
        payload["suite_id"] = args["suite_id"]
    if project_id:
        payload["project_id"] = project_id

    # ── 3. Trigger the run ─────────────────────────────────────────────────
    try:
        data = api("POST", "ci/run", json=payload)
    except Exception as exc:
        return {"success": False, "message": f"Failed to start tests: {exc}"}

    runs = data.get("runs", [])
    started = data.get("started_count", 0)
    execution_ids = [r["execution_job_id"] for r in runs if r.get("execution_job_id")]

    return {
        "success": started > 0,
        "connected": True,
        "tunnel_url": tunnel_url,
        "message": (
            f"Started {started} of {data.get('requested_count', 0)} test(s) "
            f"against tunnel {tunnel_url}."
        ),
        "started_count": started,
        "failed_to_start_count": data.get("failed_to_start_count", 0),
        "runs": [
            {
                "test_name": r.get("saved_job_name"),
                "test_id": r.get("saved_job_id"),
                "execution_id": r.get("execution_job_id"),
                "error": r.get("error"),
            }
            for r in runs
        ],
        # Agents should NOT block waiting — poll after the estimated window.
        "check_after_seconds": 150,
        "next_steps": (
            [
                f"Wait ~2-3 minutes, then call: "
                f"get_test_execution(execution_id='{execution_ids[0]}')"
            ]
            if execution_ids
            else []
        ),
        "url_tip": (
            f"Make sure your saved test URLs start with {tunnel_url} "
            "(not localhost) so the cloud browser can reach your local app."
        ),
    }
