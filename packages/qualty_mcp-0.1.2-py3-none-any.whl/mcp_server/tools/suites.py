from typing import Any

from ..api import api
from ..config import get_default_project_id


def handle_list_test_suites(args: dict) -> dict:
    project_id = args.get("project_id") or get_default_project_id()

    params = {}
    if project_id:
        params["project_id"] = project_id

    data = api("GET", "test-suites", params=params)
    if isinstance(data, list):
        suites = data
    elif isinstance(data, dict):
        suites = data.get("suites") or data.get("results") or []
    else:
        suites = []

    return {
        "project_id": project_id,
        "suites": [
            {
                "id": s.get("id"),
                "name": s.get("name"),
                "description": s.get("description"),
                "test_count": len(s.get("jobs", [])),
                "sequence_count": len(s.get("sequences", [])),
                "tests": [
                    {"id": j.get("id"), "name": j.get("name")}
                    for j in s.get("jobs", [])
                ],
                "sequences": [
                    {"id": seq.get("id"), "name": seq.get("name")}
                    for seq in s.get("sequences", [])
                ],
                "created_at": s.get("created_at"),
            }
            for s in suites
        ],
        "total": len(suites),
    }


def handle_create_test_suite(args: dict) -> dict:
    project_id = args.get("project_id") or get_default_project_id()

    payload: dict[str, Any] = {"name": args["name"]}
    if args.get("description"):
        payload["description"] = args["description"]
    if args.get("job_ids"):
        payload["job_ids"] = args["job_ids"]
    if args.get("sequence_ids"):
        payload["sequence_ids"] = args["sequence_ids"]
    if project_id:
        payload["project_id"] = project_id

    data = api("POST", "test-suites", json=payload)
    suite = data if isinstance(data, dict) else {}
    job_count = len(suite.get("jobs", []))
    seq_count = len(suite.get("sequences", []))

    return {
        "success": True,
        "message": f"Test suite '{suite.get('name')}' created with {job_count} test(s) and {seq_count} sequence(s).",
        "suite_id": suite.get("id"),
        "name": suite.get("name"),
        "project_id": suite.get("project_id"),
        "test_count": job_count,
        "sequence_count": seq_count,
        "tests": suite.get("jobs", []),
        "sequences": suite.get("sequences", []),
        "created_at": suite.get("created_at"),
        "next_steps": [
            "Run the suite: run_tests(suite_id='" + str(suite.get("id", "")) + "')",
        ],
    }


def handle_update_test_suite(args: dict) -> dict:
    suite_id = (args.get("suite_id") or "").strip()
    if not suite_id:
        return {"success": False, "message": "suite_id is required."}

    payload: dict[str, Any] = {}
    if "name" in args and args["name"] is not None:
        payload["name"] = args["name"]
    if "description" in args and args["description"] is not None:
        payload["description"] = args["description"]
    if "job_ids" in args and args["job_ids"] is not None:
        payload["job_ids"] = args["job_ids"]
    if "sequence_ids" in args and args["sequence_ids"] is not None:
        payload["sequence_ids"] = args["sequence_ids"]

    if not payload:
        return {"success": False, "message": "No fields provided to update."}

    data = api("PUT", f"test-suites/{suite_id}", json=payload)
    suite = data if isinstance(data, dict) else {}
    job_count = len(suite.get("jobs", []))
    seq_count = len(suite.get("sequences", []))

    return {
        "success": True,
        "message": f"Test suite '{suite.get('name')}' updated with {job_count} test(s) and {seq_count} sequence(s).",
        "suite_id": suite.get("id"),
        "name": suite.get("name"),
        "description": suite.get("description"),
        "project_id": suite.get("project_id"),
        "test_count": job_count,
        "sequence_count": seq_count,
        "tests": suite.get("jobs", []),
        "sequences": suite.get("sequences", []),
        "updated_at": suite.get("updated_at"),
    }
