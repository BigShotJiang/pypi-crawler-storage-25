from ..api import api
from ..config import get_default_project_id


def handle_list_test_executions(args: dict) -> dict:
    status_filter = (args.get("status") or "").strip() or None
    since         = (args.get("since") or "").strip() or None
    limit         = args.get("limit", 10)

    params = {}
    if status_filter:
        params["status"] = status_filter
    if since:
        params["since"] = since
    if limit:
        params["limit"] = limit

    data = api("GET", "jobs", params=params)
    if isinstance(data, list):
        jobs_list = data
    elif isinstance(data, dict):
        jobs_list = data.get("jobs") or data.get("results") or []
    else:
        jobs_list = []

    # Filter to current project only
    project_id = get_default_project_id()
    if project_id:
        jobs_list = [j for j in jobs_list if str(j.get("project_id") or "") == str(project_id)]

    return {
        "project_id": project_id,
        "executions": [
            {
                "execution_id":    j.get("job_id") or j.get("id"),
                "test_name":       j.get("episode_name") or j.get("job_name") or j.get("name"),
                "status":          j.get("status"),
                "passed":          j.get("successful_tests"),
                "failed":          j.get("failed_tests"),
                "total":           j.get("total_tests"),
                "started_at":      j.get("created_at") or j.get("started_at"),
                "failure_summary": j.get("failure_summary"),
            }
            for j in jobs_list
        ],
        "tip": "Call get_test_execution(execution_id='<id>') on any run to get full step-by-step details and network logs.",
    }


def handle_get_test_execution(args: dict) -> dict:
    execution_id = (args.get("execution_id") or "").strip()
    if not execution_id:
        return {"error": "execution_id is required."}

    # Fetch full results (no mode=agent so we get ALL combinations and steps_json)
    data = api("GET", f"results/{execution_id}")

    combinations = data.get("combinations", [])

    result_combinations = []
    for c in combinations:
        test_result_id = c.get("test_result_id")

        # Only fetch network logs for failed combinations — passing runs don't need debug info
        network = None
        combination_success = c.get("success")
        if test_result_id and not combination_success:
            try:
                net_data = api("GET", f"network-log/{test_result_id}")
                report = net_data.get("report", {})
                network = {
                    "summary":               report.get("summary"),
                    "failed_requests_top_20": report.get("failed_requests_top_20", []),
                    "slowest_requests_top_20": report.get("slowest_requests_top_20", []),
                }
            except Exception:
                network = None

        steps = c.get("steps_json") or []

        result_combinations.append({
            "test_result_id":    test_result_id,
            "device":            c.get("device"),
            "browser":           c.get("browser"),
            "success":           c.get("success"),
            "explanation":       c.get("explanation"),
            "expected_behavior": c.get("expected_behavior"),
            "runtime_sec":       c.get("runtime_sec"),
            "total_steps":       c.get("total_steps"),
            "steps":             steps,
            "network":           network,
        })

    return {
        "execution_id":      execution_id,
        "test_name":         data.get("episode_name"),
        "url":               data.get("url"),
        "expected_behavior": data.get("expected_behavior"),
        "summary": {
            "total":       data.get("total_combinations"),
            "passed":      data.get("successful_combinations"),
            "failed":      data.get("failed_combinations"),
            "runtime_sec": round(data.get("total_runtime_sec") or 0, 1),
        },
        "combinations": result_combinations,
    }
