from typing import Any

from ..api import api, resolve_project_id, list_projects_raw
from ..config import get_default_project_id, get_default_root_url, get_default_devices, get_default_browsers
from ..review import run_review_server


def handle_list_saved_jobs(args: dict) -> dict:
    params: dict[str, str] = {}

    project_id = args.get("project_id")
    project_name = args.get("project_name")
    if project_name and not project_id:
        project_id = resolve_project_id(None, project_name)
    if not project_id:
        project_id = get_default_project_id()
    if project_id:
        params["project_id"] = project_id

    if args.get("suite_id"):
        params["suite_id"] = args["suite_id"]
    if args.get("name"):
        params["name"] = args["name"]
    if args.get("ids"):
        params["ids"] = ",".join(args["ids"])

    data = api("GET", "saved-jobs", params=params)
    if isinstance(data, list):
        jobs = data
    elif isinstance(data, dict):
        jobs = data.get("jobs") or data.get("results") or []
    else:
        jobs = []

    return {
        "tests": [
            {
                "id": j.get("id"),
                "name": j.get("name"),
                "description": j.get("description"),
                "url": j.get("url"),
                "project_id": j.get("project_id"),
                "created_at": j.get("created_at"),
            }
            for j in jobs
        ],
        "total": len(jobs),
    }


def handle_plan_tests(args: dict) -> dict:
    """Conversational planning step before create_test.

    If explicit user answers for `test_plan` are not
    provided, returns a `needs_user_input` response with the questions the
    agent must ask the user. The agent must not infer the value.

    Once explicitly provided, returns generation rules for the selected test
    plan plus the next step.

    Pure function — no API calls, no I/O.
    """
    # Preferred vocabulary (explicit user choice).
    plan_raw = (args.get("test_plan") or "").strip().lower()
    valid_plans = {"quick_check", "user_journeys", "full_coverage"}
    test_plan = plan_raw if plan_raw in valid_plans else ""

    # Backward compatibility: map old fields if callers still send them.
    if not test_plan:
        strategy_raw = (args.get("test_strategy") or "").strip().lower()
        raw_priorities = args.get("priorities") or []
        if isinstance(raw_priorities, str):
            raw_priorities = [raw_priorities]
        normalized_priorities = {
            p.upper() for p in raw_priorities if isinstance(p, str)
        }
        if strategy_raw == "smoke":
            test_plan = "quick_check"
        elif strategy_raw == "regression":
            if normalized_priorities == {"P0"}:
                test_plan = "user_journeys"
            elif normalized_priorities:
                test_plan = "full_coverage"

    must_cover_paths = args.get("must_cover_paths") or []
    if isinstance(must_cover_paths, str):
        must_cover_paths = [must_cover_paths]
    release_context = (args.get("release_context") or "").strip()
    intent = (args.get("intent") or "").strip()

    if not test_plan:
        return {
            "status": "needs_user_input",
            "message": (
                "Explicit user confirmation is required before generating tests. "
                "Ask the user these questions verbatim, then call plan_tests again "
                "with the user's answers. Do not infer the test plan "
                "from intent, codebase context, or prior runs."
            ),
            "intent_received": intent or None,
            "explicit_user_confirmation_required": True,
            "questions": [
                {
                    "id": "test_plan",
                    "ask": (
                        "What do you want to test?"
                    ),
                    "options": [
                        "quick_check",
                        "user_journeys",
                        "full_coverage",
                    ],
                    "option_labels": {
                        "quick_check": "Quick check — critical screens and actions (~6-10 tests)",
                        "user_journeys": "User journeys — full end-to-end flows that mimic real users moving through your app (~3-5 journeys)",
                        "full_coverage": "Full coverage — everything above plus edge cases and integrations (~20+ tests)",
                    },
                },
                {
                    "id": "must_cover_paths",
                    "ask": "Are there specific flows or pages I MUST cover? (free text, optional)",
                },
                {
                    "id": "release_context",
                    "ask": (
                        "What's the context — pre-deploy gate, weekly run, "
                        "post-feature ship, or general coverage? (optional)"
                    ),
                },
            ],
            "do_not": ["Do not call create_test until the user answers these."],
        }

    quick_check_rules = {
        "target_count": "~6-10 tests",
        "focus": [
            "critical login/auth",
            "critical screens",
            "critical user actions",
            "core navigation",
            "system health checks",
        ],
        "skip": ["edge cases", "UI polish", "load tests"],
    }
    user_journeys_rules = {
        "target_count": "~3-5 journeys",
        "focus": [
            "end-to-end user journeys",
            "real user flow transitions across pages",
            "state continuity through multi-step actions",
            "journey-level success criteria",
        ],
    }
    full_coverage_rules = {
        "target_count": "~20+ tests",
        "focus": [
            "all quick-check coverage",
            "all journey coverage",
            "edge cases",
            "integration points",
            "error handling and recovery paths",
        ],
    }

    generation_rules: dict[str, Any] = {
        "quick_check": quick_check_rules,
        "user_journeys": user_journeys_rules,
        "full_coverage": full_coverage_rules,
    }

    return {
        "status": "ready",
        "test_plan": test_plan,
        "test_plan_label": {
            "quick_check": "Quick check",
            "user_journeys": "User journeys",
            "full_coverage": "Full coverage",
        }.get(test_plan),
        "generation_rules": generation_rules[test_plan],
        "next_step": (
            "Call create_test(tests=[...]) aligned to this explicit user-selected test plan. "
            "The user will then review in the browser UI."
        ),
        "must_cover_paths": must_cover_paths,
        "release_context": release_context,
    }


def handle_create_test(args: dict) -> dict:
    resolved_project_id = resolve_project_id(None, None)
    root_url = get_default_root_url()
    try:
        projects = list_projects_raw()
        match = next((p for p in projects if str(p.get("id")) == str(resolved_project_id)), None)
        project_name = match.get("name") if match else None
    except Exception:
        project_name = None

    # Normalise to a list of test dicts
    raw_tests: list[dict] = args.get("tests") or []
    if not raw_tests:
        return {
            "success": False,
            "message": "No tests provided. Pass a 'tests' array with at least one test definition.",
        }

    try:
        profiles_raw = api("GET", f"projects/{resolved_project_id}/saved-login-profiles")
        profiles = profiles_raw if isinstance(profiles_raw, list) else (
            profiles_raw.get("results") or []
        )
    except Exception:
        profiles = []

    confirmed = run_review_server(
        tests=raw_tests,
        profiles=profiles,
        root_url=root_url,
        project_name=project_name,
        timeout=600,  # 10 minutes
    )

    if not confirmed:
        return {
            "success": False,
            "message": "No tests were created (all removed or cancelled).",
        }

    created = []
    errors = []
    for t in confirmed:
        payload: dict[str, Any] = {
            "name":              (t.get("name") or "").strip(),
            "url":               t.get("url", ""),
            "steps":             t.get("steps", ""),
            "stagehand_steps":   t.get("stagehand_steps", ""),
            "expected_behavior": t.get("expected_behavior", ""),
            "description":       t.get("description", ""),
            "project_id":        resolved_project_id,
        }
        devices  = t.get("devices")  or get_default_devices()
        browsers = t.get("browsers") or get_default_browsers()
        if devices:
            payload["devices"] = devices
        if browsers:
            payload["browsers"] = browsers
        if t.get("saved_login_profile_id"):
            payload["saved_login_profile_id"] = t["saved_login_profile_id"]
        if t.get("username"):
            payload["username"] = t["username"]
        if t.get("password"):
            payload["password"] = t["password"]
        if t.get("network_backend_host"):
            payload["network_backend_host"] = t["network_backend_host"]

        try:
            job = api("POST", "saved-jobs", json=payload)
            job_data = job if isinstance(job, dict) else {}
            created.append({
                "test_id":    job_data.get("id"),
                "name":       job_data.get("name"),
                "url":        job_data.get("url"),
                "project_id": job_data.get("project_id"),
                "created_at": job_data.get("created_at"),
            })
        except Exception as exc:
            errors.append({"name": payload["name"], "error": str(exc)})

    all_ids = [t["test_id"] for t in created if t.get("test_id")]
    result: dict = {
        "success":       len(created) > 0,
        "message":       f"{len(created)} test(s) created successfully." + (
            f" {len(errors)} failed." if errors else ""
        ),
        "created_count": len(created),
        "tests":         created,
        "next_steps": [
            f"Group into a suite: create_test_suite(name='...', job_ids={all_ids})",
            f"Run them now:       run_tests(job_ids={all_ids})",
        ] if all_ids else [],
    }
    if errors:
        result["errors"] = errors
    if root_url:
        result["project_root_url"] = root_url
    return result


def handle_update_test(args: dict) -> dict:
    test_id = (args.get("test_id") or "").strip()
    if not test_id:
        return {"success": False, "message": "test_id is required."}

    payload: dict[str, Any] = {}
    for field in ("name", "url", "steps", "expected_behavior", "description"):
        if field in args and args[field] is not None:
            payload[field] = args[field]
    if "devices" in args and args["devices"] is not None:
        payload["devices"] = args["devices"]
    if "browsers" in args and args["browsers"] is not None:
        payload["browsers"] = args["browsers"]

    if not payload:
        return {"success": False, "message": "No fields provided to update."}

    job = api("PUT", f"saved-jobs/{test_id}", json=payload)
    job_data = job if isinstance(job, dict) else {}

    return {
        "success": True,
        "message": f"Test '{job_data.get('name')}' updated successfully.",
        "test_id": job_data.get("id"),
        "name": job_data.get("name"),
        "url": job_data.get("url"),
        "steps": job_data.get("steps"),
        "expected_behavior": job_data.get("expected_behavior"),
        "devices": job_data.get("devices"),
        "browsers": job_data.get("browsers"),
        "updated_at": job_data.get("updated_at"),
    }
