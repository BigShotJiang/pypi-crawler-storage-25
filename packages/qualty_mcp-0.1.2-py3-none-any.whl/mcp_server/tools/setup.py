from ..api import list_projects_raw
from ..config import (
    get_api_token, get_default_project_id, get_default_root_url,
    save_config, save_credentials,
)


def handle_setup(args: dict) -> dict:
    token = (args.get("token") or "").strip()
    project_id = (args.get("project_id") or "").strip()

    if token:
        save_credentials(token)

    if project_id:
        try:
            projects = list_projects_raw()
            match = next((p for p in projects if str(p.get("id")) == str(project_id)), None)
            name = match.get("name") if match else project_id
            root_url = match.get("url") if match else None
        except Exception:
            name = project_id
            root_url = None
        cfg_updates: dict = {"default_project_id": project_id}
        if root_url:
            cfg_updates["default_root_url"] = root_url
        cfg_path = save_config(cfg_updates)
        return {
            "success": True,
            "message": f"Default project set to '{name}'.",
            "config_file": str(cfg_path),
            "default_root_url": root_url,
            "tip": "You're all set! Run create_test to get started.",
        }

    current_token = get_api_token()
    if not current_token:
        return {
            "needs_token": True,
            "message": (
                "No API token found. Ask the user for their Qualty API token "
                "(starts with qlty_ci_...), then call setup(token='qlty_ci_...')."
            ),
            "hint": "Tokens can be generated in Qualty -> Settings -> API Tokens.",
        }

    default_project_id = get_default_project_id()
    if default_project_id:
        try:
            projects = list_projects_raw()
            match = next((p for p in projects if str(p.get("id")) == str(default_project_id)), None)
            project_name = match.get("name") if match else default_project_id
        except Exception:
            project_name = default_project_id
        return {
            "ready": True,
            "message": "Qualty is configured. You're ready to go.",
            "default_project_id": default_project_id,
            "default_project_name": project_name,
            "default_root_url": get_default_root_url(),
        }

    try:
        projects = list_projects_raw()
    except Exception as exc:
        return {
            "error": f"Could not fetch projects: {exc}",
            "tip": "Check that your API token is valid and the base URL is correct.",
        }

    if not projects:
        return {
            "error": "No projects found for this token.",
            "tip": "Create a project in the Qualty dashboard first.",
        }

    numbered = [
        {"number": i + 1, "name": p["name"], "id": p["id"]}
        for i, p in enumerate(projects)
    ]
    return {
        "needs_project": True,
        "projects": numbered,
        "agent_instructions": (
            "Show the user ONLY the project names as a numbered list (do NOT show IDs). "
            "Ask them to pick a number. Then call setup(project_id='<id>') using the ID "
            "that corresponds to their choice."
        ),
    }
