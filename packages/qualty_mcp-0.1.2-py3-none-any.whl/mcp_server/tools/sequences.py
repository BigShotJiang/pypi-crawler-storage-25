from typing import Any

from ..api import api


def _extract_job_id(item: dict) -> str | None:
    job = item.get("job")
    if isinstance(job, dict):
        return job.get("id")
    return item.get("job_id")


def _fetch_job_names(job_ids: list[str]) -> dict[str, str]:
    """Return a {job_id: job_name} map for the given IDs in one API call."""
    if not job_ids:
        return {}
    data = api("GET", "saved-jobs", params={"ids": ",".join(job_ids)})
    if isinstance(data, list):
        jobs = data
    elif isinstance(data, dict):
        jobs = data.get("jobs") or data.get("results") or []
    else:
        jobs = []
    return {j["id"]: j["name"] for j in jobs if j.get("id") and j.get("name")}


def handle_list_sequences(args: dict) -> dict:
    params: dict[str, Any] = {}
    if args.get("project_id"):
        params["project_id"] = args["project_id"]

    data = api("GET", "test-sequences", params=params if params else None)
    if isinstance(data, list):
        sequences = data
    elif isinstance(data, dict):
        sequences = data.get("sequences") or data.get("results") or []
    else:
        sequences = []

    # Collect all unique job IDs across all sequences and fetch names in one call
    all_job_ids = list({
        _extract_job_id(item)
        for s in sequences
        for item in s.get("items", [])
        if _extract_job_id(item)
    })
    job_names = _fetch_job_names(all_job_ids)

    return {
        "sequences": [
            {
                "id": s.get("id"),
                "name": s.get("name"),
                "description": s.get("description"),
                "project_id": s.get("project_id"),
                "stop_on_failure": s.get("stop_on_failure"),
                "step_count": len(s.get("items", [])),
                "items": [
                    {
                        "id": item.get("id"),
                        "stage": item.get("stage"),
                        "position": item.get("position"),
                        "job_id": (job_id := _extract_job_id(item)),
                        "job_name": job_names.get(job_id) if job_id else None,
                    }
                    for item in s.get("items", [])
                ],
                "created_at": s.get("created_at"),
                "updated_at": s.get("updated_at"),
            }
            for s in sequences
        ],
        "total": len(sequences),
    }


def handle_create_sequence(args: dict) -> dict:
    payload: dict[str, Any] = {"name": args["name"]}

    if args.get("description"):
        payload["description"] = args["description"]
    if args.get("project_id"):
        payload["project_id"] = args["project_id"]
    if "stop_on_failure" in args:
        payload["stop_on_failure"] = args["stop_on_failure"]

    # Auto-assign positions within each stage based on array order
    stage_counters: dict[int, int] = {}
    payload["items"] = []
    for item in args.get("items", []):
        stage = item["stage"]
        stage_counters[stage] = stage_counters.get(stage, 0) + 1
        payload["items"].append({
            "job_id": item["job_id"],
            "stage": stage,
            "position": stage_counters[stage],
        })

    data = api("POST", "test-sequences", json=payload)
    seq = data if isinstance(data, dict) else {}
    step_count = len(seq.get("items", []))

    return {
        "success": True,
        "message": f"Test sequence '{seq.get('name')}' created with {step_count} step(s).",
        "sequence_id": seq.get("id"),
        "name": seq.get("name"),
        "description": seq.get("description"),
        "project_id": seq.get("project_id"),
        "stop_on_failure": seq.get("stop_on_failure"),
        "step_count": step_count,
        "items": [
            {
                "id": item.get("id"),
                "stage": item.get("stage"),
                "position": item.get("position"),
                "job_id": item.get("job", {}).get("id") if isinstance(item.get("job"), dict) else item.get("job_id"),
                "job_name": item.get("job", {}).get("name") if isinstance(item.get("job"), dict) else None,
            }
            for item in seq.get("items", [])
        ],
        "created_at": seq.get("created_at"),
        "next_steps": [
            f"Run the sequence: POST /api/v1/test-sequences/{seq.get('id', '')}/run",
        ],
    }
