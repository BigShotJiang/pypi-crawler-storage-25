from typing import Any

from ..api import api


def handle_run_tests(args: dict) -> dict:
    sequence_id = (args.get("sequence_id") or "").strip()

    if not args.get("job_ids") and not args.get("suite_id") and not sequence_id:
        return {
            "error": "Provide at least one selector: job_ids, suite_id, or sequence_id.",
            "example": {
                "run_by_ids": {"job_ids": ["<test_id_1>", "<test_id_2>"]},
                "run_suite":  {"suite_id": "<suite_id>"},
                "run_sequence": {"sequence_id": "<sequence_id>"},
            },
        }

    # ── Sequence run (separate backend endpoint) ───────────────────────────
    if sequence_id:
        data = api("POST", f"test-sequences/{sequence_id}/run")
        return {
            "success": data.get("status") == "started",
            "type": "sequence",
            "message": f"Sequence '{data.get('sequence_name')}' started ({data.get('total_steps')} step(s)).",
            "sequence_run_id": data.get("sequence_run_id"),
            "sequence_id": data.get("sequence_id"),
            "sequence_name": data.get("sequence_name"),
            "total_steps": data.get("total_steps"),
            "status": data.get("status"),
            "tip": (
                "Sequence steps run serially. Use list_test_executions() to see "
                "individual step results as they complete."
            ),
        }

    # ── Job / suite run ────────────────────────────────────────────────────
    payload: dict[str, Any] = {}
    if args.get("job_ids"):
        payload["job_ids"] = args["job_ids"]
    if args.get("suite_id"):
        payload["suite_id"] = args["suite_id"]

    data = api("POST", "ci/run", json=payload)
    runs = data.get("runs", [])

    return {
        "success": data.get("started_count", 0) > 0,
        "type": "jobs",
        "message": f"Started {data.get('started_count', 0)} of {data.get('requested_count', 0)} tests.",
        "started_count": data.get("started_count"),
        "failed_to_start_count": data.get("failed_to_start_count"),
        "runs": [
            {
                "test_name":    r.get("saved_job_name"),
                "test_id":      r.get("saved_job_id"),
                "execution_id": r.get("execution_job_id"),
                "error":        r.get("error"),
            }
            for r in runs
        ],
        "tip": (
            "Use get_test_execution(execution_id='<id>') to fetch results once complete. "
            "Tests typically take 2-3 minutes."
        ),
    }
