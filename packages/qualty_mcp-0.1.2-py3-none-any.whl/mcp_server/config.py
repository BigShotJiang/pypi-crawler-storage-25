"""
Qualty MCP — Configuration helpers.

Resolution order:
  base URL: mcp_server/.env only
  other values: env var > ~/.qualty/credentials > .qualty.json (walked up from cwd)
"""

import json
import os
from pathlib import Path

CONFIG_FILENAME = ".qualty.json"
_CREDENTIALS_FILE = Path.home() / ".qualty" / "credentials"
_MCP_ENV_FILE = Path(__file__).resolve().parent / ".env"
_PROD_BASE_URL = "https://qualty-api-production.up.railway.app"
_DEV_BASE_URL = "https://qualty-api-development.up.railway.app"


# ---------------------------------------------------------------------------
# .qualty.json
# ---------------------------------------------------------------------------

def find_config_file() -> Path | None:
    """Walk up from cwd looking for .qualty.json."""
    current = Path.cwd()
    for directory in [current, *current.parents]:
        candidate = directory / CONFIG_FILENAME
        if candidate.exists():
            return candidate
    return None


def load_config() -> dict:
    path = find_config_file()
    if path is None:
        return {}
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def save_config(updates: dict) -> Path:
    """Merge updates into .qualty.json at cwd (create if absent)."""
    path = Path.cwd() / CONFIG_FILENAME
    existing: dict = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text())
        except Exception:
            pass
    existing.update(updates)
    path.write_text(json.dumps(existing, indent=2))
    return path


# ---------------------------------------------------------------------------
# ~/.qualty/credentials
# ---------------------------------------------------------------------------

def save_credentials(token: str) -> None:
    """Save API token to ~/.qualty/credentials with restricted permissions."""
    creds_dir = _CREDENTIALS_FILE.parent
    creds_dir.mkdir(parents=True, exist_ok=True)
    _CREDENTIALS_FILE.write_text(json.dumps({"api_token": token}, indent=2))
    _CREDENTIALS_FILE.chmod(0o600)


def load_credentials() -> dict:
    try:
        return json.loads(_CREDENTIALS_FILE.read_text())
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# mcp_server/.env
# ---------------------------------------------------------------------------

def load_mcp_env() -> dict[str, str]:
    """Parse key=value pairs from mcp_server/.env (if present)."""
    if not _MCP_ENV_FILE.exists():
        return {}

    out: dict[str, str] = {}
    try:
        for raw in _MCP_ENV_FILE.read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip("'").strip('"')
            if key:
                out[key] = value
    except Exception:
        return {}
    return out


# ---------------------------------------------------------------------------
# Runtime accessors (re-read on every call so env/file changes are picked up)
# ---------------------------------------------------------------------------

def get_base_url() -> str:
    mcp_env = load_mcp_env()
    # Optional explicit override if a full URL is provided.
    override_url = (mcp_env.get("QUALTY_BASE_URL") or "").strip().rstrip("/")
    if override_url:
        return override_url

    # Default behavior: hardcoded prod endpoint unless USE_PROD_URL disables it.
    use_prod_raw = (mcp_env.get("USE_PROD_URL") or "1").strip().lower()
    use_prod = use_prod_raw in {"1", "true", "yes", "on"}
    return _PROD_BASE_URL if use_prod else _DEV_BASE_URL


def get_api_token() -> str:
    return (
        os.environ.get("QUALTY_API_TOKEN", "")
        or load_credentials().get("api_token", "")
    )


def get_default_project_id() -> str | None:
    cfg = load_config()
    return cfg.get("default_project_id") or os.environ.get("QUALTY_DEFAULT_PROJECT_ID")


def get_default_root_url() -> str | None:
    cfg = load_config()
    return cfg.get("default_root_url") or os.environ.get("QUALTY_DEFAULT_ROOT_URL")


def get_default_devices() -> list[str] | None:
    return load_config().get("default_devices")


def get_default_browsers() -> list[str] | None:
    return load_config().get("default_browsers")
