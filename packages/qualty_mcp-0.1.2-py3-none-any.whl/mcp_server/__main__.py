import argparse
import asyncio
import json
import os
import sys
from pathlib import Path

from .api import list_projects_raw
from .config import (
    find_config_file,
    get_api_token,
    get_base_url,
    get_default_project_id,
    load_config,
    load_mcp_env,
    save_config,
    save_credentials,
)
from .server import main


def _run_server() -> None:
    asyncio.run(main())


def _cmd_init(_: argparse.Namespace) -> int:
    print("Qualty MCP initialization")
    print("-------------------------")

    token = get_api_token().strip()
    if not token:
        token = input("Enter Qualty API token (qlty_ci_...): ").strip()
        if not token:
            print("No token entered. Aborting.")
            return 1
        save_credentials(token)
        print("Saved token to ~/.qualty/credentials")
    else:
        print("Token already configured.")

    try:
        projects = list_projects_raw()
    except Exception as exc:
        print(f"Could not fetch projects: {exc}")
        return 1

    if not projects:
        print("No projects available for this token.")
        return 1

    print("\nSelect default project:")
    for idx, project in enumerate(projects, 1):
        print(f"{idx}. {project.get('name')} ({project.get('id')})")

    selected = input("Project number (Enter to skip): ").strip()
    if selected:
        try:
            project = projects[int(selected) - 1]
        except Exception:
            print("Invalid selection.")
            return 1
        updates = {"default_project_id": str(project.get("id"))}
        if project.get("url"):
            updates["default_root_url"] = project.get("url")
        config_path = save_config(updates)
        print(f"Saved default project to {config_path}")
    else:
        print("Skipped default project selection.")

    print("\nInitialization complete.")
    print("Next: add `qualty-mcp` to your MCP client config and restart your client.")
    return 0


def _cmd_doctor(_: argparse.Namespace) -> int:
    print("Qualty MCP doctor")
    print("-----------------")
    ok = True

    token = get_api_token().strip()
    if token:
        print("PASS token configured")
    else:
        print("FAIL missing API token")
        ok = False

    base_url = get_base_url().strip()
    print(f"INFO base URL: {base_url}")

    config_path = find_config_file()
    if config_path:
        print(f"PASS config file found: {config_path}")
    else:
        print("INFO no .qualty.json found from current directory upward")

    default_project = get_default_project_id()
    if default_project:
        print(f"PASS default project configured: {default_project}")
    else:
        print("WARN no default project configured")

    if token:
        try:
            projects = list_projects_raw()
            print(f"PASS API reachable ({len(projects)} project(s) visible)")
        except Exception as exc:
            print(f"FAIL API connectivity/auth check failed: {exc}")
            ok = False

    if ok:
        print("Doctor check passed.")
        return 0
    print("Doctor check failed.")
    return 1


def _cmd_status(args: argparse.Namespace) -> int:
    print("Qualty MCP status")
    print("-----------------")

    config_path = find_config_file()
    cfg = load_config()
    mcp_env = load_mcp_env()

    token = get_api_token().strip()
    token_source = "missing"
    if os.environ.get("QUALTY_API_TOKEN"):
        token_source = "process env QUALTY_API_TOKEN"
    elif token:
        token_source = "~/.qualty/credentials"

    base_url_source = "default"
    if os.environ.get("QUALTY_BASE_URL"):
        base_url_source = "process env QUALTY_BASE_URL"
    elif mcp_env.get("QUALTY_BASE_URL"):
        base_url_source = "mcp_server/.env"
    elif cfg.get("base_url"):
        base_url_source = ".qualty.json base_url"

    print(f"token_configured: {'yes' if token else 'no'}")
    print(f"token_source: {token_source}")
    print(f"base_url_source: {base_url_source}")
    print(f"active_project_id: {get_default_project_id() or '(none)'}")
    print(f"active_project_root_url: {cfg.get('default_root_url') or '(none)'}")
    print(f"workspace_config_path: {config_path if config_path else '(none found)'}")
    print(f"workspace_mcp_path: {Path.cwd() / '.mcp.json'}")
    print(f"user_cursor_mcp_path: {Path.home() / '.cursor' / 'mcp.json'}")
    print(f"credentials_path: {Path.home() / '.qualty' / 'credentials'}")
    return 0


def _select_project_interactively(projects: list[dict], current_project_id: str | None) -> tuple[int, dict] | None:
    print("\nProjects:")
    for idx, project in enumerate(projects, 1):
        marker = " (active)" if current_project_id and str(project.get("id")) == str(current_project_id) else ""
        print(f"{idx}. {project.get('name')}{marker}")

    selected = input("Select project number to activate (Enter to cancel): ").strip()
    if not selected:
        return None
    try:
        selected_index = int(selected)
        return selected_index, projects[selected_index - 1]
    except Exception:
        return None


def _activate_project(project: dict, selection_number: int | None = None) -> int:
    updates = {"default_project_id": str(project.get("id"))}
    if project.get("url"):
        updates["default_root_url"] = project.get("url")
    config_path = save_config(updates)
    if selection_number is not None:
        print(f"Activated project #{selection_number}: {project.get('name')}")
    else:
        print(f"Activated project: {project.get('name')}")
    print(f"Saved to {config_path}")
    return 0


def _cmd_list_projects(args: argparse.Namespace) -> int:
    try:
        projects = list_projects_raw()
    except Exception as exc:
        print(f"Could not fetch projects: {exc}")
        return 1

    if not projects:
        print("No projects available for this account.")
        return 1

    current_project_id = get_default_project_id()
    selected = _select_project_interactively(projects, current_project_id)
    if selected is None:
        print("No project activated.")
        return 0
    selection_number, chosen = selected
    return _activate_project(chosen, selection_number=selection_number)


def _cmd_switch_project(args: argparse.Namespace) -> int:
    try:
        projects = list_projects_raw()
    except Exception as exc:
        print(f"Could not fetch projects: {exc}")
        return 1

    if not projects:
        print("No projects available for this account.")
        return 1

    if args.project_id:
        match = next((p for p in projects if str(p.get("id")) == args.project_id), None)
        if not match:
            print(f"Project ID not found: {args.project_id}")
            return 1
        return _activate_project(match)

    if args.project_name:
        match = next(
            (p for p in projects if (p.get("name") or "").strip().lower() == args.project_name.lower()),
            None,
        )
        if not match:
            print(f"Project name not found: {args.project_name}")
            return 1
        return _activate_project(match)

    selected = _select_project_interactively(projects, get_default_project_id())
    if selected is None:
        print("No project activated.")
        return 0
    selection_number, chosen = selected
    return _activate_project(chosen, selection_number=selection_number)


def _mcp_snippet(base_url: str | None = None) -> dict:
    env = {}
    if base_url:
        env["QUALTY_BASE_URL"] = base_url

    out = {
        "mcpServers": {
            "qualty": {
                "command": "qualty-mcp",
                "args": ["serve"],
            }
        }
    }
    if env:
        out["mcpServers"]["qualty"]["env"] = env
    return out


def _cmd_print_cursor_config(args: argparse.Namespace) -> int:
    snippet = _mcp_snippet(base_url=args.base_url)
    print(json.dumps(snippet, indent=2))
    return 0


def _cmd_print_claude_code_config(args: argparse.Namespace) -> int:
    snippet = _mcp_snippet(base_url=args.base_url)
    print(json.dumps(snippet, indent=2))
    return 0


def _cursor_mcp_path() -> Path:
    return Path.cwd() / ".mcp.json"


def _claude_code_mcp_path() -> Path:
    return Path.cwd() / ".mcp.json"


def _cmd_install_cursor(args: argparse.Namespace) -> int:
    mcp_path = _cursor_mcp_path()
    if mcp_path.exists():
        try:
            data = json.loads(mcp_path.read_text())
        except Exception:
            print(f"Existing {mcp_path} is invalid JSON.")
            return 1
    else:
        data = {}

    data.setdefault("mcpServers", {})
    server_cfg: dict = {"command": "qualty-mcp"}
    if args.base_url:
        server_cfg["env"] = {"QUALTY_BASE_URL": args.base_url}
    data["mcpServers"]["qualty"] = server_cfg

    mcp_path.write_text(json.dumps(data, indent=2) + "\n")
    print(f"Updated {mcp_path}")
    print("Restart Cursor/Claude Code to load the new MCP config.")
    return 0


def _cmd_install_claude_code(args: argparse.Namespace) -> int:
    mcp_path = _claude_code_mcp_path()
    if mcp_path.exists():
        try:
            data = json.loads(mcp_path.read_text())
        except Exception:
            print(f"Existing {mcp_path} is invalid JSON.")
            return 1
    else:
        data = {}

    data.setdefault("mcpServers", {})
    server_cfg: dict = {"command": "qualty-mcp"}
    if args.base_url:
        server_cfg["env"] = {"QUALTY_BASE_URL": args.base_url}
    data["mcpServers"]["qualty"] = server_cfg

    mcp_path.write_text(json.dumps(data, indent=2) + "\n")
    print(f"Updated {mcp_path}")
    print("Restart Claude Code to load the new MCP config.")
    return 0


def _cmd_release_checklist(_: argparse.Namespace) -> int:
    print("Qualty MCP release checklist")
    print("----------------------------")
    print("1. Bump [project].version in pyproject.toml")
    print("2. Build artifacts: python3 -m build")
    print("3. Smoke-test wheel: pipx install --force dist/*.whl")
    print("4. Validate CLI: qualty-mcp doctor")
    print("5. Validate MCP startup: qualty-mcp (stdio server)")
    print("6. Publish to PyPI")
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qualty-mcp",
        description="Qualty MCP server and client onboarding CLI",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("serve", help="Run MCP stdio server")

    p_init = sub.add_parser("init", help="Initialize local token and default project")
    p_init.set_defaults(func=_cmd_init)

    p_doctor = sub.add_parser("doctor", help="Validate local config and API connectivity")
    p_doctor.set_defaults(func=_cmd_doctor)

    p_status = sub.add_parser("status", help="Show effective runtime configuration and sources")
    p_status.set_defaults(func=_cmd_status)

    p_list_projects = sub.add_parser(
        "list-projects",
        help="List projects and select one to activate",
    )
    p_list_projects.set_defaults(func=_cmd_list_projects)

    p_switch = sub.add_parser(
        "switch-project",
        help="Activate a project by ID/name or interactive selection",
    )
    p_switch.add_argument("--project-id", default=None, help="Project ID to activate")
    p_switch.add_argument("--project-name", default=None, help="Project name to activate")
    p_switch.set_defaults(func=_cmd_switch_project)

    p_print = sub.add_parser("print-cursor-config", help="Print .mcp.json snippet for Cursor")
    p_print.add_argument("--base-url", default=None, help="Optional QUALTY_BASE_URL override")
    p_print.set_defaults(func=_cmd_print_cursor_config)

    p_print_claude = sub.add_parser("print-claude-code-config", help="Print .mcp.json snippet for Claude Code")
    p_print_claude.add_argument("--base-url", default=None, help="Optional QUALTY_BASE_URL override")
    p_print_claude.set_defaults(func=_cmd_print_claude_code_config)

    p_install = sub.add_parser("install-cursor", help="Create or update local .mcp.json")
    p_install.add_argument("--base-url", default=None, help="Optional QUALTY_BASE_URL override")
    p_install.set_defaults(func=_cmd_install_cursor)

    p_install_claude = sub.add_parser("install-claude-code", help="Create or update local .mcp.json for Claude Code")
    p_install_claude.add_argument("--base-url", default=None, help="Optional QUALTY_BASE_URL override")
    p_install_claude.set_defaults(func=_cmd_install_claude_code)

    p_release = sub.add_parser("release-checklist", help="Show pre-publish release checklist")
    p_release.set_defaults(func=_cmd_release_checklist)

    return parser


def run() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "serve":
        _run_server()
        return

    # No subcommand:
    # - In non-interactive contexts (MCP client), start server for compatibility.
    # - In interactive terminal, show help instead of waiting for JSON-RPC input.
    if args.command is None:
        if not sys.stdin.isatty():
            _run_server()
            return
        parser.print_help()
        print("\nTip: use `qualty-mcp serve` to run the MCP server.")
        return

    func = getattr(args, "func", None)
    if func is None:
        parser.print_help()
        sys.exit(1)

    code = func(args)
    sys.exit(code)


if __name__ == "__main__":
    run()
