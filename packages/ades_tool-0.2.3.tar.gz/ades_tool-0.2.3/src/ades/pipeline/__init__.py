"""Local tagging pipeline."""
