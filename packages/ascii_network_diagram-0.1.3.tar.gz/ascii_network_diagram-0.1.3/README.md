# ascii-network-diagram

ascii-network-diagram is a Python package for generating visually appealing ASCII art network diagrams directly in your terminal. It is designed for quick visualization of star-topology networks, making it easy to share, document, or debug network layouts in plain text environments.

**Key Features:**

- Draws star network diagrams with 2 to 12 nodes.
- Each node can have a label, VLAN (optional), and connection/circuit ID (optional).
- VLAN and title are not required; the diagram will render without them.
- Automatically adjusts box sizes and layout for your node labels.
- Attempts to center the diagram in the terminal
- Output is pure ASCII/Unicode, suitable for terminals, documentation, and code comments.
- No external dependencies beyond Python standard library.
- Outputs nodes in list-order from left-center in a counter-clockwise pattern

**Limitations:**

- There is no overflow handling. If the diagram is too wide for your screen, it prints a warning:
  - `[Warning] Diagram width exceeds terminal width. Consider shortening labels or reducing the number of nodes.`

**Usage Example:**

```
from ascii_network_diagram import star_diagram

nodes = [
    {"label": "node1.core, eth0", "vlan": 100, "connection": "CIR-100"},
    {"label": "node2.core, eth1", "vlan": 100, "connection": "CIR-100"},
]

star_diagram(nodes, title="2 Node Star Diagram")
```

**Output:**

```text
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                                                                                                      │
│                                                 2 Node Star Diagram                                                  │
│                                                                                                                      │
├──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                                      │
│                                ┌──────────────────┐             ┌──────────────────┐                                 │
│  CIR-100 ──── (vlan 100) ────▶ │ node1.core, eth0 │ ◀═════════▶ │ node2.core, eth1 │ ◀──── (vlan 100) ──── CIR-100   │
│                                └──────────────────┘             └──────────────────┘                                 │
│                                                                                                                      │
└──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

## Installation

```
pip install ascii-network-diagram
```

## Usage

```
from ascii_network_diagram import star_diagram

nodes = [
    {"label": "node1.core, eth0", "vlan": 100, "connection": "CIR-100"},
    {"label": "node2.core, eth1", "vlan": 100, "connection": "CIR-100"},
]

star_diagram(nodes, title="2 Node Star Diagram")
```

## License

MIT License
