
from setuptools import setup, find_packages

import os

setup(
    name="ascii-network-diagram",
    version="0.1.3",
    description="A package for generating network diagrams in ASCII art.",
    author="Joshua Bettigole",
    author_email="your.email@example.com",
    package_dir={"": "src"},
    packages=["ascii_network_diagram"],
    install_requires=[],
    python_requires=">=3.7",
    url="https://github.com/yourusername/ascii-network-diagram",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    include_package_data=True,
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
)