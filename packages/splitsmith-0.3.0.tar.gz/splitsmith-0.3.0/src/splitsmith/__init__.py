"""splitsmith: extract IPSC shot splits from head-mounted camera footage."""

__version__ = "0.3.0"
