"""FastAPI app for the production UI.

Endpoints (locked v1 surface):

  GET  /api/health                  -- project metadata + schema version
  GET  /api/project                 -- full MatchProject dump
  GET  /api/fs/list?path=...        -- list directory entries (folder picker)
  POST /api/scoreboard/import       -- import an SSI Scoreboard JSON
  POST /api/project/placeholder-stages -- bootstrap source-first (no scoreboard yet)
  POST /api/videos/scan             -- register videos (folder or explicit paths)
  POST /api/videos/auto-match       -- run video_match.py heuristic, return suggestions
  POST /api/videos/remove           -- remove a registered video + cleanup caches
  GET  /api/videos/link-status      -- per-video raw/<name> symlink state (ok/broken/...)
  POST /api/videos/relink/scan      -- recursive dry-run: candidates per video
  POST /api/videos/relink/apply     -- apply chosen symlink rewrites
  GET  /api/project/cleanup/plan    -- preview disk-cleanup plan
  POST /api/project/cleanup         -- apply disk-cleanup (refuses while jobs run)
  POST /api/assignments/move        -- set role / unassign / move between stages
  POST /api/project/settings        -- update raw/audio/trimmed/exports dir overrides
  GET  /api/fs/probe?path=...       -- probe + thumbnail one source file on demand
  GET  /api/thumbnails/{key}.jpg    -- serve cached thumbnail
  POST /api/stages/{n}/detect-beep  -- submit a beep-detection job (runs in pool)
  POST /api/stages/{n}/beep         -- manual beep_time override (synchronous)
  POST /api/stages/{n}/beep/select  -- promote one ranked candidate (synchronous)
  POST /api/stages/{n}/time         -- manual stage duration (no-scoreboard path)
  POST /api/stages/{n}/trim         -- submit an audit-mode trim job
  POST /api/stages/{n}/shot-detect  -- submit shot detection on the audit clip
  POST /api/stages/shot-detect      -- bulk shot detection on every eligible stage
  POST /api/stages/{n}/videos/{vid}/detect-beep -- per-video beep detection
  POST /api/stages/{n}/videos/{vid}/beep         -- per-video manual override
  POST /api/stages/{n}/videos/{vid}/beep/select  -- per-video candidate select
  POST /api/stages/{n}/videos/{vid}/beep/snap    -- propose a snapped beep near a user hint
  POST /api/stages/{n}/videos/{vid}/trim         -- per-video audit-mode trim
  GET  /api/stages/{n}/videos/{vid}/beep-preview -- per-video ~1s preview MP4
  GET  /api/jobs                    -- list all retained jobs
  GET  /api/jobs/{job_id}           -- poll a single job for progress / status
  POST /api/jobs/{job_id}/cancel    -- cooperative cancel of a running job
  POST /api/jobs/{job_id}/acknowledge      -- dismiss a failed job (issue #73)
  POST /api/jobs/acknowledge-failures      -- dismiss every unacknowledged failure
  GET  /api/stages/{n}/audio        -- serve cached primary WAV (Range supported)
  GET  /api/stages/{n}/peaks?bins=N -- waveform peak data for the audit screen
  GET  /api/stages/{n}/beep-preview -- ~1s MP4 around the detected beep (#27)
  GET  /api/videos/stream?path=...  -- serve a registered video file (Range)
  GET  /api/stages/{n}/audit        -- read the stage's audit JSON (404 if none)
  PUT  /api/stages/{n}/audit        -- atomically write the stage's audit JSON
  GET  /api/fixture/audit?path=...  -- standalone fixture review (read JSON)
  PUT  /api/fixture/audit?path=...  -- standalone fixture review (write JSON)
  GET  /api/fixture/peaks?path=...  -- waveform peaks for a fixture's sibling WAV
  GET  /api/fixture/audio?path=...  -- serve the fixture's sibling WAV (Range)
  GET  /api/fixture/video?path=...  -- serve a fixture-bound video file (Range)
  GET  /api/user/recent-projects    -- recently-opened MatchProject roots (#75)
  POST /api/user/recent-projects/forget -- drop one entry from the list
  POST /api/user/recent-projects/bind   -- switch the in-memory project
  POST /api/user/recent-projects/unbind -- drop the bound project (back to picker)
  GET  /api/user/scoreboard-identity -- saved SSI identity (404 if none)
  PUT  /api/user/scoreboard-identity -- write the SSI identity

Design notes:
- Localhost only. No auth, no CORS configuration beyond what Vite needs in dev.
- The server holds at most one ``MatchProject`` open at a time. The
  binding can be set at startup (``--project``) or chosen at runtime via
  the SPA picker (POST /api/user/recent-projects/bind). When unbound,
  every project-bound endpoint returns 409 ``no_project`` and the SPA
  redirects to its picker route. Multi-project orchestration lives in
  the SPA.
- All on-disk mutations go through the project model's atomic save.
- The server re-loads the project from disk for every request (no caching), so
  external edits are visible without restart.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from collections.abc import Callable
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any, Literal

from fastapi import Body, FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from starlette.background import BackgroundTask

from .. import __version__ as splitsmith_version
from .. import automation as automation_settings
from .. import backup as backup_mod
from .. import beep_detect, cross_align, match_model, report, user_config, video_probe
from .. import cleanup as cleanup_module
from .. import coach as coach_module
from .. import coach_distributions as coach_distributions_module
from .. import ensemble as ensemble_module
from .. import shot_detect as shot_detect_module  # noqa: F401  (kept for legacy monkeypatch points)
from .. import thumbnail as thumbnail_helpers
from .. import waveform as waveform_helpers
from ..config import (
    BeepDetectConfig,
    CoachAutoClassifyConfig,
    Config,
    IntervalClass,
    IntervalClassSource,
    StageRounds,
)
from ..fixture_schema import (
    AgcState,
    AudioSource,
    Camera,
    CameraMount,
    CameraPosition,
    probe_camera_metadata,
)
from ..match_registry import MatchRegistry
from ..runtime import runtime as process_runtime
from . import audio as audio_helpers
from . import exports as export_helpers
from . import match_exports as match_export_helpers
from .jobs import Job, JobCancelled, JobHandle, JobRegistry, ShutdownInProgressError
from .project import (
    VIDEO_EXTENSIONS,
    MatchProject,
    ScoreboardImportConflictError,
    StageEntry,
    StageVideo,
    VideoRole,
)
from .scoreboard import (
    CachingScoreboardClient,
    CompetitorNotInMatch,
    LocalJsonScoreboard,
    MatchNotFound,
    ScoreboardAuthError,
    ScoreboardClient,
    ScoreboardError,
    ScoreboardRateLimited,
    ScoreboardUpstreamError,
    ShooterNotFound,
    SsiHttpClient,
    StageTimesNotImplemented,
    StageTimesUnavailable,
)
from .scoreboard.local import DEFAULT_MATCH_FILENAME, DEFAULT_SCOREBOARD_DIRNAME


def _ensure_source_reachable(stage_number: int | None, source: Path) -> None:
    """Raise a structured 424 when ``source`` doesn't exist on disk.

    The SPA reads ``detail.code == "source_unreachable"`` to render a
    uniform "reconnect the USB / SD card" message wherever a source-bound
    operation is invoked (detect-beep, audit-mode trim, beep preview,
    video stream, export). Callers handle the "no primary" check with
    their endpoint-specific status code before calling this -- the helper
    only handles the upstream-dependency-offline case.
    """
    if source.exists():
        return
    raise HTTPException(
        status_code=424,
        detail={
            "code": "source_unreachable",
            "stage_number": stage_number,
            "path": str(source),
            "message": (
                "Source video"
                + (f" for stage {stage_number}" if stage_number is not None else "")
                + f" is not reachable: {source}. If it lives on external "
                f"storage (USB drive, SD card), reconnect and try again."
            ),
        },
    )


def _cancellable_runner(handle: JobHandle):
    """Build a ``trim.Runner`` that registers ffmpeg with the job for cancel.

    Mirrors the ``subprocess.run(check=True, capture_output=True)`` shape
    that :func:`splitsmith.trim.trim_video` expects, but uses ``Popen`` so
    the registry can ``terminate()`` ffmpeg the moment a cancel arrives.
    Without this the worker thread sits inside ``proc.wait()`` until the
    whole encode finishes -- a couple of minutes on a 4K Insta360 stage.
    """

    def runner(cmd, *, check=True, capture_output=True, text=True, **kwargs):
        stdout_arg = subprocess.PIPE if capture_output else None
        stderr_arg = subprocess.PIPE if capture_output else None
        proc = subprocess.Popen(  # noqa: S603 -- argv is constructed by us
            cmd,
            stdout=stdout_arg,
            stderr=stderr_arg,
            text=text,
            **kwargs,
        )
        try:
            handle.attach_subprocess(proc)
            try:
                stdout, stderr = proc.communicate()
            finally:
                handle.detach_subprocess()
        except JobCancelled:
            # attach_subprocess terminated the proc when the cancel
            # arrived before we could attach -- reap it so we don't leak
            # a zombie, then propagate. Use a short wait to bound the
            # impact if the child is wedged in uninterruptible I/O.
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            raise
        if check and proc.returncode != 0:
            # When the registry terminated ffmpeg as part of a cancel,
            # surface the cancel rather than the noisy non-zero exit.
            if handle.is_cancel_requested():
                raise JobCancelled()
            raise subprocess.CalledProcessError(proc.returncode, cmd, output=stdout, stderr=stderr)
        return subprocess.CompletedProcess(
            args=cmd,
            returncode=proc.returncode,
            stdout=stdout,
            stderr=stderr,
        )

    return runner


logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent.parent / "ui_static" / "dist"
UI_SOURCE_DIR = Path(__file__).parent.parent / "ui_static"


def _ensure_ui_built() -> None:
    """Rebuild the SPA bundle if missing or older than any tracked source file.

    Without this, ``splitsmith ui`` happily serves a stale ``dist/`` from a
    previous build, so source edits never reach the browser. We compare
    mtimes of every file under ``ui_static/src/`` (plus the manifests that
    affect the build) against the newest file in ``dist/``; if anything is
    newer, run ``npm run build``. ``node_modules/`` and ``dist/`` itself are
    excluded.

    No-op when ``npm`` isn't on PATH (the user might be in a deploy environment
    that ships dist/ separately) -- log a warning and serve whatever's there.
    """
    src_dir = UI_SOURCE_DIR / "src"
    if not src_dir.exists():
        return  # not a development checkout
    tracked: list[Path] = []
    tracked.extend(src_dir.rglob("*"))
    for manifest in (
        "package.json",
        "package-lock.json",
        "vite.config.ts",
        "tsconfig.json",
        "tsconfig.app.json",
        "tsconfig.node.json",
        "tailwind.config.js",
        "postcss.config.js",
        "index.html",
    ):
        p = UI_SOURCE_DIR / manifest
        if p.exists():
            tracked.append(p)
    src_mtime = max(
        (p.stat().st_mtime for p in tracked if p.is_file()),
        default=0.0,
    )

    dist_index = STATIC_DIR / "index.html"
    dist_mtime = (
        min(
            (p.stat().st_mtime for p in STATIC_DIR.rglob("*") if p.is_file()),
            default=0.0,
        )
        if dist_index.exists()
        else 0.0
    )

    if dist_index.exists() and dist_mtime >= src_mtime:
        return  # already up to date

    npm = shutil.which("npm")
    if npm is None:
        logger.warning("ui_static/dist appears stale but npm is not on PATH; serving whatever is in dist/")
        return

    logger.info(
        "Rebuilding SPA bundle (dist mtime %.0f < source %.0f)...",
        dist_mtime,
        src_mtime,
    )
    try:
        subprocess.run(
            [npm, "run", "build"],
            cwd=UI_SOURCE_DIR,
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        logger.error("npm run build failed (exit %d); serving stale bundle", exc.returncode)


def _now_iso() -> str:
    """ISO-8601 UTC timestamp for audit_events entries."""
    return datetime.now(UTC).isoformat()


def _load_env_files(project_root: Path | None = None) -> list[Path]:
    """Pick up ``.env.local`` then ``.env`` from the project root, the cwd
    the user launched the server from, and the global user-config dir.

    ``project_root`` is optional so the unbound boot path (picker /
    create-match flow) can still pull ``SPLITSMITH_SSI_TOKEN`` from
    ``<cwd>/.env.local`` or ``<user_config_dir>/.env.local`` -- the
    scoreboard search endpoint needs it before any project exists.

    ``SPLITSMITH_SSI_TOKEN`` (and any other ``SPLITSMITH_*`` env var) lives
    in one of these files for typical setups; without this hook the token
    only works if the user remembered to ``export`` it before launching
    ``splitsmith ui``.

    Search order (process env always wins via ``override=False``; the
    first file to define a key keeps it):

    1. ``<project_root>/.env`` -- shared per-project defaults
    2. ``<project_root>/.env.local`` -- per-machine secret, gitignored
    3. ``<cwd>/.env``           -- repo / launch-dir shared default
    4. ``<cwd>/.env.local``     -- repo / launch-dir per-machine secret
    5. ``<user_config_dir>/.env`` -- global per-user default
    6. ``<user_config_dir>/.env.local`` -- global per-user secret (#75)

    The user-config layer is the natural home for the SSI API token,
    which is per-user rather than per-project; per-project settings still
    win because they're loaded earlier.
    Duplicate paths (when the user runs from inside the project directory,
    or sets ``SPLITSMITH_HOME`` to one of the other locations) are loaded
    once.
    """
    try:
        from dotenv import load_dotenv
    except ImportError:
        return []

    candidates: list[Path] = []
    seen: set[Path] = set()
    bases: list[Path] = []
    if project_root is not None:
        bases.append(project_root.resolve())
    bases.append(Path.cwd().resolve())
    if not user_config.is_disabled():
        bases.append(user_config.user_config_dir())
    for base in bases:
        for name in (".env", ".env.local"):
            try:
                candidate = (base / name).resolve()
            except OSError:
                continue
            if candidate in seen:
                continue
            seen.add(candidate)
            if candidate.is_file():
                candidates.append(candidate)

    for path in candidates:
        load_dotenv(path, override=False)
    return candidates


class _ScoreboardClientCtx:
    """Context-manager wrapper so Local + HTTP-backed clients close cleanly.

    The protocol doesn't require ``close()``, but the HTTP client owns an
    ``httpx.Client`` we want to release per request. Local clients are a
    no-op. The wrapper proxies the four protocol methods only -- callers
    must not poke at internal types.
    """

    def __init__(
        self,
        inner: ScoreboardClient,
        *,
        owns_close: bool,
        inner_http: SsiHttpClient | None = None,
    ) -> None:
        self._inner = inner
        self._owns_close = owns_close
        self._inner_http = inner_http

    def __enter__(self) -> ScoreboardClient:
        return self._inner

    def __exit__(self, *_exc: object) -> None:
        if self._owns_close and self._inner_http is not None:
            self._inner_http.close()


class _NoOpClient:
    """Inner stub so ``CachingScoreboardClient`` can be instantiated for cache
    invalidation alone (no upstream call expected). All four protocol methods
    raise -- callers shouldn't reach them when only ``invalidate_*`` is used.
    """

    def search_matches(self, query: str):  # type: ignore[no-untyped-def]
        raise RuntimeError("_NoOpClient.search_matches: cache-invalidate only")

    def get_match(self, content_type: int, match_id: int):  # type: ignore[no-untyped-def]
        raise RuntimeError("_NoOpClient.get_match: cache-invalidate only")

    def find_shooter(self, name: str):  # type: ignore[no-untyped-def]
        raise RuntimeError("_NoOpClient.find_shooter: cache-invalidate only")

    def get_shooter(self, shooter_id: int):  # type: ignore[no-untyped-def]
        raise RuntimeError("_NoOpClient.get_shooter: cache-invalidate only")

    def get_stage_times(  # type: ignore[no-untyped-def]
        self, content_type: int, match_id: int, competitor_id: int
    ):
        raise RuntimeError("_NoOpClient.get_stage_times: cache-invalidate only")


def _raise_scoreboard_http(exc: ScoreboardError) -> None:
    """Translate a typed ``ScoreboardError`` into the right HTTP status.

    Codes are stable so the SPA can match on ``detail.code`` regardless of
    the human message. Banner copy lives client-side; we ship the message
    + retry hint, not the rendered string.
    """
    if isinstance(exc, ScoreboardAuthError):
        raise HTTPException(
            status_code=401,
            detail={
                "code": "scoreboard_auth",
                "message": str(exc),
                "env_var": "SPLITSMITH_SSI_TOKEN",
                "docs_url": "https://github.com/mandakan/ssi-scoreboard/blob/main/docs/api-v1.md",
            },
        )
    if isinstance(exc, ScoreboardRateLimited):
        raise HTTPException(
            status_code=429,
            detail={
                "code": "scoreboard_rate_limited",
                "message": str(exc),
                "retry_after": exc.retry_after,
            },
        )
    if isinstance(exc, ScoreboardUpstreamError):
        raise HTTPException(
            status_code=502,
            detail={
                "code": "scoreboard_offline",
                "message": str(exc),
            },
        )
    if isinstance(exc, StageTimesNotImplemented):
        raise HTTPException(
            status_code=502,
            detail={
                "code": "stage_times_blocked_on_upstream",
                "message": str(exc),
                "upstream_issue": "ssi-scoreboard#400",
                "upstream_url": "https://github.com/mandakan/ssi-scoreboard/issues/400",
            },
        )
    if isinstance(exc, StageTimesUnavailable):
        raise HTTPException(
            status_code=400,
            detail={
                "code": "stage_times_offline_pure_matchdata",
                "message": str(exc),
            },
        )
    if isinstance(exc, ShooterNotFound):
        raise HTTPException(status_code=404, detail=str(exc))
    if isinstance(exc, CompetitorNotInMatch):
        raise HTTPException(
            status_code=404,
            detail={
                "code": "competitor_not_in_match",
                "message": str(exc),
            },
        )
    raise HTTPException(status_code=500, detail=str(exc))


_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "::1", "localhost", "testclient"})


def _is_loopback(request: Request) -> bool:
    """Reject /api/shutdown from non-loopback callers.

    ``testclient`` is included so the TestClient ASGI shim works in
    pytest without a real socket; it's a value set by the server side
    (the ASGI scope) so a remote caller can't spoof it.
    """
    client = request.client
    if client is None:
        return False
    return client.host in _LOOPBACK_HOSTS


def _no_project_error() -> HTTPException:
    """Raised by :class:`AppState` when an endpoint that needs a bound
    project is hit while the server is in unbound (picker) mode.

    The SPA inspects ``detail.code == "no_project"`` to redirect to the
    picker route instead of rendering a generic error.
    """
    return HTTPException(
        status_code=409,
        detail={
            "code": "no_project",
            "message": (
                "No project is currently open. Pick one from the project "
                "list (POST /api/user/recent-projects/bind) or restart "
                "with `splitsmith ui --project <path>`."
            ),
        },
    )


# Per-request match root resolved by the ``/api/matches/{match_id}/...``
# alias middleware (#353 Phase 3 PR C). When set, ``AppState.shooter_root``
# reads from here instead of the process singleton -- which means two
# concurrent requests carrying different match ids resolve to their own
# match roots without fighting over ``state._bound_root``. The singleton
# is kept as a fallback for legacy bare-path traffic + picker UX; it can
# go away entirely once every endpoint is exercised under the new prefix.
current_match_root: ContextVar[Path | None] = ContextVar("splitsmith_current_match_root", default=None)
current_match_id: ContextVar[str | None] = ContextVar("splitsmith_current_match_id", default=None)


@dataclass
class AppState:
    """Process state. One bound project at a time (#353).

    A bound project is either a **Match folder** (multi-shooter) or a
    **legacy single-shooter project**. The two layouts share a single
    state record but expose different resolution paths:

    - Match-level operations (list shooters, merge, export the whole
      match) read :attr:`match_root` directly.
    - Shooter-scoped operations require a slug from the URL path and
      resolve via :meth:`shooter_root` / :meth:`shooter_project`.

    There is no notion of an "active" or "current" shooter on the
    server. Every shooter-scoped request must carry the slug in its
    path; the SPA's URL is the single source of truth.

    The server can boot without a bound project (``splitsmith ui`` with
    no ``--project``); in that mode every scoped property raises 409
    ``no_project`` and the SPA stays on the picker.
    """

    _bound_root: Path | None = None
    _bound_kind: Literal["match", "legacy"] | None = None
    _bound_name: str | None = None
    _bound_match_id: str | None = None
    jobs: JobRegistry = field(default_factory=JobRegistry)
    matches: MatchRegistry = field(default_factory=MatchRegistry)
    # Stop callback registered by :func:`splitsmith.ui.embedded.run_embedded`
    # so the /api/shutdown route can ask uvicorn to exit. None under the
    # ``splitsmith ui`` CLI path -- Ctrl-C via _JobAwareServer.handle_exit
    # is the stop mechanism there.
    shutdown_handler: Callable[[], None] | None = None
    # Idempotency latch for /api/shutdown: first call kicks the drain
    # thread, subsequent calls return 202 without rescheduling.
    shutdown_initiated: bool = False

    @property
    def is_bound(self) -> bool:
        return self._bound_root is not None

    @property
    def bound_kind(self) -> Literal["match", "legacy"] | None:
        return self._bound_kind

    @property
    def bound_name(self) -> str | None:
        return self._bound_name

    @property
    def bound_root(self) -> Path:
        """The bound project's on-disk root (match folder OR legacy project)."""
        if self._bound_root is None:
            raise _no_project_error()
        return self._bound_root

    @property
    def match_root(self) -> Path:
        """The bound match folder. 409 ``not_a_match`` for legacy projects."""
        if self._bound_root is None:
            raise _no_project_error()
        if self._bound_kind != "match":
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "not_a_match",
                    "message": (
                        "Bound project is a legacy single-shooter layout. "
                        "Match-level operations require a Match folder."
                    ),
                },
            )
        return self._bound_root

    def shooter_root(self, slug: str) -> Path:
        """Resolve ``slug`` to the shooter's project directory on disk.

        For a Match folder: validates the slug is registered and the
        directory exists, then returns ``<match>/shooters/<slug>``.

        For a legacy single-shooter project: there is exactly one shooter
        and its data lives at the bound root. The slug is accepted as-is
        (the SPA derives it from ``competitor_name`` via :func:`legacy_slug`)
        so callers don't need to special-case the legacy layout.

        Resolution order (#353 Phase 3 PR C):

        1. ``current_match_root`` ContextVar -- set by the
           ``/api/matches/{match_id}/...`` alias middleware. This is the
           per-request path; multiple tabs on different matches stay
           isolated because each request carries its own context.
        2. ``self._bound_root`` -- the legacy singleton. Kept as a
           fallback for legacy bare ``/api/shooters/{slug}/...`` traffic
           (clients that haven't migrated to the new prefix yet) and for
           the picker boot path.
        """
        scoped_root = current_match_root.get()
        if scoped_root is not None:
            # Per-request scope is always a Match folder (the middleware
            # rejects legacy projects upstream). Validate the slug and
            # resolve under that root, ignoring the singleton.
            match = match_model.Match.load(scoped_root)
            if slug not in match.shooters:
                raise HTTPException(
                    status_code=404,
                    detail=f"shooter {slug!r} is not registered on this match",
                )
            return match_model.Match.shooter_root(scoped_root, slug)
        if self._bound_root is None:
            raise _no_project_error()
        if self._bound_kind == "legacy":
            return self._bound_root
        match = match_model.Match.load(self._bound_root)
        if slug not in match.shooters:
            raise HTTPException(
                status_code=404,
                detail=f"shooter {slug!r} is not registered on this match",
            )
        return match_model.Match.shooter_root(self._bound_root, slug)

    def shooter_project(self, slug: str) -> MatchProject:
        """Load the legacy ``MatchProject`` for ``slug``."""
        return MatchProject.load(self.shooter_root(slug))

    @property
    def bound_match_id(self) -> str | None:
        """The bound match's stable id, or ``None`` when unbound / legacy."""
        return self._bound_match_id

    def bind_match(self, root: Path, name: str) -> None:
        self._bound_root = root
        self._bound_kind = "match"
        self._bound_name = name
        # Load to ensure ``match_id`` is materialised (Match.load runs the
        # v3 -> v4 migration on the fly), then pin it into the registry so
        # the id resolves immediately even before the next recents refresh.
        match = match_model.Match.load(root)
        self._bound_match_id = match.match_id
        if match.match_id:
            self.matches.register(match.match_id, root)

    def bind_legacy(self, root: Path, name: str) -> None:
        self._bound_root = root
        self._bound_kind = "legacy"
        self._bound_name = name
        self._bound_match_id = None

    def unbind(self) -> None:
        self._bound_root = None
        self._bound_kind = None
        self._bound_name = None
        self._bound_match_id = None


def legacy_slug(project: MatchProject) -> str:
    """Synthesise a shooter slug for a legacy single-shooter project.

    Legacy projects predate the Match -> Shooter split; their on-disk
    layout has no ``shooters/<slug>/`` subdir. To keep every shooter-
    scoped URL slug-bearing (no second URL family for legacy projects),
    we mint a deterministic *opaque* slug from the project's metadata
    (name + scoreboard ids) so the URL is stable across reloads but
    doesn't carry the competitor name. The SPA reads it via
    ``/api/health.default_shooter_slug`` after binding.
    """
    return match_model._legacy_view_slug(project)


def _any_active_job(state: AppState) -> Job | None:
    """Return the first PENDING/RUNNING job, or None.

    Used by destructive endpoints (cleanup) to refuse running while
    workers are mid-flight. ``find_active`` on the registry is
    kind-scoped; this helper scans every kind so a beep job blocks a
    cleanup just as a trim does.
    """
    from .jobs import JobStatus

    for job in state.jobs.list():
        if job.status in (JobStatus.PENDING, JobStatus.RUNNING):
            return job
    return None


# Module-level cache for the 4-voter ensemble runtime (issue #31). Heavy
# (CLAP ~600 MB, PANN ~80 MB), so it is loaded on the first shot-detect
# call and reused for subsequent calls. The threading lock guards against
# two shot-detect jobs colliding on first init when the model weights
# haven't downloaded yet.
_ENSEMBLE_RUNTIME: ensemble_module.EnsembleRuntime | None = None
_ENSEMBLE_RUNTIME_LOCK = threading.Lock()


def _trim_wav_to_clip(src_wav: Path, dst_wav: Path, start_s: float, end_s: float) -> None:
    """Cut ``src_wav`` to ``[start_s, end_s)`` and write to ``dst_wav``.

    Used by promote-secondary so the derived fixture's audio matches the
    "fixture is clip-local" convention shared with primary fixtures.
    Re-encodes (PCM s16 / mono / 48 kHz) so the output is a stable WAV
    regardless of the source codec.
    """
    ffmpeg_bin = process_runtime().ffmpeg_binary
    if not shutil.which(ffmpeg_bin):
        raise RuntimeError(f"ffmpeg binary not found: {ffmpeg_bin}")
    duration = max(0.0, end_s - start_s)
    cmd = [
        ffmpeg_bin,
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-ss",
        f"{start_s:.3f}",
        "-i",
        str(src_wav),
        "-t",
        f"{duration:.3f}",
        "-ac",
        "1",
        "-ar",
        "48000",
        "-c:a",
        "pcm_s16le",
        str(dst_wav),
    ]
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(
            f"ffmpeg trim failed (exit {exc.returncode}): {exc.stderr or exc.stdout!r}"
        ) from exc


def _get_ensemble_runtime() -> ensemble_module.EnsembleRuntime:
    """Lazy-load + cache the ensemble runtime; thread-safe.

    Test code monkeypatches this function (and
    ``ensemble_module.detect_shots_ensemble``) to avoid pulling the heavy
    model weights into the test process.

    Voter E (issue #183) adds a CLIP image-encoder load on top of the
    existing CLAP/PANN/GBDT models. Skip it unless the operator has
    opted in via ``SPLITSMITH_ENABLE_VOTER_E=1`` so the default install
    doesn't pay ~600 MB of memory and the first-call download.
    """
    global _ENSEMBLE_RUNTIME
    if _ENSEMBLE_RUNTIME is None:
        with _ENSEMBLE_RUNTIME_LOCK:
            if _ENSEMBLE_RUNTIME is None:
                with_voter_e = os.environ.get("SPLITSMITH_ENABLE_VOTER_E") == "1"
                _ENSEMBLE_RUNTIME = ensemble_module.load_ensemble_runtime(with_voter_e=with_voter_e)
    return _ENSEMBLE_RUNTIME


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str = splitsmith_version
    bound: bool
    project_name: str | None = None
    project_root: str | None = None
    # Stable match identifier (issue #353 Phase 3 PR A). ``None`` when
    # unbound or bound to a legacy single-shooter project. The SPA will
    # start scoping URLs on this in a follow-up PR.
    match_id: str | None = None
    # Layout discriminator + a default slug for shooter-scoped URLs (#353).
    # Match-bound: the alphabetically-first registered shooter, or ``None``
    # when the match is empty. Legacy-bound: the deterministic legacy slug.
    # Lets the SPA build /audit/<slug>/... links from any slugless surface
    # (Home, sidebar Audit/Coach/Export rows) without forcing the user to
    # pick a shooter when there's only one sensible default.
    kind: str | None = None  # "match" | "legacy" | None when unbound
    default_shooter_slug: str | None = None


class PromoteSecondaryBody(BaseModel):
    """Body for the project-aware promote-secondary endpoint.

    Defined at module scope (not inside the lab-route factory) so FastAPI
    can resolve the forward reference under ``from __future__ import
    annotations``.
    """

    mount: str
    position: str
    audio_source: str = "internal"
    agc_state: str = "unknown"
    snap_window_ms: float = 60.0
    min_spacing_ms: float = 80.0
    slug: str | None = None
    camera_id: str | None = None
    overwrite: bool = False


class PromoteAgainstFixtureBody(BaseModel):
    """Body for ``/api/lab/projects/.../promote-against-fixture`` (issue #149 follow-up).

    Like :class:`PromoteSecondaryBody` but the anchor comes from an
    explicit fixture slug rather than being derived from the project's
    name + stage number. Lets the user anchor *any* project video
    (primary or secondary) against any existing fixture -- the typical
    case is a phone-cam-only project anchored against a previously
    audited headcam fixture.
    """

    anchor_slug: str
    mount: str
    position: str
    audio_source: str = "internal"
    agc_state: str = "unknown"
    snap_window_ms: float = 60.0
    min_spacing_ms: float = 80.0
    slug: str | None = None
    camera_id: str | None = None
    overwrite: bool = False


class RecentProjectDetail(BaseModel):
    """Enriched RecentProject for the redesigned match picker (#322).

    Mirrors :class:`user_config.RecentProject` plus derived metadata read
    from disk at listing time. ``kind`` is ``"match"`` for a redesign-era
    Match folder, ``"legacy"`` for a single-shooter project, ``"missing"``
    when the path no longer exists, ``"unknown"`` for an existing path that
    is neither.

    Derived fields are best-effort: a stale or unreadable project still
    shows up with ``kind="unknown"`` so the user can find and remove it
    rather than silently disappearing.
    """

    path: str
    name: str
    last_opened_at: datetime
    kind: Literal["match", "legacy", "missing", "unknown"]
    # Stable match identifier (#353 Phase 3). Populated for ``kind="match"``
    # via the load-time migration; ``None`` on legacy / missing / unknown.
    match_id: str | None = None
    # The five fields below only populate for resolved kinds.
    shooter_count: int = 0
    stage_count: int = 0
    stages_audited: int = 0
    match_date: str | None = None
    club: str | None = None
    last_modified_at: datetime | None = None
    status: Literal["in_progress", "exported", "archived", "unknown"] = "unknown"
    # ``True`` for matches the user created without scoreboard data --
    # surfaces the "manual" pill in the polished picker.
    manual: bool = False
    # Human-readable shooter names in match order so the picker can
    # render real initials in avatar stacks instead of stubs.
    shooter_names: list[str] = []


class CreateMatchStageDraft(BaseModel):
    """One row of the manual-create stage editor."""

    stage_number: int
    stage_name: str
    expected_rounds: int | None = None
    target_type: str | None = None


class CreateMatchPrimaryShooter(BaseModel):
    """Primary-shooter section of the manual-create form."""

    name: str
    division: str | None = None


class CreateMatchManualRequest(BaseModel):
    """Body for POST /api/match/create-manual (#322).

    Scaffolds a Match folder with the supplied stages + the primary shooter
    registered. The first shooter's directory is bound on success so the
    rest of the server (which still speaks legacy ``MatchProject``) keeps
    working unchanged.
    """

    name: str
    project_folder: str
    match_date: date | None = None
    club: str | None = None
    match_type: str | None = None
    default_division: str | None = None
    stages: list[CreateMatchStageDraft]
    primary_shooter: CreateMatchPrimaryShooter


class CreateMatchCompetitorPick(BaseModel):
    """One competitor the user is bringing into the new match (#322).

    ``selected_competitor_id`` is the per-match id (needed for the
    stage-times lookup). ``selected_shooter_id`` is the global stable
    SSI id; both are kept so refresh-by-name works later. Picks are
    treated equally -- there is no "me" or "primary" flag because the
    operator running the app may be coaching and not a shooter at all
    (see issue #350 / ``feedback_operator_vs_shooter``).
    """

    name: str
    division: str | None = None
    selected_shooter_id: int | None = None
    selected_competitor_id: int


class CreateMatchScoreboardRequest(BaseModel):
    """Body for POST /api/match/create-from-scoreboard (#322).

    Scaffolds a Match folder named after the upstream match, creates
    one shooter per :class:`CreateMatchCompetitorPick`, populates
    stage definitions from the upstream ``MatchData``, pins each
    competitor, and merges stage times -- all in one round trip so
    the create flow lands the user on a fully-populated match.
    """

    project_folder: str
    name: str
    match_id: int
    content_type: int
    competitors: list[CreateMatchCompetitorPick]


class ShooterCameraInfo(BaseModel):
    """One camera entry for a shooter, derived from per-stage primaries (#324)."""

    # Stable id grouping = ``camera_make|camera_model|camera_mount``; the
    # SPA renders ordered labels (Camera A / B / ...) per shooter.
    group_key: str
    make: str | None
    model: str | None
    mount: str | None
    role: Literal["primary", "secondary"]
    video_count: int
    stage_numbers: list[int]


class ShooterListEntry(BaseModel):
    """One row of GET /api/match/shooters (#324)."""

    slug: str
    name: str
    selected_shooter_id: int | None
    selected_competitor_id: int | None
    stages_audited: int
    stages_total: int
    video_count: int
    cameras: list[ShooterCameraInfo]
    # Stages where the primary has a beep + stage time set but no audit-mode
    # trim cache MP4 on disk. Drives the "Rebuild trim caches (N)" CTA on
    # the Shooters page (#351). Counts only stages where rebuild is possible
    # (primary + beep + stage_time + reachable source); stages missing those
    # prerequisites are excluded from the count.
    stages_missing_trim: int = 0


class ShooterListResponse(BaseModel):
    """GET /api/match/shooters payload (#324)."""

    match_root: str
    match_name: str
    shooters: list[ShooterListEntry]


class AddShooterRequest(BaseModel):
    """POST /api/match/shooters body (#324)."""

    name: str
    division: str | None = None


class CompareShotPoint(BaseModel):
    """One shot for a shooter on a stage (#328 timeline)."""

    shot_number: int
    time_after_beep: float  # seconds since beep (primary stage clock)
    source: Literal["detected", "manual"]


class CompareShooterRecord(BaseModel):
    """One shooter's data for a stage (#328 multi-shooter timeline)."""

    slug: str
    name: str
    # Path to the lossless trim clip on disk; the SPA streams via
    # GET /api/match/shooters/{slug}/videos/stream?path=...
    video_path: str | None
    # Trim is per-shooter and starts at ``beep_offset_in_clip`` seconds
    # before the beep; SPA uses this to sync all clips to time-since-beep.
    beep_offset_in_clip: float | None
    duration_seconds: float | None
    stage_time_seconds: float | None
    shots: list[CompareShotPoint]


class CompareStageResponse(BaseModel):
    """GET /api/match/stage/{stage_number}/compare payload (#328)."""

    stage_number: int
    stage_name: str
    shooters: list[CompareShooterRecord]


class BeepQueueAltCandidate(BaseModel):
    """One alternative beep candidate carried on a queue item (#326)."""

    time: float
    confidence: float | None


class BeepQueueItem(BaseModel):
    """One pending beep review item (#326)."""

    slug: str
    shooter_name: str
    stage_number: int
    stage_name: str
    video_id: str
    video_path: str
    beep_time: float | None
    beep_confidence: float | None
    beep_reviewed: bool
    status: Literal["missing", "low_confidence", "unreviewed", "confirmed"]
    alt_candidates: list[BeepQueueAltCandidate]
    # Auto-computed cross-align suggestion for secondaries lives on the
    # shooter's other videos; the SPA fetches them lazily if needed.


class BeepQueueStageGroup(BaseModel):
    """All pending beep items for a single stage, across shooters (#326)."""

    stage_number: int
    stage_name: str
    items: list[BeepQueueItem]
    total_primaries: int
    confirmed: int


class BeepQueueResponse(BaseModel):
    """GET /api/match/beep-queue payload (#326)."""

    total_items: int
    pending_count: int
    confirmed_count: int
    stages: list[BeepQueueStageGroup]


class BeepQueueConfirmRequest(BaseModel):
    """POST /api/match/beep-queue/confirm body (#326)."""

    slug: str
    stage_number: int
    video_id: str
    # The user-confirmed beep time. When None the existing detected beep
    # is kept and only ``reviewed`` flips to True.
    time: float | None = None
    source: Literal["detected", "manual", "alt"] = "detected"


class MergePlanShooterMove(BaseModel):
    """One source legacy project routed into a shooter slot in the planned
    merge. Mirrors :class:`match_model.ShooterMove` with paths as strings
    for the JSON wire."""

    source_root: str
    slug: str
    destination_root: str
    competitor_name: str


class MergePlanStage(BaseModel):
    """One reconciled stage in the planned merge."""

    stage_number: int
    stage_name: str
    expected_rounds: int | None = None
    placeholder: bool = False


class MergePlanRequest(BaseModel):
    """POST /api/match/merge/plan body (#332)."""

    inputs: list[str]
    output: str | None = None
    name: str | None = None


class MergePlanResponse(BaseModel):
    """Successful response from /api/match/merge/plan. Conflicts come back
    as HTTP 409 with the conflict message in ``detail``; this model only
    describes the *valid* outcome the user is being asked to confirm."""

    output_root: str
    name: str
    scoreboard_match_id: str | None
    scoreboard_content_type: int | None
    match_date: str | None
    stages: list[MergePlanStage]
    shooter_moves: list[MergePlanShooterMove]


class MergeExecuteRequest(BaseModel):
    """POST /api/match/merge/execute body."""

    inputs: list[str]
    output: str
    name: str | None = None
    move: bool = False


class DeveloperStepCounts(BaseModel):
    """Counts shown on each step of the dev-mode workflow stepper.

    The ``validate_runs`` field is named to avoid shadowing
    ``BaseModel.validate``; the SPA exposes it as ``step_counts.validate_runs``.
    """

    corpus: int
    review: int
    validate_runs: int
    retrain: int


class DeveloperModelInfo(BaseModel):
    """Active ensemble + workflow status. Drives the dev-shell model chip
    and the per-step counter badges on the sidebar."""

    active_version: str
    recall: float
    precision: float | None
    f1: float | None
    fixture_count: int
    built_at: str | None = None
    step_counts: DeveloperStepCounts


class DevReviewQueueItem(BaseModel):
    """One queue row for the dev review surface."""

    slug: str
    audit_path: str
    source: Literal["match", "github", "ad-hoc"]
    source_label: str
    status: Literal["pending", "flagged", "done"]
    n_shots: int
    n_disagreements: int
    promoted_at: str | None = None
    venue: str | None = None
    stage_number: int | None = None
    shooter: str | None = None
    age_seconds: int | None = None


class DevReviewQueueResponse(BaseModel):
    pending: list[DevReviewQueueItem]
    flagged: list[DevReviewQueueItem]
    done: list[DevReviewQueueItem]


class BindRecentProjectRequest(BaseModel):
    """Body for POST /api/user/recent-projects/bind.

    The server binds in-memory only; on next launch the user reopens via
    the same picker. ``name`` is optional -- the server reads the
    on-disk display name from ``project.json`` when available.
    ``create=true`` opts into scaffolding a brand-new project at ``path``
    (mkdir + MatchProject.init); the default of ``false`` keeps the
    existing strict "open only" behaviour so a typo can't silently
    create an empty project under a wrong path.
    """

    path: str
    name: str | None = None
    create: bool = False


# Request bodies ----------------------------------------------------------


class ScoreboardImportRequest(BaseModel):
    data: dict[str, Any]
    overwrite: bool = False


class ForgetRecentProjectRequest(BaseModel):
    """Body for POST /api/user/recent-projects/forget (#75)."""

    path: str


class ScoreboardIdentityRequest(BaseModel):
    """Body for PUT /api/user/scoreboard-identity (#75).

    Mirrors :class:`splitsmith.user_config.ScoreboardIdentity`. ``shooter_id``
    is required; everything else is optional so the SPA can save a partial
    identity without forcing the user to fill division / club.
    """

    shooter_id: int
    display_name: str | None = None
    division: str | None = None
    club: str | None = None
    base_url: str | None = None


class ScoreboardUploadRequest(BaseModel):
    """Body for POST /api/scoreboard/upload (#50).

    The SPA reads the dropped file as text, parses it as JSON, and posts
    the dict here. The backend writes it to ``<project>/scoreboard/match.json``
    and uses :class:`LocalJsonScoreboard` to populate the project; the same
    ``MatchData`` shape an online ``get_match`` would return.
    """

    data: dict[str, Any]
    overwrite: bool = False


class ScoreboardFetchRequest(BaseModel):
    """Body for POST /api/scoreboard/fetch (#50).

    Pulls a full match from the live scoreboard (cache-first via
    :class:`CachingScoreboardClient`) and populates the project. When the
    project already has a local ``scoreboard/match.json`` we still honour
    the offline path -- the endpoint refuses with 409 so the user clears
    the local file before falling back to the live source.
    """

    content_type: int
    match_id: int
    overwrite: bool = False


class SelectShooterRequest(BaseModel):
    """Body for POST /api/scoreboard/select-shooter (#64).

    Both ids are required: the SPA picks a shooter from
    ``/api/scoreboard/shooter/search`` (which returns ``shooterId``), then
    looks up the matching ``competitor_id`` in the loaded ``MatchData``
    before posting. Server-side derivation of the competitor id would
    require us to refetch ``MatchData`` here; the SPA already has it.
    """

    shooter_id: int
    competitor_id: int


class PlaceholderStagesRequest(BaseModel):
    """Bootstrap request: create N placeholder stages without a scoreboard."""

    stage_count: int
    match_name: str | None = None
    match_date: date | None = None


class ScanRequest(BaseModel):
    """Either ``source_dir`` (folder scan, current behaviour) or
    ``source_paths`` (explicit list of files, USB-cam workflow). Exactly one
    must be provided."""

    source_dir: str | None = None
    source_paths: list[str] | None = None
    auto_assign_primary: bool = True
    link_mode: str = "symlink"


class ScanResponse(BaseModel):
    registered: list[str]
    auto_assigned: dict[int, str]
    skipped: list[str]


class RelinkScanRequest(BaseModel):
    """Body for POST /api/videos/relink/scan.

    Walks ``search_root`` recursively, indexes videos by basename, and
    matches them against the project's registered ``raw/<name>``
    entries. Pure dry-run: never touches the filesystem.
    """

    search_root: str


class RelinkApplyRequest(BaseModel):
    """Body for POST /api/videos/relink/apply.

    ``decisions`` maps ``video_id`` to the absolute filesystem path the
    user picked (typically one of the candidates returned by the scan
    endpoint, or a manually-typed override). Any video_id not listed is
    left untouched.
    """

    decisions: dict[str, str]


class RelinkEntryResponse(BaseModel):
    video_id: str
    name: str
    link_path: str
    current_target: str | None
    current_status: str
    candidates: list[str]
    chosen_path: str | None
    ambiguous: bool
    found: bool


class RelinkScanResponse(BaseModel):
    search_root: str
    entries: list[RelinkEntryResponse]


class RelinkAppliedEntry(BaseModel):
    video_id: str
    name: str
    link_path: str
    previous_target: str | None
    new_target: str


class RelinkApplyResponse(BaseModel):
    applied: list[RelinkAppliedEntry]


class LinkStatusEntry(BaseModel):
    video_id: str
    name: str
    link_path: str
    current_target: str | None
    status: str


class LinkStatusResponse(BaseModel):
    """Per-video filesystem status for the ``raw/<name>`` symlinks.
    Surfaced separately from ``/api/project`` so we don't pollute the
    persisted ``MatchProject`` model with computed fs state.
    """

    entries: list[LinkStatusEntry]


class SettingsRequest(BaseModel):
    """Partial update for project storage overrides (#23). Any field omitted
    is left unchanged. Pass ``""`` (empty string) to clear an override back to
    the project-root default. Set ``confirm=True`` to acknowledge that any
    existing files in the *old* directories will be left behind (no migration)."""

    raw_dir: str | None = None
    audio_dir: str | None = None
    trimmed_dir: str | None = None
    exports_dir: str | None = None
    probes_dir: str | None = None
    thumbs_dir: str | None = None
    # Audit-mode trim buffers (#15 / #16). Pre = pad before beep,
    # post = pad after stage end. Both must be non-negative.
    trim_pre_buffer_seconds: float | None = None
    trim_post_buffer_seconds: float | None = None
    # Layered automation override (#215). ``None`` keeps the current
    # value; pass an :class:`AutomationOverride`-shaped dict with
    # field values (or nulls) to set / clear individual project-level
    # overrides. The resolved effective value is exposed via
    # ``GET /api/automation``.
    automation: automation_settings.AutomationOverride | None = None
    confirm: bool = False


class MoveRequest(BaseModel):
    video_path: str
    to_stage_number: int | None = None
    role: VideoRole = "secondary"


class BeepOverrideRequest(BaseModel):
    beep_time: float | None  # None clears the override


class StageTimeRequest(BaseModel):
    """Body for POST /api/stages/{n}/time.

    Manual stage-duration entry for projects without scoreboard data.
    ``time_seconds = None`` clears back to placeholder (0.0). Positive
    values are taken as authoritative and stamped with
    ``time_seconds_manual=True`` so a later scoreboard sync won't
    clobber them.
    """

    time_seconds: float | None


class BeepSelectRequest(BaseModel):
    """Body for POST /api/stages/{n}/beep/select.

    ``time`` is matched against ``primary.beep_candidates`` within 1 ms.
    Time-based addressing (rather than an index into the list) is robust
    against the SPA holding a stale candidate snapshot when a concurrent
    trim job re-persists the project: the user picked a *time*, so the
    server should honour that exact pick regardless of where it lands in
    the current list.
    """

    time: float


class BeepReviewRequest(BaseModel):
    """Body for POST /api/stages/{n}/videos/{vid}/beep/review (#71).

    Pure UI-state flag: pipeline doesn't gate on it. Setting ``True``
    requires that ``beep_time`` already exists on the video.
    """

    reviewed: bool


class CameraMountRequest(BaseModel):
    """Body for PATCH /api/stages/{n}/videos/{vid}/camera-mount (#143).

    Override the heuristic ``camera_mount`` stamped at register time.
    Drives the per-camera-class threshold dispatch in the 4-voter
    ensemble. ``mount`` accepts any fixture-schema ``CameraMount``
    string ("head", "chest", "helmet", "belt", "hand", "gimbal",
    "tripod", "monopod") or ``None`` to clear back to the heuristic
    default.
    """

    mount: str | None


class CameraModelRequest(BaseModel):
    """Body for PATCH /api/stages/{n}/videos/{vid}/camera-model (#303-followup).

    Override the ffprobed ``camera_make`` / ``camera_model``. Both must
    be supplied together or both ``None`` (clearing back to the probe
    default). Drives the per-camera-model within-stage amplitude floor
    dispatch (#304) -- known calibrated models get their tuned floor,
    unknown values fall back to the generic-headcam default.
    """

    make: str | None
    model: str | None


class CalibratedCameraModel(BaseModel):
    """One row in the dropdown the SPA presents on the Ingest screen."""

    key: str
    make: str
    model: str
    amp_floor: float


class BeepSnapRequest(BaseModel):
    """Body for POST /api/stages/{n}/videos/{vid}/beep/snap.

    ``hint_time`` is the user's ear-aligned guess (seconds into source).
    ``window_s`` is the half-window the snap is allowed to search inside
    -- defaults to 1.5 s. Wider than the eyeball precision of a click
    on a long-range waveform, narrow enough that competing in-stage
    transients (steel rings, shots) don't enter the candidate pool when
    the marker is anywhere reasonable.
    """

    hint_time: float
    window_s: float = 1.5


class BeepSnapResponse(BaseModel):
    """Result of a snap-to-beep proposal. Stateless -- the SPA decides
    whether to accept (PUT the snapped time as the manual override) or
    dismiss (keep the user's hint)."""

    snapped_time: float
    delta: float
    peak_amplitude: float
    score: float
    duration_ms: float


class ExportStageRequest(BaseModel):
    """Body for POST /api/stages/{n}/export.

    Each toggle defaults True; turning one off skips that artefact while
    leaving the others on. ``write_trim`` produces the lossless stream-copy
    trim into ``<project>/exports/`` -- distinct from the audit-mode
    short-GOP scrub copy in ``<project>/trimmed/``. The FCPXML always
    references the lossless trim so SPA exports match ``splitsmith single``.
    """

    write_trim: bool = True
    write_csv: bool = True
    write_fcpxml: bool = True
    write_report: bool = True
    # Pre-rendered alpha overlay MOV (issue #45). Defaults False because
    # the render is per-frame PIL + ffmpeg -- non-trivially slower than
    # the other writers. The Analysis & Export checkbox opts-in per stage.
    write_overlay: bool = False
    # Overlay format knobs (issue #45 follow-up). Defaults match the
    # legacy ProRes 4444 path on platforms without VideoToolbox; on macOS
    # ``"auto"`` switches to ``hevc-alpha`` (~10-20x smaller). Resolution
    # and fps caps are off by default to preserve frame-for-frame parity
    # with the source clip.
    overlay_codec: Literal["auto", "hevc-alpha", "prores-4444"] = "auto"
    overlay_max_height: int | None = None
    overlay_max_fps: float | None = None
    # Palette preset for the overlay text + stroke. ``"splitsmith"``
    # (default) uses the same tokens the web UI ships, mirrored into
    # ``data/overlay_theme.json``. ``"clean"`` is the neutral
    # white-on-amber alternative.
    overlay_theme: Literal["splitsmith", "clean"] = "splitsmith"
    # Multi-cam selection (issue #54). Allowlist of secondary
    # ``video_id``s to ride the FCPXML / get their own lossless trim. The
    # default ``None`` means "include every secondary with a beep" -- the
    # legacy behaviour. An empty list excludes all secondaries; a non-empty
    # list ships only the named cams (silently dropping any id not on the
    # stage). Cams without a beep are still skipped regardless of selection
    # since they can't be sync-aligned.
    secondary_video_ids: list[str] | None = None


class MatchExportRequest(BaseModel):
    """Body for POST /api/match/export (issue #171).

    Stitches the listed stages into one FCPXML, in the order given. Each
    stage must already have a lossless trim + audit shots (run the per-stage
    export first); the match export composes from those without re-encoding.
    ``head_pad_seconds`` / ``tail_pad_seconds`` are the visible padding
    around the beep / final shot per stage and are clamped server-side to
    the project's pre/post buffer settings (default 5.0s) -- exceeding the
    cap returns 400. ``project_name`` defaults to the bound project's name
    when omitted.
    """

    stage_numbers: list[int]
    head_pad_seconds: float = 5.0
    tail_pad_seconds: float = 5.0
    include_secondaries: bool = True
    include_overlay: bool = True
    # Overlay format knobs forwarded to per-stage re-renders. Match the
    # single-stage defaults so a match export with no overlay edits is
    # byte-comparable with the per-stage export.
    overlay_codec: Literal["auto", "hevc-alpha", "prores-4444"] = "auto"
    overlay_max_height: int | None = None
    overlay_max_fps: float | None = None
    overlay_theme: Literal["splitsmith", "clean"] = "splitsmith"
    project_name: str | None = None
    # Issue #193. ``"stacked"`` keeps secondaries full-frame (today's
    # behaviour). ``"pip-corners"`` adds an ``<adjust-transform>`` to each
    # secondary, rotating through TR -> TL -> BR -> BL at 25% scale.
    pip_layout: Literal["stacked", "pip-corners"] = "stacked"
    # Issue #197. ``"fcpxml"`` writes Final Cut Pro 1.10 (the default).
    # ``"fcp7xml"`` writes a Final Cut Pro 7-style xmeml ``.xml``
    # importable into Premiere Pro and DaVinci Resolve. Issue #174:
    # ``"mp4"`` bakes the stitched composition into a single MP4 via
    # ffmpeg (overlays / PiP burned in, no NLE needed).
    output_format: Literal["fcpxml", "fcp7xml", "mp4"] = "fcpxml"
    # Issue #195. Uniform transition between every consecutive stage
    # pair, or ``"none"`` for hard cuts. Currently only the FCPXML
    # renderer emits transitions; FCP7 / MP4 surface a "transitions
    # ignored" anomaly when set together with those formats.
    transition_kind: Literal["none", "zoom", "static"] = "none"
    transition_duration_seconds: float = 0.5
    # Issue #196. Per-stage title cards. ``"slate"`` adds a pre-stage
    # card on the spine; ``"lower-third"`` is a connected text clip
    # overlaid on the start of the primary. FCPXML only today;
    # FCP7 / MP4 surface a "titles ignored" anomaly when combined.
    title_kind: Literal["none", "slate", "lower-third"] = "none"
    title_duration_seconds: float = 1.5
    # Issue #173. Optional intro / outro video paths. Server expands
    # ``~`` and probes the file to validate frame rate against the
    # timeline. Missing files surface as anomalies; non-fatal so the
    # rest of the export still ships.
    intro_path: str | None = None
    outro_path: str | None = None
    # Issue #204 layer 1. Generate a YouTube-shaped JSON sidecar
    # alongside the export plus a per-shot ``.srt``. FCPXML route
    # also gets chapter markers embedded so they survive an NLE
    # round-trip into an MP4 chapter atom.
    youtube_sidecar: bool = False
    # Issue #204 layer 2. Encode the MP4 with YouTube's recommended
    # H.264 profile / GOP / colour / audio params. Only meaningful for
    # ``output_format == "mp4"``; ignored otherwise (anomaly surfaced).
    youtube_preset: bool = False


class RevealRequest(BaseModel):
    """Body for POST /api/files/reveal.

    Opens the OS file manager at ``path``'s parent, selecting the file when
    the platform supports it (``open -R`` on macOS). The path must resolve
    inside the project root for safety -- we don't expose a generic shell
    out.
    """

    path: str


class SwapPrimaryRequest(BaseModel):
    """Body for POST /api/assignments/swap-primary.

    Promotes ``video_path`` to primary on ``stage_number``. When the stage
    has audit work and ``confirm`` is False, the endpoint refuses with a
    409 response describing what would be lost so the SPA can prompt the
    user. Passing ``confirm=True`` performs the swap and renames the
    existing audit JSON to ``stage<N>.json.bak``.
    """

    video_path: str
    stage_number: int
    confirm: bool = False


class SkipStageRequest(BaseModel):
    """Body for POST /api/stages/{n}/skip. Toggles ``stage.skipped``."""

    skipped: bool


class NudgeDismissRequest(BaseModel):
    """Body for POST /api/project/nudges/dismiss (#218 phase 4).

    The audit-pending reminder shown on stages with empty
    ``shots[]`` but a non-empty candidate pool. ``dismissed=True``
    adds ``stage_number`` to the project's
    ``nudges_dismissed_stages`` list; ``dismissed=False`` clears it
    so the reminder reappears (e.g., the user wants the prompt
    back).
    """

    stage_number: int
    dismissed: bool = True


class CoachShotPatchRequest(BaseModel):
    """Body for PATCH /api/stages/{n}/shots/{shot_number}/coach (issue #161).

    Each field is independently optional. Use ``clear_class`` / ``clear_note``
    to drop a previously-set value. ``interval_class`` and
    ``interval_class_source`` must be set together when present.
    """

    interval_class: IntervalClass | None = None
    interval_class_source: IntervalClassSource | None = None
    clear_class: bool = False
    improvement_flag: bool | None = None
    coaching_note: str | None = None
    clear_note: bool = False


class CleanupRequest(BaseModel):
    """Body for POST /api/project/cleanup.

    The server re-plans server-side from this list rather than trusting a
    client-supplied path list -- a malicious or buggy client cannot ask
    us to delete arbitrary files outside the project's known buckets.
    """

    categories: list[cleanup_module.CleanupCategory]


class RemoveVideoRequest(BaseModel):
    """Body for POST /api/videos/remove (#24).

    ``reset_audit`` only takes effect when removing a primary; otherwise it
    is ignored (audit is stage-level state, and non-primary removals do not
    invalidate it).
    """

    video_path: str
    reset_audit: bool = False


class FsEntry(BaseModel):
    name: str
    kind: Literal["dir", "video", "file"]
    video_count: int | None = None  # populated for dirs
    size_bytes: int | None = None  # populated for files
    mtime: float | None = None
    # Populated for videos when probed (issue #24). ``duration`` may be null
    # if probing was skipped (no ?probe=true) or hit the per-listing budget.
    # ``thumbnail_url`` points at /api/thumbnails/{key}.jpg when a thumbnail
    # is cached; the caller can hit /api/fs/probe to generate one on demand.
    duration: float | None = None
    thumbnail_url: str | None = None


class SuggestedStart(BaseModel):
    """One sidebar bookmark in the FolderPicker.

    Distinct from a flat string list so the SPA can group entries by
    ``kind`` (recent / home / removable / network) and render the right
    icon. ``label`` is what to show in the sidebar; ``path`` is the
    absolute path to navigate to. Only ``kind="removable"`` and
    ``"network"`` carry the platform-specific mount discovery output --
    everything else is the user-stable bookmarks.
    """

    path: str
    label: str
    kind: Literal["recent", "home", "removable", "network"]


class FsListing(BaseModel):
    path: str
    parent: str | None
    entries: list[FsEntry]
    suggested_starts: list[SuggestedStart]


def _bind_project_to_state(
    state: AppState,
    root: Path,
    fallback_name: str,
) -> str:
    """Initialise ``root`` on disk if needed, load its env files, record
    the open in ``~/.splitsmith/projects.json``, and bind it on ``state``.

    Used both at startup (when ``--project`` was passed) and at runtime
    (when the SPA POSTs to /api/user/recent-projects/bind). Returns the
    on-disk display name so the caller can echo it back.

    When ``root`` is a redesign-era Match folder (has ``match.json``),
    the match itself is bound (``state.bind_match``) and the SPA addresses
    individual shooters via slug-bearing URLs. Otherwise we bind the
    legacy single-shooter project directly.
    """
    resolved = root.resolve()
    if match_model.is_match_folder(resolved):
        try:
            match = match_model.Match.load(resolved)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(
                status_code=400,
                detail=f"failed to load match at {resolved}: {exc}",
            ) from exc
        if not match.shooters:
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "match_empty",
                    "message": (
                        f"Match {resolved} has no shooters yet. " "Add a shooter or recreate the match."
                    ),
                },
            )
        name = match.name or fallback_name
        user_config.record_project_open(resolved, name, kind="match")
        loaded_env = _load_env_files(resolved)
        if loaded_env:
            logger.info("Loaded env from %s", ", ".join(str(p) for p in loaded_env))
        state.bind_match(resolved, name)
        return name
    return _bind_legacy_root_to_state(state, resolved, fallback_name=fallback_name)


def _bind_legacy_root_to_state(
    state: AppState,
    root: Path,
    fallback_name: str,
) -> str:
    """Bind a legacy MatchProject directory (project.json layout)."""
    MatchProject.init(root, name=fallback_name)
    resolved = root.resolve()
    loaded_env = _load_env_files(resolved)
    if loaded_env:
        logger.info("Loaded env from %s", ", ".join(str(p) for p in loaded_env))
    try:
        loaded_project = MatchProject.load(resolved)
        recorded_name = loaded_project.name or fallback_name
    except Exception:  # pragma: no cover -- defensive: never block boot
        recorded_name = fallback_name
    user_config.record_project_open(resolved, recorded_name, kind="legacy")
    state.bind_legacy(resolved, recorded_name)
    return recorded_name


def _enrich_recent_project(rp: user_config.RecentProject) -> RecentProjectDetail:
    """Read on-disk metadata for one recent-project entry.

    Returns a :class:`RecentProjectDetail` that the redesigned match
    picker (#322) renders directly. Best-effort: anything we can't
    answer leaves the corresponding field at its default. Errors never
    propagate -- a stale entry shows up as ``kind="missing"`` so the
    user can prune it.
    """
    detail = RecentProjectDetail(
        path=rp.path,
        name=rp.name,
        last_opened_at=rp.last_opened_at,
        kind="unknown",
    )
    path = Path(rp.path)
    if not path.exists():
        detail.kind = "missing"
        return detail

    try:
        kind, _ = match_model.from_path(path)
    except FileNotFoundError:
        detail.kind = "unknown"
        return detail

    try:
        if kind == "match":
            match = match_model.Match.load(path)
            detail.kind = "match"
            detail.name = match.name or rp.name
            detail.match_id = match.match_id
            detail.shooter_count = len(match.shooters)
            detail.stage_count = len(match.stages)
            detail.match_date = match.match_date.isoformat() if match.match_date else None
            detail.manual = match.scoreboard_match_id is None
            # Audited = average audited-stage count across shooters.
            # "Audited" comes from :func:`stage_audit_status` -- the
            # operator has to hit Save & next at least once on the
            # stage for it to count. Skipped stages don't qualify.
            audited_total = 0
            shooter_names: list[str] = []
            for slug in match.shooters:
                shooter_root = match_model.Match.shooter_root(path, slug)
                try:
                    shooter = match.load_shooter(path, slug)
                except (FileNotFoundError, KeyError):
                    shooter_names.append(slug)
                    continue
                try:
                    legacy = MatchProject.load(shooter_root)
                except FileNotFoundError:
                    shooter_names.append(shooter.name or slug)
                    continue
                audited_total += legacy.audited_count(shooter_root)
                shooter_names.append(shooter.name or slug)
            detail.shooter_names = shooter_names
            detail.stages_audited = audited_total // max(len(match.shooters), 1) if match.shooters else 0
            metadata_path = path / match_model.MATCH_FILE
        else:
            project = MatchProject.load(path)
            detail.kind = "legacy"
            detail.name = project.name or rp.name
            detail.shooter_count = 1
            detail.stage_count = len(project.stages)
            detail.match_date = project.match_date.isoformat() if project.match_date else None
            detail.manual = project.scoreboard_match_id is None
            detail.stages_audited = project.audited_count(path)
            if project.competitor_name:
                detail.shooter_names = [project.competitor_name]
            metadata_path = path / "project.json"

        if metadata_path.exists():
            mtime = metadata_path.stat().st_mtime
            detail.last_modified_at = datetime.fromtimestamp(mtime, tz=UTC)
    except Exception:  # noqa: BLE001 -- defensive: never break listing
        return detail

    # Derive status. "exported" = every stage audited (heuristic); "archived"
    # = no modification in 180 days; "in_progress" otherwise.
    if detail.stage_count > 0 and detail.stages_audited >= detail.stage_count:
        detail.status = "exported"
    elif detail.last_modified_at is not None:
        age = datetime.now(UTC) - detail.last_modified_at
        if age.days > 180:
            detail.status = "archived"
        else:
            detail.status = "in_progress"
    else:
        detail.status = "in_progress"
    return detail


def create_app(
    *,
    project_root: Path | None = None,
    project_name: str | None = None,
    lab_enabled: bool = False,
) -> FastAPI:
    """Create the FastAPI app, optionally pre-bound to one match project.

    When ``project_root`` is omitted the server boots **unbound**: the
    picker endpoints (recent projects, fs/list, project bind) work; every
    other project-bound endpoint returns 409 ``no_project`` so the SPA
    can redirect to its picker route. The user binds a project at runtime
    via POST /api/user/recent-projects/bind.

    When bound, the project is initialised on first call (idempotent),
    then the app keeps the root path and re-loads on every request. We
    avoid caching the model in memory so external edits to
    ``project.json`` are visible without restart.

    ``lab_enabled`` gates the ``/api/lab/*`` routes (and the SPA reads
    ``/api/server/features`` on mount to know whether to show the Lab
    nav entry). Hidden by default; opt in via ``splitsmith ui --lab``.
    """
    state = AppState()
    # Populate the match-id registry from recent projects so id -> path
    # lookups resolve without waiting for a picker bind. Cheap (one
    # match.json read per recent entry; legacy projects are skipped).
    # Pre-v4 match.json files get the id assigned + persisted here on
    # the fly via Match.load's load-time migration.
    state.matches.refresh_from_recent_projects()
    # Load .env / .env.local before binding so SPLITSMITH_SSI_TOKEN (and
    # friends) are available on the unbound boot path too -- the
    # create-match-from-scoreboard flow needs the token before any
    # project exists. Bound binds re-call this with their project root
    # so per-project overrides still win.
    _load_env_files(project_root)
    if project_root is not None:
        _bind_project_to_state(
            state,
            project_root,
            fallback_name=project_name or project_root.name or "match",
        )

    app = FastAPI(
        title="splitsmith UI",
        description="Production UI backend (issue #11/#12).",
        version="0.1.0",
    )
    # Stash on app.state so the uvicorn server wrapper in :func:`serve`
    # can read live job state when handling Ctrl-C: the signal handler
    # needs to enumerate pending / running jobs to tell the user what's
    # being waited on, and the registry isn't otherwise reachable from
    # outside the closure.
    app.state.splitsmith_state = state

    @app.exception_handler(ShutdownInProgressError)
    async def _shutdown_in_progress_handler(request: Request, exc: ShutdownInProgressError) -> JSONResponse:
        """Map ShutdownInProgressError to 503 across every submit() callsite."""
        return JSONResponse(
            status_code=503,
            content={"detail": {"code": "shutting_down", "message": str(exc)}},
        )

    # ----------------------------------------------------------------------
    # /api/matches/{match_id}/... alias middleware (#353 Phase 3 PR B/C)
    # ----------------------------------------------------------------------
    #
    # The SPA's URLs live under ``/match/:matchId/`` so each tab can pin
    # its own match. The corresponding API prefix is accepted by this
    # one middleware:
    #
    # 1. Validate ``match_id`` against the registry (404 ``match_not_found``
    #    when unknown).
    # 2. Set the ``current_match_root`` / ``current_match_id`` ContextVars
    #    for the lifetime of the request so ``state.shooter_root`` can
    #    resolve against the URL's match rather than the singleton.
    # 3. Strip ``matches/{match_id}/`` and forward to the existing route
    #    table -- 69 endpoint decorators are untouched.
    #
    # Two concurrent requests with different match ids stay isolated
    # because each runs in its own contextvar scope. The singleton
    # ``state._bound_root`` is only consulted for legacy bare-path
    # traffic that hasn't migrated to the new prefix.
    @app.middleware("http")
    async def _match_id_alias(request, call_next):
        path = request.url.path
        prefix = "/api/matches/"
        if not path.startswith(prefix):
            return await call_next(request)
        remainder = path[len(prefix) :]
        match_id, sep, rest = remainder.partition("/")
        if not sep or not match_id:
            return JSONResponse(
                status_code=400,
                content={
                    "detail": {
                        "code": "match_id_required",
                        "message": "expected /api/matches/{match_id}/...",
                    }
                },
            )
        try:
            match_root = state.matches.resolve(match_id)
        except KeyError:
            return JSONResponse(
                status_code=404,
                content={
                    "detail": {
                        "code": "match_not_found",
                        "message": f"unknown match_id {match_id!r}",
                    }
                },
            )
        rewritten = "/api/" + rest
        request.scope["path"] = rewritten
        request.scope["raw_path"] = rewritten.encode("utf-8")
        root_token = current_match_root.set(match_root)
        id_token = current_match_id.set(match_id)
        try:
            return await call_next(request)
        finally:
            current_match_root.reset(root_token)
            current_match_id.reset(id_token)

    # ----------------------------------------------------------------------
    # API
    # ----------------------------------------------------------------------

    def _local_match_path(root: Path) -> Path:
        """Resolve ``<root>/scoreboard/match.json`` (offline source path)."""
        return root / DEFAULT_SCOREBOARD_DIRNAME / DEFAULT_MATCH_FILENAME

    def _resolve_scoreboard_client(root: Path) -> ScoreboardClient:
        """Pick the concrete ``ScoreboardClient`` for this shooter root.

        Local JSON wins when present so the user can stay fully offline by
        dropping a file. Otherwise we wrap the HTTP client in the project-
        local cache so a second open of the same match is a cache hit. The
        caller is responsible for ``close()`` -- both implementations are
        context managers (Local is a no-op; HTTP closes the httpx Client).
        """
        local_path = _local_match_path(root)
        if local_path.exists():
            local = LocalJsonScoreboard(local_path)
            return _ScoreboardClientCtx(local, owns_close=False)
        try:
            http = SsiHttpClient()
        except ScoreboardAuthError as exc:
            _raise_scoreboard_http(exc)
        cache_dir = root / "scoreboard" / "cache"
        cached = CachingScoreboardClient(http, cache_dir)
        return _ScoreboardClientCtx(cached, owns_close=True, inner_http=http)

    def _health_after_bind(recorded_name: str) -> HealthResponse:
        """Build a HealthResponse from the currently-bound project."""
        default_slug: str | None = None
        kind = state.bound_kind
        if kind == "match":
            match = match_model.Match.load(state.bound_root)
            shooters = sorted(match.shooters)
            default_slug = shooters[0] if shooters else None
        elif kind == "legacy":
            try:
                project = MatchProject.load(state.bound_root)
                default_slug = legacy_slug(project)
            except Exception:  # noqa: BLE001 -- defensive
                default_slug = None
        return HealthResponse(
            bound=True,
            project_name=recorded_name,
            project_root=str(state.bound_root),
            kind=kind,
            default_shooter_slug=default_slug,
            match_id=state.bound_match_id,
        )

    @app.get("/api/health", response_model=HealthResponse)
    def health() -> HealthResponse:
        if not state.is_bound:
            return HealthResponse(bound=False)
        return _health_after_bind(state.bound_name or "")

    @app.get("/api/models/status")
    def models_status() -> dict[str, Any]:
        """Slim model layer status (issue #377 -- doc 03).

        The SPA polls this on mount + after each detect to know whether
        to render the "downloading models" overlay. Wheels that don't
        ship the ``model_artifacts`` calibration block (today's torch
        path) return ``available=False`` so the frontend doesn't draw
        the overlay at all.
        """
        from .. import models as model_layer

        registry = model_layer.get_default_registry()
        if registry is None:
            return {"available": False, "artifacts": [], "missing": [], "mismatched": []}
        statuses = registry.status()
        missing = [s.slug for s in statuses if s.state == "missing"]
        mismatched = [s.slug for s in statuses if s.state == "mismatched"]
        return {
            "available": True,
            "cache_root": str(registry.root),
            "artifacts": [
                {
                    "slug": s.slug,
                    "state": s.state,
                    "sha256": s.expected_sha256,
                    "size_bytes": s.size_bytes,
                }
                for s in statuses
            ],
            "missing": missing,
            "mismatched": mismatched,
        }

    @app.post("/api/shutdown", status_code=202)
    def shutdown(request: Request) -> dict[str, Any]:
        """Drain in-flight jobs and ask uvicorn to exit (issue #369).

        Loopback-only -- the embedded sidecar trusts only its own host.
        Idempotent: the first call kicks a daemon drain thread; later
        calls return 202 without rescheduling.

        Under the CLI's ``splitsmith ui`` path the registered stop
        callback is None, so this drains jobs but does not stop the
        server -- the operator still uses Ctrl-C there.
        """
        if not _is_loopback(request):
            raise HTTPException(
                status_code=403,
                detail={"code": "loopback_only", "message": "shutdown is loopback-only"},
            )
        if state.shutdown_initiated:
            return {"status": "shutting_down", "already": True}
        state.shutdown_initiated = True
        state.jobs.begin_shutdown()
        handler = state.shutdown_handler
        drain_timeout = 30.0

        def _drain_then_stop() -> None:
            try:
                state.jobs.wait_for_drain(drain_timeout)
            finally:
                if handler is not None:
                    handler()

        threading.Thread(target=_drain_then_stop, name="splitsmith-shutdown", daemon=True).start()
        return {"status": "shutting_down", "already": False}

    @app.get("/api/shooters/{slug}/project")
    def get_project(slug: str) -> JSONResponse:
        project = state.shooter_project(slug)
        root = state.shooter_root(slug)
        statuses = project.stage_statuses(root)
        payload = project.model_dump(mode="json")
        # Enrich each stage's serialized dict with its computed status
        # so the SPA never recomputes "is this audited?" client-side.
        # The status field is read-only (not on the StageEntry model);
        # PUTting it back is a no-op since model parsing ignores
        # unknown keys via Pydantic v2's default behavior.
        for stage_dict in payload.get("stages", []):
            n = stage_dict.get("stage_number")
            if n is None:
                continue
            status = statuses.get(int(n))
            if status is not None:
                stage_dict["status"] = status.value
        return JSONResponse(payload)

    @app.get("/api/shooters/{slug}/project/export")
    def export_project_endpoint(
        slug: str,
        include_trimmed: bool = Query(False),
        include_exports: bool = Query(False),
        include_raw: bool = Query(False),
        include_audio: bool = Query(False),
    ) -> FileResponse:
        """Stream the bound project as a ``.tar.gz`` download.

        The default archive contains only ``project.json``, ``audit/`` and
        ``scoreboard/`` -- the artefacts that cannot be regenerated from
        the source footage. The ``include_*`` query flags opt
        regeneratable directories into the archive. The archive is
        written to a temp file and deleted once the response finishes
        streaming.
        """
        root = state.shooter_root(slug)
        tmp = Path(tempfile.mkdtemp(prefix="splitsmith-export-"))
        archive = tmp / f"{root.name}.tar.gz"
        try:
            result = backup_mod.export_project(
                root,
                archive,
                include_trimmed=include_trimmed,
                include_exports=include_exports,
                include_raw=include_raw,
                include_audio=include_audio,
            )
        except backup_mod.BackupError as exc:
            shutil.rmtree(tmp, ignore_errors=True)
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        stamp = datetime.now(UTC).strftime("%Y%m%d")
        download_name = f"{root.name}-backup-{stamp}.tar.gz"
        return FileResponse(
            result.archive_path,
            media_type="application/gzip",
            filename=download_name,
            background=BackgroundTask(shutil.rmtree, tmp, ignore_errors=True),
        )

    @app.post("/api/me/projects/import")
    async def import_project_endpoint(
        archive: UploadFile = File(...),
        dest_root: str = Form(...),
        overwrite: bool = Form(False),
        bind: bool = Form(False),
    ) -> JSONResponse:
        """Restore an archive produced by ``GET /api/project/export``.

        Extracts under ``dest_root``. When ``bind`` is true, the newly
        imported project is bound and added to the recent-projects list
        so the SPA can navigate straight into it.
        """
        dest = Path(dest_root).expanduser()
        tmp = Path(tempfile.mkdtemp(prefix="splitsmith-import-"))
        staged = tmp / "upload.tar.gz"
        try:
            with staged.open("wb") as out:
                while True:
                    chunk = await archive.read(1 << 20)
                    if not chunk:
                        break
                    out.write(chunk)
            try:
                result = backup_mod.import_project(staged, dest, overwrite=overwrite)
            except backup_mod.BackupError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

        if bind:
            _bind_project_to_state(state, result.project_root, fallback_name=result.project_name)

        return JSONResponse(
            {
                "project_root": str(result.project_root),
                "project_name": result.project_name,
                "manifest": result.manifest,
            }
        )

    @app.get("/api/shooters/{slug}/automation")
    def get_automation(slug: str) -> JSONResponse:
        """Resolved automation settings + per-field provenance (#215 / #216).

        Combines the global YAML / env-var defaults with the bound
        project's override. The SPA renders provenance badges next to
        each toggle so users see which layer set the current value.
        ``cli_value`` is always None on the daemon path -- the server
        doesn't take per-call CLI flags.
        """
        project = state.shooter_project(slug)
        resolved = automation_settings.resolve_automation(
            project_override=project.automation,
        )
        return JSONResponse(
            {
                "settings": resolved.settings.model_dump(mode="json"),
                "provenance": {
                    field: {
                        "source": prov.source,
                        "cli_value": prov.cli_value,
                        "project_value": prov.project_value,
                        "global_value": prov.global_value,
                    }
                    for field, prov in resolved.provenance.items()
                },
            }
        )

    @app.post("/api/shooters/{slug}/project/nudges/dismiss")
    def dismiss_nudge(slug: str, req: NudgeDismissRequest) -> JSONResponse:
        """Persist a per-project nudge dismissal (#218 phase 4).

        Adds ``stage_number`` to ``MatchProject.nudges_dismissed_stages``
        when ``dismissed=True`` (idempotent), removes it otherwise.
        Returns the full project dump so the SPA can replace its
        cached state without a separate refetch.
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        try:
            project.stage(req.stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        current = set(project.nudges_dismissed_stages)
        if req.dismissed:
            current.add(req.stage_number)
        else:
            current.discard(req.stage_number)
        project.nudges_dismissed_stages = sorted(current)
        project.save(root)
        return JSONResponse(project.model_dump(mode="json"))

    @app.get("/api/shooters/{slug}/hitl-queue")
    def get_hitl_queue(slug: str) -> JSONResponse:
        """Items in the project that need human (or agent) attention (#219).

        Walks every primary video and emits one item per beep that's
        either missing (auto-detection found no candidate) or below the
        ``beep_low_confidence_threshold`` automation gate -- exactly
        the cases where the auto-trust chain didn't fire and a human
        has to pick. Manual entries and high-confidence reviewed beeps
        never appear here.

        Response shape (stable; consumed by the SPA AND the MCP):

            {
              "items": [
                {
                  "kind": "beep_missing" | "beep_low_confidence",
                  "stage_number": int,
                  "video_id": str,
                  "confidence": float | None,
                  "suggested_action": str,
                },
                ...
              ],
              "threshold": float,
            }

        Ordered by stage number ascending; severity ties (a low-conf
        and a missing on the same stage) keep their stable insertion
        order. The SPA shows this as a project-level work queue; the
        MCP exposes it as a resource so an agent can drive the picks.
        """
        project = state.shooter_project(slug)
        resolved = automation_settings.resolve_automation(
            project_override=project.automation,
        )
        threshold = resolved.settings.beep_low_confidence_threshold
        items: list[dict] = []
        for stg in sorted(project.stages, key=lambda s: s.stage_number):
            primary = next(
                (v for v in stg.videos if v.role == "primary"),
                None,
            )
            if primary is None:
                continue
            if primary.beep_auto_detect_failed:
                items.append(
                    {
                        "kind": "beep_missing",
                        "stage_number": stg.stage_number,
                        "video_id": primary.video_id,
                        "confidence": None,
                        "suggested_action": (
                            "Set the beep manually on the waveform: open the "
                            "stage's ingest panel and click the beep marker."
                        ),
                    }
                )
                continue
            if primary.beep_source == "auto" and primary.beep_time is not None and not primary.beep_reviewed:
                # Either confidence is below the threshold OR the field
                # predates layer 3a (None) -- both warrant review.
                items.append(
                    {
                        "kind": "beep_low_confidence",
                        "stage_number": stg.stage_number,
                        "video_id": primary.video_id,
                        "confidence": primary.beep_confidence,
                        "suggested_action": (
                            "Listen to the ranked candidates and pick the "
                            "correct beep, or nudge the timestamp on the "
                            "waveform."
                        ),
                    }
                )
        return JSONResponse({"items": items, "threshold": threshold})

    @app.get("/api/shooters/{slug}/project/match-analysis")
    def get_match_analysis(slug: str) -> JSONResponse:
        """Run the canonical video-match heuristic over the project and return
        per-stage windows + per-video classification.

        Single source of truth for the SPA's match-window timeline:
        tolerance, window edges, and per-video classification are all
        produced by :mod:`splitsmith.video_match`. Future heuristic
        improvements (per-stage tolerance, ML-based scoring, confidence
        bands) extend this endpoint rather than adding policy to the SPA.
        """
        project = state.shooter_project(slug)
        return JSONResponse(project.match_analysis().model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/scoreboard/import")
    def import_scoreboard(slug: str, req: ScoreboardImportRequest) -> JSONResponse:
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        try:
            project.import_scoreboard(req.data, overwrite=req.overwrite)
        except ScoreboardImportConflictError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except (KeyError, ValueError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        project.save(root)
        return JSONResponse(project.model_dump(mode="json"))

    # ----------------------------------------------------------------------
    # SSI Scoreboard v1 wiring (#50)
    # ----------------------------------------------------------------------
    #
    # The UI consumes only the ``ScoreboardClient`` Protocol -- the resolver
    # below picks the concrete implementation per request based on project
    # state. Drop a ``<project>/scoreboard/match.json`` and every request
    # transparently switches to the offline path; remove the file and the
    # next request hits the live API. Errors are mapped to HTTP statuses
    # the SPA can render as actionable banners (acceptance criterion).

    @app.get("/api/shooters/{slug}/scoreboard/source")
    def scoreboard_source(slug: str) -> JSONResponse:
        """Report whether the offline JSON or the live API will serve requests.

        The SPA renders a "loaded from local JSON, no network used" indicator
        when ``mode == "local"`` so the user can verify the offline path
        without watching dev tools.
        """
        local_path = _local_match_path(state.shooter_root(slug))
        local = local_path.exists()
        http_ready = bool(os.environ.get("SPLITSMITH_SSI_TOKEN"))
        return JSONResponse(
            {
                "mode": "local" if local else "online",
                "local_match_json_path": str(local_path) if local else None,
                "http_token_set": http_ready,
            }
        )

    @app.post("/api/shooters/{slug}/scoreboard/upload")
    def scoreboard_upload(slug: str, req: ScoreboardUploadRequest) -> JSONResponse:
        """Accept a dropped SSI ``match.json`` and populate the project.

        Three input shapes are accepted (see ``LocalJsonScoreboard``):
        pure SSI v1 ``MatchData``, a richer combined v1+stages format, or
        the legacy ``examples/`` shape. The file is written to
        ``<project>/scoreboard/match.json`` *first*, so a subsequent reload
        still finds the offline source even if populate throws. The
        offline ``LocalJsonScoreboard`` then parses it and -- when the
        file carries per-competitor stage results for exactly one
        competitor -- auto-pins that competitor and merges the times so
        the user lands on a fully-populated stage list in one drop.
        """
        root = state.shooter_root(slug)
        local_path = _local_match_path(root)
        local_path.parent.mkdir(parents=True, exist_ok=True)
        local_path.write_text(
            json.dumps(req.data, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        try:
            scoreboard = LocalJsonScoreboard(local_path)
        except Exception as exc:  # validation, KeyError, etc.
            raise HTTPException(
                status_code=400,
                detail=f"dropped JSON is not a recognized scoreboard payload: {exc}",
            ) from exc

        project = state.shooter_project(slug)
        try:
            project.populate_from_match_data(scoreboard.match, overwrite=req.overwrite)
        except ScoreboardImportConflictError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

        # Auto-pin path: a single-competitor richer file maps cleanly to
        # "this is me." Multi-competitor files (e.g. the upstream-issue
        # combined shape with multiple shooters' results) leave the user
        # to pick via the shooter pinner -- we don't guess.
        merged = 0
        default_cid = scoreboard.default_competitor_id()
        if default_cid is not None and scoreboard.has_stage_times:
            try:
                results = scoreboard.get_stage_times(
                    scoreboard.content_type or 0,
                    scoreboard.match_id or 0,
                    default_cid,
                )
            except (KeyError, ScoreboardError):
                results = None
            if results is not None:
                merged = project.merge_stage_times(results)
                project.selected_competitor_id = default_cid
                # Resolve the picked competitor inside the parsed match.
                # We persist shooter_id (for the global "this is me"
                # identity) and competitor_name (so the SPA can show
                # who's pinned without re-fetching MatchData on every
                # render).
                picked = next(
                    (c for c in scoreboard.match.competitors if c.id == default_cid),
                    None,
                )
                if picked is not None:
                    project.selected_shooter_id = picked.shooterId
                    project.competitor_name = picked.name
        project.save(root)
        return JSONResponse({**project.model_dump(mode="json"), "stage_times_merged": merged})

    @app.get("/api/shooters/{slug}/scoreboard/search")
    def scoreboard_search(slug: str, q: str = Query("", min_length=0)) -> JSONResponse:
        """Search the active scoreboard source for matches by free-text query."""
        with _resolve_scoreboard_client(state.shooter_root(slug)) as client:
            try:
                refs = client.search_matches(q)
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)
        return JSONResponse([ref.model_dump(mode="json") for ref in refs])

    @app.get("/api/scoreboard/search")
    def scoreboard_search_unbound(q: str = Query("", min_length=0)) -> JSONResponse:
        """Search the live scoreboard without a bound shooter (#322).

        The create-match-from-scoreboard flow runs *before* a project
        exists, so there is no shooter root to scope a cache to. Search
        results aren't cached anyway -- ``CachingScoreboardClient`` only
        memoises ``get_match`` -- so we skip the cache wrapper entirely
        and go straight to the HTTP client.
        """
        try:
            client = SsiHttpClient()
        except ScoreboardAuthError as exc:
            _raise_scoreboard_http(exc)
        with client:
            try:
                refs = client.search_matches(q)
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)
        return JSONResponse([ref.model_dump(mode="json") for ref in refs])

    @app.get("/api/scoreboard/matches/{content_type}/{match_id}")
    def scoreboard_match_data_unbound(content_type: int, match_id: int) -> JSONResponse:
        """Fetch full match data (incl. competitor list) without binding.

        The create-from-scoreboard flow needs the competitor roster
        *before* a project exists so the user can pick multiple
        shooters in one step. Mirrors the unbound search endpoint:
        skip the per-project cache and call the HTTP client directly.
        Hitting this twice for the same match in the same session is
        cheap on scoreboard.urdr.dev (CDN-cached) and avoids hauling
        a per-session in-memory cache around just for this flow.
        """
        try:
            client = SsiHttpClient()
        except ScoreboardAuthError as exc:
            _raise_scoreboard_http(exc)
        with client:
            try:
                data = client.get_match(content_type, match_id)
            except MatchNotFound as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)
        return JSONResponse(data.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/scoreboard/fetch")
    def scoreboard_fetch(slug: str, req: ScoreboardFetchRequest) -> JSONResponse:
        """Fetch a full match (cache-first) and populate the project.

        When the project already has a pinned competitor (carried over from
        a previous session), auto-merge their stage times in the same
        round-trip. New picks (no pin yet) still need ``/select-shooter``
        afterwards -- the SPA flow stays the same.
        """
        root = state.shooter_root(slug)
        with _resolve_scoreboard_client(root) as client:
            try:
                match_data = client.get_match(req.content_type, req.match_id)
            except MatchNotFound as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)
        project = state.shooter_project(slug)
        try:
            project.populate_from_match_data(match_data, overwrite=req.overwrite)
        except ScoreboardImportConflictError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

        merged = 0
        if project.selected_competitor_id is not None:
            try:
                merged = _fetch_and_merge_stage_times(
                    root,
                    project,
                    req.content_type,
                    req.match_id,
                    project.selected_competitor_id,
                )
            except HTTPException:
                # Stage times failed (upstream not shipped yet, etc.).
                # Persist the populated stage shell anyway so the user
                # has something to work with; they can hit refresh-times
                # once the upstream resolves.
                project.save(root)
                raise
        else:
            project.save(root)
        return JSONResponse({**project.model_dump(mode="json"), "stage_times_merged": merged})

    @app.get("/api/shooters/{slug}/scoreboard/match-data")
    def scoreboard_match_data(slug: str) -> JSONResponse:
        """Return the resolved ``MatchData`` for the project's loaded match.

        The SPA needs this to map a picked ``shooterId`` to the per-match
        ``competitor_id`` before calling ``/select-shooter``. We don't
        denormalise that mapping onto the ``MatchProject`` because it
        drifts when upstream re-fetches; serving on demand keeps the
        cache as the single source of truth.
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        if project.scoreboard_match_id is None or project.scoreboard_content_type is None:
            raise HTTPException(
                status_code=404,
                detail="project has no scoreboard match loaded yet",
            )
        try:
            ct = project.scoreboard_content_type
            mid = int(project.scoreboard_match_id)
        except (TypeError, ValueError) as exc:
            raise HTTPException(
                status_code=400,
                detail=(
                    "project's scoreboard_match_id isn't numeric; this match "
                    "predates the v1 wiring (#50). Re-import via /upload or /fetch."
                ),
            ) from exc
        with _resolve_scoreboard_client(root) as client:
            try:
                match_data = client.get_match(ct, mid)
            except MatchNotFound as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)
        return JSONResponse(match_data.model_dump(mode="json"))

    @app.get("/api/shooters/{slug}/scoreboard/shooter/search")
    def scoreboard_shooter_search(slug: str, q: str = Query("", min_length=0)) -> JSONResponse:
        """Find shooters by name. Offline mode searches this match's
        competitor list only; online mode hits the live shooter index."""
        if not q.strip():
            return JSONResponse([])
        with _resolve_scoreboard_client(state.shooter_root(slug)) as client:
            try:
                refs = client.find_shooter(q)
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)
        return JSONResponse([ref.model_dump(mode="json") for ref in refs])

    @app.post("/api/shooters/{slug}/scoreboard/select-shooter")
    def scoreboard_select_shooter(slug: str, req: SelectShooterRequest) -> JSONResponse:
        """Pin (shooter_id, competitor_id) and merge stage times into the project.

        Validates the competitor against the loaded match before
        persisting -- a wrong cid (typoed by hand, or the user picked a
        shooter who isn't in this match) shouldn't leave the project
        with an invalid pin that breaks every subsequent refresh.

        Failure modes:
        - 409 ``no_match_loaded``: project has no scoreboard match yet
        - 404 ``competitor_not_in_match``: the cid isn't in the loaded
          MatchData -- pin not persisted, user is asked to re-pick
        - 400 ``stage_times_offline_pure_matchdata``: offline source
          carries no stage results; pin *is* persisted so refresh-times
          can retry once the user drops a richer JSON or goes online
        - 502 ``scoreboard_offline``: transient upstream issue;
          pin persisted so refresh-times retries on the same selection
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        if project.scoreboard_match_id is None or project.scoreboard_content_type is None:
            raise HTTPException(
                status_code=409,
                detail=(
                    "project has no scoreboard match loaded; pick a match "
                    "(drop JSON or fetch) before pinning a shooter"
                ),
            )
        try:
            ct = project.scoreboard_content_type
            mid = int(project.scoreboard_match_id)
        except (TypeError, ValueError) as exc:
            raise HTTPException(
                status_code=400,
                detail="project's scoreboard_match_id isn't numeric",
            ) from exc

        # Validate the competitor is actually in this match before
        # persisting. Cheap server-side guard (uses the cached MatchData),
        # avoids the "I picked a shooter and now my project is in a bad
        # state" pattern. 404 with a discrete code so the SPA can prompt
        # the user to pick again rather than rendering an upstream banner.
        with _resolve_scoreboard_client(root) as client:
            try:
                match_data = client.get_match(ct, mid)
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)
        picked = next(
            (c for c in match_data.competitors if c.id == req.competitor_id),
            None,
        )
        if picked is None:
            raise HTTPException(
                status_code=404,
                detail={
                    "code": "competitor_not_in_match",
                    "message": (
                        f"competitor {req.competitor_id} isn't in this match. " "Pick a different shooter."
                    ),
                },
            )

        project.selected_shooter_id = req.shooter_id
        project.selected_competitor_id = req.competitor_id
        # Persist the human-readable name so the SPA's collapsed
        # scoreboard summary doesn't have to re-fetch MatchData just to
        # render "pinned: Mathias Rinaldo" instead of an integer id.
        project.competitor_name = picked.name
        project.save(root)

        merged = _fetch_and_merge_stage_times(root, project, ct, mid, req.competitor_id)
        return JSONResponse({**project.model_dump(mode="json"), "stage_times_merged": merged})

    @app.post("/api/shooters/{slug}/scoreboard/refresh-times")
    def scoreboard_refresh_times(slug: str) -> JSONResponse:
        """Re-pull and re-merge stage times for the pinned competitor.

        Invalidates every cached stage-times entry for the match (not
        just the pinned competitor) because in-progress matches often
        update multiple shooters at once and a fresh pull is cheap. Use
        this after the user knows the upstream has new scorecards.
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        if (
            project.selected_competitor_id is None
            or project.scoreboard_match_id is None
            or project.scoreboard_content_type is None
        ):
            raise HTTPException(
                status_code=409,
                detail="pin a shooter first; refresh-times has nothing to re-fetch",
            )
        try:
            ct = project.scoreboard_content_type
            mid = int(project.scoreboard_match_id)
        except (TypeError, ValueError) as exc:
            raise HTTPException(
                status_code=400,
                detail="project's scoreboard_match_id isn't numeric",
            ) from exc

        # Drop every cached stage_times entry for this match so the
        # next get_stage_times call goes upstream.
        cache_dir = root / "scoreboard" / "cache"
        if cache_dir.exists():
            cache = CachingScoreboardClient(_NoOpClient(), cache_dir)
            cache.invalidate_match_stage_times(ct, mid)

        merged = _fetch_and_merge_stage_times(root, project, ct, mid, project.selected_competitor_id)
        return JSONResponse({**project.model_dump(mode="json"), "stage_times_merged": merged})

    def _fetch_and_merge_stage_times(
        root: Path, project: MatchProject, ct: int, mid: int, competitor_id: int
    ) -> int:
        """Shared helper -- get_stage_times + merge_stage_times, with the
        right error mapping. Persists the project on success.

        Also opportunistically backfills ``stage_rounds`` from the cached
        ``MatchData`` so existing projects pick up ``min_rounds`` /
        target counts on the existing "refresh times" SPA action without
        requiring a full overwrite-import that would orphan video
        assignments.
        """
        with _resolve_scoreboard_client(root) as client:
            try:
                results = client.get_stage_times(ct, mid, competitor_id)
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)
            except KeyError as exc:
                raise HTTPException(
                    status_code=404,
                    detail=str(exc),
                ) from exc
            # Best-effort backfill of stage_rounds. Failure is non-fatal
            # -- stage times are the user-visible action; rounds are an
            # additive bonus that the next real scoreboard refresh can
            # still cover.
            try:
                match_data = client.get_match(ct, mid)
                project.merge_stage_rounds(match_data)
            except ScoreboardError:
                pass
        merged = project.merge_stage_times(results)
        project.save(root)
        return merged

    @app.post("/api/shooters/{slug}/project/placeholder-stages")
    def create_placeholder_stages(slug: str, req: PlaceholderStagesRequest) -> JSONResponse:
        """Create N placeholder stages so source-first ingest works without a
        scoreboard. A real scoreboard import later overlays the placeholders
        and preserves video assignments by ``stage_number``."""
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        try:
            project.init_placeholder_stages(
                req.stage_count,
                match_name=req.match_name,
                match_date=req.match_date,
            )
        except ScoreboardImportConflictError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        project.save(root)
        return JSONResponse(project.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/videos/scan", response_model=ScanResponse)
    def scan_videos(slug: str, req: ScanRequest) -> ScanResponse:
        if req.link_mode not in ("symlink", "copy"):
            raise HTTPException(status_code=400, detail="link_mode must be 'symlink' or 'copy'")
        if (req.source_dir is None) == (req.source_paths is None):
            raise HTTPException(
                status_code=400,
                detail="exactly one of source_dir or source_paths must be provided",
            )

        # Build the list of files to register and capture the directory we'll
        # remember as last_scanned_dir. For source_paths mode we use the parent
        # of the first file as a sensible default for the picker next time.
        candidates: list[Path] = []
        last_dir: Path | None = None
        if req.source_dir is not None:
            source = Path(req.source_dir).expanduser()
            if not source.exists():
                raise HTTPException(status_code=400, detail=f"source dir not found: {source}")
            if not source.is_dir():
                raise HTTPException(status_code=400, detail=f"not a directory: {source}")
            # Walk recursively so the picker can accept a top-level folder
            # whose videos live in subdirectories (mirrors the relink
            # scanner's behaviour). ``rglob`` does not follow directory
            # symlinks by default, which avoids cycles on network shares.
            for entry in sorted(source.rglob("*")):
                if not entry.is_file():
                    continue
                if entry.suffix.lower() not in VIDEO_EXTENSIONS:
                    continue
                candidates.append(entry)
            last_dir = source.resolve()
        else:
            assert req.source_paths is not None
            if not req.source_paths:
                raise HTTPException(status_code=400, detail="source_paths must be non-empty")
            for raw in req.source_paths:
                p = Path(raw).expanduser()
                if not p.exists():
                    raise HTTPException(status_code=400, detail=f"file not found: {p}")
                if not p.is_file():
                    raise HTTPException(status_code=400, detail=f"not a file: {p}")
                candidates.append(p)
            last_dir = candidates[0].parent.resolve() if candidates else None

        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        registered: list[str] = []
        skipped: list[str] = []
        for entry in candidates:
            try:
                video = project.register_video(
                    entry,
                    root,
                    link_mode=req.link_mode,  # type: ignore[arg-type]
                )
            except (FileNotFoundError, ValueError) as exc:
                skipped.append(f"{entry.name}: {exc}")
                continue
            registered.append(str(video.path))

        auto_assigned: dict[int, str] = {}
        if req.auto_assign_primary:
            suggestions = project.auto_match(root)
            for stage_num, video_path in suggestions.items():
                stage = project.stage(stage_num)
                # Only auto-assign primary when the stage has no primary yet.
                if stage.primary() is not None:
                    continue
                project.assign_video(video_path, to_stage_number=stage_num, role="primary")
                auto_assigned[stage_num] = str(video_path)

        if last_dir is not None:
            project.last_scanned_dir = str(last_dir)

        project.save(root)

        # Queue auto-beep for every freshly-primaried video (#67). Done
        # after save so the persisted state reflects the assignment when
        # the worker re-loads the project.
        for stage_num, video_path in auto_assigned.items():
            stage = project.stage(stage_num)
            video = next((v for v in stage.videos if str(v.path) == video_path), None)
            if video is not None:
                _auto_queue_beep_if_needed(slug, project, stage_num, video)

        return ScanResponse(
            registered=registered,
            auto_assigned=auto_assigned,
            skipped=skipped,
        )

    @app.get("/api/shooters/{slug}/videos/link-status", response_model=LinkStatusResponse)
    def get_link_status(slug: str) -> LinkStatusResponse:
        """Per-video status of ``raw/<name>`` symlinks.

        Lets the SPA badge broken / missing entries on the project page
        without an extra walk on every project fetch.
        """
        from .. import relink as relink_mod

        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        infos = relink_mod.inspect_links(project, root)
        return LinkStatusResponse(
            entries=[
                LinkStatusEntry(
                    video_id=info.video_id,
                    name=info.name,
                    link_path=str(info.link_path),
                    current_target=str(info.target) if info.target is not None else None,
                    status=info.status,
                )
                for info in infos
            ]
        )

    @app.post("/api/shooters/{slug}/videos/relink/scan", response_model=RelinkScanResponse)
    def relink_scan(slug: str, req: RelinkScanRequest) -> RelinkScanResponse:
        """Recursive dry-run: walk ``search_root`` and report per-video
        candidates without touching the filesystem.
        """
        from .. import relink as relink_mod

        search_root = Path(req.search_root).expanduser()
        try:
            index = relink_mod.index_search_root(search_root)
        except (FileNotFoundError, NotADirectoryError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        project = state.shooter_project(slug)
        infos = relink_mod.inspect_links(project, state.shooter_root(slug))
        plan = relink_mod.plan_relink(infos, index)
        return RelinkScanResponse(
            search_root=str(search_root.resolve()),
            entries=[
                RelinkEntryResponse(
                    video_id=entry.video_id,
                    name=entry.name,
                    link_path=str(entry.link_path),
                    current_target=(str(entry.current_target) if entry.current_target is not None else None),
                    current_status=entry.current_status,
                    candidates=[str(p) for p in entry.candidates],
                    chosen_path=str(entry.chosen_path) if entry.chosen_path is not None else None,
                    ambiguous=entry.ambiguous,
                    found=entry.found,
                )
                for entry in plan
            ],
        )

    @app.post("/api/shooters/{slug}/videos/relink/apply", response_model=RelinkApplyResponse)
    def relink_apply(slug: str, req: RelinkApplyRequest) -> RelinkApplyResponse:
        """Apply a user-confirmed set of symlink rewrites.

        ``project.json`` is not modified -- only the symlinks under
        ``raw/`` are repointed. The video_id is preserved so the SPA
        can match the response back to its rows.
        """
        from .. import relink as relink_mod

        if not req.decisions:
            raise HTTPException(status_code=400, detail="decisions must be non-empty")
        project = state.shooter_project(slug)
        infos = {info.video_id: info for info in relink_mod.inspect_links(project, state.shooter_root(slug))}
        decisions: list[tuple[Path, Path]] = []
        id_for_link: dict[Path, str] = {}
        for video_id, target_str in req.decisions.items():
            info = infos.get(video_id)
            if info is None:
                raise HTTPException(status_code=400, detail=f"unknown video_id: {video_id}")
            if info.status == "not_a_symlink":
                raise HTTPException(
                    status_code=400,
                    detail=f"{info.name} is a regular file, not a symlink -- relink not supported",
                )
            target = Path(target_str).expanduser()
            if not target.exists():
                raise HTTPException(status_code=400, detail=f"target does not exist: {target}")
            if not target.is_file():
                raise HTTPException(status_code=400, detail=f"target is not a file: {target}")
            decisions.append((info.link_path, target))
            id_for_link[info.link_path] = video_id
        applied = relink_mod.apply_relink(decisions)
        return RelinkApplyResponse(
            applied=[
                RelinkAppliedEntry(
                    video_id=id_for_link.get(entry.link_path, ""),
                    name=entry.name,
                    link_path=str(entry.link_path),
                    previous_target=(
                        str(entry.previous_target) if entry.previous_target is not None else None
                    ),
                    new_target=str(entry.new_target),
                )
                for entry in applied
            ]
        )

    @app.post("/api/shooters/{slug}/project/settings")
    def update_settings(slug: str, req: SettingsRequest) -> JSONResponse:
        """Update storage path overrides. Any None field is left unchanged;
        pass an empty string to clear back to the project-root default.

        If a path field is changing and the *old* directory contains files,
        return 409 with a structured ``non_empty_old_dirs`` payload unless
        ``confirm=True`` is sent. Existing files are not auto-migrated --
        the warning lets the caller surface "you'll be leaving these behind".
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        update: dict[str, str | None] = {}
        for fname in (
            "raw_dir",
            "audio_dir",
            "trimmed_dir",
            "exports_dir",
            "probes_dir",
            "thumbs_dir",
        ):
            value = getattr(req, fname)
            if value is None:
                continue
            normalized = value.strip() or None
            update[fname] = normalized

        # Detect non-empty old dirs for fields that are actually changing.
        resolver_for = {
            "raw_dir": project.raw_path,
            "audio_dir": project.audio_path,
            "trimmed_dir": project.trimmed_path,
            "exports_dir": project.exports_path,
            "probes_dir": project.probes_path,
            "thumbs_dir": project.thumbs_path,
        }
        non_empty: list[dict[str, object]] = []
        for fname, new_value in update.items():
            if new_value == getattr(project, fname):
                continue  # no change
            old_path = resolver_for[fname](root)
            if not old_path.exists() or not old_path.is_dir():
                continue
            try:
                file_count = sum(1 for _ in old_path.iterdir())
            except OSError:
                continue
            if file_count == 0:
                continue
            non_empty.append(
                {
                    "field": fname,
                    "path": str(old_path),
                    "file_count": file_count,
                }
            )

        if non_empty and not req.confirm:
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "non_empty_old_dirs",
                    "message": (
                        "Changing these paths will leave existing files behind "
                        "in the old location -- splitsmith does not migrate. "
                        "Resend with confirm=true to proceed."
                    ),
                    "dirs": non_empty,
                },
            )

        for fname, value in update.items():
            setattr(project, fname, value)

        for buf_field in ("trim_pre_buffer_seconds", "trim_post_buffer_seconds"):
            value = getattr(req, buf_field)
            if value is None:
                continue
            if value < 0:
                raise HTTPException(
                    status_code=400,
                    detail=f"{buf_field} must be non-negative, got {value}",
                )
            setattr(project, buf_field, value)

        # #215 -- patch the automation override on the project.
        # Replacing the whole sub-object keeps the patch shape simple
        # (the override is small enough that field-level merging would
        # add complexity without a real benefit).
        if req.automation is not None:
            project.automation = req.automation

        # Make sure each configured directory is creatable; surface a 400
        # rather than failing later in detect-beep / trim / export.
        for resolver in (
            project.raw_path,
            project.audio_path,
            project.trimmed_path,
            project.exports_path,
            project.probes_path,
            project.thumbs_path,
        ):
            target = resolver(root)
            try:
                target.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                raise HTTPException(
                    status_code=400,
                    detail=f"cannot create directory {target}: {exc}",
                ) from exc

        project.save(root)
        return JSONResponse(project.model_dump(mode="json"))

    def _resolve_stage_video(
        slug: str, stage_number: int, video_id: str
    ) -> tuple[MatchProject, StageEntry, StageVideo]:
        """Load the project + stage + video for a per-video endpoint.

        Returns the trio so the caller doesn't have to re-read state. Raises
        404 when stage / video doesn't exist; pre-flight check on the
        source-on-disk lives at the call site so endpoints that don't need
        a reachable file (clear, manual override) can skip it.
        """
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        video = stage.find_video_by_id(video_id)
        if video is None:
            raise HTTPException(
                status_code=404,
                detail=f"stage {stage_number} has no video with id {video_id!r}",
            )
        return project, stage, video

    # Cross-cam alignment is accepted as a *suggestion* (beep_source="aligned",
    # beep_reviewed=False so the SPA forces the user to verify on the waveform
    # picker) when the peak-to-runner-up ratio of the cross-correlation clears
    # this threshold. 1.0 means the landmark wasn't distinctive at all.
    # Empirically calibrated on tallmilan-2026 secondaries: same-stage pairs
    # where in-stream detection independently succeeded land at 1.23-1.34, and
    # plausible alignments on the in-stream-failed pairs land at 1.15-1.31.
    # Same-mic non-overlapping clips sit at ~1.00. 1.10 leaves a slim margin
    # over the floor while still surfacing real alignments. False positives
    # are caught by the user in the picker before "Mark reviewed"; false
    # negatives mean the user starts from the auto-detect-failed state and
    # places the marker by hand, which is the same UX as before this change.
    _align_confidence_floor = 1.10

    def _try_align_secondary_to_primary(
        root: Path,
        proj: MatchProject,
        stage: StageEntry,
        video: StageVideo,
        handle: JobHandle,
    ) -> cross_align.CrossAlignResult | None:
        """Attempt cross-correlation alignment of ``video`` against the stage's
        primary. Returns the raw result whenever cross-correlation could be
        computed (so the caller can save ``confidence`` as a diagnostic even
        below the auto-accept floor); returns ``None`` only when alignment
        isn't possible at all (no primary, no primary beep_time, audio not
        cached, landmark window too narrow). Threshold comparison happens at
        the call site so a low-confidence result can still inform the UI.

        Run only on the secondary soft-fail path -- when in-stream beep
        detection has already raised ``BeepNotFoundError``. Cheap (envelope
        cross-correlation at 200 Hz; sub-second on a 60 s clip), but not free,
        so we skip it on the primary path entirely.
        """
        primary = stage.primary()
        if primary is None or primary.beep_time is None:
            return None
        primary_audio_path = audio_helpers.primary_audio_path(root, stage.stage_number, project=proj)
        secondary_audio_path = audio_helpers.video_audio_path(root, stage.stage_number, video, project=proj)
        if not primary_audio_path.exists() or not secondary_audio_path.exists():
            # Either side missing means the user hasn't run beep-detect on
            # the primary yet, or the secondary's own audio extract failed
            # before we even got here. Both are dealt with by the existing
            # soft-fail UX -- alignment can be retried later.
            return None
        try:
            primary_audio, primary_sr = beep_detect.load_audio(primary_audio_path)
            secondary_audio, secondary_sr = beep_detect.load_audio(secondary_audio_path)
            handle.update(progress=0.45, message="Aligning to primary...")
            result = cross_align.align_secondary_to_primary(
                primary_audio,
                primary_sr,
                primary.beep_time,
                secondary_audio,
                secondary_sr,
            )
        except cross_align.CrossAlignError as exc:
            logger.info(
                "cross-align skipped for stage %d video %s: %s",
                stage.stage_number,
                video.video_id,
                exc,
            )
            return None
        return result

    def _run_detect_beep_for_video(handle: JobHandle, slug: str, stage_number: int, video_id: str) -> None:
        """Worker: detect ``video``'s beep, then auto-chain trim.

        Generic over role:
          - primary: detect -> trim -> shot_detect (existing pipeline).
          - secondary: detect -> trim (no shot_detect; the audit timeline
            is anchored to the primary's beep).

        Trim is treated as a soft failure: the beep is valuable on its
        own and the SPA can re-trim later.
        """
        handle.update(progress=0.05, message="Loading project...")
        proj = state.shooter_project(slug)
        stg = proj.stage(stage_number)
        video = stg.find_video_by_id(video_id)
        if video is None:
            raise RuntimeError(f"video {video_id} disappeared from stage {stage_number} mid-flight")
        source = proj.resolve_video_path(state.shooter_root(slug), video.path)
        role_label = "primary" if video.role == "primary" else f"cam {video.video_id[:6]}"
        handle.update(
            progress=0.15,
            message=f"Extracting audio + detecting beep ({role_label})...",
        )
        try:
            beep = audio_helpers.detect_video_beep(
                state.shooter_root(slug),
                stage_number,
                video,
                source,
                project=proj,
                ffmpeg_binary=process_runtime().ffmpeg_binary,
            )
        except beep_detect.BeepNotFoundError as exc:
            # Primary failure is fatal -- the entire downstream pipeline
            # (trim window, shot timeline) hangs off the primary beep.
            # Surfacing as a job error gets the user looking at the audio
            # right away rather than silently falling through to a wrong
            # alignment. Secondary failure is soft-handled below: many
            # non-headcam cameras (iPhone tripod, RO position, AGC'd) just
            # don't capture a sustained 2-5 kHz tone, and aborting the
            # import on every one of them is the worse UX.
            if video.role == "primary":
                raise
            logger.info(
                "no beep on secondary stage %d video %s: %s",
                stage_number,
                video.video_id,
                exc,
            )
            # Cross-correlation fallback: when the primary already has a
            # beep, try aligning the secondary's audio against the
            # primary's landmark window. Same buzzer + first shots in the
            # same room means the loudness envelopes line up modulo a
            # constant time offset, even when the secondary's mic missed
            # the sustained 2-5 kHz tone the in-stream detector wants.
            aligned = _try_align_secondary_to_primary(state.shooter_root(slug), proj, stg, video, handle)
            video.beep_peak_amplitude = None
            video.beep_duration_ms = None
            video.beep_candidates = []
            video.beep_reviewed = False
            video.processed["beep"] = True
            # Surface the cross-correlation confidence whenever we got one,
            # even if we don't promote the suggestion. Lets the UI tell the
            # difference between "never tried" and "tried, sub-floor result".
            video.beep_alignment_confidence = aligned.confidence if aligned is not None else None
            # Delta is only meaningful when both in-stream AND cross-align
            # produced timestamps. In-stream failed here, so wipe it.
            video.beep_alignment_delta_ms = None
            if aligned is not None and aligned.confidence >= _align_confidence_floor:
                handle.update(
                    progress=0.55,
                    message=(f"Aligned to primary (conf {aligned.confidence:.2f}); " "verify on waveform"),
                )
                video.beep_time = aligned.secondary_beep_time
                video.beep_source = "aligned"
                video.beep_auto_detect_failed = False
                # Treat as "we have a usable beep_time": fall through to
                # the trim block below.
                beep = aligned
            else:
                if aligned is not None:
                    logger.info(
                        "cross-align below floor for stage %d video %s: conf %.2f < %.2f",
                        stage_number,
                        video.video_id,
                        aligned.confidence,
                        _align_confidence_floor,
                    )
                handle.update(progress=0.55, message="No beep detected; pick on waveform")
                video.beep_time = None
                video.beep_source = "auto"
                video.beep_auto_detect_failed = True
                video.processed["trim"] = False
                beep = None
        else:
            handle.update(progress=0.55, message="Saving beep...")
            video.beep_time = beep.time
            video.beep_source = "auto"
            video.beep_peak_amplitude = beep.peak_amplitude
            video.beep_duration_ms = beep.duration_ms
            video.beep_confidence = beep.confidence
            video.beep_candidates = list(beep.candidates)
            video.beep_auto_detect_failed = False
            video.beep_alignment_confidence = None
            video.beep_alignment_delta_ms = None
            video.processed["beep"] = True
            # Auto-detected beeps need explicit user review (#71) UNLESS
            # the calibrated confidence (#220 layer 3a) clears the
            # ``beep_low_confidence_threshold`` automation gate (#219).
            # Above the threshold we auto-trust: the detector is right
            # ~95 % of the time in that band, so making the user click
            # to confirm every high-confidence beep adds friction
            # without catching real problems. Below it the user has to
            # review -- the HITL queue (``GET /api/hitl-queue``) lists
            # exactly these. Resets to False on re-detection so the
            # prior approval doesn't carry over to a fresh run.
            resolved_auto = automation_settings.resolve_automation(
                project_override=proj.automation,
            )
            threshold = resolved_auto.settings.beep_low_confidence_threshold
            video.beep_reviewed = beep.confidence >= threshold
            # Sanity check: when in-stream succeeded on a secondary, ALSO
            # run cross-correlation against the primary. If the two
            # methods disagree by more than ~250 ms it usually means the
            # in-stream detector locked onto something that wasn't the
            # buzzer (a steel-strike that resembles a tone, an early
            # range-officer command, etc.). The delta is surfaced in the
            # SPA so the user can compare both candidates on the
            # waveform before marking reviewed. Never overrides the
            # in-stream result -- in-stream has frequency-domain
            # information cross-align doesn't, so when they agree we
            # trust the in-stream answer; when they disagree we let the
            # user decide.
            if video.role != "primary":
                check = _try_align_secondary_to_primary(state.shooter_root(slug), proj, stg, video, handle)
                if check is not None and check.confidence >= _align_confidence_floor:
                    video.beep_alignment_confidence = check.confidence
                    video.beep_alignment_delta_ms = (beep.time - check.secondary_beep_time) * 1000.0

        trimmed_ok = False
        if beep is not None and stg.time_seconds > 0:
            handle.check_cancel()
            handle.update(progress=0.55, message=f"Trimming audit clip ({role_label})...")
            try:
                audio_helpers.ensure_video_audit_trim(
                    state.shooter_root(slug),
                    stage_number,
                    video,
                    source,
                    video.beep_time,
                    stg.time_seconds,
                    project=proj,
                    runner=_cancellable_runner(handle),
                    ffmpeg_binary=process_runtime().ffmpeg_binary,
                )
                video.processed["trim"] = True
                trimmed_ok = True
            except (FileNotFoundError, audio_helpers.AudioExtractionError) as exc:
                # Soft failure: beep alone is still useful, especially for
                # secondaries (audit alignment works without a trim cache).
                logger.warning(
                    "auto-trim failed for stage %d video %s: %s",
                    stage_number,
                    video.video_id,
                    exc,
                )
                handle.update(message=f"beep saved; trim failed: {exc}")
        handle.update(progress=0.85, message="Saving project...")
        # Read-modify-write the project file: extract / detection /
        # ffmpeg trim can take 30+ s during which the user may have
        # toggled ``beep_reviewed`` on other stages. Reloading and
        # copying our targeted fields onto the fresh project preserves
        # those concurrent edits instead of stomping them with the
        # snapshot we loaded at job start.
        fresh = state.shooter_project(slug)
        try:
            stg_fresh = fresh.stage(stage_number)
        except KeyError:
            stg_fresh = None
        v_fresh = stg_fresh.find_video_by_id(video_id) if stg_fresh is not None else None
        if v_fresh is not None:
            v_fresh.beep_time = video.beep_time
            v_fresh.beep_source = video.beep_source
            v_fresh.beep_peak_amplitude = video.beep_peak_amplitude
            v_fresh.beep_duration_ms = video.beep_duration_ms
            v_fresh.beep_confidence = video.beep_confidence
            v_fresh.beep_candidates = list(video.beep_candidates)
            v_fresh.beep_reviewed = video.beep_reviewed
            v_fresh.beep_auto_detect_failed = video.beep_auto_detect_failed
            v_fresh.beep_alignment_confidence = video.beep_alignment_confidence
            v_fresh.beep_alignment_delta_ms = video.beep_alignment_delta_ms
            v_fresh.processed["beep"] = True
            if trimmed_ok:
                v_fresh.processed["trim"] = True
            fresh.save(state.shooter_root(slug))
        if trimmed_ok and video.role == "primary" and video.beep_reviewed:
            # Shot detection is primary-only AND gated on
            # ``beep_reviewed`` (#71). That flag is True either because
            # the user explicitly clicked "Mark reviewed" (which
            # re-triggers chaining via ``set_beep_reviewed``) or because
            # the auto-trust gate cleared (#219 layer 3b: confidence at
            # or above ``beep_low_confidence_threshold``). Saves the
            # heavy CLAP / GBDT / PANN ensemble work when the beep
            # timestamp is wrong, since everything downstream of it
            # would be garbage anyway.
            #
            # Layered automation gate (#215): users can disable the
            # auto-trigger globally or per project. ``cli_override`` is
            # always None for the server -- the daemon doesn't take
            # CLI flags at this entry point.
            resolved = automation_settings.resolve_automation(
                project_override=fresh.automation,
            )
            if (
                resolved.settings.shot_detect_on_beep_verified
                and state.jobs.find_active(kind="shot_detect", stage_number=stage_number) is None
            ):
                state.jobs.submit(
                    kind="shot_detect",
                    stage_number=stage_number,
                    fn=lambda h, sl=slug, n=stage_number: _run_shot_detect(h, sl, n),
                )
        handle.update(progress=1.0, message="Done")

    def _submit_detect_beep(slug: str, stage_number: int, video: StageVideo) -> JSONResponse:
        """Validate + dedupe + queue a detect-beep job for ``video``.

        Shared by the per-video endpoint and the primary-only legacy
        endpoint so both honour the same reachability + manual-override
        pre-flight checks.
        """
        existing = state.jobs.find_active(
            kind="detect_beep", stage_number=stage_number, video_id=video.video_id
        )
        if existing is not None:
            return JSONResponse(existing.model_dump(mode="json"))
        job = state.jobs.submit(
            kind="detect_beep",
            stage_number=stage_number,
            video_id=video.video_id,
            fn=lambda h, sl=slug, n=stage_number, vid=video.video_id: (
                _run_detect_beep_for_video(h, sl, n, vid)
            ),
        )
        return JSONResponse(job.model_dump(mode="json"))

    def _auto_queue_beep_if_needed(
        slug: str, project: MatchProject, stage_number: int, video: StageVideo
    ) -> bool:
        """Best-effort auto-queue of detect_beep on a freshly-assigned video.

        Hooked into scan auto-assign, ``/assignments/move``, and
        ``/assignments/swap-primary`` so the user doesn't have to click
        "detect beep" on every camera before the audit screen is useful
        (#67). Auto-firing is conservative -- we silently skip whenever
        manual user action is the right call:

        - already detected (``processed.beep``) or manually overridden
          (``beep_source == "manual"``) -- never replace user input
        - role ``ignored`` -- video is intentionally outside the pipeline
        - source not reachable -- USB / SD card likely unplugged; the
          user will retry by hand once it's back
        - duplicate active job -- ``_submit_detect_beep`` already dedupes
          by (kind, stage, video_id), but checking up front avoids the
          unnecessary JSONResponse round-trip
        - ``SPLITSMITH_AUTO_BEEP_DISABLED=1`` is set -- escape hatch for
          tests that need to assert pre-detection state without racing
          against an auto-fired worker

        Returns True when a job was queued (or already running), False
        when skipped. Callers don't need to react; the SPA picks up the
        new job via its existing JobsPanel polling.
        """
        if os.environ.get("SPLITSMITH_AUTO_BEEP_DISABLED") == "1":
            return False
        if video.role == "ignored":
            return False
        if video.processed.get("beep") or video.beep_time is not None:
            return False
        if video.beep_source == "manual":
            return False
        source = project.resolve_video_path(state.shooter_root(slug), video.path)
        if not source.exists():
            logger.info(
                "auto-beep skipped for stage %d video %s: source not reachable (%s)",
                stage_number,
                video.video_id,
                source,
            )
            return False
        _submit_detect_beep(slug, stage_number, video)
        return True

    @app.post("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/detect-beep")
    def detect_beep_for_video(
        slug: str, stage_number: int, video_id: str, force: bool = False
    ) -> JSONResponse:
        """Submit a beep-detection job for ``video_id`` on ``stage_number``.

        Generic over role (primary or secondary): each video gets its own
        detect job, its own beep timestamp, its own short-GOP trim, and
        its own dedupe slot in the registry so the user can run primary +
        Cam 2 + Cam 3 in parallel. Shot detection auto-chains only for
        primary results; secondaries align to the primary timeline by
        their own beep so they don't need their own shot timeline.
        """
        project, _stage, video = _resolve_stage_video(slug, stage_number, video_id)
        _ensure_source_reachable(
            stage_number, project.resolve_video_path(state.shooter_root(slug), video.path)
        )
        if video.beep_source == "manual" and not force:
            raise HTTPException(
                status_code=409,
                detail=(
                    "video has a manual beep override; pass ?force=true to "
                    "replace it with auto-detected output"
                ),
            )
        return _submit_detect_beep(slug, stage_number, video)

    @app.post("/api/shooters/{slug}/stages/{stage_number}/detect-beep")
    def detect_beep(slug: str, stage_number: int, force: bool = False) -> JSONResponse:
        """Submit a beep-detection job for the stage's primary.

        Backward-compat shim that resolves the primary's id and forwards to
        the per-video pipeline. Returns a Job snapshot immediately; the SPA
        polls ``/api/jobs/{id}`` for progress and refetches ``/api/project``
        on completion.
        """
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        primary = stage.primary()
        if primary is None:
            raise HTTPException(
                status_code=400,
                detail=f"stage {stage_number} has no primary video",
            )
        _ensure_source_reachable(
            stage_number, project.resolve_video_path(state.shooter_root(slug), primary.path)
        )
        if primary.beep_source == "manual" and not force:
            raise HTTPException(
                status_code=409,
                detail=(
                    "stage has a manual beep override; pass ?force=true to "
                    "replace it with auto-detected output"
                ),
            )
        return _submit_detect_beep(slug, stage_number, primary)

    @app.post("/api/shooters/{slug}/stages/{stage_number}/trim")
    def trim_stage(slug: str, stage_number: int) -> JSONResponse:
        """Submit an audit-mode short-GOP trim job for the stage's primary.

        Backward-compat shim: forwards to the per-video pipeline. Returns
        a Job snapshot. Idempotent on the worker side: when the cached
        MP4 is newer than the source, the job completes near-instantly
        without re-encoding.
        """
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        primary = stage.primary()
        if primary is None:
            raise HTTPException(
                status_code=400,
                detail=f"stage {stage_number} has no primary video",
            )
        return _submit_trim(slug, stage_number, stage, primary, project)

    def _submit_trim(
        slug: str,
        stage_number: int,
        stage: StageEntry,
        video: StageVideo,
        project: MatchProject,
    ) -> JSONResponse:
        """Validate + dedupe + queue a trim job for ``video``.

        Pre-flight checks (reachability, beep present, stage_time set)
        apply equally to primary and secondary -- both need a beep_time
        and a non-zero stage_time to define the trim window.
        """
        _ensure_source_reachable(
            stage_number, project.resolve_video_path(state.shooter_root(slug), video.path)
        )
        if video.beep_time is None:
            raise HTTPException(
                status_code=400,
                detail=f"stage {stage_number} video has no beep_time yet",
            )
        if stage.time_seconds <= 0:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"stage {stage_number} has time_seconds=0; import a "
                    "scoreboard or set the stage time before trimming"
                ),
            )
        existing = state.jobs.find_active(kind="trim", stage_number=stage_number, video_id=video.video_id)
        if existing is not None:
            return JSONResponse(existing.model_dump(mode="json"))
        job = state.jobs.submit(
            kind="trim",
            stage_number=stage_number,
            video_id=video.video_id,
            fn=lambda h, sl=slug, n=stage_number, vid=video.video_id: (_run_trim_for_video(h, sl, n, vid)),
        )
        return JSONResponse(job.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/trim")
    def trim_for_video(slug: str, stage_number: int, video_id: str) -> JSONResponse:
        """Submit an audit-mode trim job for ``video_id`` on ``stage_number``."""
        project, stage, video = _resolve_stage_video(slug, stage_number, video_id)
        return _submit_trim(slug, stage_number, stage, video, project)

    def _run_trim_for_video(handle: JobHandle, slug: str, stage_number: int, video_id: str) -> None:
        """Worker for the audit-mode trim of a specific video.

        Auto-chains shot detection only when the trimmed video is the
        primary; secondaries align to the primary's audit timeline by
        their own beep, so they do not need their own shot-detection run.
        """
        handle.update(progress=0.1, message="Preparing trim...")
        proj = state.shooter_project(slug)
        stg = proj.stage(stage_number)
        video = stg.find_video_by_id(video_id)
        if video is None or video.beep_time is None:
            raise RuntimeError("video or beep disappeared mid-flight")
        source = proj.resolve_video_path(state.shooter_root(slug), video.path)
        handle.check_cancel()
        role_label = "primary" if video.role == "primary" else f"cam {video.video_id[:6]}"
        handle.update(progress=0.3, message=f"Encoding short-GOP MP4 ({role_label})...")
        audio_helpers.ensure_video_audit_trim(
            state.shooter_root(slug),
            stage_number,
            video,
            source,
            video.beep_time,
            stg.time_seconds,
            project=proj,
            runner=_cancellable_runner(handle),
            ffmpeg_binary=process_runtime().ffmpeg_binary,
        )
        handle.update(progress=0.85, message="Saving project...")
        # Read-modify-write to avoid stomping concurrent edits made
        # while ffmpeg was running (e.g. another stage's beep review).
        fresh = state.shooter_project(slug)
        stg_fresh = fresh.stage(stage_number)
        v_fresh = stg_fresh.find_video_by_id(video_id)
        if v_fresh is not None:
            v_fresh.processed["trim"] = True
            fresh.save(state.shooter_root(slug))
        if (
            video.role == "primary"
            and video.beep_reviewed
            and state.jobs.find_active(kind="shot_detect", stage_number=stage_number) is None
        ):
            # Same gate as the detect-then-trim path (#71): don't burn
            # CLAP / GBDT / PANN cycles on a beep the user hasn't
            # confirmed. Manual entries pre-set ``beep_reviewed`` to True
            # so this still runs; the auto-detect path waits for the
            # user's explicit "Mark reviewed" click which re-fires
            # shot_detect from there.
            #
            # Layered automation gate (#215): a global / project
            # opt-out can suppress this auto-trigger.
            resolved = automation_settings.resolve_automation(
                project_override=fresh.automation,
            )
            if resolved.settings.shot_detect_on_beep_verified:
                state.jobs.submit(
                    kind="shot_detect",
                    stage_number=stage_number,
                    fn=lambda h, sl=slug, n=stage_number: _run_shot_detect(h, sl, n),
                )
        handle.update(progress=1.0, message="Done")

    def _run_trim_at_root(
        handle: JobHandle,
        shooter_root: Path,
        stage_number: int,
        video_id: str,
    ) -> None:
        """Like :func:`_run_trim_for_video` but scoped to an explicit
        ``shooter_root`` instead of the server's bound ``state``. Used by
        the bulk-rebuild endpoint so the operator can regenerate trim
        caches for a non-active shooter without rebinding (which would
        force-reload their current Audit / Compare context).

        Unlike the bound variant this never auto-chains shot detection --
        the operator is doing a maintenance pass on derived data; the
        original audit + shot results are kept as-is.
        """
        handle.update(progress=0.1, message="Preparing trim...")
        proj = MatchProject.load(shooter_root)
        stg = proj.stage(stage_number)
        video = stg.find_video_by_id(video_id)
        if video is None or video.beep_time is None:
            raise RuntimeError("video or beep disappeared mid-flight")
        source = proj.resolve_video_path(shooter_root, video.path)
        handle.check_cancel()
        role_label = "primary" if video.role == "primary" else f"cam {video.video_id[:6]}"
        handle.update(progress=0.3, message=f"Encoding short-GOP MP4 ({role_label})...")
        audio_helpers.ensure_video_audit_trim(
            shooter_root,
            stage_number,
            video,
            source,
            video.beep_time,
            stg.time_seconds,
            project=proj,
            runner=_cancellable_runner(handle),
            ffmpeg_binary=process_runtime().ffmpeg_binary,
        )
        handle.update(progress=0.85, message="Saving project...")
        fresh = MatchProject.load(shooter_root)
        stg_fresh = fresh.stage(stage_number)
        v_fresh = stg_fresh.find_video_by_id(video_id)
        if v_fresh is not None:
            v_fresh.processed["trim"] = True
            fresh.save(shooter_root)
        handle.update(progress=1.0, message="Done")

    def _run_trim_for_stage(handle: JobHandle, slug: str, stage_number: int) -> None:
        """Backward-compat shim for legacy callers (e.g. beep-override
        endpoints) that submit a trim by stage_number alone.

        Resolves the stage's primary and forwards to the per-video
        worker. New callers should pass a ``video_id`` and submit via
        :func:`_run_trim_for_video` directly.
        """
        proj = state.shooter_project(slug)
        try:
            stg = proj.stage(stage_number)
        except KeyError as exc:
            raise RuntimeError(f"stage {stage_number} disappeared mid-flight: {exc}") from exc
        primary = stg.primary()
        if primary is None:
            raise RuntimeError(f"stage {stage_number} has no primary mid-flight")
        _run_trim_for_video(handle, slug, stage_number, primary.video_id)

    def _run_shot_detect(handle: JobHandle, slug: str, stage_number: int, reset: bool = False) -> None:
        """Worker that runs the 4-voter ensemble on the stage's audit clip.

        Reads the trimmed clip's WAV (extracting it on demand if needed),
        runs ``splitsmith.ensemble.detect_shots_ensemble`` over the
        ``[beep .. beep+stage]`` window, and writes both the consensus
        ``shots[]`` and the full voter-A universe into the audit JSON.

        ``_candidates_pending_audit.candidates`` carries every candidate
        annotated with per-voter signals (vote_a/b/c/d, ensemble_score,
        score_c, clap_diff, gunshot_prob) so the audit UI can render the
        decision trail. ``shots[]`` is seeded from the consensus subset
        unless it is already populated -- the user retains authority. If
        ``reset`` is True, ``shots[]`` is wiped first so the user can
        start over after a bad beep / detector pass.

        Adaptive prior: if the audit JSON already carries
        ``stage_rounds.expected``, voter C switches to its adaptive
        top-(K+slack) mode and the apriori boost lifts the top-K
        confidence-ranked candidates over the consensus line.
        """
        proj = state.shooter_project(slug)
        stg = proj.stage(stage_number)
        prim = stg.primary()
        if prim is None or prim.beep_time is None:
            raise RuntimeError(f"stage {stage_number} has no primary or no beep yet")
        if stg.time_seconds <= 0:
            raise RuntimeError(
                f"stage {stage_number} has time_seconds=0; import a "
                "scoreboard before running shot detection"
            )
        source = proj.resolve_video_path(state.shooter_root(slug), prim.path)

        # Re-detect-all on an old project (and the v1->v2 cache migration in
        # #298) leaves stages with no trimmed MP4 cached. Without that file,
        # ensure_audit_audio falls back to the full source WAV -- shot
        # detection still works, but the audit page then streams the raw
        # source clip into <video>, where long-GOP 4K MOVs wedge in buffering
        # on first play. Force the trim here so every shot-detect run leaves
        # the audit cache in the same state the beep-detect path would have.
        handle.update(progress=0.05, message="Ensuring audit trim...")
        try:
            audio_helpers.ensure_video_audit_trim(
                state.shooter_root(slug),
                stage_number,
                prim,
                source,
                prim.beep_time,
                stg.time_seconds,
                project=proj,
                runner=_cancellable_runner(handle),
                ffmpeg_binary=process_runtime().ffmpeg_binary,
            )
            trim_fresh = state.shooter_project(slug)
            try:
                v_fresh = trim_fresh.stage(stage_number).find_video_by_id(prim.video_id)
            except KeyError:
                v_fresh = None
            if v_fresh is not None and not v_fresh.processed.get("trim"):
                v_fresh.processed["trim"] = True
                trim_fresh.save(state.shooter_root(slug))
        except (FileNotFoundError, audio_helpers.AudioExtractionError) as exc:
            # Soft failure: detection can still proceed against the source
            # WAV. ensure_audit_audio's fallback handles the missing trim,
            # so we log and continue rather than abort the whole job.
            logger.warning(
                "shot_detect could not (re)build trim for stage %d: %s",
                stage_number,
                exc,
            )

        handle.update(progress=0.1, message="Preparing audio...")
        audit = audio_helpers.ensure_audit_audio(
            state.shooter_root(slug),
            stage_number,
            source,
            prim.beep_time,
            project=proj,
            ffmpeg_binary=process_runtime().ffmpeg_binary,
        )
        beep_in_clip = audit.beep_in_clip if audit.beep_in_clip is not None else prim.beep_time

        # Read existing audit JSON up-front: we need ``stage_rounds.expected``
        # before running detection (it changes voter C's mode and the
        # apriori boost) and we'll merge results back into the same dict.
        audit_dir = proj.audit_path(state.shooter_root(slug))
        audit_dir.mkdir(parents=True, exist_ok=True)
        audit_file = audit_dir / f"stage{stage_number}.json"
        if audit_file.exists():
            try:
                existing_json = json.loads(audit_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                existing_json = {}
        else:
            existing_json = {
                "stage_number": stg.stage_number,
                "stage_name": stg.stage_name,
                "stage_time_seconds": stg.time_seconds,
                "beep_time": round(beep_in_clip, 4),
                "shots": [],
            }
        # Carry stage_rounds (min_rounds + target breakdown) from the
        # project state into the audit JSON so the ensemble's adaptive
        # voter C + apriori boost can consume ``stage_rounds.expected``.
        # Project value wins over a stale audit-JSON copy: re-running
        # detection after a scoreboard refresh should pick up the new
        # round count without manual edits.
        if stg.stage_rounds is not None:
            existing_json["stage_rounds"] = stg.stage_rounds.model_dump(mode="json", exclude_none=True)
        expected_rounds: int | None = None
        sr_block = existing_json.get("stage_rounds")
        if isinstance(sr_block, dict):
            raw = sr_block.get("expected")
            if isinstance(raw, int) and raw > 0:
                expected_rounds = raw

        handle.update(progress=0.2, message="Loading ensemble models...")
        runtime = _get_ensemble_runtime()

        handle.update(progress=0.4, message="Detecting shots (4-voter ensemble)...")
        audio_array, sr = beep_detect.load_audio(audit.audio_path)
        # Camera-class dispatch (issue #143). When the primary's mount
        # is set, look up handheld vs. headcam thresholds; otherwise
        # the ensemble falls back to the default class (headcam).
        cam_class = ensemble_module.camera_class_from_mount(prim.camera_mount)
        # Voter E opt-in (issue #183). Off by default for the first
        # release; flip via env var until corpus growth justifies
        # default-on. Requires the calibration to ship a probe head
        # AND the source video to be reachable.
        enable_e = os.environ.get("SPLITSMITH_ENABLE_VOTER_E") == "1"
        ensemble_cfg = ensemble_module.EnsembleConfig(enable_voter_e=enable_e)
        result = ensemble_module.detect_shots_ensemble(
            audio_array,
            sr,
            beep_in_clip,
            stg.time_seconds,
            runtime,
            expected_rounds=expected_rounds,
            ensemble_config=ensemble_cfg,
            camera_class=cam_class,
            camera_make=prim.camera_make,
            camera_model=prim.camera_model,
            video_path=source if enable_e else None,
            source_beep_time=prim.beep_time if enable_e else None,
        )

        candidates: list[dict[str, Any]] = []
        for cand in result.candidates:
            candidates.append(
                {
                    "candidate_number": cand.candidate_number,
                    "time": cand.time,
                    "ms_after_beep": cand.ms_after_beep,
                    "peak_amplitude": cand.peak_amplitude,
                    "confidence": cand.confidence,
                    "vote_a": cand.vote_a,
                    "vote_b": cand.vote_b,
                    "vote_c": cand.vote_c,
                    "vote_e": cand.vote_e,
                    "vote_total": cand.vote_total,
                    "apriori_boost": cand.apriori_boost,
                    "ensemble_score": cand.ensemble_score,
                    "score_c": cand.score_c,
                    "clap_diff": cand.clap_diff,
                    "gunshot_prob": cand.gunshot_prob,
                    "voter_e_signal": cand.voter_e_signal,
                }
            )

        handle.update(progress=0.85, message="Saving audit JSON...")
        existing_json["_candidates_pending_audit"] = {
            "_note": (
                "3-voter ensemble (PANN gunshot folded into voter C). "
                "vote_a/b/c=1 means the voter kept the candidate; "
                "ensemble_score = vote_total + apriori_boost. shots[] is "
                "seeded from candidates with ensemble_score >= consensus."
            ),
            "consensus": result.consensus,
            "expected_rounds": result.expected_rounds,
            "candidates": candidates,
        }
        if reset:
            existing_json["shots"] = []
        seeded_shots = False
        if not existing_json.get("shots"):
            kept = [c for c in result.candidates if c.kept]
            existing_json["shots"] = [
                {
                    "shot_number": i,
                    "candidate_number": c.candidate_number,
                    "time": c.time,
                    "ms_after_beep": c.ms_after_beep,
                    "source": "detected",
                    "ensemble_votes": c.vote_total,
                    "apriori_boost": c.apriori_boost,
                    "ensemble_score": c.ensemble_score,
                }
                for i, c in enumerate(kept, start=1)
            ]
            seeded_shots = True
        events = list(existing_json.get("audit_events") or [])
        events.append(
            {
                "ts": _now_iso(),
                "kind": "shot_detect_run",
                "payload": {
                    "candidate_count": len(candidates),
                    "kept_count": sum(1 for c in result.candidates if c.kept),
                    "consensus": result.consensus,
                    "expected_rounds": result.expected_rounds,
                    "seeded_shots": seeded_shots,
                },
            }
        )
        existing_json["audit_events"] = events

        # Atomic write + .bak (mirrors put_stage_audit).
        tmp = audit_file.with_suffix(audit_file.suffix + ".tmp")
        backup = audit_file.with_suffix(audit_file.suffix + ".bak")
        tmp.write_text(json.dumps(existing_json, indent=2) + "\n", encoding="utf-8")
        if audit_file.exists():
            if backup.exists():
                backup.unlink()
            audit_file.replace(backup)
        tmp.replace(audit_file)

        # Read-modify-write the project file: a long-running shot_detect
        # job must not save the snapshot it loaded at start, because the
        # user may have toggled ``beep_reviewed`` on other stages in the
        # interim (the review action kicks shot_detect, so concurrent
        # bursts are the common case). Reloading from disk and mutating
        # only the targeted field preserves those concurrent edits.
        fresh = state.shooter_project(slug)
        stg_fresh = fresh.stage(stage_number)
        prim_fresh = stg_fresh.primary()
        if prim_fresh is not None:
            prim_fresh.processed["shot_detect"] = True
            fresh.save(state.shooter_root(slug))
        handle.update(progress=1.0, message=f"Done -- {len(candidates)} candidates")

    @app.post("/api/shooters/{slug}/stages/shot-detect")
    def shot_detect_all_endpoint(slug: str, reset: bool = False) -> JSONResponse:
        """Submit shot-detection on every eligible stage in the project.

        A stage is eligible when it has a primary video with a confirmed
        ``beep_time`` and ``time_seconds > 0`` -- i.e. the same gates the
        per-stage endpoint checks. Stages that don't qualify are silently
        skipped and reported in ``skipped`` so the SPA can surface them.

        Idempotent dedupe: stages with an already-active shot-detect job
        adopt the existing job instead of starting a second.

        ``reset=true`` clears each affected stage's ``shots[]`` before
        running, matching the per-stage endpoint's semantics.
        """
        project = state.shooter_project(slug)
        jobs: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        for stage in project.stages:
            stage_number = stage.stage_number
            primary = stage.primary()
            if primary is None:
                skipped.append({"stage_number": stage_number, "reason": "no_primary"})
                continue
            if primary.beep_time is None:
                skipped.append({"stage_number": stage_number, "reason": "no_beep"})
                continue
            if stage.time_seconds <= 0:
                skipped.append({"stage_number": stage_number, "reason": "no_time_seconds"})
                continue
            existing = state.jobs.find_active(kind="shot_detect", stage_number=stage_number)
            if existing is not None:
                jobs.append(existing.model_dump(mode="json"))
                continue
            job = state.jobs.submit(
                kind="shot_detect",
                stage_number=stage_number,
                fn=lambda h, sl=slug, n=stage_number, r=reset: _run_shot_detect(h, sl, n, reset=r),
            )
            jobs.append(job.model_dump(mode="json"))
        return JSONResponse({"jobs": jobs, "skipped": skipped})

    @app.post("/api/shooters/{slug}/stages/{stage_number}/shot-detect")
    def shot_detect_endpoint(slug: str, stage_number: int, reset: bool = False) -> JSONResponse:
        """Submit a shot-detection job for the stage's audit clip.

        Returns a Job snapshot. Idempotent dedupe via the registry: a second
        click while one is running adopts the existing job. The candidate
        list lands in the audit JSON's ``_candidates_pending_audit`` block,
        which is what the audit screen reads to render markers.

        ``reset=true`` wipes ``shots[]`` first so the user can start over.
        """
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        primary = stage.primary()
        if primary is None:
            raise HTTPException(
                status_code=400,
                detail=f"stage {stage_number} has no primary video",
            )
        if primary.beep_time is None:
            raise HTTPException(
                status_code=400,
                detail=f"stage {stage_number} primary has no beep_time yet",
            )
        if stage.time_seconds <= 0:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"stage {stage_number} has time_seconds=0; import a "
                    "scoreboard before running shot detection"
                ),
            )

        existing = state.jobs.find_active(kind="shot_detect", stage_number=stage_number)
        if existing is not None:
            return JSONResponse(existing.model_dump(mode="json"))
        job = state.jobs.submit(
            kind="shot_detect",
            stage_number=stage_number,
            fn=lambda h, sl=slug, r=reset: _run_shot_detect(h, sl, stage_number, reset=r),
        )
        return JSONResponse(job.model_dump(mode="json"))

    @app.get("/api/me/jobs", response_model=list[Job])
    def list_jobs() -> list[Job]:
        """Snapshot of all retained jobs (active + recently finished)."""
        return state.jobs.list()

    @app.get("/api/me/jobs/{job_id}", response_model=Job)
    def get_job(job_id: str) -> Job:
        """Poll a single job. SPA polls ~1 Hz while a job is active."""
        job = state.jobs.get(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail=f"unknown job: {job_id}")
        return job

    @app.post("/api/me/jobs/acknowledge-failures", response_model=list[Job])
    def acknowledge_all_failures() -> list[Job]:
        """Mark every currently-unacknowledged FAILED job as seen (issue #73).

        Used by the JobsPanel "Dismiss all failures" header action. Returns
        the snapshots that actually flipped to acknowledged so the SPA can
        diff against its in-memory list without an extra refetch.
        """
        return state.jobs.acknowledge_all_failures()

    @app.post("/api/me/jobs/{job_id}/acknowledge", response_model=Job)
    def acknowledge_job(job_id: str) -> Job:
        """Mark a single failed job as seen (issue #73).

        No-op for jobs that aren't failed or are already acknowledged --
        the snapshot is returned unchanged so the SPA can still pin its
        local state to the server response.
        """
        job = state.jobs.acknowledge(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail=f"unknown job: {job_id}")
        return job

    @app.post("/api/me/jobs/{job_id}/cancel", response_model=Job)
    def cancel_job(job_id: str) -> Job:
        """Request cooperative cancellation of a running or pending job.

        The registry sets ``cancel_requested=True`` and (for trim jobs)
        terminates the running ffmpeg subprocess. The worker then bails
        out at its next phase boundary, ending the job in
        ``status=cancelled``. Idempotent: cancelling a finished job
        returns the existing snapshot unchanged.
        """
        job = state.jobs.cancel(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail=f"unknown job: {job_id}")
        return job

    def _apply_beep_override(
        slug: str,
        project: MatchProject,
        stage: StageEntry,
        video: StageVideo,
        beep_time: float | None,
    ) -> None:
        """Apply a manual beep override to ``video``.

        Generic over role: secondaries also need their cached trim
        invalidated when the user moves their beep, since the trim window
        is anchored to that beep. ``beep_time=None`` clears back to "no
        beep yet"; otherwise sets ``beep_source="manual"`` and drops the
        candidate list so the UI doesn't keep suggesting a stale auto pick.
        Shot-detect flag clearing is primary-only -- secondaries don't
        carry their own shot timeline.
        """
        if beep_time is None:
            video.beep_time = None
            video.beep_source = None
            video.beep_peak_amplitude = None
            video.beep_duration_ms = None
            video.beep_confidence = None
            video.beep_candidates = []
            video.beep_auto_detect_failed = False
            video.beep_alignment_confidence = None
            video.beep_alignment_delta_ms = None
            video.processed["beep"] = False
            video.processed["trim"] = False
            video.beep_reviewed = False
            if video.role == "primary":
                video.processed["shot_detect"] = False
        else:
            video.beep_time = beep_time
            video.beep_source = "manual"
            video.beep_peak_amplitude = None
            video.beep_duration_ms = None
            # Manual entry pins confidence at 1.0 -- the user told us
            # where the beep is, so the auto-trust gate (#219) opens.
            video.beep_confidence = 1.0
            video.beep_candidates = []
            video.beep_auto_detect_failed = False
            video.beep_alignment_confidence = None
            video.beep_alignment_delta_ms = None
            video.processed["beep"] = True
            video.processed["trim"] = False
            # Manual beep entry implies the user looked at the
            # waveform to type the value -- skip the review pill (#71).
            video.beep_reviewed = True
            if video.role == "primary":
                video.processed["shot_detect"] = False

        audio_helpers.invalidate_video_audit_trim(
            state.shooter_root(slug), stage.stage_number, video, project=project
        )

    def _maybe_chain_trim(slug: str, stage: StageEntry, video: StageVideo) -> None:
        """Auto-fire a trim job for ``video`` when conditions allow.

        Used after a beep override / candidate select: if the user just
        gave us a beep and the stage time is known, the next thing they
        want is a fresh short-GOP trim. Dedupes through ``find_active``
        so a still-running job adopts instead of racing.
        """
        if video.beep_time is None or stage.time_seconds <= 0:
            return
        if (
            state.jobs.find_active(kind="trim", stage_number=stage.stage_number, video_id=video.video_id)
            is not None
        ):
            return
        state.jobs.submit(
            kind="trim",
            stage_number=stage.stage_number,
            video_id=video.video_id,
            fn=lambda h, sl=slug, n=stage.stage_number, vid=video.video_id: (
                _run_trim_for_video(h, sl, n, vid)
            ),
        )

    def _select_candidate_on_video(video: StageVideo, time_value: float) -> None:
        """Promote the candidate at ``time_value`` (within 1 ms) on ``video``.

        Mirrors the v1 primary path: the time still came from the detector
        so ``beep_source="auto"`` is preserved; only the chosen candidate
        changes. Raises ``HTTPException`` for caller-facing errors so both
        the per-video and legacy primary endpoints get the same response
        shapes.
        """
        if not video.beep_candidates:
            raise HTTPException(
                status_code=400,
                detail="video has no candidate list yet; run detect-beep first",
            )
        match_eps = 1e-3
        chosen = None
        for c in video.beep_candidates:
            if abs(c.time - time_value) <= match_eps:
                chosen = c
                break
        if chosen is None:
            available = ", ".join(f"{c.time:.3f}" for c in video.beep_candidates)
            raise HTTPException(
                status_code=400,
                detail=(
                    f"no candidate within {match_eps * 1000:.0f} ms of "
                    f"{time_value:.3f}s; available: [{available}]"
                ),
            )
        video.beep_time = chosen.time
        video.beep_source = "auto"
        video.beep_peak_amplitude = chosen.peak_amplitude
        video.beep_duration_ms = chosen.duration_ms
        video.beep_confidence = chosen.confidence
        video.beep_auto_detect_failed = False
        video.beep_alignment_confidence = None
        video.beep_alignment_delta_ms = None
        video.processed["beep"] = True
        video.processed["trim"] = False
        # Switching candidate is a fresh claim about which moment is
        # the beep -- prior review approval doesn't carry over (#71).
        video.beep_reviewed = False
        if video.role == "primary":
            video.processed["shot_detect"] = False

    @app.post("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/beep")
    def override_beep_for_video(
        slug: str, stage_number: int, video_id: str, req: BeepOverrideRequest
    ) -> JSONResponse:
        """Manually set or clear ``video``'s beep timestamp.

        ``req.beep_time = None`` clears back to "no beep yet"; otherwise
        the value (in seconds, must be >= 0) is taken as authoritative
        with ``beep_source="manual"``. Same dedupe + auto-trim chain as
        the legacy primary endpoint, just keyed per video.
        """
        project, stage, video = _resolve_stage_video(slug, stage_number, video_id)
        if req.beep_time is not None and req.beep_time < 0.0:
            raise HTTPException(status_code=400, detail="beep_time must be >= 0")
        _apply_beep_override(slug, project, stage, video, req.beep_time)
        project.save(state.shooter_root(slug))
        if req.beep_time is not None:
            _maybe_chain_trim(slug, stage, video)
        return JSONResponse(project.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/stages/{stage_number}/beep")
    def override_beep(slug: str, stage_number: int, req: BeepOverrideRequest) -> JSONResponse:
        """Backward-compat shim: manually set / clear the primary's beep."""
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        primary = stage.primary()
        if primary is None:
            raise HTTPException(
                status_code=400,
                detail=f"stage {stage_number} has no primary video",
            )
        if req.beep_time is not None and req.beep_time < 0.0:
            raise HTTPException(status_code=400, detail="beep_time must be >= 0")
        _apply_beep_override(slug, project, stage, primary, req.beep_time)
        project.save(state.shooter_root(slug))
        if req.beep_time is not None:
            _maybe_chain_trim(slug, stage, primary)
        return JSONResponse(project.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/stages/{stage_number}/time")
    def set_stage_time(slug: str, stage_number: int, req: StageTimeRequest) -> JSONResponse:
        """Manually set or clear the stage duration.

        For projects without scoreboard data (the only source that
        normally populates ``time_seconds``). Setting a positive value
        stamps ``time_seconds_manual=True`` so a later scoreboard sync
        won't clobber it. ``time_seconds = None`` clears back to 0.0
        (and clears the manual flag), which re-blocks trim / shot
        detection.

        Does NOT auto-chain a trim job -- the user clicks Trim
        themselves once they're satisfied with the duration.
        """
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        if req.time_seconds is None:
            stage.time_seconds = 0.0
            stage.time_seconds_manual = False
        else:
            if req.time_seconds <= 0.0:
                raise HTTPException(
                    status_code=400,
                    detail="time_seconds must be > 0 (use null to clear)",
                )
            stage.time_seconds = float(req.time_seconds)
            stage.time_seconds_manual = True
        project.save(state.shooter_root(slug))
        return JSONResponse(project.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/beep/snap")
    def snap_beep_for_video(
        slug: str, stage_number: int, video_id: str, req: BeepSnapRequest
    ) -> JSONResponse:
        """Refine a user-placed beep marker by snapping it to the strongest
        tone in a tight window around the hint.

        The user has listened to the audio and dropped a marker close to
        the beep; this endpoint runs the same bandpass + envelope detector
        on a slice of the WAV and returns the rise-foot leading edge of
        the strongest run inside ``[hint - window_s, hint + window_s]``.
        Stateless: caller decides whether to accept the proposal as a
        manual override (POST .../beep) or dismiss it.

        404 when no run in the window meets the duration / amplitude
        criteria. The SPA surfaces that as "no beep found nearby; widen
        the window or move the marker".
        """
        project, _stage, video = _resolve_stage_video(slug, stage_number, video_id)
        source = project.resolve_video_path(state.shooter_root(slug), video.path)
        _ensure_source_reachable(stage_number, source)
        if req.hint_time < 0.0:
            raise HTTPException(status_code=400, detail="hint_time must be >= 0")
        if req.window_s <= 0.0:
            raise HTTPException(status_code=400, detail="window_s must be > 0")

        audio_path = audio_helpers.ensure_video_audio(
            state.shooter_root(slug),
            stage_number,
            video,
            source,
            project=project,
            ffmpeg_binary=process_runtime().ffmpeg_binary,
        )
        audio, sr = beep_detect.load_audio(audio_path)
        duration_s = audio.size / sr if sr > 0 else 0.0
        if duration_s <= 0:
            raise HTTPException(status_code=500, detail="cached audio is empty")
        if req.hint_time > duration_s:
            raise HTTPException(
                status_code=400,
                detail=f"hint_time {req.hint_time:.3f}s exceeds audio duration {duration_s:.3f}s",
            )

        slice_start_s = max(0.0, req.hint_time - req.window_s)
        slice_end_s = min(duration_s, req.hint_time + req.window_s)
        start_idx = int(round(slice_start_s * sr))
        end_idx = int(round(slice_end_s * sr))
        if end_idx <= start_idx:
            raise HTTPException(
                status_code=400,
                detail="snap window is empty after clipping to audio bounds",
            )
        sliced = audio[start_idx:end_idx]

        # Relax detection thresholds: the user has already localized the
        # beep with their marker, so the snap doesn't need the full-clip
        # detector's belt-and-braces against false positives.
        # - silence_window_s shrinks to fit the slice (the configured
        #   1.5 s pre-window would be silently truncated otherwise).
        # - search_window_s = 0 disables the front-of-audio cap (the
        #   slice itself is the cap).
        # - min_duration_ms drops to 40 ms so a clipped / faint beep
        #   whose envelope only briefly clears the cutoff still
        #   registers. The full-clip detector keeps 150 ms to suppress
        #   short clicks; in a 2 s window centred on the marker, those
        #   competing transients aren't a concern.
        # - min_abs_peak drops to 0.01 so a quiet recording (Insta360
        #   GO 3S beep at low gain) still has a candidate run.
        cfg = BeepDetectConfig(
            silence_window_s=min(0.3, max(0.05, req.window_s * 0.6)),
            silence_pre_skip_s=0.05,
            search_window_s=0.0,
            top_n_candidates=8,
            min_duration_ms=40,
            min_abs_peak=0.01,
            min_amplitude=0.05,
        )
        try:
            detection = beep_detect.detect_beep(sliced, sr, cfg)
        except beep_detect.BeepNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

        # Times in ``detection`` are slice-local; shift back to source
        # time. Pick the candidate closest to the user's hint -- in a
        # tight window the hint is the prior, not silence-preference.
        hint_in_slice = req.hint_time - slice_start_s
        chosen = min(detection.candidates, key=lambda c: abs(c.time - hint_in_slice))
        snapped_time = float(chosen.time + slice_start_s)
        return JSONResponse(
            BeepSnapResponse(
                snapped_time=snapped_time,
                delta=snapped_time - req.hint_time,
                peak_amplitude=float(chosen.peak_amplitude),
                score=float(chosen.score),
                duration_ms=float(chosen.duration_ms),
            ).model_dump()
        )

    @app.post("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/beep/select")
    def select_beep_candidate_for_video(
        slug: str, stage_number: int, video_id: str, req: BeepSelectRequest
    ) -> JSONResponse:
        """Promote one of ``video``'s ranked candidates as authoritative."""
        project, stage, video = _resolve_stage_video(slug, stage_number, video_id)
        _select_candidate_on_video(video, req.time)
        audio_helpers.invalidate_video_audit_trim(
            state.shooter_root(slug), stage_number, video, project=project
        )
        project.save(state.shooter_root(slug))
        _maybe_chain_trim(slug, stage, video)
        return JSONResponse(project.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/beep/review")
    def set_beep_reviewed(
        slug: str, stage_number: int, video_id: str, req: BeepReviewRequest
    ) -> JSONResponse:
        """Flip ``video.beep_reviewed`` (issue #71).

        Setting True requires ``beep_time`` to be set; setting False is
        always allowed (e.g. user wants to re-review). For a primary
        whose trim is already cached, marking True kicks off shot
        detection -- this is the explicit unblock point for the
        downstream pipeline (auto-detect leaves the flag False so the
        ensemble doesn't burn cycles on an unconfirmed beep, and we
        finally fire it here once the user has listened and approved).
        """
        project, stage, video = _resolve_stage_video(slug, stage_number, video_id)
        if req.reviewed and video.beep_time is None:
            raise HTTPException(
                status_code=400,
                detail="cannot mark a beep reviewed before one has been detected",
            )
        video.beep_reviewed = bool(req.reviewed)
        project.save(state.shooter_root(slug))

        # When the user confirms the primary's beep AND the trim is
        # already cached from the auto-detect chain, kick off the
        # gated shot-detect now. No-op when trim hasn't run yet (it
        # will run after, then auto-chain because the gate is open),
        # or for secondaries (no shot timeline of their own).
        if (
            req.reviewed
            and video.role == "primary"
            and video.processed.get("trim")
            and state.jobs.find_active(kind="shot_detect", stage_number=stage_number) is None
        ):
            state.jobs.submit(
                kind="shot_detect",
                stage_number=stage_number,
                fn=lambda h, sl=slug, n=stage_number: _run_shot_detect(h, sl, n),
            )

        return JSONResponse(project.model_dump(mode="json"))

    @app.patch("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/camera-mount")
    def set_camera_mount(
        slug: str, stage_number: int, video_id: str, req: CameraMountRequest
    ) -> JSONResponse:
        """Override the heuristic ``camera_mount`` (issue #143).

        Validated against the fixture-schema ``CameraMount`` enum so
        downstream code can trust the stored value. ``None`` clears the
        override -- the next shot-detect run will use the artifact's
        default class instead of a per-class threshold.
        """
        project, _stage, video = _resolve_stage_video(slug, stage_number, video_id)
        from ..fixture_schema import CameraMount

        if req.mount is not None:
            try:
                CameraMount(req.mount)
            except ValueError as exc:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"unknown camera mount {req.mount!r}; expected one of "
                        + ", ".join(m.value for m in CameraMount)
                    ),
                ) from exc
        video.camera_mount = req.mount
        project.save(state.shooter_root(slug))
        return JSONResponse(project.model_dump(mode="json"))

    @app.patch("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/camera-model")
    def set_camera_model(
        slug: str, stage_number: int, video_id: str, req: CameraModelRequest
    ) -> JSONResponse:
        """Override the ffprobed camera make + model (#303-followup).

        Used when ffprobe couldn't read the QuickTime tag (e.g. Meta
        Vanguard glasses) or guessed wrong. The SPA's Ingest screen
        presents a dropdown sourced from
        ``GET /api/calibrated-camera-models`` plus an "Other (generic
        headcam)" sentinel that clears back to ``None`` / ``None`` --
        the runtime then falls back to the engine-side generic-headcam
        amp floor (#304).

        Both fields must be supplied together or both ``None``: a
        half-filled pair would produce no usable lookup key but isn't
        what the UI ever sends, so we refuse it as a 400.
        """
        if (req.make is None) != (req.model is None):
            raise HTTPException(
                status_code=400,
                detail="camera-model: 'make' and 'model' must be supplied together or both null",
            )
        project, _stage, video = _resolve_stage_video(slug, stage_number, video_id)
        video.camera_make = req.make
        video.camera_model = req.model
        project.save(state.shooter_root(slug))
        return JSONResponse(project.model_dump(mode="json"))

    @app.get("/api/calibrated-camera-models")
    def list_calibrated_camera_models() -> JSONResponse:
        """Enumerate the camera models present in the shipped calibration.

        The SPA shows these as the dropdown options on the Ingest screen.
        Unknown models still get the runtime's generic-headcam fallback
        floor, but offering an explicit pick lets the user steer a
        Vanguard-shaped fixture to its tuned threshold even when
        ffprobe yielded nothing.

        Result order is descending floor (most aggressive cut first)
        so the most-trusted model sorts to the top; ties broken
        alphabetically.
        """
        runtime = _get_ensemble_runtime()
        floors = runtime.calibration.amp_floor_by_camera_model or {}
        displays = runtime.calibration.camera_model_metadata or {}
        rows: list[dict[str, Any]] = []
        for key, floor in floors.items():
            meta = displays.get(key) or {}
            rows.append(
                {
                    "key": key,
                    "make": meta.get("make", key.split(" ", 1)[0].title()),
                    "model": meta.get("model", key.split(" ", 1)[1].title() if " " in key else key.title()),
                    "amp_floor": float(floor),
                }
            )
        rows.sort(key=lambda r: (-r["amp_floor"], r["key"]))
        return JSONResponse({"models": rows})

    @app.post("/api/shooters/{slug}/stages/{stage_number}/beep/select")
    def select_beep_candidate(slug: str, stage_number: int, req: BeepSelectRequest) -> JSONResponse:
        """Backward-compat shim: promote a ranked candidate on the primary.

        Lets the user fix a wrong auto-pick without typing a timestamp.
        Re-uses the auto-detect provenance because the time still came
        from the detector -- we only changed which candidate the project
        trusts. Triggers a re-trim so the cached audit clip lines up.
        """
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        primary = stage.primary()
        if primary is None:
            raise HTTPException(
                status_code=400,
                detail=f"stage {stage_number} has no primary video",
            )
        _select_candidate_on_video(primary, req.time)
        audio_helpers.invalidate_video_audit_trim(
            state.shooter_root(slug), stage_number, primary, project=project
        )
        project.save(state.shooter_root(slug))
        _maybe_chain_trim(slug, stage, primary)
        return JSONResponse(project.model_dump(mode="json"))

    def _resolve_audit_audio(
        slug: str, project: MatchProject, stage_number: int
    ) -> audio_helpers.AuditAudioResult:
        """Shared resolver for /audio + /peaks: prefers the trimmed clip's
        WAV, falls back to full primary on cache miss / no trim."""
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        primary = stage.primary()
        if primary is None:
            raise HTTPException(
                status_code=404,
                detail=f"stage {stage_number} has no primary video",
            )
        try:
            return audio_helpers.ensure_audit_audio(
                state.shooter_root(slug),
                stage_number,
                project.resolve_video_path(state.shooter_root(slug), primary.path),
                primary.beep_time,
                project=project,
                ffmpeg_binary=process_runtime().ffmpeg_binary,
            )
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except audio_helpers.AudioExtractionError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    def _resolve_video_audio(
        slug: str, project: MatchProject, stage_number: int, video: StageVideo
    ) -> audio_helpers.AuditAudioResult:
        """Per-video version of :func:`_resolve_audit_audio`.

        Always returns the full source WAV, regardless of role. The picker
        is where the user *questions* the current beep -- if it shows the
        trimmed audit clip, a beep that fell outside the trim window is
        invisible and can't be moved onto. The audit screen still reaches
        for the trimmed clip via the per-stage `/audio` + `/peaks`
        endpoints, which is the right consumer for that cache.

        ``beep_in_clip`` is just ``video.beep_time``; the WAV is in source
        time so no trim offset applies.
        """
        source = project.resolve_video_path(state.shooter_root(slug), video.path)
        try:
            audio_path = audio_helpers.ensure_video_audio(
                state.shooter_root(slug),
                stage_number,
                video,
                source,
                project=project,
                ffmpeg_binary=process_runtime().ffmpeg_binary,
            )
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except audio_helpers.AudioExtractionError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        return audio_helpers.AuditAudioResult(
            audio_path=audio_path,
            beep_in_clip=video.beep_time,
            trimmed=False,
        )

    def _serve_beep_preview(
        slug: str,
        project: MatchProject,
        stage_number: int,
        video: StageVideo,
        t: float | None,
    ) -> FileResponse:
        """Build the ~1 s MP4 around ``t`` (or ``video.beep_time``) and serve it.

        Shared by the legacy primary endpoint and the per-video endpoint
        so both honour the same 404 / 424 / cache semantics.
        """
        source = project.resolve_video_path(state.shooter_root(slug), video.path)
        _ensure_source_reachable(stage_number, source)
        center = t if t is not None else video.beep_time
        if center is None:
            raise HTTPException(
                status_code=404,
                detail=f"stage {stage_number} video has no beep_time yet",
            )
        if center < 0:
            raise HTTPException(status_code=400, detail="t must be >= 0")
        thumbs_dir = project.thumbs_path(state.shooter_root(slug))
        try:
            clip = thumbnail_helpers.ensure_clip(
                source,
                cache_dir=thumbs_dir,
                center_time=float(center),
                duration_s=1.0,
                width=480,
                ffmpeg_binary=process_runtime().ffmpeg_binary,
            )
        except thumbnail_helpers.ThumbnailError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        return FileResponse(clip, media_type="video/mp4", filename=clip.name)

    @app.get("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/beep-preview")
    def video_beep_preview(
        slug: str, stage_number: int, video_id: str, t: float | None = None
    ) -> FileResponse:
        """Serve a ~1 s MP4 around ``video``'s beep (or override ``t``)."""
        project, _stage, video = _resolve_stage_video(slug, stage_number, video_id)
        return _serve_beep_preview(slug, project, stage_number, video, t)

    @app.get("/api/shooters/{slug}/stages/{stage_number}/beep-preview")
    def stage_beep_preview(slug: str, stage_number: int, t: float | None = None) -> FileResponse:
        """Serve a tiny MP4 around the primary's beep timestamp (#27, #22).

        Default center is the primary's persisted ``beep_time``. The
        optional ``t`` query param overrides it so the BeepCandidates
        picker (#22) can preview alternative ranked candidates without
        promoting them first. Cache keys on (source mtime/size, center
        time, duration), so each distinct ``t`` gets its own cached clip.
        """
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        primary = stage.primary()
        if primary is None:
            raise HTTPException(
                status_code=404,
                detail=f"stage {stage_number} has no primary video",
            )
        return _serve_beep_preview(slug, project, stage_number, primary, t)

    @app.get("/api/shooters/{slug}/stages/{stage_number}/audio")
    def stage_audio(slug: str, stage_number: int) -> FileResponse:
        """Serve the audit-clip WAV for ``stage_number``.

        Prefers the primary's audit WAV (extracted from the short-GOP trimmed
        MP4 produced by Sub 5 / #16) so the waveform timeline matches what
        the user is auditing. Falls back to the primary's full source WAV
        when no trimmed clip exists yet -- the SPA surfaces this with a
        "trim required" hint.
        """
        project = state.shooter_project(slug)
        result = _resolve_audit_audio(slug, project, stage_number)
        return FileResponse(
            result.audio_path,
            media_type="audio/wav",
            filename=result.audio_path.name,
        )

    @app.get("/api/shooters/{slug}/stages/{stage_number}/peaks")
    def stage_peaks(
        slug: str,
        stage_number: int,
        bins: int = Query(default=1200, ge=16, le=8192),
    ) -> JSONResponse:
        """Return ``bins`` peak magnitudes (0..1) for the stage's audit clip.

        The peaks come from whichever WAV ``_resolve_audit_audio`` picked
        (trimmed clip if available, full source otherwise). The response
        carries ``beep_time`` translated into the served clip's local
        timeline + ``trimmed`` so the SPA can render the beep marker
        correctly and warn when the user is auditing an untrimmed source.
        """
        project = state.shooter_project(slug)
        audit = _resolve_audit_audio(slug, project, stage_number)
        peaks = waveform_helpers.ensure_peaks(audit.audio_path, bins)
        payload = peaks.model_dump(mode="json")
        payload["beep_time"] = audit.beep_in_clip
        payload["trimmed"] = audit.trimmed
        return JSONResponse(payload)

    @app.get("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/audio")
    def video_audio(slug: str, stage_number: int, video_id: str) -> FileResponse:
        """Serve ``video``'s WAV for the per-video beep picker.

        Primary forwards to the legacy stage audio resolver so the
        trimmed audit clip is preferred. Secondary returns the full
        per-cam WAV (``stage<N>_cam_<vid>.wav``) -- no per-secondary
        trim clip exists yet, and the picker needs the entire clip so
        the user can find the buzzer / first-shot regardless of where
        the current beep estimate is.
        """
        project, _stage, video = _resolve_stage_video(slug, stage_number, video_id)
        result = _resolve_video_audio(slug, project, stage_number, video)
        return FileResponse(
            result.audio_path,
            media_type="audio/wav",
            filename=result.audio_path.name,
        )

    @app.get("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/peaks")
    def video_peaks(
        slug: str,
        stage_number: int,
        video_id: str,
        bins: int = Query(default=1200, ge=16, le=8192),
    ) -> JSONResponse:
        """Return ``bins`` peak magnitudes for ``video``'s WAV.

        Same shape as ``/api/stages/{n}/peaks`` so the SPA's waveform
        picker can take the same path for primary + secondary -- the
        only thing that varies between roles is the URL.
        """
        project, _stage, video = _resolve_stage_video(slug, stage_number, video_id)
        audit = _resolve_video_audio(slug, project, stage_number, video)
        peaks = waveform_helpers.ensure_peaks(audit.audio_path, bins)
        payload = peaks.model_dump(mode="json")
        payload["beep_time"] = audit.beep_in_clip
        payload["trimmed"] = audit.trimmed
        return JSONResponse(payload)

    @app.get("/api/shooters/{slug}/stages/{stage_number}/audit")
    def get_stage_audit(slug: str, stage_number: int) -> JSONResponse:
        """Return the stage's audit JSON (issue #15) if one has been written.

        Lives at ``<project>/audit/stage<N>.json`` -- the same path the
        existing audit-prep / audit-apply flow uses. Returns ``200 null``
        when no audit file exists yet (the audit screen treats this as
        "fresh -- start from candidates if any, otherwise empty
        markers"); 404 is reserved for genuinely-unknown stages so the
        SPA can distinguish.
        """
        project = state.shooter_project(slug)
        try:
            project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        audit_file = project.audit_path(state.shooter_root(slug)) / f"stage{stage_number}.json"
        if not audit_file.exists():
            return JSONResponse(None)
        try:
            payload = json.loads(audit_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=500, detail=f"audit read failed: {exc}") from exc
        return JSONResponse(payload)

    @app.put("/api/shooters/{slug}/stages/{stage_number}/audit")
    def put_stage_audit(slug: str, stage_number: int, payload: dict[str, Any]) -> JSONResponse:
        """Atomically write the audit JSON for a stage.

        Layout follows the existing audit-prep / audit-apply convention plus
        an ``audit_events`` append-only log (issue #15). The SPA owns the
        document shape -- this endpoint just verifies it's a JSON object,
        writes it under ``<project>/audit/stage<N>.json``, and keeps the
        previous version as ``stage<N>.json.bak`` so a bad save can be
        recovered.

        The atomic-write pattern is: serialize -> ``stage<N>.json.tmp`` ->
        rename existing final to ``.bak`` (replacing any prior backup) ->
        rename ``.tmp`` to final. A crashed process never leaves the SPA
        without a readable JSON.
        """
        project = state.shooter_project(slug)
        try:
            project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        audit_dir = project.audit_path(state.shooter_root(slug))
        audit_dir.mkdir(parents=True, exist_ok=True)
        target = audit_dir / f"stage{stage_number}.json"
        tmp = target.with_suffix(target.suffix + ".tmp")
        backup = target.with_suffix(target.suffix + ".bak")
        try:
            tmp.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
            if target.exists():
                if backup.exists():
                    backup.unlink()
                target.replace(backup)
            tmp.replace(target)
        except OSError as exc:
            if tmp.exists():
                tmp.unlink()
            raise HTTPException(status_code=500, detail=f"audit write failed: {exc}") from exc
        return JSONResponse(payload)

    @app.get("/api/shooters/{slug}/stages/{stage_number}/anomalies")
    def get_stage_anomalies(slug: str, stage_number: int) -> JSONResponse:
        """Return structured anomalies for the saved audit JSON (issue #42).

        Single source of truth for ``report.detect_anomalies_structured``:
        the audit screen also runs the same rules client-side for live
        feedback while the user keeps / rejects markers, but consumers
        that only need a snapshot (external tooling, integration tests,
        the report.txt writer) can hit this endpoint instead of reading
        the JSON and re-deriving.

        Returns ``{anomalies: []}`` when the stage has no audit JSON, no
        beep yet, or an empty ``shots[]`` -- the SPA renders these as
        "no anomalies" / "no shots audited yet" depending on context.
        """
        project = state.shooter_project(slug)
        try:
            stg = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

        audit_file = project.audit_path(state.shooter_root(slug)) / f"stage{stage_number}.json"
        if not audit_file.exists():
            return JSONResponse({"anomalies": []})
        try:
            audit_payload = json.loads(audit_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=500, detail=f"audit read failed: {exc}") from exc

        prim = stg.primary()
        beep_time = prim.beep_time if prim is not None and prim.beep_time is not None else 0.0
        shots = export_helpers.audit_shots_to_engine_shots(audit_payload, beep_time_in_source=beep_time)
        anomalies = report.detect_anomalies_structured(shots, beep_time, stg.time_seconds)
        return JSONResponse({"anomalies": [a.model_dump() for a in anomalies]})

    # ----------------------------------------------------------------------
    # Coach endpoints (#161). Read-only on shot timestamps -- all writes go
    # to the coaching annotation fields owned by ``splitsmith.coach``.
    # Storage is the same audit JSON Audit reads/writes. The coach is lazy:
    # GET surfaces the current rule's verdict + a stale flag without
    # mutating; reclassify persists auto entries; PATCH writes one shot's
    # coach fields.
    # ----------------------------------------------------------------------

    def _video_beep_in_clip(
        slug: str,
        project: MatchProject,
        stage_number: int,
        video: StageVideo,
    ) -> float | None:
        """Where the beep falls inside the clip the SPA will receive
        from ``/api/videos/stream`` for ``video``.

        When a per-video trimmed MP4 exists, the beep sits at
        ``min(beep_time, trim_pre_buffer_seconds)`` inside it (the trim
        starts at ``max(0, beep_time - pre_buffer)``). When there's no
        trim we fall through to the source clip and the beep is at
        ``beep_time`` directly. Pure check: no ffmpeg, no audio
        extraction -- the file existence + project config is enough.
        """
        if video.beep_time is None:
            return None
        trimmed = audio_helpers.trimmed_video_path(
            state.shooter_root(slug), stage_number, video, project=project
        )
        if trimmed.exists() and trimmed.stat().st_size > 0:
            return min(video.beep_time, project.trim_pre_buffer_seconds)
        return video.beep_time

    def _coach_video_entries(slug: str, project: MatchProject, stg: Any) -> list[dict[str, Any]]:
        """Per-video metadata the SPA needs to seek every synced camera.

        Order mirrors VideoPanel's expectation: primary first, then
        secondaries by ``added_at``. ``beep_in_clip`` is the position
        inside the clip the SPA will actually be playing -- the source
        clip when no trim exists, the trimmed clip when one does.
        """
        primary = stg.primary()
        secondaries = sorted(
            (v for v in stg.videos if v.role == "secondary"),
            key=lambda v: v.added_at,
        )
        ordered_videos = ([primary] if primary is not None else []) + secondaries
        out: list[dict[str, Any]] = []
        for v in ordered_videos:
            out.append(
                {
                    "path": str(v.path),
                    "role": v.role,
                    "beep_in_clip": _video_beep_in_clip(slug, project, stg.stage_number, v),
                }
            )
        return out

    def _load_audit_for_coach(
        slug: str,
        stage_number: int,
    ) -> tuple[dict[str, Any], Path, float | None, Any, MatchProject]:
        """Shared loader: validates the stage, reads the audit JSON,
        returns (payload, path, primary_beep_in_clip, stage, project).
        """
        project = state.shooter_project(slug)
        try:
            stg = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        audit_file = project.audit_path(state.shooter_root(slug)) / f"stage{stage_number}.json"
        if not audit_file.exists():
            raise HTTPException(
                status_code=404,
                detail=f"no audit JSON yet for stage {stage_number}",
            )
        try:
            payload = json.loads(audit_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=500, detail=f"audit read failed: {exc}") from exc
        prim = stg.primary()
        primary_beep_in_clip = (
            _video_beep_in_clip(slug, project, stage_number, prim) if prim is not None else None
        )
        return payload, audit_file, primary_beep_in_clip, stg, project

    def _coach_atomic_write(audit_file: Path, payload: dict[str, Any]) -> None:
        tmp = audit_file.with_suffix(audit_file.suffix + ".tmp")
        backup = audit_file.with_suffix(audit_file.suffix + ".bak")
        try:
            tmp.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
            if audit_file.exists():
                if backup.exists():
                    backup.unlink()
                audit_file.replace(backup)
            tmp.replace(audit_file)
        except OSError as exc:
            if tmp.exists():
                tmp.unlink()
            raise HTTPException(status_code=500, detail=f"coach write failed: {exc}") from exc

    def _build_coach_response(
        slug: str,
        payload: dict[str, Any],
        primary_beep_in_clip: float | None,
        stg: Any,
        project: MatchProject,
        cfg: CoachAutoClassifyConfig,
    ) -> dict[str, Any]:
        # Coach plays the same clip the audit screen serves -- typically
        # the project-local trimmed MP4 -- so every "absolute" time must
        # be in the served clip's coordinate system. Anchoring on
        # ``primary_beep_in_clip`` keeps Coach working when the source
        # SSD is unplugged. Falls back to 0.0 when the project hasn't
        # set a beep yet (older / partial audits).
        clip_anchor = primary_beep_in_clip if primary_beep_in_clip is not None else 0.0
        raw_shots = payload.get("shots") or []
        ordered = sorted(
            (s for s in raw_shots if isinstance(s, dict) and "ms_after_beep" in s),
            key=lambda s: float(s.get("ms_after_beep", 0)),
        )
        coach_shots: list[dict[str, Any]] = []
        prev_ms: float | None = None
        for s in ordered:
            ms = float(s["ms_after_beep"])
            time_from_beep = ms / 1000.0
            gap_s: float | None
            if prev_ms is None:
                gap_s = None
                split = time_from_beep  # draw
            else:
                gap_s = (ms - prev_ms) / 1000.0
                split = gap_s
            prev_ms = ms
            stale = coach_module.is_classification_stale(s, gap_s=gap_s, config=cfg)
            reload_hint = coach_module.reload_hinted(gap_s, cfg)
            coach_shots.append(
                {
                    "shot_number": int(s.get("shot_number", 0)),
                    "ms_after_beep": int(ms),
                    "time_from_beep": time_from_beep,
                    # In the served clip's coordinate system: where the
                    # SPA must seek the primary <video> for this shot.
                    "time_absolute": clip_anchor + time_from_beep,
                    "split": split,
                    "interval_class": s.get("interval_class"),
                    "interval_class_source": s.get("interval_class_source"),
                    "improvement_flag": bool(s.get("improvement_flag", False)),
                    "coaching_note": s.get("coaching_note"),
                    "stale": stale,
                    "reload_hint": reload_hint,
                }
            )
        return {
            "stage_number": stg.stage_number,
            "stage_name": stg.stage_name,
            # Where the beep falls in the served primary clip. Used by
            # the SPA's beep row + as the anchor for offsetting synced
            # secondaries (each ``videos[i].beep_in_clip`` mirrors this
            # field for that camera's served clip).
            "beep_time": clip_anchor,
            "videos": _coach_video_entries(slug, project, stg),
            "shots": coach_shots,
        }

    @app.get("/api/shooters/{slug}/stages/{stage_number}/coach")
    def get_stage_coach(slug: str, stage_number: int) -> JSONResponse:
        """Return the per-shot coach view for a stage.

        Read-only: the stored ``interval_class`` is surfaced as-is, plus a
        ``stale`` flag indicating whether the current rule disagrees. The
        client can call ``POST /coach/reclassify`` to persist the rule's
        verdict onto unset/auto entries. Returns ``200 null`` when the
        stage has no audit JSON yet (a normal pre-audit state); 404 is
        reserved for genuinely-unknown stage numbers.
        """
        project = state.shooter_project(slug)
        try:
            stg = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        audit_file = project.audit_path(state.shooter_root(slug)) / f"stage{stage_number}.json"
        if not audit_file.exists():
            return JSONResponse(None)
        payload, _audit_file, beep_in_clip, stg, project = _load_audit_for_coach(slug, stage_number)
        cfg = CoachAutoClassifyConfig()
        return JSONResponse(_build_coach_response(slug, payload, beep_in_clip, stg, project, cfg))

    @app.post("/api/shooters/{slug}/stages/{stage_number}/coach/reclassify")
    def reclassify_stage_coach(slug: str, stage_number: int) -> JSONResponse:
        """Force the auto-classifier to (re)write ``interval_class`` for
        every shot whose source is unset or ``"auto"``. Manual entries are
        preserved. Idempotent.
        """
        payload, audit_file, beep_in_clip, stg, project = _load_audit_for_coach(slug, stage_number)
        cfg = CoachAutoClassifyConfig()
        shots = payload.get("shots") or []
        if not isinstance(shots, list):
            raise HTTPException(status_code=500, detail="audit shots is not a list")
        coach_module.classify_intervals_in_dicts(shots, cfg)
        events = list(payload.get("audit_events") or [])
        events.append(
            {
                "ts": _now_iso(),
                "kind": "coach_reclassify",
                "payload": {"shot_count": len(shots)},
            }
        )
        payload["audit_events"] = events
        _coach_atomic_write(audit_file, payload)
        return JSONResponse(_build_coach_response(slug, payload, beep_in_clip, stg, project, cfg))

    @app.patch("/api/shooters/{slug}/stages/{stage_number}/shots/{shot_number}/coach")
    def patch_stage_shot_coach(
        slug: str,
        stage_number: int,
        shot_number: int,
        body: CoachShotPatchRequest,
    ) -> JSONResponse:
        """Patch the coaching annotation fields on one shot. Returns the
        updated coach response for the stage so the client can refresh.
        """
        payload, audit_file, beep_in_clip, stg, project = _load_audit_for_coach(slug, stage_number)
        cfg = CoachAutoClassifyConfig()
        shots = payload.get("shots") or []
        if not isinstance(shots, list):
            raise HTTPException(status_code=500, detail="audit shots is not a list")
        target = next(
            (s for s in shots if isinstance(s, dict) and int(s.get("shot_number", -1)) == shot_number),
            None,
        )
        if target is None:
            raise HTTPException(
                status_code=404,
                detail=f"shot {shot_number} not found in stage {stage_number}",
            )
        try:
            coach_module.write_coach_fields(
                target,
                interval_class=body.interval_class,
                interval_class_source=body.interval_class_source,
                clear_class=body.clear_class,
                improvement_flag=body.improvement_flag,
                coaching_note=body.coaching_note,
                clear_note=body.clear_note,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        events = list(payload.get("audit_events") or [])
        events.append(
            {
                "ts": _now_iso(),
                "kind": "coach_patch",
                "payload": {
                    "shot_number": shot_number,
                    "fields": coach_module.read_coach_fields(target),
                },
            }
        )
        payload["audit_events"] = events
        _coach_atomic_write(audit_file, payload)
        return JSONResponse(_build_coach_response(slug, payload, beep_in_clip, stg, project, cfg))

    @app.get("/api/shooters/{slug}/stages/{stage_number}/coach/distributions")
    def get_stage_coach_distributions(slug: str, stage_number: int) -> JSONResponse:
        """Histograms + summary stats for one stage's coach annotations.

        Unset interval classes are computed in memory; nothing persists.
        Empty classes still appear in the response with count=0 so the
        UI can render an empty histogram without a special case.
        """
        payload, _audit_file, _beep_in_clip, stg, _project = _load_audit_for_coach(slug, stage_number)
        cfg = CoachAutoClassifyConfig()
        shots = payload.get("shots") or []
        if not isinstance(shots, list):
            raise HTTPException(status_code=500, detail="audit shots is not a list")
        result = coach_distributions_module.stage_distributions(
            stage_number=stg.stage_number,
            stage_name=stg.stage_name,
            shots=shots,
            config=cfg,
        )
        return JSONResponse(result.model_dump())

    @app.get("/api/shooters/{slug}/coach/distributions")
    def get_match_coach_distributions(slug: str) -> JSONResponse:
        """Match-level distributions across every stage with an audit
        JSON. Stages without an audit are silently skipped -- they
        haven't been audited yet so they'd just dilute the average.
        """
        project = state.shooter_project(slug)
        cfg = CoachAutoClassifyConfig()
        audit_dir = project.audit_path(state.shooter_root(slug))
        triples: list[tuple[int, str, list[dict[str, Any]]]] = []
        for stg in project.stages:
            audit_file = audit_dir / f"stage{stg.stage_number}.json"
            if not audit_file.exists():
                continue
            try:
                stage_payload = json.loads(audit_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise HTTPException(
                    status_code=500,
                    detail=f"audit read failed for stage {stg.stage_number}: {exc}",
                ) from exc
            shots = stage_payload.get("shots") or []
            if not isinstance(shots, list):
                continue
            triples.append((stg.stage_number, stg.stage_name, shots))
        result = coach_distributions_module.match_distributions(stages=triples, config=cfg)
        return JSONResponse(result.model_dump())

    # ----------------------------------------------------------------------
    # Fixture-review endpoints (closes #19 -- the old splitsmith.review_server
    # standalone). The /review SPA route reads a single audit fixture (JSON
    # + sibling WAV + optional video) and edits it in place. No project
    # context, no stages, no jobs. Localhost-only convention applies; paths
    # are passed by the user via CLI / query string.
    # ----------------------------------------------------------------------

    def _resolve_fixture_path(path: str) -> Path:
        """Validate + resolve a fixture path the SPA passed in. Localhost
        only -- we trust the user's machine but still refuse non-existent
        files cleanly so the SPA can show a 404 message."""
        target = Path(path).expanduser()
        try:
            resolved = target.resolve(strict=True)
        except (FileNotFoundError, OSError) as exc:
            raise HTTPException(status_code=404, detail=f"fixture not found: {target}") from exc
        if not resolved.is_file():
            raise HTTPException(status_code=400, detail=f"fixture is not a file: {resolved}")
        return resolved

    @app.get("/api/fixture/audit")
    def get_fixture_audit(path: str = Query(...)) -> JSONResponse:
        """Read the fixture JSON at ``path``."""
        target = _resolve_fixture_path(path)
        try:
            payload = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=500, detail=f"fixture read failed: {exc}") from exc
        return JSONResponse(payload)

    @app.put("/api/fixture/audit")
    def put_fixture_audit(
        path: str = Query(...),
        payload: dict[str, Any] = Body(...),  # noqa: B008  FastAPI default-arg DI
    ) -> JSONResponse:
        """Atomically rewrite a fixture JSON. Same .bak backup pattern as
        ``/api/stages/{n}/audit``: serialize -> .tmp -> rename existing
        target to .bak (replacing any prior backup) -> rename .tmp to
        target. A crashed write never leaves the SPA without a JSON."""
        target = _resolve_fixture_path(path)
        tmp = target.with_suffix(target.suffix + ".tmp")
        backup = target.with_suffix(target.suffix + ".bak")
        try:
            tmp.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
            if backup.exists():
                backup.unlink()
            target.replace(backup)
            tmp.replace(target)
        except OSError as exc:
            if tmp.exists():
                tmp.unlink()
            raise HTTPException(status_code=500, detail=f"fixture write failed: {exc}") from exc
        return JSONResponse(payload)

    @app.get("/api/fixture/peaks")
    def get_fixture_peaks(
        path: str = Query(...),
        bins: int = Query(default=1200, ge=16, le=8192),
    ) -> JSONResponse:
        """Compute peaks for the fixture's sibling WAV (``<path>.with_suffix('.wav')``).

        Returns the same payload as the project peaks endpoint so the
        Review page can reuse the same client-side rendering, including
        the ``beep_time`` and ``trimmed`` fields. The fixture is treated
        as already-trimmed (clip-local timeline) by convention.
        """
        target = _resolve_fixture_path(path)
        wav = target.with_suffix(".wav")
        if not wav.exists():
            raise HTTPException(
                status_code=404,
                detail=f"fixture audio not found: {wav}",
            )
        result = waveform_helpers.ensure_peaks(wav, bins)
        # The fixture JSON owns the canonical beep_time; we expose it via
        # the audit endpoint instead of re-deriving here. peaks payload
        # gets ``trimmed=true`` since fixtures are clip-local.
        payload = result.model_dump(mode="json")
        try:
            fixture_json = json.loads(target.read_text(encoding="utf-8"))
            payload["beep_time"] = fixture_json.get("beep_time")
        except (OSError, json.JSONDecodeError):
            payload["beep_time"] = None
        payload["trimmed"] = True
        return JSONResponse(payload)

    @app.get("/api/fixture/audio")
    def get_fixture_audio(path: str = Query(...)) -> FileResponse:
        """Serve the WAV alongside ``path`` (same stem, .wav extension)."""
        target = _resolve_fixture_path(path)
        wav = target.with_suffix(".wav")
        if not wav.exists():
            raise HTTPException(
                status_code=404,
                detail=f"fixture audio not found: {wav}",
            )
        return FileResponse(wav, media_type="audio/wav", filename=wav.name)

    @app.get("/api/fixture/video")
    def get_fixture_video(path: str = Query(...)) -> FileResponse:
        """Serve an arbitrary video file the user binds to a fixture.

        The CLI's ``splitsmith review --video <path>`` passes this through
        to the SPA via a query param. Localhost-only; we don't restrict
        the path beyond "must exist + must be a file".
        """
        target = _resolve_fixture_path(path)
        media_type = "video/mp4" if target.suffix.lower() == ".mp4" else "application/octet-stream"
        return FileResponse(target, media_type=media_type, filename=target.name)

    @app.get("/api/shooters/{slug}/videos/stream")
    def stream_video(
        slug: str,
        path: str = Query(...),
        kind: Literal["auto", "trim", "source"] = Query("auto"),
    ) -> FileResponse:
        """Serve a registered video file with HTTP Range support.

        ``kind`` selects which file backs the response:

        - ``trim``: per-video short-GOP MP4 produced by Sub 5 / #16
          (``<trimmed>/stage<N>_cam_<video_id>_trimmed.mp4``); 404 if not
          built yet. The re-encoded clip seeks frame-accurately, which
          is what makes the audit screen's drag-scrubbing feel
          responsive.
        - ``source``: the original camera file. Used while the trim is
          still building.
        - ``auto`` (default, for back-compat with non-audit callers):
          trim if present, source otherwise.

        The audit screen always passes an explicit ``kind`` so the file
        bound to a ``<video>`` element can't change mid-session when a
        background trim job completes -- a switch from source bytes to
        trim bytes mid-Range-request wedges the player ("source not
        found") and forced a full reload to recover.

        Validates that ``path`` matches a video registered to the project
        (any stage, any role, or unassigned) so the endpoint cannot be
        used as a generic file-read primitive.
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        located = project.find_video(Path(path))
        if located is None:
            raise HTTPException(
                status_code=404,
                detail=f"video not registered with project: {path}",
            )
        stage, video = located

        served_path: Path | None = None
        if kind in ("auto", "trim") and stage is not None:
            # Per-video short-GOP trim is keyed per role: each angle has
            # its own scrub clip cut around its own beep, so dragging
            # the audit playhead doesn't stall on a 4K MOV from a phone.
            trimmed = audio_helpers.trimmed_video_path(root, stage.stage_number, video, project=project)
            if trimmed.exists():
                served_path = trimmed.resolve()
        if served_path is None:
            if kind == "trim":
                raise HTTPException(
                    status_code=404,
                    detail=f"trimmed clip not built yet for {path}",
                )
            served_path = project.resolve_video_path(root, video.path).resolve()
            # Same structured shape as detect-beep / trim / preview so
            # the SPA's "reconnect external storage" surface is uniform.
            _ensure_source_reachable(stage.stage_number if stage is not None else None, served_path)

        media_type = "video/mp4" if served_path.suffix.lower() == ".mp4" else "application/octet-stream"
        return FileResponse(served_path, media_type=media_type, filename=served_path.name)

    @app.get("/api/shooters/{slug}/fs/list", response_model=FsListing)
    def fs_list(
        slug: str,
        path: str | None = Query(default=None),
        probe: bool = Query(default=False),
    ) -> FsListing:
        """List a directory's children for the in-app folder picker.

        - ``path=None`` returns the user's home directory plus suggested-start
          bookmarks (last scanned, ~/Movies, ~/Videos, ~).
        - Hidden entries (dot-prefixed) are skipped.
        - Symlinks are resolved before listing; broken symlinks are silently
          dropped from the entries list.
        - Per-directory ``video_count`` is computed by a single shallow scan.
        - When ``probe=true``, video entries get ``duration`` + thumbnail
          generation via ffprobe / ffmpeg, bounded by a wall-clock budget
          (~5 s) so a USB-mounted directory with hundreds of clips doesn't
          stall the picker. Entries past the budget come back with null
          fields and a per-row Generate affordance in the SPA. Cached
          probes / thumbnails always populate -- the budget only gates the
          first-time work.
        """
        project = state.shooter_project(slug)
        target = Path(path).expanduser() if path else _default_start(project.last_scanned_dir)
        try:
            target = target.resolve(strict=True)
        except (FileNotFoundError, OSError) as exc:
            raise HTTPException(status_code=404, detail=f"path not found: {target}") from exc
        if not target.is_dir():
            raise HTTPException(status_code=400, detail=f"not a directory: {target}")

        entries: list[FsEntry] = []
        try:
            children = sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc

        probes_dir = project.probes_path(state.shooter_root(slug))
        thumbs_dir = project.thumbs_path(state.shooter_root(slug))
        budget_deadline = time.monotonic() + 5.0  # wall-clock budget for new probes

        for child in children:
            if child.name.startswith("."):
                continue
            try:
                if child.is_dir():
                    video_count = _count_videos_shallow(child)
                    entries.append(FsEntry(name=child.name, kind="dir", video_count=video_count))
                elif child.is_file():
                    is_video = child.suffix.lower() in VIDEO_EXTENSIONS
                    stat = child.stat()
                    duration: float | None = None
                    thumbnail_url: str | None = None
                    if is_video:
                        duration, thumbnail_url = _video_metadata_for(
                            child,
                            slug=slug,
                            probes_dir=probes_dir,
                            thumbs_dir=thumbs_dir,
                            allow_new=probe and time.monotonic() < budget_deadline,
                            duration_for_thumb=None,
                        )
                    entries.append(
                        FsEntry(
                            name=child.name,
                            kind="video" if is_video else "file",
                            size_bytes=stat.st_size,
                            mtime=stat.st_mtime,
                            duration=duration,
                            thumbnail_url=thumbnail_url,
                        )
                    )
            except (PermissionError, OSError):
                # Broken symlink, permission issue on a child -- skip rather
                # than fail the whole listing.
                continue

        parent = str(target.parent) if target.parent != target else None
        suggested = _suggested_starts(project.last_scanned_dir)

        return FsListing(
            path=str(target),
            parent=parent,
            entries=entries,
            suggested_starts=suggested,
        )

    @app.get("/api/fs/list-dirs", response_model=FsListing)
    def fs_list_dirs(path: str | None = Query(default=None)) -> FsListing:
        """List a directory's child directories without a bound project.

        Used by the create-match folder picker, which needs to browse
        the filesystem *before* any project exists (so the shooter-
        scoped ``/api/shooters/{slug}/fs/list`` isn't reachable). The
        response shape mirrors :class:`FsListing` so the SPA can share
        rendering code, but ``entries`` is directories only -- no video
        probing, no thumbnails -- because this picker selects a *parent*
        folder for a new project, not media to ingest.

        Hidden entries (dot-prefixed) and broken symlinks are skipped.
        Permission errors surface as 403.
        """
        target = Path(path).expanduser() if path else _default_start(None)
        try:
            target = target.resolve(strict=True)
        except (FileNotFoundError, OSError) as exc:
            raise HTTPException(status_code=404, detail=f"path not found: {target}") from exc
        if not target.is_dir():
            raise HTTPException(status_code=400, detail=f"not a directory: {target}")

        try:
            children = sorted(target.iterdir(), key=lambda p: p.name.lower())
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc

        entries: list[FsEntry] = []
        for child in children:
            if child.name.startswith("."):
                continue
            try:
                if not child.is_dir():
                    continue
            except (PermissionError, OSError):
                continue
            entries.append(FsEntry(name=child.name, kind="dir"))

        parent = str(target.parent) if target.parent != target else None
        suggested = _suggested_starts(None)
        return FsListing(
            path=str(target),
            parent=parent,
            entries=entries,
            suggested_starts=suggested,
        )

    @app.get("/api/shooters/{slug}/fs/probe")
    def fs_probe(slug: str, path: str = Query(...)) -> JSONResponse:
        """Probe a single video file on demand: ffprobe + thumbnail extraction.

        Used by the SPA when a picker row came back with null fields (the
        list-time budget was exhausted, or ``probe=true`` wasn't passed).
        Cached results are returned without re-running the binaries. Also
        surfaces resolution/codec/size so the unassigned-tray rows can show
        enough metadata for the user to identify which clip is which.
        """
        project = state.shooter_project(slug)
        # StageVideo.path is project-relative for default projects, so resolve
        # via the project root rather than process CWD before strict-resolving.
        raw_target = Path(path).expanduser()
        target = project.resolve_video_path(state.shooter_root(slug), raw_target)
        try:
            target = target.resolve(strict=True)
        except (FileNotFoundError, OSError) as exc:
            raise HTTPException(status_code=404, detail=f"path not found: {target}") from exc
        if not target.is_file():
            raise HTTPException(status_code=400, detail=f"not a file: {target}")
        if target.suffix.lower() not in VIDEO_EXTENSIONS:
            raise HTTPException(status_code=400, detail=f"not a video: {target}")

        probes_dir = project.probes_path(state.shooter_root(slug))
        thumbs_dir = project.thumbs_path(state.shooter_root(slug))
        duration, thumbnail_url = _video_metadata_for(
            target,
            slug=slug,
            probes_dir=probes_dir,
            thumbs_dir=thumbs_dir,
            allow_new=True,
            duration_for_thumb=None,
        )
        cached_probe = video_probe.cached(target, probes_dir)
        size_bytes: int | None = None
        try:
            size_bytes = target.stat().st_size
        except OSError:
            size_bytes = None
        return JSONResponse(
            {
                "duration": duration,
                "thumbnail_url": thumbnail_url,
                "width": cached_probe.width if cached_probe is not None else None,
                "height": cached_probe.height if cached_probe is not None else None,
                "codec": cached_probe.codec if cached_probe is not None else None,
                "size_bytes": size_bytes,
            }
        )

    @app.get("/api/shooters/{slug}/thumbnails/{cache_key}.jpg", include_in_schema=False)
    def serve_thumbnail(slug: str, cache_key: str) -> FileResponse:
        """Serve a cached thumbnail by its content-addressed key.

        Keys are 16-char hex from :func:`video_probe.source_cache_key`. We
        validate the key shape so we never accept an arbitrary path that
        could escape the thumbs directory.
        """
        if not cache_key.isalnum() or len(cache_key) > 32:
            raise HTTPException(status_code=400, detail="invalid thumbnail key")
        project = state.shooter_project(slug)
        thumbs_dir = project.thumbs_path(state.shooter_root(slug))
        candidate = thumbs_dir / f"{cache_key}.jpg"
        if not candidate.exists():
            raise HTTPException(status_code=404, detail="thumbnail not cached")
        return FileResponse(candidate, media_type="image/jpeg", filename=candidate.name)

    @app.post("/api/shooters/{slug}/videos/auto-match")
    def auto_match(slug: str) -> JSONResponse:
        project = state.shooter_project(slug)
        suggestions = project.auto_match(state.shooter_root(slug))
        return JSONResponse({str(stage_num): str(path) for stage_num, path in suggestions.items()})

    @app.post("/api/shooters/{slug}/videos/remove")
    def remove_video(slug: str, req: RemoveVideoRequest) -> JSONResponse:
        """Remove a registered video and clean up its caches.

        Walks the :class:`RemovalPlan` returned by the model: unlinks the
        symlink under ``raw_dir`` (the source on USB / external storage is
        never touched), and clears the audio + trimmed caches if the removed
        video was a primary that had been processed. When ``reset_audit`` is
        set and the video was a primary, the per-stage audit JSON is
        deleted too -- otherwise audit data is preserved so a re-ingest of
        the same stage with a different file picks up where the user left
        off.
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        try:
            plan = project.remove_video(
                Path(req.video_path),
                root,
                reset_audit=req.reset_audit,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

        # Symlink under raw_dir: remove only if it's actually a symlink we
        # created. If the user pointed raw_dir at the source and the link is
        # in fact the original file, leave it alone.
        try:
            if plan.raw_link_path.is_symlink():
                plan.raw_link_path.unlink()
            elif plan.raw_link_path.exists():
                # Treat as a copy splitsmith placed (link_mode="copy"). We
                # only delete files inside raw_dir; never anything beyond.
                raw_dir = project.raw_path(root).resolve()
                try:
                    plan.raw_link_path.resolve().relative_to(raw_dir)
                    plan.raw_link_path.unlink()
                except ValueError:
                    logger.debug(
                        "skipping raw cleanup; %s is outside raw_dir %s",
                        plan.raw_link_path,
                        raw_dir,
                    )
        except OSError as exc:
            logger.warning("could not unlink %s: %s", plan.raw_link_path, exc)

        for cache_path in (plan.audio_cache_path, plan.trimmed_cache_path):
            if cache_path is None:
                continue
            try:
                cache_path.unlink(missing_ok=True)
            except OSError as exc:
                logger.warning("could not remove cache %s: %s", cache_path, exc)

        if plan.audit_path is not None:
            try:
                plan.audit_path.unlink(missing_ok=True)
            except OSError as exc:
                logger.warning("could not remove audit %s: %s", plan.audit_path, exc)

        project.save(root)
        return JSONResponse(
            {
                "project": project.model_dump(mode="json"),
                "plan": plan.model_dump(mode="json"),
            }
        )

    @app.get("/api/shooters/{slug}/project/cleanup/plan")
    def cleanup_plan(
        slug: str,
        categories: str = Query("", description="Comma-separated category list."),
    ) -> JSONResponse:
        """Preview a cleanup plan without deleting anything.

        Empty / unknown categories yield an empty plan rather than 400 so
        the SPA can debounce-fetch as the user toggles checkboxes
        without worrying about partial selections.
        """
        project = state.shooter_project(slug)
        cats: set[cleanup_module.CleanupCategory] = set()
        for token in categories.split(","):
            token = token.strip()
            if not token:
                continue
            try:
                cats.add(cleanup_module.CleanupCategory(token))
            except ValueError:
                # Skip unknown categories silently; the SPA only sends
                # known ones, and a stale tab shouldn't crash here.
                continue
        plan = cleanup_module.plan_cleanup(project, state.shooter_root(slug), cats)
        return JSONResponse(plan.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/project/cleanup")
    def cleanup_apply(slug: str, req: CleanupRequest) -> JSONResponse:
        """Apply a cleanup. Refuses while jobs are pending or running.

        Re-plans server-side: the client only sends categories, never
        paths. Any active job is treated as a hard block (409) -- mid-
        flight ffmpeg writes into ``trimmed/`` or audit JSON saves into
        ``audit/`` would race with the deletes and corrupt state.
        """
        active = _any_active_job(state)
        if active is not None:
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "jobs_active",
                    "message": (
                        f"Job '{active.kind}' is still {active.status}; "
                        "cancel or wait for it to finish before cleaning up."
                    ),
                    "job_id": active.id,
                    "kind": active.kind,
                },
            )
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        cats = set(req.categories)
        plan = cleanup_module.plan_cleanup(project, root, cats)
        result = cleanup_module.apply_cleanup(plan, root=root)
        return JSONResponse(
            {
                "plan": plan.model_dump(mode="json"),
                "result": result.model_dump(mode="json"),
            }
        )

    @app.post("/api/shooters/{slug}/assignments/move")
    def move_assignment(slug: str, req: MoveRequest) -> JSONResponse:
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        try:
            project.assign_video(
                Path(req.video_path),
                to_stage_number=req.to_stage_number,
                role=req.role,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        project.save(root)

        # Auto-queue beep on assignment to a real stage (#67). Skip when
        # unassigning (to_stage_number=None) or marking ignored -- those
        # don't put the video into the pipeline.
        if req.to_stage_number is not None and req.role != "ignored":
            stage = project.stage(req.to_stage_number)
            video = next((v for v in stage.videos if str(v.path) == req.video_path), None)
            if video is not None:
                _auto_queue_beep_if_needed(slug, project, req.to_stage_number, video)

        return JSONResponse(project.model_dump(mode="json"))

    @app.post("/api/shooters/{slug}/assignments/swap-primary")
    def swap_primary(slug: str, req: SwapPrimaryRequest) -> JSONResponse:
        """Promote ``video_path`` to primary on ``stage_number``.

        Audit-safe: when the stage has shots in its audit JSON, refuses with
        a 409 response unless ``confirm=True`` is passed. On confirm, the
        audit JSON is renamed to ``.bak`` so a bad swap is recoverable, and
        the new primary's processed flags are cleared so detection re-runs.
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        try:
            stage = project.stage(req.stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

        warns = project.primary_swap_warns(root, stage_number=req.stage_number)
        if warns and not req.confirm:
            existing = stage.primary()
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "audit_exists",
                    "message": (
                        f"Stage {req.stage_number} has audit work on its current "
                        "primary. Confirm the swap to back the audit up to .bak "
                        "and re-run detection on the new primary."
                    ),
                    "stage_number": req.stage_number,
                    "current_primary": str(existing.path) if existing else None,
                    "new_primary": req.video_path,
                },
            )
        try:
            project.swap_primary(
                Path(req.video_path),
                root=root,
                stage_number=req.stage_number,
                backup_audit=warns,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        project.save(root)

        # Auto-queue beep for the new primary (#67). swap_primary may
        # clear ``processed.beep`` to force re-detection on the new
        # video's audio; the helper picks up the cleared flag and queues
        # accordingly. No-op when the video already had a current beep.
        new_primary = project.stage(req.stage_number).primary()
        if new_primary is not None:
            _auto_queue_beep_if_needed(slug, project, req.stage_number, new_primary)

        return JSONResponse(project.model_dump(mode="json"))

    @app.get("/api/shooters/{slug}/exports/overview")
    def export_overview(slug: str) -> JSONResponse:
        """Match-overview payload for the Analysis & Export screen.

        Returns one row per stage with audit + export status (shot count,
        pending candidates, file paths, last export time, ready-to-export
        flag). Pure stat: no detection, no rewriting of audit JSON.
        """
        project = state.shooter_project(slug)
        rows = project.export_overview(state.shooter_root(slug))
        return JSONResponse({"stages": [r.model_dump(mode="json") for r in rows]})

    @app.post("/api/shooters/{slug}/stages/{stage_number}/export")
    def export_stage(slug: str, stage_number: int, req: ExportStageRequest) -> JSONResponse:
        """Submit a per-stage export job.

        Wraps the ``export_helpers.export_stage`` orchestrator (lossless trim
        + CSV + FCPXML + report) in a JobRegistry entry so the SPA's
        JobsPanel surfaces progress alongside detect-beep / trim /
        shot-detect. Returns a Job snapshot; the SPA polls
        ``/api/jobs/{id}`` until status leaves running, then re-fetches
        ``/api/exports/overview`` to refresh paths and ``last_export_at``.

        Pre-flight validations (stage exists, primary present, beep ready,
        source reachable, scoreboard not placeholder) still raise HTTP
        errors up front so the SPA can show a clear error before queueing
        a useless job.
        """
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        primary = stage.primary()
        if primary is None or primary.beep_time is None:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"stage {stage_number} has no primary or no beep yet; "
                    "finish ingest + audit before exporting"
                ),
            )
        if stage.time_seconds <= 0 or stage.scorecard_updated_at is None:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"stage {stage_number} is a placeholder; import a real " "scoreboard before exporting"
                ),
            )
        # Source-reachability surfaces as a structured 424 so the SPA
        # renders the same "reconnect external storage" message used
        # elsewhere -- even if the user only wants CSV/report (those would
        # still work, but the explicit 424 lets them re-try after
        # reconnecting rather than hunting for the partial degradation
        # message in the per-row anomaly list).
        if req.write_trim or req.write_fcpxml:
            _ensure_source_reachable(
                stage_number, project.resolve_video_path(state.shooter_root(slug), primary.path)
            )

        existing = state.jobs.find_active(kind="export", stage_number=stage_number)
        if existing is not None:
            return JSONResponse(existing.model_dump(mode="json"))
        job = state.jobs.submit(
            kind="export",
            stage_number=stage_number,
            fn=lambda h, sl=slug, n=stage_number, r=req: _run_export_for_stage(h, sl, n, r),
        )
        return JSONResponse(job.model_dump(mode="json"))

    def _run_export_for_stage(
        handle: JobHandle, slug: str, stage_number: int, req: ExportStageRequest
    ) -> None:
        """Worker for /api/stages/{n}/export. Phases mirror the user's
        mental model so the JobsPanel message is meaningful."""
        from ..config import StageData as EngineStageData

        handle.update(progress=0.05, message="Loading project...")
        proj = state.shooter_project(slug)
        stg = proj.stage(stage_number)
        prim = stg.primary()
        if prim is None or prim.beep_time is None:
            raise RuntimeError("primary or beep disappeared mid-flight")

        audit_file = proj.audit_path(state.shooter_root(slug)) / f"stage{stage_number}.json"
        exports_dir = proj.exports_path(state.shooter_root(slug))
        source_video = proj.resolve_video_path(state.shooter_root(slug), prim.path)
        engine_stage = EngineStageData(
            stage_number=stg.stage_number,
            stage_name=stg.stage_name,
            time_seconds=stg.time_seconds,
            scorecard_updated_at=stg.scorecard_updated_at,
        )

        # Phase progress is approximate; trim dominates wall time when the
        # source is large, so we hold at 0.4 through the trim phase and
        # then jump on the small writers.
        if req.write_trim:
            handle.update(progress=0.15, message="Trimming source (lossless stream copy)...")
        elif req.write_fcpxml:
            handle.update(progress=0.15, message="Reading audit + preparing FCPXML...")
        else:
            handle.update(progress=0.15, message="Reading audit JSON...")
        handle.check_cancel()

        # Multi-cam (issue #54). Each secondary with a known beep ships
        # alongside the primary so a single Generate click produces the
        # complete multi-cam timeline. Cams without a beep yet -- e.g.
        # registered but ingest didn't finish -- are silently skipped; the
        # SPA's ingest screen flags those rows separately. The Export page
        # may also pass ``secondary_video_ids`` to restrict the roster to a
        # subset (None = include every cam with a beep, the legacy default).
        allowed_ids: set[str] | None = (
            set(req.secondary_video_ids) if req.secondary_video_ids is not None else None
        )
        secondaries: list[export_helpers.SecondaryExport] = []
        for sv in stg.videos:
            if sv.role != "secondary":
                continue
            if sv.beep_time is None:
                continue
            if allowed_ids is not None and sv.video_id not in allowed_ids:
                continue
            sec_source = proj.resolve_video_path(state.shooter_root(slug), sv.path)
            secondaries.append(
                export_helpers.SecondaryExport(
                    video_id=sv.video_id,
                    source_path=sec_source,
                    beep_time_in_source=sv.beep_time,
                    label=f"Cam {sv.video_id}",
                )
            )

        try:
            result = export_helpers.export_stage(
                request=export_helpers.StageExportRequest(
                    stage_number=stage_number,
                    write_trim=req.write_trim,
                    write_csv=req.write_csv,
                    write_fcpxml=req.write_fcpxml,
                    write_report=req.write_report,
                    write_overlay=req.write_overlay,
                    overlay_codec=req.overlay_codec,
                    overlay_max_height=req.overlay_max_height,
                    overlay_max_fps=req.overlay_max_fps,
                    overlay_theme=req.overlay_theme,
                ),
                audit_path=audit_file,
                exports_dir=exports_dir,
                source_video_path=source_video if source_video.exists() else None,
                stage_data=engine_stage,
                beep_time_in_source=prim.beep_time,
                pre_buffer_seconds=proj.trim_pre_buffer_seconds,
                post_buffer_seconds=proj.trim_post_buffer_seconds,
                config=Config(),
                secondaries=secondaries,
            )
        except export_helpers.StageExportError as exc:
            # Surface as a job failure with the exporter's own message so
            # the JobsPanel row reads "audit JSON has no shots in shots[]"
            # rather than a stack trace.
            raise RuntimeError(str(exc)) from exc

        handle.update(progress=0.95, message="Saving project...")
        proj.updated_at = datetime.now(UTC)
        proj.save(state.shooter_root(slug))

        # Final message summarises what shipped + flags any skipped
        # artefacts (FCPXML without a trim, etc). The full list lives in
        # the report.txt; the user can Reveal it for details.
        bits: list[str] = []
        if result.trimmed_video_path is not None:
            bits.append("trim")
        if result.secondary_trimmed_paths:
            n = len(result.secondary_trimmed_paths)
            bits.append(f"{n} secondary trim{'s' if n != 1 else ''}")
        if result.csv_path is not None:
            bits.append("csv")
        if result.fcpxml_path is not None:
            bits.append("fcpxml")
        if result.report_path is not None:
            bits.append("report")
        if result.overlay_path is not None:
            bits.append("overlay")
        summary = ", ".join(bits) if bits else "nothing written"
        if result.anomalies:
            n = len(result.anomalies)
            word = "anomaly" if n == 1 else "anomalies"
            summary += f" ({n} {word} -- see report.txt)"
        handle.update(progress=1.0, message=f"Done: {summary}")

    @app.get("/api/match/templates")
    def list_match_templates() -> JSONResponse:
        """List export templates from built-in + user dirs (issue #198).

        Used by the export dialog to populate a "Template" dropdown.
        Each entry carries the parsed template body so the client can
        apply it client-side without a second request.
        """
        from .. import templates as templates_mod

        entries = templates_mod.list_templates()
        payload = [
            {
                "id": e.id,
                "source": e.source,
                "template": e.template.model_dump(exclude_none=True),
            }
            for e in entries
        ]
        return JSONResponse({"templates": payload})

    @app.post("/api/shooters/{slug}/export/match")
    def export_match(slug: str, req: MatchExportRequest) -> JSONResponse:
        """Stitch N stages into one FCPXML (issue #171, #172).

        Job-queued: per-stage trims (and optional overlays) can take
        minutes for a real match, so the response is a Job snapshot the
        SPA polls via ``/api/me/jobs/{id}``. The worker re-runs any
        missing per-stage exports before invoking the match composer,
        so the user doesn't have to click Generate on each stage first.

        Validation up-front (404 on unbound project, 400 on empty
        selection / unknown stage / missing primary or beep / padding out
        of range) so the SPA shows a clear error before queueing.
        """
        project = state.shooter_project(slug)
        if not req.stage_numbers:
            raise HTTPException(status_code=400, detail="stage_numbers cannot be empty")

        # Padding cap: clamp at the project's pre/post buffer. Exceeding
        # the cap is a 400 with a precise message, not a silent clamp --
        # the user's slider in #172 already enforces the same bound, so a
        # value above it is a real bug worth surfacing.
        max_head = project.trim_pre_buffer_seconds
        max_tail = project.trim_post_buffer_seconds
        if not 0.0 <= req.head_pad_seconds <= max_head:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"head_pad_seconds={req.head_pad_seconds} out of range; "
                    f"must be in [0.0, {max_head}] (project trim_pre_buffer)"
                ),
            )
        if not 0.0 <= req.tail_pad_seconds <= max_tail:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"tail_pad_seconds={req.tail_pad_seconds} out of range; "
                    f"must be in [0.0, {max_tail}] (project trim_post_buffer)"
                ),
            )

        # Pre-flight stage validations. Loaded once here so a bad
        # selection 400s before we queue a worker. The audit-shots check
        # happens in the worker (it reads the JSON anyway) so we don't
        # double-parse.
        for stage_number in req.stage_numbers:
            try:
                stage = project.stage(stage_number)
            except KeyError as exc:
                raise HTTPException(
                    status_code=400,
                    detail=f"stage {stage_number} not found in project",
                ) from exc
            primary = stage.primary()
            if primary is None or primary.beep_time is None:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"stage {stage_number} has no primary or no beep yet; "
                        "finish ingest + audit before match export"
                    ),
                )
            # Source-reachability matters because the worker may have to
            # produce missing trims via ffmpeg. Surface up-front rather
            # than letting the worker fail mid-flight.
            if not project.resolve_video_path(state.shooter_root(slug), primary.path).exists():
                _ensure_source_reachable(
                    stage_number,
                    project.resolve_video_path(state.shooter_root(slug), primary.path),
                )

        existing = state.jobs.find_active(kind="match_export")
        if existing is not None:
            return JSONResponse(existing.model_dump(mode="json"))
        job = state.jobs.submit(
            kind="match_export",
            fn=lambda h, sl=slug, r=req: _run_match_export(h, sl, r),
        )
        return JSONResponse(job.model_dump(mode="json"))

    def _run_match_export(handle: JobHandle, slug: str, req: MatchExportRequest) -> None:
        """Worker for the shooter's match-export job. Re-runs the per-stage exporter for
        any selected stage missing its lossless trim, then composes the
        match FCPXML.
        """
        from ..config import StageData as EngineStageData
        from . import exports as exports_mod

        handle.update(progress=0.02, message="Loading project...")
        proj = state.shooter_project(slug)
        exports_dir = proj.exports_path(state.shooter_root(slug))
        audit_dir = proj.audit_path(state.shooter_root(slug))

        n = len(req.stage_numbers)
        # Reserve the last 10% for the match compose step; the rest is
        # split evenly across per-stage trims (the dominant wall time).
        # Stages that already have a trim skip ahead within their slice
        # instead of contributing to the wait.
        per_stage_share = 0.85 / max(1, n)

        for idx, stage_number in enumerate(req.stage_numbers):
            handle.check_cancel()
            stg = proj.stage(stage_number)
            prim = stg.primary()
            if prim is None or prim.beep_time is None:
                raise RuntimeError(f"stage {stage_number}: primary or beep disappeared mid-flight")

            base = f"stage{stage_number}_{exports_mod._slugify(stg.stage_name)}"
            trimmed_path = exports_dir / f"{base}_trimmed.mp4"
            overlay_target = exports_dir / f"{base}_overlay.mov"

            # Decide what's missing. The match composer needs the
            # lossless trim + per-cam trims (when include_secondaries) +
            # optional overlay. Re-run the per-stage exporter for any
            # stage where any required artefact isn't on disk.
            wanted_secondary_ids: set[str] = set()
            if req.include_secondaries:
                for sv in stg.videos:
                    if sv.role == "secondary" and sv.beep_time is not None:
                        wanted_secondary_ids.add(sv.video_id)
            secondary_trims_present = all(
                (exports_dir / f"{base}_cam_{vid}_trimmed.mp4").exists() for vid in wanted_secondary_ids
            )
            # Treat any non-default overlay format option as "force re-render"
            # so the dialog's codec / max-height / max-fps choices actually
            # apply when a stale overlay sits on disk. With all defaults we
            # keep the legacy "skip if present" behaviour for fast re-stitching.
            overlay_format_overridden = (
                req.overlay_codec != "auto"
                or req.overlay_max_height is not None
                or req.overlay_max_fps is not None
                or req.overlay_theme != "splitsmith"
            )
            overlay_missing = req.include_overlay and (
                not overlay_target.exists() or overlay_format_overridden
            )

            needs_per_stage = not trimmed_path.exists() or not secondary_trims_present or overlay_missing
            if needs_per_stage:
                handle.update(
                    progress=0.02 + idx * per_stage_share,
                    message=(f"Stage {stage_number} ({idx + 1} of {n}): " "running per-stage export..."),
                )
                # Build the secondaries list for the per-stage exporter --
                # mirrors the single-stage endpoint's logic.
                secondaries_in: list[export_helpers.SecondaryExport] = []
                if req.include_secondaries:
                    for sv in stg.videos:
                        if sv.role != "secondary" or sv.beep_time is None:
                            continue
                        sec_source = proj.resolve_video_path(state.shooter_root(slug), sv.path)
                        secondaries_in.append(
                            export_helpers.SecondaryExport(
                                video_id=sv.video_id,
                                source_path=sec_source,
                                beep_time_in_source=sv.beep_time,
                                label=f"Cam {sv.video_id}",
                            )
                        )
                source_video = proj.resolve_video_path(state.shooter_root(slug), prim.path)
                engine_stage = EngineStageData(
                    stage_number=stg.stage_number,
                    stage_name=stg.stage_name,
                    time_seconds=stg.time_seconds,
                    scorecard_updated_at=stg.scorecard_updated_at,
                )
                try:
                    export_helpers.export_stage(
                        request=export_helpers.StageExportRequest(
                            stage_number=stage_number,
                            write_trim=True,
                            write_csv=True,
                            write_fcpxml=True,
                            write_report=True,
                            write_overlay=req.include_overlay,
                            overlay_codec=req.overlay_codec,
                            overlay_max_height=req.overlay_max_height,
                            overlay_max_fps=req.overlay_max_fps,
                            overlay_theme=req.overlay_theme,
                        ),
                        audit_path=audit_dir / f"stage{stage_number}.json",
                        exports_dir=exports_dir,
                        source_video_path=source_video if source_video.exists() else None,
                        stage_data=engine_stage,
                        beep_time_in_source=prim.beep_time,
                        pre_buffer_seconds=proj.trim_pre_buffer_seconds,
                        post_buffer_seconds=proj.trim_post_buffer_seconds,
                        config=Config(),
                        secondaries=secondaries_in,
                    )
                except export_helpers.StageExportError as exc:
                    raise RuntimeError(f"stage {stage_number}: {exc}") from exc
            else:
                handle.update(
                    progress=0.02 + idx * per_stage_share,
                    message=(f"Stage {stage_number} ({idx + 1} of {n}): " "trim already present; skipping"),
                )

        handle.check_cancel()
        handle.update(progress=0.92, message="Stitching match FCPXML...")

        # Re-load the project: the per-stage worker writes processed flags
        # via project.save() side-effects, so a fresh load picks those up.
        proj = state.shooter_project(slug)
        stages_input: list[match_export_helpers.MatchStageInput] = []
        for stage_number in req.stage_numbers:
            stg = proj.stage(stage_number)
            prim = stg.primary()
            assert prim is not None and prim.beep_time is not None
            base = f"stage{stage_number}_{exports_mod._slugify(stg.stage_name)}"
            trimmed_path = exports_dir / f"{base}_trimmed.mp4"
            audit_path = audit_dir / f"stage{stage_number}.json"
            overlay_path = exports_dir / f"{base}_overlay.mov"
            secondaries: list[match_export_helpers.MatchSecondaryInput] = []
            for sv in stg.videos:
                if sv.role != "secondary" or sv.beep_time is None:
                    continue
                sec_clip_beep = min(proj.trim_pre_buffer_seconds, sv.beep_time)
                secondaries.append(
                    match_export_helpers.MatchSecondaryInput(
                        video_id=sv.video_id,
                        trimmed_path=exports_dir / f"{base}_cam_{sv.video_id}_trimmed.mp4",
                        beep_offset_seconds=sec_clip_beep,
                        label=f"Cam {sv.video_id}",
                    )
                )
            primary_clip_beep = min(proj.trim_pre_buffer_seconds, prim.beep_time)
            stages_input.append(
                match_export_helpers.MatchStageInput(
                    stage_number=stage_number,
                    stage_name=stg.stage_name,
                    audit_path=audit_path,
                    trimmed_path=trimmed_path,
                    beep_offset_seconds=primary_clip_beep,
                    secondaries=tuple(secondaries),
                    overlay_path=overlay_path,
                )
            )

        project_name = req.project_name or proj.name or "match"
        request_data = match_export_helpers.MatchExportRequestData(
            stage_numbers=tuple(req.stage_numbers),
            head_pad_seconds=req.head_pad_seconds,
            tail_pad_seconds=req.tail_pad_seconds,
            include_secondaries=req.include_secondaries,
            include_overlay=req.include_overlay,
            project_name=project_name,
            pip_layout=req.pip_layout,
            output_format=req.output_format,
            transition_kind=req.transition_kind,
            transition_duration_seconds=req.transition_duration_seconds,
            title_kind=req.title_kind,
            title_duration_seconds=req.title_duration_seconds,
            intro_path=Path(req.intro_path).expanduser() if req.intro_path else None,
            outro_path=Path(req.outro_path).expanduser() if req.outro_path else None,
            youtube_sidecar=req.youtube_sidecar,
            youtube_preset=req.youtube_preset,
        )
        try:
            result = match_export_helpers.export_match(
                stages=stages_input,
                request=request_data,
                exports_dir=exports_dir,
                config=Config().output,
            )
        except match_export_helpers.MatchExportError as exc:
            raise RuntimeError(str(exc)) from exc

        handle.set_result(
            {
                "fcpxml_path": str(result.fcpxml_path),
                "stage_count": result.stage_count,
                "duration_seconds": result.duration_seconds,
                "anomalies": result.anomalies,
            }
        )
        anom_word = "anomaly" if len(result.anomalies) == 1 else "anomalies"
        anom_suffix = f" ({len(result.anomalies)} {anom_word})" if result.anomalies else ""
        handle.update(
            progress=1.0,
            message=(f"Done: {result.stage_count} stages, " f"{result.duration_seconds:.1f}s{anom_suffix}"),
        )

    def _reveal_in_file_manager(resolved: Path) -> None:
        """Launch the OS file manager for ``resolved``, surfacing failures.

        Without surfacing, a headless / minimal Linux install (no
        ``xdg-open``) or a Wayland session without DBUS silently
        swallows the click. Raising on nonzero exit lets the SPA toast.
        ``explorer /select`` is opted out because it returns 1 even on
        a successful selection -- treating that as failure would always
        toast on Windows.
        """
        if sys.platform == "darwin":
            cmd = ["open", "-R", str(resolved)]
            check_exit = True
        elif sys.platform.startswith("win"):
            cmd = ["explorer", f"/select,{resolved}"]
            check_exit = False
        else:
            # xdg-open doesn't support file selection; opening the parent
            # is the closest cross-distro behaviour.
            parent = resolved.parent if resolved.is_file() else resolved
            cmd = ["xdg-open", str(parent)]
            check_exit = True
        try:
            proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
        except OSError as exc:
            raise HTTPException(status_code=500, detail=f"failed to launch file manager: {exc}") from exc
        if check_exit and proc.returncode != 0:
            stderr = (proc.stderr or "").strip() or f"exit {proc.returncode}"
            raise HTTPException(
                status_code=500,
                detail=f"file manager refused to open {resolved}: {stderr}",
            )

    @app.post("/api/files/reveal")
    def reveal_file(req: RevealRequest) -> JSONResponse:
        """Reveal a file in the OS file manager.

        Restricted to paths inside the current project root so the endpoint
        can never be coerced into opening arbitrary locations. macOS uses
        ``open -R`` (selects the file in Finder); Linux uses ``xdg-open``
        on the parent dir; Windows uses ``explorer /select``.
        """
        target = Path(req.path).expanduser()
        try:
            resolved = target.resolve(strict=True)
        except (OSError, FileNotFoundError) as exc:
            raise HTTPException(status_code=404, detail=f"not found: {target}") from exc
        try:
            resolved.relative_to(state.bound_root.resolve())
        except ValueError as exc:
            raise HTTPException(
                status_code=400,
                detail="reveal path must be inside the bound project root",
            ) from exc
        _reveal_in_file_manager(resolved)
        return JSONResponse({"revealed": str(resolved)})

    @app.post("/api/shooters/{slug}/videos/reveal")
    def reveal_video(slug: str, req: RevealRequest) -> JSONResponse:
        """Reveal a registered project video in the OS file manager.

        The generic ``/api/files/reveal`` requires the resolved path to be
        inside the project root, which excludes registered videos whose
        symlinks under ``raw/`` point at the original on USB / external
        storage. This endpoint looks the path up in project state and
        reveals the symlink target -- the user already consented by
        registering the source via the picker, so revealing the original
        location is the natural action for "open containing folder".
        """
        project = state.shooter_project(slug)
        located = project.find_video(Path(req.path))
        if located is None:
            raise HTTPException(status_code=404, detail=f"video not registered: {req.path}")
        _, video = located
        target = project.resolve_video_path(state.shooter_root(slug), Path(str(video.path)))
        try:
            resolved = target.resolve(strict=True)
        except (OSError, FileNotFoundError) as exc:
            raise HTTPException(status_code=404, detail=f"not found: {target}") from exc
        _reveal_in_file_manager(resolved)
        return JSONResponse({"revealed": str(resolved)})

    @app.post("/api/shooters/{slug}/stages/{stage_number}/skip")
    def set_stage_skipped(slug: str, stage_number: int, req: SkipStageRequest) -> JSONResponse:
        """Mark ``stage_number`` as skipped (or un-skip it).

        A skipped stage is excluded from "next step" gating in the ingest
        screen so the user can advance even when the stage has no videos
        (e.g. they didn't film stage 4).
        """
        root = state.shooter_root(slug)
        project = state.shooter_project(slug)
        try:
            stage = project.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        stage.skipped = req.skipped
        project.save(root)
        return JSONResponse(project.model_dump(mode="json"))

    # ----------------------------------------------------------------------
    # Global user config (#75)
    # ----------------------------------------------------------------------
    #
    # Cross-project state lives in ``~/.splitsmith/`` (override via
    # ``SPLITSMITH_HOME``; opt out with ``SPLITSMITH_DISABLE_USER_CONFIG=1``).
    # The endpoints below let the SPA read the recent-projects list for its
    # project picker and read/write the saved SSI Scoreboard identity so the
    # scoreboard import flow can prefill 'me' instead of asking each project.

    @app.get("/api/me/recent-projects")
    def list_recent_projects(detail: bool = Query(False)) -> JSONResponse:
        """Return the recent-projects list.

        ``detail=false`` (default) returns the raw
        :class:`user_config.RecentProject` entries -- compatible with the
        legacy picker. ``detail=true`` enriches each entry with on-disk
        metadata (kind / shooters / stages / status) for the redesigned
        match picker (#322). The detailed shape is slightly slower; the
        picker route is the only caller that needs it.
        """
        projects = user_config.get_recent_projects()
        if detail:
            enriched = [_enrich_recent_project(p) for p in projects]
            return JSONResponse({"projects": [p.model_dump(mode="json") for p in enriched]})
        return JSONResponse({"projects": [p.model_dump(mode="json") for p in projects]})

    @app.post("/api/me/recent-projects/forget")
    def forget_recent_project(req: ForgetRecentProjectRequest) -> JSONResponse:
        removed = user_config.remove_recent_project(Path(req.path))
        projects = user_config.get_recent_projects()
        return JSONResponse(
            {
                "removed": removed,
                "projects": [p.model_dump(mode="json") for p in projects],
            }
        )

    @app.post("/api/me/recent-projects/bind")
    def bind_recent_project(req: BindRecentProjectRequest) -> HealthResponse:
        """Switch the in-memory project. Used by the SPA picker route.

        Accepts a path that already exists on disk (a previously-opened
        project) or a fresh path -- ``MatchProject.init`` is idempotent
        and will scaffold the subdirs if missing. The ``last_opened_at``
        timestamp is bumped so the picker re-orders to the top.
        """
        target = Path(req.path).expanduser()
        if not target.exists():
            if not req.create:
                # Conservative default: don't silently scaffold a brand-new
                # project on a typo. The "Create new project" flow on the
                # picker route passes ``create=true``.
                raise HTTPException(
                    status_code=404,
                    detail={
                        "code": "project_path_missing",
                        "message": f"Project path does not exist: {target}",
                    },
                )
            try:
                target.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        try:
            recorded = _bind_project_to_state(
                state,
                target,
                fallback_name=req.name or target.name or "match",
            )
        except OSError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _health_after_bind(recorded)

    @app.post("/api/match/create-manual")
    def create_match_manual(req: CreateMatchManualRequest) -> HealthResponse:
        """Scaffold a Match folder from the manual create-match form (#322).

        Creates ``<project_folder>/match.json`` with the supplied stages,
        registers the primary shooter under
        ``<project_folder>/shooters/<slug>/``, and binds the shooter's
        directory as the active legacy project so existing endpoints keep
        working. Folder is created if missing; refuses if a ``match.json``
        is already present (use bind to open existing matches).
        """
        target = Path(req.project_folder).expanduser()
        if (target / match_model.MATCH_FILE).exists():
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "match_already_exists",
                    "message": f"{target} already contains match.json. Open it instead.",
                },
            )
        try:
            target.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        match = match_model.Match.init(target, name=req.name)
        match.match_date = req.match_date
        match.stages = [
            match_model.MatchStageDefinition(
                stage_number=draft.stage_number,
                stage_name=draft.stage_name or f"Stage {draft.stage_number}",
                stage_rounds=(
                    StageRounds(expected=draft.expected_rounds)
                    if draft.expected_rounds is not None and draft.expected_rounds > 0
                    else None
                ),
                placeholder=False,
            )
            for draft in req.stages
        ]
        match.save(target)

        shooter_slug = match_model.mint_shooter_slug()
        shooter = match_model.Shooter(
            slug=shooter_slug,
            name=req.primary_shooter.name,
            stages=[match_model.ShooterStageData(stage_number=draft.stage_number) for draft in req.stages],
        )
        try:
            match.add_shooter(target, shooter)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        shooter_root = match_model.Match.shooter_root(target, shooter_slug)
        # The legacy MatchProject inside the shooter dir needs to mirror the
        # match-level stage definitions so the existing audit/ingest endpoints
        # have stages to operate on. We seed it directly rather than relying
        # on the user re-importing scoreboard data.
        legacy = MatchProject.init(shooter_root, name=req.name)
        legacy.competitor_name = req.primary_shooter.name
        legacy.match_date = req.match_date
        if not legacy.stages:
            for draft in req.stages:
                legacy.stages.append(
                    StageEntry(
                        stage_number=draft.stage_number,
                        stage_name=draft.stage_name or f"Stage {draft.stage_number}",
                        time_seconds=0.0,
                        stage_rounds=(
                            StageRounds(expected=draft.expected_rounds)
                            if draft.expected_rounds is not None and draft.expected_rounds > 0
                            else None
                        ),
                        placeholder=False,
                    )
                )
        legacy.save(shooter_root)

        # Bind via the match folder so _bind_project_to_state records it as
        # kind="match" and binds the first shooter without registering the
        # shooter subdir as a separate legacy project in recent-projects.
        try:
            recorded = _bind_project_to_state(state, target, fallback_name=req.name)
        except OSError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _health_after_bind(recorded)

    @app.post("/api/match/create-from-scoreboard")
    def create_match_from_scoreboard(
        req: CreateMatchScoreboardRequest,
    ) -> HealthResponse:
        """Scaffold a Match folder for a scoreboard-imported match (#322).

        Creates the folder, fetches the upstream ``MatchData`` once, and
        materialises one shooter per :class:`CreateMatchCompetitorPick`:
        each gets a populated legacy ``MatchProject`` with stage shells
        from the match, the competitor pinned, and stage times merged.
        Then binds the match. The user lands on a match where every
        shooter is already ready for the audit/ingest flow.
        """
        if not req.competitors:
            raise HTTPException(
                status_code=400,
                detail="at least one competitor must be selected",
            )
        comp_ids_seen: set[int] = set()
        for pick in req.competitors:
            if pick.selected_competitor_id in comp_ids_seen:
                raise HTTPException(
                    status_code=400,
                    detail=(f"duplicate competitor {pick.selected_competitor_id} " "in picks"),
                )
            comp_ids_seen.add(pick.selected_competitor_id)

        target = Path(req.project_folder).expanduser()
        if (target / match_model.MATCH_FILE).exists():
            raise HTTPException(
                status_code=409,
                detail={
                    "code": "match_already_exists",
                    "message": f"{target} already contains match.json. Open it instead.",
                },
            )
        try:
            target.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        match = match_model.Match.init(target, name=req.name)
        match.scoreboard_match_id = str(req.match_id)
        match.scoreboard_content_type = req.content_type
        match.save(target)

        # Fetch the match shell once -- we'll reuse it for every shooter
        # via the project-local cache so subsequent get_match calls hit
        # disk rather than the network.
        with _resolve_scoreboard_client(target) as client:
            try:
                match_data = client.get_match(req.content_type, req.match_id)
            except MatchNotFound as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
            except ScoreboardError as exc:
                _raise_scoreboard_http(exc)

        # Stable alphabetical materialisation so reruns / re-imports
        # land in the same shooter order. No "primary" shooter -- the
        # operator may not be in the roster at all (#350).
        ordered = sorted(req.competitors, key=lambda c: c.name.lower())
        for pick in ordered:
            shooter_slug = match_model.mint_shooter_slug(taken=set(match.shooters))
            shooter = match_model.Shooter(
                slug=shooter_slug,
                name=pick.name,
                selected_shooter_id=pick.selected_shooter_id,
                selected_competitor_id=pick.selected_competitor_id,
            )
            try:
                match.add_shooter(target, shooter)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc

            shooter_root = match_model.Match.shooter_root(target, shooter_slug)
            legacy = MatchProject.init(shooter_root, name=req.name)
            legacy.competitor_name = pick.name
            legacy.scoreboard_match_id = str(req.match_id)
            legacy.scoreboard_content_type = req.content_type
            legacy.selected_shooter_id = pick.selected_shooter_id
            legacy.selected_competitor_id = pick.selected_competitor_id
            try:
                legacy.populate_from_match_data(match_data, overwrite=False)
            except ScoreboardImportConflictError as exc:
                # Fresh project -- shouldn't happen, but surface clearly.
                raise HTTPException(status_code=409, detail=str(exc)) from exc
            legacy.save(shooter_root)

            # Pull stage times. Failures here aren't fatal -- the user
            # can refresh later from the shooters page -- but we record
            # the failure on the per-shooter project so the caller knows
            # which ones came up short.
            try:
                _fetch_and_merge_stage_times(
                    shooter_root,
                    legacy,
                    req.content_type,
                    req.match_id,
                    pick.selected_competitor_id,
                )
            except HTTPException as exc:
                # Don't abort the whole create on one shooter's stage
                # times failing -- log and continue. The user can hit
                # "refresh times" once the upstream issue resolves.
                logger.warning(
                    "stage-times merge failed for %s (%s): %s",
                    pick.name,
                    shooter_slug,
                    exc.detail,
                )

        # See create_match_manual: bind via the match folder, not a
        # shooter dir, so recent-projects only gets a kind="match" entry.
        try:
            recorded = _bind_project_to_state(state, target, fallback_name=req.name)
        except OSError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _health_after_bind(recorded)

    # ----------------------------------------------------------------------
    # Shooters management (#324)
    # ----------------------------------------------------------------------

    def _resolve_match_context() -> tuple[Path, match_model.Match]:
        """Return ``(match_root, match)`` for the bound project.

        Raises 409 ``not_a_match`` for legacy single-shooter layouts (the
        shooter-listing / merge / compare endpoints are match-only).
        """
        match_root = state.match_root
        return match_root, match_model.Match.load(match_root)

    def _classify_shooter(shooter_root: Path, match: match_model.Match) -> ShooterListEntry:
        """Build a list entry for a single shooter directory."""
        legacy = MatchProject.load(shooter_root)
        # ``audited`` requires the operator to have hit Save & next on
        # the stage (see :func:`stage_audit_status`). Set-up-but-not-
        # touched stages used to count here; they no longer do.
        stages_audited = legacy.audited_count(shooter_root)
        stages_missing_trim = 0
        for s in legacy.stages:
            prim = next((v for v in s.videos if v.role == "primary"), None)
            if prim is None or prim.beep_time is None or s.time_seconds <= 0:
                continue
            try:
                source = legacy.resolve_video_path(shooter_root, prim.path)
                if not source.exists():
                    continue
            except Exception:  # noqa: BLE001 -- defensive
                continue
            cache = audio_helpers.trimmed_video_path(shooter_root, s.stage_number, prim, project=legacy)
            if not cache.exists():
                stages_missing_trim += 1
        # Camera grouping: ``(make, model, mount)`` -> [(role, count, stages)].
        groups: dict[tuple[str | None, str | None, str | None], dict[str, Any]] = {}
        total_videos = 0
        for stage in legacy.stages:
            for video in stage.videos:
                if video.role == "ignored":
                    continue
                key = (video.camera_make, video.camera_model, video.camera_mount)
                g = groups.setdefault(
                    key,
                    {
                        "role": video.role,
                        "video_count": 0,
                        "stages": set(),
                    },
                )
                # Primary wins over secondary if any video on this camera is
                # primary on any stage (shooters tend to keep camera roles
                # consistent across stages).
                if video.role == "primary":
                    g["role"] = "primary"
                g["video_count"] += 1
                g["stages"].add(stage.stage_number)
                total_videos += 1
        cameras = [
            ShooterCameraInfo(
                group_key=f"{k[0] or ''}|{k[1] or ''}|{k[2] or ''}",
                make=k[0],
                model=k[1],
                mount=k[2],
                role=g["role"],
                video_count=g["video_count"],
                stage_numbers=sorted(g["stages"]),
            )
            for k, g in groups.items()
        ]
        return ShooterListEntry(
            slug=shooter_root.name,
            name=legacy.competitor_name or shooter_root.name,
            selected_shooter_id=legacy.selected_shooter_id,
            selected_competitor_id=legacy.selected_competitor_id,
            stages_audited=stages_audited,
            stages_total=len(match.stages),
            video_count=total_videos,
            cameras=cameras,
            stages_missing_trim=stages_missing_trim,
        )

    # ----------------------------------------------------------------------
    # Match merge (#332) -- consolidate N legacy single-shooter projects
    # into one redesign-era match folder via the SPA. Wraps the existing
    # match_model.plan_merge + execute_merge that the `splitsmith match
    # merge` CLI uses.
    # ----------------------------------------------------------------------

    def _plan_response_from_model(plan: match_model.MergePlan) -> MergePlanResponse:
        return MergePlanResponse(
            output_root=str(plan.output_root),
            name=plan.name,
            scoreboard_match_id=plan.scoreboard_match_id,
            scoreboard_content_type=plan.scoreboard_content_type,
            match_date=plan.match_date.isoformat() if plan.match_date else None,
            stages=[
                MergePlanStage(
                    stage_number=s.stage_number,
                    stage_name=s.stage_name,
                    expected_rounds=(s.stage_rounds.expected if s.stage_rounds is not None else None),
                    placeholder=s.placeholder,
                )
                for s in plan.stages
            ],
            shooter_moves=[
                MergePlanShooterMove(
                    source_root=str(mv.source_root),
                    slug=mv.slug,
                    destination_root=str(mv.destination_root),
                    competitor_name=mv.competitor_name,
                )
                for mv in plan.shooter_moves
            ],
        )

    @app.post("/api/match/merge/plan", response_model=MergePlanResponse)
    def merge_plan(req: MergePlanRequest) -> MergePlanResponse:
        """Dry-run a merge of N legacy single-shooter projects into one
        match folder. Returns the reconciled stage definitions + per-shooter
        slug assignments so the SPA can show the user what *would* happen
        before they commit.

        409 with the conflict message when stage definitions, scoreboard
        ids, or names disagree across inputs. The user reconciles those at
        the source before retrying.
        """
        if len(req.inputs) < 2:
            raise HTTPException(
                status_code=400,
                detail="merge requires at least two input projects",
            )
        inputs = [Path(p).expanduser() for p in req.inputs]
        for src in inputs:
            if not src.exists():
                raise HTTPException(status_code=400, detail=f"input not found: {src}")
            if not match_model.is_legacy_project_folder(src):
                raise HTTPException(
                    status_code=400,
                    detail=(f"{src} is not a legacy single-shooter project " "(no project.json)"),
                )
        # output is optional for plan -- the user may not have picked a
        # destination yet. Fall back to "(unset)" so the response still
        # validates; the SPA prompts for a real path before execute.
        output = Path(req.output).expanduser() if req.output else Path("(unset)")
        try:
            plan = match_model.plan_merge(inputs, output, name=req.name)
        except match_model.MergeConflictError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return _plan_response_from_model(plan)

    @app.post("/api/match/merge/execute", response_model=HealthResponse)
    def merge_execute(req: MergeExecuteRequest) -> HealthResponse:
        """Execute a merge and bind the new match's first shooter as the
        active project so the user lands on a working session immediately.

        Refuses if the destination already contains ``match.json`` (the
        plan validation does the same check, but the user could race
        between plan + execute). Records the new match in the recent-
        projects index so the picker picks it up.
        """
        if len(req.inputs) < 2:
            raise HTTPException(
                status_code=400,
                detail="merge requires at least two input projects",
            )
        inputs = [Path(p).expanduser() for p in req.inputs]
        output = Path(req.output).expanduser()
        try:
            plan = match_model.plan_merge(inputs, output, name=req.name)
        except match_model.MergeConflictError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        try:
            match = match_model.execute_merge(plan, move=req.move)
        except FileExistsError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except OSError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

        # Bind the new match. ``_bind_project_to_state`` records the match
        # in recent-projects (kind="match") and switches state.bound_root
        # to the match folder; shooters are addressed by slug from there.
        try:
            recorded = _bind_project_to_state(state, output, fallback_name=match.name)
        except OSError as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc
        return _health_after_bind(recorded)

    @app.get("/api/match/shooters", response_model=ShooterListResponse)
    def list_match_shooters() -> ShooterListResponse:
        """List every shooter in the currently-bound match with coverage."""
        match_root, match = _resolve_match_context()
        entries: list[ShooterListEntry] = []
        for slug in match.shooters:
            shooter_root = match_model.Match.shooter_root(match_root, slug)
            try:
                entries.append(_classify_shooter(shooter_root, match))
            except Exception as exc:  # noqa: BLE001
                logger.warning("Skipping shooter %s: %s", slug, exc)
                continue
        return ShooterListResponse(
            match_root=str(match_root),
            match_name=match.name,
            shooters=entries,
        )

    @app.post("/api/match/shooters", response_model=ShooterListResponse)
    def add_match_shooter(req: AddShooterRequest) -> ShooterListResponse:
        """Add a new shooter to the bound match.

        Creates the ``<match>/shooters/<slug>/`` tree, mirrors the match's
        stage definitions into the shooter's ``project.json``, and saves a
        ``shooter.json`` next to it. Returns the refreshed list. Slugs are
        opaque random ids (``s_<hex>``) so URLs / disk paths don't leak
        competitor names.
        """
        match_root, match = _resolve_match_context()
        if not req.name.strip():
            raise HTTPException(status_code=400, detail="name is required")
        slug = match_model.mint_shooter_slug(set(match.shooters))
        shooter = match_model.Shooter(
            slug=slug,
            name=req.name,
            stages=[match_model.ShooterStageData(stage_number=s.stage_number) for s in match.stages],
        )
        try:
            match.add_shooter(match_root, shooter)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        shooter_root = match_model.Match.shooter_root(match_root, slug)
        legacy = MatchProject.init(shooter_root, name=match.name)
        legacy.competitor_name = req.name
        legacy.match_date = match.match_date
        legacy.scoreboard_match_id = match.scoreboard_match_id
        legacy.scoreboard_content_type = match.scoreboard_content_type
        if not legacy.stages:
            for sd in match.stages:
                legacy.stages.append(
                    StageEntry(
                        stage_number=sd.stage_number,
                        stage_name=sd.stage_name,
                        time_seconds=0.0,
                        stage_rounds=sd.stage_rounds,
                        placeholder=sd.placeholder,
                    )
                )
        legacy.save(shooter_root)
        return list_match_shooters()

    @app.delete("/api/match/shooters/{slug}", response_model=ShooterListResponse)
    def remove_match_shooter(slug: str) -> ShooterListResponse:
        """Remove a shooter from the bound match.

        Drops the slug from ``match.json`` and deletes
        ``<match>/shooters/<slug>/`` from disk.
        """
        match_root, match = _resolve_match_context()
        if slug not in match.shooters:
            raise HTTPException(status_code=404, detail="shooter not found")
        shooter_root = match_model.Match.shooter_root(match_root, slug)
        if shooter_root.exists():
            shutil.rmtree(shooter_root, ignore_errors=True)
        match.shooters = [s for s in match.shooters if s != slug]
        match.save(match_root)
        return list_match_shooters()

    @app.post("/api/match/shooters/{slug}/build-trim-caches")
    def build_shooter_trim_caches(slug: str) -> JSONResponse:
        """Submit trim-cache jobs for every stage in ``slug``'s project
        where the audit-mode short-GOP MP4 is missing (#351).

        Operates against the shooter's project root directly rather than
        the bound ``state``, so the user can regenerate Mathias's caches
        while staying on Anton's audit screen. Each stage with a primary
        + beep + stage_time + reachable source becomes one trim job in
        the existing JobRegistry; the SPA's JobsPanel surfaces them.
        Stages already cached are skipped silently (the underlying
        ``ensure_video_audit_trim`` is idempotent, but skipping early
        avoids the queue churn).
        """
        match_root, match = _resolve_match_context()
        if slug not in match.shooters:
            raise HTTPException(status_code=404, detail="shooter not found")
        shooter_root = match_model.Match.shooter_root(match_root, slug)
        try:
            proj = MatchProject.load(shooter_root)
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

        jobs_submitted: list[dict[str, Any]] = []
        skipped: list[dict[str, Any]] = []
        for stage in proj.stages:
            primary = next((v for v in stage.videos if v.role == "primary"), None)
            if primary is None:
                skipped.append({"stage": stage.stage_number, "reason": "no_primary"})
                continue
            if primary.beep_time is None:
                skipped.append({"stage": stage.stage_number, "reason": "no_beep"})
                continue
            if stage.time_seconds <= 0:
                skipped.append({"stage": stage.stage_number, "reason": "no_stage_time"})
                continue
            try:
                source = proj.resolve_video_path(shooter_root, primary.path)
            except Exception:  # noqa: BLE001 -- defensive
                skipped.append({"stage": stage.stage_number, "reason": "source_unreachable"})
                continue
            if not source.exists():
                skipped.append({"stage": stage.stage_number, "reason": "source_missing"})
                continue
            cache = audio_helpers.trimmed_video_path(shooter_root, stage.stage_number, primary, project=proj)
            if cache.exists():
                skipped.append({"stage": stage.stage_number, "reason": "already_cached"})
                continue
            # video_id is a hash of the source path so it's unique across
            # shooters -- the JobRegistry dedup key (kind, stage, video_id)
            # won't collide with the same stage on a different shooter.
            existing = state.jobs.find_active(
                kind="trim",
                stage_number=stage.stage_number,
                video_id=primary.video_id,
            )
            if existing is not None:
                jobs_submitted.append(existing.model_dump(mode="json"))
                continue
            job = state.jobs.submit(
                kind="trim",
                stage_number=stage.stage_number,
                video_id=primary.video_id,
                fn=lambda h, sr=shooter_root, n=stage.stage_number, vid=primary.video_id: (
                    _run_trim_at_root(h, sr, n, vid)
                ),
            )
            jobs_submitted.append(job.model_dump(mode="json"))

        return JSONResponse(
            {
                "shooter_slug": slug,
                "shooter_name": proj.competitor_name,
                "jobs_submitted": jobs_submitted,
                "skipped": skipped,
            }
        )

    # ----------------------------------------------------------------------
    # Stage compare (#328)
    # ----------------------------------------------------------------------

    @app.get(
        "/api/match/stage/{stage_number}/compare",
        response_model=CompareStageResponse,
    )
    def get_stage_compare(stage_number: int) -> CompareStageResponse:
        """Per-shooter compare data for a stage.

        Each shooter contributes their lossless trim path (if built),
        ``beep_offset_in_clip`` so the SPA can align all clips to time-
        since-beep, and the shot list as a list of ``time_after_beep``
        scalars. Shooters with no trim still appear so the SPA can render
        empty tiles instead of silently dropping the slot.
        """
        match_root, match = _resolve_match_context()
        try:
            stage_def = match.stage(stage_number)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

        records: list[CompareShooterRecord] = []
        for slug in match.shooters:
            shooter_root = match_model.Match.shooter_root(match_root, slug)
            try:
                legacy = MatchProject.load(shooter_root)
            except FileNotFoundError:
                continue
            stage = next(
                (s for s in legacy.stages if s.stage_number == stage_number),
                None,
            )
            primary = (
                next((v for v in stage.videos if v.role == "primary"), None) if stage is not None else None
            )

            beep_offset: float | None = None
            duration_seconds: float | None = None
            video_path: str | None = None
            if stage is not None and primary is not None and primary.beep_time is not None:
                # Prefer the lossless export (same file FCPXML references);
                # fall back to the audit-mode short-GOP cache produced
                # during trim+audit. Both are cuts of the same source at
                # ``beep_time - pre_buffer``, so beep alignment is identical;
                # the audit cache is the H.264 version the browser already
                # streams during scrubbing. Either is fine for sync playback,
                # and the fallback lets compare just work after audit
                # without requiring a separate lossless export pass.
                stage_name = stage_def.stage_name
                base = f"stage{stage_number}_{match_export_helpers._slugify(stage_name)}"
                exports = (
                    Path(legacy.exports_dir).expanduser() if legacy.exports_dir else shooter_root / "exports"
                )
                if not exports.is_absolute():
                    exports = shooter_root / exports
                trimmed = (
                    Path(legacy.trimmed_dir).expanduser() if legacy.trimmed_dir else shooter_root / "trimmed"
                )
                if not trimmed.is_absolute():
                    trimmed = shooter_root / trimmed
                lossless = exports / f"{base}_trimmed.mp4"
                audit_cache = trimmed / f"stage{stage_number}_cam_{primary.video_id}_trimmed.mp4"
                resolved_trim = (
                    lossless if lossless.exists() else (audit_cache if audit_cache.exists() else None)
                )
                if resolved_trim is not None:
                    video_path = str(resolved_trim)
                    beep_offset = min(legacy.trim_pre_buffer_seconds, primary.beep_time)

            # Shots come from audit; convert each shot.time to time-after-beep.
            shots: list[CompareShotPoint] = []
            if stage is not None and primary is not None and primary.beep_time is not None:
                audit_path = shooter_root / "audit" / f"stage{stage_number}.json"
                if audit_path.exists():
                    try:
                        audit_data = json.loads(audit_path.read_text(encoding="utf-8"))
                    except (OSError, json.JSONDecodeError):
                        audit_data = None
                    if isinstance(audit_data, dict):
                        for shot in audit_data.get("shots") or []:
                            t = shot.get("time")
                            if t is None:
                                continue
                            # Audit stores time in the trim's local clock;
                            # subtract the trim's beep offset to get
                            # time-since-beep.
                            audit_beep = audit_data.get("beep_time")
                            if audit_beep is None:
                                continue
                            shots.append(
                                CompareShotPoint(
                                    shot_number=int(shot.get("shot_number", 0)),
                                    time_after_beep=float(t) - float(audit_beep),
                                    source=("manual" if shot.get("source") == "manual" else "detected"),
                                )
                            )

            records.append(
                CompareShooterRecord(
                    slug=slug,
                    name=legacy.competitor_name or slug,
                    video_path=video_path,
                    beep_offset_in_clip=beep_offset,
                    duration_seconds=duration_seconds,
                    stage_time_seconds=(stage.time_seconds if stage is not None else None),
                    shots=shots,
                )
            )

        return CompareStageResponse(
            stage_number=stage_number,
            stage_name=stage_def.stage_name,
            shooters=records,
        )

    @app.get("/api/match/shooters/{slug}/videos/stream")
    def stream_shooter_video(
        slug: str,
        path: str = Query(...),
    ) -> FileResponse:
        """Serve a video registered to any shooter in the bound match (#328).

        The Compare view streams from up to N shooters at once; the
        regular /api/videos/stream endpoint only sees the active
        shooter's registry. This thin wrapper validates ``path`` against
        the named shooter's project then returns a FileResponse on the
        resolved trim/source.
        """
        match_root, match = _resolve_match_context()
        if slug not in match.shooters:
            raise HTTPException(status_code=404, detail="shooter not found")
        shooter_root = match_model.Match.shooter_root(match_root, slug)
        try:
            shooter_project = MatchProject.load(shooter_root)
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=f"shooter project missing: {exc}") from exc

        target = Path(path)
        # Allow either a registered raw/source path OR a trim file we wrote
        # ourselves: the lossless export under exports/ (FCPXML-grade) or
        # the audit-mode short-GOP cache under trimmed/ (compare's fallback
        # when no lossless export exists yet).
        located = shooter_project.find_video(target)
        served_path: Path | None = None
        if located is not None:
            stage, video = located
            served_path = shooter_project.resolve_video_path(shooter_root, video.path).resolve()
        else:
            resolved = target.expanduser().resolve()
            exports_dir = (
                Path(shooter_project.exports_dir).expanduser().resolve()
                if shooter_project.exports_dir
                else (shooter_root / "exports").resolve()
            )
            trimmed_dir = (
                Path(shooter_project.trimmed_dir).expanduser().resolve()
                if shooter_project.trimmed_dir
                else (shooter_root / "trimmed").resolve()
            )
            in_allowed_dir = False
            for allowed in (exports_dir, trimmed_dir):
                try:
                    resolved.relative_to(allowed)
                    in_allowed_dir = True
                    break
                except ValueError:
                    continue
            if not in_allowed_dir:
                raise HTTPException(
                    status_code=403,
                    detail=(
                        f"path {path} is neither a registered video nor inside "
                        f"the shooter's exports/ or trimmed/ dirs"
                    ),
                )
            if not resolved.exists():
                raise HTTPException(status_code=404, detail=f"file not found: {resolved}")
            served_path = resolved

        media_type = "video/mp4"
        return FileResponse(served_path, media_type=media_type)

    # ----------------------------------------------------------------------
    # Cross-shooter beep review queue (#326)
    # ----------------------------------------------------------------------

    @app.get("/api/match/beep-queue", response_model=BeepQueueResponse)
    def get_beep_queue(include_confirmed: bool = Query(default=False)) -> BeepQueueResponse:
        """Pending beep items across every shooter in the bound match.

        Surfaces three pending states per primary video:
          - ``missing``: detector hasn't run or didn't find a beep
          - ``low_confidence``: detector found one but below the project's
            auto-trust threshold
          - ``unreviewed``: detector found one above threshold but the
            user hasn't yet listened + approved

        When ``include_confirmed`` is true the response also includes
        items whose beep has been reviewed, with ``status="confirmed"``.
        The SPA uses this for the "Show confirmed" toggle so the user
        can revisit a settled beep without having to clear-and-redo it.

        Items are grouped by stage; per-stage shot detection is gated on
        every shooter's primary in that stage being ``beep_reviewed``.
        """
        match_root, match = _resolve_match_context()
        # Resolve the low-confidence threshold from any shooter's automation
        # settings; per-shooter thresholds aren't supported, the gate is
        # global to the match.
        threshold = 0.5
        for first_slug in match.shooters:
            try:
                proj_for_threshold = state.shooter_project(first_slug)
                resolved = automation_settings.resolve_automation(proj_for_threshold)
                threshold = resolved.settings.beep_low_confidence_threshold
                break
            except Exception:  # noqa: BLE001
                continue

        stage_lookup = {s.stage_number: s.stage_name for s in match.stages}
        groups: dict[int, BeepQueueStageGroup] = {}
        total_pending = 0
        total_confirmed = 0
        total_primaries = 0

        for slug in match.shooters:
            shooter_root = match_model.Match.shooter_root(match_root, slug)
            try:
                proj = MatchProject.load(shooter_root)
            except FileNotFoundError:
                continue
            for stage in proj.stages:
                if stage.skipped:
                    continue
                primary = next((v for v in stage.videos if v.role == "primary"), None)
                if primary is None:
                    continue
                total_primaries += 1
                grp = groups.setdefault(
                    stage.stage_number,
                    BeepQueueStageGroup(
                        stage_number=stage.stage_number,
                        stage_name=stage_lookup.get(stage.stage_number, stage.stage_name),
                        items=[],
                        total_primaries=0,
                        confirmed=0,
                    ),
                )
                grp.total_primaries += 1
                # Status classification.
                if primary.beep_time is None:
                    status = "missing"
                elif primary.beep_reviewed:
                    grp.confirmed += 1
                    total_confirmed += 1
                    if not include_confirmed:
                        continue
                    status = "confirmed"
                elif primary.beep_confidence is not None and primary.beep_confidence < threshold:
                    status = "low_confidence"
                else:
                    status = "unreviewed"
                if status != "confirmed":
                    total_pending += 1
                alts = [
                    BeepQueueAltCandidate(
                        time=cand.time,
                        confidence=cand.confidence,
                    )
                    for cand in (primary.beep_candidates or [])[:3]
                ]
                grp.items.append(
                    BeepQueueItem(
                        slug=slug,
                        shooter_name=proj.competitor_name or slug,
                        stage_number=stage.stage_number,
                        stage_name=stage_lookup.get(stage.stage_number, stage.stage_name),
                        video_id=primary.video_id,
                        video_path=primary.path.as_posix(),
                        beep_time=primary.beep_time,
                        beep_confidence=primary.beep_confidence,
                        beep_reviewed=primary.beep_reviewed,
                        status=status,
                        alt_candidates=alts,
                    )
                )

        ordered_stages = sorted(groups.values(), key=lambda g: g.stage_number)
        return BeepQueueResponse(
            total_items=total_primaries,
            pending_count=total_pending,
            confirmed_count=total_confirmed,
            stages=ordered_stages,
        )

    @app.post("/api/match/beep-queue/confirm", response_model=BeepQueueResponse)
    def confirm_beep_in_queue(req: BeepQueueConfirmRequest) -> BeepQueueResponse:
        """Confirm a beep on any shooter without changing the bound state.

        Writes through to the named shooter's ``project.json`` directly so
        the rest of the SPA's state (active shooter) is unaffected.
        When ``time`` is supplied, it overrides ``beep_time``; the call
        always sets ``beep_reviewed = True``.
        """
        match_root, match = _resolve_match_context()
        if req.slug not in match.shooters:
            raise HTTPException(status_code=404, detail="shooter not found")
        shooter_root = match_model.Match.shooter_root(match_root, req.slug)
        try:
            proj = MatchProject.load(shooter_root)
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        target_stage = next(
            (s for s in proj.stages if s.stage_number == req.stage_number),
            None,
        )
        if target_stage is None:
            raise HTTPException(status_code=404, detail="stage not found")
        target_video = next((v for v in target_stage.videos if v.video_id == req.video_id), None)
        if target_video is None:
            raise HTTPException(status_code=404, detail="video not found")
        if req.time is not None:
            target_video.beep_time = float(req.time)
            target_video.beep_source = "manual" if req.source == "manual" else "detected"
        if target_video.beep_time is None:
            raise HTTPException(
                status_code=400,
                detail="cannot mark a beep reviewed before one has been detected",
            )
        target_video.beep_reviewed = True
        proj.save(shooter_root)
        return get_beep_queue()

    @app.post("/api/me/recent-projects/unbind")
    def unbind_recent_project() -> HealthResponse:
        """Drop the bound project so the SPA returns to the picker.

        Equivalent to a `splitsmith ui` boot with no ``--project``;
        useful when the user wants to switch projects without leaving
        the browser tab.
        """
        state.unbind()
        return HealthResponse(bound=False)

    @app.get("/api/me/scoreboard-identity")
    def get_scoreboard_identity() -> JSONResponse:
        # "Not pinned yet" is a normal state, not an error -- return a
        # 200 with a null body so the SPA doesn't have to catch a 404
        # on every page load and DevTools doesn't log a failed request.
        identity = user_config.load_scoreboard_identity()
        if identity is None:
            return JSONResponse(None)
        return JSONResponse(identity.model_dump(mode="json"))

    @app.put("/api/me/scoreboard-identity")
    def put_scoreboard_identity(req: ScoreboardIdentityRequest) -> JSONResponse:
        identity = user_config.ScoreboardIdentity(
            shooter_id=req.shooter_id,
            display_name=req.display_name,
            division=req.division,
            club=req.club,
            base_url=req.base_url,
        )
        user_config.save_scoreboard_identity(identity)
        return JSONResponse(identity.model_dump(mode="json"))

    @app.delete("/api/me/scoreboard-identity")
    def delete_scoreboard_identity() -> JSONResponse:
        user_config.clear_scoreboard_identity()
        return JSONResponse({"ok": True})

    @app.get("/api/server/features")
    def server_features() -> JSONResponse:
        """Surface server-side feature flags to the SPA on first load.

        Today: ``lab`` (the developer-facing Algorithm Lab page; off by
        default, opt-in via ``splitsmith ui --lab``). The SPA hides the
        Lab nav entry when this is False so end users don't trip into
        a multi-second model-loading workflow they didn't ask for.
        """
        return JSONResponse({"lab": lab_enabled})

    # ----------------------------------------------------------------------
    # Lab: fixture management + ensemble eval + tuning
    # ----------------------------------------------------------------------
    #
    # End-user-visible only via the /lab route in the SPA. Heavy CLAP/PANN
    # runtime is loaded once on first /api/lab/eval call and cached on the
    # FastAPI app instance so subsequent eval / rescore calls amortise it.
    # The whole block is gated on ``lab_enabled`` so end-user installs
    # don't expose the developer-only routes (or carry the import cost).

    def _setup_lab() -> None:
        from .. import lab as lab_module

        _lab_runtime_cache: dict[str, Any] = {}
        _lab_universe_cache: dict[str, Any] = {}  # session: most recent run

        def _get_lab_runtime() -> Any:
            rt = _lab_runtime_cache.get("runtime")
            if rt is None:
                rt = ensemble_module.api.load_ensemble_runtime()
                _lab_runtime_cache["runtime"] = rt
            return rt

        @app.get("/api/lab/fixtures")
        def lab_fixtures() -> JSONResponse:
            return JSONResponse([r.model_dump(mode="json") for r in lab_module.list_fixtures()])

        @app.get("/api/lab/last-run")
        def lab_last_run() -> JSONResponse:
            """Return the most recent eval/rescore in this server session.

            Lets the SPA hydrate after a navigation away from /lab so
            clicking around doesn't wipe the eval state. 404 when no eval
            has been run yet (or when /api/lab/labels invalidated the
            cache).
            """
            last_run = _lab_universe_cache.get("last_run")
            if last_run is None:
                raise HTTPException(status_code=404, detail="no eval has been run yet")
            return JSONResponse(last_run.model_dump(mode="json"))

        @app.post("/api/lab/eval")
        def lab_eval(
            payload: dict[str, Any] = Body(default_factory=dict),  # noqa: B008
        ) -> JSONResponse:
            """Submit a lab-eval job. Returns a ``Job`` snapshot immediately;
            the SPA polls ``/api/jobs/{id}`` and then fetches the result via
            ``/api/lab/last-run`` once the job succeeds. Multi-second on the
            12 fixtures, so doing this inline blocked the request and
            deprived the JobsPanel of progress visibility.
            """
            slugs = payload.get("slugs")
            cfg_payload = payload.get("config") or {}
            cfg = lab_module.EvalConfig.model_validate(cfg_payload)
            persist = bool(payload.get("persist", True))
            wanted_slugs = slugs if isinstance(slugs, list) else None

            def _run(handle: JobHandle) -> None:
                handle.update(progress=0.0, message="Loading ensemble runtime...")
                runtime = _get_lab_runtime()

                def progress(i: int, total: int, slug: str) -> None:
                    handle.check_cancel()
                    handle.update(
                        progress=i / total if total else 1.0,
                        message=f"{slug} ({i}/{total})",
                    )

                run = lab_module.run_eval(
                    runtime,
                    slugs=wanted_slugs,
                    config=cfg,
                    progress=progress,
                )
                if persist:
                    try:
                        lab_module.save_run(run)
                    except OSError as exc:
                        logger.warning("lab: save_run failed: %s", exc)
                _lab_universe_cache["universe"] = run.universe
                _lab_universe_cache["last_run"] = run
                handle.update(progress=1.0, message=f"done ({len(run.universe.fixtures)} fixtures)")

            job = state.jobs.submit(kind="lab_eval", fn=_run)
            return JSONResponse(job.model_dump(mode="json"))

        @app.post("/api/lab/rescore")
        def lab_rescore(payload: dict[str, Any] = Body(...)) -> JSONResponse:  # noqa: B008
            cfg = lab_module.EvalConfig.model_validate(payload.get("config") or {})
            universe = _lab_universe_cache.get("universe")
            if universe is None:
                raise HTTPException(
                    status_code=409,
                    detail="no cached eval universe; call /api/lab/eval first",
                )
            run = lab_module.rescore_universe(universe, cfg)
            _lab_universe_cache["universe"] = run.universe
            _lab_universe_cache["last_run"] = run
            return JSONResponse(run.model_dump(mode="json"))

        @app.post("/api/lab/promote")
        def lab_promote(payload: dict[str, Any] = Body(...)) -> JSONResponse:  # noqa: B008
            stage_n = payload.get("stage_number")
            slug = payload.get("slug")
            overwrite = bool(payload.get("overwrite", False))
            if not isinstance(stage_n, int) or not isinstance(slug, str) or not slug:
                raise HTTPException(
                    status_code=400,
                    detail="payload must include integer 'stage_number' and string 'slug'",
                )
            project = state.shooter_project(slug)
            try:
                stg = project.stage(stage_n)
            except KeyError as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
            audit_json = project.audit_path(state.shooter_root(slug)) / f"stage{stage_n}.json"
            try:
                audit_audio = _resolve_audit_audio(slug, project, stage_n)
            except HTTPException:
                raise
            audit_wav = audit_audio.audio_path
            if not audit_json.exists() or not audit_wav.exists():
                raise HTTPException(
                    status_code=409,
                    detail="stage has no audit JSON / WAV; run shot-detect first",
                )
            # Refuse to promote without an explicit shooter pin (#149
            # follow-up). Fixture training data is only useful when we
            # can attribute it to a known shooter; the legacy ``self``
            # sentinel is for migrating pre-existing corpora, not for
            # new promotions. Pin via the SSI search on the Ingest page.
            if project.selected_shooter_id is None:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "this project has no SSI shooter pinned; "
                        "promote refuses to land a fixture with an "
                        "unknown shooter. Pin yourself (or the shooter "
                        "whose run this is) via the Ingest page first."
                    ),
                )
            # PII-free shooter stamp: just the deterministic token.
            # SSI ID + competitor name stay in the private project file.
            token = lab_module.shooter_token(project.selected_shooter_id)
            shooter_payload: dict[str, Any] = {"id": token}
            # Defence in depth: ensure the slug carries the token even
            # when an older client builds a slug from project.name alone.
            if token not in slug:
                slug = f"{slug}-{token}"

            # Visual/source provenance (#220 follow-up). The audit JSON
            # the SPA writes only carries shot/beep data; the calibrator
            # also wants source_video, the trim window, and the camera
            # block. Derive them from the project so the published
            # fixture is calibration-ready instead of needing a manual
            # backfill later (which is what landed s36ed6e4e + the
            # tallmilan iPhone secondaries with empty provenance).
            primary = stg.primary()
            if primary is None:
                raise HTTPException(
                    status_code=409,
                    detail=f"stage {stage_n} has no primary video; cannot promote",
                )
            if primary.beep_time is None:
                raise HTTPException(
                    status_code=409,
                    detail=(
                        f"stage {stage_n} primary has no beep_time; "
                        "detect or set the beep before promoting"
                    ),
                )
            if not primary.camera_mount:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"stage {stage_n} primary has no camera_mount; "
                        "set it on the Ingest screen so the fixture lands "
                        "in the right per-camera-class bucket."
                    ),
                )
            stage_time_seconds = getattr(stg, "time_seconds", None)
            if stage_time_seconds is None:
                raise HTTPException(
                    status_code=409,
                    detail=(f"stage {stage_n} has no time_seconds; cannot " "compute the trim window."),
                )
            source_video_path = project.resolve_video_path(state.shooter_root(slug), primary.path)
            trim_start = max(0.0, float(primary.beep_time) - float(project.trim_pre_buffer_seconds))
            trim_end = (
                float(primary.beep_time) + float(stage_time_seconds) + float(project.trim_post_buffer_seconds)
            )
            # Camera make/model (#303): use the values cached on the
            # StageVideo at register time -- those came from ffprobe and
            # the user may have overridden them via the videos PATCH
            # endpoint. Both are ``None`` when ffprobe couldn't read the
            # QuickTime tag (Meta Vanguard glasses are the present
            # example -- no tag is exposed). The per-model amplitude
            # floor lookup (#304) handles the ``None`` case by falling
            # back to the generic-headcam floor.
            camera_payload: dict[str, Any] = {
                "id": "unknown",
                "make": primary.camera_make,
                "model": primary.camera_model,
                "mount": str(primary.camera_mount),
                "position": "shooter",
                "audio_source": "internal",
                "agc_state": "unknown",
                "sample_rate": None,
                "bit_depth": None,
                "audio_codec": None,
            }

            try:
                rec = lab_module.promote_stage_to_fixture(
                    lab_module.PromoteRequest(
                        audit_json_path=audit_json,
                        audit_wav_path=audit_wav,
                        fixture_slug=slug,
                        overwrite=overwrite,
                        extra_metadata={
                            "stage_number": stage_n,
                            "stage_name": getattr(stg, "name", None),
                        },
                        shooter=shooter_payload,
                        source_video=source_video_path,
                        fixture_window_in_source=(trim_start, trim_end),
                        camera=camera_payload,
                    )
                )
            except FileExistsError as exc:
                raise HTTPException(status_code=409, detail=str(exc)) from exc
            except FileNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            return JSONResponse(rec.model_dump(mode="json"))

        @app.post("/api/lab/labels")
        def lab_labels(payload: dict[str, Any] = Body(...)) -> JSONResponse:  # noqa: B008
            """Apply categorical labels to a fixture's audit JSON (issue #86).

            Body shape::

                {
                  "audit_path": "...stage-shots-foo-2026-stage4.json",
                  "labels": [
                    {"candidate_number": 7,  "time": 2.812, "reason": "cross_bay"},
                    {"candidate_number": 14, "time": 4.364, "reason": null},
                    {"candidate_number": 22, "time": 5.220, "subclass": "steel"}
                  ]
                }

            ``time`` is the storage key (1 ms resolution) and is required:
            ``candidate_number`` shifts across detector reshuffles, time
            does not. Patches in place with a ``.bak`` backup; returns counts
            changed plus a freshly relabeled ``run`` so the SPA can update
            without firing a full ``/api/lab/eval``. ``run`` is ``None`` when
            no cached run exists yet (the SPA falls back to a real eval in
            that case).
            """
            audit_path = payload.get("audit_path")
            labels_payload = payload.get("labels")
            if not isinstance(audit_path, str) or not audit_path:
                raise HTTPException(
                    status_code=400,
                    detail="payload must include 'audit_path' (string)",
                )
            if not isinstance(labels_payload, list):
                raise HTTPException(
                    status_code=400,
                    detail="payload must include 'labels' (list)",
                )
            try:
                target = Path(audit_path).expanduser().resolve(strict=True)
            except (FileNotFoundError, OSError) as exc:
                raise HTTPException(
                    status_code=404,
                    detail=f"fixture not found: {audit_path}",
                ) from exc
            if not target.is_file():
                raise HTTPException(status_code=400, detail=f"not a file: {target}")
            try:
                labels = [lab_module.CandidateLabel.model_validate(item) for item in labels_payload]
            except Exception as exc:
                raise HTTPException(status_code=400, detail=f"invalid labels: {exc}") from exc
            try:
                counts = lab_module.apply_labels(target, labels)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc

            # Relabel the cached run in place (no model calls). Sub-100 ms,
            # so the SPA can ditch its post-label runEval and use this.
            cached_run = _lab_universe_cache.get("last_run")
            run_payload: Any = None
            if cached_run is not None:
                relabeled = lab_module.relabel_run(cached_run)
                _lab_universe_cache["last_run"] = relabeled
                _lab_universe_cache["universe"] = relabeled.universe
                run_payload = relabeled.model_dump(mode="json")
            return JSONResponse(
                {"path": str(target), "counts": counts, "run": run_payload},
            )

        @app.post("/api/lab/save-config")
        def lab_save_config(payload: dict[str, Any] = Body(...)) -> JSONResponse:  # noqa: B008
            """Write a finished run's config + provenance to ``configs/<name>.yaml``.

            Body: ``{name, note?, overwrite?}``. The active universe (the
            most recent eval/rescore) provides the run; if no eval has run
            in this server session we 409 so the user can't accidentally
            save an empty config.
            """
            name = payload.get("name")
            note = payload.get("note")
            overwrite = bool(payload.get("overwrite", False))
            if not isinstance(name, str) or not name.strip():
                raise HTTPException(status_code=400, detail="payload must include non-empty 'name'")
            universe = _lab_universe_cache.get("universe")
            if universe is None:
                raise HTTPException(
                    status_code=409,
                    detail="no cached eval universe; run /api/lab/eval first",
                )
            last_run = _lab_universe_cache.get("last_run")
            if last_run is None:
                raise HTTPException(
                    status_code=409,
                    detail="no cached run; rescore or run eval first",
                )
            try:
                target = lab_module.save_config_yaml(
                    run=last_run,
                    name=name,
                    note=note if isinstance(note, str) else None,
                    overwrite=overwrite,
                )
            except FileExistsError as exc:
                raise HTTPException(status_code=409, detail=str(exc)) from exc
            return JSONResponse({"path": str(target)})

        @app.post("/api/lab/rebuild-calibration")
        def lab_rebuild_calibration(
            payload: dict[str, Any] = Body(default_factory=dict),  # noqa: B008
        ) -> JSONResponse:
            """Submit a job that re-runs ``scripts/build_ensemble_artifacts.py``.

            Long-running (model-bound), so it goes through the JobRegistry
            and the SPA polls /api/jobs/{id} like any other job. After it
            completes the next /api/lab/eval call will pick up the new
            thresholds because the cached EnsembleRuntime is invalidated.
            """
            target_recall = float(payload.get("target_recall", 0.95))
            tolerance_ms = float(payload.get("tolerance_ms", 75.0))
            fixtures = payload.get("fixtures")
            if fixtures is not None and not isinstance(fixtures, list):
                raise HTTPException(
                    status_code=400,
                    detail="'fixtures' must be a list of slugs or omitted",
                )

            def _run(handle: JobHandle) -> None:
                # Import here to avoid pulling sklearn at server startup.
                scripts_dir = Path(__file__).resolve().parents[3] / "scripts"
                sys.path.insert(0, str(scripts_dir))
                try:
                    import build_ensemble_artifacts as build_mod  # type: ignore[import-not-found]
                finally:
                    sys.path.pop(0)

                def log(msg: str) -> None:
                    handle.check_cancel()
                    handle.update(message=msg)

                build_mod.build_artifacts(
                    fixtures=fixtures if fixtures else None,
                    target_recall=target_recall,
                    tolerance_ms=tolerance_ms,
                    log=log,
                )
                # Drop the cached runtime so the next eval reloads the new
                # calibration JSON + GBDT model.
                _lab_runtime_cache.pop("runtime", None)
                handle.update(progress=1.0, message="calibration rebuilt")

            job = state.jobs.submit(kind="rebuild_calibration", fn=_run)
            return JSONResponse(job.model_dump(mode="json"))

        # ------------------------------------------------------------------
        # Promote-from-anchor (issue #125)
        # ------------------------------------------------------------------

        class PromoteFromAnchorBody(BaseModel):
            anchor_path: str
            secondary_wav_path: str
            slug: str
            camera_id: str
            mount: str
            position: str
            audio_source: str = "internal"
            agc_state: str = "unknown"
            snap_window_ms: float = 60.0
            min_spacing_ms: float = 80.0
            overwrite: bool = False

        @app.post("/api/lab/promote-from-anchor")
        def lab_promote_from_anchor(body: PromoteFromAnchorBody) -> JSONResponse:
            """Submit a promote-from-anchor job (issue #125).

            Runs cross-align + ensemble detection + snap on the secondary
            audio, writes the pre-filled fixture JSON / WAV / promotion
            report to the fixtures directory, and returns the job ID.
            """
            anchor_path = Path(body.anchor_path).resolve()
            secondary_wav_path = Path(body.secondary_wav_path).resolve()

            if not anchor_path.exists():
                raise HTTPException(status_code=404, detail=f"anchor not found: {anchor_path}")
            if not secondary_wav_path.exists():
                raise HTTPException(
                    status_code=404,
                    detail=f"secondary WAV not found: {secondary_wav_path}",
                )

            anchor_wav_path = anchor_path.with_suffix(".wav")
            if not anchor_wav_path.exists():
                raise HTTPException(
                    status_code=404,
                    detail=f"anchor WAV not found: {anchor_wav_path}",
                )

            fixtures_root = lab_module.core.DEFAULT_FIXTURES_ROOT
            target_json = fixtures_root / f"{body.slug}.json"
            if target_json.exists() and not body.overwrite:
                raise HTTPException(
                    status_code=409,
                    detail=f"fixture already exists: {target_json} (set overwrite=true to replace)",
                )

            try:
                camera = Camera(
                    id=body.camera_id,
                    mount=CameraMount(body.mount),
                    position=CameraPosition(body.position),
                    audio_source=AudioSource(body.audio_source),
                    agc_state=AgcState(body.agc_state),
                )
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc

            def _run(handle: JobHandle) -> None:
                import shutil as _shutil

                handle.update(progress=0.05, message="loading audio...")
                primary_audio, primary_sr = beep_detect.load_audio(anchor_wav_path)
                secondary_audio, secondary_sr = beep_detect.load_audio(secondary_wav_path)

                handle.update(progress=0.10, message="loading ensemble models...")
                runtime = _get_ensemble_runtime()

                handle.check_cancel()
                handle.update(progress=0.20, message="aligning + detecting shots...")

                anchor_data = __import__("json").loads(anchor_path.read_text(encoding="utf-8"))
                result = lab_module.promote_from_anchor(
                    lab_module.PromoteFromAnchorRequest(
                        anchor_data=anchor_data,
                        primary_audio=primary_audio,
                        primary_sr=primary_sr,
                        secondary_audio=secondary_audio,
                        secondary_sr=secondary_sr,
                        secondary_source_desc=str(secondary_wav_path),
                        camera=camera,
                        slug=body.slug,
                        snap_window_ms=body.snap_window_ms,
                        min_spacing_ms=body.min_spacing_ms,
                    ),
                    runtime=runtime,
                )
                for w in result.warnings:
                    handle.update(message=f"WARNING: {w}")

                handle.check_cancel()
                handle.update(progress=0.85, message="writing fixture...")

                fixtures_root.mkdir(parents=True, exist_ok=True)
                tmp = target_json.with_suffix(".json.tmp")
                tmp.write_text(
                    __import__("json").dumps(result.fixture_data, indent=2, ensure_ascii=True) + "\n",
                    encoding="utf-8",
                )
                tmp.replace(target_json)

                target_wav = fixtures_root / f"{body.slug}.wav"
                _shutil.copy2(secondary_wav_path, target_wav)

                report_path = fixtures_root / f"{body.slug}-promotion-report.json"
                report_path.write_text(
                    __import__("json").dumps(result.promotion_report, indent=2, ensure_ascii=True) + "\n",
                    encoding="utf-8",
                )

                handle.update(
                    progress=1.0,
                    message=(
                        f"done -- {result.promotion_report['counts']['snapped']}/"
                        f"{result.promotion_report['counts']['anchor_shots']} snapped"
                    ),
                )

            job = state.jobs.submit(kind="promote_from_anchor", fn=_run)
            # Return the resolved fixture + anchor paths alongside the job so the
            # SPA can navigate to the review page once the job succeeds without
            # needing a separate result-fetch endpoint.
            return JSONResponse(
                {
                    "job": job.model_dump(mode="json"),
                    "fixture_path": str(target_json),
                    "anchor_path": str(anchor_path),
                    "slug": body.slug,
                }
            )

        @app.get("/api/lab/promote-report")
        def lab_promote_report(slug: str) -> JSONResponse:
            """Return the promotion report for a completed promote-from-anchor run."""
            fixtures_root = lab_module.core.DEFAULT_FIXTURES_ROOT
            report_path = fixtures_root / f"{slug}-promotion-report.json"
            if not report_path.exists():
                raise HTTPException(
                    status_code=404,
                    detail=f"promotion report not found for slug '{slug}'",
                )
            try:
                data = __import__("json").loads(report_path.read_text(encoding="utf-8"))
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"failed to read report: {exc}") from exc
            return JSONResponse(data)

        @app.delete("/api/lab/fixture")
        def lab_delete_fixture(slug: str) -> JSONResponse:
            """Delete a derived fixture (JSON + WAV + sibling artifacts).

            Refuses to delete primary fixtures (those without an
            ``anchor`` block) so a user can't accidentally nuke a
            ground-truth headcam fixture by clicking the wrong button.
            Use the file system directly if you really want to remove
            a primary -- forcing that explicitness is intentional.
            """
            fixtures_root = lab_module.core.DEFAULT_FIXTURES_ROOT
            json_path = fixtures_root / f"{slug}.json"
            if not json_path.exists():
                raise HTTPException(status_code=404, detail=f"no fixture: {slug}")
            try:
                payload = __import__("json").loads(json_path.read_text(encoding="utf-8"))
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"failed to read fixture: {exc}") from exc
            anchor_block = payload.get("anchor")
            if not isinstance(anchor_block, dict) or not anchor_block.get("fixture_slug"):
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"refusing to delete '{slug}': not a derived fixture "
                        "(no anchor block). Remove primary fixtures from disk directly."
                    ),
                )
            # Sibling artifacts to clean up alongside the fixture JSON.
            removed: list[str] = []
            for sibling in [
                json_path,
                json_path.with_suffix(".wav"),
                fixtures_root / f"{slug}-promotion-report.json",
                json_path.with_suffix(".json.bak"),
            ]:
                if sibling.exists():
                    try:
                        sibling.unlink()
                        removed.append(sibling.name)
                    except OSError as exc:
                        raise HTTPException(
                            status_code=500, detail=f"failed to remove {sibling.name}: {exc}"
                        ) from exc
            # Also remove peaks-* JSON cache files for this fixture.
            for cache in fixtures_root.glob(f"{slug}.peaks-*.json"):
                try:
                    cache.unlink()
                    removed.append(cache.name)
                except OSError:
                    pass
            return JSONResponse({"removed": removed})

        # ------------------------------------------------------------------
        # Project-aware secondary promotion (issue #125 follow-up)
        # ------------------------------------------------------------------

        @app.post("/api/shooters/{slug}/stages/{stage_number}/videos/{video_id}/promote-secondary")
        def promote_secondary(
            slug: str,
            stage_number: int,
            video_id: str,
            body: PromoteSecondaryBody = Body(...),  # noqa: B008
        ) -> JSONResponse:
            """Promote a project-mapped secondary video to a derived fixture.

            Resolves the anchor (primary) fixture path, the cached secondary
            WAV, and probes the source video for camera metadata so the
            caller only has to supply ``mount`` + ``position``. Anchor
            fixture must already exist (run the primary promote first).
            """
            project, stage, video = _resolve_stage_video(slug, stage_number, video_id)
            if video.role != "secondary":
                raise HTTPException(
                    status_code=400,
                    detail=f"video {video_id!r} is not a secondary on stage {stage_number}",
                )
            if video.beep_time is None:
                raise HTTPException(
                    status_code=409,
                    detail="secondary has no beep_time; detect or align beep first",
                )

            # Anchor lookup needs the shooter token suffix because the
            # primary fixture was promoted with it. Without a pinned
            # shooter we can't construct the slug -- bail with the same
            # message used by lab_promote.
            if project.selected_shooter_id is None:
                raise HTTPException(
                    status_code=400,
                    detail=("this project has no SSI shooter pinned; " "cannot resolve anchor fixture slug."),
                )
            anchor_token = lab_module.shooter_token(project.selected_shooter_id)
            primary_slug = (
                f"stage-shots-{export_helpers._slugify(project.name)}-stage{stage_number}" f"-{anchor_token}"
            )
            fixtures_root = lab_module.core.DEFAULT_FIXTURES_ROOT
            anchor_path = fixtures_root / f"{primary_slug}.json"
            if not anchor_path.exists():
                raise HTTPException(
                    status_code=409,
                    detail=(
                        f"anchor fixture not found: {anchor_path.name}. "
                        "Promote the primary stage to a fixture first."
                    ),
                )
            anchor_wav_path = anchor_path.with_suffix(".wav")
            if not anchor_wav_path.exists():
                raise HTTPException(
                    status_code=409,
                    detail=f"anchor WAV missing: {anchor_wav_path.name}",
                )

            source = project.resolve_video_path(state.shooter_root(slug), video.path)
            _ensure_source_reachable(stage_number, source)

            try:
                secondary_wav_path = audio_helpers.ensure_video_audio(
                    state.shooter_root(slug),
                    stage_number,
                    video,
                    source,
                    project=project,
                    ffmpeg_binary=process_runtime().ffmpeg_binary,
                )
            except (FileNotFoundError, audio_helpers.AudioExtractionError) as exc:
                raise HTTPException(status_code=500, detail=str(exc)) from exc

            probe = probe_camera_metadata(source)
            camera_id = (body.camera_id or probe.suggested_id or f"cam-{video.video_id[:8]}").strip()
            if not camera_id:
                raise HTTPException(
                    status_code=400,
                    detail="camera_id could not be derived; please supply one",
                )

            # ``slug`` (URL path param) names the shooter; ``fixture_slug``
            # below names the derived fixture being written. Same string
            # convention but different identities -- don't rebind ``slug``.
            fixture_slug = (body.slug or f"{primary_slug}-{camera_id}").strip()
            target_json = fixtures_root / f"{fixture_slug}.json"
            if target_json.exists() and not body.overwrite:
                raise HTTPException(
                    status_code=409,
                    detail=(f"fixture already exists: {target_json.name}" " (set overwrite=true to replace)"),
                )

            try:
                camera = Camera(
                    id=camera_id,
                    mount=CameraMount(body.mount),
                    position=CameraPosition(body.position),
                    audio_source=AudioSource(body.audio_source),
                    agc_state=AgcState(body.agc_state),
                )
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc

            # Strip home-dir prefix so the published fixture carries no
            # OS-username PII; ``scrub_local_path`` drops the
            # ``/Users/<name>/matches/<match>/`` head and keeps the
            # meaningful tail (``raw/<file>``).
            secondary_source_desc = lab_module.scrub_local_path(str(source)) or source.name
            # Use the audited in-stream beep time from the project so the
            # promote engine can skip cross-correlation entirely. The
            # ingest screen owns this value (auto + manual + review); we
            # treat it as ground truth on the project flow.
            known_secondary_beep = float(video.beep_time)

            def _run(handle: JobHandle) -> None:
                handle.update(progress=0.05, message="loading audio...")
                primary_audio, primary_sr = beep_detect.load_audio(anchor_wav_path)
                secondary_audio, secondary_sr = beep_detect.load_audio(secondary_wav_path)

                handle.update(progress=0.10, message="loading ensemble models...")
                runtime = _get_ensemble_runtime()

                handle.check_cancel()
                handle.update(progress=0.20, message="detecting shots...")

                anchor_data = __import__("json").loads(anchor_path.read_text(encoding="utf-8"))
                result = lab_module.promote_from_anchor(
                    lab_module.PromoteFromAnchorRequest(
                        anchor_data=anchor_data,
                        primary_audio=primary_audio,
                        primary_sr=primary_sr,
                        secondary_audio=secondary_audio,
                        secondary_sr=secondary_sr,
                        secondary_source_desc=secondary_source_desc,
                        camera=camera,
                        slug=fixture_slug,
                        snap_window_ms=body.snap_window_ms,
                        min_spacing_ms=body.min_spacing_ms,
                        secondary_beep_time=known_secondary_beep,
                    ),
                    runtime=runtime,
                )
                for w in result.warnings:
                    handle.update(message=f"WARNING: {w}")

                handle.check_cancel()
                handle.update(progress=0.85, message="writing fixture...")

                # Trim secondary WAV to a clip-local window around the beep,
                # mirroring the convention used by primary fixtures (the
                # /api/fixture/peaks endpoint marks fixture audio as
                # ``trimmed=true``). Without this the audit screen renders
                # the entire raw recording with shots clustered far down
                # the timeline.
                fixture_data = dict(result.fixture_data)
                secondary_beep = float(fixture_data.get("beep_time") or 0.0)
                shot_times = [
                    float(s["time"]) for s in fixture_data.get("shots", []) if s.get("time") is not None
                ]
                trim_buffer = 5.0
                trim_tail = 5.0
                clip_start = max(0.0, secondary_beep - trim_buffer)
                clip_end_floor = secondary_beep + trim_buffer
                clip_end = max(shot_times) + trim_tail if shot_times else clip_end_floor
                clip_end = max(clip_end, clip_end_floor)

                fixtures_root.mkdir(parents=True, exist_ok=True)
                target_wav = fixtures_root / f"{fixture_slug}.wav"
                handle.update(progress=0.88, message="trimming clip audio...")
                _trim_wav_to_clip(secondary_wav_path, target_wav, clip_start, clip_end)

                # Rebase time-axis fields to clip-local coordinates.
                fixture_data["beep_time"] = round(secondary_beep - clip_start, 4)
                fixture_data["fixture_window_in_source"] = [
                    round(clip_start, 4),
                    round(clip_end, 4),
                ]
                rebased_shots = []
                for s in fixture_data.get("shots", []):
                    s = dict(s)
                    if s.get("time") is not None:
                        s["time"] = round(float(s["time"]) - clip_start, 4)
                    rebased_shots.append(s)
                fixture_data["shots"] = rebased_shots
                cands = (fixture_data.get("_candidates_pending_audit") or {}).get("candidates")
                if cands:
                    rebased_cands = []
                    for c in cands:
                        c = dict(c)
                        if c.get("time") is not None:
                            c["time"] = round(float(c["time"]) - clip_start, 4)
                        rebased_cands.append(c)
                    fixture_data["_candidates_pending_audit"] = {
                        **fixture_data["_candidates_pending_audit"],
                        "candidates": rebased_cands,
                    }

                tmp = target_json.with_suffix(".json.tmp")
                tmp.write_text(
                    __import__("json").dumps(fixture_data, indent=2, ensure_ascii=True) + "\n",
                    encoding="utf-8",
                )
                tmp.replace(target_json)

                report_path = fixtures_root / f"{fixture_slug}-promotion-report.json"
                report_path.write_text(
                    __import__("json").dumps(result.promotion_report, indent=2, ensure_ascii=True) + "\n",
                    encoding="utf-8",
                )

                handle.update(
                    progress=1.0,
                    message=(
                        f"done -- {result.promotion_report['counts']['snapped']}/"
                        f"{result.promotion_report['counts']['anchor_shots']} snapped"
                    ),
                )

            job = state.jobs.submit(kind="promote_from_anchor", fn=_run)
            return JSONResponse(
                {
                    "job": job.model_dump(mode="json"),
                    "fixture_path": str(target_json),
                    "anchor_path": str(anchor_path),
                    "slug": fixture_slug,
                    "camera_id": camera_id,
                    "anchor_slug": primary_slug,
                }
            )

        # ------------------------------------------------------------------
        # Promote a project video against an arbitrary fixture anchor
        # (issue #149 follow-up). Used when the headcam ground truth
        # already lives as a fixture in ``tests/fixtures/`` and the user
        # has a phone-cam project they want to anchor against it -- no
        # in-project primary required, any video on the stage works.
        # ------------------------------------------------------------------

        @app.post("/api/lab/projects/{slug}/{stage_number}/videos/{video_id}/promote-against-fixture")
        def lab_promote_against_fixture(
            slug: str,
            stage_number: int,
            video_id: str,
            body: PromoteAgainstFixtureBody = Body(...),  # noqa: B008
        ) -> JSONResponse:
            """Anchor a project video against an existing fixture.

            Skips the role=='secondary' gate that the in-project
            ``promote-secondary`` endpoint enforces -- the typical use
            case here is a phone-cam project where the iPhone is the
            primary and there's no in-project anchor video. Anchor
            comes from ``body.anchor_slug`` (any fixture in
            ``tests/fixtures/``).
            """
            project, _stage, video = _resolve_stage_video(slug, stage_number, video_id)
            if video.beep_time is None:
                raise HTTPException(
                    status_code=409,
                    detail="video has no beep_time; detect or align beep first",
                )

            fixtures_root = lab_module.core.DEFAULT_FIXTURES_ROOT
            anchor_slug = body.anchor_slug.strip()
            if not anchor_slug:
                raise HTTPException(status_code=400, detail="anchor_slug is required")
            anchor_path = fixtures_root / f"{anchor_slug}.json"
            if not anchor_path.exists():
                raise HTTPException(
                    status_code=404,
                    detail=f"anchor fixture not found: {anchor_path.name}",
                )
            anchor_wav_path = anchor_path.with_suffix(".wav")
            if not anchor_wav_path.exists():
                raise HTTPException(
                    status_code=409,
                    detail=f"anchor WAV missing: {anchor_wav_path.name}",
                )

            source = project.resolve_video_path(state.shooter_root(slug), video.path)
            _ensure_source_reachable(stage_number, source)

            try:
                secondary_wav_path = audio_helpers.ensure_video_audio(
                    state.shooter_root(slug),
                    stage_number,
                    video,
                    source,
                    project=project,
                    ffmpeg_binary=process_runtime().ffmpeg_binary,
                )
            except (FileNotFoundError, audio_helpers.AudioExtractionError) as exc:
                raise HTTPException(status_code=500, detail=str(exc)) from exc

            probe = probe_camera_metadata(source)
            camera_id = (body.camera_id or probe.suggested_id or f"cam-{video.video_id[:8]}").strip()
            if not camera_id:
                raise HTTPException(
                    status_code=400,
                    detail="camera_id could not be derived; please supply one",
                )

            slug = (body.slug or f"{anchor_slug}-{camera_id}").strip()
            target_json = fixtures_root / f"{slug}.json"
            if target_json.exists() and not body.overwrite:
                raise HTTPException(
                    status_code=409,
                    detail=(f"fixture already exists: {target_json.name}" " (set overwrite=true to replace)"),
                )

            try:
                camera = Camera(
                    id=camera_id,
                    mount=CameraMount(body.mount),
                    position=CameraPosition(body.position),
                    audio_source=AudioSource(body.audio_source),
                    agc_state=AgcState(body.agc_state),
                )
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc

            # Strip home-dir prefix so the published fixture carries no
            # OS-username PII; ``scrub_local_path`` drops the
            # ``/Users/<name>/matches/<match>/`` head and keeps the
            # meaningful tail (``raw/<file>``).
            secondary_source_desc = lab_module.scrub_local_path(str(source)) or source.name
            known_secondary_beep = float(video.beep_time)

            def _run(handle: JobHandle) -> None:
                handle.update(progress=0.05, message="loading audio...")
                primary_audio, primary_sr = beep_detect.load_audio(anchor_wav_path)
                secondary_audio, secondary_sr = beep_detect.load_audio(secondary_wav_path)

                handle.update(progress=0.10, message="loading ensemble models...")
                runtime = _get_ensemble_runtime()

                handle.check_cancel()
                handle.update(progress=0.20, message="detecting shots...")

                anchor_data = json.loads(anchor_path.read_text(encoding="utf-8"))
                result = lab_module.promote_from_anchor(
                    lab_module.PromoteFromAnchorRequest(
                        anchor_data=anchor_data,
                        primary_audio=primary_audio,
                        primary_sr=primary_sr,
                        secondary_audio=secondary_audio,
                        secondary_sr=secondary_sr,
                        secondary_source_desc=secondary_source_desc,
                        camera=camera,
                        slug=slug,
                        snap_window_ms=body.snap_window_ms,
                        min_spacing_ms=body.min_spacing_ms,
                        secondary_beep_time=known_secondary_beep,
                    ),
                    runtime=runtime,
                )
                for w in result.warnings:
                    handle.update(message=f"WARNING: {w}")

                handle.check_cancel()
                handle.update(progress=0.85, message="writing fixture...")

                fixture_data = dict(result.fixture_data)
                secondary_beep = float(fixture_data.get("beep_time") or 0.0)
                shot_times = [
                    float(s["time"]) for s in fixture_data.get("shots", []) if s.get("time") is not None
                ]
                trim_buffer = 5.0
                trim_tail = 5.0
                clip_start = max(0.0, secondary_beep - trim_buffer)
                clip_end_floor = secondary_beep + trim_buffer
                clip_end = max(shot_times) + trim_tail if shot_times else clip_end_floor
                clip_end = max(clip_end, clip_end_floor)

                fixtures_root.mkdir(parents=True, exist_ok=True)
                target_wav = fixtures_root / f"{slug}.wav"
                handle.update(progress=0.88, message="trimming clip audio...")
                _trim_wav_to_clip(secondary_wav_path, target_wav, clip_start, clip_end)

                fixture_data["beep_time"] = round(secondary_beep - clip_start, 4)
                fixture_data["fixture_window_in_source"] = [
                    round(clip_start, 4),
                    round(clip_end, 4),
                ]
                rebased_shots = []
                for s in fixture_data.get("shots", []):
                    s = dict(s)
                    if s.get("time") is not None:
                        s["time"] = round(float(s["time"]) - clip_start, 4)
                    rebased_shots.append(s)
                fixture_data["shots"] = rebased_shots
                cands = (fixture_data.get("_candidates_pending_audit") or {}).get("candidates")
                if cands:
                    rebased_cands = []
                    for c in cands:
                        c = dict(c)
                        if c.get("time") is not None:
                            c["time"] = round(float(c["time"]) - clip_start, 4)
                        rebased_cands.append(c)
                    fixture_data["_candidates_pending_audit"] = {
                        **fixture_data["_candidates_pending_audit"],
                        "candidates": rebased_cands,
                    }

                tmp = target_json.with_suffix(".json.tmp")
                tmp.write_text(
                    json.dumps(fixture_data, indent=2, ensure_ascii=True) + "\n",
                    encoding="utf-8",
                )
                tmp.replace(target_json)

                report_path = fixtures_root / f"{slug}-promotion-report.json"
                report_path.write_text(
                    json.dumps(result.promotion_report, indent=2, ensure_ascii=True) + "\n",
                    encoding="utf-8",
                )

                handle.update(
                    progress=1.0,
                    message=(
                        f"done -- {result.promotion_report['counts']['snapped']}/"
                        f"{result.promotion_report['counts']['anchor_shots']} snapped"
                    ),
                )

            job = state.jobs.submit(kind="promote_from_anchor", fn=_run)
            return JSONResponse(
                {
                    "job": job.model_dump(mode="json"),
                    "fixture_path": str(target_json),
                    "anchor_path": str(anchor_path),
                    "slug": slug,
                    "camera_id": camera_id,
                    "anchor_slug": anchor_slug,
                }
            )

        # ------------------------------------------------------------------
        # Lab: ensemble parameter sweeps (read-only dashboard)
        # ------------------------------------------------------------------
        #
        # Backed by ``build/sweeps/runs.parquet`` + ``build/sweeps/<run_id>/``
        # written by ``scripts/run_sweep.py`` + ``scripts/plot_sweep.py``.
        # No launch endpoint yet -- sweeps stay on the CLI for now.

        from .. import lab as _lab_module_for_sweeps  # noqa: F401  (silences mypy)
        from ..lab import sweeps as _sweeps_module

        @app.get("/api/lab/sweeps")
        def lab_sweeps_list() -> JSONResponse:
            """List one row per ``run_id`` with best-F1 highlights."""
            return JSONResponse([s.model_dump(mode="json") for s in _sweeps_module.list_runs()])

        @app.get("/api/lab/sweeps/{run_id}")
        def lab_sweeps_detail(run_id: str) -> JSONResponse:
            """Return the full payload for one run: every combo + per-fixture rows."""
            detail = _sweeps_module.get_run(run_id)
            if detail is None:
                raise HTTPException(status_code=404, detail=f"no sweep run {run_id!r}")
            return JSONResponse(detail.model_dump(mode="json"))

        @app.get("/api/lab/sweeps/{run_id}/plot/{plot_name}.png")
        def lab_sweeps_plot(run_id: str, plot_name: str) -> FileResponse:
            """Serve one PNG from ``build/sweeps/<run_id>/``.

            The plot_name is restricted to alnum + underscore by the
            ``sweeps`` helper so a malicious caller can't traverse
            outside the run dir. Returns 404 when the plot doesn't
            exist (e.g. a 2D plot requested for a 1D sweep).
            """
            path = _sweeps_module.plot_path(run_id, plot_name)
            if path is None:
                raise HTTPException(status_code=404, detail="plot not found")
            return FileResponse(path, media_type="image/png", filename=path.name)

    if lab_enabled:
        _setup_lab()

    # ----------------------------------------------------------------------
    # Developer mode -- read-only metadata for the dev-shell model chip and
    # the review-queue rollup. Always available; lighter than the heavy
    # /api/lab/* runtime endpoints so the dev SPA shell can mount without
    # forcing ``--lab`` on the launcher.
    # ----------------------------------------------------------------------
    from .. import lab as _lab_for_dev  # local import to avoid module top
    from ..ensemble import load_calibration as _load_dev_calibration

    def _venue_from_slug(slug: str) -> str | None:
        # Slugs look like ``stage-shots-<venue>-2026-stage<n>-s<hash>...``.
        # The venue is the chunk between ``stage-shots-`` and the year.
        parts = slug.split("-")
        if len(parts) >= 4 and parts[0] == "stage" and parts[1] == "shots":
            venue_bits: list[str] = []
            for tok in parts[2:]:
                if tok.isdigit() and len(tok) == 4:
                    break
                venue_bits.append(tok)
            return "-".join(venue_bits) if venue_bits else None
        return None

    def _stage_from_slug(slug: str) -> int | None:
        for tok in slug.split("-"):
            if tok.startswith("stage") and tok[5:].isdigit():
                return int(tok[5:])
        return None

    def _shooter_from_slug(slug: str) -> str | None:
        # Shooter is encoded as ``s<8-hex-chars>`` (the slug hash).
        for tok in slug.split("-"):
            if len(tok) == 9 and tok.startswith("s") and all(c in "0123456789abcdef" for c in tok[1:]):
                return tok
        return None

    @app.get("/api/dev/model", response_model=DeveloperModelInfo)
    def dev_model_info() -> DeveloperModelInfo:
        """Return active ensemble metadata + workflow step counters.

        Drives the dev shell's model chip and the workflow stepper
        badges. ``recall`` is the GBDT target-recall picked at
        calibration time; precision/f1 are not stored on the artifact
        so they come back as ``None`` until a /dev/validate run writes
        them. The version string is derived from ``built_at`` so users
        can match it back to a calibration build.
        """
        cal = _load_dev_calibration()
        fixtures = _lab_for_dev.list_fixtures()
        # Version = vYYYY.MM.DD from built_at. Stable enough for the
        # chip; the calibration JSON also carries the full ISO.
        try:
            built_dt = datetime.fromisoformat(cal.built_at.replace("Z", "+00:00"))
            version = built_dt.strftime("v%Y.%m.%d")
        except (ValueError, AttributeError):
            version = "v0.0.0"
        # "review" bucket counts fixtures that came in via promote-from-
        # anchor (anchor_slug set) -- those need human confirmation
        # before they're allowed into the calibration set.
        review_count = sum(1 for f in fixtures if f.anchor_slug is not None)
        return DeveloperModelInfo(
            active_version=version,
            recall=cal.voter_c_target_recall,
            precision=None,
            f1=None,
            fixture_count=len(cal.calibration_fixtures),
            built_at=cal.built_at,
            step_counts=DeveloperStepCounts(
                corpus=len(fixtures),
                review=review_count,
                validate_runs=0,
                retrain=0,
            ),
        )

    @app.get("/api/dev/review-queue", response_model=DevReviewQueueResponse)
    def dev_review_queue() -> DevReviewQueueResponse:
        """Bucket fixtures into pending / flagged / done for the review queue.

        v1 heuristic: anchor_slug present = pending (came in via
        promote-from-anchor and needs human confirmation); explicit
        ``review_flagged`` field on the fixture JSON = flagged; all
        else = done. The flagged bucket is rarely populated today but
        the shape is here so the UI doesn't need a follow-up wire.
        """
        fixtures = _lab_for_dev.list_fixtures()
        now = datetime.now(UTC).timestamp()
        pending: list[DevReviewQueueItem] = []
        flagged: list[DevReviewQueueItem] = []
        done: list[DevReviewQueueItem] = []
        for fx in fixtures:
            age = int(now - fx.audit_mtime) if fx.audit_mtime else None
            item = DevReviewQueueItem(
                slug=fx.slug,
                audit_path=fx.audit_path,
                source="match" if fx.anchor_slug else "ad-hoc",
                source_label="Promoted from match" if fx.anchor_slug else "Audited",
                status="pending" if fx.anchor_slug else "done",
                n_shots=fx.n_shots,
                n_disagreements=0,
                promoted_at=None,
                venue=_venue_from_slug(fx.slug),
                stage_number=_stage_from_slug(fx.slug),
                shooter=_shooter_from_slug(fx.slug),
                age_seconds=age,
            )
            if item.status == "pending":
                pending.append(item)
            else:
                done.append(item)
        # Sort pending by age (newest first); done alphabetically so the
        # corpus is browsable.
        pending.sort(key=lambda x: x.age_seconds or 0)
        done.sort(key=lambda x: x.slug)
        return DevReviewQueueResponse(pending=pending, flagged=flagged, done=done)

    # ----------------------------------------------------------------------
    # Static asset serving (SPA)
    # ----------------------------------------------------------------------
    #
    # In dev, the user runs ``npm run dev`` in ``ui_static/`` and Vite serves
    # the SPA on its own port, proxying ``/api/*`` to this backend. In that
    # mode ``STATIC_DIR`` may not exist; the API routes still work and the
    # browser hits the Vite dev server directly.
    #
    # In prod, ``ui_static/dist`` is built and we serve it here.

    if STATIC_DIR.exists():
        # Mount built assets at /assets (matches Vite's default output).
        assets_dir = STATIC_DIR / "assets"
        if assets_dir.exists():
            app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

        # SPA fallback: any non-API route returns index.html so the React
        # router can handle it client-side.
        #
        # index.html must NOT be browser-cached: a fresh build emits a new
        # content-hashed bundle filename (e.g. index-DBM1MaSD.js), and only
        # the freshly-served index.html knows about it. A cached index.html
        # points at the old bundle, so a plain refresh after a rebuild
        # would keep serving stale React code until the user hard-reloads.
        # The /assets/* mount stays freely cacheable because those URLs
        # are content-addressed -- a new build emits new filenames.
        @app.get("/{full_path:path}", include_in_schema=False)
        def spa_fallback(full_path: str) -> FileResponse:
            if full_path.startswith("api/"):
                raise HTTPException(status_code=404, detail="api route not found")
            index = STATIC_DIR / "index.html"
            if not index.exists():
                raise HTTPException(
                    status_code=503,
                    detail=(
                        "SPA bundle not built. Run `npm run build` in "
                        "src/splitsmith/ui_static/ or use `npm run dev`."
                    ),
                )
            return FileResponse(index, headers={"Cache-Control": "no-cache"})

    return app


def _default_start(last_scanned_dir: str | None) -> Path:
    """Pick a default starting directory for the folder picker.

    Preference: last-scanned-dir (if it still exists) → ~/Movies → ~/Videos → ~.
    """
    if last_scanned_dir:
        p = Path(last_scanned_dir).expanduser()
        if p.is_dir():
            return p
    home = Path.home()
    for candidate in (home / "Movies", home / "Videos"):
        if candidate.is_dir():
            return candidate
    return home


def _suggested_starts(last_scanned_dir: str | None) -> list[dict[str, str]]:
    """Bookmarks the folder picker shows in a sidebar.

    Three groups, in display order:

    1. **Recent** -- the last folder the user scanned (if any). Surfaced
       on top so the cam-over-USB flow ("plug in, scan, repeat") doesn't
       require re-typing the path.
    2. **Home** -- the user's home plus the conventional video folders
       (~/Movies, ~/Videos, ~/Downloads, ~/Desktop). Cross-platform
       sensible defaults.
    3. **Removable & network** -- platform-specific mount discovery,
       best-effort. Each entry is wrapped in a per-path 200ms timeout
       so a stale network mount can't hang the picker open.
    """
    seen: set[str] = set()
    out: list[dict[str, str]] = []

    def add(path: Path | str, label: str, kind: str) -> None:
        p = str(Path(path))
        if p in seen:
            return
        seen.add(p)
        out.append({"path": p, "label": label, "kind": kind})

    if last_scanned_dir:
        p = Path(last_scanned_dir).expanduser()
        if _is_dir_with_timeout(p):
            add(p, p.name or str(p), "recent")

    home = Path.home()
    home_candidates = [
        (home, "Home"),
        (home / "Movies", "Movies"),
        (home / "Videos", "Videos"),
        (home / "Downloads", "Downloads"),
        (home / "Desktop", "Desktop"),
    ]
    for path, label in home_candidates:
        if _is_dir_with_timeout(path):
            add(path, label, "home")

    for path, label, kind in _discover_mounts():
        add(path, label, kind)

    return out


def _is_dir_with_timeout(path: Path, *, timeout: float = 0.2) -> bool:
    """``path.is_dir()`` with a wall-clock cap.

    Stale network mounts can hang ``stat()`` indefinitely. Running the
    check on a worker thread and bailing on timeout keeps the picker
    responsive at the cost of a false negative on slow-but-alive shares
    (the user can still type the path manually).
    """
    import concurrent.futures

    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
            future = ex.submit(path.is_dir)
            return future.result(timeout=timeout)
    except (concurrent.futures.TimeoutError, OSError):
        return False


def _discover_mounts() -> list[tuple[Path, str, str]]:
    """Cross-platform best-effort discovery of mounted volumes.

    Returns a list of ``(path, label, kind)`` tuples. Kind is
    ``"network"`` for paths reported by the platform's mount table as a
    network filesystem (cifs/nfs/smbfs/afpfs/fuse.sshfs); everything
    else under a removable-mount root is ``"removable"``.

    No external dependency: psutil would give cleaner fstype info but
    pulling it in for this one feature isn't worth the deploy weight.
    Stdlib reads of ``/proc/mounts`` (Linux) and the ``/Volumes``
    directory (macOS) cover the cases users actually hit.
    """
    out: list[tuple[Path, str, str]] = []
    if sys.platform == "darwin":
        out.extend(_discover_macos_volumes())
    elif sys.platform.startswith("linux"):
        out.extend(_discover_linux_mounts())
    elif sys.platform.startswith("win"):
        out.extend(_discover_windows_drives())
    return out


def _discover_macos_volumes() -> list[tuple[Path, str, str]]:
    volumes_root = Path("/Volumes")
    if not _is_dir_with_timeout(volumes_root):
        return []
    try:
        boot_inode = Path("/").stat().st_ino
    except OSError:
        boot_inode = None
    network_fstypes = _macos_network_volumes()
    out: list[tuple[Path, str, str]] = []
    try:
        for entry in sorted(volumes_root.iterdir()):
            # Hidden mounts (e.g. ``/Volumes/.timemachine``) are
            # platform internals the user never wants to scan; skip.
            if entry.name.startswith("."):
                continue
            try:
                # Skip the boot volume; ``/`` and ``/Volumes/Macintosh HD``
                # share an inode, so we filter the duplicate.
                if boot_inode is not None and entry.stat().st_ino == boot_inode:
                    continue
            except OSError:
                continue
            if not _is_dir_with_timeout(entry):
                continue
            kind = "network" if str(entry) in network_fstypes else "removable"
            out.append((entry, entry.name, kind))
    except OSError:
        return out
    return out


def _macos_network_volumes() -> set[str]:
    """Parse ``mount`` output to flag network-backed volumes under /Volumes.

    macOS prints lines like ``//user@host/share on /Volumes/Share (smbfs, ...)``.
    Best-effort: on parse failure return empty so everything in
    ``/Volumes`` falls through to ``"removable"``.
    """
    try:
        result = subprocess.run(["/sbin/mount"], capture_output=True, text=True, timeout=1.0)
    except (OSError, subprocess.TimeoutExpired):
        return set()
    if result.returncode != 0:
        return set()
    network_kinds = {"smbfs", "afpfs", "nfs", "webdav", "ftp", "fuse"}
    out: set[str] = set()
    for line in result.stdout.splitlines():
        # ``<src> on <mountpoint> (<fstype>, ...)``
        try:
            on_split = line.split(" on ", 1)
            if len(on_split) != 2:
                continue
            rest = on_split[1]
            paren = rest.find(" (")
            if paren < 0:
                continue
            mountpoint = rest[:paren]
            attrs = rest[paren + 2 :].rstrip(")")
            fstype = attrs.split(",", 1)[0].strip().lower()
            if fstype in network_kinds:
                out.add(mountpoint)
        except (ValueError, IndexError):
            continue
    return out


def _discover_linux_mounts() -> list[tuple[Path, str, str]]:
    user = os.environ.get("USER") or os.environ.get("LOGNAME") or ""
    roots: list[Path] = []
    if user:
        roots.append(Path(f"/media/{user}"))
        roots.append(Path(f"/run/media/{user}"))
    roots.extend([Path("/media"), Path("/mnt")])

    network_fstypes = {"cifs", "nfs", "nfs4", "smbfs", "fuse.sshfs", "fuse.gvfsd-fuse"}
    network_paths = _linux_network_mounts(network_fstypes)

    out: list[tuple[Path, str, str]] = []
    for root in roots:
        if not _is_dir_with_timeout(root):
            continue
        try:
            for entry in sorted(root.iterdir()):
                if not _is_dir_with_timeout(entry):
                    continue
                kind = "network" if str(entry) in network_paths else "removable"
                out.append((entry, entry.name, kind))
        except OSError:
            continue
    return out


def _linux_network_mounts(network_fstypes: set[str]) -> set[str]:
    try:
        with Path("/proc/mounts").open(encoding="utf-8") as f:
            lines = f.readlines()
    except OSError:
        return set()
    out: set[str] = set()
    for line in lines:
        parts = line.split()
        if len(parts) < 3:
            continue
        mountpoint, fstype = parts[1], parts[2]
        if fstype in network_fstypes:
            out.add(mountpoint)
    return out


# GetDriveTypeW return values (winbase.h). REMOVABLE/FIXED/CDROM/RAMDISK
# all collapse to ``"removable"`` for picker purposes; only REMOTE gets
# its own bucket and only UNKNOWN / NO_ROOT_DIR are filtered out.
_DRIVE_UNKNOWN = 0
_DRIVE_NO_ROOT_DIR = 1
_DRIVE_REMOTE = 4


def _discover_windows_drives() -> list[tuple[Path, str, str]]:
    """Enumerate Windows drives via Win32 + classify type & label.

    Replaces the old D-Z directory-existence scan with kernel32 calls so
    we can: (a) skip drives that aren't actually present, (b) classify
    mapped network drives (``DRIVE_REMOTE``) as ``"network"`` instead of
    lumping everything under ``"removable"``, and (c) read the volume
    label so the picker shows ``"INSTA360 (D:)"`` rather than just
    ``"D:"``.

    UNC shares without a drive letter (``\\\\nas\\share``) aren't
    enumerated -- the typical Windows workflow maps network drives to a
    letter via "Map Network Drive", which this picks up.
    """
    drives = _query_windows_drives()
    out: list[tuple[Path, str, str]] = []
    for letter, (drive_type, label) in sorted(drives.items()):
        if letter == "C":  # skip system drive, matching prior behaviour
            continue
        if drive_type in (_DRIVE_UNKNOWN, _DRIVE_NO_ROOT_DIR):
            continue
        kind = "network" if drive_type == _DRIVE_REMOTE else "removable"
        display = f"{label} ({letter}:)" if label else f"{letter}:"
        out.append((Path(f"{letter}:\\"), display, kind))
    return out


def _query_windows_drives() -> dict[str, tuple[int, str | None]]:
    """Return ``{letter: (drive_type, volume_label)}`` for present drives.

    Empty on non-Windows or any kernel32 failure -- the caller falls back
    to "no removable drives discovered". Volume label is skipped for
    ``DRIVE_REMOTE`` because ``GetVolumeInformationW`` can hang on a
    stale share; the drive letter is still reported so the user can
    still navigate to it manually.
    """
    try:
        import ctypes
        from ctypes import wintypes
    except ImportError:
        return {}

    try:
        # ``ctypes.windll`` is only defined on Windows; on Linux/macOS the
        # AttributeError below short-circuits to {}.
        kernel32: Any = ctypes.windll.kernel32  # type: ignore[attr-defined]
    except (AttributeError, OSError):
        return {}

    try:
        bitmask = int(kernel32.GetLogicalDrives())
    except OSError:
        return {}
    if not bitmask:
        return {}

    out: dict[str, tuple[int, str | None]] = {}
    for i in range(26):
        if not (bitmask >> i) & 1:
            continue
        letter = chr(ord("A") + i)
        root = f"{letter}:\\"
        try:
            drive_type = int(kernel32.GetDriveTypeW(ctypes.c_wchar_p(root)))
        except OSError:
            continue
        label: str | None = None
        if drive_type != _DRIVE_REMOTE:
            label_buf = ctypes.create_unicode_buffer(261)  # MAX_PATH + 1
            fs_buf = ctypes.create_unicode_buffer(261)
            try:
                ok = kernel32.GetVolumeInformationW(
                    ctypes.c_wchar_p(root),
                    label_buf,
                    wintypes.DWORD(len(label_buf)),
                    None,
                    None,
                    None,
                    fs_buf,
                    wintypes.DWORD(len(fs_buf)),
                )
            except OSError:
                ok = 0
            if ok:
                label = label_buf.value or None
        out[letter] = (drive_type, label)
    return out


def _video_metadata_for(
    source: Path,
    *,
    slug: str,
    probes_dir: Path,
    thumbs_dir: Path,
    allow_new: bool,
    duration_for_thumb: float | None,
) -> tuple[float | None, str | None]:
    """Return ``(duration, thumbnail_url)`` for a source video.

    Always uses cached results when available. Runs ffprobe / ffmpeg only
    when ``allow_new`` is True (i.e. the caller wants on-demand work and is
    OK paying the cost). Failures are swallowed -- the picker's contract is
    "best effort, never block the listing".
    """
    duration: float | None = None
    cached_probe = video_probe.cached(source, probes_dir)
    if cached_probe is not None:
        duration = cached_probe.duration
    elif allow_new:
        try:
            result = video_probe.probe(
                source,
                cache_dir=probes_dir,
                ffprobe_binary=process_runtime().ffprobe_binary,
            )
            duration = result.duration
        except video_probe.ProbeError as exc:
            logger.debug("probe failed for %s: %s", source, exc)

    thumbnail_url: str | None = None
    cached_thumb = thumbnail_helpers.cached(source, thumbs_dir)
    if cached_thumb is not None:
        thumbnail_url = f"/api/shooters/{slug}/thumbnails/{cached_thumb.stem}.jpg"
    elif allow_new:
        try:
            t_dur = duration_for_thumb if duration_for_thumb is not None else duration
            extracted = thumbnail_helpers.ensure(
                source,
                cache_dir=thumbs_dir,
                duration=t_dur,
                ffmpeg_binary=process_runtime().ffmpeg_binary,
            )
            thumbnail_url = f"/api/shooters/{slug}/thumbnails/{extracted.stem}.jpg"
        except thumbnail_helpers.ThumbnailError as exc:
            logger.debug("thumbnail failed for %s: %s", source, exc)

    return duration, thumbnail_url


def _count_videos_shallow(directory: Path, *, cap: int = 200) -> int:
    """Count video files directly inside ``directory`` (no recursion).

    Capped at ``cap`` to keep the picker responsive on huge folders. The UI
    only uses this as a ranking hint ("this folder has videos in it").
    """
    count = 0
    try:
        for entry in directory.iterdir():
            if entry.is_file() and entry.suffix.lower() in VIDEO_EXTENSIONS:
                count += 1
                if count >= cap:
                    return count
    except (PermissionError, OSError):
        return 0
    return count


def serve(
    *,
    project_root: Path | None = None,
    project_name: str | None = None,
    host: str = "127.0.0.1",
    port: int = 5174,
    reload: bool = False,
    lab_enabled: bool = False,
    skip_system_check: bool = False,
) -> None:
    """Boot uvicorn synchronously. Used by the ``splitsmith ui`` CLI command.

    Wraps ``uvicorn.Server`` so the first Ctrl-C prints a summary of the
    background jobs that are still running (detect_beep, trim,
    shot_detect) -- otherwise uvicorn's graceful-shutdown wait looks
    like the process hanging. Uvicorn already promotes a second Ctrl-C
    to a force-exit; we just decorate the first press with the job
    inventory + a hint about pressing again.

    The first thing we do is check ffmpeg / ffprobe are invocable
    (issue #377 -- doc 04). The slim install ships them as documented
    system deps; a missing binary surfaces a copy-pasteable install
    hint here rather than a cryptic ``FileNotFoundError`` mid-trim.
    ``skip_system_check=True`` bypasses the probe (used by tests).
    """
    import uvicorn

    if not skip_system_check:
        from ..system_check import check_ffmpeg

        outcome = check_ffmpeg()
        if not outcome.ok:
            sys.stderr.write(outcome.hint + "\n")
            sys.exit(2)

    _ensure_ui_built()

    if reload:
        # Reload mode requires an importable factory; pass the path string and
        # use environment variables to feed the project context. Simpler: just
        # log a warning and run without reload for now. Reload is a dev
        # convenience that we can wire properly when we have a real config.
        logger.warning("reload=True is not supported yet; running without reload")

    app = create_app(
        project_root=project_root,
        project_name=project_name,
        lab_enabled=lab_enabled,
    )
    config = uvicorn.Config(app, host=host, port=port, log_level="info")
    server = _JobAwareServer(config, app)
    server.run()


class _JobAwareServer:
    """Lazy wrapper that builds a ``uvicorn.Server`` subclass on demand.

    The subclass override has to live next to the import to avoid
    pulling uvicorn into module import; we lift it via a closure inside
    :meth:`run` so unit tests don't pay the import cost.
    """

    def __init__(self, config: Any, app: FastAPI) -> None:
        self._config = config
        self._app = app

    def run(self) -> None:
        import uvicorn

        app = self._app

        class _Inner(uvicorn.Server):
            def handle_exit(self, sig: int, frame: Any) -> None:  # type: ignore[override]
                # First press: announce active jobs so the wait is
                # visible; let uvicorn flip should_exit and shut down
                # gracefully. Second press (uvicorn already detects
                # repeat SIGINT) escalates to force_exit, which kills
                # in-flight requests + the job thread pool.
                if not self.should_exit:
                    _print_active_jobs(app)
                uvicorn.Server.handle_exit(self, sig, frame)

        server = _Inner(self._config)
        server.run()


def _print_active_jobs(app: FastAPI) -> None:
    """Dump pending / running jobs to stderr on first Ctrl-C."""
    state = getattr(app.state, "splitsmith_state", None)
    if state is None:
        return
    try:
        jobs = state.jobs.list()
    except Exception:  # pragma: no cover -- defensive: never block shutdown
        logger.warning("could not enumerate jobs on shutdown", exc_info=True)
        return
    from .jobs import JobStatus

    active = [j for j in jobs if j.status in (JobStatus.PENDING, JobStatus.RUNNING)]
    print("", file=sys.stderr, flush=True)
    if not active:
        print("Shutting down (no background jobs running).", file=sys.stderr, flush=True)
        return
    print(
        f"Shutting down -- waiting for {len(active)} background job" f"{'' if len(active) == 1 else 's'}:",
        file=sys.stderr,
        flush=True,
    )
    for j in active:
        bits = [j.kind]
        if j.stage_number is not None:
            bits.append(f"stage {j.stage_number}")
        msg = j.message or j.status.value
        bits.append(msg)
        if j.progress is not None:
            bits.append(f"{round(j.progress * 100)}%")
        print(f"  - {' / '.join(bits)}", file=sys.stderr, flush=True)
    print(
        "Press Ctrl-C again to force quit (in-flight ffmpeg / detection will be killed).",
        file=sys.stderr,
        flush=True,
    )
