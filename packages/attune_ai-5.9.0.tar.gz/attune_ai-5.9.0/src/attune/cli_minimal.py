#!/usr/bin/env python3
"""Attune AI CLI.

IMPORTANT: This CLI is for automation only (git hooks, scripts, CI/CD).
For interactive use, use Claude Code skills in VSCode or Claude Desktop.

Automation commands:
    attune workflow list              List available workflows
    attune workflow run <name>        Execute a workflow
    attune workflow info <name>       Show workflow details

Cost tracking:
    attune costs                      Show cost report (last 7 days)
    attune costs --days 30            Show cost report for 30 days
    attune costs --json               Output cost data as JSON
    attune costs --workflow NAME      Filter by workflow
    attune costs today                Show today's costs
    attune costs export -o FILE       Export costs to file
    attune costs reset --confirm      Clear all cost data

Utility commands:
    attune features                   Show available features and dependencies
    attune telemetry show             Display usage summary
    attune telemetry savings          Show cost savings
    attune telemetry export           Export to CSV/JSON
    attune telemetry routing-stats    Show adaptive routing statistics
    attune telemetry routing-check    Check for tier upgrade recommendations
    attune telemetry models           Show model performance by provider
    attune telemetry agents           Show active agents and their status
    attune telemetry signals          Show coordination signals for an agent

    attune provider show              Show current provider config
    attune provider set <name>        Set provider (anthropic)

    attune auth status                Show subscription/auth strategy status
    attune auth status --json         Output subscription status as JSON
    attune auth setup                 Configure auth strategy interactively
    attune auth reset --confirm       Clear auth strategy configuration
    attune auth recommend <file>      Get auth recommendation for a file

    attune validate                   Validate configuration
    attune version                    Show version

For interactive development, use Claude Code skills:
    /dev        Developer tools (commit, review, debug, refactor)
    /testing    Run tests, coverage, generate tests
    /workflows  AI-powered workflows (security, bug prediction)
    /docs       Documentation generation
    /release    Release preparation
"""

from __future__ import annotations

import argparse
import logging
import sys

from attune.cli_commands.cost_commands import (
    cmd_costs,
    cmd_costs_export,
    cmd_costs_reset,
    cmd_costs_today,
)
from attune.cli_commands.help_commands import cmd_help
from attune.cli_commands.memory_commands import (
    cmd_forget,
    cmd_lessons,
    cmd_remember,
)
from attune.cli_commands.provider_commands import (
    cmd_provider_set,
    cmd_provider_show,
)
from attune.cli_commands.telemetry_commands import (
    cmd_telemetry_agents,
    cmd_telemetry_export,
    cmd_telemetry_models,
    cmd_telemetry_routing_check,
    cmd_telemetry_routing_stats,
    cmd_telemetry_savings,
    cmd_telemetry_show,
    cmd_telemetry_signals,
)
from attune.cli_commands.utility_commands import (
    cmd_doctor,
    cmd_features,
    cmd_setup,
    cmd_validate,
    cmd_version,
)
from attune.cli_commands.workflow_commands import (
    cmd_workflow_info,
    cmd_workflow_list,
    cmd_workflow_run,
)
from attune.models.auth_cli import (
    cmd_auth_recommend,
    cmd_auth_reset,
    cmd_auth_setup,
    cmd_auth_status,
)

logger = logging.getLogger(__name__)


def get_version() -> str:
    """Get package version."""
    try:
        from importlib.metadata import version

        return version("attune-ai")
    except Exception:  # noqa: BLE001
        # INTENTIONAL: Fallback for dev installs without metadata
        return "dev"


# =============================================================================
# Main Entry Point
# =============================================================================


def _add_workflow_subparsers(subparsers: argparse._SubParsersAction) -> None:
    """Add workflow subcommand parsers.

    Args:
        subparsers: Parent subparsers action to attach to

    """
    workflow_parser = subparsers.add_parser("workflow", help="Workflow management")
    workflow_sub = workflow_parser.add_subparsers(dest="workflow_command")

    workflow_sub.add_parser("list", help="List available workflows")

    info_parser = workflow_sub.add_parser("info", help="Show workflow details")
    info_parser.add_argument("name", help="Workflow name")

    run_parser = workflow_sub.add_parser("run", help="Run a workflow")
    run_parser.add_argument("name", help="Workflow name")
    run_parser.add_argument("--input", "-i", help="JSON input data")
    run_parser.add_argument("--path", "-p", help="Target path")
    run_parser.add_argument("--target", "-t", help="Target value (e.g., coverage target)")
    run_parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")


def _add_telemetry_subparsers(subparsers: argparse._SubParsersAction) -> None:
    """Add telemetry subcommand parsers.

    Args:
        subparsers: Parent subparsers action to attach to

    """
    telemetry_parser = subparsers.add_parser("telemetry", help="Usage telemetry")
    telemetry_sub = telemetry_parser.add_subparsers(dest="telemetry_command")

    show_parser = telemetry_sub.add_parser("show", help="Display usage summary")
    show_parser.add_argument(
        "--days",
        "-d",
        type=int,
        default=30,
        help="Number of days (default: 30)",
    )

    savings_parser = telemetry_sub.add_parser("savings", help="Show cost savings")
    savings_parser.add_argument(
        "--days",
        "-d",
        type=int,
        default=30,
        help="Number of days (default: 30)",
    )

    export_parser = telemetry_sub.add_parser("export", help="Export telemetry data")
    export_parser.add_argument("--output", "-o", required=True, help="Output file path")
    export_parser.add_argument(
        "--format",
        "-f",
        choices=["csv", "json"],
        default="json",
        help="Output format",
    )
    export_parser.add_argument(
        "--days",
        "-d",
        type=int,
        default=30,
        help="Number of days (default: 30)",
    )

    routing_stats_parser = telemetry_sub.add_parser(
        "routing-stats",
        help="Show adaptive routing statistics",
    )
    routing_stats_parser.add_argument("--workflow", "-w", help="Workflow name")
    routing_stats_parser.add_argument("--stage", "-s", help="Stage name")
    routing_stats_parser.add_argument(
        "--days",
        "-d",
        type=int,
        default=7,
        help="Number of days (default: 7)",
    )

    routing_check_parser = telemetry_sub.add_parser(
        "routing-check",
        help="Check for tier upgrade recommendations",
    )
    routing_check_parser.add_argument("--workflow", "-w", help="Workflow name")
    routing_check_parser.add_argument(
        "--all",
        "-a",
        action="store_true",
        help="Check all workflows",
    )

    models_parser = telemetry_sub.add_parser("models", help="Show model performance by provider")
    models_parser.add_argument(
        "--provider",
        "-p",
        choices=["anthropic"],
        help="Filter by provider",
    )
    models_parser.add_argument(
        "--days",
        "-d",
        type=int,
        default=7,
        help="Number of days (default: 7)",
    )

    telemetry_sub.add_parser("agents", help="Show active agents and their status")

    signals_parser = telemetry_sub.add_parser("signals", help="Show coordination signals")
    signals_parser.add_argument("--agent", "-a", required=True, help="Agent ID to view signals for")


def _add_costs_subparsers(subparsers: argparse._SubParsersAction) -> None:
    """Add cost tracking subcommand parsers.

    Args:
        subparsers: Parent subparsers action to attach to

    """
    costs_parser = subparsers.add_parser("costs", help="View API cost tracking and savings")
    costs_parser.add_argument(
        "--days",
        "-d",
        type=int,
        default=7,
        help="Number of days (default: 7)",
    )
    costs_parser.add_argument("--json", action="store_true", help="Output as JSON")
    costs_parser.add_argument("--workflow", "-w", help="Filter by workflow name")

    costs_sub = costs_parser.add_subparsers(dest="costs_command")

    costs_sub.add_parser("today", help="Show today's costs")

    costs_export = costs_sub.add_parser("export", help="Export cost data")
    costs_export.add_argument("--output", "-o", required=True, help="Output file path")
    costs_export.add_argument(
        "--format",
        "-f",
        choices=["csv", "json"],
        default="json",
        help="Output format",
    )
    costs_export.add_argument(
        "--days",
        "-d",
        type=int,
        default=30,
        help="Number of days (default: 30)",
    )

    costs_reset = costs_sub.add_parser("reset", help="Clear all cost data")
    costs_reset.add_argument("--confirm", action="store_true", help="Confirm deletion (required)")


def _add_misc_subparsers(subparsers: argparse._SubParsersAction) -> None:
    """Add provider, memory, setup, and utility subcommand parsers.

    Args:
        subparsers: Parent subparsers action to attach to

    """
    # Provider commands
    provider_parser = subparsers.add_parser("provider", help="LLM provider configuration")
    provider_sub = provider_parser.add_subparsers(dest="provider_command")
    provider_sub.add_parser("show", help="Show current provider")
    set_parser = provider_sub.add_parser("set", help="Set provider")
    set_parser.add_argument("name", choices=["anthropic"], help="Provider name")

    # Memory commands (quick lessons)
    remember_parser = subparsers.add_parser(
        "remember",
        help='Save a lesson: attune remember "lesson text"',
    )
    remember_parser.add_argument("lesson_text", help="Lesson to remember")
    remember_parser.add_argument(
        "--global",
        action="store_true",
        dest="global",
        help="Save to global ~/.attune/lessons.md instead of project",
    )

    forget_parser = subparsers.add_parser("forget", help="Remove a lesson by number or keyword")
    forget_parser.add_argument("identifier", help="Line number or keyword to match")

    lessons_parser = subparsers.add_parser("lessons", help="List current lessons")
    lessons_parser.add_argument(
        "--global",
        action="store_true",
        dest="global",
        help="Show only global lessons",
    )

    # Setup command
    subparsers.add_parser("setup", help="Install slash commands to ~/.claude/commands/")

    # --- Auth / subscription commands ---
    auth_parser = subparsers.add_parser("auth", help="Subscription and authentication management")
    auth_sub = auth_parser.add_subparsers(dest="auth_command")

    # auth status
    auth_status_parser = auth_sub.add_parser(
        "status", help="Show subscription/auth strategy status"
    )
    auth_status_parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON instead of formatted table",
    )

    # auth setup
    auth_sub.add_parser("setup", help="Configure auth strategy interactively")

    # auth reset
    auth_reset_parser = auth_sub.add_parser("reset", help="Clear auth strategy configuration")
    auth_reset_parser.add_argument(
        "--confirm",
        action="store_true",
        help="Confirm deletion of configuration",
    )

    # auth recommend
    auth_rec_parser = auth_sub.add_parser(
        "recommend",
        help="Get auth recommendation for a file",
    )
    auth_rec_parser.add_argument("file_path", help="Path to the file to analyze")

    # --- Utility commands ---
    help_parser = subparsers.add_parser("help-docs", help="Browse documentation templates")
    help_parser.add_argument("topic", nargs="?", help="Category or template name")
    help_parser.add_argument("--tag", help="Filter by tag")
    help_parser.add_argument("--tags", action="store_true", help="List all tags")
    help_parser.add_argument("--detail", action="store_true", help="Show normal detail level")
    help_parser.add_argument(
        "--deep", action="store_true", help="Show full detail with related topics"
    )
    help_parser.add_argument("--feedback", choices=["good", "bad"], help="Rate a template")

    subparsers.add_parser("doctor", help="Run comprehensive environment health check")
    subparsers.add_parser("features", help="Show available features and dependencies")
    subparsers.add_parser("validate", help="Validate configuration")

    version_parser = subparsers.add_parser("version", help="Show version")
    version_parser.add_argument("-v", "--verbose", action="store_true", help="Show detailed info")


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="attune",
        description="Attune AI CLI (automation interface - for git hooks, scripts, CI/CD)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
NOTE: This CLI is for automation only. For interactive development,
use Claude Code skills in VSCode or Claude Desktop:

    /dev        Developer tools (commit, review, debug, refactor)
    /testing    Run tests, coverage, generate tests
    /workflows  AI-powered workflows (security, bug prediction)
    /docs       Documentation generation
    /release    Release preparation

Documentation: https://smartaimemory.com/framework-docs/
        """,
    )

    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose output",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    _add_workflow_subparsers(subparsers)
    _add_telemetry_subparsers(subparsers)
    _add_costs_subparsers(subparsers)
    _add_misc_subparsers(subparsers)

    return parser


_SUBCOMMAND_DISPATCH: dict[str, dict[str, object]] = {
    "workflow": {
        "_attr": "workflow_command",
        "list": cmd_workflow_list,
        "info": cmd_workflow_info,
        "run": cmd_workflow_run,
    },
    "telemetry": {
        "_attr": "telemetry_command",
        "show": cmd_telemetry_show,
        "savings": cmd_telemetry_savings,
        "export": cmd_telemetry_export,
        "routing-stats": cmd_telemetry_routing_stats,
        "routing-check": cmd_telemetry_routing_check,
        "models": cmd_telemetry_models,
        "agents": cmd_telemetry_agents,
        "signals": cmd_telemetry_signals,
    },
    "provider": {
        "_attr": "provider_command",
        "show": cmd_provider_show,
        "set": cmd_provider_set,
    },
    "auth": {
        "_attr": "auth_command",
        "status": cmd_auth_status,
        "setup": cmd_auth_setup,
        "reset": cmd_auth_reset,
        "recommend": cmd_auth_recommend,
    },
    "costs": {
        "_attr": "costs_command",
        "today": cmd_costs_today,
        "export": cmd_costs_export,
        "reset": cmd_costs_reset,
    },
}

_SIMPLE_DISPATCH: dict[str, object] = {
    "remember": cmd_remember,
    "forget": cmd_forget,
    "lessons": cmd_lessons,
    "setup": cmd_setup,
    "help-docs": cmd_help,
    "doctor": cmd_doctor,
    "features": cmd_features,
    "validate": cmd_validate,
    "version": cmd_version,
}


def _dispatch_subcommand(args, command: str) -> int:
    """Dispatch a command that has subcommands."""
    table = _SUBCOMMAND_DISPATCH[command]
    attr = table["_attr"]
    sub = getattr(args, attr, None)
    handler = table.get(sub)
    if handler:
        return handler(args)
    # costs has a default handler (no subcommand = show report)
    if command == "costs":
        return cmd_costs(args)
    sub_names = [k for k in table if k != "_attr"]
    print(f"Usage: attune {command} {{{'|'.join(sub_names)}}}")
    return 1


def _show_welcome() -> int:
    """Show welcome message when no command is given."""
    try:
        from attune import __version__

        ver = __version__
    except Exception:  # noqa: BLE001
        # INTENTIONAL: version is non-critical for welcome message
        ver = "?"
    print(
        f"""Attune AI v{ver} — AI-powered developer workflows

Get started:
  attune workflow list        See all available workflows
  attune workflow run <name>  Run a workflow (requires ANTHROPIC_API_KEY)
  attune auth status          Check your subscription/auth status
  attune validate             Check your configuration

For interactive development in Claude Code:
  /attune       Socratic discovery — finds the right workflow for you
  /dev          Developer tools (commit, review, debug, refactor)
  /testing      Run tests, coverage, generate tests
  /wizard run   Guided multi-step wizards

More: attune --help | Docs: https://smartaimemory.com/framework-docs/"""
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args(argv)

    # Configure logging
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING)

    command = args.command

    # Subcommand dispatch (workflow, telemetry, provider, auth, costs)
    if command in _SUBCOMMAND_DISPATCH:
        return _dispatch_subcommand(args, command)

    # Simple command dispatch
    handler = _SIMPLE_DISPATCH.get(command)
    if handler:
        return handler(args)

    # No command given
    return _show_welcome()


if __name__ == "__main__":
    sys.exit(main())
