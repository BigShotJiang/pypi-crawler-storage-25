# Ferra SDK

python библиотека для работы с Ferra API.

## Полезные ссылки

- API документация: https://ferra.marusinohome.ru/docs
- Бот для подключения и получения API key: https://t.me/Ferra_DEV_Bot

---

## Установка

Сначала получите `apiKey` для своего бота через Ferra.

После этого установите библиотеку:

```bash
pip install ferra-sdk
```

---

## Быстрый старт

Создайте экземпляр клиента и передайте в него ваш `apiKey`.

```python
import os
from ferra_sdk import FerraClient

FERRA_API_KEY = os.getenv("FERRA_API_KEY")

if not FERRA_API_KEY:
    raise ValueError("FERRA_API_KEY is required")

ferra = FerraClient(
    api_key=FERRA_API_KEY,
)
```

> По умолчанию клиент использует базовый URL: `https://ferra.marusinohome.ru`

---

## Основные возможности

С помощью SDK можно:

- получать обязательные подписки через `get_op`
- получать задания через `get_tasks`
- проверять выполнение заданий через `check_tasks`

---

# Работа с обязательной подпиской (OP)

Этот сценарий полезен, когда перед использованием бота нужно проверить, подписан ли пользователь на обязательные ресурсы.

## Пример проверки подписки

```python
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from ferra_sdk import FerraClient

ferra = FerraClient(api_key="YOUR_API_KEY")


def create_op_keyboard(tasks: list[dict]) -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text=task["title"], url=task["link"])]
        for task in tasks
    ]

    return InlineKeyboardMarkup(inline_keyboard=buttons)


async def check_subscription(message) -> bool:
    user_id = str(message.from_user.id if message.from_user else message.chat.id)
    language_code = message.from_user.language_code if message.from_user else "ru"
    username = message.from_user.username if message.from_user else ""
    first_name = message.from_user.first_name if message.from_user else "User"

    if not user_id:
        return False

    try:
        op_tasks = await ferra.get_op({
            "user_id": user_id,
            "username": username or "",
            "first_name": first_name or "User",
            "language_code": language_code or "ru",
            "action": "subscribe",
            "limit": 20,
        })

        print(op_tasks)

        if not op_tasks:
            return True

        active_tasks = [task for task in op_tasks if task["status"] == "active"]

        if not active_tasks:
            return True

        text = "\n".join(
            [f'{index + 1}. <b>{task["title"]}</b>' for index, task in enumerate(active_tasks)]
        )

        await message.answer(
            f"<b>Для продолжения выполните обязательную подписку:</b>\n\n{text}",
            parse_mode="HTML",
            disable_web_page_preview=True,
            reply_markup=create_op_keyboard([
                {
                    "id": task["id"],
                    "title": task["title"],
                    "link": task["link"],
                }
                for task in active_tasks
            ]),
        )

        return False
    except Exception as error:
        print("Failed to check subscription:", error)
        await message.answer("Не удалось проверить обязательную подписку.")
        return False
```

## Логика работы

Функция:

1. вызывает `ferra.get_op(...)`;
2. проверяет, есть ли активные обязательные задания;
3. если активных заданий нет - пропускает пользователя дальше;
4. если задания есть - показывает их списком и отправляет клавиатуру со ссылками.

---

# Получение заданий

SDK позволяет получать доступные задания для пользователя.

## Пример команды `/task`

```python
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from ferra_sdk import FerraClient

router = Router()
ferra = FerraClient(api_key="YOUR_API_KEY")


def create_tasks_keyboard(tasks: list[dict]) -> InlineKeyboardMarkup:
    buttons = []

    for task in tasks:
        row = [
            InlineKeyboardButton(text=f'Открыть: {task["title"]}', url=task["link"]),
            InlineKeyboardButton(text="Проверить", callback_data=f'check_task:{task["id"]}'),
        ]
        buttons.append(row)

    return InlineKeyboardMarkup(inline_keyboard=buttons)


@router.message(Command("task"))
async def task_command(message: Message):
    try:
        user_id = str(message.from_user.id if message.from_user else message.chat.id)
        language_code = message.from_user.language_code if message.from_user else "ru"

        tasks = await ferra.get_tasks({
            "user_id": user_id,
            "language_code": language_code or "ru",
            "limit": 5,
        })

        active_tasks = [task for task in tasks if task["status"] == "active"]

        if not active_tasks:
            await message.answer("Сейчас для вас нет активных заданий.")
            return

        text = "\n\n".join(
            [
                f'{index + 1}. <b>{task["title"]}</b>\n'
                f'Тип: {task["taskType"]}\n'
                f'Ресурс: {task["type"]}'
                for index, task in enumerate(active_tasks)
            ]
        )

        await message.answer(
            f"<b>Доступные задания</b>\n\n{text}",
            parse_mode="HTML",
            disable_web_page_preview=True,
            reply_markup=create_tasks_keyboard([
                {
                    "id": task["id"],
                    "title": task["title"],
                    "link": task["link"],
                }
                for task in active_tasks
            ]),
        )
    except Exception as error:
        print("Failed to load tasks:", error)
        await message.answer("Не удалось получить задания. Попробуйте позже.")
```

## Как это работает

Функция:

1. вызывает `ferra.get_tasks(...)`;
2. оставляет только задания со статусом `active`;
3. показывает пользователю список доступных заданий;
4. прикрепляет клавиатуру со ссылками на выполнение.

---

# Проверка выполнения заданий

После того как пользователь выполнил действие, можно проверить результат через `check_tasks`.

## Пример callback-обработчика

```python
from aiogram import Router, F
from aiogram.types import CallbackQuery
from ferra_sdk import FerraClient

router = Router()
ferra = FerraClient(api_key="YOUR_API_KEY")


@router.callback_query(F.data.startswith("check_task:"))
async def check_task_callback(callback: CallbackQuery):
    try:
        await callback.answer("Проверяем задание...")

        task_id = callback.data.split(":", 1)[1]

        result = await ferra.check_tasks({
            "taskIds": [task_id],
        })

        task = result[0] if result else None

        if not task:
            await callback.message.answer("Не удалось получить результат проверки.")
            return

        text = ""

        if task["status"] == "completed":
            text = (
                "✅ Задание выполнено успешно.\n\n"
                f'<code>{task["taskId"]}</code>'
            )
        elif task["status"] == "waiting":
            text = (
                "⏳ Задание ещё не выполнено.\n"
                "Сначала перейдите по ссылке и выполните действие."
            )
        elif task["status"] == "expired":
            text = "⌛ Срок задания истёк."
        elif task["status"] in ("failed", "error"):
            text = (
                "❌ Не удалось проверить задание.\n"
                + (f'\nОшибка: <code>{task["error"]}</code>' if task.get("error") else "")
            )
        else:
            text = f'Статус задания: <code>{task["status"]}</code>'

        await callback.message.answer(
            text,
            parse_mode="HTML",
            disable_web_page_preview=True,
        )
    except Exception as error:
        print("Failed to check task:", error)

        await callback.answer("Ошибка проверки")
        await callback.message.answer("Не удалось проверить задание. Попробуйте позже.")
```
