from __future__ import annotations

from typing import Any, Literal, NotRequired, TypedDict

ResourceType = Literal[
    'tg_bot',
    'tg_channel',
    'tg_chat',
    'tg_group',
    'max_bot',
    'max_channel',
    'link',
]

TaskType = Literal[
    'start_bot',
    'subscribers',
    'post_views',
    'boosts',
    'link_clicks',
]

TaskStatus = Literal[
    'active',
    'waiting',
    'completed',
    'failed',
    'expired',
    'cancelled',
    'error',
]


class FerraApiSuccessResponse(TypedDict):
    success: bool
    message: str
    data: Any


class FerraApiErrorResponse(TypedDict, total=False):
    success: bool
    message: str
    error: str
    code: str


class FerraClientOptions(TypedDict, total=False):
    api_key: str
    base_url: str
    timeout_ms: int
    headers: dict[str, str]


class OpTask(TypedDict):
    id: str
    status: TaskStatus
    title: str
    photoUrl: str
    link: str
    type: ResourceType


class GetOpRequest(TypedDict):
    user_id: str
    username: str
    first_name: str
    language_code: str
    action: NotRequired[Literal['subscribe']]
    limit: int


class AdTask(TypedDict):
    id: str
    status: TaskStatus
    title: str
    photoUrl: str
    link: str
    type: ResourceType
    taskType: TaskType


class GetTasksRequest(TypedDict):
    user_id: str
    language_code: str
    limit: int


class CheckTasksRequest(TypedDict):
    taskIds: list[str]


class CheckTaskResult(TypedDict, total=False):
    taskId: str
    success: bool
    status: TaskStatus
    error: str | None


class CompletedTask(TypedDict):
    id: str
    userId: str
    adBotId: str
    campaignId: str
    status: str
    title: str
    photoUrl: str
    link: str
    completedAt: str | None
    createdAt: str


class GetCompletedTasksRequest(TypedDict):
    user_id: str
