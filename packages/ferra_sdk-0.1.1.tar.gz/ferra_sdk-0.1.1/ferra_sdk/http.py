from __future__ import annotations

from typing import Any

import httpx

from .errors import FerraError
from .types import FerraApiErrorResponse

DEFAULT_BASE_URL = 'https://ferra.marusinohome.ru'


class FerraHttpClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout_ms: int = 15000,
        headers: dict[str, str] | None = None,
    ) -> None:
        if not api_key or not api_key.strip():
            raise ValueError('api_key is required')

        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.timeout_ms = timeout_ms
        self.headers = headers or {}
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout_ms / 1000,
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.api_key}',
                **self.headers,
            },
        )

    async def post(self, path: str, body: dict[str, Any]) -> Any:
        try:
            response = await self._client.post(path, json=body)
            raw_text = response.text

            try:
                json_data = response.json() if raw_text else None
            except Exception as exc:
                raise FerraError(
                    'Invalid JSON response from Ferra API',
                    status=response.status_code,
                    details=raw_text,
                ) from exc

            if response.is_error:
                error_body: FerraApiErrorResponse = json_data or {}
                raise FerraError(
                    error_body.get('message')
                    or error_body.get('error')
                    or f'Ferra API request failed with status {response.status_code}',
                    status=response.status_code,
                    code=error_body.get('code'),
                    details=json_data,
                )

            return json_data
        except FerraError:
            raise
        except httpx.TimeoutException as exc:
            raise FerraError('Request timeout') from exc
        except httpx.HTTPError as exc:
            raise FerraError(str(exc), details=repr(exc)) from exc
        except Exception as exc:
            raise FerraError(
                str(exc) if isinstance(exc, Exception) else 'Unknown request error',
                details=repr(exc),
            ) from exc

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> 'FerraHttpClient':
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()
