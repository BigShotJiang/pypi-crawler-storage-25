from __future__ import annotations

from .http import DEFAULT_BASE_URL, FerraHttpClient
from .types import (
    AdTask,
    CheckTaskResult,
    CheckTasksRequest,
    CompletedTask,
    GetCompletedTasksRequest,
    GetOpRequest,
    GetTasksRequest,
    OpTask,
)


class _OpNamespace:
    def __init__(self, client: 'FerraClient') -> None:
        self._client = client

    async def get_available(self, payload: GetOpRequest) -> list[OpTask]:
        return await self._client.get_op(payload)


class _TasksNamespace:
    def __init__(self, client: 'FerraClient') -> None:
        self._client = client

    async def get_tasks(self, payload: GetTasksRequest) -> list[AdTask]:
        return await self._client.get_tasks(payload)

    async def check_tasks(
        self,
        payload: CheckTasksRequest,
    ) -> list[CheckTaskResult]:
        return await self._client.check_tasks(payload)

    async def get_completed(
        self,
        payload: GetCompletedTasksRequest,
    ) -> list[CompletedTask]:
        return await self._client.get_completed_tasks(payload)


class FerraClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout_ms: int = 15000,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.http = FerraHttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout_ms=timeout_ms,
            headers=headers,
        )
        self.op = _OpNamespace(self)
        self.tasks = _TasksNamespace(self)

    async def get_op(self, payload: GetOpRequest) -> list[OpTask]:
        response = await self.http.post('/api/v1/op', payload)
        return response['data']

    async def get_tasks(self, payload: GetTasksRequest) -> list[AdTask]:
        response = await self.http.post('/api/v1/tasks/get_tasks', payload)
        return response['data']

    async def check_tasks(
        self,
        payload: CheckTasksRequest,
    ) -> list[CheckTaskResult]:
        response = await self.http.post('/api/v1/tasks/check_task', payload)
        return response['data']

    async def get_completed_tasks(
        self,
        payload: GetCompletedTasksRequest,
    ) -> list[CompletedTask]:
        response = await self.http.post('/api/v1/tasks/get_completed_tasks', payload)
        return response['data']

    async def aclose(self) -> None:
        await self.http.aclose()

    async def __aenter__(self) -> 'FerraClient':
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()
