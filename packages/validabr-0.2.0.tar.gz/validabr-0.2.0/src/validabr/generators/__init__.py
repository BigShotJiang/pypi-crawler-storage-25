from .cep import generate_cep
from .cnh import generate_cnh
from .cnj import generate_cnj
from .cnpj import generate_cnpj
from .cns import generate_cns
from .cpf import generate_cpf
from .ie import generate_ie
from .nfe import generate_nfe
from .pis import generate_pis
from .renavam import generate_renavam
from .titulo_eleitor import generate_titulo_eleitor

__all__ = [
    "generate_cep",
    "generate_cnh",
    "generate_cnj",
    "generate_cnpj",
    "generate_cns",
    "generate_cpf",
    "generate_ie",
    "generate_nfe",
    "generate_pis",
    "generate_renavam",
    "generate_titulo_eleitor",
]
