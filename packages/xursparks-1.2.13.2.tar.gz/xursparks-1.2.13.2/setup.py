from setuptools import setup, find_packages
import pathlib
import re

with open("requirements.txt") as f:
	install_requires = f.read().strip().split("\n")

def get_version():
    init_path = pathlib.Path(__file__).parent / "xursparks" / "__init__.py"
    with open(init_path) as f:
        content = f.read()
    match = re.search(r'^__version__ = ["\']([^"\']+)["\']', content, re.M)
    if match:
        return match.group(1)
    raise RuntimeError("Unable to find version string.")

version = get_version()
print(f"version: {version}")

setup(
    name='xursparks',
    version=version,
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=install_requires,
    author='Randell Gabriel Santos',
    author_email='randellsantos@gmail.com',
    description='Encapsulating Apache Spark for Easy Usage',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/dev-doods687/xursparks',
    license='MIT',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    project_urls={
        "Documentation": "https://hadoop.dswd.xurpasportal.com/xursparks/",
        "Source": "https://github.com/dev-doods687/xursparks",
    },
)
