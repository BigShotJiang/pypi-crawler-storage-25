"""
NLP Agent module for xursparks.xkynet

This module provides NLP-based agents for various business domains.
Note: Requires llama_index and compatible dependencies.
"""
import warnings

try:
    from xursparks.xkynet.nlp.finance import FinanceAgent
    from xursparks.xkynet.nlp.hr import HRAgent
    from xursparks.xkynet.nlp.nlp import NLPAgent
    
    __all__ = ['NLPAgent', 'FinanceAgent', 'HRAgent']
    
except Exception as e:
    error_type = type(e).__name__
    warnings.warn(
        f"[Line 16] Failed to import NLP agents ({error_type}): {str(e)}. "
        "NLP features will not be available. "
        "Please update llama_index and related dependencies: "
        "pip install --upgrade llama_index",
        RuntimeWarning
    )
    # Define stub classes for when llama_index is not available
    class NLPAgent:
        def __init__(self, *args, **kwargs):
            raise RuntimeError(
                "[Line 27] NLPAgent is not available. "
                "Please install/update llama_index: pip install --upgrade llama_index"
            )
    
    class FinanceAgent:
        def __init__(self, *args, **kwargs):
            raise RuntimeError(
                "[Line 33] FinanceAgent is not available. "
                "Please install/update llama_index: pip install --upgrade llama_index"
            )
    
    class HRAgent:
        def __init__(self, *args, **kwargs):
            raise RuntimeError(
                "[Line 39] HRAgent is not available. "
                "Please install/update llama_index: pip install --upgrade llama_index"
            )
    
    __all__ = ['NLPAgent', 'FinanceAgent', 'HRAgent']