import os

# Get the path to the CHANGELOG.md file relative to this module
changelog_path = os.path.join(os.path.dirname(__file__), "..", "CHANGELOG.md")

if os.path.exists(changelog_path):
    with open(changelog_path, "r", encoding="utf-8") as f:
        __doc__ = f.read()
else:
    __doc__ = "Changelog not found."

# This module exists only to expose the CHANGELOG.md to pdoc.
__all__ = []
