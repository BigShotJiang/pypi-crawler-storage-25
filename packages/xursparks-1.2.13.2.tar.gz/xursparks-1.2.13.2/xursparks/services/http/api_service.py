import json

from xursparks.services.http.main import Xurl
from xursparks.tools.logger import Logger

class APIService:
    def __init__(self, base_url: str = None,
                 args: dict = None,
                 **kwargs):
        self.base_url = base_url
        self.args = args
        self.debug = kwargs.get("debug", False)

    def processRequest(self):
        """
        Get the response from the args dictionary.
        Returns:
            str: The response if available, otherwise None.
        """
        base_url = self.base_url
        xurl_json = self.args.get("json")
        xurl_data = self.args.get("data")
        xurl_files = self.args.get("files")
        xurl_auth = self.args.get("auth")
        if xurl_auth is None:
            xurl_auth = self.args.get("ntlm_auth")
        
        # Aggressive debug for troubleshooting persistent UAT issue
        if self.debug:
            Logger().debug(f"xurl_auth value: '{xurl_auth}', type: {type(xurl_auth)}")

        # Robust sanitization for auth parameter
        if isinstance(xurl_auth, str):
            if not xurl_auth.strip() or xurl_auth.lower() in ["none", "null", "false", "undefined"]:
                xurl_auth = None
        
        if not isinstance(xurl_auth, (tuple, list, dict)) and xurl_auth is not None:
            if self.debug:
                Logger().debug(f"Invalid auth type {type(xurl_auth)}. Resetting to None.")
            xurl_auth = None

        xurl_headers = self.args.get("headers")
        if xurl_headers is None:
            xurl_headers = {}
        if isinstance(xurl_headers, str):
            if not xurl_headers.strip() or xurl_headers.lower() in ["none", "null", "false"]:
                xurl_headers = {}
            else:
                try:
                    xurl_headers = json.loads(xurl_headers)
                except:
                    if self.debug:
                        Logger().debug(f"Failed to parse xurl_headers JSON: '{xurl_headers}'")
                    xurl_headers = {}
        
        if not isinstance(xurl_headers, dict):
            if self.debug:
                Logger().debug(f"Invalid headers type {type(xurl_headers)}. Resetting to empty dict.")
            xurl_headers = {}
        
        # If we are sending files (multipart/form-data), we must NOT set Content-Type manually.
        # requests library will automatically generate the correct boundary string.
        if xurl_files and xurl_headers:
            # Create a copy to avoid mutating original dictionary if used elsewhere
            # Ensure it is a dictionary before calling .items()
            if isinstance(xurl_headers, dict):
                xurl_headers = {k: v for k, v in xurl_headers.items() if k.lower() != 'content-type'}
            
        xurl_method = self.args.get("method", "GET")
        xurl_verify_ssl = self.args.get("verify_ssl", False)
        
        if self.debug:
            Logger().debug("************** [xursparks.services.http.api_service.processRequest] START **************")
            Logger().debug(f'base_url: {base_url}')
            Logger().debug(f'xurl_json: {xurl_json}')
            Logger().debug(f'xurl_data: {xurl_data}')
            Logger().debug(f'xurl_files: {xurl_files}')
            Logger().debug(f'xurl_auth: {xurl_auth}')
            Logger().debug(f'xurl_method: {xurl_method}')
            Logger().debug(f'xurl_verify_ssl: {xurl_verify_ssl}')
            Logger().debug(f'xurl_headers: {xurl_headers}')
            Logger().debug("************** [xursparks.services.http.api_service.processRequest] END **************")
        xurl = Xurl(
            url=base_url,
            headers=xurl_headers,
            json=xurl_json,
            data=xurl_data,
            files=xurl_files,
            auth=xurl_auth,
            verify_ssl=xurl_verify_ssl,
            debug=self.debug
        )
        if self.debug:
            Logger().debug(f'xurl[processRequest]: {str(xurl)}')
        if xurl_method.upper() == "POST":
            response = xurl.post()
        else:
            response = xurl.get()
        Logger().log(f'xurl[processRequest]: {response}', level='debug')
        return response