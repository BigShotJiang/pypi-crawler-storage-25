import json

import pyspark.pandas as ps
from pyspark.sql.types import (
    BooleanType,
    DoubleType,
    IntegerType,
    StringType,
    StructField,
    StructType,
)

from xursparks.services.http.api_service import APIService
from xursparks.tools.logger import Logger

class APIReader:
    """
    A class to read and process API data.
    """

    def __init__(self, api_url: str = None,
                 args: dict = None,
                 spark_session: object = None,
                 data: object = None,
                 **kwargs):
        self.api_url = api_url
        self.args = args
        self.spark_session = spark_session
        self.data = data
        self.debug = kwargs.get("debug", False)

    def fetch_data(self):
        headers = self.args.get("headers", {})
        if headers is None:
            headers = {}
        if isinstance(headers, str):
            try:
                headers = json.loads(headers)
            except:
                headers = {}
            
        auth_value = self.args.get("key")
        if auth_value:
            headers["Authorization"] = f"{auth_value}"
            if self.debug:
                Logger().debug(f"Updated Authorization header with new token")
        
        if self.debug:
            Logger().debug(f"Headers: {headers}")

        api_service = APIService(base_url=self.args.get("base_url"), args={
            "auth": self.args.get("auth"),
            "headers": headers,
            "method": self.args.get("method", "GET"),
            "verify_ssl": self.args.get("verify_ssl", False),
            "data": self.args.get("data"),
            "json": self.args.get("json"),
            "files": self.args.get("files")
        }, debug=self.debug)

        return api_service.processRequest()

    def process_data(self, df:object = None, return_format:str="dataframe"):
        """
        Process the fetched data and convert to Spark DataFrame or return raw JSON.
        
        Args:
            df: Optional DataFrame to process
            return_format: Format to return the data ('dataframe' or 'json') Defaults to 'dataframe'
            
        Returns:
            pyspark.sql.DataFrame or dict/list: Processed Spark DataFrame or raw JSON data
        """
        if self.data is not None:
            if return_format.lower() == "json":
                return self.data
                
            # Create Pandas DataFrame
            panda_frame = ps.DataFrame(self.data)
            
            # Create StructType schema
            schema_fields = []
            for column, dtype in panda_frame.dtypes.items():
                if dtype == 'object':
                    field_type = StringType()
                elif dtype == 'float64':
                    field_type = DoubleType()
                elif dtype == 'int64':
                    field_type = IntegerType()
                elif dtype == 'bool':
                    field_type = BooleanType()
                else:
                    field_type = StringType()  # Default to string
                    
                schema_fields.append(StructField(column, field_type, True))
            
            schema = StructType(schema_fields)
            
            # Create Spark DataFrame with schema
            try:
                spark_df = self.spark_session.createDataFrame(
                    panda_frame,
                    schema=schema
                )
                #print("\nSpark DataFrame Schema:")
                #spark_df.printSchema()
                return spark_df
                
            except Exception as e:
                if self.debug:
                    Logger().debug(f"Error converting to Spark DataFrame: {str(e)}")
                return None
        
        return df
