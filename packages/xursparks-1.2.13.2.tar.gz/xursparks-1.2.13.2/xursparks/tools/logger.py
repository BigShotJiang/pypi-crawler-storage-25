import inspect
import logging
import os
from datetime import datetime

class Logger:
    """
    A singleton class to handle logging functionality with caller context prefixing.
    """
    _instance = None
    
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(Logger, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, log_dir: str = "logs"):
        """
        Initialize logger with log directory.
        
        Args:
            log_dir (str): Directory to store log files
        """
        if self._initialized:
            return
            
        self.log_dir = log_dir
        
        # Create logs directory if it doesn't exist
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
            
        # Configure logging
        self.logger = logging.getLogger("xursparks")
        self.logger.setLevel(logging.DEBUG)
        
        # Avoid duplicate handlers if initialized multiple times
        if not self.logger.handlers:
            # Create formatter
            formatter = logging.Formatter(
                '%(asctime)s - %(levelname)s - %(message)s'
            )
            
            # File handler - logs to file with date
            log_file = os.path.join(
                log_dir, 
                f"log_{datetime.now().strftime('%Y%m%d')}.log"
            )
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
            
            # Stream handler - logs to console
            # console_handler = logging.StreamHandler()
            # console_handler.setFormatter(formatter)
            # self.logger.addHandler(console_handler)
            
        self._initialized = True

    def _get_caller_context(self, depth=2):
        """
        Retrieves the caller's context (filename, function name, line number).
        """
        try:
            stack = inspect.stack()
            # depth 2 is usually the caller of log() or debug()
            if len(stack) > depth:
                frame = stack[depth]
                filename = os.path.basename(frame.filename)
                func_name = frame.function
                line_no = frame.lineno
                return f"[{filename}:{func_name}:{line_no}]"
            return "[unknown]"
        except Exception:
            return "[unknown]"

    def log(self, *args, level: str = "info", **kwargs):
        """
        Log a message with specified level and automatically prepended context.
        
        Args:
            *args: One or more objects to log (converted to string and joined by spaces)
            level (str): Logging level (debug, info, warning, error, critical)
        """
        message = " ".join([str(arg) for arg in args])
        prefix = self._get_caller_context()
        full_message = f"{prefix} {message}"
        
        level = level.lower()
        if level == "debug":
            self.debug(*args)
        elif level == "info":
            self.logger.info(full_message)
        elif level == "warning":
            self.logger.warning(full_message)
        elif level == "error":
            self.logger.error(full_message)
        elif level == "critical":
            self.logger.critical(full_message)
        else:
            self.logger.info(f"Unknown log level '{level}', using INFO: {full_message}")

    def debug(self, *args):
        """
        Prints debug logs with context prefix.
        """
        message = " ".join([str(arg) for arg in args])
        prefix = self._get_caller_context(depth=3) # Higher depth for nested calls
        full_message = f"{prefix} DEBUG: {message}"
        print(full_message)
        self.logger.debug(full_message)

    def __del__(self):
        """Cleanup handlers on object destruction"""
        if hasattr(self, 'logger'):
            for handler in self.logger.handlers[:]:
                handler.close()
                self.logger.removeHandler(handler)