"""Step 40 — Parallel tool dispatch.

The bridge's dispatch loop (`acp_bridge.py`) used to run every tool
call returned by one round serially: spawn runner, drain stdout,
append result, repeat. With multi-tool rounds, that meant N read_file
calls in one turn paid N runner-spawn round-trips back-to-back.

This step adds a batching layer that groups consecutive tool calls
into "parallel-safe" runs and dispatches them via a single
``asyncio.gather`` over per-call runner subprocesses. Eligibility:

- Read-only criticality (model claim AND heuristic agree, per
  ``PermissionEvaluator._effective_criticality``) → parallel-safe.
- ``ToolKind.NETWORK`` tools (delegate_*, acp_call, web_fetch, …)
  isolate state via per-call session files → parallel-safe, gated
  on per-batch state-file uniqueness so two ``delegate_claude``
  calls don't race the same persisted state.
- ``compact_context`` and ``tool_search`` mutate bridge state
  (``messages`` list / promoted-tool set) → permanently sequential.

This test pins three layers:

1. **Helpers** — ``_state_file_key``, ``_call_is_parallel_eligible``,
   ``_build_parallel_groups`` are pure functions; check them
   directly so a regression in grouping logic fails fast without
   spinning up a daemon.

2. **TurnState** — multi-runner registration must round-trip and
   ``stop()`` must terminate every registered runner (not just the
   most-recent ``self.proc`` slot).

3. **Parallel execution** — ``CoreBackend._execute_batch_parallel``
   must (a) actually run runners concurrently (timing test), (b)
   append messages and ``round_record["calls"]`` in *original* call
   order regardless of completion order, and (c) stream delta
   events from all in-flight calls without dropping anything.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, Mapping, Optional
from unittest.mock import MagicMock

import pytest

from rtxclaw_agent.acp_bridge import (
    CoreBackend,
    _PARALLEL_UNSAFE_TOOLS,
    _build_parallel_groups,
    _call_is_parallel_eligible,
    _state_file_key,
)
from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.tools import (
    Criticality,
    PermissionEvaluator,
    PermissionMode,
    Tool,
    ToolKind,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _call(name: str, /, **args: Any) -> dict[str, Any]:
    """Build a minimal normalised tool-call dict the bridge expects.

    ``name`` is positional-only so callers can pass the *tool's* own
    ``name=`` argument as a kwarg without colliding (e.g.
    ``_call("delegate_agent", name="scraper")`` — the tool itself takes
    a ``name`` argument that distinguishes targets).
    """
    return {
        "id": f"tc_{name}_{abs(hash((name, tuple(sorted(args.items()))))) & 0xFFFF:x}",
        "name": name,
        "arguments": dict(args),
    }


def _tool(name: str, kind: ToolKind = ToolKind.READ) -> Tool:
    return Tool(name=name, kind=kind, description="(test)", parameters={})


def _evaluator(mode: str = "auto") -> PermissionEvaluator:
    return PermissionEvaluator(mode=PermissionMode(mode))


# ---------------------------------------------------------------------------
# 1) Pure-function helpers
# ---------------------------------------------------------------------------


def test_state_file_key_classifies_delegate_state() -> None:
    """Tools that share a ``<sid>.delegate_*.json`` file get a stable
    collision key; everything else returns ``None`` (no shared state)."""
    # Single-file delegates: key is just the tool name.
    assert _state_file_key(_call("delegate_claude", prompt="x")) == "delegate_claude"
    assert _state_file_key(_call("delegate_codex", prompt="x")) == "delegate_codex"

    # Multi-file delegates: key includes the target name so distinct
    # targets parallelise.
    assert _state_file_key(
        _call("delegate_agent", name="scraper", task="x"),
    ) == "delegate_agent:scraper"
    assert _state_file_key(
        _call("delegate_agent", name="planner", task="x"),
    ) == "delegate_agent:planner"
    assert _state_file_key(
        _call("acp_call", name="remote-a", prompt="x"),
    ) == "acp_call:remote-a"

    # Plain tools: no shared state, no collision key.
    assert _state_file_key(_call("Read", path="/a")) is None
    assert _state_file_key(_call("Grep", pattern="x")) is None


def test_parallel_eligible_read_only_passes() -> None:
    """Read-kind tool with no model criticality claim resolves to
    READ_ONLY (per ``_effective_criticality``'s "pure-read tool with
    no claim" branch) and is parallel-eligible."""
    ev = _evaluator("auto")
    tool = _tool("Read", kind=ToolKind.READ)
    assert _call_is_parallel_eligible(tool, _call("Read", path="/a"), ev) is True


def test_parallel_eligible_excludes_bridge_state_mutators() -> None:
    """``compact_context`` and ``tool_search`` mutate the running
    messages list / promoted-tool set; even if they classified as
    read_only they must not run alongside siblings."""
    ev = _evaluator("auto")
    # Force the criticality path to read_only so the only thing
    # excluding them is the unsafe-tool filter.
    cc = _call("compact_context", criticality="read_only")
    ts = _call("ToolSearch", criticality="read_only", query="x")
    assert _call_is_parallel_eligible(_tool("compact_context"), cc, ev) is False
    assert _call_is_parallel_eligible(_tool("ToolSearch"), ts, ev) is False
    assert "compact_context" in _PARALLEL_UNSAFE_TOOLS
    assert "ToolSearch" in _PARALLEL_UNSAFE_TOOLS


def test_parallel_eligible_network_tools() -> None:
    """NETWORK-kind tools (delegate_*, acp_call, web_fetch, …) are
    I/O-bound and don't share local state — eligible regardless of
    the criticality claim. Per-batch state-file uniqueness is
    enforced separately by ``_build_parallel_groups``."""
    ev = _evaluator("auto")
    delegate = _tool("delegate_claude", kind=ToolKind.NETWORK)
    call = _call("delegate_claude", criticality="mutating", prompt="hi")
    assert _call_is_parallel_eligible(delegate, call, ev) is True


def test_parallel_eligible_excludes_mutating_local_tools() -> None:
    """A plain WRITE-kind tool with mutating criticality must NOT join
    a parallel batch: two concurrent ``write_file`` calls could
    contend on the FS, and the mutating-criticality gate is the line
    of defence the user spec asked us to draw."""
    ev = _evaluator("auto")
    write = _tool("Write", kind=ToolKind.WRITE)
    call = _call("Write", criticality="mutating", path="/a", content="x")
    assert _call_is_parallel_eligible(write, call, ev) is False


def test_build_parallel_groups_batches_consecutive_safe() -> None:
    """Three consecutive read_file calls form one batch (gather)."""
    entries = [
        {"parallel_safe": True, "state_key": None},
        {"parallel_safe": True, "state_key": None},
        {"parallel_safe": True, "state_key": None},
    ]
    assert _build_parallel_groups(entries) == [[0, 1, 2]]


def test_build_parallel_groups_splits_on_unsafe_call() -> None:
    """A mutating call between two read_only calls splits the batch:
    the mutator must run alone so subsequent reads see its effects."""
    entries = [
        {"parallel_safe": True, "state_key": None},   # read
        {"parallel_safe": False, "state_key": None},  # write
        {"parallel_safe": True, "state_key": None},   # read
    ]
    assert _build_parallel_groups(entries) == [[0], [1], [2]]


def test_build_parallel_groups_splits_on_state_file_collision() -> None:
    """Two ``delegate_claude`` calls in one round both read+write
    ``<sid>.delegate_claude.json`` and would race; the batcher must
    split them into separate groups (sequential dispatch)."""
    entries = [
        {"parallel_safe": True, "state_key": "delegate_claude"},
        {"parallel_safe": True, "state_key": "delegate_claude"},
    ]
    assert _build_parallel_groups(entries) == [[0], [1]]


def test_build_parallel_groups_distinct_delegate_targets_batch() -> None:
    """Two ``delegate_agent`` calls with different target names
    persist to different ``<sid>.delegate_agent.<name>.json`` files
    — safe to run concurrently."""
    entries = [
        {"parallel_safe": True, "state_key": "delegate_agent:scraper"},
        {"parallel_safe": True, "state_key": "delegate_agent:planner"},
    ]
    assert _build_parallel_groups(entries) == [[0, 1]]


def test_build_parallel_groups_mixed_eligibility() -> None:
    """A realistic round: 2 reads (batch) → 1 write (singleton) →
    2 reads (batch). The order across groups is preserved so
    OpenAI-shape tool message ordering still tracks the assistant's
    ``tool_calls`` list."""
    entries = [
        {"parallel_safe": True, "state_key": None},
        {"parallel_safe": True, "state_key": None},
        {"parallel_safe": False, "state_key": None},
        {"parallel_safe": True, "state_key": None},
        {"parallel_safe": True, "state_key": None},
    ]
    assert _build_parallel_groups(entries) == [[0, 1], [2], [3, 4]]


# ---------------------------------------------------------------------------
# 2) TurnState multi-runner registration
# ---------------------------------------------------------------------------


def test_turnstate_register_unregister_runner() -> None:
    """Registered runners round-trip; unregistration drops them; the
    most-recent ``self.proc`` slot stays separate (it's the worker
    pointer, not a runner)."""
    from rtxclaw_core.turn_runtime import TurnState

    fake_worker = MagicMock(name="worker_proc")
    turn = TurnState("turn_1", session_hash="abc", proc=fake_worker)

    # Empty at construction.
    assert turn.runner_procs == {}

    runner_a = MagicMock(name="runner_a")
    runner_b = MagicMock(name="runner_b")
    turn.register_runner("call_a", runner_a)
    turn.register_runner("call_b", runner_b)
    assert turn.runner_procs == {"call_a": runner_a, "call_b": runner_b}

    turn.unregister_runner("call_a")
    assert turn.runner_procs == {"call_b": runner_b}

    # Idempotent: unregistering a missing key is a no-op.
    turn.unregister_runner("call_missing")
    assert turn.runner_procs == {"call_b": runner_b}


def test_turnstate_stop_terminates_all_runners() -> None:
    """ESC → ``cancel`` → ``turn.stop()`` must SIGTERM every active
    runner, not just whichever was last assigned to ``self.proc``.
    This is the core invariant the parallel batch path depends on."""
    from rtxclaw_core.turn_runtime import TurnState

    fake_worker = MagicMock(name="worker_proc")
    turn = TurnState("turn_1", session_hash="abc", proc=fake_worker)
    runner_a = MagicMock(name="runner_a")
    runner_b = MagicMock(name="runner_b")
    turn.register_runner("call_a", runner_a)
    turn.register_runner("call_b", runner_b)

    turn.stop()

    # Worker AND every runner got terminate().
    fake_worker.terminate.assert_called_once()
    runner_a.terminate.assert_called_once()
    runner_b.terminate.assert_called_once()


# ---------------------------------------------------------------------------
# 3) _execute_batch_parallel — concurrency + ordering + delta streaming
# ---------------------------------------------------------------------------


def _make_bridge_with_runner(runner) -> CoreBackend:
    """Construct a CoreBackend wired to a custom in-process runner."""
    cfg = AgentConfig(name="t", system="sys")
    bridge = CoreBackend(cfg, tool_runner=runner)
    return bridge


def _entry(call: Mapping[str, Any]) -> dict[str, Any]:
    """Build a permission-approved dispatch entry."""
    return {
        "call": dict(call),
        "tool": _tool(call["name"]),
        "started_at": "2026-05-08T00:00:00+00:00",
        "parallel_safe": True,
        "state_key": None,
    }


def test_batch_parallel_runs_concurrently() -> None:
    """Three calls each sleep 0.1s. If they run in parallel the
    total elapsed time is well under the 0.3s a sequential dispatch
    would take. Use a generous ceiling (0.25s) so a slow CI
    machine doesn't false-fail."""
    SLEEP = 0.1
    N = 3

    async def stub_runner(backend, session_id, call, turn, *, on_delta=None):
        await asyncio.sleep(SLEEP)
        return True, f"result-{call['name']}", False, False

    bridge = _make_bridge_with_runner(stub_runner)
    entries = [_entry(_call(f"read_{i}")) for i in range(N)]

    from rtxclaw_core.turn_runtime import TurnState
    turn = TurnState("turn_1", session_hash="sid", proc=MagicMock())

    messages: list[Any] = []
    round_record: dict[str, Any] = {"calls": []}

    async def _run() -> tuple[float, list[Any]]:
        events: list[Any] = []
        t0 = time.monotonic()
        async for ev in bridge._execute_batch_parallel(
            entries, "sid", "turn_1", 0, turn, messages, round_record,
        ):
            events.append(ev)
        return time.monotonic() - t0, events

    elapsed, events = asyncio.run(_run())

    assert elapsed < SLEEP * N * 0.85, (
        f"batch ran sequentially: elapsed={elapsed:.3f}s for {N}×{SLEEP}s "
        f"(would-be-sequential≈{SLEEP * N:.3f}s)"
    )
    # All N calls landed a tool message + round_record entry.
    assert len(messages) == N
    assert len(round_record["calls"]) == N


def test_batch_parallel_preserves_call_order() -> None:
    """Even when later calls finish first (different sleep times),
    messages and round_record entries land in the original
    call-order so the OpenAI-shape tool message list still tracks
    the assistant's ``tool_calls`` order one-to-one."""
    sleeps = {"first": 0.15, "middle": 0.05, "last": 0.10}

    async def stub_runner(backend, session_id, call, turn, *, on_delta=None):
        await asyncio.sleep(sleeps[call["name"]])
        return True, f"result-{call['name']}", False, False

    bridge = _make_bridge_with_runner(stub_runner)
    entries = [
        _entry(_call("first")),
        _entry(_call("middle")),
        _entry(_call("last")),
    ]

    from rtxclaw_core.turn_runtime import TurnState
    turn = TurnState("turn_1", session_hash="sid", proc=MagicMock())

    messages: list[Any] = []
    round_record: dict[str, Any] = {"calls": []}

    async def _run() -> None:
        async for _ev in bridge._execute_batch_parallel(
            entries, "sid", "turn_1", 0, turn, messages, round_record,
        ):
            pass

    asyncio.run(_run())

    # ``middle`` finished first (0.05s), but messages must still be
    # ordered first → middle → last.
    assert [m["content"] for m in messages] == [
        "result-first", "result-middle", "result-last",
    ]
    assert [c["result"] for c in round_record["calls"]] == [
        "result-first", "result-middle", "result-last",
    ]


def test_batch_parallel_streams_deltas() -> None:
    """Delta events from every in-flight runner are forwarded as
    ``tool_call_update`` events tagged with the right
    ``toolCallId`` while the runners are still running."""

    async def stub_runner(backend, session_id, call, turn, *, on_delta=None):
        # Emit two delta chunks, then a small wait, then a third.
        if on_delta is not None:
            await on_delta(f"{call['name']}-delta-1")
            await on_delta(f"{call['name']}-delta-2")
        await asyncio.sleep(0.02)
        return True, f"result-{call['name']}", False, False

    bridge = _make_bridge_with_runner(stub_runner)
    entries = [_entry(_call("alpha")), _entry(_call("beta"))]

    from rtxclaw_core.turn_runtime import TurnState
    turn = TurnState("turn_1", session_hash="sid", proc=MagicMock())

    messages: list[Any] = []
    round_record: dict[str, Any] = {"calls": []}

    async def _run() -> list[Any]:
        events: list[Any] = []
        async for ev in bridge._execute_batch_parallel(
            entries, "sid", "turn_1", 0, turn, messages, round_record,
        ):
            events.append(ev)
        return events

    events = asyncio.run(_run())

    # Both call_ids are represented in deltas (status=in_progress).
    in_progress = [
        ev for ev in events
        if ev.get("status") == "in_progress"
    ]
    seen_ids = {ev["toolCallId"] for ev in in_progress}
    expected_ids = {entries[0]["call"]["id"], entries[1]["call"]["id"]}
    assert seen_ids == expected_ids, (
        f"deltas missing for some calls: seen={seen_ids} expected={expected_ids}"
    )
    # And we got 2 deltas per call (4 total).
    assert len(in_progress) == 4

    # Final completed events come AFTER deltas (per-call ordering).
    completed = [ev for ev in events if ev.get("status") == "completed"]
    assert len(completed) == 2


def test_batch_parallel_handles_runner_exception() -> None:
    """If a single runner raises mid-batch, the others still land
    their results and the failing call records a synthesised
    failure message — the OpenAI-shape coupling between the
    assistant's tool_calls and the following tool messages is
    preserved (one-to-one)."""

    async def stub_runner(backend, session_id, call, turn, *, on_delta=None):
        if call["name"] == "boom":
            raise RuntimeError("synthetic crash")
        await asyncio.sleep(0.02)
        return True, f"result-{call['name']}", False, False

    bridge = _make_bridge_with_runner(stub_runner)
    entries = [
        _entry(_call("alpha")),
        _entry(_call("boom")),
        _entry(_call("gamma")),
    ]

    from rtxclaw_core.turn_runtime import TurnState
    turn = TurnState("turn_1", session_hash="sid", proc=MagicMock())

    messages: list[Any] = []
    round_record: dict[str, Any] = {"calls": []}

    async def _run() -> None:
        async for _ev in bridge._execute_batch_parallel(
            entries, "sid", "turn_1", 0, turn, messages, round_record,
        ):
            pass

    asyncio.run(_run())

    # All three calls landed messages (in order).
    assert len(messages) == 3
    assert messages[0]["content"] == "result-alpha"
    assert "synthetic crash" in messages[1]["content"]
    assert messages[2]["content"] == "result-gamma"
    # Only the failing call has ok=False in the audit.
    decisions = [(c["ok"], c["result"]) for c in round_record["calls"]]
    assert decisions[0][0] is True
    assert decisions[1][0] is False
    assert decisions[2][0] is True
