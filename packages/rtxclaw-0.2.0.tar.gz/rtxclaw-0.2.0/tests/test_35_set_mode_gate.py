"""Step 35 — ``session/set_mode`` actually flips the permission gate.

Regression for the 2026-05-07 incident: the operator switched the TUI
to plan mode (``Shift+Tab``) mid-session and asked the model to draft a
script. The TUI footer correctly read ``mode: plan`` (the
``current_mode_update`` notification round-tripped) and the saved
``Session.system_mode`` was ``"plan"`` on disk — yet the model's
``write_file`` call ran anyway and a 10K-char source file got written
to a sibling repo before the user could intervene.

Root cause: ``CoreBackend._evaluator_for`` read ``cfg.permission_mode``
(the static config, ``None`` → ``"auto"``) and never consulted the
live ``sess.system_mode`` that ``set_mode`` wrote. The evaluator
stayed in AUTO for the whole life of the session regardless of what
the frontend selected, which made plan mode purely cosmetic for any
session that started in auto.

This file pins the contract so a future drive-by edit can't silently
re-introduce the bug:

- ``_evaluator_for`` MUST honour ``sess.system_mode`` first.
- A mode change between calls MUST rebuild the evaluator (otherwise
  the cached one stays in the old policy).
- The static ``cfg.permission_mode`` remains the fallback when the
  session hasn't been steered explicitly.

We exercise the bridge's gate directly with a synthesised ``write_file``
call and a stub Session — no upstream LLM, no subprocess. The intent
is to catch the regression at the smallest layer that owns the
decision.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from rtxclaw_agent.acp_bridge import CoreBackend
from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.session import Session
from rtxclaw_core.tools.permissions import (
    Decision,
    PermissionMode,
)
from rtxclaw_core.tools.registry import BUILTIN_TOOLS, ToolRegistry


def _make_bridge(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> CoreBackend:
    """Build a CoreBackend with an isolated ``RTXCLAW_AGENTS_HOME``.

    Mirrors the ``test_34_event_logging`` helper so the two files share
    a common harness and a future refactor can lift it into conftest.
    """
    monkeypatch.setenv("RTXCLAW_AGENTS_HOME", str(tmp_path / "agents"))
    cfg = AgentConfig(name="t", system="sys")
    cfg.logfile.parent.mkdir(parents=True, exist_ok=True)
    return CoreBackend(cfg)


def _bind_session(bridge: CoreBackend, sid: str, mode: str) -> Session:
    """Construct a minimal Session and register it on the bridge.

    The bridge's ``_evaluator_for`` looks up the session via
    ``self._active_sessions``; populating it directly skips the
    full ``new_session`` round-trip (which needs a system prompt
    pipeline + sessions dir setup that's out of scope here).
    """
    sess = Session(
        hash=sid,
        title="t",
        created_at="2026-05-07T00:00:00Z",
        system_prompt="",
        model="m",
        endpoint="e",
        system_mode=mode,
    )
    bridge._active_sessions[sid] = sess
    return sess


def test_evaluator_honours_session_system_mode(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Plan-mode session must yield a plan-mode evaluator even when
    ``cfg.permission_mode`` is the default (``None`` → ``"auto"``).

    This is the exact path the 2026-05-07 bug walked: a session
    created against an auto-defaulting config, flipped to plan via
    ``set_mode``, and then asked to do work. Pre-fix, the evaluator
    was AUTO; post-fix it must be PLAN."""
    bridge = _make_bridge(tmp_path, monkeypatch)
    assert (bridge.cfg.permission_mode or "auto") == "auto", (
        "harness invariant: cfg.permission_mode must default to auto "
        "for this test to mean anything"
    )
    _bind_session(bridge, "sid-plan", "plan")

    evaluator = bridge._evaluator_for("sid-plan")
    assert evaluator.mode == PermissionMode.PLAN

    # And the gate must actually deny a mutating tool. Without this
    # assertion the test would still pass even if the evaluator were
    # built but never consulted.
    registry = ToolRegistry(BUILTIN_TOOLS)
    write_tool = registry.get("Write")
    assert write_tool is not None, "write_file must be in BUILTIN_TOOLS"
    decision = evaluator.evaluate(
        write_tool,
        {"path": "/tmp/x", "content": "y", "criticality": "mutating"},
    )
    assert decision == Decision.DENY


def test_evaluator_rebuilds_on_mode_change(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Flipping ``sess.system_mode`` between calls must produce a fresh
    evaluator with the new policy. The cache key is mode-aware — a
    stale cached evaluator in the old policy would silently outlive
    a ``set_mode`` and let the wrong gate run.

    Concretely: AUTO → PLAN → AUTO must produce three evaluators in
    the right modes. We don't assert *identity* (the implementation
    is allowed to recycle objects when the mode happens to match a
    previous one) — only that ``evaluator.mode`` tracks the session."""
    bridge = _make_bridge(tmp_path, monkeypatch)
    sess = _bind_session(bridge, "sid-flip", "auto")

    e1 = bridge._evaluator_for("sid-flip")
    assert e1.mode == PermissionMode.AUTO

    sess.system_mode = "plan"
    e2 = bridge._evaluator_for("sid-flip")
    assert e2.mode == PermissionMode.PLAN
    assert e2 is not e1, (
        "mode change must rebuild the evaluator; a cached evaluator "
        "carrying the old policy would let mutating tools run after "
        "a switch into plan"
    )

    sess.system_mode = "auto"
    e3 = bridge._evaluator_for("sid-flip")
    assert e3.mode == PermissionMode.AUTO


def test_evaluator_falls_back_to_cfg_when_session_mode_blank(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When the session hasn't been steered (``system_mode=""``), the
    static ``cfg.permission_mode`` wins. This preserves operator
    intent for sessions that never call ``set_mode`` — a daemon
    started with ``permission_mode=ask`` must keep prompting."""
    monkeypatch.setenv("RTXCLAW_AGENTS_HOME", str(tmp_path / "agents"))
    cfg = AgentConfig(name="t", system="sys", permission_mode="ask")
    cfg.logfile.parent.mkdir(parents=True, exist_ok=True)
    bridge = CoreBackend(cfg)
    _bind_session(bridge, "sid-nomode", "")

    evaluator = bridge._evaluator_for("sid-nomode")
    assert evaluator.mode == PermissionMode.ASK


def test_evaluator_falls_back_to_auto_when_session_mode_unrecognised(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A bogus ``system_mode`` (corrupted save, schema drift) must NOT
    crash the bridge — it falls back to AUTO. The on-disk session
    JSON is operator-editable; a typo there shouldn't take the agent
    out, but it also must NOT silently elevate permissions to a
    weaker mode by accident."""
    bridge = _make_bridge(tmp_path, monkeypatch)
    _bind_session(bridge, "sid-bogus", "lol-not-a-mode")

    evaluator = bridge._evaluator_for("sid-bogus")
    assert evaluator.mode == PermissionMode.AUTO
