"""Step 13 — Auto-compaction (compact_messages) unit coverage.

Lives in ``src/rtxclaw_core/turn_runtime.py:compact_messages``. The
function is a deterministic three-stage squeeze used both reactively
(after a vLLM "max_tokens" overflow) and proactively (when running
prompt size approaches ``compact_at_frac × upstream_max_context``).

A bug here can:

* dangle ``tool_call_id`` refs (tool messages without a matching
  ``assistant.tool_calls``) — vLLM 400.
* drop the most-recent user message — vLLM 400 "no user query".
* leave the prompt over budget when the protected set is too big
  (acceptable — the rescaler handles it — but should be flagged in
  the audit dict so the bridge can surface a warning).

These tests anchor on those invariants explicitly so future refactors
can't silently regress them.
"""
from __future__ import annotations

from rtxclaw_core.turn_runtime import _approx_tokens, compact_messages


def _msg(role: str, content: str = "", **extra) -> dict:
    return {"role": role, "content": content, **extra}


def test_under_target_is_noop() -> None:
    msgs = [
        _msg("system", "you are a helper"),
        _msg("user", "hi"),
        _msg("assistant", "hello"),
    ]
    out, removed, audit = compact_messages(msgs, target_tokens=100_000)
    assert out == msgs
    assert removed == 0
    assert audit == {
        "truncated_tool_call_ids": [],
        "dropped_tool_call_ids": [],
        "dropped_turns": 0,
    }


def test_stage1_truncates_large_tool_results() -> None:
    """Tool result > 800 chars in the head gets compacted to head+marker."""
    big = "X" * 5000
    msgs = [
        _msg("system", "sys"),
        _msg("assistant", "", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "ls", "arguments": "{}"}},
        ]),
        _msg("tool", big, tool_call_id="t1"),
        _msg("user", "what's next"),
        _msg("assistant", "thinking"),
    ]
    target = _approx_tokens(msgs) - 500  # force squeeze
    out, removed, audit = compact_messages(msgs, target_tokens=target)
    assert removed > 0
    assert "t1" in audit["truncated_tool_call_ids"]
    tool_msg = next(m for m in out if m.get("role") == "tool")
    assert "[compacted:" in tool_msg["content"]
    assert len(tool_msg["content"]) < 1000


def test_stage2_drops_tool_then_strips_tool_call() -> None:
    """If stage 1 isn't enough, the oldest tool message is dropped AND
    its matching ``assistant.tool_calls[]`` entry pruned so no dangling
    ref survives."""
    huge = "X" * 200_000  # too big for stage 1 truncation alone
    msgs = [
        _msg("system", "sys"),
        _msg("assistant", "", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "scan", "arguments": "{}"}},
        ]),
        _msg("tool", huge, tool_call_id="t1"),
        _msg("user", "live"),
        _msg("assistant", "answer"),
    ]
    out, _removed, audit = compact_messages(msgs, target_tokens=200)
    # Stage 2 should have run: tool dropped, audit promoted.
    assert "t1" in audit["dropped_tool_call_ids"]
    # No dangling assistant.tool_calls referencing t1.
    for m in out:
        if m.get("role") == "assistant" and m.get("tool_calls"):
            for tc in m["tool_calls"]:
                assert tc.get("id") != "t1"


def test_protected_user_never_dropped_even_at_low_target() -> None:
    """The most-recent user message must survive every stage."""
    msgs = [_msg("system", "sys")]
    # 50 turns of historical chatter, then the live user.
    for i in range(50):
        msgs.append(_msg("user", f"user old {i} " * 50))
        msgs.append(_msg("assistant", f"assistant old {i} " * 50))
    msgs.append(_msg("user", "THE LIVE QUESTION"))
    msgs.append(_msg("assistant", "in flight"))

    out, _removed, _audit = compact_messages(msgs, target_tokens=20)
    user_msgs = [m for m in out if m.get("role") == "user"]
    assert any(
        m.get("content") == "THE LIVE QUESTION" for m in user_msgs
    ), f"protected user message dropped:\n{user_msgs}"


def test_load_bearing_assistant_kept_when_tool_in_tail() -> None:
    """If a tool message survives in the tail, the assistant whose
    tool_calls produced it must NOT be dropped — otherwise vLLM 400."""
    msgs = [
        _msg("system", "sys"),
        # Old (drop-able) chatter.
        _msg("user", "old user " * 200),
        _msg("assistant", "old assistant " * 200),
        # Load-bearing pair — tool sits in the kept tail (last 2).
        _msg("assistant", "", tool_calls=[
            {"id": "tk", "type": "function",
             "function": {"name": "Read", "arguments": "{}"}},
        ]),
        _msg("tool", "result", tool_call_id="tk"),
    ]
    # Force aggressive compaction.
    out, _removed, _audit = compact_messages(msgs, target_tokens=10)
    # The load-bearing assistant must still be in the output.
    assert any(
        m.get("role") == "assistant"
        and any(
            tc.get("id") == "tk" for tc in (m.get("tool_calls") or [])
        )
        for m in out
    ), f"load-bearing assistant pruned (would dangle tk):\n{out}"


def test_audit_truncated_promoted_to_dropped_in_stage2() -> None:
    """When a tool entry truncated in stage 1 is then dropped in stage
    2, it must move from ``truncated_tool_call_ids`` to
    ``dropped_tool_call_ids`` (no double-counting)."""
    big = "Y" * 50_000
    msgs = [
        _msg("system", "sys"),
        _msg("assistant", "", tool_calls=[
            {"id": "t1", "type": "function",
             "function": {"name": "f", "arguments": "{}"}},
        ]),
        _msg("tool", big, tool_call_id="t1"),
        _msg("user", "live"),
        _msg("assistant", "answer"),
    ]
    out, _removed, audit = compact_messages(msgs, target_tokens=50)
    assert "t1" in audit["dropped_tool_call_ids"]
    # Promotion happened — should not appear in both lists.
    assert "t1" not in audit["truncated_tool_call_ids"]


def test_returns_some_progress_even_when_only_protected_remain() -> None:
    """If the protected tail alone overflows, we don't loop forever —
    we return whatever survives + the audit so callers can decide."""
    msgs = [
        _msg("system", "sys " * 1000),
        _msg("user", "live " * 5000),
        _msg("assistant", "drafting " * 5000),
    ]
    out, removed, audit = compact_messages(msgs, target_tokens=10)
    # Should have terminated cleanly with protected messages intact.
    assert any(m.get("role") == "user" for m in out)
    assert isinstance(audit, dict)
    # Nothing to do: no tool messages, no extra turns to drop.
    assert audit["dropped_turns"] == 0
    assert audit["dropped_tool_call_ids"] == []
    assert removed == 0
