"""Step 04 — gateway lifecycle (start / status / stop).

Under the single-process gateway architecture there's exactly one
rtxclaw daemon per box: ``rtxclaw gateway start`` boots a parent
process that hosts every agent under ``/acp/<name>`` and lazy-spawns
each child on first request. The legacy "one daemon per agent"
flow has been retired (the per-agent ``rtxclaw agent start`` is now
a thin alias that delegates to the gateway lifecycle commands).

These tests pin the gateway lifecycle end-to-end:

  1. ``gateway start``  writes ``$RTXCLAW_HOME/gateway.pid`` and
     surfaces a bind URL in the gateway log.
  2. ``gateway status`` reports running.
  3. ``gateway stop``   removes the pidfile and reaps the process.

Daemon-side deps (hypercorn / starlette / sse-starlette) are part of
``src/requirements.txt`` so the bootstrap installs them along with
everything else; no capability gate is needed.
"""
from __future__ import annotations

import re
import time
from pathlib import Path

import pytest


def _wait_for(path: Path, timeout: float = 5.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if path.exists():
            return True
        time.sleep(0.2)
    return False


@pytest.fixture
def stopped_gateway(scaffolded_agent: Path, run_rtxclaw):
    """Pre/post: ensure no gateway is running.

    ``scaffolded_agent`` is in the param list (not used directly) so
    agent ``main``'s config exists on disk before the gateway boots
    — the gateway's agent discovery walks ``agents_root()``.
    """
    run_rtxclaw("gateway", "stop")
    yield
    run_rtxclaw("gateway", "stop")


def test_gateway_start_writes_pidfile_and_log(
    stopped_gateway, sandbox_home: Path, run_rtxclaw,
) -> None:
    pidfile = sandbox_home / "gateway.pid"
    logfile = sandbox_home / "gateway.log"
    cp = run_rtxclaw("gateway", "start", timeout=120)
    assert cp.returncode == 0, f"gateway start failed:\n{cp.stderr}"
    assert _wait_for(pidfile, timeout=20.0), "gateway.pid never appeared"
    assert _wait_for(logfile, timeout=20.0), "gateway.log never appeared"
    log_body = logfile.read_text(errors="replace")
    assert re.search(r"http://[0-9.:]+", log_body), (
        f"no bind URL in gateway log:\n{log_body[-500:]}"
    )


def test_gateway_status_reports_running(
    sandbox_home: Path, run_rtxclaw,
) -> None:
    # Assume the previous test left the gateway up; bring it up if needed.
    pidfile = sandbox_home / "gateway.pid"
    if not pidfile.exists():
        run_rtxclaw("gateway", "start", timeout=120)
        _wait_for(pidfile, timeout=20.0)
    cp = run_rtxclaw("gateway", "status")
    combined = cp.stdout + cp.stderr
    # Status prints "gateway: running (pid=<n>) at http://…" plus a
    # summary block listing agents / live children. Don't pin exact
    # phrasing — just enough to prove the status path reached the
    # live gateway.
    assert "gateway" in combined.lower()
    assert "running" in combined.lower()
    assert re.search(r"pid[ =:]\s*\d+", combined), combined


def test_gateway_stop_removes_pidfile(
    sandbox_home: Path, run_rtxclaw,
) -> None:
    pidfile = sandbox_home / "gateway.pid"
    if not pidfile.exists():
        run_rtxclaw("gateway", "start", timeout=120)
        _wait_for(pidfile, timeout=20.0)
    cp = run_rtxclaw("gateway", "stop", timeout=30)
    assert cp.returncode == 0, cp.stderr
    # Stop is async; give it up to 5 s.
    deadline = time.time() + 5
    while pidfile.exists() and time.time() < deadline:
        time.sleep(0.2)
    assert not pidfile.exists(), "pidfile still present after gateway stop"
