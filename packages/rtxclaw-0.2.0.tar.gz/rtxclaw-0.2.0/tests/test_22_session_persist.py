"""Step 22 — Session persistence round-trip coverage.

The session JSON files under ``<agent_home>/sessions/<hash>.json``
are the operator-facing persistence surface — restart the daemon and
it must rebuild every prior session faithfully. The save/load layer
is open-coded (bridge constructs ``Session(...)`` from the parsed
dict; no shared ``from_dict`` helper), which makes silent drift
between writer and reader easy.

This test pins the round-trip:

- ``save()`` produces parseable JSON with every persisted field.
- A fresh ``Session(**parsed)`` round-trips to byte-identical state
  for every persisted field, modulo defaults the writer omitted.
- The atomic-replace path leaves no ``.tmp`` debris.
- A delegate-shaped turn record (the schema test_20 pins) survives
  the round-trip.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from rtxclaw_core.session import Session


def _make_session(turn: dict | None = None) -> Session:
    s = Session(
        hash="abc123def456",
        title="round-trip test",
        created_at="2026-05-06T01:30:00+00:00",
        system_prompt="you are a helper",
        system_mode="auto",
        workspace_cwd="/tmp/work",
        workspace_origin="acp",
        model="qwen3-30b",
        endpoint="http://upstream.test/v1",
        backend="vllm",
        context_window=262144,
        compaction_count=2,
        memory_flush_compaction_count=1,
        last_memory_flush_at="2026-05-06T01:00:00+00:00",
        pinned_facts=["the user runs on a 5090", "primary timezone is UTC-3"],
        compaction_summary="dropped 12 old turns; saved 4 tool results",
        reasoning_visibility="stream",
        tool_output_visible=True,
        turns=[turn] if turn else [],
    )
    return s


def test_save_writes_parseable_json(tmp_path: Path) -> None:
    sess = _make_session()
    sess.save(tmp_path)
    path = tmp_path / f"{sess.hash}.json"
    assert path.is_file()
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["hash"] == sess.hash
    assert data["model"] == "qwen3-30b"
    assert data["context_window"] == 262144


def test_save_atomic_no_tmp_debris(tmp_path: Path) -> None:
    """Atomic-replace must clean up the sibling ``.tmp`` after a
    successful save — leftover ``.<hash>.json.tmp`` files would
    accumulate forever."""
    sess = _make_session()
    sess.save(tmp_path)
    leftovers = list(tmp_path.glob(".*.tmp"))
    assert leftovers == [], f"tmp debris left behind: {leftovers}"


def test_round_trip_preserves_every_persisted_field(tmp_path: Path) -> None:
    sess = _make_session()
    sess.save(tmp_path)
    raw = json.loads(
        (tmp_path / f"{sess.hash}.json").read_text(encoding="utf-8"),
    )
    rehydrated = Session(
        hash=raw["hash"],
        title=raw["title"],
        created_at=raw["created_at"],
        system_prompt=raw["system_prompt"],
        system_mode=raw.get("system_mode", ""),
        workspace_cwd=raw.get("workspace_cwd", ""),
        workspace_origin=raw.get("workspace_origin", ""),
        model=raw.get("model", ""),
        endpoint=raw.get("endpoint", ""),
        backend=raw.get("backend", ""),
        context_window=raw.get("context_window", 0),
        compaction_count=raw.get("compaction_count", 0),
        memory_flush_compaction_count=raw.get(
            "memory_flush_compaction_count", -1,
        ),
        last_memory_flush_at=raw.get("last_memory_flush_at", ""),
        pinned_facts=list(raw.get("pinned_facts") or []),
        compaction_summary=raw.get("compaction_summary", ""),
        reasoning_visibility=raw.get("reasoning_visibility", ""),
        tool_output_visible=bool(raw.get("tool_output_visible", False)),
        turns=list(raw.get("turns") or []),
    )
    for field in (
        "hash", "title", "created_at", "system_prompt", "system_mode",
        "workspace_cwd", "workspace_origin", "model", "endpoint",
        "backend", "context_window", "compaction_count",
        "memory_flush_compaction_count", "last_memory_flush_at",
        "pinned_facts", "compaction_summary", "reasoning_visibility",
        "tool_output_visible", "turns",
    ):
        assert getattr(rehydrated, field) == getattr(sess, field), (
            f"field {field!r} drifted in save→load round-trip:\n"
            f"  before: {getattr(sess, field)!r}\n"
            f"  after:  {getattr(rehydrated, field)!r}"
        )


def test_delegate_turn_round_trip(tmp_path: Path) -> None:
    """Delegate turn records (the schema test_20 pins) must survive
    a save/load cycle byte-for-byte — the runtime persists them via
    ``sess.save`` after every delegate dispatch."""
    delegate_turn = {
        "id": "turn_delegate_1",
        "started_at": "2026-05-06T01:30:00+00:00",
        "ended_at": "2026-05-06T01:30:30+00:00",
        "user": "what is the capital of France?",
        "thinking": "",
        "content": "Paris",
        "aborted": False,
        "error": None,
        "in_progress": False,
        "metrics": {"source": "delegate_claude"},
        "tool_rounds": [{
            "round": 0,
            "calls": [{
                "id": "direct-turn1",
                "name": "delegate_claude",
                "arguments": {"prompt": "what is the capital of France?"},
                "decision": "direct",
                "ok": True,
                "result": "Paris",
                "started_at": "2026-05-06T01:30:00+00:00",
                "ended_at": "2026-05-06T01:30:30+00:00",
            }],
        }],
    }
    sess = _make_session(turn=delegate_turn)
    sess.save(tmp_path)
    raw = json.loads(
        (tmp_path / f"{sess.hash}.json").read_text(encoding="utf-8"),
    )
    assert raw["turns"] == [delegate_turn], (
        "delegate turn record drifted across save/load — schema break"
    )


def test_save_overwrites_existing_file(tmp_path: Path) -> None:
    sess = _make_session()
    sess.save(tmp_path)
    sess.title = "renamed"
    sess.save(tmp_path)
    raw = json.loads(
        (tmp_path / f"{sess.hash}.json").read_text(encoding="utf-8"),
    )
    assert raw["title"] == "renamed"


def test_save_creates_parent_dir(tmp_path: Path) -> None:
    """Save must mkdir(parents=True) so a fresh agent's first-ever
    session doesn't crash with a FileNotFoundError on the missing
    ``sessions/`` directory."""
    nested = tmp_path / "agent" / "sessions"
    sess = _make_session()
    sess.save(nested)
    assert (nested / f"{sess.hash}.json").is_file()
