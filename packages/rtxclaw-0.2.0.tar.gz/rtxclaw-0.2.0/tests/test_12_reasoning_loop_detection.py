"""Step 12 — Reasoning-loop detector unit + integration coverage.

The detector lives in
``src/rtxclaw_core/turn_runtime.py:_detect_reasoning_loop``. It's a
silent safety net — when extended-CoT models start cycling, the bridge
hands the partial reasoning to a distiller and finalises the turn
instead of letting the loop burn the context window. A regression here
is invisible until a turn never finishes, so the detector deserves
explicit unit coverage.

Coverage:
- True positive: ≥4 occurrences of a meaty n-gram in the suffix fires.
- False positive guards: whitespace-dominated grams skipped, ≤2
  unique chars (markdown rules / "==…==") skipped, sub-threshold
  buffers skipped.
- Window cutoff: only the suffix matters (an old loop in the head
  doesn't fire on a clean tail).
- Integration-shaped: simulate a CoT trace that should fire and one
  that shouldn't, to demonstrate the detector's intended use.
"""
from __future__ import annotations

import pytest

from rtxclaw_core.turn_runtime import (
    LOOP_MIN_CONTEXT_CHARS,
    LOOP_NGRAM_LEN,
    LOOP_REPEAT_THRESHOLD,
    LOOP_WINDOW_CHARS,
    _detect_reasoning_loop,
)


def _padding(n: int) -> str:
    """A plausible-looking pad of `n` chars that's free of repetitive
    n-grams of the relevant size. Uses the alphabet rotated so no
    ``ngram_len``-window aligns twice."""
    base = "abcdefghijklmnopqrstuvwxyz0123456789"
    out: list[str] = []
    while sum(len(s) for s in out) < n:
        out.append(base[:max(LOOP_NGRAM_LEN, 1)])
        # Rotate so the next chunk has a different ``ngram_len`` head.
        base = base[1:] + base[:1]
    return "".join(out)[:n]


def test_short_buffer_does_not_fire() -> None:
    short = "Let me reconsider. " * 3
    assert _detect_reasoning_loop(short) is None


def test_pure_repetition_fires() -> None:
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    loop = "The answer must be 42 and the answer must be 42. " * (
        LOOP_REPEAT_THRESHOLD + 2
    )
    buf = pad + loop
    hit = _detect_reasoning_loop(buf)
    assert hit is not None, (
        f"detector missed clear repetition (buf len={len(buf)})"
    )
    assert "42" in hit or "answer" in hit


def test_whitespace_only_ngram_skipped() -> None:
    """A long run of spaces (e.g. a markdown table row) shouldn't trip
    the detector — that's formatting noise, not reasoning."""
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    spaces = " " * (LOOP_NGRAM_LEN * (LOOP_REPEAT_THRESHOLD + 1))
    assert _detect_reasoning_loop(pad + spaces) is None


def test_markdown_rule_ngram_skipped() -> None:
    """Repeated ``=`` characters (markdown heading underline / horizontal
    rule) collapse to ≤2 unique chars and must be skipped."""
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    rule = "=" * (LOOP_NGRAM_LEN * (LOOP_REPEAT_THRESHOLD + 1))
    assert _detect_reasoning_loop(pad + rule) is None


def test_old_loop_in_head_does_not_fire() -> None:
    """When the loop sits in the prefix and the suffix is clean, the
    detector must NOT fire — otherwise the model never recovers."""
    head = "I am stuck I am stuck I am stuck I am stuck I am stuck "
    head_pad = head * 50  # well past LOOP_WINDOW_CHARS — but at the head
    clean_tail = _padding(LOOP_WINDOW_CHARS + LOOP_MIN_CONTEXT_CHARS)
    buf = head_pad + clean_tail
    assert _detect_reasoning_loop(buf) is None


def test_low_ngram_threshold_param() -> None:
    """Caller can tighten the threshold; with threshold=2 a doubled
    n-gram must fire."""
    pad = _padding(200)
    body = ("the cat sat on the mat — " * 4)[: LOOP_NGRAM_LEN * 3]
    hit = _detect_reasoning_loop(
        pad + body,
        ngram_len=10,
        repeat_threshold=2,
        min_context_chars=100,
    )
    assert hit is not None


def test_detector_is_pure() -> None:
    """No I/O, no side effects — sanity-check by running twice on the
    same input and confirming the result matches."""
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    loop = "Consider the function f(x) = 2x + 1. " * (
        LOOP_REPEAT_THRESHOLD + 1
    )
    buf = pad + loop
    a = _detect_reasoning_loop(buf)
    b = _detect_reasoning_loop(buf)
    assert a == b


@pytest.mark.parametrize(
    "ngram_len, threshold, expect_fire",
    [
        (60, 4, True),    # default — fires
        (60, 99, False),  # impossibly high threshold — never fires
        (200, 4, False),  # n-gram longer than the loop body
    ],
)
def test_parametrised_thresholds(
    ngram_len: int, threshold: int, expect_fire: bool,
) -> None:
    pad = _padding(LOOP_MIN_CONTEXT_CHARS)
    loop = "Therefore the answer is forty two. " * 8
    buf = pad + loop
    hit = _detect_reasoning_loop(
        buf,
        ngram_len=ngram_len,
        repeat_threshold=threshold,
        window_chars=LOOP_WINDOW_CHARS,
        min_context_chars=LOOP_MIN_CONTEXT_CHARS,
    )
    assert (hit is not None) is expect_fire
