"""Step 07 — memory pipeline (real document → daily → synth → recall).

End-to-end memory loop, all running against the real upstream:

1. ``index`` / ``status`` / ``search`` CLI surface is healthy.
2. Feed the project's full README via ``rtxclaw -p`` and ask the
   model to remember the durable bits — content lands in today's
   daily at ``<agent_home>/memory/YYYY-MM-DD.md``.
3. Force ``synth_memory`` — it rewrites ``MEMORY.md`` from the daily
   with non-empty sections (the README is dense with durable facts;
   if every section comes back as the empty-placeholder, the synth
   filtered too aggressively).
4. Ask the agent ``what is rtxclaw?`` and verify the model invokes
   the ``memory_search`` tool and grounds its answer in the saved
   memory. Detected via gateway.log + response-content checks.

The fixtures cache via "is the artifact already on disk?" so all
four tests in this module trigger the LLM at most once for upload
and once for synth, not once per test.
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import pytest


# ---- index / search basics ----------------------------------------------

SEED_TOKEN = f"rtxtestmemo{os.getpid()}"


@pytest.fixture
def seeded_memory(scaffolded_agent: Path) -> Path:
    """Plant a deterministic memory file so search has a known target
    even if the model fails to call the remember tool in later tests."""
    mem_dir = scaffolded_agent / "memory"
    mem_dir.mkdir(parents=True, exist_ok=True)
    (scaffolded_agent / "MEMORY.md").write_text(
        f"- [test seed]({SEED_TOKEN}.md) — token planted by test_07_memory.py\n"
    )
    (mem_dir / f"{SEED_TOKEN}.md").write_text(
        f"---\nname: test seed\ntype: feedback\n---\n\nToken {SEED_TOKEN}.\n"
    )
    return scaffolded_agent


def test_memory_index_exits_zero(seeded_memory: Path, run_rtxclaw) -> None:
    cp = run_rtxclaw("memory", "index", "-a", "main", timeout=60)
    assert cp.returncode == 0, f"memory index failed:\n{cp.stderr}"


def test_memory_status_reports_index(seeded_memory: Path, run_rtxclaw) -> None:
    run_rtxclaw("memory", "index", "-a", "main", timeout=60)
    cp = run_rtxclaw("memory", "status", "-a", "main", timeout=30)
    combined = cp.stdout + cp.stderr
    import re
    assert re.search(r"chunks|files|MEMORY", combined), combined


def test_memory_search_finds_seed_token(seeded_memory: Path, run_rtxclaw) -> None:
    run_rtxclaw("memory", "index", "-a", "main", timeout=60)
    cp = run_rtxclaw("memory", "search", "-a", "main", SEED_TOKEN, timeout=60)
    combined = cp.stdout + cp.stderr
    assert SEED_TOKEN in combined, f"seed token not found:\n{combined}"


# ---- README → daily → synth (real document round-trip) -----------------


@pytest.fixture
def readme_text() -> str:
    """The repo's full README — the document the operator wants the
    model to extract durable knowledge from."""
    p = Path(__file__).resolve().parent.parent / "README.md"
    return p.read_text(encoding="utf-8")


def _today_daily(agent_home: Path) -> Path:
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return agent_home / "memory" / f"{today}.md"


@pytest.fixture
def remembered_readme(running_daemon: Path,  # noqa: ARG001
                      scaffolded_agent: Path,
                      run_rtxclaw,
                      report_dir: Path,
                      readme_text: str) -> Path:
    """Send the full README via ``rtxclaw -p`` and ask the model to
    extract the durable bits into memory. Idempotent — if today's
    daily already mentions rtxclaw, we trust a prior test in the
    same session did the upload and skip re-paying the LLM cost.
    """
    daily = _today_daily(scaffolded_agent)
    if daily.is_file() and "rtxclaw" in daily.read_text(errors="replace").lower():
        return scaffolded_agent

    # Deliberately *not* telling the model to call the `remember`
    # tool. The point of this test is to verify the model identifies
    # this as durable knowledge worth saving on its own — the same
    # judgment a real agent makes when its operator drops a project
    # description into the conversation. If your model never reaches
    # for the tool here, that's the test telling you it's the wrong
    # model for an agent with persistent memory.
    prompt = (
        "Here's the README of a project I'm working on, called "
        "rtxclaw. Take a look:\n\n---\n\n" + readme_text
    )
    # Real models occasionally drop the `remember` call even with
    # SOUL.md priming. Retry up to 2x — three total attempts. Each
    # transcript is saved so a persistent miss is diagnosable.
    last_cp = None
    attempt = 0
    for attempt in range(3):
        cp = run_rtxclaw("-p", prompt, timeout=300)
        last_cp = cp
        (report_dir / f"remember_readme_attempt{attempt+1}.txt").write_text(
            f"$ rtxclaw -p <README>\nprompt_chars={len(prompt)} "
            f"attempt={attempt+1}\nexit={cp.returncode}\n"
            f"--- stdout ---\n{cp.stdout}\n"
            f"--- stderr ---\n{cp.stderr[-3000:]}"
        )
        if cp.returncode != 0:
            continue
        if daily.is_file() and "rtxclaw" in daily.read_text(errors="replace").lower():
            break
    (report_dir / "remember_readme.txt").write_text(
        f"$ rtxclaw -p <README>\nprompt_chars={len(prompt)} "
        f"final_attempt={attempt+1}\nexit={last_cp.returncode}\n"
        f"--- stdout ---\n{last_cp.stdout}\n"
        f"--- stderr ---\n{last_cp.stderr[-3000:]}"
    )
    assert last_cp.returncode == 0, f"rtxclaw -p failed:\n{last_cp.stderr[-1500:]}"
    return scaffolded_agent


@pytest.fixture
def synthesized_memory(remembered_readme: Path,
                       run_in_venv,
                       configured_endpoint: str,
                       configured_model: str,
                       report_dir: Path) -> Path:
    """Force-run ``synth_memory`` on the daily so MEMORY.md contains a
    real curated body. Idempotent: skips if MEMORY.md is already
    non-empty AND mentions rtxclaw."""
    memory_md = remembered_readme / "MEMORY.md"
    if memory_md.is_file():
        body = memory_md.read_text(errors="replace")
        if "rtxclaw" in body.lower() and len(body) > 200:
            return remembered_readme

    code = f"""\
import asyncio, json
from pathlib import Path
from rtxclaw_memory.memory_synth import synth_memory
stats = asyncio.run(synth_memory(
    Path({str(remembered_readme)!r}),
    upstream_endpoint={configured_endpoint!r},
    upstream_model={configured_model!r},
    timeout_s=180.0,
))
print(json.dumps(stats))
"""
    cp = run_in_venv(code, timeout=240)
    (report_dir / "memory_synth.txt").write_text(
        f"--- stdout ---\n{cp.stdout}\n--- stderr ---\n{cp.stderr[-3000:]}"
    )
    assert cp.returncode == 0, f"synth_memory crashed:\n{cp.stderr[-1500:]}"
    last = (cp.stdout or "").strip().splitlines()[-1] if cp.stdout.strip() else "{}"
    stats = json.loads(last)
    assert stats.get("ok") is True, f"synth not ok: {stats}"
    return remembered_readme


def test_readme_remember_writes_today_daily(remembered_readme: Path,
                                            report_dir: Path) -> None:
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    daily = remembered_readme / "memory" / f"{today}.md"
    mem_dir = remembered_readme / "memory"
    listing = sorted(p.name for p in mem_dir.glob("*")) if mem_dir.is_dir() else []

    if daily.exists():
        (report_dir / f"daily_{today}.md").write_text(daily.read_text())

    assert daily.exists(), (
        f"no daily memory file for {today} at {daily}\n"
        f"memory/ contents: {listing}"
    )
    body = daily.read_text()

    # Model paraphrases freely; assert presence of at least one of the
    # project-identifying tokens so we know the README content really
    # made it into memory rather than a stray hallucination.
    project_tokens = ("rtxclaw", "cypherpunk", "sovereign", "inference")
    assert any(tok.lower() in body.lower() for tok in project_tokens), (
        f"none of {project_tokens} found in daily {daily.name}:\n{body[:2000]}"
    )
    # Daily should have substantive content. Some models split each
    # fact into a separate bullet, others consolidate into one fat
    # bullet — both are fine. Anchor on character count + ≥1 bullet.
    bullet_count = sum(1 for ln in body.splitlines() if ln.strip().startswith("- "))
    assert bullet_count >= 1, (
        f"no bullets in daily — remember tool didn't fire:\n{body[:1500]}"
    )
    bullet_chars = sum(len(ln) for ln in body.splitlines() if ln.strip().startswith("- "))
    assert bullet_chars >= 200, (
        f"daily bullet(s) total only {bullet_chars} chars — model captured "
        f"too little from a 7 KB README:\n{body[:2000]}"
    )


def test_readme_synth_rewrites_memory_md(synthesized_memory: Path,
                                         report_dir: Path) -> None:
    """The README → daily → MEMORY.md pipeline produced something
    non-trivial. Validation is run on whatever the
    ``synthesized_memory`` fixture left behind."""
    memory_md = synthesized_memory / "MEMORY.md"
    assert memory_md.is_file(), f"MEMORY.md missing at {memory_md}"
    body = memory_md.read_text()
    (report_dir / "MEMORY_after_synth.md").write_text(body)

    placeholder = "_(empty — perishable context belongs in dailies, not here)_"
    sections_total = body.count("<!-- rtxclaw:section ")
    sections_empty = body.count(placeholder)
    assert sections_total > 0, f"MEMORY.md missing section markers:\n{body[:1500]}"
    assert sections_empty < sections_total, (
        f"all {sections_total} MEMORY.md sections came back empty — "
        f"synth filtered too aggressively. Inspect "
        f"tests/reports/<latest>/MEMORY_after_synth.md"
    )

    project_tokens = ("rtxclaw", "cypherpunk", "sovereign", "inference",
                      "RTX 3060", "RTX 4090", "agent")
    assert any(tok.lower() in body.lower() for tok in project_tokens), (
        f"none of {project_tokens} survived into MEMORY.md:\n{body[:2000]}"
    )


def test_memory_search_grounds_rtxclaw_query(synthesized_memory: Path,
                                             run_rtxclaw,
                                             report_dir: Path) -> None:
    """After the README has been remembered + synthesized, asking the
    agent ``what is rtxclaw?`` should:

    1. Trigger the model's ``memory_search`` tool — it shouldn't try to
       answer from training data when the operator's curated memory
       holds the canonical project description.
    2. Produce a response grounded in the saved memory (mentioning
       project-identifying tokens that came from the README).

    Tool-use is detected by grepping the daemon's gateway.log for
    the tool name. The response is also saved to the report so the
    developer can read what the agent actually said.
    """
    # Make sure the agent's index sees the just-synthed MEMORY.md.
    run_rtxclaw("memory", "index", "-a", "main", "--force", timeout=60)

    gw_log = synthesized_memory / "logs" / "gateway.log"
    log_size_before = gw_log.stat().st_size if gw_log.is_file() else 0

    cp = run_rtxclaw("-p", "what is rtxclaw?", timeout=180)

    log_body_after = gw_log.read_text(errors="replace") if gw_log.is_file() else ""
    log_during = log_body_after[log_size_before:] if log_body_after else ""
    (report_dir / "rtxclaw_query.txt").write_text(
        f"$ rtxclaw -p 'what is rtxclaw?'\nexit={cp.returncode}\n"
        f"--- stdout ---\n{cp.stdout}\n"
        f"--- stderr ---\n{cp.stderr[-2000:]}\n"
        f"--- gateway.log slice ---\n{log_during[-6000:]}"
    )

    assert cp.returncode == 0, f"-p query failed:\n{cp.stderr[-1500:]}"
    assert cp.stdout.strip(), "agent returned empty stdout"

    # The agent auto-injects MEMORY.md into the system context at
    # session start. So a well-grounded answer can come from EITHER:
    #   (a) the auto-injected MEMORY.md (no tool call needed), or
    #   (b) an explicit memory_search call.
    # Both are valid memory-grounded behaviour. What we require is
    # that the answer matches the curated body — if the model only
    # paraphrases its training data, the README-specific tokens
    # won't all line up.
    response = cp.stdout.lower()
    project_tokens = ("rtxclaw", "cypherpunk", "sovereign", "inference",
                      "rtx 3060", "rtx 4090", "agent", "hardware",
                      "vendor lock-in", "vast.ai")
    matches = [t for t in project_tokens if t in response]
    assert len(matches) >= 3, (
        f"response only echoed {matches} of {project_tokens} — not "
        f"enough evidence the answer is grounded in saved memory.\n"
        f"Either the model is hallucinating a generic answer, or "
        f"MEMORY.md is too sparse. Inspect the report.\n\n"
        f"response:\n{cp.stdout[:2000]}"
    )

    # Soft signal: log whether memory_search was called. This is
    # informative (lazy retrieval is fine) but not a failure.
    if "memory_search" not in log_during:
        # Annotate the report so the developer sees this happened.
        (report_dir / "rtxclaw_query.txt").write_text(
            (report_dir / "rtxclaw_query.txt").read_text(errors="replace")
            + "\n\n--- note ---\n"
            "memory_search was NOT called for this query. The model "
            "grounded its answer in the auto-injected MEMORY.md "
            "instead. Both are valid; the test passes on grounding "
            "alone.\n"
        )
