"""Step 21 — Claude Code hook engine coverage.

The hook engine in ``src/rtxclaw_core/hooks.py`` is rtxclaw's
Claude-Code-compatible hook runtime: the same ``hooks.json`` config
shape, the same event names, the same stdin-payload / exit-code /
JSON-stdout control protocol. A ``hooks.json`` written for Claude
Code (or a Claude Code plugin like everything-claude-code) must load
and run here unchanged — so this suite is the contract test for that
compatibility.

Coverage:
- ``HookEngine.load`` is fail-soft (missing file, malformed JSON,
  non-object root all yield an empty engine).
- Both config shapes load: the Claude Code settings shape
  (``{"hooks": {...}}``) and a bare event map.
- Matcher semantics: ``*`` / empty match all; otherwise a regex
  ``re.fullmatch`` (so ``Edit|Write`` does NOT match ``MultiEdit``);
  a malformed regex degrades to literal equality, never raises.
- ``run`` exit-code semantics: 0 success, 2 blocking, other
  non-blocking.
- The JSON-stdout control protocol: ``continue`` / ``decision`` /
  ``hookSpecificOutput.permissionDecision`` /
  ``hookSpecificOutput.additionalContext`` / ``systemMessage`` /
  ``suppressOutput``.
- Per-event stdout routing (UserPromptSubmit / SessionStart stdout is
  context; other events' stdout is transcript-only).
- Multi-hook folding (strongest permission wins; reasons concatenate).
- Timeout handling is fail-soft.

The async ``HookEngine.run`` is driven via ``asyncio.run`` inside
sync test functions so the suite needs no async-fixture plugin.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from rtxclaw_core.hooks import HOOK_EVENTS, HookEngine, HookOutcome


# --------------------------------------------------------------------------
# load() — fail-soft
# --------------------------------------------------------------------------

def test_load_returns_empty_when_path_missing(tmp_path: Path) -> None:
    eng = HookEngine.load(tmp_path / "missing.json")
    assert eng.is_empty()


def test_load_returns_empty_on_none_path() -> None:
    assert HookEngine.load(None).is_empty()


def test_load_returns_empty_on_malformed_json(tmp_path: Path) -> None:
    p = tmp_path / "hooks.json"
    p.write_text("{ not valid json", encoding="utf-8")
    assert HookEngine.load(p).is_empty()


def test_load_returns_empty_on_non_object_root(tmp_path: Path) -> None:
    p = tmp_path / "hooks.json"
    p.write_text(json.dumps(["not", "an", "object"]), encoding="utf-8")
    assert HookEngine.load(p).is_empty()


# --------------------------------------------------------------------------
# Both config shapes
# --------------------------------------------------------------------------

def test_loads_claude_code_settings_shape(tmp_path: Path) -> None:
    """The Claude Code shape: an object with a top-level ``hooks`` key,
    sibling keys ($schema …) ignored."""
    p = tmp_path / "hooks.json"
    p.write_text(json.dumps({
        "$schema": "https://example/schema.json",
        "hooks": {
            "PreToolUse": [
                {"matcher": "Bash", "hooks": [
                    {"type": "command", "command": "true", "timeout": 5},
                ]},
            ],
        },
    }), encoding="utf-8")
    eng = HookEngine.load(p)
    assert not eng.is_empty()
    assert eng.has_event("PreToolUse")
    assert eng.hook_count("PreToolUse") == 1


def test_loads_bare_event_map_shape() -> None:
    """A bare event map (no ``hooks`` wrapper) also loads."""
    eng = HookEngine.from_dict({
        "PostToolUse": [
            {"matcher": "*", "hooks": [{"type": "command", "command": "true"}]},
        ],
    })
    assert eng.has_event("PostToolUse")


def test_unknown_event_keys_are_ignored() -> None:
    eng = HookEngine.from_dict({
        "hooks": {
            "NotARealEvent": [
                {"matcher": "*", "hooks": [{"type": "command", "command": "true"}]},
            ],
            "Stop": [
                {"matcher": "*", "hooks": [{"type": "command", "command": "true"}]},
            ],
        },
    })
    assert eng.events() == ["Stop"]


def test_hook_type_http_is_recognized() -> None:
    """An ``http`` hook type is parsed and recorded — distinct from the
    legacy "drop everything non-command" loader."""
    eng = HookEngine.from_dict({
        "hooks": {"PreToolUse": [
            {"matcher": "*", "hooks": [
                {"type": "http", "url": "http://localhost:9/hook"},
                {"type": "command", "command": "true"},
            ]},
        ]},
    })
    # Both hooks load (http + command).
    assert eng.hook_count("PreToolUse") == 2


def test_hook_type_mcp_tool_prompt_agent_are_preserved_as_unsupported() -> None:
    """Spec-listed but unimplemented hook types (mcp_tool / prompt /
    agent) are kept in the engine so ``/doctor`` surfaces them, but
    marked unsupported and skipped at fire time with a single warning."""
    eng = HookEngine.from_dict({
        "hooks": {"PostToolUse": [
            {"matcher": "*", "hooks": [
                {"type": "mcp_tool", "tool": "memory_search"},
                {"type": "prompt", "prompt": "is this a secret?"},
                {"type": "agent", "agent": "Explore"},
                {"type": "command", "command": "true"},
            ]},
        ]},
    })
    # All four hooks load (the unsupported three are kept visible).
    assert eng.hook_count("PostToolUse") == 4


def test_hook_events_constant_is_the_claude_code_set() -> None:
    # Claude Code spec events PLUS rtxclaw turn-runtime extensions that
    # expose hardcoded recovery policies as hook decision points (loop
    # detection, premature-end nudging, distill recovery, force-terminate).
    # The extension events use the standard stdin/stdout/exit-code
    # protocol so an ECC plugin's hooks.json targets them unmodified.
    assert HOOK_EVENTS == frozenset({
        # Claude Code standard set (round 1) — 10 events
        "PreToolUse", "PostToolUse", "PostToolUseFailure", "UserPromptSubmit",
        "Notification", "Stop", "SubagentStop", "PreCompact",
        "SessionStart", "SessionEnd",
        # Claude Code spec events wired in round 2 — closes the
        # spec-compliance gap surfaced by gemini round-1 audit.
        "PostToolBatch", "UserPromptExpansion", "StopFailure",
        "SubagentStart", "Setup", "PermissionRequest", "PermissionDenied",
        "Elicitation", "ElicitationResult", "InstructionsLoaded",
        # rtxclaw extension set — turn-runtime policy decision points
        "ReasoningLoopDetected", "PrematureTurnEnd", "PrematureTurnEndGate",
        "DistillRecovery", "ForceTerminate",
        # Round 3 additions — close the remaining gemini gripes:
        # per-block preamble injector control + upstream-error
        # classifier override.
        "PreambleInject", "UpstreamError",
    })


# --------------------------------------------------------------------------
# Matcher semantics
# --------------------------------------------------------------------------

def test_matcher_star_and_empty_match_all() -> None:
    assert HookEngine._matches("*", "Bash")
    assert HookEngine._matches("", "Bash")
    assert HookEngine._matches("   ", "anything")


def test_matcher_is_a_fullmatch_regex() -> None:
    assert HookEngine._matches("Bash", "Bash")
    assert HookEngine._matches("Edit|Write", "Edit")
    assert HookEngine._matches("Edit|Write", "Write")
    # fullmatch — "Edit" must NOT match "MultiEdit" (Claude Code
    # plugins list MultiEdit explicitly; we mirror that).
    assert not HookEngine._matches("Edit", "MultiEdit")
    assert not HookEngine._matches("Bash", "BashTool")


def test_matcher_bad_regex_degrades_to_literal_equality() -> None:
    # An unclosed character class is not a valid regex — must not raise.
    assert HookEngine._matches("[unclosed", "[unclosed")
    assert not HookEngine._matches("[unclosed", "Bash")


def test_match_target_per_event() -> None:
    assert HookEngine._match_target("PreToolUse", {"tool_name": "Bash"}) == "Bash"
    assert HookEngine._match_target("SessionStart", {"source": "resume"}) == "resume"
    assert HookEngine._match_target("PreCompact", {"trigger": "manual"}) == "manual"
    assert HookEngine._match_target("Stop", {}) == ""


# --------------------------------------------------------------------------
# run() — exit-code semantics
# --------------------------------------------------------------------------

def _run(eng: HookEngine, event: str, payload: dict) -> HookOutcome:
    return asyncio.run(eng.run(event, payload))


def test_run_no_matching_hooks_is_empty_outcome() -> None:
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "Bash", "hooks": [{"type": "command", "command": "true"}]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Read"})
    assert out.ran == 0 and not out.blocked and not out.has_effect


def test_run_exit_0_is_success() -> None:
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "*", "hooks": [{"type": "command", "command": "exit 0"}]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.ran == 1 and not out.blocked


def test_run_exit_2_blocks_and_feeds_stderr_back() -> None:
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "Bash", "hooks": [
            {"type": "command", "command": "echo 'nope: rm -rf' >&2; exit 2"},
        ]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.blocked
    assert "nope: rm -rf" in out.block_reason
    # exit-2 on PreToolUse is a deny.
    assert out.permission_decision == "deny"


def test_run_other_exit_code_is_non_blocking() -> None:
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "*", "hooks": [
            {"type": "command", "command": "echo warn >&2; exit 1"},
        ]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.ran == 1
    assert not out.blocked              # exit 1 != 2 => non-blocking
    assert out.should_continue


# --------------------------------------------------------------------------
# stdin payload — the event reaches the hook as JSON on stdin
# --------------------------------------------------------------------------

def test_event_payload_is_piped_as_json_on_stdin() -> None:
    # The hook echoes back fields it received on stdin.
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": "python3 -c \"import sys,json; "
                       "d=json.load(sys.stdin); "
                       "print(d['hook_event_name'], d['tool_name'])\"",
        }]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Bash", "tool_input": {"command": "ls"}})
    # PreToolUse stdout is transcript-only (not context).
    assert out.stdout_blocks == ["PreToolUse Bash"]


# --------------------------------------------------------------------------
# stdout routing — context vs transcript
# --------------------------------------------------------------------------

def test_user_prompt_submit_stdout_becomes_context() -> None:
    eng = HookEngine.from_dict({"hooks": {"UserPromptSubmit": [
        {"matcher": "*", "hooks": [
            {"type": "command", "command": "echo 'remember: be terse'"},
        ]},
    ]}})
    out = _run(eng, "UserPromptSubmit", {"prompt": "hi"})
    assert out.additional_context == "remember: be terse"
    assert out.stdout_blocks == []


def test_pre_tool_use_stdout_is_transcript_only() -> None:
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "*", "hooks": [{"type": "command", "command": "echo noted"}]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.additional_context == ""
    assert out.stdout_blocks == ["noted"]


# --------------------------------------------------------------------------
# JSON stdout control protocol
# --------------------------------------------------------------------------

def _json_hook(event: str, payload_json: str, *, matcher: str = "*") -> HookEngine:
    return HookEngine.from_dict({"hooks": {event: [
        {"matcher": matcher, "hooks": [
            {"type": "command", "command": f"printf '%s' '{payload_json}'"},
        ]},
    ]}})


def test_json_permission_decision_deny() -> None:
    eng = _json_hook("PreToolUse", json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": "writes outside workspace",
        },
    }))
    out = _run(eng, "PreToolUse", {"tool_name": "Write"})
    assert out.permission_decision == "deny"
    assert out.blocked
    assert "outside workspace" in out.block_reason


def test_json_permission_decision_ask() -> None:
    eng = _json_hook("PreToolUse", json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse", "permissionDecision": "ask",
        },
    }))
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.permission_decision == "ask"
    assert not out.blocked


def test_json_decision_block() -> None:
    eng = _json_hook("PostToolUse", json.dumps({
        "decision": "block", "reason": "lint failed",
    }))
    out = _run(eng, "PostToolUse", {"tool_name": "Edit"})
    assert out.blocked and out.block_reason == "lint failed"


def test_json_additional_context() -> None:
    eng = _json_hook("UserPromptSubmit", json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": "the repo uses pnpm, not npm",
        },
    }))
    out = _run(eng, "UserPromptSubmit", {"prompt": "install deps"})
    assert out.additional_context == "the repo uses pnpm, not npm"


def test_json_continue_false_halts() -> None:
    eng = _json_hook("Stop", json.dumps({
        "continue": False, "stopReason": "budget exhausted",
    }))
    out = _run(eng, "Stop", {"stop_hook_active": False})
    assert not out.should_continue
    assert out.stop_reason == "budget exhausted"


def test_json_system_message_and_suppress_output() -> None:
    eng = _json_hook("PostToolUse", json.dumps({
        "systemMessage": "heads up: slow test suite",
        "suppressOutput": True,
    }))
    out = _run(eng, "PostToolUse", {"tool_name": "Bash"})
    assert out.system_messages == ["heads up: slow test suite"]
    assert out.suppress_output


# --------------------------------------------------------------------------
# Multi-hook folding
# --------------------------------------------------------------------------

def test_multiple_hooks_strongest_permission_wins() -> None:
    """allow + ask + deny across three hooks => deny (strongest)."""
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "*", "hooks": [
            {"type": "command", "command":
             "printf '%s' '{\"hookSpecificOutput\":"
             "{\"permissionDecision\":\"allow\"}}'"},
        ]},
        {"matcher": "*", "hooks": [
            {"type": "command", "command":
             "printf '%s' '{\"hookSpecificOutput\":"
             "{\"permissionDecision\":\"ask\"}}'"},
        ]},
        {"matcher": "Bash", "hooks": [
            {"type": "command", "command":
             "printf '%s' '{\"hookSpecificOutput\":"
             "{\"permissionDecision\":\"deny\"}}'"},
        ]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.ran == 3
    assert out.permission_decision == "deny"
    assert out.blocked


# --------------------------------------------------------------------------
# Timeout — fail-soft
# --------------------------------------------------------------------------

def test_timeout_is_non_blocking_and_fail_soft() -> None:
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "*", "hooks": [
            {"type": "command", "command": "sleep 5", "timeout": 1},
        ]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    # A timeout is a non-blocking error — the turn proceeds.
    assert out.ran == 1
    assert not out.blocked
    assert out.results[0].timed_out


# --------------------------------------------------------------------------
# Event-specific exit-2 / decision / additionalContext gating
# --------------------------------------------------------------------------

def test_exit_2_on_non_block_capable_event_does_not_block() -> None:
    """Exit 2 only flips ``blocked`` for block-capable events. On
    SessionStart it just surfaces stderr (Claude Code behaviour)."""
    eng = HookEngine.from_dict({"hooks": {"SessionStart": [
        {"matcher": "*", "hooks": [
            {"type": "command", "command": "echo 'env not ready' >&2; exit 2"},
        ]},
    ]}})
    out = asyncio.run(eng.run("SessionStart", {"source": "startup"}))
    assert out.ran == 1
    assert not out.blocked                         # SessionStart can't block
    assert "env not ready" in out.block_reason     # …but the message is kept


def test_pre_tool_use_decision_block_denies() -> None:
    """The deprecated ``decision: block`` form on PreToolUse denies
    the tool (distinct from the modern permissionDecision path)."""
    eng = _json_hook("PreToolUse", json.dumps({
        "decision": "block", "reason": "path escapes the workspace",
    }))
    out = _run(eng, "PreToolUse", {"tool_name": "Write"})
    assert out.blocked
    assert out.permission_decision == "deny"
    assert "escapes the workspace" in out.block_reason


def test_additional_context_ignored_for_non_context_event() -> None:
    """``additionalContext`` only reaches the model for
    UserPromptSubmit / SessionStart / PostToolUse — a PreToolUse hook
    emitting it is ignored."""
    eng = _json_hook("PreToolUse", json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "additionalContext": "this should not be injected",
        },
    }))
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.additional_context == ""


# --------------------------------------------------------------------------
# is_empty / introspection
# --------------------------------------------------------------------------

def test_introspection_helpers() -> None:
    eng = HookEngine.from_dict({"hooks": {
        "PreToolUse": [
            {"matcher": "Bash", "hooks": [{"type": "command", "command": "true"}]},
            {"matcher": "Edit", "hooks": [{"type": "command", "command": "true"}]},
        ],
        "Stop": [
            {"matcher": "*", "hooks": [{"type": "command", "command": "true"}]},
        ],
    }})
    assert not eng.is_empty()
    assert eng.events() == ["PreToolUse", "Stop"]
    assert eng.hook_count("PreToolUse") == 2
    assert eng.hook_count() == 3
    assert eng.has_event("Stop") and not eng.has_event("Notification")


def test_real_everything_claude_code_hooks_json_loads() -> None:
    """The everything-claude-code plugin's own ``hooks.json`` — the
    canonical real-world Claude Code hook config — must load cleanly
    if it is installed on this host."""
    ecc = Path.home() / ".rtxclaw" / "ecc" / "hooks" / "hooks.json"
    if not ecc.is_file():
        pytest.skip("everything-claude-code not installed on this host")
    eng = HookEngine.load(ecc)
    assert not eng.is_empty()
    # ECC ships PreToolUse + PostToolUse + Stop at least.
    for ev in ("PreToolUse", "PostToolUse", "Stop"):
        assert eng.has_event(ev), f"ECC hooks.json missing {ev}"


# --------------------------------------------------------------------------
# rtxclaw turn-runtime extension events — match-targets + protocol parity
# --------------------------------------------------------------------------

def test_match_target_for_extension_events() -> None:
    # Each extension event surfaces a per-event match target so an ECC
    # plugin can scope its hooks (e.g. fire only on tight-loop tier).
    assert HookEngine._match_target(
        "ReasoningLoopDetected", {"tier": "tight"},
    ) == "tight"
    assert HookEngine._match_target(
        "PrematureTurnEnd", {"kind": "cutoff"},
    ) == "cutoff"
    # SubagentStop matches on the child agent name.
    assert HookEngine._match_target(
        "SubagentStop", {"subagent_name": "codex"},
    ) == "codex"
    # SessionEnd matches on reason.
    assert HookEngine._match_target(
        "SessionEnd", {"reason": "close_session"},
    ) == "close_session"
    # Notification matches on kind.
    assert HookEngine._match_target(
        "Notification", {"kind": "loop-detected"},
    ) == "loop-detected"


def test_extension_events_are_block_capable() -> None:
    """A ``decision: block`` from a ReasoningLoopDetected hook flips
    ``outcome.blocked`` so the turn runtime knows to suppress the
    default cascade. Same for PrematureTurnEnd / DistillRecovery /
    ForceTerminate — they're the override hooks for hardcoded policies."""
    for ev in (
        "ReasoningLoopDetected",
        "PrematureTurnEnd",
        "DistillRecovery",
        "ForceTerminate",
    ):
        eng = _json_hook(ev, json.dumps({
            "decision": "block", "reason": "operator says skip",
        }))
        out = _run(eng, ev, {"tier": "tight"})
        assert out.blocked, f"{ev} must be block-capable"
        assert "operator says skip" in out.block_reason


def test_reasoning_loop_detected_matcher_scopes_by_tier() -> None:
    """A matcher of ``tight`` fires only on tight-loop detections,
    not on ``ngram`` / ``entropy`` / ``ratio``."""
    eng = HookEngine.from_dict({"hooks": {"ReasoningLoopDetected": [
        {"matcher": "tight", "hooks": [
            {"type": "command", "command": "exit 0"},
        ]},
    ]}})
    fired = _run(eng, "ReasoningLoopDetected", {"tier": "tight"})
    skipped = _run(eng, "ReasoningLoopDetected", {"tier": "ngram"})
    assert fired.ran == 1
    assert skipped.ran == 0


# --------------------------------------------------------------------------
# PreToolUse `updatedInput` — hook rewrites tool args before dispatch
# --------------------------------------------------------------------------

def test_pre_tool_use_updated_input_is_captured() -> None:
    """A PreToolUse hook can emit ``hookSpecificOutput.updatedInput``
    to rewrite the model's tool args (e.g. inject a safety flag into a
    Bash command). The outcome surfaces it as ``updated_input`` so the
    turn runtime can swap the args in place before dispatch."""
    eng = _json_hook("PreToolUse", json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "updatedInput": {"command": "rm -rfI /tmp/safe"},
        },
    }))
    out = _run(eng, "PreToolUse", {
        "tool_name": "Bash",
        "tool_input": {"command": "rm -rf /tmp/safe"},
    })
    assert out.updated_input == {"command": "rm -rfI /tmp/safe"}
    assert out.has_effect


def test_pre_tool_use_updated_input_non_dict_is_ignored() -> None:
    """A malformed ``updatedInput`` (string / null / list) doesn't
    crash; it's silently dropped so the runner sees the original args."""
    eng = _json_hook("PreToolUse", json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "updatedInput": "this should be a dict",
        },
    }))
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.updated_input is None


def test_http_hook_posts_stdin_payload_and_folds_response() -> None:
    """An ``http``-type hook POSTs the stdin JSON to its URL and the
    HTTP response body is folded into the outcome exactly like a
    command-type hook's stdout."""
    import http.server
    import json as _json
    import threading

    received: dict = {}

    class _Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args, **kwargs):  # quiet test output
            return

        def do_POST(self):  # noqa: N802 - http.server uppercase convention
            length = int(self.headers.get("Content-Length") or 0)
            payload = self.rfile.read(length).decode("utf-8") if length else ""
            received["payload"] = payload
            received["method"] = "POST"
            received["headers"] = dict(self.headers)
            body = _json.dumps({
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": "http-hook said no",
                },
            })
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body.encode("utf-8"))

    srv = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
    port = srv.server_address[1]
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
            {"matcher": "*", "hooks": [{
                "type": "http",
                "url": f"http://127.0.0.1:{port}/hook",
                "timeout": 5,
            }]},
        ]}})
        out = _run(eng, "PreToolUse", {
            "tool_name": "Bash",
            "tool_input": {"command": "rm -rf /"},
        })
        assert out.ran == 1
        assert out.permission_decision == "deny", (
            "http hook's JSON response must drive the permission decision"
        )
        assert "http-hook said no" in out.block_reason
        # The server saw the rtxclaw stdin payload with the standard
        # fields (session_id / cwd / hook_event_name).
        sent = _json.loads(received["payload"])
        assert sent["hook_event_name"] == "PreToolUse"
        assert sent["tool_name"] == "Bash"
    finally:
        srv.shutdown()
        t.join(timeout=2.0)


def test_http_hook_5xx_is_non_blocking_error() -> None:
    """HTTP 5xx from an ``http`` hook is treated as exit-1 (non-blocking)
    so a flaky webhook doesn't take the turn down."""
    import http.server
    import threading

    class _Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args, **kwargs):
            return

        def do_POST(self):  # noqa: N802
            self.send_response(500)
            self.send_header("Content-Length", "0")
            self.end_headers()

    srv = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
    port = srv.server_address[1]
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
            {"matcher": "*", "hooks": [{
                "type": "http",
                "url": f"http://127.0.0.1:{port}/hook",
                "timeout": 5,
            }]},
        ]}})
        out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
        assert out.ran == 1
        # HTTP 5xx → exit 1 (non-blocking error). Not a deny.
        assert not out.blocked
        assert out.permission_decision == ""


    finally:
        srv.shutdown()
        t.join(timeout=2.0)


def test_pre_tool_use_updated_input_last_writer_wins() -> None:
    """When multiple PreToolUse hooks emit ``updatedInput``, the last
    one wins so chained linter-style mutators can compose in
    declaration order."""
    eng = HookEngine.from_dict({"hooks": {"PreToolUse": [
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": "printf '%s' '{\"hookSpecificOutput\":"
                       "{\"updatedInput\":{\"step\":\"first\"}}}'",
        }]},
        {"matcher": "*", "hooks": [{
            "type": "command",
            "command": "printf '%s' '{\"hookSpecificOutput\":"
                       "{\"updatedInput\":{\"step\":\"second\"}}}'",
        }]},
    ]}})
    out = _run(eng, "PreToolUse", {"tool_name": "Bash"})
    assert out.updated_input == {"step": "second"}
