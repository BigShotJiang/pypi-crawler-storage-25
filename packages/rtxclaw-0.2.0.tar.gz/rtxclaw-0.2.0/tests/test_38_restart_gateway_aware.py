"""Step 38 — `/restart` resolution under the single-process gateway.

The Telegram bot, the TUI, and the CLI all collapse ``/restart`` to
``rtxclaw_core.restart.restart_agent_detached(agent_name)``. The
single-process gateway (``rtxclaw gateway-serve``) is the only
deployed model — the legacy "one daemon per agent" path
(``rtxclaw.service`` for ``main``, ``rtxclaw-<name>.service`` for
others) has been retired, and ``restart.py`` no longer probes for
those units.

These tests pin the resolution order:

  1. ``rtxclaw-gateway.service`` is loaded and active →
     ``sudo -n systemctl restart rtxclaw-gateway.service``.
  2. No systemd unit, gateway alive (``$RTXCLAW_HOME/gateway.pid``
     ⇒ live pid) → ``rtxclaw_agent gateway restart``.
  3. No systemd unit, gateway not running →
     ``rtxclaw_agent gateway start`` (start as restart).

Plus the must-fall-through cases: stale pidfile, garbage pidfile.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

from rtxclaw_core import restart as _restart_mod
from rtxclaw_core.restart import (
    _build_restart_command,
    _gateway_running,
)


# ---- helpers -------------------------------------------------------


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Pin ``$RTXCLAW_HOME`` to a tmpdir so gateway-pidfile lookups
    don't read the real ``~/.rtxclaw/gateway.pid``.

    Also writes a minimal ``config.json`` whose ``gateway`` block
    points at an unbound port (``127.0.0.1:1``) so the HTTP-fallback
    inside ``_gateway_running`` never accidentally reaches a real
    gateway running on the dev host. Without this, the tests that
    assert "gateway not running" would flake on machines where
    ``rtxclaw-gateway.service`` is up.

    Also pins ``_systemd_managed`` to False so the non-systemd
    branches of ``_build_restart_command`` are exercised by default
    — the systemd-managed branch has its own dedicated tests below
    that opt back in explicitly. Without this, a dev box with the
    unit installed would steer every assertion into the systemd
    arm and the gateway/start coverage would silently lapse.
    """
    import json as _json
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    monkeypatch.setattr(_restart_mod, "_systemd_managed", lambda: False)
    (tmp_path).mkdir(parents=True, exist_ok=True)
    (tmp_path / "config.json").write_text(_json.dumps({
        "gateway": {"host": "127.0.0.1", "port": 1},
    }))
    return tmp_path


def _write_live_gateway_pidfile(home: Path) -> None:
    """Write our own pid into ``<home>/gateway.pid`` — guaranteed
    alive (we're running) so ``_gateway_running()`` returns True."""
    home.mkdir(parents=True, exist_ok=True)
    (home / "gateway.pid").write_text(str(os.getpid()))


def _synthesize_dead_pid() -> int:
    """Return a pid that's definitely not running on this kernel.

    Walks down from a high number until ``os.kill(pid, 0)`` raises
    ``ProcessLookupError``. PID 1 is a poor stale stand-in (always
    alive), so we use a high pid that isn't ours and isn't init.
    """
    candidate = 2_000_000_000
    while True:
        try:
            os.kill(candidate, 0)
        except ProcessLookupError:
            return candidate
        except PermissionError:  # pragma: no cover — safety net
            candidate -= 1
            continue
        candidate -= 1
        if candidate <= 0:  # pragma: no cover
            pytest.skip("can't synthesize a stale pid on this kernel")


# ---- _gateway_running ---------------------------------------------


def test_gateway_running_false_when_pidfile_missing(fake_home: Path) -> None:
    assert not (fake_home / "gateway.pid").exists()
    assert _gateway_running() is False


def test_gateway_running_true_for_live_pid(fake_home: Path) -> None:
    _write_live_gateway_pidfile(fake_home)
    assert _gateway_running() is True


def test_gateway_running_false_for_stale_pidfile(fake_home: Path) -> None:
    """An exited pid → treat as not running so callers fall through to
    the gateway-start path."""
    fake_home.mkdir(parents=True, exist_ok=True)
    (fake_home / "gateway.pid").write_text(str(_synthesize_dead_pid()))
    assert _gateway_running() is False


def test_gateway_running_false_for_garbage_pidfile(fake_home: Path) -> None:
    fake_home.mkdir(parents=True, exist_ok=True)
    (fake_home / "gateway.pid").write_text("not a number\n")
    assert _gateway_running() is False


# ---- _build_restart_command — gateway-mode ------------------------


def test_gateway_alive_dispatches_gateway_restart(
    fake_home: Path,
) -> None:
    """Live gateway → ``rtxclaw_agent gateway restart``. The unit name
    in the result is the gateway service identifier, never the
    legacy per-agent unit."""
    _write_live_gateway_pidfile(fake_home)

    cmd, mode, unit = _build_restart_command("scraper")
    assert mode == "gateway"
    assert unit == "rtxclaw-gateway"
    assert "gateway restart" in cmd
    assert "rtxclaw_agent" in cmd
    # No reference to retired per-agent units.
    assert "rtxclaw-scraper.service" not in cmd
    assert "rtxclaw.service" not in cmd
    assert "systemctl" not in cmd


def test_gateway_alive_dispatches_gateway_restart_for_main(
    fake_home: Path,
) -> None:
    """Same path for ``main`` — the agent name is informational
    (gateway restart cascades to every child) but must not leak the
    legacy ``rtxclaw.service`` unit name."""
    _write_live_gateway_pidfile(fake_home)

    cmd, mode, _unit = _build_restart_command("main")
    assert mode == "gateway"
    assert "systemctl" not in cmd
    assert "rtxclaw.service" not in cmd


def test_gateway_command_uses_current_python_executable(
    fake_home: Path,
) -> None:
    """Quoting the running interpreter avoids a PATH-shadowing bug
    where a venv-bound bot picks up a different ``python3`` than the
    one the gateway daemon was launched with."""
    _write_live_gateway_pidfile(fake_home)

    cmd, _mode, _unit = _build_restart_command("scraper")
    assert sys.executable in cmd


# ---- _build_restart_command — gateway-not-running -------------


def test_no_gateway_dispatches_gateway_start(
    fake_home: Path,
) -> None:
    """No pidfile → ``gateway start`` (start-as-restart). User-facing
    effect is the same: agent comes back up. Mode tag distinguishes
    the path so frontends can render a slightly different message
    if they want."""
    assert not (fake_home / "gateway.pid").exists()
    cmd, mode, unit = _build_restart_command("scraper")
    assert mode == "gateway-start"
    assert unit == "rtxclaw-gateway"
    assert "gateway start" in cmd
    assert "systemctl" not in cmd


def test_stale_gateway_pidfile_falls_through_to_gateway_start(
    fake_home: Path,
) -> None:
    """Crashed gateway (pidfile present, pid dead) must not trap
    callers in the no-op branch — fall through to gateway-start so
    the bounce-as-start UX still works."""
    fake_home.mkdir(parents=True, exist_ok=True)
    (fake_home / "gateway.pid").write_text(str(_synthesize_dead_pid()))

    cmd, mode, _unit = _build_restart_command("scraper")
    assert mode == "gateway-start"
    assert "gateway start" in cmd


# ---- _build_restart_command — systemd-managed -----------------


def test_systemd_active_dispatches_systemctl_restart(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Loaded+active systemd unit → ``sudo -n systemctl restart``.
    Must take precedence even if the pidfile points at a live pid:
    routing through the in-process daemonizer while systemd is also
    managing the unit creates an orphan that wins the bind race —
    the bug reproduced 2026-05-11.
    """
    monkeypatch.setattr(_restart_mod, "_systemd_managed", lambda: True)
    _write_live_gateway_pidfile(fake_home)  # would otherwise win

    cmd, mode, unit = _build_restart_command("scraper")
    assert mode == "systemd"
    assert unit == "rtxclaw-gateway"
    assert "systemctl restart rtxclaw-gateway.service" in cmd
    assert "sudo -n " in cmd
    # The in-process daemonizer must not be referenced — that's the
    # path that orphans get spawned on.
    assert "rtxclaw_agent gateway" not in cmd
    assert "gateway-serve" not in cmd


def test_systemd_active_overrides_no_pidfile(
    fake_home: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Systemd takes precedence even with no pidfile — we trust the
    unit over our own state file. Without this, a missing pidfile
    (which happens after a clean restart) would fall through to
    ``gateway start`` and race systemd."""
    monkeypatch.setattr(_restart_mod, "_systemd_managed", lambda: True)
    assert not (fake_home / "gateway.pid").exists()

    cmd, mode, _unit = _build_restart_command("main")
    assert mode == "systemd"
    assert "systemctl restart" in cmd


# NOTE: the bot's /restart no longer composes its reply from
# ``restart_agent_detached``'s return value. The reply is hard-coded
# in ``rtxclaw_telegram.bot`` (``♻ restarting rtxclaw gateway. …``)
# because under the single-process model every restart bounces the
# same target — no per-mode rendering needed.
