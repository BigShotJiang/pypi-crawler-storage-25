"""Step 05 — TUI smoke + interactive plan-mode round-trip.

Launches the TUI in plan mode against a running agent, asserts the
chrome rendered, sends a real "list files" prompt, and waits for the
model's response to land in the pane. The captured pane (after the
response) is written to the active report directory.

Plan mode is verified two ways:
- the launcher is invoked with ``--plan``
- the status footer reports ``mode: plan``

The model on the other end is whatever ``configured_endpoint`` points
at (TB07 by default for this checkout).
"""
from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path

import pytest

from conftest import RTXCLAW_BIN


def _capture(session: str, scrollback: int = 2000) -> str:
    """Grab the pane *plus* a generous scrollback window so anything
    Textual scrolled off the visible area still lands in the report."""
    cp = subprocess.run(
        ["tmux", "capture-pane", "-t", session, "-p", "-J",
         "-S", f"-{scrollback}"],
        capture_output=True, text=True, timeout=10,
    )
    return cp.stdout if cp.returncode == 0 else ""


def _is_streaming(pane: str) -> bool:
    """Footer flips between 'main idle' and 'main ▶ streaming…' while
    a turn is in flight. Anchor strictly on the streaming arrow + the
    word 'streaming' — 'thinking=on' is a session-wide setting, not a
    turn-state indicator, and matching it produces false positives."""
    p = pane.lower()
    return "▶ streaming" in p or "streaming…" in p


def _is_done(pane: str) -> bool:
    """Footer carries the agent name + an idle marker once the model
    finishes the turn.

    The per-turn ``done`` summary moved into the per-message metrics
    widget INSIDE the chat history (``─ gpu-a/qwen3 · prefill … · gen
    … tok/s · in N tok``), not the bottom status bar. The footer now
    reads ``idle  ·  agent main  ·  mode: plan  ·  ctx …`` once the
    turn settles. We anchor on ``agent <name>`` + ``idle`` (present
    in every layout the codebase has shipped) and treat absence of
    the streaming arrow as the readiness signal — the metrics line
    proves the turn returned, but a long reply pushes it out of the
    captured pane window so we can't pin on it.
    """
    p = pane.lower()
    if "agent main" not in p or "idle" not in p:
        return False
    return "▶ streaming" not in p and "streaming…" not in p


def _send_text(session: str, text: str) -> None:
    """Type ``text`` and press Enter in the tmux pane."""
    subprocess.run(["tmux", "send-keys", "-t", session, text], check=True)
    # Tiny pause so the input widget settles before Enter.
    time.sleep(0.2)
    subprocess.run(["tmux", "send-keys", "-t", session, "Enter"], check=True)


@pytest.fixture
def tmux_session(require_tmux: str, bootstrapped_venv: Path,  # noqa: ARG001
                 sandbox_env, scaffolded_agent: Path, running_daemon: Path):  # noqa: ARG001
    """Headless TUI launched in plan mode against the running daemon."""
    name = f"rtxclaw-test-{os.getpid()}"
    cp = subprocess.run(
        ["tmux", "new-session", "-d", "-s", name,
         "-c", str(RTXCLAW_BIN.parent), "-x", "200", "-y", "50",
         str(RTXCLAW_BIN), "--plan"],
        env=sandbox_env, capture_output=True, text=True,
    )
    if cp.returncode != 0:
        pytest.fail(f"tmux new-session failed (rc={cp.returncode}):\n{cp.stderr}")
    try:
        yield name
    finally:
        subprocess.run(["tmux", "kill-session", "-t", name],
                       capture_output=True)


def test_tui_renders_in_plan_mode(tmux_session: str, report_dir: Path) -> None:
    """First half: chrome renders, plan mode visible in status footer.

    The Textual ``MessageInput`` no longer ships with a placeholder
    string, so the chrome-readiness signal is the bottom status
    footer (``mode:`` token) plus the title bar (``rtxclaw —`` /
    ``AgentChatApp`` cold-start fallback). A bare ``>`` prompt
    column is also drawn but it's a one-character marker and harder
    to anchor a substring search against, so we use the footer.
    """
    pane = ""
    deadline = time.time() + 30
    while time.time() < deadline:
        pane = _capture(tmux_session)
        if "mode:" in pane.lower():
            break
        time.sleep(0.5)
    (report_dir / "tui_pane_initial.txt").write_text(pane or "(empty)")

    assert pane, "tmux capture-pane returned empty"
    assert "mode:" in pane.lower(), (
        f"status footer missing — TUI chrome didn't render:\n{pane[-500:]}"
    )
    assert "mode: plan" in pane.lower(), \
        f"plan mode not visible in status footer:\n{pane[-500:]}"
    assert ("AgentChatApp" in pane) or ("rtxclaw" in pane.lower()), \
        f"neither cold-start nor running title found:\n{pane[-500:]}"


def test_tui_lists_files_in_plan_mode(tmux_session: str, report_dir: Path) -> None:
    """Second half: send 'list files', wait for the streaming indicator
    to clear, then capture the *complete* response.

    Plan mode is read-only — the model reasons about how it would
    answer without invoking write tools, but it should still produce
    a non-trivial response that mentions files / directories. The
    capture is taken AFTER the footer flips from ``▶ streaming…``
    back to ``idle`` so the saved pane shows the full reply, not a
    half-painted frame.
    """
    # Wait for chrome — both the status footer's ``mode:`` token AND
    # an agent-connected signal (``ctx <int>/<int>`` or
    # ``model tb…``). Without the agent-up check we'd race the TUI's
    # ACP bootstrap and the prompt would get dropped on the floor:
    # ``_send_text`` types into a TextArea whose submit binding isn't
    # wired yet, so Enter inserts a newline instead of firing
    # ``action_submit``. Symptom in the captured pane: ``> list
    # files`` lingers in the input box and the model never streams.
    pane = ""
    deadline = time.time() + 30
    while time.time() < deadline:
        pane = _capture(tmux_session)
        p = pane.lower()
        chrome_ready = "mode:" in p
        # Agent connected when the status footer carries a model
        # name (``model <alias>/<id>``) — the cold-start fallback
        # leaves it as ``model -`` until the ACP client identifies.
        agent_up = "model tb" in p or "model qwen" in p
        if chrome_ready and agent_up:
            break
        time.sleep(0.5)
    initial_len = len(pane)

    _send_text(tmux_session, "list files")

    # 1) Wait for the streaming indicator to APPEAR or the user-echo
    #    UserMessage to land in the chat history (``❯ list files``).
    #    The bare-text-in-input check (``"list files" in pane``) is
    #    too weak: the typed-but-unsubmitted prompt also matches.
    deadline = time.time() + 30
    streaming_seen = False
    while time.time() < deadline:
        pane = _capture(tmux_session)
        if _is_streaming(pane) or "❯ list files" in pane:
            streaming_seen = True
            break
        time.sleep(0.5)

    # 2) Wait for streaming to CLEAR and the 'done' marker to appear.
    #    Hard cap at 120s — anything slower than that is the model
    #    hung or generating an unbounded response, and the TUI smoke
    #    test isn't the right place to sit on it.
    deadline = time.time() + 120
    last_len = -1
    quiet_since = time.time()
    while time.time() < deadline:
        pane = _capture(tmux_session)
        if _is_done(pane) and not _is_streaming(pane):
            break
        if len(pane) == last_len:
            if time.time() - quiet_since > 30:
                break  # stuck render; take what we've got
        else:
            last_len = len(pane)
            quiet_since = time.time()
        time.sleep(15)

    # 3) Take a few snapshots back-to-back and pick the most informative
    #    one. Textual occasionally redraws right when we capture, so
    #    a single snap can land mid-frame with the chat history blanked
    #    out. Prefer the longest snapshot that contains a response
    #    marker — the user's typed text is NOT preserved in the chat
    #    log (the TUI clears the input area after submit), so we anchor
    #    on the assistant's reply instead.
    response_markers = ("Thought for", "▶ ✓", "▶ ✅", "directory", "Entry")
    candidates: list[str] = []
    for _ in range(4):
        candidates.append(_capture(tmux_session))
        time.sleep(0.5)
    with_response = [p for p in candidates if any(m in p for m in response_markers)]
    pane = max(with_response or candidates, key=len)

    (report_dir / "tui_pane.txt").write_text(pane or "(empty)")

    # The pane is a fixed-size grid (200 cols × 50 rows ≈ 8400 chars
    # regardless of content), so a string-length comparison will never
    # show "growth". Anchor on real content signals instead: response
    # markers + non-blank-line count.
    nonblank = sum(1 for line in pane.splitlines() if line.strip())

    assert streaming_seen, (
        f"model never started streaming in response to 'list files'\n"
        f"pane tail:\n{pane[-1000:]}"
    )
    assert _is_done(pane), (
        f"'main idle' / 'done' markers missing — turn didn't finish?\n"
        f"pane tail:\n{pane[-1000:]}"
    )
    assert any(m in pane for m in response_markers), (
        f"no assistant response marker {response_markers} in pane:\n"
        f"{pane[-1500:]}"
    )
    assert nonblank >= 8, (
        f"pane has only {nonblank} non-blank lines — response too thin"
    )
