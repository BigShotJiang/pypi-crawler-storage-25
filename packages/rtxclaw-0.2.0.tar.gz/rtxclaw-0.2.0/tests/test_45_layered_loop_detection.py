from __future__ import annotations

from rtxclaw_core.turn_runtime import (
    _detect_entropy_collapse,
    _detect_loops_layered,
    _detect_tight_loop,
)


def _unique_pad(n: int) -> str:
    alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    out: list[str] = []
    i = 0
    while len("".join(out)) < n:
        out.append(alphabet[i % len(alphabet):] + alphabet[:i % len(alphabet)])
        i += 1
    return "".join(out)[:n]


def test_tight_loop_catches_short_token_collapse() -> None:
    buf = _unique_pad(96) + "la la la " * 16
    hit = _detect_tight_loop(buf)
    assert hit is not None
    assert "la" in hit


def test_tight_loop_ignores_markdown_rule_noise() -> None:
    buf = _unique_pad(96) + "=" * 120
    assert _detect_tight_loop(buf) is None


def test_entropy_detector_catches_low_entropy_multichar_loop() -> None:
    buf = ("abcx " * 50) + ("xyza " * 50)
    hit = _detect_entropy_collapse(buf)
    assert hit is not None
    assert hit.startswith("H=")


def test_entropy_detector_ignores_single_character_rules() -> None:
    assert _detect_entropy_collapse("=" * 240) is None


def test_layered_detector_reports_tight_before_entropy() -> None:
    hit = _detect_loops_layered(_unique_pad(96) + "tokenxyz " * 20)
    assert hit is not None
    tier, evidence = hit
    assert tier == "tight"
    assert evidence
