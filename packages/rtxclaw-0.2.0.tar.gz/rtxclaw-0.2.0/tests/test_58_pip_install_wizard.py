"""Step 58 — the three-step user story: ``pip install`` → ``rtxclaw`` → wizard → done.

Every other test in this suite drives the in-repo ``./rtxclaw`` launcher
(the ``git clone && ./rtxclaw`` path). This one validates the OTHER
supported path — the one a stranger on the internal LAN actually
takes:

    1. pip install rtxclaw          (here: ``pip install /app`` — the
                                     repo's pyproject.toml, same build
                                     a git+https install resolves)
    2. rtxclaw                      (bare command → first-run wizard)
    3. answer the wizard            (driven through tmux, like a human)
    -> done: the gateway is up and the TUI is on screen.

It is deliberately heavyweight: a real isolated venv, a real
dependency resolve, a real PTY. It is the regression guard for
"setup got hard again" — specifically:

  * the ``rtxclaw`` console script the wheel installs actually runs;
  * the first-run wizard ends by getting the gateway LIVE itself
    (``_offer_gateway_service``) instead of dumping a ``systemctl``
    to-do on the operator;
  * the TUI then connects — i.e. the gateway-port the TUI dials and
    the port the gateway binds AGREE (the :20100-vs-:7700 mismatch
    that made a fresh install fail with "connection refused").

systemd is not PID 1 in this container, so the wizard's service step
takes its no-systemd branch and starts the gateway in the background
— exactly what a containerised / sandboxed install does. The
systemd-unit branch is covered by ``rtxclaw_agent.gateway_cli``'s unit
tests; it can't be exercised from inside this image.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import time
from pathlib import Path

import pytest

from conftest import REPO_ROOT


# The repo is baked into the test image at /app (see Dockerfile.test:
# ``COPY . /app``). When pytest is run directly from a checkout instead,
# fall back to REPO_ROOT so the test is still launchable for debugging.
_APP_DIR = Path("/app") if Path("/app/pyproject.toml").is_file() else REPO_ROOT

# The gateway binds its default :20100 — the wizard writes a fresh
# config.json with no ``gateway`` block, and `_gateway_config()`
# defaults host/port. The TUI reads the SAME default, which is the
# whole point of the port-mismatch fix this branch ships. There is no
# per-worker port to pin: ``test_rtxclaw_then_wizard_lands_in_tui`` is
# a single heavyweight function, so xdist runs it on exactly one
# worker — and test_01/test_04's gateways live on the sandbox's
# 27700-range, never :20100.


# ---- tmux helpers (dedicated socket so we never inherit a stray
# ---- server's environment — see conftest's note on env propagation) --

_TMUX_SOCK = f"rtxclaw-pipwiz-{os.getpid()}"


def _tmux(*args: str, **kw) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["tmux", "-L", _TMUX_SOCK, *args],
        capture_output=True, text=True, **kw,
    )


def _capture(session: str, scrollback: int = 2000) -> str:
    cp = _tmux("capture-pane", "-t", session, "-p", "-J",
               "-S", f"-{scrollback}", timeout=10)
    return cp.stdout if cp.returncode == 0 else ""


def _send(session: str, text: str = "") -> None:
    """Type ``text`` (literally) then press Enter. Empty ``text`` ⇒
    just Enter, i.e. "accept the default"."""
    if text:
        _tmux("send-keys", "-t", session, "-l", text, timeout=10)
        time.sleep(0.2)
    _tmux("send-keys", "-t", session, "Enter", timeout=10)


def _wait_for(session: str, needle: str, *, timeout: float = 45.0,
              transcript: list[str]) -> str:
    """Poll the pane until ``needle`` shows up. Every capture is pushed
    onto ``transcript`` so the caller can assert against the whole
    wizard run afterwards (and dump it on failure)."""
    deadline = time.time() + timeout
    pane = ""
    while time.time() < deadline:
        pane = _capture(session)
        transcript.append(pane)
        if needle in pane:
            return pane
        time.sleep(0.5)
    raise AssertionError(
        f"timed out after {timeout}s waiting for {needle!r}.\n"
        f"last pane:\n{pane[-2000:]}"
    )


# ---------------------------------------------------------------------
# Step 1 — pip install rtxclaw (into a clean, isolated venv)
# ---------------------------------------------------------------------


@pytest.fixture(scope="module")
def pip_installed_rtxclaw(tmp_path_factory) -> Path:
    """``pip install`` the repo into a fresh isolated venv and return the
    path to the installed ``rtxclaw`` console script.

    This is the literal step 1 of the user story — no PYTHONPATH, no
    editable install, no ``./rtxclaw`` launcher. If the wheel's
    entry-point or dependency set is broken, this fixture fails and
    every assertion below is moot.

    The source is copied to a fresh writable dir first: that's exactly
    what ``pip install git+https://…/rtxclaw.git`` does (clone into a
    temp tree, build there) — and it keeps the build's egg_info scratch
    out of the shared ``/app`` checkout the other tests bootstrap from.
    """
    base = tmp_path_factory.mktemp("pip-wizard")
    src = base / "rtxclaw-src"
    shutil.copytree(
        _APP_DIR, src,
        ignore=shutil.ignore_patterns(
            ".git", "__pycache__", "*.pyc", "*.egg-info",
            ".venv", "venv", ".pytest_cache", "reports", ".env", ".env.*",
        ),
    )
    venv = base / "venv"
    subprocess.run(
        ["python3", "-m", "venv", str(venv)],
        check=True, capture_output=True, text=True, timeout=120,
    )
    pip = venv / "bin" / "pip"
    # Real dependency resolve from the repo's pyproject.toml — same
    # build a `pip install git+https://…/rtxclaw.git` performs.
    cp = subprocess.run(
        [str(pip), "install", str(src)],
        capture_output=True, text=True, timeout=900,
    )
    if cp.returncode != 0:
        pytest.fail(
            f"`pip install <rtxclaw source>` failed (rc={cp.returncode}):\n"
            f"{cp.stdout[-2000:]}\n{cp.stderr[-2000:]}"
        )
    rtxclaw_bin = venv / "bin" / "rtxclaw"
    assert rtxclaw_bin.is_file(), (
        f"pip install did not create the `rtxclaw` console script at "
        f"{rtxclaw_bin} — entry point broken?"
    )
    # The console script must at least run — proves the entry point
    # (rtxclaw_tui.app:main) imports cleanly inside the installed venv.
    cp = subprocess.run(
        [str(rtxclaw_bin), "--help"],
        capture_output=True, text=True, timeout=60,
    )
    assert cp.returncode == 0, (
        f"`rtxclaw --help` failed after pip install (rc={cp.returncode}):\n"
        f"{cp.stderr[-1500:]}"
    )
    assert "configure" in cp.stdout and "gateway" in cp.stdout
    return rtxclaw_bin


# A real isolated dependency resolve (textual, trafilatura, yt-dlp,
# markitdown[pdf], onnxruntime, …) does not fit in the suite's default
# 120/240s per-test cap — the convention (see tests/run-docker.sh) is a
# per-test override. The first test to touch the module-scoped
# ``pip_installed_rtxclaw`` fixture pays the install cost, so both
# carry the long cap.
@pytest.mark.timeout(900)
def test_pip_install_provides_console_script(pip_installed_rtxclaw: Path) -> None:
    """Step 1 in isolation: the wheel installs and exposes a working
    ``rtxclaw`` command (plus the ``gateway install-service`` surface
    the wizard leans on)."""
    cp = subprocess.run(
        [str(pip_installed_rtxclaw), "gateway", "--help"],
        capture_output=True, text=True, timeout=60,
    )
    assert cp.returncode == 0, cp.stderr
    assert "install-service" in cp.stdout, (
        "`rtxclaw gateway install-service` missing — the wizard's "
        "service-install path has nothing to call.\n" + cp.stdout
    )


# ---------------------------------------------------------------------
# Steps 2 + 3 — `rtxclaw` → first-run wizard → done
# ---------------------------------------------------------------------


@pytest.mark.timeout(600)
def test_rtxclaw_then_wizard_lands_in_tui(
    pip_installed_rtxclaw: Path,
    require_tmux: str,          # noqa: ARG001 — capability gate
    configured_endpoint: str,
    configured_model: str,
    tmp_path: Path,
    report_dir: Path,
) -> None:
    """The whole story end to end.

    Bare ``rtxclaw`` with no agent configured → first-run wizard. We
    answer every prompt through tmux (accepting defaults for the
    optional ones — name / Brave / Telegram / advanced — exactly like
    a human in a hurry). The wizard's final step brings the gateway up
    on its own; ``rtxclaw`` then connects and the TUI renders.

    "Done" is asserted three ways:
      * the wizard ran            (``first-run setup`` banner + saved config)
      * the wizard got us running (a live gateway PROCESS it started —
                                   pidfile on disk + ``os.kill(pid, 0)``)
      * the TUI is on screen      (``mode:`` status footer — and the TUI
                                   can only render past
                                   ``_resolve_agent_or_fail`` with a
                                   live, ACP-answering gateway)
    plus the regression guards: no ``connection refused``, no
    ``not reachable``, no stray ``:7700``.
    """
    # A genuine first-run: an empty RTXCLAW_HOME, nothing pre-seeded.
    # `rtxclaw` sees no `agents/main/config.json`, runs the first-run
    # wizard, and the wizard writes config.json from scratch.
    home = tmp_path / "rtxclaw-home"
    home.mkdir()

    env = os.environ.copy()
    env["RTXCLAW_HOME"] = str(home)
    env.pop("RTXCLAW_VENV", None)          # not a launcher run
    env.pop("RTXCLAW_AGENTS_HOME", None)
    env["RTXCLAW_NO_BOOTSTRAP"] = "1"      # belt-and-braces; we exec the
    #                                       installed script, not ./rtxclaw

    session = f"pipwiz-{os.getpid()}"
    transcript: list[str] = []
    gateway_pid: int | None = None
    try:
        cp = _tmux(
            "new-session", "-d", "-s", session, "-x", "200", "-y", "50",
            str(pip_installed_rtxclaw),
            env=env, timeout=20,
        )
        if cp.returncode != 0:
            pytest.fail(f"tmux new-session failed (rc={cp.returncode}):\n{cp.stderr}")

        # ----- the wizard, prompt by prompt -----
        _wait_for(session, "first-run setup", timeout=60, transcript=transcript)

        # 1. model deployment
        _wait_for(session, "baseUrl:", transcript=transcript)
        _send(session, configured_endpoint)
        _wait_for(session, "apiKeyEnv", transcript=transcript)
        _send(session)                                   # blank = none
        # backend probe runs against the real endpoint here
        _wait_for(session, "backend [", transcript=transcript)
        _send(session)                                   # keep detected
        _wait_for(session, "alias (short name", transcript=transcript)
        _send(session, "testbox")
        _wait_for(session, "  id ", transcript=transcript)   # `id [..]:` / `id (required):`
        _send(session, configured_model)
        _wait_for(session, "contextWindow", transcript=transcript)
        _send(session)                                   # accept detected/default
        _wait_for(session, "add another model", transcript=transcript)
        _send(session)                                   # [y/N] → no

        # 2. optional bits — accept every default, the "in a hurry" path
        _wait_for(session, "your name", transcript=transcript)
        _send(session)
        _wait_for(session, "Brave Search API key", transcript=transcript)
        _send(session)                                   # skip web search
        _wait_for(session, "set up Telegram bot", transcript=transcript)
        _send(session)                                   # [y/N] → no
        _wait_for(session, "advanced settings", transcript=transcript)
        _send(session)                                   # [y/N] → no

        # 3. the wizard's own service step — no prompt here (no systemd
        #    in the container), it just brings the gateway up. Wait for
        #    either the wizard's "started" line OR the TUI chrome that
        #    follows it.
        deadline = time.time() + 90
        landed = ""
        while time.time() < deadline:
            pane = _capture(session)
            transcript.append(pane)
            low = pane.lower()
            if "mode:" in low:                 # TUI footer — fully done
                landed = "tui"
                break
            if "gateway started" in low or "gateway already running" in low:
                landed = "gateway"
                # keep going a little — the TUI should follow within ~1-2s
            time.sleep(0.5)

        full = "\n".join(transcript)
        (report_dir / "pip_wizard_transcript.txt").write_text(full or "(empty)")
        (report_dir / "pip_wizard_final_pane.txt").write_text(
            _capture(session) or "(empty)"
        )

        # Snapshot the gateway's own log + the saved config into the
        # report dir — this private tmp_path RTXCLAW_HOME is never seen
        # by conftest's session-log snapshot, so without this a failure
        # here has nothing to triage from.
        pidfile = home / "gateway.pid"
        for fname in ("gateway.log", "config.json"):
            f = home / fname
            if f.is_file():
                shutil.copy2(f, report_dir / f"pip_wizard_{fname}")
        if pidfile.is_file():
            try:
                gateway_pid = int(pidfile.read_text().strip())
            except (OSError, ValueError):
                gateway_pid = None

        # ----- assertions: the three-step story actually completed ----
        assert "first-run setup" in full, (
            "wizard banner never showed — `rtxclaw` didn't reach the "
            f"first-run wizard.\n{full[-1500:]}"
        )

        # "Wizard saved its config" is asserted on the OUTCOME — the
        # config.json file on disk — not by grepping the transcript for
        # the "✓ saved global config" line. That line prints to the
        # normal screen and the TUI's alt-screen switch (~1 s later)
        # scrolls it out of capture-pane's reach, so a transcript grep
        # races and flakes. The file is race-free.
        #
        # And it must seed BOTH the default MCP servers and the skills
        # map: a fresh `pip install` + wizard should leave the bundled
        # MCP servers and skills configured and on by default, not
        # silently absent.
        cfg_path = home / "config.json"
        assert cfg_path.is_file(), (
            f"wizard wrote no config at {cfg_path} — it never saved.\n"
            f"{full[-1500:]}"
        )
        cfg = json.loads(cfg_path.read_text())
        mcp = cfg.get("mcpServers") or {}
        assert mcp.get("youtube") and mcp.get("markitdown"), (
            "config.json is missing the default mcpServers (youtube + "
            "markitdown) — the wizard's MCP defaults didn't persist. "
            f"config keys: {sorted(cfg)}"
        )
        skills_cfg = cfg.get("skills") or {}
        assert skills_cfg and all(
            isinstance(v, dict) and v.get("enabled") is True
            for v in skills_cfg.values()
        ), (
            "config.json is missing a populated `skills` map (every "
            f"discovered skill enabled by default). skills: {skills_cfg}"
        )
        assert "nodriver-browser" in skills_cfg, (
            "the bundled `nodriver-browser` builtin skill is not in the "
            f"seeded `skills` map: {sorted(skills_cfg)}"
        )

        # The wizard's service step is proven by a live gateway PROCESS
        # it started. `_offer_gateway_service` → `start_gateway_background()`
        # spawns `rtxclaw_agent gateway-serve`, which writes its own
        # pidfile on boot — and nothing else under this isolated
        # RTXCLAW_HOME starts one. We assert the pidfile + process
        # liveness rather than re-polling /health from the test process:
        # the wizard's own `_wait_for_listener` ALREADY gated on /health
        # before letting the TUI launch, and the TUI rendering (asserted
        # below) is itself end-to-end proof the listener answered —
        # `rtxclaw` cannot reach `app.run()` unless `_resolve_agent_or_fail`
        # confirmed a live gateway AND a 200 on ACP `initialize`.
        assert gateway_pid is not None, (
            f"no gateway.pid at {pidfile} — the wizard's service step did "
            "not start a gateway; the operator would be stranded on a "
            f"`systemctl` to-do.\n{full[-1500:]}"
        )
        gw_log_path = report_dir / "pip_wizard_gateway.log"
        gw_log_tail = (
            gw_log_path.read_text(errors="replace")[-2000:]
            if gw_log_path.is_file() else "(no gateway.log captured)"
        )
        try:
            os.kill(gateway_pid, 0)
        except (ProcessLookupError, PermissionError) as e:
            pytest.fail(
                f"the wizard started gateway pid={gateway_pid} but it is "
                f"not alive ({e!r}) — it died after boot.\n"
                f"--- gateway.log tail ---\n{gw_log_tail}"
            )

        # The bug this whole branch fixes: TUI dialing the wrong port.
        assert ":7700" not in full, (
            "stale :7700 gateway port surfaced — the TUI/gateway port "
            f"mismatch is back.\n{full[-1500:]}"
        )
        assert "connection refused" not in full.lower(), (
            f"`connection refused` in the wizard/TUI output:\n{full[-1500:]}"
        )
        assert "not reachable on the gateway" not in full, (
            f"TUI could not reach the gateway after the wizard:\n{full[-1500:]}"
        )

        # "Done" = the TUI is on screen. Give it a last grace window in
        # case we broke out of the loop on the "gateway" signal.
        if landed != "tui":
            deadline = time.time() + 30
            while time.time() < deadline:
                pane = _capture(session)
                if "mode:" in pane.lower():
                    landed = "tui"
                    break
                time.sleep(0.5)
        final_pane = _capture(session)
        (report_dir / "pip_wizard_final_pane.txt").write_text(
            final_pane or "(empty)"
        )
        assert landed == "tui" and "mode:" in final_pane.lower(), (
            "the TUI never rendered after the wizard — the three-step "
            "flow did not reach 'ready to use'.\n"
            f"final pane:\n{final_pane[-1500:]}"
        )
    finally:
        # The wizard started a real detached gateway under our private
        # RTXCLAW_HOME — conftest's stray-reaper only knows the sandbox
        # home, so we clean up our own.
        if gateway_pid is not None:
            try:
                os.kill(gateway_pid, 15)
            except (ProcessLookupError, PermissionError):
                pass
        _tmux("kill-session", "-t", session, timeout=10)
        _tmux("kill-server", timeout=10)
