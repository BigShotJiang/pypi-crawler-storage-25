"""Step 20 — Delegate turn-record schema regression net.

Direct-dispatch tools (``/claude``, ``/codex``, ``/compact`` via the
sentinel) write a turn record into the session via
``CoreBackend._run_direct_tool_call`` so future turns can see the
delegate reply as conversation context.

The bridge's :meth:`CoreBackend._build_messages` reads
``turn.get("content")`` to recover the assistant body. A regression
that writes the body under a different key (``assistant``,
``response``, ``output``…) makes the delegate result invisible to
the next round — the upstream model literally says "we never asked
Claude anything in this conversation."

This test pins:
- The canonical session schema fields (``user``, ``content``,
  ``started_at``, ``ended_at``, ``aborted``, ``error``, ``metrics``)
  are all present on a synthesized delegate turn.
- ``_build_messages`` round-trips a delegate turn into one
  ``user`` + one ``assistant`` message pair downstream.
- The assistant message body matches what the runner emitted, byte
  for byte (no silent truncation, no key-rename).
"""
from __future__ import annotations

from rtxclaw_agent.acp_bridge import CoreBackend
from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.session import Session


def _make_delegate_turn(prompt: str, body: str) -> dict:
    """Mirror the schema written by ``_run_direct_tool_call``."""
    return {
        "id": "turn_delegate_1",
        "started_at": "2026-05-06T00:00:00+00:00",
        "ended_at":   "2026-05-06T00:00:30+00:00",
        "user": prompt,
        "thinking": "",
        "content": body,
        "aborted": False,
        "error": None,
        "in_progress": False,
        "metrics": {"source": "delegate_claude"},
        "tool_rounds": [],
    }


def test_delegate_turn_record_has_canonical_keys() -> None:
    """The ``Session.add_turn`` schema is the source of truth — direct
    delegate persistence must use the same keys so downstream code
    (``_build_messages``, ``/history``, replay) doesn't have to pattern-
    match on a second schema. Fail loudly if any required key drifts."""
    rec = _make_delegate_turn("hi", "Paris")
    required = {"user", "content", "started_at", "ended_at",
                "aborted", "in_progress", "metrics"}
    missing = required - set(rec)
    assert not missing, f"delegate turn record missing keys: {missing}"


def test_delegate_turn_replays_into_message_history() -> None:
    """A delegate turn must surface as a (user, assistant) pair in the
    next round's prompt build — otherwise the upstream model can't see
    that Claude / Codex was ever invoked."""
    cfg = AgentConfig(name="t", system="sys")
    bridge = CoreBackend(cfg)
    sess = Session(
        hash="abc",
        title="t",
        created_at="2026-05-06T00:00:00+00:00",
        system_prompt=cfg.system,
        model="m",
        endpoint="http://x",
        turns=[_make_delegate_turn(
            "what is the capital of France?",
            "The capital of France is **Paris**.",
        )],
        workspace_cwd="/tmp",
        workspace_origin="acp",
    )
    msgs = bridge._build_messages(sess, [
        {"type": "text", "text": "summarise everything we just asked Claude"},
    ])

    user_msgs = [m for m in msgs if m.get("role") == "user"]
    assistant_msgs = [m for m in msgs if m.get("role") == "assistant"]
    assert any("capital of France" in (m.get("content") or "") for m in user_msgs), (
        "delegate's user prompt didn't replay into the next round"
    )
    assert any(
        "Paris" in (m.get("content") or "") for m in assistant_msgs
    ), "delegate's assistant body didn't replay — the next round will be blind"


def test_aborted_delegate_turn_skipped_in_replay() -> None:
    """Aborted delegate turns must not pollute the replay with stale
    user prompts that have no answer — they're stubbed instead."""
    cfg = AgentConfig(name="t", system="sys")
    bridge = CoreBackend(cfg)
    rec = _make_delegate_turn("partial", "")
    rec["aborted"] = True
    sess = Session(
        hash="abc", title="t", created_at="2026-05-06T00:00:00+00:00",
        system_prompt=cfg.system, model="m", endpoint="http://x",
        turns=[rec], workspace_cwd="/tmp", workspace_origin="acp",
    )
    msgs = bridge._build_messages(sess, [
        {"type": "text", "text": "what now?"},
    ])
    # The aborted turn replays as user + a "[Turn N aborted by user]"
    # stub assistant; verify the stub appears (not the empty body).
    found_stub = any(
        "[Turn" in (m.get("content") or "")
        and "aborted" in (m.get("content") or "")
        for m in msgs
    )
    assert found_stub, (
        f"aborted delegate turn must replay as a stubbed assistant — "
        f"got:\n{msgs}"
    )
