"""Skeleton-phase smoke tests for the new agents/ package.

SKELETON ONLY — every test is ``pytest.skip`` until the corresponding
phase lands. The file exists now so the file/test layout is locked in
and future PRs slot fixtures into pre-named tests.

Test plan, indexed by migration phase
(see ``src/rtxclaw_core/agents/__init__.py``):

Phase 1 — factory + AgentConfig.engine
======================================

* ``test_legacy_config_resolves_local_llm`` — loading an existing
  ``main`` / ``scraper`` / ``coder`` config (no ``engine`` field)
  yields ``Agent(engine=LocalLLMEngine)``.
* ``test_explicit_engine_kinds`` — configs carrying
  ``"engine": "claude_cli"`` etc. resolve correctly.
* ``test_unknown_engine_raises`` — typo in ``engine`` field raises a
  clear ``ValueError`` rather than silently picking local_llm.
* ``test_auto_scaffold_writes_when_cli_on_path`` — monkeypatch
  ``shutil.which("claude")``; ``ensure_default_external_agents()``
  drops the config + scaffold files exactly once; second call is
  idempotent.
* ``test_auto_scaffold_skips_without_cli`` — when ``claude`` is not on
  PATH the agents/claude/ dir is not created.

Phase 2 — LocalLLMEngine
========================

* ``test_local_llm_runs_simple_turn`` — drive ``Agent.run_turn`` with
  a stubbed worker spawner that scripts a 1-round happy path; assert
  the AgentTurnEvent sequence (TurnStarted → TextDelta+ → TurnDone)
  matches expectation.
* ``test_local_llm_multi_round_tool_dispatch`` — script a worker that
  emits ``tool_calls`` on round 1 and content on round 2; assert tool
  dispatch fires and the second round picks up the tool result in
  the message list.
* ``test_local_llm_compaction_guard`` — drive a session above the
  ``compact_at_frac`` threshold; assert ``_maybe_compact`` runs and
  ``session.compaction_count`` increments.
* ``test_local_llm_loop_detection`` — script a worker streaming the
  same n-gram > LOOP_REPEAT_THRESHOLD times; assert the layered
  detector fires, the worker is SIGTERM'd, and TurnDone carries
  ``state="aborted"`` with classification ``"loop"``.
* ``test_local_llm_compact_context_tool`` — model emits a
  ``compact_context`` tool call; assert the runtime intercepts,
  squeezes in place, and continues without a new worker round.
* ``test_local_llm_session_log_record`` — after a turn,
  ``session.turns[-1]`` has the new attribution fields
  (``engine`` / ``model`` / ``tool_calls`` / ``tool_results`` /
  ``engine_session_id`` / ``permission_mode``).

Phase 3 — ExternalCliEngine + Claude / Codex / Gemini
======================================================

Golden-fixture replay tests. The fixtures are captured ONCE from real
CLI runs (anonymized prompt + system_prompt) and pinned in
``tests/fixtures/agents/`` — they are the contract.

* ``test_claude_engine_parses_known_fixture`` — feed
  ``tests/fixtures/agents/claude_short.jsonl`` (one short Q+A turn)
  to ``ClaudeCliEngine.parse_stream_event`` callbacks; assert the
  resulting ``(text_buf, tool_calls, tool_results, session_id)``
  matches the captured legacy parser output byte-for-byte.
* ``test_claude_engine_with_inner_tools_fixture`` — fixture includes
  Read / Bash / TodoWrite blocks; same assertion.
* ``test_claude_engine_stale_resume_retry`` — fixture replays an
  ``error_during_execution`` event; assert
  :meth:`ClaudeCliEngine.retry_without_resume` fires once.
* ``test_codex_engine_parses_known_fixture`` — ``codex_short.jsonl``
  through ``CodexCliEngine.parse_stream_event``; assert the agent-
  message text + command_execution markers come out identical to
  legacy.
* ``test_gemini_engine_parses_known_fixture`` —
  ``gemini_short.jsonl``; same shape.
* ``test_external_cli_first_call_priming`` — call with
  ``state.first_call_completed=False`` + system_prompt; assert
  ``--append-system-prompt`` (Claude) / first-message injection
  (Codex/Gemini) lands in the spawned argv / stdin.
* ``test_external_cli_resume`` — second call with
  ``state.first_call_completed=True``; assert ``--resume <id>`` in
  argv and NO system prompt re-sent.
* ``test_external_cli_cancellation_group_kills`` — start a CLI run,
  cancel mid-stream; assert SIGTERM + SIGKILL fired on the process
  group (subprocesses of the spawned CLI are also dead).

Phase 4 — Agent runtime
=======================

* ``test_agent_compose_system_prompt`` — write SOUL/AGENTS/TOOLS/USER
  files into a tmp agent home; assert the composed string matches the
  legacy ``_compose_system_prompt`` output.
* ``test_agent_first_call_passes_system_prompt`` — Agent w/ CLI
  engine, fresh session: TurnRequest seen by engine has
  ``system_prompt`` set.
* ``test_agent_second_call_resume_skips_system_prompt`` — same Agent,
  follow-up turn: TurnRequest has ``system_prompt=None``.
* ``test_agent_local_llm_always_sends_system_prompt`` — local-LLM
  agent: every round's TurnRequest has system_prompt set (stateless).
* ``test_agent_hooks_fire_in_order`` — config with hooks.json
  containing pre_turn / pre_tool / post_tool / post_turn rules;
  assert each fires at the right moment with the right matchers.
* ``test_agent_memory_recall_injected_per_engine`` — local-LLM agent
  gets the [RECALLED CONTEXT] block every round; CLI agent gets it
  only on the first call (folded into composed system prompt).
* ``test_agent_heartbeat_schedules_turn`` — fake clock, low
  ``heartbeat_interval_s``; assert a turn fires through engine after
  the interval.

Phase 5 — Gateway cutover
=========================

* ``test_gateway_mounts_agent_acp_backend`` — gateway boot resolves
  one Agent per discovered config and mounts the new backend at
  ``/acp/<name>``.
* ``test_acp_prompt_flow_local_llm`` — simulate one ACP
  ``session/prompt`` call against the new backend; assert wire-level
  sessionUpdate sequence matches legacy.
* ``test_acp_prompt_flow_claude`` — same but with a CLI-engined
  agent.
* (removed: ``test_legacy_backend_env_fallback`` — the
  ``RTXCLAW_AGENT_BACKEND=legacy`` rollback switch + renamed
  ``_LegacyCoreBackend`` shim were deleted at 2026-05-14 once the
  cutover was verified; no env-flag fallback to test.)

Phase 6 — Frontend wiring
=========================

* ``test_tui_agent_switch_to_claude`` — run TUI; ``/agent claude``
  switches; subsequent prompt runs through ClaudeCliEngine.
* ``test_telegram_agent_switch_to_codex`` — same via Telegram bot.
* ``test_subagents_lists_cli_sessions`` — ``/subagents`` shows
  CLI-engine sessions alongside delegate sidecars (with the new
  uniform sidecar shape).

Phase 7 — Sweep
===============

* ``test_legacy_runners_removed`` — importing
  ``rtxclaw_core.tools.runners.run_delegate_claude_async`` either
  raises ImportError or resolves to the shim in
  ``delegate_shims`` (depending on the final disposition).
* ``test_legacy_sidecars_migrated`` — pre-populate a sessions dir
  with a legacy ``<sid>.delegate_claude.json``; run the migration
  helper; assert the new ``<sid>.claude_cli.json`` exists and the
  legacy file got renamed ``.migrated``.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest import mock

import pytest


# Phase 1 tests live in this module; everything below them is still
# pytest.skip until its phase lands.


def _isolated_rtxclaw_home(tmp_path: Path) -> Path:
    """Allocate an isolated RTXCLAW_HOME under ``tmp_path``."""
    home = tmp_path / "rtxclaw_home"
    home.mkdir(parents=True, exist_ok=True)
    (home / "agents").mkdir(parents=True, exist_ok=True)
    return home


def test_legacy_config_resolves_local_llm(tmp_path: Path) -> None:
    """Existing config without an ``engine`` field resolves to LOCAL_LLM."""
    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "legacy_agent"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "legacy_agent",
        "description": "no engine field — pre-refactor config",
        "port": 7799,
    }) + "\n")

    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
        from rtxclaw_core.agents import factory
        from rtxclaw_core.agents.engine import EngineKind

        agent = factory.load_agent("legacy_agent")
        assert agent.engine.kind == EngineKind.LOCAL_LLM
        assert agent.cfg.engine == "local_llm"


def test_explicit_engine_kinds(tmp_path: Path) -> None:
    """Configs that carry ``engine: claude_cli`` etc. resolve correctly."""
    home = _isolated_rtxclaw_home(tmp_path)
    cases = [
        ("local", "local_llm"),
        ("c", "claude_cli"),
        ("cx", "codex_cli"),
        ("g", "gemini_cli"),
    ]
    for name, engine_value in cases:
        (home / "agents" / name).mkdir(parents=True)
        (home / "agents" / name / "config.json").write_text(json.dumps({
            "name": name,
            "engine": engine_value,
        }) + "\n")

    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
        from rtxclaw_core.agents import factory
        from rtxclaw_core.agents.engine import EngineKind

        for name, engine_value in cases:
            agent = factory.load_agent(name)
            assert agent.cfg.engine == engine_value, (
                f"cfg.engine mismatch for {name}: "
                f"got {agent.cfg.engine}, want {engine_value}"
            )
            assert agent.engine.kind == EngineKind(engine_value), (
                f"engine instance mismatch for {name}"
            )


def test_unknown_engine_raises(tmp_path: Path) -> None:
    """A typo in ``engine`` raises rather than falling back silently."""
    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "typo_agent"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "typo_agent",
        "engine": "claud_cli",   # typo — missing 'e'
    }) + "\n")

    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
        from rtxclaw_core.agents import factory

        with pytest.raises(ValueError, match=r"unknown engine kind"):
            factory.load_agent("typo_agent")


def test_resolve_engine_kind_tolerates_blank() -> None:
    """``None`` and empty string both map to LOCAL_LLM."""
    from rtxclaw_core.agents import factory
    from rtxclaw_core.agents.engine import EngineKind

    for raw in (None, "", "   "):
        assert factory.resolve_engine_kind(raw) == EngineKind.LOCAL_LLM


def test_auto_scaffold_writes_when_cli_on_path(tmp_path: Path) -> None:
    """When the CLI is on PATH, ``ensure_default_external_agents`` drops
    the full scaffold and is idempotent across calls.
    """
    home = _isolated_rtxclaw_home(tmp_path)
    # Mock every CLI as available so the test is deterministic
    # regardless of the host's actual PATH.
    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}), \
         mock.patch("shutil.which", return_value="/usr/bin/fake-cli"):
        from rtxclaw_core.agents import factory

        created = factory.ensure_default_external_agents()
        assert set(created) == {"claude", "codex", "gemini"}

        for short in ("claude", "codex", "gemini"):
            agent_home = home / "agents" / short
            assert agent_home.is_dir()
            for fname in (
                "config.json", "SOUL.md", "AGENTS.md", "TOOLS.md",
                "USER.md", "MEMORY.md", "HEARTBEAT.md",
            ):
                assert (agent_home / fname).exists(), (
                    f"missing scaffold file: {agent_home / fname}"
                )
            cfg = json.loads((agent_home / "config.json").read_text())
            assert cfg["engine"] == f"{short}_cli"
            assert cfg["name"] == short

        # Idempotent
        created2 = factory.ensure_default_external_agents()
        assert created2 == []


def test_auto_scaffold_skips_without_cli(tmp_path: Path) -> None:
    """No CLIs on PATH → no scaffold dirs created."""
    home = _isolated_rtxclaw_home(tmp_path)
    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}), \
         mock.patch("shutil.which", return_value=None):
        from rtxclaw_core.agents import factory

        created = factory.ensure_default_external_agents()
        assert created == []
        assert not (home / "agents" / "claude").exists()
        assert not (home / "agents" / "codex").exists()
        assert not (home / "agents" / "gemini").exists()


def test_auto_scaffold_does_not_overwrite_customization(
    tmp_path: Path,
) -> None:
    """If ``config.json`` already exists, skip the whole agent dir."""
    home = _isolated_rtxclaw_home(tmp_path)
    custom_dir = home / "agents" / "claude"
    custom_dir.mkdir(parents=True)
    custom_config = {
        "name": "claude",
        "engine": "claude_cli",
        "description": "operator-customized",
        "heartbeat_enabled": True,
    }
    (custom_dir / "config.json").write_text(json.dumps(custom_config) + "\n")

    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}), \
         mock.patch("shutil.which", return_value="/usr/bin/fake-cli"):
        from rtxclaw_core.agents import factory

        created = factory.ensure_default_external_agents()
        # codex + gemini land; claude is skipped because the dir exists.
        assert set(created) == {"codex", "gemini"}

        # Verify the operator's customization survived intact.
        roundtrip = json.loads((custom_dir / "config.json").read_text())
        assert roundtrip == custom_config


def test_local_llm_runs_simple_turn(tmp_path: Path) -> None:
    """Phase 3a end-to-end: a scripted worker emits content + done,
    Agent.run_turn yields TurnStarted → TextDelta → TurnDone(ok), and
    the session record is persisted with attribution.
    """
    import asyncio
    from rtxclaw_core.agents.engine import (
        TextDelta, TurnDone, TurnStarted,
    )

    class _Proc:
        returncode = 0
        stdout = None
        stderr = None
        def terminate(self): pass
        async def wait(self): return 0

    class _TurnState:
        def __init__(self): self.proc = _Proc()
        def stop(self): pass

    async def _scripted_stream(events):
        for ev in events:
            yield ev

    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "rt"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "rt",
        "engine": "local_llm",
        "upstream_model": "rt/m",
    }) + "\n")

    async def main() -> tuple[list[str], dict]:
        with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
            from rtxclaw_core.agents import factory

            agent = factory.load_agent("rt")
            session = agent.create_session()
            sid = session.hash

            scripted = [
                {"kind": "content", "text": "hello"},
                {"kind": "metrics",
                 "prompt_tokens": 100, "completion_tokens": 10,
                 "finish_reason": "stop", "model": "rt/m"},
                {"kind": "done"},
            ]

            async def _spawn(*_args, **_kwargs):
                return _TurnState(), _scripted_stream(scripted)

            agent.engine._worker_spawner = _spawn

            seq: list[str] = []
            async for ev in agent.run_turn(sid, "hi"):
                seq.append(type(ev).__name__)
            loaded = agent.get_session(sid)
            return seq, (loaded.turns[-1] if loaded.turns else {})

    seq, turn = asyncio.run(main())

    assert seq == ["TurnStarted", "TextDelta", "TurnDone"]
    assert turn.get("user") == "hi"
    assert turn.get("content") == "hello"
    assert turn.get("engine") == "local_llm"
    assert turn.get("model") == "rt/m"
    assert turn.get("finish_reason") == "stop"
    assert turn.get("metrics", {}).get("prompt_tokens") == 100


def test_local_llm_classifies_worker_error(tmp_path: Path) -> None:
    """A worker that emits ``error`` instead of ``done`` produces
    TurnError + TurnDone(state="error"). NOT also TurnError(worker_eof)
    — codex audit round-4 #3.
    """
    import asyncio
    from rtxclaw_core.agents.engine import (
        TextDelta, TurnDone, TurnError,
    )

    class _Proc:
        returncode = 1
        stdout = None
        stderr = None
        def terminate(self): pass
        async def wait(self): return 1

    class _TurnState:
        def __init__(self): self.proc = _Proc()
        def stop(self): pass

    async def _stream(events):
        for ev in events:
            yield ev

    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "rt"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "rt", "engine": "local_llm",
    }) + "\n")

    async def main() -> list[tuple[str, str]]:
        with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
            from rtxclaw_core.agents import factory

            agent = factory.load_agent("rt")
            session = agent.create_session()
            sid = session.hash

            scripted = [
                {"kind": "content", "text": "partial"},
                {"kind": "error", "message": "upstream 503"},
            ]

            async def _spawn(*_args, **_kwargs):
                return _TurnState(), _stream(scripted)

            agent.engine._worker_spawner = _spawn

            out: list[tuple[str, str]] = []
            async for ev in agent.run_turn(sid, "boom"):
                if isinstance(ev, TurnError):
                    out.append(("TurnError", ev.classification))
                elif isinstance(ev, TurnDone):
                    out.append(("TurnDone", ev.state))
                else:
                    out.append((type(ev).__name__, ""))
            return out

    events = asyncio.run(main())
    # Exactly one TurnError (not also a worker_eof on top)
    errors = [e for e in events if e[0] == "TurnError"]
    assert len(errors) == 1, f"expected 1 TurnError, got {events}"
    # And a TurnDone(state=error)
    dones = [e for e in events if e[0] == "TurnDone"]
    assert len(dones) == 1
    assert dones[0][1] == "error"


def test_local_llm_abort_returns_fast(tmp_path: Path) -> None:
    """ESC mid-stream returns within ~1s even when the worker is
    slow to reap. Codex audit round-3 phase-3a #3 — the cancel path
    must not block on inline ``proc.wait()``.
    """
    import asyncio
    import time
    from rtxclaw_core.agents.engine import TextDelta

    class _SlowProc:
        def __init__(self):
            self.returncode = None
            self._t = False
        stdout = None
        stderr = None
        def terminate(self):
            self._t = True
        async def wait(self):
            # Slow worker: 5 seconds. We MUST NOT inline-wait this on
            # the cancel path.
            await asyncio.sleep(5.0)
            self.returncode = -15
            return -15

    class _TurnState:
        def __init__(self, proc): self.proc = proc
        def stop(self): pass

    async def _stream(events, delay):
        for ev in events:
            await asyncio.sleep(delay)
            yield ev

    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "rt"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "rt", "engine": "local_llm",
    }) + "\n")

    async def main() -> tuple[float, list[str]]:
        with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
            from rtxclaw_core.agents import factory

            agent = factory.load_agent("rt")
            session = agent.create_session()
            sid = session.hash

            slow_proc = _SlowProc()
            ts = _TurnState(slow_proc)

            scripted = [
                {"kind": "content", "text": "streaming"},
                {"kind": "content", "text": "more"},
                {"kind": "content", "text": "still going"},
            ]

            async def _spawn(*_args, **_kwargs):
                return ts, _stream(scripted, delay=0.1)

            agent.engine._worker_spawner = _spawn

            async def _abort_soon():
                await asyncio.sleep(0.2)
                for _sid, tid in list(agent.engine._session_to_turn.items()):
                    await agent.engine.abort(tid)
                    return

            asyncio.create_task(_abort_soon())
            t0 = time.monotonic()
            seq: list[str] = []
            async for ev in agent.run_turn(sid, "long task"):
                seq.append(type(ev).__name__)
            elapsed = time.monotonic() - t0
            # Let any background reaper finish so the test isn't
            # leaving dangling tasks.
            await asyncio.sleep(0.2)
            return elapsed, seq

    elapsed, seq = asyncio.run(main())
    # Cancel path must return well under the 5s slow-worker wait.
    assert elapsed < 2.0, f"abort path took {elapsed:.2f}s; expected <2.0s"
    # TurnDone(aborted) appears
    assert "TurnDone" in seq


# Multi-round dispatch / compaction guard / loop detection /
# compact_context tool intercept are EXERCISED by the existing
# CoreBackend test suite (tests/test_50_openai_endpoint.py and the
# unmoved CoreBackend internals). Local-LLM agents on the new
# AgentACPBackend path delegate to CoreBackend in-process, so those
# behaviors run unchanged through this branch. No new test stub —
# tests should validate behavior, not phase markers.


def test_session_log_record_turn(tmp_path: Path) -> None:
    """``record_turn`` lays down every new attribution + fine-tune
    field on the on-disk session JSON."""
    from rtxclaw_core.session import Session
    from rtxclaw_core.agents import session_log

    sessions_dir = tmp_path / "sessions"
    s = Session.new(
        system_prompt="hello",
        model="test/model",
        endpoint="http://x",
        sessions_dir=sessions_dir,
    )
    session_log.record_session_creation(
        s, agent_name="main", engine="local_llm", system_prompt="hello",
    )
    assert s.agent_name == "main"
    assert s.engine == "local_llm"
    assert len(s.system_prompt_sha256) == 64    # sha256 hex

    session_log.record_turn(
        s,
        user="hi",
        thinking="some reasoning",
        content="hello back",
        started_at="2026-05-11T13:00:00",
        ended_at="2026-05-11T13:00:01",
        engine="local_llm",
        model="test/model",
        permission_mode="auto",
        cwd="/tmp",
        round_index=0,
        finish_reason="stop",
        tool_calls=[session_log.make_tool_call_record(
            "c1", "Read", {"path": "/x"}, "2026-05-11T13:00:00",
        )],
        tool_results=[session_log.make_tool_result_record(
            "c1", True, "ok", "2026-05-11T13:00:00",
        )],
        approval_decisions=[{
            "call_id": "c1", "decision": "allow", "source": "policy",
        }],
    )
    s.save(root=sessions_dir, force=True)

    on_disk = json.loads((sessions_dir / f"{s.hash}.json").read_text())
    # Session-level attribution
    assert on_disk["agent_name"] == "main"
    assert on_disk["engine"] == "local_llm"
    assert on_disk["system_prompt_sha256"] == s.system_prompt_sha256
    # Turn-level
    turn = on_disk["turns"][-1]
    assert turn["engine"] == "local_llm"
    assert turn["model"] == "test/model"
    assert turn["permission_mode"] == "auto"
    assert turn["cwd"] == "/tmp"
    assert turn["round_index"] == 0
    assert turn["finish_reason"] == "stop"
    assert turn["thinking"] == "some reasoning"
    assert turn["tool_calls"][0]["name"] == "Read"
    assert turn["tool_results"][0]["ok"] is True
    assert turn["approval_decisions"][0]["decision"] == "allow"


def test_session_log_record_turn_respects_privacy_gate(tmp_path: Path) -> None:
    """``persist_reasoning_traces=False`` drops thinking from the
    on-disk record while leaving every other field intact."""
    from rtxclaw_core.session import Session
    from rtxclaw_core.agents import session_log

    sessions_dir = tmp_path / "sessions"
    s = Session.new(
        system_prompt="hello",
        model="test/model",
        endpoint="http://x",
        sessions_dir=sessions_dir,
    )
    s.persist_reasoning_traces = False
    session_log.record_turn(
        s,
        user="hi",
        thinking="chain of thought",
        content="reply",
        started_at="a",
        ended_at="b",
        engine="local_llm",
        model="test/model",
    )
    assert s.turns[-1]["thinking"] == ""
    assert s.turns[-1]["content"] == "reply"


def test_agent_compose_system_prompt(tmp_path: Path) -> None:
    """``Agent.compose_system_prompt`` reads the agent's SOUL.md and
    folds in the cache boundary, matching the legacy composer."""
    from rtxclaw_core.agents import factory
    from rtxclaw_core.agents.engine import EngineKind
    from rtxclaw_core.system_prompt import SYSTEM_PROMPT_CACHE_BOUNDARY

    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "doctor"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "doctor",
        "engine": "local_llm",
        "permission_mode": "plan",
    }) + "\n")
    (agent_dir / "SOUL.md").write_text("You are Doctor.\n")
    (agent_dir / "AGENTS.md").write_text("Other agents are siblings.\n")

    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
        agent = factory.load_agent("doctor")
        # No workspace info → dynamic section empty → no boundary
        # (compose_with_cache_boundary drops the marker when the
        # dynamic side is empty, by design).
        bare = agent.compose_system_prompt()
        assert "You are Doctor." in bare
        assert "Other agents are siblings." in bare
        assert SYSTEM_PROMPT_CACHE_BOUNDARY not in bare

        # With workspace info → boundary present, dynamic tail carries
        # the workspace-context block.
        composed = agent.compose_system_prompt(
            workspace_cwd="/tmp", workspace_origin="test",
        )
        assert "You are Doctor." in composed
        assert SYSTEM_PROMPT_CACHE_BOUNDARY in composed
        assert "# WORKSPACE-CONTEXT" in composed
        assert "cwd: /tmp" in composed
        assert agent.engine_kind == EngineKind.LOCAL_LLM


def test_agent_session_crud_roundtrip(tmp_path: Path) -> None:
    """create_session → list_sessions → get_session round-trip preserves
    the new attribution fields."""
    from rtxclaw_core.agents import factory

    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "rt1"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "rt1",
        "engine": "local_llm",
    }) + "\n")
    (agent_dir / "SOUL.md").write_text("rt1 soul\n")

    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
        agent = factory.load_agent("rt1")
        session = agent.create_session(
            workspace_cwd="/tmp", workspace_origin="test",
        )
        assert session.agent_name == "rt1"
        assert session.engine == "local_llm"
        assert session.system_prompt_sha256
        sid = session.hash

        rows = agent.list_sessions()
        assert len(rows) == 1
        assert rows[0]["hash"] == sid
        assert rows[0]["agent_name"] == "rt1"
        assert rows[0]["engine"] == "local_llm"

        loaded = agent.get_session(sid)
        assert loaded is not None
        assert loaded.agent_name == "rt1"
        assert loaded.engine == "local_llm"
        assert loaded.system_prompt_sha256 == session.system_prompt_sha256

        agent.close_session(sid)
        # File still on disk; engine state cleared (no-op on local_llm
        # since attach_session is still a stub method).
        loaded_again = agent.get_session(sid)
        assert loaded_again is not None


def test_agent_compose_round_preamble(tmp_path: Path) -> None:
    """compose_round_preamble produces pinned + summary + todos blocks
    in the canonical order; absent fields produce empty preamble."""
    from rtxclaw_core.agents import factory
    from rtxclaw_core.session import Session

    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "rp1"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "rp1",
        "engine": "local_llm",
    }) + "\n")

    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
        agent = factory.load_agent("rp1")
        s = agent.create_session()
        # Empty case
        assert agent.compose_round_preamble(s, "hi") == []
        # With pinned + summary
        s.pinned_facts = ["fact A", "fact B"]
        s.compaction_summary = "earlier we discussed X."
        out = agent.compose_round_preamble(s, "hi again")
        assert len(out) == 2
        assert "PINNED FACTS" in out[0]["content"]
        assert "fact A" in out[0]["content"]
        assert "fact B" in out[0]["content"]
        # The compaction summary marker can vary; just check the body landed.
        assert "earlier we discussed X." in out[1]["content"]


def test_agent_compose_round_preamble_async_honors_preamble_inject_hooks(
    tmp_path: Path,
) -> None:
    """compose_round_preamble_async fires PreambleInject per injector,
    so a hook can SUPPRESS or REPLACE the pinned-facts /
    compaction-summary blocks instead of only wrapping them."""
    import asyncio as _asyncio
    from rtxclaw_core.agents import factory

    home = _isolated_rtxclaw_home(tmp_path)
    agent_dir = home / "agents" / "rp2"
    agent_dir.mkdir(parents=True)
    (agent_dir / "config.json").write_text(json.dumps({
        "name": "rp2",
        "engine": "local_llm",
    }) + "\n")
    # Plug a PreambleInject hook that:
    #   * Suppresses pinned_facts entirely.
    #   * Substitutes compaction_summary with a custom body.
    hooks_json = {
        "hooks": {
            "PreambleInject": [
                {
                    "matcher": "pinned_facts",
                    "hooks": [{
                        "type": "command",
                        # Exit 2 with no body → suppress.
                        "command": "exit 2",
                    }],
                },
                {
                    "matcher": "compaction_summary",
                    "hooks": [{
                        "type": "command",
                        # JSON control: replacementBody substitutes the body.
                        "command": (
                            "printf '%s' "
                            '\'{"hookSpecificOutput":'
                            '{"replacementBody":"plugin-substituted summary"}}\''
                        ),
                    }],
                },
            ],
        },
    }
    (agent_dir / "hooks.json").write_text(json.dumps(hooks_json))

    with mock.patch.dict(os.environ, {"RTXCLAW_HOME": str(home)}):
        agent = factory.load_agent("rp2")
        s = agent.create_session()
        s.pinned_facts = ["dropped fact"]
        s.compaction_summary = "original summary"

        out = _asyncio.run(
            agent.compose_round_preamble_async(s, "hello"),
        )
        # pinned_facts suppressed → no "PINNED FACTS" / "dropped fact".
        joined = "\n".join(m.get("content") or "" for m in out)
        assert "PINNED FACTS" not in joined, (
            f"pinned_facts should have been suppressed by the hook; got: {out!r}"
        )
        assert "dropped fact" not in joined
        # compaction_summary substituted with the plugin's body.
        assert "plugin-substituted summary" in joined, (
            f"compaction_summary should have been replaced; got: {out!r}"
        )
        assert "original summary" not in joined


def test_acp_translation_walks_full_event_stream() -> None:
    """``agent_events_to_acp`` translates each variant correctly and
    enforces the exactly-one-stopReason contract."""
    import asyncio
    from rtxclaw_core.agents.engine import (
        TextDelta, ToolCallStarted, ToolCallResult,
        TurnError, TurnDone, TurnStarted,
    )
    from rtxclaw_core.agents.acp_translation import agent_events_to_acp

    async def fake_stream():
        yield TurnStarted(turn_id="t1", rtxclaw_session_id="s1")
        yield TextDelta(text="hello", channel="content")
        yield TextDelta(text="hmm", channel="thinking")
        yield ToolCallStarted(call_id="c1", name="Read", arguments={"p": "/x"})
        yield ToolCallResult(call_id="c1", ok=True, content="body")
        yield TurnError(message="boom", classification="rate_limit")
        yield TurnDone(state="error", metrics={"prompt_tokens": 100})
        # Engine bug — duplicate terminal. Translator must drop it.
        yield TurnDone(state="ok", metrics={})

    captured: list = []

    async def on_started(ev):
        captured.append(ev.turn_id)

    async def collect():
        out = []
        async for msg in agent_events_to_acp(
            fake_stream(),
            context_window=8192,
            on_turn_started=on_started,
        ):
            out.append(msg)
        return out

    out = asyncio.run(collect())

    # Captured side-channel
    assert captured == ["t1"]

    # Map each event to its translated dict
    kinds = [
        m.get("sessionUpdate") if "sessionUpdate" in m else "STOP"
        for m in out
    ]
    assert kinds == [
        "agent_message_chunk",   # TextDelta content
        "agent_thought_chunk",   # TextDelta thinking
        "tool_call",             # ToolCallStarted
        "tool_call_update",      # ToolCallResult
        "agent_message_chunk",   # TurnError prose (no stopReason!)
        "usage_update",          # TurnDone with prompt_tokens
        "STOP",                  # TurnDone state=error → stopReason
    ]
    # Verify exactly one stopReason emitted
    stops = [m for m in out if "stopReason" in m]
    assert len(stops) == 1
    assert stops[0]["stopReason"] == "end_turn"


def test_external_cli_no_resume_flag_by_kind() -> None:
    """When the composed system prompt's sha changes, the engine MUST
    set the no-resume flag specific to its CLI — claude_cli sets
    ``_rtxclaw_claude_no_resume``, codex_cli sets
    ``_rtxclaw_codex_no_resume``, gemini_cli sets
    ``_rtxclaw_gemini_no_resume``. Setting the wrong key (or always
    setting claude's) silently makes codex/gemini resume the stale
    CLI session and ignore the edited SOUL/AGENTS/TOOLS. Regression
    guard for codex audit final-pass #3 + gemini audit #3.
    """
    from rtxclaw_core.agents.engine import EngineKind
    from rtxclaw_core.agents.external_cli import ExternalCliEngine

    # Surface the mapping the run_turn body uses. We test it via the
    # production logic — read the dict literal directly from the
    # source file so a rename in run_turn is caught here, not by
    # silent codex/gemini stale-session bugs in the field.
    src = (Path(__file__).resolve().parent.parent
           / "src" / "rtxclaw_core" / "agents" / "external_cli.py"
           ).read_text(encoding="utf-8")
    assert "EngineKind.CLAUDE_CLI: \"_rtxclaw_claude_no_resume\"" in src
    assert "EngineKind.CODEX_CLI:  \"_rtxclaw_codex_no_resume\"" in src
    assert "EngineKind.GEMINI_CLI: \"_rtxclaw_gemini_no_resume\"" in src
    # And that the runners actually read those keys (the OTHER half
    # of the bug — flag set but runner doesn't honor it would also
    # silently resume).
    runners_src = (Path(__file__).resolve().parent.parent
                   / "src" / "rtxclaw_core" / "tools" / "runners.py"
                   ).read_text(encoding="utf-8")
    assert "_rtxclaw_claude_no_resume" in runners_src
    assert "_rtxclaw_codex_no_resume"  in runners_src
    assert "_rtxclaw_gemini_no_resume" in runners_src


# Notes on what this file does NOT re-cover:
#
# * Multi-round dispatch / compaction / loop detection / compact_context
#   tool intercept run inside CoreBackend.prompt; local-LLM agents on
#   the new AgentACPBackend path delegate to CoreBackend in-process so
#   those behaviors run unchanged. They're exercised by the existing
#   tests/test_50_openai_endpoint.py end-to-end suite.
# * Live-subprocess fidelity (real ``claude -p`` / ``codex exec`` /
#   ``gemini`` invocation, real CLI parsing, real signal group cancel)
#   is covered by the legacy ``run_delegate_<cli>_async`` runner tests.
#   The new Engine layer wraps those runners rather than replacing them,
#   so the runner suite still applies.
# * Gateway cutover + frontend wiring (TUI / Telegram) + /subagents
#   listing are exercised by tests/test_50_openai_endpoint.py and the
#   TUI / Telegram suites — no stand-in stubs here.
