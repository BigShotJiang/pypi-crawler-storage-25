"""Step 23 — SessionIndex (sqlite + FTS5) coverage.

The session index lives at ``<agent_home>/sessions/sessions.db`` and
backs ``rtxclaw memory search`` for full-text recall across saved
turns. ``SessionIndex.search`` is one of the two recall surfaces (the
other is the markdown memory index from test_14), so a regression in
the FTS layer silently breaks recall — turns appear to vanish even
though their JSON is still on disk.

Coverage:
- ``index_session`` upserts metadata + each non-empty turn.
- ``in_progress`` and empty turns are skipped (they have no
  searchable content).
- Re-indexing the same session updates rows in place — no
  duplicates.
- ``remove_session`` drops every related row.
- ``index_session_file`` is tolerant of bad JSON.
- ``reindex_all`` walks the JSON corpus and skips delegate-state
  files (``*.delegate_*.json``).
- FTS search returns the hit when the query matches a turn's text
  and respects the ``min_score`` threshold by default.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from rtxclaw_core.session_index import SessionIndex


def _session_dict(h: str, *, turns: list[dict]) -> dict:
    """Mirror the on-disk session shape ``Session.save`` writes."""
    return {
        "hash": h,
        "title": f"untitled-{h[-8:]}",
        "created_at": "2026-05-06T02:00:00+00:00",
        "system_prompt": "you are a helper",
        "model": "qwen3-30b",
        "endpoint": "http://x:8001",
        "workspace_origin": "tui",
        "turns": turns,
    }


def _turn(idx: int, user: str, content: str, **extra) -> dict:
    return {
        "user": user,
        "content": content,
        "started_at": f"2026-05-06T02:0{idx}:00+00:00",
        "ended_at": f"2026-05-06T02:0{idx}:30+00:00",
        "aborted": False,
        "in_progress": False,
        **extra,
    }


def test_index_session_returns_count(tmp_path: Path) -> None:
    idx = SessionIndex(tmp_path)
    n = idx.index_session(_session_dict("h1", turns=[
        _turn(1, "what's a sovereign agent?",
              "A sovereign agent runs locally with no remote control."),
        _turn(2, "ok and rtxclaw?",
              "rtxclaw is the flagship sovereign-inference tui agent."),
    ]))
    assert n == 2


def test_in_progress_and_empty_turns_skipped(tmp_path: Path) -> None:
    idx = SessionIndex(tmp_path)
    n = idx.index_session(_session_dict("h2", turns=[
        _turn(1, "hi", "hello there"),
        _turn(2, "next", "", in_progress=True),       # in-progress → skip
        _turn(3, "", ""),                             # empty → skip
        _turn(4, "real", "this should land"),
    ]))
    assert n == 2


def test_reindex_does_not_duplicate(tmp_path: Path) -> None:
    """Same hash, second call → row count stays the same (upsert
    semantics). FTS rows must be aligned with the new turn list."""
    idx = SessionIndex(tmp_path)
    payload = _session_dict("h3", turns=[
        _turn(1, "first", "first answer"),
        _turn(2, "second", "second answer"),
    ])
    idx.index_session(payload)
    idx.index_session(payload)
    hits = idx.search("first answer", top_k=10, min_score=0.0)
    # Zero or one hits, never two — duplicate rows would yield two.
    assert len(hits) <= 1


def test_remove_session_drops_rows(tmp_path: Path) -> None:
    idx = SessionIndex(tmp_path)
    idx.index_session(_session_dict("h4", turns=[
        _turn(1, "u", "secret-token-content"),
    ]))
    assert idx.search("secret-token-content", top_k=5, min_score=0.0)
    idx.remove_session("h4")
    assert idx.search("secret-token-content", top_k=5, min_score=0.0) == []


def test_index_session_file_tolerates_bad_json(tmp_path: Path) -> None:
    bad = tmp_path / "broken.json"
    bad.write_text("{not parseable", encoding="utf-8")
    idx = SessionIndex(tmp_path)
    # Returns 0, does not raise.
    assert idx.index_session_file(bad) == 0


def test_reindex_all_skips_delegate_state_files(tmp_path: Path) -> None:
    """``<hash>.delegate_claude.json`` files store delegate session
    state, not rtxclaw turns. They must be skipped or reindex_all
    silently corrupts the index with malformed payloads."""
    idx = SessionIndex(tmp_path)
    # Clean session file.
    (idx.sessions_dir / "abc123.json").write_text(
        json.dumps(_session_dict("abc123", turns=[
            _turn(1, "u", "real turn content"),
        ])),
        encoding="utf-8",
    )
    # Decoy delegate-state file.
    (idx.sessions_dir / "abc123.delegate_claude.json").write_text(
        json.dumps({"session_id": "external-cli-state"}),
        encoding="utf-8",
    )
    stats = idx.reindex_all()
    assert stats["files"] == 1, (
        f"reindex_all walked the delegate file: {stats}"
    )
    assert stats["indexed_turns"] == 1


def test_search_finds_indexed_turn(tmp_path: Path) -> None:
    idx = SessionIndex(tmp_path)
    idx.index_session(_session_dict("h5", turns=[
        _turn(1, "where is the dashboard?",
              "The dashboard runs on TB05 at port 3000 (Gitea) and "
              "the SCHED panel lives at /sched."),
    ]))
    hits = idx.search("dashboard SCHED", top_k=5, min_score=0.0)
    assert hits, "FTS search returned nothing for an indexed phrase"
    # All hits should reference our session.
    for h in hits:
        assert getattr(h, "session_hash", None) == "h5" or "h5" in str(h)


def test_search_empty_query_returns_empty(tmp_path: Path) -> None:
    idx = SessionIndex(tmp_path)
    idx.index_session(_session_dict("h6", turns=[
        _turn(1, "u", "anything"),
    ]))
    assert idx.search("", top_k=5, min_score=0.0) == []
    assert idx.search("   ", top_k=5, min_score=0.0) == []
