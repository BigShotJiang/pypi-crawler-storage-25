"""Step 26 — Telegram bot module-level helper coverage.

The bot's outbound text path runs through three small helpers that
each have edge cases worth pinning:

* ``_truncate_for_telegram`` — last-line-of-defense for one-shot
  ``sendMessage`` calls. Anything beyond ``TELEGRAM_MAX_TEXT`` (4000)
  gets clipped with a ``[…]`` marker.
* ``_split_at`` — picks a clean break index for the rolling-message
  rollover (when the streaming buffer crosses 4000 chars). Prefers
  newlines, then spaces, falls through to hard-cut for one big
  unbroken token.
* ``_load_acp_session_map`` — chat → session id persistence; missing
  / malformed file yields an empty dict so the bot doesn't crash on a
  bad write.

These run with no live transport so they earn their own slot
separate from the integration test_10 surface.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from rtxclaw_acp.client.client import AcpRemoteError, AcpTransportClosed
from rtxclaw_telegram.bot import (
    TELEGRAM_MAX_TEXT,
    _RollingMessage,
    _is_recoverable_session_error,
    _load_acp_session_map,
    _load_visibility_map,
    _save_visibility_map,
    _split_at,
    _truncate_for_telegram,
)
from rtxclaw_telegram.config import TelegramConfig


# ---- _truncate_for_telegram ----------------------------------------


def test_truncate_passes_through_short_text() -> None:
    short = "hello world"
    assert _truncate_for_telegram(short) == short


def test_truncate_clips_long_text_with_marker() -> None:
    long_text = "x" * (TELEGRAM_MAX_TEXT + 100)
    out = _truncate_for_telegram(long_text)
    assert len(out) <= TELEGRAM_MAX_TEXT
    assert out.endswith("[…]")


def test_truncate_at_exact_boundary_unchanged() -> None:
    text = "y" * TELEGRAM_MAX_TEXT
    assert _truncate_for_telegram(text) == text


# ---- _split_at -----------------------------------------------------


def test_split_returns_full_length_when_under_max() -> None:
    text = "tiny"
    assert _split_at(text, 100) == len("tiny")


def test_split_prefers_newline_in_right_half() -> None:
    """A newline within the right half of ``max_len`` should be the
    cut point so paragraphs stay intact across rollover."""
    text = "a" * 60 + "\n" + "b" * 50
    cut = _split_at(text, 100)
    assert cut == 60  # rfind('\n', 0, 100) → 60


def test_split_falls_back_to_space_when_no_late_newline() -> None:
    text = "a" * 60 + " " + "b" * 50
    cut = _split_at(text, 100)
    assert cut == 60


def test_split_hard_cuts_one_big_unbroken_token() -> None:
    """A 100-char base64 blob with no whitespace/newline → hard cut at
    ``max_len`` rather than fragmenting earlier."""
    text = "ABCDEFGHIJ" * 12  # 120 chars, no whitespace
    cut = _split_at(text, 100)
    assert cut == 100


def test_split_ignores_early_newline_too_left_of_half() -> None:
    """Newline at the very start of the buffer → fall through, since
    splitting there would produce a near-empty head chunk."""
    text = "\n" + "a" * 99
    cut = _split_at(text, 100)
    assert cut == 100  # newline at index 0 < half(50), skipped


# ---- _load_acp_session_map -----------------------------------------


@pytest.fixture
def tg_in_tmp(tmp_path: Path, monkeypatch) -> TelegramConfig:
    """Build a :class:`TelegramConfig` whose ``home`` points at a
    fresh tmp directory.

    The bot is now its own service. ``TelegramConfig.home`` reads
    ``$RTXCLAW_HOME`` (or ``$RTXCLAW_TELEGRAM_HOME``) lazily, so
    monkey-patching ``RTXCLAW_HOME`` redirects every bot path
    (``sessions.json``, ``offset.json``, ``logs/telegram.log``)
    under the tmp dir for the test's duration.
    """
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    tg = TelegramConfig()
    tg.home.mkdir(parents=True, exist_ok=True)
    return tg


def test_load_session_map_missing_file_returns_empty(
    tg_in_tmp: TelegramConfig,
) -> None:
    assert _load_acp_session_map(tg_in_tmp) == {}


def test_load_session_map_malformed_json_returns_empty(
    tg_in_tmp: TelegramConfig,
) -> None:
    tg_in_tmp.sessions_path.write_text("{ not valid", encoding="utf-8")
    # No raise, just empty.
    assert _load_acp_session_map(tg_in_tmp) == {}


def test_load_session_map_round_trip(tg_in_tmp: TelegramConfig) -> None:
    """The on-disk shape is now nested (``{chat_key: {agent: sid}}``)
    so the bot can carry one ACP session id per ``(chat, agent)`` pair.
    Legacy flat records (Phase A: ``{chat_key: sid}``) are hoisted
    onto ``{default_agent: sid}`` for transparent migration."""
    # Nested shape — what the bot writes today.
    nested = {"123456": {"main": "sess_abc"}, "789012": {"main": "sess_def"}}
    tg_in_tmp.sessions_path.write_text(json.dumps(nested), encoding="utf-8")
    out = _load_acp_session_map(tg_in_tmp)
    assert out == nested

    # Legacy flat shape — must be migrated under the default agent.
    flat = {"123456": "sess_abc", "789012": "sess_def"}
    tg_in_tmp.sessions_path.write_text(json.dumps(flat), encoding="utf-8")
    out = _load_acp_session_map(tg_in_tmp)
    default = tg_in_tmp.default_agent or "main"
    assert out == {
        "123456": {default: "sess_abc"},
        "789012": {default: "sess_def"},
    }


def test_load_session_map_drops_non_string_values(
    tg_in_tmp: TelegramConfig,
) -> None:
    """A bad write that left an int or list under a chat_id key should
    be ignored gracefully — better to drop the bad entry than crash
    on the next message from that chat. ``"123"`` here uses the legacy
    flat shape so it migrates onto the default agent's sub-map."""
    payload = {"123": "good_id", "456": 42, "789": ["bad"]}
    tg_in_tmp.sessions_path.write_text(json.dumps(payload), encoding="utf-8")
    out = _load_acp_session_map(tg_in_tmp)
    default = tg_in_tmp.default_agent or "main"
    assert out.get("123", {}).get(default) == "good_id"
    # Bad chat_id entries (int / list values) must NOT appear at all,
    # or — if the impl chose to coerce them — must be a sub-dict, not
    # a raw int / list.
    if "456" in out:
        assert isinstance(out["456"], dict)
    if "789" in out:
        assert isinstance(out["789"], dict)


# ---- routing -------------------------------------------------------


def test_chat_key_bare() -> None:
    assert TelegramConfig.chat_key(123) == "123"


def test_chat_key_with_thread() -> None:
    assert TelegramConfig.chat_key(-1003, 4) == "-1003:4"


def test_agent_for_uses_default_when_unrouted() -> None:
    tg = TelegramConfig(default_agent="main")
    assert tg.agent_for(42) == "main"
    assert tg.agent_for(42, 1) == "main"


def test_agent_for_thread_specific_route_wins() -> None:
    tg = TelegramConfig(
        default_agent="main",
        agent_routes={"-1003:4": "scraper", "-1003": "main"},
    )
    assert tg.agent_for(-1003) == "main"
    assert tg.agent_for(-1003, 4) == "scraper"
    # Different thread on same chat falls back to bare-chat route.
    assert tg.agent_for(-1003, 7) == "main"


# ---- _RollingMessage whitespace-edit guard -------------------------


class _FakeAPI:
    """Minimal stub of ``_TelegramAPI`` capturing edit_message calls
    so we can assert what (if anything) the rolling renderer would
    actually send to Telegram."""

    def __init__(self) -> None:
        self.edits: list[str] = []

    async def edit_message(
        self, chat_id: int, message_id: int, text: str,
    ) -> tuple[bool, float]:
        self.edits.append(text)
        return (True, 0.0)

    async def send_message(self, *args, **kwargs):  # noqa: ARG002 — unused in these tests
        return 1


def test_rolling_update_skips_whitespace_only_buffer() -> None:
    """Models often emit a few leading ``\\n`` chars before the real
    body lands. Telegram's editMessageText 400s on whitespace-only
    text (``Bad Request: text must be non-empty``), which previously
    burned an EDIT FAIL per chunk and left the chat stuck on
    ``💭 thinking…``. The renderer must withhold the edit until at
    least one non-whitespace char shows up."""
    api = _FakeAPI()
    rm = _RollingMessage(api, chat_id=42, placeholder_id=100)  # type: ignore[arg-type]
    # Force-update to bypass the edit-throttle and embargo gates so
    # we exercise the whitespace branch directly.
    import asyncio
    asyncio.run(rm.update("\n\n", force=True))
    asyncio.run(rm.update("\n\n\n\n", force=True))
    assert api.edits == [], (
        f"whitespace-only buffer should not hit Telegram; "
        f"got edits: {api.edits!r}"
    )
    asyncio.run(rm.update("\n\nhello", force=True))
    assert any("hello" in e for e in api.edits), (
        f"once non-whitespace lands, the edit should fire; "
        f"got edits: {api.edits!r}"
    )


# ---- _is_recoverable_session_error --------------------------------
#
# Locks in the contract that drives the bot's session-reopen retry:
# only known "session id is no longer attached" failures recover; a
# real model error (-32602 invalid params, custom backend error, etc.)
# must still surface as ``⚠️ agent error — see telegram.log`` so the
# operator notices.


def test_recoverable_no_live_child_message() -> None:
    """The exact error the gateway raises when an idle-reaped or
    cross-restart sid hits ``session/prompt``. Must classify as
    recoverable — that's the whole point of the retry path."""
    exc = AcpRemoteError(
        code=-32603,
        message=(
            "backend error: LookupError: no live child owns session "
            "'69ff…' (idle-reaped or never created on this gateway)"
        ),
    )
    assert _is_recoverable_session_error(exc) is True


def test_recoverable_idle_reaped_phrase() -> None:
    """Future variants of the message that still contain the
    ``idle-reaped`` marker should also recover."""
    exc = AcpRemoteError(code=-32603, message="session was idle-reaped")
    assert _is_recoverable_session_error(exc) is True


def test_recoverable_transport_closed() -> None:
    """``AcpTransportClosed`` means the SSE stream died (gateway
    restart, OOM, network blip). Reopening the client + session
    is exactly what recovery does, so it must classify as recoverable."""
    assert _is_recoverable_session_error(
        AcpTransportClosed("transport closed mid-flight"),
    ) is True
    assert _is_recoverable_session_error(
        AcpTransportClosed("client is closed"),
    ) is True


def test_not_recoverable_arbitrary_remote_error() -> None:
    """A generic backend error (parse / model / 500) is NOT a stale
    session — re-opening would just hit the same failure. Surface it."""
    exc = AcpRemoteError(
        code=-32603,
        message="backend error: ValueError: prompt blocks malformed",
    )
    assert _is_recoverable_session_error(exc) is False


def test_not_recoverable_invalid_params() -> None:
    """JSON-RPC ``-32602`` (invalid params) is a client-side bug — the
    retry would replay the same broken request."""
    exc = AcpRemoteError(code=-32602, message="messageId must be string or null")
    assert _is_recoverable_session_error(exc) is False


def test_not_recoverable_plain_exception() -> None:
    """Unrelated exception types stay non-recoverable; recovery is
    narrowly scoped to ACP errors we recognize."""
    assert _is_recoverable_session_error(RuntimeError("boom")) is False
    assert _is_recoverable_session_error(ValueError("nope")) is False


# ---- _strip_bot_mention -------------------------------------------
#
# Pins the inbound-text normalisation that turns Telegram's
# group-mention shapes into agent-friendly text. Without it the bot
# falls through to "unknown command" on ``/cmd@<botname>`` and the
# model sees its own handle in every conversational mention.


def _make_bot(monkeypatch, username: str = "rtxclawai_bot") -> Any:
    """Build a bare ``AcpTelegramBot`` with ``_bot_username`` pinned.

    The full constructor needs a real ``TelegramConfig`` + a venv
    bootstrap; for these tests we only exercise one method, so we
    object.__new__ a minimal instance and set the lone attribute the
    method reads. Keeps the test free of network / disk I/O.
    """
    from rtxclaw_telegram.bot import AcpTelegramBot
    bot = AcpTelegramBot.__new__(AcpTelegramBot)
    bot._bot_username = username
    return bot


def test_strip_bot_mention_command_suffix() -> None:
    """``/new@rtxclawai_bot`` must normalise to ``/new`` so the
    literal-comparison dispatcher in ``_handle_command`` matches."""
    bot = _make_bot(None)
    assert bot._strip_bot_mention("/new@rtxclawai_bot") == "/new"
    assert bot._strip_bot_mention("/help@rtxclawai_bot list") == "/help list"


def test_strip_bot_mention_leading_handle() -> None:
    """Conversational ``@<botname> question`` should reach the model
    as just ``question`` — the bot's own handle isn't part of the
    user's intent."""
    bot = _make_bot(None)
    assert bot._strip_bot_mention("@rtxclawai_bot what time is it") == (
        "what time is it"
    )


def test_strip_bot_mention_inline_handle() -> None:
    """Mid-sentence mentions (``hey @bot can you …``) get stripped
    too, with surrounding whitespace collapsed cleanly."""
    bot = _make_bot(None)
    assert bot._strip_bot_mention("hey @rtxclawai_bot can you help") == (
        "hey can you help"
    )


def test_strip_bot_mention_case_insensitive() -> None:
    """Telegram is case-preserving but case-insensitive on usernames;
    ``@RTXClawAI_Bot`` must be recognised as the same bot."""
    bot = _make_bot(None)
    assert bot._strip_bot_mention("/new@RTXClawAI_Bot") == "/new"


def test_strip_bot_mention_noop_without_username() -> None:
    """Cold-start race: messages can arrive before ``getMe`` lands
    ``self._bot_username``. The helper must pass text through verbatim
    rather than guess and mangle."""
    bot = _make_bot(None, username="")
    assert bot._strip_bot_mention("/new@rtxclawai_bot") == (
        "/new@rtxclawai_bot"
    )


def test_strip_bot_mention_passthrough_other_handles() -> None:
    """Mentions of OTHER users (``@alice``) must NOT be stripped —
    they're part of the message the model needs to see."""
    bot = _make_bot(None)
    assert bot._strip_bot_mention("hi @alice did you see this?") == (
        "hi @alice did you see this?"
    )


# ---- _user_allowed -------------------------------------------------
#
# Pins the per-user allowlist gate. The chat-level allowlist still
# governs IS_AUTHORIZED; this is the second-stage filter for shared
# groups where the operator wants the bot to ignore everyone except
# specific people.


def _make_bot_with_cfg(
    monkeypatch,
    *,
    allowed_user_ids: list[int] = None,
    mention_required: bool = False,
    bot_username: str = "rtxclawai_bot",
    bot_user_id: int = 100,
) -> Any:
    from rtxclaw_telegram.bot import AcpTelegramBot
    bot = AcpTelegramBot.__new__(AcpTelegramBot)
    bot._bot_username = bot_username
    bot._bot_user_id = bot_user_id

    class _Cfg:
        pass
    cfg = _Cfg()
    cfg.allowed_user_ids = list(allowed_user_ids or [])
    cfg.mention_required_in_groups = mention_required
    bot.tg_cfg = cfg
    return bot


def test_user_allowed_empty_allowlist_passes_everyone() -> None:
    """Default config (empty allowlist) ⇒ every user that survived
    the chat-level allowlist passes — preserves drop-in upgrade."""
    bot = _make_bot_with_cfg(None, allowed_user_ids=[])
    assert bot._user_allowed(42) is True
    assert bot._user_allowed(None) is True


def test_user_allowed_blocks_outside_allowlist() -> None:
    """A non-empty allowlist becomes strict — only those exact ids
    pass; everyone else is dropped silently upstream."""
    bot = _make_bot_with_cfg(None, allowed_user_ids=[42, 99])
    assert bot._user_allowed(42) is True
    assert bot._user_allowed(99) is True
    assert bot._user_allowed(7) is False
    assert bot._user_allowed(None) is False


# ---- _addressed_to_bot --------------------------------------------
#
# Pins the three signals the mention-required gate accepts: explicit
# @<botname>, replies to a bot message, and ``text_mention`` entities
# pointing at the bot's user id.


def test_addressed_to_bot_at_handle() -> None:
    """Plain ``@<botname>`` anywhere in the raw text counts."""
    bot = _make_bot_with_cfg(None)
    assert bot._addressed_to_bot("@rtxclawai_bot what's up", {}) is True
    assert bot._addressed_to_bot("/help@rtxclawai_bot", {}) is True
    assert bot._addressed_to_bot("hey @RTXClawAI_Bot can you?", {}) is True


def test_addressed_to_bot_reply_to_bot() -> None:
    """Replies to one of the bot's own messages count even without
    typing the @handle — Telegram's swipe-to-reply convention."""
    bot = _make_bot_with_cfg(None, bot_user_id=8775386091)
    msg = {"reply_to_message": {"from": {"id": 8775386091}}}
    assert bot._addressed_to_bot("looks great", msg) is True


def test_addressed_to_bot_reply_to_someone_else() -> None:
    """A reply to a different user does NOT count as a mention,
    even if the bot is in the same group."""
    bot = _make_bot_with_cfg(None, bot_user_id=100)
    msg = {"reply_to_message": {"from": {"id": 7}}}
    assert bot._addressed_to_bot("looks great", msg) is False


def test_addressed_to_bot_text_mention_entity() -> None:
    """``text_mention`` entities (mentions of users without an @-handle)
    should match when they target the bot's user id."""
    bot = _make_bot_with_cfg(None, bot_user_id=100)
    msg = {"entities": [{"type": "text_mention", "user": {"id": 100}}]}
    assert bot._addressed_to_bot("ping you", msg) is True


def test_addressed_to_bot_unrelated_message_returns_false() -> None:
    """A bare conversational message in a group with no mention,
    no reply, no entity → not addressed; gate drops it."""
    bot = _make_bot_with_cfg(None, bot_user_id=100)
    assert bot._addressed_to_bot("looks great", {}) is False


# ---- TelegramConfig persistence -----------------------------------


def test_config_round_trips_new_fields(tmp_path: Path, monkeypatch) -> None:
    """``allowed_user_ids`` + ``mention_required_in_groups`` survive
    a save/load cycle. Pins the wire format so a future field rename
    or drop trips this test instead of silently degrading prod."""
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    tg = TelegramConfig(
        bot_token="t",
        allowed_chat_ids=[1, 2],
        allowed_user_ids=[42, 99],
        mention_required_in_groups=True,
    )
    tg.home.mkdir(parents=True, exist_ok=True)
    tg.save()
    reloaded = TelegramConfig.load()
    assert reloaded.allowed_user_ids == [42, 99]
    assert reloaded.mention_required_in_groups is True


def test_config_load_coerces_invalid_user_ids(
    tmp_path: Path, monkeypatch,
) -> None:
    """Bad entries in ``allowed_user_ids`` should drop, not crash,
    matching the chat-id resilience already in place."""
    monkeypatch.setenv("RTXCLAW_HOME", str(tmp_path))
    home = tmp_path / "telegram"
    home.mkdir(parents=True)
    (home / "config.json").write_text(json.dumps({
        "allowed_user_ids": [42, "99", "not-an-int", None, 7],
        "mention_required_in_groups": True,
    }), encoding="utf-8")
    reloaded = TelegramConfig.load()
    assert reloaded.allowed_user_ids == [42, 99, 7]
    assert reloaded.mention_required_in_groups is True


# ---- _dispatch_blocks tool-header rendering -----------------------
#
# Pins the contract: with ``/tools on`` (visibility.tool_output ==
# "on") a ``ToolCallStart`` ACP update must produce a visible
# ``🔧 <title>…`` header in the assembled reply text. Two regressions
# would break this without anyone noticing until a user complained:
# (1) the closure capture of ``tool_output_visible`` going stale
# after the recovery-retry refactor, (2) ``_push_tool_header``
# accidentally falling through to an early return.


class _FakePromptStream:
    """Stand-in for ``AcpClient.session_prompt`` — yields a fixed
    sequence of ``SessionNotification`` updates plus a terminal
    ``PromptResponse``. Lets the dispatcher exercise the rendering
    path without spinning up an actual agent + LLM."""

    def __init__(self, updates: list, stop_reason: str = "end_turn") -> None:
        self.updates = updates
        self.stop_reason = stop_reason

    def __call__(self, *_args, **_kwargs):
        async def _gen():
            import acp.schema as _acp
            for u in self.updates:
                yield _acp.SessionNotification.model_validate({
                    "sessionId": "sid-test",
                    "update": u,
                })
            yield _acp.PromptResponse.model_validate({
                "stopReason": self.stop_reason,
            })
        return _gen()


def _make_dispatcher_bot(monkeypatch, *, tool_output: str = "on") -> Any:
    """Bot stub wired tightly enough to drive ``_dispatch_blocks``.

    Bypasses the real constructor: we attach only the fields the
    dispatcher reads (visibility, sessions, locks, log, agent
    config). The ACP client + AgentConfig are themselves stubs that
    return canned data — the test is about the dispatcher's
    rendering decisions, not the network.
    """
    import logging
    from rtxclaw_telegram.bot import AcpTelegramBot

    bot = AcpTelegramBot.__new__(AcpTelegramBot)
    bot._log = logging.getLogger("test")
    bot._chat_locks = {}
    bot._visibility = {
        "42": {"reasoning_visibility": "off", "tool_output": tool_output},
    }
    bot._sessions = {"42": {"main": "sid-test"}}
    bot._stale = set()
    bot.trusted_chats = set()

    # Per-PID placeholder path — never written to, but kept unique so
    # two pytest workers on the same host don't end up sharing the same
    # nominal "home" string (which would only matter if a future test
    # actually started writing there, but cheap to make safe now).
    import os as _os
    import tempfile as _tempfile
    _placeholder_home = Path(_tempfile.gettempdir()) / f"_test_agent_home_{_os.getpid()}"

    class _AgentCfg:
        name = "main"
        home = _placeholder_home
    cfg = _AgentCfg()
    bot._agent_cfg_cache = {"main": cfg}
    bot._agent_cfg = lambda chat_id, thread_id=None: cfg

    class _TgCfg:
        @staticmethod
        def chat_key(chat_id, thread_id=None):
            return str(chat_id) if thread_id is None else f"{chat_id}:{thread_id}"

        def agent_for(self, chat_id, thread_id=None):
            return "main"
    bot.tg_cfg = _TgCfg()

    return bot


def test_dispatch_renders_tool_header_when_tools_on() -> None:
    """``ToolCallStart`` with ``/tools on`` ⇒ assembled reply contains
    the ``🔧 <title>…`` header above the model's content."""
    import asyncio
    bot = _make_dispatcher_bot(None, tool_output="on")
    # Stub client: yields one tool-call start, then content, then end.
    fake_client = type("C", (), {})()
    fake_client.session_prompt = _FakePromptStream([
        {
            "sessionUpdate": "tool_call",
            "toolCallId": "call-1",
            "title": "tweet_search",
            "kind": "other",
            "status": "in_progress",
            "rawInput": {"q": "iran"},
        },
        {
            "sessionUpdate": "agent_message_chunk",
            "content": {"type": "text", "text": "Here are recent tweets."},
        },
    ])
    fake_client.session_load = lambda *a, **kw: asyncio.sleep(0)
    fake_client.session_new = lambda *a, **kw: asyncio.sleep(0)

    async def _open(chat_id, thread_id=None):
        return fake_client
    bot._get_or_open_client = _open
    bot._clients = {"42": fake_client}

    import acp.schema as _acp
    blocks = [_acp.TextContentBlock(type="text", text="hi")]
    out = asyncio.run(bot._dispatch_blocks(42, blocks))
    assert "🔧 tweet_search…" in out, (
        f"tool header missing from /tools on render: {out!r}"
    )
    assert "Here are recent tweets." in out, (
        f"content missing from render: {out!r}"
    )


def test_visibility_round_trips_through_disk(
    tg_in_tmp: TelegramConfig,
) -> None:
    """``/tools on`` and ``/reasoning stream`` must outlive a bot
    restart. Pins the on-disk shape: a save-then-load cycle returns
    the exact dict (string tokens preserved verbatim, no shape drift)."""
    payload = {
        "8484692594": {"reasoning_visibility": "off", "tool_output": "on"},
        "-1003916299625:1661": {
            "reasoning_visibility": "stream",
            "tool_output": "stream",
        },
    }
    _save_visibility_map(tg_in_tmp, payload)
    assert _load_visibility_map(tg_in_tmp) == payload


def test_visibility_load_migrates_legacy_bool(
    tg_in_tmp: TelegramConfig,
) -> None:
    """Pre-3-state-/tools installs persisted ``tool_output_visible``
    as a bool. The loader must hoist it onto the new
    ``tool_output`` string token so a redeploy doesn't silently
    forget the operator's prior choice."""
    legacy = {
        "42": {"reasoning_visibility": "on", "tool_output_visible": True},
        "43": {"tool_output_visible": False},
    }
    tg_in_tmp.visibility_path.parent.mkdir(parents=True, exist_ok=True)
    tg_in_tmp.visibility_path.write_text(json.dumps(legacy), encoding="utf-8")
    out = _load_visibility_map(tg_in_tmp)
    assert out["42"]["reasoning_visibility"] == "on"
    assert out["42"]["tool_output"] == "on"
    assert out["43"]["tool_output"] == "off"


def test_visibility_load_missing_file_returns_empty(
    tg_in_tmp: TelegramConfig,
) -> None:
    """Fresh install: no visibility.json yet ⇒ loader returns empty
    dict and every chat falls through to the off/off defaults."""
    assert _load_visibility_map(tg_in_tmp) == {}


def test_dispatch_omits_tool_header_when_tools_off() -> None:
    """``/tools off`` ⇒ the header is suppressed; only the model's
    content lands. Prevents a regression from over-eagerly
    rendering tool internals."""
    import asyncio
    bot = _make_dispatcher_bot(None, tool_output="off")
    fake_client = type("C", (), {})()
    fake_client.session_prompt = _FakePromptStream([
        {
            "sessionUpdate": "tool_call",
            "toolCallId": "call-1",
            "title": "tweet_search",
            "kind": "other",
            "status": "in_progress",
            "rawInput": {},
        },
        {
            "sessionUpdate": "agent_message_chunk",
            "content": {"type": "text", "text": "Done."},
        },
    ])
    fake_client.session_load = lambda *a, **kw: asyncio.sleep(0)
    fake_client.session_new = lambda *a, **kw: asyncio.sleep(0)

    async def _open(chat_id, thread_id=None):
        return fake_client
    bot._get_or_open_client = _open
    bot._clients = {"42": fake_client}

    import acp.schema as _acp
    blocks = [_acp.TextContentBlock(type="text", text="hi")]
    out = asyncio.run(bot._dispatch_blocks(42, blocks))
    assert "🔧" not in out, (
        f"/tools off should suppress tool header; got: {out!r}"
    )
    assert "Done." in out


def test_rolling_finalize_falls_back_to_idle_for_whitespace_only() -> None:
    """A model that produces only newlines / spaces (or nothing
    visible) would otherwise 400 the final edit and leave the
    placeholder stale. ``finalize`` must coerce that to the idle
    text so Telegram accepts the edit."""
    api = _FakeAPI()
    rm = _RollingMessage(api, chat_id=42, placeholder_id=100)  # type: ignore[arg-type]
    import asyncio
    asyncio.run(rm.finalize("\n\n   \n"))
    assert api.edits, "finalize must always send a non-empty edit"
    assert api.edits[-1].strip(), (
        f"final edit must not be whitespace-only; got {api.edits[-1]!r}"
    )
