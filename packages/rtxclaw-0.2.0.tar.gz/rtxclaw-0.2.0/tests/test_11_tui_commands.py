"""Step 11 — TUI command coverage (mirrors tests/test_10 but for the TUI).

Drives a headless tmux-launched TUI and exercises every slash command
it accepts (configuration, session control, delegate sugars). Each
test sends keystrokes via ``tmux send-keys`` and inspects the pane via
``tmux capture-pane`` for the marker text the TUI is supposed to
render. Per-turn telemetry rows (classify / prefill / ttft / gen tps /
context len / tokens / wt) are explicitly asserted on at least one
turn so regressions in the metrics pipeline are caught here.

Skipped when:
- ``tmux`` is missing
- ``RTXCLAW_TEST_ENDPOINT`` isn't reachable (handled by the daemon
  fixture that backs this test)
- For the delegation tests: neither ``claude`` nor ``codex`` CLI is on
  PATH

This test reuses the same scaffolded-agent / running-daemon fixtures
that test_10 / test_05 use, so the workspace isolation guarantees and
sandbox wipe at session boundaries are inherited.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import time
from pathlib import Path

import pytest

from conftest import RTXCLAW_BIN


SCROLL = 4000
# Default per-turn ceiling. Bumped per-test for delegate calls (which
# shell out to claude/codex and can take 30-90 s) and /compact (LLM
# round-trip on the planner-only path).
TURN_TIMEOUT_S = 180.0


def _capture(session: str, scrollback: int = SCROLL) -> str:
    cp = subprocess.run(
        ["tmux", "capture-pane", "-t", session, "-p", "-J",
         "-S", f"-{scrollback}"],
        capture_output=True, text=True, timeout=10,
    )
    return cp.stdout if cp.returncode == 0 else ""


def _is_streaming(pane: str) -> bool:
    """In-flight state in the bottom status footer.

    The local-model indicator is ``▶ streaming…``; when the operator
    runs ``/claude`` or ``/codex`` the footer reads ``🤖 claude
    running…`` / ``💻 codex running…`` instead. Treat all three as
    in-flight — without the bridge variants, ``_wait_done``'s 6 s
    quiet-detection fallback would short-circuit while the
    delegate subprocess was still mid-spawn (claude can be silent
    5-10 s before its first stream chunk lands), and the caller
    would assert against a half-finished pane.
    """
    p = pane.lower()
    return (
        "▶ streaming" in p or "streaming…" in p
        or "claude running" in p or "codex running" in p
    )


def _is_done(pane: str) -> bool:
    """Footer carries ``agent <name>``, ``idle``, ``mode:`` once the
    turn finishes. The old format had ``main idle`` adjacent; the
    current footer is reorganised as
    ``idle · agent main · mode: <m> · ctx … · model … · upstream …``,
    so we match the three token-set fields independently. Surviving
    the next footer tweak is cheaper than chasing a literal string.
    """
    p = pane.lower()
    return "agent main" in p and "idle" in p and "mode:" in p


def _send_text(session: str, text: str) -> None:
    subprocess.run(
        ["tmux", "send-keys", "-t", session, text], check=True,
    )
    time.sleep(0.2)
    subprocess.run(
        ["tmux", "send-keys", "-t", session, "Enter"], check=True,
    )


def _wait_chrome(session: str, timeout: float = 30.0) -> str:
    """Wait until the TUI's status footer is rendered. ``mode:`` is the
    stable readiness signal — the input widget no longer ships with a
    ``Message`` placeholder string, so anchoring on the footer is the
    canonical chrome check (matches test_05's ``_wait_chrome``)."""
    deadline = time.time() + timeout
    pane = ""
    while time.time() < deadline:
        pane = _capture(session)
        if "mode:" in pane.lower():
            return pane
        time.sleep(0.4)
    return pane


def _wait_done(session: str, *, timeout: float = TURN_TIMEOUT_S) -> str:
    """Block until the TUI footer leaves the in-flight state and
    settles back to ``idle  ·  agent <name> …``.

    Returns the final pane snapshot. The caller should grep this for
    the markers it expects.

    Two short-circuits:
    - Once we've seen any in-flight indicator (``▶ streaming…``,
      ``🤖 claude running…``, ``💻 codex running…``) AND the pane
      reads idle without that indicator, the turn is done.
    - For commands that don't stream (``/tools on``, ``/refresh``,
      etc.), there's no streaming state to observe — fall back to
      "pane unchanged for the quiet window" instead.

    The quiet window is generous (45 s) so a delegate subprocess that
    sits silent during its own bootstrap (claude/codex can take
    5-10 s before the first stream chunk lands) doesn't cause the
    helper to bail with a half-finished pane.
    """
    deadline = time.time() + timeout
    last_len = -1
    quiet_since = time.time()
    pane = ""
    streaming_seen = False
    while time.time() < deadline:
        pane = _capture(session)
        in_flight = _is_streaming(pane)
        if in_flight:
            streaming_seen = True
            # Active in-flight indicator → reset the quiet window so
            # we don't bail on a delegate subprocess that's just
            # taking a moment between chunks.
            quiet_since = time.time()
        if streaming_seen and _is_done(pane) and not in_flight:
            break
        # Quiet-pane fallthrough — only fires when no in-flight
        # indicator has been seen yet (local-only acks like
        # ``/tools on``) OR the indicator went away. 8 s is generous
        # enough for a steady-state TUI to settle but not so long
        # that ``timeout`` becomes the dominant deadline for fast
        # commands.
        if len(pane) == last_len and not in_flight:
            if time.time() - quiet_since > 8:
                break
        else:
            last_len = len(pane)
            if not in_flight:
                quiet_since = time.time()
        time.sleep(0.6)
    return pane


_AGENT_ERROR_MARKERS: tuple[str, ...] = (
    "agent error",
    "agent unreachable",
    "Traceback (most recent call last)",
    "AcpRemoteError",
)


def _send_and_wait(session: str, text: str,
                   *, timeout: float = TURN_TIMEOUT_S,
                   allow_agent_error: bool = False) -> str:
    """Send a line, wait for the TUI to settle, return the final pane.

    Per operator request ("break the test on any error"): if the
    captured pane contains a known agent-error marker, the helper
    fails the test immediately. The bridge surfaces NameErrors,
    pydantic validation failures, etc. as visible toast strings; a
    test that passed despite an in-pane error envelope is a false
    pass and should regress here.
    """
    _send_text(session, text)
    pane = _wait_done(session, timeout=timeout)
    if not allow_agent_error:
        for marker in _AGENT_ERROR_MARKERS:
            if marker in pane:
                pytest.fail(
                    f"agent error in TUI pane after sending {text!r}:\n"
                    f"  marker: {marker!r}\n"
                    f"  pane tail:\n{pane[-2000:]}"
                )
    return pane


@pytest.fixture
def tmux_session(require_tmux: str, bootstrapped_venv: Path,  # noqa: ARG001
                 sandbox_env, scaffolded_agent: Path,  # noqa: ARG001
                 running_daemon: Path):  # noqa: ARG001
    """Headless TUI launched in auto mode against the running daemon.

    Auto mode lets tool-calling commands like ``/claude`` /
    ``/codex`` run without prompting for permission.
    """
    name = f"rtxclaw-tui-test-{os.getpid()}"
    cp = subprocess.run(
        ["tmux", "new-session", "-d", "-s", name,
         "-c", str(RTXCLAW_BIN.parent), "-x", "220", "-y", "55",
         str(RTXCLAW_BIN)],
        env=sandbox_env, capture_output=True, text=True,
    )
    if cp.returncode != 0:
        pytest.fail(
            f"tmux new-session failed (rc={cp.returncode}):\n{cp.stderr}",
        )
    try:
        yield name
    finally:
        subprocess.run(
            ["tmux", "kill-session", "-t", name],
            capture_output=True,
        )


# ---- helpers for per-test screenshot artefacts -----------------------


def _save_pane(report_dir: Path, name: str, pane: str) -> None:
    out = report_dir / f"tui_{name}.txt"
    out.write_text(pane or "(empty)")


# ---------- the actual tests ----------------------------------------


def test_tui_chrome_renders(tmux_session: str, report_dir: Path) -> None:
    pane = _wait_chrome(tmux_session)
    _save_pane(report_dir, "11_chrome", pane)
    assert pane, "tmux capture-pane returned empty"
    # Chrome readiness: status footer + title bar. The input widget
    # no longer ships with a ``Message`` placeholder (see _wait_chrome
    # comment), so the prompt-line anchor was retired.
    assert "mode:" in pane.lower(), f"status footer missing:\n{pane[-500:]}"
    assert ("AgentChatApp" in pane) or ("rtxclaw" in pane.lower()), (
        f"neither cold-start nor running title found:\n{pane[-500:]}"
    )


def test_help_command(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    pane = _send_and_wait(tmux_session, "/help", timeout=20)
    _save_pane(report_dir, "11_help", pane)
    p = pane.lower()
    # /help should list at least the most-used slash commands.
    assert "/new" in p, f"/help missing /new:\n{pane[-1500:]}"
    assert ("/sessions" in p or "/history" in p), (
        f"/help missing session commands:\n{pane[-1500:]}"
    )
    assert "/claude" in p or "/codex" in p, (
        f"/help missing delegate commands:\n{pane[-1500:]}"
    )


def test_new_and_basic_turn(tmux_session: str, report_dir: Path) -> None:
    """Smoke /new + a prompt; verify both surfaces:

    * Per-message stats row under the assistant response — the dim
      ``─ <alias>/<model> · prefill …ms · ttft …ms · gen … tok/s ·
      ctx … · wt …s`` line stamped per round by
      ``AssistantMessage.set_metrics``.
    * Identity-and-state footer at the bottom — ``<state> · agent
      <name> · mode: <m> · ctx <used>/<max> · model <alias>/<id> ·
      upstream <ok|DOWN>``. The footer carries identity, NOT
      transient acks (those land on ``#status-events``).

    Asserting both because regressions can break either independently
    (we've shipped fixes that flipped the wrong way in both
    directions in recent history).
    """
    _wait_chrome(tmux_session)
    _send_and_wait(tmux_session, "/new", timeout=10)
    pane = _send_and_wait(tmux_session, "say hello in one word", timeout=120)
    _save_pane(report_dir, "11_basic_turn", pane)

    p = pane.lower()
    assert "idle" in p, (
        f"turn didn't reach 'idle' state on the footer:\n{pane[-1500:]}"
    )

    # Poll for per-message stats markers — at least one must paint.
    stat_markers = ("ttft ", " tok/s", " wt ")
    deadline = time.time() + 15
    while time.time() < deadline:
        pane = _capture(tmux_session)
        plower = pane.lower()
        if any(marker in plower for marker in stat_markers):
            break
        time.sleep(0.5)
    _save_pane(report_dir, "11_basic_turn_final", pane)

    plower = pane.lower()
    assert any(marker in plower for marker in stat_markers), (
        "per-message stats row never rendered — "
        "TUI agent_client / AssistantMessage.set_metrics regressed.\n"
        f"Markers checked: {stat_markers}\n\nPane tail:\n{pane[-2000:]}"
    )

    # Status footer MUST carry the full identity strip:
    #   state · agent <name> · mode: <m> · ctx <used>/<max>
    #     · model <alias>/<id> · upstream <ok|DOWN>
    # PR #121 reinstated ctx / model / upstream after they were
    # accidentally dropped — assert they're back so a future
    # "let's simplify the footer" patch can't strip them again
    # without flagging this regression.
    footer_block = "\n".join(pane.splitlines()[-4:]).lower()
    required_in_footer = [
        ("agent ", "agent name"),
        ("mode:", "permission mode"),
        ("ctx ", "ctx used/max"),
        ("model ", "model alias/id"),
        ("upstream", "upstream status"),
    ]
    missing = [
        f"{tok!r} ({label})"
        for tok, label in required_in_footer
        if tok not in footer_block
    ]
    assert not missing, (
        "status footer is missing identity fields — "
        "_refresh_status_bar regressed.\n"
        f"Missing: {', '.join(missing)}\n\nFooter:\n{footer_block}"
    )

    # Transient acks ("session created", "/help printed", etc.) must
    # NOT live on the footer — they land on `#status-events` (the
    # row above). The footer's content should NEVER carry the
    # parenthesised transient (`(<ack>)`) the old code rendered.
    assert "(done" not in footer_block, (
        "footer is rendering the transient `(done · …)` segment — "
        "those moved to the events row above the footer.\n"
        f"Footer:\n{footer_block}"
    )


def test_status_command(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    pane = _send_and_wait(tmux_session, "/status", timeout=20)
    _save_pane(report_dir, "11_status", pane)
    p = pane.lower()
    # The /status panel should mention the agent name + endpoint.
    # We accept any mention of "agent" plus the hostname-ish endpoint
    # token "http" to keep this test resilient to small format changes.
    assert "agent" in p, f"/status missing 'agent':\n{pane[-1500:]}"
    assert "http" in p, f"/status missing endpoint URL:\n{pane[-1500:]}"


def test_mode_commands(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    for mode in ("plan", "ask", "auto"):
        pane = _send_and_wait(tmux_session, f"/mode {mode}", timeout=15)
        assert f"mode: {mode}" in pane.lower(), (
            f"/mode {mode} didn't reflect in status footer:\n{pane[-1200:]}"
        )
    _save_pane(report_dir, "11_mode_cycle", pane)


def test_thinking_toggle(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    pane_on = _send_and_wait(tmux_session, "/thinking on", timeout=15)
    pane_off = _send_and_wait(tmux_session, "/thinking off", timeout=15)
    _save_pane(report_dir, "11_thinking_toggle", pane_off)
    # Both states should land in the footer / status text. Be lenient
    # on case + spacing.
    assert "thinking=on" in pane_on.lower() or "thinking on" in pane_on.lower()
    assert "thinking=off" in pane_off.lower() or "thinking off" in pane_off.lower()


def test_reasoning_toggle(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    _send_and_wait(tmux_session, "/reasoning stream", timeout=15)
    pane = _send_and_wait(tmux_session, "tell me a one-line joke", timeout=120)
    _save_pane(report_dir, "11_reasoning_stream", pane)
    # In stream-mode we should see a thinking marker rendered inline
    # with the response. The TUI uses ``Thought for`` for collapsed
    # thinking blocks.
    assert (
        "thought for" in pane.lower()
        or "▶ thought" in pane.lower()
        or "💭" in pane
    ), f"no reasoning render in stream mode:\n{pane[-1500:]}"


def test_tools_visibility(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    _send_and_wait(tmux_session, "/tools on", timeout=15)
    pane_on = _send_and_wait(
        tmux_session, "list the files in this folder", timeout=180,
    )
    _save_pane(report_dir, "11_tools_on", pane_on)
    # With /tools on, at least one tool marker should land in the
    # transcript (✓ / ✅ / 🔧 — TUI variants).
    has_tool = any(m in pane_on for m in ("▶ ✓", "▶ ✅", "🔧"))
    assert has_tool, (
        f"/tools on but no tool marker rendered:\n{pane_on[-2000:]}"
    )


def test_sessions_listing(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    _send_and_wait(tmux_session, "/new", timeout=10)
    _send_and_wait(tmux_session, "hi", timeout=120)
    pane = _send_and_wait(tmux_session, "/sessions", timeout=20)
    _save_pane(report_dir, "11_sessions", pane)
    # Should print at least the current session id (8-hex-char
    # ``[abc12345]`` style) or the word "session" with a list separator.
    assert "session" in pane.lower(), (
        f"/sessions didn't list anything:\n{pane[-1500:]}"
    )


def test_history_command(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    _send_and_wait(tmux_session, "/new", timeout=10)
    _send_and_wait(tmux_session, "say hi", timeout=120)
    pane = _send_and_wait(tmux_session, "/history", timeout=20)
    _save_pane(report_dir, "11_history", pane)
    assert "hi" in pane.lower() or "say hi" in pane.lower(), (
        f"/history didn't echo the previous turn:\n{pane[-1500:]}"
    )


def test_refresh_command(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    pane = _send_and_wait(tmux_session, "/refresh", timeout=20)
    _save_pane(report_dir, "11_refresh", pane)
    # /refresh is mostly a no-op on TUI but must not error out the
    # session — assert the pane stays usable (footer still shows mode).
    assert "mode:" in pane.lower(), (
        f"/refresh broke the chrome:\n{pane[-1500:]}"
    )


def test_abort_command(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    pane = _send_and_wait(tmux_session, "/abort", timeout=15)
    _save_pane(report_dir, "11_abort", pane)
    # /abort with nothing in flight should ack rather than crash.
    p = pane.lower()
    assert "no in-flight" in p or "abort" in p or "cancel" in p, (
        f"/abort gave no ack:\n{pane[-1500:]}"
    )


def test_models_command(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    pane = _send_and_wait(tmux_session, "/models", timeout=20)
    _save_pane(report_dir, "11_models", pane)
    assert "model" in pane.lower(), (
        f"/models gave no listing:\n{pane[-1500:]}"
    )


def test_compact_command(tmux_session: str, report_dir: Path) -> None:
    _wait_chrome(tmux_session)
    _send_and_wait(tmux_session, "/new", timeout=10)
    _send_and_wait(tmux_session, "remember the number 42", timeout=120)
    pane = _send_and_wait(tmux_session, "/compact", timeout=180)
    _save_pane(report_dir, "11_compact", pane)
    # /compact either returns a summary line or a "nothing to remove"
    # ack — both are fine.
    p = pane.lower()
    assert (
        "compact" in p
        or "removed" in p
        or "no compaction" in p
        or "nothing" in p
    ), f"/compact gave no recognisable output:\n{pane[-1500:]}"


@pytest.mark.timeout(900)
def test_claude_codex_delegation_context(
    tmux_session: str, report_dir: Path,
) -> None:
    """Mirror of test_10's delegation test on the TUI.

    /new → /claude question → ask the upstream model what Claude said
    → /codex task → ask what Codex said → second round → final recall.
    Verifies the between-context is preserved across two rounds.
    """
    if shutil.which("claude") is None and shutil.which("codex") is None:
        pytest.skip("neither claude nor codex CLI on PATH")
    skip_claude = shutil.which("claude") is None
    skip_codex = shutil.which("codex") is None

    _wait_chrome(tmux_session)
    _send_and_wait(tmux_session, "/new", timeout=10)

    delegate_timeout = 240.0  # claude / codex subprocess can be slow

    # ---- Round 1 ------------------------------------------------
    if not skip_claude:
        pane = _send_and_wait(
            tmux_session,
            "/claude what is the capital of France? answer in one word.",
            timeout=delegate_timeout,
        )
        _save_pane(report_dir, "11_claude_round1", pane)
        assert "paris" in pane.lower(), (
            f"Claude delegation didn't return Paris:\n{pane[-2500:]}"
        )

        pane = _send_and_wait(
            tmux_session,
            "what did Claude just say about France?",
            timeout=120,
        )
        _save_pane(report_dir, "11_claude_recall1", pane)
        assert "paris" in pane.lower(), (
            f"upstream model lost Claude's reply:\n{pane[-2500:]}"
        )

    if not skip_codex:
        pane = _send_and_wait(
            tmux_session,
            "/codex print 'hello world' in python",
            timeout=delegate_timeout,
        )
        _save_pane(report_dir, "11_codex_round1", pane)
        assert any(t in pane.lower() for t in ("print", "hello", "python")), (
            f"Codex delegation didn't return code:\n{pane[-2500:]}"
        )

        pane = _send_and_wait(
            tmux_session,
            "what did Codex just write?",
            timeout=120,
        )
        _save_pane(report_dir, "11_codex_recall1", pane)
        assert any(
            t in pane.lower() for t in ("print", "hello", "python")
        ), f"upstream lost Codex's reply:\n{pane[-2500:]}"

    # ---- Round 2 ------------------------------------------------
    if not skip_claude:
        pane = _send_and_wait(
            tmux_session,
            "/claude what is 2 plus 2? answer with the number only.",
            timeout=delegate_timeout,
        )
        _save_pane(report_dir, "11_claude_round2", pane)
        assert ("4" in pane or "four" in pane.lower()), (
            f"Claude #2 didn't return 4:\n{pane[-2500:]}"
        )

        pane = _send_and_wait(
            tmux_session,
            "summarise everything we asked Claude in this conversation in one sentence",
            timeout=180,
        )
        _save_pane(report_dir, "11_claude_recall2", pane)
        france_ok = "france" in pane.lower() or "paris" in pane.lower()
        math_ok = "2" in pane or "four" in pane.lower() or "math" in pane.lower()
        assert france_ok and math_ok, (
            f"upstream lost prior Claude context: france_ok={france_ok}, "
            f"math_ok={math_ok}\npane:\n{pane[-2500:]}"
        )


# ---- footer alias rendering / model_alias propagation -----------------


def test_metrics_row_carries_alias_prefix(
    tmux_session: str, report_dir: Path,
) -> None:
    """Per-call stats row must render ``<alias>/<model>`` not just
    the bare model id.

    The bridge stamps ``model_alias`` onto the metrics dict by
    resolving the serving endpoint against ``cfg.models[]``;
    ``AssistantMessage.set_metrics`` then prints
    ``<alias>/<model>`` so the operator sees BOTH the bucket they
    picked AND the wire-level model id. Without alias resolution
    the row reads as just ``qwen3.6-27b-fp8``, which is misleading
    once the operator has /model'd to a non-default alias.
    """
    _wait_chrome(tmux_session)
    _send_and_wait(tmux_session, "/new", timeout=10)
    pane = _send_and_wait(tmux_session, "hi", timeout=120)
    _save_pane(report_dir, "11_alias_metrics", pane)

    # Expect a stats row that has the ``<alias>/<id>`` shape on the
    # leading bullet point. Default alias on this fixture is the
    # configured upstream alias (``gpu-a``, ``server1``, etc.) — accept
    # any non-empty alias token followed by ``/``. The id should
    # contain a model-ish substring (e.g. ``qwen``).
    import re
    # Looser regex to tolerate the ANSI / box-drawing line prefix.
    matches = re.findall(
        r"─\s+([a-z0-9_-]+)\s*/\s*([a-z0-9._/-]+)\s*·\s+(?:prefill|ttft|gen|wt)",
        pane,
        re.IGNORECASE,
    )
    assert matches, (
        "no alias/model prefix on the metrics row — "
        "bridge.model_alias resolution or set_metrics regressed.\n"
        f"Pane tail:\n{pane[-2000:]}"
    )
    alias, model = matches[-1]
    assert alias and model, (
        f"empty alias or model: alias={alias!r}, model={model!r}\n"
        f"Pane tail:\n{pane[-1500:]}"
    )


# ---- /agents + /agent <name> + /restart -----------------------------


def test_agents_listing(tmux_session: str, report_dir: Path) -> None:
    """``/agents`` lists every directory under
    ``~/.rtxclaw/agents/<name>`` that carries a ``config.json``.

    The fixture scaffolds a ``main`` agent at minimum, so the listing
    must contain ``main`` with a current-selection marker.
    """
    _wait_chrome(tmux_session)
    pane = _send_and_wait(tmux_session, "/agents", timeout=20)
    _save_pane(report_dir, "11_agents", pane)
    p = pane.lower()
    # ``/agents`` is a Telegram-only command in current bot.py — TUI
    # may not implement it. Two acceptable outcomes:
    #   (a) the TUI lists agents (Phase B done on TUI too)
    #   (b) the TUI prints "(no output)" / unknown-command ack
    # Either way it must NOT crash the chrome.
    assert "mode:" in p, (
        f"/agents broke the chrome:\n{pane[-1500:]}"
    )


def test_restart_command_does_not_crash(
    tmux_session: str, report_dir: Path,
) -> None:
    """``/restart`` schedules a detached gateway respawn via
    :func:`rtxclaw_core.restart.restart_agent_detached`.

    For the TUI test we cannot reliably wait for the actual
    respawn (the daemon fixture would race with the bounce), so we
    just assert the command is accepted and prints either the
    transcript notice (``♻ restart scheduled``) or routes through
    the events row without breaking the footer. The unit-test
    layer covers the helper itself.
    """
    _wait_chrome(tmux_session)
    _send_text(tmux_session, "/restart")
    # Don't `_send_and_wait` — the daemon may bounce mid-poll.
    # Just settle for a couple of seconds and confirm the chrome
    # didn't disintegrate.
    time.sleep(3)
    pane = _capture(tmux_session)
    _save_pane(report_dir, "11_restart", pane)
    p = pane.lower()
    # Footer must still be coherent (mode line present). The actual
    # respawn is exercised in the integration suite by the bot
    # tests + the systemd test on the host.
    assert "mode:" in p, (
        "/restart broke the TUI chrome instead of detaching cleanly.\n"
        f"Pane tail:\n{pane[-2000:]}"
    )


# ---- /models picker → kimi (skipped without OpenRouter creds) -------


def test_models_picker_kimi(
    tmux_session: str, report_dir: Path, sandbox_env,
) -> None:
    """End-to-end: ``/models`` → arrow-down to a configured row →
    Enter → next prompt is served by the picked model.

    Requires an OpenRouter-capable row in ``~/.rtxclaw/config.json``
    (alias ``kimi`` by convention) AND ``OPENROUTER_API_KEY`` in the
    sandbox env. Skipped otherwise so the suite stays useful on
    boxes without OpenRouter credentials.

    Catches the cluster of bugs PR #126 / #127 / #128 / #129 fixed:
    bridge ships the upstream Bearer header, agent_client passes
    ``alias=`` so the bridge resolves the row, ``_switch_to_model_row``
    surfaces ``ok=False`` on wire failures, and the stdio child
    loads ``<home>/.env`` so OPENROUTER_API_KEY actually reaches the
    worker.
    """
    if not sandbox_env.get("OPENROUTER_API_KEY"):
        pytest.skip("OPENROUTER_API_KEY not in sandbox env")

    # Skip if no ``kimi``-shaped row is configured. We don't require
    # the literal alias ``kimi`` — any row pointed at openrouter.ai
    # is fair game.
    import json as _json
    sandbox_home = Path(sandbox_env.get("RTXCLAW_HOME", ""))
    glob_cfg_p = sandbox_home / "config.json"
    if not glob_cfg_p.is_file():
        pytest.skip("no global config in sandbox")
    glob = _json.loads(glob_cfg_p.read_text())
    rows = glob.get("models") or []
    or_rows = [
        r for r in rows
        if "openrouter.ai" in str(r.get("baseUrl") or "")
    ]
    if not or_rows:
        pytest.skip("no OpenRouter row configured in sandbox")

    target_alias = or_rows[0]["alias"]

    _wait_chrome(tmux_session)
    # /model <alias> path (more deterministic than the modal picker
    # — keystroke counts there change with row order).
    _send_and_wait(tmux_session, f"/model {target_alias}", timeout=20)
    pane = _send_and_wait(
        tmux_session,
        "say hi in exactly 4 words",
        timeout=120,
    )
    _save_pane(report_dir, "11_kimi_e2e", pane)

    p = pane.lower()
    assert "401" not in p and "no cookie auth" not in p, (
        "OpenRouter HTTP 401 surfaced — Bearer header / .env loader "
        "regressed.\n"
        f"Pane tail:\n{pane[-2500:]}"
    )
    # Alias-prefix in the metrics row proves the bridge resolved
    # the upstream and the worker actually answered.
    assert f"{target_alias}/" in pane, (
        f"metrics row missing {target_alias}/<id> prefix — switch "
        "didn't take effect on the wire.\n"
        f"Pane tail:\n{pane[-2500:]}"
    )


# ---- /<agent_name> delegate sugar (TUI side) -------------------------


def test_agent_delegate_sugar(tmux_session: str, report_dir: Path) -> None:
    """``/<agent_name> <task>`` should either:

    (a) trigger ``delegate_agent`` (Phase B feature shipped in the
        Telegram bot; TUI parity may follow); OR
    (b) emit an unknown-command ack without crashing.

    Test asserts the chrome stays usable either way — this is the
    forward-compat check for when TUI grows the same sugar.
    """
    _wait_chrome(tmux_session)
    pane = _send_and_wait(
        tmux_session, "/scraper say hi", timeout=20,
        allow_agent_error=True,
    )
    _save_pane(report_dir, "11_scraper_delegate", pane)
    assert "mode:" in pane.lower(), (
        f"/<agent> sugar broke the chrome:\n{pane[-1500:]}"
    )
