from __future__ import annotations

from rtxclaw_agent.acp_bridge import CoreBackend, _build_worker_request
from rtxclaw_core.agent import AgentConfig
from rtxclaw_core.session import Session


def _bridge() -> CoreBackend:
    cfg = AgentConfig(name="t", system="sys")
    cfg.temperature = 0.23
    return CoreBackend(cfg)


def test_worker_request_applies_qwen_sampling_profile() -> None:
    sess = Session.new(
        system_prompt="sys",
        model="qwen3.6-27b-fp8",
        endpoint="http://127.0.0.1:8000/v1",
        system_mode="auto",
    )
    req = _build_worker_request(
        _bridge(), sess, [{"role": "user", "content": "hi"}], include_tools=False,
    )

    assert req["temperature"] == 0.23
    assert req["top_p"] == 0.95
    assert req["top_k"] == 20
    assert req["presence_penalty"] == 1.5
    assert req["max_tokens"] == 16384
    assert req["extra"]["chat_template_kwargs"]["enable_thinking"] is True


def test_worker_request_applies_gemma_extra_sampling() -> None:
    """Gemma profile sets the NVFP4-aware sampling. ``max_tokens`` was
    deliberately tightened from 4096 → 2048 (models.py L283) because
    NVFP4 quantization makes 4k-token planning rounds prone to
    token-collapse loops; the smaller ceiling caps the per-round blast
    radius while the streaming loop detector catches them. Test pins
    the deliberate value so a future tweak isn't silent."""
    sess = Session.new(
        system_prompt="sys",
        model="google/gemma-4-31b-it",
        endpoint="http://127.0.0.1:8000/v1",
        system_mode="auto",
    )
    req = _build_worker_request(
        _bridge(), sess, [{"role": "user", "content": "hi"}], include_tools=False,
    )

    assert req["frequency_penalty"] == 0.4
    assert req["presence_penalty"] == 0.3
    assert req["repetition_penalty"] == 1.05
    assert req["max_tokens"] == 2048
    assert req["extra"]["dry_multiplier"] == 0.8
    # Gemma profile has ``enable_thinking=True`` so the chat-template
    # kwargs ARE shipped — vLLM's gemma4 chat template gates the
    # ``<|channel>thought\n…<channel|>`` ASYMMETRIC wrap on this flag,
    # so the model can't reason at all without it.
    assert req["extra"]["chat_template_kwargs"]["enable_thinking"] is True


def test_worker_request_sampling_kill_switch(monkeypatch) -> None:
    """``RTXCLAW_DISABLE_MODEL_SAMPLING=1`` strips the OpenAI-level
    sampling fields (top_p, top_k, frequency_penalty, …) so an operator
    can A/B against the upstream's defaults. ``extra`` is INTENTIONALLY
    kept — it carries server-side decoder backstops (``repetition_detection``,
    dry-multiplier) that prevent the gemma-4 NVFP4 token-collapse loops
    described in models.py L260-295. Killing those would re-enable a
    failure mode the kill switch isn't supposed to touch."""
    monkeypatch.setenv("RTXCLAW_DISABLE_MODEL_SAMPLING", "1")
    sess = Session.new(
        system_prompt="sys",
        model="qwen3.6-27b-fp8",
        endpoint="http://127.0.0.1:8000/v1",
        system_mode="auto",
    )
    req = _build_worker_request(
        _bridge(), sess, [{"role": "user", "content": "hi"}], include_tools=False,
    )

    assert req["temperature"] == 0.23
    # OpenAI-level sampling fields are stripped.
    assert "top_p" not in req
    assert "top_k" not in req
    assert "frequency_penalty" not in req
    assert "presence_penalty" not in req
    assert "max_tokens" not in req
    # ``extra`` carrying decoder-side backstops stays — and
    # ``chat_template_kwargs`` (sourced from the sampling profile)
    # IS stripped because the profile itself is bypassed.
    if "extra" in req:
        assert "chat_template_kwargs" not in req["extra"]

