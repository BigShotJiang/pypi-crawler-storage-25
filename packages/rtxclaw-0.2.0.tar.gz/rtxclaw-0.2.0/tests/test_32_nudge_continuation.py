"""Step 32 — Continuation-nudge policy.

Background: small models (qwen3.6-class) sometimes drop EOS after a
tool chain without writing any user-visible summary. Operators see a
silent end and have to type ``status`` to discover what happened. The
bridge re-prompts the model up to ``MAX_NUDGES_PER_TURN`` times asking
it to either finish the task or summarize, with hard caps so a
non-compliant model can't loop the agent.

These tests pin the pure decision function so a future refactor can't
silently flip the policy. Integration coverage (the actual injection
into the message list + persistence onto the session record) lives
under the live-LLM smoke tests; this file is the policy contract.
"""
from __future__ import annotations

import pytest

from rtxclaw_core.agents.local_llm import (
    MAX_NUDGES_PER_TURN,
    NUDGE_MIN_TEXT_CHARS,
    NUDGE_PROMPT_BODY,
    _should_nudge,
)


# ---- baseline -----------------------------------------------------


def _base_kwargs(**overrides):
    """Return a kwargs dict that fires the nudge by default. Tests
    override one knob at a time so the failure surface is one bit."""
    out = dict(
        final_text_chars=0,
        tool_rounds_so_far=3,
        nudge_count=0,
        cancelled=False,
        terminate_reason="end_turn",
        silent_chain=False,
    )
    out.update(overrides)
    return out


def test_baseline_fires() -> None:
    assert _should_nudge(**_base_kwargs()) is True


# ---- positive cases -----------------------------------------------


def test_fires_with_terminate_reason_none() -> None:
    """Worker died without explicit terminate event — still treat as
    a natural stop and nudge."""
    assert _should_nudge(**_base_kwargs(terminate_reason=None)) is True


def test_fires_under_text_threshold() -> None:
    """Single-period summary is just whitespace dressing; nudge."""
    assert _should_nudge(**_base_kwargs(final_text_chars=NUDGE_MIN_TEXT_CHARS - 1)) is True


def test_fires_at_first_attempt() -> None:
    assert _should_nudge(**_base_kwargs(nudge_count=0)) is True


def test_fires_at_attempt_below_cap() -> None:
    """First retry already burned, one more allowed."""
    assert _should_nudge(**_base_kwargs(nudge_count=MAX_NUDGES_PER_TURN - 1)) is True


# ---- negative cases -----------------------------------------------


def test_blocks_when_no_tool_rounds() -> None:
    """First-round empty stop is a different bug — no tools fired,
    so this isn't the 'silent after tool chain' shape."""
    assert _should_nudge(**_base_kwargs(tool_rounds_so_far=0)) is False


def test_blocks_when_text_at_threshold() -> None:
    """``NUDGE_MIN_TEXT_CHARS`` is inclusive on the upper side — the
    value itself is enough text to count as a summary."""
    assert _should_nudge(**_base_kwargs(final_text_chars=NUDGE_MIN_TEXT_CHARS)) is False


def test_blocks_when_text_well_above_threshold() -> None:
    assert _should_nudge(**_base_kwargs(final_text_chars=500)) is False


def test_blocks_at_cap() -> None:
    assert _should_nudge(**_base_kwargs(nudge_count=MAX_NUDGES_PER_TURN)) is False


def test_blocks_above_cap() -> None:
    """Defensive: if state ever gets out of sync, never go past cap."""
    assert _should_nudge(**_base_kwargs(nudge_count=MAX_NUDGES_PER_TURN + 1)) is False


def test_blocks_when_cancelled() -> None:
    """User pressed ESC — never override their cancel with a nudge."""
    assert _should_nudge(**_base_kwargs(cancelled=True)) is False


def test_blocks_on_max_tokens_terminate() -> None:
    """Model hit the token budget; it didn't choose to stop. Nudging
    would just consume more tokens it doesn't have."""
    assert _should_nudge(**_base_kwargs(terminate_reason="max_tokens")) is False


def test_blocks_on_refusal_terminate() -> None:
    """Model declined for safety reasons — don't badger it."""
    assert _should_nudge(**_base_kwargs(terminate_reason="refusal")) is False


def test_blocks_on_cancelled_terminate() -> None:
    """Cancellation already terminated the worker — don't restart."""
    assert _should_nudge(**_base_kwargs(terminate_reason="cancelled")) is False


def test_blocks_after_silent_chain() -> None:
    """Two silent rounds in a row → abort. A model that won't talk
    after a nudge isn't going to start talking on the second nudge."""
    assert _should_nudge(**_base_kwargs(silent_chain=True)) is False


# ---- constants ----------------------------------------------------


def test_max_nudges_is_bounded_low() -> None:
    """Hard cap must stay tight — 5+ would be a runaway loop. 1-3 is
    the survivable range."""
    assert 1 <= MAX_NUDGES_PER_TURN <= 3


def test_min_text_chars_is_reasonable() -> None:
    """Threshold must allow a one-word answer like 'done.' through
    but reject pure whitespace. 5-25 chars is the sane range."""
    assert 5 <= NUDGE_MIN_TEXT_CHARS <= 25


def test_prompt_body_is_self_describing() -> None:
    """The injected message should be greppable in transcripts AND
    legible to the model — start with the rtxclaw tag."""
    assert NUDGE_PROMPT_BODY.startswith("[rtxclaw")
    assert "summari" in NUDGE_PROMPT_BODY.lower() or "finish" in NUDGE_PROMPT_BODY.lower()


def test_prompt_body_addresses_reasoning_only_stop() -> None:
    """qwen3-class models (live: 489 reasoning_tokens / 0 content
    tokens on a tool-using turn) dump the whole answer into the
    reasoning channel. The nudge has to explicitly tell the model
    (a) content vs reasoning is distinct and (b) not to start a new
    chain of thought — otherwise the model just emits MORE reasoning
    in response to the nudge and silently exits again."""
    body = NUDGE_PROMPT_BODY.lower()
    assert "content" in body, (
        "nudge must mention 'content' so the model knows reasoning "
        "tokens aren't user-visible"
    )
    assert "chain of thought" in body or "reasoning" in body, (
        "nudge must explicitly redirect away from another reasoning "
        "loop, otherwise qwen3 just dumps another <think> block"
    )
