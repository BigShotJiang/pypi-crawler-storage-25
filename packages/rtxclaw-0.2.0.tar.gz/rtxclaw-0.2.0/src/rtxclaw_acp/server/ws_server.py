"""aiohttp WebSocket adapter for :class:`AcpServer`.

Exposes :func:`serve_ws`, an aiohttp request handler that performs the
WS upgrade, wires the WS into a :class:`AcpServer` over a
:class:`WebSocketTransport`, and tears down all sessions opened on the
connection when the WS closes.

Conformance bullets:

* The HTTP response sent on upgrade carries a fresh ``Acp-Connection-Id``
  (UUID4 hex) so reconnection / future-friendly demultiplexing has a
  stable identifier. The dispatcher itself is connection-id-agnostic;
  the id lives ENTIRELY in this layer (and on the response headers).
* Multiple sessions can be opened on a single WS connection. The
  adapter tracks every ``sessionId`` returned by ``session/new`` /
  ``session/load`` and removes ones explicitly closed via
  ``session/close``. On WS disconnect, every still-open session has
  ``backend.close_session(sid)`` invoked in reverse-creation order so
  subordinate resources tear down before parents.
* WS-level keepalive (ping/pong) is handled by aiohttp's WebSocket
  autopings — there is no vendor heartbeat at the JSON-RPC layer.
* Binary frames trigger an immediate close with status 1003
  (unsupported data) per RFC 6455 §7.4.1.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Mapping

from aiohttp import WSCloseCode, web

from ..protocol.ws import WebSocketBinaryFrameError, WebSocketTransport
from .backend import AgentBackend
from .server import AcpServer


logger = logging.getLogger(__name__)


ACP_CONNECTION_ID_HEADER = "Acp-Connection-Id"


@dataclass
class WsConnectionState:
    """Per-WS-connection state tracked by :func:`serve_ws`.

    Lives only inside the WS adapter; the dispatcher / backend never
    see this object. The connection-id flows out via the upgrade
    response header so clients can echo it on future reconnects.
    """

    connection_id: str
    session_ids: list[str] = field(default_factory=list)
    opened_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class _SessionTrackingBackend:
    """Wraps an :class:`AgentBackend` to record every session opened on
    this connection.

    The dispatcher only ever calls the backend; we intercept the four
    methods that own session-id lifecycle:

    * ``new_session`` — extract the ``sessionId`` from the response and
      append it to the connection's tracked list.
    * ``load_session`` — likewise, plus uses the input ``sessionId``
      argument as a fallback if the response doesn't carry one.
    * ``close_session`` — drop the id from the tracked list (the
      caller did the work explicitly, no double teardown needed).
    * everything else — straight passthrough.
    """

    def __init__(
        self,
        wrapped: AgentBackend,
        state: WsConnectionState,
    ) -> None:
        self._wrapped = wrapped
        self._state = state

    def __getattr__(self, name: str) -> Any:
        # Forward anything not explicitly wrapped (e.g.
        # ``bind_session_server`` / ``unbind_session_server``, which
        # the AcpServer calls to register its outbound channel) straight
        # to the inner backend. Parity with the HTTP transport's
        # ``_BackendSessionTracker``; only the four session-lifecycle
        # methods need interception, everything else is passthrough.
        return getattr(self._wrapped, name)

    async def initialize(
        self,
        protocol_version: int,
        client_capabilities: Mapping[str, Any] | None,
        client_info: Mapping[str, Any] | None,
    ) -> Mapping[str, Any] | None:
        return await self._wrapped.initialize(
            protocol_version, client_capabilities, client_info
        )

    async def authenticate(self, method_id: str) -> None:
        await self._wrapped.authenticate(method_id)

    async def new_session(
        self, cwd: str, mcp_servers: list[Mapping[str, Any]]
    ) -> Mapping[str, Any]:
        result = await self._wrapped.new_session(cwd, mcp_servers)
        sid = (
            result.get("sessionId")
            if isinstance(result, Mapping)
            else None
        )
        if isinstance(sid, str):
            self._state.session_ids.append(sid)
        return result

    async def load_session(
        self,
        session_id: str,
        cwd: str,
        mcp_servers: list[Mapping[str, Any]],
    ) -> Mapping[str, Any]:
        result = await self._wrapped.load_session(session_id, cwd, mcp_servers)
        # Track by the request's sessionId (load_session doesn't return
        # one in the spec — the sessionId is the input).
        if isinstance(session_id, str):
            self._state.session_ids.append(session_id)
        return result

    async def list_sessions(
        self, cursor: str | None, cwd: str | None
    ) -> Mapping[str, Any]:
        return await self._wrapped.list_sessions(cursor, cwd)

    async def close_session(self, session_id: str) -> None:
        await self._wrapped.close_session(session_id)
        # Drop the most recent occurrence; if a buggy backend lets the
        # same id appear twice, subsequent close drops the next one.
        try:
            # remove last occurrence so reverse-order cleanup stays
            # well-defined.
            for idx in range(len(self._state.session_ids) - 1, -1, -1):
                if self._state.session_ids[idx] == session_id:
                    del self._state.session_ids[idx]
                    break
        except ValueError:
            pass

    async def set_mode(self, session_id: str, mode_id: str) -> None:
        await self._wrapped.set_mode(session_id, mode_id)

    async def set_config_option(
        self, session_id: str, config_id: str, value: Any
    ) -> None:
        await self._wrapped.set_config_option(session_id, config_id, value)

    async def inject_user_message(
        self, session_id: str, text: str,
    ) -> Mapping[str, Any]:
        inner = getattr(self._wrapped, "inject_user_message", None)
        if inner is None:
            raise NotImplementedError(
                "wrapped backend does not implement inject_user_message"
            )
        return await inner(session_id, text)

    def prompt(
        self,
        session_id: str,
        message_id: str | None,
        prompt: list[Mapping[str, Any]],
    ) -> AsyncIterator[Mapping[str, Any]]:
        return self._wrapped.prompt(session_id, message_id, prompt)

    async def cancel(self, session_id: str) -> None:
        await self._wrapped.cancel(session_id)


async def serve_ws(
    request: web.Request,
    *,
    backend: AgentBackend,
    agent_capabilities: Any,
    agent_info: Any,
    auth_methods: list[Any] | None = None,
) -> web.WebSocketResponse:
    """aiohttp request handler that runs an :class:`AcpServer` over WS.

    Wire it into a :class:`web.Application` like::

        async def handler(req):
            return await serve_ws(
                req,
                backend=my_backend,
                agent_capabilities=caps,
                agent_info=info,
            )

        app = web.Application()
        app.router.add_get("/acp", handler)

    On upgrade we attach a fresh ``Acp-Connection-Id`` response
    header. The id is also stashed on the returned
    :class:`web.WebSocketResponse` (``ws["acp_connection_id"]`` and
    ``ws["acp_connection_state"]``) for tests / observability.

    On normal close OR exception, every session_id tracked for this
    connection has ``backend.close_session`` invoked in reverse
    creation order. Errors during teardown are logged and swallowed —
    the connection is going away regardless.
    """
    connection_id = uuid.uuid4().hex
    state = WsConnectionState(connection_id=connection_id)

    ws = web.WebSocketResponse()
    # Attach the connection-id as a header on the upgrade response
    # before completing the handshake. aiohttp finalizes headers in
    # ``prepare()``, so we need to set this before that point.
    ws.headers[ACP_CONNECTION_ID_HEADER] = connection_id
    await ws.prepare(request)

    ws["acp_connection_id"] = connection_id
    ws["acp_connection_state"] = state

    transport = WebSocketTransport(ws)
    tracking_backend = _SessionTrackingBackend(backend, state)
    server = AcpServer(
        transport,
        tracking_backend,
        agent_capabilities=agent_capabilities,
        agent_info=agent_info,
        auth_methods=auth_methods,
    )

    try:
        await server.serve_until_close()
    except WebSocketBinaryFrameError as exc:
        logger.warning(
            "acp-ws: closing %s after binary frame: %s", connection_id, exc
        )
        try:
            await ws.close(
                code=WSCloseCode.UNSUPPORTED_DATA,
                message=b"binary frames not supported",
            )
        except Exception:
            logger.debug("acp-ws: error closing on binary-frame", exc_info=True)
    except Exception:
        logger.exception("acp-ws: unhandled error on connection %s", connection_id)
    finally:
        # Tear down sessions in reverse creation order so cleanup runs
        # children-before-parents. Backend errors during teardown are
        # logged and swallowed; the WS is going away regardless.
        for sid in reversed(list(state.session_ids)):
            try:
                await backend.close_session(sid)
            except Exception:
                logger.exception(
                    "acp-ws: backend.close_session(%s) raised during "
                    "connection teardown",
                    sid,
                )
        state.session_ids.clear()
        try:
            await transport.close()
        except Exception:
            logger.debug("acp-ws: transport close raised", exc_info=True)

    return ws


__all__ = [
    "ACP_CONNECTION_ID_HEADER",
    "WsConnectionState",
    "serve_ws",
]
