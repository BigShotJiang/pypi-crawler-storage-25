"""JSON-RPC 2.0 types + Content-Length framing for ACP stdio.

This module is byte-fidelity-conscious. From ``CLAUDE.md``:

    Tool schemas must be deterministic. Prior turns' tool calls and
    tool results stay byte-identical when replayed — store the raw
    arguments JSON the model originally emitted (raw_arguments field)
    and replay it verbatim, don't re-serialize via json.dumps which
    can reorder keys.

The same rule applies to JSON-RPC framing on the wire: when prefix
caching is in play upstream (vLLM APC, SGLang RadixAttention), every
re-serialization can shift bytes and force a cache miss. Our
``JsonRpcRequest`` / ``JsonRpcResponse`` / ``JsonRpcNotification``
preserve the **raw** ``params`` / ``result`` JSON bytes alongside the
parsed Python view. ``parse_message`` populates both; callers that
care about byte-fidelity replay use ``raw_params`` /  ``raw_result``,
not ``json.dumps(params)``.

Framing is the LSP-style stdio format used across ACP / MCP /
Language-Server-Protocol stacks::

    Content-Length: <N>\\r\\n
    \\r\\n
    <N bytes of JSON body>

Both header and body are read by ``read_message`` as raw bytes — no
parse happens at the framing layer. Callers parse the body via
``parse_message`` (which does reject batch arrays at the framing
boundary because the RFD forbids them and we apply the rule
across transports for consistency).
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Mapping, Union


# ---------------------------------------------------------------------------
# Error codes
# ---------------------------------------------------------------------------


class JsonRpcErrorCode(IntEnum):
    """JSON-RPC 2.0 standard error codes plus the RFD-specific 501.

    Standard codes are those defined in the JSON-RPC 2.0 spec. The RFD
    Streamable HTTP transport adds a server-error-range value (501)
    used to reject batch requests over HTTP — we surface that here so
    the same code can be reused by the framing layer to flag batch
    rejection consistently across stdio / WS / HTTP.
    """

    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603
    # ACP-defined: returned from session/new (and friends) when the
    # client must call ``authenticate`` before opening a session.
    # Spec ref: ``error.rs:AUTH_REQUIRED`` / schema $defs ErrorCode.
    AUTH_REQUIRED = -32000
    # Server-error-range values (-32000..-32099 reserved per JSON-RPC).
    BATCH_NOT_SUPPORTED = -32001
    # RFD-defined HTTP-status mapping for batch rejection.
    HTTP_BATCH_REJECTED = 501


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class JsonRpcParseError(Exception):
    """Raised when bytes cannot be parsed into a valid JSON-RPC message."""

    def __init__(self, message: str, *, code: int = JsonRpcErrorCode.PARSE_ERROR) -> None:
        super().__init__(message)
        self.code = code


class JsonRpcFramingError(Exception):
    """Raised when the Content-Length frame on the wire is malformed."""


# ---------------------------------------------------------------------------
# Message dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class JsonRpcError:
    """JSON-RPC error object, transport-independent."""

    code: int
    message: str
    data: Any = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"code": int(self.code), "message": self.message}
        if self.data is not None:
            out["data"] = self.data
        return out


@dataclass(frozen=True)
class JsonRpcRequest:
    """A JSON-RPC 2.0 request (has ``id``, expects a response).

    ``params`` is the parsed Python view; ``raw_params`` is the original
    body of the request as bytes, suitable for byte-identical replay.
    Storing both lets handlers that care about prefix-cache stability
    pass through the on-wire bytes without re-serializing. Both fields
    refer to the same underlying value when the wire bytes are the
    canonical form.
    """

    id: Union[str, int]
    method: str
    params: Any = None
    raw_params: bytes | None = None
    raw_message: bytes | None = field(default=None, repr=False, compare=False)

    @property
    def is_request(self) -> bool:
        return True


@dataclass(frozen=True)
class JsonRpcNotification:
    """A JSON-RPC 2.0 notification (no ``id``, no response expected)."""

    method: str
    params: Any = None
    raw_params: bytes | None = None
    raw_message: bytes | None = field(default=None, repr=False, compare=False)

    @property
    def is_notification(self) -> bool:
        return True


@dataclass(frozen=True)
class JsonRpcResponse:
    """A JSON-RPC 2.0 response.

    Either ``result`` or ``error`` is set, not both. ``raw_result``
    preserves the original bytes for the result branch (mirror of
    ``raw_params`` on requests).
    """

    id: Union[str, int, None]
    result: Any = None
    error: JsonRpcError | None = None
    raw_result: bytes | None = None
    raw_message: bytes | None = field(default=None, repr=False, compare=False)

    @property
    def is_response(self) -> bool:
        return True


JsonRpcMessage = Union[JsonRpcRequest, JsonRpcResponse, JsonRpcNotification]


# ---------------------------------------------------------------------------
# Framing
# ---------------------------------------------------------------------------


_HEADER_TERMINATOR = b"\r\n\r\n"
_LF_TERMINATOR = b"\n\n"
_CONTENT_LENGTH_LOWER = b"content-length"


async def read_message(reader: asyncio.StreamReader) -> bytes:
    """Read one Content-Length-framed message from ``reader``.

    Returns the **raw bytes** of the message body (no parsing). The
    caller decides how to interpret them. This stays at the framing
    layer so callers with byte-fidelity needs can hand the bytes
    straight to ``parse_message`` (which keeps a reference for replay).

    Raises:
        JsonRpcFramingError: on malformed framing — missing terminator,
            missing/duplicate Content-Length, non-numeric length, or
            premature EOF.
        asyncio.IncompleteReadError: passed through if the underlying
            stream closes before the body is fully consumed.

    Notes:
        Tolerant of bare ``\\n\\n`` terminators (some implementations
        emit LF-only). Rejects non-ASCII header bytes outright.
    """

    header_buf = bytearray()
    while True:
        chunk = await reader.read(1)
        if not chunk:
            if not header_buf:
                raise JsonRpcFramingError("EOF before any header bytes")
            raise JsonRpcFramingError("EOF mid-header before terminator")
        header_buf.extend(chunk)
        # Honour CRLF first; fall back to LF-only.
        if header_buf.endswith(_HEADER_TERMINATOR):
            header_bytes = bytes(header_buf[: -len(_HEADER_TERMINATOR)])
            break
        if header_buf.endswith(_LF_TERMINATOR) and not header_buf.endswith(b"\r\n\n"):
            header_bytes = bytes(header_buf[: -len(_LF_TERMINATOR)])
            break

    content_length: int | None = None
    # Parse headers strictly. ASCII only.
    try:
        header_text = header_bytes.decode("ascii")
    except UnicodeDecodeError as exc:
        raise JsonRpcFramingError("non-ASCII bytes in header section") from exc

    for line in header_text.split("\r\n") if "\r\n" in header_text else header_text.split("\n"):
        if not line:
            continue
        if ":" not in line:
            raise JsonRpcFramingError(f"malformed header line: {line!r}")
        name, _, value = line.partition(":")
        if name.strip().lower() == "content-length":
            if content_length is not None:
                raise JsonRpcFramingError("duplicate Content-Length header")
            try:
                content_length = int(value.strip())
            except ValueError as exc:
                raise JsonRpcFramingError(
                    f"non-numeric Content-Length: {value!r}"
                ) from exc
            if content_length < 0:
                raise JsonRpcFramingError("negative Content-Length")

    if content_length is None:
        raise JsonRpcFramingError("missing Content-Length header")

    body = await reader.readexactly(content_length)
    return body


async def write_message(
    writer: asyncio.StreamWriter,
    payload: bytes | Mapping[str, Any] | JsonRpcRequest | JsonRpcResponse | JsonRpcNotification,
) -> None:
    """Write one Content-Length-framed message to ``writer``.

    Accepts either pre-serialized bytes (preferred — preserves byte
    fidelity) or a dict / dataclass that we serialize via the standard
    JSON encoder. For byte-identical replay always pass bytes.
    """

    if isinstance(payload, (bytes, bytearray)):
        body = bytes(payload)
    elif isinstance(payload, (JsonRpcRequest, JsonRpcResponse, JsonRpcNotification)):
        # Prefer the original wire bytes if we have them.
        if payload.raw_message is not None:
            body = payload.raw_message
        else:
            body = json.dumps(_dataclass_to_dict(payload), separators=(",", ":")).encode("utf-8")
    elif isinstance(payload, Mapping):
        body = json.dumps(dict(payload), separators=(",", ":")).encode("utf-8")
    else:
        raise TypeError(f"unsupported payload type: {type(payload).__name__}")

    header = f"Content-Length: {len(body)}\r\n\r\n".encode("ascii")
    writer.write(header + body)
    await writer.drain()


def _dataclass_to_dict(
    msg: JsonRpcRequest | JsonRpcResponse | JsonRpcNotification,
) -> dict[str, Any]:
    """Best-effort serialization fallback for messages built in-memory."""

    if isinstance(msg, JsonRpcRequest):
        out: dict[str, Any] = {"jsonrpc": "2.0", "id": msg.id, "method": msg.method}
        if msg.params is not None:
            out["params"] = msg.params
        return out
    if isinstance(msg, JsonRpcNotification):
        out = {"jsonrpc": "2.0", "method": msg.method}
        if msg.params is not None:
            out["params"] = msg.params
        return out
    # Response.
    out = {"jsonrpc": "2.0", "id": msg.id}
    if msg.error is not None:
        out["error"] = msg.error.to_dict()
    else:
        out["result"] = msg.result
    return out


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


def parse_message(buf: bytes) -> JsonRpcMessage:
    """Parse raw JSON-RPC bytes into a typed dataclass.

    Returns one of ``JsonRpcRequest`` / ``JsonRpcResponse`` /
    ``JsonRpcNotification``. The original ``buf`` is preserved as
    ``raw_message`` on the result, and the original ``params`` / ``result``
    sub-bytes (when present) are preserved as ``raw_params`` /
    ``raw_result``. Callers that care about byte-fidelity (prefix-cache
    stability) replay the raw fields verbatim instead of re-serializing.

    Rejects JSON-RPC 2.0 batch arrays at the framing boundary with
    ``JsonRpcParseError`` whose ``.code`` is ``INVALID_REQUEST``
    (-32600). Per the Streamable HTTP RFD batches are explicitly
    forbidden over HTTP, and we apply the rule consistently across all
    transports so callers don't have to special-case the wire.
    """

    try:
        # Decode strictly as UTF-8.
        text = buf.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise JsonRpcParseError(f"non-UTF-8 message body: {exc}") from exc

    try:
        obj = json.loads(text)
    except json.JSONDecodeError as exc:
        raise JsonRpcParseError(f"malformed JSON: {exc.msg}") from exc

    if isinstance(obj, list):
        raise JsonRpcParseError(
            "JSON-RPC batch arrays are not supported",
            code=JsonRpcErrorCode.INVALID_REQUEST,
        )

    if not isinstance(obj, dict):
        raise JsonRpcParseError(
            f"top-level JSON-RPC message must be an object, got {type(obj).__name__}",
            code=JsonRpcErrorCode.INVALID_REQUEST,
        )

    jsonrpc = obj.get("jsonrpc")
    if jsonrpc != "2.0":
        raise JsonRpcParseError(
            f"unsupported jsonrpc version: {jsonrpc!r} (must be '2.0')",
            code=JsonRpcErrorCode.INVALID_REQUEST,
        )

    has_id = "id" in obj
    has_method = "method" in obj
    has_result = "result" in obj
    has_error = "error" in obj

    # Preserve raw sub-bytes for params / result.
    raw_params = _extract_raw_field(buf, "params") if "params" in obj else None
    raw_result = _extract_raw_field(buf, "result") if has_result else None

    if has_method:
        method = obj["method"]
        if not isinstance(method, str):
            raise JsonRpcParseError(
                f"method must be a string, got {type(method).__name__}",
                code=JsonRpcErrorCode.INVALID_REQUEST,
            )
        params = obj.get("params")
        if has_id:
            req_id = obj["id"]
            if not isinstance(req_id, (str, int)) or isinstance(req_id, bool):
                raise JsonRpcParseError(
                    "id must be a string or integer (or null on response)",
                    code=JsonRpcErrorCode.INVALID_REQUEST,
                )
            return JsonRpcRequest(
                id=req_id,
                method=method,
                params=params,
                raw_params=raw_params,
                raw_message=buf,
            )
        return JsonRpcNotification(
            method=method,
            params=params,
            raw_params=raw_params,
            raw_message=buf,
        )

    if has_result or has_error:
        # Responses must have an `id` field (may be null per spec for
        # parse-error responses).
        if not has_id:
            raise JsonRpcParseError(
                "response missing 'id' field",
                code=JsonRpcErrorCode.INVALID_REQUEST,
            )
        if has_result and has_error:
            raise JsonRpcParseError(
                "response must not have both 'result' and 'error'",
                code=JsonRpcErrorCode.INVALID_REQUEST,
            )
        resp_id = obj["id"]
        if resp_id is not None and (
            not isinstance(resp_id, (str, int)) or isinstance(resp_id, bool)
        ):
            raise JsonRpcParseError(
                "id must be a string, integer, or null",
                code=JsonRpcErrorCode.INVALID_REQUEST,
            )
        if has_error:
            err = obj["error"]
            if not isinstance(err, dict) or "code" not in err or "message" not in err:
                raise JsonRpcParseError(
                    "error must be an object with code and message",
                    code=JsonRpcErrorCode.INVALID_REQUEST,
                )
            return JsonRpcResponse(
                id=resp_id,
                error=JsonRpcError(
                    code=int(err["code"]),
                    message=str(err["message"]),
                    data=err.get("data"),
                ),
                raw_message=buf,
            )
        return JsonRpcResponse(
            id=resp_id,
            result=obj.get("result"),
            raw_result=raw_result,
            raw_message=buf,
        )

    raise JsonRpcParseError(
        "JSON-RPC message must have either 'method' or 'result'/'error'",
        code=JsonRpcErrorCode.INVALID_REQUEST,
    )


def _extract_raw_field(buf: bytes, field_name: str) -> bytes | None:
    """Return the byte slice of ``buf`` corresponding to the JSON value
    of ``field_name`` at the top level, or ``None`` if the field is
    absent or extraction fails.

    This is a best-effort byte-fidelity helper — it scans the bytes for
    the field key and uses the standard library ``json.JSONDecoder.raw_decode``
    to find the end of the value. Falls back to ``None`` (and callers
    must accept that re-serialization may be required) on any parse
    snag, never raises.
    """

    needle = f'"{field_name}"'.encode("utf-8")
    idx = buf.find(needle)
    if idx < 0:
        return None
    # Skip past the key, the colon, and any whitespace.
    pos = idx + len(needle)
    n = len(buf)
    while pos < n and buf[pos:pos + 1] in (b" ", b"\t", b"\n", b"\r"):
        pos += 1
    if pos >= n or buf[pos:pos + 1] != b":":
        return None
    pos += 1
    while pos < n and buf[pos:pos + 1] in (b" ", b"\t", b"\n", b"\r"):
        pos += 1
    if pos >= n:
        return None
    try:
        decoder = json.JSONDecoder()
        # raw_decode wants str.
        text = buf[pos:].decode("utf-8")
        _, end = decoder.raw_decode(text)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    # Map ``end`` (string offset) back to a byte offset. UTF-8 decoding
    # already normalized the bytes; re-encode the slice to preserve
    # exact byte content for the value.
    return text[:end].encode("utf-8")


__all__ = [
    "JsonRpcError",
    "JsonRpcErrorCode",
    "JsonRpcFramingError",
    "JsonRpcMessage",
    "JsonRpcNotification",
    "JsonRpcParseError",
    "JsonRpcRequest",
    "JsonRpcResponse",
    "parse_message",
    "read_message",
    "write_message",
]
