"""Spawn a stdio ACP agent subprocess and wrap it in an ``AcpClient``.

The lifecycle contract here is intentionally minimal:

- ``spawn_stdio_agent(cmd, ...)`` launches ``cmd`` as a child process
  with piped stdin/stdout/stderr, wraps its stdio in
  ``StdioTransport``, builds an ``AcpClient`` over that transport, and
  returns ``(client, process)``.
- The caller owns the returned ``process``. Closing the client (via
  ``client.close()``) closes the transport, which closes the child's
  stdin — agents are expected to exit cleanly on stdin EOF. For a hard
  kill (the rtxclaw ``TurnState.stop`` SIGTERM path), the caller does
  ``process.terminate()`` (or ``process.kill()``) directly on the
  ``Process`` handle.
- Stderr is left open and piped; the caller can drain it for
  diagnostics. We don't pump it ourselves to avoid taking ownership of
  yet another background task.

This honors the ``CLAUDE.md`` killability rule: every long-running
operation runs in its own OS process, and the PID is exposed to the
caller for direct signal control. ``AcpClient.close`` is the orderly
shutdown path; ``process.terminate`` is the hard kill path. Neither
goes through threads or in-loop coroutines.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Optional, Union

from ..protocol.transport import StdioTransport
from .client import AcpClient


async def spawn_stdio_agent(
    cmd: list[str],
    *,
    cwd: Optional[Union[str, Path]] = None,
    env: Optional[dict[str, str]] = None,
    client_capabilities=None,
    client_info=None,
    return_process: bool = True,
):
    """Launch ``cmd`` and wrap its stdio in an ``AcpClient``.

    Args:
        cmd: argv list, e.g. ``["claude", "--acp"]``.
        cwd: working directory for the child; defaults to the parent's
            cwd if ``None``.
        env: extra environment variables to merge into ``os.environ``
            for the child process. ``None`` inherits the parent's env
            unchanged.
        client_capabilities: passed through to ``AcpClient``.
        client_info: passed through to ``AcpClient``.
        return_process: if True (default) return ``(client, process)``;
            if False return only ``client``. The process handle is the
            killability anchor — most callers want it.

    Returns:
        ``(AcpClient, asyncio.subprocess.Process)`` or just
        ``AcpClient`` depending on ``return_process``. The client's
        read loop has been started; ``await client.initialize()`` is
        the next step.
    """

    full_env = None
    if env is not None:
        full_env = {**os.environ, **env}

    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=str(cwd) if cwd is not None else None,
        env=full_env,
    )
    if process.stdin is None or process.stdout is None:
        # Should not happen with PIPE on both sides, but the type is
        # ``Optional`` so we narrow it explicitly.
        raise RuntimeError("subprocess stdio not available after spawn")

    transport = StdioTransport(process.stdout, process.stdin)
    client = AcpClient(
        transport,
        client_capabilities=client_capabilities,
        client_info=client_info,
    )
    await client.start()

    if return_process:
        return client, process
    return client


__all__ = ["spawn_stdio_agent"]
