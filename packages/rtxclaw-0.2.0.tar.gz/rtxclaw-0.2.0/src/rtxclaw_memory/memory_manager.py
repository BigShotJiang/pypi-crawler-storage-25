"""Active memory provider lifecycle + bus wiring.

A thin orchestrator: pick the provider named in `cfg.memory_provider`,
initialize it, route bus events to it, enforce the privacy gate. It
doesn't replace the built-in memory path — `remember()`, MEMORY.md,
and `memory_search` keep working unchanged. The provider runs
alongside.

Single-select by design. Two concurrent providers fight over the
recall budget and produce muddy auto-injection; if you want to
compose providers, write one provider that internally fans out.

Provider registry is a plain dict — no plugin discovery, no YAML.
Three-line additions for the second provider; if/when there are
six, we'll revisit.

Class-based interface (`MemoryManager`) plus thin module-level
functions (`subscribe_for_agent`, `prefetch_for_query`,
`shutdown_all`) for callers that just want the default per-home
behaviour.
"""
from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from rtxclaw_memory.memory_provider import MemoryProvider


_log = logging.getLogger(__name__)


# ---- privacy gate (mirrors memory_tools.py) -------------------------

_PRIVATE_ORIGINS: frozenset[str] = frozenset({
    "", "tui", "oneshot", "heartbeat", "telegram",
})


def _is_private_origin(workspace_origin: str) -> bool:
    return (workspace_origin or "").strip().lower() in _PRIVATE_ORIGINS


# ---- recall mode + context fencing ---------------------------------

# Recall modes that callers may request via cfg.memory_recall_mode.
# - "context": auto-inject only (no provider tools surfaced).
# - "tools":   provider tools surfaced; no auto-inject.
# - "hybrid":  both. Default.
VALID_RECALL_MODES: frozenset[str] = frozenset({"context", "tools", "hybrid"})

# Cap on the auto-injected context block so a chatty provider can't
# eat the entire turn budget. Aligns with the spec's ~2000-char cap.
DEFAULT_CONTEXT_CHAR_BUDGET: int = 2000

# Context fencing: when we capture a completed turn for persistence,
# strip any `[RECALLED CONTEXT ...]` block we previously injected.
# Otherwise re-saving the assistant text re-feeds the model its own
# recalled context, which compounds across turns and pollutes
# downstream search.
_RECALLED_BLOCK_RE = re.compile(
    r"\[RECALLED\s+CONTEXT[^\]]*\][^\n]*(?:\n(?!\n).*)*",
    re.MULTILINE,
)


def strip_recalled_blocks(text: str) -> str:
    """Remove `[RECALLED CONTEXT ...]` segments from a turn capture.

    Pure function — easy to unit-test. Idempotent: running it on
    text without recalled blocks returns the input unchanged.
    """
    if not isinstance(text, str) or "[RECALLED CONTEXT" not in text:
        return text or ""
    cleaned = _RECALLED_BLOCK_RE.sub("", text)
    # Collapse the empty lines the regex leaves behind.
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    return cleaned.strip()


def truncate_for_budget(text: str, *, budget_chars: int) -> str:
    """Trim a recalled block to the configured char budget.

    Truncation is char-based, not token-based — a tokenizer-aware
    trim would tighten the bound but adds a dependency we don't
    want on the recall hot path.
    """
    if not text:
        return ""
    if len(text) <= budget_chars:
        return text
    head = text[:budget_chars].rstrip()
    return f"{head}\n[…recall truncated to {budget_chars} chars…]"


# ---- built-in providers --------------------------------------------

def _sqlite_facts_provider_factory() -> MemoryProvider:
    """Late import so a missing optional dep on one provider can't
    break manager initialization for another."""
    from rtxclaw_core.sqlite_facts import SqliteFactsProvider
    return SqliteFactsProvider()


# Built-in registry. Plain dict — the second provider is two lines.
PROVIDER_REGISTRY: dict[str, Any] = {
    "sqlite_facts": _sqlite_facts_provider_factory,
}

# Back-compat alias under the old name.
PROVIDER_FACTORIES = PROVIDER_REGISTRY


# ---- main class ----------------------------------------------------

@dataclass
class _ManagerState:
    """Container the manager carries between activate / wire / dispatch.

    Held outside `MemoryManager` itself so the public class stays
    focused on the lifecycle methods; this state is internal
    bookkeeping the bus subscriptions need to close over.
    """
    home: Path
    cfg: Any
    provider: MemoryProvider
    recall_mode: str
    context_budget: int
    bus_subs_wired: bool = False


class MemoryManager:
    """Lifecycle for a single active memory provider.

    Used two ways:
      - Direct: `mm = MemoryManager(); mm.activate(...); mm.wire_events()`
        — what the spec describes for the heartbeat bootstrap.
      - Per-home registry: `subscribe_for_agent(home, cfg)` resolves
        an existing manager (or creates one) so two callers in the
        same process don't double-wire the bus.

    Single-select: `activate` refuses when a provider is already
    bound on this instance. `deactivate()` clears it before re-
    activating with a different name.
    """

    def __init__(self) -> None:
        self._state: Optional[_ManagerState] = None

    # -- public API --------------------------------------------------

    @property
    def provider(self) -> Optional[MemoryProvider]:
        return None if self._state is None else self._state.provider

    def is_active(self) -> bool:
        return self._state is not None

    async def activate(
        self,
        provider_name: str,
        agent_home: Path,
        cfg: Any,
        workspace_origin: str = "",
    ) -> bool:
        """Bind a provider to this manager. Returns True on success.

        - `provider_name=""` resolves to the local-first default
          (`sqlite_facts`).
        - `provider_name="none"` deliberately skips activation —
          the operator opts out and the manager stays inert.
        - `workspace_origin` is checked against the privacy set;
          calls from shared frontends never activate.
        """
        if self._state is not None:
            _log.warning(
                "memory_manager: refusing reactivation; current=%s",
                self._state.provider.name,
            )
            return False

        if not _is_private_origin(workspace_origin):
            _log.info(
                "memory_manager: privacy gate refused activation "
                "(workspace_origin=%r)", workspace_origin,
            )
            return False

        name = (provider_name or "").strip().lower()
        if name == "none":
            _log.info("memory_manager: provider explicitly disabled")
            return False
        if not name:
            name = "sqlite_facts"
        factory = PROVIDER_REGISTRY.get(name)
        if factory is None:
            _log.warning(
                "memory_manager: unknown provider %r; falling back to "
                "sqlite_facts", name,
            )
            factory = PROVIDER_REGISTRY["sqlite_facts"]

        provider = factory()
        if not provider.is_available():
            _log.warning(
                "memory_manager: provider %r reports unavailable",
                provider.name,
            )
            return False

        try:
            await provider.initialize(Path(agent_home), cfg)
        except Exception:  # noqa: BLE001
            _log.exception(
                "memory_manager: provider %r initialize failed",
                provider.name,
            )
            return False

        recall_mode = (
            getattr(cfg, "memory_recall_mode", "")
            or (cfg.get("memory_recall_mode") if isinstance(cfg, dict) else "")
            or "hybrid"
        ).strip().lower()
        if recall_mode not in VALID_RECALL_MODES:
            _log.warning(
                "memory_manager: invalid recall_mode %r; defaulting to hybrid",
                recall_mode,
            )
            recall_mode = "hybrid"
        budget = int(
            getattr(cfg, "memory_context_char_budget", 0)
            or (cfg.get("memory_context_char_budget") if isinstance(cfg, dict) else 0)
            or DEFAULT_CONTEXT_CHAR_BUDGET
        )

        self._state = _ManagerState(
            home=Path(agent_home),
            cfg=cfg,
            provider=provider,
            recall_mode=recall_mode,
            context_budget=budget,
        )
        _log.info(
            "memory_manager: active provider=%s home=%s mode=%s",
            provider.name, agent_home, recall_mode,
        )
        return True

    def deactivate(self) -> None:
        """Best-effort shutdown. Idempotent."""
        if self._state is None:
            return
        try:
            self._state.provider.shutdown()
        except Exception:  # noqa: BLE001
            _log.exception(
                "memory_manager: provider %r shutdown raised",
                self._state.provider.name,
            )
        self._state = None

    def wire_events(self) -> None:
        """Subscribe the active provider to the process-wide bus.

        Safe to call multiple times — repeat calls are no-ops.
        """
        if self._state is None or self._state.bus_subs_wired:
            return
        self._wire_bus(self._state)
        self._state.bus_subs_wired = True

    def get_extra_tools(self) -> list[dict]:
        """Tool schemas the provider wants surfaced.

        Empty list when no provider is active. The bundled
        ``sqlite_facts`` provider returns ``[]`` — its tools are
        registered globally via ``tools/registry.py``. External
        providers (Honcho, Mem0, …) would return their schemas
        here.
        """
        if self._state is None:
            return []
        if self._state.recall_mode == "context":
            # Auto-inject only — don't surface explicit tools to the
            # model, the recall already happens out-of-band.
            return []
        return list(self._state.provider.get_tool_schemas() or [])

    async def dispatch_tool(self, name: str, args: dict) -> Any:
        """Route a tool call to the active provider.

        Privacy gate enforced here — providers can't forget it.
        Returns the provider's tool-result body; raises if no
        provider is active.
        """
        if self._state is None:
            raise RuntimeError(
                f"memory_manager: cannot dispatch {name!r}; no active provider"
            )
        origin = str((args or {}).get("workspace_origin") or "")
        if not _is_private_origin(origin):
            return f"{name} refused: workspace_origin is not private."
        return await self._state.provider.handle_tool_call(name, args or {})

    # -- recall composition -----------------------------------------

    async def prefetch_and_format(self, query: str) -> str:
        """Run `provider.prefetch(query)` and format for injection.

        Honors `recall_mode`:
          - "context" / "hybrid": call prefetch, format inside a
            `[RECALLED CONTEXT — <provider>]` envelope, truncate to
            the configured char budget.
          - "tools": return "" — recall happens via explicit tool
            calls, not auto-injection.

        The caller is responsible for the actual splice into the
        message list (today: `agent_runtime` would call this and
        place the block after the system prompt's cache boundary;
        the wiring is intentionally not done in this commit since
        the runtime hot path is fragile).
        """
        if self._state is None:
            return ""
        if self._state.recall_mode == "tools":
            return ""
        try:
            body = await self._state.provider.prefetch(query or "")
        except Exception:  # noqa: BLE001
            _log.exception(
                "memory_manager: prefetch raised for %s",
                self._state.provider.name,
            )
            return ""
        body = (body or "").strip()
        if not body:
            return ""
        envelope = (
            f"[RECALLED CONTEXT — from {self._state.provider.name}]\n"
            f"{body}"
        )
        return truncate_for_budget(envelope, budget_chars=self._state.context_budget)

    # -- bus wiring -------------------------------------------------

    def _wire_bus(self, state: _ManagerState) -> None:
        """Register the bus subscriptions a provider needs."""
        from rtxclaw_core.event_bus import get_bus
        bus = get_bus()
        provider = state.provider
        home_resolved = state.home.resolve()

        async def on_session_saved(payload: dict[str, Any]) -> None:
            ev_home = (payload or {}).get("agent_home", "")
            try:
                if ev_home and Path(ev_home).resolve() != home_resolved:
                    return
            except Exception:  # noqa: BLE001
                return
            origin = str(payload.get("workspace_origin") or "")
            if not _is_private_origin(origin):
                return
            path_str = payload.get("path") or ""
            session_hash = str(payload.get("session_hash") or "")
            if not path_str:
                return
            try:
                import json as _json
                data = _json.loads(Path(path_str).read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return
            turns = data.get("turns") or []
            try:
                await provider.on_session_end(turns, session_hash)
            except Exception:  # noqa: BLE001
                _log.exception(
                    "memory_manager: provider %r on_session_end raised",
                    provider.name,
                )

        async def on_turn_completed(payload: dict[str, Any]) -> None:
            user = str((payload or {}).get("user") or "")
            assistant = str((payload or {}).get("assistant") or "")
            # Context fencing: any [RECALLED CONTEXT] block that the
            # manager auto-injected before this turn must not be
            # captured back into long-term storage. Otherwise the
            # provider learns "facts" that are just its own previous
            # recall echoed back through the model.
            assistant_clean = strip_recalled_blocks(assistant)
            if not user.strip() and not assistant_clean.strip():
                return
            try:
                await provider.sync_turn(user, assistant_clean)
            except Exception:  # noqa: BLE001
                _log.exception(
                    "memory_manager: provider %r sync_turn raised",
                    provider.name,
                )

        async def on_daily_appended(payload: dict[str, Any]) -> None:
            # NOTE: `daily_appended` fires from the `remember()`
            # subprocess in the current rtxclaw build, so parent-
            # process subscribers don't see it (heartbeat.py:392-397
            # documents this for memory_synth). The subscription is
            # still wired here so the contract is in place — when
            # `remember()` runs in-process (or its events bridge into
            # the parent), providers pick up writes for free.
            ev_home = (payload or {}).get("home", "")
            try:
                if ev_home and Path(ev_home).resolve() != home_resolved:
                    return
            except Exception:  # noqa: BLE001
                return
            action = str(payload.get("action") or "add")
            content = str(payload.get("content") or "")
            category = str(payload.get("category") or "")
            try:
                await provider.on_memory_write(action, content, category)
            except Exception:  # noqa: BLE001
                _log.exception(
                    "memory_manager: provider %r on_memory_write raised",
                    provider.name,
                )

        bus.subscribe(
            "session_saved", on_session_saved,
            quiet_seconds=2.0,
            name=f"memory_manager[{provider.name}]/session_saved",
        )
        bus.subscribe(
            "turn_completed", on_turn_completed,
            quiet_seconds=0.5,
            name=f"memory_manager[{provider.name}]/turn_completed",
        )
        bus.subscribe(
            "daily_appended", on_daily_appended,
            quiet_seconds=2.0,
            name=f"memory_manager[{provider.name}]/daily_appended",
        )


# ---- per-home registry of managers --------------------------------

# Keyed by resolved home path. Each manager owns its provider +
# bus subscriptions; two callers in the same process get the same
# instance.
_MANAGERS: dict[str, MemoryManager] = {}


def get_active_manager(home: Path) -> Optional[MemoryManager]:
    return _MANAGERS.get(str(Path(home).resolve()))


def get_active_provider(home: Path) -> Optional[MemoryProvider]:
    """The provider initialized for `home`, or None if none."""
    mgr = _MANAGERS.get(str(Path(home).resolve()))
    return mgr.provider if mgr is not None else None


async def subscribe_for_agent(
    *, home: Path, cfg: Any, workspace_origin: str = "",
) -> Optional[MemoryProvider]:
    """Idempotent per-home: pick + initialize the active provider, then
    wire it to the bus.

    Reads `cfg.memory_provider` (string) and `cfg.memory_recall_mode`.
    Empty provider name falls back to `sqlite_facts`. `workspace_origin`
    is checked against the privacy set — non-private origins skip
    activation entirely (the heartbeat fires from origin="heartbeat"
    which is in the private set, so default boot works).

    Returns the active provider, or None when activation refused
    (operator-disabled, privacy gate, init failure).
    """
    key = str(Path(home).resolve())
    existing = _MANAGERS.get(key)
    if existing is not None and existing.is_active():
        return existing.provider

    mgr = existing or MemoryManager()
    name = (getattr(cfg, "memory_provider", "") or "").strip().lower()
    activated = await mgr.activate(
        provider_name=name,
        agent_home=Path(home),
        cfg=cfg,
        # Bootstrap path: the heartbeat fires from origin "heartbeat",
        # which is private. If the caller passes their own origin
        # (e.g. one-shot CLI under "tui"), we honor it.
        workspace_origin=workspace_origin or "heartbeat",
    )
    if activated:
        mgr.wire_events()
        _MANAGERS[key] = mgr
    return mgr.provider


async def prefetch_for_query(
    *, home: Path, query: str, workspace_origin: str = "",
) -> str:
    """Synchronous-from-caller's-POV recall hook.

    Returns the recalled-context block to splice after the cache
    boundary, or "" when:
    - the privacy gate refuses,
    - no provider is active for this home,
    - the recall mode is "tools",
    - the provider returns nothing.
    """
    if not _is_private_origin(workspace_origin):
        return ""
    mgr = _MANAGERS.get(str(Path(home).resolve()))
    if mgr is None or not mgr.is_active():
        return ""
    return await mgr.prefetch_and_format(query or "")


def shutdown_all() -> None:
    """Best-effort shutdown for tests + agent-restart paths."""
    for mgr in list(_MANAGERS.values()):
        try:
            mgr.deactivate()
        except Exception:  # noqa: BLE001
            _log.exception("memory_manager: deactivate raised")
    _MANAGERS.clear()


__all__ = [
    "DEFAULT_CONTEXT_CHAR_BUDGET",
    "MemoryManager",
    "PROVIDER_FACTORIES",
    "PROVIDER_REGISTRY",
    "VALID_RECALL_MODES",
    "get_active_manager",
    "get_active_provider",
    "prefetch_for_query",
    "shutdown_all",
    "strip_recalled_blocks",
    "subscribe_for_agent",
    "truncate_for_budget",
]
