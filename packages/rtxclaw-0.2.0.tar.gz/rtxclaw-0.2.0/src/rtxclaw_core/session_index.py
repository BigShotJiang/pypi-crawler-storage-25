"""SQLite-backed FTS5 search over saved session turns.

Sessions are JSON files at `<agent_home>/sessions/<hash>.json`; nothing
indexes their *contents* today, so "did we discuss X last week?" has no
fast answer. This module fixes that with a separate `sessions.db`
keyed by session hash + turn index, indexed via FTS5 on user/assistant
text combined per turn.

Two-table layout (sessions_meta + turns) instead of letting the FTS
table double as storage. Reasons:

- A future migration that wants role splitting / per-side scoring
  doesn't need a re-import — the `turns` table holds the durable
  rows; FTS is a derived index that can be rebuilt.
- `pin_fact` / future "summarize this session" tools can hit the
  `turns` table directly without going through MATCH.

Memory and session indexes are deliberately split into different
DBs so the memory index's chunking + embedding pipeline (see
`memory_index.py`) doesn't get polluted with conversational noise.

Lifecycle:

- `Session.save()` (in-process) publishes `session_saved` on the
  shared event bus.
- `subscribe_for_sessions(home)` wires that event to a non-blocking
  `index_session()` call and runs a one-shot `reindex_all()` to
  backfill any history on first wire.
- The `session_search` tool (subprocess-side) opens a fresh
  `SessionIndex` per call — same lazy pattern `memory_tools.py`
  uses for `MemoryIndex`. The tool runner subprocess inherits
  `RTXCLAW_AGENT_HOME` and `RTXCLAW_WORKSPACE_ORIGIN` so the privacy
  gate enforces the same trusted-origin set memory tools do.

FTS-only by design — vector search over conversational text added
little signal in early prototypes (turns are short, terms repeat,
BM25 + recency does the heavy lifting). Re-introduce it later by
mirroring the `chunks_vec` virtual table from `memory_index.py` if
the recall numbers ever justify it.
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
import time
from pathlib import Path
from typing import Any, Optional

from rtxclaw_memory.memory_primitives import (
    DEFAULT_SNIPPET_CHARS,
    RecallResult,
    bm25_rank_to_score,
    build_fts_query,
    format_recall_hits,
)


_log = logging.getLogger(__name__)


DEFAULT_MAX_RESULTS: int = 6
DEFAULT_MIN_SCORE: float = 0.35


# ---- privacy gate (mirrors memory_tools.py / memory_write.py) -------

_PRIVATE_ORIGINS: frozenset[str] = frozenset({
    "", "tui", "oneshot", "heartbeat", "telegram",
})


def _is_private_origin(workspace_origin: str) -> bool:
    """True iff the calling session is a private (trusted) frontend."""
    return (workspace_origin or "").strip().lower() in _PRIVATE_ORIGINS


# ---- text extraction ------------------------------------------------

def _extract_user_text(user: Any) -> str:
    """Pull plain text out of a turn's `user` field.

    Vision-capable models accept multi-part `user` content (a list of
    `{type: image_url|text, ...}` dicts). For search purposes we only
    care about the text parts; image URLs are skipped.
    """
    if isinstance(user, str):
        return user
    if isinstance(user, list):
        parts: list[str] = []
        for part in user:
            if isinstance(part, dict):
                kind = str(part.get("type") or "").lower()
                if kind == "text":
                    txt = part.get("text") or ""
                    if txt:
                        parts.append(str(txt))
            elif isinstance(part, str):
                parts.append(part)
        return "\n".join(parts)
    if user is None:
        return ""
    return str(user)


def _combine_turn(user: Any, assistant: str) -> str:
    """Combine user + assistant text into a single FTS document.

    A leading separator + role tag would help downstream consumers
    that want to slice the snippet, but FTS5's `snippet()` works
    over the raw string — keep the markup minimal.
    """
    user_text = _extract_user_text(user).strip()
    assistant_text = (assistant or "").strip()
    if user_text and assistant_text:
        return f"{user_text}\n---\n{assistant_text}"
    return user_text or assistant_text


# ---- main class -----------------------------------------------------

class SessionIndex:
    """One `sessions.db` per agent home.

    Three-table layout:
      - `sessions_meta` — one row per session (title, created_at,
        frontend, updated_at).
      - `turns` — one row per non-empty turn (combined_text, ts).
        rowid is autoincrement; FK references `sessions_meta`.
      - `turns_fts` — FTS5 virtual table over `combined_text`. Kept
        in sync manually (FTS5 triggers are fragile across
        INSERT-OR-REPLACE rowid churn — same reason `MemoryIndex`
        avoids them).

    Thread safety: NOT shared across threads. Open a fresh instance
    per call.
    """

    def __init__(self, agent_home: Path) -> None:
        self.agent_home = Path(agent_home)
        self.sessions_dir = self.agent_home / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.sessions_dir / "sessions.db"
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(str(self.db_path))
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("PRAGMA synchronous=NORMAL")
            con.execute("PRAGMA temp_store=MEMORY")
            con.execute("PRAGMA foreign_keys=ON")
        except sqlite3.DatabaseError:
            pass
        return con

    def _init_db(self) -> None:
        con = self._connect()
        try:
            con.executescript(_SCHEMA)
            con.commit()
        finally:
            con.close()

    # -- write path ----------------------------------------------------

    def index_session(self, data: dict) -> int:
        """Upsert a session's metadata + every non-empty turn.

        Replaces all existing turn rows for `session_hash` before
        re-inserting (turn count can grow between saves; rowid
        churn is fine — only the FTS table needs to stay aligned).
        Returns the number of FTS rows written.
        """
        if not isinstance(data, dict):
            return 0
        h = str(data.get("hash") or "")
        if not h:
            return 0

        title = str(data.get("title") or f"untitled-{h[-8:]}")
        created_at = str(data.get("created_at") or "")
        # The Session schema names the field `workspace_origin`; the
        # column here is `frontend` (per the implementation spec). We
        # accept either key in the payload for forward compatibility.
        frontend = str(
            data.get("frontend")
            or data.get("workspace_origin")
            or ""
        )
        turns = data.get("turns") or []
        if not isinstance(turns, list):
            turns = []
        now_ms = int(time.time() * 1000)

        con = self._connect()
        try:
            con.execute(
                "INSERT INTO sessions_meta(session_hash, title, "
                "created_at, frontend, updated_at) VALUES (?, ?, ?, ?, ?) "
                "ON CONFLICT(session_hash) DO UPDATE SET "
                "title=excluded.title, created_at=excluded.created_at, "
                "frontend=excluded.frontend, updated_at=excluded.updated_at",
                (h, title, created_at, frontend, now_ms),
            )
            # Drop FTS rows first so we can DELETE turns by FK without
            # tripping integrity (the FTS table doesn't have a real FK
            # but staying explicit avoids surprises across future
            # SQLite versions).
            con.execute(
                "DELETE FROM turns_fts WHERE session_hash = ?",
                (h,),
            )
            con.execute(
                "DELETE FROM turns WHERE session_hash = ?",
                (h,),
            )
            indexed = 0
            for idx, turn in enumerate(turns):
                if not isinstance(turn, dict):
                    continue
                if turn.get("in_progress"):
                    continue
                combined = _combine_turn(
                    turn.get("user"), turn.get("content") or "",
                )
                if not combined.strip():
                    continue
                # `ts` is best-effort — Session.add_turn writes
                # `started_at` as ISO-8601, so parse what we can and
                # fall back to now_ms.
                ts = _iso_to_ms(turn.get("started_at")) or now_ms
                con.execute(
                    "INSERT INTO turns(session_hash, turn_idx, "
                    "combined_text, ts) VALUES (?, ?, ?, ?)",
                    (h, idx, combined, ts),
                )
                con.execute(
                    "INSERT INTO turns_fts(combined_text, "
                    "session_hash, turn_idx) VALUES (?, ?, ?)",
                    (combined, h, idx),
                )
                indexed += 1
            con.commit()
        finally:
            con.close()
        return indexed

    def index_session_file(self, path: Path) -> int:
        """Read a session JSON file off disk and index it.

        Tolerant of malformed files — returns 0 on read errors.
        """
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return 0
        return self.index_session(data)

    def reindex_all(self) -> dict:
        """Walk every `<sessions_dir>/<hash>.json` and re-index it.

        Used as a one-shot bootstrap after `subscribe_for_sessions`
        registers — the bus only delivers events fired AFTER
        subscription, so the existing JSON corpus would otherwise
        stay invisible to search until each session was re-saved.
        Idempotent.
        """
        stats = {"files": 0, "indexed_turns": 0, "errors": 0}
        if not self.sessions_dir.is_dir():
            return stats
        for entry in self.sessions_dir.iterdir():
            if not entry.is_file() or entry.suffix != ".json":
                continue
            # Skip delegate-state files — they store external CLI
            # session state, not rtxclaw turns.
            if ".delegate_" in entry.name:
                continue
            stats["files"] += 1
            try:
                n = self.index_session_file(entry)
                stats["indexed_turns"] += n
            except Exception:  # noqa: BLE001
                stats["errors"] += 1
        return stats

    def remove_session(self, session_hash: str) -> None:
        """Drop one session's rows. Used when a session is deleted."""
        if not session_hash:
            return
        con = self._connect()
        try:
            con.execute("DELETE FROM turns_fts WHERE session_hash = ?", (session_hash,))
            con.execute("DELETE FROM turns WHERE session_hash = ?", (session_hash,))
            con.execute("DELETE FROM sessions_meta WHERE session_hash = ?", (session_hash,))
            con.commit()
        finally:
            con.close()

    # -- read path -----------------------------------------------------

    def search(
        self,
        query: str,
        *,
        top_k: int = DEFAULT_MAX_RESULTS,
        min_score: float = DEFAULT_MIN_SCORE,
    ) -> list[RecallResult]:
        """FTS5 search across saved session turns.

        Returns `RecallResult`s with `source="session"` so callers
        can rank session hits alongside other recall sources.
        """
        query = (query or "").strip()
        if not query:
            return []
        match = build_fts_query(query)
        if match is None:
            return []
        con = self._connect()
        try:
            rows = con.execute(
                "SELECT f.session_hash AS session_hash, "
                "       f.turn_idx     AS turn_idx, "
                "       snippet(turns_fts, 0, '', '', '…', 64) AS snippet, "
                "       bm25(turns_fts) AS rank, "
                "       m.title        AS title, "
                "       m.created_at   AS created_at, "
                "       m.frontend     AS frontend "
                "FROM turns_fts AS f "
                "LEFT JOIN sessions_meta AS m "
                "  ON m.session_hash = f.session_hash "
                "WHERE turns_fts MATCH ? "
                "ORDER BY rank LIMIT ?",
                (match, max(1, int(top_k)) * 4),
            ).fetchall()
        finally:
            con.close()

        out: list[RecallResult] = []
        for r in rows:
            score = bm25_rank_to_score(float(r["rank"]))
            if score < min_score:
                continue
            session_hash = r["session_hash"]
            title = r["title"] or f"untitled-{(session_hash or '')[-8:]}"
            created_at = str(r["created_at"] or "")
            date_part = created_at.split("T", 1)[0] if created_at else ""
            out.append(RecallResult(
                source="session",
                path_or_id=session_hash,
                title=title,
                snippet=(r["snippet"] or "")[:DEFAULT_SNIPPET_CHARS],
                score=score,
                metadata={
                    "turn_idx": int(r["turn_idx"]),
                    "date": date_part,
                    "frontend": r["frontend"] or "",
                },
            ))
        # Dedup on (session_hash, turn_idx) — defensive; with the new
        # combined-text schema each turn is one row and won't appear
        # twice, but keep the guard for forward-compatibility with any
        # future role-split index.
        by_key: dict[tuple[str, int], RecallResult] = {}
        for h in out:
            key = (h.path_or_id, int(h.metadata.get("turn_idx", 0)))
            existing = by_key.get(key)
            if existing is None or h.score > existing.score:
                by_key[key] = h
        deduped = sorted(by_key.values(), key=lambda x: x.score, reverse=True)
        return deduped[: max(1, int(top_k))]

    def stats(self) -> dict:
        con = self._connect()
        try:
            sess_n = con.execute(
                "SELECT count(*) AS n FROM sessions_meta"
            ).fetchone()["n"]
            turn_n = con.execute(
                "SELECT count(*) AS n FROM turns"
            ).fetchone()["n"]
            fts_n = con.execute(
                "SELECT count(*) AS n FROM turns_fts"
            ).fetchone()["n"]
        finally:
            con.close()
        try:
            db_size = self.db_path.stat().st_size
        except OSError:
            db_size = 0
        return {
            "db_path": str(self.db_path),
            "db_size_bytes": db_size,
            "sessions": sess_n,
            "turns": turn_n,
            "turn_rows": fts_n,  # back-compat alias
        }

    def clear(self) -> None:
        """Drop all data — for `rtxclaw session index --force` (future)."""
        con = self._connect()
        try:
            con.executescript(
                "DELETE FROM turns_fts;\n"
                "DELETE FROM turns;\n"
                "DELETE FROM sessions_meta;"
            )
            con.commit()
        finally:
            con.close()


def _iso_to_ms(ts: Any) -> int:
    """Best-effort ISO-8601 → epoch milliseconds."""
    if not ts:
        return 0
    if isinstance(ts, (int, float)):
        return int(ts)
    if not isinstance(ts, str):
        return 0
    try:
        from datetime import datetime
        # Strip any trailing 'Z' for fromisoformat (3.10 doesn't
        # accept it); 3.11+ does.
        cleaned = ts.replace("Z", "+00:00")
        return int(datetime.fromisoformat(cleaned).timestamp() * 1000)
    except (ValueError, TypeError):
        return 0


# ---- public tool entry --------------------------------------------

def session_search(
    query: str,
    *,
    top_k: int = DEFAULT_MAX_RESULTS,
    min_score: float = DEFAULT_MIN_SCORE,
    workspace_origin: str = "",
    agent_home: Optional[Path] = None,
) -> str:
    """FTS-based search over saved sessions. Returns a markdown blob.

    Privacy gate: refused on shared / group frontends, same as
    `memory_search`.
    """
    if not _is_private_origin(workspace_origin):
        return (
            "session_search refused: this session's workspace_origin is not "
            "private (past conversations may contain operator notes — "
            "shared / group frontends can't read them)."
        )
    home = agent_home or _resolve_agent_home()
    if home is None:
        return "session_search failed: agent home not resolvable from env."
    if not isinstance(query, str) or not query.strip():
        return "session_search failed: query required."
    try:
        top_k = max(1, min(20, int(top_k)))
    except (TypeError, ValueError):
        top_k = DEFAULT_MAX_RESULTS
    try:
        min_score = max(0.0, min(1.0, float(min_score)))
    except (TypeError, ValueError):
        min_score = DEFAULT_MIN_SCORE
    idx = SessionIndex(home)
    hits = idx.search(query, top_k=top_k, min_score=min_score)
    if not hits:
        return f"session_search: no matches for {query!r} (min_score={min_score})."
    return format_recall_hits(
        hits,
        header=f"# session_search: {query!r}\n_{len(hits)} hit(s)_",
    )


def _resolve_agent_home() -> Optional[Path]:
    """Same resolution as `memory_tools._resolve_agent_home`."""
    explicit = os.environ.get("RTXCLAW_AGENT_HOME")
    if explicit:
        return Path(explicit).expanduser()
    sdir = os.environ.get("RTXCLAW_SESSIONS_DIR")
    if sdir:
        p = Path(sdir).expanduser()
        if p.name == "sessions":
            return p.parent
    return None


# ---- event-bus subscriber ------------------------------------------

# Per-agent registration state (keyed by agent home path) so
# `subscribe_for_sessions()` is idempotent across multiple calls.
_REGISTERED: set[str] = set()


def subscribe_for_sessions(home: Path, *, quiet_seconds: float = 0.5) -> bool:
    """Wire `session_saved` → `SessionIndex.index_session_file()` on
    the process-wide event bus.

    Debounce is short (0.5s default) — saves are cheap to index and
    we want recent turns searchable as quickly as possible. The bus's
    late-publish-merging serializes per-subscriber so two saves of
    the same session can't run the indexer concurrently.

    First-subscribe also runs `reindex_all()` once so an agent that
    has been running for months without an index gets backfilled
    on the next heartbeat tick.

    Returns True iff newly subscribed.
    """
    key = str(Path(home).resolve())
    if key in _REGISTERED:
        return False

    async def handler(payload: dict[str, Any]) -> None:
        ev_home = (payload or {}).get("agent_home", "")
        try:
            if ev_home and Path(ev_home).resolve() != Path(home).resolve():
                return
        except Exception:  # noqa: BLE001
            return
        path_str = (payload or {}).get("path", "")
        if not path_str:
            return
        try:
            idx = SessionIndex(Path(home))
            n = idx.index_session_file(Path(path_str))
            _log.debug("session_index: indexed %d row(s) for %s", n, path_str)
        except Exception:  # noqa: BLE001
            _log.exception("session_index handler crashed for %s", path_str)

    from rtxclaw_core.event_bus import get_bus
    bus = get_bus()
    bus.subscribe(
        "session_saved", handler,
        quiet_seconds=quiet_seconds,
        name=f"session_index[{Path(home).name}]",
    )
    _REGISTERED.add(key)
    # First-subscribe backfill.
    try:
        SessionIndex(Path(home)).reindex_all()
    except Exception:  # noqa: BLE001
        _log.exception("session_index: backfill error for %s", home)
    return True


# Back-compat alias — earlier code (heartbeat.py) imports the old
# name. Keeping both spellings avoids touching unrelated wiring.
subscribe_for_agent = subscribe_for_sessions


# ---- DDL ------------------------------------------------------------

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions_meta (
  session_hash TEXT PRIMARY KEY,
  title        TEXT NOT NULL DEFAULT '',
  created_at   TEXT NOT NULL DEFAULT '',
  frontend     TEXT NOT NULL DEFAULT '',
  updated_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_meta_frontend
  ON sessions_meta(frontend);

CREATE TABLE IF NOT EXISTS turns (
  rowid         INTEGER PRIMARY KEY AUTOINCREMENT,
  session_hash  TEXT NOT NULL,
  turn_idx      INTEGER NOT NULL,
  combined_text TEXT NOT NULL,
  ts            INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_hash);
CREATE INDEX IF NOT EXISTS idx_turns_ts      ON turns(ts);

CREATE VIRTUAL TABLE IF NOT EXISTS turns_fts USING fts5(
  combined_text,
  session_hash UNINDEXED,
  turn_idx     UNINDEXED,
  tokenize='unicode61'
);
"""


__all__ = [
    "DEFAULT_MAX_RESULTS",
    "DEFAULT_MIN_SCORE",
    "DEFAULT_SNIPPET_CHARS",
    "RecallResult",
    "SessionIndex",
    "session_search",
    "subscribe_for_agent",
    "subscribe_for_sessions",
]
