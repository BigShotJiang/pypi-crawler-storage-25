"""``GeminiCliEngine`` — wraps the ``gemini`` CLI.

Class-shape facade. :meth:`delegate_runner` returns
``runners.run_delegate_gemini_async``; the
:class:`ExternalCliEngine.run_turn` driver translates that runner's
``on_delta`` callbacks into :data:`AgentTurnEvent` instances. The
CLI subprocess pipeline (``gemini -p`` first turn / ``--resume``
follow-up, ``--model``, ``--approval-mode``, ``--skip-trust``,
``init`` / ``message`` / ``tool_use`` / ``tool_result`` event
parsing) lives in the legacy runner.
"""

from __future__ import annotations

from typing import Any

from .engine import EngineKind
from .external_cli import ExternalCliEngine


class GeminiCliEngine(ExternalCliEngine):
    """Run a turn through ``gemini -p --output-format stream-json``."""

    kind = EngineKind.GEMINI_CLI
    cli_command = "gemini"
    install_url = "https://github.com/google-gemini/gemini-cli"

    @property
    def name(self) -> str:
        return "gemini"

    def delegate_runner(self) -> Any:
        """Return ``runners.run_delegate_gemini_async``.

        :meth:`ExternalCliEngine.run_turn` awaits the returned helper
        with ``on_delta`` wired to the AgentTurnEvent translator.
        """
        from rtxclaw_core.tools.runners import run_delegate_gemini_async
        return run_delegate_gemini_async

    def resume_footer(self) -> str:
        """``[gemini --resume note: …]`` footer block."""
        return (
            "\n\n[gemini --resume note: Gemini now has this exchange. On your "
            "next delegate_gemini call in this rtxclaw session, only forward "
            "context that is NEW since this point — do not restate this "
            "reply or anything earlier.]"
        )
