"""Permission gating + ASK protocol integration.

The permission policy lives in two places:

* ``rtxclaw_core.tools.permissions.PermissionEvaluator`` — pure logic:
  given ``(tool_name, args, criticality, mode)``, returns
  ``"allow"`` / ``"ask"`` / ``"deny"``.
* ``permissions_integration.ask_user`` (this module) +
  ``rtxclaw_agent.acp_bridge._ask_user_outbound`` — the ACP wire
  protocol that surfaces an ``ask`` decision to the user and waits
  for an answer.

These are Agent-level (orthogonal to engine — apply whether the
engine is local-LLM or a CLI). The Agent class and the gateway
shim agree on this surface.

Per codex audit finding #6, the permission sentinel is NOT defined
here — it lives in :mod:`.engine` as the :class:`PermissionRequested`
event variant so it can flow through the standard
:data:`AgentTurnEvent` stream the engine already yields. This module
owns only the policy table + the ACP wire round-trip.

================================================================
Permission policy (unchanged from today)
================================================================

The matrix of (criticality × mode → decision) lives in
``permissions.py`` and DOES NOT change in the refactor:

============== =========== =========== ===========
criticality \\ mode   plan       ask         auto
============== =========== =========== ===========
read_only            allow      allow       allow
mutating             ask        ask         allow
destructive          deny       ask         ask
network              ask        ask         allow
============== =========== =========== ===========

(Today's table — verify against ``permissions.PermissionEvaluator`` at
implementation time. Same evaluator used for local-LLM tool calls
AND for CLI engines' OWN tool decisions — the CLI runs in its own
permission space (``--permission-mode <x>``) but the rtxclaw side
still gates which delegate kinds the model is allowed to invoke.)

================================================================
ASK protocol
================================================================

ACP defines ``request_permission`` (server → client) with the
client responding via ``permission_response``. :func:`ask_user`
below issues the ``request_outbound("session/request_permission",
…)`` call directly through the bound :class:`AcpServer`, with a
30-second timeout safety net and an auto-answer fast path
(``_ask_user_auto_answers``) for auto-mode runs where there's no
user to ask.

After refactor the Agent.run_turn flow is:

1. Engine encounters a tool call (or, for CLI engines, a delegate
   tool the model invoked through the CLI's own tools — rare, since
   CLI engines mostly run their own tools).
2. Engine yields :class:`PermissionRequested` (an
   :data:`AgentTurnEvent` variant) instead of dispatching directly.
   (Local LLM does this inside ``_dispatch_tool_calls``; CLI engines
   never do.)
3. :class:`Agent.run_turn` catches the sentinel, runs the evaluator,
   decides ``allow`` / ``deny`` immediately OR emits an ACP
   ``request_permission`` and awaits the response via a `Future`.
4. Engine resumes with the decision.

The new sentinel event:
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Optional


# =====================================================================
# Permission protocol — flow through the event stream.
# =====================================================================
#
# The engine yields a :class:`PermissionRequested` event (defined in
# :mod:`.engine`) carrying ``response: asyncio.Future[str]``. The
# Agent intercepts it BEFORE the gateway translator sees it (it never
# appears on the ACP wire), runs :meth:`PermissionPolicy.evaluate`,
# and for ``"ask"`` decisions runs :func:`ask_user` to get an operator
# answer. Then ``response.set_result("allow"|"deny")`` unblocks the
# engine.


# =====================================================================
# Evaluator façade
# =====================================================================


class PermissionPolicy:
    """Adapter over today's :class:`PermissionEvaluator`.

    Reference: ``rtxclaw_core.tools.permissions`` (module).

    The Agent holds one of these per session (mode may be per-session-
    overridden via ``/mode``). Engines call ``evaluate(...)`` to get an
    immediate decision; the Agent layer is what bridges ``"ask"`` to
    the user.
    """

    _VALID_MODES = ("plan", "ask", "auto")

    def __init__(self, *, mode: str) -> None:
        """``mode ∈ {plan, ask, auto}``."""
        if mode not in self._VALID_MODES:
            raise ValueError(
                f"unknown mode: {mode!r} — expected one of "
                f"{', '.join(self._VALID_MODES)}"
            )
        self._mode = mode
        # Session allowlist of ``"<tool>:<pattern>"`` strings — once
        # the user picks ``YES_DONT_ASK`` for a tool, later calls
        # with matching args auto-allow. Keyed by ``tool_name`` plus
        # a coarse argument hash so a one-off allow doesn't blanket
        # the whole tool.
        self._allowlist: set[str] = set()

    def set_mode(self, mode: str) -> None:
        """Per-session ``/mode`` override.

        Reference: ``CoreBackend.set_mode`` (acp_bridge.py L1654).
        Validates ``mode ∈ {plan, ask, auto}``.
        """
        if mode not in self._VALID_MODES:
            raise ValueError(
                f"unknown mode: {mode!r} — expected one of "
                f"{', '.join(self._VALID_MODES)}"
            )
        self._mode = mode

    def evaluate(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        criticality: str,
    ) -> tuple[str, str]:
        """Return ``(decision, reason)`` per the policy table.

        ``decision ∈ {"allow", "deny", "ask"}``. ``reason`` is a
        short user-facing string used when the decision is non-allow.
        """
        crit = (criticality or "mutating").lower()
        if crit not in {"read_only", "mutating", "destructive", "network"}:
            crit = "mutating"

        mode = self._mode

        # Decision matrix per the module docstring.
        if mode == "plan":
            if crit == "read_only":
                return "allow", ""
            if crit == "destructive":
                return "deny", "plan-mode: destructive blocked"
            return "ask", "plan-mode: needs confirmation"

        if mode == "auto":
            if crit in ("read_only", "mutating"):
                return "allow", ""
            if crit == "network":
                return "allow", ""
            # destructive
            if self._pattern_for(tool_name, arguments) in self._allowlist:
                return "allow", ""
            return "ask", "destructive op in auto mode"

        # ask mode
        if crit == "read_only":
            return "allow", ""
        if self._pattern_for(tool_name, arguments) in self._allowlist:
            return "allow", ""
        return "ask", "ask-mode: confirm"

    def remember(self, tool_name: str, arguments: dict[str, Any]) -> None:
        """Add this call pattern to the session allowlist.

        Called by the Agent layer when the user answers an ASK with
        a "Yes, don't ask again" option. Destructive ops are never
        remembered — defense-in-depth.
        """
        self._allowlist.add(self._pattern_for(tool_name, arguments))

    @staticmethod
    def _pattern_for(tool_name: str, arguments: dict[str, Any]) -> str:
        """Coarse fingerprint of a call for the session allowlist.

        Tool name + a sorted, truncated JSON of the args so trivial
        variations (whitespace, key order) all hit the same key. The
        cap keeps the allowlist memory-bounded.
        """
        import json
        try:
            sig = json.dumps(arguments or {}, sort_keys=True, ensure_ascii=False)
        except (TypeError, ValueError):
            sig = str(arguments)
        return f"{tool_name}:{sig[:240]}"


# =====================================================================
# ASK protocol — ACP wire path.
# =====================================================================


@dataclass(slots=True, frozen=True)
class AskQuestion:
    """One question to surface via ACP ``request_permission``.

    Reference: ``rtxclaw_acp/protocol/schema.py`` for the wire shape.
    Today's ``_ask_user_outbound`` constructs equivalent dicts.

    The ACP wire field names (``optionId``, ``label``, ``kind``) are
    preserved by the translation layer; this dataclass is the
    Python-friendly version.
    """

    id: str
    title: str
    detail: str
    # ``default_index`` is auto-selected in ``auto`` mode (skipping the
    # round-trip) when ``self.id`` matches a known "is this safe?"
    # question pattern. Today: ``_ask_user_auto_answers`` (acp_bridge.py
    # L581–610) handles this.
    default_index: int = 0
    options: tuple[str, ...] = ("Allow", "Deny")


async def ask_user(
    questions: list[AskQuestion],
    *,
    session_id: str,
    mode: str,
    note: str = "",
    outbound: Optional[Any] = None,    # an ACP outbound channel
) -> list[dict[str, Any]]:
    """Run the ASK round-trip and return the answers.

    Behavior:

    * If ``mode == "auto"``, short-circuit via
      :func:`auto_answer` for every question recognized by the
      auto-answer pattern matcher; surface only the unrecognized ones.
    * If ``mode == "plan"``, return an immediate ``Deny`` for any
      mutating/destructive question (plan mode is research-only).
    * Otherwise call ``outbound.request_permission(...)`` and
      ``await`` the user's response.
    """
    answers: list[dict[str, Any]] = []
    mode = (mode or "").lower()

    for q in questions:
        # Auto-mode auto-answer fast path.
        if mode == "auto":
            auto = auto_answer(q, note)
            if auto is not None:
                answers.append(auto)
                continue
        if mode == "plan":
            # Plan mode hard-denies mutating questions.
            answers.append({
                "questionId": q.id,
                "optionId": "deny",
                "decision": "deny",
                "reason": "plan-mode: denied without ask",
            })
            continue

        # ASK mode — go through the outbound channel if one exists.
        if outbound is None:
            answers.append({
                "questionId": q.id,
                "optionId": "deny",
                "decision": "deny",
                "reason": "no outbound channel attached",
            })
            continue
        try:
            payload = {
                "id": q.id,
                "title": q.title,
                "detail": q.detail,
                "options": [
                    {"optionId": opt, "label": opt}
                    for opt in q.options
                ],
                "defaultIndex": q.default_index,
            }
            # AcpServer exposes ``request_outbound(method, params)``
            # — the generic outbound-request entry point. We surface
            # permission prompts via the ACP ``session/request_permission``
            # method. Match the historical legacy-bridge
            # payload shape (sessionId / toolCall / options) so a
            # frontend built against the prior wire stays compatible.
            request_fn = getattr(outbound, "request_outbound", None)
            if request_fn is None:
                # Last-resort: some stub backends expose a direct
                # ``request_permission(session_id=, question=)``
                # helper. Honor it if present so test fakes that
                # pre-date the AcpServer rewrite keep working.
                legacy_fn = getattr(outbound, "request_permission", None)
                if legacy_fn is None:
                    answers.append({
                        "questionId": q.id,
                        "optionId": "deny",
                        "decision": "deny",
                        "reason": "outbound has no request_permission / request_outbound",
                    })
                    continue
                res = legacy_fn(session_id=session_id, question=payload)
            else:
                # ACP spec ``PermissionOption.kind`` must be one of
                # ``allow_once`` / ``allow_always`` / ``reject_once`` /
                # ``reject_always``. The dataclass ``options`` field
                # carries display labels (``"Allow"`` / ``"Deny"``);
                # map each label to a spec-conforming triple so a
                # strict ACP client doesn't reject the request.
                _OPT_KIND = {
                    "allow": "allow_once",
                    "yes": "allow_once",
                    "y": "allow_once",
                    "ok": "allow_once",
                    "allow_once": "allow_once",
                    "allow_always": "allow_always",
                    "deny": "reject_once",
                    "no": "reject_once",
                    "n": "reject_once",
                    "reject": "reject_once",
                    "reject_once": "reject_once",
                    "reject_always": "reject_always",
                }
                spec_options = []
                for opt in (q.options or ["Allow", "Deny"]):
                    kind = _OPT_KIND.get(str(opt).lower(), "reject_once")
                    spec_options.append({
                        "optionId": kind,
                        "name": str(opt),
                        "kind": kind,
                    })
                req_payload = {
                    "sessionId": session_id,
                    "toolCall": {
                        "toolCallId": q.id,
                        "title": q.title or "tool",
                        "kind": "other",
                        "status": "pending",
                        "rawInput": {"detail": q.detail or ""},
                    },
                    "options": spec_options,
                }
                res = request_fn(
                    "session/request_permission", req_payload,
                )
            # 30-second safety net for the interactive case where a
            # user IS connected but walked away. Mirrors the
            # ``_PERMISSION_PROMPT_TIMEOUT_S`` ceiling the legacy
            # the legacy bridge enforced — "no answer"
            # means "no" on a destructive op so the turn never hangs.
            if hasattr(res, "__await__"):
                try:
                    res = await asyncio.wait_for(res, timeout=30.0)
                except asyncio.TimeoutError:
                    answers.append({
                        "questionId": q.id,
                        "optionId": "deny",
                        "decision": "deny",
                        "reason": "permission prompt timed out (30s)",
                    })
                    continue
            # Unwrap the AcpServer-shape outcome:
            #   {"outcome": {"outcome": "selected"|"cancelled",
            #                "optionId": "allow_once"|...}}
            if isinstance(res, dict) and "outcome" in res:
                outcome = res.get("outcome") or {}
                if isinstance(outcome, dict):
                    kind = outcome.get("outcome")
                    if kind == "cancelled":
                        res = {"optionId": "deny",
                               "reason": "user cancelled"}
                    elif kind == "selected":
                        opt_id = str(outcome.get("optionId") or "")
                        res = {"optionId": opt_id}
                    else:
                        res = {"optionId": "deny",
                               "reason": f"unknown outcome: {kind!r}"}
            # Normalize: caller may return {"optionId": ...} or a string.
            # ``allow_once`` / ``allow_always`` are the ACP-spec
            # PermissionOption ids the legacy bridge
            # used; map them to ``"allow"`` so callers don't need to
            # care about which option-id naming the wire uses.
            if isinstance(res, dict):
                opt = res.get("optionId") or res.get("decision") or "deny"
                ans = dict(res)
                ans.setdefault("questionId", q.id)
                ans.setdefault("optionId", opt)
                ans["decision"] = "allow" if str(opt).lower() in (
                    "allow", "allow_once", "allow_always",
                    "yes", "y", "0",
                ) else "deny"
                answers.append(ans)
            else:
                opt = str(res or "deny")
                answers.append({
                    "questionId": q.id,
                    "optionId": opt,
                    "decision": "allow" if opt.lower() in (
                        "allow", "yes", "y"
                    ) else "deny",
                })
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            answers.append({
                "questionId": q.id,
                "optionId": "deny",
                "decision": "deny",
                "reason": f"ask_user error: {exc}",
            })
    return answers


def auto_answer(question: AskQuestion, note: str = "") -> Optional[dict[str, Any]]:
    """Auto-mode default for one question.

    Reference: ``_ask_user_auto_answers`` (acp_bridge.py L581–610).
    Returns the auto-selected answer dict, or ``None`` when the
    question doesn't match any auto-answer pattern.
    """
    title = (question.title or "").lower()
    detail = (question.detail or "").lower()

    # Tool-permission questions in auto mode: allow safe-looking ones,
    # defer destructive-looking ones to the operator.
    destructive_signals = (
        "rm -rf", "drop table", "force push", "force-push", "delete",
        "destroy", "wipe", "uninstall", "shutdown", "reboot",
    )
    text = f"{title} {detail}"
    if any(sig in text for sig in destructive_signals):
        return None

    # Tools that should always auto-approve in auto-mode.
    safe_prefixes = (
        "allow read", "allow grep", "allow glob", "allow webfetch",
        "allow websearch", "allow ls",
    )
    if any(title.startswith(p) for p in safe_prefixes):
        return {
            "questionId": question.id,
            "optionId": "allow",
            "decision": "allow",
            "auto": True,
            "note": note,
        }

    # ``request_permission`` style — answer with the default option.
    if question.options:
        default_label = question.options[
            max(0, min(question.default_index, len(question.options) - 1))
        ]
        return {
            "questionId": question.id,
            "optionId": default_label,
            "decision": "allow" if default_label.lower() in (
                "allow", "yes", "y"
            ) else "deny",
            "auto": True,
            "note": note,
        }

    return None


# =====================================================================
# UserQuestion tool — frontend-driven ASK
# =====================================================================
#
# The ``UserQuestion`` tool (registry.py — searchable) is the model-
# facing version of this: the LOCAL LLM emits a ``UserQuestion`` tool
# call when it needs operator input mid-turn. Today this is
# main-agent-only (the ``tools_allowlist`` excludes ``UserQuestion``
# for sub-agents because they don't have a user to ask).
#
# After refactor: same behavior. ``Agent.apply_pre_tool_hooks``
# returns ``(False, "no user attached")`` for ``UserQuestion`` calls
# from a non-main agent. Main-agent ``UserQuestion`` calls go through
# the same ``ask_user`` helper above.
