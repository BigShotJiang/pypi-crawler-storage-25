"""Factory — build the right :class:`Agent` for a configured name.

The single entry point. Every caller that wants to drive an agent
(gateway, ``/agent`` slash command, ``delegate_agent`` tool) imports
:func:`load_agent` from here. Reading ``~/.rtxclaw/agents/<name>/config.json``
and branching on the ``engine`` field is the factory's only
responsibility — no policy lives in the engines themselves.
"""

from __future__ import annotations

import importlib
import logging
import shutil
from pathlib import Path
from typing import Optional

from .agent import Agent
from .engine import Engine, EngineKind
from . import default_scaffolds


_LOG = logging.getLogger("rtxclaw.agents.factory")


# Map EngineKind → (lazy import path, class name). Lazy so a typo in
# one engine module doesn't break loading agents of a different kind,
# and so we don't pay the import cost for engines an operator never
# uses.
_ENGINE_CLASSES: dict[EngineKind, tuple[str, str]] = {
    EngineKind.LOCAL_LLM:  ("rtxclaw_core.agents.local_llm", "LocalLLMEngine"),
    EngineKind.CLAUDE_CLI: ("rtxclaw_core.agents.claude_engine", "ClaudeCliEngine"),
    EngineKind.CODEX_CLI:  ("rtxclaw_core.agents.codex_engine", "CodexCliEngine"),
    EngineKind.GEMINI_CLI: ("rtxclaw_core.agents.gemini_engine", "GeminiCliEngine"),
}


def resolve_engine_kind(raw: Optional[str]) -> EngineKind:
    """Parse a config string into :class:`EngineKind`.

    Tolerates ``None`` / empty string (treated as
    :attr:`EngineKind.LOCAL_LLM` for back-compat with pre-refactor
    configs). Unknown values raise ``ValueError``.
    """
    if not raw:
        return EngineKind.LOCAL_LLM
    raw = str(raw).strip().lower()
    if not raw:
        return EngineKind.LOCAL_LLM
    try:
        return EngineKind(raw)
    except ValueError as exc:
        valid = ", ".join(k.value for k in EngineKind)
        raise ValueError(
            f"unknown engine kind: {raw!r}. Valid: {valid}"
        ) from exc


def _engine_for(kind: EngineKind, cfg: object) -> Engine:
    """Instantiate the right Engine subclass for ``kind``.

    LocalLLMEngine takes the AgentConfig (reads upstream/sampling/
    compaction from it on every turn); CLI engines take no args.
    """
    module_path, class_name = _ENGINE_CLASSES[kind]
    module = importlib.import_module(module_path)
    cls = getattr(module, class_name)
    if kind is EngineKind.LOCAL_LLM:
        return cls(cfg)
    return cls()


def load_agent(name: str) -> Agent:
    """Construct the :class:`Agent` for the named directory.

    1. ``AgentConfig.load(name)`` reads
       ``~/.rtxclaw/agents/<name>/config.json``.
    2. :func:`resolve_engine_kind` parses ``cfg.engine``.
    3. The matching :class:`Engine` subclass is instantiated.
    4. ``Agent(cfg=cfg, engine=engine)`` is returned.

    Does NOT check CLI availability — :meth:`Engine.is_available` is
    consulted lazily on the first turn so an agent with a missing
    CLI can still be listed in ``/agents`` (with a friendly status).

    Raises ``FileNotFoundError`` when no agent dir / config.json
    exists for ``name``; ``ValueError`` for an unknown engine kind.
    """
    from rtxclaw_core.agent import AgentConfig

    cfg = AgentConfig.load(name)
    kind = resolve_engine_kind(getattr(cfg, "engine", "") or "")
    engine = _engine_for(kind, cfg)
    return Agent(cfg=cfg, engine=engine)


def ensure_default_external_agents() -> list[str]:
    """Auto-scaffold ``agents/claude/``, ``agents/codex/``, ``agents/gemini/``.

    Called by the gateway at startup (and by the test suite). For each
    of the three external engines:

    1. If ``~/.rtxclaw/agents/<short_name>/config.json`` already
       exists, skip (operator may have customized it).
    2. If the corresponding CLI is missing from PATH, skip — never
       half-scaffold a dir.
    3. Otherwise, write the default scaffold via
       :func:`default_scaffolds.write_scaffold`.

    Returns the list of newly-created agent short names. Idempotent
    on every boot.
    """
    from rtxclaw_core.agent import agents_root

    root = agents_root()
    root.mkdir(parents=True, exist_ok=True)
    created: list[str] = []

    for kind in (
        EngineKind.CLAUDE_CLI,
        EngineKind.CODEX_CLI,
        EngineKind.GEMINI_CLI,
    ):
        short = default_scaffolds.short_name_for(kind.value)
        details = default_scaffolds._KIND_DETAILS[kind.value]
        cli_cmd = details["cli_command"]
        home = root / short
        if (home / "config.json").exists():
            continue
        if shutil.which(cli_cmd) is None:
            _LOG.info(
                "AGENT_SCAFFOLD_SKIP cli=%s reason=not_on_path",
                cli_cmd,
            )
            continue
        default_scaffolds.write_scaffold(home, kind.value)
        created.append(short)
        _LOG.info(
            "AGENT_SCAFFOLD_CREATED kind=%s home=%s",
            kind.value, home,
        )

    return created
