"""Uniform session log shape across every engine.

The single source of truth for "what does a session JSON file look
like, regardless of which engine ran it." Used for:

* Replay (TUI / Telegram render past sessions identically whether the
  engine was ``local_llm`` or ``claude_cli``).
* Cross-frontend sync (the ``_poll_session_for_external_turns`` path
  in ``rtxclaw_tui/app.py``).
* **Fine-tuning datasets** — operator harvests
  ``~/.rtxclaw/agents/*/sessions/*.json`` to train successor local
  models. Every turn MUST carry enough structured detail to be a
  training row on its own; no relying on inline ``🔧 <name> <json>``
  text markers to reconstruct tool calls.

Where today's data lives (legacy → new mapping):

* ``Session`` dataclass fields (``rtxclaw_core.session.Session``,
  L113–190) — preserved verbatim. New fields are additive.
* ``Session.add_turn`` (session.py L225) — current turn shape preserved;
  three new top-level fields are added (``engine``, ``tool_calls``,
  ``tool_results``) so external-engine turns carry structured detail
  that today is buried in the body's ``🔧`` text markers.
* The delegate runners' ``metrics.source = "claude"`` convention used
  by ``/v1/sessions/{sid}/delegate`` to tag a turn as engine-produced
  (see ``rtxclaw_tui/app.py`` L5371) — promoted to a first-class
  ``engine`` field so it doesn't depend on parsing ``metrics``.

Backward compat: every reader of the legacy shape (TUI history,
Telegram resume, ACP session/get) MUST continue to work. New fields
are optional and absent on pre-refactor saves.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


# ---- canonical turn record ------------------------------------------


@dataclass(slots=True)
class TurnRecord:
    """One turn in a session, engine-agnostic.

    The exact JSON shape every engine writes. Field-by-field:

    Legacy fields (already present in ``Session.add_turn``):

    * ``user`` — the user prompt. Plain string OR OpenAI-style vision
      multi-part list (preserved from session.py L228).
    * ``thinking`` — the engine's reasoning trace, if any. Empty for
      CLI engines that don't surface reasoning (Codex hides it by
      default; Claude/Gemini emit it as separate stream blocks).
    * ``content`` — the assistant's reply text. For CLI engines this
      is the concatenated ``TextDelta`` stream; for local LLM it's
      the upstream's content channel.
    * ``started_at`` / ``ended_at`` — ISO timestamps (session.py L233).
    * ``aborted`` / ``error`` / ``in_progress`` — lifecycle flags.
    * ``metrics`` — per-turn numbers. Today carries
      ``prompt_tokens`` / ``completion_tokens`` / ``ttft`` / ``gen_tps``
      / ``wall_time`` for local LLM; ``source="claude"`` plus an
      estimated chars-based proxy for delegate turns. Preserved
      as-is; the new ``engine`` field below makes the ``source``
      tag redundant but we keep both for one release cycle.

    **NEW fields** (additive — engines MUST populate):

    * ``engine`` — ``"local_llm"`` | ``"claude_cli"`` | ``"codex_cli"`` |
      ``"gemini_cli"``. Engine that produced the assistant content of
      this turn. Allows mid-session agent switches in the future
      without losing per-turn attribution.
    * ``model`` — engine-specific model id. Local LLM: the upstream
      model id (today persisted at session level only; promoted to
      per-turn so a mid-session ``/model`` switch is captured). Claude:
      the CLI's effective model (``claude-sonnet-4-6`` etc., from
      ``init`` event). Codex: the configured model. Gemini: same.
    * ``engine_session_id`` — the engine's own resume token at the
      time of this turn (Claude session uuid / Codex thread id /
      Gemini session uuid; empty for local LLM). Recorded so the
      training pipeline can correlate cross-turn state.
    * ``tool_calls`` — structured list of every tool call dispatched
      this turn. Each entry: ``{call_id, name, arguments, started_at}``.
      For local LLM this is what the model emitted; for CLI engines
      it's the inner Read/Bash/TodoWrite/etc. blocks that today live
      only as inline ``🔧 <name> <json>`` markers in ``content``.
    * ``tool_results`` — structured list of tool results. Each entry:
      ``{call_id, ok, content, ended_at}``. Pairs with ``tool_calls``
      by ``call_id``.
    * ``permission_mode`` — ``"plan"`` | ``"ask"`` | ``"auto"`` at
      the moment the turn ran. Recorded because the same prompt
      behaves differently under different modes; fine-tuning needs
      to know.
    """

    user: Any
    thinking: str
    content: str
    started_at: str
    ended_at: str
    engine: str
    model: str
    aborted: bool = False
    error: Optional[str] = None
    metrics: dict[str, Any] = field(default_factory=dict)
    in_progress: bool = False
    engine_session_id: str = ""
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    tool_results: list[dict[str, Any]] = field(default_factory=list)
    permission_mode: str = ""

    # ---- additional fine-tune fields (codex audit finding #9) ------
    #
    # All default to empty/None so legacy session readers ignore them
    # silently. Each field captures information the fine-tune pipeline
    # would otherwise reconstruct from sparse hints.

    # Working directory at turn time. Critical for code-context
    # fine-tuning (model behavior is heavily cwd-dependent).
    cwd: str = ""

    # Round index within the turn. Local-LLM turns can have many
    # rounds (model → tool → model → tool → final answer); each is
    # ONE record. Setting this lets the trainer reconstruct the
    # multi-round trajectory.
    round_index: int = 0

    # Why the upstream stopped. Sourced from worker
    # ``metrics.finish_reason`` for local LLM; CLI engines synthesize
    # ``"stop"|"tool_calls"|"length"|"error"`` from terminal events.
    finish_reason: str = ""

    # Classified upstream error when the round ended in TurnError.
    # See ``turn_runtime._classify_upstream_error``.
    error_classification: str = ""

    # Approval decisions per tool call:
    # ``[{call_id, decision, reason, source}, ...]``  where
    # ``source ∈ {policy|hook|user|auto}``.
    approval_decisions: list[dict[str, Any]] = field(default_factory=list)

    # Raw streamed tool arguments before json_repair (per call_id).
    # The repaired version lives in ``tool_calls[i].arguments``; this
    # preserves the original wire data for trainer truncation studies.
    raw_tool_arguments: dict[str, str] = field(default_factory=dict)

    # In-turn lifecycle audit events.
    compaction_events: list[dict[str, Any]] = field(default_factory=list)
    distill_events: list[dict[str, Any]] = field(default_factory=list)
    nudge_events: list[dict[str, Any]] = field(default_factory=list)
    pause_resume_log: list[dict[str, Any]] = field(default_factory=list)

    # Tool-result truncation flags (list of call_ids that were
    # truncated).
    truncated_tool_results: list[str] = field(default_factory=list)

    # CLI engine: effective argv (sans secrets) for reproducibility,
    # plus the active permission flags. Empty for local LLM.
    cli_argv: list[str] = field(default_factory=list)
    cli_permission_flags: list[str] = field(default_factory=list)

    # Multimodal attachment metadata (mime, size, sha256; raw bytes
    # live in a separate side-store keyed by sha).
    attachments: list[dict[str, Any]] = field(default_factory=list)


# ---- session header (top-of-file fields) ----------------------------


@dataclass(slots=True)
class SessionHeader:
    """Top-level fields on a session JSON, engine-agnostic.

    Mirrors ``Session.save`` payload (session.py L300–) plus the new
    attribution fields. Existing readers tolerate extra keys.
    """

    # Legacy (preserved verbatim from Session.save)
    hash: str
    title: str
    created_at: str
    system_prompt: str
    system_mode: str = ""
    workspace_cwd: str = ""
    workspace_origin: str = ""
    model: str = ""
    endpoint: str = ""
    backend: str = ""
    context_window: int = 0
    reasoning_visibility: str = "off"
    tool_output_visible: bool = False
    pinned_facts: list[str] = field(default_factory=list)
    compaction_summary: str = ""
    compaction_count: int = 0
    memory_flush_compaction_count: int = -1
    last_memory_flush_at: str = ""

    # NEW attribution fields:
    agent_name: str = ""    # which agent owned this session
    engine: str = ""        # the agent's engine at session-creation time
    # System prompt's stable hash — captured at session creation so a
    # training pipeline can group sessions that shared a SOUL/AGENTS
    # configuration even after the agent's files have evolved.
    system_prompt_sha256: str = ""
    # Whether reasoning traces persist into ``TurnRecord.thinking``.
    # Codex audit finding #9 (second half): "ALWAYS persisted" can be
    # a privacy footgun. Default True (fine-tune-friendly); operators
    # with regulatory constraints flip this to False per session.
    # Live reasoning rendering in the TUI is governed independently by
    # ``reasoning_visibility``.
    persist_reasoning_traces: bool = True


# ---- engine-side writer surface -------------------------------------


def record_turn(
    session: Any,           # actually rtxclaw_core.session.Session
    *,
    user: Any,
    thinking: str,
    content: str,
    started_at: str,
    ended_at: str,
    engine: str,
    model: str,
    sessions_dir: Optional[Any] = None,    # path-like
    engine_session_id: str = "",
    tool_calls: Optional[list[dict[str, Any]]] = None,
    tool_results: Optional[list[dict[str, Any]]] = None,
    permission_mode: str = "",
    aborted: bool = False,
    error: Optional[str] = None,
    metrics: Optional[dict[str, Any]] = None,
    in_progress: bool = False,
    # ---- fine-tune fields (codex audit round-1 #9 + round-2 #4) ----
    cwd: str = "",
    round_index: int = 0,
    finish_reason: str = "",
    error_classification: str = "",
    approval_decisions: Optional[list[dict[str, Any]]] = None,
    raw_tool_arguments: Optional[dict[str, str]] = None,
    compaction_events: Optional[list[dict[str, Any]]] = None,
    distill_events: Optional[list[dict[str, Any]]] = None,
    nudge_events: Optional[list[dict[str, Any]]] = None,
    pause_resume_log: Optional[list[dict[str, Any]]] = None,
    truncated_tool_results: Optional[list[str]] = None,
    cli_argv: Optional[list[str]] = None,
    cli_permission_flags: Optional[list[str]] = None,
    attachments: Optional[list[dict[str, Any]]] = None,
) -> None:
    """Single sink for "a turn just finished." Every engine calls this.

    Equivalent to today's ``Session.add_turn`` (session.py L225) plus
    the new attribution fields. Implementation:

    1. Build a :class:`TurnRecord` from the args. Apply the
       ``session.persist_reasoning_traces`` privacy gate: when False,
       ``thinking`` is dropped from the record (the live render still
       sees it; only the on-disk record is sanitized).
    2. Call ``session.add_turn(...)`` with legacy fields so existing
       readers keep working, AND inject the new fields directly onto
       the resulting dict (last element of ``session.turns``) so the
       JSON file carries them too.
    3. ``session.save(force=False)`` per the legacy contract.

    This function MUST be the ONLY place engines persist turn data —
    direct manipulation of ``session.turns`` is forbidden in the new
    architecture, so the on-disk shape stays uniform.

    Defaults for the new fields are conservative (empty / 0 / ""); a
    CLI-engine turn legitimately has e.g. ``round_index=0`` and no
    nudge events.
    """
    # Step 1 — privacy gate. If the session opts out of reasoning-trace
    # persistence, drop ``thinking`` on the way to disk. Live render in
    # the TUI still receives the chunks through the event stream.
    persist_reasoning = bool(getattr(session, "persist_reasoning_traces", True))
    thinking_to_persist = thinking if persist_reasoning else ""

    # Step 2 — legacy turn record. add_turn() places a dict at
    # session.turns[-1] with the original 9-key shape.
    session.add_turn(
        user=user,
        thinking=thinking_to_persist,
        content=content,
        started_at=started_at,
        ended_at=ended_at,
        aborted=aborted,
        error=error,
        metrics=metrics or {},
        in_progress=in_progress,
    )

    # Step 3 — inject new attribution + fine-tune fields onto the
    # just-appended turn dict. Existing readers that only look up the
    # nine legacy keys ignore the additions; the new agent layer (and
    # fine-tune harness) reads them.
    last = session.turns[-1]
    last["engine"] = engine
    last["model"] = model
    last["engine_session_id"] = engine_session_id
    last["tool_calls"] = list(tool_calls) if tool_calls else []
    last["tool_results"] = list(tool_results) if tool_results else []
    last["permission_mode"] = permission_mode
    last["cwd"] = cwd
    last["round_index"] = int(round_index or 0)
    last["finish_reason"] = finish_reason
    last["error_classification"] = error_classification
    last["approval_decisions"] = list(approval_decisions) if approval_decisions else []
    last["raw_tool_arguments"] = dict(raw_tool_arguments) if raw_tool_arguments else {}
    last["compaction_events"] = list(compaction_events) if compaction_events else []
    last["distill_events"] = list(distill_events) if distill_events else []
    last["nudge_events"] = list(nudge_events) if nudge_events else []
    last["pause_resume_log"] = list(pause_resume_log) if pause_resume_log else []
    last["truncated_tool_results"] = list(truncated_tool_results) if truncated_tool_results else []
    last["cli_argv"] = list(cli_argv) if cli_argv else []
    last["cli_permission_flags"] = list(cli_permission_flags) if cli_permission_flags else []
    last["attachments"] = list(attachments) if attachments else []

    # Step 4 — persist. Legacy save() handles the atomic write +
    # is-empty short-circuit. We don't force; a turn-bearing session
    # is never empty so the file lands. ``sessions_dir`` overrides
    # the module-level default the legacy ``Session.save(root=None)``
    # path would otherwise fall back to — required when the caller
    # (Agent) wants the file under the agent's own directory.
    session.save(root=sessions_dir, force=False)

    # Step 5 — publish ``turn_completed`` on the in-process event
    # bus so memory providers (sqlite_facts, MemoryManager) can
    # auto-extract facts from the just-finished turn. Best-effort;
    # failures here are downstream concerns, not part of the
    # durable save contract. Gemini audit phase-3a finding #1:
    # legacy ``CoreBackend`` triggers this every save; the new path
    # must too, otherwise fact extraction silently stops working
    # on every turn routed through Agent.run_turn.
    #
    # The agent_config (carrying ``cfg.home``) isn't directly
    # passed in here — we resolve it from ``session.agent_name``
    # via :func:`rtxclaw_core.agent.AgentConfig.load`. The
    # ``record_session_creation`` step already stamped
    # ``session.agent_name``, so this lookup is cheap.
    if not aborted and not in_progress:
        try:
            from rtxclaw_core.turn_runtime import _publish_turn_completed
            from rtxclaw_core.agent import AgentConfig
            agent_name = getattr(session, "agent_name", "") or ""
            if agent_name:
                cfg = AgentConfig.load(agent_name)
                _publish_turn_completed(session, user, content, cfg)
        except Exception:  # noqa: BLE001
            # turn_completed is a notification; never block a save
            # on it. Memory providers re-sync on the next tick.
            pass


def record_session_creation(
    session: Any,           # rtxclaw_core.session.Session
    *,
    agent_name: str,
    engine: str,
    system_prompt: str,
) -> None:
    """Stamp the new attribution fields onto a freshly-created Session.

    Called by ``Agent.create_session`` once. Computes
    ``system_prompt_sha256`` and writes ``agent_name`` + ``engine``
    onto the in-memory ``Session`` object. The next ``session.save()``
    persists them.
    """
    session.agent_name = agent_name
    session.engine = engine
    session.system_prompt_sha256 = compute_system_prompt_hash(system_prompt)


# ---- helpers --------------------------------------------------------


def make_tool_call_record(
    call_id: str,
    name: str,
    arguments: dict[str, Any],
    started_at: str,
) -> dict[str, Any]:
    """Canonical ``tool_calls[i]`` row.

    Engines build these from their stream parsers — Claude's
    ``content_block_start`` + ``content_block_stop`` pair, Codex's
    ``item.started`` with ``command_execution``, Gemini's ``tool_use``
    event. Local LLM builds them from the model's emitted tool calls.
    """
    return {
        "call_id": str(call_id),
        "name": str(name),
        "arguments": dict(arguments or {}),
        "started_at": str(started_at),
    }


def make_tool_result_record(
    call_id: str,
    ok: bool,
    content: str,
    ended_at: str,
) -> dict[str, Any]:
    """Canonical ``tool_results[i]`` row. Pairs with the call by id."""
    return {
        "call_id": str(call_id),
        "ok": bool(ok),
        "content": str(content or ""),
        "ended_at": str(ended_at),
    }


def compute_system_prompt_hash(system_prompt: str) -> str:
    """SHA-256 of the system prompt. Stable across sessions that share
    a SOUL/AGENTS/TOOLS configuration. Empty input → empty string so a
    not-yet-composed session has a sentinel rather than the sha of the
    empty string."""
    if not system_prompt:
        return ""
    import hashlib
    return hashlib.sha256(system_prompt.encode("utf-8")).hexdigest()
