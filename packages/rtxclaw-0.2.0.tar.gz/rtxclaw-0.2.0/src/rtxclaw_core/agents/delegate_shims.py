"""Cross-agent delegate-tool shims.

Holds the four ``delegate_*`` tool-runner shims that let an agent
dispatch a turn against another agent (``/claude``, ``/codex``,
``/gemini``, ``/delegate <name>``). Each shim loads the named child
agent through :func:`factory.load_agent`, opens / resumes a session
keyed off the parent sid, drives one turn via :meth:`Agent.run_turn`,
and assembles a :class:`ToolResult` whose ``content`` is the same
shape the legacy delegate runner emitted (so model transcript replay
is byte-stable across the cutover).

Renamed from ``legacy_compat`` at 2026-05-15 once the sidecar /
session-record migration helpers and the tool-call inline-marker
backfill that justified the old name were deleted — the remaining
content is the live cross-agent dispatch path, not legacy support.
"""

from __future__ import annotations

from typing import Any, Callable, Optional


async def _drive_child_agent_turn(
    short_name: str,
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> Any:
    """Common driver for the four ``shim_run_delegate_*`` shims.

    Loads the named child agent, opens (or resumes) a session keyed
    off the parent sid, dispatches one turn, and assembles a
    :class:`ToolResult` whose ``content`` is the same shape the
    delegate runner emits.
    """
    import os
    from rtxclaw_core.tools.runners import ToolResult
    from . import factory
    from .engine import TurnDone, TurnError, TextDelta, ToolCallStarted, ToolCallResult

    try:
        child = factory.load_agent(short_name)
    except FileNotFoundError:
        return ToolResult(
            content=f"[delegate {short_name}: no agent scaffolded — install the CLI and retry]",
            ok=False,
        )
    except Exception as exc:  # noqa: BLE001
        return ToolResult(
            content=f"[delegate {short_name}: load_agent failed: {exc}]",
            ok=False,
        )

    available, reason = child.engine.is_available()
    if not available:
        return ToolResult(
            content=f"[delegate {short_name}: {reason}]", ok=False,
        )

    # Resolve / create the child session keyed off the parent sid.
    parent_sid = os.environ.get("RTXCLAW_SESSION_ID") or ""
    child_sid = ""
    if parent_sid:
        sidecar = child.delegate_sidecar_path(parent_sid, child.engine.kind)
        if sidecar.exists():
            try:
                import json as _json
                data = _json.loads(sidecar.read_text(encoding="utf-8"))
                child_sid = (
                    data.get("rtxclaw_child_session_id")
                    or data.get("rtxclaw_session_id")
                    or ""
                )
            except (OSError, _json.JSONDecodeError):
                child_sid = ""

    if not child_sid or child.get_session(child_sid) is None:
        sess = child.create_session(
            workspace_cwd=args.get("cwd") or "",
            workspace_origin=f"delegate:{parent_sid[:12]}",
        )
        child_sid = sess.hash
        # Record the mapping so the next call resumes the same
        # child session.
        if parent_sid:
            try:
                import json as _json
                sidecar = child.delegate_sidecar_path(
                    parent_sid, child.engine.kind,
                )
                sidecar.parent.mkdir(parents=True, exist_ok=True)
                sidecar.write_text(
                    _json.dumps({
                        "rtxclaw_session_id": parent_sid,
                        "rtxclaw_child_session_id": child_sid,
                        "engine": child.engine.kind.value,
                    }, ensure_ascii=False),
                    encoding="utf-8",
                )
            except Exception:  # noqa: BLE001
                pass

    prompt = str(args.get("prompt") or args.get("task") or "")
    mode = str(args.get("mode") or os.environ.get("RTXCLAW_PERMISSION_MODE") or "auto")
    cwd = args.get("cwd") or None
    model = args.get("model") or None

    buf: list[str] = []
    ok = True
    last_error = ""

    async for ev in child.run_turn(
        child_sid, prompt, mode=mode, cwd=cwd, model=model,
    ):
        if isinstance(ev, TextDelta):
            if ev.channel != "tool_delta" and ev.text:
                buf.append(ev.text)
                if on_delta is not None:
                    try:
                        res = on_delta(ev.text)
                        if hasattr(res, "__await__"):
                            await res
                    except Exception:  # noqa: BLE001
                        pass
        elif isinstance(ev, ToolCallStarted):
            if on_event is not None:
                try:
                    res = on_event({
                        "kind": "tool_use",
                        "id": ev.call_id,
                        "name": ev.name,
                        "input": dict(ev.arguments or {}),
                    })
                    if hasattr(res, "__await__"):
                        await res
                except Exception:  # noqa: BLE001
                    pass
        elif isinstance(ev, ToolCallResult):
            if on_event is not None:
                try:
                    res = on_event({
                        "kind": "tool_result",
                        "tool_use_id": ev.call_id,
                        "ok": ev.ok,
                        "text": ev.content,
                    })
                    if hasattr(res, "__await__"):
                        await res
                except Exception:  # noqa: BLE001
                    pass
        elif isinstance(ev, TurnError):
            last_error = ev.message
        elif isinstance(ev, TurnDone):
            ok = ev.state == "ok"
            break

    body = "".join(buf)
    if not ok and last_error and last_error not in body:
        body = (body + "\n\n" + last_error).strip()
    return ToolResult(content=body, ok=ok)


async def shim_run_delegate_claude_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> Any:
    """Drive one Claude CLI turn keyed off the parent's session id."""
    return await _drive_child_agent_turn(
        "claude", args, on_delta=on_delta, on_event=on_event,
    )


async def shim_run_delegate_codex_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
) -> Any:
    """Drive one Codex CLI turn keyed off the parent's session id."""
    return await _drive_child_agent_turn(
        "codex", args, on_delta=on_delta,
    )


async def shim_run_delegate_gemini_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
) -> Any:
    """Drive one Gemini CLI turn keyed off the parent's session id."""
    return await _drive_child_agent_turn(
        "gemini", args, on_delta=on_delta,
    )


async def shim_run_delegate_agent_async(
    args: dict[str, Any],
    *,
    on_delta: Optional[Callable[[str], None]] = None,
    on_event: Optional[Callable[[dict], None]] = None,
) -> Any:
    """Dispatch one turn against a sibling rtxclaw agent.

    Works uniformly across engine kinds because the work is performed
    by ``Agent.run_turn`` on the target child agent.
    """
    # Accept every alias smaller-context LLMs typically reach for —
    # the canonical schema parameter is ``name`` but deepseek-v4-pro /
    # qwen / kimi often emit ``agent_id`` / ``agent_name`` / ``agent``
    # / ``target`` on the first attempt. Round-tripping a 4-round
    # tool-error recovery just to relearn the field name is wasteful
    # when the intent is unambiguous; normalise here so the FIRST
    # call lands.
    target = str(
        args.get("name")
        or args.get("agent")
        or args.get("agent_id")
        or args.get("agent_name")
        or args.get("target")
        or args.get("to")
        or ""
    )
    if not target:
        from rtxclaw_core.tools.runners import ToolResult
        return ToolResult(
            content=(
                "[delegate_agent: missing target agent — pass `name` "
                "(canonical) or any of agent / agent_id / agent_name "
                "/ target / to. Available agents: see ~/.rtxclaw/agents/]"
            ),
            ok=False,
        )
    # Normalise back to the canonical key + accept ``prompt`` /
    # ``message`` as task synonyms (registry says ``task``, but
    # delegate_claude / delegate_codex use ``prompt`` and the LLM
    # carries that habit over).
    args = dict(args)
    args["name"] = target
    if "task" not in args:
        for k in ("prompt", "message", "input"):
            v = args.get(k)
            if isinstance(v, str) and v.strip():
                args["task"] = v
                break
    return await _drive_child_agent_turn(
        target, args, on_delta=on_delta, on_event=on_event,
    )
