"""``AgentACPBackend`` — single, ACP-compliant backend for every agent.

The unified ACP surface the gateway mounts at ``/acp/<agent>`` for
EVERY agent regardless of engine kind. Single in-process backend
per agent; no child subprocess for the backend itself.

For ``local_llm`` engines: prompt routes through
:class:`CoreBackend` (which holds the same :class:`Agent` +
:class:`LocalLLMEngine` instance this backend was built with, so
session-lock / promoted-tools / mode-overrides state is single-
sourced) → :meth:`Agent.run_turn` → :meth:`LocalLLMEngine.run_turn`.
CoreBackend still owns session lifecycle (new_session, load_session,
list_sessions, close_session, cancel) and outbound permission/ask
routing.

For CLI engines (``claude_cli`` / ``codex_cli`` / ``gemini_cli``):
prompt routes through :meth:`Agent.run_turn` → :meth:`Engine.run_turn`
(:class:`ExternalCliEngine`) which translates the per-CLI
``run_delegate_*_async`` runner's callbacks into the uniform
:data:`AgentTurnEvent` stream. The Agent layer composes the
``--append-system-prompt`` priming + ``--resume`` sha-change policy.

Session lifecycle (new_session, list_sessions, etc.) routes through
CoreBackend for local-LLM and through :class:`Agent` directly for
CLI agents; both paths share the on-disk session format under
``~/.rtxclaw/agents/<name>/sessions/``.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, AsyncIterator, Mapping, Optional

from .agent import Agent
from .engine import EngineKind


_LOG = logging.getLogger("rtxclaw.agents.gateway_shim")


class AgentACPBackend:
    """Unified ACP backend wrapping one :class:`Agent`.

    Same instance for the lifetime of an agent registration. For
    local-LLM agents we hold a :class:`CoreBackend` that owns
    session lifecycle + outbound channel routing + cancel cascade;
    the actual multi-round turn loop lives in
    :class:`LocalLLMEngine.run_turn` (CoreBackend's ``prompt`` is a
    4-line proxy that forwards through ``Agent.run_turn``).
    Forwards prompt directly to :meth:`Agent.run_turn` for
    CLI-engine agents.
    """

    def __init__(self, agent: Agent) -> None:
        self.agent = agent
        self._engine_kind = agent.engine.kind

        # CoreBackend hosts the session-lifecycle / outbound-channel
        # / cancel-routing surface for local-LLM agents and proxies
        # ``prompt`` through ``Agent.run_turn``. We pass our
        # factory-built Agent in so CoreBackend reuses it instead of
        # constructing a second Agent + LocalLLMEngine pair —
        # per-session state on the engine (mode_overrides,
        # promoted_tools, session_locks, _cancelled,
        # _pending_user_messages, _active_turns, _session_to_turn)
        # is single-sourced. CLI-engine agents skip this layer
        # entirely; ``Agent.run_turn`` is called directly from
        # :meth:`prompt`.
        self._core: Optional[Any] = None
        if self._engine_kind is EngineKind.LOCAL_LLM:
            from rtxclaw_agent.acp_bridge import CoreBackend
            self._core = CoreBackend(agent.cfg, agent=agent)

        # Per-session active turn map — populated by the new CLI-engine
        # prompt path so :meth:`cancel` can route through
        # :meth:`Agent.abort`. For local-LLM agents, cancel forwards to
        # CoreBackend.cancel which has its own per-session map.
        self._cli_active_turns: dict[str, str] = {}  # sid → turn_id
        # CLI-engine outbound channel state. local-LLM agents use
        # ``self._core``'s equivalents; CLI agents have no inner
        # backend so the binding lives on AgentACPBackend itself.
        # Without these, the spec ``current_mode_update`` notification
        # and any future mode=ask gating fall through to ``None`` and
        # silently drop — exactly the regression gemini round-7 B3
        # flagged.
        self._cli_server_handle: Optional[Any] = None
        self._cli_session_servers: dict[str, Any] = {}

    # ---- AcpServer hookup ------------------------------------------

    @property
    def server_handle(self) -> Any:
        """Outbound ACP channel — used by mode=ask permission gating
        and ``current_mode_update`` notifications. For local-LLM
        agents forwarded to the inner :class:`CoreBackend`; for
        CLI-engine agents stored on this instance directly."""
        if self._core is not None:
            return getattr(self._core, "server_handle", None)
        return self._cli_server_handle

    @server_handle.setter
    def server_handle(self, value: Any) -> None:
        if self._core is not None:
            self._core.server_handle = value
        else:
            self._cli_server_handle = value

    def bind_session_server(self, session_id: str, server: Any) -> None:
        """Bind ``server`` as the outbound channel for ``session_id``.

        Called by :class:`AcpServer` on ``session/new`` /
        ``session/load`` so permission / ask_user / current_mode_update
        requests for the session route to the connection that owns it.
        The gateway shares one backend across every connection to
        ``/acp/<agent>``; per-session binding lets a multi-client
        deployment (TUI + Telegram) reach the right one.
        """
        if self._core is not None:
            self._core.bind_session_server(session_id, server)
        elif session_id:
            self._cli_session_servers[session_id] = server

    def unbind_session_server(self, session_id: str) -> None:
        """Drop the per-session outbound binding."""
        if self._core is not None:
            self._core.unbind_session_server(session_id)
        else:
            self._cli_session_servers.pop(session_id, None)

    def _outbound_for(self, session_id: str) -> Any:
        """Resolve the outbound ACP channel for ``session_id``.

        Local-LLM path delegates to ``CoreBackend._outbound_for``;
        CLI path uses the new ``_cli_session_servers`` map with a
        fallback to the bare ``server_handle`` for stub setups.
        """
        if self._core is not None:
            return self._core._outbound_for(session_id)
        srv = self._cli_session_servers.get(session_id)
        if srv is not None:
            return srv
        return self._cli_server_handle

    # ---- handshake -------------------------------------------------
    #
    # All method signatures here MUST match what
    # ``rtxclaw_acp.server.server.AcpServer`` calls (see
    # ``acp/server/server.py`` for the call sites). The AcpServer is
    # protocol-aware; this backend is the agent-side hookpoint.

    async def initialize(
        self,
        protocol_version: int,
        client_capabilities: Optional[Mapping[str, Any]],
        client_info: Optional[Mapping[str, Any]],
    ) -> Optional[Mapping[str, Any]]:
        if self._core is not None:
            return await self._core.initialize(
                protocol_version, client_capabilities, client_info,
            )
        # CLI-engine path: AcpServer's static capabilities suffice;
        # nothing to record on the backend.
        return None

    async def authenticate(self, method_id: str) -> None:
        if self._core is not None:
            await self._core.authenticate(method_id)
        # CLI engines: no-op; bearer auth is gateway-level.

    # ---- session lifecycle -----------------------------------------

    async def new_session(
        self,
        cwd: str,
        mcp_servers: list[Any],
    ) -> Mapping[str, Any]:
        if self._core is not None:
            return await self._core.new_session(cwd, mcp_servers)
        # CLI-engine path: build a Session via the Agent layer. The
        # response shape MUST match what ``CoreBackend.new_session``
        # returns so local-LLM and CLI agents look identical on the
        # wire — spec-shaped ``modes`` ({availableModes, currentModeId})
        # and ``configOptions`` (list). Snake-case ``config_options`` /
        # ``available_modes`` / ``active_mode`` are non-spec and would
        # break strict ACP clients.
        session = self.agent.create_session(
            workspace_cwd=cwd or "",
            workspace_origin="",
        )
        active_mode = (
            session.system_mode
            or getattr(self.agent.cfg, "permission_mode", "")
            or "auto"
        )
        return {
            "sessionId": session.hash,
            "modes": self._modes_state(active_mode),
            "configOptions": [],
        }

    async def load_session(
        self,
        session_id: str,
        cwd: str,
        mcp_servers: list[Any],
    ) -> Mapping[str, Any]:
        if self._core is not None:
            return await self._core.load_session(
                session_id, cwd, mcp_servers,
            )
        # CLI-engine path: mirror ``CoreBackend.load_session`` — return
        # one mapping (NOT a stream). The ACP spec's LoadSessionResponse
        # is a single mapping; frontends re-render past turns by reading
        # the on-disk session JSON directly, not by streaming sessionUpdate
        # events back through ``session/load``.
        session = self.agent.get_session(session_id)
        if session is None:
            raise RuntimeError(f"session not found: {session_id!r}")
        if cwd:
            try:
                session.workspace_cwd = cwd
            except Exception:  # noqa: BLE001
                pass
        active_mode = (
            session.system_mode
            or getattr(self.agent.cfg, "permission_mode", "")
            or "auto"
        )
        return {
            "modes": self._modes_state(active_mode),
            "configOptions": [],
        }

    async def list_sessions(
        self,
        cursor: Optional[str],
        cwd: Optional[str],
    ) -> Mapping[str, Any]:
        if self._core is not None:
            return await self._core.list_sessions(cursor, cwd)
        # CLI-engine agents (claude / codex / gemini) historically fell
        # through to ``self.agent.list_sessions()`` which returns rows
        # in rtxclaw-internal shape (``hash`` / ``turn_count`` /
        # ``created_at``). The ACP SDK validates session/list responses
        # against ``SessionInfo`` (``sessionId`` / ``cwd`` / ``title`` /
        # ``updatedAt``), so the rows were rejected on the wire and the
        # TUI / Telegram pickers silently received []. Use the shared
        # helper that BOTH backend paths now share for an ACP-shape
        # response — same sidecar filtering, same empty-turn drop,
        # same 20-cap.
        from rtxclaw_agent.acp_bridge import list_sessions_acp
        return list_sessions_acp(
            self.agent.cfg.sessions_dir, self.agent.cfg.home,
        )

    async def close_session(self, session_id: str) -> None:
        if self._core is not None:
            await self._core.close_session(session_id)
            return
        self._cli_active_turns.pop(session_id, None)
        self.agent.close_session(session_id)

    # ---- live config / mode ----------------------------------------

    async def set_mode(self, session_id: str, mode_id: str) -> None:
        if self._core is not None:
            await self._core.set_mode(session_id, mode_id)
            return
        valid = {"plan", "ask", "auto"}
        if mode_id not in valid:
            raise ValueError(f"unknown mode: {mode_id!r}")
        # CLI engines apply the mode to the NEXT --resume call's
        # permission flag.
        try:
            self.agent.engine.set_mode(session_id, mode_id)
        except Exception:  # noqa: BLE001
            pass
        # Persist on the session record so ``load_session`` round-
        # trips return the right ``currentModeId`` (gemini round-6
        # finding B3 — CLI-engine set_mode was dropping the persist
        # entirely).
        sess = self.agent.get_session(session_id)
        if sess is not None:
            try:
                sess.system_mode = mode_id
                sess.save(root=self.agent.sessions_dir, force=False)
            except Exception:  # noqa: BLE001
                pass
        # Emit the spec-required ``current_mode_update`` notification
        # so connected frontends can refresh their mode UI without
        # re-issuing ``session/load``. Use the per-session outbound
        # resolver so a multi-client (TUI + Telegram) deployment
        # reaches the connection that owns the session, not whichever
        # transport happened to set ``server_handle`` last.
        srv = self._outbound_for(session_id)
        notify = getattr(srv, "notify_session_update", None)
        if notify is None:
            return

        async def _emit() -> None:
            try:
                await notify(
                    session_id=session_id,
                    update={
                        "sessionUpdate": "current_mode_update",
                        "currentModeId": mode_id,
                    },
                )
            except Exception:  # noqa: BLE001
                pass

        try:
            import asyncio
            asyncio.create_task(_emit())
        except RuntimeError:
            pass

    async def set_config_option(
        self,
        session_id: str,
        option_id: str,
        value: Any,
    ) -> None:
        if self._core is not None:
            await self._core.set_config_option(session_id, option_id, value)
            return
        try:
            self.agent.engine.set_config_option(session_id, option_id, value)
        except Exception:  # noqa: BLE001
            pass

    async def inject_user_message(
        self, session_id: str, text: str,
    ) -> dict[str, Any]:
        """Mid-turn user-message inject — forward to the core bridge.

        The CoreBackend owns the live Agent + LocalLLMEngine pair and
        knows how to push the message into the engine's per-sid
        inject buffer. CLI-only agents (no ``_core``) don't yet
        support steering an in-flight CLI subprocess, so we surface a
        clear "not supported" ack and let the frontend fall back to
        the local turn queue.
        """
        if self._core is not None:
            return dict(
                await self._core.inject_user_message(session_id, text)
            )
        # CLI engine path: external CLI subprocess owns the turn loop
        # and can't accept mid-flight steering today. Future work
        # could wrap ``claude --resume`` / ``codex exec resume`` for
        # this — out of scope for the local-LLM path.
        return {
            "ok": False,
            "reason": "CLI engines do not support mid-turn inject",
        }

    def _modes_state(self, active_mode: str) -> dict[str, Any]:
        """Spec-shaped ``SessionModeState`` payload.

        Matches the ACP spec (``schema.json:SessionModeState``) and
        ``CoreBackend._modes_state`` byte-for-byte so frontends see the
        same mode list regardless of which engine drives the agent.
        """
        return {
            "availableModes": [
                {"id": "auto",
                 "name": "auto",
                 "description":
                     "Auto-approve safe tools; prompt on destructive actions."},
                {"id": "ask",
                 "name": "ask",
                 "description":
                     "Prompt for confirmation on every tool call."},
                {"id": "plan",
                 "name": "plan",
                 "description":
                     "Plan-only mode — propose tool calls without executing."},
            ],
            "currentModeId": active_mode,
        }

    # ---- turn dispatch ---------------------------------------------

    async def cancel(self, session_id: str) -> None:
        if self._core is not None:
            await self._core.cancel(session_id)
            return
        turn_id = self._cli_active_turns.get(session_id)
        if turn_id:
            try:
                await self.agent.abort(turn_id)
            except Exception:  # noqa: BLE001
                pass

    async def prompt(
        self,
        session_id: str,
        message_id: Optional[str],
        prompt: list[Mapping[str, Any]],
    ) -> AsyncIterator[Mapping[str, Any]]:
        """ACP ``session/prompt`` — drive one turn.

        For local-LLM agents: forward through :class:`CoreBackend`,
        whose ``prompt`` is a 4-line proxy that calls
        :meth:`Agent.run_turn` and translates the AgentTurnEvent
        stream into ACP sessionUpdate dicts via
        :mod:`.acp_translation`.

        For CLI-engine agents: call :meth:`Agent.run_turn` directly
        and translate the AgentTurnEvent stream here.
        """
        if self._core is not None:
            async for ev in self._core.prompt(session_id, message_id, prompt):
                yield ev
            return

        # CLI-engine path.
        from . import acp_translation
        from rtxclaw_agent.acp_bridge import (
            _flatten_prompt,
            _blocks_to_user_content,
            _parse_direct_delegate_marker,
        )

        # Direct-dispatch sentinel: ``/claude``, ``/codex``,
        # ``/gemini``, ``/delegate <agent>`` from any frontend.
        # User-facing semantics are "run this prompt against the
        # named agent and return the result" — independent of which
        # agent the user is currently on. Honor the sentinel here so
        # ``/claude`` works whether the active agent is local-LLM
        # (main, scraper, …) or a CLI agent (codex, gemini,
        # claude itself). The actual cross-agent call rides on the
        # legacy delegate-shim, which under the new architecture
        # drives the named child agent via ``Agent.run_turn``.
        direct = _parse_direct_delegate_marker(prompt)
        if direct is not None:
            async for msg in self._dispatch_direct_delegate(
                session_id, direct,
            ):
                yield msg
            return

        text = _flatten_prompt(prompt)
        parts: list[dict[str, Any]] = []
        if any((b.get("type") or "") != "text" for b in prompt):
            user_content = _blocks_to_user_content(prompt)
            if isinstance(user_content, list):
                parts = [dict(p) for p in user_content]

        events = self.agent.run_turn(
            session_id,
            prompt=text,
            prompt_parts=parts or None,
        )

        def _on_turn_started(ev: Any) -> None:
            try:
                self._cli_active_turns[session_id] = ev.turn_id
            except Exception:  # noqa: BLE001
                pass

        try:
            async for msg in acp_translation.agent_events_to_acp(
                events,
                context_window=int(
                    getattr(self.agent.cfg, "upstream_max_context", 0) or 0
                ),
                on_turn_started=_on_turn_started,
            ):
                yield msg
        except Exception as exc:  # noqa: BLE001
            _LOG.warning(
                "agent_events_to_acp failed for sid=%s: %s",
                session_id[:12], exc,
            )
            yield {
                "sessionUpdate": "agent_message_chunk",
                "content": {
                    "type": "text",
                    "text": f"[backend error: {exc}]",
                },
            }
            yield {"stopReason": "end_turn"}
        finally:
            self._cli_active_turns.pop(session_id, None)

    async def _dispatch_direct_delegate(
        self,
        session_id: str,
        direct: Mapping[str, Any],
    ) -> AsyncIterator[Mapping[str, Any]]:
        """Run a direct-dispatch ``/claude`` / ``/codex`` / ``/gemini``
        / ``/delegate <agent>`` sentinel and stream ACP events back.

        Works for every active agent — local-LLM AND CLI-engine —
        because the work is performed by a *child* Agent
        (``factory.load_agent(<short>)``) regardless of who the
        parent is. The active agent's session is left untouched;
        the child's reply rides back as one ``tool_call`` /
        ``tool_call_update`` pair so the frontend renders it inline.
        """
        from . import delegate_shims
        from rtxclaw_agent.acp_bridge import _text_tool_content

        tool = str(direct.get("tool") or "")
        args = direct.get("arguments") or {}
        if not isinstance(args, dict):
            args = {}

        shim_map = {
            "delegate_claude": delegate_shims.shim_run_delegate_claude_async,
            "delegate_codex":  delegate_shims.shim_run_delegate_codex_async,
            "delegate_gemini": delegate_shims.shim_run_delegate_gemini_async,
            "delegate_agent":  delegate_shims.shim_run_delegate_agent_async,
        }
        shim = shim_map.get(tool)
        if shim is None:
            yield {
                "sessionUpdate": "agent_message_chunk",
                "content": {
                    "type": "text",
                    "text": f"[direct-dispatch: unknown tool {tool!r}]",
                },
            }
            yield {"stopReason": "end_turn"}
            return

        # Map the delegate tool to a friendly title for the inline
        # ``tool_call`` widget the frontends render.
        title_map = {
            "delegate_claude": "↳ via claude",
            "delegate_codex":  "↳ via codex",
            "delegate_gemini": "↳ via gemini",
            "delegate_agent":  f"↳ via {args.get('name') or 'agent'}",
        }
        call_id = f"direct-{session_id[:8]}-{tool}"
        yield {
            "sessionUpdate": "tool_call",
            "toolCallId": call_id,
            "title": title_map.get(tool, tool),
            "kind": "other",
            "rawInput": dict(args),
        }

        # Bridge ``on_delta`` chunks → ``tool_call_update`` events
        # so the user sees the child's reply stream live.
        ev_queue: asyncio.Queue[Optional[str]] = asyncio.Queue()

        def _on_delta(chunk: str) -> None:
            try:
                ev_queue.put_nowait(chunk)
            except Exception:  # noqa: BLE001
                pass

        async def _drive() -> Any:
            try:
                # delegate_codex / delegate_gemini don't accept on_event.
                try:
                    return await shim(args, on_delta=_on_delta)
                except TypeError:
                    return await shim(args)
            finally:
                await ev_queue.put(None)  # sentinel

        driver = asyncio.create_task(_drive())
        self._cli_active_turns[session_id] = call_id

        try:
            while True:
                chunk = await ev_queue.get()
                if chunk is None:
                    break
                if chunk:
                    yield {
                        "sessionUpdate": "tool_call_update",
                        "toolCallId": call_id,
                        "status": "in_progress",
                        "content": _text_tool_content(chunk),
                    }
            try:
                result = await driver
            except asyncio.CancelledError:
                yield {
                    "sessionUpdate": "tool_call_update",
                    "toolCallId": call_id,
                    "status": "failed",
                    "content": _text_tool_content("[cancelled]"),
                }
                yield {"stopReason": "cancelled"}
                return
            except Exception as exc:  # noqa: BLE001
                yield {
                    "sessionUpdate": "tool_call_update",
                    "toolCallId": call_id,
                    "status": "failed",
                    "content": _text_tool_content(f"[shim error: {exc}]"),
                }
                yield {"stopReason": "end_turn"}
                return

            body = str(getattr(result, "content", "") or "")
            ok = bool(getattr(result, "ok", True))
            yield {
                "sessionUpdate": "tool_call_update",
                "toolCallId": call_id,
                "status": "completed" if ok else "failed",
                "content": _text_tool_content(body),
            }
            yield {"stopReason": "end_turn"}
        finally:
            if not driver.done():
                driver.cancel()
                try:
                    await driver
                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                    pass
            self._cli_active_turns.pop(session_id, None)
