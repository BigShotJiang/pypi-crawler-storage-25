"""``LocalLLMEngine`` — the full local-LLM turn-execution surface.

Drives a local-LLM-backed turn end-to-end: multi-round dispatch,
worker-subprocess streaming, tool calls (singleton + parallel batch),
permission policy, hooks (SessionStart / UserPromptSubmit / PreToolUse /
PostToolUse / Stop / PreCompact), proactive + reactive compaction,
layered loop detection, distill recovery, continuation-nudge variants
(silent EOS / mid-syntax cutoff / colon cliffhanger), force-terminate,
mid-turn user-message inject, soft-abort, KV-cache instrumentation.

``rtxclaw_agent.acp_bridge.CoreBackend.prompt`` is now a thin proxy
that forwards every prompt request through ``Agent.run_turn`` →
``LocalLLMEngine.run_turn`` and translates the yielded
``AgentTurnEvent`` stream back to ACP sessionUpdate dicts via
:mod:`.acp_translation`. CoreBackend still owns session lifecycle
(new_session / load_session / list_sessions / close_session / cancel /
inject_user_message / set_mode / set_config_option) plus outbound
permission/ask routing.

The reusable module-level helpers this engine relies on live in
``acp_bridge.py`` and ``rtxclaw_agent.worker``: ``_default_spawn_worker``,
``_default_run_tool``, ``_build_worker_request``, ``_build_parallel_groups``,
``_call_is_parallel_eligible``, ``_state_file_key``, ``_ask_user_outbound``.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any, AsyncIterator, Awaitable, Callable, Optional


_LOG = logging.getLogger("rtxclaw.agents.local_llm")

from .engine import (
    AgentTurnEvent,
    Engine,
    EngineKind,
    EngineSessionState,
    RoundComplete,
    TextDelta,
    TurnDone,
    TurnError,
    TurnRequest,
    TurnStarted,
    UserMessageInjected,
)


def _now_iso() -> str:
    """Wall-clock ISO timestamp, local TZ. Matches the legacy
    ``acp_bridge._now()`` format so saved-turn timestamps are
    comparable across backends."""
    import datetime as _dt
    return _dt.datetime.now().astimezone().isoformat()


def _classify(msg: str) -> str:
    """Forward to ``turn_runtime._classify_upstream_error``.

    Module-level shim so we don't have to import inside the hot path.
    """
    try:
        from rtxclaw_core.turn_runtime import _classify_upstream_error
        return _classify_upstream_error(msg or "")
    except Exception:  # noqa: BLE001
        return ""


async def _terminate_and_reap(
    proc: "Optional[asyncio.subprocess.Process]",
    stderr_task: "Optional[asyncio.Task[None]]",
) -> None:
    """Background cleanup task for a worker subprocess.

    Codex audit round-3 phase-3a #1+#2: ``terminate()`` schedules SIGTERM
    but doesn't reap the process; if no one awaits ``proc.wait()`` it
    becomes a zombie. This helper drains the stderr task + reaps the
    proc. Scheduled from ``_schedule_background_reap``; self-removed
    from the engine's reaper set via ``add_done_callback``.

    Best-effort: every exception is swallowed so a stuck worker
    doesn't bring down the engine.
    """
    if stderr_task is not None and not stderr_task.done():
        stderr_task.cancel()
        try:
            await stderr_task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
    if proc is not None:
        try:
            if proc.returncode is None:
                proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                # Worker didn't exit in 5s; escalate.
                try:
                    proc.kill()
                except Exception:  # noqa: BLE001
                    pass
                try:
                    await proc.wait()
                except Exception:  # noqa: BLE001
                    pass
        except ProcessLookupError:
            pass
        except Exception:  # noqa: BLE001
            pass


async def _drain_stderr(
    stream: "asyncio.StreamReader",
    rtxclaw_sid: str,
    turn_id: str,
) -> None:
    """Continuously read worker stderr and surface it via the logger.

    Codex audit round-3 finding #4: ``stderr=asyncio.subprocess.PIPE``
    is set in the legacy spawn helper; if no one drains it, a noisy
    worker can fill its PIPE and block on write, hanging the turn.

    This coroutine reads stderr line-by-line and emits each as a
    structured log line. Cancellation (the caller calls
    ``stderr_task.cancel()`` when run_turn exits) is handled silently.
    """
    try:
        while True:
            line = await stream.readline()
            if not line:
                return
            try:
                text = line.decode("utf-8", "replace").rstrip()
            except Exception:  # noqa: BLE001
                continue
            if text:
                _LOG.info(
                    "WORKER_STDERR sid=%s turn=%s line=%s",
                    rtxclaw_sid[:12], turn_id[:12], text[:500],
                )
    except asyncio.CancelledError:
        return
    except Exception:  # noqa: BLE001
        # Best-effort; don't propagate.
        return


# =====================================================================
# Constants the local-LLM path uses today. Promoted here (rather than
# re-imported from acp_bridge / turn_runtime / worker) so the new
# module is self-contained for review. Values stay in lockstep with
# the legacy constants — diff-check during step-2 implementation.
# =====================================================================

# Mirror of acp_bridge.py module-level constants.
MAX_ROUNDS_AUTO: int = 999      # auto mode cap — effectively unbounded
DEFAULT_MAX_ROUNDS: int = 20    # interactive (ask/plan) per-turn cap

# Mirror of turn_runtime.py constants.
LOOP_CHECK_STRIDE: int = 1024   # chars between layered-loop detector samples
LOOP_NGRAM_LEN: int = 30        # n-gram width fed to the layered detector
LOOP_REPEAT_THRESHOLD: int = 8  # repeats of the same n-gram → loop hit
LOOP_WINDOW_CHARS: int = 4096   # min chars before the detector arms
LOOP_DETECT_ENABLED: bool = True  # env-tunable via RTXCLAW_LOOP_DETECT

# Mirror of worker.py defaults.
WORKER_READ_TIMEOUT_S: float = 120.0   # per-chunk SSE read ceiling
PREFILL_FLOOR_MS: float = 50.0          # min plausible prefill duration
LOOP_CHARS_PER_TOKEN_MIN: float = 0.5   # token-loop ratio guard floor (see worker.py)
LOOP_RATIO_MIN_TOKENS: int = 500         # min completion tokens before the ratio check fires

# Compaction guard fraction — when est. tokens cross this × ctx_window
# the pre-round squeeze fires (turn_runtime.py compact_messages).
DEFAULT_COMPACT_AT_FRAC: float = 1.0

# How many times a blocking ``Stop`` hook may re-enter the round loop
# within one turn before the engine ends it anyway. Mirrors Claude
# Code's ``stop_hook_active`` infinite-loop guard. Overridable per-
# session via ``cfg.max_stop_continuations`` so an operator can extend
# (or tighten) the cap for a specific agent / mode without forking
# the engine.
_MAX_STOP_CONTINUATIONS: int = 3

# Continuation-nudge budget. Small models — particularly qwen3.6-class —
# sometimes drop EOS after a tool chain without writing any user-visible
# summary, so the operator sees a silent end and has to type "status" to
# discover what happened. We re-prompt the model up to
# ``MAX_NUDGES_PER_TURN`` times asking it to either finish the task or
# summarize. Hard-capped so a model that won't comply can't loop the
# agent. Overridable per-session via ``cfg.max_nudges_per_turn`` so an
# operator can extend (or tighten) the cap for a specific agent / mode.
MAX_NUDGES_PER_TURN: int = 2
# Final-round content shorter than this (after .strip()) counts as "the
# model said nothing". 10 chars is enough to allow a one-word answer
# like "done." but rejects pure whitespace / a stray period.
NUDGE_MIN_TEXT_CHARS: int = 10
NUDGE_PROMPT_BODY: str = (
    "[rtxclaw continuation] You stopped after a tool chain without "
    "writing anything user-visible. The user only sees content tokens "
    "— your reasoning channel is invisible. Write the final answer "
    "to the user now: concise and direct. Either summarize what you "
    "found and what's next, or keep working if there's more to do. "
    "Do not start a new chain of thought."
)
# Continuation-nudge body for the mid-sentence-cutoff variant. Distinct
# wording from ``NUDGE_PROMPT_BODY`` (silent-EOS-after-tools) — that one
# tells the model "you said nothing, write a final answer"; this one
# tells the model "you wrote prose then paused for a tool, your prose
# ended mid-sentence at <tail>, RESUME from there."
CUTOFF_NUDGE_PROMPT_BODY: str = (
    "[rtxclaw continuation] Your previous response was cut mid-sentence "
    "at: …{tail}\n\nResume writing from that exact point — finish the "
    "sentence first, then continue the section you were in. Do not "
    "restart the report or re-summarize what you've already written."
)
# Continuation-nudge body for the colon-cliffhanger variant. The model
# emitted prose that ended on a colon (which usually precedes a tool
# call) but produced no tool_calls. Witnessed 2026-05-12 with
# gpu-d/qwen3.6-27b-fp8-mtp + qwen3_coder tool-call parser: the round
# stops at "the routine stores `tif`:" with ``finish_reason=stop`` and
# the operator sees a dangling colon as the "final answer".
COLON_CLIFFHANGER_NUDGE_PROMPT_BODY: str = (
    "[rtxclaw continuation] Your previous response ended on a colon "
    "promising more content or a tool call, but nothing followed: …{tail}"
    "\n\nEither emit the tool call you were about to issue, or finish "
    "the sentence and write the user-facing answer. Do not restart or "
    "re-summarize."
)


def _detect_content_cutoff(content: str) -> Optional[str]:
    """Return the offending tail (~80 chars) when the assistant's
    streamed content ends in an unclosed syntactic structure, else None.

    Conservative on purpose — fires only on signals that are
    unambiguously mid-syntax, never on prose that ends with a comma /
    colon (the model legitimately pauses for tool calls with phrases
    like "Searching for X:"). Triggers:

    1. Odd count of triple-backtick fences in the tail — the model
       opened a code block but didn't close it.
    2. Odd count of inline backticks in the tail (after stripping
       triple fences) — the model opened ``inline code`` and stopped
       before closing it. Witnessed on the 2026-05-10 qwen3 long-
       planning report: the round ended at ``…handles Qwen leaking ` ``
       and the next round abandoned the report instead of resuming.

    Returns the last ~80 chars of ``content`` for inclusion in the
    continuation prompt so the model knows exactly where to resume.
    """
    if not content:
        return None
    s = content.rstrip()
    if not s:
        return None
    tail = s[-500:] if len(s) > 500 else s
    triple_fences = tail.count("```")
    if triple_fences % 2 == 1:
        return s[-80:]
    inline_backticks = tail.count("`") - 3 * triple_fences
    if inline_backticks % 2 == 1:
        return s[-80:]
    return None


def _detect_colon_cliffhanger(content: str) -> Optional[str]:
    """Return the offending tail (~80 chars) when the assistant's
    content ends on a colon but no tool call followed, else None.

    Witnessed 2026-05-12 with gpu-d/qwen3.6-27b-fp8-mtp + qwen3_coder
    tool-call parser: the round stops at "the routine stores `tif`:"
    with ``finish_reason=stop`` and zero tool calls. Caller MUST guard
    this with "round produced no tool_calls" so a healthy round that
    pauses for a tool call ("Searching for X:") does not trigger it.
    """
    if not content:
        return None
    s = content.rstrip()
    if not s.endswith(":"):
        return None
    return s[-80:]


def _format_runtime_warning(event: str, **fields: Any) -> str:
    """Format a runtime-warning line for the TUI's visible message stream.

    Surfaces loop / repetition / premature-finish events that the
    engine catches and recovers from. Without this, the recovery
    machinery (loop detector → distill → force-terminate, nudge
    detectors) is silent on the TUI: turns either appear to die or
    appear to continue normally, and the operator has to grep
    ``gateway.log`` to see what actually fired. Each line is one
    notification, prefixed with ``⚠`` for hard interventions
    (loops/force-terminate) and ``↻`` for soft recoveries
    (distill/nudges). Newlines top-and-tail isolate the warning from
    surrounding model output in the rendered bubble.

    ``event`` is a short kebab-case label (``loop-detected``,
    ``loop-distill``, ``loop-force-terminate``, ``nudge``). ``fields``
    are stringified ``k=v`` pairs; values longer than 80 chars are
    truncated.
    """
    soft = event in ("loop-distill", "nudge")
    glyph = "↻" if soft else "⚠"
    parts: list[str] = [f"{glyph} runtime: {event}"]
    for k, v in fields.items():
        if v is None or v == "":
            continue
        sv = str(v)
        if len(sv) > 80:
            sv = sv[:77] + "…"
        parts.append(f"{k}={sv}")
    body = " · ".join(parts)
    return f"\n\n{body}\n\n"


def _should_nudge(
    *,
    final_text_chars: int,
    tool_rounds_so_far: int,
    nudge_count: int,
    cancelled: bool,
    terminate_reason: Optional[str],
    silent_chain: bool,
    max_nudges: int = MAX_NUDGES_PER_TURN,
    min_text_chars: int = NUDGE_MIN_TEXT_CHARS,
) -> bool:
    """Pure decision function for the continuation-nudge detector.

    Extracted so the policy can be unit-tested without spinning up
    the whole engine. Returns True when the engine should inject one
    more ``NUDGE_PROMPT_BODY`` round; False otherwise.

    ``max_nudges`` and ``min_text_chars`` are overridable so the
    engine can thread per-session cfg overrides
    (``cfg.max_nudges_per_turn`` / ``cfg.nudge_min_text_chars``)
    without forking the constants.
    """
    if cancelled:
        return False
    if tool_rounds_so_far < 1:
        return False
    if final_text_chars >= min_text_chars:
        return False
    if nudge_count >= max_nudges:
        return False
    if terminate_reason not in (None, "end_turn"):
        return False
    if silent_chain:
        return False
    return True


# =====================================================================
# LocalLLMEngine
# =====================================================================


class LocalLLMEngine(Engine):
    """Drive a local-LLM-backed turn end-to-end.

    Composition site: one instance per :class:`Agent`, configured from
    that Agent's :class:`AgentConfig`. The engine reads the live config
    on every turn (no caching) so a runtime ``/model`` switch or
    ``/mode`` change takes effect on the next call.
    """

    kind = EngineKind.LOCAL_LLM

    def __init__(
        self,
        agent_config: Any,
        *,
        # Test seams — production passes None and the defaults below kick in.
        worker_spawner: Optional[Callable[..., Awaitable[Any]]] = None,
        tool_runner: Optional[Callable[..., Awaitable[Any]]] = None,
        max_rounds_override: Optional[int] = None,
    ) -> None:
        """Build with an :class:`AgentConfig`.

        Test seams (``worker_spawner`` / ``tool_runner``) let tests
        inject scripted streams without spawning real worker / tool
        subprocesses. Production passes ``None`` and the engine uses
        :func:`rtxclaw_agent.acp_bridge._default_spawn_worker` /
        :func:`_default_run_tool` from the helper module.
        """
        self.cfg = agent_config
        self._worker_spawner = worker_spawner
        self._tool_runner = tool_runner
        self._max_rounds_override = max_rounds_override

        # Per-session live state. Persisted across turns inside the
        # same session, dropped on close_session. All local-LLM-
        # specific — CLI engines don't have rounds, tool dispatch,
        # or context promotion.
        #
        # Persisted across turns inside the same session, dropped on
        # close_session.
        self._cancelled: dict[str, bool] = {}             # rtxclaw_sid → flag
        self._promoted_tools: dict[str, set[str]] = {}    # rtxclaw_sid → names
        self._mode_overrides: dict[str, str] = {}         # rtxclaw_sid → mode
        # Last Session object passed to ``attach_session`` — Agent.get_session
        # falls back to this when the on-disk file hasn't been written
        # yet (fresh zero-turn sessions, race between create and first
        # prompt). The bridge force-saves on create_session so this is
        # rarely needed, but it's the defense-in-depth path for any
        # caller that skips the bridge entirely.
        self._sessions: dict[str, Any] = {}               # rtxclaw_sid → Session
        # Mid-turn user message inject buffer. Frontends (TUI / Telegram)
        # push fresh user prompts here while a turn is already streaming
        # — ``run_turn`` drains the list at every round boundary and
        # appends each entry to the live message list as a ``user``-role
        # message before the next worker spawn. Lets a slow multi-round
        # plan pivot on a new user instruction without waiting for the
        # current turn to end. Per-sid because two sessions on the same
        # process must not cross-contaminate.
        self._pending_user_messages: dict[str, list[str]] = {}
        # Soft-abort flag set by ``inject_user_message`` when it SIGTERMs
        # the current round's worker so the model stops generating its
        # now-stale response. Distinguishes "user is pivoting, drain the
        # inject and continue the turn" from "operator hit ESC / sent
        # session/cancel, terminate the turn outright" (which sets
        # ``_cancelled[sid]`` instead). Cleared at the next round.
        self._soft_aborts: dict[str, bool] = {}
        # Sessions that have already received a ``SessionStart`` hook
        # event this process lifetime. Used to fire SessionStart at most
        # once per session — at the FIRST run_turn — without needing
        # tighter coupling to session create/load.
        self._sessions_started: set[str] = set()

        # Unified abort routing (codex audit round-2 finding #5).
        # The Engine ABC contract says ``abort(turn_id)`` — the engine
        # MUST be able to look up the live subprocess by turn_id, not
        # by sid. Two maps:
        #
        # * ``_active_turns: dict[turn_id, TurnState]`` — what abort()
        #   reads. One entry per in-flight turn; populated by run_turn,
        #   cleared in its finally block.
        # * ``_session_to_turn: dict[rtxclaw_sid, turn_id]`` — what the
        #   gateway's ACP ``cancel(session_id)`` resolves through. The
        #   AgentACPBackend reads this to translate sid → turn_id, then
        #   calls ``engine.abort(turn_id)``. Only one turn at a time
        #   per sid (session_lock guarantees), so this is a 1:1 map.
        self._active_turns: dict[str, Any] = {}           # turn_id → TurnState
        self._session_to_turn: dict[str, str] = {}        # rtxclaw_sid → turn_id
        # Per-session async lock — serialize concurrent prompts per sid
        # (codex audit round-1 finding #3). Lazy-allocated on first
        # session_lock() call.
        self._session_locks: dict[str, "asyncio.Lock"] = {}
        # Background reap tasks for workers that were terminated from a
        # sync ``finally`` block (e.g. consumer aclose mid-yield). Each
        # task awaits ``proc.wait()`` so the subprocess is reaped, and
        # cleans up the stderr drainer. Self-removes on completion via
        # ``add_done_callback`` (codex audit round-3 phase-3a #1+#2).
        self._background_reapers: set["asyncio.Task[None]"] = set()

    # -----------------------------------------------------------------
    # Engine ABC surface
    # -----------------------------------------------------------------

    @property
    def name(self) -> str:
        return "local_llm"

    def state_path(self, sessions_dir: Path, rtxclaw_sid: str) -> Path:
        """Returns ``<sessions_dir>/<sid>.local_llm.json`` symbolically.

        Never written — every round re-sends the full context, so there
        is no server-side resume id to persist. The path exists for
        symmetry with the CLI engines so callers can probe ``exists()``
        without branching on engine kind.
        """
        return Path(sessions_dir) / f"{rtxclaw_sid}.local_llm.json"

    def read_state(
        self, sessions_dir: Path, rtxclaw_sid: str
    ) -> EngineSessionState:
        """Return a blank state. Driver doesn't depend on it.

        Local LLM has no engine-side session id. The Agent's
        first-call-vs-resume decision is driven instead by
        :meth:`system_prompt_policy` which always returns
        ``"every_turn"`` for local LLM — so this returns a fresh blank
        :class:`EngineSessionState` and that's it.
        """
        return EngineSessionState(
            rtxclaw_session_id=rtxclaw_sid,
            engine=EngineKind.LOCAL_LLM,
        )

    def write_state(
        self, sessions_dir: Path, state: EngineSessionState
    ) -> None:
        """No-op. Local LLM has no engine-side session id."""
        return None

    def system_prompt_policy(
        self,
        state: "EngineSessionState",
        *,
        current_system_prompt_sha256: str,
    ) -> str:
        """Always ``"every_turn"``.

        The local LLM is stateless across rounds — every prompt
        request to the upstream HTTP API carries the full message
        list including a fresh system prompt. The Agent layer composes
        the prompt once per turn and the engine prepends it on every
        round within that turn. ``current_system_prompt_sha256`` is
        ignored (no persisted session to invalidate).
        """
        return "every_turn"

    async def session_lock(
        self, rtxclaw_sid: str
    ) -> Any:  # asyncio.Lock
        """Lazy-allocate a per-session asyncio.Lock.

        Cached in ``self._session_locks: dict[str, asyncio.Lock]``.
        Local LLM mostly doesn't NEED this since rounds are sequential
        within a turn — but the Engine ABC contract requires it, and
        we use it to serialize the "two simultaneous prompts on the
        same sid" case the same way CLI engines do.
        """
        lock = self._session_locks.get(rtxclaw_sid)
        if lock is None:
            lock = asyncio.Lock()
            self._session_locks[rtxclaw_sid] = lock
        return lock

    def attach_session(self, rtxclaw_sid: str, session: "Any") -> None:
        """Initialize per-session live state.

        Sets ``self._cancelled[sid] = False`` + ``self._promoted_tools[sid]
        = set()``. Pulls any prior mode override from
        ``session.system_mode`` (today's :class:`Session` carries
        this field). Also caches ``session`` on ``self._sessions`` so
        ``Agent.get_session`` can recover it when the on-disk file
        hasn't been written yet.
        """
        self._cancelled.setdefault(rtxclaw_sid, False)
        self._promoted_tools.setdefault(rtxclaw_sid, set())
        if session is not None:
            self._sessions[rtxclaw_sid] = session
        mode = str(getattr(session, "system_mode", "") or "") or None
        if mode:
            self._mode_overrides[rtxclaw_sid] = mode

    def detach_session(self, rtxclaw_sid: str) -> None:
        """Cleanup on ``close_session``.

        Codex audit round-3 #5 + round-4 #2:

        * If a turn is in flight (``_session_to_turn[sid]`` present)
          preserve EVERYTHING — including ``_cancelled[sid]`` —
          so an abort flag set during the spawn window doesn't get
          silently dropped while the still-active run_turn is
          waiting to observe it. Caller should abort + await
          TurnDone, then re-call ``close_session``.
        * Once idle, drop the per-session bookkeeping atomically.
        """
        if rtxclaw_sid in self._session_to_turn:
            _LOG.warning(
                "detach_session called while turn is active for sid=%s; "
                "all per-session state preserved until run_turn exits",
                rtxclaw_sid[:12],
            )
            return
        # Clear SessionStart memory so a later attach of the same sid
        # re-fires the hook with source="resume" (and prevents a
        # slow set leak across many sessions).
        self._sessions_started.discard(rtxclaw_sid)
        self._cancelled.pop(rtxclaw_sid, None)
        self._promoted_tools.pop(rtxclaw_sid, None)
        self._mode_overrides.pop(rtxclaw_sid, None)
        self._session_locks.pop(rtxclaw_sid, None)
        self._sessions.pop(rtxclaw_sid, None)
        self._pending_user_messages.pop(rtxclaw_sid, None)
        self._soft_aborts.pop(rtxclaw_sid, None)

    def inject_user_message(self, rtxclaw_sid: str, text: str) -> bool:
        """Queue a user message for the in-flight (or next) turn.

        Frontends call this when the user submits a fresh prompt while
        the model is already streaming a multi-round plan. The
        ``run_turn`` round-loop drains
        ``self._pending_user_messages[sid]`` at every round boundary,
        appending each entry to the live ``messages`` as a
        ``{"role": "user", "content": text}`` block before the next
        worker spawn — so the model sees the steering message on its
        very next round and can pivot.

        Soft-abort the current worker: when a turn is in flight, we
        ALSO call ``turn_state.stop()`` on the active round so the
        in-progress model generation gets SIGTERM'd. Without this,
        the model finishes the prior plan's final assistant content
        (sometimes 30K+ tokens — observed 2026-05-15 with qwen3.6-27b
        completing a categorized inventory before addressing the
        steer) and the inject only lands AFTER that wasted work. The
        engine's per-sid ``_cancelled`` flag is intentionally NOT
        set — only the worker subprocess dies; the round-loop then
        sees EOF, recovers gracefully, and the next iteration's
        drain picks up the inject so the model pivots.

        Returns ``True`` when the message was queued. ``False`` only
        if ``text`` is empty/whitespace. The method does NOT require an
        active turn — if no turn is running, the queued message will be
        picked up at the start of the next ``run_turn`` call for this
        sid (round 0 drain).
        """
        text = (text or "").strip()
        if not text:
            return False
        self._pending_user_messages.setdefault(rtxclaw_sid, []).append(text)
        # Soft-abort the in-flight worker (if any) so the round-loop
        # pivots NOW rather than after the model finishes its current
        # generation. Don't touch ``_cancelled`` — that would terminate
        # the whole turn instead of just rolling to the next round.
        # The soft-abort flag tells the engine read loop to treat the
        # worker's eventual ``{kind: aborted}`` event as a normal
        # round end rather than a real cancellation.
        #
        # Only set the flag when there's a live worker to actually
        # interrupt. Setting it when ``stop()`` is a no-op (no active
        # turn, worker already exited between rounds) would leave
        # stale state that suppresses a later real cancel.
        turn_id = self._session_to_turn.get(rtxclaw_sid)
        turn_state = (
            self._active_turns.get(turn_id) if turn_id else None
        )
        if turn_state is not None:
            self._soft_aborts[rtxclaw_sid] = True
            try:
                turn_state.stop()
            except Exception:  # noqa: BLE001
                pass
        return True

    def _drain_pending_user_messages(
        self, rtxclaw_sid: str
    ) -> list[str]:
        """Atomically pull every pending inject for ``rtxclaw_sid``.

        Returns the list in arrival order and clears the buffer. The
        round-loop calls this at the top of each round; appending the
        drained entries to ``messages`` is the caller's job (so the
        engine controls placement relative to preamble / compaction).
        """
        pending = self._pending_user_messages.get(rtxclaw_sid)
        if not pending:
            return []
        out = list(pending)
        pending.clear()
        return out

    def is_available(self) -> tuple[bool, str]:
        """``True`` always — upstream endpoint reachability is checked
        lazily on the first HTTP call (today's
        ``rtxclaw_agent.openai_endpoint`` already surfaces 502 / refused
        / DNS errors as structured tool-result errors)."""
        return True, ""

    def _schedule_background_reap(
        self,
        proc: "Optional[asyncio.subprocess.Process]",
        stderr_task: "Optional[asyncio.Task[None]]",
    ) -> None:
        """Schedule a fire-and-forget cleanup task for a worker proc.

        Called from a sync ``finally`` block (where we can't ``await``)
        when the generator has been ``aclose()``d mid-yield, OR from
        the inner cancellation handler so the abort path returns
        quickly without inline-awaiting ``proc.wait(timeout=2)``
        (codex audit round-3 phase-3a #1+#2+#3).

        The task awaits ``proc.wait()`` so the subprocess is reaped
        cleanly, cancels and awaits the stderr drainer, then removes
        itself from ``_background_reapers``.
        """
        if proc is None and stderr_task is None:
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return                              # no loop — nothing to do
        task = loop.create_task(_terminate_and_reap(proc, stderr_task))
        self._background_reapers.add(task)
        task.add_done_callback(self._background_reapers.discard)

    async def abort(self, turn_id: str, *, force: bool = False) -> None:
        """Best-effort kill of the named in-flight turn.

        Codex audit round-2 finding #5: keyed by ``turn_id``. Looks up
        the :class:`TurnState`, calls its ``stop(force=…)`` to SIGTERM
        (or SIGKILL+killpg when ``force=True``) the worker and every
        registered runner subprocess, then reverse-resolves the sid
        to mark cancellation.

        ``force=True`` is the two-press hard-kill escalation
        ``CoreBackend.cancel`` triggers when a second ESC lands inside
        ``_HARD_KILL_WINDOW_S`` — propagates the SIGKILL +
        ``killpg`` semantics that ``TurnState.stop`` already
        implements.

        Round-3 finding #2: flags cancellation EVEN IF the turn
        hasn't reached the ``_active_turns`` map yet (we're in the
        spawn window). The flag is checked by run_turn at the top of
        the read loop, so the turn either dies at spawn-time-cancel
        or right after the first event.

        Idempotent — unknown turn_ids are still recorded as cancelled
        via the sid reverse-resolve below.
        """
        turn = self._active_turns.get(turn_id)
        if turn is not None:
            try:
                turn.stop(force=force)
            except TypeError:
                # Older ``TurnState.stop`` had no ``force`` kwarg.
                try:
                    turn.stop()
                except Exception:  # noqa: BLE001
                    pass
            except Exception:  # noqa: BLE001
                pass
        # Reverse-resolve sid and flag cancellation. This works even
        # when the spawn hasn't yet populated _active_turns — run_turn
        # checks self._cancelled[sid] before yielding any event.
        for sid, tid in list(self._session_to_turn.items()):
            if tid == turn_id:
                self._cancelled[sid] = True
                break

    # -----------------------------------------------------------------
    # Main turn driver
    # -----------------------------------------------------------------

    async def run_turn(  # type: ignore[override]
        self,
        request: TurnRequest,
        state: EngineSessionState,
        *,
        sessions_dir: Path,
        turn_id: str,
        env: Optional[dict[str, str]] = None,
    ) -> AsyncIterator[AgentTurnEvent]:
        """Drive a full multi-round turn against the local LLM.

        This method ABSORBS the body of ``CoreBackend.prompt`` (acp_bridge.py
        L2838–~L3500). The translation from ACP sessionUpdate dicts to
        :data:`AgentTurnEvent` instances happens at every ``yield``.

        Sequence (high level):

        1. **Load session** — fetch ``Session`` by ``request.extra["sid"]``
           via :meth:`_session_for`.
        2. **Direct-tool-call bypass** — if ``request.extra`` carries a
           ``__RTXCLAW_DELEGATE__:`` sentinel, route through
           :meth:`_run_direct_tool_call`. This is what ``/claude``,
           ``/codex``, ``/gemini``, ``/compact`` slash commands hit.
           (acp_bridge.py L2860–2873)
        3. **Build message list** — :meth:`_build_messages_simple`. The
           composed system prompt arrives via ``request.system_prompt``;
           the below-cache-boundary preamble blocks (skills, memory
           recall, pinned facts, rolling summary, todos) arrive via
           ``request.preamble``. The engine NEVER reaches into
           SOUL/AGENTS/TOOLS.md or the memory provider itself —
           composition is exclusively the Agent layer's responsibility
           (codex audit finding #5).
        4. **Round loop** — up to ``self._max_rounds_for_mode()`` (auto
           = effectively uncapped). Per round:

           a. :meth:`_apply_round_preamble` — splice
              ``request.preamble`` back into the working message list.
              Idempotent — same content replaces prior placement.
           b. :meth:`_maybe_compact` — proactive context squeeze.
           c. :meth:`_log_round` — KV-cache hash instrumentation.
           d. Spawn worker via :meth:`_spawn_worker`.
           e. Consume worker events via :meth:`_consume_worker_events`,
              translating each to :data:`AgentTurnEvent`.
           f. Streaming loop-detection on ``thinking`` + ``content``
              channels (3 detectors layered).
           g. On ``tool_calls`` event: dispatch via
              :meth:`_dispatch_tool_calls`. May yield
              :class:`PermissionRequested` events back through the
              :class:`Agent` for ASK-mode calls. After each call,
              append the tool-result message and continue.
           h. On natural ``done`` with no tool_calls: end-of-turn.
           i. On ``aborted`` / streamed-loop / ratio-loop / context-
              overflow: route through the appropriate recovery
              (:meth:`_distill_recovery` / :meth:`_reactive_compact` /
              :meth:`_continuation_nudge` / :meth:`_force_terminate`).

        8. **Post-turn**:

           * :func:`session_log.record_turn` — uniform turn record
             (engine="local_llm", model, tool_calls, tool_results,
             metrics).
           * ``Session.save()``.
           * ``HookEngine.post_turn`` if hooks loaded
             (``cfg.hooks_path``).
           * Memory provider ``post_turn_observe`` hook
             (``memory_manager.observe_turn(session)``).
           * Pre-compaction memory flush check
             (``cfg.memory_flush_enabled`` + threshold math).

        9. **Yield** ``TurnDone(state=…)`` with final metrics.
        """
        from .engine import (
            TextDelta, ToolCallResult, ToolCallStarted, TurnDone,
            TurnError, TurnStarted,
        )

        # Pull caller-supplied session out of request.extra. The Agent
        # layer puts it there so the engine doesn't need to re-load it.
        session = request.extra.get("session")
        if session is None:
            yield TurnError(
                message="LocalLLMEngine.run_turn requires "
                        "request.extra['session']",
                classification="bad_request",
            )
            yield TurnDone(state="error")
            return

        rtxclaw_sid = session.hash
        # Reset stale cancel flag at the START of a turn so an abort
        # of a PRIOR turn doesn't carry over (codex audit round-3 #8).
        self._cancelled[rtxclaw_sid] = False
        # Set sid → turn_id BEFORE spawn so ESC during the spawn
        # window still routes correctly (codex audit round-3 #2).
        self._session_to_turn[rtxclaw_sid] = turn_id

        # Hook engine + per-turn hook context — supplied by the Agent
        # layer. The Agent owns the :class:`HookEngine`; the *engine*
        # owns the turn loop, so this is where Claude Code's hook
        # lifecycle (UserPromptSubmit / PreToolUse / PostToolUse /
        # Stop / PreCompact) actually fires.
        hook_engine = request.extra.get("hook_engine")
        hook_ctx = dict(request.extra.get("hook_ctx") or {})

        # Per-turn aggregates — populated as rounds run so the Agent
        # layer can persist a uniform record regardless of how we exit.
        thinking_buf: list[str] = []
        content_buf: list[str] = []
        engine_tool_calls: list[dict[str, Any]] = []
        engine_tool_results: list[dict[str, Any]] = []
        last_metrics: dict[str, Any] = {}
        terminal_state = "error"
        started_at_iso = _now_iso()

        yield TurnStarted(
            turn_id=turn_id,
            rtxclaw_session_id=rtxclaw_sid,
            engine_session_id="",
            resumed=False,
        )

        # --- SessionStart hook (first turn per session) -----------------
        if hook_engine is not None and rtxclaw_sid not in self._sessions_started:
            self._sessions_started.add(rtxclaw_sid)
            # Resume vs startup: any prior turns on the session means
            # this is a resume; otherwise startup. Operator-facing
            # `clear` / `compact` sources land here only if the caller
            # set them on the engine state — we default to inferring.
            _source = "resume" if (
                getattr(session, "turns", None) and len(session.turns) > 0
            ) else "startup"
            # ``Setup`` (Claude Code spec) — fires on first-init flows
            # before SessionStart. We treat any startup with no prior
            # turns AND no prior session metadata as the first-init
            # case. An ECC plugin can stage one-time scaffolding
            # (writing CLAUDE.md, generating a starter SOUL, etc.)
            # here; SessionStart fires next for the regular per-session
            # init work.
            if _source == "startup":
                _setup = await self._fire_hook(
                    hook_engine, hook_ctx, "Setup",
                    {"source": "startup"},
                )
                for _sm in _setup.system_messages:
                    yield TextDelta(text=f"[hook] {_sm}\n", channel="content")
                if _setup.additional_context:
                    yield TextDelta(
                        text=_setup.additional_context + "\n",
                        channel="content",
                    )
            _ss = await self._fire_hook(
                hook_engine, hook_ctx, "SessionStart",
                {"source": _source},
            )
            # Surface system messages; additionalContext from
            # SessionStart is folded into the user turn below.
            for _sm in _ss.system_messages:
                yield TextDelta(text=f"[hook] {_sm}\n", channel="content")

        # --- Direct-dispatch bypass (/claude /codex /gemini /compact) ----
        # The Agent passes the raw prompt; if it leads with the
        # ``__RTXCLAW_DELEGATE__`` sentinel the operator drove the
        # dispatch decision (no LLM round) — route straight to the
        # delegate tool. ``_run_direct_tool_call`` yields its own
        # terminal ``TurnDone``.
        direct = None
        try:
            from rtxclaw_agent.acp_bridge import _parse_direct_delegate_marker
            direct = _parse_direct_delegate_marker(
                [{"type": "text", "text": request.prompt or ""}]
            )
        except Exception:  # noqa: BLE001
            direct = None
        if direct is not None:
            async for ev in self._run_direct_tool_call(session, turn_id, direct):
                yield ev
            return

        # --- UserPromptSubmit hooks (Claude Code) -----------------------
        # Fires for EVERY prompt, including multimodal (image / file
        # parts). Skipping it on multipart would let a user bypass a
        # blocking inspection hook simply by attaching an image —
        # contradicts Claude Code's security contract.
        user_text = request.prompt or ""
        if hook_engine is not None:
            ups = await self._fire_hook(
                hook_engine, hook_ctx, "UserPromptSubmit",
                {"prompt": user_text},
            )
            for sm in ups.system_messages:
                yield TextDelta(text=f"[hook] {sm}\n", channel="content")
            if ups.blocked or not ups.should_continue:
                yield TurnError(
                    message=(
                        ups.block_reason or ups.stop_reason
                        or "blocked by a UserPromptSubmit hook"
                    ),
                    classification="hook_blocked",
                )
                yield TurnDone(state="error")
                return
            if ups.additional_context:
                user_text = (
                    f"{ups.additional_context}\n\n{user_text}"
                    if user_text else ups.additional_context
                )

            # ``UserPromptExpansion`` (Claude Code spec) — fires AFTER
            # UserPromptSubmit so a plugin can rewrite slash commands
            # / argument-expanded skill invocations before the prompt
            # is built into the message list. Most useful for
            # plugins that ship custom slash commands (e.g. ``/research-wiki``
            # → "run the multi-loop research skill with topic X").
            # Hook ``decision: block`` + ``reason: <expanded prompt>``
            # rewrites ``user_text`` wholesale; ``additionalContext``
            # is prepended.
            command_name = ""
            if user_text.lstrip().startswith("/"):
                first_token = user_text.lstrip().split(maxsplit=1)[0]
                command_name = first_token  # includes the leading "/"
            upe = await self._fire_hook(
                hook_engine, hook_ctx, "UserPromptExpansion",
                {"prompt": user_text, "command": command_name},
            )
            for sm in upe.system_messages:
                yield TextDelta(text=f"[hook] {sm}\n", channel="content")
            if upe.blocked and upe.block_reason:
                user_text = upe.block_reason
            elif upe.additional_context:
                user_text = (
                    f"{upe.additional_context}\n\n{user_text}"
                    if user_text else upe.additional_context
                )
            if not upe.should_continue:
                yield TurnError(
                    message=(
                        upe.stop_reason
                        or "blocked by a UserPromptExpansion hook"
                    ),
                    classification="hook_blocked",
                )
                yield TurnDone(state="error")
                return

        # Build the initial message list (system + preamble + transcript
        # + the live user turn).
        user_content: "str | list[dict[str, Any]]"
        if request.prompt_parts:
            user_content = list(request.prompt_parts)
        else:
            user_content = user_text
        messages = self._build_messages_simple(
            session, user_content,
            request.system_prompt, request.preamble,
        )

        # ``InstructionsLoaded`` (Claude Code spec) — fires once per
        # turn after the system prompt + preamble (CLAUDE.md /
        # AGENTS.md / SOUL.md / pinned facts) is composed, so an ECC
        # plugin can:
        #   * Observe what instructions are active (audit trail).
        #   * Inject ``additionalContext`` that is prepended to the
        #     system prompt for THIS round only (per-turn dynamic
        #     context, e.g. "user is in plan mode — read-only tools
        #     allowed", or freshly-fetched docs from a remote source).
        # The hook receives the joined preamble text as ``source``
        # match-target (the file paths are not exposed by
        # ``request.preamble`` directly — it's already-rendered
        # text — but the plugin can scope by inspecting the
        # ``preamble`` payload field for substrings).
        if hook_engine is not None and hook_engine.has_event(
            "InstructionsLoaded",
        ):
            _preamble_text = (
                "\n\n".join(request.preamble or [])
                if isinstance(request.preamble, (list, tuple))
                else str(request.preamble or "")
            )
            instr = await self._fire_hook(
                hook_engine, hook_ctx, "InstructionsLoaded",
                {
                    "system_prompt": request.system_prompt or "",
                    "preamble": _preamble_text,
                    "source": "round_preamble",
                },
            )
            for _sm in instr.system_messages:
                yield TextDelta(text=f"[hook] {_sm}\n", channel="content")
            if instr.additional_context and messages:
                # Splice the hook's text BEFORE the system prompt
                # (so it acts as a prefix wrapper). If no system
                # prompt is present, fall through to inserting at
                # position 0 of the message list.
                if (
                    isinstance(messages[0], dict)
                    and messages[0].get("role") == "system"
                ):
                    sys_body = str(messages[0].get("content") or "")
                    messages[0] = dict(messages[0])
                    messages[0]["content"] = (
                        f"{instr.additional_context}\n\n{sys_body}"
                        if sys_body else instr.additional_context
                    )
                else:
                    messages.insert(
                        0,
                        {
                            "role": "system",
                            "content": instr.additional_context,
                        },
                    )

        max_rounds = self._max_rounds_for_mode(rtxclaw_sid)
        promoted = self._promoted_tools.setdefault(rtxclaw_sid, set())
        nudge_log: list[dict[str, Any]] = []
        distill_recoveries = 0
        force_terminate_attempted = False
        stop_continuations = 0
        # Tracks rounds whose worker yielded one or more ``tool_calls`` —
        # the continuation-nudge policy fires ONLY after at least one
        # tool-using round so a normal first-round end_turn is never
        # nudged. Mirrors ``_should_nudge.tool_rounds_so_far``.
        tool_rounds_so_far = 0

        # Round budget is shared ACROSS Stop-hook continuations — a
        # blocking Stop hook gets whatever's left of ``max_rounds``, not
        # a full fresh budget every time. (Without this, 3 continuations
        # could spin the agent for 4× the configured cap.)
        round_idx = 0
        try:
            # Outer loop: a blocking ``Stop`` hook re-enters the round
            # loop with the hook's reason appended as a fresh user
            # message (bounded by ``_MAX_STOP_CONTINUATIONS``).
            while True:
                while round_idx < max_rounds:
                    if self._cancelled.get(rtxclaw_sid):
                        terminal_state = "aborted"
                        break

                    # Mid-turn user-message inject drain. Any prompts
                    # the frontend pushed via ``inject_user_message``
                    # while the previous round was streaming land here
                    # as fresh user-role messages — so a slow plan can
                    # pivot on the steering input on its very next
                    # worker spawn instead of waiting for the turn to
                    # end. Drained AFTER the cancel check (so an abort
                    # racing the inject still wins) and BEFORE the
                    # preamble splice (so the new user turn appears
                    # below the standard pinned/summary/todos blocks).
                    #
                    # Each inject is wrapped in an explicit override
                    # directive — without it, qwen3.6-27b treats the
                    # new prompt as a follow-up question (observed
                    # 2026-05-15: the model finished a 36K-char
                    # categorized table AND addressed the steer
                    # instead of dropping the prior plan). The marker
                    # makes "user is changing direction" explicit so
                    # the small model knows to drop expansion of the
                    # prior plan and act on the new directive alone.
                    pending = self._drain_pending_user_messages(
                        rtxclaw_sid,
                    )
                    for text in pending:
                        wrapped = (
                            "⚠ MID-TURN USER STEER — the user has "
                            "interrupted with a new instruction. Stop "
                            "expanding on the prior plan. Treat this "
                            "as the operative request; any prior tool "
                            "work counts only if it directly serves "
                            "this new directive.\n\n"
                            f"{text}"
                        )
                        messages.append(
                            {"role": "user", "content": wrapped}
                        )
                        yield UserMessageInjected(
                            text=text, round_idx=round_idx,
                        )

                    # Re-splice the Agent-composed preamble + proactive
                    # compaction before every round (idempotent).
                    if round_idx > 0:
                        messages = self._apply_round_preamble(
                            messages, request.preamble,
                        )
                    # PreCompact only fires when compaction will
                    # actually fire (cheap threshold check), not every
                    # round_idx > 0 — an expensive PreCompact hook
                    # firing 20 times per turn was the original
                    # complaint.
                    #
                    # A PreCompact hook can SUBSTITUTE the compaction
                    # strategy via two output shapes:
                    #   * ``hookSpecificOutput.replacementMessages``
                    #     (a list of {role, content} dicts) — the
                    #     engine uses these wholesale instead of
                    #     running ``_maybe_compact``.
                    #   * ``decision: block`` with no replacement →
                    #     compaction is SKIPPED entirely (operator
                    #     asks the engine to push the unmodified
                    #     message list at the model and risk a
                    #     context-overflow error, which the
                    #     reactive-compact path catches).
                    compaction_handled_by_hook = False
                    if hook_engine is not None and round_idx > 0:
                        _ctx = int(
                            getattr(self.cfg, "upstream_max_context", 0)
                            or 0,
                        )
                        if _ctx > 0:
                            try:
                                from rtxclaw_core.turn_runtime import (
                                    _approx_tokens,
                                )
                                _est = _approx_tokens(messages)
                                _frac = float(
                                    getattr(
                                        self.cfg, "compact_at_frac",
                                        DEFAULT_COMPACT_AT_FRAC,
                                    ) or DEFAULT_COMPACT_AT_FRAC
                                )
                                if _est + 4096 >= int(_ctx * _frac):
                                    pc = await self._fire_hook(
                                        hook_engine, hook_ctx,
                                        "PreCompact",
                                        {
                                            "trigger": "auto",
                                            "custom_instructions": "",
                                            "current_tokens": _est,
                                            "context_window": _ctx,
                                        },
                                    )
                                    # Honor replacementMessages (sub-
                                    # stitute strategy) or block:skip.
                                    for r in (pc.results or []):
                                        j = getattr(r, "json_output", None)
                                        if not isinstance(j, dict):
                                            continue
                                        hso = j.get("hookSpecificOutput")
                                        if isinstance(hso, dict):
                                            rm = hso.get(
                                                "replacementMessages",
                                            )
                                            if (
                                                isinstance(rm, list)
                                                and all(
                                                    isinstance(m, dict)
                                                    for m in rm
                                                )
                                            ):
                                                messages = list(rm)
                                                compaction_handled_by_hook = True
                                                break
                                    if (
                                        not compaction_handled_by_hook
                                        and pc.blocked
                                    ):
                                        # Hook asked to skip compaction
                                        # without a substitute. Leave
                                        # ``messages`` unchanged.
                                        compaction_handled_by_hook = True
                            except Exception:  # noqa: BLE001
                                pass
                    if not compaction_handled_by_hook:
                        messages = self._maybe_compact(session, messages)
                    self._log_round(
                        rtxclaw_sid, turn_id, round_idx, messages, [],
                    )

                    # Spawn the worker round.
                    try:
                        turn_state, event_stream = await self._spawn_worker(
                            session=session, messages=messages,
                            turn_id=turn_id, env=env,
                        )
                    except Exception as exc:  # noqa: BLE001
                        yield TurnError(
                            message=f"worker spawn failed: {exc}",
                            classification="spawn_failed",
                        )
                        terminal_state = "error"
                        break
                    self._active_turns[turn_id] = turn_state
                    proc = getattr(turn_state, "proc", None)
                    stderr_task: Optional[asyncio.Task[None]] = None
                    if proc is not None and proc.stderr is not None:
                        stderr_task = asyncio.create_task(
                            _drain_stderr(proc.stderr, rtxclaw_sid, turn_id),
                        )

                    rs = _RoundState()
                    round_error: Optional[str] = None
                    round_error_class = ""
                    had_done = False
                    try:
                        async for ev in event_stream:
                            if self._cancelled.get(rtxclaw_sid):
                                try:
                                    turn_state.stop()
                                except Exception:  # noqa: BLE001
                                    pass
                                break
                            if not isinstance(ev, dict):
                                continue
                            kind = ev.get("kind") or ""
                            if kind == "thinking":
                                txt = str(ev.get("text") or "")
                                if txt:
                                    rs.thinking_buf.append(txt)
                                    # Privacy gate: stream thinking
                                    # deltas to the frontend only when
                                    # the operator opted in. Buffering
                                    # for the session record stays on
                                    # so the turn audit still has the
                                    # trace (subject to
                                    # session.persist_reasoning_traces).
                                    if str(
                                        getattr(
                                            self.cfg,
                                            "reasoning_visibility",
                                            "off",
                                        ) or "off"
                                    ).lower() != "off":
                                        yield TextDelta(
                                            text=txt, channel="thinking",
                                        )
                            elif kind == "content":
                                txt = str(ev.get("text") or "")
                                if txt:
                                    rs.content_buf.append(txt)
                                    yield TextDelta(
                                        text=txt, channel="content",
                                    )
                                    hit, rs.content_loop_check_chars = (
                                        self._check_streamed_loop(
                                            rs.content_buf,
                                            rs.content_loop_check_chars,
                                            "content",
                                        )
                                    )
                                    if hit is not None:
                                        rs.loop_detected = True
                                        rs.loop_tier, rs.loop_evidence = hit
                                        try:
                                            turn_state.stop()
                                        except Exception:  # noqa: BLE001
                                            pass
                                        break
                            elif kind == "tool_calls":
                                for c in (
                                    ev.get("calls")
                                    or ev.get("tool_calls") or []
                                ):
                                    if isinstance(c, dict):
                                        rs.pending_tool_calls.append(dict(c))
                            elif kind == "tool_args_loop":
                                rs.loop_detected = True
                                rs.loop_tier = "ratio"
                                rs.loop_evidence = str(
                                    ev.get("evidence") or "tool_args_loop",
                                )
                            elif kind == "metrics":
                                rs.metrics = {
                                    k: v for k, v in ev.items()
                                    if k != "kind"
                                }
                            elif kind == "aborted":
                                # Distinguish hard cancel (operator hit
                                # ESC, ACP session/cancel) from soft
                                # abort (``inject_user_message`` killed
                                # the worker so the model pivots). Soft
                                # aborts leave ``_cancelled`` alone so
                                # the round-loop continues to the next
                                # iteration where the drain picks up
                                # the inject; the soft-abort flag is
                                # also cleared so the next genuine
                                # abort isn't suppressed.
                                if self._soft_aborts.pop(
                                    rtxclaw_sid, False,
                                ):
                                    break
                                self._cancelled[rtxclaw_sid] = True
                                break
                            elif kind == "error":
                                round_error = str(
                                    ev.get("message") or "worker error",
                                )
                                round_error_class = (
                                    self._classify_upstream_error(round_error)
                                )
                                # ``UpstreamError`` hook — lets an ECC
                                # plugin override the classification
                                # (e.g. recognise a model-specific
                                # error string as ``upstream context-
                                # length overflow`` so the engine
                                # fires reactive-compact instead of
                                # giving up). Two control paths:
                                #   * ``hookSpecificOutput.classification``
                                #     rewrites the tag fed to
                                #     ``_reactive_compact_on_overflow``
                                #     AND to the surfaced TurnError
                                #     (so a plugin's classification
                                #     actually STEERS the routing,
                                #     not just the user-facing label).
                                #   * ``decision: block`` with no
                                #     replacement → suppress the
                                #     reactive-compact retry; surface
                                #     the error as-is (operator
                                #     wants a hard stop).
                                if hook_engine is not None:
                                    ue = await self._fire_hook(
                                        hook_engine, hook_ctx,
                                        "UpstreamError",
                                        {
                                            "message": round_error,
                                            "classification": round_error_class,
                                            "round_idx": round_idx,
                                        },
                                    )
                                    for r in (ue.results or []):
                                        j = getattr(r, "json_output", None)
                                        if not isinstance(j, dict):
                                            continue
                                        hso = j.get("hookSpecificOutput")
                                        if not isinstance(hso, dict):
                                            continue
                                        cls = hso.get("classification")
                                        if isinstance(cls, str) and cls.strip():
                                            round_error_class = cls.strip()
                                            break
                                    # If the hook BLOCKED (decision:
                                    # block) without supplying a
                                    # classification override, rewrite
                                    # to a tag that won't trigger
                                    # reactive-compact, so the engine
                                    # surfaces the error verbatim.
                                    if (
                                        ue.blocked
                                        and round_error_class
                                        in ("context_length",
                                            "upstream context-length overflow")
                                    ):
                                        round_error_class = (
                                            "upstream error (hook-suppressed)"
                                        )
                                break
                            elif kind == "done":
                                had_done = True
                                break
                    except asyncio.CancelledError:
                        try:
                            turn_state.stop()
                        except Exception:  # noqa: BLE001
                            pass
                        self._cancelled[rtxclaw_sid] = True
                    finally:
                        # Reap this round's worker before the next one.
                        # On the ABORT path we must return fast — SIGTERM
                        # now and hand the reap to a background task
                        # (the inline 2 s wait is happy-path only).
                        if self._cancelled.get(rtxclaw_sid):
                            if proc is not None and proc.returncode is None:
                                try:
                                    proc.terminate()
                                except Exception:  # noqa: BLE001
                                    pass
                            if proc is not None or stderr_task is not None:
                                self._schedule_background_reap(
                                    proc, stderr_task,
                                )
                        else:
                            if (
                                stderr_task is not None
                                and not stderr_task.done()
                            ):
                                stderr_task.cancel()
                                try:
                                    await stderr_task
                                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                                    pass
                            if proc is not None:
                                try:
                                    if proc.returncode is None:
                                        proc.terminate()
                                    await asyncio.wait_for(
                                        proc.wait(), timeout=2.0,
                                    )
                                except asyncio.TimeoutError:
                                    # SIGTERM didn't take — escalate to
                                    # SIGKILL and hand off to the
                                    # background reaper so the round
                                    # doesn't leak a zombie worker.
                                    try:
                                        proc.kill()
                                    except (ProcessLookupError, OSError):
                                        pass
                                    self._schedule_background_reap(proc, None)
                                except ProcessLookupError:
                                    pass
                                except Exception:  # noqa: BLE001
                                    pass
                        self._active_turns.pop(turn_id, None)
                        # Clear soft-abort regardless of how the round
                        # ended. Without this, a SIGTERM that exits
                        # the worker via EOF (no terminal ``aborted``
                        # event) leaves the flag set, and a later
                        # genuine operator abort gets silently
                        # downgraded to a soft pivot.
                        self._soft_aborts.pop(rtxclaw_sid, None)

                    # Roll round buffers into the turn aggregates.
                    thinking_buf.extend(rs.thinking_buf)
                    content_buf.extend(rs.content_buf)
                    if rs.metrics:
                        last_metrics = rs.metrics
                        self._record_round_metrics(
                            session, round_idx, rs.metrics,
                            str(rs.metrics.get("endpoint") or ""),
                        )

                    if self._cancelled.get(rtxclaw_sid):
                        terminal_state = "aborted"
                        break

                    if round_error is not None:
                        # Reactive squeeze + retry on a context-overflow.
                        # Threads the hook-overridable
                        # ``round_error_class`` (set by the
                        # UpstreamError hook above) so a plugin's
                        # classification rewrite actually steers the
                        # routing decision — not just the user-facing
                        # error label.
                        new_messages, retried = (
                            await self._reactive_compact_on_overflow(
                                session, messages, round_error,
                                classification=round_error_class,
                            )
                        )
                        if retried:
                            messages = new_messages
                            round_idx += 1
                            continue
                        yield TurnError(
                            message=round_error,
                            classification=round_error_class,
                        )
                        terminal_state = "error"
                        break

                    # Post-stream token-ratio loop check.
                    if not rs.loop_detected:
                        ratio_hit = self._check_ratio_loop(rs.metrics or {})
                        if ratio_hit is not None:
                            rs.loop_detected = True
                            rs.loop_tier, rs.loop_evidence = ratio_hit

                    # --- tool calls → dispatch, then another round ------
                    if rs.pending_tool_calls and not rs.loop_detected:
                        # OpenAI-compatible chat APIs require an
                        # ``assistant`` message carrying THIS round's
                        # ``tool_calls`` immediately before the matching
                        # ``role=tool`` result messages — without it the
                        # next worker round 400s on the upstream. Append
                        # the assistant message first, normalised, then
                        # dispatch (which appends the tool results).
                        from rtxclaw_agent.acp_bridge import (
                            _build_assistant_round_msg,
                        )
                        norm_calls = [
                            self._normalize_call(c)
                            for c in rs.pending_tool_calls
                        ]
                        messages.append(_build_assistant_round_msg(
                            content="".join(rs.content_buf),
                            thinking="".join(rs.thinking_buf),
                            tool_calls=norm_calls,
                        ))
                        round_record: dict[str, Any] = {
                            "round_idx": round_idx, "calls": [],
                        }
                        async for ev in self._dispatch_tool_calls(
                            norm_calls, session, messages,
                            turn_state, round_record, promoted,
                            hook_engine=hook_engine, hook_ctx=hook_ctx,
                        ):
                            if isinstance(ev, ToolCallStarted):
                                if not ev.is_outer:
                                    engine_tool_calls.append({
                                        "id": ev.call_id, "name": ev.name,
                                        "arguments": ev.arguments,
                                    })
                            elif isinstance(ev, ToolCallResult):
                                engine_tool_results.append({
                                    "id": ev.call_id, "ok": ev.ok,
                                    "content_size": len(ev.content or ""),
                                })
                            yield ev
                        # Tool-using round → bump the budget the
                        # continuation-nudge policy keys on (see
                        # ``_should_nudge``).
                        tool_rounds_so_far += 1
                        # Signal the round boundary so the Agent can
                        # checkpoint the in-progress turn to disk and
                        # any mid-turn user-message injects queued
                        # during this round get drained at the top of
                        # the next iteration.
                        yield RoundComplete(round_idx=round_idx)
                        round_idx += 1
                        continue

                    # --- loop detected → distill / force-terminate ------
                    if rs.loop_detected:
                        loop_hit = (
                            rs.loop_tier or "loop", rs.loop_evidence or "",
                        )
                        # ``ReasoningLoopDetected`` hook fires BEFORE
                        # the hardcoded distill→force-terminate cascade
                        # so an ECC plugin can:
                        #   * ``decision: block`` (exit 2) → treat the
                        #     detection as a false positive; suppress
                        #     the recovery and keep the round going.
                        #   * ``continue: false`` → end the turn now
                        #     (operator wants hard stop, not recovery).
                        #   * ``additionalContext`` → inject a custom
                        #     preamble into the message tail BEFORE the
                        #     normal cascade fires (e.g. "you were
                        #     looping; here are the constraints…").
                        # No-op / no hook → fall through to the canned
                        # distill→force-terminate flow exactly as before.
                        loop_hook = await self._fire_hook(
                            hook_engine, hook_ctx,
                            "ReasoningLoopDetected",
                            {
                                "tier": loop_hit[0],
                                "evidence": loop_hit[1],
                                "round_idx": round_idx,
                                "thinking_chars": sum(
                                    len(p) for p in rs.thinking_buf
                                ),
                                "content_chars": sum(
                                    len(p) for p in rs.content_buf
                                ),
                                "distill_recoveries": distill_recoveries,
                            },
                        )
                        for sm in loop_hook.system_messages:
                            yield TextDelta(
                                text=f"[hook] {sm}\n", channel="content",
                            )
                        if not loop_hook.should_continue:
                            # Hook asked to stop the turn entirely.
                            terminal_state = "ok" if content_buf else "error"
                            if loop_hook.stop_reason:
                                yield TextDelta(
                                    text=(
                                        "\n[ReasoningLoopDetected hook] "
                                        f"{loop_hook.stop_reason}\n"
                                    ),
                                    channel="content",
                                )
                            break
                        if loop_hook.blocked:
                            # False-positive suppression: clear the
                            # round's loop flags, optionally inject the
                            # hook's reason as a user message so the
                            # model sees the operator's correction,
                            # and continue to the natural-completion
                            # path below as if no loop had fired.
                            rs.loop_detected = False
                            rs.loop_tier = ""
                            rs.loop_evidence = ""
                            if loop_hook.block_reason:
                                messages.append({
                                    "role": "user",
                                    "content": (
                                        "[ReasoningLoopDetected hook — "
                                        "false-positive override] "
                                        + loop_hook.block_reason
                                    ),
                                })
                                yield TextDelta(
                                    text=_format_runtime_warning(
                                        "loop-suppressed",
                                        reason=loop_hook.block_reason,
                                    ),
                                    channel="content",
                                )
                                await self._notify(
                                    hook_engine, hook_ctx,
                                    "loop-suppressed",
                                    loop_hook.block_reason,
                                    tier=loop_hit[0],
                                )
                                round_idx += 1
                                continue
                            # No reason supplied — just resume the
                            # round (no extra user message); fall
                            # through past the cascade.
                        else:
                            if loop_hook.additional_context:
                                messages.append({
                                    "role": "user",
                                    "content": loop_hook.additional_context,
                                })
                            # Surface the detection so the TUI /
                            # Telegram / one-shot frontends render an
                            # inline warning instead of looking like
                            # the turn died.
                            yield TextDelta(
                                text=_format_runtime_warning(
                                    "loop-detected",
                                    tier=loop_hit[0],
                                    evidence=loop_hit[1],
                                ),
                                channel="content",
                            )
                            await self._notify(
                                hook_engine, hook_ctx,
                                "loop-detected",
                                f"reasoning loop ({loop_hit[0]})",
                                tier=loop_hit[0],
                                evidence=loop_hit[1],
                                round_idx=round_idx,
                            )
                            cap = int(
                                getattr(
                                    self.cfg, "distill_max_recoveries", 3,
                                ) or 3
                            )
                            if distill_recoveries < cap:
                                messages, recovered = (
                                    await self._distill_recovery(
                                        session, messages, loop_hit, rs,
                                        distill_recoveries,
                                        hook_engine=hook_engine,
                                        hook_ctx=hook_ctx,
                                    )
                                )
                                if recovered:
                                    yield TextDelta(
                                        text=_format_runtime_warning(
                                            "loop-distill",
                                            attempt=distill_recoveries + 1,
                                        ),
                                        channel="content",
                                    )
                                    await self._notify(
                                        hook_engine, hook_ctx,
                                        "loop-distill",
                                        "distill recovery fired",
                                        attempt=distill_recoveries + 1,
                                        tier=loop_hit[0],
                                    )
                                    distill_recoveries += 1
                                    round_idx += 1
                                    continue
                            if not force_terminate_attempted:
                                messages, fired = await self._force_terminate(
                                    messages,
                                    hook_engine=hook_engine,
                                    hook_ctx=hook_ctx,
                                    tier=loop_hit[0],
                                    round_idx=round_idx,
                                )
                                force_terminate_attempted = True
                                if fired:
                                    yield TextDelta(
                                        text=_format_runtime_warning(
                                            "loop-force-terminate",
                                        ),
                                        channel="content",
                                    )
                                    await self._notify(
                                        hook_engine, hook_ctx,
                                        "loop-force-terminate",
                                        "force-terminate fired",
                                        tier=loop_hit[0],
                                    )
                                    round_idx += 1
                                    continue
                            # Cascade exhausted (distill capped AND
                            # force-terminate already fired). Pending
                            # inject overrides every non-cancel terminal
                            # exit so the operator's steering message
                            # still lands on the next round.
                            if self._pending_user_messages.get(rtxclaw_sid):
                                round_idx += 1
                                continue
                            terminal_state = (
                                "ok" if content_buf else "error"
                            )
                            break
                        # Loop suppressed by a blocking hook with no
                        # reason supplied — fall through to the
                        # premature-end / natural-completion branches
                        # exactly as if no loop had fired.

                    # --- premature turn end → continuation nudge --------
                    # Three variants — silent EOS after a tool chain,
                    # mid-syntax cutoff (open backticks / fence), and
                    # colon cliffhanger (content ends on ``:`` with no
                    # tool calls). All gated by ``_should_nudge``: must
                    # have had at least one prior tool round, not be
                    # cancelled, and stay under ``MAX_NUDGES_PER_TURN``.
                    if had_done:
                        round_content = "".join(rs.content_buf)
                        final_text = round_content.strip()
                        cutoff_tail = _detect_content_cutoff(round_content)
                        colon_tail = (
                            _detect_colon_cliffhanger(round_content)
                            if not rs.pending_tool_calls else None
                        )
                        # Pick the right variant + tail. Silent wins
                        # when the round was entirely empty; cutoff
                        # wins over colon (a mid-fence content also
                        # ending in ``:`` is the unclosed-syntax
                        # problem, not the cliffhanger).
                        nudge_kind: Optional[str] = None
                        nudge_tail: Optional[str] = None
                        if not round_content and not rs.thinking_buf:
                            nudge_kind = "silent"
                        elif cutoff_tail is not None:
                            nudge_kind = "cutoff"
                            nudge_tail = cutoff_tail
                        elif colon_tail is not None:
                            nudge_kind = "colon"
                            nudge_tail = colon_tail
                        elif len(final_text) < NUDGE_MIN_TEXT_CHARS:
                            # Tool chain ended with a near-empty
                            # natural-language summary — the operator
                            # sees a blank reply. Treat as silent.
                            nudge_kind = "silent"

                        # ``PrematureTurnEndGate`` hook (rtxclaw
                        # extension) — fires BEFORE the heuristic
                        # gate (``_should_nudge`` and the hardcoded
                        # ``MAX_NUDGES_PER_TURN`` / ``NUDGE_MIN_TEXT_CHARS``
                        # constants). Lets a plugin add nudge kinds
                        # the hardcoded detectors don't recognise
                        # (e.g. trailing-comma, fenced-quote) or
                        # enable nudges that the hardcoded gate would
                        # suppress (e.g. nudge when
                        # ``tool_rounds_so_far == 0`` for a chat-only
                        # model). Hook return semantics:
                        #   * ``hookSpecificOutput.kind`` /
                        #     ``hookSpecificOutput.tail`` → override
                        #     the variant + tail.
                        #   * ``continue: false`` → suppress nudge
                        #     entirely (end the turn).
                        #   * ``decision: block`` + ``reason: <body>``
                        #     → enable a nudge with the hook's body,
                        #     overriding the hardcoded gate (used to
                        #     force a nudge when ``_should_nudge``
                        #     would have returned False).
                        gate_override_body: Optional[str] = None
                        gate_force_fire = False
                        gate_force_suppress = False
                        if hook_engine is not None:
                            gate_hook = await self._fire_hook(
                                hook_engine, hook_ctx,
                                "PrematureTurnEndGate",
                                {
                                    "kind": nudge_kind or "",
                                    "tail": nudge_tail or "",
                                    "final_text_chars": len(final_text),
                                    "tool_rounds_so_far": tool_rounds_so_far,
                                    "nudge_count": len(nudge_log),
                                    "round_idx": round_idx,
                                },
                            )
                            for sm in gate_hook.system_messages:
                                yield TextDelta(
                                    text=f"[hook] {sm}\n",
                                    channel="content",
                                )
                            # Honor hookSpecificOutput.kind / tail.
                            for r in reversed(gate_hook.results):
                                j = getattr(r, "json_output", None)
                                if not isinstance(j, dict):
                                    continue
                                hso = j.get("hookSpecificOutput")
                                if not isinstance(hso, dict):
                                    continue
                                k = hso.get("kind")
                                if isinstance(k, str) and k.strip():
                                    nudge_kind = k.strip()
                                t = hso.get("tail")
                                if isinstance(t, str):
                                    nudge_tail = t
                                break
                            if not gate_hook.should_continue:
                                gate_force_suppress = True
                            elif (
                                gate_hook.blocked
                                and gate_hook.block_reason
                            ):
                                gate_force_fire = True
                                gate_override_body = gate_hook.block_reason

                        if (
                            nudge_kind is not None and not gate_force_suppress
                        ) or gate_force_fire:
                            silent_chain = bool(
                                nudge_log
                                and nudge_log[-1].get("kind") == nudge_kind
                            )
                            # Per-session overrides via cfg (round 4):
                            # ``cfg.max_nudges_per_turn`` raises/lowers
                            # the budget without editing the module
                            # constants. ``cfg.nudge_min_text_chars``
                            # adjusts the "near-empty" threshold.
                            _nudge_cap = int(
                                getattr(
                                    self.cfg, "max_nudges_per_turn",
                                    MAX_NUDGES_PER_TURN,
                                ) or MAX_NUDGES_PER_TURN
                            )
                            _nudge_floor = int(
                                getattr(
                                    self.cfg, "nudge_min_text_chars",
                                    NUDGE_MIN_TEXT_CHARS,
                                ) or NUDGE_MIN_TEXT_CHARS
                            )
                            # The hardcoded gate. The PrematureTurnEndGate
                            # hook can FORCE override this via
                            # ``gate_force_fire`` (e.g. plugin wants to
                            # nudge even though _should_nudge said no).
                            should_fire = (
                                True if gate_force_fire
                                else (
                                    _should_nudge(
                                        final_text_chars=len(final_text),
                                        tool_rounds_so_far=tool_rounds_so_far,
                                        nudge_count=len(nudge_log),
                                        cancelled=self._cancelled.get(
                                            rtxclaw_sid, False,
                                        ),
                                        terminate_reason="end_turn",
                                        silent_chain=silent_chain,
                                        max_nudges=_nudge_cap,
                                        min_text_chars=_nudge_floor,
                                    ) if nudge_kind == "silent" else (
                                        # Cutoff / colon variants are
                                        # stricter: always fire if we
                                        # still have budget, regardless
                                        # of final_text length (the
                                        # content was non-empty by
                                        # definition).
                                        len(nudge_log) < _nudge_cap
                                        and not self._cancelled.get(
                                            rtxclaw_sid, False,
                                        )
                                    )
                                )
                            )
                            # ``PrematureTurnEnd`` hook fires BEFORE
                            # the canned nudge body so an ECC plugin
                            # can:
                            #   * ``continue: false`` → skip nudging
                            #     and end the turn (operator considers
                            #     the round complete enough).
                            #   * ``decision: block`` + ``reason: …`` →
                            #     substitute the hook's body for the
                            #     canned ``NUDGE_PROMPT_BODY`` /
                            #     ``CUTOFF_NUDGE_PROMPT_BODY`` /
                            #     ``COLON_CLIFFHANGER_NUDGE_PROMPT_BODY``.
                            # No-op / no hook → default canned body.
                            premature_hook = await self._fire_hook(
                                hook_engine, hook_ctx,
                                "PrematureTurnEnd",
                                {
                                    "kind": nudge_kind,
                                    "tail": nudge_tail or "",
                                    "tool_rounds_so_far": tool_rounds_so_far,
                                    "nudge_count": len(nudge_log),
                                    "final_text_chars": len(final_text),
                                    "should_fire_default": should_fire,
                                    "round_idx": round_idx,
                                },
                            )
                            for sm in premature_hook.system_messages:
                                yield TextDelta(
                                    text=f"[hook] {sm}\n",
                                    channel="content",
                                )
                            # The Gate hook's override body (if any)
                            # is the default; PrematureTurnEnd may
                            # rewrite it again below.
                            override_body: Optional[str] = gate_override_body
                            if not premature_hook.should_continue:
                                # Hook asked to stop. Treat as a clean
                                # turn end without nudging.
                                should_fire = False
                            elif (
                                premature_hook.blocked
                                and premature_hook.block_reason
                            ):
                                # Hook supplied a substitute nudge body.
                                override_body = premature_hook.block_reason
                                should_fire = True
                            if should_fire:
                                messages, fired = await self._continuation_nudge(
                                    messages, nudge_log,
                                    kind=nudge_kind, tail=nudge_tail,
                                    body_override=override_body,
                                )
                                if fired:
                                    yield TextDelta(
                                        text=_format_runtime_warning(
                                            "nudge", kind=nudge_kind,
                                        ),
                                        channel="content",
                                    )
                                    await self._notify(
                                        hook_engine, hook_ctx,
                                        "nudge",
                                        f"continuation nudge ({nudge_kind})",
                                        nudge_kind=nudge_kind,
                                        overridden=override_body is not None,
                                    )
                                    round_idx += 1
                                    continue
                        if self._pending_user_messages.get(rtxclaw_sid):
                            round_idx += 1
                            continue
                        # Fall through if neither premature-end variant
                        # nor inject pivot applied — handled below by
                        # the natural-completion path.

                    # --- mid-turn inject pivot --------------------------
                    # The model wants to terminate (no more tool calls)
                    # but a steering user prompt has arrived in the
                    # inject buffer since the round started. Spin up
                    # another round so the drain at the top of the
                    # next iteration picks it up and the assistant
                    # responds to the new instruction — instead of
                    # ending the turn and forcing the operator to
                    # start a fresh one. Without this guard a late
                    # inject (between the last tool result and
                    # finish_reason=stop) silently sits in the buffer
                    # until the next ``run_turn`` invocation.
                    if (
                        had_done
                        and self._pending_user_messages.get(rtxclaw_sid)
                    ):
                        round_idx += 1
                        continue

                    # --- natural completion -----------------------------
                    if had_done:
                        terminal_state = "ok"
                        break

                    # Soft-aborted by ``inject_user_message`` — the
                    # worker was SIGTERM'd mid-stream so the model
                    # would stop wasting compute on the now-stale
                    # plan. ``had_done`` is False because no proper
                    # ``done`` event reached us before EOF. Treat as
                    # "round ended, drain inject, pivot" rather than
                    # surfacing a worker_eof error.
                    if self._pending_user_messages.get(rtxclaw_sid):
                        round_idx += 1
                        continue

                    yield TurnError(
                        message="worker exited without a `done` event",
                        classification="worker_eof",
                    )
                    terminal_state = "error"
                    break
                else:
                    # Round cap hit — treat as a (degraded) completion.
                    # Don't pivot on round-cap: the cap exists to bound
                    # runaway loops; honouring an inject here would
                    # let a chained inject keep extending the turn
                    # past its safety budget. Operator must start a
                    # fresh turn instead.
                    terminal_state = "ok" if content_buf else "error"

                # --- Stop hooks (Claude Code) — with continuation -------
                if (
                    terminal_state != "ok"
                    or hook_engine is None
                    or self._cancelled.get(rtxclaw_sid)
                ):
                    break
                # Cap is overridable per-session — ``cfg.max_stop_continuations``
                # lets the operator extend or tighten the loop without
                # editing the module-level constant.
                _stop_cap = int(
                    getattr(
                        self.cfg, "max_stop_continuations", _MAX_STOP_CONTINUATIONS,
                    ) or _MAX_STOP_CONTINUATIONS
                )
                if stop_continuations >= _stop_cap:
                    # ``StopFailure`` (Claude Code spec) — fires when
                    # the Stop hook's continuation budget is exhausted.
                    # Lets an ECC plugin escalate (notify the
                    # operator, write a recovery scratchpad, raise an
                    # incident) — observational, never blocks the
                    # turn-end.
                    await self._fire_hook(
                        hook_engine, hook_ctx, "StopFailure",
                        {
                            "reason": "stop_continuation_cap",
                            "continuations": stop_continuations,
                            "max_continuations": _stop_cap,
                        },
                    )
                    break
                stop = await self._fire_hook(
                    hook_engine, hook_ctx, "Stop",
                    {"stop_hook_active": stop_continuations > 0},
                )
                for sm in stop.system_messages:
                    yield TextDelta(
                        text=f"[hook] {sm}\n", channel="content",
                    )
                if stop.additional_context:
                    yield TextDelta(
                        text=stop.additional_context + "\n",
                        channel="content",
                    )
                if not stop.blocked:
                    break
                # A Stop hook asked the agent to keep going — append the
                # reason as a fresh user turn and re-enter the round loop.
                stop_continuations += 1
                messages.append({
                    "role": "user",
                    "content": (
                        "[Stop hook] "
                        + (stop.block_reason or "continue working")
                    ),
                })
                yield TextDelta(
                    text=(
                        "\n[Stop hook requested continuation] "
                        f"{stop.block_reason}\n"
                    ),
                    channel="content",
                )
        finally:
            self._active_turns.pop(turn_id, None)
            self._session_to_turn.pop(rtxclaw_sid, None)

        ended_at_iso = _now_iso()

        # Stash structured engine audit on request.extra so the Agent
        # layer can write the canonical session_log record (codex
        # audit round-3 #6 — Agent owns recording).
        request.extra["_engine_audit"] = {
            "thinking": "".join(thinking_buf),
            "content": "".join(content_buf),
            "tool_calls": engine_tool_calls,
            "tool_results": engine_tool_results,
            "metrics": last_metrics,
            "started_at": started_at_iso,
            "ended_at": ended_at_iso,
            "state": terminal_state,
        }

        yield TurnDone(
            state=terminal_state,
            metrics=last_metrics if terminal_state == "ok" else {},
        )

    async def _notify(
        self,
        hook_engine: Any,
        hook_ctx: Optional[dict[str, Any]],
        kind: str,
        message: str,
        **extra: Any,
    ) -> None:
        """Fire Claude Code's ``Notification`` hook for a runtime event.

        Used at every operator-visible runtime warning surface — loop
        detected, distill recovery, force-terminate, continuation
        nudge — so an ECC plugin can route the event to a webhook /
        desktop notifier / telemetry sink. The hook's effects on
        return value are intentionally IGNORED here: Notification is
        observational, not gating. Never raises.
        """
        if hook_engine is None or not hook_engine.has_event("Notification"):
            return
        payload: dict[str, Any] = {
            "kind": kind,
            "message": message,
        }
        for k, v in (extra or {}).items():
            if v is not None and v != "":
                payload[k] = v
        try:
            await hook_engine.run(
                "Notification", payload, **(hook_ctx or {}),
            )
        except Exception:  # noqa: BLE001
            # Notification firing must never affect the turn — swallow
            # everything, including a misbehaving plugin's exception.
            pass

    async def _fire_hook(
        self,
        hook_engine: Any,
        hook_ctx: dict[str, Any],
        event: str,
        payload: dict[str, Any],
    ) -> Any:
        """Run one Claude Code hook event; never raises.

        Returns an empty-effect :class:`~rtxclaw_core.hooks.HookOutcome`
        when the engine has no matching hooks or errors — callers treat
        "no hooks" and "hooks ran, no effect" identically.
        """
        from rtxclaw_core.hooks import HookOutcome
        if hook_engine is None or not hook_engine.has_event(event):
            return HookOutcome(event=event)
        try:
            return await hook_engine.run(event, payload, **hook_ctx)
        except Exception as exc:  # noqa: BLE001
            self._log_event("HOOK_ERROR", event=event, error=str(exc))
            return HookOutcome(event=event)

    # -----------------------------------------------------------------
    # Phase 3a helpers — simple worker spawn + message build.
    # -----------------------------------------------------------------

    def _build_messages_simple(
        self,
        session: Any,
        user_content: "str | list[dict[str, Any]]",
        system_prompt: Optional[str],
        preamble: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Build the per-round message list for the upstream worker.

        * Per-turn ``[Turn N]\\n`` marker so the cache prefix stays
          byte-stable across replays (vLLM APC / SGLang RadixAttention
          reuse KV across requests only when the block-aligned prefix
          matches).
        * LIVE turn gets ``[Turn N · YYYY-MM-DD HH:MM:SS TZ (Weekday)]\\n``
          so the model has a reliable wall-clock anchor.
        * Aborted / in-progress prior turns get one-line stubs rather
          than full replay — replaying tens of thousands of tokens of
          cancelled tool work would tax every subsequent turn's TTFT.
        """
        import datetime as _dt
        msgs: list[dict[str, Any]] = []
        sys_text = system_prompt or session.system_prompt
        if sys_text:
            msgs.append({"role": "system", "content": sys_text})
        for block in preamble:
            msgs.append(dict(block))

        prior_turns = list(session.turns or [])

        def _marker(idx: int) -> str:
            return f"[Turn {idx}]\n"

        def _live_marker(idx: int) -> str:
            now = _dt.datetime.now().astimezone()
            ts = now.strftime("%Y-%m-%d %H:%M:%S %z")
            day = now.strftime("%A")
            return f"[Turn {idx} · {ts} ({day})]\n"

        for turn_idx, t in enumerate(prior_turns):
            u = t.get("user")
            if t.get("aborted"):
                if u:
                    msgs.append({"role": "user",
                                 "content": _marker(turn_idx) + str(u)})
                    msgs.append({"role": "assistant",
                                 "content": f"[Turn {turn_idx} aborted by user]"})
                continue
            if t.get("in_progress"):
                if u:
                    msgs.append({"role": "user",
                                 "content": _marker(turn_idx) + str(u)})
                    msgs.append({"role": "assistant",
                                 "content": f"[Turn {turn_idx} interrupted before completing — treat as unanswered]"})
                continue
            if u:
                msgs.append({"role": "user",
                             "content": _marker(turn_idx) + str(u)})
            c = t.get("content")
            if c:
                msgs.append({"role": "assistant", "content": str(c)})

        # LIVE turn — index = number of prior turns. The wall-clock
        # marker is intentionally appended only to the live message
        # so the prefix stays byte-stable for prior turns.
        live_idx = len(prior_turns)
        if isinstance(user_content, str):
            msgs.append({"role": "user",
                         "content": _live_marker(live_idx) + user_content})
        else:
            # Multi-part content — prepend a text-marker block so the
            # marker still rides at the head of the user message
            # without breaking the multi-part shape.
            parts: list[dict[str, Any]] = [
                {"type": "text", "text": _live_marker(live_idx)},
            ]
            parts.extend(list(user_content))
            msgs.append({"role": "user", "content": parts})
        return msgs

    async def _spawn_worker(
        self,
        *,
        session: Any,
        messages: list[dict[str, Any]],
        turn_id: str,
        env: Optional[dict[str, str]] = None,
    ) -> tuple[Any, AsyncIterator[dict[str, Any]]]:
        """Spawn a worker subprocess and return ``(TurnState,
        event_stream)``.

        Reuses the legacy ``_default_spawn_worker`` helper from
        ``rtxclaw_agent.acp_bridge`` by providing a minimal
        backend-shim that exposes ``cfg`` and ``_session_for``. The
        legacy code path is unchanged; we just call into it.
        """
        # Test-seam: caller-injected spawner wins.
        if self._worker_spawner is not None:
            return await self._worker_spawner(
                self, session, messages, turn_id, env,
            )

        from rtxclaw_agent.acp_bridge import _default_spawn_worker
        from rtxclaw_core.tools.registry import BUILTIN_TOOLS, ToolRegistry

        # The legacy spawner expects a CoreBackend-shaped object with
        # ``cfg`` and ``_session_for``. Build a one-off shim that ALSO
        # exposes ``_promoted_tools`` defensively in case the legacy
        # helper consults it.
        engine = self
        class _Shim:
            def __init__(self, cfg, sess):
                self.cfg = cfg
                self._sess = sess
                self._promoted_tools = engine._promoted_tools
            def _session_for(self, sid: str):
                return self._sess if sid == self._sess.hash else None

        # Cost-saving filter: only the core tools + names the model
        # explicitly promoted via ``ToolSearch(query="select:...")``
        # ship in the tools[] payload. Without this, every round
        # carries ~30 KB of deferred tool schemas the small model
        # almost never invokes — defeating the deferred-tools
        # design and bloating the prompt cache prefix.
        sid = session.hash
        promoted = self._promoted_tools.get(sid, set())
        registry = ToolRegistry(BUILTIN_TOOLS)
        allowed = {t.name for t in registry.core_tools()} | set(promoted)

        shim = _Shim(self.cfg, session)
        turn_state, event_stream = await _default_spawn_worker(
            shim,                              # backend
            sid,                               # session_id
            [],                                # prompt_blocks (unused; messages passed)
            turn_id,                           # turn_id
            messages,                          # explicit message list
            allowed_tool_names=allowed,
        )
        return turn_state, event_stream

    # -----------------------------------------------------------------
    # Message-list construction
    # -----------------------------------------------------------------

    def _apply_round_preamble(
        self,
        messages: list[dict[str, Any]],
        preamble: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Idempotently splice the Agent-composed preamble blocks.

        Reference: acp_bridge.py L1912–1947 (today's
        ``_apply_persistent_injections``). The semantic is preserved
        exactly: each block REPLACES any prior occurrence (matched by
        a stable marker comment at the top of the block), so calling
        every round keeps the prefix byte-stable. Order in the message
        list:

            system → pinned → rolling_summary → todos → skill_preamble
            → memory_recall → live tail

        The composition step (deciding WHAT goes into each block)
        lives on :class:`Agent` (see :meth:`Agent.compose_round_preamble`).
        The engine just splices what it's given — single composition
        owner per codex audit finding #5.
        """
        if not preamble:
            return messages

        # Markers used by the preamble injection helpers — each block
        # carries a unique sentinel near the top so re-splicing is
        # idempotent (replaces in-place, doesn't duplicate). Marker
        # strings MUST match the actual prefix each producer emits;
        # mismatched markers let the previous block survive into
        # round_idx > 0 and the preamble duplicates:
        # * ``turn_runtime._inject_pinned_facts`` writes
        #   ``[PINNED FACTS — survive every compaction; …]``
        # * ``turn_runtime._inject_compaction_summary`` writes
        #   ``[ROLLING COMPACTION SUMMARY — …]``
        # * ``turn_runtime._inject_current_todos`` writes
        #   ``[CURRENT TODO LIST]`` (or a richer status header)
        # * ``skill_index.render_preamble`` writes
        #   ``[Auto-invoked skill: …]``
        # * ``memory_manager.MemoryManager.prefetch_and_format`` writes
        #   ``[RECALLED CONTEXT — from <provider>]``
        MARKERS = (
            "[PINNED FACTS",
            "[ROLLING COMPACTION SUMMARY",
            "[CURRENT TODO LIST",
            "[Auto-invoked skill",
            "[RECALLED CONTEXT",
        )

        def _marker_for(block: dict[str, Any]) -> Optional[str]:
            content = str(block.get("content") or "")
            for m in MARKERS:
                if m in content[:80]:
                    return m
            return None

        # Find the system message (index 0 by convention). The
        # preamble sits *after* system, *before* the live transcript.
        out: list[dict[str, Any]] = []
        sys_idx = -1
        for i, m in enumerate(messages):
            if isinstance(m, dict) and m.get("role") == "system":
                sys_idx = i
                break

        # Strip any existing preamble blocks (matched by marker)
        # so the new ones land at their canonical position.
        existing = list(messages)
        head = existing[: sys_idx + 1] if sys_idx >= 0 else []
        tail = existing[sys_idx + 1 :] if sys_idx >= 0 else existing
        cleaned_tail = [
            m for m in tail
            if not (isinstance(m, dict) and _marker_for(m))
        ]
        out.extend(head)
        for block in preamble:
            out.append(dict(block))
        out.extend(cleaned_tail)
        return out

    # -----------------------------------------------------------------
    # Compaction
    # -----------------------------------------------------------------

    def _maybe_compact(
        self,
        session: Any,
        messages: list[dict[str, Any]],
        *,
        force: bool = False,
    ) -> list[dict[str, Any]]:
        """Proactive compaction trigger.

        Reference: acp_bridge.py L1949+ and turn_runtime.compact_messages
        (L1071). When estimated ``prompt_tokens + max_tokens >=
        compact_at_frac × upstream_max_context``, squeeze old tool
        results in place and persist the rolling summary onto the
        session. ``force=True`` from the ``compact_context`` tool
        intercept (acp_bridge.py L2223–2250) bypasses the threshold.

        Also handles the memory-flush hook: when the upcoming
        compaction would cross the reserve threshold
        (``cfg.memory_flush_reserve_tokens_floor`` +
        ``cfg.memory_flush_soft_threshold_tokens``), pause and run a
        silent agentic turn that lets the model save context to
        MEMORY.md before squeezing. See cfg.memory_flush_* defaults
        and the existing flow inside acp_bridge.
        """
        try:
            from rtxclaw_core.turn_runtime import (
                _approx_tokens,
                compact_messages,
                compact_session_data_in_place,
            )
        except ImportError:
            return messages

        ctx_window = int(getattr(self.cfg, "upstream_max_context", 0) or 0)
        if ctx_window <= 0:
            return messages

        if not force:
            # Threshold gate — same math as the legacy proactive
            # squeeze. Compute approx tokens of the working set and
            # compare against ``compact_at_frac × ctx_window``.
            try:
                est = _approx_tokens(messages)
            except Exception:  # noqa: BLE001
                return messages
            max_tokens = int(getattr(self.cfg, "upstream_max_completion_tokens", 4096) or 4096)
            frac = float(
                getattr(self.cfg, "compact_at_frac", DEFAULT_COMPACT_AT_FRAC)
                or DEFAULT_COMPACT_AT_FRAC
            )
            threshold = int(ctx_window * frac)
            if est + max_tokens < threshold:
                return messages

        try:
            squeezed, summary = compact_messages(messages, ctx_window=ctx_window)
        except Exception:  # noqa: BLE001
            return messages
        try:
            compact_session_data_in_place(session, summary)
        except Exception:  # noqa: BLE001
            pass
        self._log_event(
            "COMPACTION_DONE",
            session_id=getattr(session, "hash", ""),
            forced=force,
            kept_msgs=len(squeezed),
            removed=max(0, len(messages) - len(squeezed)),
        )
        return squeezed

    async def _reactive_compact_on_overflow(
        self,
        session: Any,
        messages: list[dict[str, Any]],
        upstream_error: str,
        *,
        classification: str = "",
    ) -> tuple[list[dict[str, Any]], bool]:
        """Reactive squeeze after a context-overflow 400.

        Triggered when the error classifies as a context-length
        overflow. The caller passes the already-resolved
        ``classification`` string (which may have been rewritten by
        an ``UpstreamError`` hook — see :meth:`run_turn`), so a
        plugin can:

        * Promote a normally-unrecognised model-specific overflow
          string to ``"upstream context-length overflow"`` (or the
          equivalent hook-claimed marker) so the reactive squeeze
          DOES fire.
        * Suppress reactive compaction by rewriting the
          classification to anything OTHER than the overflow marker
          (e.g. ``"hook_overridden"``) — the turn then surfaces the
          original error to the user instead of silently retrying.

        Recognises both the legacy spelling (``"context_length"``,
        kept for back-compat with callers that pass the short tag)
        and the modern ``_classify_upstream_error`` return string
        (``"upstream context-length overflow"``). Falls back to
        re-running the classifier on the raw message only when
        ``classification`` is empty, so a caller that wasn't updated
        for round 4 still gets the routing decision.

        Returns ``(messages, retried)`` — ``retried=True`` means we
        squeezed and the caller should re-spawn the worker.
        """
        if not classification:
            classification = self._classify_upstream_error(upstream_error)
        overflow_markers = (
            "context_length",
            "upstream context-length overflow",
        )
        if classification not in overflow_markers:
            return messages, False
        try:
            from rtxclaw_core.turn_runtime import compact_messages
        except ImportError:
            return messages, False
        ctx_window = int(getattr(self.cfg, "upstream_max_context", 0) or 0)
        if ctx_window <= 0:
            return messages, False
        try:
            squeezed, summary = compact_messages(
                messages, ctx_window=ctx_window, aggressive=True,
            )
        except TypeError:
            try:
                squeezed, summary = compact_messages(
                    messages, ctx_window=ctx_window,
                )
            except Exception:  # noqa: BLE001
                return messages, False
        except Exception:  # noqa: BLE001
            return messages, False
        try:
            from rtxclaw_core.turn_runtime import compact_session_data_in_place
            compact_session_data_in_place(session, summary)
        except Exception:  # noqa: BLE001
            pass
        self._log_event(
            "COMPACTION_REACTIVE",
            session_id=getattr(session, "hash", ""),
            kept_msgs=len(squeezed),
        )
        return squeezed, True

    # -----------------------------------------------------------------
    # Worker subprocess
    # -----------------------------------------------------------------

    def _build_worker_request(
        self,
        session: Any,
        messages: list[dict[str, Any]],
        tools_payload: list[dict[str, Any]],
        *,
        endpoint: str,
        model: str,
        max_tokens: int,
    ) -> dict[str, Any]:
        """Build the JSON payload passed to ``worker.main`` on stdin.

        Reference: acp_bridge.py L324–381. Carries:

        * ``endpoint`` / ``model`` / ``backend`` (provider hint).
        * Sampling knobs from the model row + per-turn override.
        * ``tools`` schemas (OpenAI function-tool format).
        * ``tool_choice`` (today: always ``"auto"``).
        * ``stream_options`` to request token-usage in the final chunk.
        * ``chat_template_kwargs.enable_thinking`` so Gemma 4 / Qwen3
          take the right prefill path.
        * ``headers`` — upstream-specific (Bearer, X-API-Key, …)
          resolved via ``cfg.upstream_headers(endpoint)``.
        """
        try:
            from rtxclaw_agent.acp_bridge import _build_worker_request
        except ImportError as exc:
            raise RuntimeError(
                "rtxclaw_agent.acp_bridge._build_worker_request is unavailable"
            ) from exc

        # The legacy helper reads cfg from a backend-shaped object.
        # Build a thin shim so we don't have to instantiate the
        # full legacy backend just to format a request.
        class _Shim:
            def __init__(self, cfg: Any) -> None:
                self.cfg = cfg

        # Caller-provided endpoint/model/max_tokens override the
        # session-derived values the legacy helper picks up.
        original_endpoint = session.endpoint
        original_model = session.model
        try:
            if endpoint:
                session.endpoint = endpoint
            if model:
                session.model = model
            payload = _build_worker_request(
                _Shim(self.cfg), session, messages,
                include_tools=bool(tools_payload),
            )
        finally:
            session.endpoint = original_endpoint
            session.model = original_model

        if tools_payload:
            # Override the auto-discovered tools with the caller's list.
            payload["tools"] = list(tools_payload)
            payload.setdefault("tool_choice", "auto")
            # Explicitly enable parallel tool calls. OpenAI's default
            # is ``true`` but several OpenAI-compatible servers (incl.
            # some deepseek deployments) treat the missing field as
            # ``false`` and emit a single tool_use per response —
            # which serialises an 8-subagent fan-out into 8 round
            # trips. Setting it explicitly forces deepseek-v4-pro /
            # qwen / kimi to emit ALL eligible tool calls in one
            # round when the model decides multiple are appropriate.
            payload.setdefault("parallel_tool_calls", True)
        if max_tokens:
            payload["max_tokens"] = int(max_tokens)
        return payload

    async def _consume_worker_events(
        self,
        event_stream: AsyncIterator[dict[str, Any]],
        turn: Any,
        round_state: "_RoundState",
    ) -> AsyncIterator[AgentTurnEvent]:
        """Translate worker SSE-JSONL events to :data:`AgentTurnEvent`.

        Worker event kinds (worker.py L34 + downstream paths):

        * ``thinking``       → buffered into ``round_state.thinking_buf``;
                              forwarded as :class:`TextDelta` ONLY when
                              ``cfg.reasoning_visibility != "off"``.
                              Persistence into the session record is
                              GATED by ``session.persist_reasoning_traces``
                              (default True; operator-flippable for
                              privacy — codex audit round-2 finding #6).
        * ``content``        → :class:`TextDelta`. Buffered into
                              ``round_state.content_buf``.
        * ``tool_start``     → :class:`ToolCallStarted` (legacy; no
                              current worker emits these — reserved for
                              future workers).
        * ``tool_delta``     → :class:`TextDelta` routed through a
                              ``call_id`` (today's ``tool_call_update``
                              with in-progress + content).
        * ``tool_result``    → :class:`ToolCallResult` (currently used
                              only by direct-dispatch path; LLM path
                              builds these from runner replies).
        * ``tool_calls``     → queue into ``round_state.pending_tool_calls``
                              for the post-stream dispatch step. Do NOT
                              yield — :meth:`_dispatch_tool_calls` will
                              fire the structured events when each call
                              actually runs.
        * ``metrics``        → record on the :class:`TurnState`,
                              ``session_log`` will pick it up at turn
                              end. Also yields :class:`TextDelta` with
                              empty text + a usage_update side-channel
                              for the gateway's ACP usage_update
                              translation (TUI status bar).
        * ``tool_args_loop`` → set ``round_state.loop_detected`` with
                              tier=``ratio`` + evidence (worker pre-
                              empted a tool-args token-collapse loop —
                              workers.py L362–380).
        * ``decode_drop``    → log + count; not a fatal event.
        * ``done``           → end of round; check
                              ``round_state.pending_tool_calls``.
        * ``aborted``        → :class:`TurnDone(state="aborted")` and
                              break out of the round loop.
        * ``error``          → :class:`TurnError` with the message, then
                              re-classify via
                              :meth:`_classify_upstream_error` to decide
                              between abort / reactive-compact-retry.
        """
        reasoning_visibility = str(
            getattr(self.cfg, "reasoning_visibility", "") or "off"
        ).lower()

        async for ev in event_stream:
            if not isinstance(ev, dict):
                continue
            kind = ev.get("kind") or ""
            if kind == "thinking":
                text = str(ev.get("text") or "")
                if not text:
                    continue
                round_state.thinking_buf.append(text)
                if reasoning_visibility != "off":
                    yield TextDelta(text=text, channel="thinking")
            elif kind == "content":
                text = str(ev.get("text") or "")
                if not text:
                    continue
                round_state.content_buf.append(text)
                yield TextDelta(text=text, channel="content")
            elif kind == "tool_calls":
                # Accumulate for post-stream dispatch.
                calls = ev.get("calls") or ev.get("tool_calls") or []
                for c in calls:
                    if isinstance(c, dict):
                        round_state.pending_tool_calls.append(dict(c))
            elif kind == "tool_args_loop":
                round_state.loop_detected = True
                round_state.loop_tier = "ratio"
                round_state.loop_evidence = str(
                    ev.get("evidence") or "tool_args_loop",
                )
            elif kind == "decode_drop":
                round_state.json_decode_failures += 1
                self._log_event(
                    "DECODE_DROP",
                    session_id=getattr(turn, "session_hash", ""),
                    reason=str(ev.get("reason") or ""),
                )
            elif kind == "metrics":
                round_state.metrics = {
                    k: v for k, v in ev.items() if k != "kind"
                }
            elif kind == "done":
                round_state.terminated_naturally = True
                return
            elif kind == "aborted":
                yield TurnDone(state="aborted", metrics=round_state.metrics or {})
                return
            elif kind == "error":
                msg = str(ev.get("message") or "worker error")
                yield TurnError(
                    message=msg,
                    classification=self._classify_upstream_error(msg),
                )
                return

    # -----------------------------------------------------------------
    # Tool dispatch
    # -----------------------------------------------------------------

    async def _dispatch_tool_calls(
        self,
        calls: list[dict[str, Any]],
        session: Any,
        messages: list[dict[str, Any]],
        turn: Any,
        round_record: dict[str, Any],
        promoted: set[str],
        *,
        hook_engine: Any = None,
        hook_ctx: Optional[dict[str, Any]] = None,
    ) -> AsyncIterator[AgentTurnEvent]:
        """Run pending tool calls; mutate ``messages`` with results.

        Reference: acp_bridge.py L2370–2549 (parallel batch) and
        L2136–2369 (singleton). Behavior outline:

        1. **Permission gate** — yield a :class:`PermissionRequested`
           event; the Agent layer resolves it against the active
           mode (plan / ask / auto) and writes the decision back into
           ``ev.response``. Denied calls produce a synthetic
           ``tool_call_update`` failed result.
        2. **UserQuestion** — handled by ``_default_run_tool``
           on a name match, routing through ``_ask_user_outbound``
           (auto-mode auto-answers via :func:`_ask_user_auto_answers`).
        3. **Parallel grouping** — :meth:`_build_parallel_groups`
           splits the call list into safe batches (parallel-eligible
           calls grouped, stateful/conflicting ones serialized).
        4. **Dispatch** — for each group, fan out via
           :meth:`_execute_batch_parallel`. The single-call fallback
           uses :meth:`_execute_call_singleton`.
        5. **compact_context intercept** — when the tool name is
           ``compact_context`` (acp_bridge L2223), call
           :meth:`_maybe_compact(force=True)` instead of spawning a
           runner. The squeezed message list MUTATES ``messages`` in
           place.
        6. **delegate budget** — cap external-CLI delegates
           (``delegate_claude`` / ``delegate_codex`` / ``delegate_gemini``)
           at ONE per turn per bridge (acp_bridge L2908–2912). The
           second call returns a synthetic failed tool_call_update
           telling the model to surface the prior reply instead of
           looping. ``delegate_agent`` and ``acp_call`` are NOT capped.
        7. **tool_search promotion** — when a call is ``tool_search``
           and succeeds, parse the selection and add the promoted tool
           names to ``promoted`` so the next round's tools_payload
           includes them (acp_bridge L1780–1798).
        8. **Streaming truncation guard** — if a call's arguments
           carry the ``_arguments_unparsed`` sentinel (worker repair
           gave up), short-circuit with a clean error rather than
           passing garbage to the runner (acp_bridge L2169–2221).

        Yields :class:`ToolCallStarted` / :class:`ToolCallResult` for
        every dispatched call so the gateway can translate them to ACP
        ``tool_call`` / ``tool_call_update`` events. A
        :class:`PermissionRequested` is yielded for every call whose
        ``PreToolUse`` hook didn't already decide — the Agent layer
        resolves it against the permission policy / ASK protocol.
        """
        from .engine import (
            PermissionRequested, ToolCallResult, ToolCallStarted, TextDelta,
        )

        if not calls:
            return

        hook_ctx = hook_ctx or {}
        round_idx = int(round_record.get("round_idx") or 0)

        def _denied(call_id: str, name: str, reason: str) -> None:
            # Append a synthetic tool-result message so the model sees
            # the denial and can adapt next round.
            messages.append({
                "role": "tool", "tool_call_id": call_id, "name": name,
                "content": f"[denied] {reason}",
            })
            round_record.setdefault("calls", []).append({
                "id": call_id, "name": name, "ok": False, "denied": reason,
            })

        # --- Gate every call (compact intercept → PreToolUse → policy) ---
        approved: list[dict[str, Any]] = []
        for raw in calls:
            norm = self._normalize_call(raw)
            call_id, name, args = norm["id"], norm["name"], norm["arguments"]

            # 0. Streaming-truncation guard: when the upstream cut off
            #    the tool call's ``arguments`` JSON mid-stream and the
            #    structural repair / parser also failed, ``arguments``
            #    carries a sole ``_arguments_unparsed`` key. Short-
            #    circuit with a clean, model-actionable error rather
            #    than passing garbage to the runner (which would
            #    surface a confusing arg-shape complaint).
            if (
                isinstance(args, dict)
                and "_arguments_unparsed" in args
                and len(args) == 1
            ):
                unparsed = str(args.get("_arguments_unparsed") or "")
                tail = unparsed[-160:] if len(unparsed) > 160 else unparsed
                err_msg = (
                    f"tool args malformed: streamed `arguments` JSON for "
                    f"`{name}` was truncated mid-stream and couldn't be "
                    f"auto-repaired ({len(unparsed)} chars; tail: "
                    f"{tail!r}). Retry with a smaller call (fewer items "
                    "or shorter strings) and avoid batching this tool "
                    "with another long-args tool in the same round."
                )
                yield ToolCallStarted(call_id=call_id, name=name, arguments=args)
                _denied(call_id, name, err_msg)
                yield ToolCallResult(
                    call_id=call_id, ok=False,
                    content=f"[arguments truncated] {err_msg}",
                )
                continue

            # 1. compact_context intercept — squeeze in place, no runner.
            if name == "compact_context":
                yield ToolCallStarted(call_id=call_id, name=name, arguments=args)
                squeezed = self._maybe_compact(session, messages, force=True)
                messages[:] = squeezed
                messages.append({
                    "role": "tool", "tool_call_id": call_id, "name": name,
                    "content": "context compacted",
                })
                yield ToolCallResult(
                    call_id=call_id, ok=True, content="context compacted",
                )
                continue

            # 2. PreToolUse hook (Claude Code). deny / exit-2 /
            #    decision:block => skip the call; allow => bypass the
            #    permission policy; ask / no-opinion => fall through.
            #    ``hookSpecificOutput.updatedInput`` lets a hook rewrite
            #    the tool args before dispatch — used by linter-style
            #    plugins that normalise paths, downgrade destructive
            #    flags, or splice safety options into ``Bash`` commands.
            hook_decision = ""
            if hook_engine is not None:
                pre = await self._fire_hook(
                    hook_engine, hook_ctx, "PreToolUse",
                    {"tool_name": name, "tool_input": args},
                )
                for sm in pre.system_messages:
                    yield TextDelta(text=f"[hook] {sm}\n", channel="content")
                if pre.blocked or pre.permission_decision == "deny":
                    reason = (
                        pre.block_reason or pre.permission_reason
                        or "blocked by a PreToolUse hook"
                    )
                    yield ToolCallStarted(
                        call_id=call_id, name=name, arguments=args,
                    )
                    _denied(call_id, name, reason)
                    yield ToolCallResult(
                        call_id=call_id, ok=False,
                        content=f"[denied by PreToolUse hook] {reason}",
                    )
                    continue
                if pre.updated_input is not None:
                    # Hook rewrote the args. Replace in place — the
                    # downstream criticality gate + runner see the
                    # rewritten dict, so a destructive ``rm -rf`` that
                    # the hook downgraded to ``rm -rfI`` flows through
                    # the rest of the pipeline correctly. Mutate
                    # ``norm["arguments"]`` so the dispatch step
                    # downstream picks the rewritten args up too.
                    args = dict(pre.updated_input)
                    norm["arguments"] = args
                hook_decision = pre.permission_decision  # "" | "allow" | "ask"

            # 3. Permission policy via PermissionRequested — the Agent
            #    resolves it. Skipped when a PreToolUse hook said allow.
            if hook_decision != "allow":
                import asyncio as _asyncio
                fut: "_asyncio.Future[str]" = _asyncio.get_event_loop().create_future()
                # Compute effective criticality the cautious way:
                # combine the tool's static kind + a safety heuristic
                # over the command + the model's self-claim, then take
                # the most-cautious of the three. Trusting the
                # model-supplied ``criticality`` alone lets a malicious
                # prompt downgrade ``Bash {"command": "rm -rf /",
                # "criticality": "read_only"}`` past the destructive
                # gate in auto mode (gemini round-6 finding B1).
                effective_crit = self._effective_criticality_for(
                    name, args,
                )
                # ``PermissionRequest`` hook (Claude Code spec) — fires
                # AFTER the cautious criticality merge and BEFORE the
                # Agent's permission gate. An ECC plugin can:
                #   * ``decision: block`` (exit 2) → outright deny the
                #     tool with the hook's reason as the model-facing
                #     denial body (skips the Agent gate entirely).
                #   * Return ``permissionDecision: allow|deny|ask`` →
                #     overrides the Agent gate's decision.
                #   * Return ``hookSpecificOutput.updatedCriticality``
                #     → mutates the criticality fed to the Agent (e.g.
                #     upgrade ``mutating`` to ``destructive`` after
                #     LLM-judge audit of the command). This is the
                #     primary surface for plugins that want to plug
                #     into ``_effective_criticality_for`` without
                #     forking the engine.
                if hook_engine is not None:
                    perm_hook = await self._fire_hook(
                        hook_engine, hook_ctx, "PermissionRequest",
                        {
                            "tool_name": name,
                            "tool_input": args,
                            "criticality": effective_crit,
                        },
                    )
                    for sm in perm_hook.system_messages:
                        yield TextDelta(
                            text=f"[hook] {sm}\n", channel="content",
                        )
                    if perm_hook.blocked or perm_hook.permission_decision == "deny":
                        reason = (
                            perm_hook.block_reason
                            or perm_hook.permission_reason
                            or "blocked by a PermissionRequest hook"
                        )
                        # Fire PermissionDenied so an audit plugin can
                        # log the hook-side denial too.
                        await self._fire_hook(
                            hook_engine, hook_ctx, "PermissionDenied",
                            {
                                "tool_name": name,
                                "tool_input": args,
                                "criticality": effective_crit,
                                "reason": reason,
                                "source": "hook",
                            },
                        )
                        yield ToolCallStarted(
                            call_id=call_id, name=name, arguments=args,
                        )
                        _denied(call_id, name, reason)
                        yield ToolCallResult(
                            call_id=call_id, ok=False,
                            content=f"[denied by PermissionRequest hook] {reason}",
                        )
                        continue
                    if perm_hook.permission_decision == "allow":
                        # Hook approved unconditionally — skip the
                        # Agent gate, mirror the PreToolUse `allow`
                        # path.
                        approved.append(norm)
                        continue
                    # Honor ``hookSpecificOutput.updatedCriticality``
                    # if the hook surfaced one. Folded into the
                    # criticality fed to the Agent.
                    new_crit = self._extract_updated_criticality(perm_hook)
                    if new_crit:
                        effective_crit = new_crit
                perm_ev = PermissionRequested(
                    call_id=call_id, tool_name=name, arguments=args,
                    criticality=effective_crit,
                    response=fut,
                    hook_decision=hook_decision,
                )
                yield perm_ev
                try:
                    decision = await fut
                except Exception:  # noqa: BLE001
                    decision = "deny"
                if str(decision) != "allow":
                    reason = perm_ev.reason or "permission denied"
                    # Fire PermissionDenied so an audit plugin sees
                    # the Agent-gate denial too.
                    if hook_engine is not None:
                        await self._fire_hook(
                            hook_engine, hook_ctx, "PermissionDenied",
                            {
                                "tool_name": name,
                                "tool_input": args,
                                "criticality": effective_crit,
                                "reason": reason,
                                "source": "agent_gate",
                            },
                        )
                    yield ToolCallStarted(
                        call_id=call_id, name=name, arguments=args,
                    )
                    _denied(call_id, name, reason)
                    yield ToolCallResult(
                        call_id=call_id, ok=False,
                        content=f"[permission denied] {reason}",
                    )
                    continue

            approved.append(norm)

        if not approved:
            return

        # --- Dispatch the approved calls --------------------------------
        # Serial dispatch: each tool's result message lands in
        # ``messages`` before the next call runs, so the model's
        # ``tool_calls`` order is preserved and a later call can depend
        # on an earlier one's result. (Parallel batching of read-only
        # calls — _build_parallel_groups / _execute_batch_parallel — is
        # a latent optimisation, not wired here: correctness first.)
        for entry in approved:
            async for ev in self._execute_call_singleton(
                entry, session,
                round_idx=round_idx, turn=turn,
                messages=messages, round_record=round_record,
                hook_engine=hook_engine, hook_ctx=hook_ctx,
            ):
                yield ev
            # tool_search / ToolSearch promotion: when the model used
            # ``query="select:Foo,Bar"`` to explicitly load tools, add
            # those names to ``promoted`` so they ride in the NEXT
            # round's tools[] payload (see _spawn_worker's
            # allowed_tool_names filter). This is the load-bearing
            # mechanism that lets small models scale to many deferred
            # tools without paying their schema cost every round.
            if entry["name"] in ("ToolSearch", "tool_search"):
                _q = str(entry["arguments"].get("query") or "")
                if _q.lower().startswith("select:"):
                    for _nm in _q[len("select:"):].split(","):
                        _nm = _nm.strip()
                        if _nm:
                            promoted.add(_nm)

        # ``PostToolBatch`` (Claude Code spec) — fires after the whole
        # round's tool batch completes. Observational: lets a plugin
        # see the per-round tool topology (which tools ran, in what
        # order, with what outcomes) and emit a summary message /
        # tick a global counter / audit the batch shape. Differs from
        # ``PostToolUse`` (per-call) in granularity.
        if hook_engine is not None:
            batch = await self._fire_hook(
                hook_engine, hook_ctx, "PostToolBatch",
                {
                    "tool_name": ",".join(e["name"] for e in approved),
                    "tool_count": len(approved),
                    "calls": [
                        {
                            "id": e["id"], "name": e["name"],
                            "arguments": e["arguments"],
                        }
                        for e in approved
                    ],
                    "round_idx": round_idx,
                },
            )
            for sm in batch.system_messages:
                yield TextDelta(text=f"[hook] {sm}\n", channel="content")

    @staticmethod
    def _extract_updated_criticality(perm_hook: Any) -> str:
        """Pull ``hookSpecificOutput.updatedCriticality`` out of the
        outcome's most recent JSON control block, if a hook surfaced
        one. Returns ``""`` when no hook touched criticality.

        ``HookOutcome`` doesn't carry per-key extension fields (it'd
        bloat the dataclass for every event-specific knob), so the
        getter walks the raw per-hook results from the outcome and
        picks the LAST hook whose JSON output named the field. This
        matches the ``updatedInput`` "last writer wins" rule —
        chained mutators compose in declaration order, and the final
        verdict is the merged severity.
        """
        if not getattr(perm_hook, "results", None):
            return ""
        for r in reversed(perm_hook.results):
            j = getattr(r, "json_output", None)
            if not isinstance(j, dict):
                continue
            hso = j.get("hookSpecificOutput")
            if not isinstance(hso, dict):
                continue
            uc = hso.get("updatedCriticality")
            if isinstance(uc, str) and uc.strip():
                return uc.strip()
        return ""

    def _effective_criticality_for(
        self, tool_name: str, args: dict[str, Any],
    ) -> str:
        """Compute the most-cautious criticality for one tool call.

        Combines three signals — the tool registry's static kind
        (READ / WRITE / EXEC / NETWORK), a safety heuristic over the
        command (for ``Bash``-style execs), and the model's own
        ``args["criticality"]`` claim — and returns the *most
        cautious* of the three so a model can't downgrade
        ``rm -rf /`` past the destructive gate by labeling it
        ``read_only``. Defaults to ``"mutating"`` when the tool
        isn't in the registry.
        """
        try:
            from rtxclaw_core.tools import (
                BUILTIN_TOOLS,
                PermissionEvaluator,
                PermissionMode,
                ToolRegistry,
            )
            # ``BUILTIN_TOOLS`` is a tuple, not a mapping — look up
            # the matching ``Tool`` by name via :class:`ToolRegistry`.
            tool = ToolRegistry(BUILTIN_TOOLS).get(tool_name)
            if tool is None:
                # Unknown tool — pessimistic default.
                return "mutating"
            evaluator = PermissionEvaluator(PermissionMode.AUTO)
            return str(
                evaluator._effective_criticality(tool, args).value,
            )
        except Exception:  # noqa: BLE001
            return "mutating"

    @staticmethod
    def _normalize_call(raw: dict[str, Any]) -> dict[str, Any]:
        """Coerce a worker / queued tool call into ``{id, name, arguments}``.

        Accepts both the raw OpenAI tool-call shape (``{"id", "function":
        {"name", "arguments"}}``) and the already-normalised
        ``{"id"/"call_id", "name", "arguments"}`` shape, plus the
        ``{"call": ...}`` wrapper the parallel-group helper emits.
        """
        call = raw.get("call") if isinstance(raw.get("call"), dict) else raw
        fn = call.get("function") if isinstance(call.get("function"), dict) else {}
        call_id = str(call.get("id") or call.get("call_id") or "")
        name = str(fn.get("name") or call.get("name") or "?")
        raw_args = fn.get("arguments")
        if raw_args is None:
            raw_args = call.get("arguments")
        if isinstance(raw_args, str):
            try:
                import json as _json
                args = _json.loads(raw_args or "{}")
            except (ValueError, TypeError):
                args = {"_arguments_unparsed": raw_args}
        elif isinstance(raw_args, dict):
            args = dict(raw_args)
        else:
            args = {}
        return {"id": call_id, "name": name, "arguments": args}

    def _build_parallel_groups(
        self, calls: list[dict[str, Any]]
    ) -> list[list[dict[str, Any]]]:
        """Group calls into safe parallel batches.

        Reference: acp_bridge.py L535–579 (and L499 / L515 for the
        eligibility predicates). Two calls go in the same group iff:

        * Both are read-only / pure-network (per ``Tool.kind``).
        * They don't share a state-file key
          (:func:`_state_file_key` returns distinct keys).
        * Neither call mutates a file the other reads (heuristic on
          ``args.path`` / ``args.file_path``).

        Calls that aren't parallel-eligible become singleton groups so
        the dispatch loop still runs them in order.
        """
        try:
            from rtxclaw_agent.acp_bridge import _build_parallel_groups
            return _build_parallel_groups(calls)
        except ImportError:
            # Conservative fallback — one call per group.
            return [[c] for c in (calls or [])]

    async def _execute_call_singleton(
        self,
        entry: dict[str, Any],
        session: Any,
        round_idx: int,
        turn: Any,
        messages: list[dict[str, Any]],
        round_record: dict[str, Any],
        *,
        hook_engine: Any = None,
        hook_ctx: Optional[dict[str, Any]] = None,
    ) -> AsyncIterator[AgentTurnEvent]:
        """Run ONE permission-approved tool call.

        Reference: acp_bridge.py L2136–2369. Mirrors the legacy ALLOW
        branch: streams runner deltas via :class:`TextDelta` keyed on
        the call_id, captures the final result body, appends a
        ``{"role": "tool", "tool_call_id": …, "content": …}`` message
        to ``messages`` so the next round sees the result.

        Mutations: ``messages`` (appended in-place) and
        ``round_record["calls"]`` (one record per call).

        Failure modes captured:

        * Tool runner spawn fails (``TOOL_RUNNER_SPAWN_FAILED`` event).
        * Tool runner aborted mid-stream (``TOOL_RUNNER_ABORT``).
        * Tool runner cancelled (``TOOL_RUNNER_CANCEL``); sets
          ``self._cancelled[sid]`` and re-raises.
        """
        from .engine import ToolCallStarted, ToolCallResult, TextDelta

        call = entry.get("call") or entry
        call_id = str(call.get("id") or call.get("call_id") or "")
        name = str(
            (call.get("function") or {}).get("name")
            or call.get("name")
            or "?"
        )
        raw_args = (
            (call.get("function") or {}).get("arguments")
            or call.get("arguments")
            or "{}"
        )
        if isinstance(raw_args, str):
            try:
                import json
                args = json.loads(raw_args)
            except (json.JSONDecodeError, ValueError):
                args = {"_raw": raw_args}
        else:
            args = dict(raw_args or {})

        sid = getattr(session, "hash", "") or ""

        # ``SubagentStart`` (Claude Code spec) — fires BEFORE the
        # delegate runner spawns the child agent's turn. Symmetric to
        # SubagentStop (which fires after the child returns). Lets an
        # ECC plugin emit a "child agent started" notification or
        # snapshot the parent state before the cross-agent boundary.
        if hook_engine is not None and name.startswith("delegate_"):
            subagent_name = (
                name[len("delegate_"):]
                or str(args.get("name") or "agent")
            )
            await self._fire_hook(
                hook_engine, hook_ctx or {},
                "SubagentStart",
                {
                    "subagent_name": subagent_name,
                    "tool_name": name,
                    "tool_input": args,
                },
            )

        # ``Elicitation`` (Claude Code spec) — fires BEFORE the
        # AskUserQuestion tool round-trips through the frontend so an
        # ECC plugin can:
        #   * ``decision: block`` (exit 2) → suppress the user
        #     question entirely; the hook's ``reason`` becomes the
        #     synthesised answer body the model gets back (use case:
        #     an MCP elicitation handler that auto-answers from a
        #     remote knowledge base).
        #   * Observe the question list (audit / telemetry).
        # ``ElicitationResult`` fires AFTER the answer comes back so
        # plugins can post-process / log the user's response.
        asks_user = name in ("AskUserQuestion", "ask_user", "UserQuestion")
        elicitation_hook = None
        if hook_engine is not None and asks_user:
            elicitation_hook = await self._fire_hook(
                hook_engine, hook_ctx or {},
                "Elicitation",
                {
                    "name": name,
                    "tool_input": args,
                    "questions": args.get("questions") or [],
                },
            )
            for sm in elicitation_hook.system_messages:
                yield TextDelta(
                    text=f"[hook] {sm}\n", channel="content",
                )
            if elicitation_hook.blocked and elicitation_hook.block_reason:
                # Plugin supplied a synthetic answer body — short-
                # circuit the round trip with the hook's reason.
                yield ToolCallStarted(
                    call_id=call_id, name=name, arguments=args,
                )
                messages.append({
                    "role": "tool", "tool_call_id": call_id, "name": name,
                    "content": elicitation_hook.block_reason,
                })
                yield ToolCallResult(
                    call_id=call_id, ok=True,
                    content=elicitation_hook.block_reason,
                )
                await self._fire_hook(
                    hook_engine, hook_ctx or {},
                    "ElicitationResult",
                    {
                        "name": name,
                        "tool_input": args,
                        "answer": elicitation_hook.block_reason,
                        "source": "hook",
                    },
                )
                return

        yield ToolCallStarted(call_id=call_id, name=name, arguments=args)

        # Stream runner callbacks back through the generator. on_delta
        # carries Claude/Codex/Gemini's prose chunks (keyed on this
        # outer call_id so the TUI mounts a streaming ToolResultMessage
        # under the delegate widget); on_event carries inner
        # tool_use/tool_result blocks (each with the CLI's own call_id,
        # so the TUI mounts native ToolCallMessage/ToolResultMessage
        # for Read/Bash/TodoWrite/etc.). Queue + driver task mirrors
        # _execute_batch_parallel below and ExternalCliEngine.run_turn —
        # async generators can't yield from inside a callback, so we
        # channel through an asyncio.Queue.
        ev_queue: asyncio.Queue[Any] = asyncio.Queue()

        async def _on_delta(chunk: str) -> None:
            if chunk:
                await ev_queue.put(TextDelta(
                    text=chunk, channel="tool_delta", call_id=call_id,
                ))

        async def _on_event(payload: dict) -> None:
            kind = (payload or {}).get("kind") or ""
            if kind == "tool_use":
                await ev_queue.put(ToolCallStarted(
                    call_id=str(payload.get("id") or ""),
                    name=str(payload.get("name") or "?"),
                    arguments=dict(payload.get("input") or {}),
                ))
            elif kind == "tool_result":
                await ev_queue.put(ToolCallResult(
                    call_id=str(payload.get("tool_use_id") or ""),
                    ok=bool(payload.get("ok", True)),
                    content=str(payload.get("text") or ""),
                ))

        async def _drive() -> tuple[bool, str, bool, bool]:
            try:
                return await self._invoke_runner(
                    sid,
                    {"id": call_id, "name": name, "arguments": args},
                    turn,
                    on_delta=_on_delta,
                    on_event=_on_event,
                )
            finally:
                await ev_queue.put(None)  # sentinel

        driver = asyncio.create_task(_drive())

        ok = True
        body = ""
        aborted = False
        truncated = False
        try:
            while True:
                ev = await ev_queue.get()
                if ev is None:
                    break
                yield ev
            ok, body, aborted, truncated = await driver
        except asyncio.CancelledError:
            if not driver.done():
                driver.cancel()
                try:
                    await driver
                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                    pass
            self._cancelled[sid] = True
            self._log_event("TOOL_RUNNER_CANCEL", session_id=sid, name=name)
            raise
        except Exception as exc:  # noqa: BLE001
            ok, body = False, f"runner error: {exc}"
            self._log_event(
                "TOOL_RUNNER_SPAWN_FAILED",
                session_id=sid, name=name, error=str(exc),
            )

        if aborted:
            self._log_event(
                "TOOL_RUNNER_ABORT", session_id=sid, name=name,
            )

        # PostToolUse hooks (Claude Code) — observation + optional
        # context injection. ``additionalContext`` is folded into the
        # tool-result message body so the model actually sees it on the
        # next round (not just the transcript); a blocking PostToolUse
        # hook appends its reason as model-facing feedback.
        post_ctx = ""
        if hook_engine is not None:
            post = await self._fire_hook(
                hook_engine, hook_ctx or {},
                "PostToolUse" if ok else "PostToolUseFailure",
                {"tool_name": name, "tool_input": args, "tool_response": body},
            )
            for sm in post.system_messages:
                yield TextDelta(text=f"[hook] {sm}\n", channel="content")
            if post.additional_context:
                post_ctx = post.additional_context
            if post.blocked and post.block_reason:
                post_ctx = (
                    (post_ctx + "\n\n" if post_ctx else "")
                    + f"[PostToolUse hook] {post.block_reason}"
                )
            # ``SubagentStop`` (Claude Code) — fires when a child
            # agent's turn completes. rtxclaw's "subagents" are the
            # ``delegate_*`` tool family (Claude / Codex / Gemini CLI
            # children + ``delegate_agent`` to a sibling rtxclaw
            # agent). The hook receives the child's ``tool_response``
            # body so an ECC plugin can post-process the child's
            # output (lint, route to telemetry, append a
            # cross-agent summary) before the parent sees it.
            if name.startswith("delegate_"):
                subagent_name = (
                    name[len("delegate_"):]
                    or str(args.get("name") or "agent")
                )
                sub = await self._fire_hook(
                    hook_engine, hook_ctx or {},
                    "SubagentStop",
                    {
                        "subagent_name": subagent_name,
                        "tool_name": name,
                        "tool_input": args,
                        "tool_response": body,
                        "state": "ok" if ok else "error",
                        "stop_hook_active": False,
                    },
                )
                for sm in sub.system_messages:
                    yield TextDelta(
                        text=f"[hook] {sm}\n", channel="content",
                    )
                if sub.additional_context:
                    post_ctx = (
                        (post_ctx + "\n\n" if post_ctx else "")
                        + sub.additional_context
                    )
                if sub.blocked and sub.block_reason:
                    post_ctx = (
                        (post_ctx + "\n\n" if post_ctx else "")
                        + f"[SubagentStop hook] {sub.block_reason}"
                    )
        result_body = f"{body}\n\n{post_ctx}" if post_ctx else body

        # ``ElicitationResult`` (Claude Code spec) — fires AFTER the
        # AskUserQuestion answer comes back so an ECC plugin can
        # post-process / log / route the user's reply. Observational
        # by default; ``additionalContext`` is folded into the tool-
        # result body the model sees so a plugin can add post-hoc
        # interpretation (e.g. "user selected `cancel`; treating as
        # 'do not proceed'").
        if hook_engine is not None and asks_user:
            er = await self._fire_hook(
                hook_engine, hook_ctx or {},
                "ElicitationResult",
                {
                    "name": name,
                    "tool_input": args,
                    "answer": body,
                    "ok": ok,
                    "source": "frontend",
                },
            )
            for sm in er.system_messages:
                yield TextDelta(text=f"[hook] {sm}\n", channel="content")
            if er.additional_context:
                result_body = (
                    f"{result_body}\n\n{er.additional_context}"
                    if result_body else er.additional_context
                )

        # Append the result to the message list for the next round.
        messages.append({
            "role": "tool",
            "tool_call_id": call_id,
            "name": name,
            "content": result_body,
        })

        round_record.setdefault("calls", []).append({
            "id": call_id,
            "name": name,
            "ok": ok,
            "truncated": truncated,
            "aborted": aborted,
            "content_size": len(result_body or ""),
        })

        yield ToolCallResult(call_id=call_id, ok=ok, content=result_body)

    async def _execute_batch_parallel(
        self,
        entries: list[dict[str, Any]],
        session: Any,
        round_idx: int,
        turn: Any,
        messages: list[dict[str, Any]],
        round_record: dict[str, Any],
        *,
        hook_engine: Any = None,
        hook_ctx: Optional[dict[str, Any]] = None,
    ) -> AsyncIterator[AgentTurnEvent]:
        """Run a batch of parallel-eligible calls concurrently.

        Reference: acp_bridge.py L2370–2549. Fan-out via
        ``asyncio.gather``; each driver task gets its own
        ``on_delta`` callback keyed on the call_id so the streaming
        :class:`TextDelta`s don't interleave incorrectly. Order of
        the appended tool-result messages MATCHES the order of
        ``entries`` so the model sees a deterministic transcript.
        """
        if not entries:
            return

        # Per-entry deterministic queue so the events for different
        # parallel calls don't interleave at the consumer.
        queues: list[asyncio.Queue[Any]] = [asyncio.Queue() for _ in entries]

        async def _drive_one(idx: int, entry: dict[str, Any]) -> None:
            try:
                async for ev in self._execute_call_singleton(
                    entry, session, round_idx, turn, messages, round_record,
                    hook_engine=hook_engine, hook_ctx=hook_ctx,
                ):
                    await queues[idx].put(ev)
            finally:
                await queues[idx].put(None)  # sentinel

        tasks = [
            asyncio.create_task(_drive_one(i, e))
            for i, e in enumerate(entries)
        ]
        try:
            for idx, q in enumerate(queues):
                while True:
                    ev = await q.get()
                    if ev is None:
                        break
                    yield ev
        finally:
            for t in tasks:
                if not t.done():
                    t.cancel()
            for t in tasks:
                try:
                    await t
                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                    pass

    async def _invoke_runner(
        self,
        session_id: str,
        call: dict[str, Any],
        turn: Any,
        *,
        on_delta: Optional[Callable[[str], Awaitable[None]]] = None,
        on_event: Optional[Callable[[dict], Awaitable[None]]] = None,
    ) -> tuple[bool, str, bool, bool]:
        """Call ``self._tool_runner`` with optional streaming callbacks.

        Reference: acp_bridge.py L2107–2134. Returns
        ``(ok, body, aborted, truncated)``. Falls back through narrower
        signatures (no ``on_event``, then no ``on_delta``) for test
        stubs that don't accept them.
        """
        runner = self._tool_runner
        if runner is None:
            try:
                from rtxclaw_agent.acp_bridge import _default_run_tool
            except ImportError as exc:
                return False, f"no tool runner available: {exc}", False, False
            # ``_default_run_tool`` expects ``(backend, session_id,
            # call, turn, **kw)``. The bridge normally pre-binds
            # ``backend=self`` when it builds the engine (see
            # ``CoreBackend._get_new_agent``). If we got here with no
            # injected runner, the engine was built outside the
            # bridge — wrap with a synthesized CoreBackend-shaped
            # shim so the signature still lines up.
            engine = self
            sess_cache = engine._sessions
            class _RunToolShim:
                def __init__(self) -> None:
                    self.cfg = engine.cfg
                    self.server_handle = None
                def _session_for(self, sid: str) -> Any:
                    return sess_cache.get(sid)
                def _outbound_for(self, _sid: str) -> Any:  # noqa: ARG002
                    return None
            shim_backend = _RunToolShim()
            async def _bound(session_id: str, call: dict, turn_state: Any, **kw: Any) -> Any:
                return await _default_run_tool(shim_backend, session_id, call, turn_state, **kw)
            runner = _bound
        if runner is None:
            return False, "no tool runner configured", False, False

        # Try the widest signature first, then progressively narrower
        # ones for test-injected stubs.
        attempts = []
        if on_event is not None:
            attempts.append({"on_delta": on_delta, "on_event": on_event})
        attempts.append({"on_delta": on_delta})
        attempts.append({})
        last_exc: Optional[BaseException] = None
        for kwargs in attempts:
            try:
                result = await runner(session_id, call, turn, **kwargs)
                # Coerce — some runners return a ToolResult, some a tuple.
                if isinstance(result, tuple) and len(result) >= 2:
                    ok = bool(result[0])
                    body = str(result[1] or "")
                    aborted = bool(result[2]) if len(result) > 2 else False
                    truncated = bool(result[3]) if len(result) > 3 else False
                    return ok, body, aborted, truncated
                ok = bool(getattr(result, "ok", True))
                body = str(getattr(result, "content", "") or "")
                aborted = bool(getattr(result, "aborted", False))
                truncated = bool(getattr(result, "truncated", False))
                return ok, body, aborted, truncated
            except TypeError as exc:
                last_exc = exc
                continue
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                return False, f"runner raised: {exc}", False, False
        return False, f"no runner signature matched: {last_exc}", False, False

    # -----------------------------------------------------------------
    # Permission + ASK protocol
    # -----------------------------------------------------------------

    # Orphan ``_request_permission`` / ``_ask_user`` methods removed
    # 2026-05-15. The live permission flow runs at the Agent layer:
    # :class:`LocalLLMEngine` yields a :class:`PermissionRequested`
    # event mid-dispatch, :meth:`Agent.resolve_permission` runs the
    # policy + ``permissions_integration.ask_user`` (which talks to
    # the bound :class:`AcpServer` via
    # ``request_outbound("session/request_permission", payload)``),
    # and sets the event's response future. The engine never makes
    # the policy decision itself.

    # -----------------------------------------------------------------
    # Loop detection
    # -----------------------------------------------------------------

    def _check_streamed_loop(
        self,
        buf: list[str],
        last_check_chars: int,
        stream_label: str,    # "thinking" | "content"
    ) -> tuple[Optional[tuple[str, str]], int]:
        """Sample the layered detector on the buffer.

        Reference: acp_bridge.py L3083–3159 and turn_runtime detectors
        (L214 / L271 / L300 / L320). Throttled to once per
        ``LOOP_CHECK_STRIDE`` chars so cost stays bounded.

        Returns ``(hit_or_none, new_last_check_chars)`` where ``hit``
        is ``(tier, evidence_ngram)`` when a loop is detected.
        """
        if not LOOP_DETECT_ENABLED:
            return None, last_check_chars
        text = "".join(buf)
        if len(text) < LOOP_WINDOW_CHARS:
            return None, last_check_chars
        if len(text) - last_check_chars < LOOP_CHECK_STRIDE:
            return None, last_check_chars
        try:
            from rtxclaw_core.turn_runtime import _detect_loops_layered
        except ImportError:
            return None, len(text)
        try:
            hit = _detect_loops_layered(
                text,
                ngram_len=LOOP_NGRAM_LEN,
                repeat_threshold=LOOP_REPEAT_THRESHOLD,
            )
        except TypeError:
            try:
                hit = _detect_loops_layered(text)
            except Exception:  # noqa: BLE001
                return None, len(text)
        except Exception:  # noqa: BLE001
            return None, len(text)
        if not hit:
            return None, len(text)
        if isinstance(hit, tuple):
            return (str(hit[0]), str(hit[1] if len(hit) > 1 else "")), len(text)
        return (str(hit), ""), len(text)

    def _check_ratio_loop(
        self, metrics: dict[str, Any]
    ) -> Optional[tuple[str, str]]:
        """Post-stream token-loop ratio guard.

        Reference: worker.py L572–609 (computes
        ``token_loop_suspected``) and acp_bridge.py L3292–3327
        (acts on it). Fires when completion_tokens >=
        :data:`LOOP_RATIO_MIN_TOKENS` AND
        ``chars_per_token < cfg.loop_chars_per_token_min`` (model row
        override) or :data:`LOOP_CHARS_PER_TOKEN_MIN` (env default).
        """
        if not metrics:
            return None
        # If the worker already pre-classified the loop, surface it.
        if metrics.get("token_loop_suspected"):
            return ("ratio", str(metrics.get("evidence") or "token_loop_suspected"))
        # Skip the backstop when the upstream gave a clean termination
        # signal — mirrors the worker pre-classifier. A clean finish
        # means the model chose to end this round on purpose, so a
        # high reasoning/content ratio is dense thinking, not a loop.
        if metrics.get("finish_reason") in ("stop", "tool_calls"):
            return None
        completion_tokens = int(metrics.get("completion_tokens") or 0)
        if completion_tokens < LOOP_RATIO_MIN_TOKENS:
            return None
        chars = int(metrics.get("completion_chars") or 0)
        if chars <= 0:
            return None
        ratio = chars / max(1, completion_tokens)
        floor = float(
            getattr(self.cfg, "loop_chars_per_token_min", 0)
            or LOOP_CHARS_PER_TOKEN_MIN
        )
        if ratio < floor:
            return ("ratio", f"chars_per_token={ratio:.2f} < floor={floor:.2f}")
        return None

    # -----------------------------------------------------------------
    # Distill recovery + continuation nudge + force-terminate
    # -----------------------------------------------------------------

    async def _distill_recovery(
        self,
        session: Any,
        messages: list[dict[str, Any]],
        loop_hit: tuple[str, str],
        round_state: "_RoundState",
        recovery_count: int,
        *,
        hook_engine: Any = None,
        hook_ctx: Optional[dict[str, Any]] = None,
    ) -> tuple[list[dict[str, Any]], bool]:
        """Distill the partial reasoning into a fresh frame, then continue.

        Reference: turn_runtime._distill_partial_reasoning (L759) plus
        the surrounding loop in ``CoreBackend.prompt`` (the
        distill_recoveries / distill_max_recoveries counters,
        acp_bridge L2921–2931).

        Steps:

        1. Pause the worker (if still running), kill it.
        2. Fire the ``DistillRecovery`` hook. The hook may
           ``continue: false`` (skip recovery; fall through to force-
           terminate) or ``decision: block`` + ``reason: <preamble>``
           (substitute the operator's preamble for the canned
           distiller call — useful when the operator already has a
           cheap on-disk summariser and doesn't want to spend an LLM
           round).
        3. Otherwise: call ``_distill_partial_reasoning(thinking_buf,
           model=…)`` — a cheap LLM round that produces a structured
           JSON ``{"summary", "key_findings", "next_step"}``.
        4. Parse via ``_parse_distill_json``; format via
           ``_format_distill_for_recovery``.
        5. Replace the assistant-round-in-progress message with the
           formatted recovery preamble, signal the loop to start a
           fresh worker round.

        ``cfg.distill_max_recoveries`` (default 3) caps how many times
        this fires per turn. After that, fall through to
        :meth:`_force_terminate`.

        Returns ``(messages, recovered)``.
        """
        try:
            from rtxclaw_core.turn_runtime import (
                _distill_partial_reasoning,
                _format_distill_for_recovery,
                _parse_distill_json,
            )
        except ImportError:
            return messages, False

        max_recoveries = int(
            getattr(self.cfg, "distill_max_recoveries", 3) or 3
        )
        if recovery_count >= max_recoveries:
            return messages, False

        thinking = "".join(round_state.thinking_buf)
        if not thinking.strip():
            return messages, False

        # ``DistillRecovery`` hook: gives operators a substitution point
        # for the (expensive) LLM-based distiller round. A
        # ``decision: block`` with a ``reason`` body short-circuits the
        # distiller entirely — the hook's text becomes the recovery
        # preamble. A ``continue: false`` skips distill so the cascade
        # advances to force-terminate immediately.
        preamble: Optional[str] = None
        if hook_engine is not None:
            distill_hook = await self._fire_hook(
                hook_engine, hook_ctx or {},
                "DistillRecovery",
                {
                    "tier": loop_hit[0] if loop_hit else "",
                    "evidence": loop_hit[1] if loop_hit else "",
                    "attempt": recovery_count + 1,
                    "max_recoveries": max_recoveries,
                    "thinking_chars": len(thinking),
                },
            )
            if not distill_hook.should_continue:
                return messages, False
            if distill_hook.blocked and distill_hook.block_reason:
                preamble = distill_hook.block_reason

        if preamble is None:
            try:
                raw = await _distill_partial_reasoning(
                    self.cfg,
                    thinking,
                )
            except TypeError:
                try:
                    raw = await _distill_partial_reasoning(thinking)
                except Exception:  # noqa: BLE001
                    return messages, False
            except Exception:  # noqa: BLE001
                return messages, False
            try:
                parsed = _parse_distill_json(raw)
                preamble = _format_distill_for_recovery(parsed)
            except Exception:  # noqa: BLE001
                return messages, False
        # Drop the partial assistant message at the tail and insert
        # the recovery preamble in its place.
        out = list(messages)
        while out and isinstance(out[-1], dict) and out[-1].get("role") == "assistant":
            out.pop()
        out.append({"role": "assistant", "content": preamble})
        self._log_event(
            "DISTILL_RECOVERY",
            session_id=getattr(session, "hash", ""),
            attempt=recovery_count + 1,
            tier=str(loop_hit[0]) if loop_hit else "",
        )
        return out, True

    async def _continuation_nudge(
        self,
        messages: list[dict[str, Any]],
        nudge_log: list[dict[str, Any]],
        *,
        kind: str = "silent",
        tail: Optional[str] = None,
        body_override: Optional[str] = None,
    ) -> tuple[list[dict[str, Any]], bool]:
        """Inject one of the nudge bodies for a premature-finish round.

        Three variants, chosen by ``kind``:

        * ``"silent"`` — the round produced no content and no tool calls
          (or content shorter than ``NUDGE_MIN_TEXT_CHARS``). Injects
          ``NUDGE_PROMPT_BODY``.
        * ``"cutoff"`` — content present but ends mid-syntax (open
          backticks / fences); ``tail`` is the offending last ~80
          chars. Injects ``CUTOFF_NUDGE_PROMPT_BODY`` formatted with
          the tail.
        * ``"colon"`` — content ends on a colon with no tool calls
          following; ``tail`` is the last ~80 chars. Injects
          ``COLON_CLIFFHANGER_NUDGE_PROMPT_BODY`` formatted with the
          tail.

        ``body_override`` lets a ``PrematureTurnEnd`` hook substitute
        the entire body — the canonical injection point for ECC
        plugins that want per-model / per-context nudge wording. The
        canned bodies are the FALLBACK when no hook overrides.

        Don't double-nudge: if the most recent user message is already
        a nudge of the same kind, return ``(messages, False)``.

        ``nudge_log`` is mutated in place with the audit entry.
        """
        if kind == "cutoff":
            body = CUTOFF_NUDGE_PROMPT_BODY.format(tail=tail or "")
            marker = "[rtxclaw continuation] Your previous response was cut mid-sentence"
        elif kind == "colon":
            body = COLON_CLIFFHANGER_NUDGE_PROMPT_BODY.format(tail=tail or "")
            marker = "[rtxclaw continuation] Your previous response ended on a colon"
        else:
            body = NUDGE_PROMPT_BODY
            marker = "[rtxclaw continuation] You stopped after a tool chain"
        if body_override:
            # Hook-supplied body wins. Marker stays the canned one so
            # the double-nudge guard below still detects same-kind
            # repeats even when the hook rewrites the body each turn.
            body = body_override

        # Don't double-nudge: if the most recent user message is
        # already a nudge of the SAME kind, skip.
        for m in reversed(messages):
            if isinstance(m, dict) and m.get("role") == "user":
                content = str(m.get("content") or "")
                if marker in content:
                    return messages, False
                break
        nudge_log.append({"at": _now_iso(), "kind": kind})
        out = list(messages)
        out.append({"role": "user", "content": body})
        self._log_event("NUDGE_FIRED", kind=kind)
        return out, True

    async def _force_terminate(
        self,
        messages: list[dict[str, Any]],
        *,
        hook_engine: Any = None,
        hook_ctx: Optional[dict[str, Any]] = None,
        tier: str = "",
        round_idx: int = -1,
    ) -> tuple[list[dict[str, Any]], bool]:
        """Last-ditch "write a closing paragraph and END" round.

        Reference: the ``LOOP_FORCE_TERMINATE`` block referenced in
        acp_bridge.py L2933. Fires at most once per turn
        (``force_terminate_attempted`` guard) after distill recoveries
        are exhausted.

        The ``ForceTerminate`` hook fires BEFORE the canned body so an
        ECC plugin can substitute a model-tailored closing prompt
        (e.g. a Qwen-specific brevity nudge, or a tighter
        "summarize then exit" body). A ``continue: false`` skips
        force-terminate entirely (operator wants the turn to die now).
        """
        DEFAULT_FORCE_TERMINATE_BODY = (
            "[FORCE TERMINATE] Loop budget exhausted. Write a closing "
            "paragraph that summarizes the user-facing answer with what "
            "you have so far, then STOP. Do not call any more tools."
        )
        body = DEFAULT_FORCE_TERMINATE_BODY
        if hook_engine is not None:
            ft_hook = await self._fire_hook(
                hook_engine, hook_ctx or {},
                "ForceTerminate",
                {
                    "tier": tier,
                    "round_idx": round_idx,
                },
            )
            if not ft_hook.should_continue:
                return messages, False
            if ft_hook.blocked and ft_hook.block_reason:
                body = ft_hook.block_reason
        out = list(messages)
        out.append({"role": "user", "content": body})
        self._log_event("LOOP_FORCE_TERMINATE")
        return out, True

    # -----------------------------------------------------------------
    # Direct-dispatch (slash-command bypass)
    # -----------------------------------------------------------------

    async def _run_direct_tool_call(
        self,
        session: Any,
        turn_id: str,
        direct: dict[str, Any],
    ) -> AsyncIterator[AgentTurnEvent]:
        """Bypass the LLM and invoke a delegate-class tool directly.

        Reference: acp_bridge.py L2551–2837.

        Used by ``/claude``, ``/codex``, ``/gemini``, ``/compact``
        slash commands when the operator types the prompt themselves —
        the local model isn't responsible for the dispatch decision.

        Restricted to tool names matching ``delegate_*`` (so an
        unauthenticated frontend can't smuggle in a write/exec). The
        ``on_event`` path is wired so inner Claude tool blocks fan out
        as proper :class:`ToolCallStarted` / :class:`ToolCallResult`
        events (TodoWrite ticks the plan checklist; Read/Bash render
        as native widgets).

        In the new architecture, ``delegate_<kind>`` tools dispatch
        through ``Agent.run_turn`` on a *child* Agent (engine=CLI),
        so this method shrinks dramatically — the bulk of the legacy
        body moves into ``ExternalCliEngine.run_turn``. What remains
        here is the wire-event translation + per-turn metrics row.
        """
        from .engine import (
            TextDelta,
            ToolCallStarted,
            ToolCallResult,
            TurnDone,
            TurnError,
        )
        from . import delegate_shims

        name = str(direct.get("name") or direct.get("tool") or "")
        args = direct.get("arguments") or direct.get("args") or {}
        if not isinstance(args, dict):
            args = {}

        # Whitelist: only delegate_* tools (the slash-command bridges
        # /claude /codex /gemini) and ``compact_context`` (used by
        # /compact) may bypass the LLM. Anything else routes through a
        # normal turn — an unauthenticated frontend can't smuggle a
        # write/exec via this path.
        if name == "compact_context":
            # /compact: squeeze the session messages in place — no
            # runner subprocess. The Agent has the session; the
            # engine's _maybe_compact does the work.
            yield ToolCallStarted(
                call_id=f"direct-{turn_id[:8]}", name=name,
                arguments=args, is_outer=True,
            )
            try:
                # Pull the message list out of the session record.
                # Compaction mutates session_data in place via
                # compact_session_data_in_place when called force=True.
                msgs = list(getattr(session, "messages", []) or [])
                self._maybe_compact(session, msgs, force=True)
                yield ToolCallResult(
                    call_id=f"direct-{turn_id[:8]}", ok=True,
                    content="context compacted",
                )
                yield TurnDone(
                    state="ok",
                    metrics={"engine": "local_llm", "direct_dispatch": name},
                )
            except Exception as exc:  # noqa: BLE001
                yield TurnError(
                    message=str(exc),
                    classification="direct_dispatch_error",
                )
                yield TurnDone(state="error")
            return
        if not name.startswith("delegate_"):
            yield TurnError(
                message=(
                    f"direct-dispatch denied for tool {name!r} — only "
                    "delegate_* and compact_context allowed"
                ),
                classification="bad_request",
            )
            yield TurnDone(state="error")
            return

        call_id = f"direct-{turn_id[:8]}"
        yield ToolCallStarted(call_id=call_id, name=name, arguments=args, is_outer=True)

        shim_map = {
            "delegate_claude": delegate_shims.shim_run_delegate_claude_async,
            "delegate_codex":  delegate_shims.shim_run_delegate_codex_async,
            "delegate_gemini": delegate_shims.shim_run_delegate_gemini_async,
            "delegate_agent":  delegate_shims.shim_run_delegate_agent_async,
        }
        shim = shim_map.get(name)
        if shim is None:
            yield ToolCallResult(call_id=call_id, ok=False, content=f"no shim for {name}")
            yield TurnDone(state="error")
            return

        buf: list[str] = []

        def _on_delta(chunk: str) -> None:
            buf.append(chunk)

        started_at = _now_iso()
        try:
            try:
                result = await shim(args, on_delta=_on_delta)
            except TypeError:
                result = await shim(args)
        except asyncio.CancelledError:
            yield ToolCallResult(call_id=call_id, ok=False, content="".join(buf) + "\n[cancelled]")
            yield TurnDone(state="aborted")
            return
        except Exception as exc:  # noqa: BLE001
            yield ToolCallResult(call_id=call_id, ok=False, content=str(exc))
            yield TurnError(message=str(exc), classification="direct_dispatch_error")
            yield TurnDone(state="error")
            return

        body = str(getattr(result, "content", "") or "".join(buf))
        ok = bool(getattr(result, "ok", True))
        yield TextDelta(text=body, channel="content")
        yield ToolCallResult(call_id=call_id, ok=ok, content=body)
        yield TurnDone(
            state="ok" if ok else "error",
            metrics={
                "engine": "local_llm",
                "direct_dispatch": name,
                "started_at": started_at,
                "ended_at": _now_iso(),
                "size": len(body),
            },
        )

    # -----------------------------------------------------------------
    # Per-round metrics, logging, kv-cache instrumentation
    # -----------------------------------------------------------------

    def _log_round(
        self,
        session_id: str,
        turn_id: str,
        round_idx: int,
        messages: list[dict[str, Any]],
        tools_payload: list[dict[str, Any]],
    ) -> None:
        """KV-cache instrumentation: hash the prefix + tools.

        Reference: acp_bridge.py L2028–2062. Logs a structured
        ``ROUND_PREFIX`` event with the first-1024-char hash of the
        message list and a separate hash of the tools schema list, so
        an operator can tell at a glance whether two consecutive rounds
        shared a cached prefix (vLLM APC / SGLang RadixAttention KV
        reuse signal).
        """
        try:
            from rtxclaw_core.turn_runtime import (
                _hash_prefix,
                _hash_tools_payload,
            )
            prefix_hash = _hash_prefix(messages)
            tools_hash = _hash_tools_payload(tools_payload)
        except Exception:  # noqa: BLE001
            import hashlib, json
            try:
                blob = json.dumps(messages[:8], sort_keys=True)[:4096]
            except (TypeError, ValueError):
                blob = str(messages[:8])[:4096]
            prefix_hash = hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]
            try:
                tblob = json.dumps(tools_payload, sort_keys=True)
            except (TypeError, ValueError):
                tblob = str(tools_payload)
            tools_hash = hashlib.sha256(tblob.encode("utf-8")).hexdigest()[:16]

        self._log_event(
            "ROUND_PREFIX",
            session_id=session_id[:12],
            turn_id=turn_id[:12],
            round=round_idx,
            prefix=prefix_hash,
            tools=tools_hash,
        )

    def _record_round_metrics(
        self,
        session: Any,
        round_idx: int,
        metrics: dict[str, Any],
        endpoint: str,
    ) -> None:
        """Capture worker ``metrics`` payload onto the round record.

        Reference: acp_bridge.py L3200–3291 (the ``elif kind == "metrics"``
        block). Augments the worker payload with:

        * ``context_window`` from ``cfg.upstream_max_context``.
        * ``model_alias`` resolved via ``cfg.model_row_for_endpoint``.
        * Persistent ``TURN_METRICS …`` line written to
          ``cfg.logfile`` in append mode (this is gateway.log).
        """
        if not isinstance(metrics, dict):
            return
        enriched = dict(metrics)
        ctx = int(getattr(self.cfg, "upstream_max_context", 0) or 0)
        if ctx:
            enriched.setdefault("context_window", ctx)
        if endpoint and not enriched.get("endpoint"):
            enriched["endpoint"] = endpoint
        try:
            row = (
                self._resolve_model_row(enriched.get("model") or "")
                if enriched.get("model") else None
            )
            if row is not None:
                enriched.setdefault("model_alias", row.get("alias") or row.get("name") or "")
        except Exception:  # noqa: BLE001
            pass

        # Attach to the session's per-round metrics array so the
        # session log picks it up at turn end.
        try:
            rounds = getattr(session, "round_metrics", None)
            if not isinstance(rounds, list):
                rounds = []
                session.round_metrics = rounds
            rounds.append({"round_index": round_idx, **enriched})
        except Exception:  # noqa: BLE001
            pass

        self._log_event(
            "TURN_METRICS",
            round=round_idx,
            prompt_tokens=enriched.get("prompt_tokens"),
            completion_tokens=enriched.get("completion_tokens"),
            model=enriched.get("model"),
            endpoint=endpoint,
        )

    def _log_event(self, event: str, **fields: Any) -> None:
        """Structured event log via ``log_event``.

        Reference: acp_bridge.py L2063 + tools.runners._log_delegate_error
        pattern. Used for: ``LOOP_DETECTED``, ``TOOL_RUNNER_*``,
        ``TOOL_ARGS_MALFORMED``, ``ROUND_PREFIX``, ``COMPACTION_*``,
        ``DISTILL_*``, ``NUDGE_*``, ``DELEGATE_*``.
        """
        parts: list[str] = [event]
        for k, v in fields.items():
            if v is None:
                continue
            sv = str(v)
            if len(sv) > 200:
                sv = sv[:197] + "..."
            parts.append(f"{k}={sv}")
        _LOG.info(" ".join(parts))

    # -----------------------------------------------------------------
    # Upstream-error triage
    # -----------------------------------------------------------------

    def _classify_upstream_error(self, msg: str) -> str:
        """Forward to ``turn_runtime._classify_upstream_error`` (L1462).

        Returns the human-readable tag the underlying function emits:
        ``"upstream context-length overflow"`` /
        ``"upstream rate-limited"`` / ``"upstream timeout"`` /
        ``"upstream HTTP <code>"`` / ``"upstream error"``. Drives the
        reactive-compact retry decision (matched against the legacy
        short-tag spelling AND the long-form here in
        :meth:`_reactive_compact_on_overflow`), the backoff/retry
        helper, and the user-facing error message. An ``UpstreamError``
        hook can override the tag mid-stream — see :meth:`run_turn`'s
        error branch.
        """
        return _classify(msg or "")

    # -----------------------------------------------------------------
    # Mode / config
    # -----------------------------------------------------------------

    def _max_rounds_for_mode(self, session_id: str) -> int:
        """Round cap for the active mode.

        Reference: acp_bridge.py L1893–1910. Auto mode →
        :data:`MAX_ROUNDS_AUTO`; ask / plan → ``cfg._max_rounds``
        (default :data:`DEFAULT_MAX_ROUNDS`). Per-session
        ``self._mode_overrides[sid]`` wins over ``cfg.permission_mode``.
        """
        if self._max_rounds_override is not None:
            return int(self._max_rounds_override)
        mode = self._mode_overrides.get(session_id) or str(
            getattr(self.cfg, "permission_mode", "auto") or "auto"
        )
        if mode == "auto":
            return MAX_ROUNDS_AUTO
        return int(
            getattr(self.cfg, "_max_rounds", DEFAULT_MAX_ROUNDS)
            or DEFAULT_MAX_ROUNDS
        )

    async def set_mode(self, session_id: str, mode_id: str) -> None:
        """Per-session permission-mode override.

        Reference: acp_bridge.py L1654–1687. Validates ``mode_id ∈
        {plan, ask, auto}``, updates ``self._mode_overrides[sid]``,
        emits a ``mode_changed`` ACP event upstream.
        """
        if mode_id not in ("plan", "ask", "auto"):
            raise ValueError(
                f"unknown mode: {mode_id!r} — expected plan/ask/auto"
            )
        self._mode_overrides[session_id] = mode_id
        self._log_event(
            "MODE_CHANGED", session_id=session_id[:12], mode=mode_id,
        )

    async def set_config_option(
        self, session_id: str, option_id: str, value: Any
    ) -> None:
        """Per-session config-option override.

        Reference: acp_bridge.py L1688–1759. Handles ``/reasoning``,
        ``/tool``, ``/thinking``, ``/model``, ``/temperature``. Stores
        on the :class:`Session` (so persisted across restart) and
        echoes a sessionUpdate so all frontends sync.
        """
        if option_id == "reasoning":
            allowed = {"off", "live", "persist", "on"}
            v = str(value or "").lower()
            if v not in allowed:
                raise ValueError(f"reasoning: invalid value {value!r}")
            self.cfg.reasoning_visibility = v
        elif option_id == "tool":
            # Promote a tool for the next round on this session.
            name = str(value or "").strip()
            if name:
                self._promoted_tools.setdefault(session_id, set()).add(name)
        elif option_id == "thinking":
            v = bool(value) if not isinstance(value, str) else value.lower() in (
                "1", "true", "yes", "on",
            )
            self.cfg.enable_thinking = v
        elif option_id == "model":
            alias = str(value or "").strip()
            # Resolve against the operator's ``cfg.models`` deployment
            # list — the local ``_resolve_model_row`` returns a sampling
            # PROFILE (generic/qwen/gemma), not a deployment row, so it
            # can't tell us the wire model id or baseUrl. The bridge
            # mutates the SESSION (sess.model/endpoint) right after
            # this call returns; here we mirror that onto the global
            # cfg so the next fresh session (TUI ``/new``, heartbeat
            # session creation) inherits a consistent
            # ``(upstream_model, upstream_endpoint, upstream_alias)``
            # triple. The previous code stored the alias string
            # directly into ``upstream_model`` — but ``upstream_model``
            # is the wire model id (e.g. ``deepseek-v4-flash``), not
            # the alias (``deepseek``). Sending the alias as the model
            # id to tb07's vLLM produced HTTP 404 "The model deepseek
            # does not exist" the moment the operator opened a new
            # session against the same long-lived gateway process.
            row: Optional[dict[str, Any]] = None
            if alias:
                for m in (getattr(self.cfg, "models", None) or []):
                    m_dict = dict(m) if isinstance(m, dict) else getattr(m, "__dict__", {})
                    if str(m_dict.get("alias") or "") == alias:
                        row = m_dict
                        break
                if row is None:
                    raise ValueError(f"model: unknown alias {alias!r}")
            if row is not None:
                row_id = str(row.get("id") or "").strip()
                base_url = str(row.get("baseUrl") or "").strip()
                if not row_id:
                    raise ValueError(
                        f"model alias {alias!r} has no `id` configured "
                        f"({base_url or '<no baseUrl>'}). Set the model "
                        f"id explicitly in ~/.rtxclaw/config.json."
                    )
                self.cfg.upstream_model = row_id
                if base_url:
                    self.cfg.upstream_endpoint = base_url
                self.cfg.upstream_alias = alias
            else:
                self.cfg.upstream_model = ""
        elif option_id == "temperature":
            try:
                self.cfg.temperature = float(value)
            except (TypeError, ValueError) as exc:
                raise ValueError(f"temperature: {exc}") from exc
        else:
            raise ValueError(f"unknown config option: {option_id!r}")
        self._log_event(
            "CONFIG_OPTION",
            session_id=session_id[:12],
            option=option_id,
            value=str(value),
        )

    def _resolve_model_row(self, alias: str) -> Optional[dict[str, Any]]:
        """Strict alias→model row resolution (no silent fallback).

        Reference: acp_bridge.py L1761–1779 / commands.py L227. Returns
        ``None`` on typo so the caller surfaces an error instead of
        flipping the active model to a default.
        """
        if not alias:
            return None
        try:
            from rtxclaw_core.models import for_name
        except ImportError:
            return None
        try:
            row = for_name(alias, strict=True)
        except TypeError:
            # Older ``for_name`` signatures don't support ``strict``.
            try:
                row = for_name(alias)
            except Exception:  # noqa: BLE001
                return None
        except Exception:  # noqa: BLE001
            return None
        if row is None:
            return None
        # ``for_name`` may return a Model dataclass; normalize to dict.
        if isinstance(row, dict):
            return row
        out: dict[str, Any] = {}
        for attr in ("name", "alias", "endpoint", "backend",
                     "context_window", "extra_sampling"):
            v = getattr(row, attr, None)
            if v is not None:
                out[attr] = v
        return out or {"alias": alias}

# =====================================================================
# Helper dataclass — per-round state captured during the worker loop.
# Kept private to this module; nothing outside touches it.
# =====================================================================


class _RoundState:
    """Mutable state accumulated during one worker round.

    Reference: the local variables inside ``CoreBackend.prompt``'s
    inner loop (``round_thinking`` / ``round_content`` /
    ``round_tool_calls`` / ``loop_detected*`` / etc., acp_bridge.py
    L3047–3060).

    Lives only inside :meth:`LocalLLMEngine._consume_worker_events`
    and the dispatch helpers it hands off to. Dropped at end-of-round.
    """

    def __init__(self) -> None:
        self.thinking_buf: list[str] = []
        self.content_buf: list[str] = []
        self.pending_tool_calls: list[dict[str, Any]] = []
        self.metrics: Optional[dict[str, Any]] = None
        self.loop_detected: bool = False
        self.loop_tier: Optional[str] = None
        self.loop_evidence: str = ""
        self.thinking_loop_check_chars: int = 0
        self.content_loop_check_chars: int = 0
        self.json_decode_failures: int = 0
        self.terminated_naturally: bool = False
