"""Local-first fact store: a SQLite + FTS5 alternative to MEMORY.md.

Use cases:

- Save discrete factual statements ("the dataset lives at /data/x.parquet")
  with a `category`, `tags`, and `trust` score, and search them later.
- Auto-extract candidate facts from saved sessions so the operator
  doesn't have to remember to call `remember` for every preference.
- Track trust over time via `fact_feedback`: marking a fact helpful /
  unhelpful nudges its `trust` score so noisy auto-extracted facts
  decay out of search results.

Two surfaces for the model:

- `fact_store(action, ...)` — single dispatch tool with sub-actions
  `add`, `search`, `list`, `remove`, `update`. Keeps the tool count
  low; the model already knows the `remember` shape.
- `fact_feedback(fact_id_or_prefix, helpful)` — adjusts trust.

Stays explicitly decoupled from `memory_write.remember` and
`MemoryIndex`: facts.db is its own thing. A future migration could
fold facts back into the main memory index, but today they live as a
separate provider so the experiment can be enabled/disabled without
touching MEMORY.md.

Security gate (on `add`):

- **Zero-width Unicode rejection.** Invisible characters (`​`,
  `‌`, `‍`, `﻿`) are a known channel for prompt
  injection — a fact "innocent text​<malicious>" looks fine on
  the screen but smuggles instructions into the model. We refuse.
- **Credential pattern rejection.** Common API key shapes
  (`sk-...`, `xoxb-...`, AWS access keys, GitHub PATs, PEM headers)
  are rejected so a wandering model can't pin operator secrets in a
  searchable plaintext store.

The privacy gate (`_is_private_origin`) is enforced at the tool-runner
boundary identically to `memory_search` / `remember` — shared/group
frontends never reach this module.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Optional

from rtxclaw_memory.memory_index import bm25_rank_to_score, build_fts_query


_log = logging.getLogger(__name__)


DEFAULT_TRUST: float = 0.5
TRUST_HELPFUL_DELTA: float = 0.05
TRUST_UNHELPFUL_DELTA: float = 0.10
DEFAULT_MAX_RESULTS: int = 6
SNIPPET_CHARS: int = 500
MAX_FACT_CHARS: int = 4000


# ---- privacy gate (mirrors memory_tools.py) -------------------------

_PRIVATE_ORIGINS: frozenset[str] = frozenset({
    "", "tui", "oneshot", "heartbeat", "telegram",
})


def _is_private_origin(workspace_origin: str) -> bool:
    return (workspace_origin or "").strip().lower() in _PRIVATE_ORIGINS


# ---- security scanning ----------------------------------------------

# Invisible / format Unicode that's been used as a prompt-injection
# channel. We err on the side of refusing — operators rarely paste
# zero-width chars on purpose, and the false-positive cost (rejecting
# a legitimate fact with a stray BOM) is low.
_ZERO_WIDTH_CHARS: frozenset[str] = frozenset({
    "​",  # ZERO WIDTH SPACE
    "‌",  # ZERO WIDTH NON-JOINER
    "‍",  # ZERO WIDTH JOINER
    "﻿",  # ZERO WIDTH NO-BREAK SPACE / BOM
    "⁠",  # WORD JOINER
})

# Credential-shaped patterns. Matching is lossy by design — we want
# false positives over leaks. The list grows every time something
# new shows up; comments record the source so future pruning is
# possible.
_CREDENTIAL_PATTERNS: tuple[re.Pattern[str], ...] = (
    # OpenAI-style: sk-... / sk-proj-... — at least 32 chars after the
    # prefix to avoid false-positiving plain "sk-" abbreviations.
    re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_\-]{32,}\b"),
    # Anthropic.
    re.compile(r"\bsk-ant-[A-Za-z0-9_\-]{32,}\b"),
    # GitHub personal access tokens (classic + fine-grained).
    re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{32,}\b"),
    # Slack bot / app / user tokens.
    re.compile(r"\bxox[bapor]-[A-Za-z0-9-]{8,}-[A-Za-z0-9-]{8,}\b"),
    # AWS access key id.
    re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    # Google API key.
    re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    # Bearer-style tokens — only flag long ones to avoid catching
    # `Bearer foo` in test fixtures.
    re.compile(r"\bBearer\s+[A-Za-z0-9_\-\.]{40,}\b", re.IGNORECASE),
    # PEM headers — these unambiguously mark a private key.
    re.compile(r"-----BEGIN\s+(?:RSA\s+|EC\s+|OPENSSH\s+|PGP\s+)?PRIVATE\s+KEY-----"),
)


def scan_content(content: str) -> Optional[str]:
    """Return a refusal reason iff the content trips a security check.

    Pure function — easy to unit-test. Returns None when the content
    is clean.
    """
    if not isinstance(content, str):
        return "content must be a string"
    if not content.strip():
        return "content is empty"
    if len(content) > MAX_FACT_CHARS:
        return f"content exceeds {MAX_FACT_CHARS} chars"
    for ch in _ZERO_WIDTH_CHARS:
        if ch in content:
            return "content contains invisible Unicode (rejected)"
    for pat in _CREDENTIAL_PATTERNS:
        if pat.search(content):
            return "content matches a credential pattern (rejected)"
    return None


# ---- types ----------------------------------------------------------

@dataclass(frozen=True)
class Fact:
    id: str
    category: str
    content: str
    trust: float
    created_at: int
    updated_at: int
    tags: tuple[str, ...]


@dataclass(frozen=True)
class FactHit:
    fact: Fact
    score: float
    snippet: str


# ---- main class -----------------------------------------------------

class FactStore:
    """One `facts.db` per agent home, under `memory/facts.db`.

    Co-locating with `memory.db` keeps the sqlite-related state in
    one directory; they're separate files so a wipe of one (the
    operator running `rtxclaw memory index --force`) doesn't take
    out the other.
    """

    def __init__(self, agent_home: Path) -> None:
        self.agent_home = Path(agent_home)
        self.memory_dir = self.agent_home / "memory"
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.memory_dir / "facts.db"
        self._init_db()

    # -- connection / schema -----------------------------------------

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(str(self.db_path))
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("PRAGMA synchronous=NORMAL")
            con.execute("PRAGMA temp_store=MEMORY")
        except sqlite3.DatabaseError:
            pass
        return con

    def _init_db(self) -> None:
        con = self._connect()
        try:
            con.executescript(_SCHEMA)
            con.commit()
        finally:
            con.close()

    # -- write path --------------------------------------------------

    @staticmethod
    def _fact_id(content: str) -> str:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    @staticmethod
    def _normalize_tags(tags: Any) -> tuple[str, ...]:
        if tags is None:
            return ()
        if isinstance(tags, str):
            parts = [t.strip() for t in tags.split(",") if t.strip()]
        elif isinstance(tags, (list, tuple)):
            parts = [str(t).strip() for t in tags if str(t).strip()]
        else:
            return ()
        return tuple(sorted(set(parts)))

    def add(
        self,
        *,
        category: str,
        content: str,
        tags: Any = None,
        trust: float = DEFAULT_TRUST,
    ) -> tuple[Optional[Fact], Optional[str]]:
        """Insert a fact. Returns (fact, error). On dup, returns
        (existing_fact, "duplicate"). On security refusal, returns
        (None, reason).
        """
        reason = scan_content(content)
        if reason is not None:
            return None, reason
        category = (category or "").strip().lower() or "fact"
        norm_tags = self._normalize_tags(tags)
        try:
            trust_v = max(0.0, min(1.0, float(trust)))
        except (TypeError, ValueError):
            trust_v = DEFAULT_TRUST
        fid = self._fact_id(content)
        now_ms = int(time.time() * 1000)
        con = self._connect()
        try:
            row = con.execute(
                "SELECT id, category, content, trust, created_at, updated_at, tags "
                "FROM facts WHERE id = ?",
                (fid,),
            ).fetchone()
            if row is not None:
                # Don't overwrite an existing fact's category/trust on dup —
                # the second author may not know what the first set.
                return _row_to_fact(row), "duplicate"
            con.execute(
                "INSERT INTO facts(id, category, content, trust, created_at, "
                "updated_at, tags) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (fid, category, content, trust_v, now_ms, now_ms,
                 json.dumps(list(norm_tags))),
            )
            con.execute(
                "INSERT INTO facts_fts(text, fact_id, category) VALUES (?, ?, ?)",
                (content, fid, category),
            )
            con.commit()
        finally:
            con.close()
        return Fact(
            id=fid, category=category, content=content, trust=trust_v,
            created_at=now_ms, updated_at=now_ms, tags=norm_tags,
        ), None

    def remove(self, content_prefix: str) -> tuple[int, Optional[str]]:
        """Remove facts whose content starts with or contains
        `content_prefix`. Refuses if more than one row matches — the
        caller must narrow the prefix to identify exactly one fact.
        """
        pat = (content_prefix or "").strip()
        if not pat:
            return 0, "content_prefix required"
        con = self._connect()
        try:
            rows = con.execute(
                "SELECT id, content FROM facts WHERE content LIKE ? LIMIT 5",
                (f"%{pat}%",),
            ).fetchall()
            if not rows:
                return 0, f"no fact matches {pat!r}"
            if len(rows) > 1:
                return 0, (
                    f"{len(rows)} facts match {pat!r} — narrow the prefix to "
                    "identify exactly one"
                )
            fid = rows[0]["id"]
            con.execute("DELETE FROM facts WHERE id = ?", (fid,))
            con.execute("DELETE FROM facts_fts WHERE fact_id = ?", (fid,))
            con.commit()
        finally:
            con.close()
        return 1, None

    def update(
        self, *, old_content_prefix: str, new_content: str,
    ) -> tuple[Optional[Fact], Optional[str]]:
        """Replace one fact's content (preserves category + trust + tags).

        Refuses on multi-match — same as `remove`.
        """
        pat = (old_content_prefix or "").strip()
        if not pat:
            return None, "old_content_prefix required"
        reason = scan_content(new_content)
        if reason is not None:
            return None, reason
        con = self._connect()
        try:
            rows = con.execute(
                "SELECT id, category, trust, tags FROM facts "
                "WHERE content LIKE ? LIMIT 5",
                (f"%{pat}%",),
            ).fetchall()
            if not rows:
                return None, f"no fact matches {pat!r}"
            if len(rows) > 1:
                return None, (
                    f"{len(rows)} facts match {pat!r} — narrow the prefix to "
                    "identify exactly one"
                )
            row = rows[0]
            old_id = row["id"]
            new_id = self._fact_id(new_content)
            now_ms = int(time.time() * 1000)
            # Drop the old row + insert under a new id (id == hash(content)).
            con.execute("DELETE FROM facts WHERE id = ?", (old_id,))
            con.execute("DELETE FROM facts_fts WHERE fact_id = ?", (old_id,))
            con.execute(
                "INSERT INTO facts(id, category, content, trust, created_at, "
                "updated_at, tags) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (new_id, row["category"], new_content, float(row["trust"]),
                 now_ms, now_ms, row["tags"] or "[]"),
            )
            con.execute(
                "INSERT INTO facts_fts(text, fact_id, category) VALUES (?, ?, ?)",
                (new_content, new_id, row["category"]),
            )
            con.commit()
        finally:
            con.close()
        return self.get(new_id), None

    def feedback(
        self, *, fact_id_or_prefix: str, helpful: bool,
    ) -> tuple[Optional[Fact], Optional[str]]:
        """Bump trust up (helpful=True) or down (False)."""
        key = (fact_id_or_prefix or "").strip()
        if not key:
            return None, "fact_id_or_prefix required"
        con = self._connect()
        try:
            row = con.execute(
                "SELECT id, content, trust FROM facts WHERE id = ?",
                (key,),
            ).fetchone()
            if row is None:
                rows = con.execute(
                    "SELECT id, content, trust FROM facts "
                    "WHERE content LIKE ? LIMIT 5",
                    (f"%{key}%",),
                ).fetchall()
                if not rows:
                    return None, f"no fact matches {key!r}"
                if len(rows) > 1:
                    return None, (
                        f"{len(rows)} facts match {key!r} — narrow the prefix"
                    )
                row = rows[0]
            cur = float(row["trust"])
            new = cur + (TRUST_HELPFUL_DELTA if helpful else -TRUST_UNHELPFUL_DELTA)
            new = max(0.0, min(1.0, new))
            now_ms = int(time.time() * 1000)
            con.execute(
                "UPDATE facts SET trust = ?, updated_at = ? WHERE id = ?",
                (new, now_ms, row["id"]),
            )
            con.commit()
            updated = con.execute(
                "SELECT id, category, content, trust, created_at, updated_at, tags "
                "FROM facts WHERE id = ?",
                (row["id"],),
            ).fetchone()
        finally:
            con.close()
        return _row_to_fact(updated), None

    # -- read path ---------------------------------------------------

    def get(self, fact_id: str) -> Optional[Fact]:
        con = self._connect()
        try:
            row = con.execute(
                "SELECT id, category, content, trust, created_at, updated_at, tags "
                "FROM facts WHERE id = ?",
                (fact_id,),
            ).fetchone()
        finally:
            con.close()
        return _row_to_fact(row) if row else None

    def list(
        self, *, category: Optional[str] = None, limit: int = 50,
    ) -> list[Fact]:
        con = self._connect()
        try:
            if category:
                rows = con.execute(
                    "SELECT id, category, content, trust, created_at, "
                    "updated_at, tags FROM facts WHERE category = ? "
                    "ORDER BY updated_at DESC LIMIT ?",
                    (category.strip().lower(), int(limit)),
                ).fetchall()
            else:
                rows = con.execute(
                    "SELECT id, category, content, trust, created_at, "
                    "updated_at, tags FROM facts "
                    "ORDER BY updated_at DESC LIMIT ?",
                    (int(limit),),
                ).fetchall()
        finally:
            con.close()
        return [_row_to_fact(r) for r in rows]

    def search(
        self, query: str, *, top_k: int = DEFAULT_MAX_RESULTS,
    ) -> list[FactHit]:
        """FTS search blended with trust score.

        Final score = bm25_score * (0.5 + 0.5 * trust). Trust acts as
        a multiplier from 0.5 (trust=0) to 1.0 (trust=1), so a low-
        trust fact never beats a higher-trust fact at equal BM25 — and
        a totally distrusted fact still ranks at half its BM25, not
        zero, so the operator sees it (and can correct via
        `fact_feedback`).
        """
        query = (query or "").strip()
        if not query:
            return []
        match = build_fts_query(query)
        if match is None:
            return []
        con = self._connect()
        try:
            rows = con.execute(
                "SELECT f.fact_id AS fact_id, "
                "       snippet(facts_fts, 0, '', '', '…', 64) AS snippet, "
                "       bm25(facts_fts) AS rank, "
                "       fa.category AS category, fa.content AS content, "
                "       fa.trust AS trust, fa.created_at AS created_at, "
                "       fa.updated_at AS updated_at, fa.tags AS tags "
                "FROM facts_fts AS f "
                "JOIN facts AS fa ON fa.id = f.fact_id "
                "WHERE facts_fts MATCH ? "
                "ORDER BY rank LIMIT ?",
                (match, max(1, int(top_k)) * 4),
            ).fetchall()
        finally:
            con.close()
        scored: list[FactHit] = []
        for r in rows:
            bm25 = bm25_rank_to_score(float(r["rank"]))
            trust = float(r["trust"] or 0.0)
            score = bm25 * (0.5 + 0.5 * trust)
            fact = Fact(
                id=r["fact_id"],
                category=r["category"] or "fact",
                content=r["content"] or "",
                trust=trust,
                created_at=int(r["created_at"] or 0),
                updated_at=int(r["updated_at"] or 0),
                tags=tuple(json.loads(r["tags"] or "[]")) if r["tags"] else (),
            )
            scored.append(FactHit(
                fact=fact,
                score=score,
                snippet=(r["snippet"] or fact.content)[:SNIPPET_CHARS],
            ))
        scored.sort(key=lambda h: h.score, reverse=True)
        return scored[: max(1, int(top_k))]


def _row_to_fact(row: Optional[sqlite3.Row]) -> Optional[Fact]:
    if row is None:
        return None
    try:
        tags = tuple(json.loads(row["tags"] or "[]"))
    except (TypeError, ValueError):
        tags = ()
    return Fact(
        id=row["id"],
        category=row["category"] or "fact",
        content=row["content"] or "",
        trust=float(row["trust"] or 0.0),
        created_at=int(row["created_at"] or 0),
        updated_at=int(row["updated_at"] or 0),
        tags=tags,
    )


# ---- auto-extract from saved sessions -------------------------------

# Sentence-level patterns we treat as fact candidates. Operating on
# pre-split sentences lets us pick out the actual claim — extracting
# whole turns would just add session noise.
#
# The triggers below were tuned against rtxclaw's own session corpus.
# Add to them sparingly: every regex here means more rows in
# `facts.db`, more trust-decay churn, and more chance of capturing
# something that LOOKS like a fact but is actually banter.
_FACT_TRIGGERS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b(?:I|we)\s+(?:always|never|usually|prefer|like|use)\b", re.IGNORECASE),
    re.compile(r"\b(?:from now on|going forward|remember that)\b", re.IGNORECASE),
    re.compile(r"\b(?:runs?|lives?|located|installed)\s+(?:on|at|in)\b", re.IGNORECASE),
    re.compile(r"\b(?:the\s+)?(?:default|setting|config|password|key|token|endpoint|host|port)\s+(?:is|=)\b", re.IGNORECASE),
    # "<Name> is <a/the> <something>" — covers "Carlito is the operator",
    # "MarketData-News-X is the news pipeline", etc.
    re.compile(r"^\s*[A-Z][\w\-]+\s+is\s+(?:a|an|the|my|our)\b"),
)

_SENTENCE_SPLIT_RE = re.compile(r"(?<=[\.\!\?])\s+(?=[A-Z\(\[])")


def _split_sentences(text: str) -> list[str]:
    """Cheap sentence splitter — good enough for fact extraction."""
    if not isinstance(text, str):
        return []
    chunks = _SENTENCE_SPLIT_RE.split(text.strip())
    return [c.strip() for c in chunks if c and c.strip()]


def looks_like_fact(sentence: str) -> bool:
    """Heuristic: is this sentence worth saving as a fact candidate?

    Rules:
    - Skip very short or very long sentences (< 12 chars / > 280).
    - Skip questions (end with '?').
    - Skip imperatives that look like instructions to the model
      (e.g. "Run the tests", "Open the file") — too noisy.
    - Match at least one trigger pattern.
    """
    s = (sentence or "").strip()
    if len(s) < 12 or len(s) > 280:
        return False
    if s.endswith("?"):
        return False
    # Reject sentences that are pure code or path-like noise.
    if s.count("/") > 4 or s.count("`") > 4:
        return False
    for pat in _FACT_TRIGGERS:
        if pat.search(s):
            return True
    return False


def extract_facts_from_session(
    session_data: dict,
    *,
    max_per_session: int = 6,
) -> list[str]:
    """Pull candidate fact sentences out of one session JSON.

    Looks at user turns first (operator preferences are the highest-
    signal source) then assistant content. Caps the output so a
    chatty session can't flood the store.
    """
    if not isinstance(session_data, dict):
        return []
    out: list[str] = []
    seen: set[str] = set()
    turns = session_data.get("turns") or []
    if not isinstance(turns, list):
        return []

    # Local helper to avoid pulling _extract_user_text over from
    # session_index (the dependency would go the wrong way).
    def _user_text(value: Any) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, list):
            parts = [
                p.get("text", "") for p in value
                if isinstance(p, dict) and str(p.get("type") or "").lower() == "text"
            ]
            return "\n".join(p for p in parts if p)
        return str(value or "")

    for turn in turns:
        if not isinstance(turn, dict):
            continue
        if turn.get("in_progress"):
            continue
        for source in (_user_text(turn.get("user")), turn.get("content") or ""):
            if not isinstance(source, str) or not source:
                continue
            for sentence in _split_sentences(source):
                if not looks_like_fact(sentence):
                    continue
                norm = sentence.strip()
                if norm in seen:
                    continue
                seen.add(norm)
                # Reuse the security scan so auto-extracted facts go
                # through the same gate as model-supplied ones.
                if scan_content(norm) is not None:
                    continue
                out.append(norm)
                if len(out) >= max_per_session:
                    return out
    return out


# ---- event-bus subscriber ------------------------------------------

_REGISTERED: set[str] = set()


def subscribe_for_agent(*, home: Path, quiet_seconds: float = 2.0) -> bool:
    """Wire `session_saved` → fact extraction. Idempotent."""
    key = str(Path(home).resolve())
    if key in _REGISTERED:
        return False

    async def handler(payload: dict[str, Any]) -> None:
        ev_home = (payload or {}).get("agent_home", "")
        try:
            if ev_home and Path(ev_home).resolve() != Path(home).resolve():
                return
        except Exception:  # noqa: BLE001
            return
        path_str = (payload or {}).get("path", "")
        if not path_str:
            return
        try:
            data = json.loads(Path(path_str).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        candidates = extract_facts_from_session(data)
        if not candidates:
            return
        store = FactStore(Path(home))
        added = 0
        for content in candidates:
            fact, err = store.add(
                category="auto",
                content=content,
                tags=("auto",),
                trust=0.3,  # auto-extracted starts at low trust
            )
            if fact is not None and err is None:
                added += 1
        if added:
            _log.debug(
                "sqlite_facts: auto-extracted %d fact(s) from %s",
                added, path_str,
            )

    from rtxclaw_core.event_bus import get_bus
    bus = get_bus()
    bus.subscribe(
        "session_saved", handler,
        quiet_seconds=quiet_seconds,
        name=f"sqlite_facts[{Path(home).name}]",
    )
    _REGISTERED.add(key)
    return True


# ---- formatting (used by the tool runner) ---------------------------

def _format_fact_line(fact: Fact, *, idx: int, snippet: str = "") -> str:
    tag_part = f" tags={','.join(fact.tags)}" if fact.tags else ""
    return (
        f"### {idx}. [{fact.category}] {fact.id[:12]} "
        f"(trust={fact.trust:.2f}{tag_part})\n"
        f"{snippet or fact.content[:SNIPPET_CHARS]}"
    )


def fact_store(
    *,
    action: str,
    category: str = "",
    content: str = "",
    old_content_prefix: str = "",
    new_content: str = "",
    query: str = "",
    tags: Any = None,
    top_k: int = DEFAULT_MAX_RESULTS,
    workspace_origin: str = "",
    agent_home: Optional[Path] = None,
) -> str:
    """Public dispatch for the `fact_store` tool.

    Sub-actions: `add`, `search`, `list`, `remove`, `update`.
    """
    if not _is_private_origin(workspace_origin):
        return (
            "fact_store refused: this session's workspace_origin is not "
            "private."
        )
    home = agent_home or _resolve_agent_home()
    if home is None:
        return "fact_store failed: agent home not resolvable from env."
    action = (action or "").strip().lower()
    if action not in ("add", "search", "list", "remove", "update"):
        return f"fact_store failed: unknown action {action!r}"
    store = FactStore(home)

    if action == "add":
        fact, err = store.add(category=category, content=content, tags=tags)
        if err is not None and fact is None:
            return f"fact_store add refused: {err}"
        if err == "duplicate" and fact is not None:
            return (
                f"fact_store add: duplicate (id {fact.id[:12]} already in "
                f"store with trust={fact.trust:.2f})"
            )
        assert fact is not None
        return f"fact_store add: ok (id {fact.id[:12]}, trust={fact.trust:.2f})"

    if action == "search":
        hits = store.search(query, top_k=top_k)
        if not hits:
            return f"fact_store search: no matches for {query!r}"
        bits = [f"# fact_store: {query!r}", f"_{len(hits)} hit(s)_", ""]
        for i, h in enumerate(hits, 1):
            bits.append(_format_fact_line(h.fact, idx=i, snippet=h.snippet))
            bits.append(f"_score={h.score:.3f}_")
            bits.append("")
        return "\n".join(bits).rstrip() + "\n"

    if action == "list":
        facts = store.list(category=category or None, limit=int(top_k) * 3 or 30)
        if not facts:
            cat = f" category={category!r}" if category else ""
            return f"fact_store list: no facts{cat}"
        bits = [f"# fact_store: list ({len(facts)})", ""]
        for i, f in enumerate(facts, 1):
            bits.append(_format_fact_line(f, idx=i))
            bits.append("")
        return "\n".join(bits).rstrip() + "\n"

    if action == "remove":
        n, err = store.remove(old_content_prefix or content)
        if err is not None:
            return f"fact_store remove refused: {err}"
        return f"fact_store remove: ok ({n} fact removed)"

    if action == "update":
        fact, err = store.update(
            old_content_prefix=old_content_prefix,
            new_content=new_content,
        )
        if err is not None:
            return f"fact_store update refused: {err}"
        assert fact is not None
        return f"fact_store update: ok (new id {fact.id[:12]})"

    return f"fact_store failed: unhandled action {action!r}"


def fact_feedback(
    *,
    fact_id_or_prefix: str,
    helpful: bool,
    workspace_origin: str = "",
    agent_home: Optional[Path] = None,
) -> str:
    if not _is_private_origin(workspace_origin):
        return "fact_feedback refused: workspace_origin is not private."
    home = agent_home or _resolve_agent_home()
    if home is None:
        return "fact_feedback failed: agent home not resolvable from env."
    store = FactStore(home)
    fact, err = store.feedback(
        fact_id_or_prefix=fact_id_or_prefix, helpful=bool(helpful),
    )
    if err is not None:
        return f"fact_feedback refused: {err}"
    assert fact is not None
    return (
        f"fact_feedback: ok (id {fact.id[:12]} → trust={fact.trust:.2f}, "
        f"{'helpful' if helpful else 'unhelpful'})"
    )


def _resolve_agent_home() -> Optional[Path]:
    """Same resolution as `memory_tools._resolve_agent_home`."""
    explicit = os.environ.get("RTXCLAW_AGENT_HOME")
    if explicit:
        return Path(explicit).expanduser()
    sdir = os.environ.get("RTXCLAW_SESSIONS_DIR")
    if sdir:
        p = Path(sdir).expanduser()
        if p.name == "sessions":
            return p.parent
    return None


# ---- DDL ------------------------------------------------------------

_SCHEMA = """
CREATE TABLE IF NOT EXISTS facts (
  id          TEXT PRIMARY KEY,
  category    TEXT NOT NULL DEFAULT 'fact',
  content     TEXT NOT NULL,
  trust       REAL NOT NULL DEFAULT 0.5,
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL,
  tags        TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_facts_category ON facts(category);
CREATE INDEX IF NOT EXISTS idx_facts_updated  ON facts(updated_at);

CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(
  text,
  fact_id  UNINDEXED,
  category UNINDEXED,
  tokenize='unicode61'
);
"""


# ---- MemoryProvider adapter ----------------------------------------

# Spec-aligned name for callers that want the "store" thing, separate
# from the "provider" thing. `FactStore` is the original name retained
# for back-compat with earlier callers + tests; new code should prefer
# `SqliteFactsStore`.
SqliteFactsStore = FactStore


class SqliteFactsProvider:
    """`MemoryProvider` adapter around `SqliteFactsStore`.

    Lives here (not in `memory_manager.py`) so the manager imports
    one symbol per provider rather than carrying the integration
    code itself.

    The class implements the `MemoryProvider` ABC duck-typed — we
    don't import the ABC here to avoid a circular import
    (`memory_manager` already imports from this module via the
    factory). ABC compliance is verified at the bus-wiring site.
    """

    @property
    def name(self) -> str:
        return "sqlite_facts"

    def is_available(self) -> bool:
        # Pure stdlib + sqlite — always available.
        return True

    async def initialize(self, agent_home: Path, cfg: Any) -> None:
        self._home = Path(agent_home)
        # Touch the DB once so the schema lands eagerly.
        SqliteFactsStore(self._home)

    def get_tool_schemas(self) -> list[dict]:
        # Tools are registered globally via `tools/registry.py`; the
        # provider doesn't surface its own. Empty list keeps the
        # contract explicit.
        return []

    async def handle_tool_call(self, name: str, args: dict) -> Any:
        origin = str((args or {}).get("workspace_origin") or "")
        if not _is_private_origin(origin):
            return f"{name} refused: workspace_origin is not private."
        if name == "fact_store":
            return fact_store(
                action=str(args.get("action") or ""),
                category=str(args.get("category") or ""),
                content=str(args.get("content") or ""),
                old_content_prefix=str(args.get("old_content_prefix") or ""),
                new_content=str(args.get("new_content") or ""),
                query=str(args.get("query") or ""),
                tags=args.get("tags"),
                top_k=int(args.get("top_k") or 6),
                workspace_origin=origin,
                agent_home=self._home,
            )
        if name == "fact_feedback":
            return fact_feedback(
                fact_id_or_prefix=str(args.get("fact_id_or_prefix") or ""),
                helpful=bool(args.get("helpful")),
                workspace_origin=origin,
                agent_home=self._home,
            )
        raise NotImplementedError(
            f"sqlite_facts: unknown tool {name!r}"
        )

    async def prefetch(self, query: str) -> str:
        """Top-N matching facts as a `[RECALLED CONTEXT]` body.

        The manager wraps the return value in the envelope; this
        method only emits the body lines.
        """
        store = SqliteFactsStore(self._home)
        hits = store.search(query or "", top_k=3)
        if not hits:
            return ""
        bits: list[str] = []
        for h in hits:
            bits.append(
                f"- ({h.fact.category}, trust={h.fact.trust:.2f}) "
                f"{h.fact.content}"
            )
        return "\n".join(bits)

    async def sync_turn(self, user: str, assistant: str) -> None:
        """Per-turn extraction.

        Cheap pass: combine user + assistant text, run the
        regex-based fact extractor on it, add new candidates at
        low trust. The manager already strips `[RECALLED CONTEXT]`
        envelopes from the assistant text before calling us, so
        we won't capture our own previous prefetch as a "fact".
        """
        merged = f"{user or ''}\n{assistant or ''}".strip()
        if not merged:
            return
        # Wrap in a session-shaped dict so we can reuse the existing
        # extractor without a separate code path.
        session_data = {
            "turns": [{
                "user": user or "",
                "content": assistant or "",
                "started_at": "",
            }],
        }
        candidates = extract_facts_from_session(session_data)
        if not candidates:
            return
        store = SqliteFactsStore(self._home)
        for content in candidates:
            store.add(
                category="auto", content=content,
                tags=("auto",), trust=0.3,
            )

    async def on_session_end(
        self, turns: list[dict], session_hash: str = "",
    ) -> None:
        """Bulk extraction across all turns of a saved session."""
        candidates = extract_facts_from_session({"turns": turns or []})
        if not candidates:
            return
        store = SqliteFactsStore(self._home)
        for content in candidates:
            store.add(
                category="auto", content=content,
                tags=("auto",), trust=0.3,
            )

    async def on_pre_compress(self, messages: list[dict]) -> None:
        """No-op for now. Future: extract facts before compaction
        discards them. Today the heartbeat-driven `synth_memory`
        covers the cross-session knowledge-lift path."""
        return

    async def on_memory_write(
        self, action: str, content: str, category: str,
    ) -> None:
        """Mirror a `remember()` write to facts.db.

        Only `add` writes are mirrored (replace/remove rely on the
        original entry being substring-identifiable, which doesn't
        translate cleanly to fact ids). Best-effort: any failure
        path returns silently — the daily log is the source of
        truth.
        """
        if (action or "").lower() != "add":
            return
        text = (content or "").strip()
        if not text:
            return
        try:
            SqliteFactsStore(self._home).add(
                category=category or "context",
                content=text,
                tags=("from_remember",),
                trust=0.6,
            )
        except Exception:  # noqa: BLE001
            pass

    def shutdown(self) -> None:
        # No persistent connection — every method opens / closes its
        # own. Nothing to release.
        return None


__all__ = [
    "DEFAULT_TRUST",
    "DEFAULT_MAX_RESULTS",
    "Fact",
    "FactHit",
    "FactStore",
    "SqliteFactsProvider",
    "SqliteFactsStore",
    "extract_facts_from_session",
    "fact_feedback",
    "fact_store",
    "looks_like_fact",
    "scan_content",
    "subscribe_for_agent",
]
