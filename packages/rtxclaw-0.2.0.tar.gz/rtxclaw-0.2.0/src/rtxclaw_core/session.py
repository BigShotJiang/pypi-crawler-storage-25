from __future__ import annotations

import json
import os
import secrets
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# Global default — used only by callers that don't pass an explicit
# `sessions_dir`/`root` (legacy direct-spawn paths). Agents always pass
# their own per-agent sessions dir, so this default never fires for the
# agent flow. Kept cwd-independent so we never leak a `.rtxclaw/` into
# the project tree.
SESSIONS_DIR = Path.home() / ".rtxclaw" / "sessions"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class _ObjectIdGenerator:
    """MongoDB-style ObjectId generator with a counter persisted across runs.

    12 bytes → 24 hex chars:
      - 4 bytes: seconds-since-epoch timestamp (big-endian)
      - 5 bytes: per-process random nonce (constant across calls in a process)
      - 3 bytes: monotonically increasing counter

    The counter starts at zero, but `seed_from(sessions_dir)` scans existing
    session files at agent boot and bumps the counter past the highest
    one on disk. So across an agent restart:

        process A creates 0001…000005, exits
        process B boots, seed_from sets counter=5, next .new() → 0001…000006

    That gives you **optimistic sequential** IDs without an inter-process
    lock: each process picks up where the last one left off, and within a
    process the counter increments under a thread lock. The nonce stays
    random per-process so two agents that happen to start at the exact
    same wall-clock second still produce distinct IDs.

    Why not strict-sequential numeric IDs? Because two agent processes
    seeded from the same disk state would both pick "next = 6" and write
    colliding files. The nonce is the collision-safety net under real
    concurrency — sequential where possible, unique always.
    """

    def __init__(self) -> None:
        self._nonce = secrets.token_bytes(5)
        self._counter = 0
        self._lock = threading.Lock()

    def seed_from(self, sessions_dir: Path) -> None:
        """Bump the in-process counter to the max counter byte found on
        disk. Idempotent — the next `.new()` call returns max+1.

        Called once at agent boot from `AgentApp.__init__` before any
        sessions are created. If the dir doesn't exist or contains no
        ObjectId-named files, the counter stays at 0.
        """
        try:
            entries = list(sessions_dir.iterdir())
        except (OSError, FileNotFoundError):
            return
        max_counter = -1
        for p in entries:
            stem = p.stem
            # ObjectId is exactly 24 hex chars; the trailing 6 are the counter
            if len(stem) != 24:
                continue
            try:
                c = int(stem[-6:], 16)
            except ValueError:
                continue
            if c > max_counter:
                max_counter = c
        if max_counter >= 0:
            with self._lock:
                self._counter = max_counter

    def new(self) -> str:
        with self._lock:
            self._counter = (self._counter + 1) & 0xFFFFFF
            counter = self._counter
        ts = int(time.time()) & 0xFFFFFFFF
        oid = ts.to_bytes(4, "big") + self._nonce + counter.to_bytes(3, "big")
        return oid.hex()


_oid_gen = _ObjectIdGenerator()


def new_object_id() -> str:
    """Return a fresh MongoDB-style ObjectId as a 24-char hex string."""
    return _oid_gen.new()


def seed_session_id_counter(sessions_dir: Path) -> None:
    """Seed the module-level ObjectId counter from disk.

    Call once at agent boot so the counter resumes past the highest
    existing session ID; subsequent `Session.new()` calls produce
    sequential counters across the agent restart boundary.
    """
    _oid_gen.seed_from(sessions_dir)


@dataclass
class Session:
    hash: str
    title: str
    created_at: str
    system_prompt: str
    model: str
    endpoint: str
    turns: list[dict[str, Any]] = field(default_factory=list)
    # Permission mode the saved `system_prompt` was composed with. Used
    # by `agent_runtime` to decide whether the cached prompt is still
    # valid for the next turn — a mode switch (Shift+Tab in the TUI)
    # forces a fresh `load_system_prompt(...)` so the right MODE-*.md
    # file is in effect.
    system_mode: str = ""
    # The frontend-reported workspace context, captured at session
    # creation. `workspace_cwd` is the absolute filesystem directory the
    # frontend was launched from (TUI / `-p` / Telegram poller); the
    # agent injects it as a `# WORKSPACE-CONTEXT` section at the tail of
    # the system prompt so the model knows which folder the user is
    # operating in. `workspace_origin` is a short tag identifying the
    # frontend ("tui", "oneshot", "telegram", "api"). Both default to
    # empty strings; nothing is injected when both are empty (preserves
    # byte-stable prompts for callers that don't care).
    workspace_cwd: str = ""
    workspace_origin: str = ""
    # Tokenizer/protocol family of the upstream this session is bound
    # to. Empty = use cfg.backend at turn time. Stored alongside
    # `endpoint` so a session created against an alternate endpoint
    # (e.g. `rtxclaw --model gpu-c`) keeps the right backend tag for
    # every subsequent turn — without this, switching endpoints
    # mid-config would silently mismatch the tokenizer.
    backend: str = ""
    # Max context window in tokens for the bound model. 0 = use
    # cfg.upstream_max_context fallback. OpenClaw-aligned name; per
    # session because two configured `models[]` rows can advertise
    # different contextWindows (e.g. gpu-a 256k vs gpu-c 32k) and the
    # compaction guard must trigger at the right threshold for each.
    context_window: int = 0
    # Number of successful compactions this session has run. Bumps on
    # each `_compact_via_llm` success. The pre-compaction memory-flush
    # gate uses this to avoid re-flushing within the same cycle —
    # mirrors OpenClaw's `entry.compactionCount`.
    compaction_count: int = 0
    # Compaction count at which the most recent pre-compaction memory
    # flush ran. Equals `compaction_count` after a flush; differs after
    # a fresh compaction has happened, which re-arms the flush gate.
    memory_flush_compaction_count: int = -1
    # ISO timestamp of the last pre-compaction memory flush — purely
    # informational, surfaced via `rtxclaw memory status`.
    last_memory_flush_at: str = ""
    # --- pinned facts + rolling compaction summary ------------------
    # Facts the model has explicitly pinned via the `pin_fact` tool, or
    # that an operator pinned out-of-band. These survive every
    # compaction stage (deterministic and LLM-based), are re-injected
    # into the message list right after the system prompt, and persist
    # across turns. Use sparingly — every pinned fact costs prompt
    # tokens on every round.
    pinned_facts: list[str] = field(default_factory=list)
    # Rolling cross-compaction summary. The LLM summary produced by
    # `_compact_via_llm` is normally session-local (one summary per
    # compaction event, replacing the prior one). When a session
    # compacts repeatedly, facts established in compaction N can be
    # lost by compaction N+1's summary if the model focused on more
    # recent material. This field accumulates a SECOND-ORDER summary
    # across compactions so old context isn't silently dropped. Bounded
    # by `_COMPACTION_SUMMARY_MAX_CHARS` in agent_runtime.
    compaction_summary: str = ""
    # Per-session frontend visibility flags. Both default to OFF so a
    # fresh session keeps the chat clean (no reasoning stream, no tool
    # output flood); the operator opts in via `/reasoning on|stream`
    # and `/tool on`. Telegram (and any other stream-aware client)
    # reads these from the saved session record so each session
    # carries its own preference instead of falling back to a per-chat
    # default that's unrelated to which session is currently bound.
    # The model's THINKING behaviour is independent and continues to
    # be controlled by `cfg.enable_thinking` / the `/thinking` command.
    reasoning_visibility: str = "off"
    tool_output_visible: bool = False
    # ---- agents/ refactor attribution fields (Phase 2) -------------
    #
    # Set by ``rtxclaw_core.agents.session_log.record_session_creation``
    # at agent.create_session() time. Additive — sessions saved before
    # the refactor lack these fields and the loader / index tolerates
    # their absence via dataclass defaults.
    agent_name: str = ""
    engine: str = ""                # "local_llm" | "claude_cli" | …
    system_prompt_sha256: str = ""  # stable hash for fine-tune grouping
    # Privacy gate for reasoning traces. When False, ``record_turn``
    # drops the ``thinking`` channel from the on-disk record; live
    # render in the TUI still receives it (gated separately by
    # ``reasoning_visibility``).
    persist_reasoning_traces: bool = True

    @classmethod
    def new(
        cls,
        *,
        system_prompt: str,
        model: str,
        endpoint: str,
        sessions_dir: Path | None = None,  # kept for API stability; unused for id
        system_mode: str = "",
        workspace_cwd: str = "",
        workspace_origin: str = "",
        backend: str = "",
        context_window: int = 0,
    ) -> "Session":
        # Resolve at call time so test/runtime monkey-patches of the module
        # constant take effect.
        if sessions_dir is None:
            sessions_dir = SESSIONS_DIR
        h = new_object_id()
        return cls(
            hash=h,
            title=f"untitled-{h[-8:]}",  # only show the trailing counter+nonce in the title
            created_at=_now(),
            system_prompt=system_prompt,
            model=model,
            endpoint=endpoint,
            system_mode=system_mode,
            workspace_cwd=workspace_cwd,
            workspace_origin=workspace_origin,
            backend=backend,
            context_window=context_window,
        )

    def add_turn(
        self,
        *,
        user: Any,
        thinking: str,
        content: str,
        started_at: str,
        ended_at: str,
        aborted: bool = False,
        error: str | None = None,
        metrics: dict[str, Any] | None = None,
        in_progress: bool = False,
    ) -> None:
        if not self.turns and self.title.startswith("untitled-"):
            self.title = self._derive_title(user)
        new_entry = {
            "user": user,
            "thinking": thinking,
            "content": content,
            "started_at": started_at,
            "ended_at": ended_at,
            "aborted": aborted,
            "error": error,
            "metrics": metrics,
            "in_progress": in_progress,
        }
        # In-progress checkpoint updates the last turn IN PLACE when
        # it's still an in-progress entry for the SAME user prompt —
        # the engine flushes one of these per round boundary, and
        # appending each as a fresh entry would explode ``turns[]`` into
        # N near-duplicate rows. The terminal record_turn (with
        # ``in_progress=False``) likewise overwrites the trailing
        # in-progress marker so the saved turn is the final state,
        # not stacked partials. New user prompts always append.
        if (
            self.turns
            and self.turns[-1].get("in_progress")
            and self.turns[-1].get("user") == user
        ):
            self.turns[-1] = new_entry
            return
        self.turns.append(new_entry)

    @staticmethod
    def _derive_title(text: Any, limit: int = 60) -> str:
        # `text` is either a plain string OR an OpenAI-style multi-part
        # content list (vision turns ship `[image_url, text]`). Pull the
        # first non-empty text part out before deriving the title; fall
        # back to "[image]" when the user sent a bare photo with no caption.
        if isinstance(text, list):
            text_part = ""
            for part in text:
                if isinstance(part, dict) and str(part.get("type") or "").lower() == "text":
                    text_part = part.get("text") or ""
                    if text_part:
                        break
            text = text_part or "[image]"
        if not isinstance(text, str):
            text = str(text or "")
        first = next((line for line in text.strip().splitlines() if line.strip()), "")
        if not first:
            return "session"
        return first[:limit] + ("…" if len(first) > limit else "")

    def save(self, root: Path | None = None, *, force: bool = False) -> Path:
        # Resolve at call time so test/runtime monkey-patches of the module
        # constant take effect.
        if root is None:
            root = SESSIONS_DIR
        root = Path(root)
        path = root / f"{self.hash}.json"
        # Skip persistence for sessions that have no observable content:
        # zero turns AND no compaction history AND no pinned facts AND
        # no compaction summary. The acp_bridge eagerly calls save on
        # session/new so session/list survives a restart, but that left
        # one orphan zero-turn file per TUI launch on disk indefinitely
        # (operators were closing fresh TUIs without prompting). Once a
        # turn or any other mutation arrives, save() does run normally
        # and the file lands. Pass ``force=True`` to override (e.g. a
        # test that explicitly wants the empty-save path exercised).
        is_empty = (
            not self.turns
            and not self.compaction_count
            and not self.pinned_facts
            and not (self.compaction_summary or "").strip()
        )
        # The empty-skip only prevents the FIRST write — once a file
        # exists on disk for this sid, every subsequent save is an
        # update, not a creation, and the "orphan zero-turn file"
        # concern doesn't apply. Without this guard, mutations made
        # before the first turn (most importantly ``/model`` swapping
        # ``self.model`` / ``self.endpoint`` via ``set_config_option``)
        # never reach disk, and ``Agent.get_session`` re-reads the
        # original values — the worker then talks to the wrong
        # upstream while the TUI's status bar shows the new one.
        if is_empty and not force and not path.exists():
            return path
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(
            {
                "hash": self.hash,
                "title": self.title,
                "created_at": self.created_at,
                "system_prompt": self.system_prompt,
                "system_mode": self.system_mode,
                "workspace_cwd": self.workspace_cwd,
                "workspace_origin": self.workspace_origin,
                "model": self.model,
                "endpoint": self.endpoint,
                "backend": self.backend,
                "context_window": self.context_window,
                "compaction_count": self.compaction_count,
                "memory_flush_compaction_count": self.memory_flush_compaction_count,
                "last_memory_flush_at": self.last_memory_flush_at,
                "pinned_facts": list(self.pinned_facts),
                "compaction_summary": self.compaction_summary,
                "reasoning_visibility": self.reasoning_visibility,
                "tool_output_visible": self.tool_output_visible,
                "turns": self.turns,
                # ---- agents/ refactor attribution fields (Phase 2) --
                # Additive. Existing readers (TUI history, ACP load
                # session, telegram resume) ignore unknown keys.
                "agent_name": self.agent_name,
                "engine": self.engine,
                "system_prompt_sha256": self.system_prompt_sha256,
                "persist_reasoning_traces": self.persist_reasoning_traces,
            },
            indent=2,
            ensure_ascii=False,
        )
        # Atomic flush: write to a sibling tmp file, fsync, rename. Stops
        # a crash / SIGKILL / out-of-disk mid-write from leaving a
        # truncated JSON behind that the next agent boot can't parse.
        # Per-hash tmp suffix so two saves of the same session can't
        # collide (they're serialized by the dispatch loop anyway, but
        # belt-and-suspenders).
        tmp = path.with_name(f".{path.name}.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        # Notify subscribers (session_index, memory_manager). Best-
        # effort: any failure here — bus not running, importer cycle,
        # unrelated subscriber raising — must not corrupt the save
        # contract. The JSON on disk IS the source of truth; events
        # are downstream-only.
        try:
            from rtxclaw_core.event_bus import get_bus
            agent_home = root.parent if root.name == "sessions" else root
            get_bus().publish(
                "session_saved",
                {
                    "agent_home": str(agent_home),
                    "session_hash": self.hash,
                    "path": str(path),
                    "workspace_origin": self.workspace_origin,
                },
            )
        except Exception:  # noqa: BLE001
            pass
        return path
